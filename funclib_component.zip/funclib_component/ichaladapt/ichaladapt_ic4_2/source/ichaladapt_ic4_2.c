	/*****************************************************************************
* 版权所有(C) 2020, ZTE Corp. ZXSDR-RRU Platform BSP
*----------------------------------------------------------------------------
* 模 块 名 : bsp
* 文件名称 : ichaladapt_ic4.c
* 文件标识 : {[N/A]}
* 内容摘要 : 本文件提供了ICHAL适配层接口函数实现
* 注意事项 : 无
* 作    者 : 王涛10248577
* 创建日期 : 2020-11-04
* 当前版本 : Ver1.0
*----------------------------------------------------------------------------
* 变更记录 :
*
* $记录1
* 变 更 单: $0000000(N/A)
* 责 任 人: 王涛10248577
* 修改日戳: 2020-11-04
* 变更说明: 创建文件
*----------------------------------------------------------------------------
*/

#include "tx_gunb_cfg.h"
#include "ichaladapt_timedelay_ic4_2.h"
#include "ichaladapt_ic4_2.h"
#include "ichaladapt_cfr_ic4_2.h"
#include "ichaladapt_dtx_ic4_2.h"
#include "ichaldbg_ic4_2.h"
#include <pthread.h>
#include "prealloc.h"
#include "ru_basedef.h"
#include "tdd_cfg.h"
#include "ichalstub_ic4_2.h"
#include "crmsoc.h"
#include "cpri_top.h"
#include "cpri_sw.h"
#include "cpri_cw.h"
#include "ichal_common_api.h"
#include "vgactrl_api.h"
#include "cfg_gain_api.h"
#include "ac_api.h"
#include "gunb_cfg_api.h"
#include "crmntl.h"
#include "crmopt.h"
#include "crmdif.h"
#include "sw_ctrl_api.h"
#include "roe_api.h"
#include "tsg.h"
#include "gpio_reg_pack_api.h"
#include "resource_alloc_api.h"
#include "zx211413gpio.h"
#include "gunb_cfg_api.h"
#include "cpam_inter_api.h"
#include <math.h>
#include "ichal_opt_api.h"
#include "gate_dtx_api.h"
#include "tdd_api.h"
#include "crmalm.h"
#include "rx_gunb_cfg.h"
#include "cellcfgapi.h"
#include "ntl_l2ss_api.h"
#include "cpri_reg.h"
#include "mesginter_drv.h"
#include "cfr_api.h"
#include "dif_reg.h"
#include "gf_reg.h"
#include "bif_reg.h"
#include "utdoa_ctrl_api.h"
#include "psync.h"
#include "jitter_cfg.h"
#include "dlyapi.h"
#include "ichaladapt_j204_ic4_2.h"
#include "cellcfg.h"
#include "opt_cpri_api.h"
#include "resource_alloc_info.h"
#include "cfg_filter.h"
#include "optsmp.h"
#include "fr_maintain.h"
#include "hal_comm.h"
#include "sample_ch.h"
#include "dl_bank.h"
#include "ul_bank.h"
#include "pwm_unit.h"
#include "io_api.h"
#include "oneclick_collect.h"
#include "rruinfo.h"
#include "freq_cfg.h"
#include "sample_api.h"
#include "dif_dly_api.h"
#include "sample_carr.h"

#define ICHAL_ADAPT_FUNC_DEF(func, ...)       \
    {                                         \
        UINT32 retVal = BSP_OK;               \
        retVal = IcHalApi##func(__VA_ARGS__); \
        \
        return retVal;                        \
    }
#define TDM_UIAIGA_EN 1
#define MAX_SFP_NUM 4

UINT32 g_phyNoSfpNoMap[MAX_SFP_NUM] = {0,0,0,0}; /*数组下标表示光笼编号，元素值表示对应的物理光口号(serdes lane)*/
UINT32 g_ulRfDef204AndRfDly[BSP_IC42_MAX_TX_CHAN_NUM][PRX] = {0};
UINT32 g_cpgChnStatusMask = 0xffffffff;  /* 削峰硬件计算CPG状态掩码，由低到高的8个bit对应中频通道0-7，bit值1表示暂停，0表示开启 */
UINT32 g_BbuGlobalOptPort0 = 0xff;
UINT32 g_BbuGlobalOptPort1 = 0xff;
UINT32 g_setRcfFlagMask = 0;//按通道bit写1为使能RCF
UINT32  g_LastSlaveIcFlag = 0; /*是否是最后一片IC标志*/
UINT32 g_DtxDiffDlyFlag = 0;
VOID setRcfFlagMask(UINT32 mask)
{
    g_setRcfFlagMask = mask;
}

UINT32 BspHalAdaptSetPhyNoBySfpNo(UINT32 sfpNo,UINT32 phyNo)
{
    if(sfpNo >= MAX_SFP_NUM)
    {
        return BSP_ERROR;
    }
    g_phyNoSfpNoMap[sfpNo] = phyNo;

    return BSP_OK;
}
UINT32 BspHalAdaptGetPhyNoBySfpNo(UINT32 sfpNo)   /*光笼转换成物理光口号，部分机型光笼编号和serdes lane编号有交叉*/
{
    if(sfpNo >= MAX_SFP_NUM)
    {
        return BSP_ERROR;
    }

    return g_phyNoSfpNoMap[sfpNo];
}
/**************************************************************************
                            HAL公共接口
**************************************************************************/

UINT32 BspHalAdaptGetDifVer(VOID)
{
    IcHalApiGetDifVer();
    return BSP_OK;
}
#if 0
UINT32 BspHalAdaptGetIcChanMax(VOID)
{
    return BSP_IC4_DIF_CHAN_NUM;
} 
#endif

#if defined(CFR_REFACTOR)
#else
static T_DifCfgSave s_tDifCfgSave[E_DIF_CFG_TYPE_MAX] = {0};

VOID SaveDifCfg(UINT32 type, VOID *pAddr, UINT32 linkunm, UINT32 difChNum)
{
    if (type < E_DIF_CFG_TYPE_MAX)
    {
        s_tDifCfgSave[type].pAddr = pAddr;
        s_tDifCfgSave[type].linkunm = linkunm;
        s_tDifCfgSave[type].difChNum = difChNum;
    }
    return;
}

T_DifCfgSave *GetDifCfgSave(UINT32 type)
{
    if (type < E_DIF_CFG_TYPE_MAX)
    {
        return &(s_tDifCfgSave[type]);
    }
    return NULL;
}

#endif

static UINT32 pthreadRdSemTake(pthread_rwlock_t *ptSem)
{
    INT32 lTimes = 40;
    while (lTimes--)
    {
        if (0 == pthread_rwlock_tryrdlock(ptSem))
        {
            return BSP_OK;
        }
        BspSysMsDelay(50);
    }
    return BSP_ERROR;
}

static UINT32 pthreadWrSemTake(pthread_rwlock_t *ptSem)
{
    INT32 lTimes = 40;
    while (lTimes--)
    {
        if (0 == pthread_rwlock_trywrlock(ptSem))
        {
            return BSP_OK;
        }
        BspSysMsDelay(50);
    }
    return BSP_ERROR;
}

static UINT32 pthreadRdSemGive(pthread_rwlock_t *ptSem)
{
    return pthread_rwlock_unlock(ptSem);
}

static UINT32 pthreadWrSemGive(pthread_rwlock_t *ptSem)
{
    return pthread_rwlock_unlock(ptSem);
}

UINT32 BspHalAdaptDpdicRegRd(UINT32 chip, UINT32 ulPhyAddr, UINT32 ulOffset, UINT32 *ulData)
{
    return DpdIcHalAddrRegRd(chip, ulPhyAddr, ulOffset, ulData);
}

UINT32 BspHalAdaptDpdicRegWr(UINT32 chip, UINT32 ulPhyAddr, UINT32 ulOffset, UINT32 ulData)
{
    return DpdIcHalAddrRegWr(chip, ulPhyAddr, ulOffset, ulData);
}

/**************************************************************************
                            TDD 帧头相关接口
**************************************************************************/
UINT32 BspHalAdaptSetFrSelect(UINT32 difChan, T_BspHalAdaptFrTypeCfg *pFrTypeCfg)
{
    UINT32 retVal = BSP_OK;
    INPUT_POINTER_CHECK(pFrTypeCfg); 

    if(IS_NCR == BspIsNcr())
    {
        //NCR机型帧头使用随路帧头
        pFrTypeCfg->uiDlFrType = BSP_CHAN_ASSOCIATED_FR_HD;
        pFrTypeCfg->uiUlPostFrType = BSP_CHAN_ASSOCIATED_FR_HD;
    }

    retVal = IcHalApiSetDifFrSelect(difChan,pFrTypeCfg);
    return retVal;
}

UINT32 BspHalAdaptSetFrSelectByDir(UINT32 difChan, UINT32 dir)
{
    UINT32 retVal = BSP_OK;
    T_BspHalAdaptFrTypeCfg t_FrCfg = {BSP_AIR_INTERFACE_FR_HD,BSP_AIR_INTERFACE_FR_HD,BSP_AIR_INTERFACE_FR_HD,0,0};
    if(dir == TX)
    {
        retVal = IcHalApiSetDifDlFrSelect(difChan,t_FrCfg.uiDlFrType);
    }
    if(dir == RX)
    {
        retVal = IcHalApiSetDifUlFrSelect(difChan,t_FrCfg.uiUlChFrType, t_FrCfg.uiUlPostFrType);
    }
    return retVal;
}

/* 中频帧头自震荡 */
UINT32 BspHalAdaptSetFrGenerate(UINT32 frSource, UINT32 frPeriod, UINT32 frNumSource)
{
    return IcHalApiSetFrGenerate(frSource, frPeriod, frNumSource);
}

/*TDD表象结构体转换成底层新的结构体*/
static UINT32 BspFillIcHalTddInfo(T_CarrTddIndCfg *ptSrc, T_DifCarrTddIndCfg *ptDest)
{
    ptDest->uiGroupId   = ptSrc->uiGroupId  ;
    ptDest->uiTddCfgId  = ptSrc->uiTddCfgId ;
    ptDest->uiCarrNo    = ptSrc->uiCarrNo   ;
    ptDest->uiRadioMode = ptSrc->uiRadioMode;
    ptDest->uiChanMask[RX]  = ptSrc->uiChanMask;
    ptDest->uiChanMask[TX]  = ptSrc->uiChanMask;
    ptDest->uiDlUlSwNum = ptSrc->uiDlUlSwNum;
    memcpy_s(ptDest->uiDlUlSwPeriod,MAX_UL_DL_SW_NUM*sizeof(UINT32),\
            ptSrc->uiDlUlSwPeriod, MAX_UL_DL_SW_NUM*sizeof(UINT32));
    memcpy_s(ptDest->uiDlSymbolNum,MAX_UL_DL_SW_NUM*sizeof(UINT32),\
                            ptSrc->uiDlSymbolNum, MAX_UL_DL_SW_NUM*sizeof(UINT32));
    memcpy_s(ptDest->uiUlSymbolNum,MAX_UL_DL_SW_NUM*sizeof(UINT32),\
                            ptSrc->uiUlSymbolNum, MAX_UL_DL_SW_NUM*sizeof(UINT32));
    return BSP_OK;
}

/*TDD机型的TDD配置*/
UINT32 BspHalAdaptDifCfgTdd_TDD(T_CarrTddIndCfg *pTddIndCfg, UINT32 chanMask)
{
    UINT32 retVal = BSP_OK;
    T_DifCarrTddIndCfg halCarrTddIndCfg = {0};
    INPUT_POINTER_CHECK(pTddIndCfg); 
    BspFillIcHalTddInfo(pTddIndCfg,&halCarrTddIndCfg);
    halCarrTddIndCfg.uiChanMask[RX]  = chanMask ;
    halCarrTddIndCfg.uiChanMask[TX]  = chanMask ;
    retVal = IcHalApiDifCfgTdd(&halCarrTddIndCfg);
    return retVal;
}

/*TX RX ：TDD机型的TDD配置
    上下行分离中，此接口无需拆分上下行，只需分别传入上下行通道掩码即可
*/
UINT32 BspHalAdaptDifCfgTxOrRxTdd_TDD(T_CarrTddIndCfg *pTddIndCfg, UINT32 txChanMask,UINT32 rxChanMask)
{
    UINT32 retVal = BSP_OK;
    T_DifCarrTddIndCfg halCarrTddIndCfg = {0};
    INPUT_POINTER_CHECK(pTddIndCfg); 
    BspFillIcHalTddInfo(pTddIndCfg,&halCarrTddIndCfg);
    halCarrTddIndCfg.uiChanMask[RX]  = rxChanMask ;
    halCarrTddIndCfg.uiChanMask[TX]  = txChanMask ;
    retVal = IcHalApiDifCfgTdd(&halCarrTddIndCfg);
    return retVal;
}




/*FDD机型配置TDD接口*/
UINT32 BspHalAdaptDifCfgTdd_FDD(T_BspHalAdaptCarrTddIndCfg *pTddIndCfg)
{
    UINT32 retVal = BSP_OK;
    INPUT_POINTER_CHECK(pTddIndCfg); 
    retVal = IcHalApiDifCfgTdd(pTddIndCfg);
    return retVal;
}

UINT32 BspHalAdaptSetDifFrInit(T_BspHalAdaptFrInitCfg *pFrInitCfg)
{
    UINT32 retVal = BSP_OK;
    
    INPUT_POINTER_CHECK(pFrInitCfg); 
    SaveDifCfg(E_DIF_DIFPARA_FR, (VOID*)pFrInitCfg, 1, 1);        
    retVal = IcHalApiSetDifFrInit((T_DifFrInitCfg*)pFrInitCfg);
    return retVal;    
}


UINT32 BspHalAdaptOptCfgTdd(T_CarrTddIndCfg *pTddIndCfg, UINT32 cfgNum)
{
    UINT32 retVal = BSP_OK;
    INPUT_POINTER_CHECK(pTddIndCfg);
    retVal = IcHalApiOptSetTddCfg(pTddIndCfg, cfgNum);
    return retVal;
}

UINT32 BspHalAdaptGetFrStruct(UINT32 *pFrStructOfUs)
{
    T_DifCfgSave *pSaveCfg = NULL;
    T_BspHalAdaptFrInitCfg *pDifFrInfo = NULL;
    
    pSaveCfg = GetDifCfgSave(E_DIF_DIFPARA_FR);
    if(NULL != pSaveCfg)
    {
        pDifFrInfo = (T_BspHalAdaptFrInitCfg*)(pSaveCfg->pAddr);
        if(NULL != pDifFrInfo)
        {
            *pFrStructOfUs = pDifFrInfo->uiBigFrPeriod;
            return BSP_OK;
        }
    }

    return BSP_ERROR;        
}

UINT32 BspHalApiSetDlTddSel(UINT32 difChan)
{
    UINT32 retVal = 0;
    retVal = IcHalApiSetDlTddSel(difChan);
    return retVal;
}

UINT32 BspHalApiSetUlTddSel(UINT32 difChan)
{
    UINT32 retVal = 0;
    retVal = IcHalApiSetUlTddSel(difChan);
    return retVal;
}

/* Started by AICoder, pid:ne12e937e46e3b2144d30b2f80a62e0a3086c2b4 */
UINT32 BspIcHalApiSetTddSpiEn(UINT32 uiEn)
{
    UINT32 retVal = 0;
    retVal = IcHalApiSetTddSpiEn(uiEn);
    return retVal;
}
/* Ended by AICoder, pid:ne12e937e46e3b2144d30b2f80a62e0a3086c2b4 */

INT32 BspHalAdaptGetFrTmVal(UINT32 ulCfgId, UINT32 ulMode)
{
    INT32 frameDelay = 0;
    INT32 delay = 0;
    frameDelay = IcHalApiGetQcellFrTmVal(ulCfgId,ulMode);

    switch(ulMode)
    {
        case BSP_RADIO_STANDARD_LTE_TDD:
        {
            frameDelay = (-1) * frameDelay;
            delay = NS_TO_CHIP((frameDelay%10000000));
            break;
        }
        case BSP_RADIO_STANDARD_5G:
        {
            delay = NS_TO_CHIP((frameDelay%10000000));
            break;
        }
        default:
        {
            delay = frameDelay;
            break;
        }
    }
    
    return delay;
}

/**************************************************************************
                            射频开关相关接口
**************************************************************************/
/*part1 tdd_timing_gen 参数配置*/
UINT32 BspHalAdaptSetPaLnaBaseGenSel(T_TDD_BASE_TIMING_GEN_SEL *tPara, UINT32 uiTddIdx)
{
	UINT32 retVal = BSP_OK;
	retVal = IcHalApiSetPaLnaBaseGenSel(tPara,uiTddIdx);
	return retVal;
}
UINT32 BspHalAdaptSetAmpBaseGenSel(T_TDD_BASE_TIMING_GEN_SEL *tPara, UINT32 uiTddIdx)
{
	UINT32 retVal = BSP_OK;
	retVal = IcHalApiSetAmpBaseGenSel(tPara,uiTddIdx);
	return retVal;
}
UINT32 BspHalAdaptSetTransBaseGenSel(T_TRX_BASE_TIMING_GEN_SEL *tPara, UINT32 uiTddIdx)
{
	UINT32 retVal = BSP_OK;
	retVal = IcHalApiSetTransBaseGenSel(tPara,uiTddIdx);
	return retVal;
}
UINT32 BspHalAdaptSetAcCtrlBaseGenSel(T_AC_CTRL_TIMING_GEN_SEL *tPara, UINT32 uiTddIdx, UINT32 uiIoIdx)
{
	UINT32 retVal = BSP_OK;
	retVal = IcHalApiSetAcCtrlBaseGenSel(tPara,uiTddIdx, uiIoIdx);
	return retVal;
}
/**************************************************************************/
/*part2 基础时序参数和timing选择配置*/
UINT32 BspHalAdaptSetPaLnaPara(T_PA_LNA_CFG *tPara, UINT32 uiTddIdx)
{
	UINT32 retVal = BSP_OK;
	retVal = IcHalApiSetPaLnaPara(tPara,uiTddIdx);
	return retVal;
}
UINT32 BspHalAdaptSetAmpPara(T_AMP_CFG *tPara, UINT32 uiTddIdx)
{
	UINT32 retVal = BSP_OK;
	retVal = IcHalApiSetAmpPara(tPara,uiTddIdx);
	return retVal;
}
UINT32 BspHalAdaptSetTransPara(T_TRANS_CFG *tPara, UINT32 uiTddIdx)
{
	UINT32 retVal = BSP_OK;
	retVal = IcHalApiSetTransPara(tPara,uiTddIdx);
	return retVal;
}
UINT32 BspHalAdaptSetAcCtrlPara(T_AC_CTRL_CFG *tPara, UINT32 uiTddIdx, UINT32 uiIdx)
{
	UINT32 retVal = BSP_OK;
	retVal = IcHalApiSetAcCtrlPara(tPara, uiTddIdx, uiIdx);
	return retVal;
}
UINT32 BspHalAdaptSetAcCtrlFddPara(T_AC_CTRL_FDD_CFG *tPara, UINT32 uiTddIdx, UINT32 uiIdx)
{
	UINT32 retVal = BSP_OK;
	retVal = IcHalApiSetAcCtrlFddPara(tPara, uiTddIdx, uiIdx);
	return retVal;
}
/* Started by AICoder, pid:p7e45fd4a5g97c414d8a0b85e0dd1b0da1576cb1 */
UINT32 BspHalAdaptSetAcCtrlModeMapSel(UINT32 uiTddIdx, UINT32 uiMode)
{
#ifdef UT_FT_TEST
    return BSP_OK;
#endif
    return IcHalApiSetAcCtrlModeMapSel(uiTddIdx, uiMode);
}
/* Ended by AICoder, pid:p7e45fd4a5g97c414d8a0b85e0dd1b0da1576cb1 */
/**************************************************************************/
/*part3 mux选择初始化配置--tddsel dtx合入 ue定位是否合入 默认输出电平*/
UINT32 BspHalAdaptSetPaOutSel(UINT32 uiIdx, UINT32 uiSel)  /*pa开关输出*/
{
	UINT32 retVal = BSP_OK;
	retVal = IcHalApiSetPaOutSel(uiIdx,uiSel);
	return retVal;
}
UINT32 BspHalAdaptSetPaTdd4Sel1(UINT32 uiIdx, UINT32 uiSel)  /*tdd 四选一*/
{
	UINT32 retVal = BSP_OK;
	retVal = IcHalApiSetPa4Sel1(uiIdx,uiSel);
	return retVal;
}
UINT32 BspHalAdaptSetPaUeOut2Sel1(UINT32 uiIdx, UINT32 uiSel)  /*ue定位输出二选一*/
{
	UINT32 retVal = BSP_OK;
	retVal = IcHalApiSetPaUeOut2Sel1(uiIdx,uiSel);
	return retVal;
}
UINT32 BspHalAdaptSetPaDtxCombEn(UINT32 uiIdx, UINT32 uiDtxEn)  /*dtx是否合入*/
{
	UINT32 retVal = BSP_OK;
	retVal = IcHalApiSetPaDtxCombEn(uiIdx,uiDtxEn);
	return retVal;
}

UINT32 BspHalAdaptSetPaAlarmEn(UINT32 uiIdx, UINT32 uiEnMask)  /*pa告警合路配置*/
{
	UINT32 retVal = BSP_OK;
	retVal = IcHalApiSetPaAlarmEn(uiIdx,uiEnMask);
	return retVal;
}
UINT32 BspHalAdaptSetPaMuxPara(T_TDD_BASE_PALNAAMP_OUT_CFGA *tPara, UINT32 uiIdx)  /*pa模块mux初始化参数配置*/
{
	UINT32 retVal = BSP_OK;

	retVal = BspHalAdaptSetPaOutSel(uiIdx,tPara->uiBaseCfg.uiTddOutSelx);
	retVal |= BspHalAdaptSetPaTdd4Sel1(uiIdx,tPara->uiBaseCfg.uiTddOut4Sel1x);
	retVal |= BspHalAdaptSetPaUeOut2Sel1(uiIdx,tPara->uiBaseCfg.uiUeOut2Sel1);
	retVal |= BspHalAdaptSetPaDtxCombEn(uiIdx,tPara->uiBaseCfg.uiDtxComOrNot);
	retVal |= BspHalAdaptSetPaAlarmEn(uiIdx,tPara->uiAlarmEn);

	return retVal;
}
UINT32 BspHalAdaptSetLnaAlarmEn(UINT32 uiIdx, UINT32 uiEnMask)  /*lna告警合路配置*/
{
	UINT32 retVal = BSP_OK;
	retVal = IcHalApiSetLnaAlarmEn(uiIdx,uiEnMask);
	return retVal;
}
/*LNA Mux参数初始化配置*/
UINT32 BspHalAdaptSetLnaMuxPara(T_TDD_BASE_PALNAAMP_OUT_CFGA *tPara, UINT32 uiIdx)
{
	UINT32 retVal = BSP_OK;
	retVal = IcHalApiSetCombLna8InsPara(&tPara->uiBaseCfg,uiIdx);
	retVal |= IcHalApiSetLnaAlarmEn(uiIdx,tPara->uiAlarmEn);
	return retVal;
}
/*LNA Mux各个参数配置*/
UINT32 BspHalAdaptSetAmpOutSel(UINT32 uiIdx, UINT32 uiSel)  /*amp开关输出*/
{
	UINT32 retVal = BSP_OK;
	retVal = IcHalApiSetAmpOutSel(uiIdx,uiSel);
	return retVal;
}
UINT32 BspHalAdaptSetAmpTdd4Sel1(UINT32 uiIdx, UINT32 uiSel)  /*tdd 四选一*/
{
	UINT32 retVal = BSP_OK;
	retVal = IcHalApiSetAmp4Sel1(uiIdx,uiSel);
	return retVal;
}
UINT32 BspHalAdaptSetAmpUeOut2Sel1(UINT32 uiIdx, UINT32 uiSel)  /*ue定位输出二选一*/
{
	UINT32 retVal = BSP_OK;
	retVal = IcHalApiSetAmpUeOut2Sel1(uiIdx,uiSel);
	return retVal;
}
UINT32 BspHalAdaptSetAmpDtxCombEn(UINT32 uiIdx, UINT32 uiDtxEn)  /*dtx是否合入*/
{
	UINT32 retVal = BSP_OK;
	retVal = IcHalApiSetAmpDtxCombEn(uiIdx,uiDtxEn);
	return retVal;
}

/* Started by AICoder, pid:d431554878e2fb0149d20b1a10bc602c7239b8fd */
UINT32 BspHalAdaptSetLnaUeOut2Sel1(UINT32 uiIdx, UINT32 uiSel)
{
    UINT32 retVal = BSP_OK;
    retVal = IcHalApiSetUeLna2Sel1(uiIdx,uiSel);
    return retVal;
}

UINT32 BspHalAdaptSetRxEnUeOut2Sel1(UINT32 uiIdx, UINT32 uiSel)
{
    UINT32 retVal = BSP_OK;
    retVal = IcHalApiSetUeRxEn2Sel1(uiIdx,uiSel);
    return retVal;
}

UINT32 BspHalAdaptSetLnaOutSel(UINT32 uiIdx, UINT32 uiSel)
{
    UINT32 retVal = BSP_OK;
    retVal = IcHalApiSetLnaOutSel(uiIdx,uiSel);
    return retVal;
}

UINT32 BspHalAdaptSetRxEnOutSel(UINT32 uiIdx, UINT32 uiSel)
{
    UINT32 retVal = BSP_OK;
    retVal = IcHalApiSetTrxRxEnOutSel(uiIdx,uiSel);
    return retVal;
}

UINT32 BspHalAdaptSetLnaDtxCombEn(UINT32 uiIdx, UINT32 uiSel)
{
    UINT32 retVal = BSP_OK;
    retVal = IcHalApiSetLnaDtxOrNot(uiIdx,uiSel);
    return retVal;
}

UINT32 BspHalAdaptSetRxEnDtxCombEn(UINT32 uiIdx, UINT32 uiSel)
{
    UINT32 retVal = BSP_OK;
    retVal = IcHalApiSetRxEnDtxOrNot(uiIdx,uiSel);
    return retVal;
}
/* Ended by AICoder, pid:d431554878e2fb0149d20b1a10bc602c7239b8fd */

UINT32 BspHalAdaptSetAmpMuxPara(T_TDD_BASE_PALNAAMP_OUT_CFGA *tPara, UINT32 uiAmpIdx)
{
	UINT32 retVal = BSP_OK;
	retVal = BspHalAdaptSetAmpOutSel(uiAmpIdx,tPara->uiBaseCfg.uiTddOutSelx);
	retVal |= BspHalAdaptSetAmpTdd4Sel1(uiAmpIdx,tPara->uiBaseCfg.uiTddOut4Sel1x);
	retVal |= BspHalAdaptSetAmpUeOut2Sel1(uiAmpIdx,tPara->uiBaseCfg.uiUeOut2Sel1);
	retVal |= BspHalAdaptSetAmpDtxCombEn(uiAmpIdx,tPara->uiBaseCfg.uiDtxComOrNot);

	return retVal;
}

UINT32 BspHalAdaptSetTxEnOutSel(UINT32 uiIdx, UINT32 uiSel)
{
	UINT32 retVal = BSP_OK;
	retVal = IcHalApiSetTxEnOutSel(uiIdx,uiSel);
	return retVal;
}
UINT32 BspHalAdaptSetTxEnTdd4Sel1(UINT32 uiIdx, UINT32 uiSel)  /*tdd 四选一*/
{
	UINT32 retVal = BSP_OK;
	retVal = IcHalApiSetTxEn4Sel1(uiIdx,uiSel);
	return retVal;
}
UINT32 BspHalAdaptSetTxEnUeOut2Sel1(UINT32 uiIdx, UINT32 uiSel)  /*ue定位输出二选一*/
{
	UINT32 retVal = BSP_OK;
	retVal = IcHalApiSetTxEnUeOut2Sel1(uiIdx,uiSel);
	return retVal;
}
UINT32 BspHalAdaptSetTxEnDtxCombEn(UINT32 uiIdx, UINT32 uiDtxEn)  /*dtx是否合入*/
{
	UINT32 retVal = BSP_OK;
	retVal = IcHalApiSetTxEnDtxCombEn(uiIdx,uiDtxEn);
	return retVal;
}

UINT32 BspHalAdaptSetTransTxMuxPara(T_TDD_BASE_SW_OUT_CFG *tPara, UINT32 uiIdx)
{
	UINT32 retVal = BSP_OK;
	retVal = BspHalAdaptSetTxEnOutSel(uiIdx,tPara->uiTddOutSelx);
	retVal |= BspHalAdaptSetTxEnTdd4Sel1(uiIdx,tPara->uiTddOut4Sel1x);
	retVal |= BspHalAdaptSetTxEnUeOut2Sel1(uiIdx,tPara->uiUeOut2Sel1);
	retVal |= BspHalAdaptSetTxEnDtxCombEn(uiIdx,tPara->uiDtxComOrNot);
	return retVal;
}
UINT32 BspHalAdaptSetTransRxMuxPara(T_TDD_BASE_SW_OUT_CFG *tPara, UINT32 uiIdx)
{
	UINT32 retVal = BSP_OK;
    retVal = IcHalApiSetCombRx8InsPara(tPara, uiIdx);
	return retVal;
}

UINT32 BspHalAdaptSetTransOrxMuxPara(T_TDD_BASE_ORX_OUT_CFG *tPara, UINT32 uiIdx)
{
	UINT32 retVal = BSP_OK;

	retVal = IcHalApiSetCombOrx8InsPara(tPara, uiIdx);
	return retVal;
}
UINT32 BspHalAdaptSetAcEnMuxPara(T_COMB_2INSTANTIATE_PARA *tPara, UINT32 uiIdx)
{
	UINT32 retVal = BSP_OK;
	retVal = IcHalApiSetCombTrans2InsPara(tPara, uiIdx);
	return retVal;
}
UINT32 BspHalAdaptSetAcCtrlMuxPara(T_AC_CTRL_SW_OUT_CFG *tPara, UINT32 uiIdx)
{
	UINT32 retVal = BSP_OK;
	retVal = IcHalApiSetAcCtrlOutPara(tPara, uiIdx);
	return retVal;
}
/*功放保护相关*/
UINT32 BspHalAdaptSetPaLnaProtCfg(T_PA_LNA_PROT_CFG *tPaLnaProt)
{
	UINT32 retVal = BSP_OK;
	retVal = IcHalApiPaLnaProtCfg(tPaLnaProt);
	return retVal;
}
/*pa可以复用成其他功能，其他管脚不会复用成功放，这里目前看不需要识别写到谁的寄存器，只需要判断是否作为pa使用*/
UINT32 BspHalAdaptSetPaProtEnCfg(UINT32 uiIdx, UINT32 uiEn)
{
	UINT32 retVal = BSP_OK;
	retVal = IcHalApiPaProtEnCfg(uiIdx,uiEn);
	return retVal;
}
/*lna可以复用成其他功能，其他管脚不会复用成lna，这里目前看不需要识别写到谁的寄存器，只需要判断是否作为lna使用*/
UINT32 BspHalAdaptSetLnaProtEnCfg(UINT32 uiIdx, UINT32 uiEn)
{
	UINT32 retVal = BSP_OK;
	retVal = IcHalApiLnaProtEnCfg(uiIdx,uiEn);
	return retVal;
}

/*UE使能，UE定位相关*/
UINT32 BspHalAdaptSetPaUeEnCfg(T_UE_EN_CFG *tUeEn, UINT32 uiIdx)
{
	UINT32 retVal = BSP_OK;
	retVal = IcHalApiPaUeEnCfg(tUeEn,uiIdx);
	return retVal;
}
UINT32 BspHalAdaptSetLnaUeEnCfg(T_UE_EN_CFG *tUeEn, UINT32 uiIdx)
{
	UINT32 retVal = BSP_OK;
	retVal = IcHalApiLnaUeEnCfg(tUeEn,uiIdx);
	return retVal;
}
UINT32 BspHalAdaptSetTxUeEnCfg(T_UE_EN_CFG *tUeEn, UINT32 uiIdx)
{
	UINT32 retVal = BSP_OK;
	retVal = IcHalApiTxEnUeEnCfg(tUeEn,uiIdx);
	return retVal;
}
UINT32 BspHalAdaptSetRxUeEnCfg(T_UE_EN_CFG *tUeEn, UINT32 uiIdx)
{
	UINT32 retVal = BSP_OK;
	retVal = IcHalApiRxUeEnCfg(tUeEn,uiIdx);
	return retVal;
}
UINT32 BspHalAdaptSetOrxUeEnCfg(T_UE_EN_CFG *tUeEn, UINT32 uiIdx)
{
	UINT32 retVal = BSP_OK;
	retVal = IcHalApiOrxUeEnCfg(tUeEn,uiIdx);
	return retVal;
}

/*OE使能*/
UINT32 BspHalAdaptSetPaOeEnCfg(UINT32 uiIdx, UINT32 uiIsEnable)
{
	UINT32 retVal = BSP_OK;
	retVal = IcHalApiSetPaOutOe(uiIdx,uiIsEnable);
	return retVal;
}
UINT32 BspHalAdaptSetLnaOeEnCfg(UINT32 uiIdx, UINT32 uiIsEnable)
{
	UINT32 retVal = BSP_OK;
	retVal = IcHalApiSetLnaOutOe(uiIdx,uiIsEnable);
	return retVal;
}
UINT32 BspHalAdaptSetTxOeEnCfg(UINT32 uiIdx, UINT32 uiIsEnable)
{
	UINT32 retVal = BSP_OK;
	retVal = IcHalApiSetTxEnOutOe(uiIdx,uiIsEnable);
	return retVal;
}
UINT32 BspHalAdaptSetAmpOeEnCfg(UINT32 uiIdx, UINT32 uiIsEnable)
{
	UINT32 retVal = BSP_OK;
	retVal = IcHalApiSetAmpOutOe(uiIdx,uiIsEnable);
	return retVal;
}
UINT32 BspHalAdaptSetOrxOeEnCfg(UINT32 uiIdx, UINT32 uiIsEnable)
{
	UINT32 retVal = BSP_OK;
	retVal = IcHalApiSetOrxEnOutOe(uiIdx,uiIsEnable);
	return retVal;
}
UINT32 BspHalAdaptSetRxOeEnCfg(UINT32 uiIdx, UINT32 uiIsEnable)
{
	UINT32 retVal = BSP_OK;
	retVal = IcHalApiSetRxEnOutOe(uiIdx,uiIsEnable);
	return retVal;
}

UINT32 BspHalAdaptSetUlDtxLnaSel(UINT32 uiIdx, T_UL_DTX_SEL *tUlDtxSel)
{
	UINT32 retVal = BSP_OK;
	retVal = IcHalApiUlDtxLnaSel(tUlDtxSel,uiIdx);
	return retVal;
}
UINT32 BspHalAdaptSetUlDtxRxEnSel(UINT32 uiIdx, T_UL_DTX_SEL *tUlDtxSel)
{
	UINT32 retVal = BSP_OK;
	retVal = IcHalApiUlDtxRxEnSel(tUlDtxSel,uiIdx);
	return retVal;
}
UINT32 BspHalAdaptSetDlDtxRouter(UINT32 uiChanId, UINT32 uiSel) /** 8通道到8通道全路由 */
{
	UINT32 retVal = BSP_OK;
	retVal = IcHalApiSetDlDtxRouter(uiChanId,uiSel);
	return retVal;
}
UINT32 BspHalAdaptSetUlDtxRouter(UINT32 uiChanId, UINT32 uiMaskEn40)  /** 下行送来的8路40bit合路使能掩码配置 */
{
	UINT32 retVal = BSP_OK;
	retVal = IcHalApiSetUlDtxRouter(uiChanId,uiMaskEn40);
	return retVal;
}

/* Started by AICoder, pid:wf870ve1f51de4e147fe089b20f533315621f3a4 */
UINT32 BspHalAdaptSetDlDtxPaDly(UINT32 uiChanId, UINT32 uiRiseDly, UINT32 uiFallDly)
{
    UINT32 retVal = BSP_OK;
    retVal = IcHalApiSetDlDtxPaDly(uiChanId, uiRiseDly, uiFallDly);
    return retVal;
}

UINT32 BspHalAdaptSetDlDtxAmpDly(UINT32 uiChanId, UINT32 uiRiseDly, UINT32 uiFallDly)
{
    UINT32 retVal = BSP_OK;
    retVal = IcHalApiSetDlDtxAmpDly(uiChanId, uiRiseDly, uiFallDly);
    return retVal;
}

UINT32 BspHalAdaptSetDlDtxTxenDly(UINT32 uiChanId, UINT32 uiRiseDly, UINT32 uiFallDly)
{
    UINT32 retVal = BSP_OK;
    retVal = IcHalApiSetDlDtxTrxDly(uiChanId, uiRiseDly, uiFallDly);
    return retVal;
}
/*给中频设置标志 区分流程*/
UINT32 BspHalAdaptSetDtxDiffDlyFlag(UINT32 uiDtxDiffDlyFlag)
{
     g_DtxDiffDlyFlag = uiDtxDiffDlyFlag;
     return IcHalApiSetDtxDiffDlyFlag(uiDtxDiffDlyFlag);
}

UINT32 BspHalAdaptGetDtxDiffDlyFlag(VOID)
{
    return g_DtxDiffDlyFlag;
}
/* Ended by AICoder, pid:wf870ve1f51de4e147fe089b20f533315621f3a4 */

UINT32 BspHalAdaptSetDlDtxPaCombEn(UINT32 uiChanId, UINT32 uiMask) /** 下行DTX PA通道合路配置 */
{
	UINT32 retVal = BSP_OK;
	retVal = IcHalApiSetDlDtxPaCombEn(uiChanId,uiMask);
	return retVal;
}
UINT32 BspHalAdaptSetDlDtxPaModeMap(UINT32 uiChanId, UINT32 uiMask) /** 下行DTX PA通道modemap配置 */
{
	UINT32 retVal = BSP_OK;
	retVal = IcHalApiSetDlDtxPaModeMap(uiChanId,uiMask);
	return retVal;
}
UINT32 BspHalAdaptSetDlDtxPa4Sel1(UINT32 uiChanId, UINT32 uiSel) /** 下行DTX PA通道4套tddbase选1 */
{
	UINT32 retVal = BSP_OK;
	retVal = IcHalApiSetDlDtxPa4Sel1(uiChanId,uiSel);
	return retVal;
}
UINT32 BspHalAdaptSetDlDtxPaOutSel(UINT32 uiChanId, UINT32 uiSel)   /** 下行DTX PA通道输出选择 */
{
	UINT32 retVal = BSP_OK;
	retVal = IcHalApiSetDlDtxPaOutSel(uiChanId,uiSel);
	return retVal;
}

UINT32 BspHalAdaptSetDlDtxPaGpSel(UINT32 uiChanId, UINT32 uiSel)    /** 下行DTX PA通道Gp输出选择 */
{
	UINT32 retVal = BSP_OK;
	retVal = IcHalApiSetDlDtxPaGpSel(uiChanId,uiSel);
	return retVal;
}
UINT32 BspHalAdaptSetDlDtxComPaSel(UINT32 uiIdx, UINT32 uiMask)    /** 下行DTX 下行PA管脚的dtx合并选择 */
{
	UINT32 retVal = BSP_OK;
	retVal = IcHalApiSetPaDtxCombSel(uiIdx,uiMask);
	return retVal;
}


UINT32 BspHalAdaptSetDlDtxTxCombEn(UINT32 uiChanId, UINT32 uiMask) /** 下行DTX Trx通道合路配置 */
{
	UINT32 retVal = BSP_OK;
	retVal = IcHalApiSetDlDtxTrxCombEn(uiChanId,uiMask);
	return retVal;
}
UINT32 BspHalAdaptSetDlDtxTxModeMap(UINT32 uiChanId, UINT32 uiMask) /** 下行DTX Trx通道modemap配置 */
{
	UINT32 retVal = BSP_OK;
	retVal = IcHalApiSetDlDtxTrxModeMap(uiChanId,uiMask);
	return retVal;
}
UINT32 BspHalAdaptSetDlDtxTx4Sel1(UINT32 uiChanId, UINT32 uiSel) /** 下行DTX Trx通道4套tddbase选1 */
{
	UINT32 retVal = BSP_OK;
	retVal = IcHalApiSetDlDtxTrx4Sel1(uiChanId,uiSel);
	return retVal;
}
UINT32 BspHalAdaptSetDlDtxTxOutSel(UINT32 uiChanId, UINT32 uiSel)   /** 下行DTX Trx通道输出选择 */
{
	UINT32 retVal = BSP_OK;
	retVal = IcHalApiSetDlDtxTrxOutSel(uiChanId,uiSel);
	return retVal;
}

UINT32 BspHalAdaptSetDlDtxTxGpSel(UINT32 uiChanId, UINT32 uiSel)    /** 下行DTX Trx通道Gp输出选择 */
{
	UINT32 retVal = BSP_OK;
	retVal = IcHalApiSetDlDtxTrxGpSel(uiChanId,uiSel);
	return retVal;
}

UINT32 BspHalAdaptSetDlDtxComTxSel(UINT32 uiIdx, UINT32 uiMask)    /** 下行DTX 下行tx管脚的dtx合并选择 */
{
	UINT32 retVal = BSP_OK;
	retVal = IcHalApiSetTxEnDtxCombSel(uiIdx,uiMask);
	return retVal;
}

UINT32 BspHalAdaptSetDlDtxAmpCombEn(UINT32 uiChanId, UINT32 uiMask) /** 下行DTX Amp通道合路配置 */
{
	UINT32 retVal = BSP_OK;
	retVal = IcHalApiSetDlDtxAmpCombEn(uiChanId,uiMask);
	return retVal;
}
UINT32 BspHalAdaptSetDlDtxAmpModeMap(UINT32 uiChanId, UINT32 uiMask) /** 下行DTX Amp通道modemap配置 */
{
	UINT32 retVal = BSP_OK;
	retVal = IcHalApiSetDlDtxAmpModeMap(uiChanId,uiMask);
	return retVal;
}
UINT32 BspHalAdaptSetDlDtxAmp4Sel1(UINT32 uiChanId, UINT32 uiSel) /** 下行DTX Amp通道4套tddbase选1 */
{
	UINT32 retVal = BSP_OK;
	retVal = IcHalApiSetDlDtxAmp4Sel1(uiChanId,uiSel);
	return retVal;
}
UINT32 BspHalAdaptSetDlDtxAmpOutSel(UINT32 uiChanId, UINT32 uiSel)   /** 下行DTX Amp通道输出选择 */
{
	UINT32 retVal = BSP_OK;
	retVal = IcHalApiSetDlDtxAmpOutSel(uiChanId,uiSel);
	return retVal;
}

UINT32 BspHalAdaptSetDlDtxAmpGpSel(UINT32 uiChanId, UINT32 uiSel)    /** 下行DTX Amp通道Gp输出选择 */
{
	UINT32 retVal = BSP_OK;
	retVal = IcHalApiSetDlDtxAmpGpSel(uiChanId,uiSel);
	return retVal;
}
UINT32 BspHalAdaptSetDlDtxComAmpSel(UINT32 uiIdx, UINT32 uiMask)    /** 下行DTX 下行amp管脚的dtx合并选择 */
{
	UINT32 retVal = BSP_OK;
	retVal = IcHalApiSetAmpDtxCombSel(uiIdx,uiMask);
	return retVal;
}

/*前级DTX控制成0， LTE DTX处于不合入状态TDD 则io输出常低 */
UINT32 BspHalAdaptSetDtxIoLteEn(UINT32 uiChanId, UINT32 uiEn)
{
    UINT32 retVal = BSP_OK;
    retVal = IcHalApiSetDtxIoLteEn(uiChanId, uiEn);
    return retVal;
}

UINT32 BspHalAdaptSetTrxEnAcAcInSlotSel(T_TRX_ACINSLOT_PARA *tPara, UINT32 uiTddIdx)
{
    return IcHalApiSetTrxEnAcAcInSlotSel(tPara, uiTddIdx);
}

UINT32 BspHalAdaptSetPaUeEn(UINT32 uiIdx, UINT32 uiEn)                                /** Pa的Ue使能配置接口 */
{
    return IcHalApiSetPaUeEn(uiIdx,uiEn);
}
UINT32 BspHalAdaptSetLnaUeEn(UINT32 uiIdx, UINT32 uiEn)                               /** Lna的Ue使能配置接口 */
{
    return IcHalApiSetLnaUeEn(uiIdx,uiEn);
}
UINT32 BspHalAdaptSetTxenUeEn(UINT32 uiIdx, UINT32 uiEn)                              /** Txen的Ue使能配置接口 */
{
    return IcHalApiSetTxenUeEn(uiIdx,uiEn);
}
UINT32 BspHalAdaptSetRxenUeEn(UINT32 uiIdx, UINT32 uiEn)                              /** Rxen的Ue使能配置接口 */
{
    return IcHalApiSetRxenUeEn(uiIdx,uiEn);
}
UINT32 BspHalAdaptSetAmpUeEn(UINT32 uiIdx, UINT32 uiEn)                               /** Amp的Ue使能配置接口 */
{
    return IcHalApiSetAmpUeEn(uiIdx,uiEn);
}
/* Started by AICoder, pid:29f3bb2d8eged4414d070aef200ce700b967fa23 */
UINT32 BspHalAdaptSetAcCtrlUeEn(UINT32 uiIdx, UINT32 uiEn)                            /** Ac的Ue使能配置接口  */
{
    return IcHalApiSetAcCtrlUeEn(uiIdx,uiEn);
}
/* Ended by AICoder, pid:29f3bb2d8eged4414d070aef200ce700b967fa23 */
UINT32 BspHalAdaptSetPaBitmap(UINT32 uiIdx, UINT32 uiBitmapLoop, UINT32 uiBitmapVal)  /** Pa的bitmap配置接口 */
{
    return IcHalApiSetPaBitmap(uiIdx,uiBitmapLoop,uiBitmapVal);
}
UINT32 BspHalAdaptSetLnaBitmap(UINT32 uiIdx, UINT32 uiBitmapLoop, UINT32 uiBitmapVal) /** Lna的bitmap配置接口 */
{
    return IcHalApiSetLnaBitmap(uiIdx,uiBitmapLoop,uiBitmapVal);
}
UINT32 BspHalAdaptSetTxenBitmap(UINT32 uiIdx, UINT32 uiBitmapLoop, UINT32 uiBitmapVal)/** Txen的bitmap配置接口 */
{
    return IcHalApiSetTxenBitmap(uiIdx,uiBitmapLoop,uiBitmapVal);
}
UINT32 BspHalAdaptSetRxenBitmap(UINT32 uiIdx, UINT32 uiBitmapLoop, UINT32 uiBitmapVal)/** Rxen的bitmap配置接口 */
{
    return IcHalApiSetRxenBitmap(uiIdx,uiBitmapLoop,uiBitmapVal);
}
UINT32 BspHalAdaptSetAmpBitmap(UINT32 uiIdx, UINT32 uiBitmapLoop, UINT32 uiBitmapVal) /** Amp的bitmap配置接口 */
{
    return IcHalApiSetAmpBitmap(uiIdx,uiBitmapLoop,uiBitmapVal);
}



/* 根据中频号获取当前通道所有载波的制式 返回10进制数，如：8192，转换为16进制为 0x2000*/
UINT32 BspHalAdaptGetTxRadioModeByDifChan(UINT32 uiDifChan,UINT32 *auiRadioMode,UINT32 *auiCarrId)
{
    
    UINT32 uRet = BSP_OK;
    UINT32 uiCarrNum = 0; 

    uRet = IcHalGetTxRadioModeByDifChan(uiDifChan, auiCarrId, auiRadioMode, &uiCarrNum);
    dbgInfoEx("carrNUm is %d \n",uiCarrNum);
    for(UINT32 index=0; index<uiCarrNum; index++)
    {
        dbgInfoEx("carrNumber:%d,  auiCarrId:%d,  radioMode:%d \n",index,auiCarrId[index],auiRadioMode[index]);
    }

    return uRet;
}

/* Started by AICoder, pid:s22391c1460befa142170af410cb70005de7d904 */
/* 根据中频号获取当前通道所有载波的制式 返回10进制数，如：8192，转换为16进制为 0x2000*/
UINT32 BspHalAdaptGetRxRadioModeByDifChan(UINT32 uiDifChan,UINT32 *auiRadioMode,UINT32 *auiCarrId)
{
    UINT32 uRet = BSP_OK;
    UINT32 uiCarrNum = 0; 

    INPUT_POINTER_CHECK(auiRadioMode);
    INPUT_POINTER_CHECK(auiCarrId);

    uRet = IcHalGetRxRadioModeByDifChan(uiDifChan, auiCarrId, auiRadioMode, &uiCarrNum);
    dbgInfoEx("carrNUm is %d \n",uiCarrNum);
    for(UINT32 index=0; index<uiCarrNum; index++)
    {
        dbgInfoEx("carrNumber:%d,  auiCarrId:%d,  radioMode:%d \n",index,auiCarrId[index],auiRadioMode[index]);
    }

    return uRet;
}
/* Ended by AICoder, pid:s22391c1460befa142170af410cb70005de7d904 */

/* 获取通道中的载波数量 */
UINT32 BspHalAdaptGetTxRadioNumByDifChan(UINT32 uiDifChan)
{
    UINT32 uRet = BSP_OK;   
    UINT32 auiCarrId[BSP_DIF_CARR_MAX_NUM] = {0};
    UINT32 auiRadioMode[BSP_DIF_CARR_MAX_NUM] = {0};
    UINT32 uiCarrNum = 0; 

    uRet = IcHalGetTxRadioModeByDifChan(uiDifChan, auiCarrId, auiRadioMode, &uiCarrNum);

    if(BSP_OK != uRet)
    {
        uiCarrNum = -1;
        dbgInfo("get CarrNum error ! uiCarrNum: %d",uiCarrNum);
    }

    return uiCarrNum;
}



/**************************************************************************

                            TDD开关时序控制
**************************************************************************/
UINT32 BspHalAdaptGetPaOutSel(UINT32 uiIdx, UINT32 *uiSel)
{
        UINT32 retVal = (UINT32)0;
        retVal = IcHalApiGetPaOutSel(uiIdx,uiSel);
        return retVal;
}
UINT32 BspHalAdaptGetLnaOutSel(UINT32 uiIdx, UINT32 *uiSel)
{
        UINT32 retVal = (UINT32)0;
        retVal = IcHalApiGetLnaOutSel(uiIdx,uiSel);
        return retVal;
}
UINT32 BspHalAdaptGetAmpOutSel(UINT32 uiIdx, UINT32 *uiSel)
{
        UINT32 retVal = (UINT32)0;
        retVal = IcHalApiGetAmpOutSel(uiIdx,uiSel);
        return retVal;
}
UINT32 BspHalAdaptGetTrxTxEnOutSel(UINT32 uiIdx, UINT32 *uiSel)
{
        UINT32 retVal = (UINT32)0;
        retVal = IcHalApiGetTrxTxEnOutSel(uiIdx,uiSel);
        return retVal;
}
UINT32 BspHalAdaptGetTrxRxEnOutSel(UINT32 uiIdx, UINT32 *uiSel)
{
        UINT32 retVal = (UINT32)0;
        retVal = IcHalApiGetTrxRxEnOutSel(uiIdx,uiSel);
        return retVal;
}
UINT32 BspHalAdaptGetTrxFbEnOutSel(UINT32 uiIdx, UINT32 *uiSel)
{
        UINT32 retVal = (UINT32)0;
        retVal = IcHalApiGetFbSwOutSel(uiIdx,uiSel);
        return retVal;
}
UINT32 BspHalAdaptGetTrxTxEnACOutSel(UINT32 uiIdx, UINT32 *uiSel)
{
        UINT32 retVal = (UINT32)0;
        retVal = IcHalApiGetTrxTxEnACOutSel(uiIdx,uiSel);
        return retVal;
}
UINT32 BspHalAdaptGetTrxRxEnACOutSel(UINT32 uiIdx, UINT32 *uiSel)
{
        UINT32 retVal = (UINT32)0;
        retVal = IcHalApiGetTrxRxEnACOutSel(uiIdx,uiSel);
        return retVal;
}
UINT32 BspHalAdaptGetAcCtrlOutSel(UINT32 uiIdx, UINT32 *uiSel)
{
        UINT32 retVal = (UINT32)0;
        retVal = IcHalApiGetAcCtrlOutSel(uiIdx,uiSel);
        return retVal;
}

/*ac inslot 信号生成配置*/
/* Started by AICoder, pid:d68a0dff72a64b21a1961733a6569503 */
UINT32 BspHalAdaptSetLinkAcInSlotPara(T_AC_INSLOT_PARA *tPara, UINT32 uiTddIdx)
{
    UINT32 retVal = BSP_OK;
    INPUT_POINTER_CHECK(tPara);
    retVal = IcHalApiSetIoTddDlyAcInSlotPara(tPara, uiTddIdx);
    return retVal;
}
/* Ended by AICoder, pid:d68a0dff72a64b21a1961733a6569503 */
#if 0
/**************************************************************************
                            AC 相关接口
**************************************************************************/
//AC-SYNC
UINT32 BspHalAdaptSetACEn(UINT32 uiEn)                    \
ICHAL_ADAPT_FUNC_DEF(SetACEn,uiEn)
UINT32 BspHalAdaptSetAcSync33FrSel(UINT32 uiSel)          \
ICHAL_ADAPT_FUNC_DEF(SetACSync33FrSel,uiSel)
UINT32 BspHalAdaptSetACSyncModeSel(UINT32 uiSel)          \
ICHAL_ADAPT_FUNC_DEF(SetACSyncModeSel,uiSel)
UINT32 BspHalAdaptSetACSyncFrPeriodMode(UINT32 uiMode)    \
ICHAL_ADAPT_FUNC_DEF(SetACSyncFrPeriodMode,uiMode)
UINT32 BspHalAdaptSetACSyncSrcSel(UINT32 uiSel)           \
ICHAL_ADAPT_FUNC_DEF(SetACSyncSrcSel,uiSel)
UINT32 BspHalAdaptSetACSyncCutMode(UINT32 uiMode)         \
ICHAL_ADAPT_FUNC_DEF(SetACSyncCutMode,uiMode)
UINT32 BspHalAdaptSetACSyncPulseWidth(UINT32 uiWidth)              \
ICHAL_ADAPT_FUNC_DEF(SetACSyncPulseWidth,uiWidth)
UINT32 BspHalAdaptSetACSyncHighGate(UINT32 uiHighGate)              \
ICHAL_ADAPT_FUNC_DEF(SetACSyncHighGate,uiHighGate)

//AC---DL_BANK
UINT32 BspHalAdaptSetRamSel(UINT32 uiBlockId, UINT32 uiRamSel)                                        \
ICHAL_ADAPT_FUNC_DEF(SetRamSel,uiBlockId,uiRamSel)
UINT32 BspHalAdaptGetRamSel(UINT32 uiBlockId, UINT32 *uiRamSel)                                       \
ICHAL_ADAPT_FUNC_DEF(GetRamSel,uiBlockId,uiRamSel)
UINT32 BspHalAdaptSetAcPos(UINT32 uiBlockId, UINT32 uiAcPos)                                          \
ICHAL_ADAPT_FUNC_DEF(SetAcPos,uiBlockId,uiAcPos)
UINT32 BspHalAdaptGetAcPos(UINT32 uiBlockId, UINT32 *uiAcPos)                                         \
ICHAL_ADAPT_FUNC_DEF(GetAcPos,uiBlockId,uiAcPos)
UINT32 BspHalAdaptSetAcSyncClear(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 uiClr)                      \
ICHAL_ADAPT_FUNC_DEF(SetAcSyncClear,uiBlockId,uiAcIdx,uiClr)
UINT32 BspHalAdaptGetAcSyncClear(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 *uiClr)                     \
ICHAL_ADAPT_FUNC_DEF(GetAcSyncClear,uiBlockId,uiAcIdx,uiClr)
UINT32 BspHalAdaptSetPostLongDlyTimesCa(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 uiPos)               \
ICHAL_ADAPT_FUNC_DEF(SetPostLongDlyTimesCa,uiBlockId,uiAcIdx,uiPos)
UINT32 BspHalAdaptGetPostLongDlyTimesCa(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 *uiPos)              \
ICHAL_ADAPT_FUNC_DEF(GetPostLongDlyTimesCa,uiBlockId,uiAcIdx,uiPos)
UINT32 BspHalAdaptSetAcGainCa(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 uiGainCa)                      \
ICHAL_ADAPT_FUNC_DEF(SetAcGainCa,uiBlockId,uiAcIdx,uiGainCa)
UINT32 BspHalAdaptGetAcGainCa(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 *uiGainCa)                     \
ICHAL_ADAPT_FUNC_DEF(GetAcGainCa,uiBlockId,uiAcIdx,uiGainCa)
UINT32 BspHalAdaptSetFrameId(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 uiId)                           \
ICHAL_ADAPT_FUNC_DEF(SetFrameId,uiBlockId,uiAcIdx,uiId)
UINT32 BspHalAdaptGetFrameId(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 *uiId)                          \
ICHAL_ADAPT_FUNC_DEF(GetFrameId,uiBlockId,uiAcIdx,uiId)
UINT32 BspHalAdaptSetOdevityFlag(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 uiFlag)                     \
ICHAL_ADAPT_FUNC_DEF(SetOdevityFlag,uiBlockId,uiAcIdx,uiFlag)
UINT32 BspHalAdaptGetOdevityFlag(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 *uiFlag)                    \
ICHAL_ADAPT_FUNC_DEF(GetOdevityFlag,uiBlockId,uiAcIdx,uiFlag)
UINT32 BspHalAdaptSetOdevityEn(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 uiEn)                         \
ICHAL_ADAPT_FUNC_DEF(SetOdevityEn,uiBlockId,uiAcIdx,uiEn)
UINT32 BspHalAdaptGetOdevityEn(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 *uiEn)                        \
ICHAL_ADAPT_FUNC_DEF(GetOdevityEn,uiBlockId,uiAcIdx,uiEn)
UINT32 BspHalAdaptSetFrameIdEn(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 uiEn)                         \
ICHAL_ADAPT_FUNC_DEF(SetFrameIdEn,uiBlockId,uiAcIdx,uiEn)
UINT32 BspHalAdaptGetFrameIdEn(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 *uiEn)                        \
ICHAL_ADAPT_FUNC_DEF(GetFrameIdEn,uiBlockId,uiAcIdx,uiEn)
UINT32 BspHalAdaptSetAc5msEn(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 uiEn)                           \
ICHAL_ADAPT_FUNC_DEF(SetAc5msEn,uiBlockId,uiAcIdx,uiEn)
UINT32 BspHalAdaptGetAc5msEn(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 *uiEn)                          \
ICHAL_ADAPT_FUNC_DEF(GetAc5msEn,uiBlockId,uiAcIdx,uiEn)
UINT32 BspHalAdaptSetOptFrameIdMk(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 uiMask)                    \
ICHAL_ADAPT_FUNC_DEF(SetOptFrameIdMk,uiBlockId,uiAcIdx,uiMask)
UINT32 BspHalAdaptGetOptFrameIdMk(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 *uiMask)                   \
ICHAL_ADAPT_FUNC_DEF(GetOptFrameIdMk,uiBlockId,uiAcIdx,uiMask)
UINT32 BspHalAdaptSetAcDataSelCa(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 uiSelCa)                    \
ICHAL_ADAPT_FUNC_DEF(SetAcDataSelCa,uiBlockId,uiAcIdx,uiSelCa)
UINT32 BspHalAdaptGetAcDataSelCa(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 *uiSelCa)                   \
ICHAL_ADAPT_FUNC_DEF(GetAcDataSelCa,uiBlockId,uiAcIdx,uiSelCa)
UINT32 BspHalAdaptSetGpFrSelCaMod(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 uiMod)                     \
ICHAL_ADAPT_FUNC_DEF(SetGpFrSelCaMod,uiBlockId,uiAcIdx,uiMod)
UINT32 BspHalAdaptGetGpFrSelCaMod(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 *uiMod)                    \
ICHAL_ADAPT_FUNC_DEF(GetGpFrSelCaMod,uiBlockId,uiAcIdx,uiMod)
UINT32 BspHalAdaptSetAcTddConfig(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 uiTddCfg)                   \
ICHAL_ADAPT_FUNC_DEF(SetAcTddConfig,uiBlockId,uiAcIdx,uiTddCfg)
UINT32 BspHalAdaptGetAcTddConfig(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 *uiTddCfg)                  \
ICHAL_ADAPT_FUNC_DEF(GetAcTddConfig,uiBlockId,uiAcIdx,uiTddCfg)
UINT32 BspHalAdaptSetAc10msSelCa(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 uiSelCa)                    \
ICHAL_ADAPT_FUNC_DEF(SetAc10msSelCa,uiBlockId,uiAcIdx,uiSelCa)
UINT32 BspHalAdaptGetAc10msSelCa(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 *uiSelCa)                   \
ICHAL_ADAPT_FUNC_DEF(GetAc10msSelCa,uiBlockId,uiAcIdx,uiSelCa)
UINT32 BspHalAdaptSetAcInsrtTimeCa(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 uiTimeCa)                 \
ICHAL_ADAPT_FUNC_DEF(SetAcInsrtTimeCa,uiBlockId,uiAcIdx,uiTimeCa)
UINT32 BspHalAdaptGetAcInsrtTimeCa(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 *uiTimeCa)                \
ICHAL_ADAPT_FUNC_DEF(GetAcInsrtTimeCa,uiBlockId,uiAcIdx,uiTimeCa)
UINT32 BspHalAdaptSetAcCaliEnCa(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 uiEn)                        \
ICHAL_ADAPT_FUNC_DEF(SetAcCaliEnCa,uiBlockId,uiAcIdx,uiEn)
UINT32 BspHalAdaptGetAcCaliEnCa(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 *uiEn)                       \
ICHAL_ADAPT_FUNC_DEF(GetAcCaliEnCa,uiBlockId,uiAcIdx,uiEn)
UINT32 BspHalAdaptSetAcInsrtStartAddrCa(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 uiAddr)              \
ICHAL_ADAPT_FUNC_DEF(SetAcInsrtStartAddrCa,uiBlockId,uiAcIdx,uiAddr)
UINT32 BspHalAdaptGetAcInsrtStartAddrCa(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 *uiAddr)             \
ICHAL_ADAPT_FUNC_DEF(GetAcInsrtStartAddrCa,uiBlockId,uiAcIdx,uiAddr)
UINT32 BspHalAdaptSetGpIdCa(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 uiGpId)                          \
ICHAL_ADAPT_FUNC_DEF(SetGpIdCa,uiBlockId,uiAcIdx,uiGpId)
UINT32 BspHalAdaptGetGpIdCa(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 *uiGpId)                         \
ICHAL_ADAPT_FUNC_DEF(GetGpIdCa,uiBlockId,uiAcIdx,uiGpId)
UINT32 BspHalAdaptSetAcInsrtEndAddr(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 uiAddr)                  \
ICHAL_ADAPT_FUNC_DEF(SetAcInsrtEndAddr,uiBlockId,uiAcIdx,uiAddr)
UINT32 BspHalAdaptGetAcInsrtEndAddr(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 *uiAddr)                 \
ICHAL_ADAPT_FUNC_DEF(GetAcInsrtEndAddr,uiBlockId,uiAcIdx,uiAddr)
UINT32 BspHalAdaptSetAcSeqLength(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 uiAcSeqLen)                 \
ICHAL_ADAPT_FUNC_DEF(SetAcSeqLength,uiBlockId,uiAcIdx,uiAcSeqLen)
UINT32 BspHalAdaptGetAcSeqLength(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 *uiAcSeqLen)                \
ICHAL_ADAPT_FUNC_DEF(GetAcSeqLength,uiBlockId,uiAcIdx,uiAcSeqLen)
UINT32 BspHalAdaptSetPreAcInsrtDlyCa(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 uiDly)                  \
ICHAL_ADAPT_FUNC_DEF(SetPreAcInsrtDlyCa,uiBlockId,uiAcIdx,uiDly)
UINT32 BspHalAdaptGetPreAcInsrtDlyCa(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 *uiDly)                 \
ICHAL_ADAPT_FUNC_DEF(GetPreAcInsrtDlyCa,uiBlockId,uiAcIdx,uiDly)
UINT32 BspHalAdaptSetAcInsrtZeroNumCa(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 uiZeroNum)             \
ICHAL_ADAPT_FUNC_DEF(SetAcInsrtZeroNumCa,uiBlockId,uiAcIdx,uiZeroNum)
UINT32 BspHalAdaptGetAcInsrtZeroNumCa(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 *uiZeroNum)            \
ICHAL_ADAPT_FUNC_DEF(GetAcInsrtZeroNumCa,uiBlockId,uiAcIdx,uiZeroNum)
UINT32 BspHalAdaptSetPostAcInsrtDlyCa(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 uiDly)                 \
ICHAL_ADAPT_FUNC_DEF(SetPostAcInsrtDlyCa,uiBlockId,uiAcIdx,uiDly)
UINT32 BspHalAdaptGetPostAcInsrtDlyCa(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 *uiDly)                \
ICHAL_ADAPT_FUNC_DEF(GetPostAcInsrtDlyCa,uiBlockId,uiAcIdx,uiDly)
UINT32 BspHalAdaptSetPostAcInsrtLongDlyCa(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 uiDly)             \
ICHAL_ADAPT_FUNC_DEF(SetPostAcInsrtLongDlyCa,uiBlockId,uiAcIdx,uiDly)
UINT32 BspHalAdaptGetPostAcInsrtLongDlyCa(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 *uiDly)            \
ICHAL_ADAPT_FUNC_DEF(GetPostAcInsrtLongDlyCa,uiBlockId,uiAcIdx,uiDly)
UINT32 BspHalAdaptSetTopDataSelCfg(UINT32 uiBlockId, UINT32 uiCarrId, UINT32 uiCfg)                   \
ICHAL_ADAPT_FUNC_DEF(SetTopDataSelCfg,uiBlockId,uiCarrId,uiCfg)
UINT32 BspHalAdaptGetTopDataSelCfg(UINT32 uiBlockId, UINT32 uiCarrId, UINT32 *uiCfg)                  \
ICHAL_ADAPT_FUNC_DEF(GetTopDataSelCfg,uiBlockId,uiCarrId,uiCfg)
UINT32 BspHalAdaptSetAcSync(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 uiSync)                          \
ICHAL_ADAPT_FUNC_DEF(SetAcSync,uiBlockId,uiAcIdx,uiSync)
UINT32 BspHalAdaptGetAcSync(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 *uiSync)                         \
ICHAL_ADAPT_FUNC_DEF(GetAcSync,uiBlockId,uiAcIdx,uiSync)
UINT32 BspHalAdaptSetAcInsertTimes(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 uiTimes)                  \
ICHAL_ADAPT_FUNC_DEF(SetAcInsertTimes,uiBlockId,uiAcIdx,uiTimes)
UINT32 BspHalAdaptGetAcInsertTimes(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 *uiTimes)                 \
ICHAL_ADAPT_FUNC_DEF(GetAcInsertTimes,uiBlockId,uiAcIdx,uiTimes)
UINT32 BspHalAdaptSetFrGpPha(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 uiGpPha)                        \
ICHAL_ADAPT_FUNC_DEF(SetFrGpPha,uiBlockId,uiAcIdx,uiGpPha)
UINT32 BspHalAdaptGetFrGpPha(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 *uiGpPha)                       \
ICHAL_ADAPT_FUNC_DEF(GetFrGpPha,uiBlockId,uiAcIdx,uiGpPha)
UINT32 BspHalAdaptAcInsrtDataWrRam(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 *pAcData, UINT32 uiAcDataLen) \
ICHAL_ADAPT_FUNC_DEF(AcInsrtDataWrRam,uiBlockId, uiAcIdx, pAcData, uiAcDataLen)

//AC--UL_BANK
UINT32 BspHalAdaptSetUlchDataDelayCfg(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 uiDlyCfg)              \
ICHAL_ADAPT_FUNC_DEF(SetUlchDataDelayCfg,uiBlockId,uiAcIdx,uiDlyCfg)
UINT32 BspHalAdaptGetUlchDataDelayCfg(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 *uiDlyCfg)             \
ICHAL_ADAPT_FUNC_DEF(GetUlchDataDelayCfg,uiBlockId,uiAcIdx,uiDlyCfg)
UINT32 BspHalAdaptSetUlchFrDelayCfg(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 uiDlyCfg)                \
ICHAL_ADAPT_FUNC_DEF(SetUlchFrDelayCfg,uiBlockId,uiAcIdx,uiDlyCfg)
UINT32 BspHalAdaptGetUlchFrDelayCfg(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 *uiDlyCfg)               \
ICHAL_ADAPT_FUNC_DEF(GetUlchFrDelayCfg,uiBlockId,uiAcIdx,uiDlyCfg)
UINT32 BspHalAdaptSetAccbBankRouterCfg(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 uiRouterCfg)          \
ICHAL_ADAPT_FUNC_DEF(SetAccbBankRouterCfg,uiBlockId,uiAcIdx,uiRouterCfg)
UINT32 BspHalAdaptGetAccbBankRouterCfg(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 *uiRouterCfg)         \
ICHAL_ADAPT_FUNC_DEF(GetAccbBankRouterCfg,uiBlockId,uiAcIdx,uiRouterCfg)
UINT32 BspHalAdaptSetAccbFr5msEn(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 ui5msEn)                    \
ICHAL_ADAPT_FUNC_DEF(SetAccbFr5msEn,uiBlockId,uiAcIdx,ui5msEn)
UINT32 BspHalAdaptGetAccbFr5msEn(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 *ui5msEn)                   \
ICHAL_ADAPT_FUNC_DEF(GetAccbFr5msEn,uiBlockId,uiAcIdx,ui5msEn)
UINT32 BspHalAdaptSetAccbFrNum(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 uiFrNum)                      \
ICHAL_ADAPT_FUNC_DEF(SetAccbFrNum,uiBlockId,uiAcIdx,uiFrNum)
UINT32 BspHalAdaptGetAccbFrNum(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 *uiFrNum)                     \
ICHAL_ADAPT_FUNC_DEF(GetAccbFrNum,uiBlockId,uiAcIdx,uiFrNum)
UINT32 BspHalAdaptSetAccbFrameIdMask(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 uiIdMask)               \
ICHAL_ADAPT_FUNC_DEF(SetAccbFrameIdMask,uiBlockId,uiAcIdx,uiIdMask)
UINT32 BspHalAdaptGetAccbFrameIdMask(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 *uiIdMask)              \
ICHAL_ADAPT_FUNC_DEF(GetAccbFrameIdMask,uiBlockId,uiAcIdx,uiIdMask)
UINT32 BspHalAdaptSetAccbFrameId(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 uiId)                       \
ICHAL_ADAPT_FUNC_DEF(SetAccbFrameId,uiBlockId,uiAcIdx,uiId)
UINT32 BspHalAdaptGetAccbFrameId(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 *uiId)                      \
ICHAL_ADAPT_FUNC_DEF(GetAccbFrameId,uiBlockId,uiAcIdx,uiId)
UINT32 BspHalAdaptSetAccbFr5msId(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 ui5msId)                    \
ICHAL_ADAPT_FUNC_DEF(SetAccbFr5msId,uiBlockId,uiAcIdx,ui5msId)
UINT32 BspHalAdaptGetAccbFr5msId(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 *ui5msId)                   \
ICHAL_ADAPT_FUNC_DEF(GetAccbFr5msId,uiBlockId,uiAcIdx,ui5msId)
UINT32 BspHalAdaptSetAccbDataRouterCfg(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 uiRouterCfg)          \
ICHAL_ADAPT_FUNC_DEF(SetAccbDataRouterCfg,uiBlockId,uiAcIdx,uiRouterCfg)
UINT32 BspHalAdaptGetAccbDataRouterCfg(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 *uiRouterCfg)         \
ICHAL_ADAPT_FUNC_DEF(GetAccbDataRouterCfg,uiBlockId,uiAcIdx,uiRouterCfg)
UINT32 BspHalAdaptSetAccbGpvldRouterCfg(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 uiRouterCfg)         \
ICHAL_ADAPT_FUNC_DEF(SetAccbGpvldRouterCfg,uiBlockId,uiAcIdx,uiRouterCfg)
UINT32 BspHalAdaptGetAccbGpvldRouterCfg(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 *uiRouterCfg)        \
ICHAL_ADAPT_FUNC_DEF(GetAccbGpvldRouterCfg,uiBlockId,uiAcIdx,uiRouterCfg)
UINT32 BspHalAdaptSetAccbChFr0RouterCfg(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 uiRouter0Cfg)        \
ICHAL_ADAPT_FUNC_DEF(SetAccbChFr0RouterCfg,uiBlockId,uiAcIdx,uiRouter0Cfg)
UINT32 BspHalAdaptGetAccbChFr0RouterCfg(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 *uiRouter0Cfg)       \
ICHAL_ADAPT_FUNC_DEF(GetAccbChFr0RouterCfg,uiBlockId,uiAcIdx,uiRouter0Cfg)
UINT32 BspHalAdaptSetAccbChFr1RouterCfg(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 uiRouter1Cfg)        \
ICHAL_ADAPT_FUNC_DEF(SetAccbChFr1RouterCfg,uiBlockId,uiAcIdx,uiRouter1Cfg)
UINT32 BspHalAdaptGetAccbChFr1RouterCfg(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 *uiRouter1Cfg)       \
ICHAL_ADAPT_FUNC_DEF(GetAccbChFr1RouterCfg,uiBlockId,uiAcIdx,uiRouter1Cfg)
UINT32 BspHalAdaptSetAccbChRouterCfg(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 uiRouterCfg)            \
ICHAL_ADAPT_FUNC_DEF(SetAccbChRouterCfg,uiBlockId,uiAcIdx,uiRouterCfg)
UINT32 BspHalAdaptGetAccbChRouterCfg(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 *uiRouterCfg)           \
ICHAL_ADAPT_FUNC_DEF(GetAccbChRouterCfg,uiBlockId,uiAcIdx,uiRouterCfg)
UINT32 BspHalAdaptSetAccbChBnkRouterCfg(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 uiRouterCfg)         \
ICHAL_ADAPT_FUNC_DEF(SetAccbChBnkRouterCfg,uiBlockId,uiAcIdx,uiRouterCfg)
UINT32 BspHalAdaptGetAccbChBnkRouterCfg(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 *uiRouterCfg)        \
ICHAL_ADAPT_FUNC_DEF(GetAccbChBnkRouterCfg,uiBlockId,uiAcIdx,uiRouterCfg)
UINT32 BspHalAdaptSetAccbSnapEn(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 uiSnapEn)                    \
ICHAL_ADAPT_FUNC_DEF(SetAccbSnapEn,uiBlockId,uiAcIdx,uiSnapEn)
UINT32 BspHalAdaptGetAccbSnapEn(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 *uiSnapEn)                   \
ICHAL_ADAPT_FUNC_DEF(GetAccbSnapEn,uiBlockId,uiAcIdx,uiSnapEn)
UINT32 BspHalAdaptSetAccbCbMode(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 uiCbMode)                    \
ICHAL_ADAPT_FUNC_DEF(SetAccbCbMode,uiBlockId,uiAcIdx,uiCbMode)
UINT32 BspHalAdaptGetAccbCbMode(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 *uiCbMode)                   \
ICHAL_ADAPT_FUNC_DEF(GetAccbCbMode,uiBlockId,uiAcIdx,uiCbMode)
UINT32 BspHalAdaptSetAccbFrameIdEn(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 uiFrameIdEn)              \
ICHAL_ADAPT_FUNC_DEF(SetAccbFrameIdEn,uiBlockId,uiAcIdx,uiFrameIdEn)
UINT32 BspHalAdaptGetAccbFrameIdEn(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 *uiFrameIdEn)             \
ICHAL_ADAPT_FUNC_DEF(GetAccbFrameIdEn,uiBlockId,uiAcIdx,uiFrameIdEn)
UINT32 BspHalAdaptSetAccbCycleNum(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 uiCycleNum)                \
ICHAL_ADAPT_FUNC_DEF(SetAccbCycleNum,uiBlockId,uiAcIdx,uiCycleNum)
UINT32 BspHalAdaptGetAccbCycleNum(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 *uiCycleNum)               \
ICHAL_ADAPT_FUNC_DEF(GetAccbCycleNum,uiBlockId,uiAcIdx,uiCycleNum)
UINT32 BspHalAdaptSetAccbRssiEn(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 uiRssiEn)                    \
ICHAL_ADAPT_FUNC_DEF(SetAccbRssiEn,uiBlockId,uiAcIdx,uiRssiEn)
UINT32 BspHalAdaptGetAccbRssiEn(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 *uiRssiEn)                   \
ICHAL_ADAPT_FUNC_DEF(GetAccbRssiEn,uiBlockId,uiAcIdx,uiRssiEn)
UINT32 BspHalAdaptSetAccbFreeCbEn(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 FreeCbEn)                  \
ICHAL_ADAPT_FUNC_DEF(SetAccbFreeCbEn,uiBlockId,uiAcIdx,FreeCbEn)
UINT32 BspHalAdaptGetAccbFreeCbEn(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 *FreeCbEn)                 \
ICHAL_ADAPT_FUNC_DEF(GetAccbFreeCbEn,uiBlockId,uiAcIdx,FreeCbEn)
UINT32 BspHalAdaptSetAccbRamRdEn(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 uiEn)                       \
ICHAL_ADAPT_FUNC_DEF(SetAccbRamRdEn,uiBlockId,uiAcIdx,uiEn)
UINT32 BspHalAdaptGetAccbRamRdEn(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 *uiEn)                      \
ICHAL_ADAPT_FUNC_DEF(GetAccbRamRdEn,uiBlockId,uiAcIdx,uiEn)
UINT32 BspHalAdaptSetAccbHoldNum(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 uiHoldNum)                  \
ICHAL_ADAPT_FUNC_DEF(SetAccbHoldNum,uiBlockId,uiAcIdx,uiHoldNum)
UINT32 BspHalAdaptGetAccbHoldNum(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 *uiHoldNum)                 \
ICHAL_ADAPT_FUNC_DEF(GetAccbHoldNum,uiBlockId,uiAcIdx,uiHoldNum)
UINT32 BspHalAdaptSetAccbGetNum(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 uiGetNum)                    \
ICHAL_ADAPT_FUNC_DEF(SetAccbGetNum,uiBlockId,uiAcIdx,uiGetNum)
UINT32 BspHalAdaptGetAccbGetNum(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 *uiGetNum)                   \
ICHAL_ADAPT_FUNC_DEF(GetAccbGetNum,uiBlockId,uiAcIdx,uiGetNum)
UINT32 BspHalAdaptSetAccbDelayNum(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 uiDelayNum)                \
ICHAL_ADAPT_FUNC_DEF(SetAccbDelayNum,uiBlockId,uiAcIdx,uiDelayNum)
UINT32 BspHalAdaptGetAccbDelayNum(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 *uiDelayNum)               \
ICHAL_ADAPT_FUNC_DEF(GetAccbDelayNum,uiBlockId,uiAcIdx,uiDelayNum)
UINT32 BspHalAdaptSetAccbVgaDelay(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 uiVgaDly)                  \
ICHAL_ADAPT_FUNC_DEF(SetAccbVgaDelay,uiBlockId,uiAcIdx,uiVgaDly)
UINT32 BspHalAdaptGetAccbVgaDelay(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 *uiVgaDly)                 \
ICHAL_ADAPT_FUNC_DEF(GetAccbVgaDelay,uiBlockId,uiAcIdx,uiVgaDly)
UINT32 BspHalAdaptSetAccbFrTaDelay(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 uiTaDly)                  \
ICHAL_ADAPT_FUNC_DEF(SetAccbFrTaDelay,uiBlockId,uiAcIdx,uiTaDly)
UINT32 BspHalAdaptGetAccbFrTaDelay(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 *uiTaDly)                 \
ICHAL_ADAPT_FUNC_DEF(GetAccbFrTaDelay,uiBlockId,uiAcIdx,uiTaDly)
UINT32 BspHalAdaptSetAccbCbLength(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 uiCbLen)                   \
ICHAL_ADAPT_FUNC_DEF(SetAccbCbLength,uiBlockId,uiAcIdx,uiCbLen)
UINT32 BspHalAdaptGetAccbCbLength(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 *uiCbLen)                  \
ICHAL_ADAPT_FUNC_DEF(GetAccbCbLength,uiBlockId,uiAcIdx,uiCbLen)
UINT32 BspHalAdaptSetAccbInslotWaitAbnml(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 uiInslot)           \
ICHAL_ADAPT_FUNC_DEF(SetAccbInslotWaitAbnml,uiBlockId,uiAcIdx,uiInslot)
UINT32 BspHalAdaptGetAccbInslotWaitAbnml(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 *uiInslot)          \
ICHAL_ADAPT_FUNC_DEF(GetAccbInslotWaitAbnml,uiBlockId,uiAcIdx,uiInslot)
UINT32 BspHalAdaptSetAccbIntCnt(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 uiCnt)                       \
ICHAL_ADAPT_FUNC_DEF(SetAccbIntCnt,uiBlockId,uiAcIdx,uiCnt)
UINT32 BspHalAdaptGetAccbIntCnt(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 *uiCnt)                      \
ICHAL_ADAPT_FUNC_DEF(GetAccbIntCnt,uiBlockId,uiAcIdx,uiCnt)
UINT32 BspHalAdaptSetAccbAcInslotDelay(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 uiInslotDly)          \
ICHAL_ADAPT_FUNC_DEF(SetAccbAcInslotDelay,uiBlockId,uiAcIdx,uiInslotDly)
UINT32 BspHalAdaptGetAccbAcInslotDelay(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 *uiInslotDly)         \
ICHAL_ADAPT_FUNC_DEF(GetAccbAcInslotDelay,uiBlockId,uiAcIdx,uiInslotDly)
UINT32 BspHalAdaptSetAccbAcInslotEn(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 uiEn)                    \
ICHAL_ADAPT_FUNC_DEF(SetAccbAcInslotEn,uiBlockId,uiAcIdx,uiEn)
UINT32 BspHalAdaptGetAccbAcInslotEn(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 *uiEn)                   \
ICHAL_ADAPT_FUNC_DEF(GetAccbAcInslotEn,uiBlockId,uiAcIdx,uiEn)
UINT32 BspHalAdaptSetAccbFrMeas(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 uiFrMeas)                    \
ICHAL_ADAPT_FUNC_DEF(SetAccbFrMeas,uiBlockId,uiAcIdx,uiFrMeas)
UINT32 BspHalAdaptGetAccbFrMeas(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 *uiFrMeas)                   \
ICHAL_ADAPT_FUNC_DEF(GetAccbFrMeas,uiBlockId,uiAcIdx,uiFrMeas)
UINT32 BspHalAdaptGetAccbDoneInt(UINT32 uiBlockId, UINT32 *uiInt)                                     \
ICHAL_ADAPT_FUNC_DEF(GetAccbDoneInt,uiBlockId,uiInt)
UINT32 BspHalAdaptSetAccbWarningClr(UINT32 uiBlockId, UINT32 uiClr)                                   \
ICHAL_ADAPT_FUNC_DEF(SetAccbWarningClr,uiBlockId,uiClr)
UINT32 BspHalAdaptGetAccbWarningClr(UINT32 uiBlockId, UINT32 *uiClr)                                  \
ICHAL_ADAPT_FUNC_DEF(GetAccbWarningClr,uiBlockId,uiClr)
UINT32 BspHalAdaptSetAccbDoneIntClr(UINT32 uiBlockId, UINT32 uiClr)                                   \
ICHAL_ADAPT_FUNC_DEF(SetAccbDoneIntClr,uiBlockId,uiClr)
UINT32 BspHalAdaptGetAccbDoneIntClr(UINT32 uiBlockId, UINT32 *uiClr)                                  \
ICHAL_ADAPT_FUNC_DEF(GetAccbDoneIntClr,uiBlockId,uiClr)
UINT32 BspHalAdaptSetAccbDoneIntEn(UINT32 uiBlockId, UINT32 uiEn)                                     \
ICHAL_ADAPT_FUNC_DEF(SetAccbDoneIntEn,uiBlockId,uiEn)
UINT32 BspHalAdaptGetAccbDoneIntEn(UINT32 uiBlockId, UINT32 *uiEn)                                    \
ICHAL_ADAPT_FUNC_DEF(GetAccbDoneIntEn,uiBlockId,uiEn)
UINT32 BspHalAdaptGetAccbVgaCoef(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 uiIdx, UINT32 *uiCoef)      \
ICHAL_ADAPT_FUNC_DEF(GetAccbVgaCoef,uiBlockId,uiAcIdx,uiIdx,uiCoef)
UINT32 BspHalAdaptGetAccbVgaAbnml(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 uiIdx, UINT32 *uiAbnml)    \
ICHAL_ADAPT_FUNC_DEF(GetAccbVgaAbnml,uiBlockId,uiAcIdx,uiIdx,uiAbnml)
UINT32 BspHalAdaptAcSampleDataRdRam(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 *pAcData, UINT32 *uiAcDataLen)    \
ICHAL_ADAPT_FUNC_DEF(AcSampleDataRdRam,uiBlockId,uiAcIdx,pAcData,uiAcDataLen)
UINT32 BspHalAdaptGetAccbVgaStatus(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 uiIdx, UINT32 *uiStatus)    \
ICHAL_ADAPT_FUNC_DEF(GetAccbVgaStatus,uiBlockId,uiAcIdx,uiIdx,uiStatus)
#endif
/**************************************************************************
                            光口相位补偿相关接口
**************************************************************************/
UINT32 BspHalAdaptGetPhaCompParaScsSymNum(UINT32 cellIdx, UINT32* scs, UINT32* symNum) \
ICHAL_ADAPT_FUNC_DEF(GetPhaCompParaScsSymNum,cellIdx,scs,symNum)
UINT32 BspHalAdaptCfgPhaCompVal(UINT32 cellIdx, UINT32 uDir, UINT32 *pPhaCompVal, UINT32 uLen) \
ICHAL_ADAPT_FUNC_DEF(CfgPhaCompVal, cellIdx, uDir, pPhaCompVal, uLen)
/**************************************************************************
                            光口Ers相关接口
**************************************************************************/
UINT32 BspHalAdaptGetCellAntMask(UINT32 cellId, UINT32 dir, UINT32* antMask)                     \
ICHAL_ADAPT_FUNC_DEF(GetCellAntMask,cellId,dir,antMask)
UINT32 BspHalAdaptGetCellCaMode(UINT32 cellId, UINT32* cellCaMode)                               \
ICHAL_ADAPT_FUNC_DEF(GetCellCaMode,cellId,cellCaMode)
UINT32 BspHalAdaptGetCellRadioMode(UINT32 cellId, UINT32* radioMode)                             \
ICHAL_ADAPT_FUNC_DEF(GetCellRadioMode,cellId,radioMode)
UINT32 BspHalAdaptSetCellErsInfo(UINT32 cellId, UINT32 carrNo, UINT32 caMode, UINT32 scale)      \
ICHAL_ADAPT_FUNC_DEF(SetCellErsInfo,cellId,carrNo,caMode,scale)
UINT32 BspHalAdaptGetCarrNoByOptCellId(UINT32 cellId, UINT32 *puCarrNo)
{
    return IcHalApiGetCarrNoByOptCellId(cellId,puCarrNo);
}
/**************************************************************************
                            光口配小区相关接口
**************************************************************************/
UINT32 BspHalAdaptBifGfCrmRxReset(void)      \
ICHAL_ADAPT_FUNC_DEF(BifGfCrmReset)


UINT32 BspHalApiUpdateScale(void)      \
ICHAL_ADAPT_FUNC_DEF(UpdateScale)


UINT32 BspInitOptHalCellCfg(T_CellCfgInfo* cellCfg, UINT32 txResIndex, UINT32 rxResIndex, T_OptCellCfgInfo* outCellCfg)
{
    UINT32 retVal = BSP_OK;
    INPUT_POINTER_CHECK(cellCfg);
    INPUT_POINTER_CHECK(outCellCfg);

    outCellCfg->cellIndex = cellCfg->cellIndex;
    outCellCfg->cellAdFlag = cellCfg->cellAdFlag;
    outCellCfg->cellMcsId = cellCfg->cellMcsId;
    outCellCfg->cellLocalCarrNo = cellCfg->cellLocalCarrNo;

    outCellCfg->cellBw[RX] = cellCfg->cellBw[RX];
    outCellCfg->cellBw[TX] = cellCfg->cellBw[TX];
    outCellCfg->cellIFType = cellCfg->cellIFType;
    outCellCfg->cellBearType = cellCfg->cellBearType;

    outCellCfg->cellSCSBitMap = cellCfg->cellSCSBitMap;
    outCellCfg->cellTTI = cellCfg->cellTTI;
    outCellCfg->cellAntRadioMode = cellCfg->cellAntRadioMode;
    outCellCfg->cellCarrNo = cellCfg->cellCarrNo;

    outCellCfg->cellAntMask[RX] = cellCfg->cellAntMask[RX];
    outCellCfg->cellAntMask[TX] = cellCfg->cellAntMask[TX];
    outCellCfg->cellULCompressMode = cellCfg->cellULCompressMode;
    outCellCfg->cellDLDeCompressMode = cellCfg->cellDLDeCompressMode;

    outCellCfg->cellIQPkgOLEN[RX] = cellCfg->cellIQPkgOLEN[RX];
    outCellCfg->cellIQPkgOLEN[TX] = cellCfg->cellIQPkgOLEN[TX];
    outCellCfg->iqSampleRate = cellCfg->iqSampleRate;
    outCellCfg->cellgScn = cellCfg->cellgScn;

    outCellCfg->carrCopyType = cellCfg->carrCopyType;
    outCellCfg->orginalCellIndex = cellCfg->orginalCellIndex;
    outCellCfg->dspfreqMode = cellCfg->dspfreqMode;

    outCellCfg->cellSsbValid = cellCfg->cellSsbValid;
    outCellCfg->fftaCpType = cellCfg->fftaCpType;
    outCellCfg->cellCAMode = cellCfg->cellCAMode;
    outCellCfg->cellPrachDagcEn = cellCfg->cellPrachDagcEn;
    outCellCfg->cellTax = cellCfg->tax;
    outCellCfg->cellRvsTax[TX] = cellCfg->rvsTax[TX];
    outCellCfg->cellRvsTax[RX] = cellCfg->rvsTax[RX];
    outCellCfg->resIndex[RX] = rxResIndex;
    outCellCfg->resIndex[TX] = txResIndex;
    outCellCfg->resv[RX] = cellCfg->resv[RX];

    outCellCfg->cellLnetwkDlys[RX] = cellCfg->cellLnetwkDlys[RX];
    outCellCfg->cellLnetwkDlys[TX] = cellCfg->cellLnetwkDlys[TX];

    outCellCfg->pattenType = cellCfg->pattenType;
    outCellCfg->bandFrmAdj = cellCfg->bandFrmAdj;
    outCellCfg->cellNcrOverallDirType = cellCfg->cellNcrOverallDirType;


    retVal |= memcpy_s(outCellCfg->cellTxSymbolBit, sizeof(outCellCfg->cellTxSymbolBit), cellCfg->cellTxSymbolBit, sizeof(cellCfg->cellTxSymbolBit));
    retVal |= memcpy_s(outCellCfg->cellRxSymbolBit, sizeof(outCellCfg->cellRxSymbolBit), cellCfg->cellRxSymbolBit, sizeof(cellCfg->cellRxSymbolBit));
    retVal |= memcpy_s(&outCellCfg->tIqBindInfo, sizeof(T_IqAntBindInfo), &cellCfg->iqAntBindInfo, sizeof(T_IqAntBindInfo));
    return retVal;
}

UINT32 BspHalAdaptOptCellInfoInit(T_CellCfgInfo* cellCfg, UINT32 txResIndex, UINT32 rxResIndex)
{
    UINT32 retVal = BSP_OK; 
    T_OptCellCfgInfo optCellCfg = {0};
    INPUT_POINTER_CHECK(cellCfg);

    retVal = BspInitOptHalCellCfg(cellCfg, txResIndex, rxResIndex, &optCellCfg);
    if (retVal != BSP_OK) 
    {
        dbgErr("BspInitOptHalCellCfg fail\r\n");
        return BSP_ERROR;
    }
    retVal = IcHalApiOptCellInfoInit(&optCellCfg);
    return retVal;
}

UINT32 BspHalAdapSetRvsTax(UINT32 uCellId, UINT32 uRadioMode, INT32 rvsTaxDL,INT32 rvsTaxUL)
{
    return IcHalApiSetRvsTax(uCellId, uRadioMode, rvsTaxDL, rvsTaxUL);
}

UINT32 BspHalAdapSetFftFocVal(UINT32 uCellId, UINT32 radio, UINT32 dir, INT32 offset)
{
    return IcHalApiSetFftFocVal(uCellId, radio, dir, offset);
}

UINT32 BspHalAdaptOptL1CellPrachInfoInit(T_PrachCellInfo* prachCellInfo, UINT32 prachNum)
{
    UINT32 retVal = BSP_OK;  
    INPUT_POINTER_CHECK(prachCellInfo);
    retVal = IcHalApiOptL1CellPrachInfoInit(prachNum, prachCellInfo);
    return retVal;
}

UINT32 BspHalAdaptOptCellCfg(UINT32 cellId)
{
    UINT32 retVal = BSP_OK;  
    retVal = IcHalApiOptCellCfg(cellId);
    return retVal;
}
UINT32 BspHalAdaptOptCellDelte(UINT32 cellId)
{
    UINT32 retVal = BSP_OK;
    retVal = IcHalApiOptCellDel(cellId);
    return retVal;
}

UINT32 BspHalAdaptOptGFAxiTest(VOID)
{
#ifdef UT_FT_TEST
    return BSP_OK;
#endif
    UINT32 retVal = BSP_OK;
    retVal = IcHalOptGFAxiTest();
    return retVal;
}

UINT32 BspHalAdaptSetOptLinkTbl(T_Opt_Link_Tbl *pOptlink,UINT32 linkNum)
{
    UINT32 retVal = BSP_OK;  
    INPUT_POINTER_CHECK(pOptlink);
    retVal = IcHalApiSetOptLinkTbl(pOptlink, linkNum);
    return retVal;
}

UINT32 BspHalAdaptInitOptEcpriCellInfo(T_EcpriCellStreamInfo *pPara,UINT32 dir)
{
    UINT32 retVal = BSP_OK;  
    INPUT_POINTER_CHECK(pPara);
    retVal = IcHalApiOptEcpriCellInfoInit(pPara, dir);
    return retVal;    
}

UINT32 BspHalAdaptSetOptAntFlowMapInfo(T_OptAntFlowMapInfo*  optAntFlowMapInfoArr, UINT32 mapArrSize)
{
    UINT32 retVal = BSP_OK;  
    INPUT_POINTER_CHECK(optAntFlowMapInfoArr);
    retVal = IcHalApiSetOptAntFlowMapInfo(optAntFlowMapInfoArr, mapArrSize);
    return retVal; 
}

UINT32 BspHalAdaptAcWgtSwitchByChnMap(UINT32 acType, UINT32 antMask, UINT32 swOnOrOff)
{
    UINT32 retVal = BSP_OK;  
    retVal = IcHalApiAcWgtSwitchByChnMap(acType, antMask, swOnOrOff);
    return retVal; 
}

UINT32 BspHalAdaptInitOptFftaPara(UINT32 cellId, UINT32 dir, UINT32 scs, T_FFTACfgPara* fftaPara)
{
    UINT32 retVal = BSP_OK;  
    retVal = IcHalApiInitOptFftaPara(cellId, dir, scs, fftaPara);
    return retVal; 
}

UINT32 BspHalAdaptInitOptFftaHwCfg(VOID)
{
    UINT32 retVal = BSP_OK;  
    retVal = IcHalApiInitOptFftaHwCfg();
    return retVal;     
}

UINT32 BspHalAdaptPreCfgL1OptByWorkMode(UINT32 workMode)
{
    UINT32 retVal = BSP_OK;  
    retVal = IcHalApiPreCfgL1OptByWorkMode(workMode);
    return retVal;      
}
//暂时屏蔽 4.2上暂时没有ecpri
#if 0
UINT32 BspHalAdaptSetCwHiPowRptEn(UINT32 enable)
{
	//暂时屏蔽 4.2上暂时没有ecpri
    //return IcHalApiSetCwHiPowRptEn(enable);
	return BSP_OK;
}

UINT32 BspHalAdaptSetCwHiPowRptCfg(T_CwHiPowRtpInfo *ptCwHiPowRtpInfo, UINT32 num)
{

    return IcHalApiSetCwHiPowRptCfg(ptCwHiPowRtpInfo, num);
	return BSP_OK;
}
#endif
UINT32 BspHalAdaptSetEcpriRemoteRst(UINT8 *pDestMac1,UINT8 *pDestMac2)
{
   return IcHalApiSetEcpriRemoteRst(pDestMac1, pDestMac2);
}

/* 远程掉电复位初始化配置 */
UINT32 BspHalAdaptSetCrmRmtPwdRstSrc(UINT32 uRstSrc)
{
    return IcHalApiSetCrmRmtPwdRstSrc(uRstSrc);
}
/* 远程掉电复位测试接口 */
UINT32 BspHalAdaptSetCrmRmtPwdRstTestEn(UINT32 uTestEn)
{
    return IcHalApiSetCrmRmtPwdRstTestEn(uTestEn);
}
/* 远程掉电复位状态获取 */
UINT32 BspHalAdaptGetCrmRmtPwdRstSrc(UINT32 *pRstSrc)
{
    INPUT_POINTER_CHECK(pRstSrc);
    return IcHalApiGetCrmRmtPwdRstSrc(pRstSrc);
}
/* 远程硬复位初始化配置 */
UINT32 BspHalAdaptSetCrmRmtHardRstSrc(UINT32 uRstSrc)
{
    return IcHalApiSetCrmRmtHardRstSrc(uRstSrc);   
}

/* 用于更新光口小区的GSCN和SSB，保证功率计算正常 */
UINT32 BspHalAdaptUpdataGscn(UINT32 uRadioMode, UINT32 uCellId, UINT32 uGscn, UINT32 uSsbValid)
{
    return IcHalApiUpdataGscn(uRadioMode, uCellId, uGscn, uSsbValid);
}

UINT32 BspHalAdaptOptCpriParamInit(T_BspHalAdaptOptCpriInfo* optInitCpriCfgInfo)
{
	return IcHalApiCpriParamSet(optInitCpriCfgInfo);
}
/* 配置整机制式(单模/混模)到光口HAL层　hal计算时延时使用　此处要添加fdd制式 具体规则还需要和hal商量*/
UINT32 BspHalAdaptSetCellCfgMode(UINT32 radioStandard)
{
    UINT32 cfgMode = 0;

    /* NR单模 */
    if(BSP_RADIO_STANDARD_5G == radioStandard)
    {
        cfgMode = BSP_CELL_CFG_MODE_ONLY_NR;
    }
    else if(BSP_RADIO_STANDARD_LTE_TDD == radioStandard)
    {
        cfgMode = BSP_CELL_CFG_MODE_ONLY_LTE;
    }
    else if((BSP_RADIO_STANDARD_LTE_TDD | BSP_RADIO_STANDARD_5G) == radioStandard)
    {
        cfgMode = BSP_CELL_CFG_MODE_MIX_NR_LTE;
    }
    else
    {
        return BSP_ERROR;
    }

    return IcHalApiSetCellCfgMode(cfgMode);
}
/**************************************************************************
                            光口初始化相关接口
**************************************************************************/
UINT32 BspHalAdaptOptCpriInit(VOID)
{
    UINT32 retVal = BSP_OK;
    retVal = IcHalApiCpriInit();
    return retVal;
}
/*FDD机型配置crc掩码*/
UINT32 BspHalAdaptOptCpriSetCrcMask(UINT32 logicOpt, UINT32 subChanMaskHig32bit, UINT32 subChanMaskLow32bit)
{
    UINT32 retVal = BSP_OK;
    retVal = IcHalApiOptCpriSetCrcMask(logicOpt, subChanMaskHig32bit, subChanMaskLow32bit);
    return retVal;
}
UINT32 BspHalAdaptOptInit(T_BspHalAdaptOptInitCfgInfo* optInitCfgInfo)
{
    UINT32 retVal = BSP_OK;
    T_OptInitPara  optHalInitPara = {0};

    INPUT_POINTER_CHECK(optInitCfgInfo);
    retVal = memcpy_s(&optHalInitPara, sizeof(T_OptInitPara), optInitCfgInfo, sizeof(T_BspHalAdaptOptInitCfgInfo));
    if (retVal != BSP_OK)
    {
        dbgErr("BspHalAdaptOptInit convert IcHal para error,please check parameter\r\n");
        return BSP_ERROR;
    }
    retVal = IcHalApiOptInit(&optHalInitPara);
    return retVal;
}

UINT32 BspHalAdaptLoadM0CoreVersion(UINT32 ulCoreId, UINT32 ulSceneType)
ICHAL_ADAPT_FUNC_DEF(LoadM0CoreVersion,ulCoreId, ulSceneType)

UINT32 BspHalAdaptMeasureInit(UINT32 uCpriOrEcpri)
ICHAL_ADAPT_FUNC_DEF(OptMeasureInit,uCpriOrEcpri)

UINT32 BspHalAdaptLycaSetTxFirCoff(UINT32 serdesId, UINT32 laneId, UINT32 eoh0, UINT32 eoh1, UINT32 eoh2, UINT32 eoh3)
ICHAL_ADAPT_FUNC_DEF(LycaSetTxFirCoff, serdesId, laneId, eoh0, eoh1, eoh2, eoh3)

UINT32 BspHalAdaptLycaLoadFw(UINT32 serdesId, UINT32 laneId)
ICHAL_ADAPT_FUNC_DEF(LycaLoadFw,serdesId,laneId)

UINT32 BspHalAdaptLycaInitTx(UINT32 serdesId, UINT32 laneId, UINT32 rate, DOUBLE ldb)
ICHAL_ADAPT_FUNC_DEF(LycaInitTx,serdesId,laneId,rate,ldb)

UINT32 BspHalAdaptTestLycaInitRx(UINT32 serdesId, UINT32 laneId, INT8 phaseMin, INT8 phaseMax, UINT32 uVga, UINT32 uCmtermCtrl)
ICHAL_ADAPT_FUNC_DEF(TestLycaInitRx,serdesId,laneId,phaseMin,phaseMax,uVga,uCmtermCtrl)

/*环回测试时配置下联光口使能*/
UINT32 BSPHalAdaptDlinkSetSendDataEn(UINT32 ulOptNo, UINT32 ulOptEn)
{
    UINT32 retVal = BSP_OK;

    retVal = IcHalOptCpriDLinkSetSendDataEn(ulOptNo, ulOptEn);

    return retVal;
}
T_M0VerLoadInfo s_tMainM0VerInfo = {0};
T_M0VerLoadInfo s_tSlaveM0VerInfo = {0};

UINT32 BspSetMainM0VerLoadInfo(T_M0VerLoadInfo *pM0VerLoadInfo)
{
    INPUT_POINTER_CHECK(pM0VerLoadInfo);
    memcpy_s(&s_tMainM0VerInfo, sizeof(T_M0VerLoadInfo), pM0VerLoadInfo, sizeof(T_M0VerLoadInfo));
    return BSP_OK;
}

UINT32 BspGetMainM0VerLoadInfo(T_M0VerLoadInfo *pM0VerLoadInfo)
{
    INPUT_POINTER_CHECK(pM0VerLoadInfo);
    memcpy_s(pM0VerLoadInfo, sizeof(T_M0VerLoadInfo), &s_tMainM0VerInfo, sizeof(T_M0VerLoadInfo));
    return BSP_OK;
}

UINT32 BspSetSlaveM0VerLoadInfo(T_M0VerLoadInfo *pM0VerLoadInfo)
{
    INPUT_POINTER_CHECK(pM0VerLoadInfo);
    memcpy_s(&s_tSlaveM0VerInfo, sizeof(T_M0VerLoadInfo), pM0VerLoadInfo, sizeof(T_M0VerLoadInfo));
    return BSP_OK;
}

UINT32 BspGetSlaveM0VerLoadInfo(T_M0VerLoadInfo *pM0VerLoadInfo)
{
    INPUT_POINTER_CHECK(pM0VerLoadInfo);
    memcpy_s(pM0VerLoadInfo, sizeof(T_M0VerLoadInfo), &s_tSlaveM0VerInfo, sizeof(T_M0VerLoadInfo));
    return BSP_OK;
}

/*环回测试时配置下联光口*/
UINT32 BSPHalAdaptDlinkSetSendData(UINT32 ulOptNo, UINT32 ulRegVal)
{
    UINT32 retVal = BSP_OK;

    retVal = IcHalOptCpriDLinkSetSendData(ulOptNo, ulRegVal);

    return retVal;
}
/*环回测试时从下联光口获取环回值*/
UINT32 BSPHalAdaptDlinkGetSendData(UINT32 ulOptNo, UINT32 *pData)
{
    UINT32 retVal = BSP_OK;

    INPUT_POINTER_CHECK(pData);
    retVal = IcHalOptCpriDLinkGetRegVal(ulOptNo, pData);

    return retVal;
}

UINT32 BspHalAdaptSetOptRst(UINT32 ulRstRequsetVal)
{
    UINT32 retVal = BSP_OK;

    retVal = IcHalSetOptCpriCfgTransLsarRstReq(ulRstRequsetVal);

    return retVal;
}

UINT32 BspHalAdaptCpriCfgTransLsarRstReqEn(UINT32 uCpuEn, UINT32 uTransSwitch)
{
    return IcHalApiCpriCfgTransLsarRstReqEn(uCpuEn,uTransSwitch);
}
UINT32 BspHalAdaptSetOptRstEn(UINT32 ulRstRequsetVal)
{
    UINT32 retVal = BSP_OK;

    retVal = IcHalSetOptCpriCfgTransLsarRstReqEn(ulRstRequsetVal);

    return retVal;
}

UINT32 BspHalAdaptCpriCfgOptProperty(UINT32 ulPhyOptNo, UINT32 ulProperty, UINT32 ulPropertyCfgEn, UINT32 ulChipInterConn)
{
    return IcHalApiCpriCfgOptProperty(ulPhyOptNo, ulProperty, ulPropertyCfgEn, ulChipInterConn);
}


UINT32 BspHalAdaptGetOptProperty(UINT32 ulPhyOptNo, UINT32 *ulProperty, UINT32 *ulChipInterConn)
{
    UINT32 retVal = BSP_OK;

    INPUT_POINTER_CHECK(ulProperty);
    INPUT_POINTER_CHECK(ulChipInterConn);
    retVal = IcHalCpriGetOptProperty(ulPhyOptNo, ulProperty, ulChipInterConn);

    return retVal;
}
UINT32 BspHalAdaptOptCpriCfgCuMasterEn(UINT32 ulSwitch)
{
    return IcHalApiCpriCfgCuMasterEn(ulSwitch);
}
UINT32 BspHalAdaptCpriMapConfig(UINT32 ulSw, UINT32 ulHoldOver, UINT32 ulPhyOptNo)
{
    return IcHalApiCpriMapConfig(ulSw, ulHoldOver, ulPhyOptNo);
}

/*片内逻辑口的绑定关系设置*/
UINT32 BspHalAdaptCpriOptBindSel(UINT32 ulLogOptNo, UINT32 ulLogOptSel)
{
    return IcHalApiCpriOptBindSel(ulLogOptNo, ulLogOptSel);
}
/**************************************************************************
                            光口自适应相关接口
**************************************************************************/
UINT32 BspHalAdaptOptCpriCmInit(VOID)
{
    return IcHalApiOptCpriCmInit();
}

UINT32 BspHalAdaptGetCpriLastStageCmStatus(VOID)
{
    return IcHalApiGetCpriLastStageCmStatus();
}

UINT32 BspHalAdaptOptRoeSetHdlcRate(VOID)
{
    return IcHalRoeSetHdlcRateApi();
}

/*读取 hdlc 速率的配置值 000:noHDLC;001:960K;010:1.92M;011:2.4M;100:3.84M;101:4.8M;110:7.68M;111:invalid : */
UINT32 BspHalAdaptGetOptHdlcRate(VOID)
{
    return IcHalApiGetOptHdlcRate();
}

/* 支持7.68M Hdlc速率控制字能力上报 */
UINT32 BspHalAdaptSoftenHdlcRateCapabilityCw(UINT32 hdlcRateCapability)
{
    return IcHalApiSoftenHdlcRateCapabilityCw(hdlcRateCapability);
}

UINT32 BspHalAdaptRoeGetQcellFnb9PacketState(VOID)
{
    return IcHalApiRoeGetQcellFnb9PacketState();
}

UINT32 BspHalApiCpriSelAlignFr(VOID)
{
    return IcHalApiCpriSelAlignFr();
}
UINT32 BspHalAdaptCpriSetTxRxPPoint(UINT32 ulLogicOpt, UINT32 ulManualSwitch, UINT32 ulPPoint)
{
    UINT32 retVal = BSP_OK;
    retVal = IcHalApiCpriSetTxPPoint(ulLogicOpt, ulManualSwitch, ulPPoint);
    retVal |= IcHalApiCpriSetRxPPoint(ulLogicOpt, ulManualSwitch, ulPPoint);

    return retVal;
}
UINT32 BspHalAdaptCtrlM0SerdesRxinit(UINT32 sw)
{
    return IcHalApiCtrlM0SerdesRxinit(sw);
}

UINT32 BspHalAdaptGetM0SerdesRxinitAck(VOID)
{
    return IcHalApiGetM0SerdesRxinitAck();
}

UINT32 BspHalAdaptSetM0SerdesRxInitInfo(UINT32 optIndex, T_M0RINGSWITCHINFO* info)
{
    return IcHalApiSetM0SerdesRxInitInfo(optIndex, info);
}

UINT32 BspHalAdapGetM0InitSerdesCnt(UINT32 *pCore0Start, UINT32 *pCore0End, UINT32 *pCore1Start, UINT32 *pCore1End)
{
#ifdef UT_FT_TEST
    return BSP_OK;
#endif

    UINT32 retVal = BSP_OK;
    UINT32 coreId = 0;
    T_M0VerLoadInfo tM0VerInfo = {0};

    retVal = BspGetMainM0VerLoadInfo(&tM0VerInfo);

    for(coreId=0; coreId<tM0VerInfo.coreNum; coreId++)
    {
    	if(tM0VerInfo.coreLoadInfo[coreId].ceneType == E_M0_VERSION_UBR)
    	{
            if(coreId == 0)
            {
                retVal |= IcHalApiGetM0InitSerdesCnt(coreId, E_M0_VERSION_UBR, pCore0Start, pCore0End);
            }
            else
            {
                retVal |= IcHalApiGetM0InitSerdesCnt(coreId, E_M0_VERSION_UBR, pCore1Start, pCore1End);
            }
        }
    }

    return retVal;
}

UINT32 BspHalAdapGetGetM0RunStatus(UINT32 *pM0Core0Sta, UINT32 *pM0Core1Sta, UINT32 *pM0Core0Ctrl, UINT32 *pM0Core1Ctrl)
{
#ifdef UT_FT_TEST
    return BSP_OK;
#endif
    UINT32 retVal = BSP_OK;
    UINT32 coreId = 0;
    T_M0VerLoadInfo tM0VerInfo = {0};

    retVal = BspGetMainM0VerLoadInfo(&tM0VerInfo);

    for(coreId=0; coreId<tM0VerInfo.coreNum; coreId++)
    {
    	if(tM0VerInfo.coreLoadInfo[coreId].ceneType == E_M0_VERSION_UBR)
    	{
            if(coreId == 0)
            {
                retVal |= IcHalApiGetM0RunStatus(coreId, E_M0_VERSION_UBR, pM0Core0Sta, pM0Core0Ctrl);
            }
            else
            {
                retVal |= IcHalApiGetM0RunStatus(coreId, E_M0_VERSION_UBR, pM0Core1Sta, pM0Core1Ctrl);
            }
    	}
    }
    return retVal;
}

UINT32 BspHalAdaptSoftenRruIndexrCw(UINT32 uMode)
{
    return IcHalApiSoftenRruIndexrCw(uMode);
}

UINT32 BspHalAdaptSw2TblClr(VOID)
{
    return IcHalApiSw2TblClr();
}

UINT32 BspHalAdaptReCfgSw2Tbl(VOID)
{
    return IcHalApiReCfgSw2Tbl();
}

UINT32 BspHalAdaptCpriLastStageCm(UINT32 ulEnable)
{
    return IcHalApiCpriLastStageCm(ulEnable);
}

UINT32 BspHalAdaptSwCfgIqCloseEn(UINT32 ulLogOptNo, UINT32 ulEn, UINT32 chnDir)
{
    return IcHalApiSwCfgIqCloseEn(ulLogOptNo, ulEn, chnDir);
}

UINT32 BspHalAdaptCpriSetSerdesCdcRxStableWind(UINT32 ulPhyOptNo, UINT32 ulStbWndWid)
{
    return IcHalApiCpriSetSerdesCdcRxStableWind(ulPhyOptNo, ulStbWndWid);
}

UINT32 BspHalAdaptCpriCfgMux2FrmSel(UINT32 ulMux2FrmSel)
ICHAL_ADAPT_FUNC_DEF(CpriCfgMux2FrmSel,ulMux2FrmSel)

UINT32 BspHalAdaptCpriCfgLineRate(UINT32 ulPhyNo,UINT32 ulSpeed)
ICHAL_ADAPT_FUNC_DEF(CpriCfgLineRate,ulPhyNo,ulSpeed)

UINT32 BspHalAdaptCpriGetLineRate(UINT32 ulPhyNo,UINT32* ulSpeed)
ICHAL_ADAPT_FUNC_DEF(CpriGetLineRate,ulPhyNo,ulSpeed)
/*光口状态正常后配置光口cpri线速率给光口 光口自适应里配置的时候 可能逻辑主光口没识别出来报错  后边建链又不重配了*/
UINT32 BspHalAdaptAxcArrangeTypeByBspRate(UINT32 ulPhyNo, UINT32 ulSpeed, UINT32 ulExternMode)
{
   return IcHalApiCfgAxcArrangeTypeByBspRate(ulPhyNo, ulSpeed, ulExternMode);
}

UINT32 BspHalAdaptCpriGetAxcArrangeType(UINT32 ulLogOptNo, UINT32 *pParitySeparate, UINT32 *pAxcChanNum)
ICHAL_ADAPT_FUNC_DEF(CpriGetAxcArrangeType,ulLogOptNo, pParitySeparate, pAxcChanNum)

UINT32 BspHalAdaptGetLogOpt(UINT32 ulPhyNo)
ICHAL_ADAPT_FUNC_DEF(GetLogOpt,ulPhyNo)

UINT32 BspHalAdaptRoeQcellAdjust(UINT32 uRate)
ICHAL_ADAPT_FUNC_DEF(RoeQcellAdjust,uRate)

UINT32 BspHalAdaptRoeSetQcellEthAdjust(UINT32 ulQcellChan)
ICHAL_ADAPT_FUNC_DEF(RoeSetQcellEthAdjust,ulQcellChan)

UINT32 BspHalNtlXmacCtrl(E_OPT_WORKMODE e_OptWorkMode, UINT32 udXmacId, UINT32 udEnable)
ICHAL_ADAPT_FUNC_DEF(NtlXmacCtrl,e_OptWorkMode,udXmacId,udEnable)

UINT32 BspHalNtlXmacCfgPortSpeed(UINT32 udMacId, UINT32 udSpeed)
ICHAL_ADAPT_FUNC_DEF(NtlXmacCfgPortSpeed,udMacId,udSpeed)

UINT32 BspHalAdaptGetPhyOpt(UINT32 ulLogNo)
ICHAL_ADAPT_FUNC_DEF(GetPhyOpt,ulLogNo)

UINT32 BspHalAdaptSetCpriProtocol(UINT32 ulProtocol)
ICHAL_ADAPT_FUNC_DEF(SetCpriProtocol,ulProtocol)

UINT32 BspHalAdaptGetQcellLinkCtrlX(UINT32 ulLogOptNo)
ICHAL_ADAPT_FUNC_DEF(GetQcellLinkCtrlX,ulLogOptNo)

UINT32 BspHalAdaptCpriCfgTransQcellLinkCtrlX(UINT32 ulLogOptNo, UINT32 ulLinkCtrlX)
ICHAL_ADAPT_FUNC_DEF(CpriCfgTransQcellLinkCtrlX,ulLogOptNo,ulLinkCtrlX)

UINT32 BspHalAdaptCpriCfgTransQcellRruId(UINT32 ulLogOptNo, UINT32 ulRruId)
ICHAL_ADAPT_FUNC_DEF(CpriCfgTransQcellRruId,ulLogOptNo,ulRruId)

UINT32 BspHalAdaptCfgPdPwrOffMask(UINT32 PwrOff0Mask, UINT32 PwrOff1Mask)
ICHAL_ADAPT_FUNC_DEF(CfgPdPwrOffMask,PwrOff0Mask,PwrOff1Mask)

UINT32 BspHalAdaptOptQcellHdResetInit(UINT32 ulSwitch)
ICHAL_ADAPT_FUNC_DEF(OptQcellHdResetInit,ulSwitch)

/*获取光口协议 0-cpri; 1-Ir; 2-qcell*/
UINT32 BspHalAdaptGetCpriProtocol(UINT32 *pulProtocol)
{
    UINT32 retVal = BSP_OK;
    retVal = IcHalApiGetCpriProtocol(pulProtocol);
    return retVal;
}
UINT32 BspHalAdaptGetCpriAdaptedProtocol(UINT32 ulPhyOpt, UINT32* pulProtocol)
{
    UINT32 retVal = BSP_OK;
    retVal = IcHalApiGetCpriAdaptedProtocol(ulPhyOpt,pulProtocol);
    return retVal;
}

UINT32 BspHalAdaptGetCpriNetMode(UINT32 *pulNetMode)
ICHAL_ADAPT_FUNC_DEF(GetCpriNetMode,pulNetMode)

UINT32 BspHalAdaptSetCpriNetMode(UINT32 ulNetMode)
ICHAL_ADAPT_FUNC_DEF(SetCpriNetMode,ulNetMode)


UINT32 BspHalAdaptCheckUlCarryInfo(UINT32 uiBandWidth, UINT32 uiSampelRate, UINT32 uiCarrRadio)
ICHAL_ADAPT_FUNC_DEF(CheckUlCarryInfo, uiBandWidth,  uiSampelRate,  uiCarrRadio)


UINT32 BspHalAdaptCheckDlCarryInfo(UINT32 uiBandWidth, UINT32 uiSampelRate, UINT32 uiCarrRadio)
ICHAL_ADAPT_FUNC_DEF(CheckDlCarryInfo, uiBandWidth, uiSampelRate, uiCarrRadio)

/* 设置盲插、非盲插、Qcell标识给光口 */
UINT32 BspHalAdaptSetCpriRruType(E_CPRI_RRU_TYPE ulType)
ICHAL_ADAPT_FUNC_DEF(SetCpriRruType,ulType)

UINT32 BspHalAdaptGetOptLopStatus(UINT32 ulPhyOpt)   /*物理光口状态机lop告警状态*/
{
   UINT32 retVal = BSP_OK;
   retVal = IcHalApiOptSerdesGetLopInFsmStatus(ulPhyOpt);
   return retVal;
}
UINT32 BspHalAdaptGetOptLofStatus(UINT32 ulPhyOpt)   /*物理光口状态机lof告警状态*/
{
   UINT32 retVal = BSP_OK;
   retVal = IcHalApiOptSerdesGetLofInFsmStatus(ulPhyOpt);
   return retVal;
}
UINT32 BspHalAdaptGetOptLosStatus(UINT32 ulPhyOpt)   /*物理光口状态机los告警状态*/
{
   UINT32 retVal = BSP_OK;
   retVal = IcHalApiOptSerdesGetLosInFsmStatus(ulPhyOpt);
   return retVal;
}

UINT32 BspHalAdaptQcellSwTblClr(VOID)
{
   UINT32 retVal = BSP_OK;
   retVal = IcHalApiQcellSwTblClr();
   retVal |= IcHalApiOptQcellCellDel();
   return retVal;
}

UINT32 BspHalAdaptGetCpriPhyOptAlm(UINT32 ulPhyOpt)   /*物理光口告警事件记录*/
{
   UINT32 retVal = BSP_OK;
   retVal = IcHalApiGetCpriPhyOptAlm(ulPhyOpt);
   return retVal;
}
UINT32 BspHalAdaptClrCpriPhyOptAlm(UINT32 ulPhyOpt,UINT32 ulAlmMask)   /*物理光口告警事件记录清楚，正常流程先清再读*/
{
   UINT32 retVal = BSP_OK;
   retVal = IcHalApiClrCpriPhyOptAlm(ulPhyOpt,ulAlmMask);
   return retVal;
}
UINT32 BspHalAdaptGetCpriLogOptAlm(UINT32 ulLogOpt)   /*逻辑光口告警事件记录*/
{
   UINT32 retVal = BSP_OK;
   retVal = IcHalApiGetCpriLogOptAlm(ulLogOpt);
   return retVal;
}
UINT32 BspHalAdaptClrCpriLogOptAlm(UINT32 ulLogOpt,UINT32 ulAlmMask)   /*逻辑光口告警事件记录清楚，正常流程先清再读*/
{
   UINT32 retVal = BSP_OK;
   retVal = IcHalApiClrCpriLogOptAlm(ulLogOpt,ulAlmMask);
   return retVal;
}
UINT32 BspHalAdaptGetCpriLogFsm(UINT32 ulLogOpt)    /* 逻辑光口状态机 */
{
    UINT32 retVal = BSP_OK;
    retVal = IcHalApiGetLogicFsmStatus(ulLogOpt);
    return retVal;
}
UINT32 BspHalAdaptGetCpriPhyFsm(UINT32 ulPhyOpt)    /* 物理光口状态机 */
{
    UINT32 retVal = BSP_OK;
    retVal = IcHalApiGetPhyFsmStatus(ulPhyOpt);
    return retVal;
}
UINT32 BspHalAdaptGetCpriCdcResyncSta(UINT32 ulPhyOpt)    /* 物理光口RX CDC跨时钟域失步 */
{
    UINT32 retVal = BSP_OK;
    retVal = IcHalApiGetCdcRxResyncStat(ulPhyOpt);
    return retVal;
}
/*serdes 状态机是否正常 返回ok代表正常 error代表异常*/
UINT32 BspHalAdaptGetSerdesFsmStatus(UINT32 ulPhyOpt)
{
    UINT32 retVal = BSP_OK;
    retVal = IcHalApiOptSerdesGetFsmStatus(ulPhyOpt);
    return retVal;
}

/* 配置TDD是否开启LOP/LOS/LOF/LCV检测,其影响TDD映射主光口竞争逻辑 */
UINT32 BspSetCfgTddLcvEnable(UINT32 ulMaskEn)
{
    UINT32 retVal = BSP_OK;
    retVal = IcHalApiCfgTddLcvEnable(ulMaskEn);
    return retVal;
}

/* 软件强制上报lop告警，不由IC自动上报告警 */
UINT32 BspOptManualSetLopAlarm(UINT32 ulLogicOpt, UINT32 softEn, UINT32 alarmEn)
{
    UINT32 retVal = BSP_OK;
    retVal = IcHalApiOptManualSetLopAlarm(ulLogicOpt, softEn, alarmEn);
    return retVal;
}

/* 软件强制上报los告警，不由IC自动上报告警 */
UINT32 BspOptManualSetLosAlarm(UINT32 ulLogicOpt, UINT32 softEn, UINT32 alarmEn)
{
    UINT32 retVal = BSP_OK;
    retVal = IcHalApiOptManualSetLosAlarm(ulLogicOpt, softEn, alarmEn);
    return retVal;
}

/* 软件强制上报lof告警，不由IC自动上报告警 */
UINT32 BspOptManualSetLofAlarm(UINT32 ulLogicOpt, UINT32 softEn, UINT32 alarmEn)
{
    UINT32 retVal = BSP_OK;
    retVal = IcHalApiOptManualSetLofAlarm(ulLogicOpt, softEn, alarmEn);
    return retVal;
}

UINT32 BspSetCpriCfgResetThres(UINT32 en, UINT32 thres)
{
    UINT32 retVal = BSP_OK;
    retVal = IcHalApiCpriCfgResetThres(en, thres);
    return retVal;
}

UINT32 BspSetCpriCfgResetPdThres(UINT32 en, UINT32 thres)
{
    UINT32 retVal = BSP_OK;
    retVal = IcHalApiCpriCfgResetPdThres(en, thres);
    return retVal;
}

UINT32 BspSetOptCwNetAlarmMask(UINT32 ulLogicOpt, UINT32 mask)
{
    UINT32 retVal = BSP_OK;
    retVal = IcHalApiOptCwNetAlarmMask(ulLogicOpt, mask);
    return retVal;
}

/*级联/环网模式下，向级联光口转发的控制字来源选择，可以选择主光口转发到级联光口，也可以选择按照光口绑定关系进行转发*/
UINT32 BspSetCpriCfgCasTransMode(UINT32 cfgEn, UINT32 transMode)
{
    UINT32 retVal = BSP_OK;
    retVal = IcHalApiCpriCfgCasTransMode( cfgEn, transMode);
    return retVal;
}

/*配置是否向下联光口转发IR rru id range，仅环网模式下有效*/
UINT32 BspSetCpriCfgTransIrRruIdRange(UINT32 cfgEn, UINT32 isTrans)
{
    UINT32 retVal = BSP_OK;
    retVal = IcHalApiCpriCfgTransIrRruIdRange( cfgEn, isTrans);
    return retVal;
}

/*配置逻辑光口2/3的10ms系统帧频是否环回指示。环/负荷分担加环网模式下有效。*/
UINT32 BspSetOptCpriSetFrameLoopBack(UINT32 logOptNo, UINT32 isSwitch)
{
    UINT32 retVal = BSP_OK;
    retVal = IcHalApiOptCpriSetFrameLoopBack(logOptNo, isSwitch);
    return retVal;
}

/*各逻辑光口控制字转发来源光口配置, 级联/环网时向上级转发下级告警*/
UINT32 BspSetOptCpriCwOptBindCfg(UINT32 logOptNo, UINT32 logOptBindSel)
{
    UINT32 retVal = BSP_OK;
    retVal = IcHalApiCpriCwOptBindCfg(logOptNo, logOptBindSel);
    return retVal;
}

UINT32 BspSetUpDownLinkOptNum(UINT32 softEn, UINT32 upLinkNum, UINT32 downLinKNum)
{
    UINT32 retVal = BSP_OK;
    retVal = IcHalApiCfgUpDownLinkOptNum(softEn, upLinkNum, downLinKNum);
    return retVal;
}

/*各光口绑定关系有效性配置。仅控制字组网转发时有效.*/
UINT32 BspSetOptCfgOptBindValid(UINT32 optBindValidEn, UINT32 optBindValidMask)
{
    UINT32 retVal = BSP_OK;
    retVal = IcHalApiCfgOptBindValid(optBindValidEn, optBindValidMask);
    return retVal;
}

/*环网时获取是否是末级*/
UINT32 BspSetOptCpriGetRruLastStageFlag(UINT32 *isLastStage)
{
    UINT32 retVal = BSP_OK;
    INPUT_POINTER_CHECK(isLastStage);

    retVal = IcHalApiCpriGetRruLastStageFlag(isLastStage);
    return retVal;
}

/*上报解析的IR协议控制字LOS/LOF。实时上报。对应逻辑光口0，仅逻辑光口2和3为下联口时，上报值有效。*/
UINT32 BspSetOptGetCpriCwIrLosLof(UINT32 logOptNo)
{
    UINT32 retVal = BSP_OK;
    retVal = IcHalApiGetCpriCwIrLosLof(logOptNo);
    return retVal;
}

/*绑定逻辑口和物理口关系*/
UINT32 BspSetOptCpriRelation(UINT32 ulLogOptNo, UINT32 ulPhyOptNo, UINT32 ulCpuCfgEn)
{
    UINT32 retVal = BSP_OK;
    retVal = IcHalApiCpriSetRelation(ulLogOptNo, ulPhyOptNo, ulCpuCfgEn);
    return retVal;
}

/*获取绑定逻辑口和物理口关系*/
UINT32 BspGetOptCpriRelation(UINT32 ulLogOptNo, UINT32 *ulPhyOptNo, UINT32 *ulCpuCfgEn)
{
    UINT32 retVal = BSP_OK;
    retVal = IcHalApiCpriGetCfgRelation(ulLogOptNo, ulPhyOptNo, ulCpuCfgEn);
    return retVal;
}

/* 信令使能设置 */
UINT32 BspHalAdaptRoeIqSetFlowEnOrDis(UINT32 ulDir, UINT32 ulChanIndex, UINT32 ulFlowId, UINT32 ulEnOrDis)
{
    UINT32 retVal = BSP_OK;
    retVal = IcHalRoeIqSetFlowEnOrDis(ulDir, ulChanIndex, ulFlowId, ulEnOrDis);
    return retVal;
}

/*关闭光口输出*/
UINT32 BspSetOptCpriCfgSfpTxDisable(UINT32 ulManualEn, UINT32 ulTransCfg)
{
    UINT32 retVal = BSP_OK;
    retVal = IcHalApiCpriCfgSfpTxDisable(ulManualEn, ulTransCfg);
    return retVal;
}

/* 控制光口天线使能(BIF/GIF/DIF) */
UINT32 BspHalAdaptSetOptAntEn(UINT32 dir, UINT32 enable)
{
    return IcHalApiSetOptAntEn(dir, enable);
}

/*关闭光口输出的掩码 ，配合BspSetOptCpriCfgSfpTxDisable使用*/
UINT32 BspSetOptCpriCfgIoTxDisableMask(UINT32 uMask)
{
    UINT32 retVal = BSP_OK;
    retVal = IcHalApiCpriCfgIoTxDisableMask(uMask);
    return retVal;
}

/*ulRstFlag 0:复位 1:释放*/
UINT32 BspHalAdaptCrmOptCpriLaneReset(UINT32 ulPhyOpt, UINT32 ulRstFlag)
{
    return IcHalApiCrmOptCpriLaneSetReset(ulPhyOpt,ulRstFlag);
}
UINT32 BspHalAdaptGetCpriFsmJumpCnt(UINT32 ulPhyOptNo)   /*物理光口状态机跳转次数计数，用以判断是否有跳转跃迁*/
{
   UINT32 ulCnt = 0;
   ulCnt = IcHalApiGetPhyOptSyncStatusChangeCnt(ulPhyOptNo);
   return ulCnt;
}


UINT32 BspHalAdaptGetMainLogicOpt(UINT32 *mainLogicOpt)/*获取逻辑主光口号,实际是通过物理主光口号转换过来的*/
{
    UINT32 retVal = BSP_OK;

    retVal = IcHalApiGetMainLogOpt(mainLogicOpt);

    return retVal;
}
UINT32 BspHalAdaptGetMainPhyOpt(UINT32 *mainPhyOpt)   /*获取物理主光口号*/
{
    UINT32 retVal = BSP_OK;

    retVal = IcHalApiGetMainPhyOpt(mainPhyOpt);

    return retVal;
}

UINT32 BspHalAdaptGetMainOptRruIndex(UINT32 *rruIndex)   /*获取RRU index */
{
    UINT32 retVal = BSP_OK;

    retVal = IcHalApiGetMainOptRruIndex(rruIndex);

    return retVal;
}

UINT32 BspHalAdaptSetDivClk(UINT32 chip,UINT32 speed,UINT32 div,UINT32 laneIdx)  /*设置crm恢复时钟接口 入参为物理光口对应的lane*/
{
    UINT32 retVal = BSP_OK;

    retVal = IcHalApiCrmOptCpriLaneSetDivClk(chip, speed,laneIdx);
    return retVal;
}

UINT32 BspHalAdaptSetCrmOptCpriRefClkSoft(UINT32 laneIdx)   /*crm 恢复钟选择，入参为物理光口对应的lane*/
{
    UINT32 retVal = BSP_OK;

    retVal = IcHalApiCrmOptCrpiRefClkSoft(0,laneIdx);

    return retVal;
}

UINT32 BspSetCrmOptCpriRefClkSoft(UINT32 laneIdx)
{
	 UINT32 pStatus = 0;
	 UINT32 uloop =0;
	 UINT32 date =0;
	 UINT32 retVal = BSP_OK;

	  for(uloop=0;uloop<15;uloop++)
	  {
	  	  BspSysMsDelay(10);
	  	  retVal = BspHalAdaptPcsGetLinkPcsSta(0,&pStatus);
	   	  CHECK_RETVAL_PRN(BspHalAdaptPcsGetLinkPcsSta, retVal);
	      if(0x3 == pStatus)
	      {
	          RedirPrintf("funcet %s  line %d,pStatus:%d!\n", __FUNCTION__,__LINE__,pStatus);
	      	  date++;
	      }
	      if(0x3 != pStatus)
	      {
	          RedirPrintf("funcet %s  line %d,pStatus:%d!\n", __FUNCTION__,__LINE__,pStatus);
	       	  date = 0;
	      }
	      if(date == 5 )
	      {
	          RedirPrintf("funcet %s  line %d,pStatus:%d!\n", __FUNCTION__,__LINE__,pStatus);
	      	  break;
	      }
	  }
	  BspHalAdaptSetCrmOptCpriRefClkSoft(laneIdx);
	  return BSP_OK;
}

UINT32 BspHalAdaptGetGfCheckFlag(VOID)
{
    return IcHalApiGetGfCheckFlag();
}

UINT32 BspHalAdaptSetCrmOptCrpiRefClkOeDisable(UINT32 laneIdx)   /*软件选择，同时关闭输出*/
{
    UINT32 retVal = BSP_OK;

    retVal = IcHalApiCrmOptCrpiRefClkOeDisable(0,laneIdx);

    return retVal;
}
UINT32 BspHalAdaptSetCrmOptCrpiRefClkLogic(VOID)   /*硬件选择，同时输出*/
{
    UINT32 retVal = BSP_OK;

    retVal = IcHalApiCrmOptCrpiRefClkLogic(0);

    return retVal;
}

// 获取恢复钟有没有打开
UINT32 BspHalAdaptCrmOptGetCrpiRefClkSta(UINT32 laneIdx) 
{
    UINT32 retVal = BSP_OK;

    retVal = IcHalApiCrmOptGetCrpiRefClkSta(0,laneIdx);

    return retVal;
}

UINT32 BspHalAdaptSetCrmOptECpriLaneSetDivClk(UINT32 chip,UINT32 speed,UINT32 laneIdx)
{
    UINT32 retVal = BSP_OK;

    retVal = IcHalApiCrmOptECpriLaneSetDivClk(chip,speed,laneIdx);

    return retVal;

}

UINT32 BspHalAdaptSetRoeQcellLinkRebuildApi(UINT32 roeChan)
{
    UINT32 retVal = BSP_OK;

    retVal = IcHalRoeQcellLinkRebuildApi(roeChan);

    return retVal;

}
/* Started by AICoder, pid:t694dca324g23f714f1e0a7560116f039168a0dd */
UINT32 BspHalAdaptSetRoeCpriLinkRebuildApi(UINT32 roeChan)
{
    UINT32 retVal = BSP_OK;

    // retVal = IcHalRoeCpriLinkRebuildApi(roeChan);

    return retVal;
}
/* Ended by AICoder, pid:t694dca324g23f714f1e0a7560116f039168a0dd */
UINT32 BspHalAdaptSetRoeIqDemapperTimeMeasApi(UINT32 roeChan, UINT32 *pMaxChipNum)
{
    UINT32 retVal = BSP_OK;

    retVal = IcHalRoeIqDemapperTimeMeasApi(roeChan, pMaxChipNum);

    return retVal;

}

/* Started by AICoder, pid:df267y90c8j355914df50a4a5074211bad07ccd1 */
UINT32 BspHalAdaptCrmCfgShortAlmDebounce(UINT32 nsbt0TimeUs, UINT32 nsbt1TimeUs, UINT32 rgpsTimeUs)
{
    UINT32 retVal = BSP_OK;

    retVal = IcHalApiCrmCfgShortAlmDebounce(nsbt0TimeUs, nsbt1TimeUs, rgpsTimeUs);

    return retVal;
}

UINT32 BspHalAdaptCrmCfgShortAlmExtend(UINT32 nsbt0TimeUs, UINT32 nsbt1TimeUs, UINT32 rgpsTimeUs)
{
    UINT32 retVal = BSP_OK;

    retVal = IcHalApiCrmCfgShortAlmExtend(nsbt0TimeUs, nsbt1TimeUs, rgpsTimeUs);

    return retVal;
}

UINT32 BspHalAdaptCrmCfgShortAlmBreak(UINT32 nsbt0TimeUs, UINT32 nsbt1TimeUs, UINT32 rgpsTimeUs)
{
    UINT32 retVal = BSP_OK;

    retVal = IcHalApiCrmCfgShortAlmBreak(nsbt0TimeUs, nsbt1TimeUs, rgpsTimeUs);

    return retVal;
}
/* Ended by AICoder, pid:df267y90c8j355914df50a4a5074211bad07ccd1 */

/* Started by AICoder, pid:w8687n36e0z51bf146400bafd046fe19786746b8 */
UINT32 BspHalAdaptCrmCfgShortAlmNsbt0(UINT32 debounceTimeUs, UINT32 extendTimeUs, UINT32 breakTimeUs)
{
    return IcHalApiCrmCfgShortAlmNsbt0( debounceTimeUs, extendTimeUs, breakTimeUs);
}

UINT32 BspHalAdaptCrmCfgShortAlmNsbt1(UINT32 debounceTimeUs, UINT32 extendTimeUs, UINT32 breakTimeUs)
{
    return IcHalApiCrmCfgShortAlmNsbt1(debounceTimeUs, extendTimeUs, breakTimeUs);
}

UINT32 BspHalAdaptCrmCfgShortAlmRgps(UINT32 debounceTimeUs, UINT32 extendTimeUs, UINT32 breakTimeUs)
{
    return IcHalApiCrmCfgShortAlmRgps(debounceTimeUs, extendTimeUs, breakTimeUs);
}
/* Ended by AICoder, pid:w8687n36e0z51bf146400bafd046fe19786746b8 */

/* Started by AICoder, pid:ya85de8619q6107143df0ab1700aec458c57b7a8 */
UINT32 BspHalAdaptCrmGetShortAlmNsbt0(UINT32 *pDebounceTimeUs, UINT32 *pExtendTimeUs, UINT32 *pBreakTimeUs)
{
    return IcHalApiCrmGetShortAlmNsbt0(pDebounceTimeUs, pExtendTimeUs, pBreakTimeUs);
}

UINT32 BspHalAdaptCrmGetShortAlmNsbt1(UINT32 *pDebounceTimeUs, UINT32 *pExtendTimeUs, UINT32 *pBreakTimeUs)
{
    return IcHalApiCrmGetShortAlmNsbt1(pDebounceTimeUs, pExtendTimeUs, pBreakTimeUs);
}

UINT32 BspHalAdaptCrmGetShortAlmRgps(UINT32 *pDebounceTimeUs, UINT32 *pExtendTimeUs, UINT32 *pBreakTimeUs)
{
    return IcHalApiCrmGetShortAlmRgps(pDebounceTimeUs, pExtendTimeUs, pBreakTimeUs);
}
/* Ended by AICoder, pid:ya85de8619q6107143df0ab1700aec458c57b7a8 */

UINT32 BspHalAdaptSetOptQcellInitApi(T_OPT_ROE_INIT_PARA *pOptRoeInitPara)
{
#ifdef UT_FT_TEST
    return BSP_OK;
#endif
    UINT32 retVal = BSP_OK;
    retVal = IcHalApiOptQcellInit(pOptRoeInitPara);
    return retVal;
}

UINT32 BspHalAdaptPcsSetGloableCfgEn(UINT32 ulPhyOpt, UINT32 ulSwitch)   /*pcs配置使能*/
{
    UINT32 retVal = BSP_OK;

    retVal = IcHalApiPcsSetGloableCfgEn(ulPhyOpt,ulSwitch);

    return retVal;
}

UINT32 BspHalAdaptPcsSetLinkProtocol(UINT32 ulPhyOpt, UINT32 protocal)   /*pcs设置编码模式*/
{
    UINT32 retVal = BSP_OK;

    retVal = IcHalApiPcsSetLinkProtocol(ulPhyOpt,protocal);

    return retVal;
}

UINT32 BspHalAdaptPcsSetLinkFecMode(UINT32 ulPhyOpt, UINT32 fecMode)   /*pcs设置fec模式*/
{
    UINT32 retVal = BSP_OK;

    retVal = IcHalApiPcsSetLinkFecMode(ulPhyOpt,fecMode);

    return retVal;
}

UINT32 BspHalAdaptPcsGetLinkFecMode(UINT32 ulPhyOpt, UINT32 *pfecMode)   /*pcs获取fec模式*/
{
    UINT32 retVal = BSP_OK;

    retVal = IcHalApiPcsGetLinkFecMode(ulPhyOpt, pfecMode);

    return retVal;
}

UINT32 BspHalAdaptPcsSet1XLinkCfgEn(UINT32 ulPhyOpt, UINT32 ulDir, UINT32 ulSwitch)   /*pcs复位解复位*/
{
    UINT32 retVal = BSP_OK;

    retVal = IcHalApiPcsSet1XLinkEn(ulPhyOpt,ulDir,ulSwitch);

    return retVal;
}

UINT32 BspHalAdaptPcsEventOutCtrlEn(UINT32 phyOpt, UINT32 *enSta)   /*获取均匀使能使能*/
{
    UINT32 retVal = BSP_OK;

    retVal = IcHalApiGetPcsEvenOutCtrlEn(phyOpt, enSta);

    return retVal;
}
/*gnss Gps需要从那个逻辑光口获取鉴相无相帧号*/
UINT32 BspSetCpriGpsBfnSel(UINT32 logicOpt)
{
    UINT32 retVal = BSP_OK;

    retVal = IcHalApiCpriGpsBfnSel(logicOpt);

    return retVal;
}

/*gnss Gps需要从那个逻辑光口获取鉴相10ms帧 */
UINT32 BspSetCpriGpsFrSel(UINT32 logicOpt)
{
    UINT32 retVal = BSP_OK;

    retVal = IcHalApiCpriGpsFrSel(logicOpt);

    return retVal;
}

UINT32 BspHalAdaptGetCurrentFiberPort(VOID)
{
    UINT32 retVal = BSP_OK;
    UINT32 optNo  = 0xff;

    retVal = IcHalApiGetMainLogOpt(&optNo);
    if(retVal != BSP_OK)
    {
    	dbgErr("BspHalAdaptGetCurrentFiberPort error\n");
    }
    return optNo;
}
UINT32 BspHalAdaptGetCpriRruId(UINT32 logNo)
{
	return IcHalApiGetCpriRruId(logNo);
}
UINT32 BspHalAdaptGetQcellRruId(UINT32 logNo)
{
	return IcHalApiGetQcellRruId(logNo);
}
UINT32 BspHalAdaptGetIrRruId(UINT32 logNo)
{
	return IcHalApiGetIrRruId(logNo);
}
UINT32 BspHalAdaptGetBbuFiberPort(UINT32 logNo)
{
    return IcHalApiGetCpriCwIrBbuPort(logNo);
}

UINT32 BspHalAdaptGetBbuCpriFiberPort(UINT32 logNo)
{
    return IcHalApiGetCpriCwCpriBbuPort(logNo);
}

UINT32 BspHalAdaptGetTddUplinkLinkInd(VOID)
{
	return IcHalApiGetTddUplinkLinkInd();
}
UINT32 BspHalAdaptGetTddUplinkRruIdRange(VOID)
{
	return IcHalApiGetTddUplinkRruIdRange();
}
UINT32 BspHalAdaptCpriSelfAdaptProtect(UINT32 uProtect)   /*自适应流程完成之前，需要关闭远程复位和掉电告警*/
{
	return IcHalApiCpriSelfAdaptProtect(uProtect);
}
UINT32 BspHalAdaptCpriGetStaCvCnt(UINT32 phyOpt)
{
	return IcHalApiGetCpriStaCvCnt(phyOpt);
}
UINT32 BspHalAdaptCpriGetStaShcCvCnt(UINT32 phyOpt)
{
	return IcHalApiGetCpriStaShcvCnt(phyOpt);
}
/*第二级异常导致第一级下联口有告警 无法正确转发控制字到第二级  第二级异常时强制指定，因为第二级依赖于此才能正常，否则死循环，第二级正常时恢复正常解析配置*/
UINT32 BspHalAdaptCpriCfgTxPriority(UINT32 ulLogOptNo, UINT32 ulPriorityCfg, UINT32 ulPriorityCfgEn)
{
    return IcHalApiCpriCfgTxPriority( ulLogOptNo,  ulPriorityCfg,  ulPriorityCfgEn);
}
/*2,1 异速率 2,2 同速率*/
UINT32 BspHalAdaptCpriUlFrameAlignFrSel(UINT32 ulLogOptNo, UINT32 ulUlFrSel)
{
    return IcHalApiCpriUlFrameAlignFrSel(ulLogOptNo,ulUlFrSel);
}
/*上下方向同一速率过serdes时延不一样，TDL TUL受影响，同速率级联不受影响，a+b == b+a 异速率没法加和抵消*/
UINT32 BspHalAdaptGetRateDlyDelt(UINT32 ulBspRate)
{
    return IcHalApiGetRateDlyDelt(ulBspRate);
}

UINT32 BspHalAdaptCpriGetCpriRstReq(UINT32 *rstReq)
{
    return IcHalApiCpriGetCpriRstReq(rstReq);
}

UINT32 BspHalAdaptCpriClearCpriRstReq(VOID)
{
    return IcHalApiCpriClearCpriRstReq();
}

/*FDD恢复时钟拔掉光纤没有关断问题增加 针对64b/66b编码时极限扩展和非极限扩展的选择，和FEC 模式保持一致*/
/*1、0xc2402a2c寄存器，fec_en是针对64b/66b编码时极限扩展和非极限扩展的选择；
2、0xc2402550寄存器，是产生los的不同处理方式选择，有0  1  2三种配置，该寄存器和0xc2402a2c配合使用。
     fec_en=1时，该寄存器配置为1，直接由pcs送给cpri的编码同步指示产生los；配置为2，cpri根据接收的超帧头解析处理产生los；配置为其它值，cpri根据接收的超帧头解析和pcs编码同步指示产生los。
     fec_en=0时，该寄存器配置为1，cpri根据接收的超帧头解析处理产生los；配置为2，直接由pcs送给cpri的错误帧头超门限指示产生los；配置为其它值，cpri根据接收的超帧头解析和pcs的错误帧头超门限指示产生los。
     光纤断链后，cpri收不到超帧头，cv_cnt计数无法累加，los告警就无法产生。所以fec_en=1时，配置为1。配置为2和其它值的区别，请@何林娜补充下*/
UINT32 BspHalAdaptCpriCfgFecEn(UINT32 ulphyOptNo, UINT32 ulSwitch) /*0xc2402a2c*/
{
    return IcHalApiCpriCfgFecEn(ulphyOptNo, ulSwitch);
}
/*FDD恢复时钟拔掉光纤没有关断问题增加  但是实测和微院理论不一致，不配置此寄存器 直接默认值0x80000001 */
UINT32 BspHalAdaptCpriMapLcvOption(UINT32 ulphyOptNo,UINT32 uSrcSel)    /*0xc2402550  fec_en=1时，该寄存器配置为1,fec_en=0时,配置为2 直接由pcs送给cpri的编码同步指示产生los */
{
  return IcHalApiCpriMapLcvOption(ulphyOptNo,uSrcSel);
}
/* Started by AICoder, pid:2e7e5m304d3074614c230a8180e7183f34f24ce2 */
/*配置帧头自震荡或者2点*/
UINT32 BspHalAdaptCpriSetFrTestMode(UINT32 ulLogOptNo, UINT32 ulTestMode)
{
    UINT32 netWorkMode = 0;

    (VOID)BspHalAdaptGetCpriNetMode(&netWorkMode);
    if(netWorkMode != NET_MODE_LOAD_SHARE)
    {
        return IcHalApiCpriSetFrTestMode(ulLogOptNo, ulTestMode);
    }

    return BSP_OK;
}
/* Started by AICoder, pid:u3f1ck787c2495b14ab508862011df2d9d837ca8 */
UINT32 BspHalAdaptCpriSetFrByLoadShare(UINT32 ulLogOptNo, UINT32 ulTestMode)
{
    UINT32 netWorkMode = 0;
    UINT32 ulProtocol  = 0;
    UINT32 ulRet       = BSP_OK;

    ulRet = BspHalAdaptGetCpriProtocol(&ulProtocol);
    if(ulRet != BSP_OK)
    {
        dbgErr("BspGetOptCpriProtocol error\n");
        return ulRet;
    }
    
    (VOID)BspHalAdaptGetCpriNetMode(&netWorkMode);
    dbgInfoEx("%s ulProtocol %d netWorkMode  %d \n",__FUNCTION__,ulProtocol,netWorkMode);
    if((netWorkMode == NET_MODE_LOAD_SHARE) && (ulProtocol == PROCOTOL_IR))
    {
        return IcHalApiCpriSetFrTestMode(ulLogOptNo, ulTestMode);
    }

    return BSP_OK;
}
/* Ended by AICoder, pid:u3f1ck787c2495b14ab508862011df2d9d837ca8 */
/* Ended by AICoder, pid:2e7e5m304d3074614c230a8180e7183f34f24ce2 */
UINT32 BspHalAdaptCpriGetFrTestMode(UINT32 ulLogOptNo, UINT32 *pulTestMode)
{
    return IcHalApiCpriGetFrTestMode(ulLogOptNo, pulTestMode);
}

UINT32 BspHalAdaptCpriInternalLoopback(UINT32 ulLogOptNo, UINT32 ulTestMode)
{
    return IcHalApiCpriInternalLoopback(ulLogOptNo, ulTestMode);
}

/*上联主逻辑光口开-1 上联另外个逻辑光口关-0  告警屏蔽数据*/
UINT32 BspHalAdaptCpriCfgMidfreqAlmShutDataEn(UINT32 ulLogOptNo, UINT32 ulSwitch)
{
    return IcHalApiCpriCfgMidfreqAlmShutDataEn(ulLogOptNo, ulSwitch);
}
/*ulAlgSel-0 正式流程 1-产线高速线缆*/
UINT32 BspHalAdaptLycaAlgorithmSel(UINT32 ulAlgSel)
{
    return IcHalApiSetLycaAlgorithm(ulAlgSel);
}
/*获取光口倒换方向*/
UINT32 BspHalAdaptCpriGetRruDirection(UINT32 *pRruDirection)
{
    UINT32 ulRet = BSP_OK;

    INPUT_POINTER_CHECK(pRruDirection);
    ulRet = IcHalApiCpriGetRruDirection(pRruDirection);

    return ulRet;
}
/*中频帧号来源选择   传逻辑主光口*/
UINT32 BspHalAdaptCpriMidFreqBfnSel(UINT32 ulBfnSel)
{
    return  IcHalApiCpriMidFreqBfnSel(ulBfnSel);
}

/*Psync无线帧号选择   传逻辑主光口*/
UINT32 BspHalAdaptCpriPsyncBfnSel(UINT32 ulLogOptNo)
{
    return  IcHalApiCpriPsyncBfnSel(ulLogOptNo);
}

UINT32 g_ulMainUpBaseDelayLogOpt = 0xff;     /*主片从进程使用的上行基准光口*/
/*GF通道帧头选择和延时使能配置*/
UINT32 BspHalAdaptCpriBifGfRxChanFr(UINT32 uMainLogOpt)
{
    g_ulMainUpBaseDelayLogOpt = uMainLogOpt;
    return IcHalApiCpriSetBifGfRxChanFr(uMainLogOpt);
}

UINT32 BspHalAdaptGetCpriBifGfRxChanFr(void)
{
    return g_ulMainUpBaseDelayLogOpt;
}

UINT32 BspHalAdaptCpriSetSW2FrDelay(void)
{
    return IcHalApiCpriSetSW2FrDelay();
}

UINT32 BspHalAdaptCpri2PointFrSel(void)
{
    return IcHalApiCpri2PointFrSel();
}

UINT32 BspHalAdaptSetSW2TXDownlinkFrSel(UINT32 baseOpt)
{
    return IcHalApiSetSW2TXDownlinkFrSel(baseOpt);
}

UINT32 BspHalDifPaOffOptAlmMaskPaptCfg(UINT32 uMainLogOpt)
{
    return IcHalApiCpriSetDifPaOffOptAlmMask(uMainLogOpt);
}


/*信令来源选择*/
UINT32 BspHalAdaptCpriCfgCmUxSel(UINT32 ulCfgUx, UINT32 ulCmUxSel)
{
    return IcHalApiCpriCfgCmUxSel(ulCfgUx, ulCmUxSel);
}
/*读取光口p值*/
UINT32 BspHalAdaptCpriGetRxPPoint(UINT32 *pPoint)
{
    INPUT_POINTER_CHECK(pPoint);
    return IcHalApiCpriGetRxPPoint(pPoint);
}

/*和主光口保持一致    上行对齐帧头选择   ulFrSel传逻辑主光口+1*/
UINT32 BspHalAdaptCfgSwSrcAlignFr(UINT32 ulFrSel)
{
    return IcHalApiCfgSwSrcAlignFr(ulFrSel);
}
/*下联口有lcv告警，屏蔽优先级控制字 ulMaskEn:1不发/0强发  ulPhyOptNo:下联逻辑口*/
UINT32 BspHalAdaptCfgPriorityCwMask(UINT32 ulPhyOptNo, UINT32 ulMaskEn)
{
    return IcHalApiCfgPriorityCwMask(ulPhyOptNo, ulMaskEn);
}
/*FDD 获取优先级控制字*/
UINT32 BspHalAdaptGetFddPriority(UINT32 ulPhyOptNo)
{
    return IcHalApiGetFddPriority(ulPhyOptNo);
}
/*获取状态机的同步状态 0xc240209c*/
UINT32 BspHalAdaptGetOptSyncStatus(UINT32 ulPhyOptNo)
{
    return IcHalApiGetSerdesPhyOptSyncStatus(ulPhyOptNo);
}

/*给IC下发APP下发的主光口号和方向*/
VOID BspHalAdaptSetMainPhyOpt(UINT32 mainPhyOpt, UINT32 dir)
{
    IcHalSetPhyMainOpt(mainPhyOpt);
    IcHalApiSetMasterPort(dir);
    return;
}
/* Started by AICoder, pid:g618ej7306a63a114f5b0b8bf034bf15db75e690 */
VOID BspHalAdaptSetSleepCellMasterPort(UINT32 port)
{
    IcHalApiSetSleepCellMasterPort(port);
    return;
}
UINT32 BspHalAdaptUlSleepCellCheck(UINT32 uiDifChan, UINT32 uiCarrId, UINT32 uiRadioMode)
{
    return IcHalApiUlSleepCellCheck(uiDifChan, uiCarrId, uiRadioMode);
}
UINT32 BspHalAdaptDlSleepCellCheck(UINT32 uiDifChan, UINT32 uiCarrId, UINT32 uiRadioMode)
{
    return IcHalApiDlSleepCellCheck(uiDifChan, uiCarrId, uiRadioMode);
}
/* Ended by AICoder, pid:g618ej7306a63a114f5b0b8bf034bf15db75e690 */

/* Started by AICoder, pid:t0abc070845a9d8140580bbd4019d55ea0697533 */
UINT32 BspHalAdaptCheckBifCarrDly(T_OptDormantCellCfgInfo *pDlyCfgInfo)
{
    INPUT_POINTER_CHECK(pDlyCfgInfo);
    return IcHalApiCheckBifCarrDly(pDlyCfgInfo);
}

UINT32 BspHalAdaptCheckGfCarrDly(T_OptDormantCellCfgInfo *pDlyCfgInfo)
{
    INPUT_POINTER_CHECK(pDlyCfgInfo);
    return IcHalApiCheckGfCarrDly(pDlyCfgInfo);
}

UINT32 BspHalAdaptCheckDifCarrDly(T_OptDormantCellCfgInfo *pDlyCfgInfo)
{
    INPUT_POINTER_CHECK(pDlyCfgInfo);
    return IcHalApiCheckDifCarrDly(pDlyCfgInfo);
}

UINT32 BspHalAdaptCheckFftCarrDly(T_OptDormantCellCfgInfo *pDlyCfgInfo)
{
    INPUT_POINTER_CHECK(pDlyCfgInfo);
    return IcHalApiCheckFftCarrDly(pDlyCfgInfo);
}

UINT32 BspHalAdaptTxSleepCellCheckGate(UINT32 uiChanId, UINT32 uiCarrId, UINT32 uiRadioMode, UINT32 *puiErrFlg)
{
    INPUT_POINTER_CHECK(puiErrFlg);
    return IcHalApiTxSleepCellCheckGate(uiChanId, uiCarrId, uiRadioMode, puiErrFlg);
}

UINT32 BspHalAdaptRxSleepCellCheckGate(UINT32 uiChanId, UINT32 uiCarrId, UINT32 uiRadioMode, UINT32 *puiErrFlg)
{
    INPUT_POINTER_CHECK(puiErrFlg);
    return IcHalApiRxSleepCellCheckGate(uiChanId, uiCarrId, uiRadioMode, puiErrFlg);
}

UINT32 BspHalAdaptTxSleepCellCheckNco(UINT32 uiChanId, UINT32 uiCarrId, UINT32 uiRadioMode, UINT32 *puiErrFlg)
{
    INPUT_POINTER_CHECK(puiErrFlg);
    return IcHalApiTxSleepCellCheckNco(uiChanId, uiCarrId, uiRadioMode, puiErrFlg);
}

UINT32 BspHalAdaptRxSleepCellCheckNco(UINT32 uiChanId, UINT32 uiCarrId, UINT32 uiRadioMode, UINT32 *puiErrFlg)
{
    INPUT_POINTER_CHECK(puiErrFlg);
    return IcHalApiRxSleepCellCheckNco(uiChanId, uiCarrId, uiRadioMode, puiErrFlg);
}

UINT32 BspHalAdaptTxSleepCellCheckBank(UINT32 uiChanId, UINT32 uiCarrId, UINT32 uiRadioMode, UINT32 *puiErrFlg)
{
    INPUT_POINTER_CHECK(puiErrFlg);
    return IcHalApiTxSleepCellCheckBank(uiChanId, uiCarrId, uiRadioMode, puiErrFlg);
}

UINT32 BspHalAdaptRxSleepCellCheckBank(UINT32 uiChanId, UINT32 uiCarrId, UINT32 uiRadioMode, UINT32 *puiErrFlg)
{
    INPUT_POINTER_CHECK(puiErrFlg);
    return IcHalApiRxSleepCellCheckBank(uiChanId, uiCarrId, uiRadioMode, puiErrFlg);
}
/* Ended by AICoder, pid:t0abc070845a9d8140580bbd4019d55ea0697533 */

UINT32 BspHalAdaptCfgTddLcvEnable(UINT32 maskEn)
{
    return IcHalApiCfgTddLcvEnable(maskEn);
}

/*获取光口无线帧*/
UINT32 BspGetSynPsyncFrameNo(VOID)
{
    return IcHalApiGetSynPsyncFrameNo();
}
/*设置光口超帧*/
UINT32 BspSetSynPsyncSuperFrameNo(UINT32 superFrameNo)
{
    return IcHalApiSetSynPsyncSuperFrameNo(superFrameNo);
}
UINT32 BspHalAdaptGetSynPsyncSuperFrameNo(VOID)
{
    return IcHalApiGetSynPsyncSuperFrameNo();
}

/* UTDOA中断开关 */
UINT32 BspHalAdaptUtdoaPsyncIrqCfg(UINT32 switchEnable)
{
#ifdef UT_FT_TEST
    return BSP_OK;
#endif
    return IcHalApiUtdoaPsyncIrqCfg(switchEnable);
}

/* UTDOA中断获取获取切换标记flag */
UINT32 BspHalAdaptUtdoaGetCovertFlag(VOID)
{
#ifdef UT_FT_TEST
    return BSP_OK;
#endif
    return IcHalApiUtdoaGetCovertFlag();
}

/* UTDOA设置光口中断共享标志的flag */
UINT32 BspHalAdaptUtdoaSetCovertFlag(UINT32 convertFlag)
{
#ifdef UT_FT_TEST
    return BSP_OK;
#endif
    return IcHalApiUtdoaSetCovertFlag(convertFlag);
}

// uiEn：1代表清gp，0代表不清gp。utdoa场景配1，其他场景配0
UINT32 BspHalAdaptSetUlTddClrEn(UINT32 bspChan, UINT32 carrId, UINT32 radioMode, UINT32 en)
{
    return IcHalApiSetUlTddClrEn(bspChan, carrId, radioMode, en);
}

//1代表动态门控有效，节电；0代表动态门控不生效，不节电。UTDOA场景配0，其余场景配1
UINT32 BspHalAdaptSetUlBankTddSw(UINT32 bspChan, UINT32 carrId, UINT32 radioMode, UINT32 en)
{
    return IcHalApiSetUlBankTddSw(bspChan, carrId, radioMode, en);
}

/* Started by AICoder, pid:64f73vfd32r401e1424309803011781f4e03b72e */
UINT32 BspHalAdaptSetUtSendAacGain(UINT32 difChan, UINT32 carrId, UINT32 radioMode, T_BspHalAdaptUtAacGainArray *pAacGainArray)
{
#ifdef UT_FT_TEST
    return BSP_OK;
#endif
    return IcHalApiSetUtSendAAcGain(difChan, carrId, radioMode, pAacGainArray);
}
/* Ended by AICoder, pid:64f73vfd32r401e1424309803011781f4e03b72e */

/* Started by AICoder, pid:w04cem6067nbe93147050a3a30d10e1aa595598c */
UINT32 BspHalAdaptUtdoaAacIrqCfg(UINT32 en)
{
#ifdef UT_FT_TEST
    return BSP_OK;
#endif
    return IcHalApiUtdoaAacIrqCfg(en);
}

UINT32 BspHalAdaptSetUtdoaSmallErgodicPara(T_UtdoaSmallErgodicParaOpt *utdoaAacPara)
{
#ifdef UT_FT_TEST
    return BSP_OK;
#endif
    return IcHalApiSetUtdoaSmallErgodicPara(utdoaAacPara);
}
/* Ended by AICoder, pid:w04cem6067nbe93147050a3a30d10e1aa595598c */

//清除数据 uiType(3代表UTDOA) uiGrp(0代表RTT增益组号，1代表R2R增益组号)
// UINT32 BspHalAdaptClrSaveRegInfo(UINT32 uiType, UINT32 uiGrp)

//设置存放类型号   uiType和uiGrp含义同（1）
// UINT32 BspHalAdaptSetSaveGrp(UINT32 uiType, UINT32 uiGrp)

//使能  //uiEn配置为1，代表下发的增益会进行寄存器地址和值的映射操作。
// UINT32 BspHalAdaptSetSaveRegEn(UINT32 uiEn)

//bsp下发载波增益，中频完成映射关系并保存到全局变量

/* Started by AICoder, pid:u27e51b0eba77d3147960a321046851cce92ce58 */
UINT32 BspHalAdaptSaveUtSendAAcGain(UINT32 uiDifChan, UINT32 uiCarrId, UINT32 uiRadioMode, T_BspHalAdaptUtAacGainArray *pAacGainArray)
{
#ifdef UT_FT_TEST
    return BSP_OK;
#endif
    return IcHalApiSaveUtSendAAcGain(uiDifChan, uiCarrId, uiRadioMode, pAacGainArray);
}
/* Ended by AICoder, pid:u27e51b0eba77d3147960a321046851cce92ce58 */

// uiType配置为3 获取映射关系的全局变量数组，用于写入共享内存。
// UINT32 BspHalAdaptGetSaveRegInfo(UINT32 uiType, UINT32 uiGrp, T_RegSaveUnit* pData)

/* Started by AICoder, pid:z3ebdhc858w5ad214f860ab8406e8b4d873169ab */
UINT32 BspHalAdaptUtInsertSampleUlBank(UINT32 chanMask, UINT32 carrId, UINT32 radioMode, UINT32 mode)   //回插后采数接口
{
#ifdef UT_FT_TEST
    return BSP_OK;
#endif
    return IcHalApiUtInsertSampleUlBank(chanMask, carrId, radioMode, mode);
}

UINT32 BspHalAdaptSampleBank(UINT32 chanMask, UINT32 carrId, UINT32 radioMode, UINT32 mode, UINT32 flag)   //utdoat统一采数接口
{
#ifdef UT_FT_TEST
    return BSP_OK;
#endif
    return IcHalApiUtdoaSample(chanMask, carrId, radioMode, mode, flag);
}

UINT32 BspHalAdaptRecoverSampleCfg(VOID)  //采数配置恢复接口
{
#ifdef UT_FT_TEST
    return BSP_OK;
#endif
    return IcHalApiRecoverSampleCfg();
}

// 入参：配置2 ，代表ulbank 返回值：0代表采数未完成，1代表采数完成
UINT32 BspHalAdaptGetSampleCarrFinish(UINT32 module)   /** 打印载波级采数是否完成标志*/
{
#ifdef UT_FT_TEST
    return BSP_OK;
#endif
    return IcHalApiGetSampleCarrFinish(module);
}

// 入参：uiModule配置为2
UINT32 BspHalAdaptEndSampleCarr(UINT32 module)   //结束载波级采数 
{
#ifdef UT_FT_TEST
    return BSP_OK;
#endif
    return IcHalApiEndSampleCarr(module);
}

UINT32 BspHalAdaptRenameSampleFile(VOID)
{
#ifdef UT_FT_TEST
    return BSP_OK;
#endif
    return IcHalApiRenameSampleFile();
}
/* Ended by AICoder, pid:z3ebdhc858w5ad214f860ab8406e8b4d873169ab */

UINT32 BspHalAdaptRenameUtdoaSampleFile(UINT32 flag)
{
#ifdef UT_FT_TEST
    return BSP_OK;
#endif
    return IcHalApiRenameUtodaSampleFile(flag);
}

UINT32 BspHalAdaptCpriSerdesGetLosCnt(UINT32 ulPhyOptNo)
{
    return IcHalCpriSerdesGetLosCnt(ulPhyOptNo);
}

UINT32 BspHalAdaptCpriSerdesGetLofCnt(UINT32 ulPhyOptNo)
{
    return IcHalCpriSerdesGetLofCnt(ulPhyOptNo);
}

UINT32 BspHalAdaptCpriSerdesGetLopCnt(UINT32 ulPhyOptNo)
{
    return IcHalCpriSerdesGetLopCnt(ulPhyOptNo);
}

/*按逻辑口软配bbuport*/
UINT32 BspHalAdaptSoftCfgTxBbuport(UINT32 ulLogOpt, UINT32 ulCfgEn)
{
    return IcHalApiSoftCfgTxBbuport(ulLogOpt,ulCfgEn);
}
/**************************************************************************
                            IQ相关接口
**************************************************************************/
UINT32 BspHalAdaptOptSwTblAssign(UINT32 uCfgNum, T_IQRecord_BSP *pPara)
ICHAL_ADAPT_FUNC_DEF(OptSwTblAssign,uCfgNum,pPara)
UINT32 BspHalAdaptGetPPoint(UINT32 optPort)
ICHAL_ADAPT_FUNC_DEF(CpriGetPPoint,optPort)
UINT32 BspHalAdaptSetGlobleOutFrDir(UINT32 dir)
ICHAL_ADAPT_FUNC_DEF(SetGlobleOutFrDir,dir)
UINT32 BspHalAdaptOptRachSwTblAssign(UINT32 tblNum, T_IQRecord_BSP *pTblInfo)
ICHAL_ADAPT_FUNC_DEF(OptRachSwTblAssign, tblNum, pTblInfo)

UINT32 BspHalAdaptSetCpriLineRate(UINT32 ulPhyNo,UINT32 ulSpeed)
{
    return IcHalApiSetCpriLineRate(ulPhyNo,ulSpeed);
}
UINT32 BspHalAdaptUpdateFrCfg(VOID)
{
    return IcHalApiUpdateFrCfg();
}
UINT32 BspHalAdaptOptCrsSwTblCfg(UINT32 uTblNum, T_IQRecord_Slave *pTblInfo)
{
    return IcHalApiOptCrsSwTblCfg(uTblNum,pTblInfo);
}
UINT32 BspHalAdaptCpriCfgDlNetTrasBypass(UINT32 ulLogOptNo, UINT32 bypass)
{
    return IcHalApiCpriCfgDlNetTrasBypass(ulLogOptNo, bypass);
}

UINT32 BspHalAdaptCpriCfgUlNetTrasBypass(UINT32 ulLogOptNo, UINT32 bypass)
{
     return IcHalApiCpriCfgUlNetTrasBypass(ulLogOptNo, bypass);
}

UINT32 BspHalAdaptCpriCfgTulFixedValue(UINT32 val)
{
    return IcHalApiCpriCfgTulFixedValue(val);
}
/**************************************************************************
                            时延相关接口
**************************************************************************/
UINT32 BspHalAdaptSetFrameAlignment(UINT32 bandId, UINT32 radioMode, INT32 frameDelay)
ICHAL_ADAPT_FUNC_DEF(SetFrameAlignment, bandId, radioMode, frameDelay)
UINT32 BspHalAdaptSetFrameAlignment_FDD(UINT32 bspChan, UINT32 carrNo, UINT32 radioMode, INT32 frameDelay)
ICHAL_ADAPT_FUNC_DEF(SetFddFrameAlignment, bspChan, carrNo, radioMode, frameDelay)
UINT32 BspHalAdaptUpdateFddDlTddRamFrDly(UINT32 bspChan, UINT32 carrNo, UINT32 radioMode)
ICHAL_ADAPT_FUNC_DEF(UpdateFddDlTddRamFrDly, bspChan, carrNo, radioMode)
UINT32 BspHalAdaptUpdateDifChanDelay(UINT32 difChan)
ICHAL_ADAPT_FUNC_DEF(UpdateDifChanDelay, difChan)
UINT32 BspHalAdaptUpdateTxDifChanDelay(UINT32 difChan)/* 下行 */
ICHAL_ADAPT_FUNC_DEF(UpdateTxDifChanDelay, difChan)
UINT32 BspHalAdaptUpdateRxDifChanDelay(UINT32 difChan)/* 上行 */
ICHAL_ADAPT_FUNC_DEF(UpdateRxDifChanDelay, difChan)
UINT32 BspHalAdaptUpdateDifCarrDelay(UINT32 difChan, UINT32 radioMod, UINT32 difCarrNo)
ICHAL_ADAPT_FUNC_DEF(UpdateDifCarrDelay, difChan, difCarrNo, radioMod)
UINT32 BspHalAdaptUpdateQcellDifCarrDelay(UINT32 difChan, UINT32 carrIndex, UINT32 radioMode, UINT32 dir)/* QCELL用 */
{
    UINT32 retVal = BSP_OK;
    if(TX == dir)
    {
        return IcHalApiUpdateTxDifCarrDelay(difChan,carrIndex,radioMode);
    }
    else if(RX == dir)
    {
        return IcHalApiUpdateRxDifCarrDelay(difChan,carrIndex,radioMode);
    }
    else
    {
        dbgInfoEx("dir error!!");
    }
    return retVal;
}
UINT32 BspHalAdaptSetDlTddCarrDelay(UINT32 difChan, UINT32 difCarrNo, UINT32 radioMod)
{
    UINT32 retVal = BSP_OK;
    retVal = IcHalApiSetDlTddCarrDelay( difChan,difCarrNo, radioMod);
    return retVal;
}

UINT32 BspHalAdaptSetDl204AndRfDlyAllChan(UINT32 *dlDly, UINT32 num)
{
    UINT32 retVal = BSP_OK;
    UINT32 loop = 0;

    INPUT_POINTER_CHECK(dlDly);
    if(num > BSP_IC42_MAX_TX_CHAN_NUM)
    {
        return BSP_ERROR;
    }
    for(loop = 0; loop < num; loop++)
    {
        g_ulRfDef204AndRfDly[loop][TX] = dlDly[loop];    /*存储设置默认时延值 */
    }
    retVal = IcHalApiSetDl204AndRfDly(dlDly,num);

    return retVal;
}

UINT32 BspHalAdaptSetUl204AndRfDlyAllChan(UINT32 *ulDly, UINT32 num)
{
    UINT32 retVal = BSP_OK;
    UINT32 loop = 0;

    INPUT_POINTER_CHECK(ulDly);
    if(num > BSP_IC42_MAX_TX_CHAN_NUM)
    {
        return BSP_ERROR;
    }
    for(loop = 0; loop < num; loop++)
    {
        g_ulRfDef204AndRfDly[loop][RX] = ulDly[loop];
    }
    retVal = IcHalApiSetUl204AndRfDly(ulDly,num);

    return retVal;
}

/*获取单板初始化设置的默认射频时延值*/
UINT32 BspHalAdapGetDefDl204AndRfDly(UINT32 chan, UINT32 dir, UINT32 *pDly)
{
    INPUT_POINTER_CHECK(pDly);
    if(chan >= BSP_IC42_MAX_TX_CHAN_NUM)
    {
        return BSP_ERROR;
    }
    if(dir >= PRX)
    {
        return BSP_ERROR;
    }
    *pDly =  g_ulRfDef204AndRfDly[chan][dir];

    return BSP_OK;
}

/*按通道 设置射频时延值*/
UINT32 BspHalAdaptSetUl204AndRfDlyByChan(UINT32 chan, UINT32 dly)
{
    return IcHalApiSetUl204AndRfDlyByChan(dly, chan);
}

/*按通道 设置射频时延值*/
UINT32 BspHalAdaptSetDl204AndRfDlyByChan(UINT32 chan, UINT32 dly)
{
    return IcHalApiSetDl204AndRfDlyByChan(dly, chan);
}

//UINT32 BspHalAdaptGetUeAdvVal(UINT32 uMode)
//ICHAL_ADAPT_FUNC_DEF(GetUeAdvVal,uMode)
UINT32 BspHalAdaptSetUeAdvVal(UINT32 uMode, UINT32 uVal)
ICHAL_ADAPT_FUNC_DEF(SetUeAdvVal, uMode, uVal)
//UINT32 BspHalAdaptGetUeGapVal(UINT32 uMode, UINT32 *uVal)
//ICHAL_ADAPT_FUNC_DEF(GetUeGapVal,uMode,uVal)
//UINT32 BspHalAdaptSetFrameStruc(UINT32 uStrucUs)
//ICHAL_ADAPT_FUNC_DEF(SetFrameStruc,uStrucUs)

/*给HAL层提供TA和T12值*/
UINT32 BspHalAdaptSetTa(UINT32 optIndex, UINT32 taDelay)
{
    UINT32 retVal = BSP_OK;
    retVal = IcHalApiSetTaVal(taDelay);
    return retVal;
}

UINT32 BspHalAdaptSetRxTa(UINT32 optIndex, UINT32 taDelay)
{
    UINT32 retVal = BSP_OK;
    retVal = IcHalApiSetRxTaVal(taDelay);
    return retVal;
}

UINT32 BspHalAdaptSetSw2TxDstPort(UINT32 ulEn)
{
	return IcHalApiSetSw2TxDstPort(ulEn);
}
UINT32 BspHalAdaptSetQcellNrCompSwTable(UINT32 rate)
{
    UINT32 retVal = BSP_OK;
    retVal = IcHalApiSetQcellNrCompSwTable(rate);
    return retVal;
}

UINT32 BspHalAdaptSetQcellDelayPara(T_QCELLDELAYPARA *pQcellDelayPara, UINT32 uNum)
{
    UINT32 retVal = BSP_OK;
    retVal = IcHalApiSetQcellDelayPara(pQcellDelayPara, uNum);
    return retVal;
}
UINT32 BspHalAdaptRoeGetQcellCfgPacket(T_BspHalAdaptQcellCfgPacketType ulType, UINT8 *buf, UINT32 ulLen)
{
    UINT32 retVal = BSP_OK;
    retVal =  IcHalRoeGetQcellCfgPacket(ulType, buf, ulLen);
    return retVal;
}
UINT32 BspHalAdaptRoeFrPsyncToCpri(UINT32 roeIqChan)
{
   UINT32 retVal = BSP_OK;
   retVal =  IcHalApiRoeFrPsyncToCpri(roeIqChan);
   return retVal;
}
UINT32 BspHalAdaptRoeGetMeasureChange(UINT32 roeIqChan)
{
    UINT32 retVal = BSP_ERROR;
    UINT32 errVal = 1;
    UINT32 mapFlag = 0;
    UINT32 demapFlag = 0;

    mapFlag = IcHalApiRoeGetMapMeasureChange(roeIqChan);
    demapFlag = IcHalApiRoeGetDemapMeasureChange(roeIqChan, errVal);
    if ((ROE_CHANGE == mapFlag) || (ROE_CHANGE == demapFlag))
    {
        retVal = BSP_OK;
    }

    return retVal;
}
UINT32 BspHalAdaptGetEthMasterToffset(UINT32 *pulVal)
{
	UINT32 retVal = BSP_OK;
	retVal = IcHalGetEthMasterToffset(pulVal);
    return retVal;

}

UINT32 BspHalAdaptOptMonitorM0(VOID)
{
#ifdef UT_FT_TEST
   return BSP_OK;
#endif
    UINT32 retVal = BSP_OK;
    retVal = IcHalApiOptMonitorM0();
    return retVal;
}
UINT32 BspHalAdaptOptGetQcellMonitorState(VOID)
{
    UINT32 retVal = BSP_OK;
    retVal = IcHalApiOptGetQcellMonitorState();
    return retVal;
}

VOID BspHalAdapOptSetQcellMonitoState(UINT32 ulVal)
{
	 IcHalApiOptSetQcellMonitoState(ulVal);
     return ;
}

UINT32 BspHalAdaptGetQcellDelayPara(UINT32 uRadio, UINT32 uT12OrT34OrTa, UINT32 *pVal)
{
    return IcHalApiGetQcellDelayPara(uRadio, uT12OrT34OrTa, pVal);
}

/* 记录光口链接断链的状态 */
VOID BspHalAdaptRecordLinkBrokenState(VOID)
{
#ifdef UT_FT_TEST
   return ;
#endif
    IcHalApiRecordLinkBrokenState();
}

/*T12的下发uFwdOrRvs: 0-正向     1-反向*/
UINT32 BspHalAdaptSetT12(UINT32 uFwdOrRvs, UINT32 delay)
{
    UINT32 retVal = BSP_OK;
    retVal = IcHalApiSetT12Val(uFwdOrRvs,delay);
    return retVal;
    
}
/*T34的下发uFwdOrRvs: 0-正向     1-反向*/
UINT32 BspHalAdaptSetT34(UINT32 uFwdOrRvs, UINT32 t34Delay)
{
    UINT32 retVal = BSP_OK;
    retVal = IcHalApiSetT34Val(uFwdOrRvs,t34Delay);
    return retVal;
}

/*设置Talign 时延参数*/
void BspHalAdaptSetFddTalign(UINT32 talign)
{
    IcHalApiSetFddTalign(talign);
}

/*按逻辑口设置T12 负荷分担组网需要*/
UINT32 BspHalAdaptSetOptT12Val(UINT32 logOptNo, UINT32 uT12Val)
{
    UINT32 retVal = BSP_OK;
    retVal = IcHalApiSetOptT12Val(logOptNo, uT12Val);
    return retVal;
}

UINT32 BspHalAdaptSetOptT34Val(UINT32 logOptNo, UINT32 uT34Val)
{
    UINT32 retVal = BSP_OK;
    retVal = IcHalApiSetOptT34Val(logOptNo, uT34Val);
    return retVal;
}

UINT32 BspSaveBbuGlobalOptPort(UINT32 BBUGlobalOptID0, UINT32 BBUGlobalOptID1)
{
    g_BbuGlobalOptPort0 = BBUGlobalOptID0;
    g_BbuGlobalOptPort1 = BBUGlobalOptID1;

    return BSP_OK;
}

/* Started by AICoder, pid:ab4ack6a8540a6d14c1c0977c04dc828cd47a92a */
/*负荷分担双光口时 检测基准光口*/
UINT32 BspHalAdaptGetMaxDelay2Point(VOID)
{
    UINT32 loop= 0;
    UINT32 bbuPort = 0;
   /* 目前D42对外最多只有两个光口 */
    for(loop = 0; loop < 2; loop++)
    {
        bbuPort = IcHalApiGetCpriCwIrBbuPort(loop);
         if((g_BbuGlobalOptPort0 == bbuPort) && (g_BbuGlobalOptPort0 != 0xff))
         {
             if(g_BbuGlobalOptPort1 == IcHalApiGetCpriCwIrBbuPort(1 - loop))
             {
                 return IcHalApiGetMaxDelay2Point();
             }
             return loop;
         }

         if((g_BbuGlobalOptPort1 == bbuPort) && (g_BbuGlobalOptPort1 != 0xff))
         {
             if(g_BbuGlobalOptPort0 == IcHalApiGetCpriCwIrBbuPort(1 - loop))
             {
                 return IcHalApiGetMaxDelay2Point();
             }
             return loop;
         }
     }

    return IcHalApiGetMaxDelay2Point();
}
/* Ended by AICoder, pid:ab4ack6a8540a6d14c1c0977c04dc828cd47a92a */

/* Started by AICoder, pid:o106086ff0b3df3141e30a2c00e161201a3954ff */
UINT32 BspHalAdaptGetMinDelay3Point(VOID)
{
    UINT32 loop= 0;
    UINT32 bbuPort = 0;
   /* 目前D42对外最多只有两个光口 */
    for(loop = 0; loop < 2; loop++)
    {
        bbuPort = IcHalApiGetCpriCwIrBbuPort(loop);
         if((g_BbuGlobalOptPort0 == bbuPort) && (g_BbuGlobalOptPort0 != 0xff))
         {
             if(g_BbuGlobalOptPort1 == IcHalApiGetCpriCwIrBbuPort(1 - loop))
             {
                 return IcHalApiGetMinDelay3Point();
             }
             return loop;
         }

         if((g_BbuGlobalOptPort1 == bbuPort) && (g_BbuGlobalOptPort1 != 0xff))
         {
             if(g_BbuGlobalOptPort0 == IcHalApiGetCpriCwIrBbuPort(1 - loop))
             {
                 return IcHalApiGetMinDelay3Point();
             }
             return loop;
         }
     }

    return IcHalApiGetMinDelay3Point();
}
/* Ended by AICoder, pid:o106086ff0b3df3141e30a2c00e161201a3954ff */

UINT32 g_ulMainBaseDelayLogOpt = 0xff;     /*主从片使用的基准光口*/
UINT32 g_ulMainLogOptOnMaster = 0xff;     /*主片主逻辑光口*/
/*将当前检测到的基准光口下发给hal*/
VOID BspHalAdaptSetBaseDelayLogOpt(UINT32 baseOpt)
{
    g_ulMainBaseDelayLogOpt = baseOpt;
    IcHalApiSetBaseDelayLogOpt(baseOpt);
}

VOID BspHalAdaptSetSlaveBaseDelayLogOpt(UINT32 logOpt)
{
    IcHalApiSetSlaveBaseDelayLogOpt(logOpt);
}

UINT32 BspHalAdaptGetBaseDelayLogOpt(VOID)
{
    return g_ulMainBaseDelayLogOpt;
}

VOID BspHalAdaptSetMainLogOptOnMaster(UINT32 logOpt)
{
    g_ulMainLogOptOnMaster = logOpt;
}

UINT32 BspHalAdaptGeMainLogOptOnMaster(VOID)
{
    return g_ulMainLogOptOnMaster;
}


UINT32 BspHalAdaptSetFftDelay(UINT32 uDir, UINT32 uFwdOrRvs)
{
    UINT32 retVal = BSP_OK;
    retVal = IcHalApiSetFftDelay(uDir,uFwdOrRvs);
    return retVal;
}
UINT32 BspHalAdaptSetTxIcPreDly(UINT32 radio, UINT32 *preDly, UINT32 dlyNum)
ICHAL_ADAPT_FUNC_DEF(SetTxIcPreDly, radio, preDly, dlyNum)
UINT32 BspHalAdaptSetTxIcPostDly(UINT32 radio, UINT32 *postDly, UINT32 dlyNum)
ICHAL_ADAPT_FUNC_DEF(SetTxIcPostDly, radio, postDly, dlyNum)
UINT32 BspHalAdaptSetRxIcPreDly(UINT32 radio, UINT32 *preDly, UINT32 dlyNum)
ICHAL_ADAPT_FUNC_DEF(SetRxIcPreDly, radio, preDly, dlyNum)
UINT32 BspHalAdaptSetRxIcPostDly(UINT32 radio, UINT32 *postDly, UINT32 dlyNum)
ICHAL_ADAPT_FUNC_DEF(SetRxIcPostDly, radio, postDly, dlyNum)
UINT32 BspHalAdaptGetT2aDlyMax(UINT32 radio, UINT32 *dly)
ICHAL_ADAPT_FUNC_DEF(GetT2aDlyMax, radio, dly)
UINT32 BspHalAdaptGetTa3DlyMax(UINT32 radio, UINT32 *dly)
ICHAL_ADAPT_FUNC_DEF(GetTa3DlyMax, radio, dly)

UINT32 BspHalAdaptSetCarrDly_FDD(UINT32 uChan, UINT32 dir, UINT32 carrNo, UINT32 uRadioMode, T_BspAdaptCarrDelayItem *tCarrDelay)
{
    UINT32 retVal = BSP_OK;
    UINT32 checkFlag = 0;

    if (RX == dir)
    {
        if((tCarrDelay->dwPrmUPDelay != TIME_DLY_INVALID) || (tCarrDelay->dwSecUPDelay != TIME_DLY_INVALID))
        {
            retVal |= IcHalApiSetFddCarrDly(uChan,carrNo,dir,uRadioMode,tCarrDelay->dwPrmUPDelay,tCarrDelay->dwSecUPDelay, checkFlag);
        }
    }

    if (TX == dir)
    {
        if((tCarrDelay->dwPrmDLDelay != TIME_DLY_INVALID) || (tCarrDelay->dwSecDLDelay != TIME_DLY_INVALID))
        {
            retVal |= IcHalApiSetFddCarrDly(uChan,carrNo,dir,uRadioMode,tCarrDelay->dwPrmDLDelay,tCarrDelay->dwSecDLDelay, checkFlag);
        }
    }

    return retVal;
}

/* Started by AICoder, pid:baabadcbf6v80a6140ab0b1e204f9b399ba95acd */
UINT32 BspHalAdaptSetCarrDly_Check(UINT32 uChan, UINT32 dir, UINT32 carrNo, UINT32 uRadioMode, T_BspAdaptCarrDelayItem *tCarrDelay)
{
    UINT32 retVal = BSP_OK;
    UINT32 checkFlag = 1;/*睡眠小区检测标志，hal层复用已有实现*/

    if (RX == dir)
    {
        if((tCarrDelay->dwPrmUPDelay != TIME_DLY_INVALID) || (tCarrDelay->dwSecUPDelay != TIME_DLY_INVALID))
        {
            retVal |= IcHalApiSetFddCarrDly(uChan,carrNo,dir,uRadioMode,tCarrDelay->dwPrmUPDelay,tCarrDelay->dwSecUPDelay,checkFlag);
        }
    }

    if (TX == dir)
    {
        if((tCarrDelay->dwPrmDLDelay != TIME_DLY_INVALID) || (tCarrDelay->dwSecDLDelay != TIME_DLY_INVALID))
        {
            retVal |= IcHalApiSetFddCarrDly(uChan,carrNo,dir,uRadioMode,tCarrDelay->dwPrmDLDelay,tCarrDelay->dwSecDLDelay,checkFlag);
        }
    }
    
    return retVal;
}
/* Ended by AICoder, pid:baabadcbf6v80a6140ab0b1e204f9b399ba95acd */

UINT32 BspHalAdaptSetOptTDDCarrDly(UINT32 uChan,UINT32 uDir,UINT32 uCarrNo, UINT32 uRadioMode,T_BspAdaptCarrDelayItem *tCarrDelay)
{
    UINT32 retVal = BSP_OK;

    if (RX == uDir)
    {
        if((tCarrDelay->dwPrmUPDelay != TIME_DLY_INVALID) || (tCarrDelay->dwSecUPDelay != TIME_DLY_INVALID))
        {
            retVal |= IcHalApiSetOptTDDCarrDly(uChan,uCarrNo,uDir,uRadioMode,tCarrDelay->dwPrmUPDelay,tCarrDelay->dwSecUPDelay);
        }
    }

    if (TX == uDir)
    {
        if((tCarrDelay->dwPrmDLDelay != TIME_DLY_INVALID) || (tCarrDelay->dwSecDLDelay != TIME_DLY_INVALID))
        {
            retVal |= IcHalApiSetOptTDDCarrDly(uChan,uCarrNo,uDir,uRadioMode,tCarrDelay->dwPrmDLDelay,tCarrDelay->dwSecDLDelay);
        }
    }

    return retVal;
}


UINT32 BspHalAdaptSetInterFramerDelay(UINT32 radio, UINT32 dlDelay, UINT32 ulDelay)
{
    UINT32 retVal = BSP_OK;
    retVal = IcHalApiSetLNetWkVal(radio,TX,dlDelay);
    retVal |= IcHalApiSetLNetWkVal(radio,RX,ulDelay);
    return retVal;
}
UINT32 BspHalAdaptSetReportT2aDly(UINT32 radio, UINT32 t2aDlyForward, UINT32 t2aDlyReverse)
{
    UINT32 retVal = BSP_OK;
    retVal = IcHalApiSetT2aVal(radio,t2aDlyForward);
    retVal |= IcHalApiSetRptT2aDly(radio,t2aDlyForward);
    return retVal;
}
UINT32 BspHalAdaptSetReportTa3Dly(UINT32 radio, UINT32 ta3DlyForward, UINT32 ta3DlyReverse)
{
    UINT32 retVal = BSP_OK;
    retVal = IcHalApiSetTa3Val(radio,ta3DlyForward);
    retVal |= IcHalApiSetRptTa3Dly(radio,ta3DlyForward);
    return retVal;
}
UINT32 BspHalAdaptSetChipTransmitDly(UINT32 chipTrandly_dl, UINT32 chipTrandly_ul)
ICHAL_ADAPT_FUNC_DEF(SetChipTransmitDly, chipTrandly_dl, chipTrandly_ul)
/*TDD IF1配置数据和帧头提前量的差值*/
/* UINT32 BspHalAdaptSetNrTaDiffDly_TDD(INT32 NrTaDiffDly)                        \
ICHAL_ADAPT_FUNC_DEF(SetNrTaDiffDly_TDD,NrTaDiffDly) */

UINT32 BspHalAdaptGetUeAdvGapVal(UINT32 mode, UINT32 *pUeAdvValNs, UINT32 *pUeGapValNs, UINT32 *pMixModAdvComp)
{
    return IcHalApiGetUeAdvGapVal(mode, pUeAdvValNs, pUeGapValNs, pMixModAdvComp);
}

UINT32 BspHalAdaptSetTddIoUeAdvGapVal(UINT32 ueAdvValNs, UINT32 ueGapValNs, UINT32 mixModAdvComp)
{
    return IcHalApiSetTddIoUeAdvGapVal(ueAdvValNs, ueGapValNs, mixModAdvComp);
}

UINT32 BspHalAdaptGetTddIoUeAdvGapVal(UINT32 *pUeAdvValNs, UINT32 *pUeGapValNs, UINT32 *pMixModAdvComp)
{
    return IcHalApiGetTddIoUeAdvGapVal(pUeAdvValNs, pUeGapValNs, pMixModAdvComp);
}
/*FDD非负荷分担模式  环网正向或非环网主光口 Toffset*/
UINT32 BspHalAdaptGetFddForwardToffset(UINT32 *toffset)
ICHAL_ADAPT_FUNC_DEF(GetFddForwardToffset, toffset)
/*FDD非负荷分担模式 环网反向Toffset*/
UINT32 BspHalAdaptGetFddReverseToffset(UINT32 *toffset)
ICHAL_ADAPT_FUNC_DEF(GetFddReverseToffset, toffset)
/*FDD负荷分担模式 环网正向Toffset,当前实际没有RRU负荷分担加环网的需求，只有多片场景IC芯片存在此种模式，
对于多片场景，目前光口号固定传0即可*/
UINT32 BspHalAdaptGetFddLoadBalanceForwardToffset(UINT32 logicOptNo, UINT32 *toffset)
ICHAL_ADAPT_FUNC_DEF(GetFddLoadBalanceForwardToffset,logicOptNo,toffset)
/*FDD负荷分担模式 环网反向Toffset,当前实际没有RRU负荷分担加环网的需求，只有多片场景IC芯片存在此种模式，
对于多片场景，目前光口号固定传0即可*/
UINT32 BspHalAdaptGetFddLoadBalanceReverseToffset(UINT32 logicOptNo, UINT32 *toffset)
ICHAL_ADAPT_FUNC_DEF(GetFddLoadBalanceReverseToffset,logicOptNo,toffset)
/*FDD负荷分担模式 非环网逻辑上联口Toffset，负荷分担下逻辑光口号如何定义传递，待具体需求时讨论*/
UINT32 BspHalAdaptGetFddLoadBalanceToffset(UINT32 logicOptNo, UINT32 *toffset)
ICHAL_ADAPT_FUNC_DEF(GetFddLoadBalanceToffset,logicOptNo,toffset)
/*TDD非负荷分担模式主光口的Toffset测量*/
UINT32 BspHalAdaptGetTddMasterToffset(UINT32 *toffset)
ICHAL_ADAPT_FUNC_DEF(GetTddMasterToffset,toffset)
/*TDD负荷分担逻辑上联口Toffset测量，负荷分担下逻辑光口号如何定义传递，待具体需求时讨论*/
UINT32 BspHalAdaptGetTddLoadBalanceToffset(UINT32 logicOptNo, UINT32 *toffset)
ICHAL_ADAPT_FUNC_DEF(GetTddLoadBalanceToffset,logicOptNo,toffset)
/*获得toffset配置值*/
UINT32 BspHalAdaptGetCpriFwdToffsetRegVal(UINT32 ulLogOptNo, UINT32 *pulToffset)
ICHAL_ADAPT_FUNC_DEF(GetCpriFwdToffsetRegVal,ulLogOptNo,pulToffset)

/*FDD非负荷分担模式  环网正向Tn测量*/
UINT32 BspHalAdaptGetFddForwardTn(UINT32 *tnVal)
ICHAL_ADAPT_FUNC_DEF(GetFddForwardTn, tnVal)
/*FDD非负荷分担模式 环网反向Tn测量*/
UINT32 BspHalAdaptGetFddReverseTn(UINT32 *tnVal)
ICHAL_ADAPT_FUNC_DEF(GetFddReverseTn, tnVal)
/*FDD非负荷分担模式  非环网Tn测量*/
UINT32 BspHalAdaptGetFddTn(UINT32 *tnVal)
ICHAL_ADAPT_FUNC_DEF(GetFddTn, tnVal)
/*FDD负荷分担模式 环网正向Tn测量,当前实际没有RRU负荷分担加环网的需求，只有多片场景IC芯片存在此种模式，
对于多片场景，目前光口号固定传0即可*/
UINT32 BspHalAdaptGetFddLoadBalanceForwardTn(UINT32 logicOptNo, UINT32 *tnVal)
ICHAL_ADAPT_FUNC_DEF(GetFddLoadBalanceForwardTn,logicOptNo,tnVal)
/*FDD负荷分担模式 环网反向Tn测量,当前实际没有RRU负荷分担加环网的需求，只有多片场景IC芯片存在此种模式，
对于多片场景，目前光口号固定传0即可*/
UINT32 BspHalAdaptGetFddLoadBalanceReverseTn(UINT32 logicOptNo, UINT32 *tnVal)
ICHAL_ADAPT_FUNC_DEF(GetFddLoadBalanceReverseTn,logicOptNo,tnVal)
/*FDD负荷分担模式 非环网逻辑下联口Tn测量，负荷分担下逻辑光口号如何定义传递，待具体需求时讨论*/
UINT32 BspHalAdaptGetFddLoadBalanceTn(UINT32 logicOptNo, UINT32 *tnVal)
ICHAL_ADAPT_FUNC_DEF(GetFddLoadBalanceTn,logicOptNo,tnVal)
/*TDD非负荷分担模式TN测量*/
UINT32 BspHalAdaptGetTddMasterTn(UINT32 *tnVal)
ICHAL_ADAPT_FUNC_DEF(GetTddMasterTn,tnVal)
/*TDD负荷分担模式TN测量，负荷分担下逻辑光口号如何定义传递，待具体需求时讨论*/
UINT32 BspHalAdaptGetTddLoadBalanceTn(UINT32 logicOptNo, UINT32 *tnVal)
ICHAL_ADAPT_FUNC_DEF(GetTddLoadBalanceTn,logicOptNo,tnVal)


/*FDD非负荷分担模式  环网正向Tdl测量*/
UINT32 BspHalAdaptGetFddForwardTdl(UINT32 *tdlVal)
ICHAL_ADAPT_FUNC_DEF(GetFddForwardTdl, tdlVal)
/*FDD非负荷分担模式 环网反向Tdl测量*/
UINT32 BspHalAdaptGetFddReverseTdl(UINT32 *tdlVal)
ICHAL_ADAPT_FUNC_DEF(GetFddReverseTdl, tdlVal)
/*FDD非负荷分担模式  非环网Tdl测量*/
UINT32 BspHalAdaptGetFddTdl(UINT32 *tdlVal)
ICHAL_ADAPT_FUNC_DEF(GetFddTdl, tdlVal)
/*FDD负荷分担模式 环网正向Tdl测量,当前实际没有RRU负荷分担加环网的需求，只有多片场景IC芯片存在此种模式，
对于多片场景，目前光口号固定传0即可*/
UINT32 BspHalAdaptGetFddLoadBalanceForwardTdl(UINT32 logicOptNo, UINT32 *tdlVal)
ICHAL_ADAPT_FUNC_DEF(GetFddLoadBalanceForwardTdl,logicOptNo,tdlVal)
/*FDD负荷分担模式 环网反向Tdl测量,当前实际没有RRU负荷分担加环网的需求，只有多片场景IC芯片存在此种模式，
对于多片场景，目前光口号固定传0即可*/
UINT32 BspHalAdaptGetFddLoadBalanceReverseTdl(UINT32 logicOptNo, UINT32 *tdlVal)
ICHAL_ADAPT_FUNC_DEF(GetFddLoadBalanceReverseTdl,logicOptNo,tdlVal)
/*FDD负荷分担模式 非环网逻辑下联口Tdl测量，负荷分担下逻辑光口号如何定义传递，待具体需求时讨论*/
UINT32 BspHalAdaptGetFddLoadBalanceTdl(UINT32 logicOptNo, UINT32 *tdlVal)
ICHAL_ADAPT_FUNC_DEF(GetFddLoadBalanceTdl,logicOptNo,tdlVal)
/*TDD非负荷分担模式Tdl测量*/
UINT32 BspHalAdaptGetTddMasterTdl(UINT32 *tdlVal)
ICHAL_ADAPT_FUNC_DEF(GetTddMasterTdl,tdlVal)
/*TDD负荷分担模式Tdl测量，负荷分担下逻辑光口号如何定义传递，待具体需求时讨论*/
UINT32 BspHalAdaptGetTddLoadBalanceTdl(UINT32 logicOptNo, UINT32 *tdlVal)
ICHAL_ADAPT_FUNC_DEF(GetTddLoadBalanceTdl,logicOptNo,tdlVal)


/*FDD非负荷分担模式  环网正向Tul测量*/
UINT32 BspHalAdaptGetFddForwardTul(UINT32 *tulVal)
ICHAL_ADAPT_FUNC_DEF(GetFddForwardTul, tulVal)
/*FDD非负荷分担模式 环网反向Tul测量*/
UINT32 BspHalAdaptGetFddReverseTul(UINT32 *tulVal)
ICHAL_ADAPT_FUNC_DEF(GetFddReverseTul, tulVal)
/*FDD非负荷分担模式  非环网Tul测量*/
UINT32 BspHalAdaptGetFddTul(UINT32 *tulVal)
ICHAL_ADAPT_FUNC_DEF(GetFddTul, tulVal)
/*FDD负荷分担模式 环网正向Tul测量,当前实际没有RRU负荷分担加环网的需求，只有多片场景IC芯片存在此种模式，
对于多片场景，目前光口号固定传0即可*/
UINT32 BspHalAdaptGetFddLoadBalanceForwardTul(UINT32 logicOptNo, UINT32 *tulVal)
ICHAL_ADAPT_FUNC_DEF(GetFddLoadBalanceForwardTul,logicOptNo,tulVal)
/*FDD负荷分担模式 环网反向Tul测量,当前实际没有RRU负荷分担加环网的需求，只有多片场景IC芯片存在此种模式，
对于多片场景，目前光口号固定传0即可*/
UINT32 BspHalAdaptGetFddLoadBalanceReverseTul(UINT32 logicOptNo, UINT32 *tulVal)
ICHAL_ADAPT_FUNC_DEF(GetFddLoadBalanceReverseTul,logicOptNo,tulVal)
/*FDD负荷分担模式 非环网逻辑下联口Tul测量，负荷分担下逻辑光口号如何定义传递，待具体需求时讨论*/
UINT32 BspHalAdaptGetFddLoadBalanceTul(UINT32 logicOptNo, UINT32 *tulVal)
ICHAL_ADAPT_FUNC_DEF(GetFddLoadBalanceTul,logicOptNo,tulVal)
/*TDD非负荷分担模式Tul测量*/
UINT32 BspHalAdaptGetTddMasterTul(UINT32 *tulVal)
ICHAL_ADAPT_FUNC_DEF(GetTddMasterTul,tulVal)
/*TDD负荷分担模式Tul测量,负荷分担下逻辑光口号如何定义传递，待具体需求时讨论*/
UINT32 BspHalAdaptGetTddLoadBalanceTul(UINT32 logicOptNo, UINT32 *tulVal)
ICHAL_ADAPT_FUNC_DEF(GetTddLoadBalanceTul,logicOptNo,tulVal)

/*CPRI Toffset 配置到光口全局变量*/
UINT32 BspHalAdaptCfgCpriFwdToffset(UINT32 logicOptNo, UINT32 toffset)
ICHAL_ADAPT_FUNC_DEF(CfgCpriFwdToffset,logicOptNo,toffset)
/* Toffset配置到寄存器 */
UINT32 BspHalAdaptCpriFwdToffsetRegCfg(UINT32 logicOptNo, UINT32 toffset)
ICHAL_ADAPT_FUNC_DEF(CpriFwdToffsetRegCfg,logicOptNo,toffset)
/*CPRI Toffset 反向配置(环网用),TDD没有目前没有环网需求，具体如何传递光口号，待具体需求时讨论*/
UINT32 BspHalAdaptCfgCpriRvsToffset(UINT32 logicOptNo, UINT32 toffset)
ICHAL_ADAPT_FUNC_DEF(CfgCpriRvsToffset,logicOptNo,toffset)
/* Toffset配置到寄存器 */
UINT32 BspHalAdaptCpriRvsToffsetRegCfg(UINT32 logicOptNo, UINT32 toffset)
ICHAL_ADAPT_FUNC_DEF(CpriRvsToffsetRegCfg,logicOptNo,toffset)

/**************************************************************************
                            增益控制相关接口
**************************************************************************/
/* 下行dlpre增益系数配置，位于TDM通道，用于对所有载波进行降额以规避成型溢出问题 */
UINT32 BspHalAdaptSetDlpreGain(UINT32 difChan, UINT32 carrIndex, UINT32 radioMode, INT32 gain)
{
    UINT32 retVal = BSP_OK;

    if(gain == GAIN_INVALID) 
    {
        /*如果增益为无效值，则将 dlpre 增益关断*/
        retVal = IcHalApiSetDlpreTdmGainCut(difChan, carrIndex, radioMode);
    }
    else
    {
        retVal =  IcHalApiSetDlpreGain(difChan, carrIndex, radioMode, gain);
    }

    return retVal;
}

/* 下行dlpre模块tdm通道增益数据关断-寄存器写0 */
UINT32 BspHalAdaptSetDlpreTdmGainCut(UINT32 difChan, UINT32 carrIndex, UINT32 radioMode)
{
    UINT32 retVal = BSP_OK;

    retVal =  IcHalApiSetDlpreTdmGainCut(difChan, carrIndex, radioMode);

    return retVal;
}

/* 下行dlbank模块ap_tune增益系数配置 */
UINT32 BspHalAdaptSetDlbankAptune(UINT32 difChan, UINT32 carrIndex, UINT32 radioMode, INT32 gain)
{
    UINT32 retVal = BSP_OK;

    retVal =  IcHalApiSetDlbankAptune(difChan, carrIndex, radioMode, gain);

    return retVal;
}         

/* 下行dlbank模块dgain增益系数配置，分载波增调整 */
UINT32 BspHalAdaptSetDlbankDgain(UINT32 difChan, UINT32 carrIndex, UINT32 radioMode, INT32 gain)
{
    UINT32 retVal = BSP_OK;

    if(gain == GAIN_INVALID) /*GAIN_INVALID*/
    {
        /*如果增益为无效值，则将增益清0*/
        retVal =  IcHalApiSetDlbankDgainRegWrZero(difChan, carrIndex, radioMode);
    }
    else
    {
        retVal =  IcHalApiSetDlbankDgain(difChan, carrIndex, radioMode, gain);
    }

    return retVal;
}

/* Started by AICoder, pid:72d739fa26mcad9147eb0bed80a5900698b40e1e */
UINT32 BspHalAdaptSetDlpreTdmGain(UINT32 uiDifChan, INT32 iGain)
{
    UINT32 retVal = BSP_OK;
    retVal =  IcHalApiSetDlpreTdmGain(uiDifChan,iGain);  
    return retVal;
}
/* Ended by AICoder, pid:72d739fa26mcad9147eb0bed80a5900698b40e1e */

/** 获取下行dlpre分载波增益 */
UINT32 BspHalAdaptGetDlpreGain(UINT32 difChan, UINT32 carrIndex, UINT32 radioMode, INT32 *pGain)
{
    UINT32 retVal = BSP_OK;

    INPUT_POINTER_CHECK(pGain);
    retVal =  IcHalApiGetDlpreGain(difChan, carrIndex, radioMode, pGain);

    return retVal;
}

/** 获取下行dlbank模块ap_tune分载波增益 */
UINT32 BspHalAdaptGetDlbankAptune(UINT32 difChan, UINT32 carrIndex, UINT32 radioMode, INT32 *pGain)
{
    UINT32 retVal = BSP_OK;

    INPUT_POINTER_CHECK(pGain);
    retVal =  IcHalApiGetDlbankAptune(difChan, carrIndex, radioMode, pGain);

    return retVal;
}

/** 获取下行dlbank模块dgain分载波增益 */
UINT32 BspHalAdaptGetDlbankDgain(UINT32 difChan, UINT32 carrIndex, UINT32 radioMode, INT32 *pGain)
{
    UINT32 retVal = BSP_OK;
    UINT32 dlBankDgainReg = GAIN_INVALID;

    INPUT_POINTER_CHECK(pGain);
    retVal =  IcHalApiGetDlbankDgainRegWrZero(difChan, carrIndex, radioMode, &dlBankDgainReg); 
    if(dlBankDgainReg == 0)
    {
        *pGain = GAIN_INVALID;
        return retVal;
    }
    retVal =  IcHalApiGetDlbankDgain(difChan, carrIndex, radioMode, pGain);

    return retVal;
}

/** 设置下行载波增益开关。数据状态（sw） 1：打开 0：关断 */
UINT32 BspHalAdaptSetDlCarrGainSw(UINT32 difChan, UINT32 radioMode, UINT32 carrIndex, INT32 sw)
{
    UINT32 retVal = BSP_OK;

    retVal =  IcHalApiDlbankDgainDataEn(difChan, carrIndex, radioMode, sw);

    return retVal;
}

/** 设置上行载波增益开关。数据状态（sw） 1：打开 0：关断 */
UINT32 BspHalAdaptSetUlCarrGainSw(UINT32 difChan, UINT32 radioMode, UINT32 carrIndex, INT32 sw)
{
    UINT32 retVal = BSP_OK;

    retVal =  IcHalApiUlbankAptuneDataEn(difChan, carrIndex, radioMode, sw);

    return retVal;
}

/** 获取下行载波增益开关状态。数据状态（*pSw） 1：打开 0：关断 */
UINT32 BspHalAdaptGetDlCarrGainSw(UINT32 difChan, UINT32 radioMode, UINT32 carrIndex, INT32 *pSw)
{
    UINT32 retVal = BSP_OK;

    INPUT_POINTER_CHECK(pSw);
    retVal =  IcHalApiDlbankDgainDataEnStatus(difChan, carrIndex, radioMode, (UINT32 *)pSw);

    return retVal;
}

UINT32 BspHalAdaptGetDlPerCarrGainSw(UINT32 difChan, UINT32 radioMode, UINT32 carrIndex, INT32 *pSw)
{
    UINT32 retVal = BSP_OK;

    INPUT_POINTER_CHECK(pSw);
    retVal =  IcHalApiGetDlpreGainDataEnStatus(difChan, carrIndex, radioMode, (UINT32 *)pSw);

    return retVal;
}

UINT32 BspHalAdaptGetDlBankAptuneCarrGainSw(UINT32 difChan, UINT32 radioMode, UINT32 carrIndex, INT32 *pSw)
{
    UINT32 retVal = BSP_OK;

    INPUT_POINTER_CHECK(pSw);
    retVal =  IcHalApiGetDlbankAptuneDataEnStatus(difChan, carrIndex, radioMode, (UINT32 *)pSw);

    return retVal;
}

/** 获取上行载波增益开关状态。数据状态（*pSw） 1：打开 0：关断 */
UINT32 BspHalAdaptGetUlCarrGainSw(UINT32 difChan, UINT32 radioMode, UINT32 carrIndex, INT32 *pSw)
{
    UINT32 retVal = BSP_OK;

    INPUT_POINTER_CHECK(pSw);
    retVal =  IcHalApiGetUlbankAptuneDataEnStatus(difChan, carrIndex, radioMode, (UINT32 *)pSw);

    return retVal;
}

/** CFR 入口K0增益设置 */
UINT32 BspHalAdaptSetK0Gain(UINT32 uiDifChan, INT32 uiGain)
{
    UINT32 retVal = BSP_OK;

    retVal =  IcHalApiSetDlcfrK0(uiDifChan, uiGain);

    return retVal;
}

/** 获取 CFR 入口K0增益 */
UINT32 BspHalAdaptGetK0Gain(UINT32 uiDifChan, INT32 *puiGain)
{
    UINT32 retVal = BSP_OK;

    INPUT_POINTER_CHECK(puiGain);
    retVal =  IcHalApiGetDlcfrK0(uiDifChan, puiGain);

    return retVal;
}

/** 异厂家 CFR 入口K0增益设置 */
UINT32 BspHalAdaptSetK0GainDiff(UINT32 difChan, INT32 gain)
{
    UINT32 retVal = BSP_OK;

    retVal =  IcHalApiSetDlcfrK0Diff(difChan, gain);

    return retVal;
}

/** 获取异厂家 CFR 入口K0增益 */
UINT32 BspHalAdaptGetK0GainDiff(UINT32 difChan, INT32 *pGain)
{
    UINT32 retVal = BSP_OK;

    INPUT_POINTER_CHECK(pGain);
    retVal =  IcHalApiGetDlcfrK0Diff(difChan, pGain);

    return retVal;
}

/** 设置 DPD 入口增益 */
UINT32 BspHalAdaptSetK1Gain(UINT32 uiDifChan, INT32 uiGain)
{
    UINT32 retVal = BSP_OK;

    retVal =  IcHalApiSetDlcfrGain2(uiDifChan, uiGain);

    return retVal;
}

/** 获取 DPD 入口增益 */
UINT32 BspHalAdaptGetK1Gain(UINT32 uiDifChan, INT32 *puiGain)
{
    UINT32 retVal = BSP_OK;

    INPUT_POINTER_CHECK(puiGain);
    retVal =  IcHalApiGetDlcfrGain2(uiDifChan, puiGain);

    return retVal;
}

/** 设置合载波闭环功控数字域增益值 */
UINT32 BspHalAdaptSetK2Gain(UINT32 uiDifChan, INT32 uiGain)
{
    UINT32 retVal = BSP_OK;

    retVal =  IcHalApiSetDlpostGain4(uiDifChan, uiGain);

    return retVal;
}

/** 获取合载波闭环功控数字域增益值 */
UINT32 BspHalAdaptGetK2Gain(UINT32 uiDifChan, INT32 *puiGain)
{
    UINT32 retVal = BSP_OK;

    INPUT_POINTER_CHECK(puiGain);
    retVal =  IcHalApiGetDlpostGain4(uiDifChan, puiGain);

    return retVal;
}

/** 设置上行ulbank模块ap_tune增益值 */
UINT32 BspHalAdaptSetUlbankAptune(UINT32 difChan, UINT32 carrIndex, UINT32 radioMode, INT32 gain)
{
    UINT32 retVal = BSP_OK;

    retVal =  IcHalApiSetUlbankAptune(difChan, carrIndex, radioMode, gain);

    return retVal;
}         

/** 获取上行ulbank模块ap_tune增益值 */
UINT32 BspHalAdaptGetUlbankAptune(UINT32 difChan, UINT32 carrIndex, UINT32 radioMode, INT32 *pGain)
{
    UINT32 retVal = BSP_OK;

    INPUT_POINTER_CHECK(pGain);
    retVal =  IcHalApiGetUlbankAptune(difChan, carrIndex, radioMode, pGain);

    return retVal;
}

/** 下行dlpre模块载波到频段的路由1级增益配置API接口 */
UINT32 BspHalAdaptSetDlpreBbtssiGain(UINT32 difChan, UINT32 carrIndex, UINT32 radioMode, INT32 gain)
{
    UINT32 retVal = BSP_OK;
    if(gain == GAIN_INVALID) /*GAIN_INVALID*/
    {
        /*如果增益为无效值，则将增益清0*/
        /* retVal =  IcHalApiClrDlpreBbtssiGain(difChan, carrIndex, radioMode); */
    }
    else
    {
        retVal =  IcHalApiSetDlpreBbtssiGain(difChan, carrIndex, radioMode, gain);
    }
    
    

    return retVal;
}

/* Started by AICoder, pid:j3322i2e296fff714e5f0adf70458f119610ba4e */
UINT32 BspHalAdaptGetDlcfrDerate(UINT32 difChan, INT32* pGain)
{
    INPUT_POINTER_CHECK(pGain);

    return IcHalApiGetDlcfrDerate(difChan, pGain);
}
/* Ended by AICoder, pid:j3322i2e296fff714e5f0adf70458f119610ba4e */

UINT32 BspHalAdaptSetRxVgaGain(UINT32 difChan, UINT32 radioMode, UINT32 carrIndex, INT32 preAtt)                   \
ICHAL_ADAPT_FUNC_DEF(SetRxVgaGain,difChan,radioMode,carrIndex,preAtt)
UINT32 BspHalAdaptGetRxVgaGain(UINT32 difChan, UINT32 radioMode, UINT32 carrIndex, INT32 *preAtt)                  \
ICHAL_ADAPT_FUNC_DEF(GetRxVgaGain,difChan,radioMode,carrIndex,preAtt)
UINT32 BspHalAdaptSetRxPcGain(UINT32 difChan, UINT32 radioMode, UINT32 carrIndex, INT32 preAtt)                    \
ICHAL_ADAPT_FUNC_DEF(SetRxPcGain,difChan,radioMode,carrIndex,preAtt)
UINT32 BspHalAdaptGetRxPcGain(UINT32 difChan, UINT32 radioMode, UINT32 carrIndex, INT32 *preAtt)                   \
ICHAL_ADAPT_FUNC_DEF(GetRxPcGain,difChan,radioMode,carrIndex,preAtt)
UINT32 BspHalAdaptSetTxUmtsAgcCfg(UINT32 uiDifChan, UINT32 uiCarrId, UINT32 uiRadioMode, T_BspHalAdaptUmtsTxAgcCfg *ptTxAgcCfg)
ICHAL_ADAPT_FUNC_DEF(SetTxUmtsAgcCfg, uiDifChan, uiCarrId, uiRadioMode, ptTxAgcCfg)
UINT32 BspHalAdaptSetUmtsDagcInit(T_UmtsDagcInfo *ptUmtsDagcInfo)
ICHAL_ADAPT_FUNC_DEF(SetUmtsDagcInit, ptUmtsDagcInfo)
UINT32 BspHalAdaptSetDlbankAptuneWithPhase(UINT32 uiDifChan, UINT32 uiCarrId, UINT32 uiRadioMode, INT32 iRealCoef, INT32 iImagCoef)     \
ICHAL_ADAPT_FUNC_DEF(SetDlbankAptuneWithPhase,uiDifChan,uiCarrId,uiRadioMode,iRealCoef,iImagCoef)

UINT32 BspHalAdaptGetUlbankAptuneCoef(UINT32 difChan, UINT32 difCarrNo, UINT32 radioMode, UINT32 *pCoef)
{
    UINT32 retVal = BSP_OK;

    INPUT_POINTER_CHECK(pCoef);
    retVal =  IcHalApiGetUlbankAptuneCoef(difChan, difCarrNo, radioMode, pCoef);

    return retVal;
}

UINT32 BspHalAdaptSetUlbankAptuneCoef(UINT32 difChan, UINT32 difCarrNo, UINT32 radioMode, UINT32 coef)
{
    UINT32 retVal = BSP_OK;

    retVal =  IcHalApiSetUlbankAptuneCoef(difChan, difCarrNo, radioMode, coef);

    return retVal;
}

UINT32 BspHalAdaptSetSampleUlChTimes(UINT32 sampleTimes)
{
    return IcHalApiSampleUlChTimes(sampleTimes);
}

UINT32 BspHalAdaptSampleDlCfr1(UINT32 uiDifChan, UINT32 uiPosSel)
{
    return HalSampleDlCfr1(uiDifChan, uiPosSel);
}

/**************************************************************************
                            AGC 与 MGC 控制相关接口
**************************************************************************/

/** AGC初始化配置接口 */
UINT32 BspHalAdaptInitVgaAgc(T_BspHalAdaptVgaCtrlComPara *pVgaCtrlPara, T_BspHalAdaptVgaCompPara *pVgaCompPara)
{
    UINT32 retVal = BSP_OK;

    INPUT_POINTER_CHECK(pVgaCtrlPara);
    INPUT_POINTER_CHECK(pVgaCompPara);
    retVal =  IcHalApiInitVgaAgc(pVgaCtrlPara, pVgaCompPara);

    return retVal;
}

/** MGC 204 cmd初始化配置接口 */
UINT32 BspHalAdaptInitVgaJ204CmdPara(T_BspHalAdaptVgaJ204CmdPara *pVgaJ204CmdPara)
{
    UINT32 retVal = BSP_OK;

    INPUT_POINTER_CHECK(pVgaJ204CmdPara);
    retVal =  IcHalApiSetVgaJ204CmdPara(pVgaJ204CmdPara);

    return retVal;
}

/** MGC初始化配置接口 */
UINT32 BspHalAdaptInitVgaMgc(T_BspHalAdaptVgaCtrlComPara *pVgaCtrlPara, T_BspHalAdaptVgaCtrlMgcPara *pVgaCtrlMgcPara, T_BspHalAdaptVgaCompPara *pVgaCompPara)
{
    UINT32 retVal = BSP_OK;

    INPUT_POINTER_CHECK(pVgaCtrlPara);
    INPUT_POINTER_CHECK(pVgaCtrlMgcPara);
    INPUT_POINTER_CHECK(pVgaCompPara);
    retVal =  IcHalApiInitVgaMgc(pVgaCtrlPara, pVgaCtrlMgcPara, pVgaCompPara);

    return retVal;
}

/**
 ******************************************************************************
 * @name        BspHalAdaptInitQcellVgaCompPara
 * @brief       Qcell反补参数初始化配置接口
 * @param[in]   T_QcellCompPara *pQcellCompPara
 * @return      BSP_OK/BSP_ERROR
 * @author
 * @date
 ******************************************************************************
*/
UINT32 BspHalAdaptInitQcellVgaCompPara(T_BspHalAdaptQcellCompPara *pQcellCompPara)
{
    UINT32 retVal = BSP_OK;
    INPUT_POINTER_CHECK(pQcellCompPara);
    retVal = IcHalApiInitQcellVgaCompPara(pQcellCompPara);
    return retVal;
}

/**
 ******************************************************************************
 * @name        BspHalAdaptInitMtsBusCfg
 * @brief       MTS_BUS传输slicer或ad快检标志配置接口
 * @param[in]   UINT32 uiMtsBusIdx 0~1
 * @param[in]   T_BspHalAdaptMtsBusCfgPara pMtsBusCfgPara
 * @return      BSP_OK/BSP_ERROR
 ******************************************************************************
*/
UINT32 BspHalAdaptInitMtsBusCfg(UINT32 uiBusIdx,T_BspHalAdaptMtsBusCfgPara *pMtsBusCfgPara)
{
    UINT32 retVal = BSP_OK;
    INPUT_POINTER_CHECK(pMtsBusCfgPara);
    retVal =  IcHalApiInitMtsBusCfg(uiBusIdx,pMtsBusCfgPara);
    return retVal;
}

/**
 ******************************************************************************
 * @name        BspHalAdaptSetMtsBusRoute
 * @brief       MTS_BUS传输slicer或ad快检标志配置接口
 * @param[in]   UINT32 uiDifChan 0~7
 * @param[in]   UINT32 uiMtsBusIdx 0~1
 * @param[in]   UINT32 uiMtsRx 0~7
 ******************************************************************************
*/
UINT32 BspHalAdaptSetMtsBusRoute(UINT32 uiDifChan, UINT32 uiMtsBusIdx, UINT32 uiMtsRx)
{
    UINT32 retVal = BSP_OK;
    retVal = IcHalApiSetMtsBusRoute(uiDifChan,uiMtsBusIdx,uiMtsRx);
    return retVal;
}

/* VGA slicer->dB单位转换表配置 */
UINT32 BspHalAdaptSetVgaTransDbLut(UINT32 blockId, UINT32* vgaLutTab)
{
    UINT32 retVal = BSP_OK;

    INPUT_POINTER_CHECK(vgaLutTab);
    retVal = IcHalApiSetVgaTransDbLut(vgaLutTab);

    return retVal;
}

/* VGA补偿增益一次性配置接口 */
UINT32 BspHalAdaptSetAllRxVgaGain(INT32 gain)
{
    UINT32 retVal = BSP_OK;

    retVal = IcHalApiSetAllRxVgaGain(gain);

    return retVal;
}

/* VGA补偿增益配置接口 */
/* UINT32 BspHalAdaptSetRxVgaGain(UINT32 difChan, UINT32 radioMode, UINT32 carrIndex, INT32 preAtt) 
{
    UINT32 retVal = BSP_OK;

    retVal = IcHalApiSetRxVgaGain(difChan,radioMode,carrIndex,preAtt);

    return retVal;
} */

/* VGA补偿增益获取接口 */
/* UINT32 BspHalAdaptGetRxVgaGain(UINT32 difChan, UINT32 radioMode, UINT32 carrIndex, INT32 *preAtt)
{
    UINT32 retVal = BSP_OK;

    INPUT_POINTER_CHECK(preAtt);
    retVal = IcHalApiGetRxVgaGain(difChan,radioMode,carrIndex,preAtt);

    return retVal;
} */


/* 上行链路增益配置接口 */
UINT32 BspHalAdaptSetRxVgaInherentGain(UINT32 difChan, UINT32 radioMode, UINT32 carrIndex, INT32 preAtt)
{
    UINT32 retVal = BSP_OK;

    retVal = IcHalApiSetVgaInherentGain(difChan,radioMode,carrIndex,preAtt);

    return retVal;
}
/* 上行分载波增益一次性配置接口 */
UINT32 BspHalAdaptSetAllRxPcGain(INT32 preAtt) 
{
    UINT32 retVal = BSP_OK;

    retVal = IcHalApiSetAllRxPcGain(preAtt);

    return retVal;
}

/* QCELL上行定标增益接口：目前只有U制式使用 */
UINT32 BspHalAdaptSetRfGain(UINT32 uiRadioMode,INT32 iRfGain)
{
    UINT32 retVal = BSP_OK;

    retVal = IcHalApiSetRfGain(uiRadioMode, iRfGain);

    return retVal;
}

UINT32 BspHalAdaptSetInherentGain(UINT32 uiDifChan, UINT32 uiRadioMode, UINT32 uiCarrNo, INT32 iPreAtt)
{
    UINT32 retVal = BSP_OK;
    retVal =  IcHalApiSetInherentGain(uiDifChan,uiRadioMode,uiCarrNo,iPreAtt);
    return retVal;
}
/* VGA模式配置接口 */
UINT32 BspHalAdaptSetVgaMode(UINT32 mode) 
{
    UINT32 retVal = BSP_OK;

    retVal = IcHalApiSetVgaMode(mode);

    return retVal;
}

/* VGA模式配置接口 */
UINT32 BspHalAdaptSetVgaModeByChan(UINT32 difChan, UINT32 mode)
{
    UINT32 retVal = BSP_OK;

    retVal = IcHalApiSetChVgaMode(difChan,mode);

    return retVal;
}

/* VGA ad_info->dB衰减量单位转换表配置 */
UINT32 BspHalAdaptSetVgaAcInfoDbLut(UINT32 *vgaLutTab)
{
    UINT32 retVal = BSP_OK;

    INPUT_POINTER_CHECK(vgaLutTab);
    retVal = IcHalApiSetVgaAcInfoDbLut(vgaLutTab);

    return retVal;
}

/* 给AC的VGA延迟上报接口 */
UINT32 BspHalAdaptGetVgaCompDlyToAC(UINT32 difChan, UINT32 carrIndex, UINT32 radioMode, UINT32 posId, UINT32 *dlyClk)
{
    UINT32 retVal = BSP_OK;

    INPUT_POINTER_CHECK(dlyClk);
    retVal = IcHalApiGetVgaCompDlyToAC(difChan, carrIndex, radioMode, posId, dlyClk);

    return retVal;
}

/* 射频rfbus总线真值表配置 */
UINT32 BspHalAdaptSetRfBusRealValTab(UINT32 rfIdx, UINT32 *valTab, UINT32 lenTbl)
{
    UINT32 retVal = BSP_OK;

    INPUT_POINTER_CHECK(valTab);
    retVal = IcHalApiSetRfBusRealValTab(rfIdx, valTab, lenTbl);

    return retVal;
}

/* 中频ifbus真值表配置 */
UINT32 BspHalAdaptSetIfBusRealValTab(UINT32 ifIdx, UINT32 *valTab, UINT32 lenTbl)
{
    UINT32 retVal = BSP_OK;

    INPUT_POINTER_CHECK(valTab);
    retVal = IcHalApiSetIfBusRealValTab(ifIdx, valTab, lenTbl);

    return retVal;
}

/* 配置vga策略表 */
UINT32 BspHalAdaptSetVgaMgcSheets(UINT32 difChan, UINT32 *sheetTbl, UINT32 lenTbl)
{
    UINT32 retVal = BSP_OK;

    INPUT_POINTER_CHECK(sheetTbl);
    retVal = IcHalApiSetVgaMgcSheet(difChan, sheetTbl, lenTbl);

    return retVal;
}

/* 配置手动模式att衰减量 */
UINT32 BspHalAdaptSetManualAtt(UINT32 difChan, UINT32 attVal) 
{
    UINT32 retVal = BSP_OK;

    retVal = IcHalApiSetManualAtt(difChan, attVal);

    return retVal;
}

/* 配置手动模式vga衰减量 */
UINT32 BspHalAdaptSetManualVga(UINT32 difChan, UINT32 vgaVal) 
{
    UINT32 retVal = BSP_OK;

    retVal = IcHalApiSetManualVga(difChan, vgaVal);

    return retVal;
}

/* 中频ifbus初始化配置 */
UINT32 BspHalAdaptInitIfBusPara(UINT32 ifIdx, T_BspHalAdaptIfBusPara *ifBusPara)
{
    UINT32 retVal = BSP_OK;

    INPUT_POINTER_CHECK(ifBusPara);
    retVal = IcHalApiInitIfBusPara(ifIdx, ifBusPara);

    return retVal;
}

/* 射频rfbus初始化配置 */
UINT32 BspHalAdaptInitRfBusPara(UINT32 rfIdx, UINT32 rateSel) 
{
    UINT32 retVal = BSP_OK;

    retVal = IcHalApiInitRfBusPara(rfIdx, rateSel);

    return retVal;
}

/* 时间片配置 */
UINT32 BspHalAdaptSetIfRfSendTimeFlagCfg(T_BspHalAdaptTimeCfgPara *timeCfgPara)
{
    UINT32 retVal = BSP_OK;

    INPUT_POINTER_CHECK(timeCfgPara);
    retVal = IcHalApiSetIfRfSendTimeFlagCfg(timeCfgPara);

    return retVal;
}

/* 中频ifbus路由配置（类spi模式） */
UINT32 BspHalAdaptSetIfBusRoute(UINT32 rfIdx, UINT32 difChan, UINT32 mtsRx) 
{
    UINT32 retVal = BSP_OK;

    retVal = IcHalApiSetIfBusRoute(rfIdx, difChan, mtsRx);

    return retVal;
}

/* 射频rfbus路由配置（类spi模式） */
UINT32 BspHalAdaptSetRfBusRoute(UINT32 rfIdx, UINT32 difChan, UINT32 vgaCh) 
{
    UINT32 retVal = BSP_OK;

    retVal = IcHalApiSetRfBusRoute(rfIdx, difChan, vgaCh);

    return retVal;
}

/* 中频ifbus器件配置（spi2模式） */
UINT32 BspHalAdaptSetIfBusAddr(UINT32 rfIdx, UINT32 difChan, UINT32 addr) 
{
    UINT32 retVal = BSP_OK;

    retVal = IcHalApiSetIfBusAddr(rfIdx, difChan, addr);

    return retVal;
}

/* 射频rfbus器件配置（spi2模式） */
UINT32 BspHalAdaptSetRfBusAddr(UINT32 rfIdx, UINT32 difChan, UINT32 addr) 
{
    UINT32 retVal = BSP_OK;

    retVal = IcHalApiSetRfBusAddr(rfIdx, difChan, addr);

    return retVal;
}

/* OE 使能接口，0:input，1:output*/
UINT32 BspHalAdaptInitVgaOeInput(UINT32 oE) 
{
    UINT32 retVal = BSP_OK;

    retVal = IcHalApiInitVgaOeInput(oE);

    return retVal;
}


/* OE VGA bus 初始化*/
UINT32 BspHalAdaptInitVgaBusPara(void)
{
    UINT32 retVal = BSP_OK;

    retVal = IcHalApiInitVgaBusPara();

    return retVal;
}

/**************************************************************************
                  REV功率回退开始
**************************************************************************/
UINT32 BspSetRevInit(UINT32 uiDifChan, T_RevInfoCfg *pRevCfg)
ICHAL_ADAPT_FUNC_DEF(SetRevInit, uiDifChan, pRevCfg)

UINT32 BspRevAlarmClr(UINT32 uiDifChan)
ICHAL_ADAPT_FUNC_DEF(RevWarnClr, uiDifChan)

UINT32 BspRevAlarmStaRpt(UINT32 uiDifChan, UINT32 *almSta)
ICHAL_ADAPT_FUNC_DEF(RevWarnStaRpt, uiDifChan, almSta)

UINT32 BspGetRevAlarmThr(UINT32 uiDifChan, INT32 *uiFbThr)
ICHAL_ADAPT_FUNC_DEF(GetRevWarnThr, uiDifChan, uiFbThr)

UINT32 BspSetRevWarnThr(UINT32 uiDifChan, INT32 uiFbThr)
ICHAL_ADAPT_FUNC_DEF(SetRevWarnThr, uiDifChan, uiFbThr)

UINT32 BspGetRevEnSta(UINT32 uiDifChan, UINT32 *puiEn)
ICHAL_ADAPT_FUNC_DEF(GetRevEnSta, uiDifChan, puiEn)

UINT32 BspGetRevPowerRpt(UINT32 uiDifChan, DOUBLE *pVal)
ICHAL_ADAPT_FUNC_DEF(RevCoefValRpt, uiDifChan, pVal)

/**************************************************************************
                  REV功率回退
**************************************************************************/

/**************************************************************************
                  pad模块相关接口
**************************************************************************/
/*配置1.8V/3.3V管脚复用，按照属性配置接口*/
UINT32 BspSetPadSt(UINT32 padName, UINT32 value)
ICHAL_ADAPT_FUNC_DEF(SetPadSt,padName,value)
UINT32 BspSetPadSl(UINT32 padName, UINT32 value)
ICHAL_ADAPT_FUNC_DEF(SetPadSl,padName,value)
UINT32 BspSetPadPull(UINT32 padName, UINT32 value)
ICHAL_ADAPT_FUNC_DEF(SetPadPull,padName,value)
UINT32 BspSetPadDs(UINT32 padName, UINT32 value)
ICHAL_ADAPT_FUNC_DEF(SetPadDs,padName,value)
UINT32 BspSetPadCfgDone(UINT32 padName, UINT32 value)
ICHAL_ADAPT_FUNC_DEF(SetPadCfgDone,padName,value)
UINT32 BspSetPadFuncSel(UINT32 padName, UINT32 value)
ICHAL_ADAPT_FUNC_DEF(SetPadFuncSel,padName,value)

/*差分管脚帧头选择和功能复用配置接口*/
UINT32 BspSetPadLvdsFrameHead(UINT32 padName, UINT32 value)
ICHAL_ADAPT_FUNC_DEF(SetLvdsFrameHead,padName,value)
UINT32 BspSetPadLvdsFuncSel(UINT32 padName, UINT32 value)
ICHAL_ADAPT_FUNC_DEF(SetLvdsFuncSel,padName,value)

/*获取/配置 1.8V/3.3V管脚整个寄存器的值，主要用于维测*/
UINT32 BspHalSetPadReg(UINT32 padName, UINT32 value)
ICHAL_ADAPT_FUNC_DEF(SetPadReg,padName,value)
UINT32 BspHalGetPadReg(UINT32 padName, UINT32 *value)
ICHAL_ADAPT_FUNC_DEF(GetPadReg,padName,value)

/*获取/配置 差分管脚差分相关功能整个寄存器的值
 * 注：每个差分管脚对应两个寄存器，[reg0]用于配置差分相关功能，不需要软件配置，主要用于维测*/
UINT32 BspHalSetLvdsCfg(UINT32 padName, UINT32 value)
ICHAL_ADAPT_FUNC_DEF(SetLvdsCfg,padName,value)
UINT32 BspHalGetLvdsCfgVal(UINT32 padName, UINT32  *value)
ICHAL_ADAPT_FUNC_DEF(GetLvdsCfgVal,padName,value)

/*获取/配置 差分管脚帧头复用功能整个寄存器的值
 * 每个差分管脚对应两个寄存器，[reg1]用于配置差分帧头和功能复用，主要用于维测*/
UINT32 BspHalSetLvdsPad(UINT32 padName, UINT32 value)
ICHAL_ADAPT_FUNC_DEF(SetLvdsPad,padName,value)
UINT32 BspHalGetLvdsPadVal(UINT32 padName, UINT32 * value)
ICHAL_ADAPT_FUNC_DEF(GetLvdsPadVal,padName,value)
/**************************************************************************
                  配频模块相关接口开始
**************************************************************************/
static pthread_rwlock_t s_DifInfoUpdateWrSem = PTHREAD_RWLOCK_INITIALIZER;
static T_BspAdaptOneChanCarrInfo **s_BspHalAdaptDifCarrInfo = NULL;

UINT32 BspHalAdaptSetTxCarrNco(UINT32 difChan, UINT32 radioMode, UINT32 difCarrNo, INT32 offset)
ICHAL_ADAPT_FUNC_DEF(SetTxCarrNco,difChan,difCarrNo,radioMode,offset)
UINT32 BspHalAdaptSetGsmCenterFreq(UINT32 difChan, UINT32 radioMode, UINT32 difCarrNo, INT32 uiFreq)
ICHAL_ADAPT_FUNC_DEF(SetGsmCenterFreq,difChan,difCarrNo,radioMode,uiFreq)
UINT32 BspHalAdaptSetRxCarrNco(UINT32 difChan, UINT32 radioMode, UINT32 difCarrNo, INT32 offset)
ICHAL_ADAPT_FUNC_DEF(SetRxCarrNco,difChan,difCarrNo,radioMode,offset)
UINT32 BspHalAdaptSetTxFreqNco(UINT32 difChan, UINT32 difFreqId, INT32 offset)
ICHAL_ADAPT_FUNC_DEF(SetTxFreqNco,difChan,difFreqId, offset)
UINT32 BspHalAdaptSetTxFreqNco2(UINT32 difChan, UINT32 bandNo, INT32 offset)
ICHAL_ADAPT_FUNC_DEF(SetTxFreqNco2,difChan,bandNo,offset)
UINT32 BspHalAdaptSetRxFreqNco2(UINT32 difChan, UINT32 bandNo, INT32 offset)
ICHAL_ADAPT_FUNC_DEF(SetRxFreqNco2,difChan,bandNo,offset)
UINT32 BspHalAdaptSetAnfCfg(UINT32 difChan, UINT32 uiCarrId, UINT32 uiRadioMode, T_RxAnfCarrCfg *ptAnfCfg)
ICHAL_ADAPT_FUNC_DEF(SetAnfCfg,difChan,uiCarrId,uiRadioMode,ptAnfCfg)
UINT32 BspHalAdaptSetAnfClr()
ICHAL_ADAPT_FUNC_DEF(SetAnfClr)
UINT32 BspHalAdapt60msAlarm(UINT32 uiDifChan, UINT32 uiCarrId, UINT32 uiRadioMode, UINT32 *puiAlarm)
ICHAL_ADAPT_FUNC_DEF(60msAlarm,uiDifChan,uiCarrId,uiRadioMode,puiAlarm)
UINT32 BspHalAdaptGetGsmIqCfgFlag(UINT32 uiDifChan, UINT32 uiCarrId, UINT32 uiCarrRadio, UINT32 *puiIqCfgFlag)
ICHAL_ADAPT_FUNC_DEF(GetGsmIqCfgFlag,uiDifChan,uiCarrId,uiCarrRadio,puiIqCfgFlag)
UINT32 BspHalRxDataOffEn(UINT32 uiDifChan, UINT32 uiCarrId, UINT32 uiRadioMode, UINT32 uiFlag)
ICHAL_ADAPT_FUNC_DEF(RxDataOffEn,uiDifChan,uiCarrId,uiRadioMode,uiFlag)
UINT32 BspHalAdaptGetFftTxAcByAnt(UINT32 uCarrNo, UINT32 uRadioMode,UINT32 uAntMask, UINT32 *pAcVal, UINT32 *pAcNum)
ICHAL_ADAPT_FUNC_DEF(GetFftTxAcByAnt,uCarrNo,uRadioMode,uAntMask,pAcVal,pAcNum)

/* 设置发射链路Guard Band NCO，offset单位：Hz */
UINT32 BspHalAdaptSetTxGuardBandNco(UINT32 difChan, UINT32 carrNo, UINT32 radioMode, INT32 offset)
{
    return IcHalApiSetTxGuardBandNco(difChan, carrNo, radioMode, offset);
}

/* 设置接收链路Guard Band NCO，offset单位：Hz */
UINT32 BspHalAdaptSetRxGuardBandNco(UINT32 difChan, UINT32 carrNo, UINT32 radioMode, INT32 offset)
{
    return IcHalApiSetRxGuardBandNco(difChan, carrNo, radioMode, offset);
}

/* GSM载波NCO来源选择配置, flag:0(软件配置), 1(gsm全路由进来) */
UINT32 BspHalAdaptSetTxGsmNcoSel(UINT32 difChan, UINT32 carrNo, UINT32 radioMode, UINT32 flag)
{
    return IcHalApiSetTxGsmNcoSel(difChan, carrNo, radioMode, flag);
}

UINT32 BspHalAdaptSetTxBankNco(UINT32 difChan, UINT32 difCarrNo, UINT32 radioMode, INT32 offset)
{
    return IcHalApiSetTxBankNco(difChan, difCarrNo, radioMode, offset);
}
UINT32 BspHalAdaptSetRxBankNco(UINT32 difChan, UINT32 difCarrNo, UINT32 radioMode, INT32 offset)
{
    return IcHalApiSetRxBankNco(difChan, difCarrNo, radioMode, offset);
}

/* Started by AICoder, pid:ue6f7b13baz32d1140610a853071b31dafa7431b */
/*设置ulch Dc旁路功能*/
UINT32 BspHalAdaptSetDcBypass(UINT32 uiDifChan, UINT32 uiIsBypass)
{
    return IcHalApiSetDcBypass(uiDifChan, uiIsBypass);
}
/*配置ulch iir滤波器系数*/
UINT32 BspHalAdaptSetDcIirCoef(UINT32 uiDifChan, UINT32 uiIirCoef)
{
    return IcHalApiSetDcIirCoef(uiDifChan, uiIirCoef);
}
/*设置ulch Dc模式*/
UINT32 BspHalAdaptSetDcMode(UINT32 uiDifChan, UINT32 uiDcMode)
{
    return IcHalApiSetDcMode(uiDifChan, uiDcMode);
}
/* Ended by AICoder, pid:ue6f7b13baz32d1140610a853071b31dafa7431b */

/* Started by AICoder, pid:wd78bef580l01ce1487909d0b00be70f4b199743 */
UINT32 BspHalAdaptSetPbOrBbuMode(UINT32 mode)
{
    return IcHalApiSetPbOrBbuMode(mode);
}

VOID BspHalAdaptGfTdmCheckForQcell(VOID)
{
    return IcHalApiGfTdmCheckForQcell();
}
/* Ended by AICoder, pid:wd78bef580l01ce1487909d0b00be70f4b199743 */

UINT32 BspHalAdaptSetDifCarrId(UINT32 dir, UINT32 difChan, UINT32 radioMode, UINT32 carrId, UINT32 difCarrId)
{
    UINT32 retVal = BSP_OK;

    if(dir == TX)
    {
        /* hal层未定义该接口，暂时屏蔽直接返回BSP_OK */
        return BSP_OK;
       /* retVal = IcHalApiSetTxDifCarrId(difChan, radioMode, carrId, difCarrId);*/
    }
    else if(dir == RX)
    {
        /* hal层未定义该接口，暂时屏蔽直接返回BSP_OK */
        return BSP_OK;
        /*retVal = IcHalApiSetRxDifCarrId(difChan, radioMode, carrId, difCarrId);*/
    }
    else
    {
        return BSP_ERROR;
    }
    return retVal;
}

static T_BspAdaptOneChanCarrInfo **BspGetHalAdaptDifCarrInfoMem(void)
{
    if (s_BspHalAdaptDifCarrInfo == NULL)
    {
        UINT32 i = 0;
        size_t mallocLen = sizeof(T_BspAdaptOneChanCarrInfo *) * 3;
        s_BspHalAdaptDifCarrInfo = (T_BspAdaptOneChanCarrInfo **)malloc(mallocLen);
        if (s_BspHalAdaptDifCarrInfo == NULL)
        {
            return NULL;
        }
        zte_memset_s(s_BspHalAdaptDifCarrInfo, mallocLen, 0, mallocLen);
        for (i = 0; i < 3; i++)
        {
            mallocLen = sizeof(T_BspAdaptOneChanCarrInfo) * BSP_HALADAPT_IC_CHAN_MAX_NUM;
            s_BspHalAdaptDifCarrInfo[i] = (T_BspAdaptOneChanCarrInfo *)malloc(mallocLen);
            if (s_BspHalAdaptDifCarrInfo[i] == NULL)
            {
                break;
            }
            zte_memset_s(s_BspHalAdaptDifCarrInfo[i], mallocLen, 0, mallocLen);
        }
        /* 存在局部申请失败的情况,释放所有内存 */
        if (i < 3)
        {
            for (i = 0; i < 3; i++)
            {
                if (s_BspHalAdaptDifCarrInfo[i] != NULL)
                {
                    free(s_BspHalAdaptDifCarrInfo[i]);
                }
            }
            free(s_BspHalAdaptDifCarrInfo);
            s_BspHalAdaptDifCarrInfo = NULL;
            return NULL;
        }
    }
    return s_BspHalAdaptDifCarrInfo;
}

T_BspAdaptOneChanCarrInfo *BspHalAdaptGetDifChanCarrInfo(UINT32 dir, UINT32 difChan)
{
    T_BspAdaptOneChanCarrInfo **bspHalAdaptDifCarrInfo = BspGetHalAdaptDifCarrInfoMem();
    if(dir > PRX || difChan >= BSP_HALADAPT_IC_CHAN_MAX_NUM || bspHalAdaptDifCarrInfo == NULL)
    {
        return NULL;
    }
    if (BSP_OK != pthreadRdSemTake(&s_DifInfoUpdateWrSem))
    {
        return NULL;
    }

    pthreadRdSemGive(&s_DifInfoUpdateWrSem);
    return &(bspHalAdaptDifCarrInfo[dir][difChan]);
}

static VOID BspFillIcHalCarrInfo(T_BspAdaptOneChanCarrInfo *ptSrc, T_DifCarrInfo *ptDest)
{
    UINT32 ulCarrLoop = 0;
    ptDest->uiCarrNum = ptSrc->carrNum;
    dbgInfo("[%s] uiCarrNum = %d\n",__FUNCTION__,ptDest->uiCarrNum);
    for(ulCarrLoop=0; ulCarrLoop<ptSrc->carrNum; ulCarrLoop++)
    {
        ptDest->atCarrInfo[ulCarrLoop].uiCarrId = ptSrc->oneCarrInfo[ulCarrLoop].difCarrNo;
        ptDest->atCarrInfo[ulCarrLoop].uiCarrFreq = ptSrc->oneCarrInfo[ulCarrLoop].carrFreq;
        ptDest->atCarrInfo[ulCarrLoop].uiCarrRadio = ptSrc->oneCarrInfo[ulCarrLoop].carrRadio;
        ptDest->atCarrInfo[ulCarrLoop].uiCarrBw = ptSrc->oneCarrInfo[ulCarrLoop].carrBw;
        ptDest->atCarrInfo[ulCarrLoop].uiIsSsb = ptSrc->oneCarrInfo[ulCarrLoop].isSsb;
        ptDest->atCarrInfo[ulCarrLoop].uiIsRcf = ptSrc->oneCarrInfo[ulCarrLoop].isRcf;
        ptDest->atCarrInfo[ulCarrLoop].uiDelOrAddFlag = ptSrc->oneCarrInfo[ulCarrLoop].delOrAddFlag;
        ptDest->atCarrInfo[ulCarrLoop].uiIsCfir = ptSrc->oneCarrInfo[ulCarrLoop].sideFilterSw;
        ptDest->atCarrInfo[ulCarrLoop].uiCellId = ptSrc->oneCarrInfo[ulCarrLoop].uiCellId;
    }
    return;
}

static VOID BspGetIcHalCarrInfo(T_BspAdaptOneChanCarrInfo *ptSrc, T_DifCarrInfo *ptDest)
{
    UINT32 ulCarrLoop = 0;
    ptSrc->carrNum = ptDest->uiCarrNum;
    dbgInfo("[%s] uiCarrNum = %d\n",__FUNCTION__,ptDest->uiCarrNum);
    for(ulCarrLoop=0; ulCarrLoop<ptDest->uiCarrNum; ulCarrLoop++)
    {
        ptSrc->oneCarrInfo[ulCarrLoop].difCarrNo = ptDest->atCarrInfo[ulCarrLoop].uiCarrId;
        ptSrc->oneCarrInfo[ulCarrLoop].carrFreq = ptDest->atCarrInfo[ulCarrLoop].uiCarrFreq;
        ptSrc->oneCarrInfo[ulCarrLoop].carrRadio = ptDest->atCarrInfo[ulCarrLoop].uiCarrRadio;
        ptSrc->oneCarrInfo[ulCarrLoop].carrBw = ptDest->atCarrInfo[ulCarrLoop].uiCarrBw;
        ptSrc->oneCarrInfo[ulCarrLoop].isSsb = ptDest->atCarrInfo[ulCarrLoop].uiIsSsb;
        ptSrc->oneCarrInfo[ulCarrLoop].isRcf = ptDest->atCarrInfo[ulCarrLoop].uiIsRcf;
        ptSrc->oneCarrInfo[ulCarrLoop].delOrAddFlag = ptDest->atCarrInfo[ulCarrLoop].uiDelOrAddFlag;
    }
    return;
}

/**********************************************************************
* 函数名称: BspHalAdaptTxAnalysis
* 功能描述: 配频模块下行资源预分析
* 输入参数: ptTxCarrInfo 下行所有通道载波信息
* 输出参数: 无
* 返  回  值: BSP_OK/BSP_ERROR
************************************************************************/
UINT32 BspHalAdaptTxAnalysis(T_BspHalAdaptChanInfo *ptTxChanInfo, T_DifChanInfo *ptTxFailChanInfo)
{
    UINT32 retVal     = BSP_OK;
    UINT32 chanLoop   = 0;
    UINT32 txChanNum  = 0;
    UINT32 halDifChan = 0;
    UINT32 carrLoop   = 0;
    T_DifChanInfo *halChanInfo = NULL;
    T_BspAdaptOneChanCarrInfo **bspHalAdaptDifCarrInfo = BspGetHalAdaptDifCarrInfoMem();
    INPUT_POINTER_CHECK(bspHalAdaptDifCarrInfo);
    INPUT_POINTER_CHECK(ptTxChanInfo);

    halChanInfo = (T_DifChanInfo *)malloc(sizeof(T_DifChanInfo));
    INPUT_POINTER_CHECK(halChanInfo);
    zte_memset_s(halChanInfo, sizeof(T_DifChanInfo), 0, sizeof(T_DifChanInfo));
    txChanNum = ptTxChanInfo->chanNum;

    if(BSP_OK != pthreadWrSemTake(&s_DifInfoUpdateWrSem))
    {
        free(halChanInfo);
        dbgErr("%s write sem error!\n", __FUNCTION__);
        return BSP_ERROR;
    }

    for(chanLoop = 0; chanLoop < txChanNum; chanLoop++)
    {
        if(ptTxChanInfo->chanInfo[chanLoop].carrNum > NELEMENTS(ptTxChanInfo->chanInfo[chanLoop].oneCarrInfo))
        {
            free(halChanInfo);
            dbgErr("%s [%d] is more than difhal carr max num[%d] !\n",
                __FUNCTION__, ptTxChanInfo->chanInfo[chanLoop].carrNum, NELEMENTS(ptTxChanInfo->chanInfo[chanLoop].oneCarrInfo));
            pthreadWrSemGive(&s_DifInfoUpdateWrSem);
            return BSP_ERROR;
        }

        halDifChan = ptTxChanInfo->chanInfo[chanLoop].difChanNo;
        dbgInfo("%s line[%d] chanLoop  %d halDifChan %d\n", __FUNCTION__, __LINE__, chanLoop, halDifChan);

        memcpy_s(&(bspHalAdaptDifCarrInfo[TX][halDifChan]), sizeof(T_BspAdaptOneChanCarrInfo),
                &(ptTxChanInfo->chanInfo[chanLoop]), sizeof(T_BspAdaptOneChanCarrInfo));

        BspFillIcHalCarrInfo(&(ptTxChanInfo->chanInfo[chanLoop]), &(halChanInfo->atChanInfo[halDifChan]));
        dbgSaveHalCarrInfo(TX, halDifChan, &(halChanInfo->atChanInfo[halDifChan]));
        if(IS_NCR ==  BspIsNcr())
        {
            for(carrLoop = 0; carrLoop < BSP_DIF_CARR_MAX_NUM * 2; carrLoop++)
            {
                halChanInfo->atChanInfo[halDifChan].atCarrInfo[carrLoop].uiIsRcf = (g_setRcfFlagMask & BIT_SET(halDifChan)) ? 1 : 0;
                dbgInfo("%s line[%d] chanLoop  %d carr %d chanMask 0x%08lX uiIsRcf %d\n", __FUNCTION__, __LINE__, chanLoop, carrLoop,
                        BIT_SET(halDifChan), halChanInfo->atChanInfo[halDifChan].atCarrInfo[carrLoop].uiIsRcf);
            }
        }
    }

    retVal = IcHalApiTxResourceAlloc(halChanInfo, ptTxFailChanInfo);
    free(halChanInfo);
    pthreadWrSemGive(&s_DifInfoUpdateWrSem);
    return retVal;
}

/**********************************************************************
* 函数名称: BspHalAdaptRxAnalysis
* 功能描述: 配频模块上行资源预分析
* 输入参数: ptRxCarrInfo 下行所有通道通道载波信息
* 输出参数: 无
* 返  回  值: BSP_OK/BSP_ERROR
************************************************************************/
UINT32 BspHalAdaptRxAnalysis(T_BspHalAdaptChanInfo *ptRxChanInfo, T_DifChanInfo *ptRxFailChanInfo)
{
    UINT32 retVal     = BSP_OK;
    UINT32 chanLoop   = 0;
    UINT32 rxChanNum  = 0;
    UINT32 halDifChan = 0;
    T_DifChanInfo *halChanInfo = NULL;
    T_BspAdaptOneChanCarrInfo **bspHalAdaptDifCarrInfo = BspGetHalAdaptDifCarrInfoMem();
    INPUT_POINTER_CHECK(bspHalAdaptDifCarrInfo);
    INPUT_POINTER_CHECK(ptRxChanInfo);
    halChanInfo = (T_DifChanInfo *)malloc(sizeof(T_DifChanInfo));
    INPUT_POINTER_CHECK(halChanInfo);
    zte_memset_s(halChanInfo, sizeof(T_DifChanInfo), 0, sizeof(T_DifChanInfo));
    rxChanNum = ptRxChanInfo->chanNum;
    if(BSP_OK != pthreadWrSemTake(&s_DifInfoUpdateWrSem))
    {
        free(halChanInfo);
        dbgErr("%s write sem error!\n", __FUNCTION__);
        return BSP_ERROR;
    }

    for(chanLoop = 0; chanLoop < rxChanNum; chanLoop++)
    {
        if(ptRxChanInfo->chanInfo[chanLoop].carrNum > NELEMENTS(ptRxChanInfo->chanInfo[chanLoop].oneCarrInfo))
        {
            dbgErr("%s [%d] is more than difhal carr max num[%d] !\n",
                __FUNCTION__, ptRxChanInfo->chanInfo[chanLoop].carrNum, NELEMENTS(ptRxChanInfo->chanInfo[chanLoop].oneCarrInfo));
            free(halChanInfo);
            pthreadWrSemGive(&s_DifInfoUpdateWrSem);
            return BSP_ERROR;
        }
        halDifChan = ptRxChanInfo->chanInfo[chanLoop].difChanNo;

        memcpy_s(&(bspHalAdaptDifCarrInfo[RX][halDifChan]), sizeof(T_BspAdaptOneChanCarrInfo),
                &(ptRxChanInfo->chanInfo[chanLoop]), sizeof(T_BspAdaptOneChanCarrInfo));

        BspFillIcHalCarrInfo(&(ptRxChanInfo->chanInfo[chanLoop]), &halChanInfo->atChanInfo[halDifChan]);
        dbgSaveHalCarrInfo(RX, halDifChan, &(halChanInfo->atChanInfo[halDifChan]));
    }

    retVal = IcHalApiRxResourceAlloc(halChanInfo, ptRxFailChanInfo);
    free(halChanInfo);
    pthreadWrSemGive(&s_DifInfoUpdateWrSem);
    return retVal;
}

/**********************************************************************
* 函数名称: BspHalAdaptTxAnalysisDuc0
* 功能描述: 配频模块下行资源0级Duc预分析
* 输入参数: ptTxCarrInfo 下行所有通道载波信息
* 输出参数: 无
* 返  回  值: BSP_OK/BSP_ERROR
************************************************************************/
UINT32 BspHalAdaptTxAnalysisDuc0(T_BspHalAdaptChanInfo *ptTxChanInfo)
{
    UINT32 retVal     = BSP_OK;
    UINT32 chanLoop   = 0;
    UINT32 carrLoop   = 0;
    UINT32 txChanNum  = 0;
    UINT32 halDifChan = 0;
    T_DifChanInfo *halChanInfo = NULL;

    INPUT_POINTER_CHECK(ptTxChanInfo);
    halChanInfo = (T_DifChanInfo *)malloc(sizeof(T_DifChanInfo));
    INPUT_POINTER_CHECK(halChanInfo);
    zte_memset_s(halChanInfo, sizeof(T_DifChanInfo), 0, sizeof(T_DifChanInfo));
    txChanNum = ptTxChanInfo->chanNum;

    if(BSP_OK != pthreadWrSemTake(&s_DifInfoUpdateWrSem))
    {
        free(halChanInfo);
        dbgErr("%s write sem error!\n", __FUNCTION__);
        return BSP_ERROR;
    }

    for(chanLoop = 0; chanLoop < txChanNum; chanLoop++)
    {
        if(ptTxChanInfo->chanInfo[chanLoop].carrNum > NELEMENTS(ptTxChanInfo->chanInfo[chanLoop].oneCarrInfo))
        {
            dbgErr("%s [%d] is more than difhal carr max num[%d] !\n",
                __FUNCTION__, ptTxChanInfo->chanInfo[chanLoop].carrNum, NELEMENTS(ptTxChanInfo->chanInfo[chanLoop].oneCarrInfo));
            free(halChanInfo);
            pthreadWrSemGive(&s_DifInfoUpdateWrSem);
            return BSP_ERROR;
        }
        halDifChan = ptTxChanInfo->chanInfo[chanLoop].difChanNo;
        dbgInfo("%s line[%d] chanLoop  %d, halDifChan %d\n", __FUNCTION__, __LINE__, chanLoop, halDifChan);

        BspFillIcHalCarrInfo(&(ptTxChanInfo->chanInfo[chanLoop]), &(halChanInfo->atChanInfo[halDifChan]));
        if(IS_NCR ==  BspIsNcr())
        {
            for(carrLoop = 0; carrLoop < BSP_DIF_CARR_MAX_NUM * 2; carrLoop++)
            {
                halChanInfo->atChanInfo[halDifChan].atCarrInfo[carrLoop].uiIsRcf = (g_setRcfFlagMask & BIT_SET(halDifChan)) ? 1 : 0;
                dbgInfo("%s line[%d] chanLoop %d carr %d chanMask 0x%08lX uiIsRcf %d\n", __FUNCTION__, __LINE__, chanLoop, carrLoop,
                        BIT_SET(halDifChan), halChanInfo->atChanInfo[halDifChan].atCarrInfo[carrLoop].uiIsRcf);
            }
        }
    }

    retVal = IcHalApiTxResourceAllocDuc0(halChanInfo);
    free(halChanInfo);
    pthreadWrSemGive(&s_DifInfoUpdateWrSem);
    return retVal;
}

/**********************************************************************
* 函数名称: BspHalAdaptTxAnalysisDuc0Rpt
* 功能描述: 配频模块下行资源0级Duc预分析
* 输入参数: ptTxCarrInfo 下行所有通道载波信息
* 输出参数: 无
* 返  回  值: BSP_OK/BSP_ERROR
************************************************************************/
UINT32 BspHalAdaptTxAnalysisDuc0Rpt(T_BspHalAdaptChanInfo *ptTxChanInfo, T_BspHalAdaptChanInfo *ptFailTxChanInfo, UINT32 flag)
{
    UINT32 retVal     = BSP_OK;
    UINT32 chanLoop   = 0;
    UINT32 carrLoop   = 0;
    UINT32 txChanNum  = 0;
    UINT32 halDifChan = 0;
    UINT32 overChanNum = 0;
    T_DifChanInfo *halChanInfo = NULL;
    T_DifChanInfo *pHalFailChanInfo = NULL;

    INPUT_POINTER_CHECK(ptTxChanInfo);
    INPUT_POINTER_CHECK(ptFailTxChanInfo);
    halChanInfo = (T_DifChanInfo *)malloc(sizeof(T_DifChanInfo));
    INPUT_POINTER_CHECK(halChanInfo);
    zte_memset_s(halChanInfo, sizeof(T_DifChanInfo), 0, sizeof(T_DifChanInfo));
    pHalFailChanInfo = (T_DifChanInfo *)malloc(sizeof(T_DifChanInfo));
    if (NULL == pHalFailChanInfo)
    {
        free(halChanInfo);
        dbgErr("[%s] pHalFailChanInfo is NULL!\n", __FUNCTION__);
        return BSP_ERROR;
    }
    zte_memset_s(pHalFailChanInfo, sizeof(T_DifChanInfo), 0, sizeof(T_DifChanInfo));
    txChanNum = ptTxChanInfo->chanNum;

    if(BSP_OK != pthreadWrSemTake(&s_DifInfoUpdateWrSem))
    {
        free(halChanInfo);
        free(pHalFailChanInfo);
        dbgErr("%s write sem error!\n", __FUNCTION__);
        return BSP_ERROR;
    }

    for(chanLoop = 0; chanLoop < txChanNum; chanLoop++)
    {
        if(ptTxChanInfo->chanInfo[chanLoop].carrNum > NELEMENTS(ptTxChanInfo->chanInfo[chanLoop].oneCarrInfo))
        {
            dbgErr("%s [%d] is more than difhal carr max num[%d] !\n",
                __FUNCTION__, ptTxChanInfo->chanInfo[chanLoop].carrNum, NELEMENTS(ptTxChanInfo->chanInfo[chanLoop].oneCarrInfo));
            free(halChanInfo);
            free(pHalFailChanInfo);
            pthreadWrSemGive(&s_DifInfoUpdateWrSem);
            return BSP_ERROR;
        }
        halDifChan = ptTxChanInfo->chanInfo[chanLoop].difChanNo;

        BspFillIcHalCarrInfo(&(ptTxChanInfo->chanInfo[chanLoop]), &(halChanInfo->atChanInfo[halDifChan]));
        if(IS_NCR ==  BspIsNcr())
        {
            for(carrLoop = 0; carrLoop < BSP_DIF_CARR_MAX_NUM * 2; carrLoop++)
            {
                halChanInfo->atChanInfo[halDifChan].atCarrInfo[carrLoop].uiIsRcf = 0;
            }
        }
    }
    if(flag == 1)
    {
        retVal = IcHalApiTxResourceNbPreAlloc(halChanInfo, pHalFailChanInfo);
    }
    else
    {
        retVal = IcHalApiTxResourceAllocDuc0Rpt(halChanInfo, pHalFailChanInfo);
    }

    for(chanLoop = 0; chanLoop < txChanNum; chanLoop++)
    {
        if(0 == pHalFailChanInfo->atChanInfo[chanLoop].uiCarrNum)
        {
            continue;
        }

        ptFailTxChanInfo->chanInfo[overChanNum].difChanNo = chanLoop;
        ptFailTxChanInfo->chanInfo[overChanNum].carrNum = pHalFailChanInfo->atChanInfo[chanLoop].uiCarrNum;

        for(carrLoop = 0; carrLoop < pHalFailChanInfo->atChanInfo[chanLoop].uiCarrNum; carrLoop++)
        {
            ptFailTxChanInfo->chanInfo[overChanNum].oneCarrInfo[carrLoop].difCarrNo = pHalFailChanInfo->atChanInfo[chanLoop].atCarrInfo[carrLoop].uiCarrId;
            ptFailTxChanInfo->chanInfo[overChanNum].oneCarrInfo[carrLoop].carrFreq = pHalFailChanInfo->atChanInfo[chanLoop].atCarrInfo[carrLoop].uiCarrFreq;
            ptFailTxChanInfo->chanInfo[overChanNum].oneCarrInfo[carrLoop].carrRadio = pHalFailChanInfo->atChanInfo[chanLoop].atCarrInfo[carrLoop].uiCarrRadio;
            ptFailTxChanInfo->chanInfo[overChanNum].oneCarrInfo[carrLoop].carrBw = pHalFailChanInfo->atChanInfo[chanLoop].atCarrInfo[carrLoop].uiCarrBw;
            ptFailTxChanInfo->chanInfo[overChanNum].oneCarrInfo[carrLoop].uiCellId = pHalFailChanInfo->atChanInfo[chanLoop].atCarrInfo[carrLoop].uiCellId;
        }
        overChanNum++;
    }
    ptFailTxChanInfo->chanNum = overChanNum;

    free(halChanInfo);
    free(pHalFailChanInfo);
    pthreadWrSemGive(&s_DifInfoUpdateWrSem);
    return retVal;
}

/**********************************************************************
* 函数名称: BspHalAdaptRxAnalysisDdc0
* 功能描述: 配频模块上行0级Duc资源预分析
* 输入参数: ptRxCarrInfo 下行所有通道通道载波信息
* 输出参数: 无
* 返  回  值: BSP_OK/BSP_ERROR
************************************************************************/
UINT32 BspHalAdaptRxAnalysisDdc0(T_BspHalAdaptChanInfo *ptRxChanInfo)
{
    UINT32 retVal     = BSP_OK;
    UINT32 chanLoop   = 0;
    UINT32 txChanNum  = 0;
    UINT32 halDifChan = 0;
    T_DifChanInfo *halChanInfo = NULL;

    INPUT_POINTER_CHECK(ptRxChanInfo);
    halChanInfo = (T_DifChanInfo *)malloc(sizeof(T_DifChanInfo));
    INPUT_POINTER_CHECK(halChanInfo);
    zte_memset_s(halChanInfo, sizeof(T_DifChanInfo), 0, sizeof(T_DifChanInfo));
    txChanNum = ptRxChanInfo->chanNum;

    if(BSP_OK != pthreadWrSemTake(&s_DifInfoUpdateWrSem))
    {
        free(halChanInfo);
        dbgErr("%s write sem error!\n", __FUNCTION__);
        return BSP_ERROR;
    }

    for(chanLoop = 0; chanLoop < txChanNum; chanLoop++)
    {
        if(ptRxChanInfo->chanInfo[chanLoop].carrNum > NELEMENTS(ptRxChanInfo->chanInfo[chanLoop].oneCarrInfo))
        {
            dbgErr("%s [%d] is more than difhal carr max num[%d] !\n",
                __FUNCTION__, ptRxChanInfo->chanInfo[chanLoop].carrNum, NELEMENTS(ptRxChanInfo->chanInfo[chanLoop].oneCarrInfo));
            free(halChanInfo);
            pthreadWrSemGive(&s_DifInfoUpdateWrSem);
            return BSP_ERROR;
        }
        halDifChan = ptRxChanInfo->chanInfo[chanLoop].difChanNo;
        CONTINUE_IF_EXP(halDifChan >= NELEMENTS(halChanInfo->atChanInfo));
        BspFillIcHalCarrInfo(&(ptRxChanInfo->chanInfo[chanLoop]), &(halChanInfo->atChanInfo[halDifChan]));
    }

    retVal = IcHalApiRxResourceAllocDdc0(halChanInfo);
    free(halChanInfo);
    pthreadWrSemGive(&s_DifInfoUpdateWrSem);
    return retVal;
}

/**********************************************************************
* 函数名称: BspHalAdaptRxAnalysisDdc0Rpt
* 功能描述: 配频模块上行0级Duc资源预分析
* 输入参数: ptRxCarrInfo 下行所有通道通道载波信息
* 输出参数: 无
* 返  回  值: BSP_OK/BSP_ERROR
************************************************************************/
UINT32 BspHalAdaptRxAnalysisDdc0Rpt(T_BspHalAdaptChanInfo *ptRxChanInfo, T_BspHalAdaptChanInfo *ptFailRxChanInfo, UINT32 flag)
{
    UINT32 retVal     = BSP_OK;
    UINT32 chanLoop   = 0;
    UINT32 carrLoop   = 0;
    UINT32 rxChanNum  = 0;
    UINT32 halDifChan = 0;
    UINT32 overChanNum = 0;
    T_DifChanInfo *halChanInfo = NULL;
    T_DifChanInfo *pHalFailChanInfo = NULL;

    INPUT_POINTER_CHECK(ptRxChanInfo);
    INPUT_POINTER_CHECK(ptFailRxChanInfo);
    halChanInfo = (T_DifChanInfo *)malloc(sizeof(T_DifChanInfo));
    INPUT_POINTER_CHECK(halChanInfo);
    zte_memset_s(halChanInfo, sizeof(T_DifChanInfo), 0, sizeof(T_DifChanInfo));
    pHalFailChanInfo = (T_DifChanInfo *)malloc(sizeof(T_DifChanInfo));
    if (NULL == pHalFailChanInfo)
    {
        free(halChanInfo);
        dbgErr("[%s] pHalFailChanInfo is NULL!\n", __FUNCTION__);
        return BSP_ERROR;
    }
    zte_memset_s(pHalFailChanInfo, sizeof(T_DifChanInfo), 0, sizeof(T_DifChanInfo));
    rxChanNum = ptRxChanInfo->chanNum;

    if(BSP_OK != pthreadWrSemTake(&s_DifInfoUpdateWrSem))
    {
        free(halChanInfo);
        free(pHalFailChanInfo);
        dbgErr("%s write sem error!\n", __FUNCTION__);
        return BSP_ERROR;
    }

    for(chanLoop = 0; chanLoop < rxChanNum; chanLoop++)
    {
        if(ptRxChanInfo->chanInfo[chanLoop].carrNum > NELEMENTS(ptRxChanInfo->chanInfo[chanLoop].oneCarrInfo))
        {
            dbgErr("%s [%d] is more than difhal carr max num[%d] !\n",
                __FUNCTION__, ptRxChanInfo->chanInfo[chanLoop].carrNum, NELEMENTS(ptRxChanInfo->chanInfo[chanLoop].oneCarrInfo));
            free(halChanInfo);
            free(pHalFailChanInfo);
            pthreadWrSemGive(&s_DifInfoUpdateWrSem);
            return BSP_ERROR;
        }
        halDifChan = ptRxChanInfo->chanInfo[chanLoop].difChanNo;
        CONTINUE_IF_EXP(halDifChan >= NELEMENTS(halChanInfo->atChanInfo));
        BspFillIcHalCarrInfo(&(ptRxChanInfo->chanInfo[chanLoop]), &(halChanInfo->atChanInfo[halDifChan]));
    }
    if(flag == 1)
    {
        retVal = IcHalApiRxResourceNbPreAlloc(halChanInfo, pHalFailChanInfo);
    }
    else
    {
        retVal = IcHalApiRxResourceAllocDdc0Rpt(halChanInfo, pHalFailChanInfo);
    }

    for(chanLoop = 0; chanLoop < rxChanNum; chanLoop++)
    {
        if(0 == pHalFailChanInfo->atChanInfo[chanLoop].uiCarrNum)
        {
            continue;
        }

        ptFailRxChanInfo->chanInfo[overChanNum].difChanNo = chanLoop;
        ptFailRxChanInfo->chanInfo[overChanNum].carrNum = pHalFailChanInfo->atChanInfo[chanLoop].uiCarrNum;

        for(carrLoop = 0; carrLoop < pHalFailChanInfo->atChanInfo[chanLoop].uiCarrNum; carrLoop++)
        {
            ptFailRxChanInfo->chanInfo[overChanNum].oneCarrInfo[carrLoop].difCarrNo = pHalFailChanInfo->atChanInfo[chanLoop].atCarrInfo[carrLoop].uiCarrId;
            ptFailRxChanInfo->chanInfo[overChanNum].oneCarrInfo[carrLoop].carrFreq = pHalFailChanInfo->atChanInfo[chanLoop].atCarrInfo[carrLoop].uiCarrFreq;
            ptFailRxChanInfo->chanInfo[overChanNum].oneCarrInfo[carrLoop].carrRadio = pHalFailChanInfo->atChanInfo[chanLoop].atCarrInfo[carrLoop].uiCarrRadio;
            ptFailRxChanInfo->chanInfo[overChanNum].oneCarrInfo[carrLoop].carrBw = pHalFailChanInfo->atChanInfo[chanLoop].atCarrInfo[carrLoop].uiCarrBw;
            ptFailRxChanInfo->chanInfo[overChanNum].oneCarrInfo[carrLoop].uiCellId = pHalFailChanInfo->atChanInfo[chanLoop].atCarrInfo[carrLoop].uiCellId;
        }
        overChanNum++;
    }
    ptFailRxChanInfo->chanNum = overChanNum;

    free(halChanInfo);
    free(pHalFailChanInfo);
    pthreadWrSemGive(&s_DifInfoUpdateWrSem);
    return retVal;
}

/* 中频资源分配前后使用，用于控制未使用资源的门控使能 */
VOID BspHalAdaptSetDifUnusedResGateEn(UINT32 dir, UINT32 gateEn)
{
    /*UINT32 retVal = BSP_OK;
    UINT32 gateEnSel = 0;*/

    /* hal层还没有支持门控，暂时屏蔽 */
#if 0
    if(dir > TX)
    {
        return;
    }
    if(BSP_OK == BspHalAdaptGetDifunusedGateEn(dir, &gateEnSel))
    {
        /* 如果未使用资源需要关闭门控 */
        if(!gateEnSel)
        {
            if(TX == dir)
            {
                retVal = BspHalAdaptSetTxUnusedGateEn(gateEn);
            }
            else
            {
                retVal = BspHalAdaptSetRxUnusedGateEn(gateEn);
            }
            dbgInfo("%s Set %s Unused Resouse Gate En'%d %s\n", __FUNCTION__,
                      (dir==TX?"TX":"RX"), gateEn, (retVal==BSP_OK?"SUCC":"FAIL"));
            return;
        }
        dbgInfo("%s %s Unused Resource Gate is not need to ctrl, gateEnSel=%d\n", __FUNCTION__,
                  (dir==TX?"TX":"RX"), gateEnSel);
        return;
    }

    dbgInfo("%s BspHalAdaptGetDifunusedGateEn %s fail\n", __FUNCTION__, (dir==TX?"TX":"RX"));
#endif
    return;
}

/**********************************************************************
* 函数名称: BspHalAdaptGetDifCarrBandNo
* 功能描述: hal层配置频段NCO
* 输入参数: dir TX/RX,difChan 中频通道,radioMode 载波制式，difCarrNo 载波号，bandNo band号
* 输出参数: 无
* 返  回  值: BSP_OK / BSP_ERROR
************************************************************************/
UINT32 BspHalAdaptGetDifCarrBandNo(UINT32 dir, UINT32 difChan, UINT32 radioMode,
        UINT32 difCarrNo, UINT32 *bandNo)
{
    UINT32 retVal = BSP_OK;
    INPUT_POINTER_CHECK(bandNo);

    if(TX == dir)
    {
        retVal = IcHalApiGetTxDifCarrBandNo(difChan, radioMode, difCarrNo, bandNo);
    }
    else if(RX == dir)
    {
        retVal = IcHalApiGetRxDifCarrBandNo(difChan, radioMode, difCarrNo, bandNo);
    }
    else
    {
        return BSP_ERROR;
    }

    return retVal;
}

/**********************************************************************
* 函数名称: BspHalAdaptGetDifBandFreq
* 功能描述: 获取频段数和频段频点
* 输入参数: dir TX/RX,difChan 中频通道,bandNum band数量，bandFreq band频点
* 输出参数: band数量，band频点
* 返  回  值: BSP_OK / BSP_ERROR
************************************************************************/
UINT32 BspHalAdaptGetDifBandFreq(UINT32 dir, UINT32 difChan, UINT32 *bandNum, UINT32 *bandFreq)
{
    UINT32 retVal = BSP_OK;
    INPUT_POINTER_CHECK(bandNum);
    INPUT_POINTER_CHECK(bandFreq);

    if(TX == dir)
    {
        retVal = IcHalApiGetTxDifBandFreq(difChan, bandNum, bandFreq);
    }
    else if(RX == dir)
    {
        retVal = IcHalApiGetRxDifBandFreq(difChan, bandNum, bandFreq);
    }
    else
    {
        return BSP_ERROR;
    }

    return retVal;
}

/**********************************************************************
* 函数名称: BspHalAdaptGetFreqNco2Step
* 功能描述: 获取频段NCO的步长
* 输入参数:dir TX/RX,pRfCfgPara 配频单通道所有载波信息
* 输出参数: 无
* 返  回  值: BSP_OK / BSP_ERROR
************************************************************************/
UINT32 BspHalAdaptGetFreqNco2Step(UINT32 dir, UINT32 difChan, UINT32 *step)
{
    UINT32 retVal = BSP_OK;
    INPUT_POINTER_CHECK(step);

    if(TX == dir)
    {
        retVal = IcHalApiGetTxFreqNco2Step(difChan, step);
    }
    else if(RX == dir)
    {
        retVal = IcHalApiGetRxFreqNco2Step(difChan, step);
    }
    else
    {
        return BSP_ERROR;
    }
    return retVal;
}

/**********************************************************************
* 函数名称: BspHalAdaptResourceAllocCfg
* 功能描述: hal_adapt中频TX/RX资源分配配置的API接口
* 输入参数:无
* 输出参数: 无
* 返  回  值: BSP_OK / BSP_ERROR
************************************************************************/
UINT32 BspHalAdaptResourceAllocCfg(UINT32 dir, UINT32 difChan, T_RfChanCfgEn *pRfChanCfgEn, T_DifCarrInfoCfg *ptFailCarrCfgInfo)
{
    UINT32 retVal                  = BSP_OK;
    UINT32 carrNum                 = 0;
    UINT32 carrLoop                = 0;
    T_DifCarrInfoCfg carrInfoCfgEn = {0};

    carrNum = pRfChanCfgEn->carrNum;
    carrInfoCfgEn.uiCarrNum = carrNum;
    for(carrLoop = 0; carrLoop < carrNum; carrLoop ++)
    {
        carrInfoCfgEn.atCarrInfo[carrLoop].uiCarrId = pRfChanCfgEn->carrInfo[carrLoop].carrId;
        carrInfoCfgEn.atCarrInfo[carrLoop].uiCarrRadio = pRfChanCfgEn->carrInfo[carrLoop].carrRadio;
        carrInfoCfgEn.atCarrInfo[carrLoop].uiDelOrAddFlag = pRfChanCfgEn->carrInfo[carrLoop].delOrAddFlag;
    }

    if(dir == TX)
    {
        retVal = IcHalApiTxResourceAllocCfg(difChan, &carrInfoCfgEn, ptFailCarrCfgInfo);
    }
    else if(dir == RX)
    {
        retVal = IcHalApiRxResourceAllocCfg(difChan, &carrInfoCfgEn, ptFailCarrCfgInfo);
    }
    else
    {
        dbgErr("[%s] Error: input isn't TX or RX!\n" ,__FUNCTION__);
        return BSP_ERROR;
    }

    return retVal;
}

/* 获取载波的实际成型带宽 */
UINT32 BspHalAdaptGetRealBw(UINT32 dir, UINT32 difChan, UINT32 carrId, UINT32 radioMode, UINT32 *pRealBw)
{
    UINT32 retVal = BSP_OK;
    INPUT_POINTER_CHECK(pRealBw);

    if(dir == TX)
    {
        retVal = IcHalApiGetTxRealBW(difChan, carrId, radioMode, pRealBw);
    }
    else
    {
        retVal = IcHalApiGetRxRealBW(difChan, carrId, radioMode, pRealBw);
    }

    return retVal;
}

/**********************************************************************
* 函数名称: BspHalAdaptResourceAllocClr
* 功能描述: hal_adapt中频TX/RX资源分配清零的API接口
* 输入参数:无
* 输出参数: 无
* 返  回  值: BSP_OK / BSP_ERROR
************************************************************************/
UINT32 BspHalAdaptResourceAllocClr(UINT32 dir)
{
    UINT32 retVal = BSP_OK;

    if(dir == TX)
    {
        retVal = IcHalApiTxResourceAllocClr();
    }
    else if(dir == RX)
    {
        retVal = IcHalApiRxResourceAllocClr();
    }
    else
    {
        dbgErr("[%s] Error: input isn't TX or RX!\n" ,__FUNCTION__);
        return BSP_ERROR;
    }

    return retVal;
}

/**********************************************************************
* 函数名称: BspHalAdaptResourceAllocRpt
* 功能描述: 预分析后hal层上报下行受影响的载波信息
* 输入参数:无
* 输出参数: 无
* 返  回  值: BSP_OK / BSP_ERROR
************************************************************************/
UINT32 BspHalAdaptResourceAllocRpt(UINT32 dir, T_BspHalAdaptChanInfo *ptTxChanInfo)
{
    UINT32 retVal     = BSP_OK;
    UINT32 halDifChan = 0;
    T_DifChanInfo *halChanInfoRpt = NULL;

    INPUT_POINTER_CHECK(ptTxChanInfo);
    halChanInfoRpt = (T_DifChanInfo *)malloc(sizeof(T_DifChanInfo));
    INPUT_POINTER_CHECK(halChanInfoRpt);
    zte_memset_s(halChanInfoRpt, sizeof(T_DifChanInfo), 0, sizeof(T_DifChanInfo));

    if(dir == TX)
    {
        retVal = IcHalApiTxResourceAllocRpt(halChanInfoRpt);
    }
    else if(dir == RX)
    {
        retVal = IcHalApiRxResourceAllocRpt(halChanInfoRpt);
    }
    else
    {
        free(halChanInfoRpt);
        dbgErr("[%s] Error: input isn't TX or RX!\n" ,__FUNCTION__);
        return BSP_ERROR;
    }

    for(halDifChan = 0; halDifChan < BSP_IC4_DIF_CHAN_NUM; halDifChan++)
    {
        if(halChanInfoRpt->atChanInfo[halDifChan].uiCarrNum > NELEMENTS(halChanInfoRpt->atChanInfo[halDifChan].atCarrInfo))
        {
            free(halChanInfoRpt);
            dbgErr("%s [%d] is more than difhal carr max num[%d] !\n",
                __FUNCTION__, ptTxChanInfo->chanInfo[halDifChan].carrNum, NELEMENTS(halChanInfoRpt->atChanInfo[halDifChan].atCarrInfo));
            return BSP_ERROR;
        }

        ptTxChanInfo->chanInfo[halDifChan].difChanNo = halDifChan;

        BspGetIcHalCarrInfo(&(ptTxChanInfo->chanInfo[halDifChan]), &(halChanInfoRpt->atChanInfo[halDifChan]));
        dbgSaveHalRptCarrInfo(dir, halDifChan, &(halChanInfoRpt->atChanInfo[halDifChan]));
    }
    free(halChanInfoRpt);

    return retVal;
}

/** UMTS下行UL频谱共享配置带宽 */
UINT32 BspHalAdaptSetUmtsDlBw(UINT32 difChan, UINT32 carrIndex, UINT32 radioMode, UINT32 umtsBw)
{
    UINT32 retVal = BSP_OK;
  
    retVal = IcHalApiSetUmtsDlBw(difChan, carrIndex, radioMode, umtsBw);

    return retVal;
}

/** UMTS下行UL频谱共享配置成型前NCO */
UINT32 BspHalAdaptSetUmtsDlNcoFront(UINT32 difChan, UINT32 carrIndex, UINT32 radioMode, INT32 offset)
{
    UINT32 retVal = BSP_OK;
  
    retVal = IcHalApiSetUmtsDlNcoFront(difChan, carrIndex, radioMode, offset);

    return retVal;
}

/** UMTS下行UL频谱共享配置成型后NCO */
UINT32 BspHalAdaptSetUmtsDlNcoBehind(UINT32 difChan, UINT32 carrIndex, UINT32 radioMode, INT32 offset)
{
    UINT32 retVal = BSP_OK;
  
    retVal = IcHalApiSetUmtsDlNcoBehind(difChan, carrIndex, radioMode, offset);

    return retVal;
}

/** 根据返回值判断当前UMTS的带宽是否可做单边滤波 */
UINT32 BspHalAdaptGetUmtsDlBw(UINT32 difChan, UINT32 radioMode, UINT32 umtsBw)
{
    UINT32 retVal = BSP_OK;
  
    retVal = IcHalApiGetUmtsDlBw(umtsBw);

    return retVal;
}

UINT32 BspHalAdaptGetDlBw(UINT32 difChan, UINT32 radio, UINT32 bandWidth)
{
    UINT32 ret = BSP_ERROR;

    if (BSP_RADIO_STANDARD_UMTS == radio)
    {
        ret = IcHalApiGetUmtsDlBw(bandWidth);
    }
    else if ((BSP_RADIO_STANDARD_FDD_5G == radio) || (BSP_RADIO_STANDARD_LTE_FDD == radio))
    {
        ret = IcHalApiGetTxCarrCfirNcoBw(bandWidth);
    }

    return ret;
}

UINT32 BspHalAdaptGetUlBw(UINT32 difChan, UINT32 radio, UINT32 bandWidth)
{
    UINT32 ret = BSP_ERROR;

    if ((BSP_RADIO_STANDARD_FDD_5G == radio) || (BSP_RADIO_STANDARD_LTE_FDD == radio))
    {
        ret = IcHalApiGetRxCarrCfirNcoBw(bandWidth);
    }

    return ret;
}

UINT32 BspHalAdaptSetTxCarrCfirNcoCoef(UINT32 difChan, UINT32 carrNo, UINT32 radioMode, UINT32 bandWidth)
{
    UINT retVal = BSP_OK;

    retVal = IcHalApiSetTxCarrCfirNcoCoef(difChan, carrNo, radioMode, bandWidth);

    return retVal;
}

UINT32 BspHalAdaptSetRxCarrCfirNcoCoef(UINT32 difChan, UINT32 carrNo, UINT32 radioMode, UINT32 bandWidth)
{
    UINT retVal = BSP_OK;

    retVal = IcHalApiSetRxCarrCfirNcoCoef(difChan, carrNo, radioMode, bandWidth);

    return retVal;
}

UINT32 BspHalAdaptSetTxCarrCfirNcoFront(UINT32 difChan, UINT32 carrNo, UINT32 radioMode, INT32 swFreqOffset)
{
    UINT32 retVal = BSP_OK;

    retVal = IcHalApiSetTxCarrCfirNcoFront(difChan, carrNo, radioMode, swFreqOffset);

    return retVal;
}

UINT32 BspHalAdaptSetRxCarrCfirNcoFront(UINT32 difChan, UINT32 carrNo, UINT32 radioMode, INT32 swFreqOffset)
{
    UINT32 retVal = BSP_OK;

    retVal = IcHalApiSetRxCarrCfirNcoFront(difChan, carrNo, radioMode, swFreqOffset);

    return retVal;
}

UINT32 BspHalAdaptSetTxCarrCfirNcoBehind(UINT32 difChan,UINT32 carrNo, UINT32 radioMode, INT32 offset)
{
    UINT32 retVal = BSP_OK;

    retVal = IcHalApiSetTxCarrCfirNcoBehind(difChan, carrNo, radioMode, offset);

    return retVal;
}

UINT32 BspHalAdaptSetRxCarrCfirNcoBehind(UINT32 difChan, UINT32 carrNo, UINT32 radioMode, INT32 offset)
{
    UINT32 retVal = BSP_OK;

    retVal = IcHalApiSetRxCarrCfirNcoBehind(difChan, carrNo, radioMode, offset);

    return retVal;
}
/**************************************************************************
                配频模块相关接口结束
**************************************************************************/

UINT32 BspHalAdaptDifTxRouteMapInit(T_BspHalAdaptDifTxRouteMap *ptTxRouteMap, UINT32 txLinkNum, UINT32 txDifNum)
{
    UINT32 retVal = BSP_OK;


    INPUT_POINTER_CHECK(ptTxRouteMap);
    SaveDifCfg(E_DIF_ROUTEMAP_TX, (VOID*)ptTxRouteMap, txLinkNum, txDifNum);    
    retVal = IcHalApiDifTxRouteInit((T_DifTxRouteMap*)ptTxRouteMap, txLinkNum, txDifNum);
    return retVal;
}

UINT32 BspHalAdaptDifTxRouteParaInit(T_BspHalAdaptDifTxRoutePara *ptTxRoutePara, UINT32 txLinkNum, UINT32 txDifNum)
{
    UINT32 retVal = BSP_OK;


    INPUT_POINTER_CHECK(ptTxRoutePara);
    SaveDifCfg(E_DIF_ROUTEPARA_TX, (VOID*)ptTxRoutePara, txLinkNum, txDifNum);    
    retVal = IcHalApiDifTxRouteParaInit((T_DifTxRoutePara*)ptTxRoutePara, txLinkNum, txDifNum);
    return retVal;    
}

UINT32 BspHalAdaptDifTx204RouteMapInit(T_BspHalAdaptDifTx204RouteMap *ptTx204RouteMap, UINT32 tx204LinkNum, UINT32 tx204DifNum)
{
    UINT32 retVal = BSP_OK;


    INPUT_POINTER_CHECK(ptTx204RouteMap);
    SaveDifCfg(E_DIF_ROUTEMAP_204, (VOID*)ptTx204RouteMap, tx204LinkNum, tx204DifNum); 
    retVal = IcHalApiDifTx204RouteInit((T_DifTx204RouteMap*)ptTx204RouteMap, tx204LinkNum, tx204DifNum);
    return retVal;
}

UINT32 BspHalAdaptDifRxRouteMapInit(T_BspHalAdaptDifRxRouteMap *ptRxRouteMap, UINT32 rxLinkNum, UINT32 rxDifNum)
{
    UINT32 retVal = BSP_OK;

    INPUT_POINTER_CHECK(ptRxRouteMap);
    SaveDifCfg(E_DIF_ROUTEMAP_RX, (VOID*)ptRxRouteMap, rxLinkNum, rxDifNum);
    retVal = IcHalApiDifRxRouteInit((T_DifRxRouteMap*)ptRxRouteMap, rxLinkNum, rxDifNum); 
    return retVal;    
}

UINT32 BspHalAdaptDifFbRouteMapInit(T_BspHalAdaptDifFbRouteMap *ptFbRouteMap, UINT32 fbLinkNum, UINT32 fbDifNum)
{
    UINT32 retVal = BSP_OK;

    INPUT_POINTER_CHECK(ptFbRouteMap);
    SaveDifCfg(E_DIF_ROUTEMAP_FB, (VOID*)ptFbRouteMap, fbLinkNum, fbDifNum);
    retVal = IcHalApiDifFbRouteInit(ptFbRouteMap, fbLinkNum, fbDifNum);
    return retVal;
}

UINT32 BspHalAdaptDifParaInit(T_BspHalAdaptDifCfgPara *pDifPara)
{    
    UINT32 retVal = BSP_OK;
    
    INPUT_POINTER_CHECK(pDifPara);
    SaveDifCfg(E_DIF_DIFPARA_INIT, (VOID*)pDifPara, 1, 32);
    retVal = IcHalApiDifParaInit((T_DifConfigInfo*)pDifPara);    
    return retVal;
}

UINT32 BspHalAdaptDifSamRateParaInit(T_BspHalAdaptDifSamRatePara *pDifSamratePara)
{    
    UINT32 retVal = BSP_OK;

    INPUT_POINTER_CHECK(pDifSamratePara);
    SaveDifCfg(E_DIF_DIFPARA_SAMRATE, (VOID*)pDifSamratePara, 1, 32);
    retVal = IcHalApiDifSamRateParaInit((T_DifSamRateCommPara*)pDifSamratePara);    
    return retVal;
}


UINT32 BspHalAdaptDifClkParaInit(T_BspHalAdaptDifClkPara *pDifClkPara, UINT32 type)
{
    UINT32 retVal = BSP_OK;

    INPUT_POINTER_CHECK(pDifClkPara);
    /* 保存时钟参数到全局变量中，供CRM初始化使用 */
    if(type == CFG_TYPE_CRM_INIT)
    {
        SaveDifCfg(E_DIF_DIFPARA_CLK, (VOID*)pDifClkPara, 1, 32);
    }
    /* 将时钟参数配置到中频HAL */
    else
    {
        SaveDifCfg(E_DIF_DIFPARA_CLK, (VOID*)pDifClkPara, 1, 32);
        retVal = IcHalApiDifClkParaInit((T_DifClkCommPara*)pDifClkPara);
    }
    return retVal;
}

UINT32 BspHalAdaptDifResourceAllocParaInit(T_BspHalAdaptDifResAllocPara *pDifResAllocPara)
{
    UINT32 retVal = BSP_OK;

    INPUT_POINTER_CHECK(pDifResAllocPara);
    SaveDifCfg(E_DIF_DIFPARA_RESALLOC, (VOID*)pDifResAllocPara, 1, 32);
    retVal = IcHalApiDifResourceAllocParaInit((T_DifResourceAllocCommPara*)pDifResAllocPara);    
    return retVal;  
}

#if 0
UINT32 BspHalAdaptGetDifCrmClk(T_BspHalAdaptDifCrmClk *pDifCrmClk)
{
    T_BspHalAdaptDifClkPara *pClkPara = NULL;
    T_DifCfgSave *pSaveCfg = NULL;

    INPUT_POINTER_CHECK(pDifCrmClk);
    pSaveCfg = GetDifCfgSave(E_DIF_DIFPARA_CLK);
    if(NULL != pSaveCfg)
    {
        pClkPara = (T_BspHalAdaptDifClkPara*)(pSaveCfg->pAddr);
        if (pClkPara == NULL)
        {
            dbgErr(">>BspHalAdaptGetDifCrmClk error, get dif crm clock failed \r\n");
            return BSP_ERROR;
        }
        pDifCrmClk->baseLogicClk = pClkPara->ui737Clk;
        pDifCrmClk->dlLogic2Clk = pClkPara->uiDlCfrClk;
        pDifCrmClk->dlLogic3Clk = pClkPara->uiDlDpdClk;
        pDifCrmClk->dlLogic4Clk = pClkPara->uiDlPostClk;
        pDifCrmClk->dlLogic5Clk = pClkPara->uiJ204DlLogic5Clk;
        pDifCrmClk->ulLogic1Clk = pClkPara->uiUlChClk;
        pDifCrmClk->ulLogic2Clk = pClkPara->uiJ204UlLogic2Clk;
        pDifCrmClk->fbLogic1Clk = pClkPara->uiCbClk;
        pDifCrmClk->fbLogic2Clk = pClkPara->uiJ204FbLogic2Clk;
        pDifCrmClk->dlJ204WorkClk = pClkPara->uiDlJ204WorkClk;
        pDifCrmClk->ulJ204WorkClk = pClkPara->uiUlJ204WorkClk;
        pDifCrmClk->fbJ204WorkClk = pClkPara->uiFbJ204WorkClk;   

        return BSP_OK;
    }
    return BSP_ERROR;
}
#endif
UINT32 BspHalAdaptGetDifDpdSamRate(UINT32 difChan, UINT32 *pSamRate)
{
    T_DifCfgSave* pSaveCfg = NULL;

    if(difChan >= BSP_HALADAPT_IC_CHAN_MAX_NUM || NULL == pSamRate)
    {
        return BSP_ERROR;
    }

    pSaveCfg = GetDifCfgSave(E_DIF_DIFPARA_SAMRATE);
    if(NULL == pSaveCfg)
    {
        return BSP_ERROR;
    }
    
    T_BspHalAdaptDifSamRatePara *p_dbgDifSamratePara = (T_BspHalAdaptDifSamRatePara *)(pSaveCfg->pAddr);
    if(NULL == p_dbgDifSamratePara)
    {
        return BSP_ERROR;
    }
    *pSamRate = p_dbgDifSamratePara->uiDpdSamRate[difChan];
    
    return BSP_OK;
}

UINT32 BspHalAdaptGetDifCfrSamRate(UINT32 difChan, UINT32 *pSamRate)
{
    T_DifCfgSave* pSaveCfg = NULL;

    if(difChan >= BSP_HALADAPT_IC_CHAN_MAX_NUM || NULL == pSamRate)
    {
        return BSP_ERROR;
    }

    pSaveCfg = GetDifCfgSave(E_DIF_DIFPARA_SAMRATE);
    if(NULL == pSaveCfg)
    {
        return BSP_ERROR;
    }
    
    T_BspHalAdaptDifSamRatePara *p_dbgDifSamratePara = (T_BspHalAdaptDifSamRatePara *)(pSaveCfg->pAddr);
    if(NULL == p_dbgDifSamratePara)
    {
        return BSP_ERROR;
    }
    *pSamRate = p_dbgDifSamratePara->uiCfrSamRate[difChan];
    
    return BSP_OK;
}

T_BspHalAdaptDifCommCfrPara *BspHalAdaptGetDifCfrPara(VOID)
{
    T_DifCfgSave *pSaveCfg = NULL;
    T_BspHalAdaptDifCommCfrPara *pCfrPara = NULL;

    pSaveCfg = GetDifCfgSave(E_DIF_DIFPARA_CFR);
    if(NULL != pSaveCfg)
    {
        pCfrPara = (T_BspHalAdaptDifCommCfrPara *)pSaveCfg->pAddr;
    }
    return pCfrPara;
}

UINT32 BspHalAdaptGetCfrPhase2xFlag(UINT32 difChan, UINT32 *cfrPhase2xFlag)
{
    T_DifCfgSave *pSaveCfg = NULL;
    T_BspHalAdaptDifTxRoutePara *pTxRoutePara = NULL;

    INPUT_POINTER_CHECK(cfrPhase2xFlag);
    pSaveCfg = GetDifCfgSave(E_DIF_ROUTEPARA_TX);
    if(NULL != pSaveCfg)
    {
        pTxRoutePara = (T_BspHalAdaptDifTxRoutePara*)(pSaveCfg->pAddr);
        if(NULL != pTxRoutePara && difChan < BSP_IC4_DIF_CHAN_NUM)
        {
            *cfrPhase2xFlag = pTxRoutePara[difChan].uiCfrPhase2x;
            return BSP_OK;
        }
    }

    return BSP_ERROR;    
}

#if 0
static VOID BspFillIcHalFilterCoefCfg(T_BspHalAdaptFilterCoefCfg *ptSrc, T_FILTER_COEF_CFG *ptDest)
{
    ptDest->ulRadioMode = ptSrc->radioMode;
    ptDest->ulBandWidth = ptSrc->bandWidth;
    ptDest->ulSampleRate = ptSrc->sampleRate;
    ptDest->ulNarrowBandFlag = ptSrc->narrowBandFlag;
    ptDest->ulNarrowBandVal = ptSrc->narrowBandVal;
    ptDest->pulCoefArray = ptSrc->pCoefArray;
    ptDest->ulCoefLen = ptSrc->coefLen;
    ptDest->uluRLLCFlag = ptSrc->uRLLCFlag;
    return;
}

UINT32 BspHalAdaptDlRcfFilterCoef(T_BspHalAdaptFilterCoefCfg *ptFilterCfg,UINT32 filterNum)
{
    UINT32 retVal = BSP_OK;
    T_FILTER_COEF_CFG filterCoefCfg;
    INPUT_POINTER_CHECK(ptFilterCfg);
    memset(&filterCoefCfg, 0, sizeof(T_FILTER_COEF_CFG));
    BspFillIcHalFilterCoefCfg(ptFilterCfg, &filterCoefCfg);
    retVal = IcHalApiDlRcfFilterCoef((T_FILTER_COEF_CFG*)ptFilterCfg,filterNum);
    return retVal;
}
UINT32 BspHalAdaptUlRcfFilterCoef(T_BspHalAdaptFilterCoefCfg *ptFilterCfg,UINT32 filterNum)
{
    UINT32 retVal = BSP_OK;
    T_FILTER_COEF_CFG filterCoefCfg;
    INPUT_POINTER_CHECK(ptFilterCfg);
    memset(&filterCoefCfg, 0, sizeof(T_FILTER_COEF_CFG));
    BspFillIcHalFilterCoefCfg(ptFilterCfg, &filterCoefCfg);
    retVal = IcHalApiUlRcfFilterCoef((T_FILTER_COEF_CFG*)ptFilterCfg,filterNum);
    return retVal;
}
UINT32 BspHalAdaptCbRcfFilterCoef(UINT32 *ptFilterCfg)
{
    UINT32 retVal = BSP_OK;
    INPUT_POINTER_CHECK(ptFilterCfg);
    retVal = IcHalApiCbRcfFilterCoef(ptFilterCfg);
    return retVal;
}

UINT32 BspHalAdaptGetCarrNcoStep(UINT32 dir, UINT32 difChan, UINT32 *step)
{
    return BSP_OK;       
}
UINT32 BspHalAdaptNarrowBandSwitch(UINT32 difChan, UINT32 radioMode, UINT32 difCarrNo, UINT32 sw)
{
    UINT32 retVal = BSP_OK;
    retVal = IcHalApiNarrowBandSwitch(difChan, radioMode, difCarrNo, sw);
    return retVal;
}
#endif 
UINT32 BspHalAdaptDifInit(VOID)
{
    UINT32 retVal = BSP_OK;
    retVal = IcHalApiDifInit();
    return retVal;
}

#if 0
UINT32 BspHalAdaptSetDifCarrId(UINT32 dir, UINT32 difChan, UINT32 radioMode, UINT32 carrId, UINT32 difCarrId)
{
    UINT32 retVal = BSP_OK;

    if(TX == dir)
    {
        retVal = IcHalApiSetTxDifCarrId(difChan, radioMode, carrId, difCarrId);
    }
    else if(RX == dir)
    {
        retVal = IcHalApiSetRxDifCarrId(difChan, radioMode, carrId, difCarrId);
    }
    else
    {
        return BSP_ERROR;
    }
    return retVal;
}

UINT32 BspHalAdaptShowTxCarrCfg(UINT32 difChan)
{
    return IcHalApiShowTxCarrCfg(difChan);
}

UINT32 BspHalAdaptGetTxCarrCfg(UINT32 difChan, T_AcCarrcfg *recordcarrcfg)
{
    return IcHalApiGetTxCarrCfg(difChan,recordcarrcfg);
}

UINT32 BspHalAdaptShowRxCarrCfg(UINT32 difChan)
{
    return IcHalApiShowRxCarrCfg(difChan);
}

#endif

UINT32 BspHalAdaptSetTsgTdmInfo(T_TsgTdmInfo *ptTdmInfo)
{
    UINT32 retVal = BSP_OK;

    INPUT_POINTER_CHECK(ptTdmInfo);
    retVal = IcHalApiSetTsgTdmInfo(ptTdmInfo);
    return retVal;
}



UINT32 BspHalAdaptSetTsgSelfTestInfo(T_TsgSelfTestInfo *ptSelfTestInfo)
{
    UINT32 retVal = BSP_OK;
    
    INPUT_POINTER_CHECK(ptSelfTestInfo);
    retVal = IcHalApiSetTsgSelfTestInfo(ptSelfTestInfo);
    return retVal;
}
/**************************************************************************
                            场景预置相关接口
**************************************************************************/
UINT32 BspHalAdaptCfgPreAllocSence(T_BspHalAdaptPreAllocCarrInfo *ptPreAlloc)
{
    UINT32 retVal = BSP_OK;
    INPUT_POINTER_CHECK(ptPreAlloc);
    retVal = IcHalApiOptResPreAllocIdx(ptPreAlloc->senceType);
    return retVal;
}
UINT32 BspHalAdaptCfgPreAllocCarrMap(T_BspHalAdaptAllChanCarrMapRet *ptPreAlloc,UINT32 num)
{
    UINT32 retVal = BSP_OK;
    /*T_PreAlloc *pPreAlloc = NULL;*/
    INPUT_POINTER_CHECK(ptPreAlloc);
#if 0
    /* 暂定最大值为8，待友安后续确认修改 */
     if(num >= 8)
    {
        dbgErr("%s can't accept num of bigger than 8! num[%d]\n", __FUNCTION__, num);
        return BSP_ERROR;
    }
    pPreAlloc = (T_PreAlloc*)malloc(sizeof(T_PreAlloc)*num);
    if(NULL == pPreAlloc)
    {
        dbgErr("%s pPreAlloc malloc failed!\n", __FUNCTION__);
        return BSP_ERROR;
    }
    memset(pPreAlloc, 0, sizeof(T_PreAlloc)*num);
    /* 目前实际使用中，num为1,如果num非1的场景下，如何赋值，待友安后续确认修改 */
    (void)memcpy_s(&(pPreAlloc[0].preAllocInfo), sizeof(T_PreAllocBwInfo), &(ptPreAlloc->preAllocBwInfo), sizeof(T_BspHalAdaptPreAllocBwInfo));
    retVal = IcHalApiCfgPreAlloc(pPreAlloc, dir, num);
    free(pPreAlloc);
#endif
    return retVal;
}

/****************************************************************
* 函数名称: BspHalAdaptGetPreAllocSenceInfo
* 函数说明：获取底层的预制场景数组
* 输入参数：
* 输出参数：
* 返回参数：BSP_OK,  BSP_ERROR
* 修改说明：
*     10294055   创建
*
*****************************************************************/
/*将底层hal场景预制数组　　改成统一结构　TNR FNR LTE顺序进行资源信息摆放*/
UINT32 BspHalAdaptGetPreAllocSenceList(T_BspHalAdaptOptPreAllocInfo **ptAllocList,UINT32 *preAllocNum)
{
    UINT32 ret = BSP_OK;
    T_PreAllocInfo *pPreAllocList= NULL;

    INPUT_POINTER_CHECK(ptAllocList);
    INPUT_POINTER_CHECK(preAllocNum);

    ret =  IcHalApiGetPreAllocBwInfo(&pPreAllocList, preAllocNum);
    if(BSP_OK == ret)
    {
        *ptAllocList = (T_BspHalAdaptOptPreAllocInfo *)pPreAllocList;
    }
    return ret;
}

UINT32 BspHalAdaptClrPreAlloc(void)
{
    UINT32 retVal = BSP_OK;
    retVal = IcHalApiOptCellClr();  /*清除小区*/
    retVal |= IcHalApiOptClrPreAlloc();
    return retVal;
}

UINT32 BspHalAdaptGetPreAllocCarrMapResult(T_CellCarrInfo* appCarrCfg, T_BspHalAdaptPreAllocCarrInfo* preAllocBwInfo, T_PreAllocCarrResult* presetCarrMapRet)
{
    UINT32 retVal = BSP_OK;
    return retVal;
}
UINT32 BspHalAdaptSetResPreAllocPara(UINT32 uCprType, UINT32 uAntMask)
{
    UINT32 retVal = BSP_OK;

    /* 组网模式为环网 */
    /*UINT32 uAntNum = 0;
    UINT32 ulNetWork = 0;
    uAntNum  = GetMaskBitNum(uAntMask);*/

    retVal = IcHalSetResPreAllocPara(uCprType,uAntMask);

    /*ulNetWork = IcHalApiGetFDDRingMode();*/
    if(E_OPT_MODE_QCELL != IcHalGetOptWorkMode())
    {
        retVal |= IcHalSetIf1DlyPos((UINT32)E_OPT_IF1_DLY_POS_BIF);
    }
    else
    {
        retVal |= IcHalSetIf1DlyPos((UINT32)E_OPT_IF1_DLY_POS_DIF);
    }
    return retVal;
}

UINT32 BspHalAdaptTdmMapCfg(VOID)
{
    UINT32 retVal = BSP_OK;
    retVal = IcHalApiTdmMapCfg();
    return retVal;
}
UINT32 BspHalAdaptSetTaMode(UINT32 uTaMode) /*0-150 1-250*/
{
    UINT32 retVal = BSP_OK;
    retVal = IcHalApiSetTaMode(uTaMode);
    return retVal;
}

/**************************************************************************
                            功率控制相关接口
**************************************************************************/
UINT32 BspHalAdaptReadBbTssiPow(UINT32 difChan, UINT32 carrIndex, UINT32 radioMode, INT32 *pBbTssi)
{
    UINT32 retVal = BSP_OK;
    INT32 bbTssiAvg = 0;
    INT32 bbTssiMax = 0;
    INT32 bbTssiAvgDbfs = 0;
    INT32 bbTssiMaxDbfs = 0;
    INPUT_POINTER_CHECK(pBbTssi);
    retVal = IcHalApiReadDtssiPow(difChan,carrIndex,radioMode,&bbTssiAvg,&bbTssiAvgDbfs,&bbTssiMax,&bbTssiMaxDbfs);
    *pBbTssi = bbTssiAvgDbfs;
    return retVal;
}

UINT32 BspHalAdaptGetDtssiErrorFlag(UINT32 difChan, UINT32 carrIndex, UINT32 radioMode, UINT32 *puiErrorFlag)
{
    return IcHalApiGetDtssiErrorFlag(difChan, carrIndex, radioMode, puiErrorFlag);
}

UINT32 BspHalAdaptDtssiErrorClr(UINT32 difChan, UINT32 carrIndex, UINT32 radioMode)
{
    return IcHalApiSetDtssiErrorClr(difChan, carrIndex, radioMode);
}

UINT32 BspHalAdaptReadRssiPowValue(UINT32 difChan, UINT32 carrIndex, UINT32 radioMode, UINT32 slotId, UINT32 uiRssiType, INT32 *pRssiPow)
{
    UINT32 retVal = BSP_OK;
    UINT32 rssiType = 1;
    INPUT_POINTER_CHECK(pRssiPow);
    if(uiRssiType == 1)
    {
        rssiType = 0;
    }
    IcHalApiReadRssiPow(difChan,carrIndex,radioMode,slotId,rssiType,pRssiPow);
    return retVal;
}

UINT32 BspHalAdaptPowCalcInit(T_BspHalAdaptPowChk *tPowChkCfg)
{
    UINT32 retVal = BSP_OK;
    INPUT_POINTER_CHECK(tPowChkCfg);
    retVal = IcHalApiPowChkInit((T_PowChk_Cfg*) tPowChkCfg);
    return retVal;
}

UINT32 BspHalAdaptGsmPowCalcInit(T_BspHalAdaptGsmPowChk *tPowChkCfg)
{
    UINT32 retVal = BSP_OK;
    INPUT_POINTER_CHECK(tPowChkCfg);
    retVal = IcHalApiSetGsmRssiCfg((T_GsmRssiCfg*) tPowChkCfg);
    return retVal;
}

static VOID BspFillIcHalPowCfg(T_Pow *ptSrc,  T_BspHalAdaptPowCfg*ptDest)
{
    ptDest->tssiPow = ptSrc->iTssiAvg;
    ptDest->fwdPow = ptSrc->iFwdAvg;
    return;
}
#if 0
UINT32 BspHalAdaptReadBbPcFwdPow(UINT32 difChan, UINT32 carrIndex, UINT32 radioMode, T_BspHalAdaptPowCfg *pBbPcPowCfg)
{
    UINT32 retVal = BSP_OK;
    T_Pow pcFwd;
    INPUT_POINTER_CHECK(pBbPcPowCfg);
    memset(&pcFwd, 0, sizeof(T_Pow));
    retVal = IcHalApiReadBbPcFwdPow(difChan, carrIndex, radioMode, &pcFwd);
    BspFillIcHalPowCfg(&pcFwd, pBbPcPowCfg);
    return retVal;
}
#endif
UINT32 BspHalAdaptReadFwdIfPow(UINT32 difChan, T_BspHalAdaptPowCfg *pFwdIfPowCfg)
{
    UINT32 retVal = BSP_OK;
    T_Pow fwd;
    INPUT_POINTER_CHECK(pFwdIfPowCfg);
    memset(&fwd, 0, sizeof(T_Pow));
    retVal = IcHalApiReadFwdIfPow(difChan, &fwd);
    BspFillIcHalPowCfg(&fwd, pFwdIfPowCfg);
    return retVal;
}

UINT32 BspHalAdaptReadRevIfPow(UINT32 difChan, T_BspHalAdaptPowCfg *pRevIfPowCfg)
{
    UINT32 retVal = BSP_OK;
    T_Pow rev;
    INPUT_POINTER_CHECK(pRevIfPowCfg);
    memset(&rev, 0, sizeof(T_Pow));
    retVal = IcHalApiReadRevIfPow(difChan, &rev);
    BspFillIcHalPowCfg(&rev, pRevIfPowCfg);
    return retVal;
}

UINT32 BspHalAdaptSetIfTssiPwrClr(UINT32 uiDifChan)
{
    UINT32 retVal    = BSP_OK;

    retVal |= IcHalApiSetIfTssiPwrClr(uiDifChan, 0);
    retVal |= IcHalApiSetIfTssiPwrClr(uiDifChan, 1);
    retVal |= IcHalApiSetIfTssiPwrClr(uiDifChan, 0);

    return retVal;
}

/* 切换RSSI长时检测时长 */
UINT32 BspHalAdaptSetLongRssiGroup(UINT32 state)
{
    UINT32 retVal = BSP_OK;

    retVal |= IcHalSetLongRssiGroup(state);

    return retVal;
}

 /** UMTS上行陷波点来源扫频API接口 */
UINT32 BspHalAdaptSetNbicSwitch(UINT32 difChan, UINT32 carrIndex, UINT32 radioMode, UINT32 sw)
{
    UINT32 retVal = BSP_OK;

    retVal = IcHalApiSetNbicSwitch(difChan, carrIndex, radioMode, sw);

    return retVal;
}

/** UMTS上报NBIC开关接口 */
UINT32 BspHalAdaptGetNbicSwitch(UINT32 difChan, UINT32 carrIndex, UINT32 radioMode, UINT32 *pSw)
{
    UINT32 retVal = BSP_OK;

    INPUT_POINTER_CHECK(pSw);
    retVal = IcHalApiGetNbicSwitch(difChan, carrIndex, radioMode, pSw);

    return retVal;
}

/** 设置UMTS上行NBIC功率门限,单位0.01db */
UINT32 BspHalAdaptSetNbicPowThr(UINT32 uiPowThr)
{
    UINT32 retVal = BSP_OK;

    retVal = IcHalApiSetNbicPowThr(uiPowThr);

    return retVal;
}
/*UMTS NBIC均值累加清零 光口从断链到建链中间调用一次*/
UINT32 BspHalAdaptSetNbicAccClr(VOID)
{
    return IcHalApiSetNbicAccClr();
}
/** UMTS增强型NBIC采数上报API接口 */
UINT32 BspHalAdaptGetNbicIq(UINT32 difChan, UINT32 carrIndex, UINT32 radioMode, UINT32 len, UINT32 *iqArray)
{
    UINT32 retVal = BSP_OK;

    INPUT_POINTER_CHECK(iqArray);
    retVal = IcHalApiGetNbicIq(difChan, carrIndex, radioMode, len, iqArray);

    return retVal;
}    

UINT32 BspHalAdaptOptRptFrAlmCnt(UINT32 ulLogOptNo)
{
    return IcHalApiOptRptFrAlmCnt(ulLogOptNo);
}

#if 0
/*IC4.2 无PC功率*/
UINT32 BspHalAdaptReadPcFwdIfPow(UINT32 difChan, T_BspHalAdaptPowCfg *pPcFwdIfPow)
{
    UINT32 retVal = BSP_OK;
    T_Pow pcFwd;
    INPUT_POINTER_CHECK(pPcFwdIfPow);
    memset(&pcFwd, 0, sizeof(T_Pow));
    retVal = IcHalApiReadPcFwdIfPow(difChan, &pcFwd);
    BspFillIcHalPowCfg(&pcFwd, pPcFwdIfPow);
    return retVal;
}

UINT32 BspHalAdaptReadPcRevIfPow(UINT32 difChan, T_BspHalAdaptPowCfg *pPcRevIfPow)
{
    UINT32 retVal = BSP_OK;
    T_Pow pcRev;
    INPUT_POINTER_CHECK(pPcRevIfPow);
    memset(&pcRev, 0, sizeof(T_Pow));
    retVal = IcHalApiReadPcRevIfPow(difChan, &pcRev);
    BspFillIcHalPowCfg(&pcRev, pPcRevIfPow);
    return retVal;
}

/*未调用*/
UINT32 BspHalAdaptReadSplitBbPcFwdPow(UINT32 difChan, UINT32 carrIndex, UINT32 radioMode, T_BspHalAdaptCarrPowCfg *pcFwdPowCfg[BSP_TX_CARR_SPLIT_NUM], UINT32 *pCarrNum)
{
    UINT32 retVal = BSP_OK;
    INPUT_POINTER_CHECK(pcFwdPowCfg);
    INPUT_POINTER_CHECK(pCarrNum); 
    retVal = IcHalApiReadSplitBbPcFwdPow(difChan, carrIndex, radioMode, (T_HalCarrPow**)pcFwdPowCfg, pCarrNum);
    return retVal;
}

/*未调用*/
UINT32 BspHalAdaptReadSplitRssiPow(UINT32 difChan, UINT32 carrIndex, UINT32 radioMode, T_BspHalAdaptCarrPowCfg *pRssiPowCfg[BSP_RX_CARR_SPLIT_NUM], UINT32 *pCarrNum)
{
    UINT32 retVal = BSP_OK;
    INPUT_POINTER_CHECK(pRssiPowCfg);
    INPUT_POINTER_CHECK(pCarrNum);
    retVal = IcHalApiReadSplitRssiPow(difChan, carrIndex, radioMode, (T_HalCarrPow**)pRssiPowCfg, pCarrNum);
    return retVal;
}

UINT32 BspHalAdaptInitVga(T_BspHalAdaptVgaCtrlRfGain *ptVgaGain)
{
    UINT32 retVal = BSP_OK;
    INPUT_POINTER_CHECK(ptVgaGain);
    // retVal = IcHalApiInitVga((T_VgaCtrlRfGain*) ptVgaGain);
    return retVal;
}

UINT32 BspHalAdaptInitVagAgc(T_BspHalAdaptVgaCtrlComPara* vgaCtrlPara, T_BspHalAdaptVgaCompPara* vgaCommPara)
{
    return IcHalApiInitVagAgc((T_VgaCtrlComPara*)vgaCtrlPara, (T_VgaCompPara*)vgaCommPara);
}

UINT32 BspHalAdaptInitVgaAgcPara(T_BspHalAdaptVgaAgcPara *ptVgaAgc)
{
    UINT32 retVal = BSP_OK;
    INPUT_POINTER_CHECK(ptVgaAgc);
    // retVal = IcHalApiInitVagAgcPara((T_VgaAgcPara*) ptVgaAgc);
    return retVal;
}

/* 根据光口GSCN和SSB,更新NR功率计算的符号位置 */
UINT32 BspHalAdaptSetTssiSubFramePos(VOID)
{
    return IcHalApiSetTssiSubFramePos();
}
#endif
/*--------------------------联合采数-------------------------*/
UINT32 BspHalAdaptSamplePowDetParaCfg(UINT32 powThrMin, UINT32 powDataLen, UINT32 timeMiniLen)
{
    return IcHalApiSamplePowDetParaCfg(powThrMin, powDataLen, timeMiniLen);
}

UINT32 BspHalAdaptSetPowThrodCfg(UINT32 difChan, UINT32 carrNo, UINT32 radioMode, UINT32 powPosition, UINT32 powMaxThrod)
{
    return IcHalApiSetPowThrodCfg(difChan, carrNo, radioMode, powPosition, powMaxThrod);
}

UINT32 BspHalAdaptPowThrodStart(UINT32 powPosition)
{
    return IcHalApiPowThrodStart(powPosition);
}

UINT32 BspHalAdaptPowThrodIsDone(UINT32 powPosition,UINT32 *pFlag)
{
    return IcHalApiPowThrodIsDone(powPosition,pFlag);
}

UINT32 BspHalAdaptPowThrodEnd(UINT32 powPosition)
{
    return IcHalApiPowThrodEnd(powPosition);
}

UINT32 BspHalAdaptUnionSampleCfg(VOID)
{
    return IcHalUnionSampleCfg();
}

UINT32 BspHalAdaptUpCombSmpDataL2dStart(UINT32 uCellId, UINT32 uDir,UINT32 uAnt, UINT32 uDifOrGfTmp, UINT32 uSlot, UINT32 uStartSym, UINT32 uSymbNum)
{
    return IcHalApiUpCombSmpL2dStart(uCellId, uDir, uAnt, uDifOrGfTmp, uSlot, uStartSym, uSymbNum);
}

UINT32 BspHalAdaptUpCombSmpDataL2dSave(UINT32 uCellId, UINT32 uDifOrGfTmp)
{
    return IcHalApiUpCombSmpL2dSave(uCellId, uDifOrGfTmp);
}

UINT32 BspHalAdaptSetGsmPowLevel(UINT32 difChan, UINT32 carrIndex, UINT32 PowLevel)
{
    UINT32 ret = BSP_OK;
    UINT32 radio = BSP_RADIO_STANDARD_GSM;
    ret = IcHalApiSetGsmPowLevel(difChan, carrIndex, radio, PowLevel);
    return ret;
}

UINT32 BspHalAdaptGetGsmPowLevel(UINT32 difChan, UINT32 carrIndex, UINT32 radioMode, UINT32 *puiPowLevel)
{
    UINT32 retVal = BSP_OK;

    INPUT_POINTER_CHECK(puiPowLevel);
    retVal = IcHalApiGetGsmPowLevel(difChan, carrIndex, radioMode, puiPowLevel);

    return retVal;
}

UINT32 BspHalAdaptGetCfrSwitch(UINT32 difChn, UINT32 *CfrOnOff)
{
    UINT32 retVal = BSP_OK;
    UINT32 freqBand = 0;

    INPUT_POINTER_CHECK(CfrOnOff);
    retVal = IcHalApiGetCfrSwitch(difChn, freqBand, CfrOnOff);

    return retVal;
}



#if 0

/**************************************************************************
                            J204c相关接口
**************************************************************************/
#define J204C_SERDES_LANE_MAX (32)
#define J204C_PER_BLOCK_LANE_MAX (16)
#define J204C_PER_BLOCK_LANEMASK (0xFFFF)

/*
J204 上行和反馈lane和Serdes lane的对应关系
204inf0:
serdes lane 0、2、8、10为ul0-3
serdes lane 4、6、12、14为fb0-3
j204inf1:
serdes lane 16、18、24、26为ul4-7
serdes lane 20、22、28、30为fb4-7
*/
UINT32 j204cRxLane2SerdesLaneMap[J204C_SERDES_LANE_MAX] = 
{0,2,8,10,16,18,24,26,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};

UINT32 j204cFbLane2SerdesLaneMap[J204C_SERDES_LANE_MAX] = 
{4,6,12,14,20,22,28,30,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};

UINT32 BspHalAdaptJ204GetSerdesLaneMask(UINT32 dir, UINT32 j204LaneMask)
{
    UINT32 index = 0;
    UINT32 serdesLaneMask = 0;

    if(TX == dir)
    {
        return j204LaneMask;
    }
    
    for(index=0; index<J204C_SERDES_LANE_MAX; index++)
    {
        if(j204LaneMask & (0x01<<index))
        {
            if(RX == dir)
            {
                serdesLaneMask |= (0x01 << j204cRxLane2SerdesLaneMap[index]);
            }
            else if(PRX == dir)
            {
                serdesLaneMask |= (0x01 << j204cFbLane2SerdesLaneMap[index]);
            }
            else {}
        }
    }
    return serdesLaneMask;
}

#if 0
UINT32 j204cRxLaneMap[J204C_SERDES_LANE_MAX] =
{
    //serdes lane     0,    1,    2,    3,    4,    5,    6,    7,    8,    9,    10,   11,   12,   13,   14,   15,
    /*J204C rx lane*/ 0,    1,    2,    3,    0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF,\
    //serdes lane     16,   17,   18,   19,   20,   21,   22,   23,   24,   25,   26,   27,   28,   29,   30,   31
    /*J204C rx lane*/ 4,    5,    6,    7,    0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF 
};

UINT32 j204cFbLaneMap[J204C_SERDES_LANE_MAX] =
{
    //serdes lane     0,    1,    2,    3,    4,    5,    6,    7,    8,    9,    10,   11,   12,   13,   14,   15,
    /*J204C fb lane*/ 0xFF, 0xFF, 0xFF, 0xFF, 0,    1,    2,    3,    0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF,\
    //serdes lane     16,   17,   18,   19,   20,   21,   22,   23,   24,   25,   26,   27,   28,   29,   30,   31
    /*J204C fb lane*/ 0xFF, 0xFF, 0xFF, 0xFF, 4,    5,    6,    7,    0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF 
};
#endif

static UINT32 GetJ204CBlockIdByJ204LaneMask(UINT32 dir, UINT32 laneIdMask)
{
    UINT32 blockId = 0;
    UINT32 serdesLaneMask = 0;

    serdesLaneMask = BspHalAdaptJ204GetSerdesLaneMask(dir, laneIdMask);
    
    if(serdesLaneMask & J204C_PER_BLOCK_LANEMASK)
    {
        blockId = 0;
        return blockId; 
    }
    if((serdesLaneMask>>J204C_PER_BLOCK_LANE_MAX)&J204C_PER_BLOCK_LANEMASK)
    {
        blockId = 1;
        return blockId;        
    }
    return blockId;
}

UINT32 BspHalAdaptJ204cSerdesLoadFrmware(UINT32 laneIdMask, UINT32 txDataRate, UINT32 rxDataRate)
{
    return IcHalApiJ204SdsLoadFw(laneIdMask, txDataRate, rxDataRate,(BOOL)1);
}

UINT32 BspHalAdaptJ204SerdesPhyApbRst(UINT32 txLaneIdMask,UINT32 rstFlag)
{
    UINT32 retVal = BSP_OK;
    UINT32 blockId = 0;

    blockId = GetJ204CBlockIdByJ204LaneMask(TX,txLaneIdMask);
    retVal = IcHalApiPhyApbResetCfg(blockId, rstFlag);
    return retVal;
}

UINT32 BspHalAdaptJ204cSerdesPowerOn(UINT32 dir, UINT32 laneIdMask)
{
    if(TX == dir)
    {
        return IcHalApiJ204SdsTxPwron(laneIdMask);
    }
    else if(RX == dir)
    {
        return IcHalApiJ204SdsRxPwron(laneIdMask);
    }
    else 
    {
        return BSP_ERROR;
    }
    return BSP_OK;    
}

UINT32 BspHalAdaptJ204cSerdesPowerDown(UINT32 dir, UINT32 laneIdMask)
{
    if(TX == dir)
    {
        return IcHalApiJ204SdsTxPwrDn(laneIdMask);
    }
    else if(RX == dir)
    {
        return IcHalApiJ204SdsRxPwrDn(laneIdMask);
    }
    else 
    {
        return BSP_ERROR;
    }
    return BSP_OK;    
}

UINT32 BspHalAdaptJ204cSerdesInit(UINT32 dir, UINT32 laneIdMask, UINT32 dataRate)
{
    if(TX == dir)
    {
        return IcHalApiJ204SdsTxDataEn(laneIdMask,1);
    }
    else if(RX == dir)
    {
        return IcHalApiJ204SdsRxDataEn(laneIdMask,1);
    }
    else 
    {
        return BSP_ERROR;
    }
    return BSP_OK;
}

UINT32 BspHalAdaptJ204cSerdesTrxEn(UINT32 dir, UINT32 laneIdMask, UINT32 en)
{
    if(TX == dir)
    {
        return IcHalApiJ204SdsTxDataEn(laneIdMask,en);
    }
    else if(RX == dir)
    {
        return IcHalApiJ204SdsRxDataEn(laneIdMask,en);
    }
    else 
    {
        return BSP_ERROR;
    }
    return BSP_OK;
}

UINT32 BspHalAdaptAdjustJ204SerdesTxEq(UINT32 laneIdMask,UINT32 eqPre,UINT32 eqPost,UINT32 eqMain)
ICHAL_ADAPT_FUNC_DEF(AdjustJ204SerdesTxEq,laneIdMask,eqPre,eqPost,eqMain)

UINT32 BspHalAdaptJ204LinkInit(UINT32 dir, UINT32 laneIdMask, UINT32 *pLinkInfo, UINT32 linkSize)
{
    UINT32 retVal = BSP_OK;
    UINT32 blockId = 0;
    INPUT_POINTER_CHECK(pLinkInfo)

    blockId = GetJ204CBlockIdByJ204LaneMask(dir,laneIdMask);
    retVal = IcHalApiJ204LinkInit(blockId, pLinkInfo, linkSize);
    return retVal;
}

UINT32 BspHalAdaptJ204MapInit(UINT32 dir, UINT32 laneIdMask, UINT32 *pMapInfo, UINT32 mapSize)
{
    UINT32 retVal = BSP_OK;
    UINT32 blockId = 0;
    INPUT_POINTER_CHECK(pMapInfo)

    blockId = GetJ204CBlockIdByJ204LaneMask(dir,laneIdMask);
    retVal = IcHalApiJ204MapInit(blockId, pMapInfo, mapSize);
    return retVal;
}

UINT32 BspHalAdaptCrmJ204SetResetLogic(UINT32 dir, UINT32 laneIdMask, UINT32 rstFlag)
{
    UINT32 retVal = BSP_OK;
    UINT32 blockId = 0;
    UINT32 chip = 0;
    blockId = GetJ204CBlockIdByJ204LaneMask(dir,laneIdMask); 
    
    if(TX == dir)
    {
        retVal = IcHalApiCrmJ204SetResetDLMapSmp(chip, blockId, rstFlag);
    }
    else if(RX == dir)
    {
        retVal = IcHalApiCrmJ204SetResetULMapSmp(chip, blockId, rstFlag);
    }
    else if(PRX == dir)
    {
        retVal = IcHalApiCrmJ204SetResetFBMapSmp(chip, blockId, rstFlag);
    }    
    else 
    {
        return BSP_ERROR;
    }
    return retVal;    
}

UINT32 BspHalAdaptCrmJ204SetResetApb(UINT32 dir, UINT32 laneIdMask, UINT32 rstFlag)
{
    UINT32 retVal = BSP_OK;
    UINT32 blockId = 0;
    UINT32 chip = 0;
    blockId = GetJ204CBlockIdByJ204LaneMask(dir,laneIdMask); 

    if(TX == dir)
    {
        retVal = IcHalApiCrmJ204SetResetDLApb(chip, blockId, rstFlag);
    }
    else if(RX == dir)
    {
        retVal = IcHalApiCrmJ204SetResetULApb(chip, blockId, rstFlag);
    }
    else if(PRX == dir)
    {
        retVal = IcHalApiCrmJ204SetResetFBApb(chip, blockId, rstFlag);
    }    
    else 
    {
        return BSP_ERROR;
    }
    return retVal;      
}

UINT32 BspHalAdaptCrmJ204SetResetWorkMap(UINT32 dir, UINT32 laneIdMask, UINT32 rstFlag)
{
    UINT32 retVal = BSP_OK;
    UINT32 blockId = 0;
    UINT32 chip = 0;
    blockId = GetJ204CBlockIdByJ204LaneMask(dir,laneIdMask); 

    if(TX == dir)
    {
        retVal = IcHalApiCrmJ204SetResetDLMapWork(chip, blockId, rstFlag);
    }
    else if(RX == dir)
    {
        retVal = IcHalApiCrmJ204SetResetULMapWork(chip, blockId, rstFlag);
    }
    else if(PRX == dir)
    {
        retVal = IcHalApiCrmJ204SetResetFBMapWork(chip, blockId, rstFlag);
    }    
    else 
    {
        return BSP_ERROR;
    }
    return retVal;
}

UINT32 BspHalAdaptCrmJ204SetResetWorkLane(UINT32 dir, UINT32 laneIdMask, UINT32 rstFlag)
{
    UINT32 retVal = BSP_OK;
    UINT32 blockId = 0;
    UINT32 chip = 0;
    
    blockId = GetJ204CBlockIdByJ204LaneMask(dir,laneIdMask); 
    
    if(TX == dir)
    {
        laneIdMask = laneIdMask >> (blockId * 16);
        retVal = IcHalApiCrmJ204SetResetDLLinkLane(chip, blockId, laneIdMask, rstFlag);
    }
    else if(RX == dir)
    {
        laneIdMask = laneIdMask >> (blockId * 4);
        retVal = IcHalApiCrmJ204SetResetULLinkLane(chip, blockId, laneIdMask, rstFlag);
    }
    else if(PRX == dir)
    {
        laneIdMask = laneIdMask >> (blockId * 4);
        retVal = IcHalApiCrmJ204SetResetFBLinkLane(chip, blockId, laneIdMask, rstFlag);
    }    
    else 
    {
        return BSP_ERROR;
    }
    return retVal;    
}

UINT32 BspHalAdaptCrmJ204SetResetRf(UINT32 dir, UINT32 laneIdMask, UINT32 rstFlag)
{
    UINT32 retVal = BSP_OK;
    UINT32 blockId = 0;
    UINT32 chip = 0;
    
    blockId = GetJ204CBlockIdByJ204LaneMask(dir,laneIdMask); 
    
    if(TX == dir)
    {
        return BSP_ERROR;
    }
    else if(RX == dir)
    {
        retVal = IcHalApiCrmJ204SetResetULRf(chip, blockId, rstFlag);
    }
    else if(PRX == dir)
    {
        return BSP_ERROR;
    }    
    else 
    {
        return BSP_ERROR;
    }
    return retVal;    

}

UINT32 BspHalAdaptSysrefRequest(T_BspHalAdaptSysrefCfg *pSysrefCfg)
{
    UINT32 pinId = 0;
    UINT32 retVal = BSP_OK;
    UINT32 txEnMask = 0;
    UINT32 loop = 0;
    T_DifSysrefCfg halSysrefCfg;
    INPUT_POINTER_CHECK(pSysrefCfg);

    memset(&halSysrefCfg, 0, sizeof(T_DifSysrefCfg));

    for(loop=0; loop<IC4_HALADAPT_TRANS_MAX_NUM; loop++)
    {
        if((0x1<<loop) & pSysrefCfg->tsEnable)
        {
            BspHalAdaptGetTrxPinId(loop, &pinId);
            txEnMask |= (0x1<<pinId);
            dbgInfoEx("%s chip=%d pinId=%d txEnMask=%#x\n", __func__, loop, pinId, txEnMask);
        }
    }
    
    halSysrefCfg.uiSysrefEn = pSysrefCfg->sysrefEn;
    halSysrefCfg.uiTsEnable= txEnMask;
    halSysrefCfg.uiMode = pSysrefCfg->mode;
    halSysrefCfg.uiSysrefNum = pSysrefCfg->sysrefNum;
    retVal = IcHalApiSysrefRequest(&halSysrefCfg);
    return retVal;
}

UINT32 BspHalAdaptSysrefGenerate(T_BspHalAdaptSysrefCfg *pSysrefCfg)
{
    UINT32 retVal = BSP_OK;
    T_DifSysrefGenCfg halSysrefGenCfg;
    INPUT_POINTER_CHECK(pSysrefCfg);
    
    memset(&halSysrefGenCfg, 0, sizeof(T_DifSysrefGenCfg));
    halSysrefGenCfg.uiSysrefFrDelay = pSysrefCfg->sysrefFrDelay;
    halSysrefGenCfg.uiLocalcntSyncEn = pSysrefCfg->localcntSyncEn;
    halSysrefGenCfg.uiSyncSrc = pSysrefCfg->syncSrc;
    halSysrefGenCfg.uiPrd = pSysrefCfg->period;
    halSysrefGenCfg.uiWidth = pSysrefCfg->width;
    halSysrefGenCfg.uiSysPha = pSysrefCfg->sysPha;
    halSysrefGenCfg.uiIsExtSysref = pSysrefCfg->isExtSysref;
    retVal = IcHalApiSysrefGenerate(&halSysrefGenCfg);
    return retVal;
}

UINT32 BspHalAdaptGetSysrefStatus(UINT32 dir, UINT32 laneIdMask)
{
    UINT32 retVal = BSP_OK;
    UINT32 blockId = 0;
    blockId = GetJ204CBlockIdByJ204LaneMask(dir,laneIdMask); 

    if(TX == dir)
    {
        retVal = IcHalApiGetDlSysrefStatus(blockId);
    }
    else if(RX == dir)
    {
        retVal = IcHalApiGetUlSysrefStatus(blockId);
    }
    else if(PRX == dir)
    {
        retVal = IcHalApiGetFbSysrefStatus(blockId);
    }    
    else 
    {
        return BSP_ERROR;
    }
    return retVal;        
}

UINT32 BspHalAdaptClrSysrefStatus(UINT32 dir,UINT32 laneIdMask)
{
    UINT32 retVal = BSP_OK;
    UINT32 blockId = 0;
    blockId = GetJ204CBlockIdByJ204LaneMask(dir,laneIdMask); 

    if(TX == dir)
    {
        retVal = IcHalApiClrDlSysrefStatus(blockId);
    }
    else if(RX == dir)
    {
        retVal = IcHalApiClrUlSysrefStatus(blockId);
    }
    else if(PRX == dir)
    {
        retVal = IcHalApiClrFbSysrefStatus(blockId);
    }    
    else 
    {
        return BSP_ERROR;
    }
    return retVal;     
}

UINT32 BspHalAdaptGetJ204State(UINT32 dir, UINT32 laneId, UINT32 *state, UINT32 *regVal)
{
    UINT32 blockId = 0;
    UINT32 j204cLaneId = laneId;
    UINT32 retVal = BSP_OK;

    if(j204cLaneId >= J204C_SERDES_LANE_MAX)
    {
        return BSP_ERROR;
    }
    
    blockId = GetJ204CBlockIdByJ204LaneMask(dir,0x1<<j204cLaneId); 

    //lane0-lane7 -> block0(lane0-lane3)and block1(lane0-lane3)
    if(blockId == 1)
    {
        j204cLaneId = j204cLaneId - 4;
    }    

    if(RX == dir)
    {
        retVal = IcHalApiGetJ204UlState(blockId, j204cLaneId, regVal);
    }
    else if(PRX == dir)
    {
        retVal = IcHalApiGetJ204FbState(blockId, j204cLaneId, regVal);
    }    
    else 
    {
        return BSP_ERROR;
    }

    if(BSP_OK == retVal)
    {
        *state = ((*regVal)==BSP_HALADAPT_J204_LINK_OK_REGVAL)?BSP_HALADAPT_J204_LINK_OK:BSP_HALADAPT_J204_LINK_ERR;        
    }
    
    return retVal;    
}

/* 获取CRC误码数量 */
UINT32 BspHalAdaptGetJ204CrcErrCnt(UINT32 dir, UINT32 laneId, UINT32 *crcErrCnt)
{
    UINT32 blockId = 0;
    UINT32 j204cLaneId = laneId;
    UINT32 retVal = BSP_OK;
    UINT32 regVal = 0;

    if(j204cLaneId >= J204C_SERDES_LANE_MAX)
    {
        return BSP_ERROR;
    }
    
    blockId = GetJ204CBlockIdByJ204LaneMask(dir,0x1<<j204cLaneId); 

    //lane0-lane7 -> block0(lane0-lane3)and block1(lane0-lane3)
    if(blockId == 1)
    {
        j204cLaneId = j204cLaneId - 4;
    }    

    if(RX == dir)
    {
        retVal = IcHalApiGetUlCRCErrCode(blockId, j204cLaneId, &regVal);
    }
    else if(PRX == dir)
    {
        retVal = IcHalApiGetFbCRCErrCode(blockId, j204cLaneId, &regVal);
    }    
    else 
    {
        return BSP_ERROR;
    }

    if(BSP_OK == retVal)
    {
        *crcErrCnt = regVal;        
    }
    
    return retVal;        
}

UINT32 BspHalAdaptSysrefRspEnable(UINT32 dir, UINT32 laneIdMask)
{
    UINT32 retVal = BSP_OK;
    UINT32 blockId = 0;
    blockId = GetJ204CBlockIdByJ204LaneMask(dir,laneIdMask); 

    if(RX == dir)
    {
        /** 重新响应上行sysref*/
        retVal = IcHalApiRspUlSysref(blockId);
    }
    else if(PRX == dir)
    {
        /** 重新响应反馈sysref*/
        retVal = IcHalApiRspFbSysref(blockId);
    }    
    else 
    {
        return BSP_ERROR;
    }

    return retVal;         
}

UINT32 BspHalAdaptGetJ204RegHeadAddr(UINT32 grpId)
{
    if(grpId == 0)
    {
        return 0xc7e00000;
    }
    else if(grpId == 1)
    {
        return 0xce200000;
    }
    else
    {
        return 0;
    }
}

UINT32 BspHalAdaptCrmJ204SetResetAll(UINT32 rstFlag)
{
    return IcHalApiCrmJ204SetResetAll(0, rstFlag);
}
#endif
/**************************************************************************
                            反馈开关控制相关接口
**************************************************************************/
/*反馈电子开关射频表相关参数初始化*/
UINT32 BspHalAdaptCbSwParaInit(UINT32 swIndex,T_BspHalAdaptCbSwPara* ptCbSwPara)
{
    UINT32 ret = BSP_OK;
    INPUT_POINTER_CHECK(ptCbSwPara);
    ret |= IcHalApiSwParaInit(swIndex,ptCbSwPara);
    return ret;
}
/*反馈电子开关状态表初始化*/
UINT32 BspHalAdaptCbSwStaTblInit(UINT32 swIndex, T_BspHalAdaptCbSwStaTbl* ptSwStaTbl, UINT32 len)
{
    UINT32 ret = BSP_OK;
    INPUT_POINTER_CHECK(ptSwStaTbl);
    ret = IcHalApiStaRamInit(swIndex,len,ptSwStaTbl);
    return ret;
}

UINT32 BspHalAdaptCbSwRfTblInit(UINT32 swIndex, UINT32 rfType,T_BspHalAdaptCbSwRfTbl* ptSwRfTbl)
{
    UINT32 ret = BSP_OK;
    INPUT_POINTER_CHECK(ptSwRfTbl);
    ret = IcHalApiRfRamInit(swIndex,rfType,ptSwRfTbl);
    return ret;
}

UINT32 BspHalAdaptCbSwForceModeOn(UINT32 swIndex, UINT32 chan, UINT32 sta, UINT32 period)
{
    UINT32 ret = BSP_OK;
    ret = IcHalApiSetCpuForceOpen(swIndex,chan,sta,period);
    return ret;
}
UINT32 BspHalAdaptCbSwForceModeOff(UINT32 swIndex,UINT32 chan)
{
    UINT32 ret = BSP_OK;
    ret = IcHalApiSetCpuForceOff(swIndex);
    return ret;
}
UINT32 BspHalAdaptCbPinSw(UINT32 pinName, UINT32 sw)
{
    UINT32 ret = BSP_OK;
    ret = IcHalApiPinSw(pinName,sw);
    return ret;
}
#if 0

//剩余八选二开关 2bit控制  是否对funclib可见： 已知chanA chanB  都是按射频通道作为参数
#endif

/**************************************************************************
                            CFR相关接口
**************************************************************************/
#if defined(CFR_REFACTOR)
#else
UINT32 BspHalAdaptSetCfrGate(UINT32 difChn, UINT32 freqBand, UINT32 *pcfrGate, UINT32 gateNum)
{
    UINT32 retVal = BSP_OK;

    INPUT_POINTER_CHECK(pcfrGate);
    retVal =  IcHalApiSetCfrGate(difChn, freqBand, pcfrGate, gateNum);

    return retVal;
}

UINT32 BspHalAdaptGetCfrGate(UINT32 difChn, UINT32 freqBand, UINT32 *pcfrGate, UINT32 gateNum)
{
    UINT32 retVal = BSP_OK;

    INPUT_POINTER_CHECK(pcfrGate);
    retVal =  IcHalApiGetCfrGate(difChn, freqBand, pcfrGate, gateNum);
    
    return retVal;
}


UINT32 BspHalAdaptSetCfrWin(UINT32 difChn, UINT32 freqBand, UINT32 *pcfrWin, UINT32 gateNum)
{
    UINT32 retVal = BSP_OK;

    INPUT_POINTER_CHECK(pcfrWin);
    retVal =  IcHalApiSetCfrWin(difChn, freqBand, pcfrWin, gateNum);

    return retVal;
}

UINT32 BspHalAdaptGetCfrWin(UINT32 difChn, UINT32 freqBand, UINT32 *pcfrWin, UINT32 gateNum)
{
    UINT32 retVal = BSP_OK;

    INPUT_POINTER_CHECK(pcfrWin);
    retVal =  IcHalApiGetCfrWin(difChn, freqBand, pcfrWin, gateNum);

    return retVal;
}

UINT32 BspHalAdaptSetCfrDelt(UINT32 difChn, UINT32 freqBand, UINT32 *pcfrDelt, UINT32 gateNum)
{
    UINT32 retVal = BSP_OK;

    INPUT_POINTER_CHECK(pcfrDelt);
    retVal =  IcHalApiSetCfrDelt(difChn, freqBand, pcfrDelt, gateNum);

    return retVal;
}

UINT32 BspHalAdaptGetCfrDelt(UINT32 difChn, UINT32 freqBand, UINT32 *pcfrDelt, UINT32 gateNum)
{
    UINT32 retVal = BSP_OK;

    INPUT_POINTER_CHECK(pcfrDelt);
    retVal =  IcHalApiGetCfrDelt(difChn, freqBand, pcfrDelt, gateNum);
    
    return retVal;
}

UINT32 BspHalAdaptSetCfrWinlevel(UINT32 difChn, UINT32 freqBand, UINT32 *pcfrWinLevel, UINT32 gateNum)
{
    UINT32 retVal = BSP_OK;

    INPUT_POINTER_CHECK(pcfrWinLevel);
    retVal =  IcHalApiSetCfrWinLevel(difChn, freqBand, pcfrWinLevel, gateNum);

    return retVal;
}

UINT32 BspHalAdaptGetCfrWinlevel(UINT32 difChn, UINT32 freqBand, UINT32 *pcfrWinLevel, UINT32 gateNum)
{
    UINT32 retVal = BSP_OK;

    INPUT_POINTER_CHECK(pcfrWinLevel);
    retVal =  IcHalApiGetCfrWinLevel(difChn, freqBand, pcfrWinLevel, gateNum);
    
    return retVal;
}

UINT32 BspHalAdaptSetCfrSwitch(UINT32 difChn, UINT32 freqBand, UINT32 cfrOnOff)
ICHAL_ADAPT_FUNC_DEF(SetCfrSwitch,difChn, freqBand, cfrOnOff)

/** 设置在线计算BBTSSI相关配置 */
UINT32 BspHalAdaptSetBbTssiCfg(UINT32 difChan)
{
    UINT32 retVal = BSP_OK;

    retVal = IcHalApiSetBbTssiCfg(difChan);

    return retVal;
}

UINT32 BspHalAdaptCfrSetSymstrGsmSel(UINT32 difChan, UINT32 freqBand)
{
    UINT32 retVal = BSP_OK;

    retVal = IcHalApiCfrSetSymstrGsmSel(difChan, freqBand);

    return retVal;
}

/** 设置削峰软硬件计算模式 **/
UINT32 BspHalAdaptCfrSetCpgMode(UINT32 difChan, UINT32 freqBand, UINT32 cpgMode)
{
    UINT32 retVal = BSP_OK;

    retVal = IcHalApiSetCfrCpgMode(difChan, freqBand, cpgMode);

    return retVal;
}

UINT32 BspHalAdaptCfrCommParaCpgInit(T_BspHalAdaptCfrParaHardCpg *pCfrHWCpgPara)
{
    UINT32 retVal = BSP_OK;

    INPUT_POINTER_CHECK(pCfrHWCpgPara);
    retVal = IcHalApiCfrCommParaCpgInit(pCfrHWCpgPara);

    return retVal;
}

UINT32 BspHalAdaptKnWordLutParaInit(T_BspHalAdaptCfrKnWordPara *pCfrKnWordPara)
{
    UINT32 retVal = BSP_OK;

    INPUT_POINTER_CHECK(pCfrKnWordPara);
    retVal = IcHalApiKnWordLutParaInit(pCfrKnWordPara);

    return retVal;
}

UINT32 BspHalAdaptCpgeParaRangeFreqInit(void)
{
    UINT32 retVal = BSP_OK;

    retVal = IcHalApiCpgeParaRangeFreqInit();

    return retVal;
}

UINT32 BspHalAdaptCfrSetCpgGateBypassInit(void)
{
    UINT32 retVal = BSP_OK;

    retVal = IcHalApiCfrSetCpgGateBypassInit();

    return retVal;
}

UINT32 BspHalAdaptDpdParCfgCommParaInit(T_BspHalAdaptDpdParCommPara *pDpdParPara)
{
    UINT32 retVal = BSP_OK;

    INPUT_POINTER_CHECK(pDpdParPara);
    retVal = IcHalApiDpdParCfgCommParaInit(pDpdParPara);

    return retVal;
}

UINT32 BspHalAdaptSetCpgParaRangeCarrInit(void)
{
    UINT32 retVal = BSP_OK;

    retVal = IcHalApiSetCpgParaRangeCarrInit();

    return retVal;
}

UINT32 BspHalAdaptCfrSetFreqWordFsInit(void)
{
    UINT32 retVal = BSP_OK;

    retVal = IcHalApiCfrSetFreqWordFsInit();

    return retVal;
}

/** 设置dlpre内部Ki索引计算功率选择参数（DSS场景）*/
UINT32 BspHalAdaptCfrSetDlpreKiPowSelInit(void)
{
    UINT32 retVal = BSP_OK;

    retVal = IcHalApiCfrSetDlpreKiPowSelInit();

    return retVal;
}

UINT32 BspHalAdaptCfrSetDelay(UINT32 difChn, UINT32 freqBand, T_BspHalAdaptCfrDlyCalcPara *pDlyPara)
{
    UINT32 retVal = BSP_OK;

    INPUT_POINTER_CHECK(pDlyPara);
    retVal =  IcHalApiSetCfrDlyNum(difChn, freqBand, pDlyPara);

    return retVal;
}

 /** 计算每级削峰模块的tddsw扩展*/
UINT32 BspHalAdaptCfrSetTddsw(UINT32 difChan, UINT32 freqBand, T_BspHalAdaptCfrDlyCalcPara *pDlyPara)
{
    UINT32 retVal = BSP_OK;

    retVal = IcHalApiCfrSetTddsw(difChan, freqBand, pDlyPara);

    return retVal;
}

/** cpg系数长度配置的对外接口 */
UINT32 BspHalAdaptCfrSetCpgLen(UINT32 difChan, UINT32 freqBand, UINT32 cpgMaxlen)
{
    UINT32 retVal = BSP_OK;

    retVal = IcHalApiCfrSetCpgLen(difChan, freqBand, cpgMaxlen);

    return retVal;
}

UINT32 BspHalAdaptSetCfrHb1Coef(UINT32 difChn, INT32 *pcfrHb1Coef, UINT32 coefLen)
{
    UINT32 retVal = BSP_OK;
    UINT32 freqBand = 0;
    INPUT_POINTER_CHECK(pcfrHb1Coef);
    retVal =  IcHalApiSetCfrHbf1Coef(difChn, freqBand, pcfrHb1Coef, coefLen);
    return retVal;
}

UINT32 BspHalAdaptSetCfrHb0Coef(UINT32 difChn, INT32 *pcfrHb0Coef, UINT32 coefLen)
{
    UINT32 retVal = BSP_OK;
    UINT32 freqBand = 0;
    INPUT_POINTER_CHECK(pcfrHb0Coef);
    retVal =  IcHalApiSetCfrHbf0Coef(difChn, freqBand, pcfrHb0Coef, coefLen);
    return retVal;
}

UINT32 BspHalAdaptSetCfrOutMode(UINT32 difChn, UINT32 freqBand, UINT32 mode)    \
ICHAL_ADAPT_FUNC_DEF(SetCfrOutMode, difChn, freqBand, mode)

UINT32 BspHalAdaptSetDlyPara(UINT32 difChn, T_BspHalAdaptDlyCfgCfrPara *pDlyPara)
{
    UINT32 retVal = BSP_OK;
    UINT32 freqBand = 0;

    INPUT_POINTER_CHECK(pDlyPara);
    retVal =  IcHalApiSetDlyPara(difChn, freqBand, pDlyPara);

    return retVal;
}

 /** 设置dlpre内部Ki索引载波类型选择信号(dsp单g不迭代功能需要)*/
UINT32 BspHalAdaptSetDlpreKiIndexType(UINT32 difChan)
{
    UINT32 retVal = BSP_OK;

    retVal = IcHalApiSetDlpreKiIndexCaType(difChan);

    return retVal;
}

UINT32 BspHalAdaptCfrParCfgCommParaInit(T_BspHalAdaptCfrParCommPara *pCfrParPara)
{
    UINT32 retVal = BSP_OK;

    INPUT_POINTER_CHECK(pCfrParPara);
    retVal = IcHalApiCfrParCfgCommParaInit(pCfrParPara);

    return retVal;
}

/** CPG在线计算暂停与开启，suspend：0x0：开启；0x1：暂停。*/
UINT32 BspHalAdaptCfrSetCpgSuspend(UINT32 difChn, UINT32 freqBand, UINT32 suspend)
{
    UINT32 retVal = BSP_OK;
    UINT32 cpgMask = 0;

    retVal |= IcHalApiCfrSetCpgSuspend(difChn, freqBand, suspend);

    if (0 == suspend)
    {
        /* 削峰CPG系数硬件计算开始 */
        g_cpgChnStatusMask &= ~(1 << difChn);
    }
    else
    {
        g_cpgChnStatusMask |= (1 << difChn);
    }

    cpgMask = g_cpgChnStatusMask;
    retVal |= IcHalApiSetCpgOnlineStatus(cpgMask);
    dbgInfoEx("[%s] chn:%u, suspend:%u, cpgMask:0x%x \n", __FUNCTION__, difChn, suspend, cpgMask);

    return retVal;
}

/** 每级削峰模块的tddsw扩展初始化清零 */
UINT32 BspHalAdaptCfrSetTddswInit(void)
{
    UINT32 retVal = BSP_OK;

    retVal = IcHalApiCfrSetTddswInit();

    return retVal;
}

UINT32 BspHalAdaptDifCfrParaInit(T_BspHalAdaptDifCommCfrPara *pDifCfrPara)
{
    UINT32 retVal = BSP_OK;

    INPUT_POINTER_CHECK(pDifCfrPara);
    SaveDifCfg(E_DIF_DIFPARA_CFR, (VOID*)pDifCfrPara, 1, 32);
    retVal = IcHalApiCfrCommParaInit(pDifCfrPara);

    return retVal;
}

#endif
UINT32 BspHalAdaptCfrSetCpgTblCfg(UINT32 difchan, UINT32 freqBand, UINT32 *pCoef, UINT32 coefLen)
{
    UINT32 retVal = BSP_OK;

    INPUT_POINTER_CHECK(pCoef);
    retVal =  IcHalApiCfrSetCpgTblCfg(difchan, freqBand, pCoef, coefLen);

    return retVal;
}

UINT32 BspHalAdaptCfrGetCpgTblCfg(UINT32 difchan, UINT32 freqBand, UINT32 *pCoef, UINT32 coefLen)
{
    UINT32 retVal = BSP_OK;

    INPUT_POINTER_CHECK(pCoef);
    retVal =  IcHalApiCfrGetCpgTblCfg(difchan, freqBand, pCoef, coefLen);
    
    return retVal;
}

UINT32 BspHalAdaptSetCfrParCfgFr(UINT32 difChn, UINT32 freqband, UINT32 frDly, UINT32 symParFlagPer, UINT32 frDivSel)
{
    UINT32 retVal = BSP_OK;

    retVal =  IcHalApiSetCfrParCfgFr(difChn, freqband, frDly, symParFlagPer, frDivSel);

    return retVal;
}

UINT32 BspHalAdaptSetDpdParCfgFr(UINT32 difChn, UINT32 freqband, UINT32 frDly, UINT32 symParFlagPer, UINT32 frDivSel)
{
    UINT32 retVal = BSP_OK;

    retVal =  IcHalApiSetDpdParCfgFr(difChn, freqband, frDly, symParFlagPer, frDivSel);

    return retVal;
}

/**********************************************************************
* 函数名称: BspHalAdaptCfrGetPar
* 功能描述: 获取峰均比数据
* 输入参数: difChn：中频通道号
           freqBand：频段号
           peakFlag：检测方式。0：自检包络；1：自检包络+TDD；2：TDD；3：常高，FDD机型设为3。
           workMode：峰值监测模式。0：软件立即启动；1：软件启动后，Fr加延时启动。
           pos：Block级峰值检测位置选择。0：CFR入口；1：CFR出口。
* 输出参数: cfrParData：分支参数
* 返  回  值: BSP_OK/BSP_ERROR
************************************************************************/
UINT32 BspHalAdaptCfrGetPar(UINT32 difChn, UINT32 freqBand, UINT32 peakFlag, UINT32 workMode, UINT32 pos, UINT32 *cfrParData)
{
    UINT32 retVal = BSP_OK;

    INPUT_POINTER_CHECK(cfrParData);
    retVal =  IcHalApiGetCfrPar(difChn, freqBand, peakFlag, workMode, pos, cfrParData);

    return retVal;
}

UINT32 BspHalAdaptDpdGetPar(UINT32 difChn, UINT32 freqBand, UINT32 peakFlag, UINT32 workMode, UINT32 *cfrParData)
{
    UINT32 retVal = BSP_OK;

    INPUT_POINTER_CHECK(cfrParData);
    retVal =  IcHalApiGetDpdPar(difChn, freqBand, peakFlag, workMode, cfrParData);

    return retVal;
}

UINT32 BspHalAdaptCfrSetchnChgHwMask(UINT32 difChnHwMask)
{
    UINT32 retVal = BSP_OK;

    retVal = IcHalApiCfrChangeCfgFreqFlag(difChnHwMask);
    
    return retVal;  
}

UINT32 BspHalAdaptCfrSetGi(UINT32 difChn, UINT32 freqBand, UINT32 carrId, UINT32 carrRadio, UINT32 gi)
{
    UINT32 retVal = BSP_OK;

    retVal = IcHalApiCfrSetGi(difChn, freqBand, carrId, carrRadio, gi);

    return retVal;  
}

UINT32 BspHalAdaptCfrSetOriginCoef(UINT32 difChan, UINT32 carrIndex, UINT32 carrRadio, UINT32 coefLen, const INT32 *pCoefPara)
{
    UINT32 retVal = BSP_OK;

    INPUT_POINTER_CHECK(pCoefPara);
    retVal = IcHalApiCfrSetOriginCoef(difChan, carrIndex, carrRadio, coefLen, pCoefPara);

    return retVal;  
}

UINT32 BspHalAdaptCfrSetcfgFlag(UINT32 difChn, UINT32 freqBand)
{
    UINT32 retVal = BSP_OK;

    retVal = IcHalApiCfrCfgFlag(difChn, freqBand);

    return retVal;  
}

UINT32 BspHalAdaptCfrSetWord(UINT32 difChan, UINT32 freqBand, UINT32 carrIndex, UINT32 carrRadio, UINT32 freqWord)
{
    UINT32 retVal = BSP_OK;

    retVal = IcHalApiCfrSetWord(difChan, freqBand, carrIndex, carrRadio, freqWord);

    return retVal;  
}

UINT32 BspHalAdaptCfrSetDlpreKiIndexDvSel(UINT32 difChan, UINT32 freqBand)
{
    UINT32 retVal = BSP_OK;

    retVal = IcHalApiCfrSetDlpreKiIndexDvSel(difChan, freqBand);

    return retVal;  
}

UINT32 BspHalAdaptCfrSetCpgFreqCalStr(UINT32 difChan, UINT32 freqBand)
{
    UINT32 retVal = BSP_OK;

    retVal = IcHalApiCfrSetCpgFreqCalStr(difChan, freqBand);

    return retVal;  
}

UINT32 BspHalAdaptCfrCleanWord(UINT32 difChan, UINT32 freqBand)
{
    UINT32 retVal = BSP_OK;

    retVal = IcHalApiCfrCleanWord(difChan, freqBand);

    return retVal;  
}

UINT32 BspHalAdaptCfrSetCpgUpdateMode(UINT32 difChan, UINT32 freqBand)
{
    UINT32 retVal = BSP_OK;

    retVal = IcHalApiCfrSetCpgUpdateMode(difChan, freqBand);

    return retVal;  
}

UINT32 BspHalAdaptSetCpgParaRangeCarrNum(void)
{
    UINT32 retVal = BSP_OK;

    retVal = IcHalApiSetCpgParaRangeCarrNum();

    return retVal;  
}

UINT32 BspHalAdaptSetDlpreKiIndexGsm(UINT32 difChan, UINT32 carrIndex, UINT32 carrRadio, UINT32 staPowStepFreq, UINT32 deltPowFreq)
{
    UINT32 retVal = BSP_OK;

    retVal = IcHalApiSetDlpreKiIndexGsm(difChan, carrIndex, carrRadio, staPowStepFreq, deltPowFreq);

    return retVal;  
}

UINT32 BspHalAdaptCfrSetDlpreKiIndexNum(UINT32 difChan, UINT32 freqBand, UINT32 symNum)
{
    UINT32 retVal = BSP_OK;

    retVal = IcHalApiCfrSetDlpreKiIndexNum(difChan, freqBand, symNum);

    return retVal;  
}

/** CPG在线计算有关系数回读 */
UINT32 BspHalAdaptCfrGetCpgOnLine(UINT32 difChan, UINT32 ramType, UINT32 coefMode, UINT32 coefLen)
{
    UINT32 retVal = BSP_OK;

    retVal = IcHalApiCfrGetCpgOnLine(difChan, ramType, coefMode, coefLen);

    return retVal;  
}

/** 漏峰个数统计 */
UINT32 BspHalAdaptCfrLeakPeak(UINT32 difChan, UINT32 clrFlag)
{
    UINT32 retVal = BSP_OK;

    retVal = IcHalApiCfrLeakPeak(difChan, clrFlag);

    return retVal;  
}

/** 获取CPG在线计算gsm有关参数 */
UINT32 BspHalAdaptCfrGetCpgOnLineGsm(UINT32 difChan)
{
    UINT32 retVal = BSP_OK;

    retVal = IcHalApiCfrGetCpgOnLineGsm(difChan);

    return retVal;  
}

/** 获取CPG在线计算偏静态型参数 */
UINT32 BspHalAdaptCfrGetCpgOnLineStatic(UINT32 difChan)
{
    UINT32 retVal = BSP_OK;

    retVal = IcHalApiCfrGetCpgOnLineStatic(difChan);

    return retVal;  
}

/** 获取CPG在线计算stage级参数 */
UINT32 BspHalAdaptCfrGetCpgOnLineStage(UINT32 difChan)
{
    UINT32 retVal = BSP_OK;

    retVal = IcHalApiCfrGetCpgOnLineStage(difChan);

    return retVal;  
}

/** 获取CPG在线计算载波级参数 */
UINT32 BspHalAdaptCfrGetCpgOnLineCarrer(UINT32 difChan)
{
    UINT32 retVal = BSP_OK;

    retVal = IcHalApiCfrGetCpgOnLineCarrer(difChan);

    return retVal;  
}

/** 获取削峰CPG在线计算BBTSSI相关配置 */
UINT32 BspHalAdaptGetBbTssiCfg(UINT32 difChan)
{
    UINT32 retVal = BSP_OK;

    retVal = IcHalApiGetBbTssiCfg(difChan);

    return retVal;  
}

 /** CFR模块双路采数接口*/
UINT32 BspHalAdaptCfrGetSample(UINT32 difChan, UINT32 pos0, UINT32 pos1, UINT32 sampTime, UINT32 trigMode)
{
    UINT32 retVal = BSP_OK;

    retVal = IcHalApiGetCfrSample(difChan, pos0, pos1, sampTime, trigMode);

    return retVal;  
}      

 /** 清零通道内所有gi寄存器 **/
UINT32 BspHalAdaptCfrCleanGi(UINT32 difChan, UINT32 freqBand)
{
    UINT32 retVal = BSP_OK;

    retVal = IcHalApiCfrCleanGi(difChan, freqBand);

    return retVal;  
}

/** 清除原型系数载波信息 **/
UINT32 BspHalAdaptCfrClrOriginCoefCarrInfo(UINT32 difChan, UINT32 freqBand)
{
    UINT32 retVal = BSP_OK;

    retVal = IcHalApiCfrCleanOriginCoefCarrInfo(difChan, freqBand);

    return retVal;  
}

/** 原型系数配置(DSS场景) **/
UINT32 BspHalAdaptDssCfrSetOriginCoef(UINT32 difChan, UINT32 carrIndex, UINT32 carrRadio, UINT32 carrBw, UINT32 coefLen, const INT32 *pCoefPara)
{
    UINT32 retVal = BSP_OK;

    INPUT_POINTER_CHECK(pCoefPara);
    retVal = IcHalApiCfrSetOriginCoef1(difChan, carrIndex, carrRadio, carrBw, coefLen, pCoefPara);

    return retVal;  
}

/*****************************************************************************
*  函数名称   : BspHalAdaptCfrSetDssCarrInfo
*  功能描述   : 设置DSS场景下的载波信息
*  输入参数   : difChn ： 中频通道号
               carrIndex ：DSS中带宽最大载波的载波号
               carrRadio ：DSS中带宽最大载波的制式
               pDssCarrInfo ：DSS中除带宽最大载波外的其余被共享载波
*  输出参数   : 无
*  返 回 值   : BSP_OK  - 成功;其它值为失败
*  其它说明   : 无
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 10307448徐利波@2022-10-25 12:31:41
*----------------------------------------------------------------------------
*/
UINT32 BspHalAdaptCfrSetDssCarrInfo(UINT32 difChan, UINT32 carrIndex, UINT32 carrRadio, T_BspHalAdaptCfrDssCarrInfo *pDssCarrInfo)
{
    UINT32 retVal = BSP_OK;

    INPUT_POINTER_CHECK(pDssCarrInfo);
    retVal = IcHalApiCfrSetDlpreKiPowSel(difChan, carrIndex, carrRadio, pDssCarrInfo);

    return retVal;  
}

/** dlpre内部Ki索引计算功率选择参数配置通道级复位（DSS场景） **/
UINT32 BspHalAdaptCfrCleanDlpreKiPowSel(UINT32 difChan, UINT32 freqBand)
{
    UINT32 retVal = BSP_OK;

    retVal = IcHalApiCfrCleanDlpreKiPowSel(difChan, freqBand);

    return retVal;  
}

 /** 回读每个通道的tddsw扩展配置情况*/
UINT32 BspHalAdaptCfrGetTddsw(UINT32 difChan)
{
    UINT32 retVal = BSP_OK;

    retVal = IcHalApiCfrGetTddsw(difChan);

    return retVal;  
}

/** CFR模块节能初始化配置 */
UINT32 BspHalAdaptCfrSetEnergyInit(void)
{
    UINT32 retVal = BSP_OK;

    retVal = IcHalApiCfrSetEnergyInit();

    return retVal;  
}

/** 回读CFR模块节能初始化配置 */
UINT32 BspHalAdaptCfrGetEnergy(void)
{
    UINT32 retVal = BSP_OK;

    retVal = IcHalApiCfrGetEnergy();

    return retVal;  
}

/** 设置block0中ram1长度 */
UINT32 BspHalAdaptCfrSetBlock0Ram1Len(void)
{
    UINT32 retVal = BSP_OK;

    retVal = IcHalApiSetCfrBlock0Ram1Len();

    return retVal;  
}

/**************************************************************************
                            SOC相关接口
**************************************************************************/

UINT32 BspHalAdaptGetIcChipId(UINT32 *pChipIdx)
{
    UINT32 retVal = BSP_OK;

    INPUT_POINTER_CHECK(pChipIdx);
    retVal = IcHalApiGetDpdIcChipId(pChipIdx);

    return retVal;
}

UINT32 BspHalAdaptSetTrxOrxEnOrBbdv(UINT32 uiValue)
{
    UINT32 retVal = BSP_OK;

    retVal = IcHalApiSetTrxOrxEnOrBbdv(uiValue);

    return retVal;
}

UINT32 BspHalAdaptSetBbdvOutEn(UINT32 uiValue)
{
    UINT32 retVal = BSP_OK;

    retVal = IcHalApiSetBbdvOutEn(uiValue);

    return retVal;
}

UINT32 BspHalAdaptSetTrxOrxEnOutSel(UINT32 uiValue)
{
    UINT32 retVal = BSP_OK;

    retVal = IcHalApiSetTrxOrxEnOutSel(uiValue);

    return retVal;
}

//配置单端寄存器DS 4-7bit
UINT32 BspHalAdaptSetPadDs(UINT32 uiHalPadName, UINT32 uiValue)
{
    UINT32 retVal = BSP_OK;

    retVal = IcHalApiSetPadDs(uiHalPadName, uiValue);

    return retVal;
}

//配置单端寄存器config_done 8bit
UINT32 BspHalAdaptSetPadCfgDone(UINT32 uiHalPadName, UINT32 padCfgDoneVal)
{
    UINT32 retVal = BSP_OK;

    retVal = IcHalApiSetPadCfgDone(uiHalPadName, padCfgDoneVal);

    return retVal;
}

//配置单端寄存器func_sel 9-10bit
UINT32 BspHalAdaptSetPadFuncSel(UINT32 uiHalPadName, UINT32 padFuncSelVal)
{
    UINT32 retVal = BSP_OK;

    retVal = IcHalApiSetPadFuncSel(uiHalPadName, padFuncSelVal);

    return retVal;
}

#if 0

T_BspHalAdaptSocCrmClk s_CrmSocClk = 
{
    .dspClk = CRM_CLK_FREQ_400MHZ,
};

UINT32 BspHalAdaptSetCrmSocClk(T_BspHalAdaptSocCrmClk *pClkCfg)
{
    memcpy_s(&s_CrmSocClk, sizeof(T_BspHalAdaptSocCrmClk), pClkCfg, sizeof(T_BspHalAdaptSocCrmClk));
    return BSP_OK;
}

UINT32 BspHalAdaptCrmSocClkFreqInit(VOID)
{
    UINT32 chip = 0;
    UINT32 retVal = BSP_OK;

#if 0 /* 闫峰确认，MDIO和SPIFC0由内核配置，用户态不需要配置 */
    /* MDIO频率 1MHz */
    retVal = IcHalApiCrmSocMdioSetClkFreq(chip, CRM_CLK_FREQ_1MHZ);
    CHECK_RETVAL(IcHalApiCrmSocMdioSetClkFreq,retVal);
    /* SPIFC0频率 160MHz */
    retVal = IcHalApiCrmSocSpifc0SetClkFreq(chip, CRM_CLK_FREQ_160MHZ);
    CHECK_RETVAL(IcHalApiCrmSocSpifc0SetClkFreq,retVal);
#endif
    /* 当前不确认SPIFC1的时钟和SPIFC0的时钟是否独立配置，
       担心是从一个PLL输出的一路时钟，所以SPIFC1暂时也不配置
    */
#if 0 
    /* SPIFC1频率 160MHz */
    retVal = IcHalApiCrmSocSpifc1SetClkFreq(chip, CRM_CLK_FREQ_160MHZ);
    CHECK_RETVAL(IcHalApiCrmSocSpifc1SetClkFreq,retVal);
#endif
    /* DSP频率 默认400MHz */
    dbgInfoEx("%s dspClk=%d\n", __func__, s_CrmSocClk.dspClk);
    retVal = IcHalApiCrmSocDspSetClkFreq(chip, s_CrmSocClk.dspClk);
    CHECK_RETVAL(IcHalApiCrmSocDspSetClkFreq,retVal);
    
    return retVal;
}

UINT32 BspHalAdaptCrmFftInit(VOID)
{
    UINT32 chip = 0;
    UINT32 rstFlag = 1;
    UINT32 retVal = BSP_OK;

    /* 释放FFT复位 */
    retVal = IcHalApiCrmFftSetReset(chip, rstFlag);
    CHECK_RETVAL(IcHalApiCrmFftSetReset,retVal);
    /* 释放Prach复位 */
    retVal = IcHalApiCrmPrachSetReset(chip, rstFlag);
    CHECK_RETVAL(IcHalApiCrmPrachSetReset,retVal);        
    
    return retVal;
}

UINT32 BspHalAdaptCrmRoeInit(VOID)
{
    UINT32 chip = 0;
    UINT32 rstFlag = 1;
    UINT32 retVal = BSP_OK;
    
    /* 释放ROE复位 */
    retVal = IcHalApiCrmRoeSetReset(chip, rstFlag);
    CHECK_RETVAL(IcHalApiCrmRoeSetReset,retVal);        
    return retVal;   
}

/* isIF1为扩展预留，如果光口内的CPRI和DIF/GF等需要区分IF0和IF1进行初始化 */
UINT32 BspHalAdaptCrmOptInit(UINT32 isIF1)
{
    UINT32 chip = 0;
    UINT32 rstFlag = 1;
    UINT32 retVal = BSP_OK;
    
    /* 释放OPT复位 */
    retVal = IcHalApiCrmOptSetReset(chip, rstFlag);
    CHECK_RETVAL(IcHalApiCrmOptSetReset,retVal);        
    return retVal;      
}

UINT32 BspHalAdaptCrmDifClkFreqInit(VOID)
{
    UINT32 chip = 0;
    UINT32 retVal = BSP_OK;
    T_BspHalAdaptDifCrmClk difCrmClk = {0};

    /* 取得中频时钟配置 */
    retVal = BspHalAdaptGetDifCrmClk(&difCrmClk);
    CHECK_RETVAL(BspHalAdaptGetDifCrmClk,retVal);    

    /* 消除COV */
    if(0 == difCrmClk.ulLogic1Clk || 0 == difCrmClk.dlLogic2Clk || 0 == difCrmClk.dlLogic3Clk || 0 == difCrmClk.fbLogic1Clk)
    {
        return BSP_ERROR;
    }

    /* UlLogicClk配置 */
    retVal = IcHalApiCrmDifULLogicSetClkFreq(chip, difCrmClk.ulLogic1Clk, difCrmClk.ulLogic2Clk);
    CHECK_RETVAL(IcHalApiCrmDifULLogicSetClkFreq,retVal);

    /* DlLogicClk配置 */
    retVal = IcHalApiCrmDifDLLogicSetClkFreq(chip, difCrmClk.dlLogic2Clk, difCrmClk.dlLogic3Clk, difCrmClk.dlLogic4Clk, difCrmClk.dlLogic5Clk);
    CHECK_RETVAL(IcHalApiCrmDifDLLogicSetClkFreq,retVal); 
    
    /* FbLogicClk配置 */
    retVal = IcHalApiCrmDifFBLogicSetClkFreq(chip, difCrmClk.fbLogic1Clk, difCrmClk.fbLogic2Clk);
    CHECK_RETVAL(IcHalApiCrmDifFBLogicSetClkFreq,retVal);
    
    return retVal;
}

UINT32 BspHalAdaptCrmDifInit(VOID)
{
    UINT32 chip = 0;
    UINT32 rstFlag = 1;
    UINT32 retVal = BSP_OK;
    T_BspHalAdaptDifCrmClk difCrmClk = {0};

    /* Dif各模块复位释放 */
    retVal = IcHalApiCrmDifSetResetAll(chip, rstFlag);
    CHECK_RETVAL(IcHalApiCrmDifSetResetAll,retVal);

    return retVal;
}

UINT32 BspHalAdaptCrmJ204ClkFreqInit(VOID)
{
    UINT32 chip = 0;
    UINT32 retVal = BSP_OK;
    T_BspHalAdaptDifCrmClk difCrmClk = {0};

    /* 取得中频时钟配置 */
    retVal = BspHalAdaptGetDifCrmClk(&difCrmClk);
    CHECK_RETVAL(BspHalAdaptGetDifCrmClk,retVal);  

    /* 消除COV */
    if(0 == difCrmClk.ulJ204WorkClk || 0 == difCrmClk.fbJ204WorkClk || 0 == difCrmClk.dlJ204WorkClk)
    {
        return BSP_ERROR;
    }

    /* UlJ024Clk配置 */
    retVal = IcHalApiCrmDifULJ204SetClkFreq(chip, difCrmClk.ulJ204WorkClk);
    CHECK_RETVAL(IcHalApiCrmDifULJ204SetClkFreq,retVal);    

    /* DlJ024Clk配置 */
    retVal = IcHalApiCrmDifDLJ204SetClkFreq(chip, difCrmClk.dlJ204WorkClk);
    CHECK_RETVAL(IcHalApiCrmDifDLJ204SetClkFreq,retVal); 

    /* FbJ024Clk配置 */
    retVal = IcHalApiCrmDifFBJ204SetClkFreq(chip, difCrmClk.fbJ204WorkClk);
    CHECK_RETVAL(IcHalApiCrmDifFBJ204SetClkFreq,retVal); 

    return retVal;    
}
#endif
/* 
    lane0-lane3 <-> pcs0
    lane4-lane7 <-> pcs1
    网口lane      <-> pcs2
*/
UINT32 BspHalAdaptCrmPcsSetReset(UINT32 laneMask, UINT32 rstFlag)
{
    UINT32 chip = 0;
    UINT32 retVal = BSP_OK;

    if(laneMask & 0xF)
    {
        retVal = IcHalApiCrmPcsSetReset(chip, E_IC_CRM_PCS_0_RESET, rstFlag);
        CHECK_RETVAL(IcHalApiCrmPcsSetReset,retVal);
    }
    
    return BSP_OK;
}
#if 0
/* l2ss NTL主复位释放 */
UINT32 BspHalAdaptCrmNtlTopSetReset(UINT32 rstFlag)
{
    return IcHalApiCrmNtlTopSetReset(0, rstFlag);
}

/* l2ss NTL PTP复位释放 */
UINT32 BspHalAdaptCrmNtlPtpSetReset(UINT32 rstFlag)
{
    return IcHalApiCrmNtlPtpSetReset(0, rstFlag);
}
#endif
/* l2ss NTL Xmac复位释放 */
UINT32 BspHalAdaptCrmNtlXmacSetReset(UINT32 dir, UINT32 laneMask, UINT32 rstFlag)
{
    if(RX == dir)
    {
        return IcHalApiCrmNtlRxXmacSetReset(0, laneMask, rstFlag);
    }
    else if(TX == dir)
    {
        return IcHalApiCrmNtlTxXmacSetReset(0, laneMask, rstFlag);
    }
    else
    {
        return BSP_ERROR;
    }
}

UINT32 BspHalAdaptTrxpEnOrDisable(UINT32 xmacId, UINT32 en)
{
    return IcHalApiNtlTrxpEnOrDisable(xmacId, en);
}
UINT32 BspHalAdaptXmacEnOrDisable(UINT32 xmacId, UINT32 en)
{
    return IcHalApiNtlXmacEnOrDisable(xmacId, en);
}
UINT32 BspHalAdaptNtlL2ssPortVlanDebugCfg(VOID)
{
   return IcHalApiNtlL2ssPortVlanDebugCfg();
}
UINT32 BspHalAdaptNaccXmacInit(T_XmacDrvParam * ptXmacDrvParam)
{
   return IcHalApiNaccXmacInit(ptXmacDrvParam);
}

UINT32 BspHalAdaptlXmacGetPortSpeed(UINT32 xmacId)
{
    UINT32 xmacSpdList[] = {10,100,1000,2500,10000,25000,50000};
    UINT32 xmacSpd = 0;

    xmacSpd =  IcHalApiNtlXmacGetPortSpeed(xmacId);
    if(xmacSpd >= (sizeof(xmacSpdList)/sizeof(xmacSpdList[0])))
    {
        return BSP_ERROR;
    }
    return xmacSpdList[xmacSpd];
}

UINT32 BspHalAdaptNtlL2ssInit(T_OptInitPara *pOptInitPara)
{
    INPUT_POINTER_CHECK(pOptInitPara);
    return IcHalApiNtlL2ssInit(pOptInitPara);
}

UINT32 BspHalAdaptNtlL2ssInitVlanCfg(UINT32 workMode)
{
    return IcHalApiNtlL2ssInitVlanCfg(workMode);
}

/*单板下传递是最后一片从片IC的标志 */
UINT32 BspSetlastSlaveFlag(UINT32 flag)
{
    g_LastSlaveIcFlag = flag;
    return BSP_OK;
}
UINT32 BspGetlastSlaveFlag(void)
{
    return g_LastSlaveIcFlag;
}

VOID BspHalAdaptNtlL2ssSetSlaveFlag(UINT32 flag)
{
    IcHalApiSetOptChipType(E_MASTER_OR_SLAVE, flag);
    if(BspGetlastSlaveFlag() == 1) /*最后一片IC通知光口关端口8*/
    {
        IcHalApiSetOptChipType(E_OTHER_OR_LAST, 1);
    }

    return;
}
/* Ended by AICoder, pid:a5effq3ddbxbcd214ab509476013b82669e2f5b8 */
UINT32 g_ulLaneSavingFlag = 0xff;
UINT32 BspHalAdaptSetLaneSavingFlag(UINT32 flag)
{
   g_ulLaneSavingFlag = flag;
   IcHalApiSetOptChipType(E_NORMAL_OR_SAVE, flag);
   IcHalApiSetOptChipType(E_OTHER_OR_LAST, 0);
   return BSP_OK;
}

UINT32 BspHalAdaptGetLaneSavingFlag(VOID)
{
    return g_ulLaneSavingFlag;
}
UINT32 BspHalAdaptNtlL2ssTrxpEnOrDisBitmap(UINT64 protBitmap, UINT64 maskBitmap)
{
   return IcHalApiNtlL2ssTrxpEnOrDisBitmap(protBitmap, maskBitmap);
}
UINT32 BspHalAdaptGetPathPara(UINT32 *pPathPara, UINT32 byteNum)
{
    return IcHalApiGetPathPara(pPathPara, byteNum);
}
VOID BspHalAdaptCpriSetSwDstFrFlag(UINT32 flag)
{ 
    IcHalApicpriSetSwDstFrFlag(flag);
    return;
}

UINT32 BspHalAdaptGetCarrCopyFlag(UINT32 bspChan, UINT32 dir, UINT32 carrNo, UINT32 radioMode, UINT32 *pCarrCopyFlag)
{
    return IcHalApiGetCarrCopyFlag(dir, carrNo, radioMode, bspChan, pCarrCopyFlag);
}

UINT32 BspHalAdaptL2ssTrxpGetEn(UINT32 udPortNum, UINT32 udDirection)
{
    return IcHalApiL2ssTrxpGetEn(udPortNum,udDirection);
}

UINT32 BspHalAdaptSetUWBL2ssVlan(VOID)
{
    return IcHalApiSetUWBL2ssVlan();
}

#if 0
/* 复位原因记录预留寄存器 共20个 */
UINT32 BspHalAdaptCrmGetResetRecord(UINT32 regId, UINT32 *pRstRecord)
{
    UINT32 retVal = BSP_OK;
    /* 待HAL层提供正式接口，先临时读取寄存器 */
    return BspHalAdaptDpdicRegRd(0, 0xd4c00140, regId*4, pRstRecord);
}

/* 复位原因记录预留寄存器 共20个 */
UINT32 BspHalAdaptCrmClrResetRecord(UINT32 regId)
{
    UINT32 retVal = BSP_OK;
    /* 待HAL层提供正式接口，先临时读取寄存器 */
    return BspHalAdaptDpdicRegWr(0, 0xd4c00140, regId*4, 0x0);      
}

/* 清除参考时钟异常告警锁存状态 */
UINT32 BspHalAdaptCrmClrRefClkReset(VOID)
{
    UINT32 chip = 0;
    return IcHalApiCrmClrRefDetStatus(chip);    
}

UINT32 BspHalAdaptCrmClrReset(VOID)
{
    UINT32 alarmMask = CRM_PAPT_ALL_ALARM_MASK; /* CRM功放保护相关，共21种告警，一起清零，bit0-bit21 */
    UINT32 retVal = BSP_OK;
    UINT32 retTotal = BSP_OK;
    
    /* 功放保护 复位监测、参考时钟异常、PLL异常的复位清除 */
    retVal = IcHalApiCrmSetPaAlmClear(alarmMask);
    retTotal |= retVal;    
    retVal = IcHalApiCrmSetDaAlmClear(alarmMask);
    retTotal |= retVal;

    /* 清除历史告警记录 */
    retVal = IcHalApiClrBoardPwrAlm(alarmMask);;
    retTotal |= retVal;

    return retTotal;
}
#else

/* 获取CRM功放告警使能掩码 */
UINT32 BspHalAdaptGetCrmPaptAlarmEnMask(VOID)
{
    UINT32 retVal = BSP_OK;
    UINT32 mask = 0;

    retVal = CrmGetDaMask0(&mask); 
    CHECK_RETVAL_PRN(CrmGetDaMask0, retVal)
    
    return (~mask);
}

/* 获取CRM功放保护告警的具体类型 pAlarmType:E_CrmPaptAlarmType */
UINT32 BspHalAdaptGetCrmAlarmType(UINT32 *pOrgAlarmMask, UINT32 *pAlarmTypeMask)
{
    UINT32 retVal = BSP_OK;
    UINT32 alarmEnMask = 0;
    UINT32 puiSta = 0;
    UINT32 resStaMask = 0;

    INPUT_POINTER_CHECK(pOrgAlarmMask);
    INPUT_POINTER_CHECK(pAlarmTypeMask);
        
    /* 功放保护 复位监测、参考时钟异常、PLL异常的复位清除 */
    retVal = CrmAlmLatchSta(&puiSta);
    CHECK_RETVAL(CrmAlmLatchSta, retVal)

    *pOrgAlarmMask = puiSta;
    alarmEnMask = BspHalAdaptGetCrmPaptAlarmEnMask();

    dbgInfoEx("%s orgAlmMask=%#x alarmEnMask=%#x\n", __func__, puiSta, alarmEnMask);
    
    /* 判断是否有复位告警 */
    if((CRM_PAPT_RESET_ALARM_MASK & alarmEnMask) & puiSta)
    {
        resStaMask |= (0x1 << CRM_PAPT_ALM_RESET);
        dbgInfoEx("%s crm reset alarm happen resStaMask=%#x\n", __func__, resStaMask);
    }
    /* 判断是否有时钟异常告警 */
    if((CRM_PAPT_PLL_ALARM_MASK & alarmEnMask) & puiSta)
    {
        resStaMask |= (0x1 << CRM_PAPT_ALM_PLL_ERR);
        dbgInfoEx("%s crm pll alarm happen resStaMask=%#x\n", __func__, resStaMask);
    }   
    /* 判断是否有单板欠压告警 */
    if((CRM_PAPT_PWR_ALARM_MASK & alarmEnMask) & puiSta)
    {
        resStaMask |= (0x1 << CRM_PAPT_ALM_BOARD_PWR_OFF);
        dbgInfoEx("%s crm board pwr alarm happen resStaMask=%#x\n", __func__, resStaMask);
    }
    
    *pAlarmTypeMask = resStaMask;
    
    return retVal;
}

/* 清除CRM功放保护告警 pAlarmType:E_CrmPaptAlarmType */
UINT32 BspHalAdaptClrCrmAlarmType(UINT32 alarmType)
{
    UINT32 retVal = BSP_OK;
    if(CRM_PAPT_ALM_RESET == alarmType)
    {
        dbgInfoEx("%s clear crm alarm type=%d\n",__func__, alarmType);
        retVal = CrmAlmLatchStaClear(CRM_PAPT_RESET_ALARM_MASK);
        retVal |= CrmAlmLatchStaClear(0x0);
    }
    else if(CRM_PAPT_ALM_PLL_ERR == alarmType)
    {
        dbgInfoEx("%s clear crm alarm type=%d\n",__func__, alarmType);
        retVal = CrmAlmLatchStaClear(CRM_PAPT_PLL_ALARM_MASK);
        retVal |= CrmAlmLatchStaClear(0);
    }
    else if(CRM_PAPT_ALM_BOARD_PWR_OFF == alarmType)
    {
        dbgInfoEx("%s clear crm alarm type=%d\n",__func__, alarmType);
        retVal = CrmAlmLatchStaClear(CRM_PAPT_PWR_ALARM_MASK);
        retVal |= CrmAlmLatchStaClear(0);
    }    
    else 
    {
        dbgInfoEx("%s clear crm alarm err, type=%d\n",__func__, alarmType);
        return BSP_ERROR;
    }
    return retVal;
}

/* 清除全部CRM功放保护历史告警 */
UINT32 BspHalAdaptClrAllCrmAlarm(VOID)
{
    UINT32 retVal = BSP_OK;

    retVal |= CrmAlmLatchStaClear(CRM_PAPT_ALL_ALARM_MASK);

    /*固定流程写1再写0 表示清一次告警*/
    retVal |= CrmAlmLatchStaClear(0);

    return retVal;
}

UINT32 BspHalAdaptClrCrmPaAlm(E_CrmPaptAlarmType type)
{
    if (type == CRM_PAPT_ALM_BOARD_PWR_OFF)
    {
        CrmPaAlmClear0(CRM_PAPT_PWR_ALARM_MASK);
        CrmPaAlmClear0(0x0);
    }

    return BSP_OK;
}

UINT32 BspHalAdaptClrCrmDataAlm(E_CrmPaptAlarmType type)
{
    if (type == CRM_PAPT_ALM_BOARD_PWR_OFF)
    {
        CrmDaAlmClear0(CRM_PAPT_PWR_ALARM_MASK);
        CrmDaAlmClear0(0x0);
    }

    return BSP_OK;
}

UINT32 BspHalAdaptGetCrmPastAlarm(E_CrmPaptAlarmType type)
{
    UINT32 crmSta = 0;
    UINT32 chkMask = 0;

    if (type == CRM_PAPT_ALM_BOARD_PWR_OFF)
    {
        chkMask = CRM_PAPT_PWR_ALARM_MASK;
    }
    else if(type == CRM_PAPT_ALM_PLL_ERR)
    {
        chkMask = CRM_PAPT_PLL_ALARM_MASK;
    }
    else if(type == CRM_PAPT_ALM_RESET)
    {
        chkMask = CRM_PAPT_RESET_ALARM_MASK;
    }

    CrmAlmLatchSta(&crmSta);

    return (crmSta & chkMask) ? BSP_ERROR : BSP_OK;
}

UINT32 BspHalAdaptGetCrmRealAlarm(E_CrmPaptAlarmType type)
{
    UINT32 crmSta = 0;
    UINT32 chkMask = 0;

    if (type == CRM_PAPT_ALM_BOARD_PWR_OFF)
    {
        chkMask = CRM_PAPT_PWR_ALARM_MASK;
    }

    CrmAlmRealSta(&crmSta);

    return (crmSta & chkMask) ? BSP_ERROR : BSP_OK;
}

#endif

UINT32 BspHapAdaptCrmGetIcTemp(UINT32 sensorId, INT32 *pTemp)
{
    UINT32 chip = 0;
    UINT32 retVal = BSP_OK;
    retVal = IcHalApiCrmGetIcTemp(chip, sensorId, pTemp);
    return retVal;
}

/* 复位原因记录上报寄存器 共3个 */
UINT32 BspHalAdaptCrmGetResetReason(UINT32 regId, UINT32 *pRstReason)
{
    UINT32 retVal = BSP_OK;
    UINT32 chipId = 0;
    retVal = IcHalApiGetResetRecord(chipId, regId, pRstReason);
    return retVal;     
}

/* 复位原因记录上报寄存器 共3个 */
UINT32 BspHalAdaptClrCrmResetReason(UINT32 regId, UINT32 startBit, UINT32 endBit)
{
    UINT32 retVal = BSP_OK;
    UINT32 chipId = 0;
    retVal = IcHalApiClrResetRecord(chipId, regId,startBit,endBit);
    return retVal;     
}

/* 复位原因记录上报寄存器 共3个 */
UINT32 BspHalAdaptCrmGetPwrAlarm(UINT32 *pRstReason)
{
    UINT32 retVal = BSP_OK;
    UINT32 chipId = 0;
    retVal = IcHalApiGetPwrAlarm(chipId, pRstReason);
    return retVal;
}

/* 复位原因记录上报寄存器 共3个 */
UINT32 BspHalAdaptClrCrmPwrAlarm(UINT32 startBit, UINT32 endBit)
{
    UINT32 retVal = BSP_OK;
    UINT32 chipId = 0;
    retVal = IcHalApiClrPwrAlarm(chipId, startBit,endBit);
    return retVal;
}
UINT32 BspHalAdaptCrmGetN8vAlarm(UINT32 *pN8VStat)
{
    UINT32 retVal = BSP_OK;

    retVal = IcHalApiCrmN8VState(pN8VStat);
    return retVal;
}

UINT32 BspHalAdaptCrmN8VForcePaCfg(UINT32 forcePaCfgSwitch)
{
    UINT32 retVal = BSP_OK;

    retVal = IcHalApiCrmN8VForcePaCfg(forcePaCfgSwitch);

    return retVal;
}

VOID  BspHalAdaptSetPsyncSynChipId(UINT32 chipId)
{
    IcHalApiSetPsyncSynChipId(chipId);
    return;
}

/**************************************************************************
                            节能相关接口
**************************************************************************/

/* Started by AICoder, pid:dc8d740303h109b144cd0bf9f0fe43035bb90822 */
/* 中频CFR模块stage门控配置接口 uiEn:1使能；0不使能*/
UINT32 BspHalAdaptSetCfrStageGateCtrl(UINT32 uiEn)     
{
    dbgInfoEx("%s uiEn=%d\n", __FUNCTION__, uiEn);
    return IcHalApiSetCfrStageGateCtrl(uiEn);
}
/* Ended by AICoder, pid:dc8d740303h109b144cd0bf9f0fe43035bb90822 */

/* Started by AICoder, pid:37424x144dk837414583081ef0f44d0e1449d474 */
/**********************************************************************
* 函数名称: BspHalAdaptSetDldpdSetGateCfg
* 功能描述: 中频DPD/PIMC门控配置接口
* 输入参数:
*         uiChanMask：对应下行静态路由表T_BspHalAdaptDifTxRouteMap，DpdPort通道参数将对应bit置1
*         uiPimcFlag：对应中频资源分配T_BspHalAdaptDifResAllocChanPara，结构体中uiPimcFlag标志，只要有一个1，参数就传1
* 输出参数: 无
* 返  回  值: BSP_OK/BSP_ERROR
************************************************************************/
UINT32 BspHalAdaptSetDldpdSetGateCfg(UINT32 uiChanMask, UINT32 uiPimcFlag)     
{
    dbgInfoEx("%s uiChanMask=%d uiPimcFlag=%d\n", __FUNCTION__, uiChanMask, uiPimcFlag);
    return IcHalApiSetDldpdSetGateCfg(uiChanMask,uiPimcFlag);
}
/* Ended by AICoder, pid:37424x144dk837414583081ef0f44d0e1449d474 */

/* 中频下行未使用资源时钟门控使能接口 */
UINT32 BspHalAdaptSetTxUnusedGateEn(UINT32 gateEn)     
{
    dbgInfoEx("%s gateEn=%d\n", __FUNCTION__, gateEn);
    return IcHalApiSetTxUnusedGateEn(gateEn);
}

/* 中频上行未使用资源时钟门控使能接口 */
UINT32 BspHalAdaptSetRxUnusedGateEn(UINT32 gateEn)
{
    dbgInfoEx("%s gateEn=%d\n", __FUNCTION__, gateEn);
    return IcHalApiSetRxUnusedGateEn(gateEn);
}


/**********************************************************************
* 函数名称: BspHalAdaptDifUnuseResGateCtrl
* 功能描述: 中频未使用资源的门控控制
* 输入参数:
* 输出参数: 无
* 返  回  值: BSP_OK/BSP_ERROR
************************************************************************/
UINT32 BspHalAdaptDifUnuseResGateCtrl(UINT32 dir, UINT32 sw)
{
    UINT32 retVal    = BSP_OK;
    T_DpdicPwrSaveSel *pPwrsavePara = BspHalAdaptGetPwrSaveCfg();

    if(NULL != pPwrsavePara)
    {
        if(TX == dir && pPwrsavePara->difTxUnusedResSel)
        {
            retVal = IcHalApiSetTxUnusedGateEn(sw);
            dbgInfo("%s IcHalApiSetTxUnusedGateEn sw=%d ret=%#x\n", __func__,sw,retVal);
        }
        if(RX == dir && pPwrsavePara->difRxUnusedResSel)
        {
            retVal = IcHalApiSetRxUnusedGateEn(sw);
            dbgInfo("%s IcHalApiSetRxUnusedGateEn sw=%d ret=%#x\n", __func__,sw,retVal);
        }
    }
    else 
    {
        dbgInfo("%s Get Dpdic Dif Resource Gate Info fail! \n", __func__);
    }
    
    return retVal;
}

UINT32 BspHalAdaptOptAllCellEn(UINT32 en)
{
    dbgInfo("%s gateEn=%d\n", __FUNCTION__, en);
    return IcHalOptAllCellCfg(en,0x7);    
}

/*下行载波关断*/
UINT32 BspApiSetDlbankDgainEnOffInit()
{
    return IcHalApiSetDlbankDgainEnOffInit();
}

/*上行载波关断*/
UINT32 BspApiSetUlbankKpOutEnOffInit()
{
    return IcHalApiSetUlbankKpOutEnOffInit();
}

UINT32 BspOptDisableCtrl(VOID)
{
    UINT32 retVal = 0;

    retVal = IcHalOptDisable(TX);
    retVal |= IcHalOptDisable(RX);

    return retVal;
}

static UINT32 A53CoreOffLine(UINT32 coreID)
{
    CHAR cmd[64] = {0};
    int retVal = 0;

    if(coreID >= DPDIC_A53_CORE_NUM)
    {
        return BSP_ERROR;
    }
    
    if (snprintf_s(cmd, sizeof(cmd), "echo 0 > /sys/devices/system/cpu/cpu%d/online", coreID) < 0)
    {
        dbgErr("%s:snprintf_s() is error\n", __FUNCTION__);
    }
    retVal = BspSystem(cmd);
    if (retVal != BSP_OK)
    {
        dbgErr("%s: Run %s failed, ret:%d\n", __FUNCTION__, cmd, retVal);
        return BSP_ERROR;
    }
    else
    {
        dbgErr("%s: A53 core[%d] offline success\n", __FUNCTION__, coreID);
    }

    return BSP_OK;    
}

static UINT32 A53CoreOffLineConfirm(UINT32 coreID)
{
    UINT32 ulRetVal = BSP_OK;
    CHAR   acGetBuf[64] = " ";
    CHAR   acCoreName[24] = " ";
    FILE   *pFileHandle = NULL;
    INT32  lSnpRet  = 0;
    INT32  iTmpRet  = 0;

    if(coreID >= DPDIC_A53_CORE_NUM)
    {
        return BSP_ERROR;
    }
    
    iTmpRet = fopen_s(&pFileHandle, "/sys/devices/system/cpu/offline", "r");
    if((0 != iTmpRet)||(pFileHandle == NULL))
    {
        ulRetVal = BSP_ERROR;
        dbgErr("%s>>Open file Error!\n", __FUNCTION__);
        return ulRetVal;
    }  
    iTmpRet = zte_fgets_s(acGetBuf, sizeof(acGetBuf), sizeof(acGetBuf), pFileHandle);
    if (iTmpRet != 0)
    {
        dbgErr("%s>> Fgets Char Error!\n", __FUNCTION__);
        iTmpRet = fclose(pFileHandle);
        FCLOSE_CHECK(iTmpRet);    
        return BSP_ERROR;
    }
    iTmpRet = fclose(pFileHandle);
    FCLOSE_CHECK(iTmpRet);    
    
    dbgInfoEx("%s acGetBuf=%s\n",__FUNCTION__, acGetBuf);    
    lSnpRet = snprintf_s(acCoreName, sizeof(acCoreName), "%d", coreID);
    SNPRINTF_S_CHECK(lSnpRet, sizeof(acCoreName));  
    dbgInfoEx("%s acCoreName=%s\n",__FUNCTION__, acCoreName);

    if (strstr(acGetBuf, acCoreName) != NULL)
    {
        ulRetVal = BSP_OK;
    }
    else 
    {
        ulRetVal = BSP_ERROR;
    }
    
    return ulRetVal;
}


static UINT32 BspHalAdaptA53OffLine(T_DpdicPwrSaveSel* pCfg)
{
    UINT32 retVal = BSP_OK;
    UINT32 mask = 0;
    UINT32 loop = 0;

    INPUT_POINTER_CHECK(pCfg);    

    /* a53 */
    mask = pCfg->a53CoreMask;
    if(0xF != mask)
    {
        /* 先通知内核Offline A53核 */
        for(loop=0; loop<DPDIC_A53_CORE_NUM; loop++)
        {
            if(!BIT_VAL(mask,loop))
            {
                retVal |= A53CoreOffLine(loop);
            }
        }
        
        /* 等待核Offline */
        BspSysMsDelay(100);

        /* 确认核是否已offline */
        for(loop=0; loop<DPDIC_A53_CORE_NUM; loop++)
        {
            if(!BIT_VAL(mask,loop))
            {
                retVal |= A53CoreOffLineConfirm(loop);
            }
        }        

        /* 拉bit4-7的核硬复位 */
        if(BSP_OK == retVal)
        {
            retVal |= IcHalApiSetCrmA53ResetCore(mask);
            dbgInfo("%s IcHalApiSetCrmA53ResetCore mask=%#x\n", __func__,mask);
            #if 0 /* 波及软复位，暂时屏蔽 */
            retVal |= IcHalApiSetCrmA53ResetPo(mask);
            dbgInfo("%s IcHalApiSetCrmA53ResetPo mask=%#x\n", __func__,mask);
            #endif              
        }
    }
    
    return retVal;
}

/* DPDIC芯片节电门控参数初始化(用于保存单板下的门控使能配置) */
static UINT32 BspHalAdaptOptGateCtrl(T_DpdicPwrSaveSel* pCfg)
{
    UINT32 retVal = BSP_OK;
    UINT32 mask = 0;
    UINT32 loop = 0;
    UINT32 ctrlVal = 0;

    INPUT_POINTER_CHECK(pCfg);    
    
    /* cfg_gate_dif_if0_comp(id) */
    mask = pCfg->optDifIf0CompMask;
    for(loop=0; loop<OPT_DIF_BLOCK_CHAN_MAX_NUM; loop++)
    {
        ctrlVal = (!!BIT_VAL(mask,loop));
        retVal |= OptDifSetLTEGateEN(loop, ctrlVal);
        dbgInfo("%s OptDifSetLTEGateEN ulChan=%d ulMode=%d\n", __func__,loop,ctrlVal);
    }

    /* cfg_gate_dif_if1_comp(id) */
    mask = pCfg->optDifIf1CompMask;
    for(loop=0; loop<OPT_DIF_BLOCK_CHAN_MAX_NUM; loop++)
    {
        ctrlVal = (!!BIT_VAL(mask,loop));
        retVal |= OptDifSetFFTAGateEN(loop, ctrlVal);
        dbgInfo("%s OptDifSetFFTAGateEN ulChan=%d ulMode=%d\n", __func__,loop,ctrlVal);
    }

    /* cfg_gate_dif_axim(id) */
    mask = pCfg->optDifAximMask;
    for(loop=0; loop<OPT_DIF_BLOCK_CHAN_MAX_NUM; loop++)
    {
        ctrlVal = (!!BIT_VAL(mask,loop));
        retVal |= OptDifSetAXIGateEN(loop, ctrlVal);
        dbgInfo("%s OptDifSetAXIGateEN ulChan=%d ulMode=%d\n", __func__,loop,ctrlVal);
    }

    /* cfg_gate_gf_oran(id) */
    mask = pCfg->optGfOranMask;
    for(loop=0; loop<OPT_GF_BLOCK_MAX_NUM; loop++)
    {
        ctrlVal = (!!BIT_VAL(mask,loop));
        retVal |= OptGfSetOranChClkGataEn(loop, ctrlVal);
        dbgInfo("%s OptGfSetOranChClkGataEn ulTdmChan=%d ulMode=%d\n", __func__,loop,ctrlVal);
    }

    /* cfg_gate_gf_bdr(id) */
    mask = pCfg->optGfBdrMask;
    for(loop=0; loop<OPT_GF_BLOCK_MAX_NUM; loop++)
    {
        ctrlVal = (!!BIT_VAL(mask,loop));
        retVal |= OptGfSetBdrChClkGataEn(loop, ctrlVal);
        dbgInfo("%s OptGfSetBdrChClkGataEn ulTdmChan=%d ulMode=%d\n", __func__,loop,ctrlVal);
    }

    /* cfg_gate_gf_ch(id) */
    mask = pCfg->optGfChMask;
    for(loop=0; loop<OPT_GF_BLOCK_MAX_NUM; loop++)
    {
        ctrlVal = (!!BIT_VAL(mask,loop));
        retVal |= OptGfSetChClkGataEn(loop, ctrlVal);
        dbgInfo("%s OptGfSetChClkGataEn ulTdmChan=%d ulMode=%d\n", __func__,loop,ctrlVal);
    }

    /* cfg_gate_bif_oran(id) */
    mask = pCfg->optBifOranMask;
    for(loop=0; loop<OPT_BIF_BLOCK_MAX_NUM; loop++)
    {
        ctrlVal = (!!BIT_VAL(mask,loop));
        retVal |= OptBifSetOranChClkGataEn(loop, ctrlVal);
        dbgInfo("%s OptBifSetOranChClkGataEn ulTdmChan=%d ulMode=%d\n", __func__,loop,ctrlVal);
    }

    /* cfg_gate_bif_ch(id) */
    mask = pCfg->optBifChMask;
    for(loop=0; loop<OPT_BIF_BLOCK_MAX_NUM; loop++)
    {
        ctrlVal = (!!BIT_VAL(mask,loop));
        retVal |= OptBifSetBifChClkGataEn(loop, ctrlVal);
        dbgInfo("%s OptBifSetBifChClkGataEn ulTdmChan=%d ulMode=%d\n", __func__,loop,ctrlVal);
    }

    /* cfg_gate_sw1_optsw1 */
    ctrlVal = (!!pCfg->optSw1OptSw1Sel);
    retVal |= IcHalSw1ClockGatingEn(ctrlVal);
    dbgInfo("%s IcHalSw1ClockGatingEn swGate=%d\n", __func__,ctrlVal);

    /* cfg_gate_sw1_map */
    ctrlVal = (!!pCfg->optSw1MapSel);
    retVal |= IcHalSw1MapGate(ctrlVal);
    dbgInfo("%s IcHalSw1MapGate mapGate=%d\n", __func__,ctrlVal);

    /* cfg_gate_cpri_frm(id) */
    retVal |= IcHalApiCfgCpriFrmGate(pCfg->optCpriFrmMask);
    dbgInfo("%s IcHalApiCfgCpriFrmGate ulGateMask=%#x\n", __func__,pCfg->optCpriFrmMask);

    /* cfg_gate_cpri_serdes(id) */
    retVal |= IcHalApiCfgCpriSerdesGate(pCfg->optCpriSerdesMask);
    dbgInfo("%s IcHalApiCfgCpriSerdesGate ulGateMask=%#x\n", __func__,pCfg->optCpriSerdesMask);

    return retVal;
}

static UINT32 BspHalAdaptNtlGateCtrl(T_DpdicPwrSaveSel* pCfg)
{
    UINT32 retVal = BSP_OK;
    UINT32 mask = 0;

    INPUT_POINTER_CHECK(pCfg);

    /* cfg_gate_prach0_1 and cfg_gate_prach0_0 */
    mask = 0;
    mask |= ((!!(pCfg->optPrach01Sel)) << 1);
    mask |= ((!!(pCfg->optPrach00Sel)) << 0);
    retVal |= IcHalApiCrmCfgPrachGate16T0(0, mask);
    dbgInfo("%s IcHalApiCrmCfgPrachGate16T0 ulChip=%d ulClkBitMask=%#x\n", __func__,0,mask);
    
    /* cfg_gate_fft1 and cfg_gate_fft0 */
    mask = 0;
    mask |= ((!!(pCfg->optFft1Sel)) << 1);
    mask |= ((!!(pCfg->optFft0Sel)) << 0);
    retVal |= IcHalApiCrmCfgFftGate16T0(0, mask);
    dbgInfo("%s IcHalApiCrmCfgFftGate16T0 ulChip=%d ulClkBitMask=%#x\n", __func__,0,mask);

    /* cfg_gate_roe_iq0/iq1/iq2/iq3/netctrl */
    mask = IcHalApiCrmGetRoeGateReg();
    dbgInfo("[%s] mask=%#x\n", __func__, mask);
    mask &= 0x7FE;
    mask |= ((!!(pCfg->optRoeIq0Sel)) << 14);  //1
    mask |= ((!!(pCfg->optRoeIq1Sel)) << 13);  //0
    mask |= ((!!(pCfg->optRoeIq2Sel)) << 12);  //1
    mask |= ((!!(pCfg->optRoeIq3Sel)) << 11);  //0
    mask |= ((!!(pCfg->optRoeNtlCtrlSel)) << 0);
    retVal |= IcHalApiCrmCfgRoeGate(0,mask);  //35042
    dbgInfo("%s IcHalApiCrmCfgRoeGate ulChip=%d ulClkBitMask=%#x\n", __func__,0,mask);

    return retVal;
}

static UINT32 BspHalAdaptDifGateCtrl(T_DpdicPwrSaveSel* pCfg)
{
    UINT32 retVal = BSP_OK;
    UINT32 mask = 0;
    UINT32 loop = 0;
    UINT32 ctrlVal = 0;

    INPUT_POINTER_CHECK(pCfg); 

    /* cfg_gate_dif_all */
    ctrlVal = (!!pCfg->difAllSel);
    retVal |= IcHalApiSetJ204DifGate(ctrlVal);
    dbgInfo("%s IcHalApiSetJ204DifGate uiDifEn=%d\n", __func__,ctrlVal);

    /* cfg_gate_j204_dl_lane(id) */
    mask = pCfg->j204DlLaneMask;
    for(loop=0; loop<DPDIC_J204_TX_LANE_MAX_SUM; loop++)
    {
        ctrlVal = (!!BIT_VAL(mask,loop));
        retVal |= IcHalApiSetJ204DlLaneGate(0, loop, ctrlVal);
        dbgInfo("%s IcHalApiSetJ204DlLaneGate laneId=%d laneEn=%d\n", __func__,loop,ctrlVal);
    }

    /* cfg_gate_j204_fb_lane(id) */
    mask = pCfg->j204FbLaneMask;
    for(loop=0; loop<DPDIC_J204_FB_LANE_MAX_SUM; loop++)
    {
        ctrlVal = (!!BIT_VAL(mask,loop));
        retVal |= IcHalApiSetJ204FbLaneGate(0, loop, ctrlVal);
        dbgInfo("%s IcHalApiSetJ204FbLaneGate laneId=%d laneEn=%d\n", __func__,loop,ctrlVal);
    }

    /* cfg_gate_j204_ul_lane(id) */
    mask = pCfg->j204UlLaneMask;
    for(loop=0; loop<DPDIC_J204_RX_LANE_MAX_SUM; loop++)
    {
        ctrlVal = (!!BIT_VAL(mask,loop));
        retVal |= IcHalApiSetJ204UlLaneGate(0, loop, ctrlVal);
        dbgInfo("%s IcHalApiSetJ204UlLaneGate laneId=%d laneEn=%d\n", __func__,loop,ctrlVal);
    }
    
    /* cfg_gate_j204_dl_map(id) */
    mask = pCfg->j204DlMapMask;
    for(loop=0; loop<DPDIC_J204_MAP_NUM_MAX; loop++)
    {
        ctrlVal = (!!BIT_VAL(mask,loop));
        retVal |= IcHalApiSetJ204DlMapClkGate(0, loop, ctrlVal);
        dbgInfo("%s IcHalApiSetJ204DlMapClkGate MapId=%d MapEn=%d\n", __func__,loop,ctrlVal);
    }

    /* cfg_gate_j204_fb_map(id) */
    mask = pCfg->j204FbMapMask;
    for(loop=0; loop<DPDIC_J204_MAP_NUM_MAX; loop++)
    {
        ctrlVal = (!!BIT_VAL(mask,loop));
        retVal |= IcHalApiSetJ204FbMapClkGate(0, loop, ctrlVal);
        dbgInfo("%s IcHalApiSetJ204FbMapClkGate MapId=%d MapEn=%d\n", __func__,loop,ctrlVal);
    }

    /* cfg_gate_j204_ul_map(id) */
    mask = pCfg->j204UlMapMask;
    for(loop=0; loop<DPDIC_J204_MAP_NUM_MAX; loop++)
    {
        ctrlVal = (!!BIT_VAL(mask,loop));
        retVal |= IcHalApiSetJ204UlMapClkGate(0, loop, ctrlVal);
        dbgInfo("%s IcHalApiSetJ204UlMapClkGate MapId=%d MapEn=%d\n", __func__,loop,ctrlVal);
    }

    return retVal;
}

UINT32 BspHalAdaptPwrSavePreInit(VOID)
{
    UINT32 retVal = BSP_OK;
    T_DifCfgSave* pSaveCfg = NULL;
    T_DpdicPwrSaveSel* pCfg = NULL;

    pSaveCfg = GetDifCfgSave(E_IC_PWRSAVE_NORMAL_SEL);
    if(NULL == pSaveCfg)
    {
        dbgErr("GetDifCfgSave get powersave cfg fail!\n");
        return BSP_ERROR;
    }
    pCfg = (T_DpdicPwrSaveSel*)(pSaveCfg->pAddr);
    
    retVal |= BspHalAdaptA53OffLine(pCfg);
    CHECK_RETVAL_PRN(BspHalAdaptA53OffLine, retVal);

    retVal |= BspHalAdaptNtlGateCtrl(pCfg);
    CHECK_RETVAL_PRN(BspHalAdaptNtlGateCtrl, retVal);

    retVal |= BspHalAdaptDifGateCtrl(pCfg);
    CHECK_RETVAL_PRN(BspHalAdaptDifGateCtrl, retVal);

    return retVal;
}

UINT32 BspHalAdaptPwrSavePostInit(VOID)
{
    UINT32 retVal = BSP_OK;
    T_DifCfgSave* pSaveCfg = NULL;
    T_DpdicPwrSaveSel* pCfg = NULL;

    pSaveCfg = GetDifCfgSave(E_IC_PWRSAVE_NORMAL_SEL);
    if(NULL == pSaveCfg)
    {
        dbgErr("GetDifCfgSave get powersave cfg fail!\n");
        return BSP_ERROR;
    }
    pCfg = (T_DpdicPwrSaveSel*)(pSaveCfg->pAddr);

    retVal |= BspHalAdaptOptGateCtrl(pCfg);
    CHECK_RETVAL_PRN(BspHalAdaptOptGateCtrl, retVal);

    return retVal;
}

UINT32 BspHalAdaptPwrSavePostQcell(UINT32 uiPwrsaveMode)
{
    UINT32 retVal = BSP_OK;
    T_DifCfgSave* pSaveCfg = NULL;
    T_DpdicPwrSaveSel* pCfg = NULL;

    pSaveCfg = GetDifCfgSave(uiPwrsaveMode);
    if(NULL == pSaveCfg)
    {
        dbgErr("GetDifCfgSave get powersave cfg fail!\n");
        return BSP_ERROR;
    }
    pCfg = (T_DpdicPwrSaveSel*)(pSaveCfg->pAddr);

    retVal |= BspHalAdaptOptGateCtrl(pCfg);
    CHECK_RETVAL_PRN(BspHalAdaptOptGateCtrl, retVal);

    return retVal;
}

UINT32 BspHalAdaptDpdicGateCtrl(UINT32 pwrsaveType)
{
    UINT32 retVal = BSP_OK;
    T_DifCfgSave* pSaveCfg = NULL;
    T_DpdicPwrSaveSel* pCfg = NULL;

    if(E_IC_PWRSAVE_NORMAL_SEL == pwrsaveType)
    {
        pSaveCfg = GetDifCfgSave(E_IC_PWRSAVE_NORMAL_SEL);
    }
    else if(E_IC_PWRSAVE_DEEPSLEEP_SEL == pwrsaveType)
    {
        pSaveCfg = GetDifCfgSave(E_IC_PWRSAVE_DEEPSLEEP_SEL);
    }
    else if(E_IC_PWRSAVE_ALLCARROFF_SEL == pwrsaveType)
    {
        pSaveCfg = GetDifCfgSave(E_IC_PWRSAVE_ALLCARROFF_SEL);
    }
    else 
    {
        return BSP_ERROR;
    }
    
    if(NULL == pSaveCfg)
    {
        dbgErr("GetDifCfgSave get powersave cfg fail!\n");
        return BSP_ERROR;
    }
    pCfg = (T_DpdicPwrSaveSel*)(pSaveCfg->pAddr);
    
    retVal |= BspHalAdaptOptGateCtrl(pCfg);
    CHECK_RETVAL_PRN(BspHalAdaptOptGateCtrl, retVal);

    retVal |= BspHalAdaptNtlGateCtrl(pCfg);
    CHECK_RETVAL_PRN(BspHalAdaptNtlGateCtrl, retVal);

    retVal |= BspHalAdaptDifGateCtrl(pCfg);
    CHECK_RETVAL_PRN(BspHalAdaptDifGateCtrl, retVal);

    return retVal;
}

UINT32 BspHalAdaptSetPwrSaveCfg(UINT32 pwrsaveType,T_DpdicPwrSaveSel* pCfg)
{
    INPUT_POINTER_CHECK(pCfg); 

    if(E_IC_PWRSAVE_NORMAL_SEL == pwrsaveType)
    {
        SaveDifCfg(E_IC_PWRSAVE_NORMAL_SEL, (VOID*)pCfg, 0, 0);
    }
    else if(E_IC_PWRSAVE_DEEPSLEEP_SEL == pwrsaveType)
    {
        SaveDifCfg(E_IC_PWRSAVE_DEEPSLEEP_SEL, (VOID*)pCfg, 0, 0);
    }
    else if(E_IC_PWRSAVE_ALLCARROFF_SEL == pwrsaveType)
    {
        SaveDifCfg(E_IC_PWRSAVE_ALLCARROFF_SEL, (VOID*)pCfg, 0, 0);
    }
    else if(E_IC_PWRSAVE_QCELL_PB_SEL == pwrsaveType)
    {
    	SaveDifCfg(E_IC_PWRSAVE_QCELL_PB_SEL, (VOID*)pCfg, 0, 0);
    }
    else if(E_IC_PWRSAVE_QCELL_BBU_SEL == pwrsaveType)
    {
    	SaveDifCfg(E_IC_PWRSAVE_QCELL_BBU_SEL, (VOID*)pCfg, 0, 0);
    }
    else
    {
        return BSP_ERROR;
    }

    return BSP_OK;
}

T_DpdicPwrSaveSel* BspHalAdaptGetPwrSaveCfg(VOID)
{
    T_DifCfgSave* pSaveCfg = NULL;

    pSaveCfg = GetDifCfgSave(E_IC_PWRSAVE_NORMAL_SEL);
    if(NULL == pSaveCfg)
    {
        return NULL;
    }
    else 
    {
        return (T_DpdicPwrSaveSel*)(pSaveCfg->pAddr);
    }
}

/* 打开/关闭FFT和PRACH */
UINT32 BspHalAdaptOptFftPrachSwitch(UINT32 sw)
{
    return IcHalApiOptL1Switch(sw);
}

/* 配置中频除204外总控门控使能  sw: 1表示时钟打开，0表示时钟关闭 */
UINT32 BspHalAdaptSetJ204DifGate(UINT32 sw)
{
    return IcHalApiSetJ204DifGate(sw);
}

#if 0

/**************************************************************************
                            适配层和HAL层接口一致性检查
**************************************************************************/
UINT32 BspHalAdaptConsistenceCheck(VOID)
{
    return BSP_OK;
}

/**************************************************************  
 *                      R8 文件加载
***************************************************************/
UINT32 BspHalAdaptLoadArmSlaveCore(UINT32 cpuCoreId, CHAR* elfFilePath)
{
    UINT32 retVal = BSP_OK;
    INPUT_POINTER_CHECK(elfFilePath);
    retVal =  LoadArmSlaveCore(cpuCoreId, elfFilePath);
    return retVal; 
}

UINT32 BspHalAdaptR8MesgInterInit(VOID)
{
    UINT32 retVal = BSP_OK;
    retVal =  IcHalApiR8MesgInterInit();
    return retVal; 
}

UINT32 BspHalAdaptLoadFirstCfg(UINT32 chipId,UINT32 cpuId)
{
    UINT32 retVal = BSP_OK;
    retVal =  IcHalApiLoadFirstCfg(chipId, cpuId);
    return retVal; 
}

UINT32 BspHalAdaptLoadSecondR8Cfg(UINT32 chipId, UINT32 cpuId, UINT32 r8No)
{
    UINT32 retVal = BSP_OK;
    retVal = IcHalApiLoadSecondR8Cfg(chipId, cpuId, r8No);
    return retVal; 
}

UINT32 BspHalAdaptLoadSecondCevaCfg(UINT32 chipId, UINT32 cpuId, UINT32 cevaNo)
{
    UINT32 retVal = BSP_OK;
    retVal = IcHalApiLoadSecondCevaCfg(chipId, cpuId, cevaNo);
    return retVal; 
}

/**************************************************************  
 *                      Dsp 文件加载
***************************************************************/
UINT32 BspHalAdaptLoadDspVer(UINT32 dspIndex, UINT8* buff, ULONG buffSize)
{
    UINT32 retVal = BSP_OK;
    /* extern UINT32 BspLoadDspVer(ULONG ucChannel,UINT8 *pRecvBuf,LONG dwRecvFileSize); */
    retVal = IcHalApiLoadDspVersion(dspIndex, buff, buffSize);
    return retVal; 
}

/**************************************************************************
                            节能相关接口
**************************************************************************/
UINT32 BspHalAdaptSetTxChanGateEn(UINT32 uiDifChan, UINT32 uiGateEn)    \
ICHAL_ADAPT_FUNC_DEF(SetTxChanGateEn,uiDifChan,uiGateEn)
UINT32 BspHalAdaptSetRxChanGateEn(UINT32 uiDifChan, UINT32 uiGateEn)    \
ICHAL_ADAPT_FUNC_DEF(SetRxChanGateEn,uiDifChan,uiGateEn)
UINT32 BspHalAdaptSetTxCarrGateEn(UINT32 uiDifChan, UINT32 uiCarrId, UINT32 uiRatio, UINT32 uiGateEn)   \
ICHAL_ADAPT_FUNC_DEF(SetTxCarrGateEn,uiDifChan,uiCarrId,uiRatio,uiGateEn)
UINT32 BspHalAdaptSetRxCarrGateEn(UINT32 uiDifChan, UINT32 uiCarrId, UINT32 uiRatio, UINT32 uiGateEn)   \
ICHAL_ADAPT_FUNC_DEF(SetRxCarrGateEn,uiDifChan,uiCarrId,uiRatio,uiGateEn)
UINT32 BspHalAdaptSetIcAllGateEn(UINT32 uiGateEn)     \
ICHAL_ADAPT_FUNC_DEF(SetIcAllGateEn,uiGateEn)
UINT32 BspHalAdaptSetIcAllGateEn2(UINT32 uiGateEn)    \
ICHAL_ADAPT_FUNC_DEF(SetIcAllGateEn2,uiGateEn)
UINT32 BspHalAdaptSetBlockGateEn(UINT32 difChanMask, UINT32 uiGateEn)    \
ICHAL_ADAPT_FUNC_DEF(SetBlockGateEn,difChanMask,uiGateEn)

/* 光口节电接口 */
UINT32 BspHalAdaptSetOptSysPwrSaveSwitch(UINT32 sw)
{
    return IcHalApiSetOptSysPwrSaveSwitch(sw);
}

/* 中频节电门控参数初始化(用于保存单板下的门控使能配置) */
UINT32 BspHalAdaptSetDifPwrsaveGateEnCfg(T_BspHalAdaptDifPwrSaveGateCfg* pGatecfg)
{
    INPUT_POINTER_CHECK(pGatecfg); 
    SaveDifCfg(E_DIF_DIFPARA_GATE, (VOID*)pGatecfg, 1, 1);  
    return BSP_OK;
}

/* 获取中频未使用资源门控使能配置(来自单板) */
UINT32 BspHalAdaptGetDifunusedGateEn(UINT32 dir, UINT32 *pEn)
{
    UINT32 loopChan = 0;
    T_DifCfgSave* pSaveCfg = NULL;

    INPUT_POINTER_CHECK(pEn); 

    pSaveCfg = GetDifCfgSave(E_DIF_DIFPARA_GATE);    
    T_BspHalAdaptDifPwrSaveGateCfg *p_dbgDifGatePara = (T_BspHalAdaptDifPwrSaveGateCfg *)(pSaveCfg->pAddr);
    if(NULL == p_dbgDifGatePara)
    {
        return BSP_ERROR;
    }    

    if(RX == dir)
    {
        *pEn = p_dbgDifGatePara->rxUnusedGateEn;
    }
    else if(TX == dir)
    {
        *pEn = p_dbgDifGatePara->txUnusedGateEn;
    }
    else 
    {
        return BSP_ERROR;
    }

    return BSP_OK;
}

/* 中频节电门控参数配置(配置到HAL层) */
UINT32 BspHalAdaptSetPubRelateGate(T_BspHalAdaptPubRelateGateCfg* pGatecfg)
{
    INPUT_POINTER_CHECK(pGatecfg);
    dbgInfoEx("%s freOffsetGateEn=%d symPowChkGateEn=%d highFreqPowGateEn=%d\n",__FUNCTION__,
               pGatecfg->freOffsetGateEn, pGatecfg->symPowChkGateEn, pGatecfg->highFreqPowGateEn);
    return IcHalApiSetPubRelateGate((T_PubRelateGateCfg*)pGatecfg);
}

UINT32 BspHalAdaptSetDifIoGpEn(UINT32 en)
{
    UINT32 retVal    = BSP_OK;
    UINT32 difChn    = 0;
    UINT32 carrId    = 0;
    UINT32 radio     = 0;
    UINT32 loop      = 0;
    T_BspAdaptOneChanCarrInfo *pCarrInfo = NULL;

    dbgInfoEx("%s enter, en=%d\n",__FUNCTION__, en);

    for(difChn=0; difChn<BSP_HALADAPT_IC_CHAN_MAX_NUM; difChn++)
    {
        pCarrInfo = BspHalAdaptGetDifChanCarrInfo(TX, difChn);  
        if(NULL == pCarrInfo || pCarrInfo->carrNum > BSP_MAX_CARR_NUM)
        {
            continue;        
        }
        for(loop=0; loop<pCarrInfo->carrNum; loop++)
        {
            carrId = pCarrInfo->oneCarrInfo[loop].difCarrNo;
            radio = pCarrInfo->oneCarrInfo[loop].carrRadio;
            
            retVal = IcHalApiSetIoGpEn(difChn,carrId,radio,en);
            if(BSP_OK != retVal)
            {
                dbgErr("%s difChn=%d radio=%d carrNo=%d IcHalSetIoGpEn fail! \n", __func__, difChn, radio, carrId);
                return retVal;
            }
            dbgInfoEx("IcHalSetIoGpEn --> difChn=%d radio=%d carrNo=%d en=%d\n", difChn, radio, carrId, en);
        }        
    }
    dbgInfoEx("%s exit, en=%d\n",__FUNCTION__, en);
    
    return BSP_OK;
}

UINT32 BspHalAdaptSetDifIoGpEnAll(UINT32 en)
{
    return IcHalApiInitIoGpEn(en);   
}

/* 关闭L2ss内外端口 */
UINT32 BspHalAdaptNtlL2ssSw(UINT32 sw)
{
    return IcHalApiNtlL2ssSw(sw);   
}

/* 
    打开/关闭Ceva,R8等其它核的CPU代理口
    bit0:ceva
    bit1:r8
*/
UINT32 BspHalAdaptCpuAgentPortSw(UINT32 coreMask, UINT32 sw)
{
    UINT32 retVal = BSP_OK;
    UINT32 retTotal = BSP_OK;

    /* CEVA使用的代理口 */
    if(BIT_VAL(coreMask,0))
    {
        retVal = IcHalApiL2ssTrxpEnable(e_TRXP43,sw);
        retTotal |= retVal;
    }

    /* R8使用的代理口 */
    if(BIT_VAL(coreMask,1))
    {    
        retVal = IcHalApiL2ssTrxpEnable(e_TRXP44,sw);
        retTotal |= retVal;
    }
  
    return retTotal;
}

/* 打开/关闭L2ss单个Trxp端口 */
UINT32 BspHalAdaptL2ssTrxpSwitch(UINT32 trxpIdx, UINT32 sw)
{
    //coverity[cert_exp37_c_violation:SUPPRESS] 
    //coverity[cert_int31_c_violation:SUPPRESS] 
    return IcHalApiL2ssTrxpEnable(trxpIdx, sw);
}

/* 去COV临时增加，待HAL层增加正式的接口后删除 */
extern UINT32 NtlXmacEnable(UINT32 udXmacId);
extern UINT32 NtlXmacDisable(UINT32 udXmacId);

/* 打开/关闭单个Xmac端口 */
UINT32 BspHalAdaptNtlXmacSwitch(UINT32 xMacIdx, UINT32 sw)
{
    UINT32 retVal = BSP_OK;
    
    if(sw)
    {
        retVal = NtlXmacEnable(xMacIdx);
    }
    else 
    {
        retVal = NtlXmacDisable(xMacIdx);
    }
    return retVal;
}

/* 打开/关闭光口模块门控时钟 */
UINT32 BspHalAdaptSetOptAllGateSw(UINT32 sw)
{
    UINT32 retVal = BSP_OK;
    UINT32 retTotal = BSP_OK;

    if(sw)
    {
        /* 打开Prach、FFT门控时钟 */
        retVal = IcHalApiCrmCfgBlockClkEnable(E_IC_CRM_PRACH_FFT_MODE);
        retTotal |= retVal;

        /* 打开OPT(BIF/GF/DIF)门控时钟 */
        retVal = IcHalApiCrmCfgBlockClkEnable(E_IC_CRM_CFG_OPT_GATE);
        retTotal |= retVal;

        /* 打开ROE门控时钟 */
        retVal = IcHalApiCrmCfgBlockClkEnable(E_IC_CRM_CFG_ROE_OFF);
        retTotal |= retVal;        
    }
    else 
    {
        /* 关闭Prach、FFT门控时钟 */
        retVal = IcHalApiCrmCfgBlockClkDisable(E_IC_CRM_PRACH_FFT_MODE);
        retTotal |= retVal;

        /* 关闭OPT(BIF/GF/DIF)门控时钟 */
        retVal = IcHalApiCrmCfgBlockClkDisable(E_IC_CRM_CFG_OPT_GATE);
        retTotal |= retVal;

        /* 关闭ROE门控时钟 */
        retVal = IcHalApiCrmCfgBlockClkDisable(E_IC_CRM_CFG_ROE_OFF);
        retTotal |= retVal;           
    }
    
    return retTotal;
}

/* 打开/关闭L2D门控时钟 */
UINT32 BspHalAdaptSetL2DGateSw(UINT32 sw)
{
    UINT32 retVal = BSP_OK;

    if(sw)
    {
        retVal = IcHalApiCrmCfgBlockClkEnable(E_IC_CRM_CFG_PDCF_GATE);
    }
    else 
    {
        retVal = IcHalApiCrmCfgBlockClkDisable(E_IC_CRM_CFG_PDCF_GATE);
    }

    return retVal;    
}

/* 光口门控控制枚举定义 */
typedef enum _E_OPT_GATE_TYPE {
	  E_OPT_L2D_GATE_IDX = 0,
	  E_OPT_PRACH_MODE_IDX,
	  E_OPT_FFT_MODE_IDX,
	  E_OPT_PRACH_GATE_IDX,
	  E_OPT_FFT_GATE_IDX,
	  E_OPT_DIF_GATE_IDX,
	  E_OPT_GF_GATE_IDX,
	  E_OPT_ROE_GATE_IDX,
      E_OPT_OPT_GATE_TYPE_MAX,
}E_OPT_GATE_TYPE;

/* 因HAL层光口门控控制枚举定义顺序较乱，故通过以下数据调整顺序 */
static E_IC_CRM_OPT_CLK_TYPE s_optClkGateIdx[E_OPT_OPT_GATE_TYPE_MAX][OPT_16T_BLOCK_MAX_NUM] = 
{
    {E_IC_CRM_CFG_PDCF_16T0,    E_IC_CRM_CFG_PDCF_16T1  },
    {E_IC_CRM_PRACH_MODE_16T0,  E_IC_CRM_PRACH_MODE_16T1},
    {E_IC_CRM_FFT_MODE_16T0,    E_IC_CRM_FFT_MODE_16T1  },
    {E_IC_CRM_PRACH_GATE_16T0,  E_IC_CRM_PRACH_GATE_16T1},
    {E_IC_CRM_FFT_GATE_16T0,    E_IC_CRM_FFT_GATE_16T1  },
    {E_IC_CRM_OPT_DIF_16T0,     E_IC_CRM_OPT_DIF_16T1   },
    {E_IC_CRM_OPT_GF_16T0,      E_IC_CRM_OPT_GF_16T1    },
    {E_IC_CRM_ROE_16T0,         E_IC_CRM_ROE_16T1       }    
};

/* 以前后16T为1个Block单位，打开/关闭光口模块门控时钟 */
UINT32 BspHalAdaptSetOptGateSwBy16T(UINT32 blockIdx, UINT32 sw)
{
    UINT32 retVal = BSP_OK;
    UINT32 retTotal = BSP_OK;
    E_IC_CRM_OPT_CLK_TYPE gateIdx = 0;
    UINT32 loop = 0;

    if(blockIdx >=  OPT_16T_BLOCK_MAX_NUM)
    {
        return BSP_ERROR;
    }
    
    /* 打开门控 */
    if(sw)
    {   
        /* 按照E_OPT_GATE_TYPE中定义的顺序依次打开门控 todo 是否需要反向操作???? */
        for(loop=E_OPT_PRACH_MODE_IDX; loop<=E_OPT_GF_GATE_IDX; loop++)
        {
            gateIdx = s_optClkGateIdx[loop][blockIdx];  
            retVal = IcHalApiCrmCfgBlockClkEnable(gateIdx);
            retTotal |= retVal;            
        }      
    }
    /* 关闭门控 */
    else 
    {   
        /* 按照E_OPT_GATE_TYPE中定义的顺序依次关闭门控 */
        for(loop=E_OPT_PRACH_MODE_IDX; loop<=E_OPT_GF_GATE_IDX; loop++)
        {
            gateIdx = s_optClkGateIdx[loop][blockIdx];  
            retVal = IcHalApiCrmCfgBlockClkDisable(gateIdx);
            retTotal |= retVal;            
        }         
    }
    
    return retTotal;
}

/* 以前后16T为1个Block单位，打开/关闭L2D门控时钟 */
UINT32 BspHalAdaptSetL2DGateSwBy16T(UINT32 blockIdx, UINT32 sw)
{
    UINT32 retVal = BSP_OK;
    E_IC_CRM_OPT_CLK_TYPE gateIdx = 0;

    if(blockIdx >=  OPT_16T_BLOCK_MAX_NUM)
    {
        return BSP_ERROR;
    }

    gateIdx = s_optClkGateIdx[E_OPT_L2D_GATE_IDX][blockIdx];    
    if(sw)
    {
        
        retVal = IcHalApiCrmCfgBlockClkEnable(gateIdx);
    }
    else 
    {
        retVal = IcHalApiCrmCfgBlockClkDisable(gateIdx);
    }

    return retVal;    
}

/* 
    控制CORE(CEVA,R8)进入休眠或唤醒
    coreIdx: Ceva:0; R8_0:1; R8_1:2
    workMode:1:休眠; 0:唤醒
*/
UINT32 BspHalAdaptSetCoreWorkMode(UINT32 coreIdx, UINT32 workMode)
{
    if(workMode > CORE_SLEEP)
    {
        return BSP_ERROR;
    }

    if(CEVA_CORE_IDX == coreIdx)
    {
        return IcHalApiCrmCfgCevaWorkMode(workMode);
    }
    else if(R8_0_CORE_IDX == coreIdx || R8_1_CORE_IDX == coreIdx)
    {
        return IcHalApiCrmCfgR8WokrMode(coreIdx-R8_0_CORE_IDX, workMode);    
    }
    else 
    {
        return BSP_ERROR;
    }
}

/* 
    获取CORE(CEVA,R8)的工作模式
    coreIdx: Ceva:0; R8_0:1; R8_1:2
    返回值:休眠为1;0为唤醒
    
*/
UINT32 BspHalAdaptGetCoreWorkMode(UINT32 coreIdx)
{
    UINT32 ulWFMode = 0; //0代表WFI，1代表WFE

    if(CEVA_CORE_IDX == coreIdx)
    {
        return IcHalApiCrmGetCevaWorkMode();
    }
    else if(R8_0_CORE_IDX == coreIdx || R8_1_CORE_IDX == coreIdx)
    {
        return IcHalApiCrmGetR8WorkMode(coreIdx-R8_0_CORE_IDX, ulWFMode);    
    }
    else 
    {
        return BSP_ERROR;
    }

}

/* 控制光口天线使能(BIF/GIF/DIF) */
UINT32 BspHalAdaptSetOptAntEn(UINT32 dir, UINT32 enable)
{
    return IcHalApiSetOptAntEn(dir, enable);
}

/* 打开/关闭FFT和PRACH */
UINT32 BspHalAdaptOptFftPrachSwitch(UINT32 sw)
{
    return IcHalApiOptL1Switch(sw);
}

/* 光口start */
UINT32 BspHalAdaptSetOptStart(VOID)
{
    return IcHalApiSetOptStart();
}

/* 
    光口复位操作
    mode: 0:进入节能;1:退出节能
    action: 0,1,2  
*/
#if 0 /* 有风险，暂不使用，如果使用，需要HAL层封装正式接口 */
UINT32 BspHalAdaptOptReset(UINT32 mode, UINT32 action)
{
    /* 节能前 */
    if(0 == mode)
    {
        if(0 == action)
        {
            wric(0xd4c00434,0xffe);
        }
        else if(1 == action)
        {
            wric(0xd4c00438,0xeeffe);
        }
        else if(2 == action)
        {            
            wric(0xd4c0043c,0x0);
        }
        else 
        {
            return BSP_ERROR;
        }
    }
    /* 节能后 */
    else
    {
        if(0 == action)
        {
            wric(0xd4c00434,0xfff);
        }
        else if(1 == action)
        {
            wric(0xd4c00438,0xfffff);
        }
        else if(2 == action)
        {
            
            wric(0xd4c0043c,0xffffffff);
        }
        else 
        {
            return BSP_ERROR;
        }        
    }
    rdic(0xd4c00434,3);
    
    return BSP_OK;
}
#endif

/* 分Block开或关所有已配置小区的FFT加速器 */
UINT32 BspHalAdaptOptFftSwitchBy16T(UINT32 dir, UINT32 idxBs, UINT32 sw)
{
    return IcHalApiOptFftSwitchBy16T(dir,idxBs,sw);
}

/* 分Block开或关所有已配置小区的DDC加速器 */
UINT32 BspHalAdaptOptDdcSwitchBy16T(UINT32 idxBs, UINT32 sw)
{
    return IcHalApiOptDdcSwitchBy16T(idxBs, sw);
}

/* 分Block控制光口天线使能(BIF/GIF/DIF)  */
UINT32 BspHalAdaptSetOptAntEnByScsIdx(UINT32 dir, UINT32 blockIdx, UINT32 sw)
{
    return IcHalApiSetOptAntEnByScsIdx(dir, blockIdx, sw);
}
#endif

/**************************************************************************
 *                              DPD相关调用接口
 *************************************************************************/
UINT32 BspHalAdaptGetDspRouteInfo(UINT32 difchan,UINT32 band,T_BspHalAdaptDspRouter *pDspRouter)
ICHAL_ADAPT_FUNC_DEF(GetDspRoute,difchan,band,pDspRouter)

UINT32 BspHalAdaptSetAcOrTsCfgEn(UINT32 cfgType)
ICHAL_ADAPT_FUNC_DEF(SetAcCfgEn,cfgType)

UINT32 BspHalAdaptSetTsGpEn(UINT32 difChan, UINT32 gpEn)
ICHAL_ADAPT_FUNC_DEF(SetTsGpEn,difChan,gpEn)
#if 0
/*DPD 黑匣子相关接口*/
BOOLEAN BspHalAdaptIsDspAbnormal(VOID)
{
    return IcHalApiIsDspAbnormal();
}
BOOLEAN BspHalAdaptIsDspBbxFileReady(VOID)
{
    return IcHalApiIsDspBbxFileReady();
}
BOOLEAN BspHalAdaptIsNeedSendNmiToDsp(VOID)
{
    return IcHalApiIsNeedSendNmiToDsp();
}
VOID BspHalAdaptSendNmiToDsp(VOID)
{
    IcHalApiSendNmiToDsp();
    return;
}
BOOLEAN BspHalAdaptWriteDspBbxFile(UINT32 bbxFileFlag)
{
    return IcHalApiWriteDspBbxFile(bbxFileFlag);
}
UINT32  BspHalAdaptDspMonBoxInit(VOID)
{
    return IcHalApiDspMonBoxInit();
}
#endif

/* DTX相关调用接口 */
UINT32 BspHalAdaptDtxCheckParaInit(UINT32 difChan, T_BspHalAdaptDifDtxCheckPara *ptDtxPara)
{
    INPUT_POINTER_CHECK(ptDtxPara);
    SaveDifCfg(E_DIF_DIFPARA_DTX, (VOID*)ptDtxPara, 1, 1);
    return IcHalApiDtxCheckParaInit(difChan, (T_DifDtxCheckPara*)ptDtxPara);
}

/* 下行tdd动态节电配置的对外接口 */
UINT32 BspHalAdaptSetTxTddEn(UINT32 difChan, UINT32 tddEn)
{
    dbgInfoEx("%s difChan=%d tddEn=%d\n", __FUNCTION__, difChan, tddEn);
    return IcHalApiSetTxTddSwEn(difChan, tddEn);
}

/* 上行tdd动态节电配置的对外接口 */
UINT32 BspHalAdaptSetRxTddEn(UINT32 difChan, UINT32 tddEn)
{
    dbgInfoEx("%s difChan=%d tddEn=%d\n", __FUNCTION__, difChan, tddEn);
    return IcHalApiSetRxTddSwEn(difChan, tddEn);
}

UINT32 BspHalAdaptSetDtxCheckEn(UINT32 difChan, UINT32 carrId, UINT32 radio, UINT32 checkEn)
ICHAL_ADAPT_FUNC_DEF(SetDtxCheckEn,difChan,carrId,radio,checkEn)

UINT32 BspHalAdaptSetDtxEnToIo(UINT32 difChan, UINT32 carrId, UINT32 radio, UINT32 checkEn)
ICHAL_ADAPT_FUNC_DEF(SetDtxEnToIo,difChan,carrId,radio,checkEn);

UINT32 BspHalAdaptSetDtxEnToDlbank(UINT32 difChan, UINT32 carrId, UINT32 radio, UINT32 dtxEn)
ICHAL_ADAPT_FUNC_DEF(SetDtxEnToDlbank,difChan,carrId,radio,dtxEn)

/* DTX路由改配的对外接口 */
UINT32 BspHalAdaptSetDtxRoute(UINT32 difChan, UINT32 carrId, UINT32 radio, UINT32 routeEn)
{
    return IcHalApiSetDtxRoute(difChan, carrId, radio, routeEn);
}

/* 获取通道的符号节电次数的对外接口 */
UINT32 BspHalAdaptGetDtxChSymCnt(UINT32 difChan, UINT32 *pSymCnt)
{
    INPUT_POINTER_CHECK(pSymCnt);
    return IcHalApiGetDtxChSymCnt(difChan, pSymCnt);
}

/* 通道清零接口 */
UINT32 BspHalAdaptSetDtxChSymCntClr(UINT32 difChan, UINT32 clrEn)
{
    return IcHalApiSetDtxChSymCntClr(difChan, clrEn);
}

/* DTX路由复位的对外接口 */
UINT32 BspHalAdaptDtxClrAllRoute(VOID)
{
    return IcHalApiDtxClrAllRoute();
}

/*1-处于工装DTX发源场景工装筛0读数字功率和FWD功率 , 0-其他*/
UINT32 BspHalAdaptSetFddScreenZeroPowVal(UINT32 state)
{
    return IcHalApiSetFddScreenZeroPowVal(state);
}

/*FDD的空口帧头补偿标志下发*/
UINT32 BspHalAdaptSetFddAntFrCompFlag(UINT32 FlagVal)
{
    IcHalApiSetFddAntFrCompFlag(FlagVal);
    return BSP_OK;
}

/* 获取通道级符号节电时长的对外接口 */
UINT32 BspHalAdaptGetDtxChSymOffTime(UINT32 difChan, UINT32 *puiSymCntUs)
{
    INPUT_POINTER_CHECK(puiSymCntUs);
    return IcHalApiGetDtxChSymOffTime(difChan, puiSymCntUs);
}

UINT32 BspHalAdaptSetPadFrPolicy(UINT32 *puiPolicyVal, UINT32 uiPadFrNum)
{
    INPUT_POINTER_CHECK(puiPolicyVal);
    return IcHalApiSetPadFrPolicy(puiPolicyVal, uiPadFrNum);
};
UINT32 BspHalAdaptSetFrRouterPadFrSelByFrId(UINT32 uiFrId, UINT32 uiFrSel)
{
    return IcHalApiSetFrRouterPadFrSelByFrId(uiFrId, uiFrSel);
}
/**************************************************************************
 *                             光口PCS&SERDES接口
 *************************************************************************/
/* 保存光口serdes初始化各步骤的结果 */
UINT32 s_optSserdesInitStatus[E_OPT_SERDES_INIT_MAX][OPT_SERDES_LANE_MAX_NUM] = {0};

VOID SaveOptSerdesInitRes(UINT32 initStep, UINT32 laneId, UINT32 result)
{
    if(initStep < E_OPT_SERDES_INIT_MAX && laneId < OPT_SERDES_LANE_MAX_NUM)
    {
        s_optSserdesInitStatus[initStep][laneId] = result;
    }
    return;
}

VOID BspHalAdaptOptSerdesInitStatusClr(VOID)
{
    UINT32 i=0, j=0;
    for(i=0;i<E_OPT_SERDES_INIT_MAX;i++)
    {
        for(j=0;j<OPT_SERDES_LANE_MAX_NUM;j++)
        {
           s_optSserdesInitStatus[i][j] = 0xff; 
        }
    }
    return;
}

UINT32 BspHalAdaptPcsPreInit(T_BspHalAdaptPcsCfg *pcsCfg,UINT32 laneNum)
{
    UINT32 retVal = BSP_OK;

    INPUT_POINTER_CHECK(pcsCfg);
    
    /* 配置port_mod模式 */
    retVal = IcHalApiPreInitPcs(pcsCfg, laneNum);
    SaveOptSerdesInitRes(E_OPT_SERDES_PREPCS, 0, retVal);
    CHECK_RETVAL(IcHalApiPreInitPcs, retVal);

    return BSP_OK;
}

UINT32 BspHalAdaptPcsInit(T_BspHalAdaptPcsCfg *pcsCfg,UINT32 laneNum)
{
    UINT32 retVal = BSP_OK;
    UINT32 retTotal = BSP_OK;

    INPUT_POINTER_CHECK(pcsCfg);
        
    /* 配置pc s剩余配置 */
    retVal = IcHalApiInitPcs(pcsCfg, laneNum);
    retTotal |= retVal;
    CHECK_RETVAL_PRN(IcHalApiInitPcs, retVal);

    /* 配置pcs的flow_token_en,开始产生流量，pcs配置完成 */
    retVal = IcHalApiSetFlowTokenEn(pcsCfg, laneNum);
    retTotal |= retVal;
    CHECK_RETVAL_PRN(IcHalApiSetFlowTokenEn, retVal);

    /* 保存PCS初始化结果 */
    SaveOptSerdesInitRes(E_OPT_SERDES_PCS, 0, retTotal);

    return retTotal;
}

UINT32 BspHalAdaptSetFlowTokenEnPathEnDisable(T_BspHalAdaptPcsCfg *pcsCfg, UINT32 laneNum)
{
    UINT32 retVal = BSP_OK;

    INPUT_POINTER_CHECK(pcsCfg);

    retVal = IcHalApiSetFlowTokenEnPathEnDisable(pcsCfg, laneNum);
    CHECK_RETVAL_PRN(IcHalApiSetFlowTokenEnPathEnDisable, retVal);

    return retVal;
}

UINT32 BspHalAdaptPcsSetPostGloableCfgEn(UINT32 ulPhyOpt, UINT32 ulSwitch)
{
    return IcHalApiPcsSetPostGloableCfgEn(ulPhyOpt,ulSwitch);
}

/* flowtoken_en 单个通道使能控制 */
UINT32 BspHalAdaptPcsFlowTokenEn(UINT32 ulPhyOpt, UINT32 ulSwitch)
{
    UINT32 retVal = BSP_OK;
    retVal = IcHalApiPcsFlowTokenEn(ulPhyOpt, ulSwitch);
    return retVal;
}

/* Started by AICoder, pid:34dcbz0db9vd1d514c100816e06d55093a7776ee */
UINT32 BspHalAdaptQcellAdaptGetOptLinkStatus(VOID)
{
#ifdef UT_FT_TEST
    return BSP_OK;
#endif
    return IcHalApiQcellAdaptGetOptLinkStatus();
}
/* Ended by AICoder, pid:34dcbz0db9vd1d514c100816e06d55093a7776ee */

UINT32 BspHalAdaptSerdesLoadFw(T_SERDES_PARAM *serdesCfg, UINT32 laneNum)
{
    UINT32 loop = 0;
    UINT32 retVal = BSP_OK;
    UINT32 retTotal = BSP_OK;

    INPUT_POINTER_CHECK(serdesCfg);
    
    for(loop=0; loop<laneNum; loop++)
    {
        retVal = IcHalApiLycaLoadFw(serdesCfg[loop].serdesId, serdesCfg[loop].laneId);
        if(BSP_OK != retVal)
        {
            dbgErr("%s IcHalApiLycaLoadFw lane[%d][%d] err\n", __func__, serdesCfg[loop].serdesId, serdesCfg[loop].laneId);
        }
        /* 保存serdes固件加载结果 */
        SaveOptSerdesInitRes(E_OPT_SERDES_LOADFW, serdesCfg[loop].serdesId*4+serdesCfg[loop].laneId, retVal);       
        retTotal |= retVal;
    }

    return retTotal;
}

UINT32 BspHalAdaptSerdesTxInit(T_SERDES_PARAM *serdesCfg, UINT32 laneNum)
{
    UINT32 loop = 0;
    UINT32 retVal = BSP_OK;
    UINT32 serdesId = 0;
    UINT32 laneId = 0;
    UINT32 rate = 0;
    DOUBLE chlen = 0.0;
    UINT32 retTotal = BSP_OK;

    INPUT_POINTER_CHECK(serdesCfg);

    SaveDifCfg(E_OPT_SERDES_PARA, (VOID*)serdesCfg, 1, laneNum); 
    
    for(loop=0; loop<laneNum; loop++)
    {
        serdesId = serdesCfg[loop].serdesId;
        laneId = serdesCfg[loop].laneId;
        rate = serdesCfg[loop].rate;
        chlen = serdesCfg[loop].chlen;
        
        /* TX初始化（发送PRBS） */
        retVal = IcHalApiLycaInitTx(serdesId, laneId, rate, chlen);
        if(BSP_OK != retVal)
        {
            dbgErr("%s IcHalApiLycaInitTx lane[%d][%d] rate=%d chlen=%f err\n",
                __func__, serdesId, laneId, rate, chlen);
        }
        /* 保存serdesTX初始化结果 */
        //coverity[cert_int30_c_violation:SUPPRESS]
        SaveOptSerdesInitRes(E_OPT_SERDES_TXINIT, serdesId*4+laneId, retVal);  
        retTotal |= retVal;
    }

    return retTotal;
}

UINT32 BspHalAdaptSetSerdesTxEq(T_SERDES_PARAM *serdesCfg, UINT32 laneNum)
{
    UINT32 loop = 0;
    UINT32 retVal = BSP_OK;
    UINT32 serdesId = 0;
    UINT32 laneId = 0;
    UINT32 txEqEn = 0;
    INT32 eoh0 = 0;
    INT32 eoh1 = 0;
    INT32 eoh2 = 0;
    INT32 eoh3 = 0;
    UINT32 retTotal = BSP_OK;

    INPUT_POINTER_CHECK(serdesCfg);

    for(loop=0; loop<laneNum; loop++)
    {
        serdesId = serdesCfg[loop].serdesId;
        laneId = serdesCfg[loop].laneId;
        txEqEn = serdesCfg[loop].txEqEn;
        eoh0 = serdesCfg[loop].eoh0;
        eoh1 = serdesCfg[loop].eoh1;
        eoh2 = serdesCfg[loop].eoh2;
        eoh3 = serdesCfg[loop].eoh3;

        if(!txEqEn )
        {
            dbgInfoEx("%s serdesId[%d] laneId[%d] txEqEn[%d] continue\n", __func__, serdesId, laneId, txEqEn);
            continue;
        }
        
        dbgInfoEx("%s serdesId[%d] laneId[%d] txEqEn[%d] eoh0=%d eoh1=%d eoh2=%d eoh3=%d\n",
                    __func__, serdesId, laneId, txEqEn, eoh0, eoh1, eoh2, eoh3);
        
        /* TX初始化（发送PRBS） */
        //coverity[cert_int31_c_violation:SUPPRESS]
        retVal = IcHalApiLycaSetTxFirCoff(serdesId, laneId, eoh0, eoh1, eoh2, eoh3);
        if(BSP_OK != retVal)
        {
            dbgErr("%s IcHalApiLycaSetTxFirCoff lane[%d][%d] eoh0=%d eoh1=%d eoh2=%d eoh3=%d err\n", 
                __func__, serdesId, laneId, eoh0, eoh1, eoh2, eoh3);
        }
        /* 保存serdesTX初始化结果 */
        //coverity[cert_int30_c_violation:SUPPRESS] 
        SaveOptSerdesInitRes(E_OPT_SERDES_TXEQ, serdesId*4+laneId, retVal);  
        retTotal |= retVal;
    }

    return retTotal;
}

UINT32 BspHalAdaptSerdesRxInit(T_SERDES_PARAM *serdesCfg, T_BspHalAdaptSerdesRxCfg *serdesRxCfg,UINT32 laneNum)
{
    UINT32 loop = 0;
    UINT32 retVal = BSP_OK;
    UINT32 serdesId = 0;
    UINT32 laneId = 0;
    UINT32 retTotal = BSP_OK;
    /*T_BspHalAdaptSerdesRxCfg *tmpserdesRxCfg = NULL;*/

    INPUT_POINTER_CHECK(serdesCfg);
    INPUT_POINTER_CHECK(serdesRxCfg);

    for(loop=0; loop<laneNum; loop++)
    {
        serdesId = serdesCfg[loop].serdesId;
        laneId = serdesCfg[loop].laneId;
        /*tmpserdesRxCfg = &serdesRxCfg[loop];*/
        /* RX初始化 */
        dbgInfoEx("%s serdesId[%d] laneId[%d] phaseMin[%d]  phaseMax[%d]  uVga[%d]  uCmtermCtrl[%d]\n",  __func__, serdesId, laneId,
                   serdesRxCfg[loop].phaseMin,serdesRxCfg[loop].phaseMax,serdesRxCfg[loop].uVga,serdesRxCfg[loop].uCmtermCtrl);
        retVal = IcHalApiLycaInitRx(serdesId, laneId,&serdesRxCfg[loop]);
        if(BSP_OK != retVal)
        {
            dbgErr("%s IcHalApiLycaInitRx lane[%d][%d] err\n", __func__, serdesId, laneId);
        }
        /* 保存serdesRX初始化结果 */
        //coverity[cert_int30_c_violation:SUPPRESS] 
        SaveOptSerdesInitRes(E_OPT_SERDES_RXINIT, serdesId*4+laneId, retVal);  
        retTotal |= retVal;
    }

    return retTotal;
}

UINT32 BspHalAdaptLycaRxDataNrzEn(UINT32 serdesId, UINT32 laneId, UINT32 ulSwitch)
{
	return IcHalApiLycaRxDataNrzEn(serdesId,laneId,ulSwitch);
}

UINT32 BspHalAdaptSerdesChgNormal(T_SERDES_PARAM *serdesCfg, UINT32 laneNum)
{
    UINT32 loop = 0;
    UINT32 retVal = BSP_OK;
    UINT32 serdesId = 0;
    UINT32 laneId = 0;
    UINT32 retTotal = BSP_OK;

    INPUT_POINTER_CHECK(serdesCfg);
    
    for(loop=0; loop<laneNum; loop++)
    {
        serdesId = serdesCfg[loop].serdesId;
        laneId = serdesCfg[loop].laneId;
        
        /* PRBS模式切换到功能模式 */
        retVal = IcHalApiLycaTccSwitch(serdesId, laneId);
        if(BSP_OK != retVal)
        {
            dbgErr("%s IcHalApiLycaTccSwitch lane[%d][%d] err\n", __func__, serdesId, laneId);
        }
        /* 保存serdesRX初始化结果 */
        //coverity[cert_int30_c_violation:SUPPRESS] 
        SaveOptSerdesInitRes(E_OPT_SERDES_NORMAL, serdesId*4+laneId, retVal);  
        retTotal |= retVal;
    }

    return retTotal;
}

UINT32 BspHalAdaptPcsGetLinkPcsSta(UINT32 ulPhyOpt, UINT32 *pStatus)
{
    return IcHalApiGetLinkPcsSta(ulPhyOpt, pStatus);
}
/*判断SERDES的CDR锁定状态*/
UINT32 BspHalAdaptLycaGetCdrStatus(UINT32 serdesId, UINT32 laneId)
{
    UINT32 retVal = BSP_OK;
    UINT32 uCdrLock = 0;

    //coverity[cert_int30_c_violation:SUPPRESS]
    if(serdesId*4+laneId >= OPT_SERDES_LANE_MAX_NUM)
    {
        return BSP_ERROR;
    }

    retVal = IcHalApiLycaGetCdrStatus(serdesId, laneId, &uCdrLock);
    if(BSP_OK != retVal)
    {
        return BSP_ERROR;
    }
    return uCdrLock;
}

UINT32 BspHalAdaptLycaInitRx(UINT32 serdesId, UINT32 laneId,T_BspHalAdaptSerdesRxCfg *serdesRxCfg)
{
    UINT32 retVal = BSP_OK;
    static UINT16 initCounter[OPT_SERDES_LANE_MAX_NUM] = {0};
    UINT32 record = 0;

    if(serdesId*4+laneId < OPT_SERDES_LANE_MAX_NUM)
    {
        initCounter[serdesId*4+laneId]++;
        record |= initCounter[serdesId*4+laneId]<<16;
    }
    else
    {
        return BSP_ERROR;
    }
    
    retVal = IcHalApiLycaInitRx(serdesId, laneId,serdesRxCfg);
    if(BSP_OK != retVal)
    {
        dbgErr("%s IcHalApiLycaInitRx lane[%d][%d] err\n", __func__, serdesId, laneId);
        record &= 0xffff0000;
        record |= 1;
    }
    else
    {
        record &= 0xffff0000;
        record |= 0;       
    }
    /* 保存serdes切换正常模式的结果 */
    SaveOptSerdesInitRes(E_OPT_SERDES_APPRXINIT, serdesId*4+laneId, record); 

    return retVal;
}

UINT32 BspHalAdaptLycaTccSwitch(UINT32 serdesId, UINT32 laneId)
{
    UINT32 retVal = BSP_OK;
    static UINT16 swCounter[OPT_SERDES_LANE_MAX_NUM] = {0};
    UINT32 record = 0;

    if(serdesId*4+laneId < OPT_SERDES_LANE_MAX_NUM)
    {
        swCounter[serdesId*4+laneId]++;
        record |= swCounter[serdesId*4+laneId]<<16;
    }
    else
    {
        return BSP_ERROR;
    }

    retVal = IcHalApiLycaTccSwitch(serdesId, laneId);
    if(BSP_OK != retVal)
    {
        dbgErr("%s IcHalApiLycaTccSwitch lane[%d][%d] err\n", __func__, serdesId, laneId);
        record &= 0xffff0000;
        record |= 1;
    }
    else
    {
        record &= 0xffff0000;
        record |= 0;       
    }
    /* 保存serdes切换正常模式的结果 */
    SaveOptSerdesInitRes(E_OPT_SERDES_APPNORMAL, serdesId*4+laneId, record); 

    return retVal;
}

UINT32 BspHalChangeSerdesTxLaneRate(UINT32 serdesId,UINT32 laneId,UINT32 rate, T_OPTRATE_SERDES_PARAM *pSerdesPara )
{
    UINT32 retVal = BSP_OK;
    UINT32 loop = 0;
    T_BspHalAdaptSerdesTxCfg txSerdesPara = {0};

    for(loop = 0; loop < OPT_RATE_TYPE; loop++)
    {
       if(pSerdesPara->txRatePara[loop].rate == rate)
       {
           memcpy_s(&txSerdesPara,sizeof(T_BspHalAdaptSerdesTxCfg),&pSerdesPara->txRatePara[loop],sizeof(T_BspHalAdaptSerdesTxCfg));
           if((laneId == 1)&&(pSerdesPara->txRateParaEx[loop].rate  == rate))  /*光口用serdes的lane0 lane1  此分支表示两个laneTX参数不一致 新增需求*/
           {
               memcpy_s(&txSerdesPara,sizeof(T_BspHalAdaptSerdesTxCfg),&pSerdesPara->txRateParaEx[loop],sizeof(T_BspHalAdaptSerdesTxCfg));
           }
           break;
       }
    }
    dbgInfoEx("%s serdesId[%d] laneId[%d] chlen[%f]\n",  __func__, serdesId, laneId, txSerdesPara.chlen);

    retVal |= IcHalApiLycaInitTx(serdesId,laneId,rate,txSerdesPara.chlen);
    if(BSP_OK != retVal)
    {
        dbgErr("%s IcHalApiLycaInitTx lane[%d][%d] err\n", __func__, serdesId, laneId);
    }
    if(0 != txSerdesPara.txEqEn)
    {
        dbgInfoEx("%s serdesId[%d] laneId[%d] txEqEn[%d] eoh0=%d eoh1=%d eoh2=%d eoh3=%d\n",
                    __func__, serdesId, laneId,txSerdesPara.txEqEn, txSerdesPara.eoh0, txSerdesPara.eoh1, txSerdesPara.eoh2, txSerdesPara.eoh3);
        retVal = IcHalApiLycaSetTxFirCoff(serdesId, laneId, txSerdesPara.eoh0, txSerdesPara.eoh1, txSerdesPara.eoh2, txSerdesPara.eoh3);
        if(BSP_OK != retVal)
        {
            dbgErr("%s IcHalApiLycaSetTxFirCoff error\n", __func__);
            return retVal;
        }
    }
    return retVal;
}
/*serdes RX方向配置*/
UINT32 BspHalChangeSerdesRxLaneRate(UINT32 serdesId,UINT32 laneId,UINT32 rate, T_OPTRATE_SERDES_PARAM *pSerdesPara )
{
    UINT32 retVal = BSP_OK;
    UINT32 loop = 0;
    UINT32 retryTime = 3;
    T_BspHalAdaptSerdesRxCfg rxSerdesPara = {0};

    for(loop = 0; loop < OPT_RATE_TYPE; loop++)
    {
       if(pSerdesPara->txRatePara[loop].rate == rate)
       {
           memcpy_s(&rxSerdesPara,sizeof(T_BspHalAdaptSerdesRxCfg),&pSerdesPara->rxRatePara[loop],sizeof(T_BspHalAdaptSerdesRxCfg));
           break;
       }
    }
    if(loop == OPT_RATE_TYPE)
    {
        dbgErr("Get Rx Serdes Para Failed\n");
        return BSP_ERROR;
    }
    for(loop = 0; loop < retryTime; loop++)
    {
        retVal = IcHalApiLycaInitRx(serdesId,laneId,&rxSerdesPara);
        if(BSP_OK != retVal)
        {
            dbgErr("%s IcHalApiLycaInitRx lane[%d][%d] err\n", __func__, serdesId, laneId);
            continue;
        }
        break;
    }

    if(loop == retryTime)  /*多次尝试初始化rxserdes还不行*/
    {
       return BSP_ERROR;
    }
    retVal = IcHalApiLycaTccSwitch(serdesId,laneId);
    if(BSP_OK != retVal)
    {
       dbgErr("%s IcHalApiLycaTccSwitch lane[%d][%d] err\n", __func__, serdesId, laneId);
        return retVal;
    }
    return retVal;
}
UINT32 BspHalAdaptGetLycaSerdesRate(UINT32 serdesId, UINT32 laneId, UINT32 *pRate)
{
    return IcHalApiGetLycaSerdesRate(serdesId,laneId,pRate);
}
/* 判断给定载波是否当前配置中的有效载波 */
UINT32 BspHalAdaptCheckCarrValid(UINT32 dir, UINT32 difChan, UINT32 radio, UINT32 carrNo)
{
    UINT32 carrId       = 0;
    UINT32 radioMode    = 0;
    UINT32 loop         = 0;
    T_BspAdaptOneChanCarrInfo *pCarrInfo = NULL;

    if(dir > TX ||difChan >= BSP_IC4_DIF_CHAN_NUM)
    {
        return BSP_ERROR;
    }

    pCarrInfo = BspHalAdaptGetDifChanCarrInfo(dir, difChan);
    if(NULL == pCarrInfo)
    {
        return BSP_ERROR;
    }

    for(loop=0; loop<pCarrInfo->carrNum; loop++)
    {
        carrId = pCarrInfo->oneCarrInfo[loop].difCarrNo;
        radioMode = pCarrInfo->oneCarrInfo[loop].carrRadio;
        if(carrId == carrNo && radioMode == radio)
        {
            return BSP_OK;
        }
    }

    return BSP_ERROR;
}

UINT32 BspApiLycaTxDataNrzEn(UINT32 serdesId, UINT32 laneId, UINT32 ulSwitch)
{
    return IcHalApiLycaTxDataNrzEn(serdesId, laneId, ulSwitch);
}

UINT32 BspApiLycaGetTxDataNrzEn(UINT32 serdesId, UINT32 laneId, UINT32 *pSwitch)
{
    INPUT_POINTER_CHECK(pSwitch);
    return IcHalApiLycaGetTxDataNrzEn(serdesId, laneId, pSwitch);
}
/*读取serdes 眼高 lycasetprintlevel 3 可以看具体打印*/
UINT32 BspHalAdaptLycaRecnt0HistNrz(UINT32 serdesId, UINT32 laneId)
{
    return IcHalApiLycaRecnt0HistNrz(serdesId, laneId);
}

/*设置serdes是否重配的标志给IC*/
VOID BspHalAdaptSetLycaSoftResetFlag(UINT32 flag)
{
#ifndef _BSP_WITH_WFS
   IcHalApiSetLycaSoftResetFlag(flag);   /*工装不需要此功能默认即可*/
   IcHalSetOptInitFlag(flag);
#endif
}

/*获取serdes是否重配的标志*/
UINT32 BspHalAdaptGetLycaSoftResetFlag(VOID)
{
    return IcHalApiGetLycaSoftResetFlag();
}

/*设置UMTS载波复制标志*/
UINT32 BspHalAdaptSetFddUmtsVirCellFlag(UINT32 isVirCell)
{
    return IcHalApiSetFddUmtsVirCellFlag(isVirCell);
}

/*获取UMTS载波复制标志*/
UINT32 BspHalAdaptGetFddUmtsVirCellFlag(VOID)
{
    return IcHalApiGetFddUmtsVirCellFlag();
}

UINT32 BspHalAdaptSetSwOe(UINT32 enable)
{
    return IcHalApiSetSwOe(enable);
}

UINT32 BspHalAdaptGetAwRpt(UINT32 *puiAwRpt)
{
    return IcHalApiGetAwRpt(puiAwRpt);
}

UINT32 BspHalAdaptGetWirelessFrId(UINT32 *puiFrId)
{
    INPUT_POINTER_CHECK(puiFrId);
    return IcHalApiGetWirelessFrId(puiFrId);
}

UINT32 BspHalAdaptSetSwPadDebugEn(UINT32 swIdx, UINT32 bitEn)
{
    return IcHalApiSetSwPadDebugEn(swIdx,  bitEn);
}

UINT32 BspHalAdaptSetSwPadDebugCfg(UINT32 swIdx, UINT32 val)
{
    return IcHalApiSetSwPadDebugCfg(swIdx, val);
}

UINT32 BspHalAdaptSetUePaFrameId(UINT32 uiChanId, UINT32 uiFrameId)
{
    return IcHalApiSetUePaFrameId(uiChanId, uiFrameId);
}

UINT32 BspHalAdaptSetUePaAntFrDly(UINT32 idx, UINT32 frDly)
{
    return IcHalApiSetUePaAntFrDly( idx, frDly);
} 
/* Started by AICoder, pid:z234e23b970302214af90a4610533e2ae031a022 */
UINT32 BspHalAdaptSetAcCtrlAntFrDly(UINT32 idx, UINT32 frDly)
{
    return IcHalApiSetAcCtrlAntFrDly( idx, frDly);
} 

UINT32 BspHalAdaptGetFrTmValue(UINT32 tddId, UINT32 radioMode)
{
    return IcHalApiGetFrTmVal( tddId, radioMode);
} 
/* Ended by AICoder, pid:z234e23b970302214af90a4610533e2ae031a022 */

UINT32 BspHalAdaptSetUeLnaFrameId(UINT32 uiChanId, UINT32 uiFrameId)
{
    return IcHalApiSetUeLnaFrameId(uiChanId, uiFrameId);
}

UINT32 BspHalAdaptSetUeLnaAntFrDly(UINT32 idx, UINT32 frDly)
{
    return IcHalApiSetUeLnaAntFrDly( idx, frDly);
} 

UINT32 BspHalAdaptSetUeTxEnFrameId(UINT32 uiChanId, UINT32 uiFrameId)
{
    return IcHalApiSetUeTxEnFrameId(uiChanId, uiFrameId);
}

UINT32 BspHalAdaptSetUeTxEnAntFrDly(UINT32 idx, UINT32 frDly)
{
    return IcHalApiSetUeTxEnAntFrDly( idx, frDly);
}

UINT32 BspHalAdaptSetUeRxEnFrameId(UINT32 uiChanId, UINT32 uiFrameId)
{
    return IcHalApiSetUeRxEnFrameId(uiChanId, uiFrameId);
}

UINT32 BspHalAdaptSetUeRxEnAntFrDly(UINT32 idx, UINT32 frDly)
{
    return IcHalApiSetUeRxEnAntFrDly( idx, frDly);
}

UINT32 BspHalAdaptSetUeAmpFrameId(UINT32 uiChanId, UINT32 uiFrameId)
{
    return IcHalApiSetUeAmpFrameId(uiChanId, uiFrameId);
}

UINT32 BspHalAdaptSetUeAmpAntFrDly(UINT32 idx, UINT32 frDly)
{
    return IcHalApiSetUeAmpAntFrDly( idx, frDly);
}

UINT32 BspHalAdaptGetGlobleOutFrDir(UINT32 *pFrDir)
{
    INPUT_POINTER_CHECK(pFrDir);
    return IcHalApiGetGlobleOutFrDir(pFrDir);
}

#if 0
/*ecpri使用，暂时不放开*/
UINT32 BspHalAdaptNtlL2ssSetTrxpMode(T_BspHalAdaptNtlTrxpCfg *ptTrxpModeCfg,UINT32 num)
ICHAL_ADAPT_FUNC_DEF(NtlL2ssSetTrxpMode,ptTrxpModeCfg,num)

UINT32 BspHalAdaptNtlL2ssSetXmacCfg(T_BspHalAdaptNtlPortCfg *ptNtlPortCfg,UINT32 num)
ICHAL_ADAPT_FUNC_DEF(NtlL2ssSetXmacCfg,ptNtlPortCfg,num)

/* 控制字配置 */
UINT32 BspHalAdaptSetEcpriCwChnCfg(T_BspHalAdaptNtlCwChnCfg *ptNtlCwChnCfg, UINT32 uNum)
{
    INPUT_POINTER_CHECK(ptNtlCwChnCfg);

    SaveDifCfg(E_OPT_ROECW_CFG, (VOID*)ptNtlCwChnCfg, uNum, uNum); 
    return IcHalApiSetEcpriCwChnCfg((T_NtlCwChnCfg *)ptNtlCwChnCfg, uNum);
}

/* ERS快配接口 */
UINT32 BspHalAdaptSetFastErsCfg(VOID)
{
    dbgInfoEx("%s enter\n", __func__);
    return IcHalApiSetFastErsCfg();
}
#endif
/**************************************************************************
 *                  IC Trx PIN管脚和Transceiver的对应关系
 *************************************************************************/
static T_IC_TRX_PIN_MAP s_IcTrxPinMap = {{0,1}};

UINT32 BspHalAdaptSetTrxPinMap(T_IC_TRX_PIN_MAP *p_TrxPinMap)
{
    INPUT_POINTER_CHECK(p_TrxPinMap);
    memcpy_s(&s_IcTrxPinMap, sizeof(T_IC_TRX_PIN_MAP), p_TrxPinMap, sizeof(T_IC_TRX_PIN_MAP));
    return BSP_OK;
}

UINT32 BspHalAdaptGetTrxPinId(UINT32 TrxChipIdx, UINT32 *pPinId)
{
    if(TrxChipIdx>=HALADAPT_TRANS_MAX_NUM)
    {
        return BSP_ERROR;
    }
    *pPinId = s_IcTrxPinMap.icPinId[TrxChipIdx];
    return BSP_OK;
}

/* Transceiver复位接口 */
UINT32 BspHalAdaptResetTransceiverChip(UINT32 chip, UINT32 resetVal)
{
    UINT32 pinId = 0;
    UINT32 ret = BSP_OK;
    if(BspHalAdaptGetTrxPinId(chip, &pinId) != BSP_OK)
    {
        return BSP_ERROR;
    }
    dbgInfoEx("%s pinId=%d, val=%d\n", __func__, pinId, resetVal);
    /*暂时屏蔽*/
    ret = IcHalApiResetTransceiverChip(pinId, resetVal);
    return ret;
}
#if 0
/* 栅压DAC复位接口 */
UINT32 BspHalAdaptResetDacChip(UINT32 chip, UINT32 resetVal) 
{
    /* 4.0中目前暂时无法通过IC控制栅压DAC的复位引脚，
       另外0648和7948也无复位引脚,本接口为预留接口，暂时保持空实现
    */
    return BSP_OK;
}

/**************************************************************************
*                            工装相关接口
**************************************************************************/
UINT32 BspHalAdaptSetTsgFlag(UINT32 wfsFlag)    \
ICHAL_ADAPT_FUNC_DEF(SetTsgFlag,wfsFlag)
#endif


UINT32 BspHalAdaptDlBankTsgCtrl(UINT32 difChan, UINT32 carrNo, UINT32 radioMode, UINT32 tsgType, UINT32 mode, UINT32 sw)
{
    UINT32 ret = BSP_OK;
    ret = IcHalDlBankTsgCtrl(difChan, carrNo, radioMode, tsgType, mode, sw);
    return ret;
}

/* 中频发单音 */
UINT32 BspHalAdaptDifTsgSwitch(UINT32 antChan, UINT32 carrNo, UINT32 radioMode, UINT32 sw)
{
    UINT32 ret = BSP_OK;
    ret =  IcHalApiDCTsgCtrl(antChan,  carrNo,  radioMode, sw);
    return ret;
}

/* 中频发宽谱 */
UINT32 BspHalAdaptDifDlPreTsgSwitch(UINT32 antChan, UINT32 carrNo, UINT32 radioMode, UINT32 sw)
{
    UINT32 ret = BSP_OK;
    ret =  IcHalApiDlPreTsgCtrl(antChan,  carrNo,  radioMode, sw);
    return ret;
}

/* 中频cfr处发宽谱  内部已经调整大小到-14 IcHalDlCfrTsgCtrl + DlCfrSetTsgData*/
UINT32 BspHalAdaptDifCfrTsgSwitch(UINT32 difChan, UINT32 sw)
{
    UINT32 ret = BSP_OK;
    ret = IcHalApiSetDlCfrTsgCtrl(difChan, sw);
    return ret;
}

/* 中频dlpre发GSM载波TSG宽谱 */
UINT32 BspHalAdaptSetGsmTsgCtrl(UINT32 difChan, UINT32 carrNo, UINT32 radioMode, UINT32 sw)
{
    UINT32 ret = BSP_OK;
    ret = IcHalApiSetGsmTsgCtrl(difChan, carrNo, radioMode, sw);
    return ret;
}

UINT32 BspHalAdaptSetUlChTsgCtrl(UINT32 uiDifChan, UINT32 uiEn)
{
	UINT32 ret = BSP_OK;
	IcHalApiSetUlChTsgCtrl(uiDifChan,uiEn);
	return ret;
}

/* 积分带宽之后恢复成型系数配置 */
UINT32 BspHalAdaptResetRcf(UINT32 uiDir)
{
    UINT32 ret = BSP_OK;
    ret = IcHalApiResetRcf(uiDir);
    return ret;
}

UINT32 BspHalAdaptGetSysLd(UINT32 index,UINT32 *sta)
{
    UINT32 ret = BSP_OK;
    INPUT_POINTER_CHECK(sta);
    if(index == 0)
    {
        ret =  IcHalApiGetPaptUnusStatusLd0(sta);
    }
    else
    {
    	 ret =  IcHalApiGetPaptUnusStatusLd1(sta);
    }
    return ret;
}
UINT32 BspHalAdaptGetRfTxPllLd(UINT32 *sta)
{
    UINT32 ret = BSP_OK;

    INPUT_POINTER_CHECK(sta);
    ret =  IcHalApiGetPaptUnusStatusPaOff(sta);

    return ret;
}

UINT32 BspHalAdaptGetQcellT12Diff(UINT32 *pDiffNs, UINT32 ulTe14)
{
    UINT32 ret = BSP_OK;

    INPUT_POINTER_CHECK(pDiffNs);
    ret =  IcHalApiGetQcellT12Diff(pDiffNs, ulTe14);

    return ret;
}

UINT32 BspHalAdaptGetRfRxPllLd(UINT32 *sta)
{
    UINT32 ret = BSP_OK;

    INPUT_POINTER_CHECK(sta);
    ret =  IcHalApiGetPaptUnusStatusDataOff(sta);

    return ret;
}

UINT32 BspHalPsyncTimGernInit(UINT32 irqId, UINT32 timePeriod, UINT32 timeOffset, UINT32 inter, UINT32 ctrl)
{
    return HalIcPsyncTimGernXInit(irqId, timePeriod, timeOffset, inter, ctrl);
}

UINT32 BspHalAdaptPsyncCfg(UINT32 psyncMode)    \
ICHAL_ADAPT_FUNC_DEF(PsyncCfg,psyncMode)
UINT32 BspHalAdaptOptSdsCheckError(UINT32 serdesId, UINT32 laneId, E_LYCA_PRBS_MODE mode, UINT32 sw, UINT32 clr)
ICHAL_ADAPT_FUNC_DEF(OptSdsCheckError,serdesId,laneId,mode,sw,clr)
UINT32 BspHalAdaptOptSdsSendPrbs(UINT32 serdesId, UINT32 laneId, E_LYCA_PRBS_MODE mode, UINT32 sw)
ICHAL_ADAPT_FUNC_DEF(OptSdsSendPrbs,serdesId,laneId,mode,sw)
UINT32 BspHalAdaptSetCpuForceOpen(UINT32 swIdx, UINT32 chan, UINT32 status, UINT32 period)
ICHAL_ADAPT_FUNC_DEF(SetCpuForceOpen,swIdx,chan,status,period)
UINT32 BspHalAdaptSetCpuForceOff(UINT32 swIdx)
ICHAL_ADAPT_FUNC_DEF(SetCpuForceOff,swIdx)

UINT32 BspHalAdaptJ204SdsSendPrbs(UINT32 laneId,E_PRBSMODE_J204 prbsMode)
ICHAL_ADAPT_FUNC_DEF(J204SdsSendPrbs,laneId,prbsMode)
UINT32 BspHalAdaptJ204SdsCheckError(UINT32 laneId, E_PRBSMODE_J204 prbsMode, UINT32 clr)
ICHAL_ADAPT_FUNC_DEF(J204SdsCheckError,laneId,prbsMode,clr)
UINT32 BspHalAdaptCrmGetLockStatusPll(UINT32 chipId, UINT32 pllId, UINT32 *status)     \
ICHAL_ADAPT_FUNC_DEF(CrmGetLockStatusPll,chipId,pllId,status)
UINT32 BspHalAdaptCrmGetUnLockRecordPll(UINT32 chipId, UINT32 pllId, UINT32 *status)     \
ICHAL_ADAPT_FUNC_DEF(CrmGetUnLockRecordPll,chipId,pllId,status)
UINT32 BspHalAdaptCrmGetUnLockCntPll(UINT32 chipId, UINT32 pllId, UINT32 *status)     \
ICHAL_ADAPT_FUNC_DEF(CrmGetUnLockCntPll,chipId,pllId,status)
UINT32 BspHalAdaptCrmAlmShortPwrENStat(UINT32 bitStart, UINT32 bitEnd, UINT32 *PwrEnStat)     \
ICHAL_ADAPT_FUNC_DEF(CfgCrmAlmShortPwrENStat,bitStart,bitEnd,PwrEnStat)
UINT32 BspHalAdaptCrmAlmShortForceCloseState(UINT32 bitStart, UINT32 bitEnd, UINT32 *ArmShortState)     \
ICHAL_ADAPT_FUNC_DEF(CrmAlmShortForceCloseState,bitStart,bitEnd,ArmShortState)
UINT32 BspHalAdaptCfgCrmAlmShortForceCloseState(UINT32 mode, UINT32 bitStart, UINT32 bitEnd)     \
ICHAL_ADAPT_FUNC_DEF(CfgCrmAlmShortForceCloseState,mode,bitStart,bitEnd)
UINT32 BspHalAdaptCfgCrmAlmShortPwrEN(UINT32 sta, UINT32 bitStart, UINT32 bitEnd)     \
ICHAL_ADAPT_FUNC_DEF(CfgCrmAlmShortPwrEN,sta,bitStart,bitEnd)
UINT32 BspHalAdaptSetAcCtrlTop4Sel1(UINT32 uiTimingId, UINT32 uiSel)     \
ICHAL_ADAPT_FUNC_DEF(SetAcCtrlTop4Sel1,uiTimingId,uiSel)
UINT32 BspHalAdaptSetAcCtrlOeEn(UINT32 uiIdx, UINT32 uiEn)     \
ICHAL_ADAPT_FUNC_DEF(SetAcCtrlOeEn,uiIdx,uiEn)
UINT32 BspHalAdaptGetAcCtrlOeEn(UINT32 uiIdx, UINT32 *puiEn)     \
ICHAL_ADAPT_FUNC_DEF(GetAcCtrlOeEn,uiIdx,puiEn)
UINT32 BspHalAdaptGetAcCtrlTop4Sel1(UINT32 uiTimingId, UINT32 *puiSel)     \
ICHAL_ADAPT_FUNC_DEF(GetAcCtrlTop4Sel1,uiTimingId,puiSel)

UINT32 BspHalAdaptSetUlTddSwHigh(UINT32 uiDifChan, UINT32 uiHigh)
{
    return IcHalApiSetUlTddSwHigh(uiHigh);
}
UINT32 BspHalAdaptSetDlTddSwHigh(UINT32 uiDifChan, UINT32 uiCarrId, UINT32 uiCarrRadio, UINT32 uiHgih)
{
    return IcHalApiSetDlTddSwHigh(uiHgih);
}

UINT32 BspHalAdaptSyncOutOn(VOID)   \
ICHAL_ADAPT_FUNC_DEF(SyncOutOn)
UINT32 BspHalAdaptSyncOutOff(VOID)  \
ICHAL_ADAPT_FUNC_DEF(SyncOutOff)
UINT32 BspHalAdaptTrigOutOn(VOID)   \
ICHAL_ADAPT_FUNC_DEF(TrigOutOn)
UINT32 BspHalAdaptTrigOutOff(VOID)  \
ICHAL_ADAPT_FUNC_DEF(TrigOutOff)
#if 0
UINT32 BspHalAdaptSetVgaByPass(UINT32 isBypass)                                                                    \
ICHAL_ADAPT_FUNC_DEF(SetVgaByPass,isBypass)

UINT32 BspHalAdaptGetFsyncStatus()     \
ICHAL_ADAPT_FUNC_DEF(GetFsyncStatus)
UINT32 BspHalAdaptGetAntFrShake(UINT32 blockId, UINT32 *frShakeInt)     \
ICHAL_ADAPT_FUNC_DEF(GetAntFrShake,blockId,frShakeInt)
UINT32 BspHalAdaptCrmGetRefDetStatusROE(UINT32 chipId, UINT32 *refStatus)     \
ICHAL_ADAPT_FUNC_DEF(CrmGetRefDetStatusROE,chipId,refStatus)
UINT32 BspHalAdaptCrmGetRefDetStatusOpt(UINT32 chipId, UINT32 *refStatus)     \
ICHAL_ADAPT_FUNC_DEF(CrmGetRefDetStatusROE,chipId,refStatus)
UINT32 BspHalAdaptCrmGetRefDetStatusJ204_0(UINT32 chipId, UINT32 *refStatus)     \
ICHAL_ADAPT_FUNC_DEF(CrmGetRefDetStatusJ204_0,chipId,refStatus)
UINT32 BspHalAdaptCrmGetRefDetStatusJ204_1(UINT32 chipId, UINT32 *refStatus)     \
ICHAL_ADAPT_FUNC_DEF(CrmGetRefDetStatusJ204_1,chipId,refStatus)
UINT32 BspHalAdaptCrmClrUnLockRecordPll(UINT32 chipId, UINT32 pllId)     \
ICHAL_ADAPT_FUNC_DEF(CrmClrUnLockRecordPll,chipId,pllId)
UINT32 BspHalAdaptCrmClrUnLockCntPll(UINT32 chipId, UINT32 pllId)     \
ICHAL_ADAPT_FUNC_DEF(CrmClrUnLockCntPll,chipId,pllId)
UINT32 BspHalAdaptPaptDpdAbnormalMask(UINT32 uiDifChan, UINT32 uiMask)     \
ICHAL_ADAPT_FUNC_DEF(PaptDpdAbnormalMask,uiDifChan,uiMask)
UINT32 BspHalAdaptPaptPaAbnormalMask(UINT32 uiDifChan, UINT32 uiMask)     \
ICHAL_ADAPT_FUNC_DEF(PaptPaAbnormalMask,uiDifChan,uiMask)
UINT32 BspHalAdaptSetPapt2DpdWarnClr(UINT32 uiDifChan)     \
ICHAL_ADAPT_FUNC_DEF(SetPapt2DpdWarnClr,uiDifChan)
UINT32 BspHalAdaptCrmClrRefDetStatus(UINT32 chipId)  \
ICHAL_ADAPT_FUNC_DEF(CrmClrRefDetStatus,chipId)




UINT32 BspHalAdaptGetAntFrShakeInt(UINT32 uiBlockId, UINT32 *puiFrShakeInt)
{
    INPUT_POINTER_CHECK(puiFrShakeInt);
    return IcHalApiGetAntFrShakeInt(uiBlockId, puiFrShakeInt);
}

UINT32 BspHalAdaptClrAntFrSharkeInt(UINT32 uiBlockId)
{
    return IcHalApiClrAntFrSharkeInt(uiBlockId);
}

UINT32 BspHalAdaptCovertJ204toSdsLaneId(UINT32 dir, UINT32 j204LaneId)
{
    UINT32 serdesLaneId = 0;

    if ((dir > PRX) || (j204LaneId >= J204C_SERDES_LANE_MAX))
    {
        return BSP_ERROR;
    }

    if (TX == dir)
    {
        serdesLaneId = j204LaneId;
    }
    else if (RX == dir)
    {
        serdesLaneId = j204cRxLane2SerdesLaneMap[j204LaneId];
    }
    else
    {
        serdesLaneId = j204cFbLane2SerdesLaneMap[j204LaneId];
    }

    return serdesLaneId;
}

/*REV检测相关接口*/
UINT32 BspHalAdaptSetRevPowCalcAverNum(UINT32 num)
{
    return IcHalApiSetRevPowCalcAverNum(num);
}

UINT32 BspHalAdaptSaveL2dGfData(UINT32 uCellId, UINT32 uDir,UINT32 uAnt, UINT32 uSlot, UINT32 uStartSym, UINT32 uSymbNum)
{
    return IcHalApiSaveL2dGfData(uCellId, uDir, uAnt, uSlot, uStartSym, uSymbNum);
}

UINT32 BspHalAdaptCalcPowValByL2dData(UINT32 symId, UINT32 sigFreq, UINT32 carrFreq, DOUBLE* powVal)
{
    INPUT_POINTER_CHECK(powVal);
    return IcHalApiCalcPowValByL2dData(symId,sigFreq,carrFreq,powVal);
}


/*获取单板中频电压相关告警*/
UINT32 BspHalAdaptGetBoardPwrAlm(UINT32 chipId, UINT32 *pBoardPwrStatus)
{
    INPUT_POINTER_CHECK(pBoardPwrStatus);
    return IcHalApiGetBoardPwrAlm(pBoardPwrStatus);
}

UINT32 BspHalAdaptClrBoardPwrAlm(UINT32 chipId, UINT32 uiClearCode)
{
    return IcHalApiClrBoardPwrAlm(uiClearCode);
}
#endif

/**************************************************************************
                            功放保护
**************************************************************************/
UINT32 BspHalAdaptSetPaptBypass(UINT32 uiDifChan, UINT32 uiBypass)
{
    return IcHalApiSetPaptBypass(uiDifChan, uiBypass);
}

/* 功放保护初始化 */
UINT32 BspHalAdaptPaptInit(UINT32 difChan, T_BspHalAdaptPaptParaCfg* pCfg)
{
    INPUT_POINTER_CHECK(pCfg);
    SaveDifCfg(E_DIF_DIFPARA_PAPT, (VOID*)pCfg, 1, 1); 
    return IcHalApiPaptInit(difChan, (T_PaptParaInfoCfg*)pCfg);
}

UINT32 BspHalAdaptPaptAvgPow(UINT32 difChan, T_BspHalAdaptPaptCfrCfg* pCfr, T_BspHalAdaptPaptDpdCfg* pDpd)
{
    UINT32 ret = 0;

    INPUT_POINTER_CHECK(pCfr);
    INPUT_POINTER_CHECK(pDpd);

    /*配置DPD后功率参数*/
    ret = IcHalApiCfgPaptDpd(difChan, pDpd);
    /*配置CFR前功率参数*/
    ret |= IcHalApiCfgPaptCfr(difChan, pCfr);

    return ret;
}

/*更新功放保护掩码*/
UINT32 BspHalAdaptCfgPaptUnus(UINT32 difChan, T_PaptUnusInfoCfg *pCfg)
{
    UINT32 ret = 0;

    INPUT_POINTER_CHECK(pCfg);
    ret = IcHalApiCfgPaptUnus(difChan, pCfg);
    return ret;
}

/*配置高通滤波器系数*/
UINT32 BspHalAdaptCfgHpfInfo(UINT32 difChan, T_PaptHpfInfoCfg *pCfg)
{
    UINT32 ret = 0;

    INPUT_POINTER_CHECK(pCfg);
    ret = IcHalApiCfgPaptHPF(difChan, pCfg);
    return ret;
}

/* 告警上报 */
UINT32 BspHalAdaptGetPaptMonitorRpt(UINT32 difChan, UINT32* pRcd)
{
    UINT32 retVal = BSP_OK;
    UINT32 alarm[DL_POST_FREQ_NUM_IN_BLOCK] = {0};
    UINT32 num = 0;

    INPUT_POINTER_CHECK(pRcd);
    retVal = IcHalApiGetPaptMonitorRpt(difChan, alarm, &num);
    if(BSP_OK == retVal)
    {
        *pRcd = alarm[0];
    }
    return retVal;    
}

/* 告警清除 */
UINT32 BspHalAdaptClrPaptMonitorRpt(UINT32 difChan, UINT32 alarmMask)
{
    return IcHalApiClrPaptMonitorRpt(difChan, alarmMask);
}

UINT32 BspHalAdaptClrPaptPaOffMonitorRpt(UINT32 difChan, UINT32 alarmMask)
{
    return IcHalApiClrPaptPaOffMonitorRpt(difChan, alarmMask);
}

/* 功率无效告警上报 */
UINT32 BspHalAdaptGetPowInvalidFlag(UINT32 difChan, UINT32* pFlag)
{
    UINT32 retVal = BSP_OK;
    UINT32 flag[DL_POST_FREQ_NUM_IN_BLOCK] = {0};
    UINT32 num = 0;

    INPUT_POINTER_CHECK(pFlag);
    retVal = IcHalApiGetPaptPowErrRpt(difChan, flag, &num);
    if(BSP_OK == retVal)
    {
        *pFlag = flag[0];
    }
    return retVal;
}

/* 功率无效告警清除 */
UINT32 BspHalAdaptClrPowInvalidFlag(UINT32 difChan)
{
    return IcHalApiClrPaptPowErrRpt(difChan);
}

/* 获取关PA告警使能状态 */
UINT32 BspHalAdaptGetPaptPaOffMask(UINT32 difChan, UINT32* pMask)
{
    UINT32 retVal = BSP_OK;
    UINT32 mask[DL_POST_FREQ_NUM_IN_BLOCK] = {0};
    UINT32 num = 0;

    INPUT_POINTER_CHECK(pMask);
    retVal = IcHalApiGetPaptPaOffMask(difChan, mask, &num);
    if(BSP_OK == retVal)
    {
        *pMask = mask[0];
    }
    return retVal;
}

/* 获取关数据告警使能状态 */
UINT32 BspHalAdaptGetPaptDaOffMask(UINT32 difChan, UINT32* pMask)
{
    UINT32 retVal = BSP_OK;
    UINT32 mask[DL_POST_FREQ_NUM_IN_BLOCK] = {0};
    UINT32 num = 0;

    INPUT_POINTER_CHECK(pMask);
    retVal = IcHalApiGetPaptDaOffMask(difChan, mask, &num);
    if(BSP_OK == retVal)
    {
        *pMask = mask[0];
    }
    return retVal;
}


UINT32 BspHalAdaptSetPaVoltByReg(UINT32 ulLevel)
{
    UINT32 gpioValue[4] = {0}; /*bit0-gpio24; bit1-gpio23; bit2-gpio22; bit3-gpio21*/
    UINT32 gpioLevel = 0;

    if (ulLevel > 15)
    {
        dbgErr("[%s]para check error,ulLevel=%d\n",__func__,ulLevel);
        return BSP_ERROR;
    }

    /*电源模块真值表:GPIO24管脚在低位,GPIO21管脚在高位*/
    gpioValue[0] = ((ulLevel & BIT_SET(3)) != 0) ? 1 : 0; /*gpio21/10*/
    gpioValue[1] = ((ulLevel & BIT_SET(2)) != 0) ? 1 : 0; /*gpio22/11*/
    gpioValue[2] = ((ulLevel & BIT_SET(1)) != 0) ? 1 : 0; /*gpio23/12*/
    gpioValue[3] = ((ulLevel & BIT_SET(0)) != 0) ? 1 : 0; /*gpio24/13*/
    dbgInfoEx("21 = %d,22 = %d,23 = %d,24 = %d\n",gpioValue[0],gpioValue[1],gpioValue[2],gpioValue[3]);

    gpioLevel = gpioValue[0] | (gpioValue[1] << 1) | (gpioValue[2] << 2) | (gpioValue[3] << 3);
    dbgInfoEx("[%s],%d\n",__func__,gpioLevel);

    zx211413SetD48vVoltLevel(gpioLevel);

    return BSP_OK;
}
/**************************************************************************
                            远程复位初始化
**************************************************************************/
/* 远程硬复位，远程掉电复位，下电告警上报初始化接口；
 * 适用于TDD，T+F机型*/
UINT32 BSpHalAdaptSetTddPwrOff(void)
{
    UINT32 retVal = BSP_OK;

    /*远程硬复位初始化*/
    retVal |= IcHalApiSetCrmRmtHardRstSrc(0xd);
    retVal |= IcHalApiSetCrmRmtHardShSel(1);
    retVal |= IcHalApiCpriLsarResetCfg(1);

    /*初始化为响应控制字复位，光口自适应时存在误码率会关闭响应，状态正常后再打开*/
    retVal |= IcHalApiCpriSelfAdaptProtect(1);

    /*远程掉电复位*/
    retVal |= IcHalApiSetCrmRmtPwdRstSrc(0xf);

    /*掉电告警上报*/
    retVal |= IcHalApiCfgCrmAlmPwrOff(0xff, 0x3);
    retVal |= IcHalApiCfgPdPwrOffMask(2, 1);

    return retVal;
}
/* 远程硬复位，远程掉电复位，下电告警上报初始化接口；
 * 适用于FDD机型*/
UINT32 BSpHalAdaptSetFddPwrOff(void)
{
    UINT32 retVal = BSP_OK;

    /*远程硬复位初始化*/
    retVal |= IcHalApiSetCrmRmtHardRstSrc(0xe);
    retVal |= IcHalApiSetCrmRmtHardShSel(1);

    /*初始化为响应控制字复位，光口自适应时存在误码率会关闭响应，状态正常后再打开*/
    retVal |= IcHalApiCpriSelfAdaptProtect(1);

    /*远程掉电复位*/
    retVal |= IcHalApiSetCrmRmtPwdRstSrc(0xe);

    /*掉电告警上报*/
    retVal |= IcHalApiCfgCrmAlmPwrOff(0xff, 0x3);
    retVal |= IcHalApiCfgPdPwrOffMask(3, 3);

    retVal |= IcHalApiCpriPdAlarmCfgMode(1,0,0,0x5a);
    retVal |= IcHalApiCpriPdAlarmCfgThreshold(1,2,0xffff);

    return BSP_OK;
}

/*TDD IR协议屏蔽内部掉电告警*/
UINT32 BspSetInnerPwrAlmMask(void)
{
    UINT32 retVal = BSP_OK;

    retVal = IcHalApiCfgPdPwrOffMask(2,0);

    return retVal;
}

UINT32 BspHalAdaptCpriLsarResetCfg(UINT32 resetCfg)
{
    return IcHalApiCpriLsarResetCfg(resetCfg);
}

UINT32 BspHalAdaptSetCrmRmtHardShSel(UINT32 rstSrc)
{
    return IcHalApiSetCrmRmtHardShSel(rstSrc);
}

//配置delt值
UINT32 BspHalAdaptLintDeltInit(UINT32 dir, T_BspHalAdaptLinkDeltDly* p_DeltCfg, UINT32 num)
{
    INPUT_POINTER_CHECK(p_DeltCfg);

    return IcHalApiSetDeltaDly(dir, (T_HalLinkDeltaDly*)p_DeltCfg, num);
}

UINT32 BspHalAdaptSetGsmCellInfo(T_GsmCellInfo *gsmCellInfo)
{
    return IcHalApiGsmResourceCfg(gsmCellInfo);
}

UINT32 BspSetUmtsChanPow(UINT32 difChan, UINT32 uiCarrId, UINT32 uiRadioMode, UINT32 uiChanPow)
{
    UINT32 retVal = BSP_OK;

    retVal |= IcHalApiSetUmtsTssiPaEn(difChan,uiCarrId,uiRadioMode, 1);
    retVal |= IcHalApiSetUmtsTssiPaCoef(difChan,uiCarrId,uiRadioMode,uiChanPow);

    return retVal;
}


UINT32 BspInitUmtsAllCarrRatePow(UINT32 ulRatePow)
{
    UINT32 retVal = BSP_OK;
    retVal = IcHalApiSetUmtsTssiPaInit(ulRatePow);
    return retVal;
}


/* 上行TDM通道一致性使能API接口 */
UINT32 BspHalAdaptTdmAigaEn(UINT32 uiDifChan, UINT32 uiCarrId, UINT32 uiRadioMode, UINT32 uiAigaEn)
{
      UINT32 uiRet = 0;
      uiRet = IcHalApiTdmAigaEn(uiDifChan, uiCarrId, uiRadioMode, uiAigaEn);

      return uiRet;
}
/* 上行TDM通道一致性补偿因子API接口 */
UINT32 BspHalAdaptTdmAigaCoef(UINT32 uiDifChan, UINT32 uiCarrId, UINT32 uiRadioMode, INT32 uiGainDb)
{
      UINT32 uiRet = 0;
      uiRet = IcHalApiTdmAigaCoef(uiDifChan, uiCarrId, uiRadioMode, uiGainDb);

      return uiRet;
}

UINT32 BspSetTdmAigaCoef(UINT32 uiDifChan, UINT32 uiCarrId, UINT32 uiRadioMode, UINT32 uiRruNum)//  uiRruNum：RRU合并个数
{
    UINT32 uiRet   = 0;
    DOUBLE GainDbValue = 0;
    INT32 uiGainDb = 0;
    uiRet = BspHalAdaptTdmAigaEn(uiDifChan, uiCarrId, uiRadioMode, TDM_UIAIGA_EN);
    if(uiRet!= BSP_OK)
    {
        dbgErr("%s [%d] BspHalAdaptTdmAigaEn is error\n", __FUNCTION__, __LINE__);
        return BSP_ERROR;        
    }
    GainDbValue = 100*10*log10(uiRruNum);
    if(GainDbValue < INTMAX_MAX && GainDbValue > INTMAX_MIN )
    {
       uiGainDb =(-1)*((INT32)GainDbValue);
    }
    else
    {
        dbgErr("Conversion from double to INT32 cause loss of data\n");
        return BSP_ERROR;
    }

    uiRet = BspHalAdaptTdmAigaCoef(uiDifChan, uiCarrId, uiRadioMode, uiGainDb);
    return uiRet;

}



UINT32 BspHalApiGetRxDataOffFlag(UINT32 difChan, UINT32 carrNo, UINT32 radioMode, UINT32 *uiFlag)
{
    return IcHalApiGetRxDataOffFlag(difChan, carrNo, radioMode, uiFlag);
}
/**********************************************************************************
********************************PIM相关接口*****************************************
***********************************************************************************/
/*传递PIM检测信息，NCO，第一个参数NcoFlag目前固定传0即可*/
UINT32 BspHalAdaptPimChkCfg(UINT32 NcoFlag, UINT32 difChan, T_BspHalAdaptPimChkInfoCfg *ptPimChkCfgInfo)
{
    UINT32 retVal = BSP_OK;
    retVal = IcHalApiPimChkCfg(NcoFlag,difChan,ptPimChkCfgInfo);
    return retVal;
}

UINT32 BspHalAdaptPimPimCalcSw(UINT32 CalcEn)
{
    UINT32 retVal = BSP_OK;
    retVal = IcHalApiPimCalcEn(CalcEn);
    return retVal;
}

UINT32 BspHalAdaptPimChkDataRpt(UINT32 NcoFlag, UINT32 difChan, UINT32 *sumData)
{
    UINT32 retVal = BSP_OK;
    retVal = IcHalApiPimChkDataRpt(NcoFlag,difChan,sumData);
    return retVal;
}

/**************************************************************************
                           屏蔽下电告警上报
**************************************************************************/
/*  屏蔽下电告警上报      */
UINT32 BspHalAdaptMaskPwrOffAlarmReport(void)
{
    UINT32 retVal = BSP_OK;

    retVal |= IcHalApiCfgPdPwrOffMask(0, 0);

    return retVal;
}

/**************************************************************************
                           光口PCS异常告警处理
**************************************************************************/
UINT32 BspSetPcsDataAlarmMask(UINT32 optNo, UINT32 almMask)
{
    UINT32 retVal = BSP_OK;

    retVal = IcHalApiPcsDataAlarmMask(optNo,almMask);

    return retVal;
}

UINT32 BspSetPcsAmpAlarmMask(UINT32 optNo, UINT32 almMask)
{
    UINT32 retVal = BSP_OK;

    retVal = IcHalApiPcsAmpAlarmMask (optNo,almMask);

    return retVal;
}

/*光口修改ROE模块在软复位时不初始化，导致TDD机型切换协议时软复位无法建链，需要单独配置ROE的协议*/
UINT32 BspCfgRoeCmCfgProtocol(UINT32 protocol)
{
    return IcHalApiRoeCmCfg(protocol);
}

UINT32 BspHalAdaptGetRoeTxRxCntInfo(UINT32 ulDir, UINT32 ulChanIndex)
{
    return IcHalApiRoeTxRxCntInfo(ulDir, ulChanIndex);
}

UINT32 BspHalAdaptGetRoeTxRxErrInfo(UINT32 ulDir, UINT32 ulChanIndex)
{
    return IcHalApiRoeTxRxErrInfo(ulDir, ulChanIndex);
}

/*获取当前配置的roe模块的协议*/
UINT32 BspHalAdaptGetRoeCurProtocol(UINT32 chanIndex)
{
    return IcHalApiRoeGetCurProtocol(chanIndex);
}

UINT32 BspHalAdaptSetSaveGrp(UINT32 uiType, UINT32 uiGrp)
{
    return IcHalApiSetSaveGrp(uiType, uiGrp);
}

UINT32 BspHalAdaptGetSaveType()
{
    return IcHalApiGetSaveType();
}

UINT32 BspHalAdaptGetSaveGrp()
{
    return IcHalApiGetSaveGrp();
}

UINT32 BspHalAdaptSetSaveRegEn(UINT32 uiEn)
{
    return IcHalApiSetSaveRegEn(uiEn);
}

UINT32 BspHalAdaptGetSaveRegEn()
{
    return IcHalApiGetSaveRegEn();
}

UINT32 BspHalAdaptGetSaveRegInfo(UINT32 uiType, UINT32 uiGrp, T_RegSaveUnit* pData)
{
    return IcHalApiGetSaveRegInfo(uiType, uiGrp, pData);
}

UINT32 BspHalAdaptClrSaveRegInfo(UINT32 uiType, UINT32 uiGrp)
{
    return IcHalApiClrSaveRegInfo(uiType, uiGrp);
}

UINT32 BspHalAdaptUtTddClrEn(UINT32 uiDifChan, UINT32 uiCarrId, UINT32 uiRadioMode, UINT32 uiEn)
{
    return IcHalApiUtTddClrEn(uiDifChan,uiCarrId,uiRadioMode,uiEn);
}

UINT32 BspHalAdaptRcdTdmAigaClr(UINT32 uiDifChan, UINT32 uiCarrId, UINT32 uiRadioMode, UINT32 uiOffEn)
{
	return IcHalApiRcdTdmAigaClr(uiDifChan,uiCarrId,uiRadioMode,uiOffEn);
}

UINT32 BspHalAdaptRcdDlpreGainClr(UINT32 uiDifChan, UINT32 uiCarrId, UINT32 uiRadioMode, UINT32 uiOffEn)
{
	return IcHalApiRcdDlpreGainClr(uiDifChan,uiCarrId,uiRadioMode,uiOffEn);
}

/**************************************************************************
                           光口ICP通信处理
**************************************************************************/
UINT32 BspKoSubFrameCfg(T_SUBFRAME_BITMAP_MSG *pMsgIn)
{
    UINT32 retVal = BSP_OK;

    retVal =  HalIcKoSubFrameCfg(pMsgIn);

    return retVal;
}

UINT32 BspKoRfSwtichCfg(T_RF_SWTICH_MSG *pMsgIn, UINT32 msgId)
{
    UINT32 retVal = BSP_OK;

    retVal =  HalIcKoRfSwtichCfg(pMsgIn, msgId);

    return retVal;
}


UINT32 BspKoFrameNumCfg(T_FRAME_NUM_MSG *pMsgSend, T_FRAME_NUM_MSG *pMsgRecv)
{
    UINT32 retVal = BSP_OK;

    retVal =  HalIcKoFrameNumCfg(pMsgSend, pMsgRecv);

    return retVal;
}




/**************************************************************************
                           Qcell室内定位相关接口
**************************************************************************/

UINT32 BspHalAdaptM0SetMesgTnr(T_BspHalAdaptPsotionRadioInfoTnr *pMesgTnr)
{
#ifdef UT_FT_TEST
    return BSP_OK;
#endif
    return IcHalApiM0SetMesgTnr(pMesgTnr);
}

UINT32 BspHalAdaptM0SetMesgTlte(T_BspHalAdaptPsotionRadioInfoTdd *pMesgTlte)
{
#ifdef UT_FT_TEST
    return BSP_OK;
#endif
    return IcHalApiM0SetMesgTlte(pMesgTlte);
}
UINT32 BspHalAdaptM0SetMesgFdd(T_BspHalAdaptPsotionRadioInfoFddFnr *pMesgFdd)
{
#ifdef UT_FT_TEST
    return BSP_OK;
#endif
    return IcHalApiM0SetMesgFdd(pMesgFdd);
}

UINT32 BspHalAdaptSetDmimoPsyncIrqCfg(UINT32 uSwitch)
{
    return IcHalApiDmimoPsyncIrqCfg(uSwitch);
}


UINT32 BspHalAdaptGetOpt2DlPreFrCfg(UINT32 uiFrId)
{
    return HalGetOpt2DlPreFrCfg(uiFrId);
}

UINT32 BspHalAdaptUtDlBankSample(UINT32 uiDifChan, UINT32 uiCarrId, UINT32 uiRadioMode, UINT32 uiStartFlag)
{
	return IcHalApiUtDlBankSample(uiDifChan,uiCarrId,uiRadioMode,uiStartFlag);
}

UINT32 BspHalAdaptUtUlBankSample(UINT32 uiDifChan, UINT32 uiCarrId, UINT32 uiRadioMode, UINT32 uiStartFlag)
{
	return IcHalApiUtUlBankSample( uiDifChan, uiCarrId, uiRadioMode,uiStartFlag);
}

UINT32 BspHalAdaptPsyncFramenoInfoPrint(UINT32 uFrame)
{
	return IcHalApiPsyncFramenoInfoPrint(uFrame);
}

UINT32 BspHalAdaptGetTxDuc0BankId(UINT32 uiDifChan,UINT32 uiCarrId, UINT32 uiCarrRadio,UINT32 *puiBankId)
{
    UINT32 retVal = BSP_OK;
    retVal = IcHalApiGetTxDuc0BankId(uiDifChan,uiCarrId,uiCarrRadio,puiBankId);
    return retVal;
}
UINT32 BspHalAdaptSrsPsyncIrqCfgTnr(UINT32 uSwitch)
{
	return IcHalApiSrsPsyncIrqCfgTnr(uSwitch);
}

UINT32 BspHalAdaptSrsSetRevMesgTnr(VOID)
{
#ifdef UT_FT_TEST
    return BSP_OK;
#endif
    return IcHalApiM0SetRevMesgTnr();
}

UINT32 BspHalAdaptSrsPsyncIrqCfgTlte(UINT32 uSwitch)
{
#ifdef UT_FT_TEST
    return BSP_OK;
#endif
    return IcHalApiSrsPsyncIrqCfgTlte(uSwitch);
}

UINT32 BspHalAdaptSrsSetRevMesgTlte(VOID)
{
#ifdef UT_FT_TEST
    return BSP_OK;
#endif
    return IcHalApiM0SetRevMesgTlte();
}

UINT32 BspHalAdaptSrsPsyncIrqCfgFdd(UINT32 uSwitch)
{
	return IcHalApiSrsPsyncIrqCfgFdd(uSwitch);
}

UINT32 BspHalAdaptPimPsyncIrqCfg(VOID)
{
    return IcHalApiPimPsyncIrqCfg();
}

UINT32 BspHalAdaptSrsSetRevMesgFdd(VOID)
{
#ifdef UT_FT_TEST
    return BSP_OK;
#endif
    return IcHalApiM0SetRevMesgFdd();
}

UINT32 BspHalAdaptGetSrsFrameNoDelayAdjustFlagTnr(VOID)
{
    return IcHalApiGetSrsFrameNoDelayAdjustFlagTnr();
}

UINT32 BspHalAdaptGetSrsFrameNoDelayAdjustFlagFdd(VOID)
{
    return IcHalApiGetSrsFrameNoDelayAdjustFlagFdd();

}

UINT32 BspHalAdaptSetCcToGainDelay(UINT32 uDifChan,UINT32 uCarrId,UINT32 uRadioMode)
{
	 return IcHalApiSetCcToGainDelay(uDifChan,uCarrId,uRadioMode);
}

UINT32 BspHalAdaptDmmSendCfg(UINT32 uiDifChan, UINT32 uiCarrId, UINT32 uiRadioMode, T_BspHalAdaptUtDmimoParaCfg* pDmm)
{
    return IcHalApiDmmSendCfg(uiDifChan,uiCarrId,uiRadioMode,pDmm);
}
UINT32 BspHalAdaptSetDlTimingDlTddDly(UINT32 uiDifChan, UINT32 uiDlyNs)
{
	return IcHalApiSetDlTimingDlTddDly(uiDifChan,uiDlyNs);
}

UINT32 BspHalAdaptDmmSendEn(UINT32 uiDifChan, UINT32 uiCarrId, UINT32 uiRadioMode, UINT32 uiEn)
{
    return IcHalApiDmmSendEn(uiDifChan,uiCarrId,uiRadioMode,uiEn);
}

UINT32 BspHalAdaptDmmReceiveCfg(UINT32 uiDifChan, UINT32 uiCarrId, UINT32 uiRadioMode, T_BspHalAdaptUtDmimoParaCfg* pDmm)
{
    return IcHalApiDmmReceiveCfg(uiDifChan,uiCarrId,uiRadioMode,pDmm);
}

UINT32 BspHalAdaptDmmReceiveEn(UINT32 uiDifChan, UINT32 uiCarrId, UINT32 uiRadioMode, UINT32 uiEn)
{
    return IcHalApiDmmReceiveEn(uiDifChan,uiCarrId,uiRadioMode,uiEn);
}

UINT32 BspHalAdaptPsyncFrameCheck(VOID)
{
	return IcHalApiPsyncFrameCheck();
}

UINT32 BspHalAdaptQcellPsyncSyn(VOID)
{
	return IcHalApiQcellPsyncSyn();
}


UINT32 BspHalAdaptSampleIf0(UINT32 uDir, T_BspHalAdaptUtDmimoParaCfg *pDmimoParaCfg)
{
    UINT32 retVal = BSP_OK;
	//retVal = IcHalApiSampleIf0( uDir, pDmimoParaCfg);
	return retVal;
}


UINT32 BspHalAdaptUtDlIoCfg(UINT32 uiDifChan, UINT32 uiCarrId, UINT32 uiRadioMode, UINT32 uiMode, T_BspHalAdaptUtDlIoPara* pUtIo)
{
	return IcHalApiUtDlIoCfg(uiDifChan, uiCarrId,  uiRadioMode, uiMode, pUtIo);
}

UINT32 BspHalAdaptUtUlIoCfg(UINT32 uiDifChan, UINT32 uiCarrId, UINT32 uiRadioMode, UINT32 uiMode, T_BspHalAdaptUtUlIoPara* pUtIo)
{
	return IcHalApiUtUlIoCfg(uiDifChan, uiCarrId,  uiRadioMode, uiMode, pUtIo);
}
UINT32 dmmIoEnVar = DMM_UT_PUBLIC_EN_OFF;
UINT32 utIoEnVar  = DMM_UT_PUBLIC_EN_OFF;
/* Dmm和Utdoa的Io互斥，当有一个使能时，变量就为1，当两个都不使能的时候，才能置为0 */
VOID BspSetDmmIoEnVar(UINT32 dmmEn)
{
    dmmIoEnVar = dmmEn;
}
UINT32 BspGetDmmIoEnVar(VOID)
{
    dbgInfoEx("dmmIoEnVar:%d\n",dmmIoEnVar);
    return dmmIoEnVar;
}
VOID BspSetUtIoEnVar(UINT32 utEn)
{
    utIoEnVar = utEn;
}
UINT32 BspGetUtIoEnVar(VOID)
{
    dbgInfoEx("utIoEnVar:%d\n",utIoEnVar);
    return utIoEnVar;
}

UINT32 BspHalAdaptUtDlIoEn(UINT32 uiDifChan, UINT32 uiEn)
{
	return IcHalApiUtDlIoEn(uiDifChan, uiEn);
}
UINT32 BspHalAdaptSetDlGpEn(UINT32 uiDifChan, UINT32 uiRadioMode, UINT32 uiCarrId, UINT32 uiEn)
{
	return IcHalApiSetDlGpEn(uiDifChan,uiRadioMode,uiCarrId,uiEn);
}

UINT32 BspHalAdaptUtUlIoEn(UINT32 uiDifChan, UINT32 uiEn)
{
	return IcHalApiUtUlIoEn(uiDifChan, uiEn);
}

UINT32 BspHalAdaptUtSetMode(UINT32 uiMode)
{
    return IcHalApiUtSetMode(uiMode);
}

UINT32 BspHalAdaptUtGetMode(VOID)
{
    return IcHalApiUtGetMode();
}

UINT32 BspHalAdaptUtSendAacCfg(UINT32 uiDifChan, UINT32 uiCarrId, UINT32 uiRadioMode, T_BspHalAdaptUtSendParaCfg* pDmm)
{
    return IcHalApiUtSendAacCfg(uiDifChan,uiCarrId,uiRadioMode,pDmm);
}

UINT32 BspHalAdaptUtSendAacEn(UINT32 uiDifChan, UINT32 uiCarrId, UINT32 uiRadioMode, UINT32 uiEn)
{
	return IcHalApiUtSendAacEn(uiDifChan, uiCarrId,  uiRadioMode, uiEn);
}

UINT32 BspHalAdaptUtSampleCfg(UINT32 uiDifChan,UINT32 uiCarrId,UINT32 uiRadioMode,T_BspHalAdaptUtSampleParaCfg* samPara)
{
	return IcHalApiUtSampleCfg(uiDifChan, uiCarrId,  uiRadioMode, samPara);
}

UINT32 BspHalAdaptUtSampleEn(UINT32 uiDifChan, UINT32 uiCarrId, UINT32 uiRadioMode, UINT32 uiEn)
{
	return IcHalApiUtSampleEn(uiDifChan, uiCarrId,  uiRadioMode, uiEn);
}

UINT32 BspHalAdaptUtInsertAacCfg(UINT32 uiDifChan,UINT32 uiCarrId,UINT32 uiRadioMode,T_BspHalAdaptUtInsertParaCfg* psamPara)
{
	return IcHalApiUtInsertCfg(uiDifChan, uiCarrId,  uiRadioMode, psamPara);
}

UINT32 BspHalAdaptUtInsertAacEn(UINT32 uiDifChan, UINT32 uiCarrId, UINT32 uiRadioMode, UINT32 uiEn)
{
	return IcHalApiUtInsertAacEn(uiDifChan, uiCarrId,  uiRadioMode, uiEn);
}

UINT32 BspHalAdaptUtTddClrCfg(UINT32 uiDifChan, UINT32 uiCarrId, UINT32 uiRadioMode)
{
	return IcHalApiUtTddClrCfg(uiDifChan, uiCarrId,  uiRadioMode);
}
UINT32 BspHalAdaptUtTddUpdate(UINT32 uiDifChan)
{
	return IcHalApiUtTddUpdate(uiDifChan);
}
// DMM中频变量清除
UINT32 BspHalAdaptDmClear(VOID)
{
    return IcHalApiUtClear();
}

// UTDOA中频变量清除
UINT32 BspHalAdaptUtdoaClear(VOID)
{
    return IcHalApiUtdoaClear();
}

UINT32 BspHalAdaptGetQcellBfn(UINT32 ulLogOptNo)
{
    return IcHalApiGetQcellBfn(ulLogOptNo);
}

UINT32 BspOptSetSpectrumShare(UINT32 cellId,UINT32 specShare)
{
    dbgInfo("%s:cellId:%d,specShare:%d\n",__FUNCTION__,cellId,specShare);

    IcHalApiSetCellFoc7p5Flag(cellId, specShare);
    return BSP_OK;
}
UINT32 BspHalAdaptM0SetSfBitmapTnr(UINT32 uCellId, UINT32 uRadioMode, UINT32 uBitmap)
{
	return IcHalApiM0SetSfBitmapTnr(uCellId,uRadioMode,uBitmap);
}

UINT32 BspHalAdaptM0ClearMesgTnr(VOID)
{
#ifdef UT_FT_TEST
    return BSP_OK;
#endif
    return IcHalApiM0ClearMesgTnr();
}
UINT32 BspHalAdaptM0ClearMesgTlte(VOID)
{
#ifdef UT_FT_TEST
    return BSP_OK;
#endif
    return IcHalApiM0ClearMesgTlte();
}

UINT32 BspHalAdaptM0ClearMesgFdd(VOID)
{
#ifdef UT_FT_TEST
    return BSP_OK;
#endif
    return IcHalApiM0ClearMesgFdd();
}

UINT32 BspHalAdaptM0SetConDispatchMesg(T_CONVERGE_DISPATCH_INFO_TNR *pConDispatchMesg)
{
#ifdef UT_FT_TEST
    return BSP_OK;
#endif
    return IcHalApiM0SetConDispatchMesg(pConDispatchMesg);
}

UINT32 BspHalAdaptConDispathcPsyncIrqCfg(UINT32 uSwitch) 
{
    return IcHalApiConDispathcPsyncIrqCfg(uSwitch) ;
}

UINT32 BspHalAdaptM0ClearConDispatchMesg(VOID)
{
#ifdef UT_FT_TEST
    return BSP_OK;
#endif
    return IcHalApiM0ClearConDispatchMesg();
}

UINT32 BspHalAdaptM0RcvConDispatchMesg(VOID)
{
#ifdef UT_FT_TEST
    return BSP_OK;
#endif
    return IcHalApiM0SetConDispatchMesgRcv();
}

UINT32 BspHalAdaptConDispatchSetCcToGainDelay(UINT32 uDifChan,UINT32 uCarrId,UINT32 uRadioMode)
{
    return IcHalApiConDispatchSetCcToGainDelay( uDifChan, uCarrId, uRadioMode);
}

UINT32 BspHalAdaptGetTxBankId(UINT32 difChan, UINT32 carrId, UINT32 carrRadio, UINT32 *pBankId)
{
    return IcHalApiGetTxBankId(difChan, carrId, carrRadio, pBankId);
}

UINT32 BspHalAdaptGetPsyncL2dSymbolAddr(UINT32 chanNo, UINT32 carrNo, UINT32 carrMode, UINT32 dir, UINT32 *pL2dSymbolAddr)
{
    return IcHalGetPsyncL2dSymbolAddr(carrNo, carrMode, dir, chanNo, pL2dSymbolAddr);
}

UINT32 BspHalAdaptGetCellIndex(UINT32 chanNo, UINT32 carrNo, UINT32 carrMode, UINT32 dir, UINT32 *pCellID)
{
    return IcHalGetNoOptCellID(carrNo, carrMode, dir, chanNo, pCellID);
}

UINT32 BspHalAdaptJitOutWinCfg(UINT32 uiJitterVal)
{
    return IcHalApiJitOutWinCfg(uiJitterVal);
}

UINT32 BspHalAdaptJ204InfGlbWinCfg(UINT32 uiJitterVal)
{
    return IcHalApiJ204InfGlbWinCfg(uiJitterVal);
}

UINT32 BspHalAdaptSetDmimoMasterSwitchInfo(T_DmimoMasterSwitchEn *pDmimoMasterSwitchInfo)
{
    return IcHalApiUtSetDmimoMasterSwitchInfo(pDmimoMasterSwitchInfo);
}

UINT32 BspHalAdaptGetDmimoMasterCpId(UINT32 uiCarrNo, UINT32 uiRadio, UINT32 *pCpId)
{
    return IcHalApiUtGetDmimoMasterCpId(uiCarrNo, uiRadio, pCpId);
}

UINT32 BspHalAdaptGetTxCarrNum(UINT32 uiDifChan, UINT32 *puiCarrNum)
{
    return IcHalApiGetTxCarrNum(uiDifChan, puiCarrNum);
}

UINT32 BspHalAdaptGetRxCarrNum(UINT32 uiDifChan, UINT32 *puiCarrNum)
{
    return IcHalApiGetRxCarrNum(uiDifChan, puiCarrNum);
}

UINT32 BspHalApiTwoFrePrachGetRbNum(UINT32 uPrachConfigIndex,UINT32 uScs,UINT32 uPrachScs)
{
    UINT32 retVal = BSP_OK;

    retVal = IcHalApiTwoFrePrachGetRbNum(uPrachConfigIndex, uScs,uPrachScs);
    return retVal;
}

UINT32 BspHalApiSetRachModeFlag(UINT32 uCellIndex,UINT32 uFlag)
{
    UINT32 retVal = BSP_OK;

    retVal = IcHalApiSetRachModeFlag(uCellIndex, uFlag);
    return retVal;
}

UINT32 BspHalAdaptGetPimcBypass(UINT32 difChan, UINT32 *pPimcIsBypass, UINT32 *pPimcNum)
ICHAL_ADAPT_FUNC_DEF(GetPimcBypass, difChan, pPimcIsBypass, pPimcNum)

UINT32 BspHalAdaptGetOneFddValidChan(UINT32 *difChanId)
ICHAL_ADAPT_FUNC_DEF(GetOneFddValidChan, difChanId)

UINT32 BspHalAdaptGetFrTmValInChan(UINT32 difChan, UINT32 *pFrOffSetNs, UINT32 *pTddRamFrOffSetNs)
ICHAL_ADAPT_FUNC_DEF(GetFrTmValInChan, difChan, pFrOffSetNs,pTddRamFrOffSetNs)

/* Started by AICoder, pid:yfed4y4e4e343ec1496b086d7060b90aafe53d0f */
UINT32 BspHalAdaptGetDlCarrCompDly(UINT32 uiDifChan, UINT32 uiCarrId, UINT32 uiRadioMode, UINT32 *puiDlyNs)
{
    // Directly return the result of IcHalApiGetDlCarrCompDly to avoid an unnecessary local variable.
    return IcHalApiGetDlCarrCompDly(uiDifChan, uiCarrId, uiRadioMode, puiDlyNs);
}
/* Ended by AICoder, pid:yfed4y4e4e343ec1496b086d7060b90aafe53d0f */


UINT32 BspHalAdaptOptQcellInit(T_OPT_ROE_INIT_PARA *pOptRoeInitPara)
{
#ifdef UT_FT_TEST
    return BSP_OK;
#endif
    UINT32 retVal = BSP_OK;
    retVal = IcHalApiOptQcellInit(pOptRoeInitPara);
    return retVal;
}

UINT32 BspHalAdaptOptRoeInitCfg(T_OPT_ROE_INIT_PARA *pOptRoeInitPara)
{
    UINT32 retVal = BSP_OK;
    retVal = IcHalApiOptRoeInitCfg(pOptRoeInitPara);
    return retVal;
}

UINT32 BspHalAdaptRoe2CpriFrMonitor()
{
   UINT32 retVal = BSP_OK;
   retVal =  IcHalApiRoe2CpriFrMonitor();
   return retVal;
}

/* UMTS陷波功能分载波分时隙使能 */
UINT32 BspHalAdaptSetUmtsTxCfrFilterEn(UINT32 chan, UINT32 carrNo, UINT32 slotNo, UINT32 trapEn)
{
    UINT32 retVal = BSP_OK;

    retVal = IcHalApiSetUmtsTxCfrFilterEn(chan, carrNo, slotNo, trapEn);
    return retVal;
}

/* 设置UMTS陷波滤波器阶数 */
UINT32 BspHalAdaptSetUmtsTxCfrOrderNum(UINT32 orderNum)
{
    UINT32 retVal = BSP_OK;

    retVal = IcHalApiSetUmtsTxCfrOrderNum(orderNum);
    return retVal;
}

/* 设置UMTS陷波滤波器系数 */
UINT32 BspHalAdaptUmtsTxCfrFilterCoef(UINT32 chan, UINT32 carrNo, UINT32 slotNo, INT32 *pCoefArray, UINT32 coefNum)
{
    UINT32 retVal = BSP_OK;

    retVal = IcHalApiSetUmtsTxCfrFilterCoef(chan, carrNo, slotNo, pCoefArray, coefNum);
    return retVal;
}

/* UMTS陷波滤波器配置GsmSlotHd延时 */
UINT32 BspHalAdaptSetUmtsGsmSlotHdDly(UINT32 difChan, UINT32 carrNo)
{
    UINT32 retVal = BSP_OK;

    retVal = IcHalApiSetUmtsGsmSlotHdDly(difChan, carrNo);
    return retVal;
}

/*风扇控制模块*/
UINT32 BspHalAdaptSetPwmModeEn(UINT32 pwmBlock, UINT32 enFlag)
{
    UINT32 retVal = BSP_OK;

    retVal = IcHalSetPwmModeEn(pwmBlock, enFlag);
    return retVal;
}
UINT32 BspHalAdaptSetPwmModePolarSel(UINT32 pwmBlock, UINT32 sel)
{
    UINT32 retVal = BSP_OK;

    retVal = IcHalSetPwmModePolarSel(pwmBlock, sel);
    return retVal;
}
UINT32 BspHalAdaptSetPwmResolution(UINT32 pwmBlock, UINT32 val)
{
    UINT32 retVal = BSP_OK;

    retVal = IcHalSetPwmResolution(pwmBlock, val);
    return retVal;
}
UINT32 BspHalAdaptSetPwmPeriod(UINT32 pwmBlock, UINT32 period)
{
    UINT32 retVal = BSP_OK;

    retVal = IcHalSetPwmPeriod(pwmBlock, period);
    return retVal;
}

UINT32 BspHalAdaptSetPwmDuty(UINT32 pwmBlock, UINT32 duty)
{
    UINT32 retVal = BSP_OK;

    retVal = IcHalSetPwmDuty(pwmBlock, duty);
    return retVal;
}

UINT32 BspHalAdaptSetTddBandFreqFlag(UINT32 flag)
{
    return IcHalApiSetTddBandFreqFlag(flag);
}

/* Started by AICoder, pid:mcf21jc13cg222214fad09f1f044520c1ab411dd */
UINT32 BspHalAdaptSetExpansionFlag(UINT32 flag)
{
    return IcHalApiSetCaseExtensionFlag(flag);
}
/* Ended by AICoder, pid:mcf21jc13cg222214fad09f1f044520c1ab411dd */

UINT32 BspHalAdaptIsCarrValid(UINT32 difChan, UINT32 carrId, UINT32 carrRadio, UINT32 dir, UINT32 *validFlag)
{
    UINT32 retVal = BSP_OK;
    
    retVal = IcHalApiIsCarrValid(difChan, carrId, carrRadio, dir, validFlag);
    return retVal;
}

VOID BspApiRebuildPsyncSyn(VOID)
{
    return IcHalApiRebuildPsyncSyn();
}

UINT32 BspHalCpriFrameAlignRdFrSel(UINT32 logicOptIndex, UINT32 frSel)
{
    return IcHalApiCpriFrameAlignRdFrSel(logicOptIndex, frSel);
}

UINT32 BspHalAdaptGetCfrCpgRamAlarm(T_DifChanOriginCoefPara *pOriginCoefPara, UINT32 *puiAlarm)
{
    UINT32 retVal = BSP_OK;

    retVal = IcHalApiGetCfrCpgRamAlarm(pOriginCoefPara, puiAlarm);

    return retVal;
}


UINT32 BspHalAdaptSetFreqOffsetCompFlag(UINT32 flag)
{
    return IcHalApiSetFreqOffsetCompFlag(flag);
}

UINT32 BspHalAdaptGetFreqOffsetCompFlag(void)
{
    return IcHalApiGetFreqOffsetCompFlag();
}

/* Started by AICoder, pid:oc6d54d66f8affd145f8081c708c640701e4a9cd */
UINT32 BspHalAdaptSetNBCompressFlag(UINT32 uFlag)
{
    return IcHalApiSetNBCompressFlag(uFlag);
}
/* Ended by AICoder, pid:oc6d54d66f8affd145f8081c708c640701e4a9cd */

/* Started by AICoder, pid:6c9b0511f7f79fc1408b0b8ca060c2105391713b */
UINT32 BspHalAdaptSetNbRcfBypassFlag(UINT32 flag)
{
    return IcHalApiSetNbRcfBypassFlag(flag);
}
/* Ended by AICoder, pid:6c9b0511f7f79fc1408b0b8ca060c2105391713b */


/* Started by AICoder, pid:vd062badb1aaef514f9a09a9309e32047498d2f8 */
UINT32 BspHalAdaptSetFreqOffSetIndexByCarr(UINT32 uiDifChan, UINT32 uiCarrId, UINT32 uiRadioMode, UINT32 uiIndex)
{
    return IcHalApiSetFreqOffSetIndexByCarr(uiDifChan, uiCarrId, uiRadioMode, uiIndex);
}
/* Ended by AICoder, pid:vd062badb1aaef514f9a09a9309e32047498d2f8 */
UINT32 BspHalAdaptGetCarrFreqOffsetDly(UINT32 *pdifDlDelay, UINT32 *pdifUlDelay)
{
    return IcHalApiGetCarrFreqOffsetDly(pdifDlDelay, pdifUlDelay);
}

UINT32 BspHalAdaptGetNcoProtocol(UINT32 phyOptNo)
{
    return IcHalApiGetNcoProtocol(phyOptNo);
}

/**************************************************************************
                            一键采集相关接口
**************************************************************************/

/* 中频的一键采集 */
UINT32 BspHalAdaptOneClickCollectHal(VOID)
{
    return IcHalApiOneClickCollect();
}
/* 光口的一键采集 */
UINT32 BspHalAdaptOneClickCollectOpt(UINT32 mask)
{
    return IcHalApiOptQcellOneClickCollect(mask);
}

/* 获取IF1的载波延时当前缓冲能力 */
UINT32 BspHalAdaptGetIf1CarrDelayCurrentBufCapability(UINT32 dir, UINT32 bspChn, UINT32 radiomode, UINT32 carrNo, UINT32 *dlyNs)
{
    UINT32 retVal = BSP_OK;

    retVal = IcHalApiGetIf1CarrDelayCurrentBufCapability(dir, bspChn, radiomode, carrNo, dlyNs);

    return retVal;
}

/* 获取IF1的载波延时最大缓冲能力 */
UINT32 BspHalAdaptGetIf1CarrDelayMaxBufCapability(UINT32 dir, UINT32 bspChn, UINT32 radiomode, UINT32 carrNo, UINT32 *dlyNs)
{
    UINT32 retVal = BSP_OK;

    retVal = IcHalApiGetIf1CarrDelayMaxBufCapability(dir, bspChn, radiomode, carrNo, dlyNs);//最大BUFF

    return retVal;
}

/* 配置给hal该机型是否是NCR机型 */
UINT32 BspHalAdaptIsNcrType(UINT32 ncrFlag)
{
    UINT32 retVal = BSP_OK;

    retVal = IcHalApiIsNcrType(ncrFlag);

    return retVal;
}

UINT32 BspHalAdaptNcrFwdMap(T_NcrFwdMap* ptTxFwdMap,UINT32 uiTxSize,T_NcrFwdMap* ptRxFwdMap,UINT32 uiRxSize)
{
    UINT32 retVal = BSP_OK;

    retVal = IcHalApiNcrFwdMap(ptTxFwdMap, uiTxSize, ptRxFwdMap, uiRxSize);

    return retVal;
}

/* Started by AICoder, pid:id578k35cbv690f14aa709893024c52191750e9a */
/* 检查路由是否正常，puiFlag 0-异常；1-正常 */
UINT32 BspHalAdaptCheckTx204Route(UINT32 *puiFlag)
{
    UINT32 retVal = BSP_OK;

    retVal = IcHalApiCheckTx204Route(puiFlag);

    return retVal;
}
/* Ended by AICoder, pid:id578k35cbv690f14aa709893024c52191750e9a */

UINT32 BspHalAdaptSetUmtsDagcReset(VOID)
{
    UINT32 retVal = BSP_OK;

    retVal = IcHalApiSetUmtsDagcReset();

    return retVal;
}

UINT32 BspHalAdaptSetUmtsDagcPowCfg(UINT32 difChan, UINT32 carrId, UINT32 radioMode)
{
    UINT32 retVal = BSP_OK;

    retVal = IcHalApiSetUmtsDagcPowCfg(difChan, carrId, radioMode);

    return retVal;
}

UINT32 BspHalAdaptGetUmtsDagcPowPrt(UINT32 difChan, UINT32 carrId, UINT32 radioMode, UINT32 *errFlag)
{
    UINT32 retVal = BSP_OK;

    retVal = IcHalApiGetUmtsDagcPowPrt(difChan, carrId, radioMode, errFlag);

    return retVal;
}

UINT32 BspGainToReg(DOUBLE iGain, UINT32 uiBase)
{
    UINT32 uiRegVal  = 0;
    FLOAT  fRegVal   = 0;

    fRegVal = GAIN_TO_REG((DOUBLE)iGain, uiBase);
    uiRegVal = floor(fRegVal + 0.5);
    return uiRegVal;
}

UINT32 BspIcHalApiSetDlbankAptuneWithPhase(UINT32 uiDifChan, UINT32 uiCarrId, UINT32 uiRadioMode, UINT32 phase)
{
    UINT32 uiRet    = 0;
    INT32 iGain     = 0;
    INT32 iRealCoef = 0;
    INT32 iImagCoef = 0;
    UINT32 uiCoef   = 0;

    uiRet = IcHalApiGetDlbankAptune(uiDifChan, uiCarrId, uiRadioMode, &iGain);
    if(BSP_ERROR == uiRet)
    {
        return BSP_ERROR;
    }
    iGain = (iGain + 50) / 100; //API接口获取的增益值单位为0.01
    uiCoef = BspGainToReg((DOUBLE)iGain, 4096);
    iRealCoef = (INT32)((DOUBLE)uiCoef * cos(phase/(57.295779)));//57.295779为度数转弧度值转换的固定值，仅此处使用
    iImagCoef = (INT32)((DOUBLE)uiCoef * sin(phase/(57.295779)));
    uiRet = IcHalApiSetDlbankAptuneWithPhase(uiDifChan, uiCarrId, uiRadioMode, iRealCoef, iImagCoef);

    return uiRet;
}
UINT32 BspHalAdaptOptVerifyT12Cfg(UINT32 netMode, UINT32 chipTransDly, UINT32 ta, UINT32 fwdT12, UINT32 revT12)
{
    return IcHalOptVerifyT12Cfg(netMode, chipTransDly, ta, fwdT12, revT12);
}
UINT32 BspHalAdaptPsyncModeCfg(UINT32 psyncMode)
{
    return IcHalApiPsyncCfg(psyncMode);
}
UINT32 BspHalAdaptSetFeatureFrAdjustVal(UINT32 antNo, UINT32 carrNo, UINT32 radioMode, UINT32 functionMode)
{
    return IcHalApiSetFeatureFrAdjustVal(antNo, carrNo, radioMode, functionMode);  
}

/* Started by AICoder, pid:gd6d3c48a4ncd0014f350affc0dcb415bb154109 */
UINT32 BspHalAdaptCpriCfgIqCloseEn(UINT32 logOptNo, UINT32 openEn, UINT32 chnDir)
{
    return IcHalApiCpriCfgIqCloseEn(logOptNo, openEn, chnDir);
}
/* Ended by AICoder, pid:gd6d3c48a4ncd0014f350affc0dcb415bb154109 */

/* Started by AICoder, pid:u82f774464659d7149900b0cf01ee91cf2555559 */
/**
 * @brief 电桥机型设置下行额外延迟标志
 *
 * 该函数用于设置特定通道、载波、制式的下行额外延迟标志。
 *
 * @param difChan 通道号
 * @param carrId 载波ID
 * @param radioMode 制式
 * @param flag 标志位
 * @return 返回操作结果 (UINT32)
 */
UINT32 BspHalAdaptSetDlExtraDlyFlag(UINT32 difChan, UINT32 carrId, UINT32 radioMode, UINT32 flag)
{
    return IcHalApiSetDlExtraDlyFlag(difChan, carrId, radioMode, flag);
}
/* Ended by AICoder, pid:u82f774464659d7149900b0cf01ee91cf2555559 */

/* Started by AICoder, pid:w9f39z7c6bl72151424209a2a03a0d14c1c2fe67 */
/**
 * @brief 电桥机型清除额外延迟标志
 *
 * 该函数用于清除下行额外延迟标志。
 *
 * @param 无
 * @return 返回操作结果 (UINT32)
 */
UINT32 BspSetDlExtraDlyFlagClr(void)
{
    return IcHalApiSetDlExtraDlyFlagClr();
}
/* Ended by AICoder, pid:w9f39z7c6bl72151424209a2a03a0d14c1c2fe67 */

/* Started by AICoder, pid:g4843b4712ab8a214f4c085ce0d3fb6bd861a7a4 */
UINT32 BspGetChanInfoByPwrTempType(UINT32 pwrTempType, UINT32 *pwrChanNum, UINT32 *pwrChanMask)
{
    INT32 ret = 0;
    UINT32 loop = 0;
    UINT32 devNum = 0;
    T_HwInfo* hwInfo = NULL;
    CHAR *pDeviceId = NULL;
    CHAR *pPathName = NULL;
    UINT32 nodeIndex = 0;
    CHAR arrMask[BAR_MAX_LENGTH] = {'\0'};
    UINT32 chnMask = 0;
    UINT32 chnLoop = 0;
    UINT32 chanNum = 0;
    UINT32 index = 0;
    CHAR originalString[BAR_MAX_LENGTH] = "TempRpdc";
    CHAR newString[BAR_MAX_LENGTH] = {'\0'};
    INPUT_POINTER_CHECK(pwrChanNum);
    INPUT_POINTER_CHECK(pwrChanMask);

    devNum = BspGetDevNum();
    hwInfo = BspGetBoardPropInfo();
    INPUT_POINTER_CHECK(hwInfo);

    dbgInfoEx("[%s] pwrType:%u, devNum:%u \n",  __FUNCTION__, pwrTempType, devNum);

    for (loop = 0; loop < devNum; loop++)
    {
        pDeviceId = hwInfo->BoardInfo.pDeviceInfoDscp[loop].acDeviceId;
        pPathName = hwInfo->BoardInfo.pDeviceInfoDscp[loop].acPathName;
        INPUT_POINTER_CHECK(pDeviceId);
        INPUT_POINTER_CHECK(pPathName);

        ret = snprintf_s(newString, sizeof(newString), "%s%d", originalString, pwrTempType);
        SNPRINTF_S_CHECK(ret, sizeof(newString));

        if (0 == strncmp(newString, pDeviceId, 9))
        {
            for(index = 0; index < BAR_MAX_LENGTH; index++)
            {
                if ('\0' != pPathName[index])
                {
                    arrMask[index] = pPathName[index];
                }
            }
            chnMask = (UINT32)BspAtoi(arrMask, 0);
            /*暂时按照最大32通道处理*/
            for(chnLoop = 0; chnLoop < 32; chnLoop++)
            {
                if (0 != ((chnMask >> chnLoop) & 1))
                {
                    chanNum ++;
                }
            }

            nodeIndex++;
            /*目前D42 TDD没有超过32通道机型*/
            *pwrChanNum = chanNum;
            *pwrChanMask = chnMask;
            dbgInfoEx("[%s] arrMask:%s, chanMask:%d, chanNum:%d. \n", __FUNCTION__, arrMask, chnMask, chanNum);
            return BSP_OK;
        }
    }
    return BSP_ERROR;
}
/* Ended by AICoder, pid:g4843b4712ab8a214f4c085ce0d3fb6bd861a7a4 */

UINT32 BspHalAdaptGetNot10MsFrCnt(UINT32 uiFrId, UINT32 *puiNot10MsFrCnt)
{
    return IcHalApiGetNot10MsFrCnt(uiFrId, puiNot10MsFrCnt);
}

/* Started by AICoder, pid:j3e12ad3aeq3dca14aa80bb700a21e0aa2a427fd */
UINT32 BspHalCpriSwAlignFrSel(UINT32 ulLogOptNo, UINT32 ulRdFrSel, UINT32 ulBypassAlign)
{
    UINT32 netWorkMode = 0;
    UINT32 ulProtocol  = 0;
    UINT32 ulRet       = BSP_OK;

    ulRet = BspHalAdaptGetCpriProtocol(&ulProtocol);
    if(ulRet != BSP_OK)
    {
        dbgErr("BspGetOptCpriProtocol error\n");
        return ulRet;
    }
    
    (VOID)BspHalAdaptGetCpriNetMode(&netWorkMode);
    dbgInfoEx("%s ulProtocol %d netWorkMode  %d \n",__FUNCTION__,ulProtocol,netWorkMode);
    if((netWorkMode == NET_MODE_LOAD_SHARE) && (ulProtocol == PROCOTOL_IR))
    {
        return IcHalApiSwAlignFrSel(ulLogOptNo, ulRdFrSel, ulBypassAlign);
    }

    return BSP_OK;
}
/* Ended by AICoder, pid:j3e12ad3aeq3dca14aa80bb700a21e0aa2a427fd */

/* Started by AICoder, pid:a581acbd6cs44871448a08f0e0a7c40d4de8a1e7 */
UINT32 BspHalAdaptBifGFLoopCheckTest(VOID)
{
    UINT32 retVal = BSP_OK;
#ifndef UT_FT_TEST
    retVal = IcHalApiBifGFLoopCheckTest();
#endif
    return retVal;
}
/* Ended by AICoder, pid:a581acbd6cs44871448a08f0e0a7c40d4de8a1e7 */
/* Started by AICoder, pid:30554ib64e551c9148150bc680e89a1fc283f112 */
 //下发整机级的射频开关配置需要对齐的制式和帧头偏移量并配置射频开关和功率检测的帧头延时
UINT32 BspHalAdaptSetSwRadioModeAndFrOffSet(UINT32 uiRadioMode, UINT32 uiFrOffSetNs)
{
    UINT32 retVal = BSP_OK;
    retVal = IcHalApiSetSwRadioModeAndFrOffSet(uiRadioMode, uiFrOffSetNs);
    return retVal;
}

UINT32 BspHalAdaptSetSwFrDlyFlag(UINT32 uiSwFrDlyFlag)
{
    UINT32 retVal = BSP_OK;
    retVal = IcHalApiSetSwFrDlyFlag(uiSwFrDlyFlag);
    return retVal;
}
/* Ended by AICoder, pid:30554ib64e551c9148150bc680e89a1fc283f112 */

/* Started by AICoder, pid:t0bb9f9d19a0de414014092c30683e2ea920bfd5 */
UINT32 BspHalAdaptPreInitPcs(T_BspHalAdaptPcsCfg *pcsCfg, UINT32 laneNum)
{
    UINT32 retVal = BSP_OK;
    retVal = IcHalApiPreInitPcs(pcsCfg, laneNum);
    return retVal;
} 

UINT32 BspHalAdaptInitPcs(T_BspHalAdaptPcsCfg *pcsCfg, UINT32 laneNum)
{
    UINT32 retVal = BSP_OK;
    retVal = IcHalApiInitPcs(pcsCfg, laneNum);
    return retVal;
}

UINT32 BspHalAdaptSetFlowTokenEn(T_BspHalAdaptPcsCfg *pcsCfg, UINT32 laneNum)
{
    UINT32 retVal = BSP_OK;
    retVal = IcHalApiSetFlowTokenEn(pcsCfg, laneNum);
    return retVal;
}
/* Ended by AICoder, pid:t0bb9f9d19a0de414014092c30683e2ea920bfd5 */

/* Started by AICoder, pid:b4b13bcbc0sfeaf143940b6f8073160f304745e6 */
UINT32 BspHalAdaptOptCheckAxc(UINT32 cellId, UINT32 radioMode)
{
    UINT32 retVal = BSP_OK;
    retVal = IcHalApiOptCheckAxc(cellId, radioMode);
    return retVal;
}
/* Ended by AICoder, pid:b4b13bcbc0sfeaf143940b6f8073160f304745e6 */

/* Started by AICoder, pid:2a98440f07d06ec144ae097d10e5b82144a63e18 */
INT32 BspHalAdaptSetTxCarrDelayAdj(UINT32 difChan, UINT32 carrId, UINT32 radioMode, INT32 adjDlyNs)
{
    UINT32 retVal = BSP_OK;
    retVal = IcHalApiSetTxCarrDelayAdj(difChan,carrId,radioMode,adjDlyNs);
    return retVal;
}
/* Ended by AICoder, pid:2a98440f07d06ec144ae097d10e5b82144a63e18 */

/* Started by AICoder, pid:32fb6t38ffja22f14fc30b04d01b730a81e38b58 */
UINT32 BspHalAdaptCrmCfgRoeGate(UINT32 ulChip, UINT32 ulClkBitMap)
{
    UINT32 retVal = BSP_OK;
    retVal = IcHalApiCrmCfgRoeGate(ulChip, ulClkBitMap);
    return retVal;
}

UINT32 BspHalAdaptCrmCfgRoeElcBrpGate(UINT32 elcBrpGateSw)
{
    UINT32 retVal = BSP_OK;
    retVal = IcHalApiCrmCfgRoeElcBrpGate(elcBrpGateSw);
    return retVal;
}

UINT32 BspHalAdaptSw1ClockGatingEn(UINT32 swGate)
{
    UINT32 retVal = BSP_OK;
    retVal = IcHalSw1ClockGatingEn(swGate);
    return retVal;
}

UINT32 BspHalAdaptSw1MapGate(UINT32 mapGate)
{
    UINT32 retVal = BSP_OK;
    retVal = IcHalSw1MapGate(mapGate);
    return retVal;
}

UINT32 BspHalAdaptGfSetOranChClkGataEn(UINT32 ulTdmChan, UINT32 ulMode)
{
    UINT32 retVal = BSP_OK;
    retVal = OptGfSetOranChClkGataEn(ulTdmChan, ulMode);
    return retVal;
}

UINT32 BspHalAdaptGfSetBdrChClkGataEn(UINT32 ulTdmChan, UINT32 ulMode)
{
    UINT32 retVal = BSP_OK;
    retVal = OptGfSetBdrChClkGataEn(ulTdmChan, ulMode);
    return retVal;
}

UINT32 BspHalAdaptGfSetGfChClkGataEn(UINT32 ulTdmChan, UINT32 ulMode)
{
    UINT32 retVal = BSP_OK;
    retVal = OptGfSetGfChClkGataEn(ulTdmChan, ulMode);
    return retVal;
}

UINT32 BspHalAdaptDifSetLTEGateEN(UINT32 ulChan, UINT32 ulMode)
{
    UINT32 retVal = BSP_OK;
    retVal = OptDifSetLTEGateEN(ulChan, ulMode);
    return retVal;
}

UINT32 BspHalAdaptDifSetFFTAGateEN(UINT32 ulChan, UINT32 ulMode)
{
    UINT32 retVal = BSP_OK;
    retVal = OptDifSetFFTAGateEN(ulChan, ulMode);
    return retVal;
}

UINT32 BspHalAdaptDifSetAXIGateEN(UINT32 ulChan, UINT32 ulMode)
{
    UINT32 retVal = BSP_OK;
    retVal = OptDifSetAXIGateEN(ulChan, ulMode);
    return retVal;
}

UINT32 BspHalAdaptCrmCfgFftGate16T0(UINT32 ulChip, UINT32 ulClkBitMap)
{
    UINT32 retVal = BSP_OK;
    retVal = IcHalApiCrmCfgFftGate16T0(ulChip, ulClkBitMap);
    return retVal;
}

UINT32 BspHalAdaptCrmCfgPrachGate16T0(UINT32 ulChip, UINT32 ulClkBitMap)
{
    UINT32 retVal = BSP_OK;
    retVal = IcHalApiCrmCfgPrachGate16T0(ulChip, ulClkBitMap);
    return retVal;
}
/* Ended by AICoder, pid:32fb6t38ffja22f14fc30b04d01b730a81e38b58 */

UINT32 BspHalAdaptResourceRecycle(UINT32 dir, T_DifChanInfo *ptChanInfo)
{
    UINT32 retVal = BSP_OK;

    if(dir == TX)
    {
        retVal = IcHalApiTxResourceRecycle(ptChanInfo);
    }
    else if(dir == RX)
    {
        retVal = IcHalApiRxResourceRecycle(ptChanInfo);
    }
    else
    {
        dbgErr("[%s] Error: input isn't TX or RX!\n" ,__FUNCTION__);
        return BSP_ERROR;
    }

    return retVal;
}

UINT32 BspHalAdaptCatchdataSampleBySlot(UINT32 uiDifChan, UINT32 uiCarrId, UINT32 uiRadioMode,UINT32 uiSlot,UINT32 uiPos)
{
    return IcHalApiSampleBySlot(uiDifChan, uiCarrId, uiRadioMode,uiSlot,uiPos);
}

/* Started by AICoder, pid:b68b4z2e38p9e1e1416b09ed10407b094a755adf */
VOID BspHalAdaptSetNcrMutiL2ssFlag(UINT32 mutiL2ssFlag)
{
    IcHalSetNcrMutiL2ssFlag(mutiL2ssFlag);
    return;
}
/* Ended by AICoder, pid:b68b4z2e38p9e1e1416b09ed10407b094a755adf */

/* Started by AICoder, pid:10aa9g102axe61414b2809d2306024479f1480c7 */
/**************************************************************************
                            AAC序列增益相关接口
**************************************************************************/
UINT32 BspHalAdaptStartAacProcess(UINT32 uCellId, T_AacFrameBitMapInfo *pAacFrameBitMap, UINT32 frameLen,UINT32 uAacType, UINT32 uAacStage)
{
    return IcHalApiStartAacProcess(uCellId, pAacFrameBitMap, frameLen, uAacType, uAacStage);
}
UINT32 BspHalAdaptSetAacFrameGainPara(UINT32 uCellId, T_AacFrameGain * pFrameGain, INT32 gainDefalutDb, INT32 rfBackGain, UINT32 uAacType)
{
    return IcHalApiSetAacFrameGainPara(uCellId, pFrameGain, gainDefalutDb, rfBackGain, uAacType);
}
UINT32 BspHalAdaptStopAacProcess(UINT32 uCellId, UINT32 uAacType)
{
    return IcHalApiStopAacProcess(uCellId, uAacType);
}
UINT32 BspHalAdaptSetSpecialCfgFlag(E_SPECIAL_CFG_TYPE uFlag)
{
    return IcHalApiSetSpecialCfgFlag(uFlag);
}

UINT32 BspHalAdaptGetDlpreSampPointPhyAddr(UINT32 difChan, UINT32 logicCarrNo, UINT32 radioMode, UINT32 *dlyAddr)
{
    return IcHalApiGetDlpreSampPointPhyAddr(difChan, logicCarrNo, radioMode, dlyAddr);
}

UINT32 BspHalAdaptSetAacFrameModePara(T_AacFrameModePara *aacPara)
{
    return IcHalApiSetAacFrameModePara(aacPara);
}

UINT32 BspHalAdaptSetAacSampPointDlyPara(T_AacSampPointDly *dlyPara)
{
    return IcHalApiSetAacSampPointDlyPara(dlyPara);
}

UINT32 BspHalAdaptSetAacTddIoLinkMapPara(T_AacTddIoLinkMap *para)
{
    return IcHalApiSetAacTddIoLinkMapPara(para);
}

UINT32 BspHalAdaptSetAacSuperFrameInfo(UINT32 uCellId, T_AacSuperFrameInfo *pSuper, UINT32 uAacType)
{
    return IcHalApiSetAacSuperFrameInfo(uCellId, pSuper, uAacType);
}

UINT32 BspHalAdaptCarrAacSwitchEn(UINT32 uCarrNo, UINT32 uRadioMode, UINT32 uSwitch)
{
    return IcHalApiCarrAacSwitchEn(uCarrNo, uRadioMode, uSwitch);
}
/* Ended by AICoder, pid:10aa9g102axe61414b2809d2306024479f1480c7 */

/* Started by AICoder, pid:v2701w2000k88f6142270a2e1093cd0ef7c801d3 */
UINT32 BspHalAdaptCdcJitterCfg(UINT32 uiJitterVal)
{
    UINT32 retVal = BSP_OK;
    retVal =  IcHalApiCdcJitterCfg(uiJitterVal);  
    return retVal;
}
/* Ended by AICoder, pid:v2701w2000k88f6142270a2e1093cd0ef7c801d3 */

/* Started by AICoder, pid:n848303d2c023b0147ae0a92c0e4d708b4a534a3 */
UINT32 BspHalGetQcellSuperFrameAdjustFlag(VOID)
{
    return IcHalApiGetQcellSuperFrameAdjustFlag();
}
/* Ended by AICoder, pid:n848303d2c023b0147ae0a92c0e4d708b4a534a3 */

/* Started by AICoder, pid:p2c4a47f66rbda2146c4098f60c2690bdc84048c */
UINT32 BspHalAdaptSetDlyMode(UINT32 uiDlyMode)
{
    return IcHalApiSetDlyMode(uiDlyMode);
}
/* Ended by AICoder, pid:p2c4a47f66rbda2146c4098f60c2690bdc84048c */

VOID BspHalAdaptOptLogPrintInit(UINT32 ulLogType, UINT32 ulLogSize)
{
    IcHalApiOptLogPrintInit(ulLogType, ulLogSize);
    return ;
}

UINT32 BspHalAdaptSetDlbankAllDgainRegWrZero(VOID)
{
    return IcHalApiSetDlbankAllDgainRegWrZero();
}

UINT32 BspHalAdaptOptCheckBifGfTblCfg(UINT32 *pCheckResult)
{
    return IcHalApiOptCheckBifGfTblCfg(pCheckResult);
}

UINT32 BspHalAdaptOptPseudoIQCheck(UINT32 *pCheckResult)
{
    return IcHalApiOptPseudoIQCheck(pCheckResult);
}

/* Started by AICoder, pid:1285b72bbbd28e414236089f502d64294bb3b8fd */
UINT32 BspHalAdaptQcellCheckIqRes(UINT32 iqTblLen, T_PRruIqCfgItem_BSP *pRruIqCfgInfo, T_PRruIqResultItem_BSP *pRruIqResult)
{
    UINT32 retVal = BSP_OK;
    INPUT_POINTER_CHECK(pRruIqCfgInfo);
    INPUT_POINTER_CHECK(pRruIqResult);
    retVal = IcHalApiQcellCheckIqRes(iqTblLen, pRruIqCfgInfo, pRruIqResult);
    return retVal;
}

UINT32 BspHalAdaptGetQcellTxIqSwitchFlag(UINT32 icId)
{
    UINT32 retVal = BSP_OK;
    retVal = IcHalApiGetQcellTxIqSwitchFlag(icId);
    return retVal;
}

UINT32 BspHalAdaptQcellCpriIqTxSwitch(UINT32 funcId, UINT32 icId, UINT32 en)
{
    UINT32 retVal = BSP_OK;
    retVal = IcHalApiQcellCpriIqTxSwitch(funcId, icId, en);
    return retVal;
}
/* Ended by AICoder, pid:1285b72bbbd28e414236089f502d64294bb3b8fd */

UINT32 BspHalAdaptUpdateRoeState(VOID)
{
    return IcHalApiUpdateRoeState();
}

UINT32 BspHalAdaptGetOptWorkMode(VOID)
{
    return IcHalGetOptWorkMode();
}

UINT32 BspHalAdaptRoeCpriDempperBufToP2Delay(UINT32 ulChanIndex, UINT32 uDir)
{
    return IcHalRoeCpriDempperBufToP2DelayApi(ulChanIndex, uDir);
}

UINT32 BspHalAdaptRoeIqDemapperTimeMeasApiForCpri(UINT32 ulChanIndex, UINT32 uT12)
{
    return IcHalRoeIqDemapperTimeMeasApiForCpri(ulChanIndex, uT12);
}

UINT32 BspHalAdaptRoeCpriLinkRebuild(UINT32 ulChanIndex)
{
    return IcHalRoeCpriLinkRebuildApi(ulChanIndex);
}

UINT32 BspHalAdaptGetBbuRoeT12(VOID)
{
    return IcHalGetBbuRoeT12();
}


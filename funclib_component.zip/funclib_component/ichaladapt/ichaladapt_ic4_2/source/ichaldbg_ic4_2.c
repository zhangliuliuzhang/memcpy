/*****************************************************************************
* 版权所有(C) 2020, ZTE Corp. ZXSDR-RRU Platform BSP
*----------------------------------------------------------------------------
* 模 块 名 : bsp
* 文件名称 : ichaldbg.c
* 文件标识 : {[N/A]}
* 内容摘要 : 本文件提供了ICHAL适配层接口函数实现
* 注意事项 : 无
* 作    者 : 王涛10248577
* 创建日期 : 2020-11-04
* 当前版本 : Ver1.0
*----------------------------------------------------------------------------
* 变更记录 :
*
* $记录1
* 变 更 单: $0000000(N/A)
* 责 任 人: 王涛10248577
* 修改日戳: 2020-11-04
* 变更说明: 创建文件
*----------------------------------------------------------------------------
*/

#include "ichaldbg_ic4_2.h"
#include "ichaladapt_crm_ic4_2.h"

#define RESULT_TO_STR(result)  ((result)==0?"OK":((result)==0xff?"SKIP":"ERR"))

//FUNCLIB->HAL
static T_DifCarrInfo **g_dbgDifCarrInfo = NULL;
static T_DifCarrInfo **g_dbgDifCarrInfoRpt = NULL;

static T_DifCarrInfo **BspGetDbgDifCarrInfoMem(void)
{
    if (g_dbgDifCarrInfo == NULL)
    {
        UINT32 i = 0;
        size_t mallocLen = sizeof(T_DifCarrInfo *) * (PRX + 1);
        g_dbgDifCarrInfo = (T_DifCarrInfo **)malloc(mallocLen);
        if (g_dbgDifCarrInfo == NULL)
        {
            return NULL;
        }
        zte_memset_s(g_dbgDifCarrInfo, mallocLen, 0, mallocLen);
        for (i = 0; i < PRX + 1; i++)
        {
            mallocLen = sizeof(T_DifCarrInfo) * IC_CHAN_MAX_NUM;
            g_dbgDifCarrInfo[i] = (T_DifCarrInfo *)malloc(mallocLen);
            if (g_dbgDifCarrInfo[i] == NULL)
            {
                break;
            }
            zte_memset_s(g_dbgDifCarrInfo[i], mallocLen, 0, mallocLen);
        }
        /* 存在局部申请失败的情况,释放所有内存 */
        if (i < PRX + 1)
        {
            for (i = 0; i < PRX + 1; i++)
            {
                if (g_dbgDifCarrInfo[i] != NULL)
                {
                    free(g_dbgDifCarrInfo[i]);
                }
            }
            free(g_dbgDifCarrInfo);
            g_dbgDifCarrInfo = NULL;
            return NULL;
        }
    }
    return g_dbgDifCarrInfo;
}

UINT32 dbgSaveHalCarrInfo(UINT32 dir, UINT32 difChan, T_DifCarrInfo *carrInfo)
{
    T_DifCarrInfo **dbgDifCarrInfo = BspGetDbgDifCarrInfoMem();
    INPUT_POINTER_CHECK(dbgDifCarrInfo);
    if(dir<=PRX && difChan < IC_CHAN_MAX_NUM)
    {    
       memcpy_s(&(dbgDifCarrInfo[dir][difChan]), sizeof(T_DifCarrInfo), carrInfo, sizeof(T_DifCarrInfo));
       return BSP_OK;
    }
    return BSP_ERROR;
}

static T_DifCarrInfo **BspGetDbgDifCarrInfoRptMem(void)
{
    if (g_dbgDifCarrInfoRpt == NULL)
    {
        UINT32 i = 0;
        size_t mallocLen = sizeof(T_DifCarrInfo *) * (PRX + 1);
        g_dbgDifCarrInfoRpt = (T_DifCarrInfo **)malloc(mallocLen);
        if (g_dbgDifCarrInfoRpt == NULL)
        {
            return NULL;
        }
        zte_memset_s(g_dbgDifCarrInfoRpt, mallocLen, 0, mallocLen);
        for (i = 0; i < PRX + 1; i++)
        {
            mallocLen = sizeof(T_DifCarrInfo) * IC_CHAN_MAX_NUM;
            g_dbgDifCarrInfoRpt[i] = (T_DifCarrInfo *)malloc(mallocLen);
            if (g_dbgDifCarrInfoRpt[i] == NULL)
            {
                break;
            }
            zte_memset_s(g_dbgDifCarrInfoRpt[i], mallocLen, 0, mallocLen);
        }
        /* 存在局部申请失败的情况,释放所有内存 */
        if (i < PRX + 1)
        {
            for (i = 0; i < PRX + 1; i++)
            {
                if (g_dbgDifCarrInfoRpt[i] != NULL)
                {
                    free(g_dbgDifCarrInfoRpt[i]);
                }
            }
            free(g_dbgDifCarrInfoRpt);
            g_dbgDifCarrInfoRpt = NULL;
            return NULL;
        }
    }
    return g_dbgDifCarrInfoRpt;
}

UINT32 dbgSaveHalRptCarrInfo(UINT32 dir, UINT32 difChan, T_DifCarrInfo *carrInfo)
{
    T_DifCarrInfo **dbgDifCarrInfoRpt = BspGetDbgDifCarrInfoRptMem();
    INPUT_POINTER_CHECK(dbgDifCarrInfoRpt);
    if(dir<=PRX && difChan <IC_CHAN_MAX_NUM)
    {
       memcpy_s(&(dbgDifCarrInfoRpt[dir][difChan]), sizeof(T_DifCarrInfo), carrInfo, sizeof(T_DifCarrInfo));
       return BSP_OK;
    }
    return BSP_ERROR;
}

static UINT32 dbgShowHalRptDifCarrInfo(UINT32 dir, UINT32 difChan)
{
    UINT32 loopCarr = 0;
    T_DifCarrInfo *pCarrInfo = NULL;
    T_DifCarrInfo **dbgDifCarrInfoRpt = BspGetDbgDifCarrInfoRptMem();
    INPUT_POINTER_CHECK(dbgDifCarrInfoRpt);

    if(dir > PRX || difChan >=IC_CHAN_MAX_NUM)
    {
        return BSP_ERROR;
    }

    pCarrInfo = &(dbgDifCarrInfoRpt[dir][difChan]);

    dbgInfo("%s HAL CARR INFO is :\n",dir==TX?"TX":"RX");
    dbgInfo("carr flag carrId carrFreq carrBw carrRadio ssb rcf \n");
    for(loopCarr=0;loopCarr<pCarrInfo->uiCarrNum;loopCarr++)
    {
        dbgInfo("%4d %4d %6d %8d %6d %9d %3d %3d\n",loopCarr,
        pCarrInfo->atCarrInfo[loopCarr].uiDelOrAddFlag,
        pCarrInfo->atCarrInfo[loopCarr].uiCarrId,
        pCarrInfo->atCarrInfo[loopCarr].uiCarrFreq,
        pCarrInfo->atCarrInfo[loopCarr].uiCarrBw,
        pCarrInfo->atCarrInfo[loopCarr].uiCarrRadio,
        pCarrInfo->atCarrInfo[loopCarr].uiIsSsb,
        pCarrInfo->atCarrInfo[loopCarr].uiIsRcf);
    }

    return BSP_OK;
}

static UINT32 dbgShowHalDifCarrInfo(UINT32 dir, UINT32 difChan)
{
    UINT32 loopCarr = 0;
    T_DifCarrInfo *pCarrInfo = NULL;
    T_DifCarrInfo **dbgDifCarrInfo = BspGetDbgDifCarrInfoMem();
    INPUT_POINTER_CHECK(dbgDifCarrInfo);

    if(dir > PRX || difChan >=IC_CHAN_MAX_NUM)
    {
        return BSP_ERROR;
    }

    pCarrInfo = &(dbgDifCarrInfo[dir][difChan]);

    dbgInfo("%s HAL CARR INFO is :\n",dir==TX?"TX":"RX");
    dbgInfo("carr flag carrId carrFreq carrBw carrRadio ssb rcf \n");
    for(loopCarr=0;loopCarr<pCarrInfo->uiCarrNum;loopCarr++)
    {    
    	dbgInfo("%4d %4d %6d %8d %6d %9d %3d %3d\n",loopCarr,
        pCarrInfo->atCarrInfo[loopCarr].uiDelOrAddFlag,
        pCarrInfo->atCarrInfo[loopCarr].uiCarrId,
        pCarrInfo->atCarrInfo[loopCarr].uiCarrFreq,
        pCarrInfo->atCarrInfo[loopCarr].uiCarrBw,
        pCarrInfo->atCarrInfo[loopCarr].uiCarrRadio,
        pCarrInfo->atCarrInfo[loopCarr].uiIsSsb,
        pCarrInfo->atCarrInfo[loopCarr].uiIsRcf);
    }

    return BSP_OK;
}

static UINT32 dbgShowHalTxRouteMap(UINT32 startChan, UINT32 endChan)
{
    UINT32 loopChan = 0;
    T_DifCfgSave* pSaveCfg = NULL;
    UINT32 txChnNum = BspGetTxChanNum();

    if(startChan >= txChnNum || endChan >= txChnNum)
    {
        return BSP_ERROR;
    }

    pSaveCfg = GetDifCfgSave(E_DIF_ROUTEMAP_TX);
    if(NULL == pSaveCfg)
    {
        return BSP_ERROR;
    }
    
    T_DifTxRouteMap *p_dbgDifTxRouteMap = (T_DifTxRouteMap *)(pSaveCfg->pAddr);
    if(NULL == p_dbgDifTxRouteMap)
    {
        return BSP_ERROR;
    }
    
    dbgInfo("TX[linkNum=%d difNum=%d] ROUTE MAP is :\n", pSaveCfg->linkunm,pSaveCfg->difChNum);
    dbgInfo("link difChan freqId bankOut cfrPort CfrPortNum cfrCombIn cfrCombOut CfrCombPortNum cfrOut dpdPort CfrOutPortNum\n");
    for(loopChan=startChan;loopChan<=endChan;loopChan++)
    {    
    	dbgInfo("%4d %7d %6d %7d %7d %10d %9d %10d %14d %6d %7d %13d\n",
        p_dbgDifTxRouteMap[loopChan].uiLinkId,
        p_dbgDifTxRouteMap[loopChan].uiDifChan,
        p_dbgDifTxRouteMap[loopChan].uiFreqId,
        p_dbgDifTxRouteMap[loopChan].uiBankOut,
        p_dbgDifTxRouteMap[loopChan].uiCfrPort,
        p_dbgDifTxRouteMap[loopChan].uiCfrPortNum,
        p_dbgDifTxRouteMap[loopChan].uiCfrCombIn,
        p_dbgDifTxRouteMap[loopChan].uiCfrCombOut,
        p_dbgDifTxRouteMap[loopChan].uiCfrCombPortNum,
        p_dbgDifTxRouteMap[loopChan].uiCfrOut,
        p_dbgDifTxRouteMap[loopChan].uiDpdPort,
        p_dbgDifTxRouteMap[loopChan].uiCfrOutPortNum);
    } 

    return BSP_OK;
}

static UINT32 dbgShowHalTxRoutePara(UINT32 startChan, UINT32 endChan)
{
    UINT32 loopChan = 0;
    T_DifCfgSave* pSaveCfg = NULL;
    UINT32 txChnNum = BspGetTxChanNum();

    if(startChan >= txChnNum || endChan >= txChnNum)
    {
        return BSP_ERROR;
    }

    pSaveCfg = GetDifCfgSave(E_DIF_ROUTEPARA_TX);
    if(NULL == pSaveCfg)
    {
        return BSP_ERROR;
    }
    
    T_DifTxRoutePara *p_dbgDifTxRoutePara = (T_DifTxRoutePara *)(pSaveCfg->pAddr);
    if(NULL == p_dbgDifTxRoutePara)
    {
        return BSP_ERROR;
    }
    
    dbgInfo("TX[linkNum=%d difNum=%d] ROUTE PARA is :\n", pSaveCfg->linkunm,pSaveCfg->difChNum);
    dbgInfo("link difChan freqId src2Mode src3Mode src3BypassEn dpdMode etMode cfrPhase2x dpdPhase2x tddMode\n");
    for(loopChan=startChan;loopChan<=endChan;loopChan++)
    {    
    	dbgInfo("%4d %7d %6d %8d %8d %12d %7d %6d %10d %10d %7d\n",
        p_dbgDifTxRoutePara[loopChan].uiLinkId,
        p_dbgDifTxRoutePara[loopChan].uiDifChan,
        p_dbgDifTxRoutePara[loopChan].uiFreqId,
        p_dbgDifTxRoutePara[loopChan].uiSrc2Mode,
        p_dbgDifTxRoutePara[loopChan].uiSrc3Mode,
        p_dbgDifTxRoutePara[loopChan].uiSrc3BypassEn,
        p_dbgDifTxRoutePara[loopChan].uiDpdMode,
        p_dbgDifTxRoutePara[loopChan].uiEtMode,
        p_dbgDifTxRoutePara[loopChan].uiCfrPhase2x,
        p_dbgDifTxRoutePara[loopChan].uiDpdPhase2x,
        p_dbgDifTxRoutePara[loopChan].uiTddMode);
    } 

    return BSP_OK;
}

static UINT32 dbgShowHalTx204Route(UINT32 startChan, UINT32 endChan)
{
    UINT32 loopChan = 0;
    T_DifCfgSave* pSaveCfg = NULL;
    UINT32 txChnNum = BspGetTxChanNum();

    if(startChan >= txChnNum || endChan >= txChnNum)
    {
        return BSP_ERROR;
    }

    pSaveCfg = GetDifCfgSave(E_DIF_ROUTEMAP_204);
    if(NULL == pSaveCfg)
    {
        return BSP_ERROR;
    }
    
    T_DifTx204RouteMap *p_dbgDifTx204Route = (T_DifTx204RouteMap *)(pSaveCfg->pAddr);
    if(NULL == p_dbgDifTx204Route)
    {
        return BSP_ERROR;
    }
    
    dbgInfo("TX[linkNum=%d difNum=%d] 204 ROUTE MAP is :\n", pSaveCfg->linkunm,pSaveCfg->difChNum);
    dbgInfo("link difChan freqId dpdPort dlPostPort j204PortI j204PortQ dlPostPortNum\n");
    for(loopChan=startChan;loopChan<=endChan;loopChan++)
    {    
    	dbgInfo("%4d %7d %6d %7d %10d %9d %9d %13d \n",
        p_dbgDifTx204Route[loopChan].uiLinkId,
        p_dbgDifTx204Route[loopChan].uiDifChan,
        p_dbgDifTx204Route[loopChan].uiFreqId,
        p_dbgDifTx204Route[loopChan].uiDpdPort,
        p_dbgDifTx204Route[loopChan].uiDlPostPort,
        p_dbgDifTx204Route[loopChan].ui204PortI,
        p_dbgDifTx204Route[loopChan].ui204PortQ,
        p_dbgDifTx204Route[loopChan].uiDlPostPortNum
        );
    } 

    return BSP_OK;
}

static UINT32 dbgShowHalRxRouteMap(UINT32 startChan, UINT32 endChan)
{
    UINT32 loopChan = 0;
    T_DifCfgSave* pSaveCfg = NULL;
    UINT32 rxChnNum = BspGetRxChanNum();

    if(startChan >= rxChnNum || endChan >= rxChnNum)
    {
        return BSP_ERROR;
    }

    pSaveCfg = GetDifCfgSave(E_DIF_ROUTEMAP_RX);
    if(NULL == pSaveCfg)
    {
        return BSP_ERROR;
    }
    
    T_DifRxRouteMap *p_dbgDifRxRouteMap = (T_DifRxRouteMap *)(pSaveCfg->pAddr);
    if(NULL == p_dbgDifRxRouteMap)
    {
        return BSP_ERROR;
    }
    
    dbgInfo("RX[linkNum=%d difNum=%d] ROUTE MAP is :\n", pSaveCfg->linkunm,pSaveCfg->difChNum);
    dbgInfo("link difChan j204Port ulChPort ulChPortNum ulChPortSwap tddMode\n");
    for(loopChan=startChan;loopChan<=endChan;loopChan++)
    {    
    	dbgInfo("%4d %7d %8d %8d %11d %12d %7d\n",
        p_dbgDifRxRouteMap[loopChan].uiLinkId,
        p_dbgDifRxRouteMap[loopChan].uiDifChan,
        p_dbgDifRxRouteMap[loopChan].ui204Port,
        p_dbgDifRxRouteMap[loopChan].uiUlChPort,
        p_dbgDifRxRouteMap[loopChan].uiUlChPortNum,
        p_dbgDifRxRouteMap[loopChan].uiUlChSwap,
        p_dbgDifRxRouteMap[loopChan].uiTddMode);
    } 

    return BSP_OK;
}

static UINT32 dbgShowHalFbRouteMap(UINT32 startChan, UINT32 endChan)
{
    UINT32 loopChan = 0;
    T_DifCfgSave* pSaveCfg = NULL;
    UINT32 txChnNum = BspGetTxChanNum();

    if(startChan >= txChnNum || endChan >= txChnNum)
    {
        return BSP_ERROR;
    }

    pSaveCfg = GetDifCfgSave(E_DIF_ROUTEMAP_FB);
    if(NULL == pSaveCfg)
    {
        return BSP_ERROR;
    }
    
    T_DifFbRouteMap *p_dbgDifFbRouteMap = (T_DifFbRouteMap *)(pSaveCfg->pAddr);
    if(NULL == p_dbgDifFbRouteMap)
    {
        return BSP_ERROR;
    }
    
    dbgInfo("FB[linkNum=%d difNum=%d] ROUTE MAP is :\n", pSaveCfg->linkunm,pSaveCfg->difChNum);
    dbgInfo("link difChan j204PortI fbPort fbChSel fbChMode fbPhaseNum dataIqExch\n");
    for(loopChan=startChan;loopChan<=endChan;loopChan++)
    {    
    	dbgInfo("%4d %7d %9d %6d %7d %8d %10d %10d\n",
        p_dbgDifFbRouteMap[loopChan].uiLinkId,
        p_dbgDifFbRouteMap[loopChan].uiDifChan,
        p_dbgDifFbRouteMap[loopChan].uiJ204Port,
        p_dbgDifFbRouteMap[loopChan].uiFbPort,
        p_dbgDifFbRouteMap[loopChan].uiFbChSel,
        p_dbgDifFbRouteMap[loopChan].uiFbChMode,
        p_dbgDifFbRouteMap[loopChan].uiFbPhaseNum,
        p_dbgDifFbRouteMap[loopChan].uiFbDataIqExch);
    } 

    return BSP_OK;
}

static UINT32 dbgShowHalSamratePara(UINT32 startChan, UINT32 endChan)
{
    UINT32 loopChan = 0;
    T_DifCfgSave* pSaveCfg = NULL;
    UINT32 txChnNum = BspGetTxChanNum();

    if(startChan >= txChnNum || endChan >= txChnNum)
    {
        return BSP_ERROR;
    }

    pSaveCfg = GetDifCfgSave(E_DIF_DIFPARA_SAMRATE);
    if(NULL == pSaveCfg)
    {
        return BSP_ERROR;
    }
    
    T_DifSamRateCommPara *p_dbgDifSamratePara = (T_DifSamRateCommPara *)(pSaveCfg->pAddr);
    if(NULL == p_dbgDifSamratePara)
    {
        return BSP_ERROR;
    }
    
    dbgInfo("DIF Samplerate Para:\n");
    dbgInfo("link DpdSamRate CfrSamRate\n");
    for(loopChan=startChan;loopChan<=endChan;loopChan++)
    {    
    	dbgInfo("%4d %10d %10d\n",loopChan,
        p_dbgDifSamratePara->uiDpdSamRate[loopChan],
        p_dbgDifSamratePara->uiCfrSamRate[loopChan]);
    } 
    dbgInfo("\n");
    dbgInfo("ulAdcSamRate0 is %d:\n", p_dbgDifSamratePara->uiAdcSamRate[0]);
    dbgInfo("ulAdcSamRate1 is %d:\n", p_dbgDifSamratePara->uiAdcSamRate[1]);
    dbgInfo("ulAdcSamMode is %d:\n", p_dbgDifSamratePara->uiAdcSamMode);
    dbgInfo("ulDacSamRate0 is %d:\n", p_dbgDifSamratePara->uiDacSamRate[0]);
    dbgInfo("ulDacSamRate1 is %d:\n", p_dbgDifSamratePara->uiDacSamRate[1]);
    dbgInfo("ulDacSamMode is %d:\n", p_dbgDifSamratePara->uiDacSamMode);
    dbgInfo("cbAdcSamRate0 is %d:\n", p_dbgDifSamratePara->uiCbAdcSamRate[0]);
    dbgInfo("cbAdcSamRate1 is %d:\n", p_dbgDifSamratePara->uiCbAdcSamRate[1]);
    dbgInfo("cbAdcSamMode is %d:\n", p_dbgDifSamratePara->uiCbAdcSamMode);
    
    return BSP_OK;
}
static UINT32 dbgShowHalClkPara(VOID)
{
    T_DifCfgSave* pSaveCfg = NULL;

    pSaveCfg = GetDifCfgSave(E_DIF_DIFPARA_CLK);
    if(NULL == pSaveCfg)
    {
        return BSP_ERROR;
    }
    
    T_DifClkCommPara *p_dbgDifClkPara = (T_DifClkCommPara *)(pSaveCfg->pAddr);
    if(NULL == p_dbgDifClkPara)
    {
        return BSP_ERROR;
    }    
    dbgInfo("DIF Clk Para:\n");
    dbgInfo("ui737Clk is                  %d:\n", p_dbgDifClkPara->ui737Clk);
    dbgInfo("uiDlCfrClk(dl_logic2) is     %d:\n", p_dbgDifClkPara->uiDlCfrClk);
    dbgInfo("uiDlDpdClk(dl_logic3_0) is   %d:\n", p_dbgDifClkPara->uiDlDpdClk);
    dbgInfo("uiDlPostClk(dl_logic4_0) is  %d:\n", p_dbgDifClkPara->uiDlPostClk[0]);
    dbgInfo("uiDlPostClk(dl_logic4_1) is  %d:\n", p_dbgDifClkPara->uiDlPostClk[1]);
    dbgInfo("uiDlPimcClk(dl_logic3_1) is  %d:\n", p_dbgDifClkPara->uiDlPimcClk);

    dbgInfo("uiUlChClk(ul_logic1_0) is    %d:\n", p_dbgDifClkPara->uiUlChClk[0]);
    dbgInfo("uiUlChClk(ul_logic1_1) is    %d:\n", p_dbgDifClkPara->uiUlChClk[1]);
    dbgInfo("uiCbClk(fb_logic1_0) is      %d:\n", p_dbgDifClkPara->uiCbClk[0]);
    dbgInfo("uiCbClk(fb_logic1_1) is      %d:\n", p_dbgDifClkPara->uiCbClk[1]);

    
    dbgInfo("uiDlJ204SampleClk is         %d:\n", p_dbgDifClkPara->uiDlJ204SampleClk);
    dbgInfo("uiDlJ204WorkClk is           %d:\n", p_dbgDifClkPara->uiDlJ204WorkClk);
    dbgInfo("uiDlJ204SerdesClk is         %d:\n", p_dbgDifClkPara->uiDlJ204SerdesClk);
    dbgInfo("uiUlJ204SampleClk is         %d:\n", p_dbgDifClkPara->uiUlJ204SampleClk);
    dbgInfo("uiUlJ204WorkClk is           %d:\n", p_dbgDifClkPara->uiUlJ204WorkClk);
    dbgInfo("uiUlJ204SerdesClk is         %d:\n", p_dbgDifClkPara->uiUlJ204SerdesClk);
    dbgInfo("uiFbJ204SampleClk is         %d:\n", p_dbgDifClkPara->uiFbJ204SampleClk);
    dbgInfo("uiFbJ204WorkClk is           %d:\n", p_dbgDifClkPara->uiFbJ204WorkClk);
    dbgInfo("uiFbJ204SerdesClk is         %d:\n", p_dbgDifClkPara->uiFbJ204SerdesClk);
    dbgInfo("uiJ204UlLogic2Clk is         %d:\n", p_dbgDifClkPara->uiJ204UlLogic2Clk);
    dbgInfo("uiJ204DlLogic5Clk is         %d:\n", p_dbgDifClkPara->uiJ204DlLogic5Clk);
    dbgInfo("uiJ204FbLogic2Clk is         %d:\n", p_dbgDifClkPara->uiJ204FbLogic2Clk);
    
    return BSP_OK;
}

#if 0

extern T_BspHalAdaptSocCrmClk s_CrmSocClk;

static UINT32 dbgShowHalResAllocPara(UINT32 startChan, UINT32 endChan)
{
    UINT32 loopChan = 0;
    T_DifCfgSave* pSaveCfg = NULL;

    pSaveCfg = GetDifCfgSave(E_DIF_DIFPARA_RESALLOC);
    if(NULL == pSaveCfg)
    {
        return BSP_ERROR;
    }
    
    T_DifResourceAllocCommPara *p_dbgDifResAlloc = (T_DifResourceAllocCommPara *)(pSaveCfg->pAddr);
    if(NULL == p_dbgDifResAlloc)
    {
        return BSP_ERROR;
    }
    
    dbgInfo("DIF Resource Alloc Para:\n");
    dbgInfo("link TxFreqStart TxFreqEnd RxFreqStart RxFreqEnd\n");
    for(loopChan=startChan;loopChan<=endChan;loopChan++)
    {    
    	dbgInfo("%4d %11d %9d %11d %9d\n",loopChan,
        p_dbgDifResAlloc->uiTxFreqStart[loopChan],
        p_dbgDifResAlloc->uiTxFreqEnd[loopChan],
        p_dbgDifResAlloc->uiRxFreqStart[loopChan],
        p_dbgDifResAlloc->uiRxFreqEnd[loopChan]);
    } 
    
    return BSP_OK;
}

static UINT32 dbgShowHalCfrPara(UINT32 startChan, UINT32 endChan)
{
    UINT32 loopChan = 0;
    T_DifCfgSave* pSaveCfg = NULL;

    pSaveCfg = GetDifCfgSave(E_DIF_DIFPARA_CFR);
    if(NULL == pSaveCfg)
    {
        return BSP_ERROR;
    }
    
    T_CfrCommPara *p_dbgDifCfrPara = (T_CfrCommPara *)(pSaveCfg->pAddr);
    if(NULL == p_dbgDifCfrPara)
    {
        return BSP_ERROR;
    }
    
    dbgInfo("DIF Cfr Para:\n");
    dbgInfo("uiCfrClk is                %d:\n", p_dbgDifCfrPara->uiCfrClk);
    dbgInfo("link CfrGrade CfrSample Inter CpgPhase DelayEqualFlag CpgCoefLenHalfMax CfrBypassMode CpgLen\n");
    for(loopChan=startChan;loopChan<=endChan;loopChan++)
    {    
    	dbgInfo("%4d %8d %8d %5d %8d %14d %17d %12d %6d\n",loopChan,
        p_dbgDifCfrPara->uiCfrGrade[loopChan],
        p_dbgDifCfrPara->uiCfrSample[loopChan],
        p_dbgDifCfrPara->uiInter[loopChan],
        p_dbgDifCfrPara->uiCpgPhase[loopChan],
        p_dbgDifCfrPara->uiDelayEqualFlag[loopChan],
        p_dbgDifCfrPara->uiCpgCoefLenHalfMax[loopChan],       
        p_dbgDifCfrPara->uiCfrBypassMode[loopChan],
        p_dbgDifCfrPara->uiCpgLen[loopChan]);
    } 
    
    return BSP_OK;
}

static UINT32 dbgShowHalInitPara(UINT32 startChan, UINT32 endChan)
{
    UINT32 loopChan = 0;
    T_DifCfgSave* pSaveCfg = NULL;

    pSaveCfg = GetDifCfgSave(E_DIF_DIFPARA_INIT);
    if(NULL == pSaveCfg)
    {
        return BSP_ERROR;
    }
    
    T_DifConfigInfo *p_dbgDifInitPara = (T_DifConfigInfo *)(pSaveCfg->pAddr);
    if(NULL == p_dbgDifInitPara)
    {
        return BSP_ERROR;
    }
    
    dbgInfo("DIF Init Para:\n");
    dbgInfo("uiIqSwap is %d:\n", p_dbgDifInitPara->uiIqSwap);
    for(loopChan=0;loopChan<BSP_HALADAPT_DPDCB_CH_NUM;loopChan++)
    {
        dbgInfo("FbCutMode[%d] is %d:\n", loopChan, p_dbgDifInitPara->uiFbCutMode[loopChan]);
    }
    dbgInfo("link TrappingMode\n");
    for(loopChan=startChan;loopChan<=endChan;loopChan++)
    {    
    	dbgInfo("%4d %12d\n",loopChan,
        p_dbgDifInitPara->uiTrappingMode[loopChan]);
    } 
    
    return BSP_OK;
}

static UINT32 dbgShowHalOptSerdesPara(VOID)
{
    UINT32 loop = 0;
    T_DifCfgSave* pSaveCfg = NULL;
    UINT32 serdesId = 0;
    UINT32 laneId = 0;
    UINT32 rate = 0;
    E_LYCA_CLK_CFG clkMode;
    DOUBLE chlen = 0.0;
    UINT32 txEqEn = 0;
    INT32 eoh0 = 0;
    INT32 eoh1 = 0;
    INT32 eoh2 = 0;
    INT32 eoh3 = 0;    
    UINT32 laneNum = 0;

    pSaveCfg = GetDifCfgSave(E_OPT_SERDES_PARA);
    if(NULL == pSaveCfg)
    {
        return BSP_ERROR;
    }
    
    T_SERDES_PARAM *p_dbgOptSerdesPara = (T_SERDES_PARAM *)(pSaveCfg->pAddr);
    laneNum = pSaveCfg->difChNum;
    if(NULL == p_dbgOptSerdesPara)
    {
        return BSP_ERROR;
    }
    
    dbgInfo("Opt serdes Para:\n");
    for(loop=0;loop<laneNum;loop++)
    {
        serdesId = p_dbgOptSerdesPara[loop].serdesId;
        laneId = p_dbgOptSerdesPara[loop].laneId;
        rate = p_dbgOptSerdesPara[loop].rate;
        clkMode = p_dbgOptSerdesPara[loop].mode;
        chlen = p_dbgOptSerdesPara[loop].chlen;
        txEqEn = p_dbgOptSerdesPara[loop].txEqEn;
        eoh0 = p_dbgOptSerdesPara[loop].eoh0;
        eoh1 = p_dbgOptSerdesPara[loop].eoh1;
        eoh2 = p_dbgOptSerdesPara[loop].eoh2;
        eoh3 = p_dbgOptSerdesPara[loop].eoh3;        
        dbgInfo("serdesId[%d] laneId=%d rate=%d clkMode=%d chlen=%0.2f txEqEn=%d txEqPara[%d,%d,%d,%d]\n", 
                 serdesId, laneId, rate, clkMode, chlen, txEqEn, eoh0, eoh1, eoh2, eoh3);
    }
    
    return BSP_OK;
}

static UINT32 dbgShowHalDtxPara(VOID)
{
    UINT32 loopChan = 0;
    T_DifCfgSave* pSaveCfg = NULL;

    pSaveCfg = GetDifCfgSave(E_DIF_DIFPARA_DTX);
    if(NULL == pSaveCfg)
    {
        return BSP_ERROR;
    }
    
    T_DifDtxCheckPara *p_dbgDifDtxPara = (T_DifDtxCheckPara *)(pSaveCfg->pAddr);
    if(NULL == p_dbgDifDtxPara)
    {
        return BSP_ERROR;
    }    
    dbgInfo("DIF DTX Para:\n");
    dbgInfo("uiSymHead is      %d:\n", p_dbgDifDtxPara->uiSymHead);
    dbgInfo("uiHoldTime is     %d:\n", p_dbgDifDtxPara->uiHoldTime);
    dbgInfo("uiSymPowThr is    %d:\n", p_dbgDifDtxPara->uiSymPowThr);
    dbgInfo("uiSymPowWay is    %d:\n", p_dbgDifDtxPara->uiSymPowWay);
    dbgInfo("uiDtxGenSel is    %d:\n", p_dbgDifDtxPara->uiDtxGenSel);
    dbgInfo("uiPeakThrTimes is %d:\n", p_dbgDifDtxPara->uiPeakThrTimes);
    dbgInfo("uiGpLen is        %d:\n", p_dbgDifDtxPara->uiGpLen);
    
    return BSP_OK;
}

static UINT32 dbgShowHalDifPwrSaveGateEnPara(VOID)
{
    T_DifCfgSave* pSaveCfg = NULL;

    pSaveCfg = GetDifCfgSave(E_DIF_DIFPARA_GATE);
    
    T_BspHalAdaptDifPwrSaveGateCfg *p_dbgDifGatePara = (T_BspHalAdaptDifPwrSaveGateCfg *)(pSaveCfg->pAddr);
    if(NULL == p_dbgDifGatePara)
    {
        return BSP_ERROR;
    }    
    dbgInfo("DIF PWRSAVE GATE Para:\n");
    dbgInfo("freOffsetGateEn is      %d:\n", p_dbgDifGatePara->gateCfg.freOffsetGateEn);
    dbgInfo("symPowChkGateEn is      %d:\n", p_dbgDifGatePara->gateCfg.symPowChkGateEn);
    dbgInfo("highFreqPowGateEn is    %d:\n", p_dbgDifGatePara->gateCfg.highFreqPowGateEn);
    dbgInfo("txTddEn is              %d:\n", p_dbgDifGatePara->txTddEn);
    dbgInfo("rxTddEn is              %d:\n", p_dbgDifGatePara->rxTddEn);
    dbgInfo("txUnusedGateEn is       %d:\n", p_dbgDifGatePara->txUnusedGateEn);
    dbgInfo("rxUnusedGateEn is       %d:\n", p_dbgDifGatePara->rxUnusedGateEn);
 
    return BSP_OK;
}



extern UINT32 s_optSserdesInitStatus[E_OPT_SERDES_INIT_MAX][OPT_SERDES_LANE_MAX_NUM];

static UINT32 dbgShowSerdesInitStat(VOID)
{
    UINT32 loop = 0;
    UINT32 lane = 0;
    
    dbgInfo("Opt serdes Init Status:\n");
    for(loop=0;loop<OPT_SERDES_LANE_MAX_NUM;loop++)
    {
        dbgInfo("lane[%1d] PREPCS[%4s] PCS[%4s] LOADFW[%4s] TXINI[%4s] TXEQ[%4s] RXINI[%4s] TCCSW[%4s] APP:RXINI[%4x %4s] TCCSW[%4x %4s]\n", loop, 
            RESULT_TO_STR(s_optSserdesInitStatus[E_OPT_SERDES_PREPCS][loop]),
            RESULT_TO_STR(s_optSserdesInitStatus[E_OPT_SERDES_PCS][loop]),
            RESULT_TO_STR(s_optSserdesInitStatus[E_OPT_SERDES_LOADFW][loop]),
            RESULT_TO_STR(s_optSserdesInitStatus[E_OPT_SERDES_TXINIT][loop]),
            RESULT_TO_STR(s_optSserdesInitStatus[E_OPT_SERDES_TXEQ][loop]),
            RESULT_TO_STR(s_optSserdesInitStatus[E_OPT_SERDES_RXINIT][loop]),
            RESULT_TO_STR(s_optSserdesInitStatus[E_OPT_SERDES_NORMAL][loop]),
            s_optSserdesInitStatus[E_OPT_SERDES_APPRXINIT][loop]>>16,
            RESULT_TO_STR(s_optSserdesInitStatus[E_OPT_SERDES_APPRXINIT][loop]&0x0000ffff),
            s_optSserdesInitStatus[E_OPT_SERDES_APPNORMAL][loop]>>16,
            RESULT_TO_STR(s_optSserdesInitStatus[E_OPT_SERDES_APPNORMAL][loop]&0x0000ffff));
    }
    
    return BSP_OK;
}

static UINT32 dbgShowHalPaptPara(VOID)
{
    UINT32 loop = 0;
    T_DifCfgSave* pSaveCfg = NULL;

    pSaveCfg = GetDifCfgSave(E_DIF_DIFPARA_PAPT);
    if(NULL == pSaveCfg)
    {
        return BSP_ERROR;
    }
    
    PAPT_PARA_CFG *p_dbgDifPaptPara = (PAPT_PARA_CFG *)(pSaveCfg->pAddr);
    if(NULL == p_dbgDifPaptPara)
    {
        return BSP_ERROR;
    }    
    dbgInfo("DIF PAPT Para:\n");
    
    dbgInfo("1.PAPT_HPF_CFG:\n");
    dbgInfo("HpfCoef: ");
    for(loop=0;loop<9;loop++)
    {
        dbgInfo("%d, ", *(p_dbgDifPaptPara->paptHpf.pHpfCoef+loop));
    }
    dbgInfo("\n");
    dbgInfo("hpfPowThr:  %d\n", p_dbgDifPaptPara->paptHpf.hpfPowThr);
    dbgInfo("hpfWinLen:  %d\n", p_dbgDifPaptPara->paptHpf.hpfWinLen);
    dbgInfo("hpfOverNum: %d\n", p_dbgDifPaptPara->paptHpf.hpfOverNum);

    dbgInfo("\n2.PAPT_RAMP_CFG:\n");
    dbgInfo("spThr:      %d\n", p_dbgDifPaptPara->paptRamp.spThr);
    dbgInfo("rampMod:    %d\n", p_dbgDifPaptPara->paptRamp.rampMod);
    dbgInfo("daOff:      %d\n", p_dbgDifPaptPara->paptRamp.daOff);
    dbgInfo("daDly:      %d\n", p_dbgDifPaptPara->paptRamp.daDly);
    dbgInfo("rampOnStp:  %d\n", p_dbgDifPaptPara->paptRamp.rampOnStp);
    dbgInfo("rampOffStp: %d\n", p_dbgDifPaptPara->paptRamp.rampOffStp);

    dbgInfo("\n3.PAPT_UNUS_CFG:\n");
    dbgInfo("paOffDly0:  %d\n", p_dbgDifPaptPara->paptUnus.paOffDly0);
    dbgInfo("paOffDly1:  %d\n", p_dbgDifPaptPara->paptUnus.paOffDly1);
    dbgInfo("paOffMask:  %#x\n", p_dbgDifPaptPara->paptUnus.paOffMask);
    dbgInfo("daOffDly0:  %d\n", p_dbgDifPaptPara->paptUnus.daOffDly0);
    dbgInfo("daOffDly1:  %d\n", p_dbgDifPaptPara->paptUnus.daOffDly1);
    dbgInfo("daOffMask:  %#x\n", p_dbgDifPaptPara->paptUnus.daOffMask);
    dbgInfo("dpdDly:     %d\n", p_dbgDifPaptPara->paptUnus.dpdDly);
    dbgInfo("dpdMask:    %#x\n", p_dbgDifPaptPara->paptUnus.dpdMask);

    dbgInfo("\n4.PAPT_DPD_CFG:\n");
    dbgInfo("avgPowNum:  %d\n", p_dbgDifPaptPara->paptDpd.avgPowNum);
    dbgInfo("avgPowThr:  %d\n", p_dbgDifPaptPara->paptDpd.avgPowThr);
    dbgInfo("avgPowMod:  %d\n", p_dbgDifPaptPara->paptDpd.avgPowMod);
    dbgInfo("AvgIIRCoef: %d\n", p_dbgDifPaptPara->paptDpd.AvgIIRCoef);

    dbgInfo("\n5.PAPT_CFR_CFG:\n");
    dbgInfo("avgPowNumL:  %d\n", p_dbgDifPaptPara->paptCfr.avgPowNumL);
    dbgInfo("avgPowThrL:  %d\n", p_dbgDifPaptPara->paptCfr.avgPowThrL);
    dbgInfo("avgPowNumS:  %d\n", p_dbgDifPaptPara->paptCfr.avgPowNumS);
    dbgInfo("avgPowThrS:  %d\n", p_dbgDifPaptPara->paptCfr.avgPowThrS);
    dbgInfo("avgPowMod:   %d\n", p_dbgDifPaptPara->paptCfr.avgPowMod);
    dbgInfo("AvgIIRCoef:  %d\n", p_dbgDifPaptPara->paptCfr.AvgIIRCoef);
    dbgInfo("cfrTddBypss: %d\n", p_dbgDifPaptPara->paptCfr.cfrTddBypss);

    dbgInfo("\n5.PAPT_ET_TDD_CFG:\n");
    dbgInfo("etMode:    %d\n", p_dbgDifPaptPara->paptEtTdd.etMode);
    dbgInfo("etMark:    %d\n", p_dbgDifPaptPara->paptEtTdd.etMark);
    dbgInfo("tddBypass: %d\n", p_dbgDifPaptPara->paptEtTdd.tddBypass);
    dbgInfo("tddDly:    %d\n", p_dbgDifPaptPara->paptEtTdd.tddDly);

    dbgInfo("\n6.PAPT_TRANS_CFG:\n");
    dbgInfo("inverse: [");
    for(loop=0;loop<PAPT_TRANS_UNUS_GRP_NUM;loop++)
    {
        dbgInfo("%d, ", p_dbgDifPaptPara->paptTrans.inverse[loop]);
    }
    dbgInfo("]\n");
    dbgInfo("lock: [");
    for(loop=0;loop<PAPT_TRANS_UNUS_GRP_NUM;loop++)
    {
        dbgInfo("%d, ", p_dbgDifPaptPara->paptTrans.lock[loop]);
    }
    dbgInfo("]\n");
    dbgInfo("unusRouter:   %d, ", p_dbgDifPaptPara->paptTrans.unusRouter);

    dbgInfo("\n7.PAPT_ROUTER_CFG:\n");
    dbgInfo("paptRouter:   %d, ", p_dbgDifPaptPara->paptRouter);

    dbgInfo("\n8.PAPT_TRANS_CFG:\n");
    dbgInfo("byPass:  [");
    for(loop=0;loop<DL_BANK_NUM_IN_ANT_BLOCK;loop++)
    {
        dbgInfo("%d, ", p_dbgDifPaptPara->paptRcf.byPass[loop]);
    }
    dbgInfo("]\n");
    dbgInfo("overNum: [");
    for(loop=0;loop<DL_BANK_NUM_IN_ANT_BLOCK;loop++)
    {
        dbgInfo("%d, ", p_dbgDifPaptPara->paptRcf.overNum[loop]);
    }
    dbgInfo("]\n");
    dbgInfo("overThr: [");
    for(loop=0;loop<DL_BANK_NUM_IN_ANT_BLOCK;loop++)
    {
        dbgInfo("%d, ", p_dbgDifPaptPara->paptRcf.overThr[loop]);
    }
    dbgInfo("]\n");
    dbgInfo("overWin: [");
    for(loop=0;loop<DL_BANK_NUM_IN_ANT_BLOCK;loop++)
    {
        dbgInfo("%d, ", p_dbgDifPaptPara->paptRcf.overWin[loop]);
    }
    dbgInfo("]\n");
    dbgInfo("overSleepNum: [");
    for(loop=0;loop<DL_BANK_NUM_IN_ANT_BLOCK;loop++)
    {
        dbgInfo("%d, ", p_dbgDifPaptPara->paptRcf.overSleepNum[loop]);
    }
    dbgInfo("]\n");
    
    dbgInfo("\n9.PAPT_CRM_MASK:\n");
    dbgInfo("Pa dlpost0: %#x\n", p_dbgDifPaptPara->crmMask.PaOffMask0);
    dbgInfo("Pa dlpost1: %#x\n", p_dbgDifPaptPara->crmMask.PaOffMask1);
    dbgInfo("Da dlpost0: %#x\n", p_dbgDifPaptPara->crmMask.DaOffMask0);
    dbgInfo("Da dlpost1: %#x\n", p_dbgDifPaptPara->crmMask.DaOffMask1);

    return BSP_OK;
}

VOID dbgSetCrmSocDspClk(UINT32 clk)
{        
    T_BspHalAdaptSocCrmClk socClk = {0};
    socClk.dspClk = clk;
    BspHalAdaptSetCrmSocClk(&socClk);
    return;    
}

static UINT32 dbgShowHalOptRoeCwCfg(VOID)
{
    UINT32 loop = 0;
    T_DifCfgSave* pSaveCfg = NULL;
    UINT32 chnNum = 0;
    UINT32 idx = 0;
    UINT32 chnNo = 0;
    UINT32 chnDir = 0;
    UINT32 chnTpe = 0;
    UINT32 chnExtLp = 0;
    UINT32 chnInnPp = 0;
    UINT32 chnUdpPort = 0;
    UINT32 chnFlowId = 0;
    UINT32 chnVaild = 0;

    pSaveCfg = GetDifCfgSave(E_OPT_ROECW_CFG);
    
    T_NtlCwChnCfg *p_dbgOptRoeCwChn = (T_NtlCwChnCfg *)(pSaveCfg->pAddr);
    chnNum = pSaveCfg->difChNum;
    if(NULL == p_dbgOptRoeCwChn)
    {
        return BSP_ERROR;
    }
    
    dbgInfo("Opt Roe Cw Chan Info:\n");
    dbgInfo("idx chnNo chnDir chnTpe chnExtLp chnInnPp chnUdpPort chnFlowId chnVaild\n");
    for(loop=0;loop<chnNum;loop++)
    {
        idx = p_dbgOptRoeCwChn[loop].idx;
        chnNo = p_dbgOptRoeCwChn[loop].chnNo;
        chnDir = p_dbgOptRoeCwChn[loop].chnDir;
        chnTpe = p_dbgOptRoeCwChn[loop].chnTpe;
        chnExtLp = p_dbgOptRoeCwChn[loop].chnExtLp;
        chnInnPp = p_dbgOptRoeCwChn[loop].chnInnPp;
        chnUdpPort = p_dbgOptRoeCwChn[loop].chnUdpPort;
        chnFlowId = p_dbgOptRoeCwChn[loop].chnFlowId;
        chnVaild = p_dbgOptRoeCwChn[loop].chnVaild;
        dbgInfo("%3d %5d %6d %6d %8d %8d %10d %9d %8d\n",idx,chnNo,chnDir,chnTpe,chnExtLp,chnInnPp,chnUdpPort,chnFlowId,chnVaild);
    }
    
    return BSP_OK;
}
#endif

static UINT32 dbgShowHalDifCrmClkPara(VOID)
{
    T_DifCfgSave* pSaveCfg = NULL;

    pSaveCfg = GetDifCfgSave(E_DIF_CRMCLK_PARA);
    if(NULL == pSaveCfg)
    {
        return BSP_ERROR;
    }
    
    T_BspHalAdaptDifCrmClk *pPara = (T_BspHalAdaptDifCrmClk *)(pSaveCfg->pAddr);
    if(NULL == pPara)
    {
        return BSP_ERROR;
    }
    
    dbgInfo("DIF Crm Clk Para:\n");
    dbgInfo("clk_ul_logic1_0 is      %d:\n", pPara->clk_ul_logic1_0);
    dbgInfo("clk_ul_logic1_1 is      %d:\n", pPara->clk_ul_logic1_1);
    dbgInfo("clk_dl_logic2 is        %d:\n", pPara->clk_dl_logic2);
    dbgInfo("clk_dl_logic3_0 is      %d:\n", pPara->clk_dl_logic3_0);
    dbgInfo("clk_dl_logic3_1 is      %d:\n", pPara->clk_dl_logic3_1);
    dbgInfo("clk_fb_logic1_0 is      %d:\n", pPara->clk_fb_logic1_0);
    dbgInfo("clk_fb_logic1_1 is      %d:\n", pPara->clk_fb_logic1_1);
    dbgInfo("clk_dl_j204_work_0 is   %d:\n", pPara->clk_dl_j204_work_0);
    dbgInfo("clk_dl_j204_work_1 is   %d:\n", pPara->clk_dl_j204_work_1);
    dbgInfo("clk_fb_j204_work is     %d:\n", pPara->clk_fb_j204_work);
    dbgInfo("clk_ul_j204_work is     %d:\n", pPara->clk_ul_j204_work);
    
    return BSP_OK;
}

static UINT32 dbgShowHalDifCrmClkSel(VOID)
{
    T_DifCfgSave* pSaveCfg = NULL;

    pSaveCfg = GetDifCfgSave(E_DIF_CRMCLK_SEL);
    if(NULL == pSaveCfg)
    {
        return BSP_ERROR;
    }
    
    T_BspHalAdaptDifCrmClkSelect *pPara = (T_BspHalAdaptDifCrmClkSelect *)(pSaveCfg->pAddr);
    if(NULL == pPara)
    {
        return BSP_ERROR;
    }
    
    dbgInfo("DIF Crm Clk Select:\n");
    dbgInfo("mux_clk_ulch_0 is              %d:\n", pPara->mux_clk_ulch_0);
    dbgInfo("mux_clk_ulch_1 is              %d:\n", pPara->mux_clk_ulch_1);
    dbgInfo("mux_clk_dlpost_0 is            %d:\n", pPara->mux_clk_dlpost_0);
    dbgInfo("mux_clk_dlpost_1 is            %d:\n", pPara->mux_clk_dlpost_1);
    dbgInfo("mux_clk_dl_logic6 is           %d:\n", pPara->mux_clk_dl_logic6);
    dbgInfo("mux_clk_fb0 is                 %d:\n", pPara->mux_clk_fb0);
    dbgInfo("mux_clk_fb1 is                 %d:\n", pPara->mux_clk_fb1);
    dbgInfo("mux_clk_cblms is               %d:\n", pPara->mux_clk_cblms);
    dbgInfo("mux_clk_j204_fb_logic2_0 is    %d:\n", pPara->mux_clk_j204_fb_logic2_0);
    dbgInfo("mux_clk_j204_fb_logic2_1 is    %d:\n", pPara->mux_clk_j204_fb_logic2_1);
    dbgInfo("mux_clk_j204_dl_logic5_0 is    %d:\n", pPara->mux_clk_j204_dl_logic5_0);
    dbgInfo("mux_clk_j204_dl_logic5_1 is    %d:\n", pPara->mux_clk_j204_dl_logic5_1);
    dbgInfo("mux_clk_j204_sysref is         %d:\n", pPara->mux_clk_j204_sysref);
    dbgInfo("mux_clk_j204_fb_logic3_0 is    %d:\n", pPara->mux_clk_j204_fb_logic3_0);
    dbgInfo("mux_clk_j204_fb_logic3_1 is    %d:\n", pPara->mux_clk_j204_fb_logic3_1);
    dbgInfo("mux_clk_j204_dl_logic4_0 is    %d:\n", pPara->mux_clk_j204_dl_logic4_0);
    dbgInfo("mux_clk_j204_dl_logic4_1 is    %d:\n", pPara->mux_clk_j204_dl_logic4_1);
    dbgInfo("mux_clk_j204_ul_logic2_0 is    %d:\n", pPara->mux_clk_j204_ul_logic2_0);
    dbgInfo("mux_clk_j204_ul_logic2_1 is    %d:\n", pPara->mux_clk_j204_ul_logic2_1);

    return BSP_OK;
}

UINT32 dbgShowPwrSaveSel(UINT32 pwrsaveType)
{
    T_DifCfgSave* pSaveCfg = NULL;

    if(0 == pwrsaveType)
    {
        pSaveCfg = GetDifCfgSave(E_IC_PWRSAVE_NORMAL_SEL);
    }
    else if(1 == pwrsaveType)
    {
        pSaveCfg = GetDifCfgSave(E_IC_PWRSAVE_DEEPSLEEP_SEL);
    }
    else if(2 == pwrsaveType)
    {
        pSaveCfg = GetDifCfgSave(E_IC_PWRSAVE_ALLCARROFF_SEL);
    }
    else if(3 == pwrsaveType)
    {
        pSaveCfg = GetDifCfgSave(E_IC_PWRSAVE_QCELL_PB_SEL);
    }
    else if(4 == pwrsaveType)
    {
        pSaveCfg = GetDifCfgSave(E_IC_PWRSAVE_QCELL_BBU_SEL);
    }
    else 
    {
        return BSP_ERROR;
    }

    if(NULL == pSaveCfg)
    {
        return BSP_ERROR;
    }
    
    T_DpdicPwrSaveSel *pPara = (T_DpdicPwrSaveSel *)(pSaveCfg->pAddr);
    if(NULL == pPara)
    {
        return BSP_ERROR;
    }
    
    dbgInfo("DPDIC PwrSave Select:\n");
    dbgInfo("difTxUnusedResSel is              %d\n", pPara->difTxUnusedResSel);
    dbgInfo("difRxUnusedResSel is              %d\n", pPara->difRxUnusedResSel);
    dbgInfo("a53CoreMask is                    %#x\n", pPara->a53CoreMask);
    dbgInfo("optDifIf0CompMask is              %#x\n", pPara->optDifIf0CompMask);
    dbgInfo("optDifIf1CompMask is              %#x\n", pPara->optDifIf1CompMask);
    dbgInfo("optDifAximMask is                 %#x\n", pPara->optDifAximMask);
    dbgInfo("optGfOranMask is                  %#x\n", pPara->optGfOranMask);
    dbgInfo("optGfBdrMask is                   %#x\n", pPara->optGfBdrMask);
    dbgInfo("optGfChMask is                    %#x\n", pPara->optGfChMask);
    dbgInfo("optBifOranMask is                 %#x\n", pPara->optBifOranMask);
    dbgInfo("optBifChMask is                   %#x\n", pPara->optBifChMask);
    dbgInfo("optSw1OptSw1Sel is                %d\n", pPara->optSw1OptSw1Sel);
    dbgInfo("optSw1MapSel is                   %d\n", pPara->optSw1MapSel);
    dbgInfo("optCpriFrmMask is                 %#x\n", pPara->optCpriFrmMask);
    dbgInfo("optCpriSerdesMAsk is              %#x\n", pPara->optCpriSerdesMask);
    dbgInfo("optPrach01Sel is                  %d\n", pPara->optPrach01Sel);
    dbgInfo("optPrach00Sel is                  %d\n", pPara->optPrach00Sel);
    dbgInfo("optFft1Sel is                     %d\n", pPara->optFft1Sel);
    dbgInfo("optFft0Sel is                     %d\n", pPara->optFft0Sel);
    dbgInfo("optRoeIq0Sel is                   %d\n", pPara->optRoeIq0Sel);
    dbgInfo("optRoeIq1Sel is                   %d\n", pPara->optRoeIq1Sel);
    dbgInfo("optRoeIq2Sel is                   %d\n", pPara->optRoeIq2Sel);
    dbgInfo("optRoeIq3Sel is                   %d\n", pPara->optRoeIq3Sel);
    dbgInfo("optRoeNtlCtrlSel is               %d\n", pPara->optRoeNtlCtrlSel);
    
    dbgInfo("difAllSel is                      %d\n", pPara->difAllSel);
    dbgInfo("j204DlLaneMask is                 %#x\n", pPara->j204DlLaneMask);
    dbgInfo("j204FbLaneMask is                 %#x\n", pPara->j204FbLaneMask);
    dbgInfo("j204UlLaneMask is                 %#x\n", pPara->j204UlLaneMask);
    dbgInfo("j204DlMapMask is                  %#x\n", pPara->j204DlMapMask);
    dbgInfo("j204FbMapMask is                  %#x\n", pPara->j204FbMapMask);
    dbgInfo("j204UlMapMask is                  %#x\n", pPara->j204UlMapMask);

    return BSP_OK;
}

#define ICHAL_HELP_LEN (200)

UINT8 g_icHalHelpPrint[][ICHAL_HELP_LEN] =
{
    "###Funclib->Hal###",
    "ichaladaptptnall",    
//    "dbgShowHalDifPara(UINT32 startChan, UINT32 endChan)",
    "dbgShowHalDifCarrInfo(UINT32 dir, UINT32 difChan)",
    "dbgShowHalTxRouteMap(UINT32 startChan, UINT32 endChan)",
    "dbgShowHalDifCrmClkPara",    
    "dbgShowHalDifCrmClkSel",
    "dbgShowHalTxRoutePara(UINT32 startChan, UINT32 endChan)",
    "dbgShowHalTx204Route(UINT32 startChan, UINT32 endChan)",
    "dbgShowHalRxRouteMap(UINT32 startChan, UINT32 endChan)",
    "dbgShowHalFbRouteMap(UINT32 startChan, UINT32 endChan)",
    "dbgShowHalSamratePara(UINT32 startChan, UINT32 endChan)",
    "dbgShowHalClkPara(VOID)",
    "dbgShowPwrSaveSel pwrsaveType 0:normal,1:deepsleep,2:allcarroff",
//    "dbgShowHalResAllocPara(UINT32 startChan, UINT32 endChan)",
//    "dbgShowHalCfrPara(UINT32 startChan, UINT32 endChan)",
//    "dbgShowHalInitPara(UINT32 startChan, UINT32 endChan)",
//    "dbgShowHalDtxPara",
//    "dbgShowHalPaptPara",
//    "dbgShowHalDifPwrSaveGateEnPara",
//    "dbgShowHalOptSerdesPara",
//    "dbgShowSerdesInitStat",
//    "dbgShowHalOptRoeCwCfg",
//    "s_IcTrxPinMap",
//    "dbgSetCrmSocDspClk",
//    "HalGetAlignAddrDif"
};

VOID ichaladaptptnall(VOID)
{
    UINT32 txChnNum = BspGetTxChanNum()-1;
    UINT32 rxChnNum = BspGetRxChanNum()-1;

    dbgInfo("\n=========================================================\n");
    dbgShowHalTxRouteMap(0, txChnNum);
    dbgInfo("\n=========================================================\n");
    dbgShowHalTxRoutePara(0, txChnNum);
    dbgInfo("\n=========================================================\n");
    dbgShowHalTx204Route(0, txChnNum);    
    dbgInfo("\n=========================================================\n");
    dbgShowHalRxRouteMap(0, rxChnNum);
    dbgInfo("\n=========================================================\n");
    dbgShowHalFbRouteMap(0, txChnNum);
    dbgInfo("\n=========================================================\n");
    dbgShowHalSamratePara(0, txChnNum);
    dbgInfo("\n=========================================================\n");
    dbgShowHalClkPara();
    dbgInfo("\n=========================================================\n");

    return;
}

UINT32 ichaladapthelp(VOID)
{
    UINT32 udPrintCnt = 0;
    UINT32 udCnt = 0;

    dbgInfo("IchalAdapt Help:\n");

    udPrintCnt = sizeof(g_icHalHelpPrint) / ICHAL_HELP_LEN;
    for(udCnt = 0; udCnt < udPrintCnt; udCnt++)
    {
        dbgInfo(" %s \n", g_icHalHelpPrint[udCnt]);
    }

    return (UINT32)BSP_OK;
}




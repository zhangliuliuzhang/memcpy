#include "opt_tsg.h"
#include "ichaladapt_opttsg_ic4_2.h"
#include "bsppub.h"
#include "cellcfgapi.h"

UINT32 BspHalAdaptL2dCheckTest(void)
{
    UINT32 ret = BSP_OK;
    ret = IcHalApiL2dCheckTest();
    return ret;  
}

UINT32 BspHalAdaptOptTsgSwitch(UINT32 antChan, UINT32 carrNo, UINT32 radioMode, UINT32 tsgType, UINT32 sw)
{
    UINT32 ret = BSP_OK;
    ret = IcHalApiOptTsgSwitch( antChan,  carrNo,  radioMode,  tsgType, sw);
    return ret;
}

UINT32 BspHalAdaptOptDifTsgSwitch(UINT32 antChan, UINT32 carrNo, UINT32 radioMode, UINT32 tsgType, char *fileName,UINT32 sw)
{
    UINT32 ret = BSP_OK;
    ret = IcHalApiOptDifTsgSwitch( antChan,  carrNo,  radioMode,  tsgType,fileName, sw);
    return ret;
}

UINT32 BspHalAdaptQcellTsg(UINT32 uCarrNo, UINT32 uRadioMode, UINT32 uSwitch, UINT32 uSrcMode, char *fileName)
{
    UINT32 ret = BSP_OK;
    ret = IcHalApiQcellTsg(uCarrNo, uRadioMode, uSwitch, uSrcMode, fileName);
    return ret;   
}

UINT32 BspHalAdaptSetQcellTsgCarrAntChan(UINT32 srcAntChan, UINT32 dstAntChan)
{
    UINT32 ret = BSP_OK;
    ret = IcHalSetQcellTsgCarrAntChan(srcAntChan, dstAntChan);
    return ret;   
}
/* Started by AICoder, pid:n2429ie7ddpcac814dd6081f30c04000f3d41641 */
UINT32 BspHalAdaptSetGfTsgSwitch(UINT32 antChan, UINT32 carrNo, UINT32 radioMode, UINT32 switchEn, CHAR *fileName)
{
    UINT32 ret = BSP_OK;

    INPUT_POINTER_CHECK(fileName);
    ret = IcHalApiSetGfTsgSwitch(antChan, carrNo, radioMode, switchEn, fileName);
    return ret;
}
/* Ended by AICoder, pid:n2429ie7ddpcac814dd6081f30c04000f3d41641 */
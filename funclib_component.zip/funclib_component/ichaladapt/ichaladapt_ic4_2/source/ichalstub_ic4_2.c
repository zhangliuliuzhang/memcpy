/*****************************************************************************
* 版权所有(C) 2020, ZTE Corp. ZXSDR-RRU Platform BSP
*----------------------------------------------------------------------------
* 模 块 名 : bsp
* 文件名称 : ichalstub.c
* 文件标识 : {[N/A]}
* 内容摘要 : 本文件提供了ICHAL适配层接口函数实现
* 注意事项 : 无
* 作    者 : 王涛10248577
* 创建日期 : 2020-11-04
* 当前版本 : Ver1.0
*----------------------------------------------------------------------------
* 变更记录 :
*
* $记录1
* 变 更 单: $0000000(N/A)
* 责 任 人: 王涛10248577
* 修改日戳: 2020-11-04
* 变更说明: 创建文件
*----------------------------------------------------------------------------
*/

#include "ichalstub_ic4_2.h"
#include "hal_comm.h"

//opt hal header
#include "ichal_opt_api.h"
#include "icopthalcomm.h"
//dif hal
#include "init_fun_api.h"

#include "resource_alloc_api.h"


//有疑问的


#include "rx_gunb_cfg.h"
/**************************************************************************
                            单板初始化相关接口打桩
**************************************************************************/
//UINT32 IcHalApiDifTxRouteInit(T_DifTxRouteMap *ptTxRouteMap, UINT32 uiLinkNum, UINT32 uiDifNum) {return BSP_OK;}
//UINT32 IcHalApiDifTx204RouteInit(T_DifTx204RouteMap *ptTx204RouteMap, UINT32 uiLinkNum, UINT32 uiDifNum) {return BSP_OK;}
//UINT32 IcHalApiDifTxRouteParaInit(T_DifTxRoutePara *ptTxRoutePara, UINT32 uiLinkNum, UINT32 uiDifNum) {return BSP_OK;}
//UINT32 IcHalApiDifRxRouteInit(T_DifRxRouteMap *ptRxRouteMap, UINT32 uiLinkNum, UINT32 uiDifNum){return BSP_OK;}
//UINT32 IcHalApiDifInit(VOID) {return BSP_OK;}                                  /** 中频无参初始化接口 */
//UINT32 IcHalApiDifParaInit(T_DifConfigInfo *ptConfigPara) {return BSP_OK;} /** 中频有参初始化接口 */
//UINT32 IcHalApiDifSamRateParaInit(T_DifSamRateCommPara *ptDifSamRatePara){return BSP_OK;}                   /** 中频采样率公共参数初始化接口 */
//UINT32 IcHalApiDifClkParaInit(T_DifClkCommPara *ptDifClkPara){return BSP_OK;}                               /** 中频时钟公共参数初始化接口 */
//UINT32 IcHalApiDifResourceAllocParaInit(T_DifResourceAllocCommPara *ptDifResourceAllocPara){return BSP_OK;} /** 中频资源分配公共参数初始化接口 */
//UINT32 IcHalApiSetDifFrInit(T_DifFrInitCfg *pDifFrInitCfg){return BSP_OK;}

/**************************************************************************
          pad相关接口打桩
**************************************************************************/
//UINT32 IcHalApiSetPadSt(UINT32 halPadName, UINT32 value){return BSP_OK;}
//UINT32 IcHalApiSetPadSl(UINT32 halPadName, UINT32 value){return BSP_OK;}
//UINT32 IcHalApiSetPadPull(UINT32 halPadName, UINT32 value){return BSP_OK;}
//UINT32 IcHalApiSetPadDs(UINT32 halPadName, UINT32 value){return BSP_OK;}
//UINT32 IcHalApiSetPadCfgDone(UINT32 halPadName, UINT32 value){return BSP_OK;}
//UINT32 IcHalApiSetPadFuncSel(UINT32 halPadName, UINT32 value){return BSP_OK;}
//
//UINT32 IcHalApiSetLvdsFrameHead(UINT32 halPadName, UINT32 value){return BSP_OK;}
//UINT32 IcHalApiSetLvdsFuncSel(UINT32 halPadName, UINT32 value){return BSP_OK;}
//
//UINT32 IcHalApiSetPadReg(UINT32 halPadName, UINT32 value){return BSP_OK;}
//UINT32 IcHalApiGetPadReg(UINT32 halPadName, UINT32 *value){return BSP_OK;}
//
//UINT32 IcHalApiSetLvdsCfg(UINT32 halPadName, UINT32 value){return BSP_OK;}
//UINT32 IcHalApiGetLvdsCfgVal(UINT32 halPadName, UINT32  *value){return BSP_OK;}
//UINT32 IcHalApiSetLvdsPad(UINT32 halPadName, UINT32 value){return BSP_OK;}
//UINT32 IcHalApiGetLvdsPadVal(UINT32 halPadName, UINT32 * value){return BSP_OK;}
/**************************************************************************
                            配频相关接口打桩
**************************************************************************/
//UINT32 IcHalApiSetTxCarrNco(UINT32 uiDifChan, UINT32 uiCarrId, UINT32 uiRadioMode, INT32 iOffset){return BSP_OK;}
//UINT32 IcHalApiSetRxCarrNco(UINT32 uiDifChan, UINT32 uiCarrId, UINT32 uiRadioMode, INT32 iOffset){return BSP_OK;}
/*IC4.2不支持频段NCO，暂时打桩*/
UINT32 IcHalApiSetTxFreqNco2(UINT32 uiDifChan, UINT32 bandNo, INT32 iOffset){return BSP_OK;}
UINT32 IcHalApiSetRxFreqNco2(UINT32 uiDifChan, UINT32 bandNo, INT32 iOffset){return BSP_OK;}
//UINT32 IcHalApiTxResourceAlloc(T_DifChanInfo *ptTxChanInfo){return BSP_OK;}
//UINT32 IcHalApiRxResourceAllocDdc0(T_DifChanInfo *ptRxChanInfo){return BSP_OK;}
//UINT32 IcHalApiTxResourceAllocDuc0(T_DifChanInfo *ptTxChanInfo){return BSP_OK;}
//UINT32 IcHalApiRxResourceAlloc(T_DifChanInfo *ptTxChanInfo){return BSP_OK;}

UINT32 IcHalApiGetTxDifBandFreq(UINT32 difChan, UINT32 *bandNum, UINT32 *bandFreq) {return BSP_OK;}
UINT32 IcHalApiGetRxDifBandFreq(UINT32 difChan, UINT32 *bandNum, UINT32 *bandFreq) {return BSP_OK;}
UINT32 IcHalApiGetTxDifCarrBandNo(UINT32 difChan, UINT32 radioMode, UINT32 difCarrNo, UINT32 *bandNo) {return BSP_OK;}
UINT32 IcHalApiGetRxDifCarrBandNo(UINT32 difChan, UINT32 radioMode, UINT32 difCarrNo, UINT32 *bandNo) {return BSP_OK;}
UINT32 IcHalApiGetTxFreqNco2Step(UINT32 difChan, UINT32 *step) {return BSP_OK;}
UINT32 IcHalApiGetRxFreqNco2Step(UINT32 difChan, UINT32 *step) {return BSP_OK;}

#if 0
UINT32 IcHalApiTxResourceAllocClr(){return BSP_OK;}
UINT32 IcHalApiTxResourceAllocCfg(){return BSP_OK;}
UINT32 IcHalApiRxResourceAllocCfg(){return BSP_OK;}
UINT32 IcHalApiRxResourceAllocClr(){return BSP_OK;}
UINT32 IcHalApiTxResourceAllocRpt(T_DifChanInfo *ptTxChanInfo){return BSP_OK;}
UINT32 IcHalApiRxResourceAllocRpt(T_DifChanInfo *ptRxChanInfo){return BSP_OK;}
#endif

/* 功率模块使能，暂时打桩  */
//void powsw(UINT32 index, UINT32 powsw){return BSP_OK;}
/**************************************************************************
                            时延相关接口打桩
**************************************************************************/
//UINT32 IcHalApiSetFrameAlignment(UINT32 bandId, UINT32 radioMode, INT32 frameDelay) {return BSP_OK;}
//UINT32 IcHalApiSetFrameAlignment_FDD(UINT32 bspChan, UINT32 carrNo, UINT32 radioMode, INT32 frameDelay) {return BSP_OK;}
//UINT32 IcHalApiUpdateDifChanDelay(UINT32 difChan){return BSP_OK;}
//UINT32 IcHalApiUpdateDifCarrDelay(UINT32 difChan,UINT32 radioMod,UINT32 difCarrNo){return BSP_OK;}
//UINT32 IcHalApiSetUl204AndRfDly(UINT32 *dlDly, UINT32 num){return BSP_OK;}
//UINT32 IcHalApiSetUl204AndRfDly(UINT32 *ulDly, UINT32 num){return BSP_OK;}
//UINT32 IcHalApiSetUeAdvVal(UINT32 uMode, UINT32 uVal){return BSP_OK;}
//UINT32 IcHalApiGetMainLogOpt(UINT32 *mainOpt){return BSP_OK;}
//UINT32 IcHalApiSetT12Val(UINT32 uFwdOrRvs, UINT32 uT12Val); {return BSP_OK;}
//UINT32 IcHalApiSetT34Val(UINT32 uFwdOrRvs, UINT32 uT34Val);;{return BSP_OK;}
UINT32 IcHalApiSetTxIcPreDly(UINT32 radio, UINT32 *preDly, UINT32 dlyNum){return BSP_OK;}
UINT32 IcHalApiSetTxIcPostDly(UINT32 radio, UINT32 *postDly, UINT32 dlyNum){return BSP_OK;}
UINT32 IcHalApiSetRxIcPreDly(UINT32 radio, UINT32 *preDly, UINT32 dlyNum){return BSP_OK;}
UINT32 IcHalApiSetRxIcPostDly(UINT32 radio, UINT32 *postDly, UINT32 dlyNum){return BSP_OK;}
UINT32 IcHalApiGetT2aDlyMax(UINT32 radio, UINT32 *dly){return BSP_OK;}
UINT32 IcHalApiGetTa3DlyMax(UINT32 radio, UINT32 *dly){return BSP_OK;}
//UINT32 IcHalApiSetFddCarrDly(UINT32 uChan, UINT32 uCarrNo,UINT32 uDir, UINT32 uCarrMode, UINT32 uDlyFwd, UINT32 uDlyRvs){return BSP_OK;}
//UINT32 IcHalApiSetLNetWkVal(UINT32 uMode, UINT32 uDir, INT32 uVal){return BSP_OK;}
UINT32 IcHalApiSetReportT2aDly(UINT32 radio, UINT32 t2aDlyForward, UINT32 t2aDlyReverse){return BSP_OK;}
UINT32 IcHalApiSetReportTa3Dly(UINT32 radio, UINT32 ta3DlyForward, UINT32 ta3DlyReverse){return BSP_OK;}
//UINT32 IcHalApiGetUeAdvGapVal(UINT32 mode, UINT32 *pUeAdvValNs, UINT32 *pUeGapValNs, UINT32 *pMixModAdvComp){return BSP_OK;}
//UINT32 IcHalApiSetTddIoUeAdvGapVal(UINT32 ueAdvValNs, UINT32 ueGapValNs, UINT32 mixModAdvComp){return BSP_OK;}
//UINT32 IcHalApiGetTddIoUeAdvGapVal(UINT32 *pUeAdvValNs, UINT32 *pUeGapValNs, UINT32 *pMixModAdvComp){return BSP_OK;}


/**************************************************************************
                            optctrl相关接口打桩
**************************************************************************/
//UINT32 IcHalApiClrPreAlloc(VOID){return BSP_OK;}
//UINT32 IcHalApiSetOptLinkTbl(T_Opt_Link_Tbl *pOptlink, UINT32 LinkNum){return BSP_OK;}
//UINT32 IcHalApiSetOptAntFlowMapInfo(T_OptAntFlowMapInfo*  optAntFlowMapInfo, UINT32 mapSize){return BSP_OK;}
//UINT32 IcHalApiOptEcpriCellInfoInit(T_EcpriCellStreamInfo *pPara,UINT32 dir){return BSP_OK;}

//UINT32 IcHalApiOptInit(T_OptInitPara *pOptInitPara){return BSP_OK;}
//UINT32 IcHalApiOptSetTddCfg(T_CarrTddIndCfg *pCfg, UINT32 uCfgNum){return BSP_OK;}
//UINT32 IcHalApiOptCellInfoInit(T_OptCellCfgInfo *pPara){return BSP_OK;}
//UINT32 IcHalApiOptL1CellPrachInfoInit(UINT32 uRachNum, T_PrachCellInfo *pPara){return BSP_OK;}
//UINT32 IcHalApiOptCellCfg(UINT32 uCellId){return BSP_OK;}
//UINT32 IcHalApiGetCellAntMask(UINT32 uCellId, UINT32 uDir, UINT32* antMask){return BSP_OK;}
//UINT32 IcHalApiGetCellCaMode(UINT32 uCellId,UINT32* uCaMode){return BSP_OK;}
//UINT32 IcHalApiGetCellRadioMode(UINT32 uCellId,UINT32* uRadioMode){return BSP_OK;}
//UINT32 IcHalApiSetCellErsInfo(UINT32 uCellId, UINT32 carrNo,UINT32 caMode, UINT32 scaleVal){return BSP_OK;}
//UINT32 IcHalApiGetPhaCompParaScsSymNum(UINT32 uCellId, UINT32* scs, UINT32* symNum){return BSP_OK;}
//UINT32 IcHalApiCfgPhaCompVal(UINT32 uCellId, UINT32 uDir,UINT32 *pPhaCompVal, UINT32 uLen){return BSP_OK;}
//UINT32 IcHalApiPsyncCfg(UINT32 uPsyncMode){return BSP_OK;}
//UINT32 IcHalApiAcWgtSwitchByChnMap(UINT32 uDir, UINT32 uAntMask, UINT32 uSwitch){return BSP_OK;}
//UINT32 IcHalApiGetSsbPos(UINT32 *pBitMap, UINT32 uLen){return BSP_OK;}

//UINT32 IcHalApiNtlL2ssSetTrxpMode(T_TRPG_GROUP_MODE_CFG *ptTrxpModeCfg,UINT32 num){return BSP_OK;}
//UINT32 IcHalApiNtlL2ssSetXmacCfg(T_NtlPortCfg *ptNtlPortCfg,UINT32 num){return BSP_OK;}
//UINT32 IcHalApiSetOptSysPwrSaveSwitch(UINT32 uSwitch){return BSP_OK;}

/* ROE CW相关接口 */
UINT32 IcHalApiSetEcpriCwChnCfg(T_NtlCwChnCfg *ptNtlCwChnCfg, UINT32 uNum){return BSP_OK;}
UINT32 IcHalApiSetFastErsCfg(VOID){return BSP_OK;}
//UINT32 IcHalApiSetCwHiPowRptEn(UINT32 uEnable){return BSP_OK;}
//UINT32 IcHalApiSetCwHiPowRptCfg(T_CwHiPowRtpInfo *ptCwHiPowRtpInfo, UINT32 num){return BSP_OK;}
//UINT32 IcHalApiSetEcpriRemoteRst(UINT8 *pDestMac1,UINT8 *pDestMac2){return BSP_OK;}
UINT32 IcHalApiUpCombSmpL2dStart(UINT32 uCellId, UINT32 uDir,UINT32 uAnt, UINT32 uDifOrGfTmp, UINT32 uSlot, UINT32 uStartSym, UINT32 uSymbNum){return BSP_OK;}
UINT32 IcHalApiUpCombSmpL2dSave(UINT32 uCellId, UINT32 uDifOrGfTmp){return BSP_OK;}


//UINT32 IcHalApiD3ApdtOptCfg(VOID){return BSP_OK;}

//UINT32 IcHalApiSetOptAntEn(UINT32 uDir, UINT32 uEnale){return BSP_OK;}
//UINT32 IcHalApiSetOptAntEnByScsIdx(UINT32 uDir, UINT32 uScsIdx, UINT32 uSwitch){return BSP_OK;}
//UINT32 IcHalApiSetOptStart(VOID){return BSP_OK;}
//UINT32 IcHalApiOptL1Switch(UINT32 uSwitch){return BSP_OK;}
//UINT32 IcHalApiOptFftSwitchBy16T(UINT32 uDir, UINT32 uIdxBs, UINT32 uSwitch){return BSP_OK;}
//UINT32 IcHalApiOptDdcSwitchBy16T(UINT32 uIdxBs, UINT32 uSwitch){return BSP_OK;}

/* CRM Remote Pwd&Hard Rest Sel */
//UINT32 IcHalApiSetCrmRmtPwdRstSrc(UINT32 uRstSrc){return BSP_OK;}
//UINT32 IcHalApiSetCrmRmtHardRstSrc(UINT32 uRstSrc){return BSP_OK;}

UINT32 IcHalApiSetGfAntEnByCell(UINT32 uCellId, UINT32 uDir, UINT32 uIqOrRach, UINT32 uSwitch){return BSP_OK;}
UINT32 IcHalApiCloseUnusedResTdm(UINT32 dir, UINT32 chanMask, UINT32 preAllocIdx, UINT32 resIdx){return BSP_OK;}
UINT32 IcHalApiSetOptAntEnByChan(UINT32 uAntChan, UINT32 uDir, UINT32 uSwitch){return BSP_OK;}

UINT32 IcHalApiUpdataGscn(UINT32 uRadioMode, UINT32 uCellId, UINT32 uGscn, UINT32 uSsbValid){return BSP_OK;}
//UINT32 IcHalApiSetCellCfgMode(UINT32 uCellCfgMode){return BSP_OK;}
//UINT32 IcHalApiGetCpriProtocol(UINT32 *pulProtocol){return BSP_OK;}

/**************************************************************************
                            光口sedres pcs相关接口打桩
**************************************************************************/
//UINT32 IcHalApiCrmPcsSetReset(UINT32 ulChip, UINT32 ulPcsIdx, UINT32 ulRstFlag){return BSP_OK;}
//UINT32 IcHalApiCrmNtlRxXmacSetReset(UINT32 ulChip, UINT32 laneMask, UINT32 ulRstFlag){return BSP_OK;}
//UINT32 IcHalApiLycaLoadFw(UINT32 serdesId, UINT32 laneId){return BSP_OK;}
//UINT32 IcHalApiLycaInitTx(UINT32 serdesId, UINT32 laneId, UINT32 rate, E_LYCA_CLK_CFG clkMode, DOUBLE ldb){return BSP_OK;}
//UINT32 IcHalApiLycaSetTxFirCoff(UINT32 serdesId, UINT32 laneId, UINT32 eoh0, UINT32 eoh1, UINT32 eoh2, UINT32 eoh3){return BSP_OK;}
//UINT32 IcHalApiLycaInitRx(UINT32 serdesId, UINT32 laneId){return BSP_OK;}
//UINT32 IcHalApiLycaTccSwitch(UINT32 serdesId, UINT32 laneId){return BSP_OK;}
//UINT32 IcHalApiCrmNtlTxXmacSetReset(UINT32 ulChip, UINT32 laneMask, UINT32 ulRstFlag){return BSP_OK;}

UINT32 IcHalApiInitOptFftaPara(UINT32 cellId, UINT32 dir, UINT32 scs, T_FFTACfgPara* fftaPara) {return BSP_OK;}
UINT32 IcHalApiInitOptFftaHwCfg(){return BSP_OK;}
UINT32 IcHalApiPreCfgL1OptByWorkMode(UINT32 workMode) {return BSP_OK;}



/**************************************************************************
                            增益控制相关接口打桩
**************************************************************************/

/** 暂时打桩，待HAL层将接口代码合入 ITRANAAU 后，全部屏蔽此部分打桩。 **/
// UINT32 IcHalApiSetDlbankAptune(UINT32 uiDifChan, UINT32 uiCarrId, UINT32 uiRadioMode, INT32 iGain) { return BSP_OK; }
// UINT32 IcHalApiGetDlbankAptune(UINT32 uiDifChan, UINT32 uiCarrId, UINT32 uiRadioMode, INT32 *pGain) { return BSP_OK; }
// UINT32 IcHalApiUlbankAptuneDataEn(UINT32 uiDifChan, UINT32 uiCarrId, UINT32 uiRadioMode, UINT32 uiDataEn) { return BSP_OK; }
// UINT32 IcHalApiGetDlpreGainDataEnStatus(UINT32 uiDifChan, UINT32 uiCarrId, UINT32 uiRadioMode, UINT32 *puiDataEn) { return BSP_OK; }
// UINT32 IcHalApiGetUlbankAptuneDataEnStatus(UINT32 uiDifChan, UINT32 uiCarrId, UINT32 uiRadioMode, UINT32 *puiDataEn) { return BSP_OK; }
// UINT32 IcHalApiSetDlcfrK0(UINT32 uiDifChan, INT32 iGain) { return BSP_OK; }
// UINT32 IcHalApiGetDlcfrK0(UINT32 uiDifChan, INT32 *pGain) { return BSP_OK; }
// UINT32 IcHalApiSetDlcfrK0Diff(UINT32 uiDifChan, INT32 iGain) { return BSP_OK; }
// UINT32 IcHalApiGetDlcfrK0Diff(UINT32 uiDifChan, INT32 *pGain) { return BSP_OK; }
// UINT32 IcHalApiSetDlpostGain4(UINT32 uiDifChan, INT32 iGain) { return BSP_OK; }
// UINT32 IcHalApiGetDlpostGain4(UINT32 uiDifChan, INT32 *pGain) { return BSP_OK; }
// UINT32 IcHalApiSetUlbankAptune(UINT32 uiDifChan, UINT32 uiCarrId, UINT32 uiRadioMode, INT32 iGain) { return BSP_OK; }
// UINT32 IcHalApiGetUlbankAptune(UINT32 uiDifChan, UINT32 uiCarrId, UINT32 uiRadioMode, INT32 *pGain) { return BSP_OK; }


/**************************************************************************
                            SOC相关接口
**************************************************************************/

/* 暂时打桩，待BSP预研 完成接口封装合入后，再屏蔽此打桩 */
UINT32 IcHalApiGetIcChipId(UINT32 *pChipIdx) { return BSP_OK; }


/**************************************************************************
                            IQ配置相关接口打桩
**************************************************************************/
//UINT32 IcHalApiCpriGetPPoint(UINT32 optpPort) {return BSP_OK;}
//UINT32 IcHalApiSetGlobleOutFrDir(UINT32 dir) {return BSP_OK;}
//UINT32 IcHalApiSetCpriNetMode(UINT32 ulNetMode){return BSP_OK;}

/**************************************************************************
                            DPD相关接口打桩
**************************************************************************/
//UINT32 IcHalApiGetDspRoute(UINT32 uiDifChan, T_DifDspRoute *ptDspRoutePara){return BSP_OK;}
//UINT32 IcHalApiSetAcCfgEn(UINT32 uiCfgEn){return BSP_OK;}
//UINT32 IcHalApiSetTsGpEn(UINT32 uiDifChan, UINT32 uiGpEn){return BSP_OK;}
/*以下两个接口pa模块定义，但是dpd模块调用 暂时放在这里*/
//UINT32 BspTddSwModeSel(UINT32 tddSel,UINT32 modeSel) {return BSP_OK;}
//UINT32 BspUpdateTddIoVariablePara(UINT32 tddSel, UINT32 acType){return BSP_OK;}



/**************************************************************************
                            J204相关接口打桩
**************************************************************************/
/* J204 serdes */
//UINT32 IcHalApiJ204SdsLoadFw(UINT32 laneIdMask,UINT32 txDataRate,UINT32 rxDataRate,BOOL refreshExtFw) {return BSP_OK;}
//UINT32 IcHalApiPhyApbResetCfg(UINT32 serdesId,UINT32 rstFlag) {return BSP_OK;}
//UINT32 IcHalApiJ204SdsTxPwron(UINT32 laneIdMask) {return BSP_OK;}
//UINT32 IcHalApiJ204SdsRxPwron(UINT32 laneIdMask) {return BSP_OK;}
//UINT32 IcHalApiJ204SdsTxPwrDn(UINT32 laneIdMask) {return BSP_OK;}
//UINT32 IcHalApiJ204SdsRxPwrDn(UINT32 laneIdMask) {return BSP_OK;}
//UINT32 IcHalApiJ204SdsTxDataEn(UINT32 laneIdMask,BOOL enable) {return BSP_OK;}
//UINT32 IcHalApiJ204SdsRxDataEn(UINT32 laneIdMask,BOOL enable) {return BSP_OK;}
//UINT32 IcHalApiAdjustJ204SerdesTxEq(UINT32 laneIdMask,UINT32 eqPre,UINT32 eqPost,UINT32 eqMain) {return BSP_OK;}

/* j204 block */
// UINT32 IcHalApiJ204LinkInit(UINT32 uiBlockId, UINT32 *pLinkInfo, UINT32 uiLinkSize) {return BSP_OK;}
// UINT32 IcHalApiJ204MapInit(UINT32 uiBlockId, UINT32 *pMapInfo, UINT32 uiMapSize) {return BSP_OK;}

// UINT32 IcHalApiGetUlSysrefStatus(UINT32 uiBlockId) {return BSP_OK;}
// UINT32 IcHalApiGetDlSysrefStatus(UINT32 uiBlockId) {return BSP_OK;}
// UINT32 IcHalApiGetFbSysrefStatus(UINT32 uiBlockId) {return BSP_OK;}
// UINT32 IcHalApiClrUlSysrefStatus(UINT32 uiBlockId) {return BSP_OK;}
// UINT32 IcHalApiClrDlSysrefStatus(UINT32 uiBlockId) {return BSP_OK;}
// UINT32 IcHalApiClrFbSysrefStatus(UINT32 uiBlockId) {return BSP_OK;}
// UINT32 IcHalApiGetJ204UlState(UINT32 uiBlockId, UINT32 uiLaneId, UINT32 *uiUlState) {return BSP_OK;}
// UINT32 IcHalApiGetJ204FbState(UINT32 uiBlockId, UINT32 uiLaneId, UINT32 *uiFbState) {return BSP_OK;}

// UINT32 IcHalApiGetUlCRCErrCode(UINT32 uiBlockId, UINT32 uiLaneId, UINT32 *pUlCRCErrCount) {return BSP_OK;}
// UINT32 IcHalApiGetFbCRCErrCode(UINT32 uiBlockId, UINT32 uiLaneId, UINT32 *pFbCRCErrCount) {return BSP_OK;}

// UINT32 IcHalApiRspUlSysref(UINT32 uiBlockId) {return BSP_OK;}
// UINT32 IcHalApiRspFbSysref(UINT32 uiBlockId) {return BSP_OK;}
// UINT32 IcHalApiRspDlSysref(UINT32 uiBlockId) {return BSP_OK;}

// UINT32 IcHalApiSysrefRequest(T_DifSysrefCfg *pSysrefCfg) {return BSP_OK;}     
// UINT32 IcHalApiSysrefGenerate(T_DifSysrefGenCfg *SysrefGenCfg) {return BSP_OK;}


/* crm j204 */
//UINT32 IcHalApiCrmJ204SetResetDLApb(UINT32 ulChip, UINT32 ulBlockId, UINT32 ulRstFlag) {return BSP_OK;}
//UINT32 IcHalApiCrmJ204SetResetDLMapSmp(UINT32 ulChip, UINT32 ulBlockId, UINT32 ulMapId, UINT32 ulRstFlag) {return BSP_OK;}
//UINT32 IcHalApiCrmJ204SetResetDLMapWork(UINT32 ulChip, UINT32 ulBlockId, UINT32 ulMapId, UINT32 ulRstFlag) {return BSP_OK;}
//UINT32 IcHalApiCrmJ204SetResetDLLinkLane(UINT32 ulChip, UINT32 ulBlockId, UINT32 ulLaneMask, UINT32 ulRstFlag) {return BSP_OK;}
//UINT32 IcHalApiCrmJ204SetResetDLSysref(UINT32 ulChip, UINT32 ulBlockId, UINT32 ulRstFlag) {return BSP_OK;}
//
//
//UINT32 IcHalApiCrmJ204SetResetULApb(UINT32 ulChip, UINT32 ulBlockId, UINT32 ulRstFlag) {return BSP_OK;}
//UINT32 IcHalApiCrmJ204SetResetULMapSmp(UINT32 ulChip, UINT32 ulBlockId, UINT32 ulMapId, UINT32 ulRstFlag) {return BSP_OK;}
//UINT32 IcHalApiCrmJ204SetResetULMapWork(UINT32 ulChip, UINT32 ulBlockId, UINT32 ulMapId, UINT32 ulRstFlag) {return BSP_OK;}
//UINT32 IcHalApiCrmJ204SetResetULLinkLane(UINT32 ulChip, UINT32 ulBlockId, UINT32 ulLaneMask, UINT32 ulRstFlag) {return BSP_OK;}
//UINT32 IcHalApiCrmJ204SetResetULCtrl(UINT32 ulChip, UINT32 ulBlockId, UINT32 ulRstFlag) {return BSP_OK;}
//
//UINT32 IcHalApiCrmJ204SetResetFBApb(UINT32 ulChip, UINT32 ulBlockId, UINT32 ulRstFlag) {return BSP_OK;}
//UINT32 IcHalApiCrmJ204SetResetFBMapSmp(UINT32 ulChip, UINT32 ulBlockId, UINT32 ulMapId, UINT32 ulRstFlag) {return BSP_OK;}
//UINT32 IcHalApiCrmJ204SetResetFBMapWork(UINT32 ulChip, UINT32 ulBlockId, UINT32 ulMapId, UINT32 ulRstFlag) {return BSP_OK;}
//UINT32 IcHalApiCrmJ204SetResetFBLinkLane(UINT32 ulChip, UINT32 ulBlockId, UINT32 ulLaneMask, UINT32 ulRstFlag) {return BSP_OK;}
//UINT32 IcHalApiCrmJ204SetResetFBCtrl(UINT32 ulChip, UINT32 ulBlockId, UINT32 ulRstFlag) {return BSP_OK;}
//
//
//UINT32 IcHalApiCrmJ204SetResetULRf(UINT32 ulChip, UINT32 ulBlockId, UINT32 ulRstFlag) {return BSP_OK;}
//UINT32 IcHalApiCrmJ204SetResetAll(UINT32 ulChip, UINT32 ulRstFlag) {return BSP_OK;}
//
//UINT32 IcHalApiCrmJ204SetResetGlobalApb(UINT32 ulChip, UINT32 ulRstFlag) {return BSP_OK;}

/**************************************************************************
                            CFR相关接口打桩
**************************************************************************/

/**************************************************************************
                            射频控制相关接口打桩
**************************************************************************/
UINT32 IcHalApiPinSw(UINT32 PinName, UINT32 sw){return BSP_OK;}






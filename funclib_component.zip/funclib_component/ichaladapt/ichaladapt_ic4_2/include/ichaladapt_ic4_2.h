/*****************************************************************************
* 版权所有(C) 2020, ZTE Corp. ZXSDR-RRU Platform BSP
*----------------------------------------------------------------------------
* 模 块 名 : bsp
* 文件名称 : ichaladapt_ic4_2.h
* 文件标识 : {[N/A]}
* 内容摘要 : 本文件提供了ICHAL适配层对外接口声明
* 注意事项 : 无
* 作    者 : 王涛10248577
* 创建日期 : 2020-11-04
* 当前版本 : Ver1.0
*----------------------------------------------------------------------------
* 变更记录 :
*
* $记录1
* 变 更 单: $0000000(N/A)
* 责 任 人: 王涛10248577
* 修改日戳: 2020-11-04
* 变更说明: 创建文件
*----------------------------------------------------------------------------
*/

#ifndef _FUNCLIB_ICHALADAPT_IC4_2_H_
#define _FUNCLIB_ICHALADAPT_IC4_2_H_


#ifdef __cplusplus
extern "C" {
#endif

#include "tx_gunb_cfg.h"

//此处include HAL层头文件
#include "bsppub.h"
#include "bspcomm.h"
#include "exprn.h"
#include "ichaladaptbspapi.h"
#include "ichaladaptcommon.h"
#include "ichalstub_ic4_2.h"
#include "hal_comm.h"
#include "vgactrl_api.h"
#include "vgactrl.h"
#include "mesginter_drv.h"

//opt hal header
#include "ichal_opt_api.h"
#include "icopthalcomm.h"
#include "opt_cpri_api.h"
//dif hal
#include "init_fun_api.h"
#include "dif_common_para_api.h"
#include "resource_alloc_api.h"
#include "fr_cfg_api.h"
#include "freq_api.h"
#include "sw_ctrl_api.h"
#include "cfr_api.h"
#include "j204_api.h"
#include "dif_dly_api.h"
#include "router_api.h"
#include "papt_api.h"
#include "pim_chk_api.h"
#include "tdd_cfg.h"
#include "icopthalcomm.h"


//有疑问的
#include "rx_gunb_cfg.h"
#include "pad_ctrl_api.h"
#include "pwr_chk_api.h"
#include "cpam_inter_api.h"
#include "opt_pma_api.h"
#include "tx_gunb_cfg.h"
#include "io_ctrl.h"
#include "io_api.h"
#include "rev_api.h"
#include "rx_gunb_cfg.h"
#include "utdoa_ctrl_api.h"
#include "ntl_nacc_xmac.h"
#include "ichal_opt_api.h"
#include "pub_ntl.h"
#include "m0_load.h"
#include "roe.h"
#include "roe_iq.h"
#include "ic_resource.h"
//#include "boardversionload.h"


#define BSP_FLAG_VALID   ((UINT32)1)   /* 有效标志 */
#define BSP_FLAG_INVALID ((UINT32)0)   /* 无效标志 */

#define POW_IC_MAX_CHAN_CHECK(ch)               \
    if ((ch) >= BSP_HALADAPT_IC_CHAN_MAX_NUM)   \
    {                                           \
        dbgErr("%s: chan'%d is over max channum'%d\n",__FUNCTION__,ch,BSP_HALADAPT_IC_CHAN_MAX_NUM);  \
        return BSP_ERROR;                       \
    }
/**************************************************************************
                            配频相关接口
**************************************************************************/
typedef struct _T_DifCfgSave
{
    VOID* pAddr;
    UINT32 linkunm;
    UINT32 difChNum;
}T_DifCfgSave;

typedef struct tagT_HalGpioPadInfo
{
    UINT32  halPadGpioName;  /* 复用功能选择 */
}T_HalGpioPadInfo;

typedef struct
{
    UINT32                      coreId;
    UINT32                      ceneType;
} T_M0CoreLoadInfo;

typedef struct
{
    UINT32                      coreNum;
    T_M0CoreLoadInfo            coreLoadInfo[2];
} T_M0VerLoadInfo;


enum _E_DIF_CFG_TYPE
{
    E_DIF_ROUTEMAP_RX = 0,
    E_DIF_ROUTEMAP_TX,
    E_DIF_ROUTEMAP_FB,
    E_DIF_ROUTEMAP_204,
    E_DIF_ROUTEPARA_TX,
    E_DIF_DIFPARA_INIT,
    E_DIF_DIFPARA_SAMRATE,
    E_DIF_DIFPARA_CLK,
    E_DIF_DIFPARA_RESALLOC,
    E_DIF_DIFPARA_CFR,
    E_DIF_DIFPARA_FR,
    E_OPT_SERDES_PARA,
    E_DIF_DIFPARA_DTX,
    E_DIF_DIFPARA_PAPT,
    E_DIF_DIFPARA_GATE,
    E_OPT_ROECW_CFG,
    E_DIF_CRMCLK_PARA,
    E_DIF_CRMCLK_SEL,
    E_IC_PWRSAVE_NORMAL_SEL,       /* 正常工作状态节能配置 */
    E_IC_PWRSAVE_DEEPSLEEP_SEL,    /* 深度休眠状态节能配置 */
    E_IC_PWRSAVE_ALLCARROFF_SEL,   /* 全载波关断黄台节能配置 */
    E_IC_PWRSAVE_QCELL_PB_SEL,    /* QCELL连PB场景IC节电策略*/
    E_IC_PWRSAVE_QCELL_BBU_SEL,   /* QCELL连BBU场景IC节电策略*/
    E_DIF_CFG_TYPE_MAX
};

VOID SaveDifCfg(UINT32 type, VOID *pAddr, UINT32 linkunm, UINT32 difChNum);
T_DifCfgSave* GetDifCfgSave(UINT32 type);


typedef T_DifFrInitCfg  T_BspHalAdaptFrInitCfg;
typedef T_DifConfigInfo T_BspHalAdaptDifCfgPara;
typedef T_RevInfoCfg    T_BspHalAdaptRevInit;

/* IC中频HAL支持的最大载波数 */
#define BSP_HALADAPT_MAX_DIF_CARR_NUM  BSP_DIF_CARR_MAX_NUM
//IC4.0支持最大通道数的宏
#define BSP_IC4_DIF_CHAN_NUM  (IC_CHAN_MAX_NUM)
//IC4.2支持最大下行通道数的宏
#define BSP_IC42_MAX_TX_CHAN_NUM (IC_CHAN_MAX_NUM)

#define BSP_D_INFO_VALID_FLAG (D_INFO_VALID_FLAG)

#define BSP_UL_BANK_BANK_NUM_IN_BLOCK (UL_BANK_BANK_NUM_IN_BLOCK) /* 中频一个上行dlbank_block中的bank总数 */
#define BSP_DL_BANK_BANK_NUM_IN_BLOCK (DL_BANK_BANK_NUM_IN_BLOCK) /* 中频一个下行dlbank_block中的bank总数 */

#if 0
//IC4.0最大支持两反馈
#define BSP_HALADAPT_DPDCB_CH_NUM (DPDCB_CH_NUM)


#endif


typedef T_HalLinkDeltaDly T_BspHalAdaptLinkDeltDly;
typedef T_DifTxRouteMap T_BspHalAdaptDifTxRouteMap;
typedef T_DifTxRoutePara T_BspHalAdaptDifTxRoutePara; 
typedef T_DifTx204RouteMap T_BspHalAdaptDifTx204RouteMap;
typedef T_DifRxRouteMap T_BspHalAdaptDifRxRouteMap;
typedef T_DifFbRouteMap T_BspHalAdaptDifFbRouteMap;

typedef T_DifSamRateCommPara T_BspHalAdaptDifSamRatePara;

typedef T_DifClkCommPara T_BspHalAdaptDifClkPara;

typedef T_DifResourceAllocCommPara T_BspHalAdaptDifResAllocPara;
typedef T_DifResourceAllocChanPara T_BspHalAdaptDifResAllocChanPara;

#if 0
typedef T_PAD_FUNC_SEL_PARA T_BspHalAdaptPadFuncSelPara;  /* 功能选择参数 */
typedef T_PAD_CFG_DONE_PARA T_BspHalAdaptPadCfgDonePara;  /* config done 参数 */

typedef T_VgaCtrlComPara T_BspHalAdaptVgaCtrlComPara;
typedef T_VgaCompPara T_BspHalAdaptVgaCompPara;

typedef struct _T_BspHalAdaptDifCrmClk{
    UINT32 baseLogicClk;
    UINT32 dlLogic2Clk;
    UINT32 dlLogic3Clk;
    UINT32 dlLogic4Clk;
    UINT32 dlLogic5Clk;
    UINT32 ulLogic1Clk;
    UINT32 ulLogic2Clk;
    UINT32 fbLogic1Clk;
    UINT32 fbLogic2Clk;
    UINT32 dlJ204WorkClk;
    UINT32 ulJ204WorkClk;
    UINT32 fbJ204WorkClk;
}T_BspHalAdaptDifCrmClk;

UINT32 BspHalAdaptGetDifCrmClk(T_BspHalAdaptDifCrmClk *pDifCrmClk);
#endif
typedef T_DifCarrTddIndCfg T_BspHalAdaptCarrTddIndCfg;
UINT32 BspHalAdaptDifTxRouteMapInit(T_BspHalAdaptDifTxRouteMap *ptTxRouteMap, UINT32 txLinkNum, UINT32 txDifNum);
UINT32 BspHalAdaptDifTxRouteParaInit(T_BspHalAdaptDifTxRoutePara *ptTxRoutePara, UINT32 txLinkNum, UINT32 txDifNum);
UINT32 BspHalAdaptDifTx204RouteMapInit(T_BspHalAdaptDifTx204RouteMap *ptTx204RouteMap, UINT32 tx204LinkNum, UINT32 tx204DifNum);
UINT32 BspHalAdaptDifRxRouteMapInit(T_BspHalAdaptDifRxRouteMap *ptRxRouteMap, UINT32 rxLinkNum, UINT32 rxDifNum);
UINT32 BspHalAdaptDifFbRouteMapInit(T_BspHalAdaptDifFbRouteMap *ptFbRouteMap, UINT32 fbLinkNum, UINT32 fbDifNum);
UINT32 BspHalAdaptDifParaInit(T_BspHalAdaptDifCfgPara *pDifPara);
UINT32 BspHalAdaptDifSamRateParaInit(T_BspHalAdaptDifSamRatePara *pDifSamratePara);
UINT32 BspHalAdaptDifCfgTdd_TDD(T_CarrTddIndCfg *pTddIndCfg, UINT32 chanMask);
UINT32 BspHalAdaptDifCfgTxOrRxTdd_TDD(T_CarrTddIndCfg *pTddIndCfg, UINT32 txChanMask,UINT32 rxChanMask);
UINT32 BspHalAdaptDifCfgTdd_FDD(T_BspHalAdaptCarrTddIndCfg *pTddIndCfg);
INT32 BspHalAdaptGetFrTmVal(UINT32 ulCfgId, UINT32 ulMode);

UINT32 BspHalAdaptSetTxGuardBandNco(UINT32 difChan, UINT32 carrNo, UINT32 radioMode, INT32 offset);
UINT32 BspHalAdaptSetRxGuardBandNco(UINT32 difChan, UINT32 carrNo, UINT32 radioMode, INT32 offset);
UINT32 BspHalAdaptSetTxGsmNcoSel(UINT32 difChan, UINT32 carrNo, UINT32 radioMode, UINT32 flag);
UINT32 BspHalPsyncTimGernInit(UINT32 irqId, UINT32 timePeriod, UINT32 timeOffset, UINT32 inter, UINT32 ctrl);

/*
    中频时钟参数初始化
    type 0:时钟参数保存到全局变量中，供CRM初始化使用
         1:时钟参数配置到中频HAL中
*/
#define CFG_TYPE_CRM_INIT (0)
#define CFG_TYPE_HAL_INIT (1)

UINT32 BspHalAdaptDifClkParaInit(T_BspHalAdaptDifClkPara *pDifClkPara, UINT32 type);
UINT32 BspHalAdaptDifResourceAllocParaInit(T_BspHalAdaptDifResAllocPara *pDifResAllocPara);
UINT32 BspHalAdaptGetTxCarrNum(UINT32 uiDifChan, UINT32 *puiCarrNum);
UINT32 BspHalAdaptGetRxCarrNum(UINT32 uiDifChan, UINT32 *puiCarrNum);
UINT32 BspHalAdaptLoadM0CoreVersion(UINT32 ulCoreId, UINT32 ulSceneType);
UINT32 BspSetMainM0VerLoadInfo(T_M0VerLoadInfo *pM0VerLoadInfo);
UINT32 BspGetMainM0VerLoadInfo(T_M0VerLoadInfo *pM0VerLoadInfo);
UINT32 BspSetSlaveM0VerLoadInfo(T_M0VerLoadInfo *pM0VerLoadInfo);
UINT32 BspGetSlaveM0VerLoadInfo(T_M0VerLoadInfo *pM0VerLoadInfo);
/**************************************************************************
                            帧头初始化相关接口
**************************************************************************/
UINT32 BspHalAdaptSetDifFrInit(T_BspHalAdaptFrInitCfg *pFrInitCfg);
/**************************************************************************
                            时延相关接口
**************************************************************************/
#define TIME_DLY_INVALID              (0xffffffff)  /*时延无效值*/
typedef struct tagT_BspAdaptCarrDelayItem
{
    UINT32   dwPrmDLDelay;                    /* 主方向的下行时延值*/
    UINT32   dwPrmUPDelay;                    /* 主方向的上行时延值*/
    UINT32   dwSecDLDelay;                    /* 从方向的下行时延值*/
    UINT32   dwSecUPDelay;                    /* 从方向的上行时延值*/
}T_BspAdaptCarrDelayItem;


typedef E_QCELL_CFG_PACKET_TYEP T_BspHalAdaptQcellCfgPacketType ;

UINT32 BspHalAdaptSetFrameAlignment(UINT32 bandId, UINT32 radioMode, INT32 frameDelay);
UINT32 BspHalAdaptSetFrameAlignment_FDD(UINT32 bspChan, UINT32 carrNo, UINT32 radioMode, INT32 frameDelay);
UINT32 BspHalAdaptUpdateFddDlTddRamFrDly(UINT32 bspChan, UINT32 carrNo, UINT32 radioMode);
UINT32 BspHalAdaptUpdateDifChanDelay(UINT32 difChan);
UINT32 BspHalAdaptUpdateTxDifChanDelay(UINT32 difChan);/* TX */
UINT32 BspHalAdaptUpdateRxDifChanDelay(UINT32 difChan);/* RX */
UINT32 BspHalAdaptUpdateDifCarrDelay(UINT32 difChan,UINT32 radioMod,UINT32 difCarrNo);
UINT32 BspHalAdaptUpdateQcellDifCarrDelay(UINT32 difChan, UINT32 carrIndex, UINT32 radioMode, UINT32 dir);
UINT32 BspHalAdaptSetUeAdvVal(UINT32 uMode, UINT32 uVal);
UINT32 BspHalAdaptGetRruToffsetDelay(UINT32 optIndex, UINT32 *uVal);
UINT32 BspHalAdaptGetMainLogicOpt(UINT32 *mainLogicOpt);
UINT32 BspHalAdaptGetCpriProtocol(UINT32 *pulProtocol);
UINT32 BspHalAdaptGetOptProtocol(UINT32 *optProtocol);
UINT32 BspHalAdaptSetQcellDelayPara(T_QCELLDELAYPARA *pQcellDelayPara, UINT32 uNum);
UINT32 BspHalAdaptRoeGetQcellCfgPacket(T_BspHalAdaptQcellCfgPacketType ulType, UINT8 *buf, UINT32 ulLen);
UINT32 BspHalAdaptRoeFrPsyncToCpri(UINT32 roeIqChan);
UINT32 BspHalAdaptRoeGetMeasureChange(UINT32 roeIqChan);
UINT32 BspHalAdaptGetEthMasterToffset(UINT32 *pulVal);
UINT32 BspHalAdaptOptMonitorM0(VOID); 
UINT32 BspHalAdaptOptGetQcellMonitorState(VOID);
VOID BspHalAdapOptSetQcellMonitoState(UINT32 ulVal);
VOID BspHalAdaptRecordLinkBrokenState(VOID);
UINT32 BspHalAdaptGetQcellDelayPara(UINT32 uRadio, UINT32 uT12OrT34OrTa, UINT32 *pVal);
UINT32 BspHalAdaptSetSw2TxDstPort(UINT32 ulEn);
UINT32 BspHalAdaptSetQcellNrCompSwTable(UINT32 rate);

UINT32 BspHalAdaptSetCarrDly_FDD(UINT32 uChan, UINT32 dir, UINT32 carrNo, UINT32 uRadioMode, T_BspAdaptCarrDelayItem *tCarrDelay);
UINT32 BspHalAdaptSetCarrDly_Check(UINT32 uChan, UINT32 dir, UINT32 carrNo, UINT32 uRadioMode, T_BspAdaptCarrDelayItem *tCarrDelay);
UINT32 BspHalAdaptSetOptTDDCarrDly(UINT32 uChan, UINT32 uDir, UINT32 uCarrNo, UINT32 uRadioMode,T_BspAdaptCarrDelayItem *tCarrDelay);
UINT32 BspHalAdaptSetTa(UINT32 optIndex, UINT32 taDelay);
UINT32 BspHalAdaptSetRxTa(UINT32 optIndex, UINT32 taDelay);
UINT32 BspHalAdaptSetT12(UINT32 uFwdOrRvs, UINT32 delay);
UINT32 BspHalAdaptSetT34(UINT32 uFwdOrRvs, UINT32 t34Delay);
void BspHalAdaptSetFddTalign(UINT32 talign);
UINT32 BspHalAdaptSetOptT12Val(UINT32 logOptNo, UINT32 uT12Val);
UINT32 BspHalAdaptSetOptT34Val(UINT32 logOptNo, UINT32 uT34Val);
UINT32 BspHalAdaptSetFftDelay(UINT32 uDir, UINT32 uFwdOrRvs);

UINT32 BspHalAdaptSetInterFramerDelay(UINT32 radio, UINT32 dlDelay, UINT32 ulDelay);
UINT32 BspHalAdaptSetChipTransmitDly(UINT32 chipTrandly_dl, UINT32 chipTrandly_ul);
UINT32 BspHalAdaptGetUeAdvGapVal(UINT32 mode, UINT32 *pUeAdvValNs, UINT32 *pUeGapValNs, UINT32 *pMixModAdvComp);
UINT32 BspHalAdaptSetTddIoUeAdvGapVal(UINT32 ueAdvValNs, UINT32 ueGapValNs, UINT32 mixModAdvComp);
UINT32 BspHalAdaptGetTddIoUeAdvGapVal(UINT32 *pUeAdvValNs, UINT32 *pUeGapValNs, UINT32 *pMixModAdvComp);
UINT32 BspHalAdaptGetMaxDelay2Point(VOID);
UINT32 BspHalAdaptGetMinDelay3Point(VOID);
UINT32 BspSaveBbuGlobalOptPort(UINT32 BBUGlobalOptID0, UINT32 BBUGlobalOptID1);
VOID BspHalAdaptSetBaseDelayLogOpt(UINT32 baseOpt);
VOID BspHalAdaptSetSlaveBaseDelayLogOpt(UINT32 logOpt);
UINT32 BspHalAdaptGetBaseDelayLogOpt(VOID);
UINT32 BspHalAdaptGeMainLogOptOnMaster(VOID);
VOID BspHalAdaptSetMainLogOptOnMaster(UINT32 logOpt);
/**************************************************************************
                            增益控制 相关接口
**************************************************************************/
typedef T_UmtsTxAgcCfg T_BspHalAdaptUmtsTxAgcCfg;
typedef T_UmtsDagcInfo T_BspHalAdaptUmtsDagcInfo;
#define GAIN_INVALID              ((INT32)0x8fffffff)  /*增益无效值*/
UINT32 BspHalAdaptSetTxUmtsAgcCfg(UINT32 uiDifChan, UINT32 uiCarrId, UINT32 uiRadioMode, T_BspHalAdaptUmtsTxAgcCfg *ptTxAgcCfg);
UINT32 BspHalAdaptSetUmtsDagcInit(T_UmtsDagcInfo *ptUmtsDagcInfo);
UINT32 BspHalAdaptSetDlbankAptuneWithPhase(UINT32 uiDifChan, UINT32 uiCarrId, UINT32 uiRadioMode, INT32 iRealCoef, INT32 iImagCoef);
UINT32 BspHalAdaptSetK0GainDiff(UINT32 difChan, INT32 gain);
UINT32 BspHalAdaptGetK0GainDiff(UINT32 difChan, INT32 *pGain);
UINT32 BspHalAdaptSetDlpreGain(UINT32 difChan, UINT32 carrIndex, UINT32 radioMode, INT32 gain);
UINT32 BspHalAdaptSetDlpreTdmGainCut(UINT32 difChan, UINT32 carrIndex, UINT32 radioMode);
UINT32 BspHalAdaptGetDlpreGain(UINT32 difChan, UINT32 carrIndex, UINT32 radioMode, INT32 *pGain);
UINT32 BspHalAdaptSetDlbankAptune(UINT32 difChan, UINT32 carrIndex, UINT32 radioMode, INT32 gain);
UINT32 BspHalAdaptGetDlbankAptune(UINT32 difChan, UINT32 carrIndex, UINT32 radioMode, INT32 *pGain);
UINT32 BspHalAdaptSetDlbankDgain(UINT32 difChan, UINT32 carrIndex, UINT32 radioMode, INT32 gain);
UINT32 BspHalAdaptGetDlbankDgain(UINT32 difChan, UINT32 carrIndex, UINT32 radioMode, INT32 *pGain);
UINT32 BspHalAdaptSetUlbankAptune(UINT32 difChan, UINT32 carrIndex, UINT32 radioMode, INT32 gain);
UINT32 BspHalAdaptGetUlbankAptune(UINT32 difChan, UINT32 carrIndex, UINT32 radioMode, INT32 *pGain);
UINT32 BspHalAdaptSetDlpreBbtssiGain(UINT32 difChan, UINT32 carrIndex, UINT32 radioMode, INT32 gain);
UINT32 BspHalAdaptSetDlpreTdmGain(UINT32 uiDifChan, INT32 iGain);
UINT32 BspGetPaOnUnNormalFlag(UINT32 dlchan);
UINT32 BspGetTddChanModeFlag(UINT32 dlchan);
UINT32 BspHalAdaptGetDlcfrDerate(UINT32 difChan, INT32* pGain);

/**************************************************************************
 *                              AGC 与 MGC 相关结构体及接口
 *************************************************************************/
typedef T_VgaCtrlPara T_BspHalAdaptVgaCtrlComPara;    // VGA控制参数（AGC、MGC共用参数）
typedef T_VgaJ204CmdPara T_BspHalAdaptVgaJ204CmdPara; // VGA控制-MGC Cmd参数
typedef T_VgaCtrlMgcPara T_BspHalAdaptVgaCtrlMgcPara; // VGA控制-MGC参数
typedef T_VgaCompPara T_BspHalAdaptVgaCompPara;       // VGA补偿压缩参数（AGC、MGC共用参数）
typedef T_IfBusPara T_BspHalAdaptIfBusPara;           // V中频SPI总线参数
typedef T_TimeCfgPara T_BspHalAdaptTimeCfgPara;       // 时间片参数配置
typedef T_QcellCompPara T_BspHalAdaptQcellCompPara;    // VGA控制参数(QCELL AGC特有参数)

typedef T_MtsBusCfgPara T_BspHalAdaptMtsBusCfgPara;    // VGA控制参数(mts_bus 类SPI初始化参数)

typedef struct  tagT_MtsIcBusRoutePara   // VGA控制参数MTS 和中频通道，MTS芯片号对应参数
{
		UINT32 uiDifChan;
		UINT32 uiMtsBusIdx;
		UINT32 uiMtsRx;
} T_MtsIcBusRoutePara;

typedef struct  tagT_MtsBusCfgSpiPara   // VGA控制参数MTS 和中频配置参数
{
		UINT32 uiMtsBusIdx;
		T_BspHalAdaptMtsBusCfgPara mtsBusCfgPara;
} T_MtsBusCfgSpiPara;




UINT32 BspHalAdaptInitVgaAgc(T_BspHalAdaptVgaCtrlComPara *pVgaCtrlPara, T_BspHalAdaptVgaCompPara *pVgaCompPara);
UINT32 BspHalAdaptInitVgaJ204CmdPara(T_BspHalAdaptVgaJ204CmdPara *pVgaJ204CmdPara);
UINT32 BspHalAdaptInitVgaMgc(T_BspHalAdaptVgaCtrlComPara *pVgaCtrlPara, T_BspHalAdaptVgaCtrlMgcPara *pVgaCtrlMgcPara, T_BspHalAdaptVgaCompPara *pVgaCompPara);
UINT32 BspHalAdaptInitQcellVgaCompPara(T_BspHalAdaptQcellCompPara *pQcellCompPara);
UINT32 BspHalAdaptSetRxVgaGain(UINT32 difChan, UINT32 radioMode, UINT32 carrIndex, INT32 preAtt);
UINT32 BspHalAdaptGetRxVgaGain(UINT32 difChan, UINT32 radioMode, UINT32 carrIndex, INT32 *preAtt);
UINT32 BspHalAdaptSetAllRxVgaGain(INT32 gain);
UINT32 BspHalAdaptSetVgaTransDbLut(UINT32 blockId, UINT32* vgaLutTab);
UINT32 BspHalAdaptSetAllRxPcGain(INT32 preAtt);
UINT32 BspHalAdaptSetRfGain(UINT32 uiRadioMode,INT32 iRfGain);
UINT32 BspHalAdaptSetInherentGain(UINT32 uiDifChan, UINT32 uiRadioMode, UINT32 uiCarrNo, INT32 iPreAtt);
UINT32 BspHalAdaptSetRxVgaInherentGain(UINT32 difChan, UINT32 radioMode, UINT32 carrIndex, INT32 preAtt);
UINT32 BspHalAdaptSetVgaMode(UINT32 mode);
UINT32 BspHalAdaptSetVgaModeByChan(UINT32 difChan, UINT32 mode);
UINT32 BspHalAdaptSetVgaAcInfoDbLut(UINT32 *vgaLutTab);
UINT32 BspHalAdaptGetVgaCompDlyToAC(UINT32 difChan, UINT32 carrIndex, UINT32 radioMode, UINT32 posId, UINT32 *dlyClk);
UINT32 BspHalAdaptSetRfBusRealValTab(UINT32 rfIdx, UINT32 *valTab, UINT32 lenTbl);
UINT32 BspHalAdaptSetIfBusRealValTab(UINT32 ifIdx, UINT32 *valTab, UINT32 lenTbl);
UINT32 BspHalAdaptSetVgaMgcSheets(UINT32 difChan, UINT32 *sheetTbl, UINT32 lenTbl);
UINT32 BspHalAdaptSetManualAtt(UINT32 difChan, UINT32 attVal);
UINT32 BspHalAdaptSetManualVga(UINT32 difChan, UINT32 vgaVal);
UINT32 BspHalAdaptInitIfBusPara(UINT32 ifIdx, T_BspHalAdaptIfBusPara *ifBusPara);
UINT32 BspHalAdaptSetIfRfSendTimeFlagCfg(T_BspHalAdaptTimeCfgPara *timeCfgPara);
UINT32 BspHalAdaptInitRfBusPara(UINT32 rfIdx, UINT32 rateSel);
UINT32 BspHalAdaptSetIfBusRoute(UINT32 rfIdx, UINT32 difChan, UINT32 mtsRx);
UINT32 BspHalAdaptSetRfBusRoute(UINT32 rfIdx, UINT32 difChan, UINT32 vgaCh);
UINT32 BspHalAdaptSetIfBusAddr(UINT32 rfIdx, UINT32 difChan, UINT32 addr);
UINT32 BspHalAdaptSetRfBusAddr(UINT32 rfIdx, UINT32 difChan, UINT32 addr);
UINT32 BspHalAdaptInitVgaBusPara(void);
UINT32 BspHalAdaptInitVgaOeInput(UINT32 oE);
UINT32 BspHalAdaptInitVgaBusPara(void);



/**************************************************************************
 *                              DPD相关调用接口
 *************************************************************************/
typedef T_DifDspRoute T_BspHalAdaptDspRouter;
UINT32 BspHalAdaptGetDspRouteInfo(UINT32 difchan,UINT32 band,T_BspHalAdaptDspRouter *pDspRouter);


/**************************************************************************
 *                            光口SERDES&PCS相关&ECPRI
 *************************************************************************/
#define OPT_SERDES_LANE_MAX_NUM (4)
#define OPT_PCS_LANE_MAX_NUM    (4)

//#define OPT_MAX_ROE_CW_NUM (CW_CHN_MAX_TPE) /* 目前使用4个控制字，上行2个，下行2个 */
//#define OPT_MAX_ROE_CW_FLOW_NUM (256)

//#define OPT_ROE_CW_FLOW_CHIP_OFFSET  (4)
//#define OPT_ROE_ERS_FLOW_ID_0        (1)
//#define OPT_ROE_HI_POW_FLOW_ID_0     (1)
enum E_CPRI_MODE_TYPE_LIST
{
    E_SGMII_MODE_SERDES_1P25G,
    E_CPRI_MODE_SERDES_24P3G,
    E_CPRI_MODE_TYPE_MAX,
};

enum E_CPRI_MODE_SERDES_LINKPROP_TYPE
{
    E_SERDES_LINK_PROP_DOWNLINK,
    E_SERDES_LINK_PROP_UPLINK,
    E_SERDES_PROP_TYPE_MAX,
};

enum _E_OPT_SERDES_INIT_STAT
{
    E_OPT_SERDES_PREPCS = 0,
    E_OPT_SERDES_PCS,
    E_OPT_SERDES_LOADFW,
    E_OPT_SERDES_TXINIT,
    E_OPT_SERDES_TXEQ,
    E_OPT_SERDES_RXINIT,
    E_OPT_SERDES_NORMAL,
    E_OPT_SERDES_APPRXINIT,
    E_OPT_SERDES_APPNORMAL,    
    E_OPT_SERDES_INIT_MAX
};
enum _E_OPT_CPRI_PARA_TYPE
{
    E_PARA_LANE0UP,
    E_PARA_LANE1UP,
    E_PARA_LANE2UP,
    E_PARA_LANE1UP_LANE2DOWN,
    E_PARA_LANE2UP_LANE1DOWN,
    E_PARA_LANE1UP_LANE3DOWN,
    E_PARA_LANE0UP_LANE1DOWN,
    E_PARA_LANE1UP_LANE23DOWN,
    E_PARA_LANE2DOWN,
    E_PARA_LANE3DOWN,
    E_PARA_PARA_NUM,
};
/*eth*/
#define SERDES_RATE_1G25  (1250000)
#define SERDES_RATE_10G31 (10312500U)
#define SERDES_RATE_25G78 (25781250U)
#define SERDES_RATE_53G12 (53125000U)

/*cpri*/
#define SERDES_RATE_6G14  (6144000U)
#define SERDES_RATE_9G83  (9830400U)
#define SERDES_RATE_10G13 (10137600U)
#define SERDES_RATE_24G33 (24330240U)
#define OPT_RATE_TYPE (4)
    
typedef enum E_SERDES_IDS {
    SERDES_ID_0 = 0,
    SERDES_ID_1,
    SERDES_ID_2,
    SERDES_ID_3,
    SERDES_ID_BUFF
} E_SERDES_IDS;

typedef enum E_SERDES_LANE_IDS {
    SERDES_LANE_0 = 0,
    SERDES_LANE_1,
    SERDES_LANE_2,
    SERDES_LANE_3,
    SERDES_LANE_ID_BUFF
} E_SERDES_LANE_IDS;

typedef struct  T_SERDES_PARAM {
    UINT32 serdesId;
    UINT32 laneId;
    UINT32 rate;  /* 速率 */
    DOUBLE chlen; /* 电信号差损值 */
    INT32 txEqEn; /* 预加重参数是否使能 */
    INT32 eoh0;   /* 预加重参数 */
    INT32 eoh1;   /* 预加重参数 pre */
    INT32 eoh2;   /* 预加重参数 main */
    INT32 eoh3;   /* 预加重参数 post */
} T_SERDES_PARAM;

/*pma RX初始化参数配置表*/
typedef struct
{
    UINT32 rate;  /* 速率 */
    DOUBLE chlen; /* 电信号差损值 */
    INT32 txEqEn; /* 预加重参数是否使能 */
    INT32 eoh0;   /* 预加重参数 */
    INT32 eoh1;   /* 预加重参数 pre */
    INT32 eoh2;   /* 预加重参数 main */
    INT32 eoh3;   /* 预加重参数 post */
}T_BspHalAdaptSerdesTxCfg;   /*pcs通道配置表*/
typedef T_NtlPortCfg T_BspHalAdaptNtlPortCfg;
/*typedef T_TRPG_GROUP_MODE_CFG T_BspHalAdaptNtlTrxpCfg;*//*ecpri使用先屏蔽*/
typedef T_PCS_CONFIG_TBL T_BspHalAdaptPcsCfg;
/*typedef T_NtlCwChnCfg T_BspHalAdaptNtlCwChnCfg;*//*ecpri使用先屏蔽*/
typedef T_OPT_SERDES_RX_INIT_PARA T_BspHalAdaptSerdesRxCfg;
typedef T_M0RINGSWITCHINFO T_BspHalAdaptM0RingInfoCfg;
typedef struct  T_OPTRATE_SERDES_PARAM {
	T_BspHalAdaptSerdesTxCfg txRatePara[OPT_RATE_TYPE];   /*针对不同光口速率可能有不同的参数，新增参数，在原有参数基础上修改波及较多且不易理解，直接新增*/
	T_BspHalAdaptSerdesRxCfg rxRatePara[OPT_RATE_TYPE];
	T_BspHalAdaptSerdesTxCfg txRateParaEx[OPT_RATE_TYPE];
} T_OPTRATE_SERDES_PARAM;
typedef struct  T_OPT_SERDES_PCS_PARAM {
	UINT32 laneMask;
	T_SERDES_PARAM serdesParam[OPT_SERDES_LANE_MAX_NUM]; /*一片IC 最大2个serdes ip核，每个ip核最大4条lane*/
	T_BspHalAdaptSerdesRxCfg serdesRxCfg[OPT_SERDES_LANE_MAX_NUM];  /*RX lane配置参数*/
	T_BspHalAdaptPcsCfg pcsCfg[OPT_PCS_LANE_MAX_NUM]; /*注意serdes是funclib分别初始化每条lane 而pcs是整体参数传下去hal分别初始化*/
    T_OPTRATE_SERDES_PARAM optRatePara;
    UINT32 innerLanMask;                                /*片间lane的掩码*/
} T_OPT_SERDES_PCS_PARAM;

typedef struct  T_OPT_INNER_SERDES_PCS_PARAM {
    T_SERDES_PARAM serdesParam[OPT_SERDES_LANE_MAX_NUM];
    T_BspHalAdaptSerdesRxCfg serdesRxCfg[OPT_SERDES_LANE_MAX_NUM];
    T_BspHalAdaptPcsCfg pcsCfg[OPT_PCS_LANE_MAX_NUM];
} T_OPT_INNER_SERDES_PCS_PARAM;

typedef T_OPT_ROE_INIT_PARA T_BspHalAdaptOptRoeInitPara;

UINT32 BspHalAdaptPcsInit(T_BspHalAdaptPcsCfg *pcsCfg,UINT32 laneNum);
UINT32 BspHalAdaptSetFlowTokenEnPathEnDisable(T_BspHalAdaptPcsCfg *pcsCfg, UINT32 laneNum);
UINT32 BspHalAdaptPcsFlowTokenEn(UINT32 ulPhyOpt, UINT32 ulSwitch);
UINT32 BspHalAdaptQcellAdaptGetOptLinkStatus(VOID);
UINT32 BspHalAdaptPcsSetPostGloableCfgEn(UINT32 ulPhyOpt, UINT32 ulSwitch);
UINT32 BspHalAdaptPcsPreInit(T_BspHalAdaptPcsCfg *pcsCfg,UINT32 laneNum);
UINT32 BspHalAdaptSerdesLoadFw(T_SERDES_PARAM *serdesCfg, UINT32 laneNum);
UINT32 BspHalAdaptSerdesTxInit(T_SERDES_PARAM *serdesCfg, UINT32 laneNum);
UINT32 BspHalAdaptSerdesRxInit(T_SERDES_PARAM *serdesCfg, T_BspHalAdaptSerdesRxCfg *serdesRxCfg,UINT32 laneNum);
UINT32 BspHalAdaptLycaRxDataNrzEn(UINT32 serdesId, UINT32 laneId, UINT32 ulSwitch);
UINT32 BspHalAdaptSerdesChgNormal(T_SERDES_PARAM *serdesCfg, UINT32 laneNum);
//UINT32 BspHalAdaptNtlL2ssSetTrxpMode(T_BspHalAdaptNtlTrxpCfg *ptTrxpModeCfg,UINT32 num);
//UINT32 BspHalAdaptNtlL2ssSetXmacCfg(T_BspHalAdaptNtlPortCfg *ptNtlPortCfg,UINT32 num);
VOID BspHalAdaptOptSerdesInitStatusClr(VOID);

UINT32 BspHalAdaptPcsGetLinkPcsSta(UINT32 ulPhyOpt, UINT32 *pStatus);
UINT32 BspHalAdaptLycaInitRx(UINT32 serdesId, UINT32 laneId,T_BspHalAdaptSerdesRxCfg *serdesRxCfg);
UINT32 BspHalAdaptLycaTccSwitch(UINT32 serdesId, UINT32 laneId);
UINT32 BspHalAdaptSetSerdesTxEq(T_SERDES_PARAM *serdesCfg, UINT32 laneNum);
UINT32 BspHalAdaptLycaGetCdrStatus(UINT32 serdesId, UINT32 laneId);
UINT32 BspHalAdaptOptSdsCheckError(UINT32 serdesId, UINT32 laneId, E_LYCA_PRBS_MODE mode, UINT32 sw, UINT32 clr);
UINT32 BspHalAdaptOptSdsSendPrbs(UINT32 serdesId, UINT32 laneId, E_LYCA_PRBS_MODE mode, UINT32 sw);
//UINT32 BspHalAdaptSetEcpriCwChnCfg(T_BspHalAdaptNtlCwChnCfg *ptNtlCwChnCfg, UINT32 uNum);
//UINT32 BspHalAdaptSetFastErsCfg(VOID);
UINT32 BspHalChangeSerdesTxLaneRate(UINT32 serdesId,UINT32 laneId,UINT32 rate,T_OPTRATE_SERDES_PARAM *pSerdesPara);
UINT32 BspHalChangeSerdesRxLaneRate(UINT32 serdesId,UINT32 laneId,UINT32 rate,T_OPTRATE_SERDES_PARAM *pSerdesPara);
UINT32 BspHalAdaptGetLycaSerdesRate(UINT32 serdesId, UINT32 laneId, UINT32 *pRate);
UINT32 BspHalAdaptPcsSetGloableCfgEn(UINT32 ulPhyOpt, UINT32 ulSwitch);   /*pcs配置使能*/
UINT32 BspHalAdaptPcsSetLinkProtocol(UINT32 ulPhyOpt, UINT32 protocal) ;
UINT32 BspHalAdaptPcsSetLinkFecMode(UINT32 ulPhyOpt, UINT32 fecMode);
UINT32 BspHalAdaptPcsEventOutCtrlEn(UINT32 phyOpt, UINT32 *enSta);
UINT32 BspHalAdaptPcsGetLinkFecMode(UINT32 ulPhyOpt, UINT32 *pfecMode);
UINT32 BspHalAdaptPcsSet1XLinkCfgEn(UINT32 ulPhyOpt, UINT32 ulDir, UINT32 ulSwitch) ;
UINT32 BspHalAdaptTrxpEnOrDisable(UINT32 xmacId, UINT32 en);
UINT32 BspHalAdaptXmacEnOrDisable(UINT32 xmacId, UINT32 en);
UINT32 BspHalAdaptlXmacGetPortSpeed(UINT32 xmacId);
UINT32 BspHalAdaptNtlL2ssPortVlanDebugCfg(VOID);
UINT32 BspHalAdaptNaccXmacInit(T_XmacDrvParam * ptXmacDrvParam);
VOID BspHalAdaptNtlL2ssSetSlaveFlag(UINT32 flag);
UINT32 BspHalAdaptNtlL2ssInitVlanCfg(UINT32 workMode);
UINT32 BspHalAdaptNtlL2ssInit(T_OptInitPara *pOptInitPara);
UINT32 BspHalAdaptL2ssTrxpGetEn(UINT32 udPortNum, UINT32 udDirection);
UINT32 BspHalAdaptSetUWBL2ssVlan(VOID);
UINT32 BspHalAdaptSetLaneSavingFlag(UINT32 flag);
UINT32 BspHalAdaptGetLaneSavingFlag(VOID);
UINT32 BspHalAdaptNtlL2ssTrxpEnOrDisBitmap(UINT64 protBitmap, UINT64 maskBitmap);
UINT32 BspHalAdaptGetPathPara(UINT32 *pPathPara, UINT32 byteNum);
UINT32 BspHalAdaptGetCarrCopyFlag(UINT32 bspChan, UINT32 dir, UINT32 carrNo, UINT32 radioMode, UINT32 *pCarrCopyFlag);
#if 0
/***************************** pad 相关 ******************************/
UINT32 BspHalAdaptInitPadFuncSel(T_BspHalAdaptPadFuncSelPara* padFunSelPara);
UINT32 BspHalAdaptInitPadCfgDone(T_BspHalAdaptPadCfgDonePara* padCfgDonePara);
UINT32 BspHalAdaptInitPadSingleDsCfg(UINT32 padId, UINT32 regVal);
UINT32 BspHalAdaptInitPadSinglePullUpCfg(UINT32 padId, UINT32 regVal);
UINT32 BspHalAdaptInitPadSingleFuncSel(UINT32 padId, UINT32 regVal);
UINT32 BspHalAdaptInitPadSingleCfgDone(UINT32 padId, UINT32 regVal);

#endif

#define BSP_QCELL_PCS_MASK              (0x3f)  

UINT32 BspHalAdaptGetLogOpt(UINT32 ulPhyNo);
UINT32 BspHalAdaptRoeQcellAdjust(UINT32 uRate);
UINT32 BspHalAdaptRoeSetQcellEthAdjust(UINT32 ulQcellChan);
UINT32 BspHalNtlXmacCtrl(E_OPT_WORKMODE e_OptWorkMode, UINT32 udXmacId, UINT32 udEnable);
UINT32 BspHalNtlXmacCfgPortSpeed(UINT32 udMacId, UINT32 udSpeed);
UINT32 BspHalAdaptGetPhyOpt(UINT32 ulLogNo);
UINT32 BspHalAdaptSetCpriProtocol(UINT32 ulProtocol);
UINT32 BspHalAdaptCpriCfgTransQcellRruId(UINT32 ulLogOptNo, UINT32 ulRruId);
UINT32 BspHalAdaptOptQcellHdResetInit(UINT32 ulSwitch);
UINT32 BspHalAdaptCpriCfgTransQcellLinkCtrlX(UINT32 ulLogOptNo, UINT32 ulLinkCtrlX);
UINT32 BspHalAdaptGetQcellLinkCtrlX(UINT32 ulLogOptNo);
UINT32 BspHalAdaptSetCpriNetMode(UINT32 ulNetMode);
UINT32 BspHalAdaptCheckUlCarryInfo(UINT32 uiBandWidth, UINT32 uiSampelRate, UINT32 uiCarrRadio);
UINT32 BspHalAdaptCheckDlCarryInfo(UINT32 uiBandWidth, UINT32 uiSampelRate, UINT32 uiCarrRadio);
UINT32 BspHalAdaptSetCpriRruType(E_CPRI_RRU_TYPE ulType);
UINT32 BspHalAdaptCpriCfgMux2FrmSel(UINT32 ulMux2FrmSel);
UINT32 BspHalAdaptCpriGetLineRate(UINT32 ulPhyNo,UINT32* ulSpeed);
UINT32 BspHalAdaptCpriCfgLineRate(UINT32 ulPhyNo,UINT32 ulSpeed);
UINT32 BspHalAdaptAxcArrangeTypeByBspRate(UINT32 ulPhyNo, UINT32 ulSpeed, UINT32 ulExternMode);
UINT32 BspHalAdaptCpriGetAxcArrangeType(UINT32 ulLogOptNo, UINT32 *pParitySeparate, UINT32 *pAxcChanNum);
UINT32 BspHalAdaptOptCpriCmInit(VOID);
UINT32 BspHalAdaptGetPPoint(UINT32 optPort);
UINT32 BspHalAdaptSetGlobleOutFrDir(UINT32 dir);
UINT32 BspHalAdaptSetCpriLineRate(UINT32 ulPhyNo,UINT32 ulSpeed);
UINT32 BspHalAdaptUpdateFrCfg(VOID);
UINT32 BspHalAdaptOptSwTblAssign(UINT32 uCfgNum, T_IQRecord_BSP *pPara);
UINT32 BspHalAdaptOptRachSwTblAssign(UINT32 tblNum, T_IQRecord_BSP *pTblInfo);
UINT32 BspHalAdaptOptCrsSwTblCfg(UINT32 uTblNum, T_IQRecord_Slave *pTblInfo);
UINT32 BspHalAdaptGetOptLopStatus(UINT32 ulPhyOpt);   /*物理光口状态机lop告警状态*/
UINT32 BspHalAdaptGetOptLofStatus(UINT32 ulPhyOpt) ;  /*物理光口状态机lof告警状态*/
UINT32 BspHalAdaptGetOptLosStatus(UINT32 ulPhyOpt) ;  /*物理光口状态机los告警状态*/
UINT32 BspHalAdaptGetCpriPhyOptAlm(UINT32 ulPhyOpt);   /*物理光口告警事件记录*/
UINT32 BspHalAdaptClrCpriPhyOptAlm(UINT32 ulPhyOpt,UINT32 ulAlmMask);   /*物理光口告警事件记录清楚，正常流程先清再读*/
UINT32 BspHalAdaptGetCpriLogOptAlm(UINT32 ulLogOpt);   /*逻辑光口告警事件记录*/
UINT32 BspHalAdaptClrCpriLogOptAlm(UINT32 ulLogOpt,UINT32 ulAlmMask) ;  /*逻辑光口告警事件记录清楚，正常流程先清再读*/
UINT32 BspHalAdaptGetCpriLogFsm(UINT32 ulLogOpt);
UINT32 BspHalAdaptGetCpriPhyFsm(UINT32 ulPhyOpt);
UINT32 BspHalAdaptGetCpriCdcResyncSta(UINT32 ulPhyOpt);
UINT32 BspHalAdaptGetSerdesFsmStatus(UINT32 ulPhyOpt);
UINT32 BspSetCfgTddLcvEnable(UINT32 ulMaskEn);
UINT32 BspOptManualSetLopAlarm(UINT32 ulLogicOpt, UINT32 softEn, UINT32 alarmEn);
UINT32 BspOptManualSetLosAlarm(UINT32 ulLogicOpt, UINT32 softEn, UINT32 alarmEn);
UINT32 BspOptManualSetLofAlarm(UINT32 ulLogicOpt, UINT32 softEn, UINT32 alarmEn);
UINT32 BspSetCpriCfgResetThres(UINT32 en, UINT32 thres);
UINT32 BspSetCpriCfgResetPdThres(UINT32 en, UINT32 thres);
UINT32 BspSetOptCwNetAlarmMask(UINT32 ulLogicOpt, UINT32 mask);
UINT32 BspSetCpriCfgCasTransMode(UINT32 cfgEn, UINT32 transMode);
UINT32 BspSetCpriCfgTransIrRruIdRange(UINT32 cfgEn, UINT32 isTrans);
UINT32 BspSetOptCpriSetFrameLoopBack(UINT32 logOptNo, UINT32 isSwitch);
UINT32 BspSetOptCpriCwOptBindCfg(UINT32 logOptNo, UINT32 logOptBindSel);
UINT32 BspSetOptCfgOptBindValid(UINT32 optBindValidEn, UINT32 optBindValidMask);
UINT32 BspSetUpDownLinkOptNum(UINT32 softEn, UINT32 upLinkNum, UINT32 downLinKNum);
UINT32 BspSetOptCpriGetRruLastStageFlag(UINT32 *isLastStage);
UINT32 BspSetOptGetCpriCwIrLosLof(UINT32 logOptNo);
UINT32 BspSetOptCpriRelation(UINT32 ulLogOptNo, UINT32 ulPhyOptNo, UINT32 ulCpuCfgEn);
UINT32 BspGetOptCpriRelation(UINT32 ulLogOptNo, UINT32 *ulPhyOptNo, UINT32 *ulCpuCfgEn);
UINT32 BspHalAdaptRoeIqSetFlowEnOrDis(UINT32 ulDir, UINT32 ulChanIndex, UINT32 ulFlowId, UINT32 ulEnOrDis);
UINT32 BspSetOptCpriCfgSfpTxDisable(UINT32 ulManualEn, UINT32 ulTransCfg);
UINT32 BspSetOptCpriCfgIoTxDisableMask(UINT32 uMask);
UINT32 BspHalAdaptCrmOptCpriLaneReset(UINT32 ulPhyOpt, UINT32 ulRstFlag);
UINT32 BspHalAdaptGetCpriFsmJumpCnt(UINT32 ulLogOpt);   /*物理光口状态机跳转次数计数，用以判断是否有跳转跃迁*/
UINT32 BspHalAdaptGetMainLogicOpt(UINT32 *mainLogicOpt);/*获取逻辑主光口号,实际是通过物理主光口号转换过来的*/
UINT32 BspHalAdaptGetMainPhyOpt(UINT32 *mainPhyOpt);   /*获取物理主光口号*/
UINT32 BspHalAdaptGetMainOptRruIndex(UINT32 *rruIndex); /*获取逻辑主光口的RRUINDEX控制字值*/
UINT32 BspHalAdaptSetDivClk(UINT32 chip,UINT32 speed,UINT32 div,UINT32 laneIdx);  /*设置crm恢复时钟接口 入参为物理光口对应的lane*/
UINT32 BspHalAdaptSetCrmOptCpriRefClkSoft(UINT32 laneIdx);   /*crm 恢复钟选择，入参为物理光口对应的lane*/
UINT32 BspHalAdaptSetOptAntEn(UINT32 dir, UINT32 enable);
UINT32 BspSetCrmOptCpriRefClkSoft(UINT32 laneIdx);
UINT32 BspHalAdaptGetCurrentFiberPort(VOID);
UINT32 BspHalAdaptGetCpriRruId(UINT32 logNo);
UINT32 BspHalAdaptGetIrRruId(UINT32 logNo);
UINT32 BspHalAdaptGetBbuFiberPort(UINT32 logNo);
UINT32 BspHalAdaptGetBbuCpriFiberPort(UINT32 logNo);
UINT32 BspHalAdaptGetTddUplinkLinkInd(VOID);
UINT32 BspHalAdaptGetTddUplinkRruIdRange(VOID);
UINT32 BspHalAdaptGetQcellRruId(UINT32 logNo);
UINT32 BspHalAdaptCrmCfgShortAlmDebounce(UINT32 nsbt0TimeUs, UINT32 nsbt1TimeUs, UINT32 rgpsTimeUs);
UINT32 BspHalAdaptCrmCfgShortAlmExtend(UINT32 nsbt0TimeUs, UINT32 nsbt1TimeUs, UINT32 rgpsTimeUs);
UINT32 BspHalAdaptCrmCfgShortAlmBreak(UINT32 nsbt0TimeUs, UINT32 nsbt1TimeUs, UINT32 rgpsTimeUs);
UINT32 BspHalAdaptSetRoeIqDemapperTimeMeasApi(UINT32 roeChan, UINT32 *pMaxChipNum);
UINT32 BspHalAdaptSetOptQcellInitApi(T_OPT_ROE_INIT_PARA *pOptRoeInitPara);
UINT32 BspHalAdaptOptPseudoIQCheck(UINT32 *pCellOkFlag);
UINT32 BspHalAdaptSetRoeQcellLinkRebuildApi(UINT32 roeChan);
UINT32 BspHalAdaptSetRoeCpriLinkRebuildApi(UINT32 roeChan);
UINT32 BspHalAdaptGetGfCheckFlag(VOID);
UINT32 BspHalAdaptSetCrmOptCrpiRefClkOeDisable(UINT32 laneIdx) ;
UINT32 BspHalAdaptSetCrmOptCrpiRefClkLogic(VOID);
UINT32 BspHalAdaptCrmOptGetCrpiRefClkSta(UINT32 laneIdx);
UINT32 BspHalAdaptCpriSelfAdaptProtect(UINT32 uProtect);
UINT32 BspHalAdaptCpriLsarResetCfg(UINT32 resetCfg);
UINT32 BspHalAdaptSetCrmRmtHardShSel(UINT32 rstSrc);
UINT32 BspHalAdaptSetCrmRmtPwdRstSrc(UINT32 uRstSrc);
UINT32 BspHalAdaptSetCrmOptECpriLaneSetDivClk(UINT32 chip,UINT32 speed,UINT32 laneIdx);
UINT32 BspHalAdaptOptRoeSetHdlcRate(VOID);
UINT32 BspHalAdaptGetOptHdlcRate(VOID);
UINT32 BspHalAdaptSoftenHdlcRateCapabilityCw(UINT32 hdlcRateCapability);
UINT32 BspHalAdaptRoeGetQcellFnb9PacketState(VOID);
UINT32 BspHalAdaptCpriGetStaCvCnt(UINT32 phyOpt);
UINT32 BspHalApiCpriSelAlignFr(VOID);
UINT32 BspHalAdaptCpriSetTxRxPPoint(UINT32 ulLogicOpt, UINT32 ulManualSwitch, UINT32 ulPPoint);
UINT32 BspHalAdaptCtrlM0SerdesRxinit(UINT32 sw);
UINT32 BspHalAdaptGetM0SerdesRxinitAck(VOID);
UINT32 BspHalAdaptSetM0SerdesRxInitInfo(UINT32 optIndex, T_M0RINGSWITCHINFO* info);
UINT32 BspHalAdapGetM0InitSerdesCnt(UINT32 *pCore0Start, UINT32 *pCore0End, UINT32 *pCore1Start, UINT32 *pCore1End);
UINT32 BspHalAdapGetGetM0RunStatus(UINT32 *pM0Core0Sta, UINT32 *pM0Core1Sta, UINT32 *pM0Core0Ctrl, UINT32 *pM0Core1Ctrl);
UINT32 BspHalAdaptSoftenRruIndexrCw(UINT32 uMode);
UINT32 BspHalAdaptSw2TblClr(VOID);
UINT32 BspHalAdaptReCfgSw2Tbl(VOID);
UINT32 BspHalAdaptCpriLastStageCm(UINT32 ulEnable);
UINT32 BspHalAdaptCpriSetTxRxPPoint(UINT32 ulLogicOpt, UINT32 ulManualSwitch, UINT32 ulPPoint);
UINT32 BspHalAdaptSwCfgIqCloseEn(UINT32 ulLogOptNo, UINT32 ulEn, UINT32 chnDir);
UINT32 BspHalAdaptCpriSetSerdesCdcRxStableWind(UINT32 ulPhyOptNo, UINT32 ulStbWndWid);
UINT32 BspHalAdaptCpriGetStaShcCvCnt(UINT32 phyOpt);
UINT32 BspSetPcsDataAlarmMask(UINT32 optNo, UINT32 almMask);
UINT32 BspSetPcsAmpAlarmMask(UINT32 optNo, UINT32 almMask);
UINT32 BspHalAdaptGetRoeTxRxCntInfo(UINT32 ulDir, UINT32 ulChanIndex);
UINT32 BspHalAdaptGetRoeTxRxErrInfo(UINT32 ulDir, UINT32 ulChanIndex);
UINT32 BspHalAdaptGetRoeCurProtocol(UINT32 chanIndex);
UINT32 BspHalAdaptGetOptProperty(UINT32 ulPhyOptNo, UINT32 *ulProperty, UINT32 *ulChipInterConn);
UINT32 BspHalAdaptCpriCfgOptProperty(UINT32 ulPhyOptNo, UINT32 ulProperty, UINT32 ulPropertyCfgEn, UINT32 ulChipInterConn);
UINT32 BspHalAdaptSetOptRstEn(UINT32 ulRstRequsetVal);
UINT32 BspHalAdaptSetOptRst(UINT32 ulRstRequsetVal);
UINT32 BSPHalAdaptDlinkSetSendData(UINT32 ulOptNo, UINT32 ulRegVal);
UINT32 BSPHalAdaptDlinkGetSendData(UINT32 ulOptNo, UINT32 *pData);
UINT32 BspHalAdaptOptCpriCfgCuMasterEn(UINT32 ulSwitch);
UINT32 BSPHalAdaptDlinkSetSendDataEn(UINT32 ulOptNo, UINT32 ulOptEn);
UINT32 BspHalAdaptCpriMapConfig(UINT32 ulSw, UINT32 ulHoldOver, UINT32 ulPhyOptNo);
UINT32 BspHalAdaptCpriOptBindSel(UINT32 ulLogOptNo, UINT32 ulLogOptSel);
UINT32 BspHalAdaptCpriSetFrTestMode(UINT32 ulLogOptNo, UINT32 ulTestMode);
UINT32 BspHalAdaptCpriCfgTxPriority(UINT32 ulLogOptNo, UINT32 ulPriorityCfg, UINT32 ulPriorityCfgEn);
UINT32 BspHalAdaptCpriCfgDlNetTrasBypass(UINT32 ulLogOptNo, UINT32 bypass);
UINT32 BspHalAdaptCpriCfgUlNetTrasBypass(UINT32 ulLogOptNo, UINT32 bypass);
UINT32 BspHalAdaptCpriCfgTulFixedValue(UINT32 val);
UINT32 BspHalAdaptCpriUlFrameAlignFrSel(UINT32 ulLogOptNo, UINT32 ulUlFrSel);
UINT32 BspHalAdaptGetRateDlyDelt(UINT32 ulBspRate);
UINT32 BspHalAdaptCpriClearCpriRstReq(VOID);
UINT32 BspHalAdaptSetPhyNoBySfpNo(UINT32 sfpNo,UINT32 phyNo);
UINT32 BspHalAdaptGetPhyNoBySfpNo(UINT32 sfpNo);
UINT32 BspHalAdaptCpriCfgTransLsarRstReqEn(UINT32 uCpuEn, UINT32 uTransSwitch);
UINT32 BspHalAdaptCpriCfgFecEn(UINT32 ulphyOptNo, UINT32 ulSwitch);
UINT32 BspHalAdaptCpriMapLcvOption(UINT32 ulphyOptNo,UINT32 uSrcSel);
UINT32 BspHalAdaptLycaAlgorithmSel(UINT32 ulAlgSel);
UINT32 BspHalAdaptBifGfCrmRxReset(void);   /*进行所有通道的CRM RX复位流程，解决Bif Gf总线挂死故障*/
UINT32 BspHalAdaptCpriSetFrTestMode(UINT32 ulLogOptNo, UINT32 ulTestMode);
UINT32 BspHalAdaptCpriGetFrTestMode(UINT32 ulLogOptNo, UINT32 *pulTestMode);
UINT32 BspHalAdaptCpriSetFrByLoadShare(UINT32 ulLogOptNo, UINT32 ulTestMode);
UINT32 BspHalAdaptCpriInternalLoopback(UINT32 ulLogOptNo, UINT32 ulTestMode);
UINT32 BspHalAdaptCpriCfgMidfreqAlmShutDataEn(UINT32 ulLogOptNo, UINT32 ulSwitch);
UINT32 BspHalAdaptCpriGetRruDirection(UINT32 *pRruDirection);
UINT32 BspHalApiUpdateScale(void);  
UINT32 BspHalAdaptCpriMidFreqBfnSel(UINT32 ulBfnSel);
UINT32 BspHalAdaptCpriPsyncBfnSel(UINT32 ulLogOptNo);
UINT32 BspHalAdaptSetSW2TXDownlinkFrSel(UINT32 baseOpt);
UINT32 BspHalAdaptCpriBifGfRxChanFr(UINT32 uMainLogOpt);
UINT32 BspHalAdaptGetCpriBifGfRxChanFr(void);
UINT32 BspHalAdaptCpriSetSW2FrDelay(void);
UINT32 BspHalAdaptCpri2PointFrSel(void);
UINT32 BspHalDifPaOffOptAlmMaskPaptCfg(UINT32 uMainLogOpt); /*UINT32 BspHalAdaptCpriCfgMidfreqAlmShutPaEn(UINT32 ulLogOptNo, UINT32 ulSwitch);等价*/
UINT32 BspHalAdaptCpriCfgCmUxSel(UINT32 ulCfgUx, UINT32 ulCmUxSel);
UINT32 BspHalAdaptCpriGetRxPPoint(UINT32 *pPoint);
UINT32 BspHalAdaptCfgSwSrcAlignFr(UINT32 ulFrSel);
UINT32 BspHalAdaptCfgPriorityCwMask(UINT32 ulPhyOptNo, UINT32 ulMaskEn);
UINT32 BspHalAdaptGetFddPriority(UINT32 ulPhyOptNo);
UINT32 BspHalAdaptGetOptSyncStatus(UINT32 ulPhyOptNo);
VOID BspHalAdaptSetMainPhyOpt(UINT32 mainPhyOpt, UINT32 dir);
VOID BspHalAdaptSetSleepCellMasterPort(UINT32 port);
UINT32 BspHalAdaptUlSleepCellCheck(UINT32 uiDifChan, UINT32 uiCarrId, UINT32 uiRadioMode);
UINT32 BspHalAdaptDlSleepCellCheck(UINT32 uiDifChan, UINT32 uiCarrId, UINT32 uiRadioMode);

UINT32 BspHalAdaptCheckBifCarrDly(T_OptDormantCellCfgInfo *pDlyCfgInfo);
UINT32 BspHalAdaptCheckGfCarrDly(T_OptDormantCellCfgInfo *pDlyCfgInfo);
UINT32 BspHalAdaptCheckDifCarrDly(T_OptDormantCellCfgInfo *pDlyCfgInfo);
UINT32 BspHalAdaptCheckFftCarrDly(T_OptDormantCellCfgInfo *pDlyCfgInfo);
UINT32 BspHalAdaptTxSleepCellCheckGate(UINT32 uiChanId, UINT32 uiCarrId, UINT32 uiRadioMode, UINT32 *puiErrFlg);
UINT32 BspHalAdaptRxSleepCellCheckGate(UINT32 uiChanId, UINT32 uiCarrId, UINT32 uiRadioMode, UINT32 *puiErrFlg);
UINT32 BspHalAdaptTxSleepCellCheckNco(UINT32 uiChanId, UINT32 uiCarrId, UINT32 uiRadioMode, UINT32 *puiErrFlg);
UINT32 BspHalAdaptRxSleepCellCheckNco(UINT32 uiChanId, UINT32 uiCarrId, UINT32 uiRadioMode, UINT32 *puiErrFlg);
UINT32 BspHalAdaptTxSleepCellCheckBank(UINT32 uiChanId, UINT32 uiCarrId, UINT32 uiRadioMode, UINT32 *puiErrFlg);
UINT32 BspHalAdaptRxSleepCellCheckBank(UINT32 uiChanId, UINT32 uiCarrId, UINT32 uiRadioMode, UINT32 *puiErrFlg);

UINT32 BspHalAdaptCfgTddLcvEnable(UINT32 maskEn);
UINT32 BspHalAdaptGetPimcBypass(UINT32 difChan, UINT32 *pPimcIsBypass, UINT32 *pPimcNum);
UINT32 BspHalAdaptGetOneFddValidChan(UINT32 *difChanId);
UINT32 BspHalAdaptGetFrTmValInChan(UINT32 difChan, UINT32 *pFrOffSetNs, UINT32 *pTddRamFrOffSetNs);
UINT32 BspHalAdaptGetDlCarrCompDly(UINT32 uiDifChan, UINT32 uiCarrId, UINT32 uiRadioMode, UINT32 *puiDlyNs);
UINT32 BspHalAdaptOptQcellInit(T_OPT_ROE_INIT_PARA *pOptRoeInitPara);
UINT32 BspHalAdaptOptRoeInitCfg(T_OPT_ROE_INIT_PARA *pOptRoeInitPara);
UINT32 BspHalAdaptUtdoaPsyncIrqCfg(UINT32 switchEnable);
UINT32 BspHalAdaptUtdoaGetCovertFlag(VOID);
UINT32 BspHalAdaptUtdoaSetCovertFlag(UINT32 convertFlag);
UINT32 BspHalAdaptSetUlTddClrEn(UINT32 bspChan, UINT32 carrId, UINT32 radioMode, UINT32 en);
UINT32 BspHalAdaptSetUlBankTddSw(UINT32 bspChan, UINT32 carrId, UINT32 radioMode, UINT32 en);
UINT32 BspHalAdaptOptRptFrAlmCnt(UINT32 ulLogOptNo);
UINT32 BspHalAdaptRoe2CpriFrMonitor();
VOID BspApiRebuildPsyncSyn(VOID);
UINT32 BspHalAdaptCpriSerdesGetLosCnt(UINT32 ulPhyOptNo);
UINT32 BspHalAdaptCpriSerdesGetLopCnt(UINT32 ulPhyOptNo);
UINT32 BspHalAdaptCpriSerdesGetLofCnt(UINT32 ulPhyOptNo);
UINT32 BspHalAdaptSoftCfgTxBbuport(UINT32 ulLogOpt, UINT32 ulCfgEn);
UINT32 BspHalAdaptCrmCfgShortAlmNsbt0(UINT32 debounceTimeUs, UINT32 extendTimeUs, UINT32 breakTimeUs);
UINT32 BspHalAdaptCrmCfgShortAlmNsbt1(UINT32 debounceTimeUs, UINT32 extendTimeUs, UINT32 breakTimeUs);
UINT32 BspHalAdaptCrmCfgShortAlmRgps(UINT32 debounceTimeUs, UINT32 extendTimeUs, UINT32 breakTimeUs);
UINT32 BspHalAdaptCrmGetShortAlmNsbt0(UINT32 *pDebounceTimeUs, UINT32 *pExtendTimeUs, UINT32 *pBreakTimeUs);
UINT32 BspHalAdaptCrmGetShortAlmNsbt1(UINT32 *pDebounceTimeUs, UINT32 *pExtendTimeUs, UINT32 *pBreakTimeUs);
UINT32 BspHalAdaptCrmGetShortAlmRgps(UINT32 *pDebounceTimeUs, UINT32 *pExtendTimeUs, UINT32 *pBreakTimeUs);
UINT32 BspHalAdaptGetCpriLastStageCmStatus(VOID);
/**************************************************************************
 *                    IC PIN管脚和Transceiver的映射关系
 *************************************************************************/
#define HALADAPT_TRANS_MAX_NUM  (2)

typedef struct _T_IC_TRX_PIN_MAP {
    UINT32 icPinId[HALADAPT_TRANS_MAX_NUM];
} T_IC_TRX_PIN_MAP;

UINT32 BspHalAdaptSetTrxPinMap(T_IC_TRX_PIN_MAP *p_TrxPinMap);
UINT32 BspHalAdaptGetTrxPinId(UINT32 TrxChipIdx, UINT32 *pPinId);




/**************************************************************************
 *                              PAPT相关调用接口
 *************************************************************************/
typedef enum TagE_CrmPaptAlarmType
{
    CRM_PAPT_ALM_RESET = 0,
    CRM_PAPT_ALM_PLL_ERR = 1,
    CRM_PAPT_ALM_BOARD_PWR_OFF = 2
} E_CrmPaptAlarmType;

#define DPDIC_PAPT_ALM_MASK (0xFFFFFF)           /* DPDIC4.2中功放保护共有24种告警  */
#define DPDIC_CRM_PAPT_ALM_MASK (0x3FFFFFF)      /* DPDIC4.2中CRM功放保护共有26种告警  */

#define CRM_PAPT_ALL_ALARM_MASK (DPDIC_CRM_PAPT_ALM_MASK)
#define CRM_PAPT_RESET_ALARM_MASK (0x88c000)
#define CRM_PAPT_PLL_ALARM_MASK (0x58)
#define CRM_PAPT_PWR_ALARM_MASK (0x1800)

#define IC_CRM_PAPT_BIT_INDEX  (20)
#define IC_CRM_PAPT_ALARM_MAX_NUM  (26)

typedef T_PaptParaInfoCfg T_BspHalAdaptPaptParaCfg;
typedef T_PaptCfrInfoCfg T_BspHalAdaptPaptCfrCfg;
typedef T_PaptDpdInfoCfg T_BspHalAdaptPaptDpdCfg;
/* 功放保护初始化 */
UINT32 BspHalAdaptPaptInit(UINT32 difChan, T_BspHalAdaptPaptParaCfg* pCfg);

/* 告警上报 */
UINT32 BspHalAdaptGetPaptMonitorRpt(UINT32 difChan, UINT32* pRcd);
    
/* 告警清除 */
UINT32 BspHalAdaptClrPaptMonitorRpt(UINT32 difChan, UINT32 alarmMask);
UINT32 BspHalAdaptClrPaptPaOffMonitorRpt(UINT32 difChan, UINT32 alarmMask);

/* 获取关功放告警使能状态 */
UINT32 BspHalAdaptGetPaptPaOffMask(UINT32 difChan, UINT32* pMask);

/* 获取关数据告警使能状态 */
UINT32 BspHalAdaptGetPaptDaOffMask(UINT32 difChan, UINT32* pMask);

/* 获取CRM功放告警使能掩码 */
UINT32 BspHalAdaptGetCrmPaptAlarmEnMask(VOID);

/* 获取CRM功放保护告警的具体类型 pAlarmTypeMask:bit位含义参考E_CrmPaptAlarmType */
UINT32 BspHalAdaptGetCrmAlarmType(UINT32 *pOrgAlarmMask, UINT32 *pAlarmTypeMask);

/* 清除CRM功放保护告警 pAlarmType:E_CrmPaptAlarmType */
UINT32 BspHalAdaptClrCrmAlarmType(UINT32 alarmType);

/* 清除全部CRM功放保护历史告警 */
UINT32 BspHalAdaptClrAllCrmAlarm(VOID);

/* CRM 清除关功放告警  */
UINT32 BspHalAdaptClrCrmPaAlm(E_CrmPaptAlarmType type);

/* CRM 清除关数据告警  */
UINT32 BspHalAdaptClrCrmDataAlm(E_CrmPaptAlarmType type);

/* CRM 获取历史告警 */
UINT32 BspHalAdaptGetCrmPastAlarm(E_CrmPaptAlarmType type);

/* CRM 获取实时告警 */
UINT32 BspHalAdaptGetCrmRealAlarm(E_CrmPaptAlarmType type);

/* 清除全部CRM功放保护历史告警 */
UINT32 BspHalAdaptClrAllCrmAlarm(VOID);

/* 功放保护导致的功率无效检测 */
UINT32 BspHalAdaptGetPowInvalidFlag(UINT32 difChan, UINT32* pFlag);

/* 功放保护导致的功率无效告警清除 */
UINT32 BspHalAdaptClrPowInvalidFlag(UINT32 difChan);

UINT32 BspHalAdaptPaptAvgPow(UINT32 difChan, T_BspHalAdaptPaptCfrCfg* pCfr, T_BspHalAdaptPaptDpdCfg* pDpd);
UINT32 BspHalAdaptCfgPaptUnus(UINT32 difChan, T_PaptUnusInfoCfg *pCfg);
UINT32 BspHalAdaptCfgHpfInfo(UINT32 difChan, T_PaptHpfInfoCfg *pCfg);



#if 0
/**************************************************************************
*                              J204相关
 *************************************************************************/

/**************************************************************************
*                              CRM相关
 *************************************************************************/
typedef struct _T_BspHalAdaptSocCrmClk{
    UINT32 dspClk;      /* DSP时钟频率 */
    /* 待扩展其他成员 */
}T_BspHalAdaptSocCrmClk;

UINT32 BspHalAdaptSetCrmSocClk(T_BspHalAdaptSocCrmClk *pClkCfg);
#endif
UINT32 BspHalAdaptClrCrmResetReason(UINT32 regId, UINT32 startBit, UINT32 endBit);
/**************************************************************************
*                              opt相关
 *************************************************************************/
typedef T_OptCpriInfo T_BspHalAdaptOptCpriInfo;
typedef T_PreAllocInfo T_BspHalAdaptOptPreAllocInfo;
typedef T_OptInitPara T_BspHalAdaptOptInitCfgInfo;
typedef struct  T_OPT_L2SSPARA{
    UINT64 key;
    UINT64 mask;
}T_OPT_L2SSPARA;
typedef struct  T_OPT_PATH_PARAM {
    T_BspHalAdaptOptCpriInfo  *pCpriInfo;
    T_OPT_SERDES_PCS_PARAM    *pSerdesPcsPara;
    T_OPT_L2SSPARA            *pL2ssBeforePara;
    T_OPT_L2SSPARA            *pL2ssAfterPara;
}T_OPT_PATH_PARAM;
enum _E_OPTCTRL_PREALLOC_SOURCE_TYPE
{
    TDDNR_SRC_TYPE,
    LTE_SRC_TYPE,
    FDDNR_SRC_TYPE,
    LTE_IF1_SRC_TYPE,
    PRE_ALLOC_INFO_TYPE,
};
enum _E_OPTCTRL_PREALLOC_TYPE
{
    TDD_PREALLOC_ONLY100MNR_SENCE,
    FDD_PREALLOC_SENCE,
    TDD_PREALLOC_60M20M_SENCE,
    TDD_PREALLOC_100M20M_SENCE,
    TDDFDD_PREALLOC_SENCE,
    TDD_PREALLOC_ONLY20MLTE_SENCE,
    TDD_PREALLOC_ONLY80MNR_SENCE,
    TDD_PREALLOC_100M20M_SENCE_IF1,
    FDD_PREALLOC_SENCE_IF1,
    TDDFDD_PREALLOC_SENCE_TLTE_IF1,
    TDDFDD_PREALLOC_SENCE_NCR,
};

typedef struct T_PreAllocBaseInfo

{
	UINT32 uMode;
	UINT32 uScs;
	UINT32 uAntNum;
	UINT32 uIfType;
	UINT32 uBw;
	UINT32 uAllocType;   /* GF侧资源规划， */
}T_PreAllocBaseInfo;

typedef struct tag_AllPreAllocInfo {
    UINT32 senceType;
    T_PreAllocBaseInfo preAllocInfo[PRE_ALLOC_INFO_TYPE];
} T_BspHalAdaptPreAllocCarrInfo;

typedef struct tag_PreAllocBoardPara {
    UINT32 ulType;  /*cpri/ecpri/qcell*/
    UINT32 ulAntMask;  /*UBR为真实天线数,上下行不对称的以大的为准*/
}T_BspHalAdaptPreAllocBoardPara;
typedef struct T_CellCarrInfo
{
    UINT32 carrNo;        /* 逻辑载波号      */
    UINT32 radioMode;     /* 载波制式        */
    UINT32 freq;          /* 载波频率kHz     */
    UINT32 bandWidth;     /* 载波带宽单位kHz  */
    UINT32 delOrAddFlag;  // 增删标志 (0:保持 1:增加 2:删除 3:修改)
    UINT32 chanNo;        /* 载波的天线号     */
    UINT32 ifType;        /* 载波的IF类型     */
    UINT32 carrScs;       /* 载波的子载波间隔  */
} T_CellCarrInfo;
/*最大预制载波数*/
#define  MAX_ALL_CARR_NUM   (48)
typedef struct T_ChanGroupCellCarrInfo
{
	UINT32         carrNum;
    T_CellCarrInfo carrInfo[MAX_ALL_CARR_NUM];
} T_BspHalAdaptAllCellCarrInfo;/*高层下发的,过滤掉gun之后的载波信息*/


typedef struct T_CarrInfoOfCell
{
    UINT32 carrNo;        /* 逻辑载波号      */
    UINT32 radioMode;     /* 载波制式        */
    UINT32 freq;          /* 载波频率kHz     */
    UINT32 bandWidth;     /* 载波带宽单位kHz  */
    UINT32 chanMask;      /* 载波的天线掩码   */
} T_CarrInfoOfCell;

typedef struct T_GroupCellCarrInfo
{
	UINT32     carrNum;
    T_CarrInfoOfCell carrInfo[MAX_ALL_CARR_NUM];
} T_GroupCellCarrInfo;

typedef struct T_AllChanCarrMapRet {
    UINT32 carrNum;  //仅上报本身没变化但是因为载波交换而受影响的载波
    T_PreAllocCarrResult preAllocResult[MAX_ALL_CARR_NUM];
} T_BspHalAdaptAllChanCarrMapRet;

UINT32 BspHalAdaptOptCpriParamInit(T_BspHalAdaptOptCpriInfo* optInitCpriCfgInfo);
UINT32 BspHalAdaptOptCpriInit(VOID);
UINT32 BspHalAdaptMeasureInit(UINT32 uCpriOrEcpri);
UINT32 BspHalAdaptLycaSetTxFirCoff(UINT32 serdesId, UINT32 laneId, UINT32 eoh0, UINT32 eoh1, UINT32 eoh2, UINT32 eoh3);
UINT32 BspHalAdaptLycaLoadFw(UINT32 serdesId, UINT32 laneId);
UINT32 BspHalAdaptLycaInitTx(UINT32 serdesId, UINT32 laneId, UINT32 rate, DOUBLE ldb);
UINT32 BspHalAdaptTestLycaInitRx(UINT32 serdesId, UINT32 laneId, INT8 phaseMin, INT8 phaseMax, UINT32 uVga, UINT32 uCmtermCtrl);
UINT32 BspHalAdaptOptInit(T_BspHalAdaptOptInitCfgInfo* optInitCfgInfo);
UINT32 BspHalAdaptSetResPreAllocPara(UINT32 uCprType, UINT32 uAntMask);
UINT32 BspHalAdaptOptCellDelte(UINT32 cellId);
UINT32 BspHalAdaptOptCpriSetCrcMask(UINT32 logicOpt, UINT32 subChanMaskHig32bit, UINT32 subChanMaskLow32bit);
UINT32 BspHalAdaptOptGFAxiTest(VOID);

//UINT32 BspSetPadLvdsFrameHead(UINT32 padName, UINT32 value);
//UINT32 BspSetPadLvdsFuncSel(UINT32 padName, UINT32 value);

UINT32 IcHalApiSetLvdsCfg(UINT32 halPadName, UINT32 value);
UINT32 IcHalApiGetLvdsCfgVal(UINT32 halPadName, UINT32  *value);
UINT32 IcHalApiSetLvdsPadCfg(UINT32 halPadName, UINT32 value);
UINT32 IcHalApiGetLvdsPadVal(UINT32 halPadName, UINT32 * value);

UINT32 BspHalAdaptGetAwRpt(UINT32 *puiAwRpt);
/**************************************************************************
*                              配频相关
 *************************************************************************/
typedef struct tag_BspAdaptOneChanCarrInfo
{
    UINT32 difChanNo;
    UINT32 carrNum;
    T_BspHalAdaptCarrInfo oneCarrInfo[BSP_MAX_CARR_NUM * 2];
}T_BspAdaptOneChanCarrInfo;

typedef struct tagT_Adapt_Chan_Info
{
    UINT32                   chanNum;
    T_BspAdaptOneChanCarrInfo chanInfo[BSP_HALADAPT_IC_CHAN_MAX_NUM];
} T_BspHalAdaptChanInfo;

UINT32 BspHalAdaptSetSwpPowThr(UINT32 uiPowThr);
UINT32 BspHalAdaptSetUmtsDlBw(UINT32 difChan, UINT32 carrIndex, UINT32 radioMode, UINT32 umtsBw);
UINT32 BspHalAdaptSetUmtsDlNcoFront(UINT32 difChan, UINT32 carrIndex, UINT32 radioMode, INT32 offset);
UINT32 BspHalAdaptSetUmtsDlNcoBehind(UINT32 difChan, UINT32 carrIndex, UINT32 radioMode, INT32 offset);
UINT32 BspHalAdaptGetUmtsDlBw(UINT32 difChan, UINT32 radioMode, UINT32 umtsBw);
UINT32 BspHalAdaptGetDlBw(UINT32 difChan, UINT32 radio, UINT32 bandWidth);
UINT32 BspHalAdaptSetTxCarrCfirNcoCoef(UINT32 difChan, UINT32 carrNo, UINT32 radioMode, UINT32 bandWidth);
UINT32 BspHalAdaptSetTxCarrCfirNcoFront(UINT32 difChan, UINT32 carrNo, UINT32 radioMode, INT32 swFreqOffset);
UINT32 BspHalAdaptSetTxCarrCfirNcoBehind(UINT32 difChan,UINT32 carrNo, UINT32 radioMode, INT32 offset);
UINT32 BspHalAdaptTxAnalysis(T_BspHalAdaptChanInfo *ptTxChanInfo, T_DifChanInfo *ptTxFailChanInfo);
UINT32 BspHalAdaptRxAnalysis(T_BspHalAdaptChanInfo *ptRxChanInfo, T_DifChanInfo *ptRxFailChanInfo);
UINT32 BspHalAdaptTxAnalysisDuc0(T_BspHalAdaptChanInfo *ptTxChanInfo);
UINT32 BspHalAdaptTxAnalysisDuc0Rpt(T_BspHalAdaptChanInfo *ptTxChanInfo, T_BspHalAdaptChanInfo *ptFailTxChanInfo, UINT32 flag);
UINT32 BspHalAdaptRxAnalysisDdc0(T_BspHalAdaptChanInfo *ptRxChanInfo);
UINT32 BspHalAdaptRxAnalysisDdc0Rpt(T_BspHalAdaptChanInfo *ptRxChanInfo, T_BspHalAdaptChanInfo *ptFailRxChanInfo, UINT32 flag);
UINT32 BspHalAdaptGetPreAllocListInfo(T_BspHalAdaptPreAllocCarrInfo **ptAllocList,UINT32 *num);
UINT32 BspHalAdaptResourceAllocClr(UINT32 dir);
UINT32 BspHalAdaptResourceAllocCfg(UINT32 dir, UINT32 rfChan, T_RfChanCfgEn *pRfChanCfgEn, T_DifCarrInfoCfg *ptFailCarrCfgInfo);
UINT32 BspHalAdaptGetRealBw(UINT32 dir, UINT32 difChan, UINT32 carrId, UINT32 radioMode, UINT32 *pRealBw);
UINT32 BspHalAdaptGetPreAllocCarrMapResult(T_CellCarrInfo* appCarrCfg, T_BspHalAdaptPreAllocCarrInfo* preAllocBwInfo, T_PreAllocCarrResult* presetCarrMapRet);
T_BspAdaptOneChanCarrInfo *BspHalAdaptGetDifChanCarrInfo(UINT32 dir, UINT32 difChan);
UINT32 BspHalAdaptSetTsgTdmInfo(T_TsgTdmInfo *ptTdmInfo);
UINT32 BspHalAdaptResourceAllocRpt(UINT32 dir, T_BspHalAdaptChanInfo *ptTxChanInfo);
UINT32 BspHalAdaptSetTsgSelfTestInfo(T_TsgSelfTestInfo *ptSelfTestInfo);

UINT32 BspHalAdaptGetUlBw(UINT32 difChan, UINT32 radio, UINT32 bandWidth);
UINT32 BspHalAdaptSetRxCarrCfirNcoCoef(UINT32 difChan, UINT32 carrNo, UINT32 radioMode, UINT32 bandWidth);
UINT32 BspHalAdaptSetRxCarrCfirNcoFront(UINT32 difChan, UINT32 carrNo, UINT32 radioMode, INT32 swFreqOffset);
UINT32 BspHalAdaptSetRxCarrCfirNcoBehind(UINT32 difChan, UINT32 carrNo, UINT32 radioMode, INT32 offset);
/**************************************************************************
*                              TDD 帧头相关
 *************************************************************************/
typedef T_DifFrTypeCfg T_BspHalAdaptFrTypeCfg;
UINT32 BspHalAdaptSetFrSelect(UINT32 difChan, T_BspHalAdaptFrTypeCfg *pFrTypeCfg);
UINT32 BspHalAdaptSetFrSelectByDir(UINT32 difChan, UINT32 dir);
UINT32 BspHalAdaptSetFrGenerate(UINT32 frSource, UINT32 frPeriod, UINT32 frNumSource);
UINT32 BspGetSynPsyncFrameNo(VOID);
UINT32 BspSetSynPsyncSuperFrameNo(UINT32 superFrameNo);
UINT32 BspHalAdaptGetSynPsyncSuperFrameNo(VOID);

/**************************************************************************
*                              功率控制相关
 *************************************************************************/
typedef T_PowChk_Cfg T_BspHalAdaptPowChk;
typedef T_GsmRssiCfg T_BspHalAdaptGsmPowChk;
UINT32 BspHalAdaptReadRssiPowValue(UINT32 difChan, UINT32 carrIndex, UINT32 radioMode, UINT32 slotId, UINT32 uiRssiType, INT32 *pRssiPow);
UINT32 BspHalAdaptSetGsmPowLevel(UINT32 difChan, UINT32 carrIndex, UINT32 PowLevel);
UINT32 BspHalAdaptPowCalcInit(T_BspHalAdaptPowChk *tPowChkCfg);
UINT32 BspHalAdaptGsmPowCalcInit(T_BspHalAdaptGsmPowChk *tPowChkCfg);
UINT32 BspHalAdaptSetIfTssiPwrClr(UINT32 uiDifChan);
UINT32 BspHalAdaptSetNbicSwitch(UINT32 difChan, UINT32 carrIndex, UINT32 radioMode, UINT32 sw);
UINT32 BspHalAdaptGetNbicSwitch(UINT32 difChan, UINT32 carrIndex, UINT32 radioMode, UINT32 *pSw);
UINT32 BspHalAdaptGetNbicIq(UINT32 difChan, UINT32 carrIndex, UINT32 radioMode, UINT32 len, UINT32 *iqArray);
UINT32 BspHalAdaptSetNbicAccClr(VOID);
UINT32 BspHalAdaptSetNbicPowThr(UINT32 uiPowThr);
UINT32 BspHalAdaptSetLongRssiGroup(UINT32 state);
/**************************************************************************
                            SOC相关接口
**************************************************************************/
UINT32 BspHalAdaptGetIcChipId(UINT32 *pChipIdx);

/**************************************************************************
*                              反馈电子开关控制相关接口
 *************************************************************************/
#define MAX_CB_SW_NUM                (2)

typedef T_SwInitCfg T_BspHalAdaptCbSwPara;
typedef T_SwStaRam T_BspHalAdaptCbSwStaTbl;
typedef T_SwRfRam T_BspHalAdaptCbSwRfTbl;
UINT32 BspHalAdaptCbSwParaInit(UINT32 swIndex,T_BspHalAdaptCbSwPara* ptCbSwPara);
UINT32 BspHalAdaptCbSwStaTblInit(UINT32 swIndex, T_BspHalAdaptCbSwStaTbl* ptSwStaTbl, UINT32 len);
UINT32 BspHalAdaptCbSwRfTblInit(UINT32 swIndex, UINT32 rfType,T_BspHalAdaptCbSwRfTbl* ptSwRfTbl);
UINT32 BspHalAdaptCbSwForceModeOn(UINT32 swInex, UINT32 chan, UINT32 sta, UINT32 period);
UINT32 BspHalAdaptCbSwForceModeOff(UINT32 swIndex,UINT32 chan);
UINT32 BspHalAdaptCbPinSw(UINT32 pinName, UINT32 sw);
/**************************************************************************
*                              tddio 控制相关接口
 *************************************************************************/
typedef struct
{
	UINT32 uiAlarmEn;      /**pa和lna互斥来源选择**/
	T_TDD_BASE_SW_OUT_CFG  uiBaseCfg;
} T_TDD_BASE_PALNAAMP_OUT_CFGA;
UINT32 BspHalAdaptSetPaLnaBaseGenSel(T_TDD_BASE_TIMING_GEN_SEL *tPara, UINT32 uiTddIdx);
UINT32 BspHalAdaptSetAmpBaseGenSel(T_TDD_BASE_TIMING_GEN_SEL *tPara, UINT32 uiTddIdx);
UINT32 BspHalAdaptSetTransBaseGenSel(T_TRX_BASE_TIMING_GEN_SEL *tPara, UINT32 uiTddIdx);
UINT32 BspHalAdaptSetAcCtrlBaseGenSel(T_AC_CTRL_TIMING_GEN_SEL *tPara, UINT32 uiTddIdx, UINT32 uiIoIdx);
UINT32 BspHalAdaptSetPaLnaPara(T_PA_LNA_CFG *tPara, UINT32 uiTddIdx);
UINT32 BspHalAdaptSetAmpPara(T_AMP_CFG *tPara, UINT32 uiTddIdx);
UINT32 BspHalAdaptSetTransPara(T_TRANS_CFG *tPara, UINT32 uiTddIdx);
UINT32 BspHalAdaptSetAcCtrlPara(T_AC_CTRL_CFG *tPara, UINT32 uiTddIdx, UINT32 uiIdx);
UINT32 BspHalAdaptSetAcCtrlFddPara(T_AC_CTRL_FDD_CFG *tPara, UINT32 uiTddIdx, UINT32 uiIdx);
UINT32 BspHalAdaptSetAcCtrlModeMapSel(UINT32 uiTddIdx, UINT32 uiMode);
UINT32 BspHalAdaptSetPaOutSel(UINT32 uiIdx, UINT32 uiSel);
UINT32 BspHalAdaptSetPaTdd4Sel1(UINT32 uiIdx, UINT32 uiSel);
UINT32 BspHalAdaptSetPaUeOut2Sel1(UINT32 uiIdx, UINT32 uiSel);
UINT32 BspHalAdaptSetPaDtxCombEn(UINT32 uiIdx, UINT32 uiDtxEn);
UINT32 BspHalAdaptSetPaMuxPara(T_TDD_BASE_PALNAAMP_OUT_CFGA *tPara, UINT32 uiIdx);
UINT32 BspHalAdaptSetLnaAlarmEn(UINT32 uiIdx, UINT32 uiEnMask);
UINT32 BspHalAdaptSetLnaMuxPara(T_TDD_BASE_PALNAAMP_OUT_CFGA *tPara, UINT32 uiIdx);
UINT32 BspHalAdaptSetAmpOutSel(UINT32 uiIdx, UINT32 uiSel) ;
UINT32 BspHalAdaptSetAmpTdd4Sel1(UINT32 uiIdx, UINT32 uiSel) ;
UINT32 BspHalAdaptSetAmpUeOut2Sel1(UINT32 uiIdx, UINT32 uiSel);
UINT32 BspHalAdaptSetAmpDtxCombEn(UINT32 uiIdx, UINT32 uiDtxEn);
UINT32 BspHalAdaptSetAmpMuxPara(T_TDD_BASE_PALNAAMP_OUT_CFGA *tPara, UINT32 uiAmpIdx);
UINT32 BspHalAdaptSetTxEnOutSel(UINT32 uiIdx, UINT32 uiSel);
UINT32 BspHalAdaptSetTxEnTdd4Sel1(UINT32 uiIdx, UINT32 uiSel);
UINT32 BspHalAdaptSetTxEnUeOut2Sel1(UINT32 uiIdx, UINT32 uiSel) ;
UINT32 BspHalAdaptSetTxEnDtxCombEn(UINT32 uiIdx, UINT32 uiDtxEn) ;
UINT32 BspHalAdaptSetTransTxMuxPara(T_TDD_BASE_SW_OUT_CFG *tPara, UINT32 uiIdx);
UINT32 BspHalAdaptSetTransRxMuxPara(T_TDD_BASE_SW_OUT_CFG *tPara, UINT32 uiIdx);
UINT32 BspHalAdaptSetTransOrxMuxPara(T_TDD_BASE_ORX_OUT_CFG *tPara, UINT32 uiIdx);

UINT32 BspHalAdaptSetAcEnMuxPara(T_COMB_2INSTANTIATE_PARA *tPara, UINT32 uiIdx);
UINT32 BspHalAdaptSetAcCtrlMuxPara(T_AC_CTRL_SW_OUT_CFG *tPara, UINT32 uiIdx);
UINT32 BspHalAdaptSetPaLnaProtCfg(T_PA_LNA_PROT_CFG *tPaLnaProt);
UINT32 BspHalAdaptSetPaProtEnCfg(UINT32 uiIdx, UINT32 uiEn);
UINT32 BspHalAdaptSetLnaProtEnCfg(UINT32 uiIdx, UINT32 uiEn);
UINT32 BspHalSetLvdsCfg(UINT32 padName, UINT32 value);
UINT32 BspHalAdaptSetPaUeEnCfg(T_UE_EN_CFG *tUeEn, UINT32 uiIdx);
UINT32 BspHalAdaptSetLnaUeEnCfg(T_UE_EN_CFG *tUeEn, UINT32 uiIdx);
UINT32 BspHalAdaptSetTxUeEnCfg(T_UE_EN_CFG *tUeEn, UINT32 uiIdx);
UINT32 BspHalAdaptSetRxUeEnCfg(T_UE_EN_CFG *tUeEn, UINT32 uiIdx);
UINT32 BspHalAdaptSetOrxUeEnCfg(T_UE_EN_CFG *tUeEn, UINT32 uiIdx);

/*OE使能*/
UINT32 BspHalAdaptSetPaOeEnCfg(UINT32 uiIdx, UINT32 uiIsEnable);
UINT32 BspHalAdaptSetLnaOeEnCfg(UINT32 uiIdx, UINT32 uiIsEnable);
UINT32 BspHalAdaptSetTxOeEnCfg(UINT32 uiIdx, UINT32 uiIsEnable);
UINT32 BspHalAdaptSetRxOeEnCfg(UINT32 uiIdx, UINT32 uiIsEnable);
UINT32 BspHalAdaptSetOrxOeEnCfg(UINT32 uiIdx, UINT32 uiIsEnable);
UINT32 BspHalAdaptSetAmpOeEnCfg(UINT32 uiIdx, UINT32 uiIsEnable);

UINT32 BspHalAdaptGetPaOutSel(UINT32 uiIdx, UINT32 *uiSel);
UINT32 BspHalAdaptGetLnaOutSel(UINT32 uiIdx, UINT32 *uiSel);
UINT32 BspHalAdaptGetAmpOutSel(UINT32 uiIdx, UINT32 *uiSel);
UINT32 BspHalAdaptGetTrxTxEnOutSel(UINT32 uiIdx, UINT32 *uiSel);
UINT32 BspHalAdaptGetTrxRxEnOutSel(UINT32 uiIdx, UINT32 *uiSel);
UINT32 BspHalAdaptGetTrxFbEnOutSel(UINT32 uiIdx, UINT32 *uiSel);
UINT32 BspHalAdaptGetTrxTxEnACOutSel(UINT32 uiIdx, UINT32 *uiSel);
UINT32 BspHalAdaptGetTrxRxEnACOutSel(UINT32 uiIdx, UINT32 *uiSel);
UINT32 BspHalAdaptGetAcCtrlOutSel(UINT32 uiIdx, UINT32 *uiSel);
UINT32 BspHalAdaptSetSwOe(UINT32 enable);

//bitmap控制
UINT32 BspHalAdaptSetPaUeEn(UINT32 uiIdx, UINT32 uiEn);                                /** Pa的Ue使能配置接口 */
UINT32 BspHalAdaptSetLnaUeEn(UINT32 uiIdx, UINT32 uiEn);                               /** Lna的Ue使能配置接口 */
UINT32 BspHalAdaptSetTxenUeEn(UINT32 uiIdx, UINT32 uiEn);                              /** Txen的Ue使能配置接口 */
UINT32 BspHalAdaptSetRxenUeEn(UINT32 uiIdx, UINT32 uiEn);                              /** Rxen的Ue使能配置接口 */
UINT32 BspHalAdaptSetAmpUeEn(UINT32 uiIdx, UINT32 uiEn);                               /** Amp的Ue使能配置接口 */
UINT32 BspHalAdaptSetAcCtrlUeEn(UINT32 uiIdx, UINT32 uiEn);                            /** Ac的Ue使能配置接口  */

UINT32 BspHalAdaptSetPaBitmap(UINT32 uiIdx, UINT32 uiBitmapLoop, UINT32 uiBitmapVal);  /** Pa的bitmap配置接口 */
UINT32 BspHalAdaptSetLnaBitmap(UINT32 uiIdx, UINT32 uiBitmapLoop, UINT32 uiBitmapVal); /** Lna的bitmap配置接口 */
UINT32 BspHalAdaptSetTxenBitmap(UINT32 uiIdx, UINT32 uiBitmapLoop, UINT32 uiBitmapVal);/** Txen的bitmap配置接口 */
UINT32 BspHalAdaptSetRxenBitmap(UINT32 uiIdx, UINT32 uiBitmapLoop, UINT32 uiBitmapVal);/** Rxen的bitmap配置接口 */
UINT32 BspHalAdaptSetAmpBitmap(UINT32 uiIdx, UINT32 uiBitmapLoop, UINT32 uiBitmapVal); /** Amp的bitmap配置接口 */
/*dt节能管脚及路由相关*/
/*全路由*/
UINT32 BspHalAdaptSetDlDtxRouter(UINT32 uiChanId, UINT32 uiSel); /** 8通道到8通道全路由 */
UINT32 BspHalAdaptSetUlDtxRouter(UINT32 uiChanId, UINT32 uiMaskEn40); /** 下行送来的8路40bit合路使能掩码配置 */
/* Started by AICoder, pid:a34d8826cbl383814c840b10201c3306aad58918 */
UINT32 BspHalAdaptSetDlDtxPaDly(UINT32 uiChanId, UINT32 uiRiseDly, UINT32 uiFallDly);
UINT32 BspHalAdaptSetDlDtxAmpDly(UINT32 uiChanId, UINT32 uiRiseDly, UINT32 uiFallDly);
UINT32 BspHalAdaptSetDlDtxTxenDly(UINT32 uiChanId, UINT32 uiRiseDly, UINT32 uiFallDly);
UINT32 BspHalAdaptSetDtxDiffDlyFlag(UINT32 uiDtxDiffDlyFlag);
UINT32 BspHalAdaptGetDtxDiffDlyFlag(VOID);
/* Ended by AICoder, pid:a34d8826cbl383814c840b10201c3306aad58918 */
UINT32 BspHalAdaptSetUlDtxLnaSel(UINT32 uiIdx, T_UL_DTX_SEL *tUlDtxSel);
UINT32 BspHalAdaptSetUlDtxRxEnSel(UINT32 uiIdx, T_UL_DTX_SEL *tUlDtxSel);
UINT32 BspHalAdaptSetDlDtxPaCombEn(UINT32 uiChanId, UINT32 uiMask); /** 下行DTX PA通道合路配置 */
UINT32 BspHalAdaptSetDlDtxPaModeMap(UINT32 uiChanId, UINT32 uiMask); /** 下行DTX PA通道modemap配置 */
UINT32 BspHalAdaptSetDlDtxPa4Sel1(UINT32 uiChanId, UINT32 uiSel); /** 下行DTX PA通道4套tddbase选1 */
UINT32 BspHalAdaptSetDlDtxPaOutSel(UINT32 uiChanId, UINT32 uiSel);   /** 下行DTX PA通道输出选择 */
UINT32 BspHalAdaptSetDlDtxPaGpSel(UINT32 uiChanId, UINT32 uiSel) ;   /** 下行DTX PA通道Gp输出选择 */
UINT32 BspHalAdaptSetDlDtxComPaSel(UINT32 uiIdx, UINT32 uiMask);    /** 下行DTX 下行PA管脚的dtx合并选择 */
UINT32 BspHalAdaptSetDlDtxTxCombEn(UINT32 uiChanId, UINT32 uiMask); /** 下行DTX Trx通道合路配置 */
UINT32 BspHalAdaptSetDlDtxTxModeMap(UINT32 uiChanId, UINT32 uiMask); /** 下行DTX Trx通道modemap配置 */
UINT32 BspHalAdaptSetDlDtxTx4Sel1(UINT32 uiChanId, UINT32 uiSel) ;/** 下行DTX Trx通道4套tddbase选1 */
UINT32 BspHalAdaptSetDlDtxTxOutSel(UINT32 uiChanId, UINT32 uiSel);   /** 下行DTX Trx通道输出选择 */
UINT32 BspHalAdaptSetDlDtxTxGpSel(UINT32 uiChanId, UINT32 uiSel);    /** 下行DTX Trx通道Gp输出选择 */
UINT32 BspHalAdaptSetDlDtxAmpCombEn(UINT32 uiChanId, UINT32 uiMask); /** 下行DTX Amp通道合路配置 */
UINT32 BspHalAdaptSetDlDtxAmpModeMap(UINT32 uiChanId, UINT32 uiMask); /** 下行DTX Amp通道modemap配置 */
UINT32 BspHalAdaptSetDlDtxAmp4Sel1(UINT32 uiChanId, UINT32 uiSel); /** 下行DTX Amp通道4套tddbase选1 */
UINT32 BspHalAdaptSetDlDtxAmpOutSel(UINT32 uiChanId, UINT32 uiSel);   /** 下行DTX Amp通道输出选择 */
UINT32 BspHalAdaptSetDlDtxAmpGpSel(UINT32 uiChanId, UINT32 uiSel);    /** 下行DTX Amp通道Gp输出选择 */
UINT32 BspHalAdaptSetDlDtxComTxSel(UINT32 uiIdx, UINT32 uiMask);
UINT32 BspHalAdaptSetDlDtxComAmpSel(UINT32 uiIdx, UINT32 uiMask);
UINT32 BspHalAdaptSetFddScreenZeroPowVal(UINT32 state);
UINT32 BspHalAdaptSetTrxEnAcAcInSlotSel(T_TRX_ACINSLOT_PARA *tPara, UINT32 uiTddIdx);
UINT32 BspHalAdaptSetLinkAcInSlotPara(T_AC_INSLOT_PARA *tPara, UINT32 uiTddIdx);
UINT32 BspHalAdaptSetDtxIoLteEn(UINT32 uiChanId, UINT32 uiEn);
UINT32 BspHalAdaptGetTxRadioModeByDifChan(UINT32 uiDifChan,UINT32 *auiRadioMode,UINT32 *auiCarrId);
UINT32 BspHalAdaptGetRxRadioModeByDifChan(UINT32 uiDifChan,UINT32 *auiRadioMode,UINT32 *auiCarrId);
UINT32 BspHalAdaptGetTxRadioNumByDifChan(UINT32 uiDifChan);
UINT32 BspHalAdaptCfgCrmAlmShortForceCloseState(UINT32 mode, UINT32 bitStart, UINT32 bitEnd);
UINT32 BspHalAdaptCfgCrmAlmShortPwrEN(UINT32 sta, UINT32 bitStart, UINT32 bitEnd);
/* BBDV 专用电压控制 */
UINT32 BspHalAdaptSetTrxOrxEnOrBbdv(UINT32 uiValue);
UINT32 BspHalAdaptSetBbdvOutEn(UINT32 uiValue);
UINT32 BspHalAdaptSetTrxOrxEnOutSel(UINT32 uiValue);

/* LNA2 Bypass 寄存器控制接口 */
UINT32 BspHalAdaptSetPadDs(UINT32 uiHalPadName, UINT32 uiValue);/* 配置单端寄存器DS 4-7bit */
UINT32 BspHalAdaptSetPadCfgDone(UINT32 uiHalPadName, UINT32 padCfgDoneVal);/* 配置单端寄存器config_done 8bit */
UINT32 BspHalAdaptSetPadFuncSel(UINT32 uiHalPadName, UINT32 padFuncSelVal);/* 配置单端寄存器func_sel 9-10bit */

UINT32 BspSetCpriGpsFrSel(UINT32 logicOpt);
UINT32 BspSetCpriGpsBfnSel(UINT32 logicOpt);
UINT32 BspHalAdaptGetWirelessFrId(UINT32 *puiFrId);
UINT32 BspHalAdaptSetFddUmtsVirCellFlag(UINT32 isVirCell);
UINT32 BspHalAdaptGetFddUmtsVirCellFlag(VOID);
UINT32 BspHalAdaptGetCurrentFiberPort(VOID);
UINT32 BspHalAdaptGetCpriAdaptedProtocol(UINT32 ulPhyOpt, UINT32* pulProtocol);
UINT32 BspHalAdaptSetCellCfgMode(UINT32 radioStandard);
UINT32 BspHalAdaptUpCombSmpDataL2dStart(UINT32 uCellId, UINT32 uDir,UINT32 uAnt, UINT32 uDifOrGfTmp, UINT32 uSlot, UINT32 uStartSym, UINT32 uSymbNum);
UINT32 BspHalAdaptUpCombSmpDataL2dSave(UINT32 uCellId, UINT32 uDifOrGfTmp);
UINT32 BspHalAdaptGetPreAllocSenceList(T_BspHalAdaptOptPreAllocInfo **ptAllocList,UINT32 *preAllocNum);
UINT32 BspHalAdaptCfgPreAllocSence(T_BspHalAdaptPreAllocCarrInfo *ptPreAlloc);
UINT32 BspHalAdaptSetTaMode(UINT32 uTaMode);
UINT32 BspHalAdaptCfgPreAllocCarrMap(T_BspHalAdaptAllChanCarrMapRet *ptPreAlloc,UINT32 num);
UINT32 BspHalAdaptTdmMapCfg(VOID);
UINT32 BspHalAdaptCpgeParaRangeFreqInit(void);

UINT32 BspHalAdaptGetCpriNetMode(UINT32 *pulNetMode);
UINT32 BspHalAdaptGetTddMasterTn(UINT32 *tnVal);
UINT32 BspHalAdaptGetTddLoadBalanceTn(UINT32 logicOptNo, UINT32 *tnVal);
UINT32 BspHalAdaptGetFddTn(UINT32 *tnVal);
UINT32 BspHalAdaptGetFddForwardTn(UINT32 *tnVal);
UINT32 BspHalAdaptGetFddReverseTn(UINT32 *tnVal);
UINT32 BspHalAdaptGetFddLoadBalanceForwardTn(UINT32 logicOptNo, UINT32 *tnVal);
UINT32 BspHalAdaptGetFddLoadBalanceReverseTn(UINT32 logicOptNo, UINT32 *tnVal);
UINT32 BspHalAdaptGetTddMasterTul(UINT32 *tulVal);
UINT32 BspHalAdaptGetTddLoadBalanceTul(UINT32 logicOptNo, UINT32 *tulVal);
UINT32 BspHalAdaptGetFddTul(UINT32 *tulVal);
UINT32 BspHalAdaptGetFddForwardTul(UINT32 *tulVal);
UINT32 BspHalAdaptGetFddReverseTul(UINT32 *tulVal);
UINT32 BspHalAdaptGetFddLoadBalanceForwardTul(UINT32 logicOptNo, UINT32 *tulVal);
UINT32 BspHalAdaptGetFddLoadBalanceReverseTul(UINT32 logicOptNo, UINT32 *tulVal);
UINT32 BspHalAdaptGetTddMasterTdl(UINT32 *tdlVal);
UINT32 BspHalAdaptGetTddLoadBalanceTdl(UINT32 logicOptNo, UINT32 *tdlVal);
UINT32 BspHalAdaptGetFddTdl(UINT32 *tdlVal);
UINT32 BspHalAdaptGetFddForwardTdl(UINT32 *tdlVal);
UINT32 BspHalAdaptGetFddReverseTdl(UINT32 *tdlVal);
UINT32 BspHalAdaptGetFddLoadBalanceForwardTdl(UINT32 logicOptNo, UINT32 *tdlVal);
UINT32 BspHalAdaptGetFddLoadBalanceReverseTdl(UINT32 logicOptNo, UINT32 *tdlVal);
UINT32 BspHalAdaptGetTddMasterToffset(UINT32 *toffset);
UINT32 BspHalAdaptGetTddLoadBalanceToffset(UINT32 logicOptNo, UINT32 *toffset);
UINT32 BspHalAdaptGetCpriFwdToffsetRegVal(UINT32 ulLogOptNo, UINT32 *pulToffset);
UINT32 BspHalAdaptGetFddForwardToffset(UINT32 *toffset);
UINT32 BspHalAdaptGetFddReverseToffset(UINT32 *toffset);
UINT32 BspHalAdaptGetFddLoadBalanceForwardToffset(UINT32 logicOptNo, UINT32 *toffset);
UINT32 BspHalAdaptGetFddLoadBalanceReverseToffset(UINT32 logicOptNo, UINT32 *toffset);
UINT32 BspHalAdaptCfgCpriFwdToffset(UINT32 logicOptNo, UINT32 toffset);
UINT32 BspHalAdaptCfgCpriRvsToffset(UINT32 logicOptNo, UINT32 toffset);
UINT32 BspHalAdaptCpriFwdToffsetRegCfg(UINT32 logicOptNo, UINT32 toffset);
UINT32 BspHalAdaptCpriRvsToffsetRegCfg(UINT32 logicOptNo, UINT32 toffset);
UINT32 BspHalAdaptSetAcOrTsCfgEn(UINT32 cfgType);
UINT32 BspHalAdaptSetTsGpEn(UINT32 difChan, UINT32 gpEn);
UINT32 BspHalGetLvdsCfgVal(UINT32 padName, UINT32  *value);
UINT32 BspHalGetLvdsPadVal(UINT32 padName, UINT32 * value);
UINT32 BspHalAdaptGetDifVer(VOID);
UINT32 BspHalAdaptGetSysLd(UINT32 index,UINT32 *sta);
UINT32 BSpHalAdaptSetTddPwrOff(void);
UINT32 BSpHalAdaptSetFddPwrOff(void);
UINT32 BspSetInnerPwrAlmMask(void);
UINT32 BspHalAdaptGetQcellT12Diff(UINT32 *pDiffNs, UINT32 ulTe14);
UINT32 BspHalAdaptSetGsmCellInfo(T_GsmCellInfo *gsmCellInfo);
UINT32 BspHalAdaptInitQcellVgaCompPara(T_QcellCompPara *tQcellCompPara);
UINT32 BspSetUmtsChanPow(UINT32 bspChn, UINT32 uiCarrId, UINT32 uiRadioMode, UINT32 uiChanPow);
UINT32 BspInitUmtsAllCarrRatePow(UINT32 ulRatePow);
UINT32 BspHalAdaptLintDeltInit(UINT32 dir, T_BspHalAdaptLinkDeltDly* p_DeltCfg, UINT32 num);
UINT32 BspHalAdaptInitMtsBusCfg(UINT32 uiBusIdx,T_BspHalAdaptMtsBusCfgPara *pMtsBusCfgPara);
UINT32 BspHalAdaptSetMtsBusRoute(UINT32 uiDifChan, UINT32 uiMtsBusIdx, UINT32 uiMtsRx);
UINT32 BspHalAdaptQcellSwTblClr(VOID);
UINT32 BspSetTdmAigaCoef(UINT32 uiDifChan, UINT32 uiCarrId, UINT32 uiRadioMode, UINT32 uiRruNum);  //uiRruNum：RRU合并个数
VOID BspHalAdaptSetLycaSoftResetFlag(UINT32 flag);
UINT32 BspHalAdaptGetLycaSoftResetFlag(VOID);
UINT32 BspHalApiGetRxDataOffFlag(UINT32 difChan, UINT32 carrNo, UINT32 radioMode, UINT32 *uiFlag);
UINT32 BspApiLycaTxDataNrzEn(UINT32 serdesId, UINT32 laneId, UINT32 ulSwitch);
UINT32 BspApiLycaGetTxDataNrzEn(UINT32 serdesId, UINT32 laneId, UINT32 *pSwitch);
UINT32 BspHalAdaptLycaRecnt0HistNrz(UINT32 serdesId, UINT32 laneId);
UINT32 BspHalAdaptGetRfTxPllLd(UINT32 *sta);
UINT32 BspHalAdaptGetRfRxPllLd(UINT32 *sta);
UINT32 BspHalAdaptSetUePaFrameId(UINT32 uiChanId, UINT32 uiFrameId);
UINT32 BspHalAdaptSetUeLnaFrameId(UINT32 uiChanId, UINT32 uiFrameId);
UINT32 BspHalAdaptSetUeTxEnFrameId(UINT32 uiChanId, UINT32 uiFrameId);
UINT32 BspHalAdaptSetUeRxEnFrameId(UINT32 uiChanId, UINT32 uiFrameId);
UINT32 BspHalAdaptSetUeAmpFrameId(UINT32 uiChanId, UINT32 uiFrameId);
UINT32 BspHalAdaptSetUePaAntFrDly(UINT32 idx, UINT32 frDly);
UINT32 BspHalAdaptSetAcCtrlAntFrDly(UINT32 idx, UINT32 frDly);
UINT32 BspHalAdaptGetFrTmValue(UINT32 tddId, UINT32 radioMode);
UINT32 BspHalAdaptSetUeLnaAntFrDly(UINT32 idx, UINT32 frDly);
UINT32 BspHalAdaptSetUeTxEnAntFrDly(UINT32 idx, UINT32 frDly);
UINT32 BspHalAdaptSetUeRxEnAntFrDly(UINT32 idx, UINT32 frDly);
UINT32 BspHalAdaptSetUeAmpAntFrDly(UINT32 idx, UINT32 frDly);
UINT32 BspHalAdaptGetGlobleOutFrDir(UINT32 *pFrDir);

/**************************************************************************
*                              PIM相关
 *************************************************************************/
typedef T_PimChkInfoCfg T_BspHalAdaptPimChkInfoCfg;
UINT32 BspHalAdaptPimChkCfg(UINT32 NcoFlag, UINT32 difChan, T_BspHalAdaptPimChkInfoCfg *ptPimChkCfgInfo);
UINT32 BspHalAdaptPimPimCalcSw(UINT32 CalcEn);
UINT32 BspHalAdaptPimChkDataRpt(UINT32 NcoFlag, UINT32 difChan, UINT32 *sumData);
/**************************************************************************
*                              TSG相关
 *************************************************************************/
UINT32 BspHalAdaptDifTsgSwitch(UINT32 antChan, UINT32 carrNo, UINT32 radioMode, UINT32 sw);
UINT32 BspHalAdaptDifDlPreTsgSwitch(UINT32 antChan, UINT32 carrNo, UINT32 radioMode, UINT32 sw);
UINT32 BspHalAdaptResetRcf(UINT32 uiDir);
UINT32 BspHalAdaptSetGsmTsgCtrl(UINT32 difChan, UINT32 carrNo, UINT32 radioMode, UINT32 sw);
UINT32 BspHalAdaptSetUlChTsgCtrl(UINT32 uiDifChan, UINT32 uiEn);
UINT32 BspHalAdaptQcellTsg(UINT32 uCarrNo, UINT32 uRadioMode, UINT32 uSwitch, UINT32 uSrcMode, CHAR *fileName);
UINT32 BspHalAdaptOptDifTsgSwitch(UINT32 antChan, UINT32 carrNo, UINT32 radioMode, UINT32 tsgType, CHAR *fileName,UINT32 sw);
UINT32 BspHalAdaptDlBankTsgCtrl(UINT32 difChan, UINT32 carrNo, UINT32 radioMode, UINT32 tsgType, UINT32 mode, UINT32 sw);
UINT32 BspHalAdaptDifCfrTsgSwitch(UINT32 difChan, UINT32 sw);
UINT32 BspHalAdaptSetQcellTsgCarrAntChan(UINT32 srcAntChan, UINT32 dstAntChan);
UINT32 BspHalAdaptGetFftTxAcByAnt(UINT32 uCarrNo, UINT32 uRadioMode,UINT32 uAntMask, UINT32 *pAcVal, UINT32 *pAcNum);
/**************************************************************************
*                              REV功率回退相关
 *************************************************************************/
UINT32 BspSetRevInit(UINT32 uiDifChan, T_RevInfoCfg *pRevCfg);
UINT32 BspRevAlarmClr(UINT32 uiDifChan);
UINT32 BspRevAlarmStaRpt(UINT32 uiDifChan, UINT32 *almSta);
UINT32 BspGetRevAlarmThr(UINT32 uiDifChan, INT32 *uiFbThr);
UINT32 BspSetRevWarnThr(UINT32 uiDifChan,  INT32 uiFbThr);
UINT32 BspGetRevEnSta(UINT32 uiDifChan, UINT32 *puiEn);
UINT32 BspGetRevPowerRpt(UINT32 uiDifChan, DOUBLE *pVal);

/**************************************************************************
*                              UTDOA DMIMO相关
 *************************************************************************/
typedef T_UtDmimoParaCfg T_BspHalAdaptUtDmimoParaCfg;
typedef T_UtSendParaCfg  T_BspHalAdaptUtSendParaCfg;
typedef T_UtSampleParaCfg T_BspHalAdaptUtSampleParaCfg;
typedef T_UtInsertParaCfg T_BspHalAdaptUtInsertParaCfg;
typedef T_UtParaUint      T_BspHalAdaptUtParaUint;
typedef T_UtAacGainArray  T_BspHalAdaptUtAacGainArray;

#define UT_AAC_GAIN_SEC_NUM     (UT_SEQ_SEC_NUM)
#define UT_AAC_SENDRAM_LEN_BSP  (UT_SENDRAM_LEN)

typedef T_UtDlIoPara T_BspHalAdaptUtDlIoPara;
typedef T_UtUlIoPara T_BspHalAdaptUlIoPara;

typedef T_UtDlIoPara T_BspHalAdaptUtDlIoPara;
typedef T_UtUlIoPara T_BspHalAdaptUtUlIoPara;

typedef T_POSITION_RADIO_INFO_TNR T_BspHalAdaptPsotionRadioInfoTnr;
typedef T_POSITION_RADIO_INFO_TLTE T_BspHalAdaptPsotionRadioInfoTdd;
typedef T_POSITION_RADIO_INFO_FLTE_FNR T_BspHalAdaptPsotionRadioInfoFddFnr;
typedef T_CONVERGE_DISPATCH_INFO_TNR T_BspHalAdaptConvergDispatchInfoTnr;

#define DMM_UT_PUBLIC_EN_OFF  (UINT32)0
#define DMM_UT_PUBLIC_EN_ON   (UINT32)1

UINT32 BspHalAdaptM0SetMesgTnr(T_BspHalAdaptPsotionRadioInfoTnr *pMesgTnr);
UINT32 BspHalAdaptM0SetMesgTlte(T_BspHalAdaptPsotionRadioInfoTdd *pMesgTlte);
UINT32 BspHalAdaptM0SetMesgFdd(T_BspHalAdaptPsotionRadioInfoFddFnr *pMesgFdd);
UINT32 BspHalAdaptGetTxDuc0BankId(UINT32 uiDifChan,UINT32 uiCarrId, UINT32 uiCarrRadio,UINT32 *puiBankId);
UINT32 BspHalAdaptSetTddBandFreqFlag(UINT32 flag);
UINT32 BspHalAdaptSetExpansionFlag(UINT32 flag);
UINT32 BspHalAdaptDmmSendCfg(UINT32 uiDifChan, UINT32 uiCarrId, UINT32 uiRadioMode, T_BspHalAdaptUtDmimoParaCfg* pDmm);
UINT32 BspHalAdaptSetDlTimingDlTddDly(UINT32 uiDifChan, UINT32 uiDlyNs);
UINT32 BspHalAdaptSetDmimoPsyncIrqCfg(UINT32 uSwitch);
UINT32 BspHalAdaptPimPsyncIrqCfg(VOID);
UINT32 BspHalAdaptSrsPsyncIrqCfgTnr(UINT32 uSwitch);
UINT32 BspHalAdaptSrsPsyncIrqCfgTlte(UINT32 uSwitch);
UINT32 BspHalAdaptSrsPsyncIrqCfgFdd(UINT32 uSwitch);

UINT32 BspHalAdaptSrsSetRevMesgTnr(VOID);
UINT32 BspHalAdaptSrsSetRevMesgTlte(VOID);
UINT32 BspHalAdaptSrsSetRevMesgFdd(VOID);

UINT32 BspHalAdaptGetSrsFrameNoDelayAdjustFlagTnr(VOID);
UINT32 BspHalAdaptGetSrsFrameNoDelayAdjustFlagFdd(VOID);

UINT32 BspHalAdaptIsCarrValid(UINT32 difChan, UINT32 carrId, UINT32 carrRadio, UINT32 dir, UINT32 *validFlag);
UINT32 BspHalAdaptSetCcToGainDelay(UINT32 uDifChan,UINT32 uCarrId,UINT32 uRadioMode);
UINT32 BspHalAdaptDmmSendEn(UINT32 uiDifChan, UINT32 uiCarrId, UINT32 uiRadioMode, UINT32 uiEn);
UINT32 BspHalAdaptDmmReceiveCfg(UINT32 uiDifChan, UINT32 uiCarrId, UINT32 uiRadioMode, T_BspHalAdaptUtDmimoParaCfg* pDmm);
UINT32 BspHalAdaptDmmReceiveEn(UINT32 uiDifChan, UINT32 uiCarrId, UINT32 uiRadioMode, UINT32 uiEn);
UINT32 BspHalAdaptPsyncFrameCheck(VOID);
UINT32 BspHalAdaptQcellPsyncSyn(VOID);
UINT32 BspHalAdaptSampleIf0(UINT32 uDir, T_BspHalAdaptUtDmimoParaCfg *pDmimoParaCfg);
UINT32 BspHalAdaptUtDlIoCfg(UINT32 uiDifChan, UINT32 uiCarrId, UINT32 uiRadioMode, UINT32 uiMode, T_BspHalAdaptUtDlIoPara* pUtIo);
UINT32 BspHalAdaptUtUlIoCfg(UINT32 uiDifChan, UINT32 uiCarrId, UINT32 uiRadioMode, UINT32 uiMode, T_BspHalAdaptUtUlIoPara* pUtIo);
VOID BspSetDmmIoEnVar(UINT32 dmmEn);
UINT32 BspGetDmmIoEnVar(VOID);
VOID BspSetUtIoEnVar(UINT32 utEn);
UINT32 BspGetUtIoEnVar(VOID);
UINT32 BspHalAdaptUtDlIoEn(UINT32 uiDifChan, UINT32 uiEn);
UINT32 BspHalAdaptUtUlIoEn(UINT32 uiDifChan, UINT32 uiEn);
UINT32 BspHalAdaptSetDlGpEn(UINT32 uiDifChan, UINT32 uiRadioMode, UINT32 uiCarrId, UINT32 uiEn);
UINT32 BspHalAdaptUtSendAacCfg(UINT32 uiDifChan, UINT32 uiCarrId, UINT32 uiRadioMode, T_BspHalAdaptUtSendParaCfg* pDmm);
UINT32 BspHalAdaptUtSampleCfg(UINT32 uiDifChan,UINT32 uiCarrId,UINT32 uiRadioMode,T_BspHalAdaptUtSampleParaCfg* samPara);
UINT32 BspHalAdaptUtInsertAacCfg(UINT32 uiDifChan,UINT32 uiCarrId,UINT32 uiRadioMode,T_BspHalAdaptUtInsertParaCfg* psamPara);
UINT32 BspHalAdaptUtSendAacEn(UINT32 uiDifChan, UINT32 uiCarrId, UINT32 uiRadioMode, UINT32 uiEn);
UINT32 BspHalAdaptUtSetMode(UINT32 uiMode);
UINT32 BspHalAdaptUtGetMode(VOID);
UINT32 BspHalAdaptUtSampleEn(UINT32 uiDifChan, UINT32 uiCarrId, UINT32 uiRadioMode, UINT32 uiEn);
UINT32 BspHalAdaptUtInsertAacEn(UINT32 uiDifChan, UINT32 uiCarrId, UINT32 uiRadioMode, UINT32 uiEn);
UINT32 BspHalAdaptUtTddClrCfg(UINT32 uiDifChan, UINT32 uiCarrId, UINT32 uiRadioMode);
UINT32 BspHalAdaptSetSaveGrp(UINT32 uiType, UINT32 uiGrp);             //设置存放组号（0-9）
UINT32 BspHalAdaptGetSaveType();                                       //设置存放类型号（0-4）
UINT32 BspHalAdaptGetSaveGrp();                                        //获取当前存放组号
UINT32 BspHalAdaptSetSaveRegEn(UINT32 uiEn);                           //使能
UINT32 BspHalAdaptGetSaveRegEn();                                      //获取使能标志
UINT32 BspHalAdaptGetSaveRegInfo(UINT32 uiType, UINT32 uiGrp, T_RegSaveUnit* pData);  //获取某组的数据
UINT32 BspHalAdaptClrSaveRegInfo(UINT32 uiType, UINT32 uiGrp);                        //清除某组的数据
UINT32 BspHalAdaptUtTddClrEn(UINT32 uiDifChan, UINT32 uiCarrId, UINT32 uiRadioMode, UINT32 uiEn);
UINT32 BspHalAdaptRcdTdmAigaClr(UINT32 uiDifChan, UINT32 uiCarrId, UINT32 uiRadioMode, UINT32 uiOffEn);
UINT32 BspHalAdaptRcdDlpreGainClr(UINT32 uiDifChan, UINT32 uiCarrId, UINT32 uiRadioMode, UINT32 uiOffEn);
UINT32 BspHalAdaptJitOutWinCfg(UINT32 uiJitterVal);
UINT32 BspHalAdaptJ204InfGlbWinCfg(UINT32 uiJitterVal);
UINT32 BspHalAdaptUtTddUpdate(UINT32 uiDifChan);
UINT32 BspHalAdaptGetQcellBfn(UINT32 ulLogOptNo);

UINT32 BspHalAdaptM0SetSfBitmapTnr(UINT32 uCellId, UINT32 uRadioMode, UINT32 uBitmap);
UINT32 BspHalAdaptM0ClearMesgTnr(VOID);
UINT32 BspHalAdaptM0ClearMesgTlte(VOID);
UINT32 BspHalAdaptM0ClearMesgFdd(VOID);
UINT32 BspHalAdaptM0SetConDispatchMesg(T_CONVERGE_DISPATCH_INFO_TNR *pConDispatchMesg);
UINT32 BspHalAdaptConDispathcPsyncIrqCfg(UINT32 uSwitch);
UINT32 BspHalAdaptM0ClearConDispatchMesg(VOID);
UINT32 BspHalAdaptM0RcvConDispatchMesg(VOID);
UINT32 BspHalAdaptConDispatchSetCcToGainDelay(UINT32 uDifChan,UINT32 uCarrId,UINT32 uRadioMode);


UINT32 BspHalAdaptPsyncFramenoInfoPrint(UINT32 uFrame);
UINT32 BspHalAdaptUtUlBankSample(UINT32 uiDifChan, UINT32 uiCarrId, UINT32 uiRadioMode, UINT32 uiStartFlag);
UINT32 BspHalAdaptUtDlBankSample(UINT32 uiDifChan, UINT32 uiCarrId, UINT32 uiRadioMode, UINT32 uiStartFlag);
VOID  BspHalAdaptSetPsyncSynChipId(UINT32 chipId);
UINT32 BspHalAdaptSetFeatureFrAdjustVal(UINT32 antNo, UINT32 carrNo, UINT32 radioMode, UINT32 functionMode);
UINT32 BspHalAdaptCpriCfgIqCloseEn(UINT32 logOptNo, UINT32 openEn, UINT32 chnDir);
UINT32 BspHalAdaptPreInitPcs(T_BspHalAdaptPcsCfg *pcsCfg, UINT32 laneNum);
UINT32 BspHalAdaptInitPcs(T_BspHalAdaptPcsCfg *pcsCfg, UINT32 laneNum);
UINT32 BspHalAdaptSetFlowTokenEn(T_BspHalAdaptPcsCfg *pcsCfg, UINT32 laneNum);

UINT32 BspHalAdaptSetUtSendAacGain(UINT32 difChan, UINT32 carrId, UINT32 radioMode, T_BspHalAdaptUtAacGainArray *pAacGainArray);
// 光口接口
UINT32 BspHalAdaptUtdoaAacIrqCfg(UINT32 en);
UINT32 BspHalAdaptSetUtdoaSmallErgodicPara(T_UtdoaSmallErgodicParaOpt *utdoaAacPara);
// 中频接口
UINT32 BspHalAdaptSaveUtSendAAcGain(UINT32 uiDifChan, UINT32 uiCarrId, UINT32 uiRadioMode, T_UtAacGainArray *pAacGainArray);
UINT32 BspHalAdaptUtInsertSampleUlBank(UINT32 chanMask, UINT32 carrId, UINT32 radioMode, UINT32 mode); 
UINT32 BspHalAdaptSampleBank(UINT32 chanMask, UINT32 carrId, UINT32 radioMode, UINT32 mode, UINT32 flag);
UINT32 BspHalAdaptRecoverSampleCfg(VOID);
UINT32 BspHalAdaptGetSampleCarrFinish(UINT32 module);
UINT32 BspHalAdaptEndSampleCarr(UINT32 module);
UINT32 BspHalAdaptRenameSampleFile(VOID);
UINT32 BspHalAdaptRenameUtdoaSampleFile(UINT32 flag);
/**************************************************************************
                           光口ICP通信处理
**************************************************************************/
UINT32 BspKoSubFrameCfg(T_SUBFRAME_BITMAP_MSG *pMsgIn);
UINT32 BspKoRfSwtichCfg(T_RF_SWTICH_MSG *pMsgIn, UINT32 msgId);
UINT32 BspKoFrameNumCfg(T_FRAME_NUM_MSG *pMsgSend, T_FRAME_NUM_MSG *pMsgRecv);
UINT32 BspHalAdaptDmClear(VOID);
UINT32 BspHalAdaptUtdoaClear(VOID);



UINT32 BspHalAdaptGetTxBankId(UINT32 difChan, UINT32 carrId, UINT32 carrRadio, UINT32 *pBankId);
UINT32 BspHalAdaptGetPsyncL2dSymbolAddr(UINT32 chanNo, UINT32 carrNo, UINT32 carrMode, UINT32 dir, UINT32 *pL2dSymbolAddr);
UINT32 BspHalAdaptGetCellIndex(UINT32 chanNo, UINT32 carrNo, UINT32 carrMode, UINT32 dir, UINT32 *pCellID);
UINT32 BspHalAdaptSetDmimoMasterSwitchInfo(T_DmimoMasterSwitchEn *pDmimoMasterSwitchInfo);
UINT32 BspHalAdaptGetDmimoMasterCpId(UINT32 uiCarrNo, UINT32 uiRadio, UINT32 *pCpId);
UINT32 BspHalAdaptResourceRecycle(UINT32 dir, T_DifChanInfo *ptChanInfo);

/**************************************************************************
                            节能相关接口
**************************************************************************/
#define DPDIC_A53_CORE_NUM (4)

typedef struct _T_DpdicPwrSaveSel
{
    UINT32 difTxUnusedResSel;
    UINT32 difRxUnusedResSel;
    UINT32 a53CoreMask;
    UINT32 optDifIf0CompMask;
    UINT32 optDifIf1CompMask;
    UINT32 optDifAximMask;
    UINT32 optGfOranMask;
    UINT32 optGfBdrMask;
    UINT32 optGfChMask;
    UINT32 optBifOranMask;
    UINT32 optBifChMask;
    UINT32 optSw1OptSw1Sel;
    UINT32 optSw1MapSel;
    UINT32 optCpriFrmMask;
    UINT32 optCpriSerdesMask;
    UINT32 optPrach01Sel;
    UINT32 optPrach00Sel;
    UINT32 optFft1Sel;
    UINT32 optFft0Sel;  
    UINT32 optRoeIq0Sel; 
    UINT32 optRoeIq1Sel; 
    UINT32 optRoeIq2Sel; 
    UINT32 optRoeIq3Sel;
    UINT32 optRoeNtlCtrlSel;
    UINT32 difAllSel;
    UINT32 j204DlLaneMask;
    UINT32 j204FbLaneMask;
    UINT32 j204UlLaneMask;
    UINT32 j204DlMapMask;
    UINT32 j204FbMapMask;
    UINT32 j204UlMapMask;
}T_DpdicPwrSaveSel;

/* DPDIC芯片节电门控参数初始化(用于保存单板下的门控使能配置) */
UINT32 BspHalAdaptPwrSavePreInit(VOID);
UINT32 BspHalAdaptPwrSavePostInit(VOID);
UINT32 BspHalAdaptPwrSavePostQcell(UINT32 uiPwrsaveMode);
UINT32 BspHalAdaptDpdicGateCtrl(UINT32 pwrsaveType);
UINT32 BspHalAdaptSetPwrSaveCfg(UINT32 pwrsaveType,T_DpdicPwrSaveSel* pCfg);
T_DpdicPwrSaveSel* BspHalAdaptGetPwrSaveCfg(VOID);
UINT32 BspHalAdaptDifUnuseResGateCtrl(UINT32 dir, UINT32 sw);

/* 配置中频除204外总控门控使能  sw: 1表示时钟打开，0表示时钟关闭 */
UINT32 BspHalAdaptSetJ204DifGate(UINT32 sw);

/* 中频CFR模块stage门控配置接口 */
UINT32 BspHalAdaptSetCfrStageGateCtrl(UINT32 uiEn);
/* 中频DPD/PIMC门控配置接口 */
UINT32 BspHalAdaptSetDldpdSetGateCfg(UINT32 uiChanMask, UINT32 uiPimcFlag);

/* 中频下行未使用资源时钟门控使能接口 */
UINT32 BspHalAdaptSetTxUnusedGateEn(UINT32 gateEn);

/* 中频上行未使用资源时钟门控使能接口 */
UINT32 BspHalAdaptSetRxUnusedGateEn(UINT32 gateEn);

/* 光口天线使能控制 */
UINT32 BspHalAdaptOptAllCellEn(UINT32 en);
UINT32 BspApiSetDlbankDgainEnOffInit();
UINT32 BspApiSetUlbankKpOutEnOffInit();
UINT32 BspOptDisableCtrl(VOID);

UINT32 BspHalAdaptGetUlbankAptuneCoef(UINT32 difChan, UINT32 difCarrNo, UINT32 radioMode, UINT32 *pCoef);
UINT32 BspHalAdaptSetUlbankAptuneCoef(UINT32 difChan, UINT32 difCarrNo, UINT32 radioMode, UINT32 coef);
UINT32 BspHalApiTwoFrePrachGetRbNum(UINT32 uPrachConfigIndex,UINT32 uScs,UINT32 uPrachScs);
UINT32 BspHalApiSetRachModeFlag(UINT32 uCellIndex,UINT32 uFlag);
UINT32 BspHalAdaptSetSoc25MClkOutEnable(UINT32 ulSw);
UINT32 BspHalAdaptGetOpt2DlPreFrCfg(UINT32 uiFrId);

/* 850M干扰检测采集次数 */
UINT32 BspHalAdaptSetSampleUlChTimes(UINT32 sampleTimes);

UINT32 BspHalAdaptSampleDlCfr1(UINT32 uiDifChan, UINT32 uiPosSel);

UINT32 BspOptSetSpectrumShare(UINT32 cellId,UINT32 specShare);

/* GU 频谱共享 */
UINT32 BspHalAdaptSetUmtsTxCfrFilterEn(UINT32 chan, UINT32 carrNo, UINT32 slotNo, UINT32 trapEn); /* UMTS陷波功能分载波分时隙使能 */
UINT32 BspHalAdaptSetUmtsTxCfrOrderNum(UINT32 orderNum); /* UMTS陷波滤波器阶数 */
UINT32 BspHalAdaptUmtsTxCfrFilterCoef(UINT32 chan, UINT32 carrNo, UINT32 slotNo, INT32 *pCoefArray, UINT32 coefNum); /* UMTS陷波滤波器系数 */
UINT32 BspHalAdaptSetUmtsGsmSlotHdDly(UINT32 difChan, UINT32 carrNo);
UINT32 BspHalCpriFrameAlignRdFrSel(UINT32 logicOptIndex, UINT32 frSel);
VOID BspHalAdaptCpriSetSwDstFrFlag(UINT32 flag);
UINT32 BspCfgRoeCmCfgProtocol(UINT32 protocol);
UINT32 BspHalAdaptGetCfrCpgRamAlarm(T_DifChanOriginCoefPara *ptCpgCarrInfo, UINT32 *puiAlarm);

/* 一键采集 */
UINT32 BspHalAdaptOneClickCollectOpt(UINT32 mask);
UINT32 BspHalAdaptOneClickCollectHal(VOID);

/* 获取IF1的载波延时缓冲能力 */
UINT32 BspHalAdaptGetIf1CarrDelayCurrentBufCapability(UINT32 dir, UINT32 bspChn, UINT32 radiomode, UINT32 carrNo, UINT32 *dlyNs);
UINT32 BspHalAdaptGetIf1CarrDelayMaxBufCapability(UINT32 dir, UINT32 bspChn, UINT32 radiomode, UINT32 carrNo, UINT32 *dlyNs);

UINT32 BspHalAdaptIsNcrType(UINT32 ncrFlag);
UINT32 BspHalAdaptNcrFwdMap(T_NcrFwdMap* ptTxFwdMap,UINT32 uiTxSize,T_NcrFwdMap* ptRxFwdMap,UINT32 uiRxSize);

UINT32 BspHalAdaptCheckTx204Route(UINT32 *puiFlag);
UINT32 BspHalAdaptSetUmtsDagcReset(VOID);
UINT32 BspHalAdaptSetUmtsDagcPowCfg(UINT32 difChan, UINT32 carrId, UINT32 radioMode);
UINT32 BspHalAdaptGetUmtsDagcPowPrt(UINT32 difChan, UINT32 carrId, UINT32 radioMode, UINT32 *errFlag);

UINT32 BspIcHalApiSetDlbankAptuneWithPhase(UINT32 uiDifChan, UINT32 uiCarrId, UINT32 uiRadioMode, UINT32 phase);
UINT32 BspGainToReg(DOUBLE iGain, UINT32 uiBase);
UINT32 BspHalAdaptOptVerifyT12Cfg(UINT32 netMode, UINT32 chipTransDly, UINT32 ta, UINT32 fwdT12, UINT32 revT12);
UINT32 BspHalAdaptSetFreqOffsetCompFlag(UINT32 flag);
UINT32 BspHalAdaptGetFreqOffsetCompFlag(void);
UINT32 BspHalAdaptSetNbRcfBypassFlag(UINT32 flag);
UINT32 BspHalAdaptSetNBCompressFlag(UINT32 uFlag);
UINT32 BspHalAdaptSetFreqOffSetIndexByCarr(UINT32 uiDifChan, UINT32 uiCarrId, UINT32 uiRadioMode, UINT32 uiIndex);
UINT32 BspHalAdaptGetCarrFreqOffsetDly(UINT32 *pdifDlDelay, UINT32 *pdifUlDelay);
UINT32 BspHalAdaptGetNcoProtocol(UINT32 phyOptNo);
UINT32 BspHalAdaptCrmN8VForcePaCfg(UINT32 forcePaCfgSwitch);
UINT32 BspHalAdaptPsyncModeCfg(UINT32 psyncMode);

/*BBU与RRU联合采数功能*/
UINT32 BspHalAdaptSamplePowDetParaCfg(UINT32 powThrMin, UINT32 powDataLen, UINT32 timeMiniLen);
UINT32 BspHalAdaptSetPowThrodCfg(UINT32 difChan, UINT32 carrNo, UINT32 radioMode, UINT32 powPosition, UINT32 powMaxThrod);
UINT32 BspHalAdaptPowThrodStart(UINT32 powPosition);
UINT32 BspHalAdaptPowThrodIsDone(UINT32 powPosition,UINT32 *pFlag);
UINT32 BspHalAdaptPowThrodEnd(UINT32 powPosition);
UINT32 BspHalAdaptUnionSampleCfg(VOID);
UINT32 BspSetlastSlaveFlag(UINT32 flag);
UINT32 BspGetlastSlaveFlag(void);
UINT32 BspHalAdaptSetDlExtraDlyFlag(UINT32 difChan, UINT32 carrId, UINT32 radioMode, UINT32 flag);
UINT32 BspGetChanInfoByPwrTempType(UINT32 pwrTempType, UINT32 *pwrChanNum, UINT32 *pwrChanMask);
UINT32 BspHalAdaptGetNot10MsFrCnt(UINT32 uiFrId, UINT32 *puiNot10MsFrCnt);
UINT32 BspHalCpriSwAlignFrSel(UINT32 ulLogOptNo, UINT32 ulRdFrSel, UINT32 ulBypassAlign);
UINT32 BspHalAdaptBifGFLoopCheckTest(VOID);
UINT32 BspHalAdaptSetSwRadioModeAndFrOffSet(UINT32 uiRadioMode, UINT32 uiFrOffSetNs);
UINT32 BspHalAdaptSetSwFrDlyFlag(UINT32 uiSwFrDlyFlag);
UINT32 BspHalAdaptOptCheckAxc(UINT32 cellId, UINT32 radioMode);
INT32 BspHalAdaptSetTxCarrDelayAdj(UINT32 difChan, UINT32 carrId, UINT32 radioMode, INT32 adjDlyNs);
/* Started by AICoder, pid:8c276ee0a0t3dda1401208e980476a245b18d428 */
UINT32 BspHalAdaptCrmCfgRoeGate(UINT32 ulChip, UINT32 ulClkBitMap);
UINT32 BspHalAdaptCrmCfgRoeElcBrpGate(UINT32 elcBrpGateSw);
UINT32 BspHalAdaptSw1ClockGatingEn(UINT32 swGate);
UINT32 BspHalAdaptSw1MapGate(UINT32 mapGate);
UINT32 BspHalAdaptGfSetOranChClkGataEn(UINT32 ulTdmChan, UINT32 ulMode);
UINT32 BspHalAdaptGfSetBdrChClkGataEn(UINT32 ulTdmChan, UINT32 ulMode);
UINT32 BspHalAdaptGfSetGfChClkGataEn(UINT32 ulTdmChan, UINT32 ulMode);
UINT32 BspHalAdaptDifSetLTEGateEN(UINT32 ulChan, UINT32 ulMode);
UINT32 BspHalAdaptDifSetFFTAGateEN(UINT32 ulChan, UINT32 ulMode);
UINT32 BspHalAdaptDifSetAXIGateEN(UINT32 ulChan, UINT32 ulMode);
UINT32 BspHalAdaptCrmCfgFftGate16T0(UINT32 ulChip, UINT32 ulClkBitMap);
UINT32 BspHalAdaptCrmCfgPrachGate16T0(UINT32 ulChip, UINT32 ulClkBitMap);
UINT32 BspHalAdaptCatchdataSampleBySlot(UINT32 uiDifChan, UINT32 uiCarrId, UINT32 uiRadioMode,UINT32 uiSlot,UINT32 uiPos);
/* Ended by AICoder, pid:8c276ee0a0t3dda1401208e980476a245b18d428 */
VOID BspHalAdaptSetNcrMutiL2ssFlag(UINT32 mutiL2ssFlag);
UINT32 BspHalAdaptSetLnaUeOut2Sel1(UINT32 uiIdx, UINT32 uiSel);
UINT32 BspHalAdaptSetRxEnUeOut2Sel1(UINT32 uiIdx, UINT32 uiSel);
UINT32 BspHalAdaptSetLnaOutSel(UINT32 uiIdx, UINT32 uiSel);
UINT32 BspHalAdaptSetRxEnOutSel(UINT32 uiIdx, UINT32 uiSel);
UINT32 BspHalAdaptSetLnaDtxCombEn(UINT32 uiIdx, UINT32 uiSel);
UINT32 BspHalAdaptSetRxEnDtxCombEn(UINT32 uiIdx, UINT32 uiSel);
/**************************************************************************
                            AAC序列增益相关接口
**************************************************************************/
UINT32 BspHalAdaptStartAacProcess(UINT32 uCellId, T_AacFrameBitMapInfo *pAacFrameBitMap, UINT32 frameLen,UINT32 uAacType, UINT32 uAacStage);
UINT32 BspHalAdaptSetAacFrameGainPara(UINT32 uCellId, T_AacFrameGain * pFrameGain, INT32 gainDefalutDb, INT32 rfBackGain, UINT32 uAacType);
UINT32 BspHalAdaptStopAacProcess(UINT32 uCellId, UINT32 uAacType);
UINT32 BspHalAdaptSetSpecialCfgFlag(E_SPECIAL_CFG_TYPE uFlag);
UINT32 BspHalAdaptGetDlpreSampPointPhyAddr(UINT32 difChan, UINT32 logicCarrNo, UINT32 radioMode, UINT32 *dlyAddr);
UINT32 BspHalAdaptSetAacFrameModePara(T_AacFrameModePara *aacPara);
UINT32 BspHalAdaptSetAacSampPointDlyPara(T_AacSampPointDly *dlyPara);
UINT32 BspHalAdaptSetAacTddIoLinkMapPara(T_AacTddIoLinkMap *para);
UINT32 BspHalAdaptSetAacSuperFrameInfo(UINT32 uCellId, T_AacSuperFrameInfo *pSuper, UINT32 uAacType);
UINT32 BspHalAdaptCarrAacSwitchEn(UINT32 uCarrNo, UINT32 uRadioMode, UINT32 uSwitch);


UINT32 BspHalAdaptCdcJitterCfg(UINT32 uiJitterVal);

UINT32 BspHalGetQcellSuperFrameAdjustFlag(VOID);
UINT32 BspHalAdaptSetDlyMode(UINT32 uiDlyMode);
VOID BspHalAdaptOptLogPrintInit(UINT32 ulLogType, UINT32 ulLogSize);
UINT32 BspHalAdaptSetDlbankAllDgainRegWrZero(VOID);

UINT32 BspHalAdaptOptCheckBifGfTblCfg(UINT32 *pCheckResult);
UINT32 BspHalAdaptQcellCheckIqRes(UINT32 iqTblLen, T_PRruIqCfgItem_BSP *pRruIqCfgInfo, T_PRruIqResultItem_BSP *pRruIqResult);
UINT32 BspHalAdaptGetQcellTxIqSwitchFlag(UINT32 icId);
UINT32 BspHalAdaptQcellCpriIqTxSwitch(UINT32 funcId, UINT32 icId, UINT32 en);
UINT32 BspHalAdaptUpdateRoeState(VOID);
UINT32 BspHalAdaptGetOptWorkMode(VOID);
UINT32 BspHalAdaptRoeCpriDempperBufToP2Delay(UINT32 ulChanIndex, UINT32 uDir);
UINT32 BspHalAdaptRoeIqDemapperTimeMeasApiForCpri(UINT32 ulChanIndex, UINT32 uT12);
UINT32 BspHalAdaptRoeCpriLinkRebuild(UINT32 ulChanIndex);
UINT32 BspHalAdaptGetBbuRoeT12(VOID);

#ifdef __cplusplus

}
#endif
#endif 





/*****************************************************************************
* 版权所有(C) 2024, ZTE Corp. ZXSDR-RRU Platform BSP
*----------------------------------------------------------------------------
* 模 块 名 : bsp
* 文件名称 :  ichaladapt_dtx_ic4_2.h
* 文件标识 : {[N/A]}
* 内容摘要 : 本文件提供了ICHAL适配层对外接口声明
* 注意事项 : 无
* 作    者 : 张龙10281388
* 创建日期 : 2024-02-18
* 当前版本 : Ver1.0
*----------------------------------------------------------------------------
*/

#ifndef _FUNCLIB_ICHALADAPT_DTX_IC4_2_H_
#define _FUNCLIB_ICHALADAPT_DTX_IC4_2_H_

#ifdef __cplusplus
extern "C" {
#endif


#include "dtx.h"

/**************************************************************************
 *                            节能及DTX相关调用接口
 *************************************************************************/
/* 打开/关闭FFT和PRACH */
UINT32 BspHalAdaptOptFftPrachSwitch(UINT32 sw);

typedef T_DifDtxCheckPara T_BspHalAdaptDifDtxCheckPara;

UINT32 BspHalAdaptDtxCheckParaInit(UINT32 difChan, T_BspHalAdaptDifDtxCheckPara *ptDtxPara);
UINT32 BspHalAdaptSetDtxCheckEn(UINT32 difChan, UINT32 carrId, UINT32 radio, UINT32 checkEn);
UINT32 BspHalAdaptSetDtxEnToIo(UINT32 difChan, UINT32 carrId, UINT32 radio, UINT32 checkEn);
UINT32 BspHalAdaptSetDtxEnToDlbank(UINT32 difChan, UINT32 carrId, UINT32 radio, UINT32 dtxEn);




#ifdef __cplusplus

}
#endif
#endif /* _FUNCLIB_ICHALADAPT_DTX_IC4_2_H_ */

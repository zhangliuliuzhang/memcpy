#ifndef _FUNCLIB_ICHALADAPT_OPTTSG_IC4_2_H_
#define _FUNCLIB_ICHALADAPT_OPTTSG_IC4_2_H_


#ifdef __cplusplus
extern "C" {
#endif

#include "bsppub.h"
//#include "bspcomm.h"
//#include "ichaladapt_ic4_2.h"
//#include "ichaladaptbspapi.h"

UINT32 BspHalAdaptL2dCheckTest(void);

UINT32 BspHalAdaptOptTsgSwitch(UINT32 antChan, UINT32 carrNo, UINT32 radioMode, UINT32 tsgType, UINT32 sw);

UINT32 BspHalAdaptOptDifTsgSwitch(UINT32 antChan, UINT32 carrNo, UINT32 radioMode, UINT32 tsgType, char *fileName,UINT32 sw);

UINT32 BspHalAdaptQcellTsg(UINT32 uCarrNo, UINT32 uRadioMode, UINT32 uSwitch, UINT32 uSrcMode, char *fileName);

UINT32 BspHalAdaptSetQcellTsgCarrAntChan(UINT32 srcAntChan, UINT32 dstAntChan);

UINT32 BspHalAdaptSetGfTsgSwitch(UINT32 antChan, UINT32 carrNo, UINT32 radioMode, UINT32 switchEn, CHAR *fileName);

#ifdef __cplusplus

}
#endif
#endif
/*****************************************************************************
* 版权所有(C) 2024, ZTE Corp. ZXSDR-RRU Platform BSP
*----------------------------------------------------------------------------
* 模 块 名 : bsp
* 文件名称 :  ichaladapt_pwm_ic4_2.h
* 文件标识 : {[N/A]}
* 内容摘要 : 本文件提供了ICHAL适配层对外接口声明
* 注意事项 : 无
* 作    者 : 张龙10281388
* 创建日期 : 2024-02-18
* 当前版本 : Ver1.0
*----------------------------------------------------------------------------
*/

#ifndef _FUNCLIB_ICHALADAPT_PWM_IC4_2_H_
#define _FUNCLIB_ICHALADAPT_PWM_IC4_2_H_

#ifdef __cplusplus
extern "C" {
#endif


#include "bspcomm.h"


/*风扇控制*/
UINT32 BspHalAdaptSetPwmModeEn(UINT32 pwmBlock, UINT32 enFlag);
UINT32 BspHalAdaptSetPwmModePolarSel(UINT32 pwmBlock, UINT32 sel);
UINT32 BspHalAdaptSetPwmResolution(UINT32 pwmBlock, UINT32 val);
UINT32 BspHalAdaptSetPwmPeriod(UINT32 pwmBlock, UINT32 period);
UINT32 BspHalAdaptSetPwmDuty(UINT32 pwmBlock, UINT32 duty);

#ifdef __cplusplus

}
#endif
#endif /* _FUNCLIB_ICHALADAPT_PWM_IC4_2_H_ */

/*****************************************************************************
* 版权所有(C) 2020, ZTE Corp. ZXSDR-RRU Platform BSP
*----------------------------------------------------------------------------
* 模 块 名 : bsp
* 文件名称 : ichaladapt_timedelay_ic4_2.h
* 文件标识 : {[N/A]}
* 内容摘要 : 本文件提供了time delay ICHAL适配层对外接口声明
* 注意事项 : 无
* 作    者 : 殷嘉宾10256522
* 创建日期 : 2024-03-08
* 当前版本 : Ver1.0
*----------------------------------------------------------------------------
* 变更记录 :
*
* $记录1
* 变 更 单: $0000000(N/A)
* 责 任 人: 殷嘉宾10256522
* 修改日戳: 2024-03-08
* 变更说明: 创建文件
*----------------------------------------------------------------------------
*/

#ifndef _FUNCLIB_ICHALADAPT_TIMEDELAY_IC4_2_H_
#define _FUNCLIB_ICHALADAPT_TIMEDELAY_IC4_2_H_

#ifdef __cplusplus
extern "C" {
#endif

UINT32 BspHalAdaptSetDl204AndRfDlyAllChan(UINT32 *dlDly, UINT32 num);
UINT32 BspHalAdaptSetUl204AndRfDlyAllChan(UINT32 *ulDly, UINT32 num);
UINT32 BspHalAdaptSetUl204AndRfDlyByChan(UINT32 chan, UINT32 dly);
UINT32 BspHalAdaptSetDl204AndRfDlyByChan(UINT32 chan, UINT32 dly);
UINT32 BspHalAdapGetDefDl204AndRfDly(UINT32 chan, UINT32 dir, UINT32 *pDly);

UINT32 BspHalAdaptSetTxIcPreDly(UINT32 radio, UINT32 *preDly, UINT32 dlyNum);
UINT32 BspHalAdaptSetTxIcPostDly(UINT32 radio, UINT32 *postDly, UINT32 dlyNum);
UINT32 BspHalAdaptSetRxIcPreDly(UINT32 radio, UINT32 *preDly, UINT32 dlyNum);
UINT32 BspHalAdaptSetRxIcPostDly(UINT32 radio, UINT32 *postDly, UINT32 dlyNum);
UINT32 BspHalAdaptGetT2aDly(UINT32 radio, UINT32 *dly);
UINT32 BspHalAdaptGetTa3Dly(UINT32 radio, UINT32 *dly);

UINT32 BspHalAdaptSetReportT2aDly(UINT32 radio, UINT32 t2aDlyForward, UINT32 t2aDlyReverse);
UINT32 BspHalAdaptSetReportTa3Dly(UINT32 radio, UINT32 ta3DlyForward, UINT32 ta3DlyReverse);

UINT32 BspHalAdaptGetT2aDlyMax(UINT32 radio, UINT32 *dly);
UINT32 BspHalAdaptGetTa3DlyMax(UINT32 radio, UINT32 *dly);

#ifdef __cplusplus

}
#endif
#endif /* ICHALADAPT_IC4_2_INCLUDE_ICHALADAPT_TIMEDELAY_IC4_2_H_ */

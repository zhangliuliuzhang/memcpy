/*****************************************************************************
* 版权所有(C) 2020, ZTE Corp. ZXSDR-RRU Platform BSP
*----------------------------------------------------------------------------
* 模 块 名 : bsp
* 文件名称 : ichaldbg_ic4.h
* 文件标识 : {[N/A]}
* 内容摘要 : 本文件提供了ICHAL适配层对外接口声明
* 注意事项 : 无
* 作    者 : 王涛10248577
* 创建日期 : 2020-11-04
* 当前版本 : Ver1.0
*----------------------------------------------------------------------------
* 变更记录 :
*
* $记录1
* 变 更 单: $0000000(N/A)
* 责 任 人: 王涛10248577
* 修改日戳: 2020-11-04
* 变更说明: 创建文件
*----------------------------------------------------------------------------
*/

#ifndef _FUNCLIB_ICHALDBG_IC4_2_H_
#define _FUNCLIB_ICHALDBG_IC4_2_H_


#ifdef __cplusplus
extern "C" {
#endif

#include "bsppub.h"
#include "bspcomm.h"
#include "ichaladapt_ic4_2.h"
#include "ichaladaptbspapi.h"

UINT32 dbgSaveHalCarrInfo(UINT32 dir, UINT32 difChan, T_DifCarrInfo *carrInfo);
UINT32 dbgSaveHalRptCarrInfo(UINT32 dir, UINT32 difChan, T_DifCarrInfo *carrInfo);
VOID ichaladaptptnall(VOID);


#ifdef __cplusplus

}
#endif
#endif 





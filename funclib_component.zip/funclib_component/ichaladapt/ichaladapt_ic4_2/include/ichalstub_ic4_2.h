/*****************************************************************************
* 版权所有(C) 2020, ZTE Corp. ZXSDR-RRU Platform BSP
*----------------------------------------------------------------------------
* 模 块 名 : bsp
* 文件名称 : ichaladapt_ic4.h
* 文件标识 : {[N/A]}
* 内容摘要 : 本文件提供了ICHAL适配层对外接口声明
* 注意事项 : 无
* 作    者 : 王涛10248577
* 创建日期 : 2020-11-04
* 当前版本 : Ver1.0
*----------------------------------------------------------------------------
* 变更记录 :
*
* $记录1
* 变 更 单: $0000000(N/A)
* 责 任 人: 王涛10248577
* 修改日戳: 2020-11-04
* 变更说明: 创建文件
*----------------------------------------------------------------------------
*/

#ifndef _FUNCLIB_ICHALSTUB_IC4_2_H_
#define _FUNCLIB_ICHALSTUB_IC4_2_H_


#ifdef __cplusplus
extern "C" {
#endif

#include "bsppub.h"
#include "bspcomm.h"
//#include "opt_carr_attribute.h"
/**************************************************************************
                            初始化打桩结构体
**************************************************************************/
#if 0
#define IC_CHAN_FREQ_MAX_NUM ((UINT32)6)
#define IC_CHAN_MAX_NUM (8)
#define CLK_DL_LOGIC4_NUM ((UINT32)2) /** dl_logic4时钟域数目 */
#define CLK_UL_LOGIC1_NUM ((UINT32)2) /** ul_logic1时钟域数目 */
#define CLK_FB_LOGIC1_NUM ((UINT32)2) /** fb_logic1时钟域数目 */

typedef struct T_DifConfigInfoStruct
{
    UINT32 uiIqDataMode; /** ulch router模块数据补0模式：0：iq数据不变 1：iq数据最低bit补零 2：iq数据低两bit补零 */
    UINT32 uiRruType;    /** RRU标志 0: RRU 1:Qcell */
} T_DifConfigInfo;

typedef struct T_DifSamRateCommParaStruct
{
    UINT32 uiDpdSamRate[IC_CHAN_MAX_NUM]; /** DPD入口速率 */
    UINT32 uiCfrSamRate[IC_CHAN_MAX_NUM]; /** 削峰算法入口速率 */
    UINT32 uiAdc0SamRate;
    UINT32 uiAdc1SamRate;
    UINT32 uiAdcSamMode;
    UINT32 uiDacSamRate;
    UINT32 uiDacSamMode;
    UINT32 uiCbAdcSamRate;
    UINT32 uiCbAdcSamMode;
} T_DifSamRateCommPara;
typedef struct T_DifResourceAllocFreqParaStruct
{
    UINT32 uiFreqStart; /** 频段起始频点 */
    UINT32 uiFreqEnd;   /** 频段终止频点 */
    UINT32 uiPimcFlag;  /** PIMC有效标志 0：无效  1：有效 */
} T_DifResourceAllocFreqPara;

typedef struct T_DifResourceAllocChanParaStruct
{
    UINT32 uiTxFreqNum;                                           /** TX通道内的频段数 */
    UINT32 uiRxFreqNum;                                           /** RX通道内的频段数 */
    T_DifResourceAllocFreqPara tTxFreqPara[IC_CHAN_FREQ_MAX_NUM]; /** TX频段信息结构体 */
    T_DifResourceAllocFreqPara tRxFreqPara[IC_CHAN_FREQ_MAX_NUM]; /** RX频段信息结构体 */
} T_DifResourceAllocChanPara;

typedef struct T_DifResourceAllocCommParaStruct
{
    T_DifResourceAllocChanPara tResourceCommPara[IC_CHAN_MAX_NUM]; /** 所有通道的资源分配公共参数*/
} T_DifResourceAllocCommPara;

typedef struct T_DifTxRouteMapStruct
{
    /*各路由节点通道号和有效通道数*/
    UINT32 uiLinkId;  /** LINK对应的行编号 */
    UINT32 uiDifChan; /** LINK对应的中频通道号 */
    /* cfr的router0所需频段号 */
    UINT32 uiBankOut; /** LINK对应的BANK输出频段号?*/
    UINT32 uiCfrPort; /** LINK对应的CFR block的输入频段号 */
    /* cfr的combine所需频段号 */
    UINT32 uiCfrCombIn;  /** LINK对应的削峰合路的输入频段号*/
    UINT32 uiCfrCombOut; /** LINK对应的削峰合路的输出频段号 */
    /* cfr的router1所需频段号 */
    UINT32 uiCfrOut;  /** LINK对应的CFR BLOCK输出频段号 */
    UINT32 uiDpdPort; /** LINK对应的DPD输入频段号 */
    UINT32 uiCfrPortNum;
    UINT32 uiCfrCombPortNum;
    UINT32 uiCfrOutPortNum;
} T_DifTxRouteMap;

typedef struct T_DifTxRouteParaStruct
{
    UINT32 uiLinkId;       /** LINK对应的行编号 */
    UINT32 uiDifChan;      /** LINK对应的中频通道号 */
    UINT32 uiDpdMode;      /** dpd模式, 0:4T正常单相；1:4T简单两相；2:2T正常两相；3: PIMC模式（dpd block0不支持配置3）*/
    UINT32 uiSrc2Mode;     /** src2系数的模式选择：[1:0], 0:3/2倍  1:3倍  2:4倍 3:旁路*/
    UINT32 uiSrc3Mode;     /** src3模式选择：0:单相满速率2倍抽取，  1；两相满速率2倍抽取    2：单相半满速率3倍抽取  3：精延时*/
    UINT32 uiSrc3BypassEn; /** src3系数的选择：0:不旁路  1:旁路 */
    UINT32 uiEtMode;
    UINT32 uiCfrPhase2x;
    UINT32 uiDpdPhase2x;
} T_DifTxRoutePara;

typedef struct T_DifTx204RouteMapStruct
{
    UINT32 uiLinkId;     /** 链路行编号 */
    UINT32 uiDifChan;    /** LINK对应的中频通道号 */
    UINT32 uiDpdPort;    /** dlpost输入（即dpd输出）频段号,0-7为dpd输出，8-15为dpc前输出 */
    UINT32 uiDlPostPort; /** dlpost输出频段号 */
    UINT32 ui204PortI;   /** I路数据对应的204M */
    UINT32 ui204PortQ;   /** Q路数据对应的204M */
    UINT32 uiDlPostPortNum;
} T_DifTx204RouteMap;

typedef struct T_DifRxRouteMapStruct
{
    UINT32 uiLinkId;   /** LINK对应的行编号 */
    UINT32 uiDifChan;  /** LINK对应的中频通道号?*/
    UINT32 ui204Port;  /** ulch输入的通道号（对应240输出通道） */
    UINT32 uiUlChPort; /** ulch输出的通道号 */
    UINT32 uiUlChSwap; /** I、Q数据交换使能 */
} T_DifRxRouteMap;

typedef struct tag_DifFrInitCfg
{
    UINT32 uiLitFrPeriod;     // 小周期帧头
    UINT32 uiBigFrPeriod;     // 大周期帧头
    UINT32 uiDPDSampFrPeriod; // DPD采数周期
    UINT32 uiCbSWFrPeriod;    // 射频切换周期
    UINT32 uiCBFrFrameId;     // 射频切换帧号0-4095
} T_DifFrInitCfg;

typedef struct T_DifCLKCommParaStruct
{
    UINT32 ui737Clk;                       /** 737时钟域 */
    UINT32 uiDlCfrClk;                     /** dl_logic2 */
    UINT32 uiDlDpdClk;                     /** dl_logic3_0 */
    UINT32 uiDlPostClk[CLK_DL_LOGIC4_NUM]; /** dl_logic4 */
    UINT32 uiDlPimcClk;                    /** dl_logic6 */
    UINT32 uiUlChClk[CLK_UL_LOGIC1_NUM];   /** ul_logic1 */
    UINT32 uiCbClk[CLK_FB_LOGIC1_NUM];     /** fb_logic1 */
    UINT32 uiDlJ204SampleClk;
    UINT32 uiDlJ204WorkClk;
    UINT32 uiDlJ204SerdesClk;
    UINT32 uiUlJ204SampleClk;
    UINT32 uiUlJ204WorkClk;
    UINT32 uiUlJ204SerdesClk;
    UINT32 uiFbJ204SampleClk;
    UINT32 uiFbJ204WorkClk;
    UINT32 uiFbJ204SerdesClk;
    UINT32 uiJ204UlLogic2Clk;
    UINT32 uiJ204DlLogic5Clk;
    UINT32 uiJ204FbLogic2Clk;
} T_DifClkCommPara;
#endif
/**************************************************************************
                            时延相关打桩结构体
**************************************************************************/
typedef struct tagT_BspAdaptRruDelayReq
{
    UINT32	ulMainT12; /* 空口帧头提前量，单位：1/368.64M */
    UINT32	ulSlaveT12;
    UINT32	ulframeHeaderOffset; /*帧头偏移*/
    UINT32  ulframeNoOffset; /*帧号偏移*/
    UINT32  ulmainT34;
    UINT32  ulslaveT34;
}T_BspAdaptRruDelayReq;

/***********************************************************************/
/*打桩结构体*/
#if 0
typedef struct tagT_Sing_Carr_Info
{
    UINT32 uiDelOrAddFlag; /** 载波增删标志--0：保持；1：增加；2：删除*/
    UINT32 uiCarrId;       /** 载波号*/
    UINT32 uiCarrFreq;     /** 载波频点*/
    UINT32 uiCarrBw;       /** 载波带宽*/
    UINT32 uiCarrRadio;    /** 载波制式*/
    UINT32 uiIsSsb;        /** SSB载波标志*/
    UINT32 uiIsRcf;        /** 载波是否需要过成型滤波器-0：不需要过成型；1：需要过成型滤波器*/
} T_SingCarrInfo;
typedef struct tagT_Dif_Carr_Info
{
    UINT32 uiCarrNum;                                /** 该中频通道的中频载波总个数*/
    T_SingCarrInfo atCarrInfo[16]; /** 各中频载波信息*/
} T_DifCarrInfo;

#define BSP_MAX_TDD_NUM (4)
#define VGA_LUT_TAB_NUM (4)

//配频
/* 打桩结构体 */
#define   BSP_DIF_CARR_MAX_NUM   8
typedef struct tagT_Difhal_Chan_Info
{
    T_DifCarrInfo atChanInfo[IC_CHAN_MAX_NUM]; /** 全量的中频通道载波信息*/
} T_DifChanInfo;

#define BSP_MAX_TX_DIF_CARR_NUM                       (16UL)/** 单一天线的中频载波最大个数,10个中频载波（包含2个SSB）*/
#define BSP_MAX_RX_DIF_CARR_NUM                       (16UL)/** 单一天线的中频载波最大个数,8个中频载波*/
#define DLCFR_BLOCK_NUM (4)
#define DLPOST_BLOCK_NUM (2)
#define DLDPD_BLOCK_NUM (8)
#define ULCH_BLOCK_NUM (2)



typedef struct tagT_DifHal_Sing_Carr_Info
{
    UINT32 uiDelOrAddFlag;      /** 载波增删标志--0：保持；1：增加；2：删除*/
    UINT32 uiCarrId;            /** 载波号*/
    UINT32 uiCarrFreq;          /** 载波频点*/
    UINT32 uiCarrBw;            /** 载波带宽*/
    UINT32 uiCarrRadio;         /** 载波制式*/
    UINT32 uiIsSsb;             /** SSB载波标志*/
    UINT32 uiIsRcf;             /** 载波是否需要过成型滤波器-0：不需要过成型；1：需要过成型滤波器*/
}T_DifHalSingCarrInfo;

typedef struct tagT_DifHalCarr_Info
{
    UINT32 uiCarrNum;                                        /** 该中频通道的中频载波总个数*/
    T_DifHalSingCarrInfo atCarrInfo[BSP_MAX_TX_DIF_CARR_NUM];      /** 各中频载波信息*/
}T_DifHalCarrInfo;

typedef struct tag_DifPara
{
    UINT32 uiCfrSamRate[IC_CHAN_MAX_NUM];  //削峰速率
    UINT32 uiCfrGradeNum[IC_CHAN_MAX_NUM]; //削峰级数
    UINT32 uiCfrHbSta[IC_CHAN_MAX_NUM];    //搜峰速率，即CFR内部上插倍数，0为1x,1为4x
    UINT32 uiCfrMode[IC_CHAN_MAX_NUM];     //0：4x 1phase；1：4x 2phase；2：4x 4phase
    UINT32 uiCfrDlyFlag[IC_CHAN_MAX_NUM];  //CFR链路等时延标志，0：链路等时延 1：链路非等时延
    UINT32 uiCfrCpgLen[IC_CHAN_MAX_NUM];   //等时延下，削峰半长
    UINT32 uiCfrByPassMode[IC_CHAN_MAX_NUM];  //CFR旁路模式,0:等时延旁路，1：0时延旁路
    UINT32 uiCfrCpgTheoryLen[IC_CHAN_MAX_NUM]; //CFR根据规格算法提供一个理论的CPG长度，供光口建小区时时延计算上的使用
    UINT32 uiDpdClk[IC_CHAN_MAX_NUM];   
    UINT32 uiAdcSamRate;
    UINT32 uiAdcSamMode;
    UINT32 uiDacSamRate;
    UINT32 uiDacSamMode;
    UINT32 uiCbAdcSamRate;
    UINT32 uiCbAdcSamMode;
    UINT32 uiCbAdcPhaseNum;
} T_DifPara;

typedef struct T_DifFbRouteMapStruct
{
  UINT32 uiLinkId[IC_CHAN_MAX_NUM];         /** LINK对应的行编号 */
  UINT32 uiDifNum;                          /** LINK对应的中频通道数 */
  UINT32 uiDifChan[IC_CHAN_MAX_NUM];        /**?LINK对应的中频通道号?*/
  UINT32 ui204PortI[IC_CHAN_MAX_NUM];       /** LINK对应的204的16路数据I路对应的通道号(由于I/Q数据绑定，按I路数据的通道号进行索引0/2/4/6……) */
  UINT32 uiFbPort[IC_CHAN_MAX_NUM];         /** 反馈的通道号 */
  UINT32 uiFbPortNum;                       /** 反馈的有效通道数 */
  UINT32 uiFb0EvenChanSel[IC_CHAN_MAX_NUM]; /** fb0奇路通道选择 */
  UINT32 uiFb0OddChanSel[IC_CHAN_MAX_NUM];  /** fb0偶路通道选择 */
  UINT32 uiFb1EvenChanSel[IC_CHAN_MAX_NUM]; /** fb1奇路通道选择 */
  UINT32 uiFb1OddChanSel[IC_CHAN_MAX_NUM];  /** fb1偶路通道选择 */
  /************* 后续扩展参数在这之后填加 ****************/
} T_DifFbRouteMap;

typedef struct tag_filter_coef_cfg1
{
    UINT32 radioMode;
    UINT32 ulBandWidth;
    UINT32 ulSampleRate;
    UINT32 uluRLLCFlag;//超低延时标志
    UINT32 ulNarrowBandFlag;
    UINT32 ulNarrowBandVal;
    UINT32 *pulCoefArray;
    UINT32 ulCoefLen;
}T_FILTER_COEF_CFG1;



typedef struct _T_DifTxRouteMapTmp
{
    /*各路由节点通道号和有效通道数*/
    UINT32 linkId;            /* LINK对应的行编号 */  
    
    /* cfr的router0所需频段号 */
    UINT32 bankOut;           /* LINK对应的BANK输出频段号 */
    UINT32 cfrPort;           /* LINK对应的CFR block的输入频段号 */
    UINT32 cfrPortNum;        /* 削峰block输入频段的有效频段数(按1个cfr block计算) */
    
    /* cfr的router1所需频段号 */
    UINT32 cfrCombIn;         /* LINK对应的削峰合路的输入频段号*/
    UINT32 cfrCombPortNum;     /* 削峰合路输入频段的有效频段数(按1个cfr block计算) */
    UINT32 cfrCombOut;        /* LINK对应的削峰合路的输出频段号(即算法模块输入通道号) */

    /* cfr的router2（cfr到dpd路由）所需频段号 */
    UINT32 cfrOut;            /* LINK对应的CFR BLOCK输出频段号 */ 
    UINT32 cfrOutPortNum;     /* 削峰block输出的有效频段数(有频段复制时为频段复制后的有效频段数) */
    UINT32 dpdPort;           /* LINK对应的DPD输入频段号，DPD复杂四相时频段需要在cfr的router2复制一份?*/
    UINT32 difChan;           /* LINK对应的中频通道号 */

    /*路由相关参数*/
    UINT32 src2Mode;          /* src2系数的模式选择：0:2倍  1:3倍  2:4倍  3:旁路 (决定滤波器所用的系数) */      
    UINT32 src3Mode;          /* src3模式选择：0:单相半满速率2倍抽取，  1；单相满速率2倍抽取    2：两相满速率2倍抽取
                                                                3：四相满速率2倍抽取    4：1:2输入速率下精延时滤波（不抽取）  5：1:1输入速率下精延时滤波（不抽取）*/
    UINT32 src3BypassEn;      /* src3系数的选择：0:不旁路  1:旁路 */   
    UINT32 dpdMode;           /* dpd模式(七种基础模式) 0:32T正常单相；1:32T简单两相；2:16T复杂单相；3:16T正常两相；
                                                                4:8T复杂两相；5:8T正常四相；6:4T复杂4相；*/    
    UINT32 etMode;            /* ET模式  0：无效  1：ET的仅PA   2: ET的PA&电源  3：DPA */   
    UINT32 cfrPhase2x;        /* cfr两相标志 */
    UINT32 dpdPhase2x;        /* dpd两相标志 */
    /************* 后续扩展参数在这之后填加 ****************/

} T_DifTxRouteMapTmp;

typedef struct _T_DifTx204RouteMap
{
    /*各路由节点通道号和有效通道数*/
    UINT32 linkId;            /* LINK对应的行编号 */  
    
    /* dlpost到204路由所需频段号 */
    UINT32 dlPostPort;        /* Link对应的DLPOST输入通道号(即为DPD输出频段号),DPD为EA/ET/DPA模式时输出不同 */
    UINT32 dlPostPortNum;     /* dlpost输出的有效频段数(按1个dlpost block计算) */
    UINT32 j204PortI;         /* LINK对应的204的32路数据I路对应的通道号(由于I/Q数据绑定，按I路数据的通道号进行索引0/2/4/6……) */ 
    UINT32 difChan;           /*LINK对应的中频通道号*/
    /************* 后续扩展参数在这之后填加 ****************/

} T_DifTx204RouteMapTmp;

typedef struct _T_DifRxRouteMapTmp
{
    UINT32 linkId;        /* LINK对应的行编号 */
    UINT32 difChan;       /*LINK对应的中频通道号*/
    UINT32 j204PortI;     /* LINK对应的204的32路数据I路对应的通道号(由于I/Q数据绑定，按I路数据的通道号进行索引0/2/4/6……) */
    UINT32 ulChPort;      /* ulch的通道号 */
    UINT32 ulChPortNum;   /* ulch的有效通道数 */
    UINT32 uiUlChPhase2x; /* ulch两相标志 */
    /************* 后续扩展参数在这之后填加 ****************/
} T_DifRxRouteMapTmp;

typedef struct _T_DifFbRouteMapTmp
{
    UINT32 linkId;         /** LINK对应的行编号 */
    UINT32 difChan;        /** LINK对应的中频通道号 */
    UINT32 j204PortI;      /** LINK对应的204的16路数据I路对应的通道号(由于I/Q数据绑定，按I路数据的通道号进行索引0/2/4/6……) */
    UINT32 fbPort;         /** 反馈的通道号 */
    UINT32 fbChSel;        /** 反馈通道选择  0：fb0  1：fb1 */
    UINT32 fbChMode;       /** 反馈通道模式  0：单反馈  1：双反馈 */
    UINT32 fbPhaseNum;     /** 反馈相数 0：单相 1：双相 */
    /************* 后续扩展参数在这之后填加 ****************/
} T_DifFbRouteMapTmp;

 typedef struct tagDlyCfgHalPara
{
    UINT32 cfrphase;  //削峰相数，0：单相 1：双相
    UINT32 cfrGrade;  //削峰级数
    UINT32 cpglen;     //当前通道的最终的CPG长度，等长时为固定长度，非等长为最大长度，目前只需要传cpg长度，预留结构体待后续传递
    UINT32 cfrwinmax;  //削峰窗长等级，1个通道中取最大的

}T_DlyCfgCfrPara; 


typedef struct tag_PreAllocBwInfo
{
    UINT32 index;
    UINT32 nrNum;
    UINT32 lteNum;
    UINT32 bandWidth[8];     //大带宽往前排，降序排列
}T_PreAllocBwInfo;

//场景预置
typedef struct tagT_PreAlloc
{
    UINT32 chanMask;
    T_PreAllocBwInfo preAllocBwInfo;
}T_PreAlloc;
#endif
#if 0
//功率控制

typedef struct tagT_Tssi_Chk
{
    UINT32 uiTssiAsynMod;   //分载波Tssi功率上报模式 0-同步 1-异步
    UINT32 uiPowCalcMod;    //Tssi功率检测模式 0-平均值 1-最大值
    UINT32 uiAvgThred;      //平均功率筛数门限配置
    UINT32 uiAvgSymLen;     //符号长度配置
    UINT32 txPwcStart;      //Tssi功率检测起始位置配置
    UINT32 txPwcEnd;        //Tssi功率检测结束位置配置
    UINT32 pcPowCalEndPrd;  //PC功率检测end周期的长度
    UINT32 pcPowCalEndNum;  //PC功率检测end个数
}T_TssiCheck;

typedef struct tagT_Rssi_Chk
{
    UINT32 uiSfLen;         //Rssi子帧长度配置
    UINT32 uiRxSfEn;        //长时Rssi的子帧使能配置
    UINT32 uiRx1SfEn;       //短时Rssi的子帧使能配置
    UINT32 uiRxStart;       //Rssi功率检测起始位置配置
    UINT32 uiRxEnd;         //Rssi功率检测结束位置配置
    UINT32 uiRx1Start;      //短时Rssi功率检测起始位置配置
    UINT32 uiRx1End;        //短时Rssi功率检测结束位置配置
    UINT32 uiRssiCalThr;    //Rssi功率检测门限配置
    UINT32 uiRssi1CalThr;   //短时Rssi功率检测门限配置
    UINT32 uiRssiCalGrp;    //Rssi功率检测组数配置
//后续考虑功率检测无线帧号配置及真好旁路；
}T_RssiCheck;

typedef struct tagT_PowCtrl_Para
{
    UINT32 ifFwdPos;        //功率检测位置配置(nco、src的选择)
    UINT32 rfSwitchDly;     //射频开关切换延时配置
}T_PowCtrl_Para;

typedef struct tagT_PowCtrl
{
    UINT32      chanNoMask;      //中频通道号
    T_TssiCheck tTssiCheck;
    T_RssiCheck tRssiCheck;
    T_PowCtrl_Para tPowCtrlPara;
}T_PowCtrl;

typedef struct tagT_PowChk_Cfg1
{
    UINT32    powNum;
    T_PowCtrl tPowCtrl[BSP_MAX_TDD_NUM];
}T_PowChk_Cfg1;

typedef struct tagT_pow
{
    INT32 tssiPow;      //uint:0.01dBFs
    INT32 fwdPow;       //uint:0.01dBFs
}T_Pow;

typedef struct tagT_CarrPow1
{
    UINT32 splitCarrNo;
    T_Pow  tPow;
}T_CarrPow1;

typedef struct vgactrlGain
{
    INT32  rfFixGain;                           //16通道共用一个增益值，0.5db
    INT32  diffFacx;                            //facx用于补偿各射频通道增益偏差，射频提供，0.1db
    UINT32 vgaMode;                             //vga模式 VGA_MODE_AGC--表示AGC模式
    UINT32 agcJ204Switch;                       // VGA_AGC_J204_ENABLE：J204传送slicer信息
    UINT32 agcSlicerBitNum;                     //agc模式下slicer bit位宽;
    UINT32 agcSlicerDbStep;                     //agc模式下slicer biUINT32 initVgaAgcCompPara(UINT32 chip,UINT32 j204En)t位宽;
    UINT32 vgaType;                             //0- 90XX, 1-79XX;
    UINT32 vgaLutTab[VGA_LUT_TAB_NUM];          // slicer表，目前看IC3中是四个寄存器
}T_VgaCtrlRfGain;

typedef struct vgaAgcPara
{
    UINT32 Kp;
    UINT32 CompIdx;
    UINT32 CompThr;
    UINT32 CompMode;
    UINT32 CompBypass;
    UINT32 CompUndecLen;
    UINT32 DcrmPt;
}T_VgaAgcPara;


//J204C
/*DPDIC4编译修改，拔桩*/

typedef struct tagT_DifSysrefCfg
{
    UINT32 uiSysrefEn;          //发sysref使能，0代表往外发sysref，1代表不往外发sysref
    UINT32 uiSysrefFrDelay;     //sysref帧头延时配置（默认配置0）,单位是737时钟下的一个clk，最大值为0xfffffff
    UINT32 uiMode;              //设置sysref发送模式，0代表发固定个数sysref，1代表sysref常发
    UINT32 uiLocalcntSyncEn;    //配置系统同步信号产生周期计数器清0，0:帧头到来时不清周期计数器，1：帧头到来时清周期计数器
    UINT32 uiSyncSrc;           //配置产生系统同步信号的寄存器源，0：选择前级空空口帧头，1：多片同步信号（IO引脚）
    UINT32 uiPeriod;            //配置发sysref信号的周期，取值为0-6，取值为0对应960Khz,取值为1对应480Khz，取值为2对应240Khz、取值为3对应120Khz、取值为4对应60Khz、取值为5对应30Khz、取值为6对应15Khz。具体见表SysPerTbl;
    UINT32 uiWidth;             //配置脉冲高电平宽度，其值不大于周期的一半
    UINT32 uiSysPha;            //配置初始相位
    UINT32 uiSysrefNum;         //配置发sysref个数
} T_DifSysrefCfg;


/**************************************************************************
                            反馈开关控制相关接口
**************************************************************************/

#define STATIC_FBRFRAM_DEEPTH_STUB (8*3) //  四个TRS要同参数，3种状态最大32chn，后三列TRS和第一个TRS一致通道开关配置
#define DPD_RFCHN_MAX_STUB    (8)  //DPD最大也是32chn

//5bit+2bit+...  共10bit
typedef struct  FbRfChnCtrl 
{
    uint16_t RfTrsChnCtrlSel;
    uint16_t RfTrsChnCtrlSel_len;
    uint16_t RfChnSel;
    uint16_t RfChnSel_len;
    uint16_t Res;
    uint16_t Res_len;

}T_FbRfChnCtrl;//不用的列，len为0

typedef struct  FbRfChnCtrlSelTab 
{
    UINT32 chanNum;//天线总数？？？   真值表按最大设置，这里这个参数只是真实天线总数的获取
    T_FbRfChnCtrl FbRfStaticT[STATIC_FBRFRAM_DEEPTH_STUB][4];//每一行传4个transceiver参数,每个10bit;目前看这个数字4应该不可更改

}T_FbRfChnCtrlSelTab;

typedef struct  FbDPDChnSelTab 
{
    UINT32 chanNum;//天线总数
    T_FbRfChnCtrl FbDPDStaticT[DPD_RFCHN_MAX_STUB];//每一行传1个天线参数，只会涉及一个TRS

}T_FbDPDChnSelTab;//DPD选择天线的配置

typedef struct FbPeriodChnSel 
{
    uint8_t delayProtect;//保护时间
    uint8_t tranId;//非chnA ChnB对应的tranId 可用作DPD
    uint8_t status;//该时间片任务
    uint8_t chanA;//通道选择RfTrsChnCtrlSel,无论单反馈还是双反馈都是 按静态表32行进行选择
    uint8_t ChanB;//   chanA,chanB的选择比较固化，不能太灵活，根据后端射频控制开关，相同TRS两个通道是绑定选择的;不同TRS各一个通道是需要一致开关控制的
    uint16_t period;//时间片周期 单位ms

}T_FbPeriodChnSel;

//光口
UINT32 IcHalSetCellParaValue(UINT32 uCellId,UINT32 uDir,UINT32 uType,UINT32 uFuncId,UINT32 uVal);
#endif
/**************************************************************************
                            DPD相关接口
**************************************************************************/
#define DPD_CHAN_NUM               8
typedef struct T_HalIcDspRouterStruct
{
    UINT32 cfrport[DPD_CHAN_NUM];  //削峰算法模块出口通道号：0~31；   blockId = uiCfrPort/8；  logicChan = uiCfrPort%8;
    UINT32 cfrportnum; //一个中频通道号对应的削峰通道数（出于高频场景等考虑）
    UINT32 dpdport[DPD_CHAN_NUM]; //DPD算法模块出口通道号：0~31；   blockId = uiDpdPort/4；  logicChan = uiDpdPort%4;
    UINT32 dpdportnum; //一个中频通道号对应的DPD通道数（出于高频场景、ET/DPA模式等考虑）
    UINT32 cfrsamprate;//出口，单位khz
    UINT32 src2samprate; //出口，单位KHz
    UINT32 src3samprate; //出口，单位KHz
    UINT32 fb204csamprate; //出口，单位KHz
    UINT32 dpdmode;//七种基础模式，对应寄存器配置值
    UINT32 etmode;//对应寄存器
    UINT32 reserve[8];     /* 保留 */
}T_HalIcDspRouter;
// typedef struct T_DifDspRouteStruct
// {
//   UINT32 uiCfrPort[8]; /** 削峰算法模块出口通道号：0~31； blockId = uiCfrPort/8；logicChan = uiCfrPort%8 */
//   UINT32 uiCfrPortNum;                        /** 一个中频通道号对应的削峰通道数（出于高频场景等考虑）*/
//   UINT32 uiDpdPort[8]; /** DPD算法模块出口通道号：0~31； blockId = uiDpdPort/8；logicChan = uiDpdPort%8 */
//   UINT32 uiDpdPortNum;                        /** 一个中频通道号对应的DPD通道数（出于高频场景、ET/DPA模式等考虑）*/
//   UINT32 uiCfrSampRate;                       /** 出口，单位khz */
//   UINT32 uiSrc2SampRate;                      /** 出口，单位KHz */
//   UINT32 uiSrc3SampRate;                      /** 出口，单位KHz */
//   UINT32 uiFb204cSampRate;                    /** 出口，单位KHz */
//   UINT32 uiDpdMode;                           /** 七种基础模式 0:32T正常单相；1:32T简单两相；2:16T复杂单相；3:16T正常两相；4:8T复杂两相；5:8T正常四相；6:4T复杂4相 */
//   UINT32 uiEtMode;                            /** ET/DPA模式：0：无效  1：ET的仅PA   2: ET的PA&电源  3：DPA */
//   UINT32 uiCfrBlockPortNum;                   /** 一个cfr block使用的通道数 */
//   UINT32 uiStagePortNum;                      /** 一个削峰stage支持的频段数 */
// } T_DifDspRoute;
#if 0
/**************************************************************************
                            光口serdes 相关接口
**************************************************************************/

typedef enum
{
    OPTPCS_ETH = 0,
    OPTPCS_CPRI,
} E_OPTPCS_USER_MODE; /* pcs通道使用类型:以太网还是cpri */
typedef enum 
{
    OPTPCS_BIND_MODE_4T1X = 0,
    OPTPCS_BIND_MODE_1T2X_2T1X,
    OPTPCS_BIND_MODE_2T1X_1T2X,    
    OPTPCS_BIND_MODE_1T2X_1T2X,
    OPTPCS_BIND_MODE_4X,
    OPTPCS_BIND_MODE_NG = 0xff, /* 表示没有使用 */
} E_OPTPCS_BIND_MODE;

typedef enum 
{
    OPTPCS_PORT_MODE_1X = 0,
    OPTPCS_PORT_MODE_2X,
    OPTPCS_PORT_MODE_4X,    
} E_OPTPCS_PORT_MODE;

typedef enum 
{
    OPTPCS_ETH_50G_66B=0,
    OPTPCS_ETH_25G_10G_5G_66B, /* 25g/10g/5g */
    OPTPCS_ETH_1G_2P5G_10B,  /* 1g/2.5g */ 
    
    OPTPCS_CPRI_66B = 5,    
    OPTPCS_CPRI_1G_10B,
    OPTPCS_CPRI_OTHER_10B,

    OPTPCS_ETH_4X_200G =0,
    OPTPCS_ETH_4X_100G,
    OPTPCS_ETH_4X_40G,
} E_OPTPCS_PROTOCOL_TYPE;

typedef enum OPTPCS_FEC_TYPE
{
    OPTPCS_FEC_TYPE_BYPASS=0,
    OPTPCS_FEC_TYPE_BRFEC,
    OPTPCS_FEC_TYPE_RSFEC528,
    OPTPCS_FEC_TYPE_RSFEC544,

} E_OPTPCS_FEC_TYPE;

typedef enum 
{
    OPTPCS_PCS_GEAR_WIDTH_8B = 0,
    OPTPCS_PCS_GEAR_WIDTH_10B,
    OPTPCS_PCS_GEAR_WIDTH_16B,
    OPTPCS_PCS_GEAR_WIDTH_20B,
    OPTPCS_PCS_GEAR_WIDTH_32B,
    OPTPCS_PCS_GEAR_WIDTH_40B,
    OPTPCS_PCS_GEAR_WIDTH_64B,
    OPTPCS_PCS_GEAR_WIDTH_80B,
    OPTPCS_PCS_MAX_GEAR_WIDTH,
} E_OPTPCS_PCS_GEAR_WIDTH;

typedef struct
{
    UINT32                     udPcsPortIdx;         /* pcs serdes通道索引 [0-9] */
    E_OPTPCS_USER_MODE         udEthOrCpri;          /* eth or cpri */
    E_OPTPCS_BIND_MODE         udBindMode1x4x;       /* portmode这个配置，后续不再采用，为了和上层一致，pcs的portmode从trin portmode获取 */
    E_OPTPCS_PORT_MODE         udPortMode;
    E_OPTPCS_PROTOCOL_TYPE     udProtocolType;
    E_OPTPCS_FEC_TYPE          udFecMode;
    E_OPTPCS_PCS_GEAR_WIDTH    udGearBoxBW;
    UINT32                     udLpType;        /* 0:不环回,1:OPTPCS_LL_LOOPBACK, 2:OPTPCS_PREGEAR_LOOPBACK, 3:OPTPCS_LOCAL_LOOPBACK , 4:OPTPCS_REMOTE_LOOPBACK */
    UINT32                     rsfecEvenEn;     /* cpri rsfec LANE 均匀输出使能:在cpri 24G、50G(这两种模式都会启用rsfec)时，才需要打开 */
    UINT32                     rsfecEvenMod;     /* cpri rsfec LANE 均匀输出模式, 0:24G@800M  1:50G@800M 或者 24G@400M */
} T_PCS_CONFIG_TBL;   /*pcs通道配置表*/

/*hal serdes合入后去掉*/
typedef enum
{
    POWER_DOWN_PLL = 0,
    POWER_DOWN_TX,
    POWER_DOWN_RX
} E_LYCA_POWER_DOWN_TYPE;

typedef enum
{
	CPRI_EXCEPT_10G_MODE = 0,
	ETH_MODE,
	CPRI_10G_MODE,
	RESERVED_MODE
}E_LYCA_CLK_CFG;
#endif
/******************************************************************************
 *                              opt模块打桩
 ******************************************************************************/
//#define D_OPT_CELL_NUM_MAX (16)
#if 0
enum e_OPT_ADPT_DIR
{
    OPT_ADPT_DIR_UL=0,
    OPT_ADPT_DIR_DL,
    OPT_ADPT_DIR_MAX
};

#endif
#if 0

enum OAM_CELL_CARR_SAMPLERATE
{
    OAM_CELL_CARR_SAMPLERATE_30M72 = 0,
    OAM_CELL_CARR_SAMPLERATE_46M08,
    OAM_CELL_CARR_SAMPLERATE_61M44,
    OAM_CELL_CARR_SAMPLERATE_76M8,
    OAM_CELL_CARR_SAMPLERATE_92M16,
    OAM_CELL_CARR_SAMPLERATE_122M88,
    OAM_CELL_CARR_SAMPLERATE_153M6,
    OAM_CELL_CARR_SAMPLERATE_184M32,
    OAM_CELL_CARR_SAMPLERATE_245M76,
    OAM_CELL_CARR_SAMPLERATE_23M04,
    OAM_CELL_CARR_SAMPLERATE_MAX
};

typedef struct T_OptInitPara
{
	UINT32            reserved[4];  //后续光口初始化,如需传递参数,则作为扩展传参
} T_OptInitPara;

/* 该结构体为Funclib 与 ICHAL之间交互的结构体. bsppub.h中T_CellCfgInfo为Funclib与APP交互使用 */
typedef struct T_OptCellCfgInfo {
    UINT32 cellIndex;
    UINT32 cellAdFlag;
    UINT32 cellMcsId;
    UINT32 cellLocalCarrNo;
    UINT32 cellBw[2];
    UINT8  cellIFType;   //IF0/IF1;
    UINT8  cellBearType; //CPRI/ECPRI/ROE
    UINT8  cellSCSBitMap;
    UINT8  cellTTI;     //枚举;
    UINT32 cellAntRadioMode;//小区制式
    UINT32 cellCarrNo;   //一个小区内所有天线载波号一样。
    UINT32 cellAntMask[2];
    UINT32 cellULCompressMode;
    UINT32 cellDLDeCompressMode;
    UINT8  cellTxSymbolBit[112];
    UINT8  cellRxSymbolBit[112];
    UINT32 cellIQPkgOLEN[2];  /*上下行*/
    UINT32 iqSampleRate;   //ecpri IF1 需要此字段。
    UINT32 cellgScn;
    UINT32 cellSsbValid;
    UINT8  fftaCpType;  //类型，normal or extern
    UINT32 cellCAMode;
    UINT8  cellPrachDagcEn; //VBPC 填0，PRACH不传输DGAC，VBPD 填1，需要传输DGAC
    UINT32 resIndex[2];  // 光口小区资源位置
    UINT8  resv[2];
} T_OptCellCfgInfo;

/*port*/
typedef enum
{
	L2SS_TRXP0 = 0,
	L2SS_TRXP1,
	L2SS_TRXP2,
	L2SS_TRXP3,
	L2SS_TRXP4,
	L2SS_TRXP5,
	L2SS_TRXP6,
	L2SS_TRXP7,
	L2SS_TRXP8,
	L2SS_TRXP9,
	L2SS_MAX_EPORT_ID,

	L2SS_TRXP32 = 12,
	L2SS_TRXP33,
	L2SS_TRXP34,
	L2SS_TRXP35,
	L2SS_TRXP36,
	L2SS_TRXP37,
	L2SS_TRXP38,
	L2SS_TRXP39,
	L2SS_TRXP40,
	L2SS_TRXP41,
	L2SS_TRXP42,
	L2SS_TRXP43,
	L2SS_TRXP44,
	L2SS_TRXP45,
	L2SS_TRXP46,
	L2SS_TRXP47,
	L2SS_TRXP48,
	L2SS_TRXP49,
	L2SS_TRXP50,
	L2SS_TRXP51,
	L2SS_TRXP52,
	L2SS_TRXP53,
	L2SS_TRXP54,
	L2SS_TRXP55,
	L2SS_MAX_IPORT_ID,
	L2SS_TRXP_NUM =64,

}E_TrxpId;
/*环回模式配置值*/
typedef enum
{
    e_LOOP_CLR = 0, // 0
    e_LOOP_DIRECT,  // 1 系统环回
    e_LOOP_OAM,     // 2 OAM环回
    e_LOOP_PD,         // 3  远端环回
    e_LOOP_FAR_RSV,        // 4 远端环回，保留
    e_LOOP_NEAR,       // 5 近端环回
    e_ERR_PKG_TO_CPU,  // 6 报文出错送CPU使能
    e_LOOP_TSREPLACE,  // 7 接收时间戳替换使能
    e_LOOP_MAC,        // 8 远端和近端环回MAC地址交换
    e_LOOP_ERROR,      //9 rsv
}E_LoopMode;
#endif
/*----------------------当前场景下的小区配置模式----------------------*/
typedef enum
{
    BSP_CELL_CFG_MODE_ONLY_NR = 0,
    BSP_CELL_CFG_MODE_ONLY_LTE,
    BSP_CELL_CFG_MODE_MIX_NR_LTE,
    BSP_CELL_CFG_MODE_NUM,
}E_BSP_CELL_CFG_MODE;
#if 0
typedef struct
{
    UINT32 udch0mode;
    UINT32 udch1mode;
    UINT32 udch2mode;
    UINT32 udch3mode;
}T_TRPG_GROUP_MODE_CFG; /*trpg端口组模式配置，每组4个端口 */
typedef enum
{
	e_NTL_INNER_BOARD= 0,   /* 板内通道 */
	e_NTL_BACK_BOARD,       /* 背板通道 */
	e_NTL_FRONT_BOARD,      /* 面板通道 */
	e_NTL_PORT_TYPE_NUM,    /* 最大值 */
}E_NTL_PORT_TYPE;
typedef struct
{
    UINT32 udPortId; /* E_XMAC_PORT_ID */
    E_NTL_PORT_TYPE eType;
    UINT32 eSpeed;  /*速率的定义参考E_XMAC_SPEED_TYPE*/
	UINT32 fecMode;
}T_NtlPortCfg;

typedef struct
{
	UINT32 idx;
    UINT32 chnNo;     /*4个通道的下的通道索引*/
	UINT32 chnDir;     /*CW业务方向*/
    UINT32 chnTpe;     /*承载的CW的业务类型*/
	UINT32 chnExtLp;   /*控制字通道的L2SS外逻辑端口*/
	UINT32 chnInnPp;   /*控制字通道的L2SS的内物理端口*/
    UINT32 chnUdpPort;  /*CW通道的该业务报文的udp端口号*/
    UINT32 chnFlowId;  /*CW通道的该业务报文的flowid*/
	UINT32 chnVaild;   /*CW通道的有效配置标志*/
}T_NtlCwChnCfg;


typedef struct
{
    /*top*/
    UINT32 relation_phyopt;         /*对应的物理光口号*/
    UINT32 paritySeparate;          /*AXC的奇偶分离配置:0-不分离,1-分离*/
    UINT32 axcChanNum;              /*AXC的单双通道配置：0-单通道，1-双通道*/
    UINT32 externMode;             /*逻辑光口控制字传IQ模式:3-极限扩展,有效控制字32bit; 1-常规扩展,有效控制字128bit; 0-控制字位置不传IQ*/
    UINT32 loopEn;                  /*环回*/

    /*net*/
    UINT32 swFrMode;
    UINT32 swFrPeriod;
    UINT32 frameFrMode;
    UINT32 framePeriod;
} T_LOG_OPT_PROPERTY;

typedef struct
{
    UINT32 lineRate;                /*线速率:0-2.4576GHz; 1-3.072GHz;2-4.9152HGz;3-6.144GHz;4-9.8304GHz;5-10.1376GHz;*/
                                    /*6-12.16512GHz;7-24.33024GHz;8-48.66048GHz;Other values-2.4576GHz*/
    UINT32 property;                /*0-上联,1-下联,2-未知态,3-无光态 (propertyCfgEn=1 valid)*/
    UINT32 propertyCfgEn;           /*opt property cfg enable   1-enable*/
    UINT32 chipInterConn;           /*1-CHIP间互联光口*/
    UINT32 fsmState;                /*状态*/
    UINT32 bindOptSel;
} T_PHY_OPT_PROPERTY;

#define OPT_MAX (4)
typedef struct
{
    UINT32 optMask;                /*初始化掩码 (bit0-bit3：对应四个逻辑光口，bit4：对应虚光口)*/
    UINT32 protocol;               /*0-cpri; 1-Ir; 2-qcell*/
    UINT32 netmode;                /*0-cascade;1-star;2-cascade;3-m_s;4-ring;5-load share;6-load share and ring */
    UINT32 netmodesta;             /*0:1 uplink; 1:2 uplink; 3:4 uplink*/
    UINT32 cpuCfgEn;               /*1:cpu configuration valid; 0:no care cpu configuration--> opt relation*/
    UINT32 mainopt;
    T_LOG_OPT_PROPERTY logOptProp[OPT_MAX + 1];    /*X=4 为 unknown 光口*/
    T_PHY_OPT_PROPERTY phyOptProp[OPT_MAX + 1];    /*X=4 为 unknown 光口*/
} T_OptCpriInfo;
#endif


/**************************************************************************
                            J204相关接口打桩
**************************************************************************/
/* J204 serdes */
//UINT32 IcHalApiJ204SdsLoadFw(UINT32 laneIdMask,UINT32 txDataRate,UINT32 rxDataRate,BOOL refreshExtFw);
//UINT32 IcHalApiPhyApbResetCfg(UINT32 serdesId,UINT32 rstFlag);
//UINT32 IcHalApiJ204SdsTxPwron(UINT32 laneIdMask);
//UINT32 IcHalApiJ204SdsRxPwron(UINT32 laneIdMask);
//UINT32 IcHalApiJ204SdsTxPwrDn(UINT32 laneIdMask);
//UINT32 IcHalApiJ204SdsRxPwrDn(UINT32 laneIdMask);
//UINT32 IcHalApiJ204SdsTxDataEn(UINT32 laneIdMask,BOOL enable);
//UINT32 IcHalApiJ204SdsRxDataEn(UINT32 laneIdMask,BOOL enable);
//UINT32 IcHalApiAdjustJ204SerdesTxEq(UINT32 laneIdMask,UINT32 eqPre,UINT32 eqPost,UINT32 eqMain);

UINT32 IcHalApiInitOptFftaPara(UINT32 cellId, UINT32 dir, UINT32 scs, T_FFTACfgPara* fftaPara);
UINT32 IcHalApiInitOptFftaHwCfg();
UINT32 IcHalApiPreCfgL1OptByWorkMode(UINT32 workMode);
UINT32 IcHalApiUpdataGscn(UINT32 uRadioMode, UINT32 uCellId, UINT32 uGscn, UINT32 uSsbValid);
//UINT32 IcHalApiSetCellCfgMode(UINT32 uCellCfgMode);
UINT32 IcHalApiSetTxIcPreDly(UINT32 radio, UINT32 *preDly, UINT32 dlyNum);
UINT32 IcHalApiSetTxIcPostDly(UINT32 radio, UINT32 *postDly, UINT32 dlyNum);
UINT32 IcHalApiSetRxIcPreDly(UINT32 radio, UINT32 *preDly, UINT32 dlyNum);
UINT32 IcHalApiSetRxIcPostDly(UINT32 radio, UINT32 *postDly, UINT32 dlyNum);
UINT32 IcHalApiGetT2aDlyMax(UINT32 radio, UINT32 *dly);
UINT32 IcHalApiGetTa3DlyMax(UINT32 radio, UINT32 *dly);
UINT32 IcHalApiSetReportT2aDly(UINT32 radio, UINT32 t2aDlyForward, UINT32 t2aDlyReverse);
UINT32 IcHalApiSetReportTa3Dly(UINT32 radio, UINT32 ta3DlyForward, UINT32 ta3DlyReverse);

UINT32 IcHalApiGetDlCarrGain(UINT32 difChan, UINT32 radioMode, UINT32 carrIndex, INT32 *pGain);
UINT32 IcHalApiSetDlCarrGain(UINT32 difChan, UINT32 radioMode, UINT32 carrIndex, INT32 gain);
UINT32 IcHalApiSetDlCarrGainSw(UINT32 difChan, UINT32 radioMode, UINT32 carrIndex, INT32 isOn);
UINT32 IcHalApiSetUlCarrGainSw(UINT32 difChan, UINT32 radioMode, UINT32 carrIndex, INT32 isOn);
UINT32 IcHalApiGetDlCarrGainSw(UINT32 difChan, UINT32 radioMode, UINT32 carrIndex, INT32 *pIsOn);
UINT32 IcHalApiGetUlCarrGainSw(UINT32 difChan, UINT32 radioMode, UINT32 carrIndex, INT32 *pIsOn);
UINT32 IcHalApiSetCarrBalanceGain(UINT32 difChan, UINT32 radioMode, UINT32 carrIndex, INT32 gain);
UINT32 IcHalApiGetCarrBalanceGain(UINT32 difChan, UINT32 radioMode, UINT32 carrIndex, INT32 *pcarrGain);
UINT32 IcHalApiSetK0Gain(UINT32 difChan, INT32 uiGain);
UINT32 IcHalApiGetK0Gain(UINT32 difChan, INT32 *pGain);
UINT32 IcHalApiSetK1Gain(UINT32 difChan, INT32 uiGain);
UINT32 IcHalApiGetK1Gain(UINT32 difChan, INT32 *pGain);
UINT32 IcHalApiSetK2Gain(UINT32 difChan, INT32 uiGain);
UINT32 IcHalApiGetK2Gain(UINT32 difChan, INT32 *pGain);
UINT32 IcHalApiClrDlCarrGain(UINT32 difChan, UINT32 radioMode, UINT32 carrIndex);
UINT32 IcHalApiSetDlGain(UINT32 difChan, UINT32 radioMode, UINT32 carrIndex, INT32 carrDb);
UINT32 IcHalApiRxPcGain(INT32 preAtt);
UINT32 IcHalApiRxVgaGain(INT32 preAtt);
UINT32 IcHalApiSetTxFreqNco2(UINT32 uiDifChan, UINT32 bandNo, INT32 iOffset);
UINT32 IcHalApiSetRxFreqNco2(UINT32 uiDifChan, UINT32 bandNo, INT32 iOffset);
UINT32 IcHalApiGetTxDifCarrBandNo(UINT32 difChan, UINT32 radioMode, UINT32 difCarrNo, UINT32 *bandNo);
UINT32 IcHalApiGetRxDifCarrBandNo(UINT32 difChan, UINT32 radioMode, UINT32 difCarrNo, UINT32 *bandNo);
UINT32 IcHalApiGetTxDifBandFreq(UINT32 difChan, UINT32 *bandNum, UINT32 *bandFreq);
UINT32 IcHalApiGetRxDifBandFreq(UINT32 difChan, UINT32 *bandNum, UINT32 *bandFreq);
UINT32 IcHalApiGetTxFreqNco2Step(UINT32 difChan, UINT32 *step);
UINT32 IcHalApiGetRxFreqNco2Step(UINT32 difChan, UINT32 *step);
UINT32 IcHalApiUpCombSmpL2dStart(UINT32 uCellId, UINT32 uDir,UINT32 uAnt, UINT32 uDifOrGfTmp, UINT32 uSlot, UINT32 uStartSym, UINT32 uSymbNum);
UINT32 IcHalApiUpCombSmpL2dSave(UINT32 uCellId, UINT32 uDifOrGfTmp);
UINT32 IcHalApiPinSw(UINT32 PinName, UINT32 sw);
//UINT32 IcHalApiGetDspRoute(UINT32 uiDifChan, T_DifDspRoute *ptDspRoutePara);
//UINT32 IcHalApiSetTsGpEn(UINT32 uiDifChan, UINT32 uiGpEn);
//UINT32 IcHalApiLycaLoadFw(UINT32 serdesId, UINT32 laneId);
//UINT32 IcHalApiLycaInitTx(UINT32 serdesId, UINT32 laneId, UINT32 rate, E_LYCA_CLK_CFG clkMode, DOUBLE ldb);
//UINT32 IcHalApiLycaSetTxFirCoff(UINT32 serdesId, UINT32 laneId, UINT32 eoh0, UINT32 eoh1, UINT32 eoh2, UINT32 eoh3);
//UINT32 IcHalApiLycaInitRx(UINT32 serdesId, UINT32 laneId);
//UINT32 IcHalApiLycaTccSwitch(UINT32 serdesId, UINT32 laneId);

/* j204 block */
// UINT32 IcHalApiJ204LinkInit(UINT32 uiBlockId, UINT32 *pLinkInfo, UINT32 uiLinkSize);
// UINT32 IcHalApiJ204MapInit(UINT32 uiBlockId, UINT32 *pMapInfo, UINT32 uiMapSize);

// UINT32 IcHalApiGetUlSysrefStatus(UINT32 uiBlockId);
// UINT32 IcHalApiGetDlSysrefStatus(UINT32 uiBlockId);
// UINT32 IcHalApiGetFbSysrefStatus(UINT32 uiBlockId);

// UINT32 IcHalApiClrUlSysrefStatus(UINT32 uiBlockId);
// UINT32 IcHalApiClrDlSysrefStatus(UINT32 uiBlockId);
// UINT32 IcHalApiClrFbSysrefStatus(UINT32 uiBlockId);

// UINT32 IcHalApiGetJ204UlState(UINT32 uiBlockId, UINT32 uiLaneId, UINT32 *uiUlState);
// UINT32 IcHalApiGetJ204FbState(UINT32 uiBlockId, UINT32 uiLaneId, UINT32 *uiFbState);

// UINT32 IcHalApiGetUlCRCErrCode(UINT32 uiBlockId, UINT32 uiLaneId, UINT32 *pUlCRCErrCount);
// UINT32 IcHalApiGetFbCRCErrCode(UINT32 uiBlockId, UINT32 uiLaneId, UINT32 *pFbCRCErrCount);

// UINT32 IcHalApiRspUlSysref(UINT32 uiBlockId);
// UINT32 IcHalApiRspFbSysref(UINT32 uiBlockId);
// UINT32 IcHalApiRspDlSysref(UINT32 uiBlockId);

// typedef struct T_DifSysrefGenCfgStruct
// {
//     UINT32 uiSysrefFrDelay;  //sysref帧头延时配置（默认配置0）,单位是737时钟下的一个clk，最大值为0xfffffff
//     UINT32 uiLocalcntSyncEn; //配置系统同步信号产生周期计数器清0，0:帧头到来时不清周期计数器，1：帧头到来时清周期计数器
//     UINT32 uiSyncSrc;        //配置产生系统同步信号的寄存器源，0：选择前级空空口帧头，1：多片同步信号（IO引脚）
//     UINT32 uiPrd;            //配置发sysref信号的周期，取值为0-6，取值为0对应960Khz,取值为1对应480Khz，取值为2对应240Khz、
//                              //取值为3对应120Khz、取值为4对应60Khz、取值为5对应30Khz、取值为6对应15Khz。具体见表SysPerTbl;
//     UINT32 uiWidth;          //配置sysref脉冲高电平宽度，其值不大于周期的一半
//     UINT32 uiSysPha;         //配置初始相位
//     UINT32 uiIsExtSysref;    //是否为外部sysref信号
// } T_DifSysrefGenCfg;


// typedef struct T_DifSysrefCfgStruct
// {
//     UINT32 uiSysrefEn;  //发sysref使能，0代表不往外发sysref，1代表往外发sysref
//     UINT32 uiMode;      //设置sysref发送模式，0代表sysref常发，1代表发固定个数sysref
//     UINT32 uiSysrefNum; //配置发sysref个数
//     UINT32 uiTsEnable;  //配置Sysref发给ts端的使能掩码，共2bit，对应trx0~trx1，1为使能，0为关闭
// } T_DifSysrefCfg;

// UINT32 IcHalApiSysrefRequest(T_DifSysrefCfg *pSysrefCfg);      
// UINT32 IcHalApiSysrefGenerate(T_DifSysrefGenCfg *SysrefGenCfg);


/* crm j204 */
//UINT32 IcHalApiCrmJ204SetResetDLApb(UINT32 ulChip, UINT32 ulBlockId, UINT32 ulRstFlag);
//UINT32 IcHalApiCrmJ204SetResetDLMapSmp(UINT32 ulChip, UINT32 ulBlockId, UINT32 ulMapId, UINT32 ulRstFlag);
//UINT32 IcHalApiCrmJ204SetResetDLMapWork(UINT32 ulChip, UINT32 ulBlockId, UINT32 ulMapId, UINT32 ulRstFlag);
//UINT32 IcHalApiCrmJ204SetResetDLLinkLane(UINT32 ulChip, UINT32 ulBlockId, UINT32 ulLaneMask, UINT32 ulRstFlag);
//UINT32 IcHalApiCrmJ204SetResetDLSysref(UINT32 ulChip, UINT32 ulBlockId, UINT32 ulRstFlag);
//
//
//UINT32 IcHalApiCrmJ204SetResetULApb(UINT32 ulChip, UINT32 ulBlockId, UINT32 ulRstFlag);
//UINT32 IcHalApiCrmJ204SetResetULMapSmp(UINT32 ulChip, UINT32 ulBlockId, UINT32 ulMapId, UINT32 ulRstFlag);
//UINT32 IcHalApiCrmJ204SetResetULMapWork(UINT32 ulChip, UINT32 ulBlockId, UINT32 ulMapId, UINT32 ulRstFlag);
//UINT32 IcHalApiCrmJ204SetResetULLinkLane(UINT32 ulChip, UINT32 ulBlockId, UINT32 ulLaneMask, UINT32 ulRstFlag);
//UINT32 IcHalApiCrmJ204SetResetULCtrl(UINT32 ulChip, UINT32 ulBlockId, UINT32 ulRstFlag);
//
//UINT32 IcHalApiCrmJ204SetResetFBApb(UINT32 ulChip, UINT32 ulBlockId, UINT32 ulRstFlag);
//UINT32 IcHalApiCrmJ204SetResetFBMapSmp(UINT32 ulChip, UINT32 ulBlockId, UINT32 ulMapId, UINT32 ulRstFlag);
//UINT32 IcHalApiCrmJ204SetResetFBMapWork(UINT32 ulChip, UINT32 ulBlockId, UINT32 ulMapId, UINT32 ulRstFlag);
//UINT32 IcHalApiCrmJ204SetResetFBLinkLane(UINT32 ulChip, UINT32 ulBlockId, UINT32 ulLaneMask, UINT32 ulRstFlag);
//UINT32 IcHalApiCrmJ204SetResetFBCtrl(UINT32 ulChip, UINT32 ulBlockId, UINT32 ulRstFlag);
//
//
//UINT32 IcHalApiCrmJ204SetResetULRf(UINT32 ulChip, UINT32 ulBlockId, UINT32 ulRstFlag);
//UINT32 IcHalApiCrmJ204SetResetAll(UINT32 ulChip, UINT32 ulRstFlag);
//
//UINT32 IcHalApiCrmJ204SetResetGlobalApb(UINT32 ulChip, UINT32 ulRstFlag);


/**************************************************************************
                            增益控制相关接口打桩
**************************************************************************/

// UINT32 IcHalApiSetDlbankAptune(UINT32 uiDifChan, UINT32 uiCarrId, UINT32 uiRadioMode, INT32 iGain);
// UINT32 IcHalApiGetDlbankAptune(UINT32 uiDifChan, UINT32 uiCarrId, UINT32 uiRadioMode, INT32 *pGain);
// UINT32 IcHalApiUlbankAptuneDataEn(UINT32 uiDifChan, UINT32 uiCarrId, UINT32 uiRadioMode, UINT32 uiDataEn);
// UINT32 IcHalApiGetDlpreGainDataEnStatus(UINT32 uiDifChan, UINT32 uiCarrId, UINT32 uiRadioMode, UINT32 *puiDataEn);
// UINT32 IcHalApiGetUlbankAptuneDataEnStatus(UINT32 uiDifChan, UINT32 uiCarrId, UINT32 uiRadioMode, UINT32 *puiDataEn);
// UINT32 IcHalApiSetDlcfrK0(UINT32 uiDifChan, INT32 iGain);
// UINT32 IcHalApiGetDlcfrK0(UINT32 uiDifChan, INT32 *pGain);
// UINT32 IcHalApiSetDlcfrK0Diff(UINT32 uiDifChan, INT32 iGain);
// UINT32 IcHalApiGetDlcfrK0Diff(UINT32 uiDifChan, INT32 *pGain);
// UINT32 IcHalApiSetDlpostGain4(UINT32 uiDifChan, INT32 iGain);
// UINT32 IcHalApiGetDlpostGain4(UINT32 uiDifChan, INT32 *pGain);
// UINT32 IcHalApiSetUlbankAptune(UINT32 uiDifChan, UINT32 uiCarrId, UINT32 uiRadioMode, INT32 iGain);
// UINT32 IcHalApiGetUlbankAptune(UINT32 uiDifChan, UINT32 uiCarrId, UINT32 uiRadioMode, INT32 *pGain);
//UINT32 IcHalApiSetEcpriRemoteRst(UINT8 *pDestMac1,UINT8 *pDestMac2);{return BSP_OK;}


/**************************************************************************
                            SOC相关接口打桩声明
**************************************************************************/
UINT32 IcHalApiGetIcChipId(UINT32 *pChipIdx);


/**************************************************************************
                        解决编译告警的临时HAL接口声明
**************************************************************************/
/* dif hal */
UINT32 IcHalApiSetDlTddCarrDelay(UINT32 uiDifChan, UINT32 uiCarrIndex, UINT32 uiRadioMode);

/* opt hal */
UINT32 IcHalApiSetEcpriRemoteRst(UINT8 *pDestMac1,UINT8 *pDestMac2);



#ifdef __cplusplus

}
#endif
#endif 





/*****************************************************************************
* 版权所有(C) 2020, ZTE Corp. ZXSDR-RRU Platform BSP
*----------------------------------------------------------------------------
* 模 块 名 : bsp
* 文件名称 : ichaladapt_j204_ic4_2.h
* 文件标识 : {[N/A]}
* 内容摘要 : 本文件提供了ICHAL适配层对外接口声明
* 注意事项 : 无
* 作    者 : 王涛10248577
* 创建日期 : 2020-11-04
* 当前版本 : Ver1.0
*----------------------------------------------------------------------------
* 变更记录 :
*
* $记录1
* 变 更 单: $0000000(N/A)
* 责 任 人: 王涛10248577
* 修改日戳: 2020-11-04
* 变更说明: 创建文件
*----------------------------------------------------------------------------
*/

#ifndef _FUNCLIB_ICHALADAPT_J204_IC4_2_H_
#define _FUNCLIB_ICHALADAPT_J204_IC4_2_H_


#ifdef __cplusplus
extern "C" {
#endif

#include "ichaladaptbspapi_j204.h"

/* DPDIC4.2 sysref引脚个数定义 最大2根引脚*/
#define DPDIC_SYSREF_PIN_MAX_NUM  (2)

/* J204 serdes lane定义 */
#define J204C_SERDES_LANE_MAX (8)
#define J204C_SERDES_TX_LANE_MAX (8)
#define J204C_SERDES_RX_LANE_MAX (4)
#define J204C_SERDES_FB_LANE_MAX (4)

/* J204 lane定义 */
#define DPDIC_J204_RX_LANE_MAX_SUM (4)
#define DPDIC_J204_FB_LANE_MAX_SUM (4)
#define DPDIC_J204_TX_LANE_MAX_SUM (8)
#define DPDIC_J204_LANE_NUM_MAX (8)

/* J204 Map数量定义 */
#define DPDIC_J204_MAP_NUM_MAX (2)

/* sysref有效标志 */
#define DPDIC_J204_SYSREF_VALID (1)

/* 读写地址差正常 */
#define DPDIC_J204_RWADDR_NORMAL (0)
#define DPDIC_J204_RWADDR_ERROR (1)

/**************************************************************************
*                              J204 公共
 *************************************************************************/
UINT32 BspHalAdaptJ204GetSerdesLaneMask(UINT32 dir, UINT32 j204LaneMask);
UINT32 BspHalAdaptJ204IsFullLane(UINT32 dir, UINT32 laneMask);


/**************************************************************************
*                              J204 serdes相关
 *************************************************************************/
//以下接口中的lane掩码和laneId为serdes lane
UINT32 BspHalAdaptJ204SerdesPhyApbRst(UINT32 txLaneIdMask,UINT32 rstFlag);
UINT32 BspHalAdaptJ204cSerdesLoadFrmware(UINT32 laneIdMask, UINT32 txDataRate, UINT32 rxDataRate);
UINT32 BspHalAdaptJ204cSerdesPowerOn(UINT32 dir, UINT32 laneIdMask);
UINT32 BspHalAdaptJ204cSerdesPowerDown(UINT32 dir, UINT32 laneIdMask);
UINT32 BspHalAdaptJ204cSerdesInit(UINT32 dir, UINT32 laneIdMask, UINT32 dataRate);
UINT32 BspHalAdaptAdjustJ204SerdesTxEq(UINT32 laneIdMask,UINT32 eqPre,UINT32 eqPost,UINT32 eqMain);
UINT32 BspHalAdaptJ204cSerdesTrxEn(UINT32 dir, UINT32 laneIdMask, UINT32 en);

/**************************************************************************
*                              j204 block相关
 *************************************************************************/
//以下接口中的lane掩码和laneId为J204           lane
UINT32 BspHalAdaptJ204LinkInit(UINT32 dir, UINT32 laneIdMask, UINT32 *pLinkInfo, UINT32 linkSize);
UINT32 BspHalAdaptJ204MapInit(UINT32 dir, UINT32 laneIdMask, UINT32 *pMapInfo, UINT32 mapSize);
UINT32 BspHalAdaptGetJ204UlAddrErrAlmVal(UINT32 blockId, UINT32 laneId, UINT32 *ulLaneErrVal);
UINT32 BspHalAdaptSetJ204UlClrCrcErr(UINT32 blockId, UINT32 ulBitMask);
UINT32 BspHalAdaptGetJ204UlCrcErr(UINT32 blockId, UINT32 laneId, UINT32 *ulLaneErrVal);
UINT32 BspHalAdaptSetJ204UlClr64B66BErr(UINT32 blockId, UINT32 ulBitMask);
UINT32 BspHalAdaptGetJ204Ul64B66BErr(UINT32 blockId, UINT32 laneId, UINT32 *ulLaneErrVal);
UINT32 BspHalAdaptGetJ204FbAddrErrAlmVal(UINT32 blockId, UINT32 laneId, UINT32 *fbLaneErrVal);
UINT32 BspHalAdaptSetJ204FbClrCrcErr(UINT32 blockId, UINT32 bitMask);
UINT32 BspHalAdaptGetJ204FbCrcErr(UINT32 blockId, UINT32 laneId, UINT32 *laneErrVal);
UINT32 BspHalAdaptSetJ204FbClr64B66BErr(UINT32 blockId, UINT32 bitMask);
UINT32 BspHalAdaptGetJ204Fb64B66BErr(UINT32 blockId, UINT32 laneId, UINT32 *laneErrVal);
UINT32 BspHalAdaptClrJ204UlState(UINT32 blockId);
UINT32 BspHalAdaptClrJ204FbState(UINT32 blockId);
UINT32 BspHalAdaptGetSysrefStatus(UINT32 dir, UINT32 laneIdMask);
UINT32 BspHalAdaptClrSysrefStatus(UINT32 dir, UINT32 laneIdMask);
UINT32 BspHalAdaptGetJ204State(UINT32 dir, UINT32 laneId, UINT32 *state, UINT32 *regVal);
UINT32 BspHalAdaptGetJ204CrcErrCnt(UINT32 dir, UINT32 laneId, UINT32 *crcErrCnt);
UINT32 BspHalAdaptGetJ204RwAddrDifState(UINT32 dir, UINT32 laneId, UINT32 *state, UINT32 *regVal);
UINT32 BspHalAdaptSetJ204LemcOffset(UINT32 dir, UINT32 offset);
UINT32 BspHalAdaptGetJ204LemcOffset(UINT32 dir, UINT32 *offset);
UINT32 BspHalAdaptSysrefRequest(T_BspHalAdaptSysrefCfg *pSysrefCfg);
UINT32 BspHalAdaptSysrefGenerate(T_BspHalAdaptSysrefCfg *pSysrefCfg);
UINT32 BspHalAdaptSysrefRspEnable(UINT32 dir, UINT32 laneIdMask);
UINT32 BspHalAdaptGetJ204RegHeadAddr(UINT32 grpId);
UINT32 BspHalAdaptCrmJ204SetResetAll(UINT32 rstFlag);
/* 新增接口，去掉lanemask参数，改为mapId */
UINT32 BspHalAdaptGetSysrefValidFlag(UINT32 dir, UINT32 mapId, UINT32 *validFlag);
UINT32 BspHalAdaptClrMapSysrefStatus(UINT32 dir, UINT32 mapId);


/**************************************************************************
*                              crm j204相关
 *************************************************************************/
#if 0 /* 适配层接口增加mapMask，故以下接口不再使用了 */
UINT32 BspHalAdaptJ204SetGrpLaneMask(UINT32 grpId, UINT32 dir, UINT32 laneIdMask);
#endif 

UINT32 BspHalAdaptCrmJ204SetRstLogic(UINT32 dir, UINT32 laneIdMask, UINT32 mapMask, UINT32 rstFlag);
UINT32 BspHalAdaptCrmJ204SetResetApb(UINT32 dir, UINT32 laneIdMask, UINT32 rstFlag);
UINT32 BspHalAdaptCrmJ204SetRstMap(UINT32 dir, UINT32 laneIdMask, UINT32 mapMask, UINT32 rstFlag);
UINT32 BspHalAdaptCrmJ204SetResetWorkLane(UINT32 dir, UINT32 laneIdMask, UINT32 rstFlag);
UINT32 BspHalAdaptCrmJ204SetResetRf(UINT32 dir, UINT32 laneIdMask, UINT32 rstFlag);
UINT32 BspHalAdaptCrmJ204SetResetDlSysref(UINT32 laneIdMask, UINT32 rstFlag);
UINT32 BspHalAdaptCrmJ204SetResetCtrl(UINT32 dir, UINT32 laneIdMask, UINT32 rstFlag);
UINT32 BspHalAdaptCrmJ204SetResetGlobalApb(UINT32 rstFlag);

/**************************************************************************
*                              防抖接口
 *************************************************************************/
UINT32 BspHalAdaptJ204JitOutWinCfg(UINT32 uiDir, UINT32 uiJitterVal);

/**************************************************************************
*                              其他接口
 *************************************************************************/
UINT32 BspHalAdaptGetTrxPinId(UINT32 TrxChipIdx, UINT32 *pPinId);
UINT32 BspHalAdaptJ204SdsTxResetCfg(UINT32 laneIdMask, UINT32 reset);

#ifdef __cplusplus

}
#endif
#endif 





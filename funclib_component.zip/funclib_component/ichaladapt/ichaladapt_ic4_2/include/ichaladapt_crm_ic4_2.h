/*****************************************************************************
* 版权所有(C) 2020, ZTE Corp. ZXSDR-RRU Platform BSP
*----------------------------------------------------------------------------
* 模 块 名 : bsp
* 文件名称 : ichaladapt_j204_ic4_2.h
* 文件标识 : {[N/A]}
* 内容摘要 : 本文件提供了ICHAL适配层对外接口声明
* 注意事项 : 无
* 作    者 : 王涛10248577
* 创建日期 : 2020-11-04
* 当前版本 : Ver1.0
*----------------------------------------------------------------------------
* 变更记录 :
*
* $记录1
* 变 更 单: $0000000(N/A)
* 责 任 人: 王涛10248577
* 修改日戳: 2020-11-04
* 变更说明: 创建文件
*----------------------------------------------------------------------------
*/

#ifndef _FUNCLIB_ICHALADAPT_CRM_IC4_2_H_
#define _FUNCLIB_ICHALADAPT_CRM_IC4_2_H_


#ifdef __cplusplus
extern "C" {
#endif

/*CRM pll配置参数*/
typedef struct t_T_BspHalAdaptPllCrmPara{
    UINT32 ifType;         /* 支持IF1的时候需要初始化PLL4 */
}T_BspHalAdaptPllCrmPara;
/*CRM SOC时钟配置*/
typedef struct t_T_BspHalAdaptSocCrmClk{
    UINT32 clk_spifc1_sys;         /* QSPI1 CRM时钟配置 */
    UINT32 clk_spifc2_sys;         /* QSPI2 CRM时钟配置 */
    UINT32 clk_spi0_sys;           /* SPI0 CRM时钟配置 */
    UINT32 clk_spi1_sys;           /* SPI1 CRM时钟配置 */
    UINT32 clk_spi2_sys;           /* SPI2 CRM时钟配置 */
    UINT32 clk_spi3_sys;           /* SPI3 CRM时钟配置 */
    UINT32 clk_spi4_sys;           /* SPI4 CRM时钟配置 */
    UINT32 clk_spi5_sys;           /* SPI5 CRM时钟配置 */
    UINT32 clk_spi6_sys;           /* SPI6 CRM时钟配置 */
}T_BspHalAdaptSocCrmClk;
/*CRM opt时钟配置*/
typedef struct t_T_BspHalAdaptOptCrmClk{
    UINT32 clk_opt_variable;         /* 光口可变时钟配置 */
}T_BspHalAdaptOptCrmClk;
/*CRM DIF时钟配置*/
typedef struct t_T_BspHalAdaptDifCrmClk{
    UINT32 clk_ul_logic1_0;         /* ulch模块时钟频率0 */
    UINT32 clk_ul_logic1_1;         /* ulch模块时钟频率1 */
    UINT32 clk_dl_logic2;           /* CFR模块时钟 */
    UINT32 clk_dl_logic3_0;         /* 下行为DPD生成的时钟0 */
    UINT32 clk_dl_logic3_1;         /* 下行为DPD生成的时钟1 */
    UINT32 clk_fb_logic1_0;         /* fb模块时钟频率0 */
    UINT32 clk_fb_logic1_1;         /* fb模块时钟频率1 */
    UINT32 clk_dl_j204_work_0;      /* 下行J204 map0 work时钟 */
    UINT32 clk_dl_j204_work_1;      /* 下行J204 map1 work时钟 */
    UINT32 clk_fb_j204_work;        /* 反馈J204work时钟 */
    UINT32 clk_ul_j204_work;        /* 上行J204work时钟 */
}T_BspHalAdaptDifCrmClk;

/*CRM DIF时钟选择*/
typedef struct t_T_BspHalAdaptDifCrmClkSelect{
    UINT32 mux_clk_ulch_0;             /* ulch blk0时钟选择 */
    UINT32 mux_clk_ulch_1;             /* ulch blk1时钟选择 */
    UINT32 mux_clk_dlpost_0;           /* dlpsot blk0时钟选择 */
    UINT32 mux_clk_dlpost_1;           /* dlpsot blk1时钟选择 */
    UINT32 mux_clk_dl_logic6;          /* DPD blk1(PIMC)工作时钟选择 */
    UINT32 mux_clk_fb0;                /* 反馈fb0的时钟选择 */
    UINT32 mux_clk_fb1;                /* 反馈fb1的时钟选择 */
    UINT32 mux_clk_cblms;              /* LMS用到时钟，BSP初始化为0，DSP根据需要动态切换 */
    UINT32 mux_clk_j204_fb_logic2_0;   /* 反馈204 map0对应的2分配时钟选择 */
    UINT32 mux_clk_j204_fb_logic2_1;   /* 反馈204 map1对应的2分配时钟选择 */
    UINT32 mux_clk_j204_dl_logic5_0;   /* 下行204 map0对应的2分配时钟选择 */
    UINT32 mux_clk_j204_dl_logic5_1;   /* 下行204 map1对应的2分配时钟选择 */
    UINT32 mux_clk_j204_sysref;        /* J204 Sysref的时钟选择(dl_logic3_0/dl_logic3_1) */
    UINT32 mux_clk_j204_fb_logic3_0;   /* j204反馈map对应的logic3_0时钟选择配置 */
    UINT32 mux_clk_j204_fb_logic3_1;   /* j204反馈map对应的logic3_1时钟选择配置 */
    UINT32 mux_clk_j204_dl_logic4_0;   /* j204下行map对应的logic4_0时钟选择配置 */
    UINT32 mux_clk_j204_dl_logic4_1;   /* j204下行map对应的logic4_1时钟选择配置 */
    UINT32 mux_clk_j204_ul_logic2_0;   /* j204上行map对应的logic2_0时钟选择配置 */
    UINT32 mux_clk_j204_ul_logic2_1;   /* j204上行map对应的logic2_1时钟选择配置 */
}T_BspHalAdaptDifCrmClkSelect;

/*CRM释放复位通用参数，为1为释放对应域的必须释放的模块，为0不释放，后续添加差异模块的复位释放*/
typedef struct t_T_BspHalAdaptCrmRstCommonPara{
    UINT32 rst_fft_pranch;             /* 光口FFT/PRANCH复位释放 */
    UINT32 rst_roe;                    /* ROE复位释放 */
    UINT32 rst_opt;                    /* 光口模块复位释放 */
    UINT32 rst_dif;                    /* 中频模块复位释放 */
}T_BspHalAdaptCrmRstCommonPara;

/*时钟芯片配置前的CRM初始化参数*/
typedef struct t_T_BspHalAdaptCrmPara_BeforeClk{
    T_BspHalAdaptSocCrmClk *tSocClkPara;                 /* CRM Soc时钟参数 */
}T_BspHalAdaptCrmPara_BeforeClk;

/*时钟芯片配置后的CRM初始化参数*/
typedef struct t_T_BspHalAdaptCrmPara_AfterClk{
    T_BspHalAdaptPllCrmPara *tPllClkPara;                /* CRM PLL参数 */
    T_BspHalAdaptOptCrmClk *tOptClkPara;                 /* CRM OPT时钟参数 */
    T_BspHalAdaptDifCrmClk *tDifClkPara;                 /* CRM DIF时钟参数 */
    T_BspHalAdaptCrmRstCommonPara *tCommRst;             /* CRM 公共复位释放 */
    T_BspHalAdaptDifCrmClkSelect *tDifClkSelectPara;     /* CRM DIF时钟选择参数 */
}T_BspHalAdaptCrmPara_AfterClk;


/**************************************************************************
*                              接口声明
 *************************************************************************/
UINT32 BspHalAdaptCrmRecRegSet(UINT32 ulOffset, UINT32 ulBitStart, UINT32 ulBitEnd, UINT32 ulInitRec);
UINT32 BspHalAdaptCrmRecRegGet(UINT32 ulOffset, UINT32 ulBitStart, UINT32 ulBitEnd, UINT32 *regVal);
UINT32 BspHalAdaptCrmPllParaInit(T_BspHalAdaptPllCrmPara *pCrmPllPara);
UINT32 BspHalAdaptCrmSocClkParaInit(T_BspHalAdaptSocCrmClk *pCrmSocClkPara);
UINT32 BspHalAdaptCrmOptClkParaInit(T_BspHalAdaptOptCrmClk *pCrmOptClkPara);
UINT32 BspHalAdaptCrmDifClkParaInit(T_BspHalAdaptDifCrmClk *pCrmDifClkPara);
UINT32 BspHalAdaptCrmDifClkSelectParaInit(T_BspHalAdaptDifCrmClkSelect *pCrmDifClkSelectPara);
UINT32 BspHalAdaptCrmCommonRstParaInit(T_BspHalAdaptCrmRstCommonPara *pCrmComRstPara);
UINT32 BspHalAdaptCrmGfBifDifSetReset(UINT32 chip, UINT32 rstFlag);
UINT32 BspHalAdaptGetJ204SysrefClk(UINT32 *sysrefClk);
UINT32 BspHalAdaptGetIcCalibrationTemp(INT32 *temp0, INT32 *temp1);
UINT32 BspHalAdaptSetSoc25MClkOutEnable(UINT32 ulSw);
UINT32 BspHalAdaptCfgSetCrmFifteenthRecordReg(UINT32 regVal, UINT32 bitStart, UINT32 bitEnd);
UINT32 BspHalAdaptCfgGetCrmFifteenthRecordReg(UINT32 bitStart, UINT32 bitEnd, UINT32 *regVal);
UINT32 BspHalAdaptCfgSetCrmRecordReg(UINT32 regVal,  UINT32 bitStart,  UINT32 bitEnd);
UINT32 BspHalAdaptCfgGetCrmRecordReg(UINT32 bitStart, UINT32 bitEnd, UINT32 *status);
UINT32 BspHalAdaptCrmCfgPrachFftMode(UINT32 chip, UINT32 modeBitMap);
UINT32 BspHalAdaptCrmSocPll2PwrDivEnDis(UINT32 chip, UINT32 sw);
UINT32 BspHalAdaptCrmSocPll3PwrDivEnDis(UINT32 sw);

#ifdef __cplusplus

}
#endif
#endif 





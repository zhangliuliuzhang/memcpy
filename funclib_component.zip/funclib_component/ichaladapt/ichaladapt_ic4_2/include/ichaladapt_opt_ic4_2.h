/*****************************************************************************
* 版权所有(C) 2020, ZTE Corp. ZXSDR-RRU Platform BSP
*----------------------------------------------------------------------------
* 模 块 名 : bsp
* 文件名称 : ichaladapt_opt_ic4_2.h
* 文件标识 : {[N/A]}
* 内容摘要 : 本文件提供了ICHAL适配层光口功能对外接口声明
* 注意事项 : 无
* 作    者 : 王涛10248577
* 创建日期 : 2020-11-04
* 当前版本 : Ver1.0
*----------------------------------------------------------------------------
* 变更记录 :
*
* $记录1
* 变 更 单: $0000000(N/A)
* 责 任 人: 王涛10248577
* 修改日戳: 2020-11-04
* 变更说明: 创建文件
*----------------------------------------------------------------------------
*/

#ifndef _FUNCLIB_ICHALADAPT_OPT_IC4_2_H_
#define _FUNCLIB_ICHALADAPT_OPT_IC4_2_H_


#ifdef __cplusplus
extern "C" {
#endif

#include "bsppub.h"
#include "opt_cpri_api.h"


UINT32 BspHalAdaptCpriGetCpriRstReq(UINT32 *rstReq);
UINT32 BspHalAdaptGetCpriProtocol(UINT32 *pulProtocol);
UINT32 BspHalAdaptGetCarrNoByOptCellId(UINT32 cellId, UINT32 *puCarrNo);

#ifdef __cplusplus

}
#endif
#endif 





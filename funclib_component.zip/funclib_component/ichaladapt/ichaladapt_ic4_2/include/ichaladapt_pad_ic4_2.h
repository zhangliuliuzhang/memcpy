/*****************************************************************************
* 版权所有(C) 2020, ZTE Corp. ZXSDR-RRU Platform BSP
*----------------------------------------------------------------------------
* 模 块 名 : bsp
* 文件名称 : ichaladapt_pad_ic4_2.h
* 文件标识 : {[N/A]}
* 内容摘要 : 本文件提供了board pad ICHAL适配层对外接口声明
* 注意事项 : 无
* 作    者 : 殷嘉宾10256522
* 创建日期 : 2024-03-14
* 当前版本 : Ver1.0
*----------------------------------------------------------------------------
* 变更记录 :
*
* $记录1
* 变 更 单: $0000000(N/A)
* 责 任 人: 殷嘉宾10256522
* 修改日戳: 2024-03-14
* 变更说明: 创建文件
*----------------------------------------------------------------------------
*/

#ifndef _FUNCLIB_ICHALADAPT_PAD_IC4_2_H_
#define _FUNCLIB_ICHALADAPT_PAD_IC4_2_H_

#ifdef __cplusplus
extern "C" {
#endif

UINT32 BspSetPadSt(UINT32 halPadName, UINT32 value);
UINT32 BspSetPadSl(UINT32 halPadName, UINT32 value);
UINT32 BspSetPadPull(UINT32 halPadName, UINT32 value);
UINT32 BspSetPadDs(UINT32 halPadName, UINT32 value);
UINT32 BspSetPadCfgDone(UINT32 halPadName, UINT32 value);
UINT32 BspSetPadFuncSel(UINT32 halPadName, UINT32 value);
UINT32 BspHalGetPadReg(UINT32 halPadName, UINT32 *value);
UINT32 BspHalSetPadReg(UINT32 halPadName, UINT32 value);
UINT32 BspSetPadLvdsFrameHead(UINT32 padName, UINT32 value);
UINT32 BspSetPadLvdsFuncSel(UINT32 padName, UINT32 value);

UINT32 BspHalAdaptSetSwPadDebugEn(UINT32 swIdx, UINT32 bitEn);
UINT32 BspHalAdaptSetSwPadDebugCfg(UINT32 swIdx, UINT32 val);
UINT32 BspHalAdaptSetPadFrPolicy(UINT32 *puiPolicyVal, UINT32 uiPadFrNum);
UINT32 BspHalAdaptSetFrRouterPadFrSelByFrId(UINT32 uiFrId, UINT32 uiFrSel);
#ifdef __cplusplus

}
#endif
#endif

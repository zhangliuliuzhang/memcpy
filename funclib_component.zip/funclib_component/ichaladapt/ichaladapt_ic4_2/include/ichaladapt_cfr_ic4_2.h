/*****************************************************************************
* 版权所有(C) 2024, ZTE Corp. ZXSDR-RRU Platform BSP
*----------------------------------------------------------------------------
* 模 块 名 : bsp
* 文件名称 :  ichaladapt_cfr_ic4_2.h
* 文件标识 : {[N/A]}
* 内容摘要 : 本文件提供了ICHAL适配层对外接口声明
* 注意事项 : 无
* 作    者 : 张龙10281388
* 创建日期 : 2024-02-18
* 当前版本 : Ver1.0
*----------------------------------------------------------------------------
*/

#ifndef _FUNCLIB_ICHALADAPT_CFR_IC4_2_H_
#define _FUNCLIB_ICHALADAPT_CFR_IC4_2_H_

#ifdef __cplusplus
extern "C" {
#endif


#include "cfr_api.h"

/**************************************************************************
 *                              削峰相关结构体及接口
 *************************************************************************/

typedef T_DlyCfgCfrPara T_BspHalAdaptDlyCfgCfrPara; 
typedef T_CfrDlyCalcPara T_BspHalAdaptCfrDlyCalcPara;
typedef T_CfrCommParaCpg T_BspHalAdaptCfrParaHardCpg;
typedef T_CfrCommPara T_BspHalAdaptDifCommCfrPara;
typedef T_CfrParCfgCommPara T_BspHalAdaptCfrParCommPara;
typedef T_DpdParCfgCommPara T_BspHalAdaptDpdParCommPara;
typedef T_CfrKnWordLutCommPara T_BspHalAdaptCfrKnWordPara;
typedef T_KiPowSharedCarrInfoPara T_BspHalAdaptCfrDssCarrInfo;

T_BspHalAdaptDifCommCfrPara *BspHalAdaptGetDifCfrPara(VOID);

UINT32 BspHalAdaptCfrSetCpgTblCfg(UINT32 difchan, UINT32 freqBand, UINT32 *pCoef, UINT32 coefLen);
UINT32 BspHalAdaptCfrGetCpgTblCfg(UINT32 difchan, UINT32 freqBand, UINT32 *pCoef, UINT32 coefLen);
UINT32 BspHalAdaptCfrSetWord(UINT32 difChan, UINT32 freqBand, UINT32 carrIndex, UINT32 carrRadio, UINT32 freqWord);
UINT32 BspHalAdaptCfrSetcfgFlag(UINT32 difChn, UINT32 freqBand);
UINT32 BspHalAdaptSetDlpreKiIndexGsm(UINT32 difChan, UINT32 carrIndex, UINT32 carrRadio, UINT32 staPowStepFreq, UINT32 deltPowFreq);
UINT32 BspHalAdaptCfrSetOriginCoef(UINT32 difChan, UINT32 carrIndex, UINT32 carrRadio, UINT32 coefLen, const INT32 *pCoefPara);
UINT32 BspHalAdaptCfrSetGi(UINT32 difChn, UINT32 freqBand, UINT32 carrId, UINT32 carrRadio, UINT32 gi);
UINT32 BspHalAdaptCfrCleanWord(UINT32 difChan, UINT32 freqBand);
UINT32 BspHalAdaptCfrSetDlpreKiIndexNum(UINT32 difChan, UINT32 freqBand, UINT32 symNum);
UINT32 BspHalAdaptCfrSetCpgUpdateMode(UINT32 difChan, UINT32 freqBand);
UINT32 BspHalAdaptCfrSetDlpreKiIndexDvSel(UINT32 difChan, UINT32 freqBand);
UINT32 BspHalAdaptGetGsmPowLevel(UINT32 difChan, UINT32 carrIndex, UINT32 radioMode, UINT32 *puiPowLevel);

UINT32 BspHalAdaptDifCfrParaInit(T_BspHalAdaptDifCommCfrPara *pDifCfrPara);
UINT32 BspHalAdaptCfrCommParaCpgInit(T_BspHalAdaptCfrParaHardCpg *pCfrHWCpgPara);
UINT32 BspHalAdaptKnWordLutParaInit(T_BspHalAdaptCfrKnWordPara *pCfrKnWordPara);
UINT32 BspHalAdaptCfrParCfgCommParaInit(T_BspHalAdaptCfrParCommPara *pCfrParPara);
UINT32 BspHalAdaptDpdParCfgCommParaInit(T_BspHalAdaptDpdParCommPara *pDpdParPara);
UINT32 BspHalAdaptDpdGetPar(UINT32 difChn, UINT32 freqBand, UINT32 peakFlag, UINT32 workMode, UINT32 *cfrParData);
UINT32 BspHalAdaptSetDpdParCfgFr(UINT32 difChn, UINT32 freqband, UINT32 frDly, UINT32 symParFlagPer, UINT32 frDivSel);
UINT32 BspHalAdaptGetCfrWinlevel(UINT32 difChn, UINT32 freqBand, UINT32 *pcfrWinLevel, UINT32 gateNum);
UINT32 BspHalAdaptGetCfrDelt(UINT32 difChn, UINT32 freqBand, UINT32 *pcfrDelt, UINT32 gateNum);
UINT32 BspHalAdaptSetCfrWinlevel(UINT32 difChn, UINT32 freqBand, UINT32 *pcfrWinLevel, UINT32 gateNum);
UINT32 BspHalAdaptSetCfrWin(UINT32 difChn, UINT32 freqBand, UINT32 *pcfrWin, UINT32 gateNum);
UINT32 BspHalAdaptSetCfrDelt(UINT32 difChn, UINT32 freqBand, UINT32 *pcfrDelt, UINT32 gateNum);
UINT32 BspHalAdaptSetCfrGate(UINT32 difChn, UINT32 freqBand, UINT32 *pcfrGate, UINT32 gateNum);
UINT32 BspHalAdaptSetDlyPara(UINT32 difChn, T_BspHalAdaptDlyCfgCfrPara *pDlyPara);
UINT32 BspHalAdaptSetCfrOutMode(UINT32 difChn, UINT32 freqBand, UINT32 mode);
UINT32 BspHalAdaptSetCfrHb0Coef(UINT32 difChn, INT32 *pcfrHb0Coef, UINT32 coefLen);
UINT32 BspHalAdaptSetCfrHb1Coef(UINT32 difChn, INT32 *pcfrHb1Coef, UINT32 coefLen);
UINT32 BspHalAdaptCfrSetDelay(UINT32 difChn, UINT32 freqBand, T_BspHalAdaptCfrDlyCalcPara *pDlyPara);
UINT32 BspHalAdaptCfrSetFreqWordFsInit(void);
UINT32 BspHalAdaptSetCpgParaRangeCarrInit(void);
UINT32 BspHalAdaptCfrSetSymstrGsmSel(UINT32 difChan, UINT32 freqBand);
UINT32 BspHalAdaptSetCpgParaRangeCarrNum(void);
UINT32 BspHalAdaptCfrSetchnChgHwMask(UINT32 difChnHwMask);
UINT32 BspHalAdaptCfrSetCpgFreqCalStr(UINT32 difChan, UINT32 freqBand);
UINT32 BspHalAdaptCfrSetCpgSuspend(UINT32 difChn, UINT32 freqBand, UINT32 suspend);
UINT32 BspHalAdaptSetCfrSwitch(UINT32 difChn, UINT32 freqBand, UINT32 cfrOnOff);
UINT32 BspHalAdaptCfrGetCpgOnLine(UINT32 difChan, UINT32 ramType, UINT32 coefMode, UINT32 coefLen);
UINT32 BspHalAdaptCfrLeakPeak(UINT32 difChan, UINT32 clrFlag);
UINT32 BspHalAdaptCfrGetCpgOnLineGsm(UINT32 difChan);
UINT32 BspHalAdaptCfrGetCpgOnLineStatic(UINT32 difChan);
UINT32 BspHalAdaptCfrGetCpgOnLineStage(UINT32 difChan);
UINT32 BspHalAdaptCfrGetCpgOnLineCarrer(UINT32 difChan);
UINT32 BspHalAdaptGetBbTssiCfg(UINT32 difChan);
UINT32 BspHalAdaptSetBbTssiCfg(UINT32 difChan);
UINT32 BspHalAdaptCfrGetSample(UINT32 difChan, UINT32 pos0, UINT32 pos1, UINT32 sampTime, UINT32 trigMode);
UINT32 BspHalAdaptCfrCleanGi(UINT32 difChan, UINT32 freqBand);
UINT32 BspHalAdaptCfrClrOriginCoefCarrInfo(UINT32 difChan, UINT32 freqBand);
UINT32 BspHalAdaptDssCfrSetOriginCoef(UINT32 difChan, UINT32 carrIndex, UINT32 carrRadio, UINT32 carrBw, UINT32 coefLen, const INT32 *pCoefPara);
UINT32 BspHalAdaptCfrSetDssCarrInfo(UINT32 difChan, UINT32 carrIndex, UINT32 carrRadio, T_BspHalAdaptCfrDssCarrInfo *pDssCarrInfo);
UINT32 BspHalAdaptCfrSetTddswInit(void);
UINT32 BspHalAdaptCfrCleanDlpreKiPowSel(UINT32 difChan, UINT32 freqBand);
UINT32 BspHalAdaptCfrGetTddsw(UINT32 difChan);
UINT32 BspHalAdaptCfrSetEnergyInit(void);
UINT32 BspHalAdaptCfrGetEnergy(void);
UINT32 BspHalAdaptCfrSetCpgMode(UINT32 difChan, UINT32 freqBand, UINT32 cpgMode);
UINT32 BspHalAdaptCfrSetBlock0Ram1Len(void);
UINT32 BspHalAdaptSetDlpreKiIndexType(UINT32 difChan);

UINT32 BspHalAdaptCfrSetCpgGateBypassInit(void);
UINT32 BspHalAdaptCfrSetDlpreKiPowSelInit(void);
UINT32 BspHalAdaptCfrSetTddsw(UINT32 difChan, UINT32 freqBand, T_BspHalAdaptCfrDlyCalcPara *pDlyPara);
UINT32 BspHalAdaptCfrSetCpgLen(UINT32 difChan, UINT32 freqBand, UINT32 cpgMaxlen);

#ifdef __cplusplus

}
#endif
#endif /* _FUNCLIB_ICHALADAPT_CFR_IC4_2_H_ */

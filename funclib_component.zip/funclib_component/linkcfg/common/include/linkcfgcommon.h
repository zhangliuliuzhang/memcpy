/*****************************************************************************
* 版权所有(C) 2017, ZTE Corp. ZXSDR-RRU Platform BSP
*----------------------------------------------------------------------------
* 模 块 名 : bsp
* 文件名称 : linkcfgcommon.h
* 文件标识 : {[N/A]}
* 内容摘要 : 本文件提供了链路配置接口声明
* 注意事项 : 无
* 作    者 :   10090699
* 创建日期 : 2017-03-08
* 当前版本 : Ver1.0
*----------------------------------------------------------------------------
* 变更记录 :
*
* $记录1
* 变 更 单: $0000000(N/A)
* 责 任 人: 10090699
* 修改日戳: 2017-03-08
* 变更说明: 创建文件
*----------------------------------------------------------------------------
*/

#ifndef _FUNCLIB_LINKCFGCOMMON_H_
#define _FUNCLIB_LINKCFGCOMMON_H_



#ifdef __cplusplus
extern "C" {
#endif

#include "linkcfgapi.h"
#include "funccommon_log.h"
#include "funccommonapi.h"

/**************************************************************************
 *                        宏
 **************************************************************************/
#define CELL_RE_REF_PWR_LOW   -600    //小区传递过来的RE参考功率下边界
#define CELL_RE_REF_PWR_UP    500     //小区传递过来的RE参考功率上边界
/**************************************************************************
 *                         数据类型
 **************************************************************************/
typedef struct T_PRACH_CFG_IDX_MAP
{
    UINT32 idx;
    UINT32 fmt;
    UINT32 sym;
    UINT32 uHfFmtVal;	
    UINT32 uHfsymVal;		
} T_PRACH_CFG_IDX_MAP;

typedef struct T_PRACH_CFG_BB_PARA_SET
{
    UINT32 fmt;
    UINT32 symbol;
    UINT32 sample;
    UINT32 sFreq;
    UINT32 uMainCarrNo;	
}T_PRACH_CFG_BB_PARA_SET;


typedef UINT32 (*FUNC_ERS_SCALE_CALC)(INT32 lCellReRefPwr,UINT32 ulReNum, UINT32 *pscaleVal);
typedef UINT32 (*FUNC_ERS_SCALE_CALC_FOR_SPLITCELL)(UINT32 ulCarrNum,INT32 lCellReRefPwr,UINT32 ulReNum, UINT32 *pscaleVal);
typedef UINT32 (*FUNC_GET_PRACH_INFO)(T_IfBbPrachParaV2*,T_PRACH_CFG_BB_PARA_SET*);
typedef UINT32 (*FUNC_GET_LTE_SCALE)(T_CellFftaPara *ptInfo,UINT32 *pVal);
typedef UINT32 (*FUNC_GET_PRACH_FREQ_OFFSET)(T_CellPrachPara *pPara,UINT32 *freqOffset,UINT32 *pNum);
//typedef UINT32(*FUNC_BIT_MAP_SET)(UINT32 ulCarrNo,UINT32 ulMode);

typedef enum
{
    E_IF_BB_PRACH_CFG_AAU_LOW_FREQ = 0,
    E_IF_BB_PRACH_CFG_AAU_HIGH_FREQ,
    E_IF_BB_PRACH_CFG_AAU_MAX,
}E_IF_BB_PRACH_CFG_AAU_TYPE;

typedef enum
{
    E_PRACH_FORMAT__0   =  0,
    E_PRACH_FORMAT__1   =  1,
    E_PRACH_FORMAT__2   =  2,
    E_PRACH_FORMAT__3   =  3,
    E_PRACH_FORMAT_A0   =  4,//保留
    E_PRACH_FORMAT_A1   =  5,
    E_PRACH_FORMAT_A2   =  6,
    E_PRACH_FORMAT_A3   =  7,
    E_PRACH_FORMAT_B1   =  8,
    E_PRACH_FORMAT_B2   =  9,
    E_PRACH_FORMAT_B3   = 10,
    E_PRACH_FORMAT_B4   = 11,
    E_PRACH_FORMAT_C0   = 12,
    E_PRACH_FORMAT_C2   = 13,
    E_PRACH_FORMAT_D0   = 14,//保留
    E_PRACH_FORMAT_D2   = 15,//保留
    E_PRACH_FORMAT_A1B1 = 16,
    E_PRACH_FORMAT_A2B2 = 17,
    E_PRACH_FORMAT_A3B3 = 18,
    E_PRACH_FORMAT_MAX
}E_PRACH_FORMAT_TYPE;

typedef enum
{
    E_PRACH_SCS_FREQ_15K     = 0,//实际配1
    E_PRACH_SCS_FREQ_30K     = 1,//实际配2
    E_PRACH_SCS_FREQ_60K     = 2,//3
    E_PRACH_SCS_FREQ_120K    = 3,//4
    E_PRACH_SCS_FREQ_240K    = 4,//5
    E_PRACH_SCS_FREQ_SPARE30 = 5,//6
    E_PRACH_SCS_FREQ_SPARE2  = 6,//7
    E_PRACH_SCS_FREQ_SPARE1  = 7,//8
    E_PRACH_SCS_FREQ_1P25K   = 8,//9
    E_PRACH_SCS_FREQ_5K      = 9,//10
    E_PRACH_SCS_FREQ_MAX
}E_PRACH_SCS_FREQ;//MSG1 SCS子载波间隔

/**************************************************************************
 *                         函数声明
 **************************************************************************/

UINT32 BspSetTxCarrNco(UINT32 bspChan, UINT32 carr, UINT32 radioMode, UINT32 ncoVal);
UINT32 BspGetTxCarrNco(UINT32 bspChan, UINT32 carr, UINT32 radioMode, UINT32 *ncoVal);
UINT32 BspGetTxFreqNco(UINT32 bspChan, UINT32 carr, UINT32 radioMode, UINT32 *ncoVal);
UINT32 BspSetRxCarrNco(UINT32 bspChan, UINT32 carr, UINT32 radioMode, UINT32 ncoVal);
UINT32 BspGetRxCarrNco(UINT32 bspChan, UINT32 carr, UINT32 radioMode, UINT32 *ncoVal);
UINT32 BspSetTxCarrBand(UINT32 ulBwType, UINT32 ulBspChnl, UINT32 ulCarrNo,
                                                UINT32 ulRadioMode, UINT32 ulBwKHz);
UINT32 BspGetTxCarrBand(UINT32 ulBwType, UINT32 ulBspChnl, UINT32 ulCarrNo,
                                              UINT32 ulRadioMode, UINT32 *pulBwKHz);
UINT32 BspSetRxCarrBand(UINT32 ulBwType, UINT32 ulBspChnl, UINT32 ulCarrNo,
                                                UINT32 ulRadioMode, UINT32 ulBwKHz);
UINT32 BspGetRxCarrBand(UINT32 ulBwType, UINT32 ulBspChnl, UINT32 ulCarrNo,
                                               UINT32 ulRadioMode, UINT32 *pulBwKHz);
UINT32 BspGetCarrBandRegInfo(UINT32 ulBwType, UINT32 ulTrxDir, UINT32 ulBspChnl,
                                     UINT32 ulCarr, UINT32 *pulRegAddr, UINT32 *pulRegData);
UINT32 BspGetCarrNcoRegAddr(UINT32 trxDir, UINT32 bspChan, UINT32 carr, UINT32 *pNcoRegAddr);
UINT32 BspInitIfBbPrachParaCfg(UINT32 aauType, FUNC_GET_PRACH_INFO getFunc);
    
UINT32 BspCalcScaleBasedOnErsCallback(FUNC_ERS_SCALE_CALC pFunc);

UINT32 BspClrRfFpgaBitmap(VOID);
UINT32 BspRegisterFuncGetLteScaleCallBack(FUNC_GET_LTE_SCALE pFunc);
UINT32 BspGetCellPrachFreqOffSetRegister(FUNC_GET_PRACH_FREQ_OFFSET pFunc);
//UINT32 BspSetCfgRfBitMap(FUNC_BIT_MAP_SET ptFunc);
//UINT32 BspCfgRfBitMap(UINT32 ulCarrNo,UINT32 ulMode);
UINT32 BspGetCarrStatus(UINT32 uDir,UINT32 carrNo,UINT32 radioMode,UINT32 *pcarrSta,UINT32 txChnNum);
VOID BspStub_SsbPrach(UINT32 ulflag);
VOID BspStub_LinkMuliCarrFlag(UINT32 ulflag);
UINT32 BspGetCarrMode(UINT32 dir, UINT32 chan, UINT32 carrNo);
UINT32 HalIcGetCellIdByCfg(UINT32 mode, UINT32 dir, UINT32 carrNo, UINT32 antNo);
UINT32 optGetCellCarrBw(UINT32 cell,UINT32 dir);
UINT32 trxstatus();
#ifdef __cplusplus
}
#endif
#endif 




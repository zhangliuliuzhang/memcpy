
#include <string.h>
#include "bsppub.h"
#include "bspcomm.h"
#include "chnmapcommon.h"
#include "linkcfgcommon.h"
#include "exprn.h"
#include "rruinfo.h"
#include "regdrv_accesstbl.h"
#include "regdrv_access.h"
#include "linkcfgcommon.h"
#include "chnmap_a.h"
#include "funccommon_chncfg.h"
#ifdef DPDIC3_R8998G
#include "res_mng_localcell.h"
#endif

/**************************************************************************
 *                         宏定义
 **************************************************************************/
#define IF_BB_PRACH_CFG_CHECK_INIT_RETURN               \
    {                                                       \
        if(E_IF_BB_PRACH_CFG_AAU_MAX == s_aauType)          \
        {                                                   \
            dbgErr("[%s]PrachCfg not Init\n", __FUNCTION__);\
            return BSP_ERROR;                               \
        }                                                   \
    }

#define PRACH_MAX_CARR_NUM        2
#define RE_NUM_OF_PER_RB          12   //每个RB有12个RE
#define MAINCARRTOTAL    4
#define LTE_ERS_INDEX_START       0
#define LTE_ERS_INDEX_END         300

static UINT32 linkcfgcommregprn = 0;
#define REG_DEBUG(regId, reg, offset, data) \
        if (linkcfgcommregprn) printf("[%s] (id:%d)wrfpga %#x (mask:%#x) data:%#x\n", __FUNCTION__, (regId), (reg), (offset), (data))


#define GET_ERR_INDEX_RANGE(ers,start,end)  ((ers) < (start) ? (start) : ((ers) > (end) ? (end) : (ers)))

/**************************************************************************
 *                         变量与数据类型
 **************************************************************************/
typedef enum
{
    E_PRACH_FORMAT__3_RB_NUM = 3,
    E_PRACH_FORMAT_12_RB_NUM = 12
}E_PRACH_FORMAT_RB_NUM_TYPE;

typedef struct tagT_LteScaleTbl
{
    UINT32 ersIndex;
    UINT32 scaleVal;
}T_LteScaleTbl;

//static FUNC_BIT_MAP_SET g_BitMapSet = NULL;

static FUNC_GET_PRACH_INFO s_prachGetFunc              = NULL;
FUNC_ERS_SCALE_CALC        pCalcErsScaleFunc           = NULL;
FUNC_ERS_SCALE_CALC        pQueAllFpgaCalcErsScaleFunc    = NULL;
FUNC_ERS_SCALE_CALC_FOR_SPLITCELL        pKu5PCalcErsScaleFunc    = NULL;
FUNC_ERS_SCALE_CALC_FOR_SPLITCELL        pHfCalcErsScaleFunc    = NULL;
static UINT32              s_totalRbNumofPrachPosition = 0xFFFF;
static UINT32              s_aauType                   = E_IF_BB_PRACH_CFG_AAU_MAX;//272个RB
static T_IfBbPrachParaV2   s_v208DbgTmpDataV2 = {0};//最大存储2载波的参数
static UINT32 s_SSBsitePrach = 0x0;
static UINT32 s_MuliCarrFlag = 0x0;

static T_LteScaleTbl s_lteScaleTbl[] =
{
    {0  , 6},
    {1  , 6},
    {2  , 6},
    {3  , 6},
    {4  , 6},
    {5  , 6},
    {6  , 6},
    {7  , 6},
    {8  , 6},
    {9  , 6},
    {10 , 6},
    {11 , 6},
    {12 , 6},
    {13 , 6},
    {14 , 6},
    {15 , 6},
    {16 , 6},
    {17 , 6},
    {18 , 6},
    {19 , 6},
    {20 , 6},
    {21 , 6},
    {22 , 6},
    {23 , 6},
    {24 , 6},
    {25 , 6},
    {26 , 6},
    {27 , 6},
    {28 , 6},
    {29 , 5},
    {30 , 5},
    {31 , 5},
    {32 , 5},
    {33 , 5},
    {34 , 5},
    {35 , 5},
    {36 , 5},
    {37 , 5},
    {38 , 5},
    {39 , 5},
    {40 , 5},
    {41 , 5},
    {42 , 5},
    {43 , 5},
    {44 , 5},
    {45 , 5},
    {46 , 5},
    {47 , 5},
    {48 , 5},
    {49 , 5},
    {50 , 5},
    {51 , 5},
    {52 , 5},
    {53 , 5},
    {54 , 5},
    {55 , 5},
    {56 , 5},
    {57 , 5},
    {58 , 5},
    {59 , 5},
    {60 , 5},
    {61 , 5},
    {62 , 5},
    {63 , 5},
    {64 , 5},
    {65 , 5},
    {66 , 5},
    {67 , 5},
    {68 , 5},
    {69 , 5},
    {70 , 5},
    {71 , 5},
    {72 , 5},
    {73 , 5},
    {74 , 5},
    {75 , 5},
    {76 , 5},
    {77 , 5},
    {78 , 5},
    {79 , 5},
    {80 , 5},
    {81 , 5},
    {82 , 5},
    {83 , 5},
    {84 , 5},
    {85 , 5},
    {86 , 5},
    {87 , 5},
    {88 , 5},
    {89 , 4},
    {90 , 4},
    {91 , 4},
    {92 , 4},
    {93 , 4},
    {94 , 4},
    {95 , 4},
    {96 , 4},
    {97 , 4},
    {98 , 4},
    {99 , 4},
    {100, 4},
    {101, 4},
    {102, 4},
    {103, 4},
    {104, 4},
    {105, 4},
    {106, 4},
    {107, 4},
    {108, 4},
    {109, 4},
    {110, 4},
    {111, 4},
    {112, 4},
    {113, 4},
    {114, 4},
    {115, 4},
    {116, 4},
    {117, 4},
    {118, 4},
    {119, 4},
    {120, 4},
    {121, 4},
    {122, 4},
    {123, 4},
    {124, 4},
    {125, 4},
    {126, 4},
    {127, 4},
    {128, 4},
    {129, 4},
    {130, 4},
    {131, 4},
    {132, 4},
    {133, 4},
    {134, 4},
    {135, 4},
    {136, 4},
    {137, 4},
    {138, 4},
    {139, 4},
    {140, 4},
    {141, 4},
    {142, 4},
    {143, 4},
    {144, 4},
    {145, 4},
    {146, 4},
    {147, 4},
    {148, 4},
    {149, 3},
    {150, 3},
    {151, 3},
    {152, 3},
    {153, 3},
    {154, 3},
    {155, 3},
    {156, 3},
    {157, 3},
    {158, 3},
    {159, 3},
    {160, 3},
    {161, 3},
    {162, 3},
    {163, 3},
    {164, 3},
    {165, 3},
    {166, 3},
    {167, 3},
    {168, 3},
    {169, 3},
    {170, 3},
    {171, 3},
    {172, 3},
    {173, 3},
    {174, 3},
    {175, 3},
    {176, 3},
    {177, 3},
    {178, 3},
    {179, 3},
    {180, 3},
    {181, 3},
    {182, 3},
    {183, 3},
    {184, 3},
    {185, 3},
    {186, 3},
    {187, 3},
    {188, 3},
    {189, 3},
    {190, 3},
    {191, 3},
    {192, 3},
    {193, 3},
    {194, 3},
    {195, 3},
    {196, 3},
    {197, 3},
    {198, 3},
    {199, 3},
    {200, 3},
    {201, 3},
    {202, 3},
    {203, 3},
    {204, 3},
    {205, 3},
    {206, 3},
    {207, 3},
    {208, 3},
    {209, 2},
    {210, 2},
    {211, 2},
    {212, 2},
    {213, 2},
    {214, 2},
    {215, 2},
    {216, 2},
    {217, 2},
    {218, 2},
    {219, 2},
    {220, 2},
    {221, 2},
    {222, 2},
    {223, 2},
    {224, 2},
    {225, 2},
    {226, 2},
    {227, 2},
    {228, 2},
    {229, 2},
    {230, 2},
    {231, 2},
    {232, 2},
    {233, 2},
    {234, 2},
    {235, 2},
    {236, 2},
    {237, 2},
    {238, 2},
    {239, 2},
    {240, 2},
    {241, 2},
    {242, 2},
    {243, 2},
    {244, 2},
    {245, 2},
    {246, 2},
    {247, 2},
    {248, 2},
    {249, 2},
    {250, 2},
    {251, 2},
    {252, 2},
    {253, 2},
    {254, 2},
    {255, 2},
    {256, 2},
    {257, 2},
    {258, 2},
    {259, 2},
    {260, 2},
    {261, 2},
    {262, 2},
    {263, 2},
    {264, 2},
    {265, 2},
    {266, 2},
    {267, 2},
    {268, 2},
    {269, 2},
    {270, 1},
    {271, 1},
    {272, 1},
    {273, 1},
    {274, 1},
    {275, 1},
    {276, 1},
    {277, 1},
    {278, 1},
    {279, 1},
    {280, 1},
    {281, 1},
    {282, 1},
    {283, 1},
    {284, 1},
    {285, 1},
    {286, 1},
    {287, 1},
    {288, 1},
    {289, 1},
    {290, 1},
    {291, 1},
    {292, 1},
    {293, 1},
    {294, 1},
    {295, 1},
    {296, 1},
    {297, 1},
    {298, 1},
    {299, 1},
    {300, 1}
};
static FUNC_GET_LTE_SCALE pFuncGetLteScale = NULL;
static FUNC_GET_PRACH_FREQ_OFFSET pGetPrachFreqOffset = NULL;

/**************************************************************************
 *                         函数声明定义
 **************************************************************************/
UINT32 trxcarrstatus(VOID);
UINT32 BspGetStub_SsbPrach(VOID);

UINT32 BspInitIfBbPrachParaCfg(UINT32 aauType, FUNC_GET_PRACH_INFO getFunc)
{
    s_aauType = aauType;
    switch(aauType)
    {
        case E_IF_BB_PRACH_CFG_AAU_LOW_FREQ:
            {
                INPUT_POINTER_CHECK(getFunc);
                s_prachGetFunc = getFunc;
                s_totalRbNumofPrachPosition = 136*2;//272个RB;
                break;
            }
        case E_IF_BB_PRACH_CFG_AAU_HIGH_FREQ:
            {
                //高频机型修改这里的定义
                INPUT_POINTER_CHECK(getFunc);
                s_prachGetFunc = getFunc;
                s_totalRbNumofPrachPosition = 132*2;
                break;
            }
        default:
            {
                dbgErr("[%s]case out of range\n", __FUNCTION__);
                return BSP_ERROR;
            }
    }

    BspLog(LOG_LEVEL_0,"{%s} aauType'%d\n", __FUNCTION__,aauType);
    return BSP_OK;
}

UINT32 BspCalcScaleBasedOnErsCallback(FUNC_ERS_SCALE_CALC pFunc)
{
    INPUT_POINTER_CHECK(pFunc);
    pCalcErsScaleFunc = pFunc;
    return BSP_OK;
}

UINT32 BspQueAllFpgaCalcScaleBasedOnErsCallback(FUNC_ERS_SCALE_CALC pFunc)
{
    INPUT_POINTER_CHECK(pFunc);
    pQueAllFpgaCalcErsScaleFunc = pFunc;
    return BSP_OK;
}
#if 0
UINT32 BspSetCfgRfBitMap(FUNC_BIT_MAP_SET ptFunc)
{
    if(ptFunc!=NULL)
    {
        g_BitMapSet = ptFunc;
    }
    return BSP_OK;
}
UINT32 BspCfgRfBitMap(UINT32 ulCarrNo,UINT32 ulMode)
{
    if(g_BitMapSet!=NULL)
    {
        return g_BitMapSet(ulCarrNo,ulMode);
    }
    return BSP_OK;
}
#endif

#ifdef DPDIC3_R8998G

UINT32 BspKu5PCalcScaleBasedOnErsCallback(FUNC_ERS_SCALE_CALC_FOR_SPLITCELL pFunc)
{
    INPUT_POINTER_CHECK(pFunc);
    pKu5PCalcErsScaleFunc = pFunc;
    return BSP_OK;
}
#endif

UINT32 BspHfCalcScaleBasedOnErsCallback(FUNC_ERS_SCALE_CALC_FOR_SPLITCELL pFunc)
{
    INPUT_POINTER_CHECK(pFunc);
    pHfCalcErsScaleFunc = pFunc;
    return BSP_OK;
}

UINT32 BspSetErsScale(UINT32 ulCarrNo,INT32 lCellReRefPwr,UINT32 ulBandWith,UINT32 ulRbNum)
{
    UINT32 fpgaIdx     = 0;
    /* UINT32 fpgaBusType = 0; */
    UINT32 scaleVal    = 0;
    UINT32 uIfFpgaStartIndex = 0;
    UINT32 ulDifchan = 0;
    UINT32 ulIfChipNum       = 0;
    UINT32 retVal = 0;
    UINT32 ulCarrNum = ulCarrNo;
#ifdef DPDIC3_R8998G
    UINT32 uCellId = 0;
    UINT32 uBw = 0;
    UINT32 carrNo = 0;
#endif

    UINT32 radioMode = BspGetCarrMode(TX, 0, ulCarrNo);
    if (BSP_OK != BspGetBspCarrMap(TX,ulCarrNo,radioMode,NULL,&ulCarrNum))
    {
        ulCarrNum = ulCarrNo;
    }

    /* SOC仅有一块FPGA*/
    #if 0
    if (BSP_OK != SpiGetFpgaIdByName("Fpga0", &fpgaIdx, &fpgaBusType))
    {
        dbgErr("get fpgaId failed\n");
        return BSP_ERROR;
    }
    #endif
    dbgInfoEx("[%s]The CarrNo(%d),CellReRefPwr(%d),BandWith(%d),RbNum(%d)\n",__FUNCTION__,ulCarrNum,lCellReRefPwr,ulBandWith,ulRbNum);
    if(NULL != pHfCalcErsScaleFunc)
    {
        if(BSP_ERROR != pHfCalcErsScaleFunc(ulCarrNo,lCellReRefPwr,ulRbNum,&scaleVal))
        {
            dbgInfoEx("%s Scale Value is %d\n",__FUNCTION__,scaleVal); //调试信息，用后清除
            return BSP_OK;
        }
        else
        {
            dbgErr("[%s]Index Scale Value Failed!!!\n",__FUNCTION__);
            return BSP_ERROR;
        }
    }
    if(NULL != pQueAllFpgaCalcErsScaleFunc)
    {
        if(BSP_ERROR != pQueAllFpgaCalcErsScaleFunc(lCellReRefPwr,ulRbNum,&scaleVal))
        {
            dbgInfoEx("%s Scale Value is %d\n",__FUNCTION__,scaleVal); //调试信息，用后清除
         ulIfChipNum = BspGetDifChipNum();

           retVal = BspGetDifInfoByRfChn(0, 0, &uIfFpgaStartIndex, &ulDifchan);
           if(retVal != BSP_OK)
           {
                dbgInfoEx("BspGetDifInfoByRfChn failer!!\n");
            }
            for(fpgaIdx = uIfFpgaStartIndex; fpgaIdx <(uIfFpgaStartIndex+ulIfChipNum); fpgaIdx++)
            {
                if(s_MuliCarrFlag == 0x1) //98e配置双nr
                {
                    //coverity[cert_exp37_c_violation:SUPPRESS]
                    //coverity[cert_int31_c_violation:SUPPRESS]
                    BspRegWr(fpgaIdx, REG_IF_ERS_SCALE_CARRY0, ulCarrNum*0x100, scaleVal - 1);
                }
                else
                {
                    //coverity[cert_exp37_c_violation:SUPPRESS]
                    //coverity[cert_int31_c_violation:SUPPRESS]
                    BspRegWr(fpgaIdx, REG_IF_ERS_SCALE_CARRY0 + ulCarrNum, 0, scaleVal - 1);
                }
            }
            return BSP_OK;
        }
        else
        {
            dbgErr("[%s]Index Scale Value Failed!!!\n",__FUNCTION__);
            return BSP_ERROR;
        }
    }
    if(NULL != pCalcErsScaleFunc)
    {
        if(BSP_ERROR != pCalcErsScaleFunc(lCellReRefPwr,ulRbNum,&scaleVal))
        {
            dbgInfoEx("%s Scale Value is %d\n",__FUNCTION__,scaleVal); //调试信息，用后清除
            if(s_MuliCarrFlag == 0x1) //98e配置双nr
            {
                //coverity[cert_exp37_c_violation:SUPPRESS]
                //coverity[cert_int31_c_violation:SUPPRESS]
                BspRegWr(fpgaIdx, REG_IF_ERS_SCALE_CARRY0, ulCarrNum*0x100, scaleVal - 1);
            }
            else
            {
                //coverity[cert_exp37_c_violation:SUPPRESS]
                //coverity[cert_int31_c_violation:SUPPRESS]
                BspRegWr(fpgaIdx, REG_IF_ERS_SCALE_CARRY0 + ulCarrNum, 0, scaleVal - 1);
            }
            return BSP_OK;
        }
        else
        {
            dbgErr("[%s]Index Scale Value Failed!!!\n",__FUNCTION__);
            return BSP_ERROR;
        }
    }
#ifdef DPDIC3_R8998G
    if(NULL != pKu5PCalcErsScaleFunc)
    {
        if(BSP_ERROR != pKu5PCalcErsScaleFunc(ulCarrNo,lCellReRefPwr,ulRbNum,&scaleVal))
        {
#if 0
            dbgInfoEx("%s Scale Value is %d\n",__FUNCTION__,scaleVal); //调试信息，用后清除

            BspRegWr(fpgaIdx, REG_IF_ERS_SCALE_CARRY0 + ulCarrNum, 0, scaleVal - 1);
            BspRegWr(fpgaIdx, REG_IF_ERS_SCALE_CARRY1 + ulCarrNum, 0, scaleVal - 1);
#else
            uCellId = HalIcGetCellIdByCfg(0x2000, TX, ulCarrNum, 0);
            uBw = optGetCellCarrBw(uCellId,TX);
            dbgInfo("%s(carr=%d,cell=%d,bw=%d) Scale Value is %d\n",
                __FUNCTION__,ulCarrNum,uCellId,uBw,scaleVal); //调试信息，用后清除
            //if(((is9604()==0)&&(uBw!=OAM_CELL_CARR_BW_60M)) /*ku5p的80M版本80M和100M固定是其载波0，对应设置载波0对应的寄存器*/
                    //||(is9604()&&
            carrNo = BspGetNRCarrNo(RADIO_STANDARD_5G,ulCarrNum);
            if (0 == carrNo) /*ku5p的2个100M版本按小区号设置对应的寄存器*/
            {
                BspRegWr(fpgaIdx, REG_IF_ERS_SCALE_CARRY0, 0, scaleVal - 1);
                BspRegWr(fpgaIdx, REG_IF_ERS_SCALE_CARRY0, 0x100, scaleVal - 1);
            }
            else /*ku5p的80M版本60M固定是其载波1，对应设置载波1对应的寄存器*/
            {
                BspRegWr(fpgaIdx, REG_IF_ERS_SCALE_CARRY0, 0x300, scaleVal - 1);
                BspRegWr(fpgaIdx, REG_IF_ERS_SCALE_CARRY0, 0x400, scaleVal - 1);
            }
#endif
            return BSP_OK;
        }
        else
        {
            dbgErr("[%s]Index Scale Value Failed!!!\n",__FUNCTION__);
            return BSP_ERROR;
        }
    }
#endif
    dbgErr("[%s]Call Back Function Is Null !!!\n",__FUNCTION__);
    return BSP_ERROR;
}
static UINT32 BspGetPrachStartSymbol(UINT32 startSymbol, UINT32* symbol)
{
    IF_BB_PRACH_CFG_CHECK_INIT_RETURN;
    INPUT_POINTER_CHECK(symbol);
    if(E_IF_BB_PRACH_CFG_AAU_LOW_FREQ == s_aauType)
    {
        switch(startSymbol)//低频的计算处理
        {
            case 0:
                *symbol = 0;
                 break;
            case 1:
                *symbol = 2;
                break;
            case 2:
                *symbol = 3;
                break;
            case 3:
                *symbol = 6;
                break;
            default:
                dbgErr("[%s]aauType'%d, case out of range\n", __FUNCTION__, s_aauType);
                return BSP_ERROR;
                break;
        }
    }
    else
    {
        *symbol = startSymbol;
    }

    return BSP_OK;
}
static UINT32 BspGetIfBbPrachRbNum(UINT32 format, UINT32 subCarrSpace, UINT32* rbNum)
{
    IF_BB_PRACH_CFG_CHECK_INIT_RETURN;
    INPUT_POINTER_CHECK(rbNum);
    if(E_IF_BB_PRACH_CFG_AAU_LOW_FREQ == s_aauType)
    {
        switch(format)//低频的Rb计算处理
        {
            case E_PRACH_FORMAT__0:
                *rbNum = E_PRACH_FORMAT__3_RB_NUM;
                break;
            case E_PRACH_FORMAT_A3:
            case E_PRACH_FORMAT_C2:
            case E_PRACH_FORMAT_B4:
                *rbNum = E_PRACH_FORMAT_12_RB_NUM;
                break;
            default:
                dbgErr("[%s]aauType'%d, case out of range\n", __FUNCTION__, s_aauType);
                return BSP_ERROR;
                break;
        }
    }
    else
    {
        switch(subCarrSpace)//高频的Rb计算处理
        {
            case 2:
           *rbNum = 6;
                break;
            case 3:
           *rbNum = 12;
                break;
            default:
                return BSP_ERROR;

        }
    }

    return BSP_OK;
}

static UINT32 BspGetIfBbPrachSampleSel(UINT32 format, UINT32 subCarrSpace, UINT32* SampleSel)
{
    IF_BB_PRACH_CFG_CHECK_INIT_RETURN;
    INPUT_POINTER_CHECK(SampleSel);

    if(E_IF_BB_PRACH_CFG_AAU_LOW_FREQ != s_aauType)
    {
        return BSP_ERROR;
    }

    switch(subCarrSpace)
    {
        case 0:
            {
                *SampleSel = 1;
                break;
            }
        case 1:
            {
                *SampleSel = 2;
                break;
            }
        default:
            {
                dbgErr("[%s]aauType'%d, case out of range\n", __FUNCTION__, s_aauType);
                return BSP_ERROR;
            }
    }

    return BSP_OK;
}


UINT32 BspSetIfBbPrachPara(T_IfBbPrachPara *ifBbPrachPara)
{
    UINT32 retVal            = 0;
    UINT32 fpgaId            = 0;
    UINT32 totalReNum        = 0;
    UINT32 rBNum             = 0;
    UINT32 wrStartFreq       = 0;
    UINT32 format            = 0;
    UINT32 startRb           = 0;
    UINT32 startSymbol       = 0;
    UINT32 cfgIndex          = 0;
    UINT32 prachSCS          = 0;
    UINT32 sampleSel         = 0;
    UINT32 ucarrNo           = 0;
    UINT32 uIfFpgaStartIndex = 0;
    /* UINT32 uIfFpgaEndIndex   = 0; */
    UINT32 ulDifchan         = 0;
    UINT32 ulIfChipNum       = 0;
    UINT32 symbol            = 0;

    INPUT_POINTER_CHECK(ifBbPrachPara);
    IF_BB_PRACH_CFG_CHECK_INIT_RETURN;

    format      = ifBbPrachPara->prachFormat;
    startRb     = ifBbPrachPara->rbStart;
    startSymbol = ifBbPrachPara->StartSymbol;
    cfgIndex    = ifBbPrachPara->prachConfigIndex;
    prachSCS    = ifBbPrachPara->prachSubcarrierSpacing;
    ucarrNo     = ifBbPrachPara->carrNo;

    if(BSP_OK != (retVal = BspGetPrachStartSymbol(startSymbol,&symbol)))
    {
        dbgErr("[%s]Get symbol Failed\n", __FUNCTION__);
        return BSP_ERROR;
    }

    if(BSP_OK != (retVal = BspGetIfBbPrachRbNum(format,prachSCS,&rBNum)))
    {
        dbgErr("[%s]Get RbNum Failed\n", __FUNCTION__);
        return BSP_ERROR;
    }

    ulIfChipNum = BspGetDifChipNum();

    totalReNum = RE_NUM_OF_PER_RB * s_totalRbNumofPrachPosition / 2;//RE总个数
    if(startRb < s_totalRbNumofPrachPosition / 2)
    {
        wrStartFreq = totalReNum - startRb*RE_NUM_OF_PER_RB - rBNum * RE_NUM_OF_PER_RB / 2;
    }
    else
    {
        wrStartFreq = totalReNum - startRb*RE_NUM_OF_PER_RB - rBNum * RE_NUM_OF_PER_RB / 2;
        wrStartFreq = 1 + (~wrStartFreq);//后136个RB的数据，要取补码
    }

    retVal = BspGetDifInfoByRfChn(0, 0, &uIfFpgaStartIndex, &ulDifchan);
    if(retVal != BSP_OK)
    {
        dbgInfoEx("BspGetDifInfoByRfChn failer!!\n");
    }

    for(fpgaId = uIfFpgaStartIndex; fpgaId <(uIfFpgaStartIndex+ulIfChipNum); fpgaId++)
    {
        BspRegWr(fpgaId,REG_PRACH_FORMAT,    0,format);
        BspRegWr(fpgaId,REG_PRACH_START_FREQ+ucarrNo,0,wrStartFreq);

        BspRegWr(fpgaId,REG_PRACH_START_SYM, 0,symbol);
        BspRegWr(fpgaId,REG_PRACH_CFG_INDEX, 0,cfgIndex);
        BspRegWr(fpgaId,REG_PRACH_SUBCARRIER_SPACE, 0,prachSCS);//高频的配置

        if(BSP_OK == (retVal = BspGetIfBbPrachSampleSel(format,prachSCS,&sampleSel)))
        {
            BspRegWr(fpgaId,REG_PRACH_SAMPLE_SEL,0,sampleSel);//子载波间隔
            dbgInfoEx("[%s]Fmt'%d,SCS'%d,sampleSel'%d\n", __FUNCTION__,format,prachSCS,sampleSel);
            BspLog(LOG_LEVEL_0,"[%s]Fmt'%d,SCS'%d,sampleSel'%d\n", __FUNCTION__,format,prachSCS,sampleSel);
        }
    }

    dbgInfoEx("[%s]Fmt'%d,rBNum'%d,startRb'%d,startFreq'0x%08x,symbol'%d('%d),cfgIndx'%d,SCS'%d\n",
               __FUNCTION__,format,rBNum,startRb,wrStartFreq,startSymbol,symbol,cfgIndex,prachSCS);

    BspLog(LOG_LEVEL_0,"{%s}Fmt'%d,rBNum'%d,startRb'%d,startFreq'0x%08x,symbol'%d('%d),cfgIndx'%d,SCS'%d\n",
               __FUNCTION__,format,rBNum,startRb,wrStartFreq,startSymbol,symbol,cfgIndex,prachSCS);

    return BSP_OK;
}

UINT32 BspSetIfBbPrachParaV2(T_IfBbPrachParaV2 *pV2)
{
    /* UINT32               ret     = 0; */
    /* UINT32               reNum   = 0; */
    /* UINT32               rbNum   = 0; */
    /* UINT32               sFreq   = 0; */
    /* UINT32               fmt     = 0; */
    /* UINT32               RBstart    = 0; */
    /* UINT32               symbol  = 0; */
    /* UINT32               cfgIdx  = 0; */
    /* UINT32               msg1Scs = 0; */
    /*UINT16               scs     = 0;    */
    /* UINT32               sample  = 0; */
    UINT32               retVal    = 0;
    UINT32               fpga    = 0;
    UINT32               ulIfChipNum       = 0;
    /* UINT32               totalReNum        = 0;     */
    /* UINT32               startSymbol            = 0;     */
    UINT32               ulDifchan         = 0;
    /* UINT32               ulCarrierBandWidth0 = 0; */
    UINT32               uIfFpgaStartIndex = 0;
    /* UINT32               prachConfigIndex            = 0; */
    /* T_PRACH_CFG_IDX_MAP*     idxData = NULL; */
    T_PRACH_CFG_BB_PARA_SET  set = {0};
    /* T_RruRfCfgInfo rruCfgPara = {0}; */
    UINT32 FreqC_SSB = 0;
    UINT32 FreqL_carr = 0;
    /*UINT32 FreqCarr = 0;*/
    UINT32 RBssbSta = 0;
    UINT32 REssbOff = 0;
    UINT32 SSB_start = 0;
    UINT32 rmtsurport = 0;
    UINT32 Scs_Trans[5] = {15,30,60,120,240};
    UINT32 uFpgaLogicNo;
    UINT32 uRadioMode = 0;

    UINT32 uFpgaLogicPrachCarrid = 0;
    UINT32 ufpgaId0 = 0;//IFFPGA0
    UINT32 ufpgaId1 = 1;//IFFPGA1
    UINT32 uOffset = 0;
    UINT32 fpgaVal = 0;
    UINT32 fpgaVal00 = 2;
    UINT32 fpgaVal11 = 2;
    UINT32 prachcarrOffset = 0;

    INPUT_POINTER_CHECK(pV2);
    INPUT_POINTER_CHECK(s_prachGetFunc);
    BspLog(LOG_LEVEL_0,"%s (pV2->carrNo =%d,pV2->cellId=%d,pV2->maincarrTotal=%d,pV2->maincarrIndex=%d,pV2->prachConfigIndex=%d,pV2->msg1FrequencyStart=%d)\n",\
        __FUNCTION__,pV2->carrNo,pV2->cellId,pV2->maincarrTotal,pV2->maincarrIndex,pV2->prachConfigIndex,pV2->msg1FrequencyStart);



    prachcarrOffset = pV2->carrNo *8 ;
    ulIfChipNum = BspGetDifChipNum();

    memcpy_s((VOID*)&s_v208DbgTmpDataV2, sizeof(T_IfBbPrachParaV2), (VOID*)pV2, sizeof(T_IfBbPrachParaV2));
    if(pV2->prachConfigIndex != 0xffffffff)
    {
        if(BSP_OK != s_prachGetFunc(pV2, &set))
        {
            dbgErr("[%s]Func Get Error\n", __FUNCTION__);
            return BSP_ERROR;
        }


        retVal = BspGetDifInfoByRfChn(0, 0, &uIfFpgaStartIndex, &ulDifchan);
        if(retVal != BSP_OK)
        {
            dbgInfoEx("BspGetDifInfoByRfChn failer!!\n");
        }
        if(pV2->maincarrTotal == 0)
        {
            pV2->maincarrTotal = 1;
        }

        for(fpga = uIfFpgaStartIndex; fpga <(uIfFpgaStartIndex+ulIfChipNum); fpga++)
        {
            if(s_MuliCarrFlag == 0x1) //98e配置双nr
            {
                BspRegBitValWr(fpga, REG_PRACH_FORMAT, 0, set.fmt, prachcarrOffset, 3+prachcarrOffset);   //prach格式     0x6c10 [3:0] nr0  [11:8]nr1
                BspRegWr(fpga, REG_PRACH_START_FREQ, pV2->carrNo,set.sFreq); //频偏          0x6c20 nr0 频偏 ；0x6c21 nr1频偏
                BspRegBitValWr(fpga, REG_PRACH_START_SYM,  0, set.symbol, prachcarrOffset, 4+prachcarrOffset);//起始符号      0x6c12 [4:0]:nr0  [12:8]:nr1
                BspRegBitValWr(fpga, REG_PRACH_SAMPLE_SEL, 0, set.sample, prachcarrOffset, 1+prachcarrOffset);//子载波间隔    0x6c11 [1:0] nr0  [9:8]:nr1
                BspRegWr(fpga, REG_PRACH_CFG_INDEX,  0,pV2->prachConfigIndex);//0x6814 LOW FREQ
            }
            else
           {
            BspRegWr(fpga, REG_PRACH_FORMAT,     0,set.fmt);   //0x6802 0:A3制式  1:C2制式
            if(s_SSBsitePrach !=(UINT32)0xfe)
            {
                BspRegWr(fpga, REG_PRACH_START_FREQ+ pV2->maincarrIndex, 0,set.sFreq); //0x680C 0x680e  freq
            }
            BspRegWr(fpga, REG_PRACH_START_SYM,  0,set.symbol);//0x6812 0~13
            BspRegWr(fpga, REG_PRACH_SAMPLE_SEL, 0,set.sample);//0x680A//子载波间隔
            BspRegWr(fpga, REG_PRACH_CFG_INDEX,  0,pV2->prachConfigIndex);//0x6814 LOW FREQ
            BspRegWr(fpga,REG_PRACH_SUBCARRIER_SPACE, 0,set.sample);//高频的配置0x6810 3:120KHZ 2:60khz
            }
            if(s_SSBsitePrach ==(UINT32)0xff)   //高频9825
            {
                switch (pV2->maincarrTotal)
                {
                    case 4:
                    {
                        BspRegWr(fpga, REG_PRACH_CFG_MODE,  0,2);//0x6818

                        switch(pV2->maincarrIndex)
                        {
                            case 0:
                            {
                                BspRegWr(fpga, REG_PRACH_MCARR_VALID,  0,set.uMainCarrNo);//0x6814  Hfreq 100M:0,1,2,3 200M:0,2 400M 0
                                break;
                            }
                            case 1:
                            {
                                BspRegWr(fpga, REG_PRACH_MCARR_VALID,  2,set.uMainCarrNo);//0x6816  Hfreq 100M:0,1,2,3 200M:0,2 400M 0
                                break;
                            }
                            case 2:
                            {
                                BspRegWr(fpga, REG_PRACH_MCARR_VALID,  0x30,set.uMainCarrNo);//0x6844  Hfreq 100M:0,1,2,3 200M:0,2 400M 0
                                break;
                            }
                            case 3:
                            {
                                BspRegWr(fpga, REG_PRACH_MCARR_VALID,  0x32,set.uMainCarrNo);//0x6846  Hfreq 100M:0,1,2,3 200M:0,2 400M 0
                                break;
                            }
                            default:
                            {
                                BspRegWr(fpga, REG_PRACH_MCARR_VALID,  0,set.uMainCarrNo);//0x6814  Hfreq 100M:0,1,2,3 200M:0,2 400M 0
                                break;
                            }

                        }
                         break;
                    }
                    case 2:
                    {
                        BspRegWr(fpga, REG_PRACH_CFG_MODE,  0,1);//0x6818

                        switch(pV2->maincarrIndex)
                        {
                            case 0:
                            {
                                BspRegWr(fpga, REG_PRACH_MCARR_VALID,  0,set.uMainCarrNo);//0x6814  Hfreq 100M:0,1,2,3 200M:0,2 400M 0
                                break;
                            }
                            case 1:
                            {
                                BspRegWr(fpga, REG_PRACH_MCARR_VALID,  2,set.uMainCarrNo);//0x6816  Hfreq 100M:0,1,2,3 200M:0,2 400M 0
                                break;
                            }
                            default:
                            {
                                BspRegWr(fpga, REG_PRACH_MCARR_VALID,  0,set.uMainCarrNo);//0x6814  Hfreq 100M:0,1,2,3 200M:0,2 400M 0
                                break;
                            }

                        }
                          break;
                    }
                    case 1:
                    {
                        BspRegWr(fpga, REG_PRACH_CFG_MODE,  0,0);//0x6818
                        BspRegWr(fpga, REG_PRACH_MCARR_VALID,  0,set.uMainCarrNo);//0x6814  Hfreq 100M:0,1,2,3 200M:0,2 400M 0
                        break;
                    }
                    default:
                    {
                        BspRegWr(fpga, REG_PRACH_CFG_MODE,  0,0);//0x6818
                        BspRegWr(fpga, REG_PRACH_MCARR_VALID,  0,set.uMainCarrNo);//0x6814  Hfreq 100M:0,1,2,3 200M:0,2 400M 0
                        break;
                    }

                }// end switch
            }//end s_SSBsitePrach ==(UINT32)0xff
            else if(s_SSBsitePrach ==(UINT32)0xfe)   //高频9815
            {
                switch (pV2->maincarrTotal)
                {
                    case 4:
                    {
                        BspRegWr(fpga, REG_PRACH_CFG_MODE,  0,2);//0x683e

                        switch(pV2->maincarrIndex)
                        {
                            case 0:
                            {
                                BspRegWr(fpga, REG_PRACH_MCARR_VALID,  0,set.uMainCarrNo);//0x6814  Hfreq 100M:0,1,2,3 200M:0,2 400M 0
                                BspRegWr(fpga, REG_PRACH_START_FREQ,   0,set.sFreq); //0x680C freq
                                break;
                            }
                            case 1:
                            {
                                BspRegWr(fpga, REG_PRACH_MCARR_VALID,  0x2c,set.uMainCarrNo);//0x6840  Hfreq 100M:0,1,2,3 200M:0,2 400M 0
                                BspRegWr(fpga, REG_PRACH_START_FREQ,   0x02,set.sFreq); //0x680e freq
                                break;
                            }
                            case 2:
                            {
                                BspRegWr(fpga, REG_PRACH_MCARR_VALID,  0x2e,set.uMainCarrNo);//0x6842  Hfreq 100M:0,1,2,3 200M:0,2 400M 0
                                BspRegWr(fpga, REG_PRACH_START_FREQ,   0x3a,set.sFreq); //0x6846 freq
                                break;
                            }
                            case 3:
                            {
                                BspRegWr(fpga, REG_PRACH_MCARR_VALID,  0x30,set.uMainCarrNo);//0x6844  Hfreq 100M:0,1,2,3 200M:0,2 400M 0
                                BspRegWr(fpga, REG_PRACH_START_FREQ,   0x3c,set.sFreq); //0x6848 freq
                                break;
                            }
                            default:
                            {
                                BspRegWr(fpga, REG_PRACH_MCARR_VALID,  0,set.uMainCarrNo);//0x6814  Hfreq 100M:0,1,2,3 200M:0,2 400M 0
                                break;
                            }

                        }
                         break;
                    }
                    case 2:
                    {
                        BspRegWr(fpga, REG_PRACH_CFG_MODE,  0,1);//0x683e

                        switch(pV2->maincarrIndex)
                        {
                            case 0:
                            {
                                BspRegWr(fpga, REG_PRACH_MCARR_VALID,  0,set.uMainCarrNo);//0x6814  Hfreq 100M:0,1,2,3 200M:0,2 400M 0
                                BspRegWr(fpga, REG_PRACH_START_FREQ,   0,set.sFreq); //0x680C freq
                                break;
                            }
                            case 1:
                            {
                                BspRegWr(fpga, REG_PRACH_MCARR_VALID,  0x2c,set.uMainCarrNo);//0x6840  Hfreq 100M:0,1,2,3 200M:0,2 400M 0
                                BspRegWr(fpga, REG_PRACH_START_FREQ,   0x02,set.sFreq); //0x680e freq
                                break;
                            }
                            default:
                            {
                                BspRegWr(fpga, REG_PRACH_MCARR_VALID,  0,set.uMainCarrNo);//0x6814  Hfreq 100M:0,1,2,3 200M:0,2 400M 0
                                BspRegWr(fpga, REG_PRACH_START_FREQ,   0,set.sFreq); //0x680C freq
                                break;
                            }

                        }
                          break;
                    }
                    case 1:
                    {
                        BspRegWr(fpga, REG_PRACH_CFG_MODE,  0,0);//0x683e
                        BspRegWr(fpga, REG_PRACH_MCARR_VALID,  0,set.uMainCarrNo);//0x6814  Hfreq 100M:0,1,2,3 200M:0,2 400M 0
                        BspRegWr(fpga, REG_PRACH_START_FREQ,   0,set.sFreq); //0x680C freq
                        break;
                    }
                    default:
                    {
                        BspRegWr(fpga, REG_PRACH_CFG_MODE,  0,0);//0x683e
                        BspRegWr(fpga, REG_PRACH_MCARR_VALID,  0,set.uMainCarrNo);//0x6814  Hfreq 100M:0,1,2,3 200M:0,2 400M 0
                        BspRegWr(fpga, REG_PRACH_START_FREQ,   0,set.sFreq); //0x680C freq
                        break;
                    }

                }// end switch
            }//end s_SSBsitePrach ==(UINT32)0xfe
            else
            {
                BspRegWr(fpga, REG_PRACH_MCARR_VALID,  0,set.uMainCarrNo);//0x6814  Hfreq 100M:0,1,2,3 200M:0,2 400M 0
            }
        }//end for
    }//end (pV2->prachConfigIndex != 0xffffffff)

    dbgInfo("[%s]set.fmt %d, symbol %d, sample %d, sFreq 0x%08x, prachConfigIndex %d,scs=%d ,gscn = %d,carrBandWidth0=%d\n",
               __FUNCTION__,set.fmt,set.symbol,set.sample,set.sFreq,pV2->prachConfigIndex,pV2->subCarrSpacing0,pV2->gscn,pV2->carrBandWidth0);

    if((BspGetStub_SsbPrach()) == (UINT32)(0xFF))    //高频9825
    {
/*-------240K SSB载波频域位置计算, 仅考虑100M带宽------*/
      if(pV2->carrBandWidth0 ==(UINT16)(66) )//RB Numbers
      {
        FreqC_SSB = 24250080 + 17280*(pV2->gscn - 22256);      //kHz,SSB中心频点计算
        dbgInfoEx("SSB center Frequence ==%d, SCS_Val = %d, Carr_center_Frq=%d \n",FreqC_SSB,Scs_Trans[pV2->subCarrSpacing0],pV2->carrCenterFrq0);

        FreqL_carr = pV2->carrCenterFrq0 - ((12*(pV2->carrBandWidth0)*(Scs_Trans[pV2->subCarrSpacing0]))/2); //可用载波最低子载波的中心偏点
        RBssbSta = (FreqC_SSB - 10*12*240 - FreqL_carr)/(Scs_Trans[pV2->subCarrSpacing0]) ; //SSB的起始RB
        REssbOff = RBssbSta % 12;  //SSB的RE偏移--FPGA截取PHY的频域数据中取了偏移

        /*--------配置FPGA-------*/
        SSB_start = 12*(RBssbSta/12) + REssbOff ; //SSB的起始位置

        if(BspCarrIdMapGetLocalCarrId(pV2->carrNo,&uFpgaLogicNo,&uRadioMode) != BSP_OK)
        {
            uFpgaLogicNo = pV2->carrNo;
        }

        for(fpga = uIfFpgaStartIndex; fpga <(uIfFpgaStartIndex+ulIfChipNum); fpga++)
        {
            if(uFpgaLogicNo == 0)
            {
                BspRegWr(fpga,REG_PRACH_SSB_READDR0,0,SSB_start);/*偏移值设定取决于逻辑提供寄存器地址*/
            }
            else
            {
                BspRegWr(fpga,REG_PRACH_SSB_READDR1,(uFpgaLogicNo-1)*2,SSB_start);
            }

         }
      }

      if(pV2->prachDistanceMode != 0xFF)//默认非主载，不改配逻辑寄存器
      {
          rmtsurport = (pV2->prachDistanceMode == (UINT8)(1))? 1:0 ;
          for(fpga = uIfFpgaStartIndex; fpga <(uIfFpgaStartIndex+ulIfChipNum); fpga++)
          {
              BspRegWr(fpga,REG_PRACH_RM_CP_CFG0,(UINT32)(0),rmtsurport);
          }
      }
    }//end (BspGetStub_SsbPrach()) == (UINT32)(0xFF)

    if((BspGetStub_SsbPrach()) == (UINT32)(0xFF))//9825 prach配置
    {
        BspLog(LOG_LEVEL_0,"%s enter 9825 prach configure \n", __FUNCTION__);
        dbgInfo("\n%s enter 9825 prach configure \n", __FUNCTION__);
        if(pV2->prachDistanceMode == 0xFF)//主载波配置
        {//根据APP下发的carrNo，查询对应的 localcarrid
            if(BspCarrIdMapGetLocalCarrId(pV2->carrNo, &uFpgaLogicPrachCarrid, &uRadioMode) != BSP_OK)
            {
                dbgErr("(BspCarrIdMapGetLocalCarrId() is ERROR, please check !!! \n");
                return BSP_ERROR;
            }
            else
            {
                dbgInfo("\n 9825 fpga resgister prach configure 1 \n");
                if(uFpgaLogicPrachCarrid == 1)//如果 localcarrid 是 1，
                {
                    dbgInfo("\n localcarrid == 1 \n");

                    if(pV2->configType == 1)//并且 configType 也是 1 ，则 bit0 置 1；
                    {
                        fpgaVal = 0;
                    }
                    else
                    {
                        fpgaVal = 1;

                    }

                    dbgInfo("\n localcarrid == 1 && configType != 1\n");
                    BspRegWr(ufpgaId0, REG_FPGA_SET_PRACH0, uOffset, fpgaVal);
                    BspLog(LOG_LEVEL_0,"%s chip(%d) >> localcarrid == 1 &&　pV2->configType != 1 ufpgaId0`s  fpgaVal1 is %d\n",  __FUNCTION__, ufpgaId0, fpgaVal);
                    BspRegWr(ufpgaId1, REG_FPGA_SET_PRACH0, uOffset, fpgaVal);
                    BspLog(LOG_LEVEL_0,"%s chip(%d) >> localcarrid == 1 &&　pV2->configType != 1 ufpgaId1`s  fpgaVal1 is %d\n",  __FUNCTION__, ufpgaId1, fpgaVal);

                    BspRegRd(ufpgaId0, REG_FPGA_SET_PRACH0, 0, &fpgaVal00);
                    BspRegRd(ufpgaId1, REG_FPGA_SET_PRACH0, 0, &fpgaVal11);
                    dbgInfo("%s >> localcarrid == 1 &&　pV2->configType != 1 ufpgaId0`s  fpgaVal00 is %d\n", __FUNCTION__, fpgaVal00);
                    dbgInfo("%s >> localcarrid == 1 &&　pV2->configType != 1 ufpgaId1`s  fpgaVal11 is %d\n", __FUNCTION__, fpgaVal11);
                }
                dbgInfo("\n 9825 fpga resgister prach configure 5 \n");
                if(uFpgaLogicPrachCarrid == 5)//如果 localcarrid 是 5，
                {
                    dbgInfo("\n localcarrid == 5 \n");
                    if(pV2->configType == 1)//并且 configType 也是 1 ，则 bit1 置 1；
                    {
                        fpgaVal = 1;
                    }
                    else//否则，bit1置 0；
                    {
                        fpgaVal = 0;
                    }

                    dbgInfo("\n localcarrid == 5 && configType == 1\n");
                    BspRegWr(ufpgaId0, REG_FPGA_SET_PRACH1, uOffset, fpgaVal);
                    BspLog(LOG_LEVEL_0,"%s chip(%d) >> localcarrid == 5 &&　pV2->configType == 1 ufpgaId0`s  fpgaVal1 is %d\n",  __FUNCTION__, ufpgaId0, fpgaVal);
                    BspRegWr(ufpgaId1, REG_FPGA_SET_PRACH1, uOffset, fpgaVal);
                    BspLog(LOG_LEVEL_0,"%s chip(%d) >> localcarrid == 5 &&　pV2->configType == 1 ufpgaId1`s  fpgaVal1 is %d\n",  __FUNCTION__, ufpgaId1, fpgaVal);

                    BspRegRd(ufpgaId0, REG_FPGA_SET_PRACH1, 0, &fpgaVal00);
                    BspRegRd(ufpgaId1, REG_FPGA_SET_PRACH1, 0, &fpgaVal11);
                    dbgInfo("%s >> localcarrid == 5 &&　pV2->configType == 1 ufpgaId0`s  fpgaVal00 is %d\n", __FUNCTION__, fpgaVal00);
                    dbgInfo("%s >> localcarrid == 5 &&　pV2->configType == 1 ufpgaId1`s  fpgaVal11 is %d\n", __FUNCTION__, fpgaVal11);
                }
            }
        }
    }

    #ifdef A9815
    if(BspGetOptBbVbpType(0) == BSP_BB_VBP_TYPE_V3)    //高频9815 v3
    {
        if(BspCarrIdMapGetLocalCarrId(pV2->carrNo,&uFpgaLogicNo,&uRadioMode) != BSP_OK)
        {
            uFpgaLogicNo = pV2->carrNo;
        }
/*-------240K SSB载波频域位置计算, 仅考虑100M带宽------*/
      if(pV2->carrBandWidth0 ==(UINT16)(66) )//RB Numbers
      {
        //FreqC_SSB = 24250080 + 17280*(pV2->gscn - 22256);      //kHz,SSB中心频点计算
        if(pV2->gscn == 0)
        {
            FreqC_SSB = pV2->carrCenterFrq0-12960;      //kHz,SSB中心频点计算
        }
        else
        {
           FreqC_SSB = 24250080 + 17280*(pV2->gscn - 22256);      //kHz,SSB中心频点计算
        }
        dbgInfoEx("SSB center Frequence ==%d, SCS_Val = %d, Carr_center_Frq=%d \n",FreqC_SSB,Scs_Trans[pV2->subCarrSpacing0],pV2->carrCenterFrq0);

        FreqL_carr = pV2->carrCenterFrq0 - ((12*(pV2->carrBandWidth0)*(Scs_Trans[pV2->subCarrSpacing0]))/2); //可用载波最低子载波的中心偏点
        RBssbSta = (FreqC_SSB - 10*12*120 - FreqL_carr)/(Scs_Trans[pV2->subCarrSpacing0]) ; //SSB的起始RB
        REssbOff = RBssbSta % 12;  //SSB的RE偏移--FPGA截取PHY的频域数据中取了偏移
        SSB_rb_start = RBssbSta/12;
        /*--------配置FPGA-------*/
        SSB_start = 12*(RBssbSta/12) + REssbOff ; //SSB的起始位置

        for(fpga = uIfFpgaStartIndex; fpga <(uIfFpgaStartIndex+ulIfChipNum); fpga++)
        {
            dbgInfoEx("\nSSB_start = %d,SSB_rb_start = %d\n",SSB_start,SSB_rb_start);

            BspRegWr(fpga,REG_PRACH_SSB_READDR0,uFpgaLogicNo*2,SSB_start);

            if(uFpgaLogicNo/4 == 0)
            {
                BspRegWr(0,REG_PRACH_SSB_RB_READDR0,uFpgaLogicNo*2,SSB_rb_start);/*偏移值设定取决于逻辑提供寄存器地址*/
            }
            else
            {
                   BspRegWr(0,REG_PRACH_SSB_RB_READDR1,(uFpgaLogicNo-4)*2,SSB_rb_start);
            }

         }
      }

    }//end (BspGetOptBbVbpType(0) == BSP_BB_VBP_TYPE_V3)
    #endif
    BspLog(LOG_LEVEL_0,"%s end\n",__FUNCTION__);
    return BSP_OK;
}

/**********************************************************************
* 函数名称：BspCarrStatusCollect
* 功能描述：查看载波开关状态
* 输入参数：无
* 输出参数：无
* 返 回 值：BSP_OK    - 成功
*           BSP_ERROR - 失败
* 其它说明：无
***********************************************************************/
UINT32 BspCarrStatusCollect(VOID)
{
    UINT32 tmpRegData[2] = {0};
    UINT32 DLCarrAddr    = 0;
    UINT32 ULCarrAddr    = 0;
    UINT32 ulfpgaIdx     = 0;
    UINT32 retVal        = BSP_OK;
    RedirPrintf("\nCarrier Switch state:\n");

    /*下行载波开关状态*/
    retVal |= BspGetRegAddrAndMask(ulfpgaIdx, REG_TX_DATA_OFF_CARR0, 0, &DLCarrAddr, NULL);
    retVal |= BspRegRd(ulfpgaIdx, REG_TX_DATA_OFF_CARR0, 0, &tmpRegData[0]);
    RedirPrintf("Downlink Carrier: addr = 0x%05X, state = 0x%04X\n", DLCarrAddr, tmpRegData[0]);

    /*上行载波开关状态*/
    retVal |= BspGetRegAddrAndMask(ulfpgaIdx, REG_RX_DATA_OFF_CARR0, 0, &ULCarrAddr, NULL);
    retVal |= BspRegRd(ulfpgaIdx, REG_RX_DATA_OFF_CARR0, 0, &tmpRegData[1]);
    RedirPrintf("Uplink Carrier:   addr = 0x%05X, state = 0x%04X\n", ULCarrAddr, tmpRegData[1]);

    trxcarrstatus();

    return retVal;
}

/**************************************************************************
 *                         手敲调试命令区
 **************************************************************************/
UINT32 setIfBbPrachPara(UINT8 carr, UINT32 format,UINT32 cfgId,UINT32 rbStart,UINT32 symbol, UINT32 ulPraSpacing)
{
    T_IfBbPrachPara para = {0};
    para.carrNo                 = carr;
    para.prachFormat            = format;
    para.prachConfigIndex       = cfgId;
    para.rbStart                = rbStart;
    para.StartSymbol            = symbol;
    para.prachSubcarrierSpacing = ulPraSpacing;
    return BspSetIfBbPrachPara(&para);
}

static UINT32 setParaData(const char *srcStr, const char *dstStr, UINT32* updateVal)
{
    char *buf  = NULL;
    INPUT_POINTER_CHECK(srcStr);
    INPUT_POINTER_CHECK(dstStr);
    INPUT_POINTER_CHECK(updateVal);

    if(NULL != (buf = strstr(srcStr,dstStr)))
    {
        *updateVal = strtoul(buf + strlen(dstStr), 0, 0);
        STRTOUL_CHECK(((unsigned long)(*updateVal)));
        dbgInfoEx("dstStr:%s,updateVal:0x%04x\n", dstStr, *updateVal);
    }
    else
    {
        dbgErr("dstStr:%s,string not found!\n", dstStr);
        return BSP_ERROR;
    }

    return BSP_OK;
}

static UINT32 prachSetParaV2Data(char* fileName, T_IfBbPrachParaV2 *pV2)
{
    /* UINT32 data       = 0; */
    /* UINT32 enable     = 0; */
    INT32  readLen    = 0;
    UINT32 ret        = 0;
    char   temp[1024] = {0};//申请了1K字节的临时空间
    /* UINT8  *buf       = NULL; */
    FILE   *fp        = NULL;
    INT32  fclsRet    = 0;

    INPUT_POINTER_CHECK(fileName);
    INPUT_POINTER_CHECK(pV2);
    if (NULL == (fp = fopen(fileName,"r")))
    {
        dbgErr("[%s]Error! File Not Found\n", __FUNCTION__);
        return BSP_ERROR;
    }

    if(0 >= (readLen = fread(temp,1,sizeof(temp)-1,fp)))
    {
        fclsRet = fclose(fp);
        FCLOSE_CHECK(fclsRet);
        dbgErr("[%s]Error! Empty File\n", __FUNCTION__);
        return BSP_ERROR;
    }

    fclsRet = fclose(fp);
    FCLOSE_CHECK(fclsRet);

    temp[1024 - 1] = '\0';//尾部置0
    ret |= setParaData(temp, "carrNo=",               (UINT32 *)(&(pV2->carrNo)));
    ret |= setParaData(temp, "prachConfigIndex=",     (UINT32 *)(&(pV2->prachConfigIndex)));
    ret |= setParaData(temp, "rbStartInitBwp=",       (UINT32 *)(&(pV2->rbStartInitBwp)));
    ret |= setParaData(temp, "msg1FrequencyStart=",   (UINT32 *)(&(pV2->msg1FrequencyStart)));
    ret |= setParaData(temp, "msg1SubcarrierSpacing=",(UINT32 *)(&(pV2->msg1SubcarrierSpacing)));
    ret |= setParaData(temp, "subcarrierSpacing=",    (UINT32 *)(&(pV2->subcarrierSpacing)));
    ret |= setParaData(temp, "offsetToCarr0=",        (UINT32 *)(&(pV2->offsetToCarr0)));
    ret |= setParaData(temp, "subCarrSpacing0=",      (UINT32 *)(&(pV2->subCarrSpacing0)));
    ret |= setParaData(temp, "carrBandWidth0=",       (UINT32 *)(&(pV2->carrBandWidth0)));
    ret |= setParaData(temp, "offsetToCarr1=",        (UINT32 *)(&(pV2->offsetToCarr1)));
    ret |= setParaData(temp, "subCarrSpacing1=",      (UINT32 *)(&(pV2->subCarrSpacing1)));
    ret |= setParaData(temp, "carrBandWidth1=",       (UINT32 *)(&(pV2->carrBandWidth1)));
    ret |= setParaData(temp, "carrCenterFrq0=",       (UINT32 *)(&(pV2->carrCenterFrq0)));
    ret |= setParaData(temp, "gscn=",       (UINT32 *)(&(pV2->gscn)));
    ret |= setParaData(temp, "cellId=",       (UINT32 *)(&(pV2->cellId)));
    ret |= setParaData(temp, "prachDistanceMode=",       (UINT32 *)(&(pV2->prachDistanceMode)));

    return ret;
}

UINT32 setIfBbPrachParaV2(char* cfgFileName)
{
    UINT32                  ret = 0;
    T_IfBbPrachParaV2       pV2 = {0};

    INPUT_POINTER_CHECK(cfgFileName);

    /** cfgFileName文本的内容样例 ***
     ********************************
     * carrNo=0
     * prachConfigIndex=0
     * rbStartInitBwp=0
     * msg1FrequencyStart=0
     * msg1SubcarrierSpacing=0
     * subcarrierSpacing=0
     * offsetToCarr0=0
     * subCarrSpacing0=0
     * carrBandWidth0=0
     * offsetToCarr1=0
     * subCarrSpacing1=0
     * carrBandWidth1=0
     * carrCenterFrq0=0
     * gscn=0
     *cellId=0
     *prachDistanceMode =0
     ********************************/

    if(BSP_OK != (ret = prachSetParaV2Data(cfgFileName, &pV2)))
    {
        dbgErr("[%s]get prachSetParaV2Data failed\n", __FUNCTION__);
        return BSP_ERROR;
    }

    if(BSP_OK != (ret = BspSetIfBbPrachParaV2(&pV2)))
    {
        dbgErr("[%s]get getParaV2ConvertInfo failed\n", __FUNCTION__);
        return BSP_ERROR;
    }

    return ret;
}


UINT32 BspGetCellPrachFreqOffSetRegister(FUNC_GET_PRACH_FREQ_OFFSET pFunc)
{
    pGetPrachFreqOffset = pFunc;
    return BSP_OK;
}

/*****************************************************************************
 *  函数名称     : BspSetPrachPara(*)
 *  功能描述     : 小区PRACH参数配置
 *  输入参数     :
 *  输出参数     : 无
 *  返回值      : BSP_OK
 *  其他说明     :
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *
 *----------------------------------------------------------------------------
 */
UINT32 BspSetPrachPara(T_CellPrachPara *ptInfo)
{
    UINT32 loop = 0;
    UINT32 fpgaId = 0;
    const UINT32 carrOffset = 0x2;
    UINT32 carrNo = 0;
    /* UINT32 regEn, regAddr = REG_CARR0_FREQ_NCO_0, regDataH, regDataL; */
    E_REG_FUNCID_DEF regAddr = REG_CARR0_FREQ_NCO_0;
    UINT32 freqOffset[CELL_PRACH_FREQ_OFFSET_NUM] = {0};
    UINT32 freqNum = 0;
    UINT32 selFlag = 0;
    INPUT_POINTER_CHECK(ptInfo);
    UINT32 tmpRegAddr, tmpValMask;

    if (BSP_OK != BspGetBspCarrMap(TX,ptInfo->carrNo,ptInfo->radioMode,NULL,&carrNo))
    {
        return BSP_ERROR;
    }
    dbgInfo("%s logicCarr:%d fpgaCarr:%d radioMode:%#x \n", __FUNCTION__, ptInfo->carrNo, carrNo, ptInfo->radioMode);

    if (ptInfo->radioMode == RADIO_STANDARD_LTE_TDD)
    {
        regAddr = REG_CARR0_FREQ_NCO_0_LTE;
        /*mmecpri todo*/
        if (pGetPrachFreqOffset && BSP_OK==pGetPrachFreqOffset(ptInfo, freqOffset,&freqNum))
        {
            BspRegRd(fpgaId, REG_CARR_FREQ_STEP_FLAG, 0, &selFlag);
            BspRegWr(fpgaId, REG_CARR_FREQ_STEP_FLAG, 0, selFlag|(1<<carrNo));
            /*小区所使用的PARCH的协议类型，规定了PARCH组帧格式，长短码结构等格式出现的时刻   这个需要配置给逻辑*/
            for (loop=0; loop<min(freqNum,CELL_PRACH_FREQ_OFFSET_NUM); ++loop)
            {
                BspRegWr(fpgaId, regAddr+loop, carrNo*carrOffset, freqOffset[loop]);
                BspGetRegAddrAndMask(fpgaId, regAddr+loop, carrNo*carrOffset, &tmpRegAddr, &tmpValMask);
                REG_DEBUG(regAddr+loop, tmpRegAddr, tmpValMask, freqOffset[loop]);
            }
            BspRegWr(fpgaId, REG_CARR_FREQ_STEP_FLAG, 0, selFlag&(~(1<<carrNo)));
        }
    }

    return BSP_OK;
}

UINT32 BspRegisterFuncGetLteScaleCallBack(FUNC_GET_LTE_SCALE pFunc)
{
    pFuncGetLteScale = pFunc;
    return BSP_OK;
}

UINT32 BspGetLteScaleInfo(T_CellFftaPara *ptInfo,UINT32 *pVal)
{
    UINT32 pow = 0;
    FLOAT  powDbm = 0.0;
    FLOAT  txErsDbm = 0.0;
    FLOAT  portDbm = 0.0;
    INT32  ersIndex = 0;
    UINT32 portVal[] = {1, 2, 4};
    UINT32 loop;
    INPUT_POINTER_CHECK(pVal);
    INPUT_POINTER_CHECK(ptInfo);

    pow = BspGetRruFullPow();
    if (pow == 0)
    {
        return BSP_ERROR;
    }
    if (ptInfo->txErs > 1100)
    {
        dbgErr("%s txErs'%d is invalid\n",__FUNCTION__,ptInfo->txErs);
        return BSP_ERROR;
    }
    if (ptInfo->portNum >= NELEMENTS(portVal))
    {
        dbgErr("%s portNum'%d is invalid\n",__FUNCTION__,ptInfo->portNum);
        return BSP_ERROR;
    }

    powDbm = (FLOAT)(10*log10(pow));
    /* E_RS_new = 10 * (E_RS?C?(Pcell_max - 43) +10*lg(port_num)) */
    txErsDbm = (ptInfo->txErs - 600.0) / 10.0;
    portDbm = 10*log10(portVal[ptInfo->portNum]);
    ersIndex = (INT32)(10 * (txErsDbm - (powDbm - 43) + portDbm));
    dbgInfoEx("%s txErs=%d portNum=%d ersIndex=%d\n",__FUNCTION__,ptInfo->txErs,ptInfo->portNum,ersIndex);
    ersIndex = GET_ERR_INDEX_RANGE(ersIndex,LTE_ERS_INDEX_START,LTE_ERS_INDEX_END);

    for (loop = 0; loop < NELEMENTS(s_lteScaleTbl); loop++)
    {
        if (ersIndex == (INT32)s_lteScaleTbl[loop].ersIndex)
        {
            *pVal = s_lteScaleTbl[loop].scaleVal;
            return BSP_OK;
        }
    }
    return BSP_ERROR;
}

/*****************************************************************************
 *  函数名称     : BspSetFftaPara(*)
 *  功能描述     : 小区FFTA参数配置
 *  输入参数     :
 *  输出参数     : 无
 *  返回值      : BSP_OK
 *  其他说明     :
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *
 *----------------------------------------------------------------------------
 */
UINT32 BspSetFftaPara(T_CellFftaPara *ptInfo)
{
    UINT32 carrNo = 0;
    E_REG_FUNCID_DEF regAddr = REG_RES_SCALE_CARR0_TX;
    UINT32 scaleVal = 0;
    UINT32 chipInfo[8] = {0};
    UINT32 chipNum = 8;
    UINT32 carrSelVal = 0;
    UINT32 loop;
    FUNC_GET_LTE_SCALE pFunc = pFuncGetLteScale;
    //UINT32 tmpRegAddr, tmpValMask;
    INPUT_POINTER_CHECK(ptInfo);

    if (BSP_OK != BspGetBspCarrMap(TX,ptInfo->carrNo,ptInfo->radioMode,NULL,&carrNo))
    {
        return BSP_ERROR;
    }
    dbgInfo("%s logicCarr:%d fpgaCarr:%d radioMode:%#x \n", __FUNCTION__, ptInfo->carrNo, carrNo, ptInfo->radioMode);

    if (ptInfo->radioMode == RADIO_STANDARD_LTE_TDD)
    {
        regAddr = REG_RES_SCALE_CARR0_TX_LTE;
        if (pFunc == NULL)
        {
            pFunc = BspGetLteScaleInfo;
        }

        if (BSP_OK != pFunc(ptInfo,&scaleVal))
        {
            return BSP_ERROR;
        }

        if (BSP_OK != BspGetRegChip(regAddr,chipInfo,&chipNum))
        {
            return BSP_ERROR;
        }
        for (loop = 0; loop < chipNum; loop++)
        {
            BspRegRd(chipInfo[loop], REG_RES_SCALE_CARR_SEL_FLAG, 0, &carrSelVal);
            BspRegWr(chipInfo[loop], REG_RES_SCALE_CARR_SEL_FLAG, 0, carrSelVal|(1<<carrNo));
            BspRegWr(chipInfo[loop], regAddr, carrNo, scaleVal);
            BspRegWr(chipInfo[loop], REG_RES_SCALE_CARR_SEL_FLAG, 0, carrSelVal&(~(1<<carrNo)));
            //BspGetRegAddrAndMask(chipInfo[loop], regAddr, carrNo, &tmpRegAddr, &tmpValMask);
            //REG_DEBUG(regAddr, tmpRegAddr, tmpValMask, ptInfo->txErs);
        }
    }

    return BSP_OK;
}

UINT32 BspSetRfFpgaBitmap(UINT32 carrNo, UINT32 radioMode, UINT32 isON)
{
    UINT32 chipInfo[8] = {0};
    UINT32 chipNum = 8;
    E_REG_FUNCID_DEF regAddr;
    UINT32 regIdxTmp = 0;
    UINT32 loop;

    if (BSP_OK != BspGetBspCarrMap(TX,carrNo,radioMode,NULL,&carrNo))
    {
        return BSP_ERROR;
    }

    regAddr = REG_FPGA_BITMAP_SEL_CARR0 + carrNo;
    regIdxTmp = regAddr;
    if (BSP_OK != BspGetRegChip(regIdxTmp,chipInfo,&chipNum))
    {
        return BSP_ERROR;
    }

    for (loop = 0; loop < chipNum; loop++)
    {
        BspRegWr(chipInfo[loop], regAddr, 0, isON);
    }

    return BSP_OK;
}

UINT32 BspClrRfFpgaBitmap(VOID)
{
    UINT32 loop;
    T_McsCarrIdMap mapInfo[MCS_ID_MAP_NUM_MAX] = {0};
    UINT32 mapInfoNum = MCS_ID_MAP_NUM_MAX;

    if (BSP_OK != BspGetMcsCarrIdMap(mapInfo,&mapInfoNum))
    {
        return BSP_ERROR;
    }

    for (loop = 0; loop < mapInfoNum; loop++)
    {
        BspSetRfFpgaBitmap(mapInfo[loop].logicCarrNo,mapInfo[loop].radioMode,0);
    }

    return BSP_OK;
}

#ifdef BUILD_WITH_OM_FUNC
UINT32 txoff(UINT32 startChn,UINT32 endChn)
{
    UINT32 retVal = BSP_OK;
    UINT32 chn = startChn;
    UINT32 chnNum = min(BspGetTxChannel(), endChn+1);

    do
    {
        retVal |= BspSetTxSwitch(chn, SWITCH_OFF);
    } while (++chn < chnNum);
    return retVal;
}
#endif

UINT32 txon(UINT32 startChn,UINT32 endChn)
{
    UINT32 retVal = BSP_OK;
    UINT32 chn = startChn;
    UINT32 chnNum = min(BspGetTxChannel(), endChn+1);

    do
    {
        retVal |= BspSetTxSwitch(chn, SWITCH_ON);
    } while (++chn < chnNum);
    return retVal;
}

#ifdef BUILD_WITH_OM_FUNC
UINT32 rxoff(UINT32 startChn,UINT32 endChn)
{
    UINT32 retVal = BSP_OK;
    UINT32 chn = startChn;
    UINT32 chnNum = min(BspGetRxChannel(), endChn+1);

    do
    {
        retVal |= BspSetRxSwitch(chn, SWITCH_OFF);
    } while (++chn < chnNum);
    return retVal;
}

UINT32 rxon(UINT32 startChn,UINT32 endChn)
{
    UINT32 retVal = BSP_OK;
    UINT32 chn = startChn;
    UINT32 chnNum = min(BspGetRxChannel(), endChn+1);

    do
    {
        retVal |= BspSetRxSwitch(chn, SWITCH_ON);
    } while (++chn < chnNum);
    return retVal;
}
#endif

UINT32 trxstatus()
{
    UINT32 txChnNum = BspGetTxChannel();
    UINT32 rxChnNum= BspGetRxChannel();
    UINT32 *txSta, *rxSta;
    UINT32 loop;

    txSta = malloc(txChnNum*sizeof(UINT32));
    if (txSta == NULL)
    {
        return BSP_ERROR;
    }
    rxSta= malloc(rxChnNum*sizeof(UINT32));
    if (rxSta == NULL)
    {
        free(txSta);
        return BSP_ERROR;
    }

    memset(txSta,0,txChnNum*sizeof(UINT32));
    for (loop = 0; loop < txChnNum; loop++)
    {
        txSta[loop] = BspGetTxSwitch(loop);
    }

    memset(rxSta,0,rxChnNum*sizeof(UINT32));
    for (loop = 0; loop < rxChnNum; loop++)
    {
        rxSta[loop] = BspGetRxSwitch(loop);
    }

    RedirPrintf("tx switch status(0:OFF,1:ON):\n");
    for (loop = 0; loop < txChnNum; loop++)
    {
        RedirPrintf("[%d]%d%s",loop,txSta[loop],((loop+1)%8)?" ":"\n");
    }
    RedirPrintf("\n");

    RedirPrintf("rx switch status(0:OFF,1:ON):\n");
    for (loop = 0; loop < rxChnNum; loop++)
    {
        RedirPrintf("[%d]%d%s",loop,rxSta[loop],((loop+1)%8)?" ":"\n");
    }
    RedirPrintf("\n");

    free(txSta);
    free(rxSta);
    return BSP_OK;
}

#ifdef BUILD_WITH_OM_FUNC
UINT32 trxsta()
{
    return trxstatus();
}
#endif

static UINT32 GetLinkCarrMode(UINT32 chn,UINT32 carr,UINT32 dir,UINT32 defRadio)
{
    UINT32 radio = 0;
    radio = BspGetCarrMode(dir, chn, carr);
    if (radio == BSP_ERROR)
    {
        radio = defRadio;
    }
    return radio;
}

static UINT32 trxcarronoff(UINT32 dir,UINT32 carr,UINT32 startChn,UINT32 endChn,UINT32 sw,UINT32 radio)
{
    UINT32 retVal = BSP_OK;
    UINT32 chn = startChn;
    UINT32 trxNum = (dir==RX)?BspGetRxChannel():BspGetTxChannel();
    UINT32 chnNum = min(trxNum, endChn+1);

    do
    {
        if (radio == 0)
        {
            radio = GetLinkCarrMode(chn,carr,dir,radio);
        }
        retVal |= BspSetCarrSwitch(chn,radio, carr, dir, sw);
    } while (++chn < chnNum);
    return retVal;
}

#ifdef BUILD_WITH_OM_FUNC
UINT32 txcarroff(UINT32 carr,UINT32 startChn,UINT32 endChn,UINT32 radio)
{
    return trxcarronoff(TX,carr,startChn,endChn,SWITCH_OFF,radio);
}

UINT32 txcarron(UINT32 carr,UINT32 startChn,UINT32 endChn,UINT32 radio)
{
    return trxcarronoff(TX,carr,startChn,endChn,SWITCH_ON,radio);
}


UINT32 rxcarroff(UINT32 carr,UINT32 startChn,UINT32 endChn,UINT32 radio)
{
    return trxcarronoff(RX,carr,startChn,endChn,SWITCH_OFF,radio);
}

UINT32 rxcarron(UINT32 carr,UINT32 startChn,UINT32 endChn,UINT32 radio)
{
    return trxcarronoff(RX,carr,startChn,endChn,SWITCH_ON,radio);
}
#endif

UINT32 trxcarrstatus(VOID)
{
    UINT32 txChnNum = BspGetTxChannel();
    UINT32 rxChnNum= BspGetRxChannel();
    UINT32 *txSta, *rxSta;
    UINT32 loop, carr;
    UINT32 radio = BSP_RADIO_STANDARD_5G;
    txSta = malloc(txChnNum*sizeof(UINT32));
    if (txSta == NULL)
    {
        return BSP_ERROR;
    }
    rxSta= malloc(rxChnNum*sizeof(UINT32));
    if (rxSta == NULL)
    {
        free(txSta);
        return BSP_ERROR;
    }

    RedirPrintf("trx carrier switch status(0:OFF,1:ON):\n");
    for (carr = 0; carr < BspGetBspCarrNum(); carr++)
    {
        memset(txSta,0,txChnNum*sizeof(UINT32));
        for (loop = 0; loop < txChnNum; loop++)
        {
            radio = GetLinkCarrMode(loop,carr,TX,BSP_RADIO_STANDARD_5G);
            BspGetCarrSwitch(loop,radio,carr,TX,&txSta[loop]);
        }

        memset(rxSta,0,rxChnNum*sizeof(UINT32));
        for (loop = 0; loop < rxChnNum; loop++)
        {
            radio = GetLinkCarrMode(loop,carr,RX,BSP_RADIO_STANDARD_5G);
            BspGetCarrSwitch(loop,radio,carr,RX,&rxSta[loop]);
        }

        RedirPrintf("carr%d TX ",carr);
        for (loop = 0; loop < txChnNum; loop++)
        {
            RedirPrintf("[%d]%d%s",loop,txSta[loop],((loop+1)%8)?" ":"\n         ");
        }
        RedirPrintf("\n");

        RedirPrintf("carr%d Rx ",carr);
        for (loop = 0; loop < rxChnNum; loop++)
        {
            RedirPrintf("[%d]%d%s",loop,rxSta[loop],((loop+1)%8)?" ":"\n         ");
        }
        RedirPrintf("\n");

    }

    free(txSta);
    free(rxSta);
    return BSP_OK;
}

#ifdef BUILD_WITH_OM_FUNC
UINT32 trxcarrsta()
{
    return trxcarrstatus();
}
#endif

UINT32 carrsta(UINT32 uDir)
{
    UINT32 txChnNum = BspGetTxChannel();
    UINT32 *txSta;
    UINT32 loop, carr;
    UINT32 uMode  = BspGetRadioStandard();
    UINT32 carrNum = BspGetBspCarrNum();
    UINT32 ulRadioNum = 0;
    UINT32 ulRadioLoop = 0;
    UINT32 isOn = 0;
    struct sRadio {
        UINT32 uMode;
        CHAR *pcModeString;
    }atRadio[] =
    {
        {BSP_RADIO_STANDARD_LTE_TDD, "LTE_TDD"},
        {BSP_RADIO_STANDARD_LTE_FDD, "LTE_FDD"},
        {BSP_RADIO_STANDARD_UMTS,    "UMTS"  },
        {BSP_RADIO_STANDARD_GSM,     "GSM"   },
        {BSP_RADIO_STANDARD_NB_IOT,  "NB-IOT"},
        {BSP_RADIO_STANDARD_5G,      "5G-NR" },
    };
    ulRadioNum = NELEMENTS(atRadio);

    txSta = malloc(txChnNum*sizeof(UINT32));
    if (txSta == NULL)
    {
        return BSP_ERROR;
    }

    dbgInfo("trx carrier switch status(0:OFF,1:ON):\n");
    for (ulRadioLoop = 0; ulRadioLoop < ulRadioNum; ulRadioLoop++)
    {
        if (0 == (uMode & atRadio[ulRadioLoop].uMode))
        {
            continue;
        }
        dbgInfo("\n-----------------%s CarrSum'%d ChnlSum'%d ---------------\n",atRadio[ulRadioLoop].pcModeString, carrNum, txChnNum);
        for (carr = 0; carr < carrNum; carr++)
        {
            memset(txSta,0xff,txChnNum*sizeof(UINT32));
            for (loop = 0; loop < txChnNum; loop++)
            {
                if(BspGetCarrSwitch(loop,atRadio[ulRadioLoop].uMode,carr,uDir,&isOn) == BSP_OK)
                {
                    txSta[loop] = isOn;
                }
            }

            if(TX==uDir)
            {
                dbgInfo("carr%d TX ",carr);
            }
            else
            {
                dbgInfo("carr%d RX ",carr);
            }
            for (loop = 0; loop < txChnNum; loop++)
            {
                dbgInfo("[%d]%d%s",loop,txSta[loop],((loop+1)%16)?" ":"\n");
            }
        }
    }
    free(txSta);
    return BSP_OK;
}

UINT32 BspGetCarrStatus(UINT32 uDir,UINT32 carrNo,UINT32 radioMode,UINT32 *pcarrSta,UINT32 txChnNum)
{
    UINT32 loop = 0;
    UINT32 isOn = 0;

    INPUT_POINTER_CHECK(pcarrSta);
    txChnNum = min(32,txChnNum);


    dbgInfoEx("trx carrier switch status(0:OFF,1:ON):\n");
    dbgInfoEx("\n-----------------0x%x CarrNo'%d ChnlSum'%d ---------------\n",radioMode, carrNo, txChnNum);

    for (loop = 0; loop < txChnNum; loop++)
    {
        if(BspGetCarrSwitch(loop,radioMode,carrNo,uDir,&isOn) == BSP_OK)
        {
            pcarrSta[loop] = isOn;
        }
    }

    return BSP_OK;
}
static VOID show208(VOID)
{
    UINT32 loop = 0;
    for(loop = 0; loop < PRACH_MAX_CARR_NUM; loop++)
    {
        dbgInfo("***************************\n");
        dbgInfo("carrNo                = %d\n", s_v208DbgTmpDataV2.carrNo);
        dbgInfo("prachConfigIndex      = %d\n", s_v208DbgTmpDataV2.prachConfigIndex);
     dbgInfo("maincarrTotal                = %d\n", s_v208DbgTmpDataV2.maincarrTotal);
        dbgInfo("maincarrIndex      = %d\n", s_v208DbgTmpDataV2.maincarrIndex);
        dbgInfo("rbStartInitBwp        = %d\n", s_v208DbgTmpDataV2.rbStartInitBwp);
        dbgInfo("msg1FrequencyStart    = %d\n", s_v208DbgTmpDataV2.msg1FrequencyStart);
        dbgInfo("msg1SubcarrierSpacing = %d\n", s_v208DbgTmpDataV2.msg1SubcarrierSpacing);
        dbgInfo("subcarrierSpacing     = %d\n", s_v208DbgTmpDataV2.subcarrierSpacing);
        dbgInfo("offsetToCarr0         = %d\n", s_v208DbgTmpDataV2.offsetToCarr0);
        dbgInfo("subCarrSpacing0       = %d\n", s_v208DbgTmpDataV2.subCarrSpacing0);
        dbgInfo("carrBandWidth0        = %d\n", s_v208DbgTmpDataV2.carrBandWidth0);
        dbgInfo("offsetToCarr1         = %d\n", s_v208DbgTmpDataV2.offsetToCarr1);
        dbgInfo("subCarrSpacing1       = %d\n", s_v208DbgTmpDataV2.subCarrSpacing1);
        dbgInfo("carrBandWidth1        = %d\n", s_v208DbgTmpDataV2.carrBandWidth1);
        dbgInfo("factBandWidth         = %d\n", s_v208DbgTmpDataV2.factBandWidth);
    }
}

#ifdef BUILD_WITH_OM_FUNC
VOID testbspsetprachpara(UINT32 carr, UINT32 radio)
{
    UINT32 loop = 0;
    T_CellPrachPara info = {0};
    info.carrNo = carr;
    info.radioMode = radio;
    for (loop=0; loop<NELEMENTS(info.freqOffset); ++loop)
    {
        info.freqOffset[loop] = loop+1;
    }
    BspSetPrachPara(&info);
}

VOID testbspsetfftapara(UINT32 carr, UINT32 radio)
{
    T_CellFftaPara info = {0};
    info.carrNo = carr;
    info.radioMode = radio;
    info.txErs = 0x55aa;
    BspSetFftaPara(&info);
}
#endif

static UINT32 BspShowPrachPara(char* cfgFileName)
{
    UINT32                  ret = 0;
    T_IfBbPrachParaV2       pV2 = {0};

    INPUT_POINTER_CHECK(cfgFileName);

    /** cfgFileName文本的内容样例 ***
     ********************************
     * carrNo=0
     * prachConfigIndex=0
     * rbStartInitBwp=0
     * msg1FrequencyStart=0
     * msg1SubcarrierSpacing=0
     * subcarrierSpacing=0
     * offsetToCarr0=0
     * subCarrSpacing0=0
     * carrBandWidth0=0
     * offsetToCarr1=0
     * subCarrSpacing1=0
     * carrBandWidth1=0
     *prachDistanceMode =0
     ********************************/

    if(BSP_OK != (ret = prachSetParaV2Data(cfgFileName, &pV2)))
    {
        dbgErr("[%s]get prachSetParaV2Data failed\n", __FUNCTION__);
        return BSP_ERROR;
    }

    BspSysMsDelay(500);
    dbgInfo("carrNo=%d\n",pV2.carrNo);
    dbgInfo("cellId=%d\n",pV2.cellId);
    dbgInfo("gscn=%d\n",pV2.gscn);
    dbgInfo("subCarrSpacing0=%d\n",pV2.subCarrSpacing0);
    dbgInfo("carrBandWidth0=%d\n",pV2.carrBandWidth0);
    dbgInfo("prachDistanceMode=%d\n",pV2.prachDistanceMode);


    dbgInfo("------Start Config PRACH V2 PARA ---------\n");

    ret |= BspSetIfBbPrachParaV2(&pV2);

    return ret;



}


VOID BspStub_SsbPrach(UINT32 ulflag)
{
    s_SSBsitePrach = ulflag;
}


UINT32 BspGetStub_SsbPrach(VOID)
{
    return s_SSBsitePrach ;
}
VOID BspStub_LinkMuliCarrFlag(UINT32 ulflag)
{
    s_MuliCarrFlag = ulflag;
}
UINT32 BspGetStub_LinkMuliCarrFlag(VOID)
{
    return s_MuliCarrFlag ;
}

VOID ptst(UINT32 carrNo, UINT32 cellId, UINT16 maincarrTotal, UINT16 maincarrIndex, UINT32 prachConfigIndex,UINT32 msg1SubcarrierSpacing,UINT8  prachDistanceMode)
{
    T_IfBbPrachParaV2  t_ifbbprachcfg={0};

    t_ifbbprachcfg.carrNo = carrNo;
    t_ifbbprachcfg.cellId = cellId;
    t_ifbbprachcfg.maincarrTotal = maincarrTotal;
    t_ifbbprachcfg.maincarrIndex = maincarrIndex;
    t_ifbbprachcfg.prachConfigIndex = prachConfigIndex;
    t_ifbbprachcfg.msg1SubcarrierSpacing = msg1SubcarrierSpacing;
    t_ifbbprachcfg.prachDistanceMode = prachDistanceMode;


    BspSetIfBbPrachParaV2(&t_ifbbprachcfg);

    return ;

}


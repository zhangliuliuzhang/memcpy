/*****************************************************************************
* 版权所有(C) 2021, ZTE Corp. ZXSDR-RHP Platform BSP
*----------------------------------------------------------------------------
* 模 块 名  : BSP
* 文件名称 :
* 文件标识 : {[N/A]}
* 内容摘要 : 
* 注意事项 : 无
* 作    者 : 
* 创建日期 : 2017-2-27 14:45:34
* 当前版本 : Ver1.0
*----------------------------------------------------------------------------
* 变更记录 :
* $记录1
* 变 更 单: $0000000(N/A)
* 责 任 人: 
* 修改日戳: 
* 变更说明: 创建文件
*----------------------------------------------------------------------------
*/
#include "bsppub.h"
#include "bspcomm.h"
#include "chnmap_a.h"
#include "linkcfg_ic4_2.h"
#include "resource_alloc_api.h"
#include "ichaladaptbspapi.h"
#include "ichaladapt_ic4_2.h"
#include "funccommon_chncfg.h"
#include "funccommon_a.h"

INT32 s_dlPreGain[IC_CHAN_MAX_NUM];          /** dlpre载波增益*/

/* Started by AICoder, pid:n0e2c19a18t052214a81095e505ede128991ebc2 */
UINT32 g_pfuncOfCarrPowFeed = 0;
VOID BspCfgCarrPowFeedFunc(UINT32 cfg)
{
    g_pfuncOfCarrPowFeed = cfg;
}
/* Ended by AICoder, pid:n0e2c19a18t052214a81095e505ede128991ebc2 */

/* Started by AICoder, pid:qc405h0ffbo097c14425080aa057b24d10089859 */
UINT32 BspSetCarrSwitch(UINT32 chan,UINT32 radio,UINT32 carr,UINT32 trx,UINT32 isOn)
{
    UINT32 difId     = 0;
    UINT32 difChnl   = 0;
    UINT32 retVal    = BSP_OK;
    INT32 dlpreGain = 0;
    UINT32 carrPow = 0x7fffffff;
    T_HwInfo *pHwInfo = NULL;

    retVal |= BspGetCfgCarrPow(chan, carr, radio, &carrPow);

    if(g_pfuncOfCarrPowFeed && BSP_OK != retVal)
    {
        if(NULL != (pHwInfo = BspGetGlobalRruHwInfo()))
        {
            carrPow = pHwInfo->RruInfo.aulRatedPowerPath[chan % BSP_MAX_TX_CHAN];
            retVal  = BSP_OK;
            dbgInfo("%s.%d: %u %u %u %u %u Set Default Pow %u\n",__FUNCTION__,__LINE__,
                    chan, radio, carr, trx, isOn, carrPow);
        }
    }

    if (BspGetDifInfoByRfChn(chan,trx,&difId,&difChnl) != BSP_OK)
    {
        dbgErr("%s BspGetDifInfoByRfChn(%d) return error\n",__FUNCTION__,chan);
        BspLog(LOG_LEVEL_0,"%s BspGetDifInfoByRfChn(%d) return error\n",__FUNCTION__,chan);
        return BSP_ERROR;
    }

    if(trx == TX)
    {
        retVal |= BspHalAdaptSetDlCarrGainSw(difChnl, radio, carr, isOn);

        if (SWITCH_OFF == isOn)
        {
            retVal |= BspHalAdaptSetDlpreTdmGainCut(difChnl, carr, radio);
        }

        if ((SWITCH_ON == isOn) && (carrPow != 0))
        {
            dlpreGain = s_dlPreGain[difChnl];
            retVal |= BspHalAdaptSetDlpreGain(difChnl, carr, radio, dlpreGain);
        }
    }
    else
    {
        retVal |= BspHalAdaptSetUlCarrGainSw(difChnl, radio, carr, isOn);
    }
    if((RADIO_STANDARD_5G == radio) && (SUPPORT == BspGetIsSupportAac()))
    {
        retVal |= BspHalAdaptCarrAacSwitchEn(carr, radio, isOn);
    }

    BspLog(LOG_LEVEL_0,"%s{chn'%u,carr'%u,radio'0x%x,trx'%u,sw'%u,dlpreGain'%d,pow'%u} ok\n",
                __FUNCTION__,chan,carr,radio,trx,isOn,dlpreGain,carrPow);

    return retVal;
}
/* Ended by AICoder, pid:qc405h0ffbo097c14425080aa057b24d10089859 */

UINT32 BspGetCarrSwitch(UINT32 chan,UINT32 radio,UINT32 carr,UINT32 trx, UINT32 *isOn)
{
    UINT32 difId     = 0;
    UINT32 difChnl   = 0;
    UINT32 retVal    = BSP_OK;

    INPUT_POINTER_CHECK(isOn);

    if (BspGetDifInfoByRfChn(chan,trx,&difId,&difChnl) != BSP_OK)
    {
        dbgErr("%s BspGetDifInfoByRfChn(%d) return error\n",__FUNCTION__,chan);
        BspLog(LOG_LEVEL_0,"%s BspGetDifInfoByRfChn(%d) return error\n",__FUNCTION__,chan);
        return BSP_ERROR;
    }

    /* 对于当前配置中的无效载波，不进行查询,直接返回错误 */
    if(BSP_OK != BspHalAdaptCheckCarrValid(trx, difChnl, radio, carr))
    {
        return BSP_ERROR;
    }

    if(trx == TX)
    {
        BspHalAdaptGetDlCarrGainSw(difChnl, radio, carr, (INT32 *)isOn);
    }
    else
    {
        BspHalAdaptGetUlCarrGainSw(difChnl, radio, carr, (INT32 *)isOn);
    }

    return retVal;
}

/* 设置削峰通道 dlpre 增益 */
UINT32 BspSetLinkCfgDlpreGain(UINT32 bspChn, INT32 gain)
{
    if(bspChn >= IC_CHAN_MAX_NUM)
    {
        dbgErr("%s bspChn(%d) exceeds the maxChn(%d) \n",__FUNCTION__,bspChn,IC_CHAN_MAX_NUM);
        return BSP_ERROR; 
    }

    s_dlPreGain[bspChn] = gain;

    return BSP_OK;
}

//V3的载波静音接口, V4继续保留
//uCellId：小区ID信息
//uCarrIdx：载波位置 0（低频点）,1（中频点）,2（高频点）
//uSwitch ： 1开（不静音），0关（静音）；
UINT32 BspSetCellCarrCombSwitch(UINT32 uCellId, UINT32 uCarrIdx, UINT32 uSwitch)
{
    #if 0
    UINT32 uCellIdx = HalIcCellGetPosId(uCellId);
    return HalIcSetCellSwitch(uCellIdx, uCarrIdx, uSwitch);
    #endif
    return BSP_OK;
}

UINT32 BspSetRepeatPeriod(UINT32 periodType)
{
    return BSP_OK;
}

UINT32 BspSetSrsSymbolNum(UINT32 srsNum)
{
	/* 2.0需要，3.0和4.0不需要
    UINT32 chipNo[64] = {0};
    UINT32 chipNum = NELEMENTS(chipNo);
    UINT32 loop;
    
    linkCfgLog(LOG_INFO,"%s {%d} enter\n",__FUNCTION__,srsNum);
    
    if (BSP_OK != BspGetRegChip(REG_SUBFRAME_REPEAT_PERIOD,chipNo,&chipNum))
    {
        dbgInfoEx("%s {%d} return error\n",__FUNCTION__,srsNum);
        return BSP_ERROR;
    }

    for (loop = 0; loop < chipNum; loop++)
    {
        BspRegWr(chipNo[loop],REG_SUBFRAME_SRS_SYMB_DISABLE,0,!srsNum);
    }

    linkCfgLog(LOG_INFO,"%s {%d} ok\n",__FUNCTION__,srsNum);*/
    return BSP_OK;
}


UINT32 BspSetGapSymbolNum(UINT32 gapNum)
{
	/* 2.0需要，3.0和4.0不需要
    UINT32 chipNo[64] = {0};
    UINT32 chipNum = NELEMENTS(chipNo);
    UINT32 loop;
    
    linkCfgLog(LOG_INFO,"%s {%d} enter\n",__FUNCTION__,gapNum);
    
    if (BSP_OK != BspGetRegChip(REG_SUBFRAME_REPEAT_PERIOD,chipNo,&chipNum))
    {
        dbgInfoEx("%s {%d} return error\n",__FUNCTION__,gapNum);
        return BSP_ERROR;
    }

    for (loop = 0; loop < chipNum; loop++)
    {
        BspRegWr(chipNo[loop],REG_SUBFRAME_GAP_SYMB_NUM,0,gapNum);
    }

    linkCfgLog(LOG_INFO,"%s {%d} ok\n",__FUNCTION__,gapNum);*/
    return BSP_OK;
}

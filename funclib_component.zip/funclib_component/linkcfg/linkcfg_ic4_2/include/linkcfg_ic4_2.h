/*****************************************************************************
* 版权所有(C) 2017, ZTE Corp. ZXSDR-RRU Platform BSP
*----------------------------------------------------------------------------
* 模 块 名 : bsp
* 文件名称 : linkcfg.h
* 文件标识 : {[N/A]}
* 内容摘要 : 本文件提供了链路配置接口声明
* 注意事项 : 无
* 作    者 :   10090699
* 创建日期 : 2017-03-08
* 当前版本 : Ver1.0
*----------------------------------------------------------------------------
* 变更记录 :
*
* $记录1
* 变 更 单: $0000000(N/A)
* 责 任 人: NA
* 修改日戳: NA
* 变更说明: 创建文件
*----------------------------------------------------------------------------
*/

#ifndef _FUNCLIB_LINKCFG_IC4_H_
#define _FUNCLIB_LINKCFG_IC4_H_



#ifdef __cplusplus
extern "C" {
#endif

#include "linkcfgcommon.h"

#define SYSMBLE_NUM_PER_SLOT 14

UINT32 BspSetTxSwitchAll(UINT32 isOn);
UINT32 BspSetRxSwitchAll(UINT32 isOn);

typedef UINT32 (*FUNC_GET_STATUS)(UINT32 ulChan);

typedef UINT32 (*FUNC_SET_STATUS)(UINT32 ulChan, INT32 Status);
typedef UINT32 (*FUNC_8T_GET_NCO_OFFSETADDR)(VOID);

VOID   BspGetTxStatusCallBackInit(FUNC_GET_STATUS pGetStatus);
VOID   BspSetTxStatusCallBackInit(FUNC_SET_STATUS pSetStatus);

VOID   BspGetRxStatusCallBackInit(FUNC_GET_STATUS pGetStatus);
VOID   BspSetRxStatusCallBackInit(FUNC_SET_STATUS pSetStatus);

UINT32 BspSetLinkCfgChnlSelFlag(UINT32 ulSelFlag);


typedef UINT32 (*FUNC_SET_CARR_SWITCH)(UINT32 chan,UINT32 radio,UINT32 carr,UINT32 trx,UINT32 isOn);
typedef UINT32 (*FUNC_GET_CARR_SWITCH)(UINT32 chan,UINT32 radio,UINT32 carr,UINT32 trx, UINT32 *pIsOn);
VOID   BspSetCarrSwCallBackInit(FUNC_SET_CARR_SWITCH pSetCarrSw);
VOID   BspGetCarrSwCallBackInit(FUNC_GET_CARR_SWITCH pGetCarrSw);
VOID BspSetTxSwitchCallBackInit(FUNC_SET_STATUS pfSetTxSwitch);

UINT32 BspSetTxSwitch(UINT32 chan, UINT32 isOn);
UINT32 BspSetTxSwitchFdd(UINT32 chan, UINT32 sw);
UINT32 BspSetRxSwitch(UINT32 chan, UINT32 isOn);
UINT32 BspSetLinkCfgDlpreGain(UINT32 bspChn, INT32 gain);
VOID BspSetCarrSwitchVal(UINT uCarriSwitchVal);
UINT32 Bsp8TGetNcoOffsetAddrCallback(FUNC_8T_GET_NCO_OFFSETADDR pFunc);
UINT32 BspSetCarrSwitch(UINT32 chan,UINT32 radio,UINT32 carr,UINT32 trx,UINT32 isOn);
VOID BspCfgCarrPowFeedFunc(UINT32 pow);

#ifdef __cplusplus
}
#endif
#endif 





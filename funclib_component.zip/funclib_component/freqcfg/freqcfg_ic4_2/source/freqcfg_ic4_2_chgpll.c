/*****************************************************************************
* 版权所有(C) 2021, ZTE Corp. ZXSDR-RRU Platform BSP
*----------------------------------------------------------------------------
* 模 块 名 : 配频
* 文件名称 : freqcfg_ic4_2_chgpll.c
* 文件标识 : {[N/A]}
* 内容摘要 : 本文件提供了配频模块变本振相关函数实现
* 注意事项 : 无
*----------------------------------------------------------------------------*/
#include "bsppub.h"
#include "bspcomm.h"
#include "freqcfg_ic4_2.h"
#include "freqcfgcommon.h"
#include "freqcfg_ic4_2_chgpll.h"
#include "exprn.h"
#include "chnmap_a.h"
#include "devdrv_transceiver.h"
/**************************************************************************
 *                        宏定义
 **************************************************************************/
#define TRANSCEIVER_MAX_CHAN_NUM        8   /* 每个Transceiver芯片最大支持通道数 */
#define MAX_TRANSCEIVER_NUM             4   /* 每片IC最大Transceiver数 */

#define NEED_RECALC_LO         1
#define NO_NEED_RECALC_LO      0

#define BANDWIDTH_0M           0 /*0表示带宽无效*/

#define BANDWIDTH_NR_START          (0)
#define BANDWIDTH_TYPE_NUM_NR       (30) /* NR支持的带宽种类,参见 s_carrBWInfo 变量,不够请添加 */
#define BANDWIDTH_TYPE_NUM_LTE_TDD  (30)
#define BANDWIDTH_LTE_TDD_START     BANDWIDTH_TYPE_NUM_NR
#define BANDWIDTH_NB_START          (BANDWIDTH_TYPE_NUM_NR + BANDWIDTH_TYPE_NUM_LTE_TDD)
#define BANDWIDTH_TYPE_NUM_NB       (1)

#define CARR_NUM_CHECK(_carrNum, _maxNum)                               \
if ( (_carrNum) >= (_maxNum) )                                          \
{                                                                       \
    dbgErr("%s carr num '%d overload!\n", __FUNCTION__, (_carrNum));    \
    return BSP_ERROR;                                                   \
}

#define RESOURRCES_FREE                                                 \
for (chanIdx = 0; chanIdx < chanNum; ++chanIdx)                         \
{                                                                       \
    free(bindChanRfPllCfgPara[chanIdx].carrInfo);                       \
}                                                                       \
free(bindChanRfPllCfgPara);

/* 判断是否在dpd范围内 */
#define IS_LO_IN_DPD_RANGE(_loFreq, _dpdLow, _dpdHigh) ( ((_loFreq) >= (_dpdLow)) && ((_loFreq) <= (_dpdHigh)) )
/**************************************************************************
 *                        全局变量
 **************************************************************************/
static FUNC_CalcCenterFreqDynamicFromBoard pFuncCalcCenterFreqDynamicFromBoard = NULL;
static FUNC_FreqCfgDynamicAnalyseFromBoard pFuncFreqCfgDynamicAnalyseFromBoard = NULL;
static FUNC_FreqCfgLoFreqFromBoard         pFUNCFreqCfgLoFreqFromBoard         = NULL;
static T_RfCfgParaAllChan *s_saveCfgPara            = NULL; /* 保存变本振传入的载波信息*/
static T_PllChangeInfoAllChan s_savePreAnysPara[2]  = {0}; /* 保存变本振计算结果 */
static UINT32 s_mtsCaliFlag[MAX_TRANSCEIVER_NUM]    = {0}; /* MTS是否已校准标志 */

static T_ChanPllInfo s_chanPllInfo[BSP_MAX_TX_CHAN] = {0};/* 单板下传入通道与本振的对应关系 */
static UINT32 s_pllFlagFromBoard                    = 0;
static UINT32 s_firstChgTxPll[BSP_MAX_TX_CHAN]      = {0};
static UINT32 s_firstChgRxPll[BSP_MAX_RX_CHAN]      = {0};
static UINT32 s_loStep                              = 60; /*Ic4.2本振频点固定为60K的整倍数*/
static UINT32 s_pllFlagByMainMgr            = 0;   /* 主进程变本振标志 */
/* 保存动态计算本振中间参数,方便计算 */
static T_CarrFreqBandIdxInfo *s_carrFreqBandInfo = NULL;

UINT32 g_LoBlackoutAvoidFlag[BSP_MAX_CHAN_NUM] = {0};

static T_BandWidthInfo s_carrBWInfo[BANDWIDTH_TYPE_NUM_NR+BANDWIDTH_TYPE_NUM_LTE_TDD+BANDWIDTH_TYPE_NUM_NB] = {
    /* NR, 由于NR_BANDWIDTH_TYPE_NUM限制,最多添加到29,如果29不够,请再添加及修改NR_BANDWIDTH_TYPE_NUM */
    /* index                           carrBw        rbNum   signalBw        proCalcBw                      delta1Bw*/
    [BANDWIDTH_NR_START + 0] =
    {BANDWIDTH_NR_START + 0,        BANDWIDTH_100M,    273,   98310,   98310 + FREQ_DELTA_NR_720KHz,   BANDWIDTH_100M - FREQ_DELTA_1_120KHz},
    {BANDWIDTH_NR_START + 1,        BANDWIDTH_90M,     245,   88230,   88230 + FREQ_DELTA_NR_720KHz,   BANDWIDTH_90M  - FREQ_DELTA_1_120KHz},
    {BANDWIDTH_NR_START + 2,        BANDWIDTH_80M,     217,   78150,   78150 + FREQ_DELTA_NR_720KHz,   BANDWIDTH_80M  - FREQ_DELTA_1_120KHz},
    {BANDWIDTH_NR_START + 3,        BANDWIDTH_70M,     189,   68070,   68070 + FREQ_DELTA_NR_720KHz,   BANDWIDTH_70M  - FREQ_DELTA_1_120KHz},
    {BANDWIDTH_NR_START + 4,        BANDWIDTH_60M,     162,   58350,   58350 + FREQ_DELTA_NR_720KHz,   BANDWIDTH_60M  - FREQ_DELTA_1_120KHz},
    {BANDWIDTH_NR_START + 5,        BANDWIDTH_50M,     133,   47910,   47910 + FREQ_DELTA_NR_720KHz,   BANDWIDTH_50M  - FREQ_DELTA_1_120KHz},
    {BANDWIDTH_NR_START + 6,        BANDWIDTH_40M,     106,   38190,   38190 + FREQ_DELTA_NR_720KHz,   BANDWIDTH_40M  - FREQ_DELTA_1_120KHz},
    {BANDWIDTH_NR_START + 7,        BANDWIDTH_30M,     78,    28110,   28110 + FREQ_DELTA_NR_720KHz,   BANDWIDTH_30M  - FREQ_DELTA_1_120KHz},
    {BANDWIDTH_NR_START + 8,        BANDWIDTH_25M,     65,    23430,   23430 + FREQ_DELTA_NR_720KHz,   BANDWIDTH_25M  - FREQ_DELTA_1_120KHz},
    {BANDWIDTH_NR_START + 9,        BANDWIDTH_20M,     51,    18390,   18390 + FREQ_DELTA_NR_720KHz,   BANDWIDTH_20M  - FREQ_DELTA_1_120KHz},
    {BANDWIDTH_NR_START + 10,       BANDWIDTH_15M,     38,    13710,   13710 + FREQ_DELTA_NR_720KHz,   BANDWIDTH_15M  - FREQ_DELTA_1_120KHz},
    {BANDWIDTH_NR_START + 11,       BANDWIDTH_10M,     24,     8670,    8670 + FREQ_DELTA_NR_720KHz,   BANDWIDTH_10M  - FREQ_DELTA_1_120KHz},
    {BANDWIDTH_NR_START + 12,       BANDWIDTH_5M,      11,     3990,    3990 + FREQ_DELTA_NR_720KHz,   BANDWIDTH_5M},

    /* LTE */
    [BANDWIDTH_LTE_TDD_START + 0] =
    {BANDWIDTH_LTE_TDD_START + 0,   BANDWIDTH_20M,     100,   18000,   18000 + FREQ_DELTA_LTE_360KHz,  BANDWIDTH_20M - FREQ_DELTA_1_120KHz},
    {BANDWIDTH_LTE_TDD_START + 1,   BANDWIDTH_15M,     75,    13500,   13500 + FREQ_DELTA_LTE_360KHz,  BANDWIDTH_15M - FREQ_DELTA_1_120KHz},
    {BANDWIDTH_LTE_TDD_START + 2,   BANDWIDTH_10M,     50,     9000,    9000 + FREQ_DELTA_LTE_360KHz,  BANDWIDTH_10M - FREQ_DELTA_1_120KHz},
    {BANDWIDTH_LTE_TDD_START + 3,   BANDWIDTH_5M,      25,     4500,    4500 + FREQ_DELTA_LTE_360KHz,  BANDWIDTH_5M},

    /* NB */
    [BANDWIDTH_NB_START + 0] =
    {BANDWIDTH_NB_START + 0,   BANDWIDTH_0P2M,     0,   200,   200,  200},
};

/**************************************************************************
 *                        函数声明
 **************************************************************************/
static UINT32 BspGetChgPllInfo(UINT32 trx, T_RfCfgParaAllChan *allChanCfgInfo , T_PllChangeInfoAllChan *allChanChangeInfo);
static T_RfCfgPara* GetMergedRfCfgPara(T_RfCfgParaAllChan *allChanCfgInfo, UINT32 trx);
static UINT32 MergeRfCfgPara(T_RfCfgPara *dynamicRfCfg, T_RfPllCfgPara *rfCfgPara);
static UINT32 IsCarrInfoSame(T_CarrInfo *leftCarrInfo, T_CarrInfo *rightCarrInfo);
static UINT32 RfPllChange(UINT32 trx, UINT32 chan, UINT32 LoFreqKHz);
static UINT32 RfBandNcoBaseChange(UINT32 trx, UINT32 chan, INT32 BandNcoBase);
static UINT32 BspFreqCfgDynamicAnalyse(UINT32 trx, UINT32 chan, T_CarrInfo *pCarrInfo,UINT32 carrNum, UINT32 *freqOut);
static UINT32 CarrFreqSort(T_CarrInfo *carrInfo, UINT32 carrNum);
static int CarrFreqSortCompareUp(const void *a, const void *b);
static UINT32 IsLoFreqInGuardBand(UINT32 trx, UINT32 chan, UINT32 carrNum, UINT32 loFreq);
static UINT32 IsLoCarrFreqOffsetOk(UINT32 trx, UINT32 chan, UINT32 carrNum, UINT32 loFreq, INT32 mtsNco);
//static UINT32 UpdateCenterFreqDynamic(UINT32 trx, UINT32 chan, UINT32 carrNum);
static UINT32 GetDpdRangeLow(UINT32 uDir, UINT32 ulBspChan);
static UINT32 GetDpdRangeHigh(UINT32 uDir, UINT32 ulBspChan);
//static UINT32 GetCarrEdgeFreqs(UINT32 carrNum, UINT32 dpdFreqRangeLow, UINT32 dpdFreqRangeHigh, UINT32 *edges);
static UINT32 BspFreqCfgDynamicAnalyse_TranBandNco(UINT32 trx, UINT32 chan, UINT32 carrNum,
        T_CarrInfo *allChanCfgInfo, UINT32 *rfpll);
static void RfPllCfgParaAddOneCarr(T_RfCfgPara *dynamicRfCfg, T_CarrInfo *oneCarrInfo);
static void PrnSortedCarrInfo(UINT32 num);
static void GetBwStartIdxAndNum(UINT32 radioMode, UINT32 *startIdx, UINT32 *num);
static UINT32 GetBandNcoFlag(UINT32 uDir, UINT32 ulBspChan);
static T_RfPllCfgInit *GetRfPllCfg(UINT32 uDir, UINT32 ulBspChan);
static UINT32 BspChangeAllChanPllByTrsvId(UINT32 trx, UINT32 trsvNo, UINT32 LoFreqKHz, UINT32 mtsNco);
static UINT32 GetLoChangeMargin(UINT32 dir, UINT32 bspChan);
/**************************************************************************
 *                        函数定义
 **************************************************************************/

static UINT32 saveBspLogChangePllCfg(UINT32 trx, T_RfCfgParaAllChan *allChanCfgInfo )
{
    UINT32 chanLoop = 0;
    UINT32 carrLoop = 0;

    INPUT_POINTER_CHECK(allChanCfgInfo);

    BspLog(LOG_LEVEL_0,"freq: %s: chanNum{%d}. \n",__FUNCTION__,allChanCfgInfo->chanNum);
    for(chanLoop = 0; chanLoop < allChanCfgInfo->chanNum; chanLoop ++)
    {
        BspLog(LOG_LEVEL_0,"freq: %s: chanNo{%d}, carrNum{%d}. \n",__FUNCTION__, allChanCfgInfo->allInfo[chanLoop].chanNo, allChanCfgInfo->allInfo[chanLoop].carrNum);
        for(carrLoop = 0; carrLoop < allChanCfgInfo->allInfo[chanLoop].carrNum; carrLoop ++)
        {
            if(trx == TX)
            {
                BspLog(LOG_LEVEL_0,"freq: %s: ---TX---  , carrNo[%d], radioMode[%d], freq[%d], bandWidth[%d], cfgFlag[%d], freqOffset[%d], difIfType[%d]. \n",
                        __FUNCTION__, allChanCfgInfo->allInfo[chanLoop].carrInfo[carrLoop].carrNo, allChanCfgInfo->allInfo[chanLoop].carrInfo[carrLoop].radioMode, allChanCfgInfo->allInfo[chanLoop].carrInfo[carrLoop].freq,
                        allChanCfgInfo->allInfo[chanLoop].carrInfo[carrLoop].bandWidth,allChanCfgInfo->allInfo[chanLoop].carrInfo[carrLoop].cfgFlag, allChanCfgInfo->allInfo[chanLoop].carrInfo[carrLoop].freqOffset,
                        allChanCfgInfo->allInfo[chanLoop].carrInfo[carrLoop].difIfType);
            }
            else
            {
                BspLog(LOG_LEVEL_0,"freq: %s: ---RX--- carrNo[%d], radioMode[%d], freq[%d], bandWidth[%d], cfgFlag[%d], freqOffset[%d], difIfType[%d]. \n",
                        __FUNCTION__, allChanCfgInfo->allInfo[chanLoop].carrInfo[carrLoop].carrNo, allChanCfgInfo->allInfo[chanLoop].carrInfo[carrLoop].radioMode, allChanCfgInfo->allInfo[chanLoop].carrInfo[carrLoop].freq,
                        allChanCfgInfo->allInfo[chanLoop].carrInfo[carrLoop].bandWidth, allChanCfgInfo->allInfo[chanLoop].carrInfo[carrLoop].cfgFlag, allChanCfgInfo->allInfo[chanLoop].carrInfo[carrLoop].freqOffset,
                        allChanCfgInfo->allInfo[chanLoop].carrInfo[carrLoop].difIfType);
            }
        }
    }

    return BSP_OK;
}

UINT32 BspSetLoBlackoutAvoidFlag(UINT32 chan, UINT32 flag)
{
    g_LoBlackoutAvoidFlag[chan] = flag;
    return BSP_OK;
}
UINT32 BspGetLoBlackoutAvoidFlag(UINT32 chan)
{
    return g_LoBlackoutAvoidFlag[chan];
}

/**********************************************************************
* 函数名称: BspChangePllCfgPreAnalyse(*)
* 功能描述: 动态本振计算预分析, 结构体有注释对应变量含义
* 输入参数: trx, allChanCfgInfo
* 输出参数: allChanChangeInfo
* 返 回 值: BSP_OK / BSP_ERROR -- 载波制式不支持/非标准带宽过多
* 其它说明:
* ---------------------------------------------------------------------------
************************************************************************/
UINT32 BspChangePllCfgPreAnalyse(UINT32 trx, T_RfCfgParaAllChan *allChanCfgInfo , T_PllChangeInfoAllChan *allChanChangeInfo)
{
    UINT32 retVal = BSP_OK;
    size_t bufLen = 0;

    INPUT_POINTER_CHECK(allChanCfgInfo);
    INPUT_POINTER_CHECK(allChanChangeInfo);

    if (allChanCfgInfo->chanNum > BSP_MAX_TX_CHAN)
    {
        dbgErr("%s chanNum'%d overload!\n", __FUNCTION__, allChanCfgInfo->chanNum);
        BspLog(LOG_LEVEL_0, "%s chanNum'%d overload!\n", __FUNCTION__, allChanCfgInfo->chanNum);
        return BSP_ERROR;
    }

    saveBspLogChangePllCfg(trx, allChanCfgInfo);

    if (s_saveCfgPara == NULL)
    {
        bufLen = sizeof(T_RfCfgParaAllChan) * 2;
        s_saveCfgPara = (T_RfCfgParaAllChan *)malloc(bufLen);
        INPUT_POINTER_CHECK(s_saveCfgPara);
        memset_s(s_saveCfgPara, bufLen, 0, bufLen);
    }
    memcpy_s(&s_saveCfgPara[!!trx], sizeof(T_RfCfgParaAllChan), allChanCfgInfo, sizeof(T_RfCfgParaAllChan));
    memset(s_mtsCaliFlag, 0, sizeof(s_mtsCaliFlag));

    retVal = BspGetChgPllInfo(trx, allChanCfgInfo, allChanChangeInfo);

    BspLog(LOG_LEVEL_0, "%s trx'%d chanNum'%d retVal'%#x\n", __FUNCTION__, trx, allChanCfgInfo->chanNum, retVal);

    memcpy_s(&s_savePreAnysPara[!!trx], sizeof(s_savePreAnysPara[0]), allChanChangeInfo, sizeof(s_savePreAnysPara[0]));
    return retVal;
}

/**********************************************************************
* 函数名称: BspChangeAllChanPllByTrsvId(*)
* 功能描述: 将计算的本振频点按默认本振,赋值给同一片transceiver上的所有通道
* 输入参数:
*   trx：收发方向
*   trsvNo：需要变本振的Transceiver芯片ID
*   LoFreqKHz：本振计算结果
* 输出参数:
*   无
* 返 回 值: BSP_OK / BSP_ERROR
************************************************************************/
static UINT32 BspChangeAllChanPllByTrsvId(UINT32 trx, UINT32 trsvNo, UINT32 LoFreqKHz, UINT32 mtsNco)
{
    UINT32 chanNum = 0;
    UINT32 chanIdx = 0;
    UINT32 trsvId  = 0;
    UINT32 retVal  = BSP_OK;
    UINT32 cfgSolutions                      = 0;
    T_RfPllCfgInit *ptRfPllCfgInit           = NULL;
    ptRfPllCfgInit = pGetRfPllCfgHandle(trx);

    chanNum = (trx == TX) ? BspGetTxBspChanNum() : BspGetRxBspChanNum();
    /* 循环所有Bsp通道 */
    for(chanIdx = 0; chanIdx < chanNum; ++chanIdx)
    {
        cfgSolutions = ptRfPllCfgInit[chanIdx].cfgSolution;
        trsvId = getChanMergePllNo(chanIdx, trx);
        if((trsvId == trsvNo) && (cfgSolutions == FREQ_CFG_SOLUTION_DYNAMIC))
        {
            retVal |= RfBandNcoBaseChange(trx, chanIdx,mtsNco);
            retVal |= RfPllChange(trx, chanIdx, LoFreqKHz);
            BspLog(LOG_LEVEL_0,"<%s><%d> RfPllChange 'trx=%d 'chanNo=%d 'Pllfreq=%d 'mtsNco = %d\n", __FUNCTION__, __LINE__, trx, chanIdx, LoFreqKHz, mtsNco);
        }
    }

    return retVal;
}

/**********************************************************************
* 函数名称: BspGetChgPllInfo(*)
* 功能描述: 关联通道号及MTS通道映射关系，传递需要计算的小区配置信息
* 输入参数:
*   trx：收发方向
*   allChanCfgInfo：小区配置信息
*   allFreqOut：本振计算结果，与通道绑定
* 输出参数:
*   allCalcRet--是否变本振标志，与通道绑定
* 返 回 值: 是否需要变本振 / BSP_ERROR -- 载波制式不支持/非标准带宽过多
************************************************************************/
static UINT32 BspGetChgPllInfo(UINT32 trx, T_RfCfgParaAllChan *allChanCfgInfo , T_PllChangeInfoAllChan *allChanChangeInfo)
{
    UINT32 chanIdx                           = 0;
    UINT32 chanNo                            = 0;
    UINT32 bindChanGrpFirstChan              = 0;
    UINT32 chanNum                           = 0;
    T_RfCfgPara *bindChanRfPllCfgPara        = NULL;
    UINT32 reCalcFreq[MAX_TRANSCEIVER_NUM]   = {0};
    UINT32 reCalcFinish[MAX_TRANSCEIVER_NUM] = {0};
    UINT32 reCalcRet[MAX_TRANSCEIVER_NUM]    = {0};
    INT32 reCalcBandNco[MAX_TRANSCEIVER_NUM]   = {0};
    UINT32 calcRet                           = 0;
    UINT32 cfgSolutions                      = 0;
    T_RfPllCfgInit *ptRfPllCfgInit           = NULL;

    INPUT_POINTER_CHECK(allChanCfgInfo);
    INPUT_POINTER_CHECK(allChanChangeInfo);

    ptRfPllCfgInit = pGetRfPllCfgHandle(trx);
    /* 获取通道绑定相关信息整合 */
    bindChanRfPllCfgPara = GetMergedRfCfgPara(allChanCfgInfo, trx);
    if (bindChanRfPllCfgPara == NULL)
    {
        dbgErr("%s <%d> malloc failed!\n", __FUNCTION__, __LINE__);
        BspLog(LOG_LEVEL_0, "%s <%d> malloc failed!\n", __FUNCTION__, __LINE__);
        return BSP_ERROR;
    }

    chanNum = allChanCfgInfo->chanNum;
    allChanChangeInfo->chanNum = chanNum;
    /* 整合后的通道进行动态本振计算,并进行赋值 */
    for (chanIdx = 0; chanIdx < chanNum; ++ chanIdx)
    {
        chanNo = allChanCfgInfo->allInfo[chanIdx].chanNo;
        cfgSolutions = ptRfPllCfgInit[chanNo].cfgSolution;

        allChanChangeInfo->allChangeInfo[chanIdx].chanNo = chanNo;
        if((cfgSolutions != FREQ_CFG_SOLUTION_DYNAMIC) || (0 == allChanCfgInfo->allInfo[chanIdx].carrNum))
        {
            dbgInfo("%s: chan[%d] carrNum is 0 OR cfgSolutions[%d] != 4. \n", __FUNCTION__, chanNo, cfgSolutions);
            continue;
        }

        bindChanGrpFirstChan = getChanMergePllNo(chanNo, trx);

        if (bindChanGrpFirstChan >= MAX_TRANSCEIVER_NUM)
        {
            dbgErr("%s: input param chan'%d is out of range'%d !\n", __FUNCTION__, bindChanGrpFirstChan, MAX_TRANSCEIVER_NUM);
            RESOURRCES_FREE
            return BSP_ERROR;
        }

        if(reCalcFinish[bindChanGrpFirstChan] == 0)
        {
            /*单板下挂接方式未使用，暂时按照bandNcoFlag = 2处理*/
            if(2 == GetBandNcoFlag(trx, chanNo))
            {
                calcRet = BspFreqCfgDynamicAnalyse_TranBandNco(trx, chanNo, bindChanRfPllCfgPara[bindChanGrpFirstChan].carrNum,
                        bindChanRfPllCfgPara[bindChanGrpFirstChan].carrInfo, &reCalcFreq[bindChanGrpFirstChan]);
            }
            else
            {
                calcRet = BspFreqCfgDynamicAnalyse(trx, chanNo, bindChanRfPllCfgPara[bindChanGrpFirstChan].carrInfo,
                        bindChanRfPllCfgPara[bindChanGrpFirstChan].carrNum, &reCalcFreq[bindChanGrpFirstChan]);
            }

            if(calcRet == BSP_ERROR)
            {
                dbgErr("%s >> calc trx'%d transceiver'%d error!!!\n", __FUNCTION__, trx, bindChanGrpFirstChan);
                /*资源释放 */
                RESOURRCES_FREE
                return BSP_ERROR;
            }
            reCalcBandNco[bindChanGrpFirstChan] = ptRfPllCfgInit[chanNo].bandNcoBase;
            reCalcFinish[bindChanGrpFirstChan] = 1;
            reCalcRet[bindChanGrpFirstChan]    = calcRet;
        }
        allChanChangeInfo->allChangeInfo[chanIdx].pllFreq = reCalcFreq[bindChanGrpFirstChan];
        allChanChangeInfo->allChangeInfo[chanIdx].changePllFlag = reCalcRet[bindChanGrpFirstChan];

        RfPllChange(trx, chanNo, reCalcFreq[bindChanGrpFirstChan]);
        /*RfBandNcoBaseChange(trx, chanNo,reCalcBandNco[bindChanGrpFirstChan]);*/
        BspChangeAllChanPllByTrsvId(trx, bindChanGrpFirstChan, reCalcFreq[bindChanGrpFirstChan],reCalcBandNco[bindChanGrpFirstChan]);
    }

    /*资源释放 */
    RESOURRCES_FREE

    return BSP_OK;;
}

/**********************************************************************
* 函数名称: GetMergedRfCfgPara(*)
* 功能描述: 将同一个本振的载波信息绑定到一起
* 输入参数: allChanCfgInfo 全量载波信息
* 输出参数: 无
* 返 回 值 : mergeBindChanGrpRfCfg，绑定侯同一个本振的载波信息
* 注意事项: 该函数会返回malloc的T_RfCfgPara， T_RfCfgPara->carrInfo也是malloc的;
* 使用者需要在函数外判断非空，使用完成后需要在外释放
************************************************************************/
static T_RfCfgPara* GetMergedRfCfgPara(T_RfCfgParaAllChan *allChanCfgInfo, UINT32 trx)
{
    T_RfCfgPara* mergeBindChanGrpRfCfg  = NULL;
    UINT32 chanIdx                      = 0;
    UINT32 chanNo                       = 0;
    UINT32 chanNum                      = 0;
    UINT32 bindChanGrpFirstChan         = 0;
    UINT32 isMergeOk                    = 1;
    UINT32 cfgSolutions                 = 0;
    T_RfPllCfgInit *ptRfPllCfgInit = NULL;

    INPUT_POINTER_CHECK_RETURN_NULL(allChanCfgInfo);

    ptRfPllCfgInit = pGetRfPllCfgHandle(trx);

    mergeBindChanGrpRfCfg = (T_RfCfgPara*)malloc(sizeof(T_RfCfgPara) * BSP_MAX_TX_CHAN);
    if (mergeBindChanGrpRfCfg == NULL)
    {
        dbgErr("%s <%d> malloc failed!\n", __FUNCTION__, __LINE__);
        return NULL;
    }
    memset(mergeBindChanGrpRfCfg, 0, sizeof(T_RfCfgPara) * BSP_MAX_TX_CHAN);

    chanNum = allChanCfgInfo->chanNum;
    for (chanIdx = 0; chanIdx < chanNum; ++ chanIdx)
    {
        chanNo = allChanCfgInfo->allInfo[chanIdx].chanNo;
        cfgSolutions = ptRfPllCfgInit[chanNo].cfgSolution;

        if(cfgSolutions != FREQ_CFG_SOLUTION_DYNAMIC)
        {
            continue;
        }

        bindChanGrpFirstChan = getChanMergePllNo(chanNo, trx);
        if (MergeRfCfgPara(&mergeBindChanGrpRfCfg[bindChanGrpFirstChan], &allChanCfgInfo->allInfo[chanIdx]) != BSP_OK)
        {
            isMergeOk = 0;
            break;
        }
    }

    if (isMergeOk == 1)
    {
        return mergeBindChanGrpRfCfg;
    }

    for (chanIdx = 0; chanIdx < chanNum; ++chanIdx)
    {
        free(mergeBindChanGrpRfCfg[chanIdx].carrInfo);
    }
    free(mergeBindChanGrpRfCfg);

    return NULL;
}
UINT32 BspSetChanPllInfo(T_ChanPllInfo *pInfo, UINT32 uiChanPllInfoNum)
{
    UINT32 chanIdx = 0;

    for(chanIdx = 0;chanIdx <uiChanPllInfoNum;chanIdx ++)
    {
        dbgInfoEx("%s, chanNo%d ,PllNo%d ,pllType%d\n", __FUNCTION__,pInfo[chanIdx].chanNo,pInfo[chanIdx].PllNo,pInfo[chanIdx].pllType);
        s_chanPllInfo[chanIdx].chanNo = pInfo[chanIdx].chanNo;
        s_chanPllInfo[chanIdx].PllNo = pInfo[chanIdx].PllNo;
        s_chanPllInfo[chanIdx].pllType = pInfo[chanIdx].pllType;
    }
    s_pllFlagFromBoard  = 1;

    return BSP_OK;
}

UINT32 getChanMergePllNo(UINT32 chanNo, UINT32 trx)
{
    UINT32 pllId   = 0;
    UINT32 bspChan = 0;

    if(s_pllFlagFromBoard == 0)
    {
        if (BspGetBspChnByRfChn(chanNo, trx, &bspChan) != BSP_OK)
        {
            dbgErr("%s >> get BspChan info failed!\n", __FUNCTION__);
            return BSP_ERROR;
        }

        if (BspGetTransceiverInfoByBspChnl(bspChan, NULL, &pllId, NULL) != BSP_OK)
        {
            dbgErr("%s >> get transceiver info failed!\n", __FUNCTION__);
            return BSP_ERROR;
        }
    }
    else
    {
        pllId = s_chanPllInfo[chanNo].PllNo; /*这个地方下一单后面优化要封装一个函数,不能将通道号和序号混用*/
    }

    BspLog(LOG_LEVEL_0,"%s >> get chanNo %d to transceiver ID %d\n", __FUNCTION__, chanNo, pllId);

    return pllId;
}

static UINT32 MergeRfCfgPara(T_RfCfgPara *dynamicRfCfg, T_RfPllCfgPara *rfCfgPara)
{
    UINT32 curCarrNum        = 0;
    UINT32 addCarrNum        = 0;
    UINT32 carrIdx           = 0;
    T_CarrInfo *carrInfoTemp = NULL;

    INPUT_POINTER_CHECK(dynamicRfCfg);
    INPUT_POINTER_CHECK(rfCfgPara);

    curCarrNum = dynamicRfCfg->carrNum;
    addCarrNum = rfCfgPara->carrNum;

    while (curCarrNum + addCarrNum >= dynamicRfCfg->carrInfoCapacity)
    {
        dynamicRfCfg->carrInfoCapacity += BSP_MAX_CARR_NUM;
        if ( (carrInfoTemp = realloc(dynamicRfCfg->carrInfo, sizeof(T_CarrInfo) * (dynamicRfCfg->carrInfoCapacity))) == NULL)
        {
            BspLog(LOG_LEVEL_0, "%s <%d> realloc failed!\n", __FUNCTION__, __LINE__);
            return BSP_ERROR;
        }
        dynamicRfCfg->carrInfo = carrInfoTemp;
    }

    for (carrIdx = 0; carrIdx < addCarrNum; ++carrIdx)
    {
        carrInfoTemp = &rfCfgPara->carrInfo[carrIdx];
        RfPllCfgParaAddOneCarr(dynamicRfCfg, carrInfoTemp);
    }

    return BSP_OK;
}

static void RfPllCfgParaAddOneCarr(T_RfCfgPara *dynamicRfCfg, T_CarrInfo *oneCarrInfo)
{
    UINT32 curCarrNum = 0;
    UINT32 carrIdx    = 0;

    INPUT_POINTER_CHECK_RETURN(dynamicRfCfg);
    INPUT_POINTER_CHECK_RETURN(oneCarrInfo);

    curCarrNum = dynamicRfCfg->carrNum;
    for (carrIdx = 0; carrIdx < curCarrNum; ++carrIdx)
    {
        if (IsCarrInfoSame(&dynamicRfCfg->carrInfo[carrIdx], oneCarrInfo))
        {
            dbgInfoEx("%s carr is same! carrNo'%d radio'%d freq'%d bw'%d\n",
                __FUNCTION__, oneCarrInfo->carrNo, oneCarrInfo->radioMode, oneCarrInfo->freq, oneCarrInfo->bandWidth);
            return ;
        }
    }

    dynamicRfCfg->carrInfo[curCarrNum] = *oneCarrInfo;
    dynamicRfCfg->carrNum += 1;

    return ;
}

static UINT32 IsCarrInfoSame(T_CarrInfo *leftCarrInfo, T_CarrInfo *rightCarrInfo)
{
    UINT32 isSame = 0;

    INPUT_POINTER_CHECK(leftCarrInfo);
    INPUT_POINTER_CHECK(rightCarrInfo);

    isSame = ( (leftCarrInfo->radioMode == rightCarrInfo->radioMode)
            && (leftCarrInfo->freq == rightCarrInfo->freq)
            && (leftCarrInfo->bandWidth == rightCarrInfo->bandWidth) );

    return isSame;
}

/**********************************************************************
* 函数名称: RfPllChange(*)
* 功能描述: 设置中心频点，按默认本振方式传入初始化函数
* 输入参数: trx:上下行，chan 射频通道号， LoFreqKHz：本振频点
* 输出参数: 无
* 返 回 值 : BSP_OK/BSP_ERROR
* 注意事项: 无
************************************************************************/
static UINT32 RfPllChange(UINT32 trx, UINT32 chan, UINT32 LoFreqKHz)
{
    UINT32 bspChan                 = 0;
    UINT32 retVal                  = 0;
    T_RfPllCfgInit *ptRfPllCfgInit = NULL;
    UINT32 bspChanNum = (RX == trx) ? BspGetRxChannel():BspGetTxChannel();
    ptRfPllCfgInit = pGetRfPllCfgHandle(trx);
    INPUT_POINTER_CHECK(ptRfPllCfgInit);

    retVal |= BspGetBspChnByRfChn(chan, trx, &bspChan);
    
    if (BSP_OK != retVal)
    {
        dbgErr("%s>>TxChnl'%d BspGetBspChnByRfChn Get Error!\n",
               __FUNCTION__, chan);
        return BSP_ERROR;
    }
    if(bspChan >= bspChanNum)
    {
        dbgErr("%s: input BspChan'%d is out of range.\n", __FUNCTION__, bspChan);
        return BSP_ERROR;
    }
    ptRfPllCfgInit[bspChan].defLoFreqKHz = (UINT32)((INT32)LoFreqKHz + ptRfPllCfgInit[bspChan].bandNcoBase);

    if(pFUNCFreqCfgLoFreqFromBoard != NULL)
    {
        pFUNCFreqCfgLoFreqFromBoard(trx, bspChan, (UINT32)((INT32)LoFreqKHz + ptRfPllCfgInit[bspChan].bandNcoBase));
    }
    else
    {
        BspRecordLoFreq(trx, bspChan, (UINT32)((INT32)LoFreqKHz + ptRfPllCfgInit[bspChan].bandNcoBase));
    }

    BspLog(LOG_LEVEL_0,"%s >> RfPllChange dir%d chan%d change Lo%d, lo with mtsnco = %d\n", __FUNCTION__, trx, bspChan, LoFreqKHz,
            ptRfPllCfgInit[bspChan].defLoFreqKHz);

    return BSP_OK;
}

/* Started by AICoder, pid:c0cdbpbea0c9b1c14c780a47008b391d43f0d207 */
/* 提供给app使用，调用此函数便不能再调用本振分析函数给从进程同步主进程的变本振结果 */
UINT32 BspSetChangeLoFreq(UINT32 trx, UINT32 chan, UINT32 loFreqKHz)
{
    UINT32 retVal = BSP_OK;

    retVal = RfPllChange(trx, chan, loFreqKHz);
    BspLog(LOG_LEVEL_0,"%s >> RfPllChange dir%d chan%d change Lo%d. \n", __FUNCTION__, trx, chan, loFreqKHz);

    return retVal;
}
/* Ended by AICoder, pid:c0cdbpbea0c9b1c14c780a47008b391d43f0d207 */

/**********************************************************************
* 函数名称: RfBandNcoBaseChange(*)
* 功能描述: 设置中心频点，按默认本振方式传入初始化函数
* 输入参数: trx:上下行，chan 射频通道号， LoFreqKHz：本振频点
* 输出参数: 无
* 返 回 值 : BSP_OK/BSP_ERROR
* 注意事项: 无
************************************************************************/
static UINT32 RfBandNcoBaseChange(UINT32 trx, UINT32 chan, INT32 BandNcoBase)
{
    UINT32 bspChan                 = 0;
    UINT32 retVal                  = 0;
    T_RfPllCfgInit *ptRfPllCfgInit = NULL;

    ptRfPllCfgInit = pGetRfPllCfgHandle(trx);
    INPUT_POINTER_CHECK(ptRfPllCfgInit);

    retVal |= BspGetBspChnByRfChn(chan, trx, &bspChan);
    if (BSP_OK != retVal)
    {
        dbgErr("%s>>TxChnl'%d BspGetBspChnByRfChn Get Error!\n",
               __FUNCTION__, chan);
        return BSP_ERROR;
    }

    ptRfPllCfgInit[bspChan].bandNcoBase = BandNcoBase;
    BspLog(LOG_LEVEL_0,"%s >> RfBandNcoBaseChange dir%d chan%d change BandNcoBase%d\n", __FUNCTION__, trx, bspChan, BandNcoBase);

    return BSP_OK;
}

static void UpdateFreqOffset(UINT32 dir)
{
    if(dir == RX)
    {
        s_carrBWInfo[BANDWIDTH_NB_START].delta1Bw = 2400;
        s_carrBWInfo[BANDWIDTH_NB_START].proCalcBw = 2400;
    }
    else
    {
        s_carrBWInfo[BANDWIDTH_NB_START].delta1Bw = 4800;
        s_carrBWInfo[BANDWIDTH_NB_START].proCalcBw = 4800;
    }
}

/**********************************************************************
* 函数名称: BspFreqCfgDynamicAnalyse(*)
* 功能描述: 计算动态本振
* 输入参数: trx:上下行，chan 射频通道号， allChanCfgInfo：全量载波信息，
*         carrNum:载波数，freqOut:计算的本振频点
* 输出参数: 无
* 返 回 值 : BSP_ERROR/是否需要重新计算本振
* 注意事项: 无
************************************************************************/
static UINT32 BspFreqCfgDynamicAnalyse(UINT32 trx, UINT32 chan, T_CarrInfo *pCarrInfo,
        UINT32 carrNum, UINT32 *freqOut)
{
    UINT32 recalFreq = 0;
    UINT32 lastFreq  = 0;

    INPUT_POINTER_CHECK(pCarrInfo);
    INPUT_POINTER_CHECK(freqOut);

    if(pFuncFreqCfgDynamicAnalyseFromBoard != NULL)
    {
        return pFuncFreqCfgDynamicAnalyseFromBoard(trx, chan, carrNum, pCarrInfo, freqOut);
    }

    /* 针对NB载波，上下行分别更新有效带宽及保护带宽 */
    UpdateFreqOffset(trx);

    /* 载波排序 */
    if (CarrFreqSort(pCarrInfo, carrNum) != BSP_OK)
    {
        /* 如果出错,可能是制式出错,或者未支持的带宽超限了.影响下面计算,直接返回失败. */
        return BSP_ERROR;
    }

    if (NEED_RECALC_LO != IsCurrentLoFreqOk(trx, chan, carrNum, &lastFreq))
    {
        BspLog(LOG_LEVEL_0,"<%s> No Need ReCalc Lo\n", __FUNCTION__);
        BspLog(LOG_LEVEL_0,"%s(%d,%d,%d) no recalc\n",__FUNCTION__,trx,chan,lastFreq);
        *freqOut = lastFreq;
        return NO_NEED_RECALC_LO;
    }
    else
    {
        recalFreq = UpdateCenterFreqDynamic(trx, chan, carrNum);
        BspLog(LOG_LEVEL_0,"<%s> re calc lo:%d\n", __FUNCTION__, recalFreq);
        BspLog(LOG_LEVEL_0,"%s(TRX[%d], chan[%d], recalFreq[%d], lasteFreq[%d]) recalc!\n",__FUNCTION__,trx,chan,recalFreq,lastFreq);
        *freqOut = recalFreq;
        if (lastFreq == recalFreq)
        {
            return NO_NEED_RECALC_LO;
        }
        else
        {
            return NEED_RECALC_LO;
        }
    }
}

T_CarrFreqBandIdxInfo *BspGetCarrFreqBandInfoMem(UINT32 memInit)
{
    size_t bufLen = BSP_MAX_CARR_NUM * BSP_MAX_TX_CHAN * sizeof(T_CarrFreqBandIdxInfo);
    if (s_carrFreqBandInfo == NULL)
    {
        s_carrFreqBandInfo = (T_CarrFreqBandIdxInfo *)malloc(bufLen);
        if (s_carrFreqBandInfo == NULL)
        {
            return NULL;
        }
        memset_s(s_carrFreqBandInfo, bufLen, 0, bufLen);
    }
    if (memInit == 1)
    {
        memset_s(s_carrFreqBandInfo, bufLen, 0, bufLen);
    }
    return s_carrFreqBandInfo;
}

static UINT32 CarrFreqSort(T_CarrInfo *carrInfo, UINT32 carrNum)
{
    UINT32 bandIdx               =0;
    UINT32 bandWidthStartIdx     =0;
    UINT32 bandWidthNum          =0;
    UINT32 radioMode             =0;
    UINT32 findFlag              =0;
    UINT32 carrIdx               =0;
    UINT32 freqBandInfoCarrIdx   =0;
    T_CarrFreqBandIdxInfo *carrFreqBandInfo = BspGetCarrFreqBandInfoMem(1);
    INPUT_POINTER_CHECK(carrFreqBandInfo);
    INPUT_POINTER_CHECK(carrInfo);
    CARR_NUM_CHECK(carrNum, (BSP_MAX_CARR_NUM * BSP_MAX_TX_CHAN));
    for (carrIdx = 0; carrIdx < carrNum; ++carrIdx)
    {
        carrFreqBandInfo[freqBandInfoCarrIdx].carrFreq = carrInfo[carrIdx].freq;
        carrFreqBandInfo[freqBandInfoCarrIdx].radioMode = radioMode = carrInfo[carrIdx].radioMode;

        dbgInfoEx("%s [%d] radio'%#x freq'%d bw'%d\n", __FUNCTION__, carrIdx, radioMode, carrInfo[carrIdx].freq, carrInfo[carrIdx].bandWidth);

        bandWidthStartIdx = bandWidthNum = 0; /* 当前只支持NR,LTE_TDD.其他制式暂不支持 */
        GetBwStartIdxAndNum(radioMode, &bandWidthStartIdx, &bandWidthNum);
        for (bandIdx = bandWidthStartIdx, findFlag = 0; (bandIdx < bandWidthStartIdx + bandWidthNum) && (s_carrBWInfo[bandIdx].carrBw != 0); ++bandIdx)
        {
            if (s_carrBWInfo[bandIdx].carrBw == carrInfo[carrIdx].bandWidth)
            {
                carrFreqBandInfo[freqBandInfoCarrIdx].bandWidthIdx = bandIdx;
                findFlag = 1;
                break;
            }
        }
        if (!findFlag) /* 特殊情况考虑:配置的带宽是s_carrBWInfo不支持的场景,吴晶:当前协议下已经包括了，如果出现类似没出现的带宽，信号带宽、保护带宽、载波带宽，统一按载波带宽来 */
        {
            /* 制式不支持 或者 带宽配的是s_carrBWInfo不支持的场景而且s_carrBWInfo已经满了,走到下面的error分支 */
            if (bandIdx >= bandWidthStartIdx + bandWidthNum)
            {
                dbgErr("%s radioMode'%#x bandWidth'%d not support! And current bandWidth idx is overload!\n", __FUNCTION__, radioMode, carrInfo[carrIdx].bandWidth);
                return BSP_ERROR;
            }
            BspLog(LOG_LEVEL_0,"%s bandWidth'%d not found!, add as idx'%d\n", __FUNCTION__, carrInfo[carrIdx].bandWidth, bandIdx);
            s_carrBWInfo[bandIdx].proCalcBw = carrInfo[carrIdx].bandWidth;
            s_carrBWInfo[bandIdx].signalBw = carrInfo[carrIdx].bandWidth;
            s_carrBWInfo[bandIdx].carrBw = carrInfo[carrIdx].bandWidth;
            s_carrBWInfo[bandIdx].index = bandIdx;
            carrFreqBandInfo[freqBandInfoCarrIdx].bandWidthIdx = bandIdx;
        }
        freqBandInfoCarrIdx += 1;
    }

    qsort(carrFreqBandInfo, carrNum, sizeof(carrFreqBandInfo[0]), CarrFreqSortCompareUp);
    PrnSortedCarrInfo(freqBandInfoCarrIdx);

    return BSP_OK;
}

static int CarrFreqSortCompareUp(const void *a, const void *b)
{
    T_CarrFreqBandIdxInfo *aa = (T_CarrFreqBandIdxInfo*)a;
    T_CarrFreqBandIdxInfo *bb = (T_CarrFreqBandIdxInfo*)b;
    return aa->carrFreq > bb->carrFreq;
}

static void PrnSortedCarrInfo(UINT32 num)
{
    UINT32 loop;
    T_CarrFreqBandIdxInfo *carrFreqBandInfo = BspGetCarrFreqBandInfoMem(0);
    INPUT_POINTER_CHECK_RETURN(carrFreqBandInfo);
    dbgInfoEx("%-10s%-10s%-10s%-10s\n", "sortIdx", "radio", "freq", "bwIdx");
    for (loop = 0; loop < num; ++loop)
    {
        dbgInfoEx("%-10d%-10x%-10d%-10d\n", loop, carrFreqBandInfo[loop].radioMode, carrFreqBandInfo[loop].carrFreq,
                carrFreqBandInfo[loop].bandWidthIdx);
    }
}

/* 当前只支持NR,LTE_TDD.其他制式暂不支持 */
static void GetBwStartIdxAndNum(UINT32 radioMode, UINT32 *startIdx, UINT32 *num)
{
    INPUT_POINTER_CHECK_RETURN(startIdx);
    INPUT_POINTER_CHECK_RETURN(num);
    if ((radioMode == BSP_RADIO_STANDARD_5G)||(radioMode == BSP_RADIO_STANDARD_FDD_5G))
    {
        *startIdx = BANDWIDTH_NR_START;
        *num = BANDWIDTH_TYPE_NUM_NR;
    }
    else if (radioMode == BSP_RADIO_STANDARD_LTE_TDD)
    {
        *startIdx = BANDWIDTH_LTE_TDD_START;
        *num = BANDWIDTH_TYPE_NUM_LTE_TDD;
    }
    else if (radioMode == RADIO_STANDARD_NB_IOT)
    {
        *startIdx = BANDWIDTH_NB_START;
        *num = BANDWIDTH_TYPE_NUM_NB;
    }
    return ;
}

UINT32 IsCurrentLoFreqOk(UINT32 trx, UINT32 chan, UINT32 carrNum, UINT32 *freqOut)
{
    UINT32 lastLoFreq      = 0;
    UINT32 pllNo           = 0;
    UINT32 defaultLoFreq   = 0;
    INT32 mtsNco          = 0;
    const char *debugTitle = "<need recalc lo?>";

    INPUT_POINTER_CHECK(freqOut);

    defaultLoFreq = BspGetRfCenterFreq(trx, chan);
    mtsNco     = BspGetRfNco(trx, chan);
    lastLoFreq = BspGetLoFreqChanged(trx, chan);
    lastLoFreq = lastLoFreq - mtsNco;
    BspLog(LOG_LEVEL_0,"%s defaultLo:%d lastLo:%d, mtsNco = %d.\n", debugTitle, defaultLoFreq, lastLoFreq,mtsNco);
    if ((lastLoFreq == 0) || (lastLoFreq == BSP_ERROR)) /* BspGetLoFreqChanged失败就判断默认本振 */
    {
        if ((defaultLoFreq == 0) || (defaultLoFreq == BSP_ERROR)) /* 连上电的默认本振都获取失败,就直接重新计算本振 */
        {
            BspLog(LOG_LEVEL_0,"%s defaultLo and lastLo is invaild!, re calc lo!\n", debugTitle);
             *freqOut = lastLoFreq;
             return NEED_RECALC_LO;
        }
        else
        {
            lastLoFreq = defaultLoFreq;
        }
    }
    else if(s_pllFlagByMainMgr == 1)
    {
        lastLoFreq = defaultLoFreq;
    }
    pllNo = getChanMergePllNo(chan, trx);
    if(pllNo >= BSP_MAX_TX_CHAN)
    {
        dbgErr("%s: chan[%d],pllNo[%d] is over range.\n", __FUNCTION__, chan,pllNo);
        return BSP_ERROR;
    }
    if((s_firstChgTxPll[pllNo] == 0) && (trx == TX))
    {
        s_firstChgTxPll[pllNo] = 1;
        return NEED_RECALC_LO;
    }

    if((s_firstChgRxPll[pllNo] == 0) && (trx == RX))
    {
        s_firstChgRxPll[pllNo] = 1;
        return NEED_RECALC_LO;
    }

    /* 判断本振是否在带内,在带内的话需要重新计算本振 */
    if (IsLoFreqInGuardBand(trx, chan, carrNum, lastLoFreq) != BSP_OK)
    {
        BspLog(LOG_LEVEL_0,"%s cell is not exist! and lo is not in guard band, recalc lo!\n", debugTitle);
        *freqOut = lastLoFreq;
        return NEED_RECALC_LO;
    }

    /* 判断本振是否在滤波器中心频点有效门限值，不在门限内的话需要重新计算本振 */
    if (IsLoFreqRangeOk(trx, chan, lastLoFreq) != BSP_OK)
    {
        BspLog(LOG_LEVEL_0,"%s not all carr-lo offset in ifBW range, recalc lo!\n", debugTitle);
        *freqOut = lastLoFreq;
        return NEED_RECALC_LO;
    }

    /* 判断是否所有载波离本振<=NCO移频范围 */
    if (IsLoCarrFreqOffsetOk(trx, chan, carrNum, lastLoFreq, mtsNco) != BSP_OK)
    {
        BspLog(LOG_LEVEL_0,"%s not all carr-lo offset in NCO range, recalc lo!\n", debugTitle);
        *freqOut = lastLoFreq;
        return NEED_RECALC_LO;
    }

    *freqOut = lastLoFreq;
    BspLog(LOG_LEVEL_0,"%s all carr-lo offset in ifBW range, current lo'%d is ok!\n", debugTitle, lastLoFreq);
    return NO_NEED_RECALC_LO;
}

UINT32 BspSetChgPllByMainMgrFlag(UINT32 flag)
{
    s_pllFlagByMainMgr = flag;
    return BSP_OK;
}

/* 将所有载波按中心频率从小到大排列,判断本振频点LO是否落在任何一个载波信号带内 */
static UINT32 IsLoFreqInGuardBand(UINT32 trx, UINT32 chan, UINT32 carrNum, UINT32 loFreq)
{
    UINT32 loop    = 0;
    UINT32 difFreq = 0;
    UINT32 bandIdx = 0;
    UINT32 retVal  = BSP_OK;
    T_CarrFreqBandIdxInfo *carrFreqBandInfo = BspGetCarrFreqBandInfoMem(0);
    INPUT_POINTER_CHECK(carrFreqBandInfo);

    for (loop = 0; loop < carrNum; ++loop)
    {
        difFreq = abs(carrFreqBandInfo[loop].carrFreq - loFreq);
        bandIdx = carrFreqBandInfo[loop].bandWidthIdx;
        if(difFreq < s_carrBWInfo[bandIdx].proCalcBw / 2)
        {
            retVal = BSP_ERROR;
            break;
        }
        BspLog(LOG_LEVEL_0,">>%s radio'%#x bandWidth'%d protWidth'%d carrFreq'%d loFreq'%d %s guard band!\n",__FUNCTION__,
                s_carrFreqBandInfo[loop].radioMode,s_carrBWInfo[bandIdx].carrBw, s_carrBWInfo[bandIdx].proCalcBw,
                s_carrFreqBandInfo[loop].carrFreq, loFreq, "not in" + (retVal == BSP_OK) * 4);
    }

    return retVal;
}

/* Started by AICoder, pid:p8709ce3eai305214905093f208af3799214ce18 */
/*
 * 本振频率距离滤波器中心频点变化范围判断，此判断是为了避免只在边界配置小带宽场景
 * 1.获取滤波器中心频点filterCenterFreq
 * 2.获取本振变化范围loFreqRange
 * 3.判断本振频点是否在本振范围内[loFreqRangeLow,loFreqRangeHigh]
 * 4.若不在，选取距离本振最近的边界
 */
UINT32 IsLoFreqRangeOk(UINT32 trx, UINT32 chan, UINT32 loFreq)
{
    UINT32 filterCenterFreq           = 0;
    UINT32 filterLow                  = 0;
    UINT32 filterHigh                 = 0;
    UINT32 loFreqRange                = 0;
    UINT32 loFreqRangeLow             = 0;
    UINT32 loFreqRangeHigh            = 0;
    UINT32 loFixFreq                  = 0;
    pGetRfFreqRange pFuncGetFreqRange = BspGetFilterRangeFreqCallBack();
    T_RfPllCfgInit *ptRfPllCfgInit    = NULL;
    pGetLoFreqBlackout pLoFreqBlackoutFunc = (pGetLoFreqBlackout)BspGetLoFreqBlackoutCallBack();
    const char *debugTitle            = "<need recalc lo?>";

    ptRfPllCfgInit = pGetRfPllCfgHandle(trx);
    INPUT_POINTER_CHECK(ptRfPllCfgInit);

    /*本振变化范围 0-不需判断*/
    loFreqRange = ptRfPllCfgInit[chan].loToFilterThre;
    if (0 == loFreqRange)
    {
        return BSP_OK;
    }

    /* 获取滤波器中心频点 */
    if (pFuncGetFreqRange == NULL)
    {
        dbgErr("%s get filter call back func failed!\n", debugTitle);
        return BSP_ERROR;
    }
    if (pFuncGetFreqRange(trx, chan, &filterLow, &filterHigh) != BSP_OK)
    {
        dbgErr("%s get filter range failed!\n", debugTitle);
        return BSP_ERROR;
    }
    filterCenterFreq = (filterLow + filterHigh) / 2;

    //计算本振变化范围上下边界
    loFreqRangeLow  = filterCenterFreq - loFreqRange;
    loFreqRangeHigh = filterCenterFreq + loFreqRange;

    /* Started by AICoder, pid:56970pa1eex8ac81480b083d1014bc1f07805609 */
    if(NULL != pLoFreqBlackoutFunc)
    {
        if( BSP_OK != pLoFreqBlackoutFunc(chan,loFreq))//本振频点不符合Transceiver要求，需要规避
        {
            BspLog(LOG_LEVEL_0,"%s>> chan:%d, loFreq:%d khz within blackout!!! return filterCenterFreq:[%d]\n",  __FUNCTION__, chan, loFreq,filterCenterFreq);
            return filterCenterFreq;
        }
    }
    /* Ended by AICoder, pid:56970pa1eex8ac81480b083d1014bc1f07805609 */

    if ((loFreq >= min(loFreqRangeLow,loFreqRangeHigh)) && (loFreq <= max(loFreqRangeLow,loFreqRangeHigh)))
    {
        return BSP_OK;
    }
    else
    {
        loFixFreq = (abs(loFreq - loFreqRangeLow) < abs(loFreq - loFreqRangeHigh)) ? loFreqRangeLow : loFreqRangeHigh;
        if(NULL != pLoFreqBlackoutFunc)
        {
            if( BSP_OK != pLoFreqBlackoutFunc(chan,loFixFreq))//本振频点不符合Transceiver要求，需要规避
            {
                BspLog(LOG_LEVEL_0,"%s>> chan:%d, loFixFreq:%d khz within blackout!!! return filterCenterFreq:[%d]\n",  __FUNCTION__, chan, loFixFreq,filterCenterFreq);
                return filterCenterFreq;
            }
        }
        return loFixFreq;
    }
}
/* Ended by AICoder, pid:p8709ce3eai305214905093f208af3799214ce18 */

/** 判断所有载波偏离本振是否在NCO移频范围内,选取最低f0和最高fn载波中心频点,要满足:
 * | lo - (f0 - BW0''/2) | <= loToCarrThre & | (fn + BWn''/2) - lo | <= loToCarrThre*/
static UINT32 IsLoCarrFreqOffsetOk(UINT32 trx, UINT32 chan, UINT32 carrNum, UINT32 loFreq, INT32 mtsNco)
{
    UINT32 retVal                  = BSP_ERROR;
    UINT32 lowIdx                  = 0;
    UINT32 highIdx                 = carrNum - 1;
    UINT32 bwIdxLow                = 0;
    UINT32 bwIdxHigh               = 0;
    UINT32 ifCenterFreq = 0;        /*除去BAND NCO后的载波看到的移频的中心频点*/
    T_RfPllCfgInit *ptRfPllCfgInit = NULL;
    T_CarrFreqBandIdxInfo *carrFreqBandInfo = BspGetCarrFreqBandInfoMem(0);
    INPUT_POINTER_CHECK(carrFreqBandInfo);
    ptRfPllCfgInit = pGetRfPllCfgHandle(trx);
    INPUT_POINTER_CHECK(ptRfPllCfgInit);

    if (0 == ptRfPllCfgInit[chan].loToCarrThre)
    {
        BspLog(LOG_LEVEL_0, "freq: %s >> chan[%d] loToCarrThre error!\n", __FUNCTION__, chan);
        dbgErr("%s >> chan[%d] loToCarrThre error!\n", __FUNCTION__, chan);
        return BSP_ERROR;
    }

    if (carrNum == 0)
    {
        dbgErr("%s >> carrNum = %d! error!\n", __FUNCTION__, carrNum);
        return BSP_ERROR;
    }

    if(ptRfPllCfgInit[chan].bandNcoFlag == 1)
    {
        ifCenterFreq = loFreq + mtsNco;
    }
    else
    {
        ifCenterFreq = loFreq;
    }

    bwIdxLow = carrFreqBandInfo[lowIdx].bandWidthIdx;
    bwIdxHigh = carrFreqBandInfo[highIdx].bandWidthIdx;

    if ((abs(carrFreqBandInfo[lowIdx].carrFreq - s_carrBWInfo[bwIdxLow].signalBw / 2 - ifCenterFreq) <= ptRfPllCfgInit[chan].loToCarrThre) &&
        (abs(carrFreqBandInfo[highIdx].carrFreq + s_carrBWInfo[bwIdxHigh].signalBw / 2 - ifCenterFreq) <= ptRfPllCfgInit[chan].loToCarrThre))
    {
        retVal = BSP_OK;
    }

    BspLog(LOG_LEVEL_0, ">>%s retVal[%d](0:in range, 0xffffffff:not in range)!  lo'%d IfCenterFreq‘%d ’CarrThre'%d. low:(%d,%d) high(%d,%d)\n", __FUNCTION__, retVal,
            loFreq, ifCenterFreq, ptRfPllCfgInit[chan].loToCarrThre,carrFreqBandInfo[lowIdx].carrFreq, s_carrBWInfo[bwIdxLow].signalBw,
            carrFreqBandInfo[highIdx].carrFreq, s_carrBWInfo[bwIdxHigh].signalBw);

    return retVal;
}

static UINT32 getNearestTargetFreq(UINT32 beginFreq, UINT32 *edges, UINT32 edgeNum, UINT32 loChangeWidth)
{
    UINT32 edgeIdx    = 0;
    UINT32 targetFreq = 0;
    UINT32 difFreq    = INT32_MAX;

    for (edgeIdx = 0; edgeIdx < edgeNum; ++edgeIdx)
    {
        if (abs(edges[edgeIdx] - beginFreq) < difFreq)
        {
            difFreq = abs(edges[edgeIdx] - beginFreq);
            targetFreq = edges[edgeIdx];
        }
    }

    if(loChangeWidth != BANDWIDTH_0M)
    {
        for (edgeIdx = 0; edgeIdx < edgeNum; ++edgeIdx)
            {
                if (abs(edges[edgeIdx] - beginFreq) < (difFreq + loChangeWidth))
                {
                    targetFreq = edges[edgeIdx];
                }
            }
    }

    return targetFreq;
}

static UINT32 getMtsChanNco(UINT32 trx, UINT32 chan, UINT32 beginFreq, UINT32 targetFreq, UINT32 carrNum)
{
    UINT32 mtsNcoStep = 0;
    T_RfPllCfgInit *ptRfPllCfgInit = NULL;
    INT32 mtsNco     = 0;

    CHECK_BSPCHN(chan);

    ptRfPllCfgInit = pGetRfPllCfgHandle(trx);
    mtsNcoStep = ptRfPllCfgInit[chan].bandNcoStep;

    if(ptRfPllCfgInit[chan].bandNcoStep == 0)
    {
        dbgInfo("%s [ERROR]:bandNcoStep[board] Parameter missing!\n", __FUNCTION__);
        return beginFreq;
    }

    targetFreq = targetFreq / s_loStep * s_loStep;
    mtsNco = beginFreq - targetFreq;
    mtsNco = mtsNco / (INT32)mtsNcoStep * (INT32)mtsNcoStep;

    ptRfPllCfgInit[chan].bandNcoBase = mtsNco;
    BspLog(LOG_LEVEL_0,"%s chan'%d dir'%d beginFreq'%d targetFreq'%d mtsNco:%d, - mtsNco[%d], mtsNcoStep[%d]\n", __FUNCTION__, chan,trx,beginFreq,targetFreq,ptRfPllCfgInit[chan].bandNcoBase, - mtsNco, mtsNcoStep);

    if (IsLoCarrFreqOffsetOk(trx, chan, carrNum, targetFreq, mtsNco) != BSP_OK)
    {
        BspLog(LOG_LEVEL_0,"%s with MTS_NCO freq'%d no in if band width!\n", __FUNCTION__, targetFreq);
        targetFreq = beginFreq;
        ptRfPllCfgInit[chan].bandNcoBase = 0;
        if((trx == TX) && (ptRfPllCfgInit[chan].pSetMtsNco != NULL))
        {
            ptRfPllCfgInit[chan].pSetMtsNco(chan,trx,0, 0,0);
        }
        ptRfPllCfgInit[chan].bandNcoBase = 0;
    }
    else
    {
        if((trx == TX) && (ptRfPllCfgInit[chan].pSetMtsNco != NULL))
        {
            ptRfPllCfgInit[chan].pSetMtsNco(chan,trx,mtsNco, - mtsNco,- mtsNco);
        }
    }

    BspLog(LOG_LEVEL_0,"%s mtsNco:%d, - mtsNco[%d], mtsNcoStep[%d]\n", __FUNCTION__, ptRfPllCfgInit[chan].bandNcoBase, - mtsNco, mtsNcoStep);
    return targetFreq;
}

static UINT32 clearMtsNco(UINT32 trx, UINT32 chan)
{
    T_RfPllCfgInit *ptRfPllCfgInit = NULL;
    ptRfPllCfgInit = pGetRfPllCfgHandle(trx);

    if((trx == TX) && (ptRfPllCfgInit[chan].pSetMtsNco != NULL))
    {
        ptRfPllCfgInit[chan].pSetMtsNco(chan,trx,0, 0,0);
        BspLog(LOG_LEVEL_0,"%s, trx = %d.\n", __FUNCTION__, trx);
    }
    ptRfPllCfgInit[chan].bandNcoBase = 0;

    return BSP_OK;
}

static UINT32 BspGetCarrCenterFreq(UINT32 carrNum)
{
    UINT32 bwIdx = 0;
    UINT32 leftEdge = 0;
    UINT32 rightEdge = 0;
    UINT32 centerFreq = 0;
    T_CarrFreqBandIdxInfo *carrFreqBandInfo = BspGetCarrFreqBandInfoMem(0);
    INPUT_POINTER_CHECK(carrFreqBandInfo);

    bwIdx = carrFreqBandInfo[0].bandWidthIdx;
    leftEdge = carrFreqBandInfo[0].carrFreq - s_carrBWInfo[bwIdx].signalBw / 2;

    bwIdx = carrFreqBandInfo[carrNum - 1].bandWidthIdx;
    rightEdge = carrFreqBandInfo[carrNum - 1].carrFreq + s_carrBWInfo[bwIdx].signalBw / 2;

    /*取实际最左边沿和最右边沿的中心做目标射频频点*/
    centerFreq = (leftEdge + rightEdge) / 2;
    centerFreq = centerFreq / s_loStep * s_loStep;
    BspLog(LOG_LEVEL_0, "freq: %s leftEdge[%d], rightEdge[%d], centerFreq[%d], \n", __FUNCTION__, leftEdge, rightEdge, centerFreq);

    return centerFreq;
}

/**
 * 1. 将所有载波按中心频率从小到大排序,确认各载波左l右r边界.
 *      c0_l = f0 - BW'0/2, cn_r = fn + BW'n/2
 *      载波不重叠: ci_r = fi + BW'i/2, cj_l = fj - BW'j/2
 *      载波重叠: ci_r = cj_l = (fi + BWi/2 + fj - BWj/2)/2
 * 2. 将载波边界合并掉相同值后,并在DPD带宽内[fa, fb]选出落入其中的载波边界中(c0,...,cm),并判断该数列中是否能满足下面要求:
 *      |ck - (f0 - BW''0/2)| <= BWIF/2 & |(fn + BW''n/2)-ck| <= BWIF/2
 * 3. 满足上述条件的载波边界数为0,则fLO = fFilter-center
 *      满足上述条件的载波边界大于1时,则fLo选择最接近fFilter-center的那个
 * 4. 按本振栅格重新计算本振
 *      fLo = INT(fLo / fStep)*fStep
 * 5. 判断所有载波有用信号离fLo是否在NCO范围内,在范围内有效,否则取fLo = fFilter-center
 *      对于NR3.0可以配置频段NCO(NCO2),当载波距离超出范围时,可设置fNCO2 = fFilter-center - fLo按NCO2的配频步进来配置,然后再根据(fLo+fNCO2)判断信号范围以及计算载波NCO
 *
 * 注意:当前只实现到第四步,第五步还是按照之前的NCO配置方案修改
*/
UINT32 UpdateCenterFreqDynamic(UINT32 trx, UINT32 chan, UINT32 carrNum)
{
    UINT32 edges[BSP_MAX_CARR_NUM * 2] = {0};
    UINT32 edgeNum                     = 0;
    UINT32 edgeIdx                     = 0;
    UINT32 difFreq                     = INT32_MAX;
    UINT32 targetFreq                  = 0;
    UINT32 dpdFreqRangelow             = GetDpdRangeLow(trx, chan);
    UINT32 dpdFreqRangeHigh            = GetDpdRangeHigh(trx, chan);
    UINT32 filterCenterFreq            = 0;
    UINT32 filterLow                   = 0;
    UINT32 filterHigh                  = 0;
    UINT32 calcRet                     = 0;
    UINT32 beginFreq                   = 0;
    UINT32 loChangeWidth = GetLoChangeMargin(trx, chan);

    const char *debugTitle             = "<re calc lo>";
    pGetRfFreqRange pFuncGetFreqRange  = BspGetFilterRangeFreqCallBack();

    /* 获取滤波器中心频点 */
    if (pFuncGetFreqRange == NULL)
    {
        BspLog(LOG_LEVEL_0, "freq: %s get filter call back func failed!\n", __FUNCTION__);
        dbgErr("%s get filter call back func failed!\n", debugTitle);
        return BSP_ERROR;
    }
    if (pFuncGetFreqRange(trx, chan, &filterLow, &filterHigh) != BSP_OK)
    {
        BspLog(LOG_LEVEL_0, "freq: %s get filter range failed!\n", __FUNCTION__);
        dbgErr("%s get filter range failed!\n", debugTitle);
        return BSP_ERROR;
    }
    filterCenterFreq = (filterLow + filterHigh) / 2;

    /* 将所有载波按中心频率从小到大排序,确认各载波左l右r边界.并选出落在DPD带宽中的 */
    edgeNum = GetCarrEdgeFreqs(carrNum, dpdFreqRangelow, dpdFreqRangeHigh, edges , chan);

    BspLog(LOG_LEVEL_0,"%s DPD[%d,%d] edge num:%d filter-center:%d\n", debugTitle, dpdFreqRangelow, dpdFreqRangeHigh, edgeNum, filterCenterFreq);
    /* 选择本振，默认选择载波中心频点*/

    if((edgeNum > (BSP_MAX_CARR_NUM * 2)) || (edgeNum == 0))
    {
        dbgErr("%s: chan[%d],edgeNum[%d] is over range.\n", __FUNCTION__, chan,edgeNum);
        return BSP_ERROR;
    }
    targetFreq = BspGetCarrCenterFreq(carrNum);
    beginFreq = targetFreq;
    for (edgeIdx = 0; edgeIdx < edgeNum; ++edgeIdx)
    {
        BspLog(LOG_LEVEL_0,"%s [%d] edge:%d\n", debugTitle, edgeIdx, edges[edgeIdx]);
        if (IsLoCarrFreqOffsetOk(trx, chan, carrNum, edges[edgeIdx], 0) != BSP_OK)
        {
            BspLog(LOG_LEVEL_0,"%s freq'%d no in if band width!\n", debugTitle, edges[edgeIdx]);
            continue;
        }
        if (abs(edges[edgeIdx] - filterCenterFreq) < difFreq)
        {
            difFreq = abs(edges[edgeIdx] - filterCenterFreq);
            targetFreq = edges[edgeIdx];
        }
    }

    if((GetBandNcoFlag(trx, chan) == 1))
    {
        if((targetFreq == beginFreq)&&(difFreq == INT32_MAX))
        {
            targetFreq = getNearestTargetFreq(beginFreq, edges, edgeNum, loChangeWidth);
            targetFreq = getMtsChanNco(trx, chan,beginFreq, targetFreq, carrNum);
        }
        else
        {
            clearMtsNco(trx, chan);
        }
    }

    calcRet = IsLoFreqRangeOk(trx, chan, targetFreq);
    if (calcRet != BSP_OK && calcRet != BSP_ERROR)
    {
        targetFreq = calcRet / s_loStep * s_loStep;
    }

    targetFreq = targetFreq / s_loStep * s_loStep;

    BspLog(LOG_LEVEL_0,"%s choose %d\n", debugTitle, targetFreq);
    return targetFreq;
}

static UINT32 GetDpdRangeLow(UINT32 uDir, UINT32 ulBspChan)
{
    T_RfPllCfgInit *pRfPllCfg = GetRfPllCfg(uDir, ulBspChan);
    if (pRfPllCfg != NULL)
    {
        return pRfPllCfg[ulBspChan].dpdRangeLow;
    }
    return BSP_ERROR;
}

/*异常时返回BANDWIDTH_0M，表示不需要增加本振选择余量*/
static UINT32 GetLoChangeMargin(UINT32 dir, UINT32 bspChan)
{
    UINT32 chanNum = BspGetTxChanNum();
    T_RfPllCfgInit *pRfPllCfg = GetRfPllCfg(dir, bspChan);

    if(bspChan >= chanNum)
    {
        BspLog(LOG_LEVEL_0,"freq %s ERROR, chan[%d] is over chanNum[%d]!\n", bspChan, chanNum);
        return BANDWIDTH_0M;
    }

    if (pRfPllCfg != NULL)
    {
        return pRfPllCfg[bspChan].loChangeSelectMargin;
    }

    BspLog(LOG_LEVEL_0,"freq %s ERROR, chan[%d] is over chanNum[%d]!\n", bspChan, chanNum);
    return BANDWIDTH_0M;
}

static UINT32 GetDpdRangeHigh(UINT32 uDir, UINT32 ulBspChan)
{
    T_RfPllCfgInit *pRfPllCfg = GetRfPllCfg(uDir, ulBspChan);
    if (pRfPllCfg != NULL)
    {
        return pRfPllCfg[ulBspChan].dpdRangeHigh;
    }
    return BSP_ERROR;
}

UINT32 GetCarrEdgeFreqs(UINT32 carrNum, UINT32 dpdFreqRangeLow, UINT32 dpdFreqRangeHigh, UINT32 *edges, UINT32 chan)
{
    UINT32 loop            = 0;
    UINT32 bwIdx           = 0;
    /* UINT32 bwIdxPre        = 0; */
    UINT32 leftEdge        = 0;
    UINT32 rightEdge       = 0;
    INT32  edgeNum         = 0;
    const char *debugTitle = "<calc carr edge>";
    pGetLoFreqBlackout pLoFreqBlackoutFunc = (pGetLoFreqBlackout)BspGetLoFreqBlackoutCallBack();
    T_CarrFreqBandIdxInfo *carrFreqBandInfo = BspGetCarrFreqBandInfoMem(0);
    INPUT_POINTER_CHECK(carrFreqBandInfo);
    dbgInfoEx("%s >> dpd[%d,%d], carrNum:%d\n", debugTitle, dpdFreqRangeLow, dpdFreqRangeHigh, carrNum);
    for (loop = bwIdx = rightEdge = 0; loop < carrNum; ++loop)
    {
        bwIdx = carrFreqBandInfo[loop].bandWidthIdx;
        leftEdge = carrFreqBandInfo[loop].carrFreq - \
                s_carrBWInfo[bwIdx%(BANDWIDTH_TYPE_NUM_NR+BANDWIDTH_TYPE_NUM_LTE_TDD+BANDWIDTH_TYPE_NUM_NB)].delta1Bw / 2;
        dbgInfoEx("%s >> [%d] leftEdge:%d\n", debugTitle, loop, leftEdge);
        if (rightEdge == leftEdge)
        {
            BspLog(LOG_LEVEL_0,"%s current left edge = right edge, merge into %d!\n", debugTitle, leftEdge);
            edgeNum -= 1;
        }
        else if (rightEdge > leftEdge) /* 载波重叠,仅支持不同频配置，注意这里取的带宽是BW,不是BW' */
        {
            /* 相邻载波同频时不计算边界，按当前载波边界计算，不同频时取左右边界中心 */
            if(carrFreqBandInfo[loop-1].carrFreq == carrFreqBandInfo[loop].carrFreq)
            {
                BspLog(LOG_LEVEL_0,"%s current carrFreq = last carrFreq, ignore current edge!\n", debugTitle);
                continue;
            }
#if 0
            bwIdxPre = carrFreqBandInfo[loop-1].bandWidthIdx;
            leftEdge = (carrFreqBandInfo[loop-1].carrFreq + s_carrBWInfo[bwIdxPre].proCalcBw / 2 +
                        carrFreqBandInfo[loop].carrFreq - s_carrBWInfo[bwIdx].proCalcBw / 2) / 2;
#endif
            leftEdge = carrFreqBandInfo[loop].carrFreq - s_carrBWInfo[bwIdx].proCalcBw / 2;
            BspLog(LOG_LEVEL_0,"%s current left edge < right edge, merge into %d!\n", debugTitle, leftEdge);
            edgeNum -= 1;
        }
        if (edgeNum < 0) /* 正常不会走入此分支,保护edges.配置异常频点才会.比如S49机型配置S35频点 */
        {
            dbgErr("%s edgeNum'%d overload!\n", __FUNCTION__, edgeNum);
            edgeNum = 0;
            continue;
        }

        if((leftEdge % s_loStep) != 0)
        {
            leftEdge = leftEdge / s_loStep * s_loStep + s_loStep;
        }
        /* Started by AICoder, pid:150311b56e97fd214e190b0780d933159d44e8c4 */
        if (IS_LO_IN_DPD_RANGE(leftEdge, dpdFreqRangeLow, dpdFreqRangeHigh))
        {

            if(NULL != pLoFreqBlackoutFunc)
            {
                if( BSP_OK == pLoFreqBlackoutFunc(chan,leftEdge))
                {
                    edges[edgeNum++] = leftEdge;
                }

            }else
            {
                edges[edgeNum++] = leftEdge;
            }
        }
        /* Ended by AICoder, pid:150311b56e97fd214e190b0780d933159d44e8c4 */
        rightEdge = carrFreqBandInfo[loop].carrFreq + \
                s_carrBWInfo[bwIdx%(BANDWIDTH_TYPE_NUM_NR+BANDWIDTH_TYPE_NUM_LTE_TDD+BANDWIDTH_TYPE_NUM_NB)].delta1Bw / 2;
        rightEdge = rightEdge / s_loStep * s_loStep;
        BspLog(LOG_LEVEL_0,"%s >> [%d] rightEdge:%d\n", debugTitle, loop, rightEdge);
        /* Started by AICoder, pid:f7310pb77fa017b1401e0a22400ed511431491e5 */
        if (IS_LO_IN_DPD_RANGE(rightEdge, dpdFreqRangeLow, dpdFreqRangeHigh))
        {
            if(NULL != pLoFreqBlackoutFunc)
            {
                if( BSP_OK == pLoFreqBlackoutFunc(chan,rightEdge))
                {
                    edges[edgeNum++] = rightEdge;
                }
            }else
            {
                edges[edgeNum++] = rightEdge;
            }
        }
        /* Ended by AICoder, pid:f7310pb77fa017b1401e0a22400ed511431491e5 */
    }
    return edgeNum;
}

/*使用transceiver的频段NCO，如MTS的频段NCO时，需要将本振和配频中实际使用的中心频点都返回
  由于使用tran的频段NCO的话，计算本振的方法暂时无法统一，目前有用到tran的频段NCO的计算放在单板下实现
  传递到配频中的实际中心频点，本振和频段NCO的关系为PLL+bandNco=difCenterFreq，频段NCO根据上下行注意正负
*/
static UINT32 BspFreqCfgDynamicAnalyse_TranBandNco(UINT32 trx, UINT32 chan, UINT32 carrNum,
        T_CarrInfo *allChanCfgInfo, UINT32 *rfpll)
{
    UINT32 ret = BSP_OK;
    if(NULL != pFuncCalcCenterFreqDynamicFromBoard)
    {
        ret = pFuncCalcCenterFreqDynamicFromBoard(trx, chan, carrNum, allChanCfgInfo, rfpll);
        dbgInfoEx("%s ret = %d \n", __FUNCTION__, ret);
        return ret;
    }
    dbgErr("%s pFuncCalcCenterFreqDynamicFromBoard is NULL \n", __FUNCTION__);
    return BSP_ERROR;
}

UINT32 BspCalcCenterFreqDynamicFromBoardCall(FUNC_CalcCenterFreqDynamicFromBoard pFunc)
{
    pFuncCalcCenterFreqDynamicFromBoard = pFunc;
    return BSP_OK;
}

UINT32 BspFreqCfgDynamicAnalyseFromBoardCall(FUNC_FreqCfgDynamicAnalyseFromBoard pFunc)
{
    pFuncFreqCfgDynamicAnalyseFromBoard = pFunc;
    return BSP_OK;
}

UINT32 BspFreqCfgLoFreqFromBoardCall(FUNC_FreqCfgLoFreqFromBoard pFunc)
{
    pFUNCFreqCfgLoFreqFromBoard = pFunc;
    return BSP_OK;
}

static T_RfPllCfgInit *GetRfPllCfg(UINT32 uDir, UINT32 ulBspChan)
{
    UINT32 chanNum = (RX == uDir) ? BspGetRxChannel():BspGetTxChannel();
    
    if(ulBspChan >= chanNum)
    {
        dbgErr("%s: input ulBspChan'%d is out of range.uDir:%d \n", __FUNCTION__, ulBspChan,uDir);
        return NULL;
    }

    return pGetRfPllCfgHandle(uDir);
}

static UINT32 GetBandNcoFlag(UINT32 uDir, UINT32 ulBspChan)
{
    T_RfPllCfgInit *pRfPllCfg = GetRfPllCfg(uDir, ulBspChan);
    if (pRfPllCfg != NULL)
    {
        return pRfPllCfg[ulBspChan].bandNcoFlag;
    }
    return BSP_ERROR;
}

UINT32 BspSetMtsCaliFlags(UINT32 trsvId, UINT32 flags)
{
    if(trsvId >= MAX_TRANSCEIVER_NUM)
    {
        dbgInfo("%s: Transceive num is over 4. \n", __FUNCTION__);
        return BSP_ERROR;
    }

    s_mtsCaliFlag[trsvId] = flags;

    return BSP_OK;
}

UINT32 BspGetMtsCaliFlags(UINT32 trsvId)
{
    if(trsvId >= MAX_TRANSCEIVER_NUM)
    {
        dbgInfo("%s: Transceive num is over 4. \n", __FUNCTION__);
        return BSP_ERROR;
    }

    return s_mtsCaliFlag[trsvId];
}

UINT32 BspSetLoStep(UINT32 loStep)
{
    s_loStep = loStep;

    return BSP_OK;
}

UINT32 BspGetLoStep(void)
{
    return s_loStep;
}

static void PrnDynamicLoPara(void)
{
    const char *dirName[2] = {"RX", "TX"};
    UINT32 dirNum = 2;
    UINT32 dir, chanIdx, carrIdx;

    if (s_saveCfgPara == NULL)
    {
        return;
    }
    dbgInfo("\n====================%s====================\n", "input para");
    for (dir = 0; dir < dirNum; ++dir)
    {
        dbgInfo("trx:%s, chanNum:%d\n", dirName[dir], s_saveCfgPara[dir].chanNum);
        for (chanIdx = 0; chanIdx < s_saveCfgPara[dir].chanNum; ++chanIdx)
        {
            dbgInfo("chanNo:%d carrNum:%d\n", s_saveCfgPara[dir].allInfo[chanIdx].chanNo, s_saveCfgPara[dir].allInfo[chanIdx].carrNum);
            dbgInfo("%-10s%-10s%-10s%-10s%-10s%-10s\n", "carrNo", "radio", "freq", "bw", "cfgFlag", "offset");
            for (carrIdx = 0; carrIdx < s_saveCfgPara[dir].allInfo[chanIdx].carrNum; ++carrIdx)
            {
                dbgInfo("%-10d%-10d%-10d%-10d%-10d%-10d\n",
                s_saveCfgPara[dir].allInfo[chanIdx].carrInfo[carrIdx].carrNo, s_saveCfgPara[dir].allInfo[chanIdx].carrInfo[carrIdx].radioMode,
                s_saveCfgPara[dir].allInfo[chanIdx].carrInfo[carrIdx].freq, s_saveCfgPara[dir].allInfo[chanIdx].carrInfo[carrIdx].bandWidth,
                s_saveCfgPara[dir].allInfo[chanIdx].carrInfo[carrIdx].cfgFlag, s_saveCfgPara[dir].allInfo[chanIdx].carrInfo[carrIdx].freqOffset);
            }

        }
    }

    dbgInfo("\n====================%s====================\n", "output para");
    for (dir = 0; dir < dirNum; ++dir)
    {
        dbgInfo("trx:%s, chanNum:%d\n", dirName[dir], s_savePreAnysPara[dir].chanNum);

        for (chanIdx = 0; chanIdx < s_saveCfgPara[dir].chanNum; ++chanIdx)
        {
            dbgInfo("%-10s%-10s%-10s\n", "chanNo", "flag", "freq");
            dbgInfo("%-10d%-10d%-10d\n", s_savePreAnysPara[dir].allChangeInfo[chanIdx].chanNo,
            s_savePreAnysPara[dir].allChangeInfo[chanIdx].changePllFlag, s_savePreAnysPara[dir].allChangeInfo[chanIdx].pllFreq);
        }
    }

    return ;
}

UINT32 BspGetPllFreqChanged(UINT32 dir, UINT32 chan)
{
    UINT32 mtsNco = 0;
    UINT32 loFreq = 0;
    UINT32 pllFreq = 0;

    mtsNco = BspGetRfNco(dir, chan);
    loFreq = BspGetLoFreqChanged(dir, chan);

    pllFreq = loFreq - mtsNco;

    dbgInfoEx("%s: dir[%d], chan[%d], mtsNco[%d], loFreq[%d], pllFreq[%d]. \n", __FUNCTION__,
            dir, chan, mtsNco, loFreq, pllFreq);
    return pllFreq;
}

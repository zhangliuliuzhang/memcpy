/*****************************************************************************
* 版权所有(C) 2021, ZTE Corp. ZXSDR-RRU Platform BSP
*----------------------------------------------------------------------------
* 模 块 名 : 配频
* 文件名称 : freqcfg_ic4_2_dbg.c
* 文件标识 : {[N/A]}
* 内容摘要 : 本文件提供了配频接口函数实现
* 注意事项 : 无
* 作    者 : 李权明10279092
* 创建日期 : 2022-01-24
* 当前版本 : Ver1.0
*----------------------------------------------------------------------------*/
#include "freqcfg_ic4_2.h"
#include "freqcfg_ic4_2_analyse.h"

#include "freqcfg_ic4_2_dbg.h"
#include "bspcomm.h"
#include "ichaladaptbspapi.h"
#include "ichaladapt_ic4_2.h"

UINT32 freqcfgPrnFlag = 0;
static T_DbgChanNcoInfo s_dbgNcoInfo[PRX][BSP_IC4_DIF_CHAN_NUM] = {0};

typedef struct T_DbgCarrInfo
{
    UINT32 carrNo;        //* 逻辑载波号
    UINT32 radioMode;     //* 载波制式
    UINT32 freq;          //* 载波频率kHz
    UINT32 bandWidth;     //* 载波带宽单位kHz
    UINT32 delAddFlag;    //* 0:保持 1:增加 2:删除 3:修改
} T_DbgCarrInfo;


T_DbgCarrInfo dbgCarrInfo[2][BSP_MAX_CARR_NUM] =
{
    {
  /*TX: carrNo    radioMode               freq        bandWidth   delAddFlag */
        {0,         BSP_RADIO_STANDARD_5G,  2625000,    100000,      1},
        {1,         0,                      0,          0,           1},
        {2,         0,                      0,          0,           1},
        {3,         0,                      0,          0,           1}
    },

    {
  /*RX: carrNo    radioMode               freq        bandWidth   delAddFlag */
        {0,         BSP_RADIO_STANDARD_5G,  2625000,    100000,       1},
        {1,         0,                      0,          0,            1},
        {2,         0,                      0,          0,            1},
        {3,         0,                      0,          0,            1}
    }

};

//打印开关接口 FREQCFG_ANALYSE/FREQCFG_NCO
static UINT32 freqCfgSetPrn(UINT32 flag)
{
    freqcfgPrnFlag = flag;
    return freqcfgPrnFlag;
}

#ifdef FREQCFG_DEBUG_MODE
UINT32 dbgSaveNcoInfo(UINT32 dir, UINT32 bspChan, T_DbgChanNcoInfo *info)
{
    if(dir<PRX && bspChan <BSP_IC4_DIF_CHAN_NUM)
    {
        memcpy_s(&(s_dbgNcoInfo[dir][bspChan]), sizeof(T_DbgChanNcoInfo), info, sizeof(T_DbgChanNcoInfo));
    }
    return BSP_OK;
}

UINT32 dbgSaveNcoBasicInfo(UINT32 dir, UINT32 bspChan, UINT32 difChan, UINT32 centerFreq, UINT32 bandNum, UINT32 carrNum)
{
    if(dir >= PRX || bspChan >= BSP_IC4_DIF_CHAN_NUM)
    {
       return BSP_ERROR;
    }

    memset(&(s_dbgNcoInfo[dir][bspChan]), 0, sizeof(T_DbgChanNcoInfo));
    s_dbgNcoInfo[dir][bspChan].difChan = difChan;
    s_dbgNcoInfo[dir][bspChan].centerFreq = centerFreq;
    s_dbgNcoInfo[dir][bspChan].bandNum = bandNum;
    s_dbgNcoInfo[dir][bspChan].carrNum = carrNum;

    return BSP_OK;
}

UINT32 dbgSaveNcoBandInfo(UINT32 dir, UINT32 bspChan, UINT32 bandNo, UINT32 freqNco2Step, UINT32 bandFreq, INT32 freqNco2)
{
    if(dir>=PRX || bspChan >= BSP_IC4_DIF_CHAN_NUM || bandNo >= BSP_IC_PERCHAN_BAND_NUM)
    {
       return BSP_ERROR;
    }

    s_dbgNcoInfo[dir][bspChan].freqNco2Step[bandNo] = freqNco2Step;
    s_dbgNcoInfo[dir][bspChan].bandFreq[bandNo] =  bandFreq;
    s_dbgNcoInfo[dir][bspChan].freqNco2[bandNo] = freqNco2;

    return BSP_OK;
}

UINT32 dbgSaveNcoCarrInfo(UINT32 dir, UINT32 bspChan, UINT32 carr, UINT32 difCarrNo, UINT32 carrFreq, INT32 carrNco, UINT32 carrBandNo)
{
    if(dir>=PRX || bspChan >= BSP_IC4_DIF_CHAN_NUM || carr >= BSP_MAX_CARR_NUM)
    {
       return BSP_ERROR;
    }

    s_dbgNcoInfo[dir][bspChan].carrNcoInfo[carr].difCarrNo = difCarrNo;
    s_dbgNcoInfo[dir][bspChan].carrNcoInfo[carr].carrFreq = carrFreq;
    s_dbgNcoInfo[dir][bspChan].carrNcoInfo[carr].carrNco = carrNco;
    s_dbgNcoInfo[dir][bspChan].carrNcoInfo[carr].carrBandNo = carrBandNo;

    return BSP_OK;
}

static UINT32 dbgShowNcoInfo(UINT32 dir, UINT32 bspChan)
{
    UINT32 loopIdx = 0;
    if(dir >= PRX || bspChan >= BSP_IC4_DIF_CHAN_NUM)
    {
        return BSP_ERROR;
    }
    dbgInfo("NCO MODE is : %s\n\n",(CARR_NCO_ONLY == BspGetBoardNcoGrade(bspChan,TX))?"CARR_NCO_ONLY":"CARR_FREQ_NCO_BOTH");
    dbgInfo("DIR%s  BSPCHAN%d CHAN INFO is :\n",dir==TX?"TX":"RX",bspChan);
    dbgInfo("difChan     is %d\n",s_dbgNcoInfo[dir][bspChan].difChan);
    dbgInfo("centerFreq  is %d\n",s_dbgNcoInfo[dir][bspChan].centerFreq);
    dbgInfo("carrNum     is %d\n",s_dbgNcoInfo[dir][bspChan].carrNum);
    dbgInfo("bandNum     is %d\n",s_dbgNcoInfo[dir][bspChan].bandNum);

    dbgInfo("DIR%d  BSPCHAN%d BAND INFO is :\n",dir,bspChan);
    dbgInfo("BAND  BANDFREQ  FREQNCO FREQNCOSTEP\n");
    for(loopIdx=0;loopIdx<s_dbgNcoInfo[dir][bspChan].bandNum;loopIdx++)
    {
        dbgInfo("%4d  %8d  %7d %11d\n",loopIdx,
            s_dbgNcoInfo[dir][bspChan].bandFreq[loopIdx],
            s_dbgNcoInfo[dir][bspChan].freqNco2[loopIdx],
            s_dbgNcoInfo[dir][bspChan].freqNco2Step[loopIdx]);
    }

    dbgInfo("CARR  DIFCARRNO      CARRFREQ  CARRNCO  CARRBANDNO\n");
    for(loopIdx=0;loopIdx<s_dbgNcoInfo[dir][bspChan].carrNum;loopIdx++)
    {
        dbgInfo("%4d  %9d  %12d  %7d  %10d\n",loopIdx,
        s_dbgNcoInfo[dir][bspChan].carrNcoInfo[loopIdx].difCarrNo,
        s_dbgNcoInfo[dir][bspChan].carrNcoInfo[loopIdx].carrFreq,
        s_dbgNcoInfo[dir][bspChan].carrNcoInfo[loopIdx].carrNco,
        s_dbgNcoInfo[dir][bspChan].carrNcoInfo[loopIdx].carrBandNo);
    }
    return BSP_OK;
}
#endif

UINT32 test_freq(UINT32 txChanNum, UINT32 rxChanNum)
{
    UINT32 retVal = BSP_OK;
    UINT32 carrIndex = 0;
    UINT32 txCarrNum = 0;
    UINT32 rxCarrNum = 0;
    UINT32 txCarrNum_RfCfg = 0;
    UINT32 rxCarrNum_RfCfg = 0;
    UINT32 chanIndex = 0;
    T_RfCfgPara rfCfgPara = {0};
    T_DestCarrInfoAllChans *pCarrInfoAllChans= NULL;
    UINT32 txArray[BSP_MAX_CARR_NUM] = {0};
    UINT32 rxArray[BSP_MAX_CARR_NUM] = {0};
    pCarrInfoAllChans = (T_DestCarrInfoAllChans *)malloc(sizeof(T_DestCarrInfoAllChans));
    if(NULL == pCarrInfoAllChans)
    {
        BspLog(LOG_LEVEL_0,"%s pCarrInfoAllChans mallic err\n", __func__);
        return BSP_ERROR;
    }

    for(carrIndex=0; carrIndex<BSP_MAX_CARR_NUM; carrIndex++)
    {
        if(dbgCarrInfo[TX][carrIndex].radioMode)
        {
            txArray[txCarrNum] = carrIndex;
            txCarrNum++;
        }
        if(dbgCarrInfo[RX][carrIndex].radioMode)
        {
            rxArray[rxCarrNum] = carrIndex;
            rxCarrNum++;
        }
    }

    //TX
    pCarrInfoAllChans->txChanNum = txChanNum;
    for(chanIndex=0; chanIndex<txChanNum; chanIndex++)
    {
        pCarrInfoAllChans->txCarrInfo[chanIndex].carrNum = txCarrNum;
        pCarrInfoAllChans->txCarrInfo[chanIndex].chanNo = chanIndex;
        for (carrIndex = 0; carrIndex < txCarrNum; carrIndex++)
        {
            pCarrInfoAllChans->txCarrInfo[chanIndex].carrInfo[carrIndex].bandWidth = dbgCarrInfo[TX][txArray[carrIndex]].bandWidth;
            pCarrInfoAllChans->txCarrInfo[chanIndex].carrInfo[carrIndex].carrNo = dbgCarrInfo[TX][txArray[carrIndex]].carrNo;
            pCarrInfoAllChans->txCarrInfo[chanIndex].carrInfo[carrIndex].freq = dbgCarrInfo[TX][txArray[carrIndex]].freq;
            pCarrInfoAllChans->txCarrInfo[chanIndex].carrInfo[carrIndex].radioMode = dbgCarrInfo[TX][txArray[carrIndex]].radioMode;
            pCarrInfoAllChans->txCarrInfo[chanIndex].carrInfo[carrIndex].delOrAddFlag = dbgCarrInfo[TX][txArray[carrIndex]].delAddFlag;
        }
    }

    //RX
    pCarrInfoAllChans->rxChanNum = rxChanNum;
    for(chanIndex=0; chanIndex<rxChanNum; chanIndex++)
    {
        pCarrInfoAllChans->rxCarrInfo[chanIndex].carrNum = rxCarrNum;
        pCarrInfoAllChans->rxCarrInfo[chanIndex].chanNo = chanIndex;
        for (carrIndex = 0; carrIndex < rxCarrNum; carrIndex++)
        {
            pCarrInfoAllChans->rxCarrInfo[chanIndex].carrInfo[carrIndex].bandWidth = dbgCarrInfo[RX][txArray[carrIndex]].bandWidth;
            pCarrInfoAllChans->rxCarrInfo[chanIndex].carrInfo[carrIndex].carrNo = dbgCarrInfo[RX][txArray[carrIndex]].carrNo;
            pCarrInfoAllChans->rxCarrInfo[chanIndex].carrInfo[carrIndex].freq = dbgCarrInfo[RX][txArray[carrIndex]].freq;
            pCarrInfoAllChans->rxCarrInfo[chanIndex].carrInfo[carrIndex].radioMode = dbgCarrInfo[RX][txArray[carrIndex]].radioMode;
            pCarrInfoAllChans->rxCarrInfo[chanIndex].carrInfo[carrIndex].delOrAddFlag = dbgCarrInfo[RX][txArray[carrIndex]].delAddFlag;
        }
    }

    //预分析
    retVal = BspAnalyseRfcCfgFreqCarrInfo(pCarrInfoAllChans);
    if (BSP_OK != retVal)
    {
        BspLog(LOG_LEVEL_0,"%s>>retVal(%d),iBspAnalyseRfcCfgFreqCarrInfo!\n",
           __FUNCTION__, retVal) ;
        free(pCarrInfoAllChans);
        return BSP_ERROR;
    }
    free(pCarrInfoAllChans);
    BspSysUsDelay(50);
    //TX
    rfCfgPara.carrInfo =  malloc(sizeof(T_CarrInfo) * txCarrNum );
    if(NULL == rfCfgPara.carrInfo)
    {
        return BSP_ERROR;
    }
    for (carrIndex = 0; carrIndex < txCarrNum; carrIndex++)
    {
        if(0 != dbgCarrInfo[TX][txArray[carrIndex]].delAddFlag)
        {
            rfCfgPara.carrInfo[txCarrNum_RfCfg].bandWidth = dbgCarrInfo[TX][txArray[carrIndex]].bandWidth;
            rfCfgPara.carrInfo[txCarrNum_RfCfg].carrNo = dbgCarrInfo[TX][txArray[carrIndex]].carrNo;
            rfCfgPara.carrInfo[txCarrNum_RfCfg].freq =  dbgCarrInfo[TX][txArray[carrIndex]].freq;
            rfCfgPara.carrInfo[txCarrNum_RfCfg].radioMode = dbgCarrInfo[TX][txArray[carrIndex]].radioMode;
            txCarrNum_RfCfg++;
        }
    }
    rfCfgPara.carrNum  = txCarrNum_RfCfg;

    if (txCarrNum_RfCfg)
    {
        for(chanIndex=0; chanIndex<txChanNum; chanIndex++)
        {
            retVal = BspSetTxRfCfg(chanIndex, &rfCfgPara);
            if (BSP_OK != retVal)
            {
                free(rfCfgPara.carrInfo);
                BspLog(LOG_LEVEL_0,"%s>>retVal(%d),BspSetTxRfCfg Error!\n",
                    __FUNCTION__, retVal) ;
                return BSP_ERROR;
            }
            BspSysUsDelay(50);
        }

    }
    free(rfCfgPara.carrInfo);


    //RX
    rfCfgPara.carrInfo =  malloc(sizeof(T_CarrInfo) * rxCarrNum );
    if(NULL == rfCfgPara.carrInfo)
    {
        return BSP_ERROR;
    }

    for (carrIndex = 0; carrIndex < rxCarrNum; carrIndex++)
    {
        if(0 != dbgCarrInfo[RX][rxArray[carrIndex]].delAddFlag)
        {
            rfCfgPara.carrInfo[rxCarrNum_RfCfg].bandWidth = dbgCarrInfo[RX][rxArray[carrIndex]].bandWidth;
            rfCfgPara.carrInfo[rxCarrNum_RfCfg].carrNo = dbgCarrInfo[RX][rxArray[carrIndex]].carrNo;
            rfCfgPara.carrInfo[rxCarrNum_RfCfg].freq =  dbgCarrInfo[RX][rxArray[carrIndex]].freq;
            rfCfgPara.carrInfo[rxCarrNum_RfCfg].radioMode = dbgCarrInfo[RX][rxArray[carrIndex]].radioMode;
            rxCarrNum_RfCfg++;
        }
    }
    rfCfgPara.carrNum  = rxCarrNum_RfCfg;

    if(rxCarrNum_RfCfg)
    {
        for(chanIndex=0; chanIndex<rxChanNum; chanIndex++)
        {
            retVal = BspSetRxRfCfg(chanIndex, &rfCfgPara);
            if (BSP_OK != retVal)
            {
                free(rfCfgPara.carrInfo);
                BspLog(LOG_LEVEL_0,"%s>>retVal(%d),BspSetRxRfCfg Error!\n",
                    __FUNCTION__, retVal) ;
                return BSP_ERROR;
            }
            BspSysUsDelay(50);
        }

    }
    free(rfCfgPara.carrInfo);

    return retVal;
}

/* Started by AICoder, pid:1fe04q98988f9bb14846089b402e8b3d2c326d2e */
UINT32 showfilterAbility(UINT32 dir)
{
    UINT32 loopRadio = 0;
    UINT32 loopBw = 0;
    T_FilterAbilityInfo *pFilterAbility = BspGetFilterAbilityInfo();
    INPUT_POINTER_CHECK(pFilterAbility);

    if (dir >= PRX)
    {
        dbgErr("[%s]: dir'%d out of range!\n",__FUNCTION__, dir);
        return BSP_ERROR;
    }

    dbgInfo("[%s] dir:%d, rruSupport:%d, radioSum:%d \n",
            __FUNCTION__, dir, pFilterAbility[dir].rruSupport, pFilterAbility[dir].radioSum);

    for (loopRadio = 0; loopRadio < pFilterAbility[dir].radioSum; loopRadio++)
    {
        INPUT_POINTER_CHECK(pFilterAbility[dir].radioInfo);

        dbgInfo("[%s] radio:0x%x, bwSum:%d.\n", __FUNCTION__,
            pFilterAbility[dir].radioInfo[loopRadio].radio, pFilterAbility[dir].radioInfo[loopRadio].bwSum);

        for (loopBw = 0; loopBw < pFilterAbility[dir].radioInfo[loopRadio].bwSum; loopBw++)
        {
            dbgInfo("[%s] loopBw:%d, bandWidth:%d.\n", __FUNCTION__,
                    loopBw, pFilterAbility[dir].radioInfo[loopRadio].bandWidth[loopBw]);
        }
    }

    return BSP_OK;
}
/* Ended by AICoder, pid:1fe04q98988f9bb14846089b402e8b3d2c326d2e */

/*****************************************************************************
* 版权所有(C) 2021, ZTE Corp. ZXSDR-RRU Platform BSP
*----------------------------------------------------------------------------
* 模 块 名 : 配频
* 文件名称 : freqcfg_ic4.2.c
* 文件标识 : {[N/A]}
* 内容摘要 : 本文件提供了配频接口函数实现
* 注意事项 : 无
* 作    者 : 李权明10279092
* 创建日期 : 2021-11-26
* 当前版本 : Ver1.0
*----------------------------------------------------------------------------*/
#include "bsppub.h"
#include "bspcomm.h"
#include "freqcfg_ic4_2.h"
#include "freqcfg_ic4_2_dbg.h"
#include "bspcomm.h"
#include "chnmapcommon.h"
#include "ichaladaptbspapi.h"
#include "chnmap_a.h"
#include "freqcfgcommon.h"
#include "funccommon_fpga.h"

#define TRANS_CALI_FLAG_NUM              16
static UINT32 s_transCaliFlag[TRANS_CALI_FLAG_NUM] = {0};     //MTS是否已校准标志
T_RfPllCfgInit *txRfPllCfgInit = NULL;
T_RfPllCfgInit *rxRfPllCfgInit = NULL;
#define NEED_RECALC_LO         1
#define NO_NEED_RECALC_LO      0

#define BAND_NO_0              0
#define BAND_NO_1              1

#define GET_NEAR_FROM_CENTERFREQ         1
#define GET_FAR_FROM_CENTERFREQ          0

#define BAND_NCO      (1)

static FUNC_CALLED_AFTER_FREQCFG s_pFuncCalledAfterFreqcfg[TX+1][FUNC_AFTER_FREQCFG_INDEX_MAX] = {0};
static FUNC_UPDATE_PAPT_AVG_POW_INFO s_pFuncUpdatePaptAvgPowInfo = NULL;
static FUNC_UnfixCalcCenterFreqFromBoard pFuncUnfixCalcCenterFreqFromBoard = NULL;
static FUNC_CfgExTrxNco pFuncCfgExTrxNco = NULL;
static FUNC_CfgTrxRfNco pFuncCfgTrxRfNco = NULL;
static T_FilterChnInfo *s_filterChnInfo = NULL;
T_FilterChnInfo *s_filterNrChnInfo = NULL;
T_FilterChnInfo *s_filterUlNrChnInfo = NULL;
T_FilterChnInfo *s_filterLteChnInfo = NULL;
T_FilterChnInfo *s_filterUlLteChnInfo = NULL;
static T_CfrFreqFiOffsetInfo s_cfrLteNrDssFreqFiOffsetInfo[MAX_TX_CHANNEL] = {0};

static UINT32 s_SupportMgrFreqFlag = 0;   /*支持主从片主进程进行配频*/
static T_GuShareBwFreqCfg atGuShareFreqCfg[MAX_TX_CHANNEL_GU_SHAREBW][MAX_CARRIERS_NUM_UMTS] = {0};  /* GU频谱共享高层下发配置 */



UINT32 BspSetSupportMgrFreqFlag(UINT32 mgrFreqFlag)
{
    s_SupportMgrFreqFlag = mgrFreqFlag;
    return BSP_OK;
}

UINT32 BspGetSupportMgrFreqFlag(VOID)
{
    return s_SupportMgrFreqFlag;
}

#define CHECK_SUPPORT_MGR_FREQ_FLAG(retVal)   \
    if (BspGetSupportMgrFreqFlag() == 1)      \
    {                                         \
        return retVal;                        \
    }

static UINT32 RfCfgGetMaxChnlSum(UINT32 dir);
static UINT32 unfixCalcCenterFreq(T_RfCfgPara *pRfCfgPara);
static UINT32 fixedCalcCenterFreq(UINT32 dir,UINT32 bspChnl,T_RfCfgPara *pRfCfgPara);
static UINT32 RxRfPllCfgInit(UINT32 bspChan, T_RfPllCfgInit *pPara);
static UINT32 UnfixCalcCenterFreqUpdate(UINT32 dir, UINT32 bspChnl, T_RfCfgPara *pRfCfgPara);
static UINT32 NeedCalcLoFreqFlag(UINT32 dir, UINT32 bspChnl, T_RfCfgPara *pRfCfgPara);
static UINT32 UpdateCenterFreq(UINT32 dir, T_RfCfgPara *pRfCfgPara);
static UINT32 UnfixCalcCenterFreqFromBoard(UINT32 dir,UINT32 bspChnl,T_RfCfgPara *pRfCfgPara);
UINT32 BspSetCarrSwitch(UINT32 chan,UINT32 radio,UINT32 carr,UINT32 trx,UINT32 isOn);

T_ChanNcoInfo s_saveNcoInfo[PRX][BSP_IC4_DIF_CHAN_NUM] = {0};
static UINT32 s_ulLteSubFrameRatio = 2;    /*9124 机型使用 修改默认值解决插损测量时此参数还未下发问题*/
static UINT32 s_ulSpecSubFramRatio = 7;

UINT32 BspSaveNcoCarrInfo(UINT32 dir,UINT32 loop, UINT32 difChan,UINT32 radioMode,UINT32 carrNo,UINT32 carrNco, UINT32 carrBandNo,INT32 bandNco)
{
    if(dir>=PRX || difChan >= BSP_IC4_DIF_CHAN_NUM  || loop >= BSP_MAX_CARR_NUM)
    {
       return BSP_ERROR;
    }
    s_saveNcoInfo[dir][difChan].carrNcoInfo[loop].radioMode = radioMode;
    s_saveNcoInfo[dir][difChan].carrNcoInfo[loop].carrNo = carrNo;
    s_saveNcoInfo[dir][difChan].carrNcoInfo[loop].carrNco = carrNco;
    s_saveNcoInfo[dir][difChan].carrNcoInfo[loop].carrBandNo = carrBandNo;
    s_saveNcoInfo[dir][difChan].carrNcoInfo[loop].bandNco = bandNco;

    return BSP_OK;
}

INT32 BspGetBandNcoCfg(UINT32 dir, UINT32 difChan, UINT32 carrNo, UINT32 radioMode)
{
	UINT32 loop = 0;
    if(dir>=PRX || difChan >= BSP_IC4_DIF_CHAN_NUM )
    {
       return BSP_ERROR;
    }
    for(loop = 0; loop < BSP_MAX_CARR_NUM; loop++)
    {
    	if((s_saveNcoInfo[dir][difChan].carrNcoInfo[loop].radioMode ==radioMode)&&(s_saveNcoInfo[dir][difChan].carrNcoInfo[loop].carrNo == carrNo) )
    	{
    		dbgInfoEx("%s dir %d, difChan %d, carrNo %d, radioMode 0x%x bandNco %d\n",__FUNCTION__,dir, difChan, carrNo, radioMode, s_saveNcoInfo[dir][difChan].carrNcoInfo[loop].bandNco);
    		return s_saveNcoInfo[dir][difChan].carrNcoInfo[loop].bandNco;
    	}
    }
    return BSP_ERROR;
}

UINT32 BspSetTxCarrNcoOffset(UINT32 difChan, UINT32 carrNo, UINT32 radioMod, INT32 carrNco)
{
    UINT32 retVal = BSP_OK;
    INT32 ncoFront = 0;
    INT32 ncoFi = 0;

    retVal |= BspGetFilterNcoFront(difChan, carrNo, radioMod, &ncoFront);
    retVal |= BspGetCfrFreqFiOffset(difChan, carrNo, radioMod, &ncoFi);

    if ((BSP_OK == retVal) && (ncoFront != 0))
    {
        if (BSP_RADIO_STANDARD_UMTS == radioMod)
        {
            retVal |= BspHalAdaptSetUmtsDlNcoBehind(difChan, carrNo, radioMod, ncoFi);
        }
        else
        {
            retVal |= BspHalAdaptSetTxCarrCfirNcoBehind(difChan, carrNo, radioMod, ncoFi);
        }

        BspLog(LOG_LEVEL_0,"[%s]: difChan'%d, carrNo'%d, radioMod'0x%x, carrNco'%d, ncoFront'%d, ncoFi'%d, retVal'%d\n",
                    __FUNCTION__, difChan, carrNo, radioMod, carrNco, ncoFront, ncoFi, retVal);
        dbgInfoEx("[%s]: difChan'%d, carrNo'%d, radioMod'0x%x, carrNco'%d, ncoFront'%d, ncoFi'%d, retVal'%d\n",
                    __FUNCTION__, difChan, carrNo, radioMod, carrNco, ncoFront, ncoFi, retVal);

        return retVal;
    }

    retVal = BspHalAdaptSetTxCarrNco(difChan, radioMod, carrNo, carrNco);

    dbgInfoEx("[%s]: difChan'%d, carrNo'%d, radioMod'0x%x, carrNco'%d, retVal'%d\n",
                __FUNCTION__, difChan, carrNo, radioMod, carrNco, retVal);

    return retVal;
}

INT32 BspGetCarrNcoCfg(UINT32 dir, UINT32 difChan, UINT32 carrNo, UINT32 radioMode)
{
	UINT32 loop = 0;
    if(dir>=PRX || difChan >= BSP_IC4_DIF_CHAN_NUM )
    {
       return BSP_ERROR;
    }
    for(loop = 0; loop < BSP_MAX_CARR_NUM; loop++)
    {
    	if((s_saveNcoInfo[dir][difChan].carrNcoInfo[loop].radioMode ==radioMode)&&(s_saveNcoInfo[dir][difChan].carrNcoInfo[loop].carrNo == carrNo) )
    	{
    		dbgInfoEx("%s dir %d, difChan %d, carrNo %d, radioMode 0x%x carrNco %d\n",__FUNCTION__,dir, difChan, carrNo, radioMode, s_saveNcoInfo[dir][difChan].carrNcoInfo[loop].carrNco);
    		return s_saveNcoInfo[dir][difChan].carrNcoInfo[loop].carrNco;
    	}
    }
    return BSP_ERROR;
}

/* 查询（单边滤波存储的带宽==11M）&&（载波制式==NR），则取单边滤波的11M带宽配置给DSP；条件不满足时，则取大包配置中的带宽给DSP */
UINT32 BspGetFilterCarrBw(UINT32 dir, UINT32 bspChan, UINT32 carrNo, UINT32 carrRadio, UINT32 cfgBw)
{
    UINT32 ret = BSP_OK;
    UINT32 chipId = 0;
    UINT32 difChan = 0;
    T_carrFilterPara carrPara = {0};

    if ((dir >= PRX) || (carrNo >= BSP_MAX_CARR_NUM))
    {
        return cfgBw;
    }

    ret |= BspGetDifInfoByBspChn(bspChan, dir, &chipId, &difChan);

    if (TX == dir)
    {
        ret = BspGetPublicDlFilterPara(bspChan, carrNo, carrRadio, &carrPara);
    }
    else
    {
        ret = BspGetPublicUlFilterPara(bspChan, carrNo, carrRadio, &carrPara);
    }

    if (BSP_OK != ret)
    {
        return cfgBw;
    }

    if (BSP_OK == BspJudgeCarrFilter(difChan, dir, carrNo, carrRadio))
    {
        return carrPara.rcfbandwidth;
    }

    return cfgBw;
}

/* 查询（单边滤波存储的带宽==11M）&&（载波制式==NR），则取单边滤波的nco2配置给DSP；条件不满足时，则取大包配置记录的banknco给DSP */
INT32 BspGetFilterCarrNco(UINT32 dir, UINT32 bspChan, UINT32 carrNo, UINT32 carrRadio, INT32 bankNco)
{
    UINT32 ret = BSP_OK;
    UINT32 chipId = 0;
    UINT32 difChan = 0;
    T_carrFilterPara carrPara = {0};

    if ((dir >= PRX) || (carrNo >= BSP_MAX_CARR_NUM))
    {
        return bankNco;
    }

    ret |= BspGetDifInfoByBspChn(bspChan, dir, &chipId, &difChan);

    if (TX == dir)
    {
        ret = BspGetPublicDlFilterPara(bspChan, carrNo, carrRadio, &carrPara);
    }
    else
    {
        ret = BspGetPublicUlFilterPara(bspChan, carrNo, carrRadio, &carrPara);
    }

    if (BSP_OK != ret)
    {
        return bankNco;
    }

    if (BSP_OK == BspJudgeCarrFilter(difChan, dir, carrNo, carrRadio))
    {
        return carrPara.nco2;
    }

    return bankNco;
}

/* 查询单边滤波存在，则取单边滤波的bankNco - carrPara.nco1配置给DSP；条件不满足时，则取大包配置记录的banknco给DSP */
INT32 BspGetFilterBankNco(UINT32 dir, UINT32 bspChan, UINT32 carrNo, UINT32 carrRadio, INT32 bankNco)
{
    UINT32 ret = BSP_OK;
    T_carrFilterPara carrPara = {0};

    // 检查方向和载波编号是否有效
    if (dir >= PRX || carrNo >= BSP_MAX_CARR_NUM)
    {
        return bankNco;
    }

    // 根据方向获取相应的滤波参数
    if (TX == dir)
    {
        ret = BspGetPublicDlFilterPara(bspChan, carrNo, carrRadio, &carrPara);
    }
    else
    {
        ret = BspGetPublicUlFilterPara(bspChan, carrNo, carrRadio, &carrPara);
    }

    // 如果获取滤波参数失败，返回原始bankNco
    if (BSP_OK != ret)
    {
        return bankNco;
    }

    return (bankNco - carrPara.nco1);
}


INT32 BspGetCarrCarrBankNcoCfg(UINT32 dir, UINT32 difChan, UINT32 carrNo, UINT32 radioMode)
{
	UINT32 ulRet = 0;
	INT32 BandNco = 0;
	INT32 BankNco = 0;

	if(dir>=PRX || difChan >= BSP_IC4_DIF_CHAN_NUM || carrNo >= BSP_MAX_CARR_NUM)
	{
	   return BSP_ERROR;
	}

	ulRet = IcHalApiGetRxBandNco(difChan, carrNo, radioMode, &BandNco, &BankNco);

	if(BSP_OK == ulRet)
	{
		return BankNco;
	}

	return BSP_ERROR;
}

INT32 BspGetCarrCarrBandNcoCfg(UINT32 dir, UINT32 difChan, UINT32 carrNo, UINT32 radioMode)
{
	UINT32 ulRet = 0;
	INT32 BandNco = 0;
	INT32 BankNco = 0;

	if(dir>=PRX || difChan >= BSP_IC4_DIF_CHAN_NUM || carrNo >= BSP_MAX_CARR_NUM)
	{
	   return BSP_ERROR;
	}

	ulRet = IcHalApiGetRxBandNco(difChan, carrNo, radioMode, &BandNco, &BankNco);

	if(BSP_OK == ulRet)
	{
		return BandNco;
	}

	return BSP_ERROR;
}
/**********************************************************************
* 函数名称: pGetRfPllCfgHandle
* 功能描述: 获取单板下配频模块初始化信息的结构体指针
* 输入参数: dir 上行/下行
* 输出参数: 无
* 返  回  值: ptRfPllCfgInit配频模块初始化信息的结构体指针
************************************************************************/
T_RfPllCfgInit *pGetRfPllCfgHandle(UINT32 dir)
{
    T_RfPllCfgInit *ptRfPllCfgInit = NULL;

    if (TX == dir)
    {
        ptRfPllCfgInit = txRfPllCfgInit;
    }
    else
    {
        ptRfPllCfgInit = rxRfPllCfgInit;
    }

    return ptRfPllCfgInit;
}

/**********************************************************************
* 函数名称: BspGetRfCfgNcoStep
* 功能描述: 获取单板下配频模块初始化信息的结构体指针
* 输入参数: dir 上行/下行
* 输出参数: 无
* 返  回  值: ulNcoStepKHz 获取NCO步进
************************************************************************/
static UINT32 BspGetRfCfgNcoStep(UINT32 ulTrxType, UINT32 ulBspChnl)
{
    UINT32 ulNcoStepKHz = 0;
    T_RfPllCfgInit *ptRfPllCfgInit = NULL;

    ptRfPllCfgInit = pGetRfPllCfgHandle(ulTrxType);
    if (NULL != ptRfPllCfgInit)
    {
        ulNcoStepKHz = ptRfPllCfgInit[ulBspChnl].ncoStep;
    }
    else

    {
        ulNcoStepKHz = BSP_ERROR;
    }

    if (0 == ulNcoStepKHz)
    {
        ulNcoStepKHz = BSP_ERROR;
    }

    return ulNcoStepKHz;
}

/**********************************************************************
* 函数名称: BspInitRruDifCfgBankNcoPara
* 功能描述: 中频BandNco参与计算前的赋值
* 输入参数: bspChan bsp通道
* 输出参数: 无
* 返  回  值: BSP_OK/BSP_ERROR
************************************************************************/
UINT32 BspInitRruDifCfgBankNcoPara(UINT32 bspChan, UINT32 dir)
{
    UINT32 bspChanNum = 0;
    if(TX == dir)
    {
        bspChanNum = BspGetTxBspChanNum();
        if (bspChan >= bspChanNum)
        {
            return BSP_ERROR;
        }
    }
    else
    {
        bspChanNum = BspGetRxBspChanNum();
        if (bspChan >= bspChanNum)
        {
            return BSP_ERROR;
        }
    }
    
	T_DPD_UL_FB_BAND_NCO_INFO *pDpdUlFbBandNco = NULL;

    BspBandNcoFreqInit();
    pDpdUlFbBandNco = BspGetDpdUlFbBandNco();
    
    if(NULL != pDpdUlFbBandNco)
	{
        if(TX == dir)
        {
    	    pDpdUlFbBandNco[TX].bandNcoInfo[bspChan] =  txRfPllCfgInit[bspChan].bandNcoBase;
            dbgInfoEx(" bspChan:%d TX-BandNco:%d", bspChan, pDpdUlFbBandNco[TX].bandNcoInfo[bspChan]);
        }
        else if (RX == dir)
        {
            pDpdUlFbBandNco[RX].bandNcoInfo[bspChan] =  rxRfPllCfgInit[bspChan].bandNcoBase;
            dbgInfoEx(" bspChan:%d RX-BandNco:%d", bspChan, pDpdUlFbBandNco[RX].bandNcoInfo[bspChan]);
        }
	}
    return BSP_OK;    
}
/**********************************************************************
* 函数名称: RxRfPllCfgInit
* 功能描述: 单板下行配频初始化信息传递给全局结构体rxRfPllCfgInit
* 输入参数: bspChan bsp通道， pPara 上行配频信息
* 输出参数: 无
* 返  回  值: BSP_OK/BSP_ERROR
************************************************************************/
static UINT32 RxRfPllCfgInit(UINT32 bspChan, T_RfPllCfgInit *pPara)
{
    UINT32 rxNum = BspGetRxBspChanNum();
    if (bspChan >= rxNum)
    {
        return BSP_ERROR;
    }

    if (NULL == rxRfPllCfgInit)
    {
        rxRfPllCfgInit = malloc(sizeof(T_RfPllCfgInit)*rxNum);
        INPUT_POINTER_CHECK(rxRfPllCfgInit);
    }

    memcpy_s(&rxRfPllCfgInit[bspChan], sizeof(T_RfPllCfgInit), pPara, sizeof(T_RfPllCfgInit));
    if (NULL == BspGetRfFreqNcoStepCallBack())
    {
        BspSetRfFreqNcoStepCallBack((pGetRfFreqNcoStep)BspGetRfCfgNcoStep);
    }
    BspInitRruDifCfgBankNcoPara(bspChan, RX);
    return BSP_OK;
}

/**********************************************************************
* 函数名称: TxRfPllCfgInit
* 功能描述: 单板上行配频初始化信息传递给全局结构体rxRfPllCfgInit
* 输入参数: bspChan bsp通道， pPara 上行配频信息
* 输出参数: 无
* 返  回  值: BSP_OK/BSP_ERROR
************************************************************************/
static UINT32 TxRfPllCfgInit(UINT32 bspChan, T_RfPllCfgInit *pPara)
{
    UINT32 txNum = BspGetTxBspChanNum();
    if (bspChan >= txNum)
    {
        return BSP_ERROR;
    }

    if (NULL == txRfPllCfgInit)
    {
        txRfPllCfgInit = malloc(sizeof(T_RfPllCfgInit)*txNum);
        INPUT_POINTER_CHECK(txRfPllCfgInit);
    }

    memcpy(&txRfPllCfgInit[bspChan], pPara, sizeof(T_RfPllCfgInit));
    if (NULL == BspGetRfFreqNcoStepCallBack())
    {
        BspSetRfFreqNcoStepCallBack((pGetRfFreqNcoStep)BspGetRfCfgNcoStep);
    }
    BspInitRruDifCfgBankNcoPara(bspChan, TX);
    return BSP_OK;
}

/**********************************************************************
* 函数名称: BspRfPllCfgInit
* 功能描述: 将所有单板配频初始化信息传递给全局结构体rx/txRfPllCfgInit
* 输入参数: bspChan bsp通道， pPara 上行配频信息
* 输出参数: 无
* 返  回  值: BSP_OK/BSP_ERROR
************************************************************************/
UINT32 BspRfPllCfgInit(UINT32 bspChan, UINT32 dir, T_RfPllCfgInit *pPara)
{
    INPUT_POINTER_CHECK(pPara);
    UINT32 retVal = BSP_OK;

    if (pPara->loStep == 0)
    {
        return BSP_ERROR;
    }

    if (dir == TX)
    {
        retVal = TxRfPllCfgInit(bspChan, pPara);
    }
    else
    {
        retVal = RxRfPllCfgInit(bspChan, pPara);
    }

    return retVal;
}

/* 调用BspUpdatePaptAvgPowInfo的回调函数指针，单独封装用于避免圈复杂度增加 */
static UINT32 BspCallUpdatePaptAvgPowFunc(UINT32 bspChan)
{
    UINT32 retVal = BSP_OK;

    if(NULL != s_pFuncUpdatePaptAvgPowInfo)
    {
        retVal = s_pFuncUpdatePaptAvgPowInfo(bspChan);  /* 功放保护均值门限更新 */
    }

    return retVal;
}

static UINT32 saveBspLogFreqRfCfg(UINT32 trx, UINT32 chan, T_RfCfgPara *pRfCfgPara)
{
    UINT32 loop = 0;

    INPUT_POINTER_CHECK(pRfCfgPara);

    BspLog(LOG_LEVEL_0,"freq: %s: chan[%d], carrNum{%d}. \n",__FUNCTION__,chan, pRfCfgPara->carrNum);
    for(loop = 0; loop < pRfCfgPara->carrNum; loop ++)
    {
        if(trx == TX)
        {
            BspLog(LOG_LEVEL_0,"freq: %s: ---TX--- chan[%d], carrInfoCapacity[%d], carrNo[%d], radioMode[%d], freq[%d], bandWidth[%d], cfgFlag[%d], freqOffset[%d], difIfType[%d]. \n",
                    __FUNCTION__,chan, pRfCfgPara->carrInfoCapacity,pRfCfgPara->carrInfo[loop].carrNo, pRfCfgPara->carrInfo[loop].radioMode, pRfCfgPara->carrInfo[loop].freq,
                    pRfCfgPara->carrInfo[loop].bandWidth, pRfCfgPara->carrInfo[loop].cfgFlag, pRfCfgPara->carrInfo[loop].freqOffset, pRfCfgPara->carrInfo[loop].difIfType);
        }
        else
        {
            BspLog(LOG_LEVEL_0,"freq: %s: ---RX--- chan[%d], carrInfoCapacity[%d], carrNo[%d], radioMode[%d], freq[%d], bandWidth[%d], cfgFlag[%d], freqOffset[%d], difIfType[%d]. \n",
                    __FUNCTION__,chan, pRfCfgPara->carrInfoCapacity,pRfCfgPara->carrInfo[loop].carrNo, pRfCfgPara->carrInfo[loop].radioMode, pRfCfgPara->carrInfo[loop].freq, pRfCfgPara->carrInfo[loop].bandWidth,
                    pRfCfgPara->carrInfo[loop].cfgFlag, pRfCfgPara->carrInfo[loop].freqOffset, pRfCfgPara->carrInfo[loop].difIfType);
        }
    }

    return BSP_OK;
}

UINT32 BspOpenCarrSwitchNcr(UINT32 chan, T_RfCfgPara *pRfCfgPara, UINT32 dir)
{
    UINT32 loop = 0;
    UINT32 retVal = 0;

    if(IS_NCR == BspIsNcr())
    {
        for(loop = 0; loop < pRfCfgPara->carrNum; loop++)
        {
            retVal = BspSetCarrSwitch(chan, pRfCfgPara->carrInfo[loop].radioMode, pRfCfgPara->carrInfo[loop].carrNo, dir, SWITCH_ON);
            CHECK_RETVAL(BspSetCarrSwitch, retVal);
        }
    }

    return BSP_OK;
}

/**********************************************************************
* 函数名称: BspSetTxRfCfg
* 功能描述: 根据下发的通道内载波信息配置下行NCO和本振频点
* 输入参数: chan 通道号，pRfCfgPara 配频单通道所有载波信息
* 输出参数: 无
* 返  回  值: BSP_OK / BSP_ERROR
************************************************************************/
/* Started by AICoder, pid:hff717579472bc8148d209550106f8360f533073 */
UINT32 BspSetTxRfCfg(UINT32 chan, T_RfCfgPara *pRfCfgPara)
{
    UINT32 retVal = BSP_OK;
    UINT32 bspChan = 0;
    UINT32 maxChanNum = 0;
    UINT32 maxCarrNum = 0;
    UINT32 loFreq = 0;
    UINT32 centFreq = 0;
    UINT32 loop = 0;
    FUNC_CALLED_AFTER_FREQCFG pFuncAfterFreqcfg = NULL;
    T_RfFreqCfgFailCarrInfoChan ptFreqCfgFailCarrInfoChan = {0};

    BspLog(LOG_LEVEL_0,"%s enter\n", __FUNCTION__);
    PARAM_POINTER_NULL_CHK_WITH_RET(ERROR_INVALID_PARA, pTxRfCfgParam, pRfCfgPara);
    freqCfgExLog(FREQCFG_RFCFG,"\n%s>>TxChnl'%d Start, CarrNum %d\n", __FUNCTION__, chan, pRfCfgPara->carrNum);

    maxChanNum = BspGetTxChannel();
    maxCarrNum = BspGetBspCarrNum();

    saveBspLogFreqRfCfg(TX, chan, pRfCfgPara);

    if (chan >= maxChanNum)
    {
        BspLog(LOG_LEVEL_0,"%s>>Error! ChanNo Over range; Chan(0~%d)= %d\n",
               __FUNCTION__, maxChanNum - 1, chan);
        return BSP_ERROR;
    }

    if (pRfCfgPara->carrNum > maxCarrNum)
    {
        BspLog(LOG_LEVEL_0,"%s>>Error! CarrNo Over range; Carr(0~%d)= %d\n",
               __FUNCTION__, maxCarrNum - 1, chan);
        return BSP_ERROR;
    }

    retVal |= BspGetBspChnByRfChn(chan, TX, &bspChan);
    if (BSP_OK != retVal)
    {
        BspLog(LOG_LEVEL_0,"%s>>TxChnl'%d BspGetBspChnByRfChn Get Error!\n",
               __FUNCTION__, chan);
        return BSP_ERROR;
    }
    retVal |= BspAddRfCfgPara(bspChan, TX, pRfCfgPara);
    if (BSP_OK != retVal)
    {
        BspLog(LOG_LEVEL_0,"%s>>TxChnlbspChan(%d) RfCfgParam Add Error!\n", __FUNCTION__, bspChan);
        return BSP_ERROR;
    }

    if ((pRfCfgPara->carrNum == 0))
    {
        retVal |= BspClrRruRfCfgPara(bspChan, TX);
        BspLog(LOG_LEVEL_0,"%s>>Error! TxCarrNum = %d; Chan = %d\n",__FUNCTION__, pRfCfgPara->carrNum, chan);
        return BSP_OK;
    }

    retVal |= BspCfgBand(chan, TX, pRfCfgPara);
    if (BSP_OK != retVal)
    {
        BspLog(LOG_LEVEL_0,"%s>>TxChnlbspChan(%d) BspCfgBand Error!\n", __FUNCTION__, bspChan);
    }

    if (BspGetCenterFreqSrc(TX, bspChan) == 1)
    {
        centFreq = BspGetCenterFreq(TX, chan);
                BspLog(LOG_LEVEL_0,"[%s]from app,centFreq is %d \n",__FUNCTION__, centFreq);
    }
    else
    {
        centFreq = CalcCenterFreq(TX, bspChan, pRfCfgPara);
        BspRecordCenterFreq(TX, bspChan, centFreq);
                BspLog(LOG_LEVEL_0,"[%s]from loacal, centFreq is %d  \n", __FUNCTION__, centFreq);
    }

    if ((centFreq == 0) || ( centFreq == BSP_ERROR))
    {
        BspLog(LOG_LEVEL_0,"%s>>TxChnl'%d CenterFreq'%d Get Error!\n",
               __FUNCTION__, chan, centFreq);
        return BSP_ERROR;
    }

    if (BspGetLoFreqSrc(TX, bspChan) == 1)
    {
        loFreq = BspGetLoFreqChanged(TX, chan);

        if ((0 == loFreq) || (BSP_ERROR == loFreq))
        {
            BspLog(LOG_LEVEL_0,"%s>>TxChnl'%d LoFreq'%d Get Error!\n",
                   __FUNCTION__, chan, loFreq);
            return BSP_ERROR;
        }
    }

    freqCfgExLog(FREQCFG_RFCFG,"%s>>TxChnl'%d bspChan'%d centFreq'%d loFreq'%d \n", __FUNCTION__, chan, bspChan, centFreq, loFreq);

    retVal |= BspInitRruCfgPara(chan, TX);
    CHECK_SUPPORT_MGR_FREQ_FLAG(retVal);
    if (retVal == BSP_OK)
    {
        retVal |= CfgTxRfPll(bspChan, centFreq, loFreq);
        retVal |= CfgTxNco(bspChan, centFreq, pRfCfgPara, &ptFreqCfgFailCarrInfoChan);
        if (retVal != BSP_OK)
        {
            BspLog(LOG_LEVEL_0,"%s>>TxChnl'%d RfPll&Nco Cfg Error!\n", __FUNCTION__, chan);
        }
    }
    else
    {
        BspLog(LOG_LEVEL_0,"%s>>TxChnl'%d InitRruCfgPara Check Error!\n", __FUNCTION__, chan);
    }

    retVal |= BspInitRruTxDifCfgPara(chan);
    if(retVal != BSP_OK)
    {
        BspLog(LOG_LEVEL_0,"%s>>BspInitRruTxDifCfgPara chan=%d Error!\n", __FUNCTION__, chan);
    }

    //执行预先挂接好的需要在配频后执行的其他处理
    for(loop=0; loop<FUNC_AFTER_FREQCFG_INDEX_MAX; loop++)
    {
        pFuncAfterFreqcfg = s_pFuncCalledAfterFreqcfg[TX][loop];
        if(NULL != pFuncAfterFreqcfg)
        {
            retVal |= pFuncAfterFreqcfg(chan, NULL);
            if(retVal != BSP_OK)
            {
                BspLog(LOG_LEVEL_0,"%s>>pFuncAfterFreqcfg chan=%d Error!\n", __FUNCTION__, chan);
            }
        }
    }

    retVal |= BspCallUpdatePaptAvgPowFunc(bspChan);  /* 功放保护均值门限更新 */

    freqCfgExLog(FREQCFG_RFCFG,"%s>>TxChnl'%d End\n", __FUNCTION__, chan);
    BspLog(LOG_LEVEL_0,"%s chan=%d ret=%d exit\n", __FUNCTION__, chan, retVal);

    retVal |= BspOpenCarrSwitchNcr(chan, pRfCfgPara, TX);

    return retVal;
}

UINT32 BspSetTxRfCfgNew(UINT32 chan, T_RfCfgPara *pRfCfgPara, T_RfFreqCfgFailCarrInfoChan *ptFreqCfgFailCarrInfoChan)
{
    UINT32 retVal = BSP_OK;
    UINT32 bspChan = 0;
    UINT32 maxChanNum = 0;
    UINT32 maxCarrNum = 0;
    UINT32 loFreq = 0;
    UINT32 centFreq = 0;
    UINT32 loop = 0;
    FUNC_CALLED_AFTER_FREQCFG pFuncAfterFreqcfg = NULL;

    BspLog(LOG_LEVEL_0,"%s enter\n", __FUNCTION__);
    PARAM_POINTER_NULL_CHK_WITH_RET(ERROR_INVALID_PARA, pTxRfCfgParam, pRfCfgPara);
    freqCfgExLog(FREQCFG_RFCFG,"\n%s>>TxChnl'%d Start, CarrNum %d\n", __FUNCTION__, chan, pRfCfgPara->carrNum);

    INPUT_POINTER_CHECK(ptFreqCfgFailCarrInfoChan);

    maxChanNum = BspGetTxChannel();
    maxCarrNum = BspGetBspCarrNum();

    saveBspLogFreqRfCfg(TX, chan, pRfCfgPara);
    if (chan >= maxChanNum)
    {
        BspLog(LOG_LEVEL_0,"%s>>Error! ChanNo Over range; Chan(0~%d)= %d\n",
               __FUNCTION__, maxChanNum - 1, chan);
        return BSP_ERROR;
    }
    if (pRfCfgPara->carrNum > maxCarrNum)
    {
        BspLog(LOG_LEVEL_0,"%s>>Error! CarrNo Over range; Carr(0~%d)= %d\n",
               __FUNCTION__, maxCarrNum - 1, chan);
        return BSP_ERROR;
    }

    retVal |= BspGetBspChnByRfChn(chan, TX, &bspChan);
    if (BSP_OK != retVal)
    {
        BspLog(LOG_LEVEL_0,"%s>>TxChnl'%d BspGetBspChnByRfChn Get Error!\n",
               __FUNCTION__, chan);
        return BSP_ERROR;
    }
    retVal |= BspAddRfCfgPara(bspChan, TX, pRfCfgPara);
    if (BSP_OK != retVal)
    {
        BspLog(LOG_LEVEL_0,"%s>>TxChnlbspChan(%d) RfCfgParam Add Error!\n", __FUNCTION__, bspChan);
        return BSP_ERROR;
    }

    if ((pRfCfgPara->carrNum == 0))
    {
        retVal |= BspClrRruRfCfgPara(bspChan, TX);
        BspLog(LOG_LEVEL_0,"%s>>Error! TxCarrNum = %d; Chan = %d\n",__FUNCTION__, pRfCfgPara->carrNum, chan);
        return BSP_OK;
    }

    retVal |= BspCfgBand(chan, TX, pRfCfgPara);
    (VOID)BspJudgeRetureVal(retVal, LOG_LEVEL_0, "%s>>TxChnlbspChan(%d) BspCfgBand Error!\n", __FUNCTION__, bspChan);

    if (BspGetCenterFreqSrc(TX, bspChan) == 1)
    {
        centFreq = BspGetCenterFreq(TX, chan);
        BspLog(LOG_LEVEL_0,"[%s]from app,centFreq is %d \n",__FUNCTION__, centFreq);
    }
    else
    {
        centFreq = CalcCenterFreq(TX, bspChan, pRfCfgPara);
        BspRecordCenterFreq(TX, bspChan, centFreq);
        BspLog(LOG_LEVEL_0,"[%s]from loacal, centFreq is %d  \n", __FUNCTION__, centFreq);
    }

    if ((centFreq == 0) || ( centFreq == BSP_ERROR))
    {
        BspLog(LOG_LEVEL_0,"%s>>TxChnl'%d CenterFreq'%d Get Error!\n",
               __FUNCTION__, chan, centFreq);
        return BSP_ERROR;
    }

    if (BspGetLoFreqSrc(TX, bspChan) == 1)
    {
        loFreq = BspGetLoFreqChanged(TX, chan);

        if ((0 == loFreq) || (BSP_ERROR == loFreq))
        {
            BspLog(LOG_LEVEL_0,"%s>>TxChnl'%d LoFreq'%d Get Error!\n",
                   __FUNCTION__, chan, loFreq);
            return BSP_ERROR;
        }
    }

    freqCfgExLog(FREQCFG_RFCFG,"%s>>TxChnl'%d bspChan'%d centFreq'%d loFreq'%d \n", __FUNCTION__, chan, bspChan, centFreq, loFreq);

    retVal |= BspInitRruCfgPara(chan, TX);
    CHECK_SUPPORT_MGR_FREQ_FLAG(retVal);
    (VOID)BspJudgeRetureVal(retVal, LOG_LEVEL_0, "%s>>TxChnl'%d InitRruCfgPara Check Error!\n", __FUNCTION__, chan);
    if (retVal == BSP_OK)
    {
        retVal |= CfgTxRfPll(bspChan, centFreq, loFreq);
        retVal |= CfgTxNco(bspChan, centFreq, pRfCfgPara, ptFreqCfgFailCarrInfoChan);
        (VOID)BspJudgeRetureVal(retVal, LOG_LEVEL_0, "%s>>TxChnl'%d RfPll&Nco Cfg Error!\n", __FUNCTION__, chan);
    }

    retVal |= BspInitRruTxDifCfgPara(chan);
    (VOID)BspJudgeRetureVal(retVal, LOG_LEVEL_0, "%s>>BspInitRruTxDifCfgPara chan=%d Error!\n", __FUNCTION__, chan);

    //执行预先挂接好的需要在配频后执行的其他处理
    for(loop=0; loop<FUNC_AFTER_FREQCFG_INDEX_MAX; loop++)
    {
        pFuncAfterFreqcfg = s_pFuncCalledAfterFreqcfg[TX][loop];
        if(NULL != pFuncAfterFreqcfg)
        {
            retVal |= pFuncAfterFreqcfg(chan, NULL);
            (VOID)BspJudgeRetureVal(retVal, LOG_LEVEL_0, "%s>>pFuncAfterFreqcfg chan=%d Error!\n", __FUNCTION__, chan);
        }
    }

    retVal |= BspCallUpdatePaptAvgPowFunc(bspChan);  /* 功放保护均值门限更新 */

    freqCfgExLog(FREQCFG_RFCFG,"%s>>TxChnl'%d End\n", __FUNCTION__, chan);
    BspLog(LOG_LEVEL_0,"%s chan=%d ret=%d exit\n", __FUNCTION__, chan, retVal);

    retVal |= BspOpenCarrSwitchNcr(chan, pRfCfgPara, TX);

    return retVal;
}

/* Ended by AICoder, pid:hff717579472bc8148d209550106f8360f533073 */
UINT32 BspSetTxRfCfgUwb(UINT32 chan, T_RfCfgPara *pRfCfgPara)
{
	return BspSetTxRfCfg(chan, pRfCfgPara);
}

/**********************************************************************
* 函数名称: BspSetRxRfCfg
* 功能描述: 根据下发的通道内载波信息配置上行NCO和本振频点
* 输入参数: chan 通道号，pRfCfgPara 配频单通道所有载波信息
* 输出参数: 无
* 返  回  值: BSP_OK / BSP_ERROR
************************************************************************/
UINT32 BspSetRxRfCfg(UINT32 chan, T_RfCfgPara *pRfCfgPara)
{
    UINT32 centFreq = 0;
    UINT32 bspChan = 0;
    UINT32 loFreq = 0;
    UINT32 maxChnlSum = 0;
    UINT32 maxCarrNum = 0;
    UINT32 retVal = BSP_OK;
    UINT32 loop = 0;
    FUNC_CALLED_AFTER_FREQCFG pFuncAfterFreqcfg = NULL;
    T_RfFreqCfgFailCarrInfoChan ptFreqCfgFailCarrInfoChan = {0};

    BspLog(LOG_LEVEL_0,"%s enter\n", __FUNCTION__);

    maxChnlSum = BspGetRxChannel();
    maxCarrNum = BspGetBspCarrNum();

    saveBspLogFreqRfCfg(RX, chan, pRfCfgPara);

    PARAM_POINTER_NULL_CHK_WITH_RET(ERROR_INVALID_PARA, pTxRfCfgParam, pRfCfgPara);

    freqCfgExLog(FREQCFG_RFCFG,"\n%s>>RxChnl'%d Start, CarrNum %d\n", __FUNCTION__, chan, pRfCfgPara->carrNum);

    if (chan >= maxChnlSum)
    {
        BspLog(LOG_LEVEL_0,"%s>>Error! ChnlNo Over range; Chnl(0~%d)= %d\n",
               __FUNCTION__, maxChnlSum - 1, chan);
        return BSP_ERROR;
    }

    if (pRfCfgPara->carrNum > maxCarrNum)
    {
        BspLog(LOG_LEVEL_0,"%s>>Error! CarrNo Over range; Carr(0~%d)= %d\n",
               __FUNCTION__, maxCarrNum - 1, chan);
        return BSP_ERROR;
    }

    retVal |= BspGetBspChnByRfChn(chan, RX, &bspChan);
    if (BSP_OK != retVal)
    {
        BspLog(LOG_LEVEL_0,"%s>>TxChnl'%d BspGetBspChnByRfChn Get Error!\n",
               __FUNCTION__, chan);
        return BSP_ERROR;
    }

    retVal |= BspAddRfCfgPara(bspChan, RX, pRfCfgPara);
    if (BSP_OK != retVal)
    {
        BspLog(LOG_LEVEL_0,"%s>>RxChnlbspChan(%d) RfCfgParam Add Error!\n", __FUNCTION__, bspChan);
        return BSP_ERROR;
    }

    if (pRfCfgPara->carrNum == 0)
    {
        retVal |= BspClrRruRfCfgPara(bspChan, RX);
        BspLog(LOG_LEVEL_0,"%s>>Error! RxCarrNum = %d; Chan = %d\n", __FUNCTION__, pRfCfgPara->carrNum, chan);
        return BSP_OK;
    }

    retVal |= BspCfgBand(chan, RX, pRfCfgPara);
    if (BSP_OK != retVal)
    {
        BspLog(LOG_LEVEL_0,"%s>>RxChnlbspChan(%d) BspCfgBand Error!\n", __FUNCTION__, bspChan);
    }

    if (BspGetCenterFreqSrc(RX, bspChan) == 1)
    {
        centFreq = BspGetCenterFreq(RX, chan);
        dbgInfoEx("%s>>CenterFreqSrc = 1, chan %d \n", __FUNCTION__, chan);
    }
    else
    {
        centFreq = CalcCenterFreq(RX, bspChan, pRfCfgPara);
        BspRecordCenterFreq(RX, bspChan, centFreq);
        dbgInfoEx("%s>>CenterFreqSrc != 1, chan %d \n", __FUNCTION__, chan);
    }
    if ((centFreq == 0) || ( centFreq == BSP_ERROR))
    {
        BspLog(LOG_LEVEL_0,"%s>>RxChnl'%d CenterFreq'%d Get Error!\n",
               __FUNCTION__, chan, centFreq);
        return BSP_ERROR;
    }

    if (BspGetLoFreqSrc(RX, bspChan) == 1)
    {
        loFreq = BspGetLoFreqChanged(RX, chan);

        if ((0 == loFreq) || (BSP_ERROR == loFreq))
        {
            BspLog(LOG_LEVEL_0,"%s>>TxChnl'%d LoFreq'%d Get Error!\n",
                   __FUNCTION__, chan, loFreq);
            return BSP_ERROR;
        }
    }

    freqCfgExLog(FREQCFG_RFCFG,"%s>>RxChnl'%d bspChan'%d centFreq'%d loFreq'%d \n", __FUNCTION__, chan, bspChan, centFreq, loFreq);

    retVal |= BspInitRruCfgPara(chan, RX);
    CHECK_SUPPORT_MGR_FREQ_FLAG(retVal);
    if (retVal == BSP_OK)
    {
        retVal |= CfgRxRfPll(bspChan, centFreq, loFreq);
        retVal |= CfgRxNco(bspChan, centFreq, pRfCfgPara, &ptFreqCfgFailCarrInfoChan);
        if (retVal != BSP_OK)
        {
            BspLog(LOG_LEVEL_0,"%s>>TxChnl'%d RfPll&Nco Cfg Error!\n", __FUNCTION__, chan);
        }
    }
    else
    {
        BspLog(LOG_LEVEL_0,"%s>>TxChnl'%d InitRruCfgPara Check Error!\n", __FUNCTION__, chan);
    }

    //执行预先挂接好的需要在配频后执行的其他处理
    for(loop=0; loop<FUNC_AFTER_FREQCFG_INDEX_MAX; loop++)
    {
        pFuncAfterFreqcfg = s_pFuncCalledAfterFreqcfg[RX][loop];
        if(NULL != pFuncAfterFreqcfg)
        {
            retVal |= pFuncAfterFreqcfg(chan, NULL);
            if(retVal != BSP_OK)
            {
                BspLog(LOG_LEVEL_0,"%s>>pFuncAfterFreqcfg chan=%d Error!\n", __FUNCTION__, chan);
            }
        }
    }

    freqCfgExLog(FREQCFG_RFCFG,"%s>>RxChnl'%d End\n", __FUNCTION__, chan);

    BspLog(LOG_LEVEL_0,"%s chan=%d ret=%d exit\n", __FUNCTION__, chan, retVal);

    retVal |= BspOpenCarrSwitchNcr(chan, pRfCfgPara, RX);

    return retVal;

}

UINT32 BspSetRxRfCfgNew(UINT32 chan, T_RfCfgPara *pRfCfgPara, T_RfFreqCfgFailCarrInfoChan *ptFreqCfgFailCarrInfoChan)
{
    UINT32 centFreq = 0;
    UINT32 bspChan = 0;
    UINT32 loFreq = 0;
    UINT32 maxChnlSum = 0;
    UINT32 maxCarrNum = 0;
    UINT32 retVal = BSP_OK;
    UINT32 loop = 0;
    FUNC_CALLED_AFTER_FREQCFG pFuncAfterFreqcfg = NULL;

    BspLog(LOG_LEVEL_0,"%s enter\n", __FUNCTION__);

    maxChnlSum = BspGetRxChannel();
    maxCarrNum = BspGetBspCarrNum();

    saveBspLogFreqRfCfg(RX, chan, pRfCfgPara);

    PARAM_POINTER_NULL_CHK_WITH_RET(ERROR_INVALID_PARA, pTxRfCfgParam, pRfCfgPara);
    INPUT_POINTER_CHECK(ptFreqCfgFailCarrInfoChan);

    freqCfgExLog(FREQCFG_RFCFG,"\n%s>>RxChnl'%d Start, CarrNum %d\n", __FUNCTION__, chan, pRfCfgPara->carrNum);

    if (chan >= maxChnlSum)
    {
        BspLog(LOG_LEVEL_0,"%s>>Error! ChnlNo Over range; Chnl(0~%d)= %d\n",
               __FUNCTION__, maxChnlSum - 1, chan);
        return BSP_ERROR;
    }

    if (pRfCfgPara->carrNum > maxCarrNum)
    {
        BspLog(LOG_LEVEL_0,"%s>>Error! CarrNo Over range; Carr(0~%d)= %d\n",
               __FUNCTION__, maxCarrNum - 1, chan);
        return BSP_ERROR;
    }

    retVal |= BspGetBspChnByRfChn(chan, RX, &bspChan);
    if (BSP_OK != retVal)
    {
        BspLog(LOG_LEVEL_0,"%s>>TxChnl'%d BspGetBspChnByRfChn Get Error!\n",
               __FUNCTION__, chan);
        return BSP_ERROR;
    }

    retVal |= BspAddRfCfgPara(bspChan, RX, pRfCfgPara);
    if (BSP_OK != retVal)
    {
        BspLog(LOG_LEVEL_0,"%s>>RxChnlbspChan(%d) RfCfgParam Add Error!\n", __FUNCTION__, bspChan);
        return BSP_ERROR;
    }

    if (pRfCfgPara->carrNum == 0)
    {
        retVal |= BspClrRruRfCfgPara(bspChan, RX);
        BspLog(LOG_LEVEL_0,"%s>>Error! RxCarrNum = %d; Chan = %d\n", __FUNCTION__, pRfCfgPara->carrNum, chan);
        return BSP_OK;
    }

    retVal |= BspCfgBand(chan, RX, pRfCfgPara);
    (VOID)BspJudgeRetureVal(retVal,LOG_LEVEL_0,"%s>>RxChnlbspChan(%d) BspCfgBand Error!\n", __FUNCTION__, bspChan);

    if (BspGetCenterFreqSrc(RX, bspChan) == 1)
    {
        centFreq = BspGetCenterFreq(RX, chan);
        dbgInfoEx("%s>>CenterFreqSrc = 1, chan %d \n", __FUNCTION__, chan);
    }
    else
    {
        centFreq = CalcCenterFreq(RX, bspChan, pRfCfgPara);
        BspRecordCenterFreq(RX, bspChan, centFreq);
        dbgInfoEx("%s>>CenterFreqSrc != 1, chan %d \n", __FUNCTION__, chan);
    }
    if ((centFreq == 0) || ( centFreq == BSP_ERROR))
    {
        BspLog(LOG_LEVEL_0,"%s>>RxChnl'%d CenterFreq'%d Get Error!\n",
               __FUNCTION__, chan, centFreq);
        return BSP_ERROR;
    }

    if (BspGetLoFreqSrc(RX, bspChan) == 1)
    {
        loFreq = BspGetLoFreqChanged(RX, chan);

        if ((0 == loFreq) || (BSP_ERROR == loFreq))
        {
            BspLog(LOG_LEVEL_0,"%s>>TxChnl'%d LoFreq'%d Get Error!\n",
                   __FUNCTION__, chan, loFreq);
            return BSP_ERROR;
        }
    }

    freqCfgExLog(FREQCFG_RFCFG,"%s>>RxChnl'%d bspChan'%d centFreq'%d loFreq'%d \n", __FUNCTION__, chan, bspChan, centFreq, loFreq);

    retVal |= BspInitRruCfgPara(chan, RX);
    CHECK_SUPPORT_MGR_FREQ_FLAG(retVal);
    (VOID)BspJudgeRetureVal(retVal,LOG_LEVEL_0,"%s>>TxChnl'%d InitRruCfgPara Check Error!\n", __FUNCTION__, chan);
    if (retVal == BSP_OK)
    {
        retVal |= CfgRxRfPll(bspChan, centFreq, loFreq);
        retVal |= CfgRxNco(bspChan, centFreq, pRfCfgPara, ptFreqCfgFailCarrInfoChan);
        (VOID)BspJudgeRetureVal(retVal,LOG_LEVEL_0,"%s>>TxChnl'%d RfPll&Nco Cfg Error!\n", __FUNCTION__, chan);
    }

    //执行预先挂接好的需要在配频后执行的其他处理
    for(loop=0; loop<FUNC_AFTER_FREQCFG_INDEX_MAX; loop++)
    {
        pFuncAfterFreqcfg = s_pFuncCalledAfterFreqcfg[RX][loop];
        if(NULL != pFuncAfterFreqcfg)
        {
            retVal |= pFuncAfterFreqcfg(chan, NULL);
            (VOID)BspJudgeRetureVal(retVal,LOG_LEVEL_0,"%s>>pFuncAfterFreqcfg chan=%d Error!\n", __FUNCTION__, chan);
        }
    }

    freqCfgExLog(FREQCFG_RFCFG,"%s>>RxChnl'%d End\n", __FUNCTION__, chan);

    BspLog(LOG_LEVEL_0,"%s chan=%d ret=%d exit\n", __FUNCTION__, chan, retVal);

    retVal |= BspOpenCarrSwitchNcr(chan, pRfCfgPara, RX);

    return retVal;

}

UINT32 BspSetRxRfCfgUwb(UINT32 chan, T_RfCfgPara *pRfCfgPara)
{
	return BspSetRxRfCfg(chan, pRfCfgPara);
}
/**********************************************************************
* 函数名称: CfgTxRfPll
* 功能描述: 根据计算的本振频点配置射频器件的本振
* 输入参数: bspChan BSP通道号，centFreq 中心频点，loFreq 本振频点
* 输出参数: 无
* 返  回  值: BSP_OK / BSP_ERROR
************************************************************************/
UINT32 CfgTxRfPll(UINT32 bspChan, UINT32 centFreq, UINT32 loFreq)
{
    INT32  ifFreq = 0;
    UINT32 loStep = 0;
    UINT32 ncoStep = 0;
    T_RfPllCfgInit *ptRfPllCfgInit = NULL;

    ptRfPllCfgInit = pGetRfPllCfgHandle(TX);
    INPUT_POINTER_CHECK(ptRfPllCfgInit);
    ifFreq  = ptRfPllCfgInit->ifFreq;
    loStep  = ptRfPllCfgInit->loStep;
    ncoStep = ptRfPllCfgInit->ncoStep;
    freqCfgExLog(FREQCFG_PLL,"%s:Start ifFreq %d loStep %d ncoStep %d, cfgSlotion %d\n",__FUNCTION__,
               ifFreq, loStep, ncoStep, ptRfPllCfgInit->cfgSolution);

    if (1 != BspGetLoFreqSrc(TX,bspChan))
    {
        if((ncoStep != BSP_FREQ_ZERO)&&(loStep != BSP_FREQ_ZERO))
        {
            if (ifFreq != 0)
            {
                loFreq = (centFreq - ifFreq) / ncoStep * ncoStep;
                loFreq = (loFreq / loStep * loStep);
            }
            else
            {
                loFreq = (centFreq / loStep * loStep);
            }
        }
        BspLog(LOG_LEVEL_0,"%s>> LoFreq %d !\n", __FUNCTION__, loFreq);
        BspRecordLoFreq(TX, bspChan, loFreq);
    }

    if ((ptRfPllCfgInit[bspChan].cfgSolution == BSP_FREQ_NO_CONFIGC_LO)
            || (ptRfPllCfgInit[bspChan].defLoFreqKHz0 == BSP_FREQ_DYNAMIC_LO))
    {
        return BSP_OK;
    }

    if (NULL == ptRfPllCfgInit[bspChan].pLoCfg)
    {
        dbgInfo("%s>>ptRfPllCfgInit[bspChan].pLoCfg is NULL,not config LO,"
                "return  Lo %d!\n", __FUNCTION__, loFreq);
        return BSP_OK;
    }

    if(NULL != ptRfPllCfgInit[bspChan].pLoGet)
    {
        if(loFreq == ptRfPllCfgInit[bspChan].pLoGet(bspChan))
        {
            freqCfgExLog(FREQCFG_PLL,"%s:loFreq%d\n",__FUNCTION__,loFreq);
            return BSP_OK;
        }
    }

    freqCfgExLog(FREQCFG_PLL,"%s End return Lo %d!\n", __FUNCTION__, loFreq);
    return ptRfPllCfgInit[bspChan].pLoCfg(bspChan,loFreq);
}

/**********************************************************************
* 函数名称: CfgRxRfPll
* 功能描述: 上行，根据计算的本振频点配置射频器件的本振
* 输入参数: bspChan BSP通道号，centFreq 中心频点，loFreq 本振频点
* 输出参数: 无
* 返  回  值: BSP_OK / BSP_ERROR
************************************************************************/
UINT32 CfgRxRfPll(UINT32 bspChan, UINT32 centFreq, UINT32 loFreq)
{
    INT32  ifFreq = 0;
    UINT32 loStep = 0;
    UINT32 ncoStep = 0;
    T_RfPllCfgInit *ptRfPllCfgInit = NULL;

    ptRfPllCfgInit = pGetRfPllCfgHandle(RX);
    INPUT_POINTER_CHECK(ptRfPllCfgInit);
    ifFreq  = ptRfPllCfgInit->ifFreq;
    loStep  = ptRfPllCfgInit->loStep;
    ncoStep = ptRfPllCfgInit->ncoStep;

    freqCfgExLog(FREQCFG_PLL,"%s:Start ifFreq %d loStep %d ncoStep %d, cfgSlotion %d\n",__FUNCTION__,
               ifFreq, loStep, ncoStep, ptRfPllCfgInit->cfgSolution);

    if (1 != BspGetLoFreqSrc(RX,bspChan))
    {
        if((ncoStep != BSP_FREQ_ZERO)&&(loStep != BSP_FREQ_ZERO))
        {
            if (ifFreq != 0)
            {
                loFreq = (centFreq - ifFreq) / ncoStep * ncoStep;
                loFreq = (loFreq / loStep * loStep);
            }
            else
            {
                loFreq = (centFreq / loStep * loStep);
            }
        }
        BspRecordLoFreq(RX, bspChan, loFreq);
    }

    if ((ptRfPllCfgInit[bspChan].cfgSolution == BSP_FREQ_NO_CONFIGC_LO)
            || (ptRfPllCfgInit[bspChan].defLoFreqKHz0 == BSP_FREQ_DYNAMIC_LO))
    {
        return BSP_OK;
    }

    if (NULL == ptRfPllCfgInit[bspChan].pLoCfg)
    {
        dbgInfo("%s>>ptRfPllCfgInit[bspChan].pLoCfg is NULL,not config LO,"
                "return  Lo %d!\n", __FUNCTION__, loFreq);
        return BSP_OK;
    }
    if(NULL != ptRfPllCfgInit[bspChan].pLoGet)
    {
        if(loFreq == ptRfPllCfgInit[bspChan].pLoGet(bspChan))
        {
            freqCfgExLog(FREQCFG_PLL,"%s:loFreq%d\n",__FUNCTION__,loFreq);
            return BSP_OK;
        }
    }
    freqCfgExLog(FREQCFG_PLL,"%s End return Lo %d!\n", __FUNCTION__, loFreq);
    return ptRfPllCfgInit[bspChan].pLoCfg(bspChan,loFreq);
}

/**********************************************************************
* 函数名称: RfCfgGetMaxChnlSum
* 功能描述: 获取单板支持的最大通道数
* 输入参数: dir 上行/下行
* 输出参数: 无
* 返  回  值: ulMaxChnlSum最大通道数
************************************************************************/
static UINT32 RfCfgGetMaxChnlSum(UINT32 dir)
{
    UINT32 ulMaxChnlSum = 0;

    if (dir == TX)
    {
        ulMaxChnlSum = BspGetTxBspChanNum();
    }
    else
    {
        ulMaxChnlSum = BspGetRxBspChanNum();
    }

    return ulMaxChnlSum;
}

/**********************************************************************
* 函数名称: CalcCarrAndCenterDif
* 功能描述: 计算所有载波边缘到中心频点的距离是否符合要求
* 输入参数: centerFreq 边缘频点，*freq 所有边缘频点结构体，freqNum 边缘频点个数
*         freqThre 距离范围，flag 最近/最远标志
* 输出参数: 无
* 返  回  值: NEED_RECALC_LO/NO_NEED_RECALC_LO
************************************************************************/
static UINT32 CalcCarrAndCenterDif(UINT32 centerFreq, UINT32 *freq, UINT32 freqNum,
        UINT32 freqThre, UINT32 flag)
{
    UINT32 loop = 0;
    UINT32 difFreq = 0;
    UINT32 carrNo = 0xFF;

    difFreq = freqThre;

    for (loop = 0; loop < freqNum; loop++)
    {
        if(flag  == 1)
        {
            if (difFreq > abs((INT32)freq[loop] -  (INT32)centerFreq))
            {
                difFreq = abs((INT32)freq[loop] -  (INT32)centerFreq);
                carrNo  = loop;
            }
        }
        else
        {
            if (difFreq < abs((INT32)freq[loop] -  (INT32)centerFreq))
            {
                difFreq = abs((INT32)freq[loop] -  (INT32)centerFreq);
                carrNo  = loop;
            }
        }
    }

    return carrNo;
}

/**********************************************************************
* 函数名称: NeedCalcLoFreqFlag
* 功能描述: 判断是否需要重新计算本振
* 输入参数: pRfCfgPara 配频单通道所有载波信息
* 输出参数: 无
* 返  回  值: NEED_RECALC_LO/NO_NEED_RECALC_LO
************************************************************************/
static UINT32 NeedCalcLoFreqFlag(UINT32 dir, UINT32 bspChnl, T_RfCfgPara *pRfCfgPara)
{
    UINT32 carr = 0;
    UINT32 lastCenterFreq = 0;
    UINT32 freqEdge[BSP_MAX_CARR_NUM * 2] = {0};
    UINT32 carrNo = 0;
    T_RfPllCfgInit *ptRfPllCfgInit = NULL;

    ptRfPllCfgInit = pGetRfPllCfgHandle(dir);
    INPUT_POINTER_CHECK(ptRfPllCfgInit);
    lastCenterFreq = BspGetCenterFreq(dir,bspChnl);

    dbgInfoEx("last center freq = %d\n", lastCenterFreq);

    /* 如果获取频点失败或者获取频点值为零，默认需要重新计算频点 */
    if((lastCenterFreq == 0 ) || (lastCenterFreq == BSP_ERROR ))
    {
        return NEED_RECALC_LO;
    }

    /* 当前本振是否在载波边缘,如果不是，则需要计算本振 */
    for (carr = 0; carr < pRfCfgPara->carrNum; carr++)
    {
        if( (abs(pRfCfgPara->carrInfo[carr].freq -  pRfCfgPara->carrInfo[carr].bandWidth/2) <=
                lastCenterFreq) &&
            (abs(pRfCfgPara->carrInfo[carr].freq +  pRfCfgPara->carrInfo[carr].bandWidth/2) >=
                lastCenterFreq) )
        {
            dbgInfoEx(" last calc lofreq between freq edge, need recalc lo\n");
            return NEED_RECALC_LO;
        }
    }

    /* 当前本振离所有载波有用信号是否小于等于100M, 如果不是，重新计算本振 */
    for (carr = 0; carr < pRfCfgPara->carrNum; carr++)
    {
        freqEdge[2*carr]   = pRfCfgPara->carrInfo[carr].freq - pRfCfgPara->carrInfo[carr].bandWidth/2;
        freqEdge[2*carr+1] = pRfCfgPara->carrInfo[carr].freq + pRfCfgPara->carrInfo[carr].bandWidth/2;
    }

    carrNo = CalcCarrAndCenterDif(lastCenterFreq, &freqEdge[0], pRfCfgPara->carrNum * 2,
            ptRfPllCfgInit[0].loToCarrThre,GET_FAR_FROM_CENTERFREQ);
    if (carrNo != 0xFF)
    {
        return NEED_RECALC_LO;
    }
    return NO_NEED_RECALC_LO;
}

/**********************************************************************
* 函数名称: unfixCalcCenterFreq
* 功能描述: 根据app下发的载波信息计算非固定无限制的中心频点
* 输入参数: pRfCfgPara 配频单通道所有载波信息
* 输出参数: 无
* 返  回  值: centerLoFreq中心频点
************************************************************************/
static UINT32 unfixCalcCenterFreq(T_RfCfgPara *pRfCfgPara)
{
    UINT32 carr = 0;
    UINT32 minFreq = 0xFFFFFFFF;
    UINT32 maxFreq = 0;
    UINT32 minIdx = 0, maxIdx = 0;
    UINT32 left = 0, right = 0;

    INPUT_POINTER_CHECK(pRfCfgPara);

    for (carr = 0; carr < pRfCfgPara->carrNum; carr++)
    {
        if (pRfCfgPara->carrInfo[carr].freq < minFreq)
        {
            minFreq = pRfCfgPara->carrInfo[carr].freq;
            minIdx  = carr;
        }
        if (pRfCfgPara->carrInfo[carr].freq > maxFreq)
        {
            maxFreq = pRfCfgPara->carrInfo[carr].freq;
            maxIdx  = carr;
        }
    }
    left = (minFreq - pRfCfgPara->carrInfo[minIdx].bandWidth);
    right= (maxFreq + pRfCfgPara->carrInfo[maxIdx].bandWidth);
    return (left + right) / 2;
}

/**********************************************************************
* 函数名称: fixedCalcCenterFreq
* 功能描述: 从单板下获取本振固定振频点，如果不需要配置LO则初始化时不要挂接tRxRfCfgInit.pLoCfg
* 输入参数: dir 上行/下行，bspChnl bsp通道号，pRfCfgPara 配频单通道所有载波信息
* 输出参数: 无
* 返  回  值: fixLoFreqKHz固定中心频点
************************************************************************/
static UINT32 fixedCalcCenterFreq(UINT32 dir,UINT32 bspChnl,T_RfCfgPara *pRfCfgPara)
{
    UINT32 trxType      = dir;
    UINT32 fixLoFreqKHz = 0;
    T_RfPllCfgInit *ptRfPllCfgInit = NULL;

    ptRfPllCfgInit = pGetRfPllCfgHandle(trxType);
    fixLoFreqKHz = ptRfPllCfgInit[bspChnl].defLoFreqKHz;

    return fixLoFreqKHz;
}

/**********************************************************************
* 函数名称: UpdateCenterFreq
* 功能描述: 更新不满足需求的中心频点
* 输入参数: pRfCfgPara 配频单通道所有载波信息
* 输出参数: 无
* 返  回  值: centerFreq中心频点
************************************************************************/
static UINT32 UpdateCenterFreq(UINT32 dir, T_RfCfgPara *pRfCfgPara)
{
    UINT32 carr = 0;
    UINT32 carrNo = 0, carrNoB = 0;
    UINT32 freqEdge[BSP_MAX_CARR_NUM * 2] = {0,};
    UINT32 dflFreq = 0, centerFreq = 0;
    UINT32 loStep = 0;
    UINT32 difFreq = 0xFFFFFFFF;
    T_RfPllCfgInit *ptRfPllCfgInit = NULL;

    ptRfPllCfgInit = pGetRfPllCfgHandle(dir);
    INPUT_POINTER_CHECK(ptRfPllCfgInit);
    loStep  = ptRfPllCfgInit[0].loStep;
    dflFreq = ptRfPllCfgInit[0].defLoFreqKHz;

    for (carr = 0; carr < pRfCfgPara->carrNum; carr++)
    {
        freqEdge[2*carr]   = pRfCfgPara->carrInfo[carr].freq - pRfCfgPara->carrInfo[carr].bandWidth/2;
        freqEdge[2*carr+1] = pRfCfgPara->carrInfo[carr].freq + pRfCfgPara->carrInfo[carr].bandWidth/2;
    }

    /* 步骤1. 找到离滤波器中心最近的载波边沿,作为中心频点 */
    carrNo = CalcCarrAndCenterDif(dflFreq, &freqEdge[0], pRfCfgPara->carrNum * 2,
            difFreq,GET_NEAR_FROM_CENTERFREQ);
    dbgInfoEx("first step calc freqEdgeNo = %d\n",carrNo);

    if (carrNo != 0xFF)
    {
        centerFreq = freqEdge[carrNo];
    }

    /* 步骤2. 判断此时的中心频点离所有载波的有用信号是否小于100m,如果不是，则重新计算中心频点 */
    carrNoB = CalcCarrAndCenterDif(centerFreq, &freqEdge[0], pRfCfgPara->carrNum * 2,
            ptRfPllCfgInit[0].loToCarrThre,GET_FAR_FROM_CENTERFREQ);
    dbgInfoEx("second step calc freqEdgeNo = %d\n",carrNoB);

    if (carrNoB != 0xFF)
    {
        centerFreq = (pRfCfgPara->carrInfo[carrNo/2].freq + pRfCfgPara->carrInfo[carrNoB/2].freq) /2 ;
    }

    centerFreq = centerFreq / loStep * loStep;

    return centerFreq;
}

/**********************************************************************
* 函数名称: UnfixCalcCenterFreqUpdate
* 功能描述: 非固定本振计算更新
* 输入参数: dir 上行/下行，bspChnl bsp通道号，pRfCfgPara 配频单通道所有载波信息
* 输出参数: 无
* 返  回  值: fixLoFreqKHz固定中心频点
************************************************************************/
static UINT32 UnfixCalcCenterFreqUpdate(UINT32 dir, UINT32 bspChnl, T_RfCfgPara *pRfCfgPara)
{
    INPUT_POINTER_CHECK(pRfCfgPara);

    if (NEED_RECALC_LO != NeedCalcLoFreqFlag(dir, bspChnl, pRfCfgPara))
    {
        dbgInfoEx("[%s] No Need ReCalc Lo\n", __FUNCTION__);
        return BspGetCenterFreq(dir,bspChnl);
    }
    else
    {
        return UpdateCenterFreq(dir, pRfCfgPara);
    }
}

static UINT32 UnfixCalcCenterFreqFromBoard(UINT32 dir,UINT32 bspChnl,T_RfCfgPara *pRfCfgPara)
{
    UINT32 centerLoFreq = 0;

    if(pFuncUnfixCalcCenterFreqFromBoard != NULL)
    {
        centerLoFreq = pFuncUnfixCalcCenterFreqFromBoard(dir,bspChnl,pRfCfgPara);
        return centerLoFreq;
    }

    dbgInfo("%s pFuncUnfixCalcCenterFreqFromBoard is null",__FUNCTION__);
    centerLoFreq = UnfixCalcCenterFreqUpdate(dir,bspChnl,pRfCfgPara);

    return centerLoFreq;
}

/**********************************************************************
* 函数名称: CalcCenterFreq
* 功能描述: 根据单板传递的标志计算中心频点
* 输入参数: dir 上行/下行，bspChnl bsp通道号，pRfCfgPara 配频单通道所有载波信息
* 输出参数: 无
* 返  回  值: centerLoFreq中心频点
************************************************************************/
UINT32 CalcCenterFreq(UINT32 dir,UINT32 bspChnl,T_RfCfgPara *pRfCfgPara)
{
    UINT32 cfgSolutions = 0;
    UINT32 centerLoFreq = 0;
    UINT32 maxChnlSum = 0;
    T_RfPllCfgInit *ptRfPllCfgInit = NULL;

    if (BspGetSupportMgrFreqFlag() == 1) /*A9164 AC流程需要在主片主进程下发TDD和Fdd 配频流程导致通道数变为12了*/
    {
        dbgInfoEx("\n%s>>bspChnl not need check.\n", __FUNCTION__);
    }
    else
    {
       CHECK_BSPCHN(bspChnl);
    }
    INPUT_POINTER_CHECK(pRfCfgPara);
    dbgInfoEx("\n%s>>Start Trx'%d Chan'%2d\n", __FUNCTION__,dir, bspChnl);

    maxChnlSum = RfCfgGetMaxChnlSum(dir);
    ptRfPllCfgInit = pGetRfPllCfgHandle(dir);

    if (NULL == ptRfPllCfgInit)
    {
        dbgInfoEx("\n%s>>BspFreqCfgInit is not INIT.\n", __FUNCTION__);
    }
    else
    {
        cfgSolutions = ptRfPllCfgInit[bspChnl % maxChnlSum].cfgSolution;
    }

    switch(cfgSolutions)
    {
        case BSP_FREQ_UNFIX_CALC_LO:
            centerLoFreq = unfixCalcCenterFreq(pRfCfgPara);
            break;
        case BSP_FREQ_NO_CONFIGC_LO:
            centerLoFreq = fixedCalcCenterFreq(dir, bspChnl,pRfCfgPara);
            break;
        case BSP_FREQ_UNFIX_UPDATA_LO:
            centerLoFreq = UnfixCalcCenterFreqUpdate(dir, bspChnl,pRfCfgPara);
            break;
        case BSP_FREQ_FROM_BOARD_LO:
            centerLoFreq = UnfixCalcCenterFreqFromBoard(dir, bspChnl,pRfCfgPara);
            break;
        case BSP_FREQ_DYNAMIC_LO:
            centerLoFreq = fixedCalcCenterFreq(dir, bspChnl,pRfCfgPara);
            break;
        default:
            centerLoFreq = fixedCalcCenterFreq(dir, bspChnl,pRfCfgPara);
            break;
    }

    dbgInfoEx("%s>>Trx'%d Chnl'(Sum'%2d Idx'%2d) CfgSolution'%d: CenterFreq= %d\n", __FUNCTION__,
              dir, maxChnlSum, bspChnl, cfgSolutions, centerLoFreq);
    return centerLoFreq;
}

/**********************************************************************
* 函数名称: CfgTxNco
* 功能描述: 根据计算的本振频点配置的射频器件
* 输入参数: bspChan BSP通道号，centFreq 中心频点，pRfCfgPara 配频单通道所有载波信息
* 输出参数: 无
* 返  回  值: BSP_OK / BSP_ERROR
************************************************************************/
 UINT32 CfgTxNco(UINT32 bspChan, UINT32 centFreq, T_RfCfgPara *pRfCfgPara, T_RfFreqCfgFailCarrInfoChan *ptFreqCfgFailCarrInfoChan)
{
    UINT32 retVal = BSP_OK;

    if(CARR_NCO_ONLY == BspGetBoardNcoGrade(bspChan,TX))
    {
        retVal |= CfgCarrNco(bspChan, TX, centFreq, pRfCfgPara, ptFreqCfgFailCarrInfoChan);
    }
    else
    {
        retVal |= CfgCarrAndFreqNco(bspChan,TX,centFreq,pRfCfgPara,ptFreqCfgFailCarrInfoChan);
    }

    return retVal;
}

/**********************************************************************
* 函数名称: CfgRxNco
* 功能描述: 根据计算的本振频点配置的射频器件
* 输入参数: bspChan BSP通道号，centFreq 中心频点，pRfCfgPara 配频单通道所有载波信息
* 输出参数: 无
* 返  回  值: BSP_OK / BSP_ERROR
************************************************************************/
UINT32 CfgRxNco(UINT32 bspChan, UINT32 centFreq, T_RfCfgPara *pRfCfgPara, T_RfFreqCfgFailCarrInfoChan *ptFreqCfgFailCarrInfoChan)
{
    UINT32 retVal = BSP_OK;

    if(CARR_NCO_ONLY == BspGetBoardNcoGrade(bspChan,RX))
    {
        retVal |= CfgCarrNco(bspChan, RX, centFreq, pRfCfgPara, ptFreqCfgFailCarrInfoChan);
    }
    else
    {
        retVal |= CfgCarrAndFreqNco(bspChan,RX,centFreq,pRfCfgPara,ptFreqCfgFailCarrInfoChan);
    }

    return retVal;
}

/**********************************************************************
* 函数名称: CfgCarrAndFreqNco
* 功能描述: 只有载波NCO时计算载波NCO
* 输入参数: bspChan BSP通道号，dir TX/RX,centFreq 中心频点，pRfCfgPara 配频单通道所有载波信息
* 输出参数: 无
* 返  回  值: BSP_OK / BSP_ERROR
************************************************************************/
UINT32 CfgCarrAndFreqNco(UINT32 chan,UINT32 dir, UINT32 centFreq,T_RfCfgPara *pRfCfgPara, T_RfFreqCfgFailCarrInfoChan *ptFreqCfgFailCarrInfoChan)
{
    INT32  offset = 0;
    UINT32 bspChan = 0;
    UINT32 chipId = 0;
    UINT32 difChan = 0;
    UINT32 bandFreq[BSP_IC_PERCHAN_BAND_NUM]= {0};
    UINT32 bandNum = 0;
    UINT32 bandLoop = 0;
    UINT32 freqNcoConstFlag = 0;
    INT32 freqOffset = 0;
    UINT32 carrLoop = 0;
    UINT32 radioMode = 0;
    UINT32 carrNo = 0;
    UINT32 bandNo = 0;
    INT32 carrOffset = 0;
    UINT32 carrFreq = 0;
    UINT32 txFreqNco2Step = 0;
    UINT32 rxFreqNco2Step = 0;
    UINT32 freqNco2Step = 0;
    UINT32 retVal = BSP_OK;
    INT32 bandNco = 0;
    UINT32 carrIndex = 0;

    INPUT_POINTER_CHECK(pRfCfgPara);
    INPUT_POINTER_CHECK(ptFreqCfgFailCarrInfoChan);
    freqCfgExLog(FREQCFG_NCO,"\n%s:dir %d chan %d  FuncStart\n",__FUNCTION__,dir,chan);
    retVal = BspGetBspChnByRfChn(chan, dir, &bspChan) ;
    CHECK_RETVAL(BspGetBspChnByRfChn,retVal);
    retVal = BspGetDifInfoByBspChn(bspChan, dir, &chipId, &difChan);
    CHECK_RETVAL(BspGetDifInfoByBspChn,retVal);
    freqNcoConstFlag = getFreqNcoConstFlag();

    //频段NCO配置
    if(BSP_OK != BspHalAdaptGetDifBandFreq(dir, difChan, &bandNum, bandFreq))
    {
        BspLog(LOG_LEVEL_0,"%s>>Error! dir[%d] difChan[%d] get bandNum failed!\n",
                       __FUNCTION__,  dir, difChan);
        return BSP_ERROR;
    }

#ifdef FREQCFG_DEBUG_MODE
    dbgSaveNcoBasicInfo(dir, bspChan, difChan, centFreq, bandNum, pRfCfgPara->carrNum);
#endif
    freqCfgExLog(FREQCFG_NCO,"%s dir:%d difChan:%d centFreq:%d bandNum:%d freqNcoConstFlag:%d\n",
                __FUNCTION__,dir,difChan,centFreq,bandNum,freqNcoConstFlag);

    if(BSP_OK != BspHalAdaptGetFreqNco2Step(RX, difChan, &rxFreqNco2Step))
    {
        BspLog(LOG_LEVEL_0,"%s:get rx chan%d freq nco2 step err\n",__FUNCTION__,bspChan);
        return BSP_ERROR;
    }
    if(BSP_OK != BspHalAdaptGetFreqNco2Step(TX, difChan, &txFreqNco2Step))
    {
        BspLog(LOG_LEVEL_0,"%s:get tx chan%d freq nco2 step err\n",__FUNCTION__,bspChan);
        return BSP_ERROR;
    }

    if(0 == rxFreqNco2Step || 0 == txFreqNco2Step)
    {
        BspLog(LOG_LEVEL_0,"%s:get rx chan%d freq nco2 step is zero\n",__FUNCTION__,bspChan);
        return BSP_ERROR;
    }

    for (bandLoop = 0; bandLoop < bandNum; bandLoop++)
    {
        offset = bandFreq[bandLoop] - centFreq;
        if (RX == dir)
        {
            offset = -offset;
            freqOffset = (INT32)(offset)/(INT32)(rxFreqNco2Step) * (INT32)(rxFreqNco2Step);
            BspRecordBandFreq(dir,bspChan,bandLoop,(centFreq-freqOffset));
            if(freqNcoConstFlag)
            {
                freqOffset = CONST_FREQ_NCO_RX;
                BspRecordBandFreq(dir,bspChan,bandLoop,(centFreq));
            }
            //配置频段NCO
            if(BSP_OK != BspHalAdaptSetRxFreqNco2(difChan, bandNo, freqOffset))
            {
                BspLog(LOG_LEVEL_0,"%s>>Error! Cfg band[%d] nco(%d) to hal fail! \n",
                __FUNCTION__, bandNo, freqOffset);
                return BSP_ERROR;
            }
        }
        else
        {
            freqOffset = (INT32)(offset)/(INT32)(txFreqNco2Step) * (INT32)(txFreqNco2Step);
            BspRecordBandFreq(dir,bspChan,bandLoop,(centFreq+freqOffset));
            if(freqNcoConstFlag)
            {
                freqOffset = CONST_FREQ_NCO_TX;
                BspRecordBandFreq(dir,bspChan,bandLoop,(centFreq));
            }
            //配置频段NCO
            if(BSP_OK != BspHalAdaptSetTxFreqNco2(difChan, bandNo, freqOffset))
            {
                BspLog(LOG_LEVEL_0,"%s>>ror! Cfg band[%d] nco(%d) to hal fail! \n",
                __FUNCTION__, bandNo, freqOffset);
                return BSP_ERROR;
            }
        }

        freqNco2Step = (dir==TX?txFreqNco2Step:rxFreqNco2Step);

#ifdef FREQCFG_DEBUG_MODE
        dbgSaveNcoBandInfo(dir, bspChan, bandLoop, freqNco2Step, bandFreq[bandLoop], freqOffset);
#endif
        BspLog(LOG_LEVEL_0,"freq：%s>> [freqnco] dir%d difChan%d band%d centFreq:%d, bandFreq:%d freqNco:%d freqNco2Step:%d\n",
                __FUNCTION__,dir, difChan, bandLoop, centFreq, bandFreq[bandLoop], freqOffset, freqNco2Step);
    }

    //载波NCO配置
    for(carrLoop = 0;carrLoop<pRfCfgPara->carrNum;carrLoop++)
    {
        //场景预制，载波映射
        radioMode = pRfCfgPara->carrInfo[carrLoop].radioMode;
        carrNo = pRfCfgPara->carrInfo[carrLoop].carrNo;
        carrFreq = pRfCfgPara->carrInfo[carrLoop].freq;

        if(BSP_OK != BspHalAdaptGetDifCarrBandNo(dir, difChan, radioMode, carrNo, &bandNo))
        {
            BspLog(LOG_LEVEL_0,"%s>>Error! Get dir[%d] difchan[%d] difCarrNo[%d] from fail! \n",
            __FUNCTION__, dir, difChan, carrNo);
            return BSP_ERROR;
        }
        if(bandNo >= BSP_IC_PERCHAN_BAND_NUM)
        {
              BspLog(LOG_LEVEL_0,"%s>>Error! bandNo[%d] error! \n",
            __FUNCTION__, bandNo);
              return BSP_ERROR;
        }

        //获取已配置的频段nco
        if(RX == dir)
        {
            freqOffset = (INT32)(bandFreq[bandNo] - centFreq)/(INT32)(rxFreqNco2Step) * (INT32)(rxFreqNco2Step);
        }
        else
        {
            freqOffset = (INT32)(bandFreq[bandNo] - centFreq)/(INT32)(txFreqNco2Step) * (INT32)(txFreqNco2Step);
        }

        if(freqNcoConstFlag)
        {
            if(RX ==dir)
            {
                freqOffset = -CONST_FREQ_NCO_RX;
            }
            else
            {
                freqOffset = CONST_FREQ_NCO_TX;
            }
        }
        bandNco = freqOffset;
        //刨除频段nco,剩余配置到载波nco
        carrOffset = pRfCfgPara->carrInfo[carrLoop].freq - centFreq - freqOffset;
        if(RX == dir)
        {
            carrOffset = -pRfCfgPara->carrInfo[carrLoop].freq + centFreq + freqOffset;
        }
//暂时不对载波nco步长进行判断
#if 0
        //获取载波nco步长
        if(BSP_OK != BspHalAdaptGetCarrNcoStep(dir, difChan, &carrNcoStep))
        {
            BspLog(LOG_LEVEL_0,"%s:get dir%d chan%d carr nco step err\n",__FUNCTION__,dir, bspChan);
            return BSP_ERROR;
        }
        if(ABS(carrOffset)%carrNcoStep)
        {
            BspLog(LOG_LEVEL_0,"%s: dir%d chan%d carr nco step is low precision \n",__FUNCTION__,dir, bspChan);
            return BSP_ERROR;
        }
#endif
        //配置载波nco
        if(TX == dir)
        {
            retVal = BspHalAdaptSetTxCarrNco(difChan, radioMode, carrNo, carrOffset);//carrOffset KHZ
        }
        else
        {
            retVal = BspHalAdaptSetRxCarrNco(difChan, radioMode, carrNo, carrOffset);//carrOffset KHZ
        }
        if(BSP_OK != retVal)
        {
            BspLog(LOG_LEVEL_0,"%s: dir%d chan%d set carr nco err \n",__FUNCTION__,dir, bspChan);
            ptFreqCfgFailCarrInfoChan->carrNum +=1;
            ptFreqCfgFailCarrInfoChan->carrInfo[carrIndex].carrNo = carrNo;
            ptFreqCfgFailCarrInfoChan->carrInfo[carrIndex].radioMode = radioMode;
            ptFreqCfgFailCarrInfoChan->carrInfo[carrIndex].errorCode = CFG_FREQ_ERROR;
            BspLog(LOG_LEVEL_0,"[%s] carrNum = %d, carrNo = %d, radioMode = %d, errorCode = %d\n",__FUNCTION__,
                   ptFreqCfgFailCarrInfoChan->carrNum,carrNo,radioMode,ptFreqCfgFailCarrInfoChan->carrInfo[carrIndex].errorCode);
            carrIndex += 1;
        }

#ifdef FREQCFG_DEBUG_MODE
        dbgSaveNcoCarrInfo(dir, bspChan, carrLoop, carrNo, carrFreq, carrOffset, bandNo);
#endif
        (VOID)BspSaveNcoCarrInfo(dir, carrLoop,difChan, radioMode, carrNo, carrOffset, bandNo, bandNco);
        BspLog(LOG_LEVEL_0,"freq: %s [carrnco] dir%d difChan%d carr%d carrFreq:%d, centFreq:%d, freqNco:%d carrNco:%d\n",
                    __FUNCTION__,dir,difChan, carrLoop, pRfCfgPara->carrInfo[carrLoop].freq, centFreq, freqOffset, carrOffset);
    }
    freqCfgExLog(FREQCFG_NCO, "CfgCarrAndFreqNco: chan %2d dir %d, centFreq %d, End\n", chan, dir, centFreq);

    return BSP_OK;
}

/* Started by AICoder, pid:pbf4aj593bi90b4141d6082bc0c3ea264965103b */
INT32 BspGetChanBandBase(UINT32 bspChan, UINT32 dir)
{
    INT32 bandNcoBase = 0;

    if (dir == TX && txRfPllCfgInit[bspChan].cfgSolution != BSP_FREQ_DYNAMIC_LO)
    {
        if (txRfPllCfgInit[bspChan].bandNcoFlag == 1)
        {
            bandNcoBase = txRfPllCfgInit[bspChan].bandNcoBase;
            dbgInfo("%s [%d] bspChan: %d bandNcoBase: %d\n",
                    __FUNCTION__, __LINE__, bspChan, bandNcoBase);
        }
    }
    else if (dir == RX && rxRfPllCfgInit[bspChan].cfgSolution != BSP_FREQ_DYNAMIC_LO)
    {
        if (rxRfPllCfgInit[bspChan].bandNcoFlag == 1)
        {
            bandNcoBase = rxRfPllCfgInit[bspChan].bandNcoBase;
            dbgInfo("%s [%d] bspChan: %d bandNcoBase: %d\n",
                    __FUNCTION__, __LINE__, bspChan, bandNcoBase);
        }
    }

    return bandNcoBase;
}
/* Ended by AICoder, pid:pbf4aj593bi90b4141d6082bc0c3ea264965103b */
/* Started by AICoder, pid:nd29cp5ea1mbb6f140d109f5400f852a42548c74 */
UINT32 CfgCarrRcfFpga(T_FuncCarrInfo *pFuncCarrInfo, UINT32 dir)
{
    UINT32 retVal = BSP_ERROR;
    UINT32 chipId = 0;
    UINT32 difChan = 0;
    UINT32 bspChan = 0;
    UINT32 carrRadio = 0;
    T_FpgaInfoInit *pFpgaInfo = NULL;
    INPUT_POINTER_CHECK(pFuncCarrInfo);
    bspChan = pFuncCarrInfo->bspChn;
    carrRadio = pFuncCarrInfo->radioMode;
    INPUT_BSPCHN_CHECK(bspChan);
    pFpgaInfo = BspGetFpgaInfo();
    INPUT_POINTER_CHECK(pFpgaInfo);
    INPUT_POINTER_CHECK(pFpgaInfo->pFuncSetFpgaCarrRcf);

    retVal = BspGetDifInfoByBspChn(bspChan, dir, &chipId, &difChan);
    if(BSP_OK != retVal)
    {
        BspLog(LOG_LEVEL_0,"%s:get chan%d dir%d difChan err!\n",__FUNCTION__,dir, bspChan);
        return retVal;
    }

    if ((TX == dir && BSP_RADIO_STANDARD_AIOT == carrRadio) ||
            (RX == dir && BSP_RADIO_STANDARD_AIOT == carrRadio))
    {
        retVal = pFpgaInfo->pFuncSetFpgaCarrRcf(0, dir, pFuncCarrInfo);
    }

    return retVal;
}

UINT32 CfgCarrNcoFpga(T_FuncCarrInfo *pFuncCarrInfo, UINT32 dir, UINT32 carrFreq, UINT32 centFreq, UINT32 *fpgaFlag)
{
    INPUT_POINTER_CHECK(pFuncCarrInfo);
    INPUT_POINTER_CHECK(fpgaFlag);
    UINT32 retVal = BSP_ERROR;
    UINT32 chipId = 0;
    UINT32 difChan = 0;
    UINT32 bspChan = pFuncCarrInfo->bspChn;
    UINT32 carr = pFuncCarrInfo->carr;
    UINT32 radioMode = pFuncCarrInfo->radioMode;
    T_FpgaInfoInit *pFpgaInfo = BspGetFpgaInfo();
    INPUT_BSPCHN_CHECK(bspChan);
    INPUT_POINTER_CHECK(pFpgaInfo);
    INPUT_POINTER_CHECK(pFpgaInfo->pFuncCfgFpgaCarrNco);

    retVal = BspGetDifInfoByBspChn(bspChan, dir, &chipId, &difChan);
    if(BSP_OK != retVal)
    {
        BspLog(LOG_LEVEL_0,"%s:get chan%d dir%d difChan err!\n",__FUNCTION__,dir, bspChan);
        return retVal;
    }

    /* fpga链路，d42链路无需关注此处 */
    if ((TX == dir && BSP_RADIO_STANDARD_AIOT == radioMode) ||
            (RX == dir && BSP_RADIO_STANDARD_AIOT == radioMode))
    {
        *fpgaFlag = 1;
        retVal = pFpgaInfo->pFuncCfgFpgaCarrNco(difChan, carr, dir, carrFreq, centFreq);
    }

    return retVal;
}

/**********************************************************************
* 函数名称: CfgCarrNco
* 功能描述: 只有载波NCO时计算载波NCO
* 输入参数: bspChan BSP通道号，dir TX/RX,centFreq 中心频点，pRfCfgPara 配频单通道所有载波信息
* 输出参数: 无
* 返  回  值: BSP_OK / BSP_ERROR
************************************************************************/
UINT32 CfgCarrNco(UINT32 bspChan, UINT32 dir, UINT32 centFreq, T_RfCfgPara *pRfCfgPara, T_RfFreqCfgFailCarrInfoChan *ptFreqCfgFailCarrInfoChan)
{
    UINT32 chan = 0;
    UINT32 carrLoop = 0;
    INT32 offset = 0;
    UINT32 chipId = 0;
    UINT32 difChan = 0;
    UINT32 carrNum = 0;
    UINT32 carrFreq = 0;
    UINT32 radioMode = BSP_RADIO_STANDARD_GSM;
    UINT32 carrNo = 0;
    UINT32 retVal = BSP_OK;
    UINT32 ulSliderRet = BSP_OK;
    INT32  bandNcoBase = 0;
    T_FuncCarrInfo funcCarrInfo = {};
    UINT32 fpgaFlag = 0;
    UINT32 carrIndex = 0;
    UINT32 bandWidth = 0;
    UINT32 ifType = 0;

    CHECK_BSPCHN(bspChan);//通道有效检查

    bandNcoBase = BspGetChanBandBase(bspChan, dir);

    freqCfgExLog(FREQCFG_NCO,"[%s] start!\n", __FUNCTION__);

    retVal = BspGetDifInfoByBspChn(bspChan, dir, &chipId, &difChan);
    if(BSP_OK != retVal)
    {
        BspLog(LOG_LEVEL_0,"%s:get chan%d dir%d difChan err!\n",__FUNCTION__,dir, bspChan);
        return retVal;
    }

    /* 单通道大带宽时可能需要两个band,两个band的中心频点相等，载波移频能力大*/
    BspRecordBandFreq(dir, bspChan, BAND_NO_0, centFreq);
    BspRecordBandFreq(dir, bspChan, BAND_NO_1, centFreq);

    carrNum = pRfCfgPara->carrNum;
    freqCfgExLog(FREQCFG_NCO,"[%s] difChan[%d] centFreq[%d] carrNum[%d]\n",
                __FUNCTION__, difChan, centFreq, carrNum);
    CHECK_CARR_NUM(carrNum);

#ifdef FREQCFG_DEBUG_MODE
    dbgSaveNcoBasicInfo(dir, bspChan, difChan, centFreq, 0, carrNum);
#endif

    BspGetRfChnByBspChn(bspChan, dir, &chan);
    for (carrLoop = 0 ; carrLoop < carrNum; carrLoop++)
    {
        //场景预制，载波映射
    	T_carrFilterPara tCarrFilterInfo = {0};

        radioMode = pRfCfgPara->carrInfo[carrLoop].radioMode;
        carrNo = pRfCfgPara->carrInfo[carrLoop].carrNo;
        carrFreq = pRfCfgPara->carrInfo[carrLoop].freq;
        bandWidth = pRfCfgPara->carrInfo[carrLoop].bandWidth;
        ifType = pRfCfgPara->carrInfo[carrLoop].difIfType;

        /* fpga链路，d42链路无需关注此处 */
        funcCarrInfo.bspChn = bspChan;
        funcCarrInfo.carr = carrNo;
        funcCarrInfo.radioMode = radioMode;
        funcCarrInfo.bandWidth = bandWidth;
        funcCarrInfo.ifType = ifType;
        (void)CfgCarrNcoFpga(&funcCarrInfo, dir, carrFreq, centFreq, &fpgaFlag);
        (void)CfgCarrRcfFpga(&funcCarrInfo, dir);
        if (fpgaFlag == 1)
        {
            continue;
        }

        if (dir == TX)
        {
            offset = carrFreq-centFreq-bandNcoBase;
            /* hal层封装新的接口，放置污染funclib层代码 */
            if(radioMode == BSP_RADIO_STANDARD_GSM)
            {
            	offset = carrFreq/200*200-centFreq-bandNcoBase;
                retVal |= BspHalAdaptSetGsmCenterFreq(difChan, radioMode, carrNo,  (carrFreq/200)*200);
            }

            //射频大包配置频点配置bank nco
            retVal = BspHalAdaptSetTxCarrNco(difChan, radioMode, carrNo, offset);
            //retVal |= BspSetTxCarrNcoOffset(difChan, carrNo, radioMode, offset);//offset KHZ
            //如果有单边滤波重新配置bank nco，用单边滤波的频点
            ulSliderRet = BspGetPublicDlFilterPara(bspChan, carrNo, radioMode, &tCarrFilterInfo);
            if((ulSliderRet == BSP_OK) && (tCarrFilterInfo.nco1 != 0))
            {
            	(void)BspSetSideFilterTxCarrFreq(bspChan, carrNo,  radioMode,  tCarrFilterInfo.nco2);
            }
            /*不支持动态本振的机型可以通过该接口配置dlpost NCO*/
            if((txRfPllCfgInit[chan].cfgSolution != BSP_FREQ_DYNAMIC_LO) && (txRfPllCfgInit[chan].bandNcoBase != 0))
            {
                retVal |= BspHalAdaptSetTxFreqNco(difChan,0, txRfPllCfgInit[bspChan].bandNcoBase);
            }
        }
        else
        {
            offset = centFreq + bandNcoBase - carrFreq;

            if(radioMode==BSP_RADIO_STANDARD_GSM)
            {
            	offset = centFreq + bandNcoBase -(carrFreq/200*200);
            }
            //射频大包配置频点配置bank  nco
            retVal = BspHalAdaptSetRxCarrNco(difChan, radioMode, carrNo, offset);//offset KHZ

            //如果有单边滤波配置，重新配置bank nco，用单边滤波的频点
            ulSliderRet = BspGetPublicUlFilterPara(bspChan, carrNo, radioMode, &tCarrFilterInfo);

            if((ulSliderRet == BSP_OK) && (tCarrFilterInfo.nco1 != 0))
        	{
            	(void)BspSetSideFilterRxCarrFreq(bspChan, carrNo, radioMode, tCarrFilterInfo.nco2);
        	}
        }

        if(BSP_OK != retVal)
        {
            BspLog(LOG_LEVEL_0,"%s: dir%d chan%d set carr nco err \n",__FUNCTION__,dir, bspChan);
            if(NULL != ptFreqCfgFailCarrInfoChan)
            {
                ptFreqCfgFailCarrInfoChan->carrNum +=1;
                ptFreqCfgFailCarrInfoChan->carrInfo[carrIndex].carrNo = carrNo;
                ptFreqCfgFailCarrInfoChan->carrInfo[carrIndex].radioMode = radioMode;
                ptFreqCfgFailCarrInfoChan->carrInfo[carrIndex].errorCode = CFG_FREQ_ERROR;
                BspLog(LOG_LEVEL_0,"[%s] carrNum = %d, carrNo = %d, radioMode = %d, errorCode = %d\n",__FUNCTION__,
                        ptFreqCfgFailCarrInfoChan->carrNum,
                        carrNo,radioMode,ptFreqCfgFailCarrInfoChan->carrInfo[carrIndex].errorCode);
                carrIndex += 1;
            }
        }
        BspLog(LOG_LEVEL_0,"freq： %s>>:dir%d chan%d carr%d carrFreq:%d, centFreq:%d, carrNco:%d\n",__FUNCTION__,dir,\
                bspChan, carrLoop, pRfCfgPara->carrInfo[carrLoop].freq, centFreq, offset);

#ifdef FREQCFG_DEBUG_MODE
        dbgSaveNcoCarrInfo(dir, bspChan, carrLoop, carrNo, carrFreq, offset, 0);
#endif
        (VOID)BspSaveNcoCarrInfo(dir, carrLoop,difChan, radioMode, carrNo, offset, 0, bandNcoBase);
    }
    freqCfgExLog(FREQCFG_NCO,"[%s] end!\n", __FUNCTION__);

    return BSP_OK;
}

/**********************************************************************
* 函数名称: BspCfgBand
* 功能描述: 频段相关信息获取计算
* 输入参数: bspChan BSP通道号，dir TX/RX,pRfCfgPara 配频单通道所有载波信息
* 输出参数: 无
* 返  回  值: BSP_OK / BSP_ERROR
************************************************************************/
UINT32 BspCfgBand(UINT32 bspChnl, UINT32 dir, T_RfCfgPara *pRfCfgPara)
{
    UINT32 loop = 0;
    UINT32 bandNo = 0;
    UINT32 bandNum =0;
    UINT32 bandFreq[BSP_IC_PERCHAN_BAND_NUM] = {0};
    UINT32 difChan = 0;
    UINT32 difId = 0;
    UINT32 difCarrNo = 0;

    freqCfgExLog(FREQCFG_RFCFG,"%s bspChnl'%d dir'%d start\n", __FUNCTION__, bspChnl, dir);
    if (BspGetDifInfoByBspChn(bspChnl,dir,&difId,&difChan) != BSP_OK)
    {
        BspLog(LOG_LEVEL_0,"%s: dir[%d] bspChnl[%d] get difChan failed.\n", __FUNCTION__, dir, bspChnl);
        return BSP_ERROR;
    }
    if(BSP_OK != BspHalAdaptGetDifBandFreq(dir, difChan, &bandNum, bandFreq))
    {
        BspLog(LOG_LEVEL_0,"%s: dir[%d] difChan[%d] get bandNum failed.\n", __FUNCTION__, dir, difChan);
        return BSP_ERROR;
    }

    freqCfgExLog(FREQCFG_RFCFG,"%s bandNum'%d bandFreq[0]'%d bandFreq[1]'%d\n",
            __FUNCTION__, bandNum, bandFreq[0], bandFreq[1]);

    if(BSP_IC_PERCHAN_BAND_NUM == bandNum)
    {
        for (loop = 0; loop< pRfCfgPara->carrNum; loop++)
        {
            difCarrNo = 0;//场景预置载波映射 carr -> difCarrNo
            if(BSP_OK != BspHalAdaptGetDifCarrBandNo(dir, difChan, pRfCfgPara->carrInfo[loop].radioMode, difCarrNo, &bandNo))
            {
                BspLog(LOG_LEVEL_0,"%s: dir[%d] difChan[%d] difCarrNo[%d] get bandNo failed.\n", __FUNCTION__, dir, difChan, difCarrNo);
                bandNo = 0;
            }
            //BspRecordCarrBandFlag(dir,bspChnl,pRfCfgPara->carrInfo[loop].carrNo, bandNo);
            freqCfgExLog(FREQCFG_BANDNO,"%s multiBand loop[%d] difCarrNo'%d bandNo'%d\n", __FUNCTION__, loop, difCarrNo, bandNo);
        }
        BspRecordBandFlag(dir, bspChnl, DIF_MULT_BAND);
    }
    else
    {
        for (loop = 0; loop< pRfCfgPara->carrNum; loop++)
        {
           // BspRecordCarrBandFlag(dir,bspChnl,pRfCfgPara->carrInfo[loop].carrNo, 0);
            freqCfgExLog(FREQCFG_BANDNO,"%s oneBand loop[%d] bandNo'%d\n", __FUNCTION__, loop, bandNo);
        }
        BspRecordBandFlag(dir, bspChnl, DIF_ONE_BAND);
    }
    freqCfgExLog(FREQCFG_RFCFG,"%s bspChnl'%d dir'%d end\n", __FUNCTION__, bspChnl, dir);

    return BSP_OK;
}

/**********************************************************************
* 函数名称: BspIsFreqCfgDynamic(*)
* 功能描述: 是否支持动态本振新方案(本振计算:吴晶. 软件详设:李瑞),默认不支持.
* 输入参数: 无
* 输出参数: 无
* 返 回 值: 1:新方案   0:其他老方案
* 其它说明:
* ---------------------------------------------------------------------------
* 修改日期         修改人    修改内容
* 2020-11-03
***********************************************************************
*/
UINT32 BspIsFreqCfgDynamic(void)/* zhy：上下行不对趁的话，需要拆分接口，目前EP214不影响 */
{
    T_RfPllCfgInit *ptRfPllCfgInit = NULL;
    UINT32 chanNum = BspGetTxChannel();
    UINT32 chan = 0;
    UINT32 bspChan = 0;

    ptRfPllCfgInit = pGetRfPllCfgHandle(TX);
    if (ptRfPllCfgInit == NULL)
    {
        return 0;
    }

    for(chan = 0; chan < chanNum; ++chan)
    {
        if (BspGetBspChnByRfChn(chan, TX, &bspChan) != BSP_OK)
        {
            BspLog(LOG_LEVEL_0,"%s >> get BspChan info failed!\n", __FUNCTION__);
            return BSP_ERROR;
        }
        if(ptRfPllCfgInit[bspChan].cfgSolution == FREQ_CFG_SOLUTION_DYNAMIC)
        {
            return 1;
        }
    }
    return 0;
}

UINT32 BspSetGsmCellInfo(T_GsmCellInfo *gsmCellInfo)
{
    UINT32 chan = 0;
    UINT32 chipId = 0;
    UINT32 ret = 0;


    INPUT_POINTER_CHECK(gsmCellInfo);

    for (chan = 0; chan < gsmCellInfo->gsmCellNum; chan++)
    {
        ret = BspGetDifInfoByBspChn(gsmCellInfo->gsmCell[chan].txChn, TX, &chipId, &gsmCellInfo->gsmCell[chan].txChn);
        if (ret != BSP_OK)
        {
            dbgInfo("%s: BspGetDifInfoByBspChn tx failed\n", __FUNCTION__);
        }
        ret = BspGetDifInfoByBspChn(gsmCellInfo->gsmCell[chan].rxMainChn, RX, &chipId, &gsmCellInfo->gsmCell[chan].rxMainChn);
        if (ret != BSP_OK)
        {
            dbgInfo("%s: BspGetDifInfoByBspChn rxmain failed\n", __FUNCTION__);
        }
        ret = BspGetDifInfoByBspChn(gsmCellInfo->gsmCell[chan].rxDivChn, RX, &chipId, &gsmCellInfo->gsmCell[chan].rxDivChn);
        if (ret != BSP_OK)
        {
            dbgInfoEx("%s: BspGetDifInfoByBspChn rxdiv failed\n", __FUNCTION__);
        }
    }
    
    return BspHalAdaptSetGsmCellInfo(gsmCellInfo);
}

/**********************************************************************
* 函数名称: BspGetRfCenterFreq(*)
* 功能描述: 获取BSP通道对应的本振频点
* 输入参数: 无
* 输出参数: 无
* 返 回 值:  中心频点
* 其它说明:
************************************************************************/
UINT32 BspGetRfCenterFreq(UINT32 uDir, UINT32 ulBspChan)
{
    T_RfPllCfgInit *pRfPllCfg = NULL;
    UINT32 chanNum = (TX == uDir) ? BspGetTxChannel() : BspGetRxChannel();

    if(ulBspChan >= chanNum)
    {
        BspLog(LOG_LEVEL_0,"%s: input ulBspChan'%d is out of range.\n", __FUNCTION__, ulBspChan);
        return BSP_ERROR;
    }

    pRfPllCfg = pGetRfPllCfgHandle(uDir);
    if(NULL == pRfPllCfg)
    {
        BspLog(LOG_LEVEL_0,"%s: RfPll Cfg is not Initialized.\n", __FUNCTION__);
        return BSP_ERROR;
    }

    return pRfPllCfg[ulBspChan].defLoFreqKHz;
}

/**********************************************************************
* 函数名称: BspGetRfNcoUINT32(*)
* 功能描述: 获取BSP通道对应的射频nco
* 输入参数: 无
* 输出参数: 无
* 返 回 值:  中心频点
* 其它说明:
************************************************************************/
INT32 BspGetRfNco(UINT32 uDir, UINT32 ulBspChan)
{
    T_RfPllCfgInit *pRfPllCfg = NULL;
    UINT32 chanNum = (TX == uDir) ? BspGetTxChannel() : BspGetRxChannel();

    if(ulBspChan >= chanNum)
    {
        BspLog(LOG_LEVEL_0,"%s: input ulBspChan'%d is out of range.\n", __FUNCTION__, ulBspChan);
        return BSP_ERROR;
    }

    pRfPllCfg = pGetRfPllCfgHandle(uDir);
    if(NULL == pRfPllCfg)
    {
        BspLog(LOG_LEVEL_0,"%s: RfPll Cfg is not Initialized.\n", __FUNCTION__);
        return BSP_ERROR;
    }

    return pRfPllCfg[ulBspChan].bandNcoBase;
}

UINT32 BspSetCallBackAfterFreqcfg(UINT32 dir, UINT32 index, FUNC_CALLED_AFTER_FREQCFG pFunc)
{
    if(index >= FUNC_AFTER_FREQCFG_INDEX_MAX || dir > TX)
    {
        return BSP_ERROR;
    }
    s_pFuncCalledAfterFreqcfg[dir][index] = pFunc;
    return BSP_OK;
}

UINT32 BspSetUpdatePaptAvgPowInfoCallBack(FUNC_UPDATE_PAPT_AVG_POW_INFO pFunc)
{
    s_pFuncUpdatePaptAvgPowInfo = pFunc;
    return BSP_OK;
}

UINT32 BspUpdateVswrComps(UINT32 bspChan, UINT32 uFreqKHz)
{
    UINT32 uRet = BSP_OK;
    T_RfCfgPara *pRfCfg = NULL;

    if(BSP_OK != BspCheckTxChannel(bspChan))
    {
        BspLog(LOG_LEVEL_0,"[%s]Para Error.\n",__FUNCTION__);
        return BSP_ERROR;
    }

    pRfCfg = BspGetRfCfgPara(bspChan, TX);
    if(NULL == pRfCfg)
    {
        BspLog(LOG_LEVEL_0,"[%s] chan %d pRfCfgPara in NULL \n",__FUNCTION__, bspChan);
        return BSP_ERROR;
    }

    pRfCfg->carrInfo[0].freq = uFreqKHz;
    uRet = BspSetTxRfCfg(bspChan, pRfCfg);

    /* 解决单音制式问题 */
    //BspDpdSetPimFlag(1);
    uRet |= BspDpdSetCellInfo(bspChan, 0);

    return uRet;
}
/*================================================================ 
                        动态本振(吴晶方案) start
=================================================================*/

VOID BspSetTransCaliFlags(UINT32 trsvId, UINT32 flags)
{
    if(TRANS_CALI_FLAG_NUM <= trsvId)
    {
       dbgInfo("%s: trsvId > %d\n", __FUNCTION__, TRANS_CALI_FLAG_NUM);
       return;
    }
    s_transCaliFlag[trsvId] = flags;
}

UINT32 BspGetTransCaliFlags(UINT32 trsvId)
{
    if(TRANS_CALI_FLAG_NUM <= trsvId)
    {
        dbgInfo("%s: trsvId > %d\n", __FUNCTION__, TRANS_CALI_FLAG_NUM);
        return BSP_ERROR;
    }
    return s_transCaliFlag[trsvId];
}

UINT32 BspSetTddBandFreqFlag(UINT32 flag)
{
    return BspHalAdaptSetTddBandFreqFlag(flag);
}

/* Started by AICoder, pid:m028db2c1e9393314a680a8310a2f41fd511e682 */
UINT32 BspSetExpansionFlag(UINT32 flag)
{
    return BspHalAdaptSetExpansionFlag(flag);
}
/* Ended by AICoder, pid:m028db2c1e9393314a680a8310a2f41fd511e682 */

/* Started by AICoder, pid:630c8i61dfd2046142e20b4f701b9c294f235322 */
UINT32 BspSetFreqOffSetIndexByCarr(UINT32 uiDifChan, UINT32 uiCarrId, UINT32 uiRadioMode, UINT32 uiIndex)
{
    if(1 == BspHalAdaptGetFreqOffsetCompFlag())    
    {
        return BspHalAdaptSetFreqOffSetIndexByCarr(uiDifChan, uiCarrId, uiRadioMode, uiIndex);
    }
    else
    {
        return BSP_OK;
    }
}
/* Ended by AICoder, pid:630c8i61dfd2046142e20b4f701b9c294f235322 */

/*UMTS单边滤波功能，添加相关接口*/
/**********************************************************************
* 函数名称：BspGetRcfCoefByBandWith
* 功能描述：查看U对应带宽RCF系数是否存在
* 输入参数：参数0:通道 ，参数1:制式 ，参数2：带宽
* 返 回 值：BSP_OK - 成功; 其它值为失败
* 其它说明：高层调用；高层通过接口返回值判断该带宽是否可做单边滤波。
***********************************************************************/
UINT32 BspGetRcfCoefByBandWith(UINT32 bspChan,UINT32 radioMod,UINT32 bandWidth)
{
    UINT32 ret     = BSP_OK;
    UINT32 chipId  = 0;
    UINT32 difChan = 0;

    ret = BspGetDifInfoByBspChn(bspChan, TX, &chipId, &difChan);
    if (BSP_OK != ret)
    {
        BspLog(LOG_LEVEL_0,"%s>>bspChan'%d BspGetDifInfoByBspChn Get Error!\n",
               __FUNCTION__, bspChan);
        return BSP_ERROR;
    }

    ret = BspHalAdaptGetDlBw(difChan, radioMod, bandWidth);
    BspLog(LOG_LEVEL_0, "[%s]: bspChan'%d, radioMod'0x%x, bandWidth'%dKHZ, ret'%d \n",__FUNCTION__,bspChan,radioMod,bandWidth,ret);

    return ret;
}

UINT32 BspGetUlRcfCoefByBandWith(UINT32 bspChan, UINT32 radio, UINT32 bandWidth)
{
    UINT32 ret     = BSP_OK;
    UINT32 chipId  = 0;
    UINT32 difChan = 0;

    ret = BspGetDifInfoByBspChn(bspChan, RX, &chipId, &difChan);
    if (BSP_OK != ret)
    {
        BspLog(LOG_LEVEL_0,"%s>>bspChan'%d BspGetDifInfoByBspChn Get Error!\n", __FUNCTION__, bspChan);
        return BSP_ERROR;
    }

    ret = BspHalAdaptGetUlBw(difChan, radio, bandWidth);
    BspLog(LOG_LEVEL_0, "[%s]: bspChan'%d, radio'0x%x, bandWidth'%dKHZ, ret'%d \n", __FUNCTION__, bspChan, radio, bandWidth, ret);

    return ret;
}

/**********************************************************************
* 函数名称：BspSetUmtsDlFilterCoef
* 功能描述：设置U单边滤波后U的滤波器系数
* 输入参数：参数0:通道 ，参数1:制式 ，参数2:载波 ，参数3：带宽
* 返 回 值：BSP_OK - 成功; 其它值为失败
* 其它说明：高层调用；BSP将U带宽透传HAL，HAL层拿到滤波后的带宽，匹配滤波器系数
***********************************************************************/
UINT32 BspSetUmtsDlFilterCoef(UINT32 bspChan,UINT32 radioMod, UINT32 carrNo, UINT32 bandWidth)
{
    UINT32 ret     = BSP_OK;
    UINT32 chipId  = 0;
    UINT32 difChan = 0;

    ret = BspGetDifInfoByBspChn(bspChan, TX, &chipId, &difChan);
    if (BSP_OK != ret)
    {
        BspLog(LOG_LEVEL_0,"%s>>bspChan'%d BspGetDifInfoByBspChn Get Error!\n",
               __FUNCTION__, bspChan);
        return BSP_ERROR;
    }

    ret |= BspHalAdaptSetUmtsDlBw(difChan, carrNo, radioMod, bandWidth);
    if (BSP_OK == ret)
    {
        ret |= BspSetDlFilterRcfBw(difChan, carrNo, BSP_RADIO_STANDARD_UMTS, bandWidth);
    }

    dbgInfoEx("[%s]: bspChan'%d, carrNo'%d, radioMod'0x%x, bandWidth'%dKHZ\n",__FUNCTION__,bspChan,carrNo,radioMod,bandWidth);

    return ret;
}

/**********************************************************************
* 函数名称：BspSetUmtsTxNco
* 功能描述：设置U单边滤波配置到IC的NCO1
* 输入参数：参数0:通道 ，参数1:载波 ，参数2:NCO1值(成型前NCO)
* 返 回 值：BSP_OK - 成功; 其它值为失败
* 其它说明：高层调用。
***********************************************************************/
UINT32 BspSetUmtsTxNco(UINT32 chanId, UINT32 carrNo, INT32 swFreqOffset)
{
    UINT32 ret     = BSP_OK;
    UINT32 chipId  = 0;
    UINT32 difChan = 0;

    ret = BspGetDifInfoByBspChn(chanId, TX, &chipId, &difChan);
    if (BSP_OK != ret)
    {
        BspLog(LOG_LEVEL_0,"%s>>bspChan'%d BspGetDifInfoByBspChn Get Error!\n",
               __FUNCTION__, chanId);
        return BSP_ERROR;
    }

    ret |= BspHalAdaptSetUmtsDlNcoFront(difChan, carrNo, BSP_RADIO_STANDARD_UMTS, swFreqOffset);
    if (BSP_OK == ret)
    {
        ret |= BspSetDlFilterNcoFront(difChan, carrNo, BSP_RADIO_STANDARD_UMTS, swFreqOffset);
    }

    dbgInfoEx("[%s]: chan'%d, carrNo'%d, Nco1'%d\n",__FUNCTION__,chanId,carrNo,swFreqOffset);

    return ret;
}

/**********************************************************************
* 函数名称：BspSetUmtsCarrFreq
* 功能描述：设置U单边滤波后U的中心频点
* 输入参数：参数0:通道 ，参数1:dir ，参数2:载波 ，参数3：U频点(单位:KHZ)
* 返 回 值：BSP_OK - 成功; 其它值为失败
* 其它说明： freqOffset = centFreq - NCO1，即载波中心频点移NCO1后的频点;
           传给HAL的NCO2 = (-NCO1)+链路NCO = (-NCO1)+centFreq-本振频点-bandNco
***********************************************************************/
UINT32 BspSetUmtsCarrFreq(UINT32 bspChan, UINT32 dir,UINT32 umtsCarrNo, INT32 freqOffset)
{
    UINT32 ret     = BSP_OK;
    UINT32 chipId  = 0;
    UINT32 difChan = 0;
    UINT32 rfpll   = 0;
    INT32 offset   = 0;
    INT32 bandNco   = 0;

    CHECK_BSPCHN(bspChan);

    if(txRfPllCfgInit[bspChan].cfgSolution != BSP_FREQ_DYNAMIC_LO)
    {
        if(1 == txRfPllCfgInit[bspChan].bandNcoFlag)
        {
            bandNco = txRfPllCfgInit[bspChan].bandNcoBase;
            dbgInfoEx("%s [%d] bspChan: %d bandNco: %d \n",__FUNCTION__, __LINE__, bspChan, bandNco);
        }
    }

    ret |= BspGetDifInfoByBspChn(bspChan, dir, &chipId, &difChan);

    rfpll = BspGetLoFreqChanged(TX,bspChan);
    offset = (INT32)((INT32)freqOffset - (INT32)rfpll - bandNco);

    ret |= BspHalAdaptSetUmtsDlNcoBehind(difChan, umtsCarrNo, BSP_RADIO_STANDARD_UMTS, offset);
    if (BSP_OK == ret)
    {
        ret |= BspSetCfrFreqFiOffset(difChan, umtsCarrNo, BSP_RADIO_STANDARD_UMTS, offset);
        ret |= BspSetDlFilterNcoBehind(difChan, umtsCarrNo, BSP_RADIO_STANDARD_UMTS, freqOffset);
    }

    dbgInfoEx("[%s]: bspChan'%d, dir'%d, carrNo'%d, freqOffset'%d, rfpll'%d, bandnco'%d, Nco2'%d\n",
            __FUNCTION__,bspChan,dir,umtsCarrNo,freqOffset,rfpll,bandNco,offset);

    return ret;
}

/* Started by AICoder, pid:q3023g020439d7d140730a40e060eb46e484f9d9 */
T_FilterChnInfo *BspGetFilterChnInfoMem(UINT32 radio)
{
    if (BSP_RADIO_STANDARD_UMTS == radio)//UMTS
    {
        if (s_filterChnInfo == NULL)
        {
            s_filterChnInfo = (T_FilterChnInfo *)malloc(sizeof(T_FilterChnInfo) * MAX_TX_CHANNEL);
            if (s_filterChnInfo == NULL)
            {
                return NULL;
            }
            zte_memset_s(s_filterChnInfo, sizeof(T_FilterChnInfo) * MAX_TX_CHANNEL, 0, sizeof(T_FilterChnInfo) * MAX_TX_CHANNEL);
        }
        return s_filterChnInfo;
    }
    else if (BSP_RADIO_STANDARD_FDD_5G == radio)//FDD NR
    {
        if (s_filterNrChnInfo == NULL)
        {
            s_filterNrChnInfo = (T_FilterChnInfo *)malloc(sizeof(T_FilterChnInfo) * MAX_TX_CHANNEL);
            if (s_filterNrChnInfo == NULL)
            {
                return NULL;
            }
            zte_memset_s(s_filterNrChnInfo, sizeof(T_FilterChnInfo) * MAX_TX_CHANNEL, 0, sizeof(T_FilterChnInfo) * MAX_TX_CHANNEL);
        }
        return s_filterNrChnInfo;
    }
    else if (BSP_RADIO_STANDARD_LTE_FDD == radio) //FDD LTE
    {
        if (s_filterLteChnInfo == NULL)
        {
            s_filterLteChnInfo = (T_FilterChnInfo *)malloc(sizeof(T_FilterChnInfo) * MAX_TX_CHANNEL);
            if (s_filterLteChnInfo == NULL)
            {
                return NULL;
            }
            zte_memset_s(s_filterLteChnInfo, sizeof(T_FilterChnInfo) * MAX_TX_CHANNEL, 0, sizeof(T_FilterChnInfo) * MAX_TX_CHANNEL);
        }
        return s_filterLteChnInfo;
    }

    return NULL;
}
/* Ended by AICoder, pid:q3023g020439d7d140730a40e060eb46e484f9d9 */

/* Started by AICoder, pid:yaabd5c212s5e261489e08c1803ab63381a1d75f */
T_FilterChnInfo *BspGetUlFilterChnInfoMem(UINT32 radio)
{
    if (BSP_RADIO_STANDARD_FDD_5G == radio)//FDD NR
    {
        if (s_filterUlNrChnInfo == NULL)
        {
            s_filterUlNrChnInfo = (T_FilterChnInfo *)malloc(sizeof(T_FilterChnInfo) * MAX_RX_CHANNEL);
            if (s_filterUlNrChnInfo == NULL)
            {
                return NULL;
            }
            zte_memset_s(s_filterUlNrChnInfo, sizeof(T_FilterChnInfo) * MAX_RX_CHANNEL, 0, sizeof(T_FilterChnInfo) * MAX_RX_CHANNEL);
        }
        return s_filterUlNrChnInfo;
    }
    else if (BSP_RADIO_STANDARD_LTE_FDD == radio) //FDD LTE
    {
        if (s_filterUlLteChnInfo == NULL)
        {
            s_filterUlLteChnInfo = (T_FilterChnInfo *)malloc(sizeof(T_FilterChnInfo) * MAX_RX_CHANNEL);
            if (s_filterUlLteChnInfo == NULL)
            {
                return NULL;
            }
            zte_memset_s(s_filterUlLteChnInfo, sizeof(T_FilterChnInfo) * MAX_RX_CHANNEL, 0, sizeof(T_FilterChnInfo) * MAX_RX_CHANNEL);
        }
        return s_filterUlLteChnInfo;
    }

    return NULL;
}
/* Ended by AICoder, pid:yaabd5c212s5e261489e08c1803ab63381a1d75f */

/**********************************************************************
* 函数名称：BspGetPublicDlFilterPara
* 功能描述：获取当前单边滤波参数
* 输入参数：参数0:通道，参数1:载波号，参数2:制式，参数3：滤波相关参数
* 返 回 值：BSP_OK - 成功; 其它值为失败
* 其它说明：高层调用；当前制式默认按照UMTS的单边滤波实现。
***********************************************************************/
UINT32 BspGetPublicDlFilterPara(UINT32 bspChan, UINT32 carrNo, UINT32 radioMod, T_carrFilterPara *carrPara)
{
    UINT32 ret      = BSP_OK;
    UINT32 chipId   = 0;
    UINT32 difChan  = 0;
    T_FilterChnInfo *filterChnInfo = BspGetFilterChnInfoMem(radioMod);

    if ((NULL == carrPara) || (NULL == filterChnInfo))
    {
        return ERROR_NULL_POINTER;
    }

    ret = BspGetDifInfoByBspChn(bspChan, TX, &chipId, &difChan);

    if ((difChan >= MAX_TX_CHANNEL) || (carrNo >= BSP_MAX_CARR_NUM))
    {
        BspLog(LOG_LEVEL_0,"[%s]:difChan'%d or carrNo'%d out bounds error!\n",__FUNCTION__,difChan,carrNo);
        return BSP_ERROR;
    }

    carrPara->cpgbandWidth = filterChnInfo[difChan].carrInfo[carrNo].cpgbandWidth;
    carrPara->rcfbandwidth = filterChnInfo[difChan].carrInfo[carrNo].rcfbandwidth;
    carrPara->nco1 = filterChnInfo[difChan].carrInfo[carrNo].nco1;
    carrPara->nco2 = filterChnInfo[difChan].carrInfo[carrNo].nco2;
    carrPara->fi = filterChnInfo[difChan].carrInfo[carrNo].fi;

    dbgInfoEx("[%s]: bspChan'%d, carrNo'%d, radio%d, cpgbandWidth'%d, rcfbandwidth'%d, Nco1'%d, Nco2'%d\n"
                ,__FUNCTION__, bspChan, carrNo, radioMod, carrPara->cpgbandWidth, carrPara->rcfbandwidth, carrPara->nco1, carrPara->nco2);

    return ret;
}

/* Started by AICoder, pid:d2c92q488bh7ef9148ef082890c6aa3c2080d7d1 */
UINT32 BspGetPublicUlFilterPara(UINT32 bspChan, UINT32 carrNo, UINT32 radio, T_carrFilterPara *carrPara)
{
    UINT32 ret  = BSP_OK;
    UINT32 chipId   = 0;
    UINT32 difChan  = 0;
    T_FilterChnInfo *filterChnInfo = BspGetUlFilterChnInfoMem(radio);

    if ((NULL == carrPara) || (NULL == filterChnInfo))
    {
        return ERROR_NULL_POINTER;
    }

    ret = BspGetDifInfoByBspChn(bspChan, RX, &chipId, &difChan);
    if ((ret != BSP_OK) || (difChan >= MAX_RX_CHANNEL) || (carrNo >= BSP_MAX_CARR_NUM))
    {
        dbgErr("[%s]:difChan'%d or carrNo'%d out bounds error!, ret=%d\n", __FUNCTION__, difChan, carrNo, ret);
        return BSP_ERROR;
    }

    carrPara->rcfbandwidth = filterChnInfo[difChan].carrInfo[carrNo].rcfbandwidth;
    carrPara->nco1 = filterChnInfo[difChan].carrInfo[carrNo].nco1;
    carrPara->nco2 = filterChnInfo[difChan].carrInfo[carrNo].nco2;

    dbgInfoEx("[%s]: bspChan'%d, carrNo'%d, radio%d, rcfbandwidth'%d, Nco1'%d, Nco2'%d\n"
                ,__FUNCTION__, bspChan, carrNo, radio, carrPara->rcfbandwidth, carrPara->nco1, carrPara->nco2);

    return ret;
}
/* Ended by AICoder, pid:d2c92q488bh7ef9148ef082890c6aa3c2080d7d1 */

/* Started by AICoder, pid:i4a45lfcdd2c4ec14d6a0aae40755c536ab72090 */
/*****************************************************************************
*  函数名称   : BspGetFilterBw
*  功能描述   : 获取单边滤波载波带宽
*  输入参数   : difchan: 中频通道号
               carrNo: 载波号
               radioMod: 制式
*  输出参数   : filterBw: 单边滤波后带宽
*  返 回 值   : BSP_OK  - 成功;其它值为失败
*  其它说明   : 从全局变量查询, 若取出的带宽值为0，则该载波未进行滤波。
*----------------------------------------------------------------------------*/
UINT32 BspGetFilterBw(UINT32 difChan, UINT32 carrNo, UINT32 radioMod, UINT32 *filterBw)
{
    UINT32 ret = BSP_OK;
    T_carrFilterPara filterPara = {0};

    INPUT_POINTER_CHECK(filterBw);
    if ((difChan >= MAX_TX_CHANNEL) || (carrNo >= BSP_MAX_CARR_NUM))
    {
        BspLog(LOG_LEVEL_0,"[%s]:difChan'%d or carrNo'%d out bounds error!\n",__FUNCTION__,difChan,carrNo);
        return BSP_ERROR;
    }

    if ((BSP_RADIO_STANDARD_UMTS == radioMod)
        || (BSP_RADIO_STANDARD_FDD_5G == radioMod)
        || (BSP_RADIO_STANDARD_LTE_FDD == radioMod))
    {
        ret |= BspGetPublicDlFilterPara(difChan, carrNo, radioMod, &filterPara);
        *filterBw = filterPara.rcfbandwidth;
    }
    else
    {
        *filterBw = 0;
    }

    dbgInfoEx("[%s]: difChan'%d, carrNo'%d, radioMod'0x%x, filterBw'%d\n",__FUNCTION__, difChan, carrNo, radioMod, *filterBw);

    return ret;
}

UINT32 BspGetUlFilterBw(UINT32 difChan, UINT32 carrNo, UINT32 radioMod, UINT32 *filterBw)
{
    UINT32 ret = BSP_OK;
    T_carrFilterPara filterPara = {0};

    INPUT_POINTER_CHECK(filterBw);
    if ((difChan >= MAX_RX_CHANNEL) || (carrNo >= BSP_MAX_CARR_NUM))
    {
        BspLog(LOG_LEVEL_0,"[%s]:difChan'%d or carrNo'%d out bounds error!\n",__FUNCTION__,difChan,carrNo);
        return BSP_ERROR;
    }

    if ((BSP_RADIO_STANDARD_UMTS == radioMod)
        || (BSP_RADIO_STANDARD_FDD_5G == radioMod)
        || (BSP_RADIO_STANDARD_LTE_FDD == radioMod))
    {
        ret |= BspGetPublicUlFilterPara(difChan, carrNo, radioMod, &filterPara);
        *filterBw = filterPara.rcfbandwidth;
    }
    else
    {
        *filterBw = 0;
    }

    dbgInfoEx("[%s]: difChan'%d, carrNo'%d, radioMod'0x%x, filterBw'%d\n",__FUNCTION__, difChan, carrNo, radioMod, *filterBw);

    return ret;
}
/* Ended by AICoder, pid:i4a45lfcdd2c4ec14d6a0aae40755c536ab72090 */

UINT32 showsidefilter(UINT32 bspChan, UINT32 carrNo, UINT32 radio)
{
    UINT32 ret = BSP_OK;
    T_carrFilterPara carrPara = {0};

    ret = BspGetPublicDlFilterPara(bspChan, carrNo, radio, &carrPara);
    dbgPrn("[TX]bspChan=%u carrNo=%u radio=%u nco1=%d nco2=%d rcfbw=%u cpgbw=%u\n",
            bspChan, carrNo, radio, carrPara.nco1, carrPara.nco2, carrPara.rcfbandwidth, carrPara.cpgbandWidth);

    ret |= BspGetPublicUlFilterPara(bspChan, carrNo, radio, &carrPara);
    dbgPrn("[RX]bspChan=%u carrNo=%u radio=%u nco1=%d nco2=%d rcfbw=%u\n",
            bspChan, carrNo, radio, carrPara.nco1, carrPara.nco2, carrPara.rcfbandwidth);
    return ret;
}

/* 设置当前单边滤波参数, cpgbandWidth:单边滤波时获取CPG系数时的带宽 */
UINT32 BspSetDlFilterCpgBw(UINT32 difChan, UINT32 carrNo, UINT32 radio, UINT32 cpgbandWidth)
{
    T_FilterChnInfo *filterChnInfo = BspGetFilterChnInfoMem(radio);
    INPUT_POINTER_CHECK(filterChnInfo);
    if ((carrNo < BSP_MAX_CARR_NUM) && (difChan < MAX_TX_CHANNEL))
    {
        filterChnInfo[difChan].carrInfo[carrNo].cpgbandWidth = cpgbandWidth;
        dbgInfoEx("[%s]: difChan'%d, carrNo'%d, cpgbandWidth'%d\n",__FUNCTION__, difChan, carrNo, cpgbandWidth);
    }
    else
    {
       BspLog(LOG_LEVEL_0,"[%s]: difChan'%d or carrNo'%d out of range! ",__FUNCTION__, difChan, carrNo);
       return BSP_ERROR;
    }

    return BSP_OK;
}

/* 设置当前单边滤波参数, rcfbandwidth:单边滤波时获取成型滤波器系数的UMTS带宽 */
UINT32 BspSetDlFilterRcfBw(UINT32 difChan, UINT32 carrNo, UINT32 radio, UINT32 rcfbandwidth)
{
    T_FilterChnInfo *filterChnInfo = BspGetFilterChnInfoMem(radio);
    INPUT_POINTER_CHECK(filterChnInfo);
    if ((carrNo < BSP_MAX_CARR_NUM) && (difChan < MAX_TX_CHANNEL))
    {
        filterChnInfo[difChan].carrInfo[carrNo].rcfbandwidth = rcfbandwidth;
        dbgInfoEx("[%s]: difChan'%d, carrNo'%d, rcfbandwidth'%d\n",__FUNCTION__, difChan, carrNo, rcfbandwidth);
    }
    else
    {
       BspLog(LOG_LEVEL_0,"[%s]: difChan'%d or carrNo'%d out of range! ",__FUNCTION__, difChan, carrNo);
       return BSP_ERROR;
    }

    return BSP_OK;
}

UINT32 BspSetUlFilterRcfBw(UINT32 difChan, UINT32 carrNo, UINT32 radio, UINT32 rcfbandwidth)
{
    T_FilterChnInfo *filterChnInfo = BspGetUlFilterChnInfoMem(radio);
    INPUT_POINTER_CHECK(filterChnInfo);
    if ((carrNo >= BSP_MAX_CARR_NUM) || (difChan >= MAX_RX_CHANNEL))
    {
        BspLog(LOG_LEVEL_0,"[%s]: difChan'%d or carrNo'%d out of range! ",__FUNCTION__, difChan, carrNo);
        return BSP_ERROR;
    }

    filterChnInfo[difChan].carrInfo[carrNo].rcfbandwidth = rcfbandwidth;
    dbgInfoEx("[%s]: difChan'%d, carrNo'%d, rcfbandwidth'%d\n",__FUNCTION__, difChan, carrNo, rcfbandwidth);

    return BSP_OK;
}


/* 设置当前单边滤波参数, swFreqOffset:单边滤波时的成型前NCO */
UINT32 BspSetDlFilterNcoFront(UINT32 difChan, UINT32 carrNo, UINT32 radio, INT32 swFreqOffset)
{
    T_FilterChnInfo *filterChnInfo = BspGetFilterChnInfoMem(radio);
    INPUT_POINTER_CHECK(filterChnInfo);
    if ((carrNo < BSP_MAX_CARR_NUM) && (difChan < MAX_TX_CHANNEL))
    {
        filterChnInfo[difChan].carrInfo[carrNo].nco1 = swFreqOffset;
        dbgInfoEx("[%s]: difChan'%d, carrNo'%d, swFreqOffset'%d\n",__FUNCTION__, difChan, carrNo, swFreqOffset);
    }
    else
    {
       BspLog(LOG_LEVEL_0,"[%s]: difChan'%d or carrNo'%d out of range! ",__FUNCTION__, difChan, carrNo);
       return BSP_ERROR;
    }

    return BSP_OK;
}

/* 设置单边滤波参数成型后nco, freqOffset: centFreq - NCO1 */
UINT32 BspSetDlFilterNcoBehind(UINT32 difChan, UINT32 carrNo, UINT32 radio, INT32 freqOffset)
{
    T_FilterChnInfo *filterChnInfo = BspGetFilterChnInfoMem(radio);
    INPUT_POINTER_CHECK(filterChnInfo);
    if ((carrNo < BSP_MAX_CARR_NUM) && (difChan < MAX_TX_CHANNEL))
    {
        filterChnInfo[difChan].carrInfo[carrNo].nco2 = freqOffset;
        dbgInfoEx("[%s]: difChan'%d, carrNo'%d, freqOffset'%d\n",__FUNCTION__, difChan, carrNo, freqOffset);
    }
    else
    {
       BspLog(LOG_LEVEL_0,"[%s]: difChan'%d or carrNo'%d out of range! ",__FUNCTION__, difChan, carrNo);
       return BSP_ERROR;
    }

    return BSP_OK;
}

UINT32 BspSetUlFilterNcoFront(UINT32 difChan, UINT32 carrNo, UINT32 radio, INT32 swFreqOffset)
{
    T_FilterChnInfo *filterChnInfo = BspGetUlFilterChnInfoMem(radio);
    INPUT_POINTER_CHECK(filterChnInfo);
    if ((difChan >= MAX_RX_CHANNEL) || (carrNo >= BSP_MAX_CARR_NUM))
    {
        dbgErr("[%s]: difChan'%d or carrNo'%d out of range!\n",__FUNCTION__, difChan, carrNo);
        return BSP_ERROR;
    }

    filterChnInfo[difChan].carrInfo[carrNo].nco2 = swFreqOffset;
    dbgInfoEx("[%s]: difChan'%d, carrNo'%d, swFreqOffset'%d\n",__FUNCTION__, difChan, carrNo, swFreqOffset);

    return BSP_OK;
}

UINT32 BspSetUlFilterNcoBehind(UINT32 difChan, UINT32 carrNo, UINT32 radio, INT32 swFreqOffset)
{
    T_FilterChnInfo *filterChnInfo = BspGetUlFilterChnInfoMem(radio);
    INPUT_POINTER_CHECK(filterChnInfo);
    if ((difChan >= MAX_RX_CHANNEL) || (carrNo >= BSP_MAX_CARR_NUM))
    {
        dbgErr("[%s]: difChan'%d or carrNo'%d out of range!\n",__FUNCTION__, difChan, carrNo);
        return BSP_ERROR;
    }

    filterChnInfo[difChan].carrInfo[carrNo].nco1 = swFreqOffset;
    dbgInfoEx("[%s]: difChan'%d, carrNo'%d, swFreqOffset'%d\n",__FUNCTION__, difChan, carrNo, swFreqOffset);

    return BSP_OK;
}

UINT32 BspSetCfrFreqFiOffset(UINT32 difChan, UINT32 carrNo, UINT32 radio, UINT32 offset)
{
    T_FilterChnInfo *filterChnInfo = BspGetFilterChnInfoMem(radio);
    INPUT_POINTER_CHECK(filterChnInfo);
    if ((carrNo < BSP_MAX_CARR_NUM) && (difChan < MAX_TX_CHANNEL))
    {
        filterChnInfo[difChan].carrInfo[carrNo].fi = offset;
        dbgInfoEx("[%s]: difChan'%d, carrNo'%d, offset'%d\n",__FUNCTION__, difChan, carrNo, offset);
    }
    else
    {
       BspLog(LOG_LEVEL_0,"[%s]: difChan'%d or carrNo'%d out of range! ",__FUNCTION__, difChan, carrNo);
       return BSP_ERROR;
    }

    return BSP_OK;
}

/*获取配置到HAL层的NCO*/
UINT32 BspGetCfrFreqFiOffset(UINT32 difChan, UINT32 carrNo, UINT32 radioMod, INT32 *fi)
{
    UINT32 ret = BSP_OK;
    T_carrFilterPara filterPara = {0};

    INPUT_POINTER_CHECK(fi);
    if ((difChan >= MAX_TX_CHANNEL) || (carrNo >= BSP_MAX_CARR_NUM))
    {
        BspLog(LOG_LEVEL_0,"[%s]:difChan'%d or carrNo'%d out bounds error!\n",__FUNCTION__,difChan,carrNo);
        return BSP_ERROR;
    }

    if ((BSP_RADIO_STANDARD_UMTS == radioMod)
        || (BSP_RADIO_STANDARD_FDD_5G == radioMod)
        || (BSP_RADIO_STANDARD_LTE_FDD == radioMod))
    {
        ret |= BspGetPublicDlFilterPara(difChan, carrNo, radioMod, &filterPara);
        *fi = filterPara.fi;
    }
    else
    {
        *fi = 0;
    }

    dbgInfoEx("[%s]: difChan'%d, carrNo'%d, radioMod'0x%x, fi'%d\n",__FUNCTION__, difChan, carrNo, radioMod, *fi);

    return ret;
}

/* 获取单边滤波成型前NCO */
UINT32 BspGetFilterNcoFront(UINT32 difChan, UINT32 carrNo, UINT32 radioMod, INT32 *ncoFront)
{
    UINT32 ret = BSP_OK;
    T_carrFilterPara filterPara = {0};

    INPUT_POINTER_CHECK(ncoFront);
    if ((difChan >= MAX_TX_CHANNEL) || (carrNo >= BSP_MAX_CARR_NUM))
    {
        BspLog(LOG_LEVEL_0,"[%s]:difChan'%d or carrNo'%d out bounds error!\n", __FUNCTION__, difChan, carrNo);
        return BSP_ERROR;
    }

    if ((BSP_RADIO_STANDARD_UMTS == radioMod)
        || (BSP_RADIO_STANDARD_FDD_5G == radioMod)
        || (BSP_RADIO_STANDARD_LTE_FDD == radioMod))
    {
        ret |= BspGetPublicDlFilterPara(difChan, carrNo, radioMod, &filterPara);
        *ncoFront = filterPara.nco1;
    }
    else
    {
        *ncoFront = 0;
    }

    dbgInfoEx("[%s]: difChan'%d, carrNo'%d, radioMod'0x%x, ncoFront'%d\n",__FUNCTION__, difChan, carrNo, radioMod, *ncoFront);

    return ret;
}

/* Started by AICoder, pid:00383ffa80c49dc14e430826000f00991da85949 */
UINT32 BspGetUlFilterNcoFront(UINT32 difChan, UINT32 carrNo, UINT32 radioMod, INT32 *ncoFront)
{
    UINT32 ret = BSP_OK;
    T_carrFilterPara filterPara = {0};

    INPUT_POINTER_CHECK(ncoFront);
    if ((difChan >= MAX_RX_CHANNEL) || (carrNo >= BSP_MAX_CARR_NUM))
    {
        BspLog(LOG_LEVEL_0,"[%s]:difChan'%d or carrNo'%d out bounds error!\n", __FUNCTION__, difChan, carrNo);
        return BSP_ERROR;
    }

    if ((BSP_RADIO_STANDARD_UMTS == radioMod)
        || (BSP_RADIO_STANDARD_FDD_5G == radioMod)
        || (BSP_RADIO_STANDARD_LTE_FDD == radioMod))
    {
        ret |= BspGetPublicUlFilterPara(difChan, carrNo, radioMod, &filterPara);
        *ncoFront = filterPara.nco1;
    }
    else
    {
        *ncoFront = 0;
    }

    dbgInfoEx("[%s]: difChan'%d, carrNo'%d, radioMod'0x%x, ncoFront'%d\n",__FUNCTION__, difChan, carrNo, radioMod, *ncoFront);

    return ret;
}

UINT32 BspJudgeCarrFilter(UINT32 difChn, UINT32 dir, UINT32 carrNo, UINT32 carrRadio)
{
    UINT32 retVal = BSP_OK;
    UINT32 filterBw = 0;
    UINT32 rfChan = 0;
    UINT32 carrLoop = 0;
    UINT32 carrBw = 0;
    UINT32 carrNum = 0;
    INT32 ncoFront = 0;
    T_RruRfCfgInfo *pRfCfgInfo = NULL;

    if (dir == PRX)
    {
        dbgErr("[%s] dir:%d, out of range.\n", __FUNCTION__, dir);
        return BSP_ERROR;
    }

    pRfCfgInfo = malloc(sizeof(T_RruRfCfgInfo));
    INPUT_POINTER_CHECK(pRfCfgInfo);

    retVal |= BspGetRfChnInfoByDifChn(difChn, dir, &rfChan);
    retVal |= BspGetChnlCfgCarrPara(rfChan, pRfCfgInfo);

    if (dir == TX)
    {
        carrNum = pRfCfgInfo->txCfgCarrSum;
        for (carrLoop = 0; carrLoop < carrNum; carrLoop ++)
        {
            if ((pRfCfgInfo->carr[carrLoop].carrTxNo == carrNo) && (pRfCfgInfo->carr[carrLoop].carrTxRadio == carrRadio))
            {
                carrBw = pRfCfgInfo->carr[carrLoop].carrTxBw;
                break;
            }
        }

        retVal |= BspGetFilterBw(difChn, carrNo, carrRadio, &filterBw);
        retVal |= BspGetFilterNcoFront(difChn, carrNo, carrRadio, &ncoFront);
    }

    if (dir == RX)
    {
        carrNum = pRfCfgInfo->rxCfgCarrSum;
        for (carrLoop = 0; carrLoop < carrNum; carrLoop ++)
        {
            if ((pRfCfgInfo->carr[carrLoop].carrRxNo == carrNo) && (pRfCfgInfo->carr[carrLoop].carrRxRadio == carrRadio))
            {
                carrBw = pRfCfgInfo->carr[carrLoop].carrRxBw;
                break;
            }
        }

        retVal |= BspGetUlFilterBw(difChn, carrNo, carrRadio, &filterBw);
        retVal |= BspGetUlFilterNcoFront(difChn, carrNo, carrRadio, &ncoFront);
    }

    dbgInfoEx("[%s]: difChn'%d, carrNo'%d, carrRadio'0x%x, carrBw'%d, filterBw'%d, ncoFront'%d, retVal'%d\n",
                __FUNCTION__, difChn, carrNo, carrRadio, carrBw, filterBw, ncoFront, retVal);

    /*非单边滤波*/
    if ((0 == carrBw) || (0 == filterBw))
    {
        free(pRfCfgInfo);
        return BSP_ERROR;
    }

    /*单边滤波*/
    if ((retVal == BSP_OK) && ((0 != ncoFront) || (filterBw != carrBw)))
    {
        free(pRfCfgInfo);
        return retVal;
    }

    free(pRfCfgInfo);
    return BSP_ERROR;
}
/* Ended by AICoder, pid:00383ffa80c49dc14e430826000f00991da85949 */

/* Started by AICoder, pid:36840z6525j2f47142d50b6171b7f50d00536d17 */
UINT32 BspJudgeCarrFilterByCpg(UINT32 difChn, UINT32 dir, UINT32 carrNo, UINT32 carrRadio)
{
    UINT32 retVal = BSP_OK;
    UINT32 filterBw = 0;
    UINT32 rfChan = 0;
    UINT32 carrLoop = 0;
    UINT32 carrBw = 0;
    UINT32 carrNum = 0;
    INT32 ncoFront = 0;
    T_RruRfCfgInfo *pRfCfgInfo = NULL;

    if (dir == PRX)
    {
        dbgErr("[%s] dir:%d, out of range.\n", __FUNCTION__, dir);
        return BSP_ERROR;
    }

    pRfCfgInfo = malloc(sizeof(T_RruRfCfgInfo));
    INPUT_POINTER_CHECK(pRfCfgInfo);

    retVal |= BspGetRfChnInfoByDifChn(difChn, dir, &rfChan);
    retVal |= BspGetChnlCfgCarrPara(rfChan, pRfCfgInfo);

    if (dir == TX)
    {
        carrNum = pRfCfgInfo->txCfgCarrSum;
        for (carrLoop = 0; carrLoop < carrNum; carrLoop ++)
        {
            if ((pRfCfgInfo->carr[carrLoop].carrTxNo == carrNo) && (pRfCfgInfo->carr[carrLoop].carrTxRadio == carrRadio))
            {
                carrBw = pRfCfgInfo->carr[carrLoop].carrTxBw;
                break;
            }
        }

        retVal |= BspGetFilterBwByCpg(difChn, carrNo, carrRadio, &filterBw);
        retVal |= BspGetFilterNcoFront(difChn, carrNo, carrRadio, &ncoFront);
    }

    if (dir == RX)
    {
        carrNum = pRfCfgInfo->rxCfgCarrSum;
        for (carrLoop = 0; carrLoop < carrNum; carrLoop ++)
        {
            if ((pRfCfgInfo->carr[carrLoop].carrRxNo == carrNo) && (pRfCfgInfo->carr[carrLoop].carrRxRadio == carrRadio))
            {
                carrBw = pRfCfgInfo->carr[carrLoop].carrRxBw;
                break;
            }
        }

        retVal |= BspGetUlFilterBwByCpg(difChn, carrNo, carrRadio, &filterBw);
        retVal |= BspGetUlFilterNcoFront(difChn, carrNo, carrRadio, &ncoFront);
    }

    dbgInfoEx("[%s]: difChn'%d, carrNo'%d, carrRadio'0x%x, carrBw'%d, filterBw'%d, ncoFront'%d, retVal'%d\n",
                __FUNCTION__, difChn, carrNo, carrRadio, carrBw, filterBw, ncoFront, retVal);

    /*非单边滤波*/
    if ((0 == carrBw) || (0 == filterBw))
    {
        free(pRfCfgInfo);
        return BSP_ERROR;
    }

    /*单边滤波*/
    if ((retVal == BSP_OK) && ((0 != ncoFront) || (filterBw != carrBw)))
    {
        free(pRfCfgInfo);
        return retVal;
    }

    free(pRfCfgInfo);
    return BSP_ERROR;
}
/* Ended by AICoder, pid:36840z6525j2f47142d50b6171b7f50d00536d17 */

/* Started by AICoder, pid:25a87me474i2c33145e109a140f9d46e2034caf2 */
UINT32 BspClrSideFilterNco(VOID)
{
    if (s_filterChnInfo != NULL)
    {
        zte_memset_s(s_filterChnInfo, sizeof(T_FilterChnInfo) * MAX_TX_CHANNEL, 0, sizeof(T_FilterChnInfo) * MAX_TX_CHANNEL);
    }

    if (s_filterNrChnInfo != NULL)
    {
        zte_memset_s(s_filterNrChnInfo, sizeof(T_FilterChnInfo) * MAX_TX_CHANNEL, 0, sizeof(T_FilterChnInfo) * MAX_TX_CHANNEL);
    }

    if (s_filterLteChnInfo != NULL)
    {
        zte_memset_s(s_filterLteChnInfo, sizeof(T_FilterChnInfo) * MAX_TX_CHANNEL, 0, sizeof(T_FilterChnInfo) * MAX_TX_CHANNEL);
    }

    if (s_filterUlNrChnInfo != NULL)
    {
        zte_memset_s(s_filterUlNrChnInfo, sizeof(T_FilterChnInfo) * MAX_RX_CHANNEL, 0, sizeof(T_FilterChnInfo) * MAX_RX_CHANNEL);
    }

    if (s_filterUlLteChnInfo != NULL)
    {
        zte_memset_s(s_filterUlLteChnInfo, sizeof(T_FilterChnInfo) * MAX_RX_CHANNEL, 0, sizeof(T_FilterChnInfo) * MAX_RX_CHANNEL);
    }

    return BSP_OK;
}
/* Ended by AICoder, pid:25a87me474i2c33145e109a140f9d46e2034caf2 */

/* Started by AICoder, pid:j89cas4d82m89d0149c8082820f7dd6bfcd41946 */
UINT32 BspSetTxRxCarrFreq(UINT32 bspChan, UINT32 carrNo, UINT32 radioMode, UINT32 dir,UINT32 carrFreq)
{
    INT32  bandNcoBase = 0;
    UINT32 retVal = BSP_OK;
    UINT32 chipId = 0;
    UINT32 difChan = 0;
    INT32 offset = 0;
    UINT32 centFreq = 0;

    CHECK_BSPCHN(bspChan);
    freqCfgExLog(FREQCFG_NCO,"[%s] start!\n", __FUNCTION__);
    if((dir == TX) && (txRfPllCfgInit[bspChan].cfgSolution != BSP_FREQ_DYNAMIC_LO))
    {
        if(1 == txRfPllCfgInit[bspChan].bandNcoFlag)
        {
            bandNcoBase = txRfPllCfgInit[bspChan].bandNcoBase;
            dbgInfo("%s [%d] bspChan: %d bandNcoBase: %d \n",
            __FUNCTION__, __LINE__, bspChan, bandNcoBase);
        }
    }
    if((dir == RX) && (rxRfPllCfgInit[bspChan].cfgSolution != BSP_FREQ_DYNAMIC_LO))
    {
        if(1 == rxRfPllCfgInit[bspChan].bandNcoFlag)
        {
            bandNcoBase = rxRfPllCfgInit[bspChan].bandNcoBase;
            dbgInfo("%s [%d] bspChan: %d bandNcoBase: %d \n",
            __FUNCTION__, __LINE__, bspChan, bandNcoBase);
        }
    }

    retVal = BspGetDifInfoByBspChn(bspChan, dir, &chipId, &difChan);
    if(BSP_OK != retVal)
    {
        BspLog(LOG_LEVEL_0,"%s:get chan%d dir%d difChan err!\n",__FUNCTION__,dir, bspChan);
        return retVal;
    }
    centFreq = BspGetBandFreq(dir, bspChan, BAND_NO_0);
    if (dir == TX)
    {
        offset = carrFreq-centFreq-bandNcoBase;
        retVal = BspHalAdaptSetTxBankNco(difChan,carrNo,radioMode,offset);
    }
    else
    {
        offset = centFreq + bandNcoBase -carrFreq;
        retVal = BspHalAdaptSetRxBankNco(difChan,carrNo,radioMode,offset);
        if (BSP_OK == BspJudgeCarrFilter(difChan, dir, carrNo, radioMode))
        {
            retVal |= BspSetSideFilterRxNco(bspChan, carrNo, radioMode, 0);
        }
    }
    freqCfgExLog(FREQCFG_NCO,"%s:dir%d chan%d carr%d carrFreq:%d, centFreq:%d, carrNco:%d bandNcoBase %d\n",__FUNCTION__,dir,\
            bspChan, carrNo,carrFreq, centFreq, offset,bandNcoBase);
    freqCfgExLog(FREQCFG_NCO,"[%s] end!\n", __FUNCTION__);

    return retVal;
}
/* Ended by AICoder, pid:j89cas4d82m89d0149c8082820f7dd6bfcd41946 */

/*获取下行中频通道的载波数*/
UINT32 BspIsExistTxLink(UINT32 bspChan, UINT32 *txCarrNum)
{
    UINT32 retVal = 0;
    UINT32 chipId = 0;
    UINT32 difChan = 0;

    retVal = BspGetDifInfoByBspChn(bspChan, TX, &chipId, &difChan);
    if(BSP_OK != retVal)
    {
        BspLog(LOG_LEVEL_0,"%s TX bspChan[%d] Get DifChan err\n", __FUNCTION__, bspChan);
        return BSP_ERROR;
    }

    retVal = BspHalAdaptGetTxCarrNum(difChan, txCarrNum);

    return retVal;
}

/*获取上行中频通道的载波数*/
UINT32 BspIsExistRxLink(UINT32 bspChan, UINT32 *rxCarrNum)
{
    UINT32 retVal = 0;
    UINT32 chipId = 0;
    UINT32 difChan = 0;

    retVal = BspGetDifInfoByBspChn(bspChan, RX, &chipId, &difChan);
    if(BSP_OK != retVal)
    {
        BspLog(LOG_LEVEL_0,"%s RX bspChan[%d] Get DifChan err\n", __FUNCTION__, bspChan);
        return BSP_ERROR;
    }

    retVal = BspHalAdaptGetRxCarrNum(difChan, rxCarrNum);

    return retVal;
}

UINT32 BspGetCarrInfoIsValid(UINT32 bspChan, UINT32 carrId, UINT32 carrRadio, UINT32 dir, UINT32 *validFlag)
{
    UINT32 retVal = 0;
    UINT32 chipId = 0;
    UINT32 difChan = 0;

    INPUT_POINTER_CHECK(validFlag);

    retVal = BspGetDifInfoByBspChn(bspChan, dir, &chipId, &difChan);
    if(BSP_OK != retVal)
    {
        dbgErr("[%s] dir = %d bspChan[%d] Get DifChan err\n", __FUNCTION__, dir, bspChan);
        return BSP_ERROR;
    }

    retVal = BspHalAdaptIsCarrValid(difChan, carrId, carrRadio, dir, validFlag);
    BspLog(LOG_LEVEL_0,"[%s]dir=%d,difChan[%d],carrId[%d],carrRadio[%d],validFlag[%d]\n",__FUNCTION__, dir, difChan, carrId, carrRadio, *validFlag);

    return retVal;
}

/* 设置发射链路Guard Band NCO（单位：Hz） */
UINT32 BspSetTxNbGuardOffset(UINT32 difChan, UINT32 carrNo, UINT32 radioMode, INT32 offset)
{
    return BspHalAdaptSetTxGuardBandNco(difChan, carrNo, radioMode, offset);
}

/* 设置接收链路Guard Band NCO（单位：Hz） */
UINT32 BspSetRxNbGuardOffset(UINT32 difChan, UINT32 carrNo, UINT32 radioMode, INT32 offset)
{   
    return BspHalAdaptSetRxGuardBandNco(difChan, carrNo, radioMode, offset);
}

/*检查上行LTE、NR载波的带宽和采样率 */
UINT32 BspCheckUlCarryInfo(UINT32 uiBandWidth, UINT32 uiSampelRate, UINT32 uiCarrRadio)
{
      UINT32 retVal = BSP_OK;
      retVal = BspHalAdaptCheckDlCarryInfo(uiBandWidth, uiSampelRate, uiCarrRadio);
      if(retVal!= BSP_OK)
      {
          BspLog(LOG_LEVEL_0,"%s [%d] BspCheckUlCarryInfo is error\n", __FUNCTION__, __LINE__);
          return BSP_ERROR;
      }
      return retVal;
}

/*检查下行LTE、NR载波的带宽和采样率 */
UINT32 BspCheckDlCarryInfo(UINT32 uiBandWidth, UINT32 uiSampelRate, UINT32 uiCarrRadio)
{
      UINT32 retVal = BSP_OK;
      retVal = BspHalAdaptCheckDlCarryInfo(uiBandWidth, uiSampelRate, uiCarrRadio);
      if(retVal!= BSP_OK)
      {
          BspLog(LOG_LEVEL_0,"%s [%d] BspCheckDlCarryInfo is error\n", __FUNCTION__, __LINE__);
          return BSP_ERROR;
      }
      return retVal;
}

UINT32 BspSetTxdefLoFreq(UINT32 bspChan,UINT32 defLoFreqKHz)
{
	txRfPllCfgInit[bspChan].defLoFreqKHz = defLoFreqKHz;
	return BSP_OK;
}
UINT32 BspGetTxdefLoFreq(UINT32 bspChan)
{
	return txRfPllCfgInit[bspChan].defLoFreqKHz ;
}

UINT32 BspSetRxdefLoFreq(UINT32 bspChan,UINT32 defLoFreqKHz)
{
	rxRfPllCfgInit[bspChan].defLoFreqKHz = defLoFreqKHz;
	return BSP_OK;
}
UINT32 BspGetRxdefLoFreq(UINT32 bspChan)
{
	return rxRfPllCfgInit[bspChan].defLoFreqKHz ;
}

UINT32 BspSetTxBandNco(UINT32 bspChan, INT32 bandNco)
{
    txRfPllCfgInit[bspChan].bandNcoBase = bandNco;
    return BSP_OK;
}

INT32 BspGetTxBandNco(UINT32 bspChan)
{
    return txRfPllCfgInit[bspChan].bandNcoBase ;
}

INT32 BspGetTxAcBandNco(UINT32 bspChan)
{
    return txRfPllCfgInit[bspChan].WfsAcNcoBase ;
}

/* Started by AICoder, pid:f9f445ef9cu09451473f085f4054f839f010e00e */
UINT32 BspGetTxAcLoToCarrThre(UINT32 bspChan)
{
    return txRfPllCfgInit[bspChan].loToCarrThre ;
}

VOID BspSetTxAcLoToCarrThre(UINT32 bspChan, UINT32 loToCarrThre)
{
    txRfPllCfgInit[bspChan].loToCarrThre = loToCarrThre ;
}
/* Ended by AICoder, pid:f9f445ef9cu09451473f085f4054f839f010e00e */

INT32 BspGetRxBandNco(UINT32 bspChan)
{
    /***此处为CERT CTR50-CPP误告警，如下抑制告警***/
    //coverity[cert_ctr50_cpp_violation:SUPPRESS]
    return rxRfPllCfgInit[bspChan].bandNcoBase ;
}

INT32 BspGetRxAcBandNco(UINT32 bspChan)
{
    /***此处为CERT CTR50-CPP误告警，如下抑制告警***/
    //coverity[cert_ctr50_cpp_violation:SUPPRESS]
    return rxRfPllCfgInit[bspChan].WfsAcNcoBase ;
}

/*TDD LTE帧结构下发*/
UINT32 BspSetLteIrSubFrame(UINT32 ucChNo, UINT32 ucSubFrameRatio)
{
    s_ulLteSubFrameRatio = ucSubFrameRatio;
    BspLog(LOG_LEVEL_0, "%s>>bspChan'%d ucSubFrameRatio %d\n", __FUNCTION__, ucChNo, ucSubFrameRatio);
    return BSP_OK;
}

/*TDD LTE特殊子帧配置下发*/
UINT32 BspSetLteIrSpeSubFrame(UINT32 ucChNo, UINT32 ucSpecSubFrmRatio)
{
    s_ulSpecSubFramRatio = ucSpecSubFrmRatio; /* 可维可测使用 */
    BspLog(LOG_LEVEL_0, "%s>>bspChan'%d ucSpecSubFrmRatio %d\n", __FUNCTION__, ucChNo, ucSpecSubFrmRatio);
    return BSP_OK;
}

UINT32 BspGetLteIrSubFrame(VOID)
{
    return s_ulLteSubFrameRatio;
}

UINT32 BspGetLteIrSpeSubFrame(VOID)
{
    return s_ulSpecSubFramRatio;
}

UINT32 BspSetTrxChanNcoCallBack(FUNC_CfgExTrxNco pFunc)
{
    pFuncCfgExTrxNco = pFunc;
    return BSP_OK;
}

UINT32 BspSetTrxRfNcoCallBack(FUNC_CfgTrxRfNco pFunc)
{
    pFuncCfgTrxRfNco = pFunc;
    return BSP_OK;
}

/*FDD 支持AC机型配置AC链路频点时需要配射频NCO/频段NCO*/
UINT32 BspSetTrxRfNco(UINT32 bspChan, UINT32 dir, INT32 rfNco)
{
    UINT32 retVal = BSP_ERROR;
    if(NULL != pFuncCfgTrxRfNco)
    {
        retVal = pFuncCfgTrxRfNco(bspChan, dir, rfNco);
    }
    return retVal;
}

/*9124 需要移动7989的NCO 在线校准*/
UINT32 BspSetTrxChanNco(UINT32 bspChan, UINT32 dir, UINT32 carrFreq)
{
    UINT32 retVal = BSP_OK;
    if(NULL != pFuncCfgExTrxNco)
    {
        retVal = pFuncCfgExTrxNco(bspChan, dir, carrFreq);
    }
    return retVal;
}

static UINT32 BspSetUmtsTrapSw(UINT32 chan, UINT32 carrNo, UINT32 trapEn)
{
    UINT32 retVal = BSP_OK;
    UINT32 slotNo = 0;

    for (slotNo = 0; slotNo < MAX_GUSHARE_SLOT_NUM; slotNo++)
    {
        retVal |= BspHalAdaptSetUmtsTxCfrFilterEn(chan, carrNo, slotNo, trapEn);
    }

    return retVal;
}

/* 计算陷波点系数并配置到IC中频 */
static UINT32 BspSetGuShareFilterCoef(T_BspGuShareBwFreqCfg *guShareBwFreq)
{
    INT32 index = 0;
    UINT32 loop = 0;
    UINT32 retVal = BSP_OK;
    INT32 ret = 0;
    INT32 umtsFreq = 0;
    INT32 shareFreq = 0;
    DOUBLE dtmp = 0.0;
    DOUBLE pi = 3.14159;
    UINT32 orderNum = TRAP_COEF_ARRAY_LEN - 2;
    FILE *iFp = NULL;
    FILE *qFp = NULL;
    CHAR fileName[NAME_MAX] = {0};
    DOUBLE ldf[MAX_GUSHARE_FREQ_NUM] = {0};
    INT32 coef[TRAP_COEF_ARRAY_LEN] = {0};
    INT32 c_i[TRAP_COEF_FILTER_ORDER] = {0};
    INT32 c_q[TRAP_COEF_FILTER_ORDER] = {0};
    DOUBLE c[TRAP_COEF_FILTER_ORDER] = {
            2,
            3,
            4,
            5,
            6,
            7,
            9,
            11,
            13,
            15,
            17,
            19,
            21,
            24,
            26,
            29,
            31,
            34,
            37,
            39,
            42,
            45,
            47,
            50,
            52,
            54,
            57,
            58,
            60,
            62,
            63,
            64,
            65,
            66,
            66,
            66,
            66,
            66,
            65,
            64,
            63,
            62,
            60,
            58,
            57,
            54,
            52,
            50,
            47,
            45,
            42,
            39,
            37,
            34,
            31,
            29,
            26,
            24,
            21,
            19,
            17,
            15,
            13,
            11,
            9,
            7,
            6,
            5,
            4,
            3,
            2};
    umtsFreq = (INT32)BspGetChanCarrFreq(TX, guShareBwFreq->bspChan, guShareBwFreq->carrNo, BSP_RADIO_STANDARD_UMTS);
    if (umtsFreq == (INT32)BSP_ERROR || umtsFreq == (INT32)ERROR_NULL_POINTER)
    {
        dbgInfo("[%s] umtsFreq:%d \n", __FUNCTION__, umtsFreq);
        return BSP_ERROR;
    }

    (void)snprintf_s(fileName, sizeof(fileName), "/gu_share_slot%u_i.txt", guShareBwFreq->slotNo);
    iFp = fopen(fileName, "w+b");
    if (NULL == iFp)
    {
        dbgInfo("[%s] iFp is NULL \n", __FUNCTION__);
        return BSP_ERROR;
    }
    (void)memset_s(fileName, sizeof(fileName), 0, sizeof(fileName));
    (void)snprintf_s(fileName, sizeof(fileName), "/gu_share_slot%u_q.txt", guShareBwFreq->slotNo);
    qFp = fopen(fileName, "w+b");
    if (NULL == qFp)
    {
        dbgInfo("[%s] qFp is NULL \n", __FUNCTION__);
        ret = fclose(iFp);
        FCLOSE_CHECK(ret);
        return BSP_ERROR;
    }

    dbgInfoEx("%s: ldf(cnt:%u)[", __FUNCTION__, guShareBwFreq->freqNum);
    (void)fprintf(iFp, "%s: umtsFreq=%u gsmFreq(cnt:%u)[", __FUNCTION__, umtsFreq, guShareBwFreq->freqNum);
    for (index = 0; index < guShareBwFreq->freqNum; index++)
    {
        // 单位MHZ
        shareFreq = (INT32)guShareBwFreq->shareFreq[index];
        ldf[index] = (shareFreq - umtsFreq) / 1000.0;
        dbgInfoEx(" %lf", ldf[index]);
        (void)fprintf(iFp, " %d", shareFreq);
    }
    dbgInfoEx(" ]\n");
    (void)fprintf(iFp, " ]\r\n\r\n");

    for(index = 0; index < TRAP_COEF_FILTER_ORDER; index++)
    {
        dtmp = 0.0;
        for (loop = 0; loop < guShareBwFreq->freqNum; loop++)
        {
            dtmp += cos(pi * (index - 35) * ldf[loop] * 2.0 / 3.84);
        }
        c_i[index] = (INT32)(2 * round(c[index] * dtmp));
        dbgInfoEx("index = %2u: dtmpi = %lf c_i = %d, ", index, dtmp, c_i[index]);
        (void)fprintf(iFp, "%d\r\n", c_i[index]);

        dtmp = 0.0;
        for (loop = 0; loop < guShareBwFreq->freqNum; loop++)
        {
            dtmp += sin(pi * (index - 35) * ldf[loop] * 2.0 / 3.84);
        }
        c_q[index] = (INT32)(2 * round(c[index] * dtmp));
        dbgInfoEx("dtmpq = %lf c_q = %d\n", dtmp, c_q[index]);
        (void)fprintf(qFp, "%d\r\n", c_q[index]);
    }
    ret = fclose(iFp);
    FCLOSE_CHECK(ret);
    ret = fclose(qFp);
    FCLOSE_CHECK(ret);

    for (index = 0; index < (TRAP_COEF_FILTER_ORDER / 2 + 1); index++)
    {
        coef[index * 2] = c_i[index];
        coef[(index * 2) + 1] = c_q[index];
        dbgInfoEx("[%s] index:%d, I:%d, Q:%d \n", __FUNCTION__, index, coef[index * 2], coef[(index * 2) + 1]);
    }

    retVal |= BspHalAdaptSetUmtsTxCfrOrderNum(orderNum); /* 设置梳状滤波阶数 */
    retVal |= BspHalAdaptSetUmtsGsmSlotHdDly(guShareBwFreq->bspChan, guShareBwFreq->carrNo);
    retVal |= BspHalAdaptUmtsTxCfrFilterCoef(guShareBwFreq->bspChan, guShareBwFreq->carrNo, guShareBwFreq->slotNo, coef, TRAP_COEF_ARRAY_LEN);

    return retVal;
}

/**********************************************************************
* 函数名称: BspSetGuShareBwFreq
* 功能描述: 配置梳妆滤波参数
* 输入参数: guShareFreq
* 输出参数: 无
* 返 回 值: BSP_OK:成功 其他-失败
* 其它说明: 高层调用;IC4.2一个U带内,最大支持8个陷波点,每个陷波点的系数根据该点
            配置了多少个不同的GSM频点而不同。
***********************************************************************/
UINT32 BspSetGuShareBwFreq(T_GuShareBwFreqCfg *guShareFreq)
{
    UINT32 retVal = 0;
    UINT32 slot = 0;
    UINT32 index = 0;
    T_BspGuShareBwFreqCfg guShareBwFreq = {0};

    INPUT_POINTER_CHECK(guShareFreq);

    /* 通道号和载波号入参检测 */
    if (guShareFreq->bspChan >= BspGetTxChannel())
    {
        return BSP_ERROR;
    }
    if ((guShareFreq->bspChan < MAX_TX_CHANNEL_GU_SHAREBW) && (guShareFreq->carrNo < MAX_CARRIERS_NUM_UMTS))
    {
        (void)memcpy_s(&atGuShareFreqCfg[guShareFreq->bspChan][guShareFreq->carrNo], sizeof(T_GuShareBwFreqCfg),
                guShareFreq, sizeof(T_GuShareBwFreqCfg));
    }

    // 关闭载波陷波使能
    retVal |= BspSetUmtsTrapSw(guShareFreq->bspChan, guShareFreq->carrNo, DISABLE);
    if (retVal != BSP_OK)
    {
        return BSP_ERROR;
    }

    // 如果是关闭操作, 此处返回
    if (guShareFreq->cfgSwitch == DISABLE)
    {
        return BSP_OK;
    }

    dbgInfoEx("[%s] chan:%d, carrNo:%d \n", __FUNCTION__, guShareFreq->bspChan, guShareFreq->carrNo);

    guShareBwFreq.bspChan = guShareFreq->bspChan;
    guShareBwFreq.carrNo = guShareFreq->carrNo;
    for (slot = 0; slot < MAX_GUSHARE_SLOT_NUM; slot++)
    {
        guShareBwFreq.freqNum = 0;
        guShareBwFreq.slotNo = slot;
        for (index = 0; index < MAX_GUSHARE_FREQ_NUM; index++)
        {
            if (guShareFreq->shareFreq[index] == 0 || guShareFreq->shareFreq[index] == _ERROR)
            {
                continue;
            }

            if (BIT_SET(slot) & guShareFreq->slotNo[index])
            {
                guShareBwFreq.shareFreq[guShareBwFreq.freqNum++] = guShareFreq->shareFreq[index];
            }
        }

        dbgInfoEx("[%s] slot:%u, guShareBwFreq.freqNum:%d \n", __FUNCTION__, slot, guShareBwFreq.freqNum);
        if (guShareBwFreq.freqNum > 0)
        {
            BspSetGuShareFilterCoef(&guShareBwFreq);
        }
    }

    /* 打开载波陷波使能 */
    retVal |= BspSetUmtsTrapSw(guShareFreq->bspChan, guShareFreq->carrNo, ENABLE);

    return retVal;
}

static UINT32 BspTestGuShareFreqCfg(UINT32 bspChan, UINT32 carrNo)
{
    T_GuShareBwFreqCfg *cfg = NULL;

    if (bspChan >= MAX_TX_CHANNEL_GU_SHAREBW || carrNo >= MAX_CARRIERS_NUM_UMTS)
    {
        return BSP_ERROR;
    }
    cfg = &atGuShareFreqCfg[bspChan][carrNo];
    return BspSetGuShareBwFreq(cfg);
}

static void BspPrnGuShareFreqCfg(UINT32 bspChan, UINT32 carrNo)
{
    T_GuShareBwFreqCfg *cfg = NULL;
    UINT32 index = 0;

    if (bspChan >= MAX_TX_CHANNEL_GU_SHAREBW || carrNo >= MAX_CARRIERS_NUM_UMTS)
    {
        return;
    }
    cfg = &atGuShareFreqCfg[bspChan][carrNo];
    dbgInfo("bspChan=%u carrNo=%u direction=%u cfgSwitch=%u workMode=%u\n", cfg->bspChan, cfg->carrNo, cfg->direction,
            cfg->cfgSwitch, cfg->workMode);
    dbgInfo("shareFreq:");
    for (index = 0; index < MAX_GUSHARE_FREQ_NUM; index++)
    {
        dbgInfo(" %u", cfg->shareFreq[index]);
    }
    dbgInfo("\n");
    dbgInfo("slotNo(0x):");
    for (index = 0; index < MAX_GUSHARE_FREQ_NUM; index++)
    {
        dbgInfo(" %x", cfg->slotNo[index]);
    }
    dbgInfo("\n");
}

/* 打桩使用, 初始化GU频谱共享频点配置 */
static UINT32 BspInitGuShareFreqCfg(UINT32 bspChan, UINT32 carrNo, UINT32 sw, UINT32 freqOffset, UINT32 freq, UINT32 slot)
{
    T_GuShareBwFreqCfg *cfg = NULL;

    if (bspChan >= MAX_TX_CHANNEL_GU_SHAREBW || carrNo >= MAX_CARRIERS_NUM_UMTS || freqOffset >= MAX_GUSHARE_FREQ_NUM)
    {
        return BSP_ERROR;
    }
    cfg = &atGuShareFreqCfg[bspChan][carrNo];
    if (sw != 0xff)
    {
        cfg->cfgSwitch = sw;
    }

    dbgInfo("[%s] chan:%d, carrNo:%d, sw:%d, freqOffset:%d, freq:%d, slot:%d \n",
            __FUNCTION__, bspChan, carrNo, sw, freqOffset, freq, slot);

    cfg->bspChan = bspChan;
    cfg->carrNo = carrNo;
    cfg->shareFreq[freqOffset] = freq;
    cfg->slotNo[freqOffset] = slot;
    return BSP_OK;
}

/**********************************************************************
* 函数名称: BspGetGuShareBwAbility
* 功能描述: 是否支持GU频谱共享-下行配置梳妆滤波
* 输入参数: 无
* 输出参数: 无
* 返 回 值: ENABLE:支持   DISABLE:不支持
* 其它说明:高层调用; IC4.2芯片默认支持
***********************************************************************/
UINT32 BspGetGuShareBwAbility(void)
{
    return ENABLE;
}

/**********************************************************************
* 函数名称: BspGetAnfMaxNum
* 功能描述: ANF功能单片IC最大可抵消干扰点数
* 输入参数: 无
* 输出参数: 无
* 返 回 值: 0-不支持  其他值--支持
* 其它说明:高层调用; IC4.2芯片最大支持16个抵消点
***********************************************************************/
UINT32 BspGetAnfMaxNum(VOID)
{
    return ANF_MAX_NUM;
}

/* IC4.2芯片默认支持NBIC功能 */
UINT32 BspGetNbicSupported(VOID)
{
     return ENABLE;
}

UINT32 BspSetSideFilterDlCoef(UINT32 bspChan, UINT32 carrNo, UINT32 radio, UINT32 bandWidth)
{
    UINT32 ret = BSP_OK;
    UINT32 chipId = 0;
    UINT32 difChan = 0;

    ret = BspGetDifInfoByBspChn(bspChan, TX, &chipId, &difChan);
    if (BSP_OK != ret)
    {
        BspLog(LOG_LEVEL_0, "%s>>bspChan'%d BspGetDifInfoByBspChn Get Error!\n", __FUNCTION__, bspChan);
        return BSP_ERROR;
    }

    ret |= BspHalAdaptSetTxCarrCfirNcoCoef(difChan, carrNo, radio, bandWidth);
    if (BSP_OK == ret)
    {
        ret |= BspSetDlFilterRcfBw(difChan, carrNo, radio, bandWidth);
    }
    BspLog(LOG_LEVEL_0, "[%s]: bspChan'%d, carrNo'%d, radio'0x%x, bandWidth'%dKHZ, ret%d\n", __FUNCTION__, bspChan, carrNo, radio, bandWidth, ret);

    return ret;
}

UINT32 BspSetSideFilterUlCoef(UINT32 bspChan, UINT32 carrNo, UINT32 radio, UINT32 bandWidth)
{
    UINT32 ret = BSP_OK;
    UINT32 chipId = 0;
    UINT32 difChan = 0;

    ret = BspGetDifInfoByBspChn(bspChan, RX, &chipId, &difChan);
    if (BSP_OK != ret)
    {
        return BSP_ERROR;
    }

    ret |= BspHalAdaptSetRxCarrCfirNcoCoef(difChan, carrNo, radio, bandWidth);
    if (BSP_OK == ret)
    {
        ret |= BspSetUlFilterRcfBw(difChan, carrNo, radio, bandWidth);
    }
    BspLog(LOG_LEVEL_0, "[%s]: bspChan'%d, carrNo'%d, radio'0x%x, bandWidth'%dKHZ, ret%d\n", __FUNCTION__, bspChan, carrNo, radio, bandWidth, ret);

    return ret;
}

/* Started by AICoder, pid:5da8955f5cc001614ad009f5d06fef4576e78de0 */
UINT32 BspSetSideFilterTxNco(UINT32 bspChan, UINT32 carrNo, UINT32 radio, INT32 swFreqOffset)
{
    UINT32 ret = BSP_OK;
    UINT32 chipId = 0;
    UINT32 difChan = 0;

    T_CellCfgInfo tCellInfo = {0};

    // 获取光口小区信息
    ret = BspGetOptCellInfoByCarr(bspChan, TX, carrNo, radio, &tCellInfo);
    if (ret != BSP_OK)
    {
        dbgInfo("%s>>bspChan '%d' radio %d carrNo %d not find opt cell!\n", __FUNCTION__, bspChan, radio, carrNo);
        return BSP_OK;
    }

    // 获取中频通道信息
    ret = BspGetDifInfoByBspChn(bspChan, TX, &chipId, &difChan);
    if (BSP_OK != ret)
    {
        return BSP_ERROR;
    }

    // IF1 配置光口移频
    if (tCellInfo.cellIFType == E_OPT_IF1)
    {
        BspLog(LOG_LEVEL_0, "%s>>bspChan '%d' Optcell %d offset %d!\n", __FUNCTION__, bspChan, tCellInfo.cellIndex, swFreqOffset);
        ret = BspHalAdapSetFftFocVal(tCellInfo.cellIndex, radio, TX, swFreqOffset);
    }
    // IF0 中频移频
    else
    {
        BspLog(LOG_LEVEL_0, "%s>>bspChan '%d' Hal Cfg offset %d!\n", __FUNCTION__, bspChan, swFreqOffset);
        ret = BspHalAdaptSetTxCarrCfirNcoFront(difChan, carrNo, radio, swFreqOffset);
    }

    // 设置下行滤波器NCO前端
    if (BSP_OK == ret)
    {
        ret |= BspSetDlFilterNcoFront(difChan, carrNo, radio, swFreqOffset);
    }

    BspLog(LOG_LEVEL_0, "[%s]: bspChan '%d', carrNo '%d', radio '0x%x', Nco1 '%d', ret %d\n",
           __FUNCTION__, bspChan, carrNo, radio, swFreqOffset, ret);

    return ret;
}
/* Ended by AICoder, pid:5da8955f5cc001614ad009f5d06fef4576e78de0 */

/* Started by AICoder, pid:6101du6458g29a6143760b2dc07f065d0e20bd35 */
UINT32 BspSetSideFilterRxNco(UINT32 bspChan, UINT32 carrNo, UINT32 radio, INT32 swFreqOffset)
{
    UINT32 ret = BSP_OK;
    UINT32 chipId = 0;
    UINT32 difChan = 0;
    INT32 freqOffset = 0;
    T_CellCfgInfo tCellInfo = {0};

    // 获取光口小区信息
    ret = BspGetOptCellInfoByCarr(bspChan, RX, carrNo, radio, &tCellInfo);
    if (ret != BSP_OK)
    {
        dbgInfo("%s>>bspChan '%d' radio %d carrNo %d not find opt cell!\n", __FUNCTION__, bspChan, radio, carrNo);
        return BSP_OK;
    }

    // 获取中频通道信息
    ret = BspGetDifInfoByBspChn(bspChan, RX, &chipId, &difChan);
    if (ret != BSP_OK)
    {
        dbgErr("%s>>bspChan '%d' BspGetDifInfoByBspChn Get Error!\n", __FUNCTION__, bspChan);
        return BSP_ERROR;
    }

    // 上行APP下发偏执NCO为-dF
    freqOffset = -swFreqOffset;

    // IF1 配置光口移频
    if (tCellInfo.cellIFType == E_OPT_IF1)
    {
        BspLog(LOG_LEVEL_0, "%s>>bspChan '%d' Optcell %d offset %d!\n", __FUNCTION__, bspChan, tCellInfo.cellIndex, swFreqOffset);
        ret = BspHalAdapSetFftFocVal(tCellInfo.cellIndex, radio, RX, freqOffset);
    }
    else
    {
        BspLog(LOG_LEVEL_0, "%s>>bspChan '%d' Hal Cfg offset %d!\n", __FUNCTION__, bspChan, swFreqOffset);
        ret = BspHalAdaptSetRxCarrCfirNcoBehind(difChan, carrNo, radio, freqOffset);
    }

    // 设置上行滤波器NCO后端
    if (ret == BSP_OK)
    {
        ret |= BspSetUlFilterNcoBehind(difChan, carrNo, radio, swFreqOffset);
    }

    BspLog(LOG_LEVEL_0, "[%s]: bspChan '%d', carrNo '%d', radio '0x%x', Nco1 '%d', ret %d\n",
           __FUNCTION__, bspChan, carrNo, radio, swFreqOffset, ret);

    return ret;
}
/* Ended by AICoder, pid:6101du6458g29a6143760b2dc07f065d0e20bd35 */

static UINT32 BspSetCfrFreqFiOffsetLteNr(UINT32 bspChan, UINT32 carrNo, INT32 swFreqOffset)
{
    UINT32 retVal = BSP_OK;
    UINT32 chipId = 0;
    UINT32 difChan = 0;

    retVal = BspGetDifInfoByBspChn(bspChan, TX, &chipId, &difChan);
    if (BSP_OK != retVal)
    {
       BspLog(LOG_LEVEL_0, "%s>>bspChan'%d BspGetDifInfoByBspChn Get Error!\n", __FUNCTION__, bspChan);
       return BSP_ERROR;
    }

    if(difChan >= MAX_TX_CHANNEL)
    {
        BspLog(LOG_LEVEL_0,"[%s]:difChan is %d, out bounds error!\n", __FUNCTION__, difChan);
        return BSP_ERROR;
    }
    s_cfrLteNrDssFreqFiOffsetInfo[difChan].carrNo = carrNo;
    s_cfrLteNrDssFreqFiOffsetInfo[difChan].offset = swFreqOffset;

    dbgInfoEx("[%s]: bspChan = %d, carrNo = %d, swFreqOffset = %d\n", __FUNCTION__, bspChan, carrNo, swFreqOffset);

    return retVal;
}

UINT32 BspGetCfrFreqFiOffsetLteNr(UINT32 bspChan, T_CfrFreqFiOffsetInfo * pcfrFreqFiOffsetInfo)
{
    UINT32 retVal = BSP_OK;
    UINT32 chipId = 0;
    UINT32 difChan = 0;

    retVal |= BspGetDifInfoByBspChn(bspChan, TX, &chipId, &difChan);
    if (BSP_OK != retVal)
    {
       BspLog(LOG_LEVEL_0, "%s>>bspChan'%d BspGetDifInfoByBspChn Get Error!\n", __FUNCTION__, bspChan);
       return BSP_ERROR;
    }

    if(MAX_TX_CHANNEL <= difChan)
    {
        BspLog(LOG_LEVEL_0,"[%s]:difChan is %d, out bounds error!\n", __FUNCTION__, difChan);
        return BSP_ERROR;
    }
    pcfrFreqFiOffsetInfo[difChan].carrNo = s_cfrLteNrDssFreqFiOffsetInfo[difChan].carrNo;
    pcfrFreqFiOffsetInfo[difChan].offset = s_cfrLteNrDssFreqFiOffsetInfo[difChan].offset;

    return retVal;
}

UINT32 BspSetSideFilterTxCarrFreq(UINT32 bspChan, UINT32 carrNo, UINT32 radio, INT32 freqOffset)
{
    UINT32 ret = BSP_OK;
    UINT32 chipId = 0;
    UINT32 difChan = 0;
    UINT32 rfPll = 0;
    INT32 offset = 0;
    INT32 bandNco = 0;

    ret = BspGetDifInfoByBspChn(bspChan, TX, &chipId, &difChan);
    if(BSP_OK != ret)
    {
        BspLog(LOG_LEVEL_0, "%s>>bspChan'%d BspGetDifInfoByBspChn Get Error!\n", __FUNCTION__, bspChan);
        return BSP_ERROR;
    }

    if(txRfPllCfgInit[bspChan].cfgSolution != BSP_FREQ_DYNAMIC_LO)
    {
        if(1 == txRfPllCfgInit[bspChan].bandNcoFlag)
        {
            bandNco = txRfPllCfgInit[bspChan].bandNcoBase;
            dbgInfoEx("%s [%d] bspChan: %d bandNco: %d \n",__FUNCTION__, __LINE__, bspChan, bandNco);
        }
    }

    rfPll = BspGetLoFreqChanged(TX, bspChan);
    offset = (INT32)((INT32)freqOffset - (INT32)rfPll - bandNco);

    ret |= BspHalAdaptSetTxCarrCfirNcoBehind(difChan, carrNo, radio, offset);
    if (BSP_OK == ret)
    {
        ret |= BspSetCfrFreqFiOffset(difChan, carrNo, radio, offset);
        ret |= BspSetCfrFreqFiOffsetLteNr(bspChan, carrNo, offset);
        ret |= BspSetDlFilterNcoBehind(difChan, carrNo, radio, freqOffset);
    }

    BspLog(LOG_LEVEL_0, "[%s]: bspChan'%d, carrNo'%d, radio%d, freqOffset'%d, rfPll'%d, bandnco'%d, Nco2'%d, ret%d\n",
            __FUNCTION__, bspChan, carrNo, radio, freqOffset, rfPll, bandNco, offset, ret);

    return ret;
}

UINT32 BspSetSideFilterRxCarrFreq(UINT32 bspChan, UINT32 carrNo, UINT32 radio, INT32 freqOffset)
{
    UINT32 ret = BSP_OK;
    UINT32 chipId = 0;
    UINT32 difChan = 0;
    UINT32 rfPll = 0;
    INT32 offset = 0;
    INT32 bandNco = 0;

    ret = BspGetDifInfoByBspChn(bspChan, RX, &chipId, &difChan);
    if(BSP_OK != ret)
    {
        dbgErr("%s>>bspChan'%d BspGetDifInfoByBspChn Get Error!\n", __FUNCTION__, bspChan);
        return BSP_ERROR;
    }

    if(rxRfPllCfgInit[bspChan].cfgSolution != BSP_FREQ_DYNAMIC_LO)
    {
        if(BAND_NCO == rxRfPllCfgInit[bspChan].bandNcoFlag)
        {
            bandNco = rxRfPllCfgInit[bspChan].bandNcoBase;
            dbgInfoEx("%s [%d] bspChan: %d bandNco: %d \n",__FUNCTION__, __LINE__, bspChan, bandNco);
        }
    }

    rfPll = BspGetLoFreqChanged(RX, bspChan);
    if ((0 == rfPll) || (BSP_ERROR == rfPll))
    {
        BspLog(LOG_LEVEL_0,"%s>>RxChnl'%d LoFreq'%d Get Error!\n", __FUNCTION__, bspChan, rfPll);
        return BSP_ERROR;
    }
    offset = (INT32)((INT32)rfPll + bandNco - freqOffset);

    ret |= BspHalAdaptSetRxCarrCfirNcoFront(difChan, carrNo, radio, offset);
    if (BSP_OK == ret)
    {
        ret |= BspSetUlFilterNcoFront(difChan, carrNo, radio, freqOffset);
    }

    BspLog(LOG_LEVEL_0, "[%s]: bspChan'%d, carrNo'%d, radio%d, freqOffset'%d, rfPll'%d, bandnco'%d, Nco2'%d, ret%d\n",
            __FUNCTION__, bspChan, carrNo, radio, freqOffset, rfPll, bandNco, offset, ret);

    return ret;
}

UINT32 rxsidefilter(UINT32 bspChan, UINT32 carrNo, UINT32 radio, UINT32 bandWidth, INT32 nco1)
{
    UINT32  ret = BSP_OK;
    INT32 freq = 0;

    ret = BspGetUlRcfCoefByBandWith(bspChan, radio, bandWidth);
    RETURN_VAL_DO_IF_EXP(BSP_OK != ret, BSP_ERROR, dbgErr("[%s] getRfcCoefByBandWith error\n", __FUNCTION__));

    ret |= BspSetSideFilterUlCoef(bspChan, carrNo, radio, bandWidth);
    RETURN_VAL_DO_IF_EXP(BSP_OK != ret, BSP_ERROR, dbgErr("[%s] set coef rx share failed\n", __FUNCTION__));

    ret |= BspSetSideFilterRxNco(bspChan, carrNo, radio, nco1);
    RETURN_VAL_DO_IF_EXP(BSP_OK != ret, BSP_ERROR, dbgErr("[%s] set rx nco1 failed\n", __FUNCTION__));

    freq = BspGetChanCarrFreq(RX, bspChan, carrNo, radio);
    RETURN_VAL_DO_IF_EXP((((INT32)BSP_ERROR == freq) || ((INT32)ERROR_NULL_POINTER == freq) || (0 == freq)), BSP_ERROR, dbgErr("[%s] get freq:%d error\n", __FUNCTION__, freq));

    ret |= BspSetSideFilterRxCarrFreq(bspChan, carrNo, radio, (INT32)(freq + nco1));
    RETURN_VAL_DO_IF_EXP(BSP_OK != ret, BSP_ERROR, dbgErr("[%s] set rx carrier freq failed\n", __FUNCTION__));

    return ret;
}

UINT32 BspCarrResourceRecycle(T_DestCarrInfoAllChans *pCarrInfoAllChans)
{
    UINT32 retVal = BSP_OK;
    UINT32 chanLoop = 0;
    UINT32 carrLoop = 0;
    UINT32 chanNo = 0;
    T_DifChanInfo *ptChanInfo = NULL;

    INPUT_POINTER_CHECK(pCarrInfoAllChans);
    ptChanInfo = (T_DifChanInfo *)malloc(sizeof(T_DifChanInfo));
    if (ptChanInfo == NULL)
    {
        return BSP_ERROR;
    }
    memset_s(ptChanInfo, sizeof(T_DifChanInfo), 0, sizeof(T_DifChanInfo));

    BspLog(LOG_LEVEL_0,"[%s] enter\n",__FUNCTION__);
    BspLog(LOG_LEVEL_0,"[%s] txChanNum = %d,rxChanNum = %d\n",__FUNCTION__,pCarrInfoAllChans->txChanNum,pCarrInfoAllChans->rxChanNum);
    for(chanLoop = 0; chanLoop < pCarrInfoAllChans->txChanNum; chanLoop++)
    {
        chanNo = pCarrInfoAllChans->txCarrInfo[chanLoop].chanNo;
        ptChanInfo->atChanInfo[chanNo].uiCarrNum = pCarrInfoAllChans->txCarrInfo[chanLoop].carrNum;
        BspLog(LOG_LEVEL_0,"[%s] chanNo = %d,txcarrnum = %d\n",__FUNCTION__,chanNo,ptChanInfo->atChanInfo[chanNo].uiCarrNum);
        for (carrLoop = 0; carrLoop < pCarrInfoAllChans->txCarrInfo[chanLoop].carrNum; carrLoop++)
        {
            ptChanInfo->atChanInfo[chanNo].atCarrInfo[carrLoop].uiDelOrAddFlag = pCarrInfoAllChans->txCarrInfo[chanLoop].carrInfo[carrLoop].delOrAddFlag;
            ptChanInfo->atChanInfo[chanNo].atCarrInfo[carrLoop].uiCarrId = pCarrInfoAllChans->txCarrInfo[chanLoop].carrInfo[carrLoop].carrNo;
            ptChanInfo->atChanInfo[chanNo].atCarrInfo[carrLoop].uiCarrFreq = pCarrInfoAllChans->txCarrInfo[chanLoop].carrInfo[carrLoop].freq;
            ptChanInfo->atChanInfo[chanNo].atCarrInfo[carrLoop].uiCarrBw = pCarrInfoAllChans->txCarrInfo[chanLoop].carrInfo[carrLoop].bandWidth;
            ptChanInfo->atChanInfo[chanNo].atCarrInfo[carrLoop].uiCarrRadio = pCarrInfoAllChans->txCarrInfo[chanLoop].carrInfo[carrLoop].radioMode;
            ptChanInfo->atChanInfo[chanNo].atCarrInfo[carrLoop].uiCellId = pCarrInfoAllChans->txCarrInfo[chanLoop].carrInfo[carrLoop].cellid;
        }
    }
    retVal |= BspHalAdaptResourceRecycle(TX, ptChanInfo);
    memset_s(ptChanInfo, sizeof(T_DifChanInfo), 0, sizeof(T_DifChanInfo));
    for(chanLoop = 0; chanLoop < pCarrInfoAllChans->rxChanNum; chanLoop++)
    {
        chanNo = pCarrInfoAllChans->rxCarrInfo[chanLoop].chanNo;
        ptChanInfo->atChanInfo[chanNo].uiCarrNum = pCarrInfoAllChans->rxCarrInfo[chanLoop].carrNum;
        BspLog(LOG_LEVEL_0,"[%s] chanNo = %d,rxcarrnum = %d\n",__FUNCTION__,chanNo,ptChanInfo->atChanInfo[chanNo].uiCarrNum);
        for (carrLoop = 0; carrLoop < pCarrInfoAllChans->rxCarrInfo[chanLoop].carrNum; carrLoop++)
        {
            ptChanInfo->atChanInfo[chanNo].atCarrInfo[carrLoop].uiDelOrAddFlag = pCarrInfoAllChans->rxCarrInfo[chanLoop].carrInfo[carrLoop].delOrAddFlag;
            ptChanInfo->atChanInfo[chanNo].atCarrInfo[carrLoop].uiCarrId = pCarrInfoAllChans->rxCarrInfo[chanLoop].carrInfo[carrLoop].carrNo;
            ptChanInfo->atChanInfo[chanNo].atCarrInfo[carrLoop].uiCarrFreq = pCarrInfoAllChans->rxCarrInfo[chanLoop].carrInfo[carrLoop].freq;
            ptChanInfo->atChanInfo[chanNo].atCarrInfo[carrLoop].uiCarrBw = pCarrInfoAllChans->rxCarrInfo[chanLoop].carrInfo[carrLoop].bandWidth;
            ptChanInfo->atChanInfo[chanNo].atCarrInfo[carrLoop].uiCarrRadio = pCarrInfoAllChans->rxCarrInfo[chanLoop].carrInfo[carrLoop].radioMode;
            ptChanInfo->atChanInfo[chanNo].atCarrInfo[carrLoop].uiCellId = pCarrInfoAllChans->rxCarrInfo[chanLoop].carrInfo[carrLoop].cellid;
        }
    }

    retVal |= BspHalAdaptResourceRecycle(RX, ptChanInfo);
    BspLog(LOG_LEVEL_0,"[%s] exit,retVal = %d\n",__FUNCTION__,retVal);
    free(ptChanInfo);
    return retVal;
}

/* Started by AICoder, pid:nd4e757d81m55c514ef50a8420853a6f3dc5019b */
UINT32 BspGetFilterBwByCpg(UINT32 difChan, UINT32 carrNo, UINT32 radioMod, UINT32 *filterBw)
{
    UINT32 ret = BSP_OK;
    T_carrFilterPara filterPara = {0};

    INPUT_POINTER_CHECK(filterBw);
    if ((difChan >= MAX_TX_CHANNEL) || (carrNo >= BSP_MAX_CARR_NUM))
    {
        BspLog(LOG_LEVEL_0,"[%s]:difChan'%d or carrNo'%d out bounds error!\n",__FUNCTION__,difChan,carrNo);
        return BSP_ERROR;
    }

    if ((BSP_RADIO_STANDARD_UMTS == radioMod)
        || (BSP_RADIO_STANDARD_FDD_5G == radioMod)
        || (BSP_RADIO_STANDARD_LTE_FDD == radioMod))
    {
        ret |= BspGetPublicDlFilterPara(difChan, carrNo, radioMod, &filterPara);
        *filterBw = filterPara.cpgbandWidth;
    }
    else
    {
        *filterBw = 0;
    }

    dbgInfoEx("[%s]: difChan'%d, carrNo'%d, radioMod'0x%x, filterBw'%d\n",__FUNCTION__, difChan, carrNo, radioMod, *filterBw);

    return ret;
}
/* Ended by AICoder, pid:nd4e757d81m55c514ef50a8420853a6f3dc5019b */

/* Started by AICoder, pid:168a0v0a0cvd8b0144390a9ac0eb40667da5e8bf */
UINT32 BspGetUlFilterBwByCpg(UINT32 difChan, UINT32 carrNo, UINT32 radioMod, UINT32 *filterBw)
{
    UINT32 ret = BSP_OK;
    T_carrFilterPara filterPara = {0};

    INPUT_POINTER_CHECK(filterBw);
    if ((difChan >= MAX_RX_CHANNEL) || (carrNo >= BSP_MAX_CARR_NUM))
    {
        BspLog(LOG_LEVEL_0,"[%s]:difChan'%d or carrNo'%d out bounds error!\n",__FUNCTION__,difChan,carrNo);
        return BSP_ERROR;
    }

    if ((BSP_RADIO_STANDARD_UMTS == radioMod)
        || (BSP_RADIO_STANDARD_FDD_5G == radioMod)
        || (BSP_RADIO_STANDARD_LTE_FDD == radioMod))
    {
        ret |= BspGetPublicUlFilterPara(difChan, carrNo, radioMod, &filterPara);
        *filterBw = filterPara.cpgbandWidth;
    }
    else
    {
        *filterBw = 0;
    }

    dbgInfoEx("[%s]: difChan'%d, carrNo'%d, radioMod'0x%x, filterBw'%d\n",__FUNCTION__, difChan, carrNo, radioMod, *filterBw);

    return ret;
}
/* Ended by AICoder, pid:168a0v0a0cvd8b0144390a9ac0eb40667da5e8bf */

UINT32 BspClearAllDlGain(VOID)
{
    return BspHalAdaptSetDlbankAllDgainRegWrZero();
}
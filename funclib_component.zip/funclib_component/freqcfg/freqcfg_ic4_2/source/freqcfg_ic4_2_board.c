/*****************************************************************************
* 版权所有(C) 2021, ZTE Corp. ZXSDR-RRU Platform BSP
*----------------------------------------------------------------------------
* 模 块 名 : 配频
* 文件名称 : freqcfg_ic4_2_board.c
* 文件标识 : {[N/A]}
* 内容摘要 : 本文件提供了配频接口函数实现
* 注意事项 : 无
* 作    者 : 李权明10279092
* 创建日期 : 2022-01-24
* 当前版本 : Ver1.0
*----------------------------------------------------------------------------*/

#include "freqcfg_ic4_2_board.h"
#include "ichaladapt_ic4_2.h"
#include "bspcomm.h"



UINT32 s_txBandFreqFromBoard[BSP_HALADAPT_MAX_DIF_CARR_NUM][BSP_IC_PERCHAN_BAND_NUM] = {0};
UINT32 s_rxBandFreqFromBoard[BSP_HALADAPT_MAX_DIF_CARR_NUM][BSP_IC_PERCHAN_BAND_NUM] = {0};

/**********************************************************************
* 函数名称: BspSetTxBandFreqFromBoard
* 功能描述: 从单板下设置下行各个通道的bandNco
* 输入参数: bspChan 通道号，bandFreq0 band0的频点，bandFreq1 band0的频点
* 输出参数: 无
* 说       明: 只有一个band时，bandFreq1可以写0
* 返  回  值: BSP_OK / BSP_ERROR
************************************************************************/
UINT32 BspSetTxBandFreqFromBoard(UINT32 bspChan,UINT32 bandFreq0,UINT32 bandFreq1)
{
    if(bspChan >= BSP_HALADAPT_MAX_DIF_CARR_NUM)
    {
        dbgErr("%s :bspChan[%d] is over maxChan!",__FUNCTION__,bspChan);
        return BSP_ERROR;
    }

    if((board_band_freq_0 >= BSP_IC_PERCHAN_BAND_NUM) ||
            (board_band_freq_1 >= BSP_IC_PERCHAN_BAND_NUM))
    {
        dbgErr("%s :bandNum is over maxBand!",__FUNCTION__);
        return BSP_ERROR;
    }

    s_txBandFreqFromBoard[bspChan][board_band_freq_0] = bandFreq0;
    s_txBandFreqFromBoard[bspChan][board_band_freq_1] = bandFreq1;

    return BSP_OK;
}

/**********************************************************************
* 函数名称: BspSetRxBandFreqFromBoard
* 功能描述: 从单板下设置上行各个通道的bandNco
* 输入参数: bspChan 通道号，bandFreq0 band0的频点，bandFreq1 band0的频点
* 输出参数: 无
* 说       明: 只有一个band时，bandFreq1可以写0
* 返  回  值: BSP_OK / BSP_ERROR
************************************************************************/
UINT32 BspSetRxBandFreqFromBoard(UINT32 bspChan,UINT32 bandFreq0,UINT32 bandFreq1)
{
    if(bspChan >= BSP_HALADAPT_MAX_DIF_CARR_NUM)
    {
        dbgErr("%s :bspChan[%d] is over maxChan!",__FUNCTION__,bspChan);
        return BSP_ERROR;
    }

    if((board_band_freq_0 >= BSP_IC_PERCHAN_BAND_NUM) ||
            (board_band_freq_1 >= BSP_IC_PERCHAN_BAND_NUM))
    {
        dbgErr("%s :bandNum is over maxBand!",__FUNCTION__);
        return BSP_ERROR;
    }

    s_rxBandFreqFromBoard[bspChan][board_band_freq_0] = bandFreq0;
    s_rxBandFreqFromBoard[bspChan][board_band_freq_1] = bandFreq1;
    return BSP_OK;
}

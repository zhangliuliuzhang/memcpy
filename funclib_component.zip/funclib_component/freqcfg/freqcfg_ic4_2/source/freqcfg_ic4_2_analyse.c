/*****************************************************************************
* 版权所有(C) 2021, ZTE Corp. ZXSDR-RRU Platform BSP
*----------------------------------------------------------------------------
* 模 块 名 : 配频
* 文件名称 : freqcfg_analyse.c
* 文件标识 : {[N/A]}
* 内容摘要 : 本文件提供了配频接口函数实现
* 注意事项 : 无
* 作    者 : 李权明10279092
* 创建日期 : 2022-01-10
* 当前版本 : Ver1.0
*----------------------------------------------------------------------------*/

#include "freqcfg_ic4_2_analyse.h"
#include "freqcfg_ic4_2.h"
#include "freqcfg_ic4_2_dbg.h"
#include "bspcomm.h"
#include "ichaladaptbspapi.h"
#include "ichaladapt_ic4_2.h"
#include "chnmap_a.h"
#include "funccommon_carrmap.h"
#include "freqcfgapi.h"
#include "funccommon_fpga.h"


static FUNC_CALLED_AFTER_PREANALYSE s_pFuncCalledAfterPreAnalyse = NULL;
static FUNC_CALLED_BEFORE_PREANALYSE s_pFuncCalledBeforePreAnalyse = NULL;
static FUNC_CHAN_POW_CALC_SWITCH s_pFuncChanPowCalcSw = NULL;
static FUNC_SET_DTX_ROUTE s_pFuncSetDtxRoute = NULL;
static T_FilterAbilityInfo *s_pFilterAbility = NULL;
static BOOL s_rxTdRcfSwitch[2] = { [0 ... 1] = FALSE};

UINT32 BspSetCallBackAfterPreAnalyse(FUNC_CALLED_AFTER_PREANALYSE pFunc)
{
    s_pFuncCalledAfterPreAnalyse = pFunc;
    return BSP_OK;
}

UINT32 BspSetCallBackBeforePreAnalyse(FUNC_CALLED_BEFORE_PREANALYSE pFunc)
{
    s_pFuncCalledBeforePreAnalyse = pFunc;
    return BSP_OK;
}

UINT32 BspSetCallBackChanPowCalcSw(FUNC_CHAN_POW_CALC_SWITCH pFunc)
{
    s_pFuncChanPowCalcSw = pFunc;
    return BSP_OK;
}

UINT32 BspSetDtxRouteCallBack(FUNC_SET_DTX_ROUTE pFunc)
{
    s_pFuncSetDtxRoute = pFunc;
    return BSP_OK;
}

/* Started by AICoder, pid:k10601318e1011b14aac08b6a06b392a29c99b2b */
UINT32 BspSetFilterAbilityInfo(UINT32 dir, T_FilterAbilityInfo *pFilterAbilityInfo)
{
    T_FilterAbilityInfo *pFilterAbility = BspGetFilterAbilityInfo();

    if (dir >= PRX)
    {
        dbgErr("[%s]: dir'%d out of range!\n",__FUNCTION__, dir);
        return BSP_ERROR;
    }

    INPUT_POINTER_CHECK(pFilterAbility);
    memcpy_s(&pFilterAbility[dir], sizeof(T_FilterAbilityInfo), (T_FilterAbilityInfo *)pFilterAbilityInfo, sizeof(T_FilterAbilityInfo));

    return BSP_OK;
}

T_FilterAbilityInfo *BspGetFilterAbilityInfo(VOID)
{
    if (s_pFilterAbility == NULL)
    {
        s_pFilterAbility = (T_FilterAbilityInfo *)malloc(sizeof(T_FilterAbilityInfo) * PRX);
        if (s_pFilterAbility == NULL)
        {
            return NULL;
        }
        zte_memset_s(s_pFilterAbility, sizeof(T_FilterAbilityInfo) * PRX, 0, sizeof(T_FilterAbilityInfo) * PRX);
    }
    return s_pFilterAbility;
}
/* Ended by AICoder, pid:k10601318e1011b14aac08b6a06b392a29c99b2b */

/* Started by AICoder, pid:db3f8vdfbd6bf8214b79082d40ad12131095c8c8 */
VOID BspSetRxTdRcfSwitchBypass(UINT32 radio, BOOL isSupport)
{
    s_rxTdRcfSwitch[radio % 2] = isSupport;
}

BOOL BspIsRxTdRcfSwitchBypass(UINT32 radio)
{
    return s_rxTdRcfSwitch[radio % 2];
}
/* Ended by AICoder, pid:db3f8vdfbd6bf8214b79082d40ad12131095c8c8 */

/**********************************************************************
* 函数名称: GetPreAnalyseCarrIdx
* 功能描述: 根据载波的方向、通道、制式、业务载波号等信息获取载波序号
* 输入参数: pCarrInfoAllChans 上行下行全载波信息
* 输出参数: 无
* 返  回  值: >=BSP_MAX_CHAN_NUM 代表出错
            < BSP_MAX_CHAN_NUM 代表获取的载波需要
************************************************************************/
static UINT32 GetPreAnalyseCarrIdx(UINT32 dir, UINT32 bspChan, UINT32 radio, UINT32 carrNo)
{
    UINT32 retVal = BSP_OK;
    UINT32 difChan = 0;
    UINT32 chipId = 0;
    T_BspAdaptOneChanCarrInfo *pCarrInfo = NULL;
    UINT32 carrLoop = 0;

    retVal |= BspGetDifInfoByBspChn(bspChan, dir, &chipId, &difChan);
    if (BSP_OK != retVal)
    {
        BspLog(LOG_LEVEL_0,"[%s] bspChan[%d] Get difChan[%d] Error!\n",__FUNCTION__, bspChan, difChan);
        return retVal;
    }

    pCarrInfo = BspHalAdaptGetDifChanCarrInfo(dir, difChan);
    if(NULL == pCarrInfo)
    {
        BspLog(LOG_LEVEL_0,"[%s] BspHalAdaptGetDifChanCarrInfo return null!\n",__FUNCTION__);
        return BSP_ERROR;        
    }

    for(carrLoop=0; carrLoop<pCarrInfo->carrNum; carrLoop++)
    {
        if(pCarrInfo->oneCarrInfo[carrLoop].difCarrNo == carrNo &&
           pCarrInfo->oneCarrInfo[carrLoop].carrRadio == radio)
        {
            return carrLoop;
        }
    }
    
    return BSP_ERROR;    
}


/**********************************************************************
* 函数名称: BspAnalyseRfcCfgFreqCarrInfo
* 功能描述: 配频模块载波资源预分析
* 输入参数: pCarrInfoAllChans 上行下行全载波信息
* 输出参数: 无
* 返  回  值: BSP_OK/BSP_ERROR
************************************************************************/
UINT32 BspAnalyseRfcCfgFreqCarrInfo(T_DestCarrInfoAllChans *pCarrInfoAllChans)
{
    UINT32 retVal       = BSP_OK;
    UINT32 carrTotalNum = 0;
    UINT32 chan         = 0;
    UINT32 bspChan      = 0;
    UINT32 rfChan      = 0;
    T_DifChanInfo *ptFailChanInfo = NULL;

    INPUT_POINTER_CHECK(pCarrInfoAllChans);
    ptFailChanInfo = (T_DifChanInfo *)malloc(sizeof(T_DifChanInfo));
    if (ptFailChanInfo == NULL)
    {
        return BSP_ERROR;
    }
    memset_s(ptFailChanInfo, sizeof(T_DifChanInfo), 0, sizeof(T_DifChanInfo));

    BspLog(LOG_LEVEL_0, "%s enter\n", __FUNCTION__);

    /* 保存预分析的载波映射关系 */
    BspSetPreAnalyseCarrIdxFunc(GetPreAnalyseCarrIdx);

    /* 如果有挂载的在中频预分析前执行的动作，则执行该动作 */
    if(NULL != s_pFuncCalledBeforePreAnalyse)
    {
        if(s_pFuncCalledBeforePreAnalyse() != BSP_OK)
        {
            BspLog(LOG_LEVEL_0,"%s>>s_pFuncCalledBeforePreAnalyse Error!\n", __FUNCTION__);
        }
    }
    retVal = BspAnalyseTxFreqCarrInfo(pCarrInfoAllChans, &carrTotalNum, ptFailChanInfo);
    if(BSP_OK != retVal)
    {
        BspLog(LOG_LEVEL_0,"[%s] BspAnalyseTxFreqCarrInfo error\n", __FUNCTION__);
        free(ptFailChanInfo);
        return retVal;
    }

    retVal = BspAnalyseRxFreqCarrInfo(pCarrInfoAllChans, &carrTotalNum, ptFailChanInfo);
    if(BSP_OK != retVal)
    {
        BspLog(LOG_LEVEL_0,"[%s] BspAnalyseRxFreqCarrInfo error\n", __FUNCTION__);
        free(ptFailChanInfo);
        return retVal;
    }

    /* 如果有挂载的在中频预分析后执行的动作，则执行该动作 */
    if(NULL != s_pFuncCalledAfterPreAnalyse)
    {
        if(s_pFuncCalledAfterPreAnalyse() != BSP_OK)
        {
            BspLog(LOG_LEVEL_0,"%s>>s_pFuncCalledAfterPreAnalyse Error!\n", __FUNCTION__);
        }
    }

    
    if(0 == carrTotalNum)
    {
        BspLog(LOG_LEVEL_0,"[%s] carrTotalNum is 0!!\n", __FUNCTION__);
        free(ptFailChanInfo);
        return BSP_OK;
    }

    for(chan = 0;chan<pCarrInfoAllChans->txChanNum;chan++)
    {
        rfChan = pCarrInfoAllChans->txCarrInfo[chan].chanNo;
        retVal = BspGetBspChnByRfChn(rfChan, TX, &bspChan);
        if (BSP_OK != retVal)
        {
            BspLog(LOG_LEVEL_0,"[%s] chan'%d - rfChan'%d get bspChn'%d error !!\n", __FUNCTION__, chan, rfChan, bspChan);
        }

        if(s_pFuncChanPowCalcSw)
        {
            s_pFuncChanPowCalcSw(bspChan,SWITCH_ON);
        }
    }

    freqCfgExLog(FREQCFG_ANALYSE,"[%s] finished! carrTotalNum is %d\n", __FUNCTION__,carrTotalNum);

    BspLog(LOG_LEVEL_0, "%s exit\n", __FUNCTION__);
    free(ptFailChanInfo);
    return retVal;
}

UINT32 BspAnalyseRfcCfgFreqCarrInfoNew(T_DestCarrInfoAllChans *pCarrInfoAllChans, T_AnalyseCarrResult *pAnalyseCarrRes)
{
    UINT32 retVal       = BSP_OK;
    UINT32 carrTotalNum = 0;
    UINT32 chan         = 0;
    UINT32 bspChan      = 0;
    UINT32 rfChan      = 0;
    UINT32 chanLoop = 0;
    UINT32 carrLoop = 0;
    UINT32 chanIndex = 0;
    T_DifChanInfo *ptTxFailChanInfo = NULL;
    T_DifChanInfo *ptRxFailChanInfo = NULL;

    INPUT_POINTER_CHECK(pCarrInfoAllChans);
    INPUT_POINTER_CHECK(pAnalyseCarrRes);

    ptTxFailChanInfo = (T_DifChanInfo *)malloc(sizeof(T_DifChanInfo));
    INPUT_POINTER_CHECK(ptTxFailChanInfo);
    memset_s(ptTxFailChanInfo, sizeof(T_DifChanInfo), 0, sizeof(T_DifChanInfo));

    ptRxFailChanInfo = (T_DifChanInfo *)malloc(sizeof(T_DifChanInfo));
    if (ptRxFailChanInfo == NULL)
    {
        free(ptTxFailChanInfo);
        return BSP_ERROR;
    }
    memset_s(ptRxFailChanInfo, sizeof(T_DifChanInfo), 0, sizeof(T_DifChanInfo));

    BspLog(LOG_LEVEL_0, "%s enter\n", __FUNCTION__);

    /* 保存预分析的载波映射关系 */
    BspSetPreAnalyseCarrIdxFunc(GetPreAnalyseCarrIdx);

    /* 如果有挂载的在中频预分析前执行的动作，则执行该动作 */
    if(NULL != s_pFuncCalledBeforePreAnalyse)
    {
        retVal = s_pFuncCalledBeforePreAnalyse();
        (VOID)BspJudgeRetureVal(retVal,LOG_LEVEL_0,"%s>>s_pFuncCalledBeforePreAnalyse Error!\n", __FUNCTION__);
    }
    retVal = BspAnalyseTxFreqCarrInfo(pCarrInfoAllChans, &carrTotalNum, ptTxFailChanInfo);
    if(BSP_OK != retVal)
    {
        BspLog(LOG_LEVEL_0,"[%s] BspAnalyseTxFreqCarrInfo error\n", __FUNCTION__);
        free(ptTxFailChanInfo);
        free(ptRxFailChanInfo);
        return retVal;
    }

    retVal = BspAnalyseRxFreqCarrInfo(pCarrInfoAllChans, &carrTotalNum, ptRxFailChanInfo);
    if(BSP_OK != retVal)
    {
        BspLog(LOG_LEVEL_0,"[%s] BspAnalyseRxFreqCarrInfo error\n", __FUNCTION__);
        free(ptTxFailChanInfo);
        free(ptRxFailChanInfo);
        return retVal;
    }
    for (chanLoop = 0; chanLoop < IC_CHAN_MAX_NUM; chanLoop++)
    {
        if(0 == ptTxFailChanInfo->atChanInfo[chanLoop].uiCarrNum)
        {
            continue;
        }
        pAnalyseCarrRes->txChanNum += 1;
        pAnalyseCarrRes->txCarrInfo[chanIndex].chanNo = chanLoop;
        pAnalyseCarrRes->txCarrInfo[chanIndex].carrNum = ptTxFailChanInfo->atChanInfo[chanLoop].uiCarrNum;
        BspLog(0,"[%s] txChanNum = %d, chanLoop = %d, carrNum = %d\n",__FUNCTION__,pAnalyseCarrRes->txChanNum,chanLoop,ptTxFailChanInfo->atChanInfo[chanLoop].uiCarrNum);
        for (carrLoop = 0; carrLoop < ptTxFailChanInfo->atChanInfo[chanLoop].uiCarrNum; carrLoop++)
        {
            pAnalyseCarrRes->txCarrInfo[chanIndex].carrInfo[carrLoop].carrNo = ptTxFailChanInfo->atChanInfo[chanLoop].atCarrInfo[carrLoop].uiCarrId;
            pAnalyseCarrRes->txCarrInfo[chanIndex].carrInfo[carrLoop].radioMode = ptTxFailChanInfo->atChanInfo[chanLoop].atCarrInfo[carrLoop].uiCarrRadio;
            pAnalyseCarrRes->txCarrInfo[chanIndex].carrInfo[carrLoop].freq = ptTxFailChanInfo->atChanInfo[chanLoop].atCarrInfo[carrLoop].uiCarrFreq;
            pAnalyseCarrRes->txCarrInfo[chanIndex].carrInfo[carrLoop].bandWidth = ptTxFailChanInfo->atChanInfo[chanLoop].atCarrInfo[carrLoop].uiCarrBw;
            pAnalyseCarrRes->txCarrInfo[chanIndex].carrInfo[carrLoop].cellId = ptTxFailChanInfo->atChanInfo[chanLoop].atCarrInfo[carrLoop].uiCellId;
            pAnalyseCarrRes->txCarrInfo[chanIndex].carrInfo[carrLoop].errorCode = ptTxFailChanInfo->atChanInfo[chanLoop].atCarrInfo[carrLoop].uiErrorCode;
        }
        chanIndex += 1;
    }
    chanIndex = 0;
    for (chanLoop = 0; chanLoop < IC_CHAN_MAX_NUM; chanLoop++)
    {
        if(0 == ptRxFailChanInfo->atChanInfo[chanLoop].uiCarrNum)
        {
            continue;
        }
        pAnalyseCarrRes->rxChanNum += 1;
        pAnalyseCarrRes->rxCarrInfo[chanIndex].chanNo = chanLoop;
        pAnalyseCarrRes->rxCarrInfo[chanIndex].carrNum = ptRxFailChanInfo->atChanInfo[chanLoop].uiCarrNum;
        BspLog(0,"[%s] rxChanNum = %d, chanLoop = %d, carrNum = %d\n",__FUNCTION__,pAnalyseCarrRes->rxChanNum,chanLoop,ptRxFailChanInfo->atChanInfo[chanLoop].uiCarrNum);
        for (carrLoop = 0; carrLoop < ptRxFailChanInfo->atChanInfo[chanLoop].uiCarrNum; carrLoop++)
        {
            pAnalyseCarrRes->rxCarrInfo[chanIndex].carrInfo[carrLoop].carrNo = ptRxFailChanInfo->atChanInfo[chanLoop].atCarrInfo[carrLoop].uiCarrId;
            pAnalyseCarrRes->rxCarrInfo[chanIndex].carrInfo[carrLoop].radioMode = ptRxFailChanInfo->atChanInfo[chanLoop].atCarrInfo[carrLoop].uiCarrRadio;
            pAnalyseCarrRes->rxCarrInfo[chanIndex].carrInfo[carrLoop].freq = ptRxFailChanInfo->atChanInfo[chanLoop].atCarrInfo[carrLoop].uiCarrFreq;
            pAnalyseCarrRes->rxCarrInfo[chanIndex].carrInfo[carrLoop].bandWidth = ptRxFailChanInfo->atChanInfo[chanLoop].atCarrInfo[carrLoop].uiCarrBw;
            pAnalyseCarrRes->rxCarrInfo[chanIndex].carrInfo[carrLoop].cellId = ptRxFailChanInfo->atChanInfo[chanLoop].atCarrInfo[carrLoop].uiCellId;
            pAnalyseCarrRes->rxCarrInfo[chanIndex].carrInfo[carrLoop].errorCode = ptRxFailChanInfo->atChanInfo[chanLoop].atCarrInfo[carrLoop].uiErrorCode;
        }
        chanIndex += 1;
    }

    /* 如果有挂载的在中频预分析后执行的动作，则执行该动作 */
    if(NULL != s_pFuncCalledAfterPreAnalyse)
    {
        retVal = s_pFuncCalledAfterPreAnalyse();
        (VOID)BspJudgeRetureVal(retVal, LOG_LEVEL_0, "%s>>s_pFuncCalledAfterPreAnalyse Error!\n", __FUNCTION__);
    }

    if(0 == carrTotalNum)
    {
        BspLog(LOG_LEVEL_0,"[%s] carrTotalNum is 0!!\n", __FUNCTION__);
        free(ptTxFailChanInfo);
        free(ptRxFailChanInfo);
        return BSP_OK;
    }

    for(chan = 0; ((chan < BSP_MAX_CHAN_NUM) && (chan < pCarrInfoAllChans->txChanNum)); chan++)
    {
        rfChan = pCarrInfoAllChans->txCarrInfo[chan].chanNo;
        retVal = BspGetBspChnByRfChn(rfChan, TX, &bspChan);
        if (BSP_OK != retVal)
        {
            BspLog(LOG_LEVEL_0,"[%s] chan'%d - rfChan'%d get bspChn'%d error !!\n", __FUNCTION__, chan, rfChan, bspChan);
        }

        if(s_pFuncChanPowCalcSw)
        {
            s_pFuncChanPowCalcSw(bspChan,SWITCH_ON);
        }
    }

    freqCfgExLog(FREQCFG_ANALYSE,"[%s] finished! carrTotalNum is %d\n", __FUNCTION__,carrTotalNum);

    BspLog(LOG_LEVEL_0, "%s exit\n", __FUNCTION__);
    free(ptTxFailChanInfo);
    free(ptRxFailChanInfo);
    return retVal;
}

/* Started by AICoder, pid:qba6ag584e9c23314bc109d920981b5b60647037 */
UINT32 BspGetSideFilterSw(UINT32 dir, UINT32 radioMode, UINT32 bandWidth, UINT32 *filterSw)
{
    UINT32 loopRadio = 0;
    UINT32 loopBw = 0;
    T_FilterAbilityInfo *pFilterAbility = BspGetFilterAbilityInfo();

    INPUT_POINTER_CHECK(filterSw);
    INPUT_POINTER_CHECK(pFilterAbility);

    if (dir >= PRX)
    {
        dbgErr("[%s]: dir'%d out of range!\n",__FUNCTION__, dir);
        return BSP_ERROR;
    }
    *filterSw = SWITCH_OFF;

    dbgInfoEx("[%s] dir:%d, radioMode:0x%x, bandWidth:%d, rruSupport:%d \n",
            __FUNCTION__, dir, radioMode, bandWidth, pFilterAbility[dir].rruSupport);

    if (FALSE == pFilterAbility[dir].rruSupport)
    {
        *filterSw = SWITCH_OFF;
        return BSP_OK;
    }

    for (loopRadio = 0; loopRadio < pFilterAbility[dir].radioSum; loopRadio++)
    {
        if (radioMode == pFilterAbility[dir].radioInfo[loopRadio].radio)
        {
            dbgInfoEx("[%s] radio:0x%x, bwSum:%d.\n", __FUNCTION__,
                pFilterAbility[dir].radioInfo[loopRadio].radio, pFilterAbility[dir].radioInfo[loopRadio].bwSum);

            /*整机支持, 且制式对应带宽总数为0, 则该制式不区分带宽均支持单边滤波*/
            if (0 == pFilterAbility[dir].radioInfo[loopRadio].bwSum)
            {
                if (bandWidth <= BANDWIDTH_20M)
                {
                    *filterSw = SWITCH_ON;
                }
                break;
            }

            for (loopBw = 0; loopBw < pFilterAbility[dir].radioInfo[loopRadio].bwSum; loopBw++)
            {
                dbgInfoEx("[%s] loopBw:%d, bandWidth:%d.\n", __FUNCTION__,
                        loopBw, pFilterAbility[dir].radioInfo[loopRadio].bandWidth[loopBw]);
                if (bandWidth == pFilterAbility[dir].radioInfo[loopRadio].bandWidth[loopBw])
                {
                    *filterSw = SWITCH_ON;
                    break;
                }
            }
        }
    }

    return BSP_OK;
}
/* Ended by AICoder, pid:qba6ag584e9c23314bc109d920981b5b60647037 */

/**********************************************************************
* 函数名称: BspAnalyseTxFreqCarrInfo
* 功能描述: 配频模块下行资源预分析
* 输入参数: pCarrInfoAllChans 上下行所有通道通道载波信息
* 输出参数: 无
* 返  回  值: BSP_OK/BSP_ERROR
************************************************************************/
UINT32 BspAnalyseTxFreqCarrInfo(T_DestCarrInfoAllChans *pCarrInfoAllChans,
        UINT32 *carrTotalNum, T_DifChanInfo *ptTxFailChanInfo)
{
    UINT32 chanLoop       = 0;
    UINT32 rfChnlNo       = 0;
    UINT32 txChanNum      = 0;
    UINT32 retVal         = BSP_OK;
    UINT32 chipId         = 0;
    UINT32 carrNumPerChan = 0;
    UINT32 carrLoop       = 0;
    UINT32 carr           = 0;
    UINT32 carrNo         = 0;
    UINT32 bspChan        = 0;
    UINT32 halDifChan     = 0;
    UINT32 sideFilterSw   = SWITCH_OFF;
    T_BspHalAdaptChanInfo *txDifChanInfo = NULL;
    T_FpgaInfoInit *pFpgaInfo = BspGetFpgaInfo();

    INPUT_POINTER_CHECK(pCarrInfoAllChans);
    INPUT_POINTER_CHECK(carrTotalNum);

    carr = *carrTotalNum;
    txChanNum = pCarrInfoAllChans->txChanNum;
    freqCfgExLog(FREQCFG_ANALYSE, "[%s] enter, txChanNum is %d\n",__FUNCTION__,txChanNum);

    txDifChanInfo = (T_BspHalAdaptChanInfo *)malloc(sizeof(T_BspHalAdaptChanInfo));
    if (txDifChanInfo == NULL)
    {
        return BSP_ERROR;
    }
    memset(txDifChanInfo, 0, sizeof(T_BspHalAdaptChanInfo));
    txDifChanInfo->chanNum = pCarrInfoAllChans->txChanNum;

    for (chanLoop = 0; chanLoop < txChanNum; chanLoop++)
    {
        rfChnlNo = pCarrInfoAllChans->txCarrInfo[chanLoop].chanNo;
        retVal |= BspGetBspChnByRfChn(rfChnlNo, TX, &bspChan);
        if (BSP_OK != retVal)
        {
            free(txDifChanInfo);
            BspLog(LOG_LEVEL_0,"[%s] chanLoop[%d] Get BspChan[%d] by RfChnl[%d] Error!\n" ,__FUNCTION__, chanLoop, bspChan, rfChnlNo);
            return retVal;
        }

        retVal |= BspGetDifInfoByBspChn(bspChan, TX, &chipId, &halDifChan);
        if (BSP_OK != retVal)
        {
            free(txDifChanInfo);
            BspLog(LOG_LEVEL_0,"[%s] chanLoop[%d] bspChan[%d] Get difChan[%d] Error!\n",__FUNCTION__, chanLoop, bspChan, halDifChan);
            return retVal;
        }
        txDifChanInfo->chanInfo[chanLoop].difChanNo = halDifChan;

        carrNumPerChan = pCarrInfoAllChans->txCarrInfo[chanLoop].carrNum;
        if (carrNumPerChan > NELEMENTS(pCarrInfoAllChans->txCarrInfo[chanLoop].carrInfo))
        {
            free(txDifChanInfo);
            BspLog(LOG_LEVEL_0,"[%s] chanLoop[%d] carrNum[%d] out of range!\n", __FUNCTION__, chanLoop, carrNumPerChan);
            return retVal;
        }
        freqCfgExLog(FREQCFG_ANALYSE, "[%s] chanLoop[%2d] TxChnl[%2d] : CarrNumPerChnl= %d\n",
                  __FUNCTION__, chanLoop, rfChnlNo , carrNumPerChan);

        txDifChanInfo->chanInfo[chanLoop].carrNum = carrNumPerChan;
        for (carrLoop = 0; carrLoop < carrNumPerChan; carrLoop++)
        {
            /* fpga链路，d42链路无需关注此处 */
            if (NULL != pFpgaInfo && BSP_RADIO_STANDARD_AIOT == pCarrInfoAllChans->txCarrInfo[chanLoop].carrInfo[carrLoop].radioMode)
            {
                if (bspChan < BSP_HALADAPT_IC_CHAN_MAX_NUM && FPGA_CHAN == pFpgaInfo->txFpgaChanFlag[bspChan])
                {
                    if(s_pFuncChanPowCalcSw)
                    {

                        s_pFuncChanPowCalcSw(bspChan,SWITCH_ON);
                    }
                    continue;
                }

            }
            carrNo = pCarrInfoAllChans->txCarrInfo[chanLoop].carrInfo[carrLoop].carrNo;

            txDifChanInfo->chanInfo[chanLoop].oneCarrInfo[carrLoop].difCarrNo = carrNo;
            txDifChanInfo->chanInfo[chanLoop].oneCarrInfo[carrLoop].carrFreq  =
                    pCarrInfoAllChans->txCarrInfo[chanLoop].carrInfo[carrLoop].freq;
            txDifChanInfo->chanInfo[chanLoop].oneCarrInfo[carrLoop].carrBw  =
                    pCarrInfoAllChans->txCarrInfo[chanLoop].carrInfo[carrLoop].bandWidth;
            txDifChanInfo->chanInfo[chanLoop].oneCarrInfo[carrLoop].carrRadio =
                    pCarrInfoAllChans->txCarrInfo[chanLoop].carrInfo[carrLoop].radioMode;
            txDifChanInfo->chanInfo[chanLoop].oneCarrInfo[carrLoop].delOrAddFlag =
                    pCarrInfoAllChans->txCarrInfo[chanLoop].carrInfo[carrLoop].delOrAddFlag;
            txDifChanInfo->chanInfo[chanLoop].oneCarrInfo[carrLoop].isRcf = 1;
            txDifChanInfo->chanInfo[chanLoop].oneCarrInfo[carrLoop].isSsb = 0;
            txDifChanInfo->chanInfo[chanLoop].oneCarrInfo[carrLoop].uiCellId =
                    pCarrInfoAllChans->txCarrInfo[chanLoop].carrInfo[carrLoop].cellid;

            BspGetSideFilterSw(TX, txDifChanInfo->chanInfo[chanLoop].oneCarrInfo[carrLoop].carrRadio, txDifChanInfo->chanInfo[chanLoop].oneCarrInfo[carrLoop].carrBw, &sideFilterSw);
            txDifChanInfo->chanInfo[chanLoop].oneCarrInfo[carrLoop].sideFilterSw = sideFilterSw;

            BspLog(LOG_LEVEL_0, "freq: [%s] Loop[%2d-%2d] carrNo[%2d] carrFreq[%2d] "
                    "carrBw[%8d] \\ carrRadio[%4d] delOrAddFlag[%d] isRcf[%d] isSsb[%d] sideFilterSw[%d] cellid[%d]\n",
                    __FUNCTION__, chanLoop, carrLoop, carrNo,
                    txDifChanInfo->chanInfo[chanLoop].oneCarrInfo[carrLoop].carrFreq,
                    txDifChanInfo->chanInfo[chanLoop].oneCarrInfo[carrLoop].carrBw,
                    txDifChanInfo->chanInfo[chanLoop].oneCarrInfo[carrLoop].carrRadio,
                    txDifChanInfo->chanInfo[chanLoop].oneCarrInfo[carrLoop].delOrAddFlag,
                    txDifChanInfo->chanInfo[chanLoop].oneCarrInfo[carrLoop].isRcf,
                    txDifChanInfo->chanInfo[chanLoop].oneCarrInfo[carrLoop].isSsb,
                    txDifChanInfo->chanInfo[chanLoop].oneCarrInfo[carrLoop].sideFilterSw,
                    txDifChanInfo->chanInfo[chanLoop].oneCarrInfo[carrLoop].uiCellId);
        }

        carr+=carrNumPerChan;
    }

    *carrTotalNum = carr;

    retVal = BspHalAdaptTxAnalysis(txDifChanInfo, ptTxFailChanInfo);
    if (BSP_OK != retVal)
    {
        free(txDifChanInfo);
        BspLog(LOG_LEVEL_0,"[%s]AllCarrNum[%d] tx resource alloc Error!\n" ,__FUNCTION__, carr);
        return retVal;
    }
    free(txDifChanInfo);

    freqCfgExLog(FREQCFG_ANALYSE, "[%s] exit\n",__FUNCTION__);
    return retVal;
}

/**********************************************************************
* 函数名称: BspAnalyseRxFreqCarrInfo
* 功能描述: 配频模块上行资源预分析
* 输入参数: pCarrInfoAllChans 上下行所有通道通道载波信息
* 输出参数: 无
* 返  回  值: BSP_OK/BSP_ERROR
************************************************************************/
UINT32 BspAnalyseRxFreqCarrInfo(T_DestCarrInfoAllChans *pCarrInfoAllChans,
        UINT32 *carrTotalNum, T_DifChanInfo *ptRxFailChanInfo)
{
    UINT32 chanLoop       = 0;
    UINT32 rfChnlNo       = 0;
    UINT32 rxChanNum      = 0;
    UINT32 retVal         = BSP_OK;
    UINT32 chipId         = 0;
    UINT32 carrNumPerChan = 0;
    UINT32 carrLoop       = 0;
    UINT32 carr           = 0;
    UINT32 carrNo         = 0;
    UINT32 bspChan        = 0;
    UINT32 halDifChan     = 0;
    UINT32 sideFilterSw   = SWITCH_OFF;
    T_BspHalAdaptChanInfo *rxDifChanInfo = NULL;
    T_FpgaInfoInit *pFpgaInfo = BspGetFpgaInfo();

    INPUT_POINTER_CHECK(pCarrInfoAllChans);
    INPUT_POINTER_CHECK(carrTotalNum);

    carr = *carrTotalNum;
    rxChanNum = pCarrInfoAllChans->rxChanNum;

    freqCfgExLog(FREQCFG_ANALYSE, "[%s] enter, rxChanNum is %d\n",__FUNCTION__,rxChanNum);
    rxDifChanInfo = (T_BspHalAdaptChanInfo *)malloc(sizeof(T_BspHalAdaptChanInfo));
    if (rxDifChanInfo == NULL)
    {
        return BSP_ERROR;
    }
    memset(rxDifChanInfo, 0, sizeof(T_BspHalAdaptChanInfo));
    rxDifChanInfo->chanNum = pCarrInfoAllChans->rxChanNum;

    for (chanLoop = 0; chanLoop < rxChanNum; chanLoop++)
    {
        rfChnlNo = pCarrInfoAllChans->rxCarrInfo[chanLoop].chanNo;

        retVal |= BspGetBspChnByRfChn(rfChnlNo, RX, &bspChan);
        if (BSP_OK != retVal)
        {
            free(rxDifChanInfo);
            BspLog(LOG_LEVEL_0,"[%s] chanLoop[%d] Get BspChan[%d] by RfChnl[%d] Error!\n" ,__FUNCTION__, chanLoop, bspChan, rfChnlNo);
            return retVal;
        }

        retVal |= BspGetDifInfoByBspChn(bspChan, RX, &chipId, &halDifChan);
        if (BSP_OK != retVal)
        {
            free(rxDifChanInfo);
            BspLog(LOG_LEVEL_0,"[%s] chanLoop[%d] bspChan[%d] Get difChan[%d] Error!\n",__FUNCTION__, chanLoop, bspChan, halDifChan);
            return retVal;
        }
        rxDifChanInfo->chanInfo[chanLoop].difChanNo = halDifChan;

        carrNumPerChan = pCarrInfoAllChans->rxCarrInfo[chanLoop].carrNum;
        if (carrNumPerChan > NELEMENTS(pCarrInfoAllChans->rxCarrInfo[chanLoop].carrInfo))
        {
            free(rxDifChanInfo);
            BspLog(LOG_LEVEL_0,"[%s] chanLoop[%d] carrNum[%d] out of range!\n", __FUNCTION__, chanLoop, carrNumPerChan);
            return retVal;
        }

        freqCfgExLog(FREQCFG_ANALYSE, "[%s] chanLoop[%2d] RxChnl[%2d]: CarrNumPerChnl= %d\n",
                  __FUNCTION__, chanLoop, rfChnlNo, carrNumPerChan);

        rxDifChanInfo->chanInfo[chanLoop].carrNum = carrNumPerChan;

        for (carrLoop = 0 ;carrLoop < carrNumPerChan; carrLoop++)
        {
            /* fpga链路，d42链路无需关注此处 */
            if (NULL != pFpgaInfo && BSP_RADIO_STANDARD_AIOT == pCarrInfoAllChans->rxCarrInfo[chanLoop].carrInfo[carrLoop].radioMode)
            {
                if (bspChan < BSP_MAX_CHAN_NUM && FPGA_CHAN == pFpgaInfo->rxFpgaChanFlag[bspChan])
                {
                    continue;
                }
            }

            carrNo = pCarrInfoAllChans->rxCarrInfo[chanLoop].carrInfo[carrLoop].carrNo;

            rxDifChanInfo->chanInfo[chanLoop].oneCarrInfo[carrLoop].difCarrNo = carrNo;
            rxDifChanInfo->chanInfo[chanLoop].oneCarrInfo[carrLoop].carrFreq  =
                    pCarrInfoAllChans->rxCarrInfo[chanLoop].carrInfo[carrLoop].freq;
            rxDifChanInfo->chanInfo[chanLoop].oneCarrInfo[carrLoop].carrBw  =
                    pCarrInfoAllChans->rxCarrInfo[chanLoop].carrInfo[carrLoop].bandWidth;
            rxDifChanInfo->chanInfo[chanLoop].oneCarrInfo[carrLoop].carrRadio =
                    pCarrInfoAllChans->rxCarrInfo[chanLoop].carrInfo[carrLoop].radioMode;
            rxDifChanInfo->chanInfo[chanLoop].oneCarrInfo[carrLoop].delOrAddFlag =
                    pCarrInfoAllChans->rxCarrInfo[chanLoop].carrInfo[carrLoop].delOrAddFlag;
            rxDifChanInfo->chanInfo[chanLoop].oneCarrInfo[carrLoop].isRcf = 1;
            /* Started by AICoder, pid:d20d5mfc1a72c6a149920ae8f0eb2a1025b149fb */
            if(TRUE == BspIsRxTdRcfSwitchBypass(!!(rxDifChanInfo->chanInfo[chanLoop].oneCarrInfo[carrLoop].carrRadio - BSP_RADIO_STANDARD_LTE_FDD)))
            {
                rxDifChanInfo->chanInfo[chanLoop].oneCarrInfo[carrLoop].isRcf = 0;
            }
            /* Ended by AICoder, pid:d20d5mfc1a72c6a149920ae8f0eb2a1025b149fb */
            rxDifChanInfo->chanInfo[chanLoop].oneCarrInfo[carrLoop].isSsb = 0;
            rxDifChanInfo->chanInfo[chanLoop].oneCarrInfo[carrLoop].uiCellId =
                    pCarrInfoAllChans->rxCarrInfo[chanLoop].carrInfo[carrLoop].cellid;

            BspGetSideFilterSw(RX, rxDifChanInfo->chanInfo[chanLoop].oneCarrInfo[carrLoop].carrRadio, rxDifChanInfo->chanInfo[chanLoop].oneCarrInfo[carrLoop].carrBw, &sideFilterSw);
            rxDifChanInfo->chanInfo[chanLoop].oneCarrInfo[carrLoop].sideFilterSw = sideFilterSw;

            BspLog(LOG_LEVEL_0, "freq: [%s] Loop[%2d-%2d] carrNo[%d] "
                    "carrFreq[%2d] carrBw[%8d] \\ carrRadio[%4d] delOrAddFlag[%d] isRcf[%d] isSsb[%d] sideFilterSw[%d] cellId[%d]\n",
                    __FUNCTION__, chanLoop, carrLoop, carrNo,
                    rxDifChanInfo->chanInfo[chanLoop].oneCarrInfo[carrLoop].carrFreq,
                    rxDifChanInfo->chanInfo[chanLoop].oneCarrInfo[carrLoop].carrBw,
                    rxDifChanInfo->chanInfo[chanLoop].oneCarrInfo[carrLoop].carrRadio,
                    rxDifChanInfo->chanInfo[chanLoop].oneCarrInfo[carrLoop].delOrAddFlag,
                    rxDifChanInfo->chanInfo[chanLoop].oneCarrInfo[carrLoop].isRcf,
                    rxDifChanInfo->chanInfo[chanLoop].oneCarrInfo[carrLoop].isSsb,
                    rxDifChanInfo->chanInfo[chanLoop].oneCarrInfo[carrLoop].sideFilterSw,
                    rxDifChanInfo->chanInfo[chanLoop].oneCarrInfo[carrLoop].uiCellId);
        }

        carr+=carrNumPerChan;
    }
    *carrTotalNum = carr;

    retVal = BspHalAdaptRxAnalysis(rxDifChanInfo, ptRxFailChanInfo);
    if (BSP_OK != retVal)
    {
        free(rxDifChanInfo);
        BspLog(LOG_LEVEL_0,"[%s]AllCarrNum[%d] rx resource alloc Error!\n" ,__FUNCTION__, carr);
        return retVal;
    }
    free(rxDifChanInfo);
    freqCfgExLog(FREQCFG_ANALYSE, "[%s] exit\n",__FUNCTION__);
    return retVal;
}

/**********************************************************************
* 函数名称: BspPreAnalyseCarrInfo
* 功能描述: 配频模块0级DUC/DDC预分析,将全载波信息下发给hal,用于判断GUN个数
* 输入参数: pCarrInfoAllChans 上行下行全载波信息
* 输出参数: 无
* 返  回  值: BSP_OK/BSP_ERROR
************************************************************************/
UINT32 BspPreAnalyseCarrInfo(T_DestCarrInfoAllChans *pCarrInfoAllChans)
{
    UINT32 retVal = BSP_OK;
    UINT32 carrTotalNum = 0;

    BspLog(LOG_LEVEL_0, "%s enter\n", __FUNCTION__);

    INPUT_POINTER_CHECK(pCarrInfoAllChans);

    retVal = BspAnalyseTxFreqDuco(pCarrInfoAllChans, &carrTotalNum);
    if(BSP_OK != retVal)
    {
        BspLog(LOG_LEVEL_0,"[%s] BspAnalyseTxFreqDuco error\n", __FUNCTION__);
        return retVal;
    }

    retVal = BspAnalyseRxFreqDdc0(pCarrInfoAllChans, &carrTotalNum);
    if(BSP_OK != retVal)
    {
        BspLog(LOG_LEVEL_0,"[%s] BspAnalyseRxFreqDdc0 error\n", __FUNCTION__);
        return retVal;
    }

    
    if(0 == carrTotalNum)
    {
        BspLog(LOG_LEVEL_0,"[%s] carrTotalNum is 0!!\n", __FUNCTION__);
        return BSP_OK;
    }

    freqCfgExLog(FREQCFG_ANALYSE,"[%s] finished! carrTotalNum is %d\n", __FUNCTION__,carrTotalNum);

    BspLog(LOG_LEVEL_0, "%s exit\n", __FUNCTION__);

    return retVal;
}

/**********************************************************************
* 函数名称: BspPreAnalyseCarrInfo
* 功能描述: 配频模块0级DUC/DDC预分析,将全载波信息下发给hal,用于判断GUN个数
* 输入参数: pCarrInfoAllChans 上行下行全载波信息
* 输出参数: 无
* 返  回  值: BSP_OK/BSP_ERROR
************************************************************************/
UINT32 BspPreAnalyseCarrInfoRpt(T_DestCarrInfoAllChans *pCarrInfoAllChans, T_PreAnalyseCarrResult  *ptPreAnalyseCarrResult, UINT32 flag)
{
    UINT32 retVal = BSP_OK;
    UINT32 txCarrNum = 0;
    UINT32 rxCarrNum = 0;
    UINT32 carrTotalNum = 0;

    BspLog(LOG_LEVEL_0, "%s enter\n", __FUNCTION__);

    INPUT_POINTER_CHECK(pCarrInfoAllChans);
    INPUT_POINTER_CHECK(ptPreAnalyseCarrResult);

    retVal = BspAnalyseTxFreqDucoRpt(pCarrInfoAllChans, &txCarrNum, ptPreAnalyseCarrResult, flag);
    if(BSP_OK != retVal)
    {
        BspLog(LOG_LEVEL_0,"[%s] BspAnalyseTxFreqDucoRpt error\n", __FUNCTION__);
        return retVal;
    }

    retVal = BspAnalyseRxFreqDdc0Rpt(pCarrInfoAllChans, &rxCarrNum, ptPreAnalyseCarrResult, flag);
    if(BSP_OK != retVal)
    {
        BspLog(LOG_LEVEL_0,"[%s] BspAnalyseRxFreqDdc0Rpt error\n", __FUNCTION__);
        return retVal;
    }

    carrTotalNum = txCarrNum + rxCarrNum;
    
    if(0 == carrTotalNum)
    {
        BspLog(LOG_LEVEL_0,"[%s] carrTotalNum is 0!!\n", __FUNCTION__);
        return BSP_OK;
    }

    freqCfgExLog(FREQCFG_ANALYSE,"[%s] finished! carrTotalNum is %d\n", __FUNCTION__,carrTotalNum);

    BspLog(LOG_LEVEL_0, "%s exit\n", __FUNCTION__);

    return retVal;
}

/**********************************************************************
* 函数名称: BspAnalyseTxFreqDdco
* 功能描述: 配频模块下行0级DUC资源预分析
* 输入参数: pCarrInfoAllChans 上下行所有通道通道载波信息
* 输出参数: 无
* 返  回  值: BSP_OK/BSP_ERROR
************************************************************************/
UINT32 BspAnalyseTxFreqDuco(T_DestCarrInfoAllChans *pCarrInfoAllChans,
        UINT32 *carrTotalNum)
{
    UINT32 chanLoop       = 0;
    UINT32 rfChnlNo       = 0;
    UINT32 txChanNum      = 0;
    UINT32 retVal         = BSP_OK;
    UINT32 chipId         = 0;
    UINT32 carrNumPerChan = 0;
    UINT32 carrLoop       = 0;
    UINT32 carr           = 0;
    UINT32 carrNo         = 0;
    UINT32 bspChan        = 0;
    UINT32 halDifChan     = 0;
    T_BspHalAdaptChanInfo *txDifChanInfo = NULL;

    INPUT_POINTER_CHECK(pCarrInfoAllChans);
    INPUT_POINTER_CHECK(carrTotalNum);

    carr = *carrTotalNum;
    txChanNum = pCarrInfoAllChans->txChanNum;
    freqCfgExLog(FREQCFG_ANALYSE, "[%s] enter, DDC0 txChanNum is %d\n",__FUNCTION__,txChanNum);

    txDifChanInfo = (T_BspHalAdaptChanInfo *)malloc(sizeof(T_BspHalAdaptChanInfo));
    if (txDifChanInfo == NULL)
    {
        return BSP_ERROR;
    }
    memset(txDifChanInfo, 0, sizeof(T_BspHalAdaptChanInfo));
    txDifChanInfo->chanNum = pCarrInfoAllChans->txChanNum;

    for (chanLoop = 0; chanLoop < txChanNum; chanLoop++)
    {
        rfChnlNo = pCarrInfoAllChans->txCarrInfo[chanLoop].chanNo;

        retVal |= BspGetBspChnByRfChn(rfChnlNo, TX, &bspChan);
        if (BSP_OK != retVal)
        {
            free(txDifChanInfo);
            BspLog(LOG_LEVEL_0,"[%s] chanLoop[%d] Get BspChan[%d] by RfChnl[%d] Error!\n" ,__FUNCTION__, chanLoop, bspChan, rfChnlNo);
            return retVal;
        }

        retVal |= BspGetDifInfoByBspChn(bspChan, TX, &chipId, &halDifChan);
        if (BSP_OK != retVal)
        {
            free(txDifChanInfo);
            BspLog(LOG_LEVEL_0,"[%s] chanLoop[%d] bspChan[%d] Get difChan[%d] Error!\n",__FUNCTION__, chanLoop, bspChan, halDifChan);
            return retVal;
        }
        txDifChanInfo->chanInfo[chanLoop].difChanNo = halDifChan;

        carrNumPerChan = pCarrInfoAllChans->txCarrInfo[chanLoop].carrNum;
        if (carrNumPerChan > NELEMENTS(pCarrInfoAllChans->txCarrInfo[chanLoop].carrInfo))
        {
            free(txDifChanInfo);
            BspLog(LOG_LEVEL_0,"[%s] chanLoop[%d] carrNum[%d] out of range!\n", __FUNCTION__, chanLoop, carrNumPerChan);
            return retVal;
        }
        BspLog(LOG_LEVEL_0, "freq: [%s] chanLoop[%2d] TxChnl[%2d]: CarrNumPerChnl= %d\n",
                  __FUNCTION__, chanLoop, rfChnlNo, carrNumPerChan);

        txDifChanInfo->chanInfo[chanLoop].carrNum = carrNumPerChan;

        for (carrLoop = 0; carrLoop < carrNumPerChan; carrLoop++)
        {
            carrNo = pCarrInfoAllChans->txCarrInfo[chanLoop].carrInfo[carrLoop].carrNo;

            txDifChanInfo->chanInfo[chanLoop].oneCarrInfo[carrLoop].difCarrNo = carrNo;
            txDifChanInfo->chanInfo[chanLoop].oneCarrInfo[carrLoop].carrFreq  =
                    pCarrInfoAllChans->txCarrInfo[chanLoop].carrInfo[carrLoop].freq;
            txDifChanInfo->chanInfo[chanLoop].oneCarrInfo[carrLoop].carrBw  =
                    pCarrInfoAllChans->txCarrInfo[chanLoop].carrInfo[carrLoop].bandWidth;
            txDifChanInfo->chanInfo[chanLoop].oneCarrInfo[carrLoop].carrRadio =
                    pCarrInfoAllChans->txCarrInfo[chanLoop].carrInfo[carrLoop].radioMode;
            txDifChanInfo->chanInfo[chanLoop].oneCarrInfo[carrLoop].delOrAddFlag =
                    pCarrInfoAllChans->txCarrInfo[chanLoop].carrInfo[carrLoop].delOrAddFlag;
            txDifChanInfo->chanInfo[chanLoop].oneCarrInfo[carrLoop].isRcf = 1;
            txDifChanInfo->chanInfo[chanLoop].oneCarrInfo[carrLoop].isSsb = 0;

            BspLog(LOG_LEVEL_0, "freq: [%s] Loop[%2d-%2d] carrNo[%2d] carrFreq[%2d] "
                    "carrBw[%8d] \\ carrRadio[%4d] delOrAddFlag[%d] isRcf[%d] isSsb[%d]\n",
                    __FUNCTION__, chanLoop, carrLoop, carrNo,
                    txDifChanInfo->chanInfo[chanLoop].oneCarrInfo[carrLoop].carrFreq,
                    txDifChanInfo->chanInfo[chanLoop].oneCarrInfo[carrLoop].carrBw,
                    txDifChanInfo->chanInfo[chanLoop].oneCarrInfo[carrLoop].carrRadio,
                    txDifChanInfo->chanInfo[chanLoop].oneCarrInfo[carrLoop].delOrAddFlag,
                    txDifChanInfo->chanInfo[chanLoop].oneCarrInfo[carrLoop].isRcf,
                    txDifChanInfo->chanInfo[chanLoop].oneCarrInfo[carrLoop].isSsb);
        }

        carr+=carrNumPerChan;
    }

    *carrTotalNum = carr;

    retVal = BspHalAdaptTxAnalysisDuc0(txDifChanInfo);
    if (BSP_OK != retVal)
    {
        free(txDifChanInfo);
        BspLog(LOG_LEVEL_0,"[%s]AllCarrNum[%d] tx resource alloc Error!\n" ,__FUNCTION__, carr);
        return retVal;
    }
    free(txDifChanInfo);
    freqCfgExLog(FREQCFG_ANALYSE, "[%s] exit\n",__FUNCTION__);
    return retVal;
}

/**********************************************************************
* 函数名称: BspAnalyseTxFreqDdco
* 功能描述: 配频模块下行0级DUC资源预分析
* 输入参数: pCarrInfoAllChans 上下行所有通道通道载波信息
* 输出参数: 无
* 返  回  值: BSP_OK/BSP_ERROR
************************************************************************/
UINT32 BspAnalyseTxFreqDucoRpt(T_DestCarrInfoAllChans *pCarrInfoAllChans,
        UINT32 *carrTotalNum, T_PreAnalyseCarrResult  *ptPreAnalyseResult, UINT32 flag)
{
    UINT32 chanLoop       = 0;
    UINT32 rfChnlNo       = 0;
    UINT32 txChanNum      = 0;
    UINT32 retVal         = BSP_OK;
    UINT32 chipId         = 0;
    UINT32 carrNumPerChan = 0;
    UINT32 carrLoop       = 0;
    UINT32 carrAllNum     = 0;
    UINT32 carrNo         = 0;
    UINT32 bspChan        = 0;
    UINT32 halDifChan     = 0;
    T_BspHalAdaptChanInfo *txDifChanInfo = NULL;
    T_BspHalAdaptChanInfo *pFailtxDifChanInfo = NULL;

    INPUT_POINTER_CHECK(pCarrInfoAllChans);
    INPUT_POINTER_CHECK(ptPreAnalyseResult);
    INPUT_POINTER_CHECK(carrTotalNum);

    pFailtxDifChanInfo = (T_BspHalAdaptChanInfo *)malloc(sizeof(T_BspHalAdaptChanInfo));
    if (pFailtxDifChanInfo == NULL)
    {
        return BSP_ERROR;
    }
    memset_s(pFailtxDifChanInfo, sizeof(T_BspHalAdaptChanInfo), 0, sizeof(T_BspHalAdaptChanInfo));

    txDifChanInfo = (T_BspHalAdaptChanInfo *)malloc(sizeof(T_BspHalAdaptChanInfo));
    if (txDifChanInfo == NULL)
    {
        free(pFailtxDifChanInfo);
        return BSP_ERROR;
    }
    memset_s(txDifChanInfo, sizeof(T_BspHalAdaptChanInfo), 0, sizeof(T_BspHalAdaptChanInfo));

    txChanNum = pCarrInfoAllChans->txChanNum;
    dbgInfoEx("[%s] enter, DDC0 txChanNum is %d\n", __FUNCTION__, txChanNum);
    if ((txChanNum > NELEMENTS(pCarrInfoAllChans->txCarrInfo)) || (txChanNum > NELEMENTS(txDifChanInfo->chanInfo)))
    {
        free(txDifChanInfo);
        free(pFailtxDifChanInfo);
        BspLog(LOG_LEVEL_0,"[%s] txChanNum[%d] out of range!\n", __FUNCTION__, txChanNum);
        return BSP_ERROR;
    }
    txDifChanInfo->chanNum = txChanNum;

    for (chanLoop = 0; chanLoop < txChanNum; chanLoop++)
    {
        rfChnlNo = pCarrInfoAllChans->txCarrInfo[chanLoop].chanNo;

        retVal |= BspGetBspChnByRfChn(rfChnlNo, TX, &bspChan);
        if (BSP_OK != retVal)
        {
            free(txDifChanInfo);
            free(pFailtxDifChanInfo);
            BspLog(LOG_LEVEL_0,"[%s] chanLoop[%d] Get BspChan[%d] by RfChnl[%d] Error!\n" ,__FUNCTION__, chanLoop, bspChan, rfChnlNo);
            return retVal;
        }

        retVal |= BspGetDifInfoByBspChn(bspChan, TX, &chipId, &halDifChan);
        if (BSP_OK != retVal)
        {
            free(txDifChanInfo);
            free(pFailtxDifChanInfo);
            BspLog(LOG_LEVEL_0,"[%s] chanLoop[%d] bspChan[%d] Get difChan[%d] Error!\n",__FUNCTION__, chanLoop, bspChan, halDifChan);
            return retVal;
        }
        txDifChanInfo->chanInfo[chanLoop].difChanNo = halDifChan;

        carrNumPerChan = pCarrInfoAllChans->txCarrInfo[chanLoop].carrNum;
        if (carrNumPerChan > NELEMENTS(pCarrInfoAllChans->txCarrInfo[chanLoop].carrInfo))
        {
            free(txDifChanInfo);
            free(pFailtxDifChanInfo);
            BspLog(LOG_LEVEL_0,"[%s] chanLoop[%d] carrNum[%d] out of range!\n", __FUNCTION__, chanLoop, carrNumPerChan);
            return BSP_ERROR;
        }
        BspLog(LOG_LEVEL_0, "freq: [%s] chanLoop[%2d] TxChnl[%2d]: CarrNumPerChnl= %d\n",
                  __FUNCTION__, chanLoop, rfChnlNo, carrNumPerChan);

        txDifChanInfo->chanInfo[chanLoop].carrNum = carrNumPerChan;

        for (carrLoop = 0; carrLoop < carrNumPerChan; carrLoop++)
        {
            carrNo = pCarrInfoAllChans->txCarrInfo[chanLoop].carrInfo[carrLoop].carrNo;

            txDifChanInfo->chanInfo[chanLoop].oneCarrInfo[carrLoop].difCarrNo = carrNo;
            txDifChanInfo->chanInfo[chanLoop].oneCarrInfo[carrLoop].carrFreq  =
                    pCarrInfoAllChans->txCarrInfo[chanLoop].carrInfo[carrLoop].freq;
            txDifChanInfo->chanInfo[chanLoop].oneCarrInfo[carrLoop].carrBw  =
                    pCarrInfoAllChans->txCarrInfo[chanLoop].carrInfo[carrLoop].bandWidth;
            txDifChanInfo->chanInfo[chanLoop].oneCarrInfo[carrLoop].carrRadio =
                    pCarrInfoAllChans->txCarrInfo[chanLoop].carrInfo[carrLoop].radioMode;
            txDifChanInfo->chanInfo[chanLoop].oneCarrInfo[carrLoop].delOrAddFlag =
                    pCarrInfoAllChans->txCarrInfo[chanLoop].carrInfo[carrLoop].delOrAddFlag;
            txDifChanInfo->chanInfo[chanLoop].oneCarrInfo[carrLoop].isRcf = 1;
            txDifChanInfo->chanInfo[chanLoop].oneCarrInfo[carrLoop].isSsb = 0;

            txDifChanInfo->chanInfo[chanLoop].oneCarrInfo[carrLoop].uiCellId =
                    pCarrInfoAllChans->txCarrInfo[chanLoop].carrInfo[carrLoop].cellid;

            BspLog(LOG_LEVEL_0, "freq: [%s] Loop[%2d-%2d] carrNo[%2d] carrFreq[%2d] "
                    "carrBw[%8d] \\ carrRadio[%4d] delOrAddFlag[%d] isRcf[%d] isSsb[%d] cellId[%d]\n",
                    __FUNCTION__, chanLoop, carrLoop, carrNo,
                    txDifChanInfo->chanInfo[chanLoop].oneCarrInfo[carrLoop].carrFreq,
                    txDifChanInfo->chanInfo[chanLoop].oneCarrInfo[carrLoop].carrBw,
                    txDifChanInfo->chanInfo[chanLoop].oneCarrInfo[carrLoop].carrRadio,
                    txDifChanInfo->chanInfo[chanLoop].oneCarrInfo[carrLoop].delOrAddFlag,
                    txDifChanInfo->chanInfo[chanLoop].oneCarrInfo[carrLoop].isRcf,
                    txDifChanInfo->chanInfo[chanLoop].oneCarrInfo[carrLoop].isSsb,
					txDifChanInfo->chanInfo[chanLoop].oneCarrInfo[carrLoop].uiCellId);
        }

        carrAllNum += carrNumPerChan;
    }

    *carrTotalNum = carrAllNum;

    retVal = BspHalAdaptTxAnalysisDuc0Rpt(txDifChanInfo, pFailtxDifChanInfo, flag);
    if (BSP_OK != retVal)
    {
        free(txDifChanInfo);
        free(pFailtxDifChanInfo);
        BspLog(LOG_LEVEL_0,"[%s] AllCarrNum[%d] tx resource alloc Error!\n" ,__FUNCTION__, carrAllNum);
        return retVal;
    }

    ptPreAnalyseResult->txChanNum = pFailtxDifChanInfo->chanNum;

    for(chanLoop = 0; chanLoop < pFailtxDifChanInfo->chanNum; chanLoop++)
    {
        ptPreAnalyseResult->txCarrInfo[chanLoop].chanNo = pFailtxDifChanInfo->chanInfo[chanLoop].difChanNo;
        ptPreAnalyseResult->txCarrInfo[chanLoop].carrNum = pFailtxDifChanInfo->chanInfo[chanLoop].carrNum;

        BspLog(LOG_LEVEL_0, "overInfo: [%s] chanLoop[%d] / chanNum[%d], chanNo[%d], carrNum[%d] \n",__FUNCTION__, chanLoop,
                ptPreAnalyseResult->txChanNum, ptPreAnalyseResult->txCarrInfo[chanLoop].chanNo, ptPreAnalyseResult->txCarrInfo[chanLoop].carrNum);

        for(carrLoop = 0; carrLoop < pFailtxDifChanInfo->chanInfo[chanLoop].carrNum; carrLoop++)
        {
            ptPreAnalyseResult->txCarrInfo[chanLoop].carrInfo[carrLoop].carrNo = pFailtxDifChanInfo->chanInfo[chanLoop].oneCarrInfo[carrLoop].difCarrNo;
            ptPreAnalyseResult->txCarrInfo[chanLoop].carrInfo[carrLoop].freq = pFailtxDifChanInfo->chanInfo[chanLoop].oneCarrInfo[carrLoop].carrFreq;
            ptPreAnalyseResult->txCarrInfo[chanLoop].carrInfo[carrLoop].radioMode = pFailtxDifChanInfo->chanInfo[chanLoop].oneCarrInfo[carrLoop].carrRadio;
            ptPreAnalyseResult->txCarrInfo[chanLoop].carrInfo[carrLoop].bandWidth = pFailtxDifChanInfo->chanInfo[chanLoop].oneCarrInfo[carrLoop].carrBw;
            ptPreAnalyseResult->txCarrInfo[chanLoop].carrInfo[carrLoop].cellId = pFailtxDifChanInfo->chanInfo[chanLoop].oneCarrInfo[carrLoop].uiCellId;
            BspLog(LOG_LEVEL_0, "overInfo: [%s] Loop[%d-%d] carrNo[%d] carrFreq[%2d] carrBw[%d] carrRadio[0x%x] cellId[%d]\n",
                    __FUNCTION__, chanLoop, carrLoop,
                    ptPreAnalyseResult->txCarrInfo[chanLoop].carrInfo[carrLoop].carrNo,
                    ptPreAnalyseResult->txCarrInfo[chanLoop].carrInfo[carrLoop].freq,
                    ptPreAnalyseResult->txCarrInfo[chanLoop].carrInfo[carrLoop].bandWidth,
                    ptPreAnalyseResult->txCarrInfo[chanLoop].carrInfo[carrLoop].radioMode,
                    ptPreAnalyseResult->txCarrInfo[chanLoop].carrInfo[carrLoop].cellId);
        }
    }

    free(txDifChanInfo);
    free(pFailtxDifChanInfo);
    dbgInfoEx("[%s] exit\n", __FUNCTION__);
    return retVal;
}

/**********************************************************************
* 函数名称: BspAnalyseRxFreqDuc0
* 功能描述: 配频模块上行0级DDC资源预分析
* 输入参数: pCarrInfoAllChans 上下行所有通道通道载波信息
* 输出参数: 无
* 返  回  值: BSP_OK/BSP_ERROR
************************************************************************/
UINT32 BspAnalyseRxFreqDdc0(T_DestCarrInfoAllChans *pCarrInfoAllChans,
        UINT32 *carrTotalNum)
{
    UINT32 chanLoop       = 0;
    UINT32 rfChnlNo       = 0;
    UINT32 rxChanNum      = 0;
    UINT32 retVal         = BSP_OK;
    UINT32 chipId         = 0;
    UINT32 carrNumPerChan = 0;
    UINT32 carrLoop       = 0;
    UINT32 carr           = 0;
    UINT32 carrNo         = 0;
    UINT32 bspChan        = 0;
    UINT32 halDifChan     = 0;
    T_BspHalAdaptChanInfo *rxDifChanInfo = NULL;

    INPUT_POINTER_CHECK(pCarrInfoAllChans);
    INPUT_POINTER_CHECK(carrTotalNum);

    carr = *carrTotalNum;
    rxChanNum = pCarrInfoAllChans->rxChanNum;

    freqCfgExLog(FREQCFG_ANALYSE, "[%s] enter, rxChanNum is %d\n",__FUNCTION__,rxChanNum);
    rxDifChanInfo = (T_BspHalAdaptChanInfo *)malloc(sizeof(T_BspHalAdaptChanInfo));
    if (rxDifChanInfo == NULL)
    {
        return BSP_ERROR;
    }
    memset(rxDifChanInfo, 0, sizeof(T_BspHalAdaptChanInfo));
    rxDifChanInfo->chanNum = pCarrInfoAllChans->rxChanNum;

    for (chanLoop = 0; chanLoop < rxChanNum; chanLoop++)
    {
        rfChnlNo = pCarrInfoAllChans->rxCarrInfo[chanLoop].chanNo;

        retVal |= BspGetBspChnByRfChn(rfChnlNo, RX, &bspChan);
        if (BSP_OK != retVal)
        {
            free(rxDifChanInfo);
            BspLog(LOG_LEVEL_0,"[%s] chanLoop[%d] Get BspChan[%d] by RfChnl[%d] Error!\n" ,__FUNCTION__, chanLoop, bspChan, rfChnlNo);
            return retVal;
        }

        retVal |= BspGetDifInfoByBspChn(bspChan, RX, &chipId, &halDifChan);
        if (BSP_OK != retVal)
        {
            free(rxDifChanInfo);
            BspLog(LOG_LEVEL_0,"[%s] chanLoop[%d] bspChan[%d] Get difChan[%d] Error!\n",__FUNCTION__, chanLoop, bspChan, halDifChan);
            return retVal;
        }
        rxDifChanInfo->chanInfo[chanLoop].difChanNo = halDifChan;

        carrNumPerChan = pCarrInfoAllChans->rxCarrInfo[chanLoop].carrNum;
        if (carrNumPerChan > NELEMENTS(pCarrInfoAllChans->rxCarrInfo[chanLoop].carrInfo))
        {
            free(rxDifChanInfo);
            BspLog(LOG_LEVEL_0,"[%s] chanLoop[%d] carrNum[%d] out of range!\n", __FUNCTION__, chanLoop, carrNumPerChan);
            return retVal;
        }

        BspLog(LOG_LEVEL_0, "freq: [%s] chanLoop[%2d] RxChnl[%2d]: CarrNumPerChnl= %d\n",
                  __FUNCTION__, chanLoop, rfChnlNo, carrNumPerChan);

        rxDifChanInfo->chanInfo[chanLoop].carrNum = carrNumPerChan;

        for (carrLoop = 0 ;carrLoop < carrNumPerChan; carrLoop++)
        {
            carrNo = pCarrInfoAllChans->rxCarrInfo[chanLoop].carrInfo[carrLoop].carrNo;

            rxDifChanInfo->chanInfo[chanLoop].oneCarrInfo[carrLoop].difCarrNo = carrNo;
            rxDifChanInfo->chanInfo[chanLoop].oneCarrInfo[carrLoop].carrFreq  =
                    pCarrInfoAllChans->rxCarrInfo[chanLoop].carrInfo[carrLoop].freq;
            rxDifChanInfo->chanInfo[chanLoop].oneCarrInfo[carrLoop].carrBw  =
                    pCarrInfoAllChans->rxCarrInfo[chanLoop].carrInfo[carrLoop].bandWidth;
            rxDifChanInfo->chanInfo[chanLoop].oneCarrInfo[carrLoop].carrRadio =
                    pCarrInfoAllChans->rxCarrInfo[chanLoop].carrInfo[carrLoop].radioMode;
            rxDifChanInfo->chanInfo[chanLoop].oneCarrInfo[carrLoop].delOrAddFlag =
                    pCarrInfoAllChans->rxCarrInfo[chanLoop].carrInfo[carrLoop].delOrAddFlag;
            rxDifChanInfo->chanInfo[chanLoop].oneCarrInfo[carrLoop].isRcf = 1;
            /* Started by AICoder, pid:o544bf8cfcy5e031423a0b83709e371754f14387 */
            if(TRUE == BspIsRxTdRcfSwitchBypass(!!(rxDifChanInfo->chanInfo[chanLoop].oneCarrInfo[carrLoop].carrRadio - BSP_RADIO_STANDARD_LTE_FDD)))
            {
                rxDifChanInfo->chanInfo[chanLoop].oneCarrInfo[carrLoop].isRcf = 0;                
            }
            /* Ended by AICoder, pid:o544bf8cfcy5e031423a0b83709e371754f14387 */
            rxDifChanInfo->chanInfo[chanLoop].oneCarrInfo[carrLoop].isSsb = 0;

            BspLog(LOG_LEVEL_0, "Freq: [%s] Loop[%2d-%2d] carrNo[%d] "
                    "carrFreq[%2d] carrBw[%8d] \\ carrRadio[%4d] delOrAddFlag[%d] isRcf[%d] isSsb[%d]\n",
                    __FUNCTION__, chanLoop, carrLoop, carrNo,
                    rxDifChanInfo->chanInfo[chanLoop].oneCarrInfo[carrLoop].carrFreq,
                    rxDifChanInfo->chanInfo[chanLoop].oneCarrInfo[carrLoop].carrBw,
                    rxDifChanInfo->chanInfo[chanLoop].oneCarrInfo[carrLoop].carrRadio,
                    rxDifChanInfo->chanInfo[chanLoop].oneCarrInfo[carrLoop].delOrAddFlag,
                    rxDifChanInfo->chanInfo[chanLoop].oneCarrInfo[carrLoop].isRcf,
                    rxDifChanInfo->chanInfo[chanLoop].oneCarrInfo[carrLoop].isSsb);
        }

        carr+=carrNumPerChan;
    }
    *carrTotalNum = carr;

    retVal = BspHalAdaptRxAnalysisDdc0(rxDifChanInfo);
    if (BSP_OK != retVal)
    {
        free(rxDifChanInfo);
        BspLog(LOG_LEVEL_0,"[%s]AllCarrNum[%d] rx resource alloc Error!\n" ,__FUNCTION__, carr);
        return retVal;
    }
    free(rxDifChanInfo);
    freqCfgExLog(FREQCFG_ANALYSE, "[%s] exit\n",__FUNCTION__);
    return retVal;
}

/**********************************************************************
* 函数名称: BspAnalyseRxFreqDdc0Rpt
* 功能描述: 配频模块上行0级DDC资源预分析
* 输入参数: pCarrInfoAllChans 上下行所有通道通道载波信息
* 输出参数: 无
* 返  回  值: BSP_OK/BSP_ERROR
************************************************************************/
UINT32 BspAnalyseRxFreqDdc0Rpt(T_DestCarrInfoAllChans *pCarrInfoAllChans,
        UINT32 *carrTotalNum, T_PreAnalyseCarrResult *ptPreAnalyseResult, UINT32 flag)
{
    UINT32 chanLoop       = 0;
    UINT32 rfChnlNo       = 0;
    UINT32 rxChanNum      = 0;
    UINT32 retVal         = BSP_OK;
    UINT32 chipId         = 0;
    UINT32 carrNumPerChan = 0;
    UINT32 carrLoop       = 0;
    UINT32 carrAllNum     = 0;
    UINT32 carrNo         = 0;
    UINT32 bspChan        = 0;
    UINT32 halDifChan     = 0;
    T_BspHalAdaptChanInfo *rxDifChanInfo = NULL;
    T_BspHalAdaptChanInfo *pFailtxDifChanInfo = NULL;

    INPUT_POINTER_CHECK(pCarrInfoAllChans);
    INPUT_POINTER_CHECK(ptPreAnalyseResult);
    INPUT_POINTER_CHECK(carrTotalNum);

    rxDifChanInfo = (T_BspHalAdaptChanInfo *)malloc(sizeof(T_BspHalAdaptChanInfo));
    if (rxDifChanInfo == NULL)
    {
        return BSP_ERROR;
    }
    memset_s(rxDifChanInfo, sizeof(T_BspHalAdaptChanInfo), 0, sizeof(T_BspHalAdaptChanInfo));

    pFailtxDifChanInfo = (T_BspHalAdaptChanInfo *)malloc(sizeof(T_BspHalAdaptChanInfo));
    if (pFailtxDifChanInfo == NULL)
    {
        free(rxDifChanInfo);
        return BSP_ERROR;
    }
    memset_s(pFailtxDifChanInfo, sizeof(T_BspHalAdaptChanInfo), 0, sizeof(T_BspHalAdaptChanInfo));

    rxChanNum = pCarrInfoAllChans->rxChanNum;
    dbgInfoEx("[%s] enter, rxChanNum is %d\n", __FUNCTION__, rxChanNum);
    if ((rxChanNum > NELEMENTS(pCarrInfoAllChans->rxCarrInfo)) || (rxChanNum > NELEMENTS(rxDifChanInfo->chanInfo)))
    {
        free(rxDifChanInfo);
        free(pFailtxDifChanInfo);
        BspLog(LOG_LEVEL_0,"[%s] rxChanNum[%d] out of range!\n", __FUNCTION__, rxChanNum);
        return BSP_ERROR;
    }
    rxDifChanInfo->chanNum = rxChanNum;

    for (chanLoop = 0; chanLoop < rxChanNum; chanLoop++)
    {
        rfChnlNo = pCarrInfoAllChans->rxCarrInfo[chanLoop].chanNo;

        retVal |= BspGetBspChnByRfChn(rfChnlNo, RX, &bspChan);
        if (BSP_OK != retVal)
        {
            free(rxDifChanInfo);
            free(pFailtxDifChanInfo);
            BspLog(LOG_LEVEL_0,"[%s] chanLoop[%d] Get BspChan[%d] by RfChnl[%d] Error!\n" ,__FUNCTION__, chanLoop, bspChan, rfChnlNo);
            return retVal;
        }

        retVal |= BspGetDifInfoByBspChn(bspChan, RX, &chipId, &halDifChan);
        if (BSP_OK != retVal)
        {
            free(rxDifChanInfo);
            free(pFailtxDifChanInfo);
            BspLog(LOG_LEVEL_0,"[%s] chanLoop[%d] bspChan[%d] Get difChan[%d] Error!\n",__FUNCTION__, chanLoop, bspChan, halDifChan);
            return retVal;
        }
        rxDifChanInfo->chanInfo[chanLoop].difChanNo = halDifChan;

        carrNumPerChan = pCarrInfoAllChans->rxCarrInfo[chanLoop].carrNum;
        if (carrNumPerChan > NELEMENTS(pCarrInfoAllChans->rxCarrInfo[chanLoop].carrInfo))
        {
            free(rxDifChanInfo);
            free(pFailtxDifChanInfo);
            BspLog(LOG_LEVEL_0,"[%s] chanLoop[%d] carrNum[%d] out of range!\n", __FUNCTION__, chanLoop, carrNumPerChan);
            return BSP_ERROR;
        }

        BspLog(LOG_LEVEL_0, "freq: [%s] chanLoop[%2d] RxChnl[%2d]: CarrNumPerChnl= %d\n",
                  __FUNCTION__, chanLoop, rfChnlNo, carrNumPerChan);

        rxDifChanInfo->chanInfo[chanLoop].carrNum = carrNumPerChan;

        for (carrLoop = 0 ;carrLoop < carrNumPerChan; carrLoop++)
        {
            carrNo = pCarrInfoAllChans->rxCarrInfo[chanLoop].carrInfo[carrLoop].carrNo;

            rxDifChanInfo->chanInfo[chanLoop].oneCarrInfo[carrLoop].difCarrNo = carrNo;
            rxDifChanInfo->chanInfo[chanLoop].oneCarrInfo[carrLoop].carrFreq  =
                    pCarrInfoAllChans->rxCarrInfo[chanLoop].carrInfo[carrLoop].freq;
            rxDifChanInfo->chanInfo[chanLoop].oneCarrInfo[carrLoop].carrBw  =
                    pCarrInfoAllChans->rxCarrInfo[chanLoop].carrInfo[carrLoop].bandWidth;
            rxDifChanInfo->chanInfo[chanLoop].oneCarrInfo[carrLoop].carrRadio =
                    pCarrInfoAllChans->rxCarrInfo[chanLoop].carrInfo[carrLoop].radioMode;
            rxDifChanInfo->chanInfo[chanLoop].oneCarrInfo[carrLoop].delOrAddFlag =
                    pCarrInfoAllChans->rxCarrInfo[chanLoop].carrInfo[carrLoop].delOrAddFlag;
            rxDifChanInfo->chanInfo[chanLoop].oneCarrInfo[carrLoop].isRcf = 1;
            /* Started by AICoder, pid:8a81esba30q57071410a0886508e311202213760 */
            if(TRUE == BspIsRxTdRcfSwitchBypass(!!(rxDifChanInfo->chanInfo[chanLoop].oneCarrInfo[carrLoop].carrRadio - BSP_RADIO_STANDARD_LTE_FDD)))
            {
                rxDifChanInfo->chanInfo[chanLoop].oneCarrInfo[carrLoop].isRcf = 0;
            }
            /* Ended by AICoder, pid:8a81esba30q57071410a0886508e311202213760 */
            rxDifChanInfo->chanInfo[chanLoop].oneCarrInfo[carrLoop].isSsb = 0;

            rxDifChanInfo->chanInfo[chanLoop].oneCarrInfo[carrLoop].uiCellId =
                    pCarrInfoAllChans->rxCarrInfo[chanLoop].carrInfo[carrLoop].cellid;

            BspLog(LOG_LEVEL_0, "Freq: [%s] Loop[%2d-%2d] carrNo[%d] "
                    "carrFreq[%2d] carrBw[%8d] \\ carrRadio[%4d] delOrAddFlag[%d] isRcf[%d] isSsb[%d] cellId[%d]\n",
                    __FUNCTION__, chanLoop, carrLoop, carrNo,
                    rxDifChanInfo->chanInfo[chanLoop].oneCarrInfo[carrLoop].carrFreq,
                    rxDifChanInfo->chanInfo[chanLoop].oneCarrInfo[carrLoop].carrBw,
                    rxDifChanInfo->chanInfo[chanLoop].oneCarrInfo[carrLoop].carrRadio,
                    rxDifChanInfo->chanInfo[chanLoop].oneCarrInfo[carrLoop].delOrAddFlag,
                    rxDifChanInfo->chanInfo[chanLoop].oneCarrInfo[carrLoop].isRcf,
                    rxDifChanInfo->chanInfo[chanLoop].oneCarrInfo[carrLoop].isSsb,
					rxDifChanInfo->chanInfo[chanLoop].oneCarrInfo[carrLoop].uiCellId);
        }

        carrAllNum += carrNumPerChan;
    }
    *carrTotalNum = carrAllNum;

    retVal = BspHalAdaptRxAnalysisDdc0Rpt(rxDifChanInfo, pFailtxDifChanInfo, flag);
    if (BSP_OK != retVal)
    {
        free(rxDifChanInfo);
        free(pFailtxDifChanInfo);
        BspLog(LOG_LEVEL_0,"[%s]AllCarrNum[%d] rx resource alloc Error!\n" ,__FUNCTION__, carrAllNum);
        return retVal;
    }

    ptPreAnalyseResult->rxChanNum = pFailtxDifChanInfo->chanNum;

    for(chanLoop = 0; chanLoop < pFailtxDifChanInfo->chanNum; chanLoop++)
    {
        ptPreAnalyseResult->rxCarrInfo[chanLoop].chanNo = pFailtxDifChanInfo->chanInfo[chanLoop].difChanNo;
        ptPreAnalyseResult->rxCarrInfo[chanLoop].carrNum = pFailtxDifChanInfo->chanInfo[chanLoop].carrNum;

        BspLog(LOG_LEVEL_0, "overInfo: [%s] chanLoop[%d] / chanNum[%d], chanNo[%d], carrNum[%d] \n",__FUNCTION__, chanLoop,
                ptPreAnalyseResult->rxChanNum, ptPreAnalyseResult->rxCarrInfo[chanLoop].chanNo, ptPreAnalyseResult->rxCarrInfo[chanLoop].carrNum);

        for(carrLoop = 0; carrLoop < pFailtxDifChanInfo->chanInfo[chanLoop].carrNum; carrLoop++)
        {
            ptPreAnalyseResult->rxCarrInfo[chanLoop].carrInfo[carrLoop].carrNo = pFailtxDifChanInfo->chanInfo[chanLoop].oneCarrInfo[carrLoop].difCarrNo;
            ptPreAnalyseResult->rxCarrInfo[chanLoop].carrInfo[carrLoop].freq = pFailtxDifChanInfo->chanInfo[chanLoop].oneCarrInfo[carrLoop].carrFreq;
            ptPreAnalyseResult->rxCarrInfo[chanLoop].carrInfo[carrLoop].bandWidth = pFailtxDifChanInfo->chanInfo[chanLoop].oneCarrInfo[carrLoop].carrBw;
            ptPreAnalyseResult->rxCarrInfo[chanLoop].carrInfo[carrLoop].radioMode = pFailtxDifChanInfo->chanInfo[chanLoop].oneCarrInfo[carrLoop].carrRadio;
            ptPreAnalyseResult->rxCarrInfo[chanLoop].carrInfo[carrLoop].cellId = pFailtxDifChanInfo->chanInfo[chanLoop].oneCarrInfo[carrLoop].uiCellId;

            BspLog(LOG_LEVEL_0, "overInfo: [%s] Loop[%d-%d] carrNo[%d] carrFreq[%d] carrBw[%d] carrRadio[0x%x] cellId[%d]\n",
                    __FUNCTION__, chanLoop, carrLoop,
                    ptPreAnalyseResult->rxCarrInfo[chanLoop].carrInfo[carrLoop].carrNo,
                    ptPreAnalyseResult->rxCarrInfo[chanLoop].carrInfo[carrLoop].freq,
                    ptPreAnalyseResult->rxCarrInfo[chanLoop].carrInfo[carrLoop].bandWidth,
                    ptPreAnalyseResult->rxCarrInfo[chanLoop].carrInfo[carrLoop].radioMode,
                    ptPreAnalyseResult->rxCarrInfo[chanLoop].carrInfo[carrLoop].cellId);
        }
    }

    free(rxDifChanInfo);
    free(pFailtxDifChanInfo);
    dbgInfoEx("[%s] exit\n", __FUNCTION__);
    return retVal;
}

UINT32 BspSetDtxRouteEnByMode(UINT32 bspChan, UINT32 dir, T_RfChanCfgEn *rfChanCfgEn)
{
    UINT32 retVal = 0;
    UINT32 radio = 0;
    UINT32 carrIdx = 0;
    UINT32 carrNum = 0;
    UINT32 carrLoop = 0;

    INPUT_POINTER_CHECK(rfChanCfgEn);

    carrNum = rfChanCfgEn->carrNum;
    if((0 == carrNum) || (TX != dir))
    {
        return BSP_OK;
    }

    for(carrLoop = 0; carrLoop < carrNum; carrLoop++)
    {
        radio = rfChanCfgEn->carrInfo[carrLoop].carrRadio;
        carrIdx = rfChanCfgEn->carrInfo[carrLoop].carrId;
        if((BSP_RADIO_STANDARD_GSM == radio) || (BSP_RADIO_STANDARD_UMTS == radio))
        {
            continue;
        }

        if(NULL != s_pFuncSetDtxRoute)
        {
            retVal = s_pFuncSetDtxRoute(bspChan, radio, carrIdx, SWITCH_ON);
        }

        BspLog(LOG_LEVEL_0,"[%s] enter, bspChan=%d, carrIdx=%d, radio=%d, retVal = %d\n",__FUNCTION__, bspChan, carrIdx, radio, retVal);
    }

    return retVal;
}

/* 资源分配生效后更新单边滤波存储的真实生效的rcf带宽 */
UINT32 BspSaveRcfBwByResourceCfg(UINT32 dir, UINT32 difChan, T_RfChanCfgEn *pRfChanCfgEn)
{
    UINT32 retVal = BSP_OK;
    UINT32 carrNo = 0;
    UINT32 carrRadio = 0;
    UINT32 delOrAddFlag = 0;
    UINT32 carrNum = 0;
    UINT32 carrLoop = 0;
    UINT32 realRcfBw = 0;

    INPUT_POINTER_CHECK(pRfChanCfgEn);
    carrNum = pRfChanCfgEn->carrNum;

    for(carrLoop = 0; carrLoop < carrNum; carrLoop ++)
    {
        carrNo = pRfChanCfgEn->carrInfo[carrLoop].carrId;
        carrRadio = pRfChanCfgEn->carrInfo[carrLoop].carrRadio;
        delOrAddFlag = pRfChanCfgEn->carrInfo[carrLoop].delOrAddFlag;

        if((delOrAddFlag == BSP_CARR_FLAG_ADD) || (delOrAddFlag == BSP_CARR_FLAG_MODIFY))
        {
            retVal = BspHalAdaptGetRealBw(dir, difChan, carrNo, carrRadio, &realRcfBw);
            if(BSP_OK == retVal)
            {
                if(dir == TX)
                {
                    BspSetDlFilterRcfBw(difChan, carrNo, carrRadio, realRcfBw);
                }
                else
                {
                    BspSetUlFilterRcfBw(difChan, carrNo, carrRadio, realRcfBw);
                }
            }
        }
    }

    return retVal;
}

/**********************************************************************
* 函数名称: BspHalResourceAllocCfg
* 功能描述: 中频TX/RX资源配置生效的API接口
* 输入参数:无
* 输出参数: 无
* 返  回  值: BSP_OK / BSP_ERROR
************************************************************************/
UINT32 BspResourceAllocCfg(UINT32 dir, UINT32 rfChan, T_RfChanCfgEn *pRfChanCfgEn)
{
    UINT32 retVal      = BSP_OK;
    UINT32 carrNum     = 0;
    UINT32 carrLoop    = 0;
    UINT32 bspChan     = 0;
    UINT32 difChan     = 0;
    UINT32 chanLoop    = 0;
    UINT32 chipId      = 0;
    UINT32 carrDelMask = 0;
    UINT32 chnDelMask  = 0;
    INT32  dlPreDgain  = 0;
    T_DifCarrInfoCfg ptFailCarrCfgInfo = {0};

    carrNum = pRfChanCfgEn->carrNum;
    retVal = BspGetBspChnByRfChn(rfChan, dir, &bspChan);
    BspLog(LOG_LEVEL_0,"line:%d, %s enter,rfChan=%d,bspChan=%d,retVal=%d\n", __LINE__,__FUNCTION__,rfChan,bspChan,retVal);
    if (BSP_OK != retVal)
    {
        BspLog(LOG_LEVEL_0,"[%s] chanLoop[%d] Get BspChan[%d] by RfChnl[%d] Error!\n" ,
               __FUNCTION__, chanLoop, bspChan, rfChan);
        return retVal;
    }

    retVal = BspGetDifInfoByBspChn(bspChan, dir, &chipId, &difChan);
    BspLog(LOG_LEVEL_0,"line:%d, %s enter,bspChan=%d,chipId=%d,retVal=%d\n", __LINE__,__FUNCTION__,bspChan,chipId,retVal);
    if (BSP_OK != retVal)
    {
        BspLog(LOG_LEVEL_0,"[%s] chanLoop[%d] bspChan[%d] Get difChan[%d] Error!\n",
                __FUNCTION__, chanLoop, bspChan, difChan);
        return retVal;
    }

    freqCfgExLog(FREQCFG_ANALYSE, "[%s] carrNum:%u\n", __FUNCTION__, carrNum);
    for(carrLoop = 0; carrLoop < carrNum; carrLoop ++)
    {
        carrDelMask = 1;
        if( 2 == pRfChanCfgEn->carrInfo[carrLoop].delOrAddFlag)
        {
            carrDelMask = 0;
        }
        chnDelMask |= carrDelMask;
        BspHalAdaptGetDlpreGain(difChan, pRfChanCfgEn->carrInfo[carrLoop].carrId, pRfChanCfgEn->carrInfo[carrLoop].carrRadio, &dlPreDgain);

        BspLog(LOG_LEVEL_0, "[%s] dir:%d, rfchan:%d, difChan:%d, carrNum:%d, DelOrAddFlag:%d, carrId:%d, carrRadio:%d,dlPreDgain:%d \n",
                __FUNCTION__, dir,rfChan,difChan,pRfChanCfgEn->carrNum,pRfChanCfgEn->carrInfo[carrLoop].delOrAddFlag,
                pRfChanCfgEn->carrInfo[carrLoop].carrId,pRfChanCfgEn->carrInfo[carrLoop].carrRadio,dlPreDgain);
    }

    /* 分配中频资源前，先打开中频未使用资源静态门控 */
    (VOID)BspHalAdaptDifUnuseResGateCtrl(dir, SWITCH_ON);

    retVal = BspHalAdaptResourceAllocCfg(dir, difChan, pRfChanCfgEn, &ptFailCarrCfgInfo);
    for(carrLoop = 0; carrLoop < carrNum; carrLoop ++)
    {
        BspHalAdaptGetDlpreGain(difChan, pRfChanCfgEn->carrInfo[carrLoop].carrId, pRfChanCfgEn->carrInfo[carrLoop].carrRadio, &dlPreDgain);
        BspLog(LOG_LEVEL_0, "[%s] line:%d, difChan:%d, carrId:%d, carrRadio:%d,dlPreDgain:%d \n",
                __FUNCTION__, __LINE__,difChan,pRfChanCfgEn->carrInfo[carrLoop].carrId,pRfChanCfgEn->carrInfo[carrLoop].carrRadio,dlPreDgain);
    }
    if(retVal != BSP_OK)
    {
        BspLog(LOG_LEVEL_0,"[%s] Error: [TX/RX= %d] chan%u resouece alloc cfg fail! TX:1,RX:0\n" ,__FUNCTION__,dir, rfChan);
    }

    /* 分配中频资源后，关闭中频未使用资源静态门控 */
    (VOID)BspHalAdaptDifUnuseResGateCtrl(dir, SWITCH_OFF);

    #ifndef FUNCLIB_ADS

    if((0 != carrNum) && (chnDelMask))
    {
        retVal |= BspHalAdaptSetFrSelectByDir(difChan, dir);
        dbgInfoEx("%s: CarrNum = %d, ChnDelMask = %d \n",__FUNCTION__, carrNum, chnDelMask);
    }
    
    BspLog(LOG_LEVEL_0,"line:%d, %s enter,difChan=%d,retVal=%d\n", __LINE__,__FUNCTION__,difChan,retVal);
    #endif

    BspSetDtxRouteEnByMode(bspChan, dir, pRfChanCfgEn);
    BspSaveRcfBwByResourceCfg(dir, difChan, pRfChanCfgEn); /*更新单边滤波存储的真实生效 rcf 带宽*/

    return retVal;
}

UINT32 BspResourceAllocCfgNew(UINT32 dir, UINT32 rfChan, T_RfChanCfgEn *pRfChanCfgEn, T_ResAllocFailCarrInfoChan *ptResAllocFailCarrInfoChan)
{
    UINT32 retVal      = BSP_OK;
    UINT32 carrNum     = 0;
    UINT32 carrLoop    = 0;
    UINT32 bspChan     = 0;
    UINT32 difChan     = 0;
    UINT32 chanLoop    = 0;
    UINT32 chipId      = 0;
    UINT32 carrDelMask = 0;
    UINT32 chnDelMask  = 0;
    INT32  dlPreDgain  = 0;
    T_DifCarrInfoCfg ptFailCarrCfgInfo = {0};

    INPUT_POINTER_CHECK(pRfChanCfgEn);
    INPUT_POINTER_CHECK(ptResAllocFailCarrInfoChan);

    carrNum = pRfChanCfgEn->carrNum;
    retVal = BspGetBspChnByRfChn(rfChan, dir, &bspChan);
    BspLog(LOG_LEVEL_0,"line:%d, %s enter,rfChan=%d,bspChan=%d,retVal=%d\n", __LINE__,__FUNCTION__,rfChan,bspChan,retVal);
    if (BSP_OK != retVal)
    {
        BspLog(LOG_LEVEL_0,"[%s] chanLoop[%d] Get BspChan[%d] by RfChnl[%d] Error!\n" ,
               __FUNCTION__, chanLoop, bspChan, rfChan);
        return retVal;
    }

    retVal = BspGetDifInfoByBspChn(bspChan, dir, &chipId, &difChan);
    BspLog(LOG_LEVEL_0,"line:%d, %s enter,bspChan=%d,chipId=%d,retVal=%d\n", __LINE__,__FUNCTION__,bspChan,chipId,retVal);
    if (BSP_OK != retVal)
    {
        BspLog(LOG_LEVEL_0,"[%s] chanLoop[%d] bspChan[%d] Get difChan[%d] Error!\n",
                __FUNCTION__, chanLoop, bspChan, difChan);
        return retVal;
    }

    freqCfgExLog(FREQCFG_ANALYSE, "[%s] carrNum:%u\n", __FUNCTION__, carrNum);
    for(carrLoop = 0; carrLoop < carrNum; carrLoop ++)
    {
        carrDelMask = 1;
        if( 2 == pRfChanCfgEn->carrInfo[carrLoop].delOrAddFlag)
        {
            carrDelMask = 0;
        }
        chnDelMask |= carrDelMask;
        BspHalAdaptGetDlpreGain(difChan, pRfChanCfgEn->carrInfo[carrLoop].carrId, pRfChanCfgEn->carrInfo[carrLoop].carrRadio, &dlPreDgain);

        BspLog(LOG_LEVEL_0, "[%s] dir:%d, rfchan:%d, difChan:%d, carrNum:%d, DelOrAddFlag:%d, carrId:%d, carrRadio:%d,dlPreDgain:%d \n",
                __FUNCTION__, dir,rfChan,difChan,pRfChanCfgEn->carrNum,pRfChanCfgEn->carrInfo[carrLoop].delOrAddFlag,
                pRfChanCfgEn->carrInfo[carrLoop].carrId,pRfChanCfgEn->carrInfo[carrLoop].carrRadio,dlPreDgain);
    }

    /* 分配中频资源前，先打开中频未使用资源静态门控 */
    (VOID)BspHalAdaptDifUnuseResGateCtrl(dir, SWITCH_ON);

    retVal = BspHalAdaptResourceAllocCfg(dir, difChan, pRfChanCfgEn, &ptFailCarrCfgInfo);

    if(0 != ptFailCarrCfgInfo.uiCarrNum)
    {
        ptResAllocFailCarrInfoChan->carrNum = ptFailCarrCfgInfo.uiCarrNum;
        for (carrLoop = 0; carrLoop < ptFailCarrCfgInfo.uiCarrNum; carrLoop++)
        {
            ptResAllocFailCarrInfoChan->carrInfo[carrLoop].carrNo = ptFailCarrCfgInfo.atCarrInfo[carrLoop].uiCarrId;
            ptResAllocFailCarrInfoChan->carrInfo[carrLoop].radioMode = ptFailCarrCfgInfo.atCarrInfo[carrLoop].uiCarrRadio;
            ptResAllocFailCarrInfoChan->carrInfo[carrLoop].errorCode = ptFailCarrCfgInfo.atCarrInfo[carrLoop].uiErrorCode;
            BspLog(0,"[%s] failedCarrNum = %d, carrNo = %d, radioMode = %d, errorCode = %d\n",__FUNCTION__, ptResAllocFailCarrInfoChan->carrNum,
                    ptResAllocFailCarrInfoChan->carrInfo[carrLoop].carrNo,
                    ptResAllocFailCarrInfoChan->carrInfo[carrLoop].radioMode,
                    ptResAllocFailCarrInfoChan->carrInfo[carrLoop].errorCode);
        }
    }

    for(carrLoop = 0; carrLoop < carrNum; carrLoop ++)
    {
        BspHalAdaptGetDlpreGain(difChan, pRfChanCfgEn->carrInfo[carrLoop].carrId, pRfChanCfgEn->carrInfo[carrLoop].carrRadio, &dlPreDgain);
        BspLog(LOG_LEVEL_0, "[%s] line:%d, difChan:%d, carrId:%d, carrRadio:%d,dlPreDgain:%d \n",
                __FUNCTION__, __LINE__,difChan,pRfChanCfgEn->carrInfo[carrLoop].carrId,pRfChanCfgEn->carrInfo[carrLoop].carrRadio,dlPreDgain);
    }
    if(retVal != BSP_OK)
    {
        BspLog(LOG_LEVEL_0,"[%s] Error: [TX/RX= %d] chan%u resouece alloc cfg fail! TX:1,RX:0\n" ,__FUNCTION__,dir, rfChan);
    }

    /* 分配中频资源后，关闭中频未使用资源静态门控 */
    (VOID)BspHalAdaptDifUnuseResGateCtrl(dir, SWITCH_OFF);

    #ifndef FUNCLIB_ADS

    if((0 != carrNum) && (chnDelMask))
    {
        retVal |= BspHalAdaptSetFrSelectByDir(difChan, dir);
        dbgInfoEx("%s: CarrNum = %d, ChnDelMask = %d \n",__FUNCTION__, carrNum, chnDelMask);
    }

    #endif
    BspLog(LOG_LEVEL_0,"line:%d, %s exit,difChan=%d,retVal=%d\n", __LINE__,__FUNCTION__,difChan,retVal);

    BspSetDtxRouteEnByMode(bspChan, dir, pRfChanCfgEn);
    BspSaveRcfBwByResourceCfg(dir, difChan, pRfChanCfgEn); /*更新单边滤波存储的真实生效 rcf 带宽*/

    return retVal;
}

/**********************************************************************
* 函数名称: BspHalResourceAllocClr
* 功能描述: 中频TX/RX资源分配清零的API接口
* 输入参数:无
* 输出参数: 无
* 返  回  值: BSP_OK / BSP_ERROR
************************************************************************/
UINT32 BspResourceAllocClr(UINT32 dir)
{
    UINT32 retVal = BSP_OK;

    /* 分配中频资源前，先打开中频未使用资源静态门控 */
    //(VOID)BspHalAdaptDifUnuseResGateCtrl(dir, SWITCH_ON);

    retVal = BspHalAdaptResourceAllocClr(dir);
    if(retVal != BSP_OK)
    {
        BspLog(LOG_LEVEL_0,"[%s] Error: [TX/RX= %d] resouece alloc clr fail! TX:1,RX:0\n" ,__FUNCTION__,dir);
    }

    /* 分配中频资源后，关闭中频未使用资源静态门控 */
    //(VOID)BspHalAdaptDifUnuseResGateCtrl(dir, SWITCH_OFF);

    return retVal;
}
UINT32 BspSetTsgTdmInfo(T_Tsg_TdmInfo *ptTdmInfo)
{
     return BspHalAdaptSetTsgTdmInfo((T_TsgTdmInfo*)ptTdmInfo);
}
VOID testTsgTdmInfo(UINT32 sample, UINT32 tsgflag)
{
	T_Tsg_TdmInfo tdmInfo = {0};
	tdmInfo.uiSampleRate = sample;
	tdmInfo.uiTsgFlag = tsgflag;
	BspSetTsgTdmInfo(&tdmInfo);
}
/*使用原有接口BspSetTsgSwitch 是否会影响正式功能  待确认，临时先定义为此名*/
UINT32 BspSetTsgSwitch(UINT32 bspChan,UINT32 carr,UINT32 carrRadio,UINT32 isOn)
{
    UINT32 ret = BSP_OK;
    UINT32 chipId = 0;
    UINT32 difChan = 0;
    UINT32 retVal = 0;
    T_FpgaInfoInit *pFpgaInfo = BspGetFpgaInfo();
    retVal = BspGetDifInfoByBspChn(bspChan, TX, &chipId, &difChan);
    if (BSP_OK != retVal)
    {
        BspLog(LOG_LEVEL_0,"[%s]bspChan'%d BspGetDifInfoByBspChn Get Error!\n", __FUNCTION__, bspChan);
        return BSP_ERROR;
    }

    /* fpga链路，d42链路无需关注此处 */
    if (NULL != pFpgaInfo && BSP_RADIO_STANDARD_AIOT == carrRadio)
    {
        INPUT_BSPCHN_CHECK(bspChan);
        if (FPGA_CHAN == pFpgaInfo->txFpgaChanFlag[bspChan] && NULL != pFpgaInfo->pFuncSetFpgaTsgSwitch)
        {
            return pFpgaInfo->pFuncSetFpgaTsgSwitch(difChan, carr, carrRadio, isOn);
        }
    }

    ret = BspHalAdaptDifTsgSwitch( difChan,  carr,  carrRadio, isOn);
    return ret;
}

/*IC 4.2硬件自检TSG源接口*/
UINT32 BspSetNtfTsgSwitch(UINT32 bspChan,UINT32 carr,UINT32 carrRadio,UINT32 isOn)
{
    UINT32 ret = BSP_OK;
    UINT32 chipId = 0;
    UINT32 difChan = 0;
    UINT32 retVal = 0;
    retVal = BspGetDifInfoByBspChn(bspChan, TX, &chipId, &difChan);
    if (BSP_OK != retVal)
    {
        BspLog(LOG_LEVEL_0,"[%s]bspChan'%d BspGetDifInfoByBspChn Get Error!\n", __FUNCTION__, bspChan);
        return BSP_ERROR;
    }
    ret = BspHalAdaptDifDlPreTsgSwitch( difChan,  carr,  carrRadio, isOn);
    return ret;
}

UINT32 BspSetDifTsgSwitch(UINT32 bspChan,UINT32 carrNo,UINT32 carrRadio,UINT32 type, UINT32 isOn)
{
    UINT32 chipId = 0;
    UINT32 difChan = 0;
    UINT32 retVal = BSP_OK;

    retVal = BspGetDifInfoByBspChn(bspChan, TX, &chipId, &difChan);
    if (BSP_OK != retVal)
    {
        dbgErr("[%s]bspChan'%d BspGetDifInfoByBspChn Get Error!\n", __FUNCTION__, bspChan);
        return BSP_ERROR;
    }

    if(1 == type)
    {
        retVal = BspHalAdaptDifCfrTsgSwitch(difChan, isOn);  /*cfr处单音*/
    }
    else
    {
        retVal = BspHalAdaptDifDlPreTsgSwitch(difChan, carrNo, carrRadio, isOn); /*宽谱*/
    }
    dbgInfo("[%s] bspChan'%d carrNo %d carrRadio %d type %d isOn %d\n", __FUNCTION__, bspChan, carrNo, carrRadio, type, isOn);
    BspLog(LOG_LEVEL_0,"[%s] bspChan'%d carrNo %d carrRadio %d type %d isOn %d\n", __FUNCTION__, bspChan, carrNo,
    carrRadio, type, isOn);

    return retVal;
}
/**********************************************************************
* 函数名称: BspTxResourceAllocRpt
* 功能描述: 中频TX/RX上报资源改动的API接口
* 输入参数:无
* 输出参数: 无
* 返  回  值: BSP_OK / BSP_ERROR
************************************************************************/
static UINT32 BspTxResourceAllocRpt(T_DestCarrInfoAllChans *pCarrInfoAllChans)
{
    UINT32 rfChnlNo       = 0;
    UINT32 txChanNum      = BspGetTxChanNum();
    UINT32 retVal         = BSP_OK;
    UINT32 chipId         = 0;
    UINT32 carrNumPerChan = 0;
    UINT32 carrLoop       = 0;
    UINT32 carrNo         = 0;
    UINT32 bspChan        = 0;
    UINT32 halDifChan     = 0;
    T_BspHalAdaptChanInfo *txDifChanInfo = NULL;

    INPUT_POINTER_CHECK(pCarrInfoAllChans);

    txDifChanInfo = (T_BspHalAdaptChanInfo *)malloc(sizeof(T_BspHalAdaptChanInfo));
    if (txDifChanInfo == NULL)
    {
        return BSP_ERROR;
    }
    zte_memset_s(txDifChanInfo, sizeof(T_BspHalAdaptChanInfo), 0, sizeof(T_BspHalAdaptChanInfo));
    BspHalAdaptResourceAllocRpt(TX, txDifChanInfo);

    for (bspChan = 0; bspChan < txChanNum; bspChan++)
    {
        retVal |= BspGetRfChnByBspChn(bspChan, TX, &rfChnlNo);
        if (BSP_OK != retVal)
        {
            free(txDifChanInfo);
            BspLog(LOG_LEVEL_0,"[%s]Get BspChan[%d] by RfChnl[%d] Error!\n" ,__FUNCTION__, bspChan, rfChnlNo);
            return retVal;
        }
        pCarrInfoAllChans->txCarrInfo[bspChan].chanNo = rfChnlNo;

        retVal |= BspGetDifInfoByBspChn(bspChan, TX, &chipId, &halDifChan);
        if (BSP_OK != retVal)
        {
            free(txDifChanInfo);
            BspLog(LOG_LEVEL_0,"[%s] bspChan[%d] Get difChan[%d] Error!\n",__FUNCTION__, bspChan, halDifChan);
            return retVal;
        }

        if(halDifChan >= BSP_IC4_DIF_CHAN_NUM)
        {
            free(txDifChanInfo);
            BspLog(LOG_LEVEL_0,"[%s] bspChan[%d] Get difChan[%d] Error!\n",__FUNCTION__, bspChan, halDifChan);
            return retVal;
        }
        carrNumPerChan = txDifChanInfo->chanInfo[halDifChan].carrNum;
        pCarrInfoAllChans->txCarrInfo[bspChan].carrNum = carrNumPerChan;

        if (carrNumPerChan > NELEMENTS(pCarrInfoAllChans->txCarrInfo[bspChan].carrInfo))
        {
            free(txDifChanInfo);
            BspLog(LOG_LEVEL_0,"[%s] bspChan[%d] carrNum[%d] out of range or is 0!\n", __FUNCTION__, bspChan, carrNumPerChan);
            return retVal;
        }
        freqCfgExLog(FREQCFG_ANALYSE, "[%s] bspChan[%2d] TxChnl[%2d] : CarrNumPerChnl= %d\n",
                  __FUNCTION__,bspChan, rfChnlNo , carrNumPerChan);

        for (carrLoop = 0; carrLoop < carrNumPerChan; carrLoop++)
        {
           carrNo = txDifChanInfo->chanInfo[halDifChan].oneCarrInfo[carrLoop].difCarrNo;
           pCarrInfoAllChans->txCarrInfo[bspChan].carrInfo[carrLoop].carrNo = carrNo;
           pCarrInfoAllChans->txCarrInfo[bspChan].carrInfo[carrLoop].freq =
                   txDifChanInfo->chanInfo[halDifChan].oneCarrInfo[carrLoop].carrFreq;
           pCarrInfoAllChans->txCarrInfo[bspChan].carrInfo[carrLoop].bandWidth =
                   txDifChanInfo->chanInfo[halDifChan].oneCarrInfo[carrLoop].carrBw;
           pCarrInfoAllChans->txCarrInfo[bspChan].carrInfo[carrLoop].radioMode =
                   txDifChanInfo->chanInfo[halDifChan].oneCarrInfo[carrLoop].carrRadio;
           /*预分析后上报的载波都是需要重新使能，所以增删标志全部置1(新增)*/
           pCarrInfoAllChans->txCarrInfo[bspChan].carrInfo[carrLoop].delOrAddFlag = 1;

            freqCfgExLog(FREQCFG_ANALYSE, "[%s] bspChan[%2d-%2d] carrNo[%2d] carrFreq[%2d] "
                    "carrBw[%8d] \\ carrRadio[%4d] delOrAddFlag[%d] \n",
                    __FUNCTION__, bspChan, carrLoop, carrNo,
                    pCarrInfoAllChans->txCarrInfo[bspChan].carrInfo[carrLoop].freq,
                    pCarrInfoAllChans->txCarrInfo[bspChan].carrInfo[carrLoop].bandWidth,
                    pCarrInfoAllChans->txCarrInfo[bspChan].carrInfo[carrLoop].radioMode,
                    pCarrInfoAllChans->txCarrInfo[bspChan].carrInfo[carrLoop].delOrAddFlag);
        }
    }
    free(txDifChanInfo);
    return retVal;
}

/**********************************************************************
* 函数名称: BspRxResourceAllocRpt
* 功能描述: 中频TX/RX上报资源改动的API接口
* 输入参数:无
* 输出参数: 无
* 返  回  值: BSP_OK / BSP_ERROR
************************************************************************/
static UINT32 BspRxResourceAllocRpt(T_DestCarrInfoAllChans *pCarrInfoAllChans)
{
    UINT32 rfChnlNo       = 0;
    UINT32 rxChanNum      = BspGetRxChanNum();
    UINT32 retVal         = BSP_OK;
    UINT32 chipId         = 0;
    UINT32 carrNumPerChan = 0;
    UINT32 carrLoop       = 0;
    UINT32 carrNo         = 0;
    UINT32 bspChan        = 0;
    UINT32 halDifChan     = 0;
    T_BspHalAdaptChanInfo *rxDifChanInfo = NULL;

    INPUT_POINTER_CHECK(pCarrInfoAllChans);

    rxDifChanInfo = (T_BspHalAdaptChanInfo *)malloc(sizeof(T_BspHalAdaptChanInfo));
    if (rxDifChanInfo == NULL)
    {
        return BSP_ERROR;
    }
    zte_memset_s(rxDifChanInfo, sizeof(T_BspHalAdaptChanInfo), 0, sizeof(T_BspHalAdaptChanInfo));
    BspHalAdaptResourceAllocRpt(RX, rxDifChanInfo);

    for (bspChan = 0; bspChan < rxChanNum; bspChan++)
    {
        retVal |= BspGetRfChnByBspChn(bspChan, RX, &rfChnlNo);
        if (BSP_OK != retVal)
        {
            free(rxDifChanInfo);
            BspLog(LOG_LEVEL_0,"[%s]Get BspChan[%d] by RfChnl[%d] Error!\n" ,__FUNCTION__, bspChan, rfChnlNo);
            return retVal;
        }
        pCarrInfoAllChans->rxCarrInfo[bspChan].chanNo = rfChnlNo;

        retVal |= BspGetDifInfoByBspChn(bspChan, RX, &chipId, &halDifChan);
        if (BSP_OK != retVal)
        {
            free(rxDifChanInfo);
            BspLog(LOG_LEVEL_0,"[%s] bspChan[%d] Get difChan[%d] Error!\n",__FUNCTION__, bspChan, halDifChan);
            return retVal;
        }

        if(halDifChan >= BSP_IC4_DIF_CHAN_NUM)
        {
            free(rxDifChanInfo);
            BspLog(LOG_LEVEL_0,"[%s] bspChan[%d] Get difChan[%d] Error!\n",__FUNCTION__, bspChan, halDifChan);
            return retVal;
        }
        carrNumPerChan = rxDifChanInfo->chanInfo[halDifChan].carrNum;
        pCarrInfoAllChans->rxCarrInfo[bspChan].carrNum = carrNumPerChan;

        if (carrNumPerChan > NELEMENTS(pCarrInfoAllChans->rxCarrInfo[bspChan].carrInfo))
        {
            free(rxDifChanInfo);
            BspLog(LOG_LEVEL_0,"[%s] bspChan[%d] carrNum[%d] out of range or is 0!\n", __FUNCTION__, bspChan, carrNumPerChan);
            return retVal;
        }
        freqCfgExLog(FREQCFG_ANALYSE, "[%s] bspChan[%2d] RxChnl[%2d] : CarrNumPerChnl= %d\n",
                  __FUNCTION__,bspChan, rfChnlNo , carrNumPerChan);

        for (carrLoop = 0; carrLoop < carrNumPerChan; carrLoop++)
        {
           carrNo = rxDifChanInfo->chanInfo[halDifChan].oneCarrInfo[carrLoop].difCarrNo;
           pCarrInfoAllChans->rxCarrInfo[bspChan].carrInfo[carrLoop].carrNo = carrNo;
           pCarrInfoAllChans->rxCarrInfo[bspChan].carrInfo[carrLoop].freq =
                   rxDifChanInfo->chanInfo[halDifChan].oneCarrInfo[carrLoop].carrFreq;
           pCarrInfoAllChans->rxCarrInfo[bspChan].carrInfo[carrLoop].bandWidth =
                   rxDifChanInfo->chanInfo[halDifChan].oneCarrInfo[carrLoop].carrBw;
           pCarrInfoAllChans->rxCarrInfo[bspChan].carrInfo[carrLoop].radioMode =
                   rxDifChanInfo->chanInfo[halDifChan].oneCarrInfo[carrLoop].carrRadio;
           /*预分析后上报的载波都是需要重新使能的，所以增删标志全部置1(新增)*/
           pCarrInfoAllChans->rxCarrInfo[bspChan].carrInfo[carrLoop].delOrAddFlag = 1;

            freqCfgExLog(FREQCFG_ANALYSE, "[%s] bspChan[%2d-%2d] carrNo[%2d] carrFreq[%2d] "
                    "carrBw[%8d] \\ carrRadio[%4d] delOrAddFlag[%d] \n",
                    __FUNCTION__, bspChan, carrLoop, carrNo,
                    pCarrInfoAllChans->rxCarrInfo[bspChan].carrInfo[carrLoop].freq,
                    pCarrInfoAllChans->rxCarrInfo[bspChan].carrInfo[carrLoop].bandWidth,
                    pCarrInfoAllChans->rxCarrInfo[bspChan].carrInfo[carrLoop].radioMode,
                    pCarrInfoAllChans->rxCarrInfo[bspChan].carrInfo[carrLoop].delOrAddFlag);
        }
    }
    free(rxDifChanInfo);
    return retVal;
}

UINT32 BspResourceAllocRpt(T_DestCarrInfoAllChans *pCarrInfoAllChans)
{
    UINT32 retVal = BSP_OK;

    retVal |= BspTxResourceAllocRpt(pCarrInfoAllChans);
    retVal |= BspRxResourceAllocRpt(pCarrInfoAllChans);

    return retVal;
}

/*根据返回值判断是否记录log，减少冗余，降低圈复杂度*/
INT32 BspJudgeRetureVal(UINT32 retVal, UINT32 loglevel, const CHAR *format, ...)
{
    CHAR logFormat[512];
    INT32 iRet = 0;

    if(BSP_OK != retVal)
    {
        va_list arg;
        va_start(arg, format);
        iRet = zte_vsnprintf_s(logFormat, sizeof(logFormat), format, arg);
        ZTE_SECURITY_FUNC_CHECK(iRet);
        BspLog(loglevel, logFormat);
        va_end(arg);
    }
    return iRet;
}

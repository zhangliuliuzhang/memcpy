/*****************************************************************************
* 版权所有(C) 2021, ZTE Corp. ZXSDR-RRU Platform BSP
*----------------------------------------------------------------------------
* 模 块 名 : 配频
* 文件名称 : freqcfg_analyse.h
* 文件标识 : {[N/A]}
* 内容摘要 : 本文件提供了配频接口函数声明
* 注意事项 : 无
* 作    者 : 李权明10279092
* 创建日期 : 2022-01-10
* 当前版本 : Ver1.0
*----------------------------------------------------------------------------*/

#ifndef _FUNCLIB_FREQCFG_IC4_2_ANALYSE_H_
#define _FUNCLIB_FREQCFG_IC4_2_ANALYSE_H_


#ifdef __cplusplus
extern "C" {
#endif

#include "freqcfgcommon.h"
#include "resource_alloc_api.h"

/* Started by AICoder, pid:d90c695e04j587514b3708e0e096171d27b4a206 */
/*整机不同制式不同带宽下的单边滤波能力*/
typedef struct tagT_RadioInfo
{
    UINT32 radio;          /* 载波制式 */
    UINT32 bwSum;          /* 该制式支持单边滤波的带宽数量(为0则该制式不区分带宽均支持单边滤波) */
    UINT32 bandWidth[10];  /* 载波带宽(kHz) */
} T_FilterRadioInfo;

typedef struct tagT_FilterInfo
{
    BOOL rruSupport;     /* 整机支持单边滤波能力 */
    UINT32 radioSum;     /* 支持单边滤波的制式数量 */
    T_FilterRadioInfo radioInfo[6]; /* 支持单边滤波的制式信息 */
}T_FilterAbilityInfo;
/* Ended by AICoder, pid:d90c695e04j587514b3708e0e096171d27b4a206 */


typedef UINT32 (*FUNC_CALLED_AFTER_PREANALYSE)(VOID);
typedef UINT32 (*FUNC_CALLED_BEFORE_PREANALYSE)(VOID);
typedef void (*FUNC_CHAN_POW_CALC_SWITCH)(UINT32 chan, UINT32 sw);
typedef UINT32 (*FUNC_SET_DTX_ROUTE)(UINT32 bspChan,UINT32 radioMod,UINT32 carrNo,UINT32 on);


UINT32 BspSetCallBackAfterPreAnalyse(FUNC_CALLED_AFTER_PREANALYSE pFunc);
UINT32 BspSetCallBackBeforePreAnalyse(FUNC_CALLED_BEFORE_PREANALYSE pFunc);
UINT32 BspSetCallBackChanPowCalcSw(FUNC_CHAN_POW_CALC_SWITCH pFunc);
UINT32 BspSetDtxRouteCallBack(FUNC_SET_DTX_ROUTE pFunc);
UINT32 BspResourceAllocClr(UINT32 dir);
UINT32 BspPreAnalyseCarrInfo(T_DestCarrInfoAllChans *pCarrInfoAllChans);
UINT32 BspPreAnalyseCarrInfoRpt(T_DestCarrInfoAllChans *pCarrInfoAllChans, T_PreAnalyseCarrResult  *ptPreAnalyseCarrResult, UINT32 flag);
UINT32 BspAnalyseRfcCfgFreqCarrInfo(T_DestCarrInfoAllChans *pCarrInfoAllChans);
UINT32 BspResourceAllocCfg(UINT32 dir, UINT32 rfChan, T_RfChanCfgEn *pRfChanCfgEn);
UINT32 BspResourceAllocRpt(T_DestCarrInfoAllChans *pCarrInfoAllChans);
UINT32 BspSetTsgSwitch(UINT32 bspChan,UINT32 carr,UINT32 carrRadio,UINT32 isOn);
UINT32 BspSetNtfTsgSwitch(UINT32 bspChan,UINT32 carr,UINT32 carrRadio,UINT32 isOn);
UINT32 BspAnalyseTxFreqDucoRpt(T_DestCarrInfoAllChans *pCarrInfoAllChans, UINT32 *carrTotalNum, T_PreAnalyseCarrResult  *ptPreAnalyseResult, UINT32 flag);
UINT32 BspAnalyseRxFreqDdc0Rpt(T_DestCarrInfoAllChans *pCarrInfoAllChans, UINT32 *carrTotalNum, T_PreAnalyseCarrResult *ptPreAnalyseResult, UINT32 flag);
UINT32 BspSetFilterAbilityInfo(UINT32 dir, T_FilterAbilityInfo *pFilterAbilityInfo);
T_FilterAbilityInfo *BspGetFilterAbilityInfo(VOID);
UINT32 BspGetSideFilterSw(UINT32 dir, UINT32 radioMode, UINT32 bandWidth, UINT32 *filterSw);
/* Started by AICoder, pid:za116we072od527141140af09007cc05636486b2 */
UINT32 BspAnalyseTxFreqCarrInfo(T_DestCarrInfoAllChans *pCarrInfoAllChans,UINT32 *carrTotalNum, T_DifChanInfo *ptTxFailChanInfo);
UINT32 BspAnalyseRxFreqCarrInfo(T_DestCarrInfoAllChans *pCarrInfoAllChans,UINT32 *carrTotalNum, T_DifChanInfo *ptRxFailChanInfo);
UINT32 BspAnalyseTxFreqDuco(T_DestCarrInfoAllChans *pCarrInfoAllChans,UINT32 *carrTotalNum);
UINT32 BspAnalyseRxFreqDdc0(T_DestCarrInfoAllChans *pCarrInfoAllChans,UINT32 *carrTotalNum);
UINT32 BspSaveRcfBwByResourceCfg(UINT32 dir, UINT32 difChan, T_RfChanCfgEn *pRfChanCfgEn);
/* Ended by AICoder, pid:za116we072od527141140af09007cc05636486b2 */
UINT32 BspResourceAllocCfgNew(UINT32 dir, UINT32 rfChan, T_RfChanCfgEn *pRfChanCfgEn, T_ResAllocFailCarrInfoChan *ptResAllocFailCarrInfoChan);
UINT32 BspAnalyseRfcCfgFreqCarrInfoNew(T_DestCarrInfoAllChans *pCarrInfoAllChans, T_AnalyseCarrResult *pAnalyseCarrRes);
INT32 BspJudgeRetureVal(UINT32 retVal, UINT32 loglevel, const CHAR *format, ...);
VOID BspSetRxTdRcfSwitchBypass(UINT32 radio, BOOL isSupport);
BOOL BspIsRxTdRcfSwitchBypass(UINT32 radio);
#ifdef __cplusplus
}
#endif

#endif

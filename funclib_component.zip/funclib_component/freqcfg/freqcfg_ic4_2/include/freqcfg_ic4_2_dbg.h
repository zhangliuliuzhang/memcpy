/*****************************************************************************
* 版权所有(C) 2021, ZTE Corp. ZXSDR-RRU Platform BSP
*----------------------------------------------------------------------------
* 模 块 名 : 配频
* 文件名称 : freqcfg_ic4.2.c
* 文件标识 : {[N/A]}
* 内容摘要 : 本文件提供了配频接口函数声明
* 注意事项 : 无
* 作    者 : 李权明10279092
* 创建日期 : 2022-01-05
* 当前版本 : Ver1.0
*----------------------------------------------------------------------------*/

#ifndef _FUNCLIB_FREQCFG_IC4_2_DBG_H_
#define _FUNCLIB_FREQCFG_IC4_2_DBG_H_


#ifdef __cplusplus
extern "C" {
#endif

#include "bsppub.h"
#include "bspcomm.h"
#include "freqcfgapi.h"
#include "freqcfgcommon.h"

#ifndef FREQCFG_DEBUG_MODE
#define FREQCFG_DEBUG_MODE
#endif

typedef struct tag_DbgCarrNcoInfo
{
    UINT32 difCarrNo;
    UINT32 carrFreq;
    INT32 carrNco;
    UINT32 carrBandNo;
}T_DbgCarrNcoInfo;

typedef struct tag_DbgChanNcoInfo
{
    UINT32 bspChan;
    UINT32 difChan;
    UINT32 centerFreq;
    UINT32 bandNum;
    UINT32 freqNco2Step[8];
    INT32 freqNco2[8];
    UINT32 bandFreq[8];
    UINT32 carrNum;
    T_DbgCarrNcoInfo carrNcoInfo[BSP_MAX_CARR_NUM];
}T_DbgChanNcoInfo;


UINT32 dbgSaveNcoBasicInfo(UINT32 dir, UINT32 bspChan, UINT32 difChan, UINT32 centerFreq, UINT32 bandNum, UINT32 carrNum);
UINT32 dbgSaveNcoBandInfo(UINT32 dir, UINT32 bspChan, UINT32 bandNo, UINT32 freqNco2Step, UINT32 bandFreq, INT32 freqNco2);
UINT32 dbgSaveNcoCarrInfo(UINT32 dir, UINT32 bspChan, UINT32 carr, UINT32 difCarrNo, UINT32 carrFreq, INT32 carrNco, UINT32 carrBandNo);
UINT32 showfilterAbility(UINT32 dir);

extern UINT32 freqcfgPrnFlag;
//分功能(预分析/配频)打印日志，可开关控制
#define freqCfgExLog(flag,fmt,...) if (freqcfgPrnFlag & flag) dbgInfo(fmt, ##__VA_ARGS__)

//打印开关
#define FREQCFG_ANALYSE (0x1)
#define FREQCFG_RFCFG (0x2)
#define FREQCFG_PLL (0x4)
#define FREQCFG_NCO (0x8)
#define FREQCFG_BANDNO (0xf0)

#ifdef __cplusplus

}
#endif
#endif

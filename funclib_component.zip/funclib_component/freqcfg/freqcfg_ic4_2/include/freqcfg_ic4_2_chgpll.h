/*****************************************************************************
* 版权所有(C) 2021, ZTE Corp. ZXSDR-RRU Platform BSP
*----------------------------------------------------------------------------
* 模 块 名 : 配频
* 文件名称 : freqcfg_ic4_2_chgpll.h
* 文件标识 : {[N/A]}
* 内容摘要 : 本文件提供了变本振相关函数声明
* 注意事项 : 无
*----------------------------------------------------------------------------*/

#ifndef _FUNCLIB_FREQCFG_IC4_2_CHGPLL_H_
#define _FUNCLIB_FREQCFG_IC4_2_CHGPLL_H_


#ifdef __cplusplus
extern "C" {
#endif

#include "freqcfgcommon.h"

/**************************************************************************
 *                        结构体
 **************************************************************************/
#define FREQ_DELTA_NR_720KHz  120*6
#define FREQ_DELTA_LTE_360KHz 120*3
#define FREQ_DELTA_1_120KHz   120

typedef struct tagT_ChanPllInfo
{
    UINT32 chanNo;
    UINT32 PllNo;
    UINT32 pllType;
}T_ChanPllInfo;

typedef struct T_BandWidthInfo {
    UINT32 index;        /* 编号 */
    UINT32 carrBw;       /* 载波带宽 kHz,对应吴晶方案 BW' */
    UINT32 rbNum;        /* 信号带宽 RB */
    UINT32 signalBw;     /* 信号带宽 kHz,对应吴晶方案 BW'' */
    UINT32 proCalcBw;    /* 计算保护带带宽 kHz, = signalBw + X. (X取720kHz). 对应吴晶方案 BW */
    UINT32 delta1Bw;
} T_BandWidthInfo;

typedef UINT32 (*FUNC_CalcCenterFreqDynamicFromBoard)(UINT32 trx, UINT32 chan, UINT32 carrNum,
        T_CarrInfo *allChanCfgInfo,UINT32 *rfpll);
UINT32 BspCalcCenterFreqDynamicFromBoardCall(FUNC_CalcCenterFreqDynamicFromBoard pFunc);
typedef UINT32 (*FUNC_FreqCfgDynamicAnalyseFromBoard)(UINT32 trx, UINT32 chan, UINT32 carrNum,
        T_CarrInfo *allChanCfgInfo,UINT32 *rfpll);
typedef VOID (*FUNC_FreqCfgLoFreqFromBoard)(UINT32 trx, UINT32 chan, UINT32 LoFreqKHz);
UINT32 BspFreqCfgDynamicAnalyseFromBoardCall(FUNC_FreqCfgDynamicAnalyseFromBoard pFunc);
UINT32 BspFreqCfgLoFreqFromBoardCall(FUNC_FreqCfgLoFreqFromBoard pFunc);
UINT32 BspSetMtsCaliFlags(UINT32 trsvId, UINT32 flags);
UINT32 BspGetMtsCaliFlags(UINT32 trsvId);
UINT32 BspSetChanPllInfo(T_ChanPllInfo *pInfo, UINT32 uiChanPllInfoNum);
UINT32 getChanMergePllNo(UINT32 chanNo, UINT32 trx);
UINT32 BspGetPllFreqChanged(UINT32 dir, UINT32 chan);
UINT32 BspSetLoStep(UINT32 loStep);
UINT32 UpdateCenterFreqDynamic(UINT32 trx, UINT32 chan, UINT32 carrNum);
UINT32 GetCarrEdgeFreqs(UINT32 carrNum, UINT32 dpdFreqRangeLow, UINT32 dpdFreqRangeHigh, UINT32 *edges, UINT32 chan);
UINT32 BspSetLoBlackoutAvoidFlag(UINT32 chan, UINT32 flag);
UINT32 BspGetLoBlackoutAvoidFlag(UINT32 chan);
UINT32 IsLoFreqRangeOk(UINT32 trx, UINT32 chan, UINT32 loFreq);
UINT32 BspSetChangeLoFreq(UINT32 trx, UINT32 chan, UINT32 loFreqKHz);
UINT32 BspSetChgPllByMainMgrFlag(UINT32 flag);
UINT32 IsCurrentLoFreqOk(UINT32 trx, UINT32 chan, UINT32 carrNum, UINT32 *freqOut);
#ifdef __cplusplus
}
#endif

#endif

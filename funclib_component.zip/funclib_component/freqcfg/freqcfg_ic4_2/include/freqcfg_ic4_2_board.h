/*****************************************************************************
* 版权所有(C) 2021, ZTE Corp. ZXSDR-RRU Platform BSP
*----------------------------------------------------------------------------
* 模 块 名 : 配频
* 文件名称 : freqcfg_ic4_2.h
* 文件标识 : {[N/A]}
* 内容摘要 : 本文件提供了配频接口函数声明
* 注意事项 : 无
* 作    者 : 李权明10279092
* 创建日期 : 2021-11-26
* 当前版本 : Ver1.0
*----------------------------------------------------------------------------*/

#ifndef _FUNCLIB_FREQCFG_IC4_2_BOARD_H_
#define _FUNCLIB_FREQCFG_IC4_2_BOARD_H_


#ifdef __cplusplus
extern "C" {
#endif

#include "freqcfgcommon.h"

#define board_band_freq_0   (0)
#define board_band_freq_1   (1)

UINT32 BspSetTxBandFreqFromBoard(UINT32 bspChan,UINT32 bandFreq0,UINT32 bandFreq1);
UINT32 BspSetRxBandFreqFromBoard(UINT32 bspChan,UINT32 bandFreq0,UINT32 bandFreq1);

#ifdef __cplusplus
}
#endif

#endif

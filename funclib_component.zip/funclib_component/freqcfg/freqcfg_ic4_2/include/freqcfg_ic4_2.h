/*****************************************************************************
* 版权所有(C) 2021, ZTE Corp. ZXSDR-RRU Platform BSP
*----------------------------------------------------------------------------
* 模 块 名 : 配频
* 文件名称 : freqcfg_ic4_2.h
* 文件标识 : {[N/A]}
* 内容摘要 : 本文件提供了配频接口函数声明
* 注意事项 : 无
* 作    者 : 李权明10279092
* 创建日期 : 2021-11-26
* 当前版本 : Ver1.0
*----------------------------------------------------------------------------*/

#ifndef _FUNCLIB_FREQCFG_IC4_2_H_
#define _FUNCLIB_FREQCFG_IC4_2_H_


#ifdef __cplusplus
extern "C" {
#endif

#include "freqcfgcommon.h"
#include "freqcfg_ic4_2_analyse.h"
#include "ichaladapt_ic4_2.h"

typedef UINT32 (*FUNC_UnfixCalcCenterFreqFromBoard)(UINT32 dir,UINT32 bspChnl,T_RfCfgPara *pRfCfgPara);
typedef UINT32 (*FUNC_CALLED_AFTER_FREQCFG)(UINT32 difChan, UINT32 *pReservePara);
typedef UINT32 (*FUNC_UPDATE_PAPT_AVG_POW_INFO)(UINT32 bspChan);
typedef UINT32 (*FUNC_CfgExTrxNco)(UINT32 bspChan,UINT32 dir, UINT32 carrNco);
typedef UINT32 (*FUNC_CfgTrxRfNco)(UINT32 bspChan,UINT32 dir, INT32 rfNco);
#define FUNC_AFTER_FREQCFG_INDEX_MAX (3)

#define BSP_IC_PERCHAN_BAND_NUM (2)

#define BSP_FREQ_UNFIX_CALC_LO      (0)
#define BSP_FREQ_NO_CONFIGC_LO      (1)
#define BSP_FREQ_UNFIX_UPDATA_LO    (2)
#define BSP_FREQ_FROM_BOARD_LO      (3)
#define BSP_FREQ_DYNAMIC_LO         (4)

#define BSP_FREQ_ZERO               (0)
#define MAX_GUSHARE_FREQ_NUM                (13)    /* GU频谱共享支持的最大GSM频点数量*/
#define MAX_GUSHARE_SLOT_NUM                (8)     /* GU频谱共享支持最大时隙数量, 即U带内可挖的陷波点数量*/
#define TRAP_COEF_FILTER_ORDER              (71)
#define MAX_TX_CHANNEL_GU_SHAREBW           (8)
#define TRAP_COEF_ARRAY_LEN                 (72)    /* 配置到IC中频的系数长度(I和Q间隔排列) */
#define ANF_MAX_NUM                         (16)    /* 每片IC的ANF功能最大抵消干扰点数量 */

#define CHECK_BSPCHN(bspChan)  if(bspChan >= BSP_IC4_DIF_CHAN_NUM) { dbgErr("%s bspChan over range!\n", __func__); return BSP_ERROR;}
#define CHECK_CARR_NUM(carr)   if((carr) > BSP_MAX_CARR_NUM) { dbgErr("%s carr over range!\n", __func__); return BSP_ERROR;}


typedef struct ChanNcoInfo
{
    UINT32 radioMode;
    UINT32 carrNo;
    INT32 carrNco;
    INT32 bandNco;
    UINT32 carrBandNo;
}T_CarrCfgNcoInfo;

typedef struct tag_CarrCfgNcoInfo{
      T_CarrCfgNcoInfo carrNcoInfo[BSP_MAX_CARR_NUM];
}T_ChanNcoInfo;

typedef struct
{
    UCHAR   bspChan;
    UCHAR   carrNo;
    UCHAR   slotNo;
    UCHAR   freqNum;
    UINT32  shareFreq[MAX_GUSHARE_FREQ_NUM];
} T_BspGuShareBwFreqCfg;

UINT32 BspGetGuShareBwAbility(void);
UINT32 BspSetGuShareBwFreq(T_GuShareBwFreqCfg *guShareFreq);
UINT32 CfgCarrAndFreqNco(UINT32 chan,UINT32 dir, UINT32 centFreq,T_RfCfgPara *pRfCfgPara, T_RfFreqCfgFailCarrInfoChan *ptFreqCfgFailCarrInfoChan);
UINT32 BspGetRfCenterFreq(UINT32 uDir, UINT32 ulBspChan);
UINT32 BspSetSupportMgrFreqFlag(UINT32 mgrFreqFlag);
UINT32 BspGetSupportMgrFreqFlag(VOID);
UINT32 BspIsFreqCfgDynamic(void);
T_RfPllCfgInit *pGetRfPllCfgHandle(UINT32 dir);
UINT32 BspSetRxRfCfg(UINT32 chan, T_RfCfgPara *pRfCfgPara);
UINT32 BspSetTxRfCfg(UINT32 chan, T_RfCfgPara *pRfCfgPara);
UINT32 BspSetRxRfCfgUwb(UINT32 chan, T_RfCfgPara *pRfCfgPara);
UINT32 BspSetTxRfCfgUwb(UINT32 chan, T_RfCfgPara *pRfCfgPara);
UINT32 BspSetCallBackAfterFreqcfg(UINT32 dir, UINT32 index, FUNC_CALLED_AFTER_FREQCFG pFunc);
UINT32 BspSetUpdatePaptAvgPowInfoCallBack(FUNC_UPDATE_PAPT_AVG_POW_INFO pFunc);
INT32 BspGetCarrNcoCfg(UINT32 dir, UINT32 difChan, UINT32 carrNo, UINT32 radioMode);
INT32 BspGetBandNcoCfg(UINT32 dir, UINT32 difChan, UINT32 carrNo, UINT32 radioMode);
INT32 BspGetCarrCarrBandNcoCfg(UINT32 dir, UINT32 difChan, UINT32 carrNo, UINT32 radioMode);
INT32 BspGetCarrCarrBankNcoCfg(UINT32 dir, UINT32 difChan, UINT32 carrNo, UINT32 radioMode);
VOID BspSetTransCaliFlags(UINT32 trsvId, UINT32 flags);
UINT32 BspGetTransCaliFlags(UINT32 trsvId);
UINT32 BspSetTddBandFreqFlag(UINT32 flag);
UINT32 BspSetExpansionFlag(UINT32 flag);
UINT32 BspSetFreqOffSetIndexByCarr(UINT32 uiDifChan, UINT32 uiCarrId, UINT32 uiRadioMode, UINT32 uiIndex);
UINT32 BspGetRcfCoefByBandWith(UINT32 bspChan,UINT32 radioMod,UINT32 bandWidth);
UINT32 BspSetUmtsCarrFreq(UINT32 bspChan, UINT32 dir,UINT32 umtsCarrNo, INT32 freqOffset);
UINT32 BspSetUmtsTxNco(UINT32 chanId, UINT32 carrNo, INT32 swFreqOffset);
UINT32 BspGetPublicDlFilterPara(UINT32 bspChan, UINT32 carrNo, UINT32 radioMod, T_carrFilterPara *carrPara);
UINT32 BspDpdSetCellInfo(UINT32 chan,UINT32 bandId);
UINT32 BspSetTxNbGuardOffset(UINT32 difChan, UINT32 carrNo, UINT32 radioMode, INT32 offset);
UINT32 BspSetRxNbGuardOffset(UINT32 difChan, UINT32 carrNo, UINT32 radioMode, INT32 offset);
INT32 BspGetRfNco(UINT32 uDir, UINT32 ulBspChan);
UINT32 BspUpdatePaptAvgPowInfo(UINT32 bspChan);
UINT32 BspCheckUlCarryInfo(UINT32 uiBandWidth, UINT32 uiSampelRate, UINT32 uiCarrRadio);
UINT32 BspCheckDlCarryInfo(UINT32 uiBandWidth, UINT32 uiSampelRate, UINT32 uiCarrRadio);
UINT32 BspGetTxdefLoFreq(UINT32 bspChan);
UINT32 BspSetTxdefLoFreq(UINT32 bspChan,UINT32 defLoFreqKHz);
UINT32 BspGetRxdefLoFreq(UINT32 bspChan);
UINT32 BspSetRxdefLoFreq(UINT32 bspChan,UINT32 defLoFreqKHz);
INT32 BspGetTxAcBandNco(UINT32 bspChan);
INT32 BspGetRxBandNco(UINT32 bspChan);
INT32 BspGetTxBandNco(UINT32 bspChan);
UINT32 BspGetTxAcLoToCarrThre(UINT32 bspChan);
VOID BspSetTxAcLoToCarrThre(UINT32 bspChan, UINT32 loToCarrThre);
INT32 BspGetRxAcBandNco(UINT32 bspChan);
UINT32 BspSetTxBandNco(UINT32 bspChan, INT32 bandNco);
UINT32 BspSetRxBandNco(UINT32 bspChan, INT32 bandNco);
UINT32 BspUpdateVswrComps(UINT32 bspChan, UINT32 uFreqKHz);
UINT32 BspGetLteIrSubFrame(VOID);
UINT32 BspGetLteIrSpeSubFrame(VOID);
T_FilterChnInfo *BspGetUlFilterChnInfoMem(UINT32 radio);
T_FilterChnInfo *BspGetFilterChnInfoMem(UINT32 radio);
UINT32 CfgCarrNco(UINT32 bspChan, UINT32 dir, UINT32 centFreq, T_RfCfgPara *pRfCfgPara, T_RfFreqCfgFailCarrInfoChan *ptFreqCfgFailCarrInfoChan);
INT32 BspGetChanBandBase(UINT32 bspChan, UINT32 dir);
UINT32 BspSetTrxChanNcoCallBack(FUNC_CfgExTrxNco pFunc);
UINT32 BspSetTrxRfNcoCallBack(FUNC_CfgTrxRfNco pFunc);
UINT32 BspSetTrxRfNco(UINT32 bspChan, UINT32 dir, INT32 rfNco);
UINT32 BspSetDlFilterCpgBw(UINT32 difChan, UINT32 carrNo, UINT32 radio, UINT32 cpgbandWidth);
UINT32 BspSetDlFilterRcfBw(UINT32 difChan, UINT32 carrNo, UINT32 radio, UINT32 rcfbandwidth);
UINT32 BspSetDlFilterNcoFront(UINT32 difChan, UINT32 carrNo, UINT32 radio, INT32 swFreqOffset);
UINT32 BspSetDlFilterNcoBehind(UINT32 difChan, UINT32 carrNo, UINT32 radio, INT32 freqOffset);
UINT32 BspSetCfrFreqFiOffset(UINT32 difChan, UINT32 carrNo, UINT32 radio, UINT32 offset);
UINT32 BspGetCfrFreqFiOffset(UINT32 difChan, UINT32 carrNo, UINT32 radioMod, INT32 *fi);
UINT32 BspGetFilterNcoFront(UINT32 difChan, UINT32 carrNo, UINT32 radioMod, INT32 *ncoFront);
UINT32 BspGetUlFilterNcoFront(UINT32 difChan, UINT32 carrNo, UINT32 radioMod, INT32 *ncoFront);
UINT32 BspSetSideFilterDlCoef(UINT32 bspChan, UINT32 carrNo, UINT32 radio, UINT32 bandWidth);
UINT32 BspSetSideFilterTxNco(UINT32 bspChan, UINT32 carrNo, UINT32 radio, INT32 swFreqOffset);
UINT32 BspSetSideFilterTxCarrFreq(UINT32 bspChan, UINT32 carrNo, UINT32 radio, INT32 freqOffset);
UINT32 BspGetCfrFreqFiOffsetLteNr(UINT32 bspChan, T_CfrFreqFiOffsetInfo * pcfrFreqFiOffsetInfo);
UINT32 BspGetFilterBw(UINT32 difChan, UINT32 carrNo, UINT32 radioMod, UINT32 *filterBw);
UINT32 BspGetUlFilterBw(UINT32 difChan, UINT32 carrNo, UINT32 radioMod, UINT32 *filterBw);
UINT32 BspJudgeCarrFilter(UINT32 difChn, UINT32 dir, UINT32 carrNo, UINT32 carrRadio);

UINT32 BspSetUlFilterRcfBw(UINT32 difChan, UINT32 carrNo, UINT32 radio, UINT32 rcfbandwidth);
UINT32 BspSetUlFilterNcoFront(UINT32 difChan, UINT32 carrNo, UINT32 radio, INT32 swFreqOffset);
UINT32 BspSetUlFilterNcoBehind(UINT32 difChan, UINT32 carrNo, UINT32 radio, INT32 swFreqOffset);
UINT32 BspSetSideFilterRxNco(UINT32 bspChan, UINT32 carrNo, UINT32 radio, INT32 swFreqOffset);
UINT32 BspSetSideFilterRxCarrFreq(UINT32 bspChan, UINT32 carrNo, UINT32 radio, INT32 freqOffset);
UINT32 rxsidefilter(UINT32 bspChan, UINT32 carrNo, UINT32 radio, UINT32 bandWidth, INT32 nco1);
void BspSetRfCfgDefault(void);
UINT32 BspClrSideFilterNco(VOID);
UINT32 BspGetFilterCarrBw(UINT32 dir, UINT32 bspChan, UINT32 carrNo, UINT32 carrRadio, UINT32 cfgBw);
INT32 BspGetFilterCarrNco(UINT32 dir, UINT32 bspChan, UINT32 carrNo, UINT32 carrRadio, INT32 bankNco);
INT32 BspGetFilterBankNco(UINT32 dir, UINT32 bspChan, UINT32 carrNo, UINT32 carrRadio, INT32 bankNco);

BOOL BspIsSupportSideFilterBw(UINT32 carrRadio, UINT32 bandWidth);
UINT32 BspSetRxRfCfgNew(UINT32 chan, T_RfCfgPara *pRfCfgPara,  T_RfFreqCfgFailCarrInfoChan *ptFreqCfgFailCarrInfoChan);
UINT32 BspSetTxRfCfgNew(UINT32 chan, T_RfCfgPara *pRfCfgPara,  T_RfFreqCfgFailCarrInfoChan *ptFreqCfgFailCarrInfoChan);
UINT32 BspCarrResourceRecycle(T_DestCarrInfoAllChans *pCarrInfoAllChans);
VOID BspSetFailedFreqCarrNo(UINT32 carrNo);
UINT32 BspCfgBand(UINT32 bspChnl, UINT32 dir, T_RfCfgPara *pRfCfgPara);
UINT32 CalcCenterFreq(UINT32 dir,UINT32 bspChnl,T_RfCfgPara *pRfCfgPara);
UINT32 CfgTxRfPll(UINT32 bspChan, UINT32 centFreq, UINT32 loFreq);
UINT32 CfgRxRfPll(UINT32 bspChan, UINT32 centFreq, UINT32 loFreq);
UINT32 CfgTxNco(UINT32 bspChan, UINT32 centFreq, T_RfCfgPara *pRfCfgPara, T_RfFreqCfgFailCarrInfoChan *ptFreqCfgFailCarrInfoChan);
UINT32 CfgRxNco(UINT32 bspChan, UINT32 centFreq, T_RfCfgPara *pRfCfgPara, T_RfFreqCfgFailCarrInfoChan *ptFreqCfgFailCarrInfoChan);
UINT32 BspJudgeCarrFilterByCpg(UINT32 difChn, UINT32 dir, UINT32 carrNo, UINT32 carrRadio);
UINT32 BspGetFilterBwByCpg(UINT32 difChan, UINT32 carrNo, UINT32 radioMod, UINT32 *filterBw);
UINT32 BspGetUlFilterBwByCpg(UINT32 difChan, UINT32 carrNo, UINT32 radioMod, UINT32 *filterBw);
#ifdef __cplusplus
}
#endif

#endif

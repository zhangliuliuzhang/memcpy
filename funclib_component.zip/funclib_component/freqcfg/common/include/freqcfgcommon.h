/*****************************************************************************
* 版权所有(C) 2017, ZTE Corp. ZXSDR-RRU Platform BSP
*----------------------------------------------------------------------------
* 模 块 名 : bsp
* 文件名称 : freqcfgcommon.h
* 文件标识 : {[N/A]}
* 内容摘要 : 本文件提供了配频接口声明
* 注意事项 : 无
* 作    者 :   10090699
* 创建日期 : 2017-03-08
* 当前版本 : Ver1.0
*----------------------------------------------------------------------------
* 变更记录 :
*
* $记录1
* 变 更 单: $0000000(N/A)
* 责 任 人: 10090699
* 修改日戳: 2017-03-08
* 变更说明: 创建文件
*----------------------------------------------------------------------------
*/

#ifndef _FUNCLIB_FREQCFGCOMMON_H_
#define _FUNCLIB_FREQCFGCOMMON_H_



#ifdef __cplusplus
extern "C" {
#endif
#include "bsppub.h"
#include "freqcfgapi.h"
#include "funccommon_log.h"
#include "funccommon_chncfg.h"
#include "rruinfo.h"


//#define BSP_MAX_MIFBAND_NUM  9

#define DIF_ONE_BAND 			 1  // 不定义成0是因为原来的BspInitRruTxDifCfgPara接口把bandFreq赋值成centerFreq,得区分开来
#define DIF_MULT_BAND 		     2

#define DIF_SMALL_BW_5M          1		
#define DIF_SMALL_BW_10M		 2
#define DIF_SMALL_BW_15M         4
#define DIF_SMALL_BW_20M         8
#define DIF_NO_SMALL_BW			 0
#define CONST_FREQ_NCO_TX -20160
#define CONST_FREQ_NCO_RX   20160

#define CPE_TX_TIME_ADVANCE_1664    1   /* BBU下发1代表1660,AAU侧+64保护 */
#define CPE_TX_TIME_ADVANCE_2560    2   /* BBU下发2代表2496,AAU侧+64保护 */

#define DIF_CARR_FOUND_FLAG       1		
#define DIF_CARR_NO_FOUND_FLAG    2		

/* 配频配置方案: 0- 根据BBU高层下发频点信息动态配本振,
               1- 根据离线参数滤波器信息固定配本振
               2- 动态本振,载波边缘.(胡文彬方案,机型:A9611A,R9606...)
               3- 半固定本振
               4- 动态本振,保护带内.(吴晶方案)
*/
#define FREQ_CFG_SOLUTION_DYNAMIC (4)
#define FREQ_CFG_SOLUTION_LOW_LOFREQ (6)/*高频低本振*/

typedef enum
{
    E_ONE_LEVEL_CFR_IBW_160M_OBW_160M   = 0,//潮�塘崔
    E_ONE_LEVEL_CFR_IBW_200M_OBW_160M   = 1,//194M�m箔吉�h蒙�i魁尚
    E_ONE_LEVEL_CFR_IBW_NUM,
}E_ONE_LEVEL_CFR_OBW_160M_TYPE;

typedef enum
{
    E_FREQ_NCO2_NOT_CONST = 0,//潮�塘崔
    E_FREQ_NCO2_IS_CONST = 1,
    E_FREQ_NCO2_NUM,
}E_FREQ_NCO2_TYPE;

#define MAX_CHAN_PER_CHIP        (16)
typedef enum
{
    CARR_NCO_ONLY      = 0,
    CARR_FREQ_NCO_BOTH = 1,
    CARR_FREQ_NCO_DLPOST_NCO2 = 2,//dl:freqnco--dlpost nco2,carrnco;ul:ulchan,carrnco
	CARR_FREQ_CARR_MNCO = 3,
    E_BOARD_NCO_MAX,
}E_BOARD_NCO2_TYPE;

typedef UINT32 (*FUNC_UNFIX_LO_CALC_COM)(T_RfCfgPara *pRfCfgPara);
typedef UINT32 (*pGetRfCfgBwpCall)(VOID);
typedef UINT32 (*pSetRfCfgBwpCall)(UINT32 ulBwpKHz);
typedef UINT32 (*pGetRfFreqNcoStep)(UINT32 ulTrxDir, UINT32 ulChnl);
typedef UINT32 (*pGetRfFreqRange)(UINT32 ulTrxDir, UINT32 ulChnl, UINT32 *pulMinFreq, UINT32 *pulMaxFreq);
typedef UINT32 (*pGetUmtsPubCarrNo)(UINT32 bspchan, UINT32 dir,UINT32 carrno);
typedef UINT32 (*pGetNbChaCarrNo)(UINT32 bspchan, UINT32 dir,UINT32 carrno,UINT32 *chnmap,UINT32 *carrnomap);
typedef UINT32 (*pGetChnBndMap)(UINT32 bspchn,UINT32 bandid, UINT32 *chanmap,UINT32 *bandidmap);
typedef UINT32 (PFuncCfrCarrInfoUpdate)(UINT32 uChn, UINT32* pCarrNo, T_RruBandCfgInfo* pCarrCfg, T_RruBandCfgInfo* pOutCarrCfg, UINT32 *pOutCarrNum, UINT32 *pProtocol);
typedef UINT32 (*pSetNbTxFreqOffset)(UINT32 difChan, UINT32 carrNo, UINT32 radioMode, INT32 offset);
typedef UINT32 (*pSetNbRxFreqOffset)(UINT32 difChan, UINT32 carrNo, UINT32 radioMode, INT32 offset);
typedef UINT32 (*pGetLteNrCarrNo)(UINT32 bspchan, UINT32 dir,UINT32 nrmaxband, UINT32 radio,UINT32 *carrno);
typedef UINT32 (*pGetLoFreqBlackout)(UINT32 bspchan, UINT32 loFreq);

typedef UINT32 (*pGetFixedBandLoFreq)(UINT32 ulBspChnl, UINT32 ulTrxType);


/* 新增规格传入频段滤波器范围, 如果不是双频段机型,不需注册                           */
typedef UINT32  (*pGetRfBandFreqRange)(UINT32 ulTrxDir, UINT32 ulChnl, UINT32 band,UINT32 *pulMinFreq, UINT32 *pulMaxFreq);


typedef UINT32 (*pHandlePrePostLoReCfg)(UINT32 trx, UINT32 chan);
typedef UINT32 (*pHandleReCfgLoFreq)(UINT32 trx, UINT32 chan, UINT32 freq);
typedef UINT32 (*FUNC_FREQ_GET_FLAG)(VOID);

typedef VOID (*FuncTypeGetRfFpgaTddioSwitch)(VOID);

/* 配频配置方案cfgSolution: 0(默认标志)- 根据BBU高层下发频点信息动态配本振,
                            1(规格配置)- 根据离线参数滤波器信息固定配本振 */
typedef struct tagT_RfPllCfgInit
{
    INT32  ifFreq;            /* 中频频点,KHz */
    UINT32 loStep;            /* 本振步进频率,KHz */
    UINT32 ncoStep;           /* NCO步进频率,KHz */
    UINT32 cfgSolution;
    UINT32 ncoSolution;       /* 区分一级NCO还是两级NCO，与频段划分无关，仅与规格带宽有关 */
    UINT32 defLoFreqKHz;
    UINT32 defLoFreqKHz0;     /* 因电联版本有两个本振引入 无此频点的机型置为0 */
    UINT32 IfBw;              /* 中频带宽,kHz */
    UINT32 dpdRangeLow;       /* DPD带宽范围,门限下限,kHz */
    UINT32 dpdRangeHigh;      /* DPD带宽范围,门限上限,kHz */
    UINT32 (*pFixLo)(UINT32 bspChan,UINT32 dir,UINT32 freq);/* 因超大带宽机型有多个本振引入 无此频点的机型不初始化该接口 */
    UINT32 loToCarrThre;      /* 本振距离载波有效门限值 */
    UINT32 loToFilterThre;    /* 本振距离滤波器中心频点有效门限值*/
    UINT32 bandNcoFlag;       /* 使用频段NCO标志，对于有频段NCO而言，判断本振是否可用方法不适用*/
    UINT32 bandNcoStep;       /* 频段NCO步进*/
    INT32  bandNcoBase;       /* 频段NCO参考基准*/
    INT32  WfsAcNcoBase;     /* 工装测试上下行频点交换建小区所使用，下行计算方式：上行本振-下行协议中心频点；上行计算方式：下行本振-上行中心频点*/
    UINT32  loChangeSelectMargin;   /* 本振频点选择滤波器右边余量选择，例S35配置3*100M(3300-3600),中心频点3450，本振优先3500，非3400*/
    UINT32 (*pLoCfg)(UINT32 bspChan,UINT32 freq);
    UINT32 (*pLoGet)(UINT32 bspChan);/* 获取本振配置频点 */
    UINT32 (*pLoCali)(UINT32 bspChan,UINT32 freq);
    UINT32 (*pGetNcoStep)(UINT32 bspChan,UINT32 dir,UINT32 carr,UINT32 radioMode);
    UINT32 (*pGetFreqRange)(UINT32 bspChan, UINT32 dir, UINT32 band, UINT32 *pminFreq, UINT32 *pmaxFreq);
    UINT32 (*pSetCarrBand)(UINT32 bspChan, UINT32 dir,UINT32 carr,UINT32 radioMode, UINT32 bandWidthKHz);
    UINT32 (*pSetMtsNco)(UINT32 bspChan, UINT32 dir, INT32 txNco, INT32 rxNco, INT32 orxNco);
}T_RfPllCfgInit;
typedef struct tagT_MifCfgUpData
{
    UINT32 link0Data;
    UINT32 link1Data;
}T_MifCfgUpData;

typedef struct tagT_MifCfgData
{
    UINT32 index;
    UINT32 carrNo;           /*载波号*/
    UINT32 bandWidth;     /*mif对应带宽*/
    UINT32 rbNum;             /*rb数*/
    UINT32 dwCfgNum;      /*下行配置数*/
    UINT32 upCfgNum;       /*上行配置数*/
    UINT32 upClrCfgVal;     /*上行清零拐点*/
    UINT32 cfgFpgaMask;    /*配置FPGA MASK*/
    UINT32 *pMifCfgDwData;  /*下行数据存放地址*/
    T_MifCfgUpData *pMifCfgUpData;  /*上行数据存放地址*/
    //UINT8  fileName1[40];     /*要加载的文件名*/
    //UINT8  fileName2[40];
}T_MifCfgData;
#if 1
typedef struct tagT_MifCfgTbl
{
    T_MifCfgData *mifCfgData;//[BSP_MAX_MIFBAND_NUM];
    UINT32 mifCfgCarrNum;
}T_MifCfgTbl;
#endif

/* DPD band nco, ulchan band nco, fb band nco */
typedef struct _T_BAND_NCO_INFO_
{
    INT32 bandNcoInfo[MAX_CHANNEL_MAP_NUM];
} T_DPD_UL_FB_BAND_NCO_INFO;



typedef struct tagT_ChanRfCfgPara
{
    UINT32       bspChan;
    UINT32       dir;
    UINT32       centerFreq;    /* 中心频点 */
    UINT32       centerFreqSrc; /* 中心频点来源,0:BSP计算,1:高层下发 */
    UINT32       rfpllFreq;
    UINT32       rfpllFreqSrc;
    UINT32       bandFlag; /* 单双频段标志 */
    UINT32       bandFreq[BSP_MAX_BAND_PER_CH];  /* 子频段中心频点 */
    UINT32       carrNcoFreq[BSP_MAX_CARR_NUM];  /* 载波nco */
    UINT32       carrBandFlag[BSP_MAX_CARR_NUM]; /* 载波属于哪个频段标识 */
    T_RfCfgPara  para;
    struct tagT_ChanRfCfgPara *next;
}T_ChanRfCfgPara;

typedef struct T_CfrLteUmtsFreqFiOffsetInfo {
    UINT32 difChn;
    UINT32 carrNo;
    UINT32 carrRadio;
    INT32  offset ;
} T_CfrLteUmtsFreqFiOffsetInfo;

typedef struct T_CfrFreqFiOffsetInfo {
    UINT32 difChn;
    UINT32 carrNo;
    UINT32 carrRadio;
    INT32  offset ;
} T_CfrFreqFiOffsetInfo;

UINT32 BspAddRfCfgPara(UINT32 chan,UINT32 dir,T_RfCfgPara *pRfCfgPara);
T_RfCfgPara * BspGetRfCfgPara(UINT32 bspChan, UINT32 dir);
UINT32 BspGetCenterFreqSrc(UINT32 dir, UINT32 bspChan);
UINT32 BspGetLoFreqSrc(UINT32 dir, UINT32 bspChan);
UINT32 BspRecordLoFreq(UINT32 dir, UINT32 bspChan, UINT32 freq);
UINT32 BspRecordCenterFreq(UINT32 dir, UINT32 bspChan, UINT32 freq);
UINT32 BspInitRruCfgPara(UINT32 chan,UINT32 dir);
UINT32 BspInitRruTxDifCfgPara(UINT32 chan);
pSetNbTxFreqOffset BspGetNbTxFreqOffsetCallBack(VOID);
UINT32 BspSetNbTxFreqOffsetCallBack(pSetNbTxFreqOffset pCallBackFunc);
pSetNbRxFreqOffset BspGetNbRxFreqOffsetCallBack(VOID);
UINT32 BspSetNbRxFreqOffsetCallBack(pSetNbRxFreqOffset pCallBackFunc);
UINT32 BspRfPllCfgInit(UINT32 bspChan,UINT32 dir,T_RfPllCfgInit *pPara);

UINT32 BspGetCarrMode(UINT32 dir, UINT32 chan, UINT32 carrNo);

typedef UINT32 (*__BspBoardLoFreqDef)(UINT32 dir, UINT32 chan);

UINT32 BspGetFreqBw(UINT32 dir, UINT32 chan, UINT32 carrNo);
UINT32 BspGetCarrBw(UINT32 dir, UINT32 chan, UINT32 carrNo, UINT32 radioMode);
UINT32 BspGetCarrBwByRfCfg(UINT32 dir, UINT32 chan, UINT32 carrNo, UINT32 radioMode);
UINT32 BspGetCarrFreq(UINT32 dir, UINT32 chan, UINT32 carrNo);
UINT32 BspGetChanCarrFreq(UINT32 dir, UINT32 chan, UINT32 carrNo, UINT32 radioMode);

UINT32 BspGetLoFreq(UINT32 dir, UINT32 chan);
UINT32 BspGetLoFreqChanged(UINT32 dir, UINT32 chan);
UINT32 BspSetTxLoFreq(UINT32 bspChan,UINT32 loFreq);

UINT32 BspGetRfChCenterFreq(UINT32 rfChan, UINT32 dir, UINT32* rfCenterFreq);

pGetRfFreqRange BspGetFilterRangeFreqCallBack(VOID);
UINT32 BspSetFilterRangeFreqCallBack(pGetRfFreqRange pCallBackFunc);
pGetRfBandFreqRange BspGetBandFilterRangeFreqCallBack(VOID);
UINT32 BspSetBandFilterRangeFreqCallBack(pGetRfBandFreqRange pCallBackFunc);
T_ChanRfCfgPara *GetRfCfgPara(UINT32 bspChan,UINT32 dir);
pGetRfFreqNcoStep BspGetRfFreqNcoStepCallBack(VOID);
UINT32 BspSetRfFreqNcoStepCallBack(pGetRfFreqNcoStep pCallBackFunc);

UINT32 BspSetRfCfgBwpSetCallBack(pSetRfCfgBwpCall pCallBackFunc);
UINT32 BspGetRfCfgBwpSetCallBack(pGetRfCfgBwpCall pCallBackFunc);
UINT32 BspSetBwpCfgFlowFlag(UINT32 ulSetType, UINT32 ulChkBitOff, UINT32 ulSetBitOff);

UINT32 BspGetRfCfgCarrSum(UINT32 dir, UINT32 chan);
UINT32 BspGetRfCfgCarrMode(UINT32 dir, UINT32 chan);
UINT32 BspClearCfgCarrInfo(UINT32 trxDir, UINT32 bspChnl);
UINT32 BspSetCenterFreq(UINT32 dir, UINT32 chan, UINT32 freq);
UINT32 BspGetCenterFreq(UINT32 dir, UINT32 chan);
UINT32 DbgSetRfCfg(UINT32 ulTrxType, UINT32 ulChnl, UINT32 ulCarr,
            UINT32 ulRadioMode, UINT32 ulFreqKHz, UINT32 ulBwKHz);
UINT32 BspGetTxChnMaxMinFreq(UINT32 bspChn,UINT32 *pMaxFreq,UINT32 *pMinFreq);
UINT32 BspSetRfCfgDbgManuCfgFlag(UINT32 ulTrxType, UINT32 ulCfgFlag);
UINT32 BspSetMifCfgTbl(T_MifCfgData*ptMifCfgData,UINT32 mifCfgDataSize);
T_MifCfgTbl * BspGetMifCfgTbl(VOID);
//UINT32 BspGetMifCfgTblSize(VOID);
UINT32 BspGetBw(VOID);

UINT32 BspGetCfgCarrNum(VOID);
UINT32 BspGetBandFlg(UINT32 dir, UINT32 chan);
UINT32 BspGetSmallBwFlg(UINT32 dir, UINT32 chan);
UINT32 BspRecordBandFlag(UINT32 dir, UINT32 bspChan, UINT32 flag);	
UINT32 BspRecordBandFreq(UINT32 dir, UINT32 bspChan, UINT32 bandNo, UINT32 bandFreq);
UINT32 BspGetBandFreq(UINT32 dir, UINT32 chan, UINT32 bandNo);
UINT32 BspGetCarrNcoFreq(UINT32 dir, UINT32 chan, UINT32 bandNo);
UINT32 BspRecordCarrBandFlag(UINT32 dir, UINT32 bspChan, UINT32 carrNo, UINT32 bandNo);
UINT32 BspGetCarrBandFlag(UINT32 dir, UINT32 chan, UINT32 carrNo);
UINT32 BspGetBandCarrNo(UINT32 dir, UINT32 chan, UINT32 carrNo);
UINT32 BspGetPllFreqCallback(__BspBoardLoFreqDef pFunc);

UINT32 BspGetTxChnBndMaxMinFreq(UINT32 bspChn,UINT32 bandid,UINT32 *pMaxFreq,UINT32 *pMinFreq);
UINT32 BspGetNbChaCarrNoInit(pGetNbChaCarrNo ptfuc);
UINT32 BspGetNrCarrNoInit(pGetLteNrCarrNo ptfuc);
UINT32 BspGetRxChnMaxMinFreq(UINT32 bspChn,UINT32 *pMaxFreq,UINT32 *pMinFreq);
UINT32 BspGetChnBndCallBack(pGetChnBndMap pCallBackFunc);
UINT32 BspGetRxChnBndMaxMinFreq(UINT32 bspChn,UINT32 bandid,UINT32 *pMaxFreq,UINT32 *pMinFreq);
UINT32 BspGetBoardNcoGrade(UINT32 bspchan,UINT32 dir);
UINT32 BspSetBoardNcoGrade(UINT32 bspchan,UINT32 dir,UINT32 grade);
UINT32 BspGetIbwObwSpeicalCfg(VOID);
UINT32 BspSetIbwObwSpeicalCfg(UINT32 cfg);
UINT32 BspIfIbwObwNeedSpecialCfg();
UINT32 BspSetCfrCarrCfgUpdateFunc(PFuncCfrCarrInfoUpdate pFunc);
UINT32 BspUnfixLoCalcComCallBack(FUNC_UNFIX_LO_CALC_COM pFunc);
UINT32 testUnfixLoCalc(VOID);
UINT32 DbgSetCarrNco(UINT32 ulTrxDir, UINT32 ulChnl, UINT32 ulCarr, INT32 iOffFreqKHz);
UINT32 BspGetCarrCfgBw(VOID);
VOID  BspSetCarrCfgBw(UINT32 uCarrBw);
UINT32 BspSetHandlePreLoReCfgFunc(pHandlePrePostLoReCfg func);
UINT32 BspSetHandlePostLoReCfgFunc(pHandlePrePostLoReCfg func);
UINT32 BspSetHandleReCfgLoFreqFunc(pHandleReCfgLoFreq func);
T_DPD_UL_FB_BAND_NCO_INFO *BspGetDpdUlFbBandNco(VOID);
UINT32 BspSetCfgedCarrStatusInfo(UINT32 trxDir, UINT32 bspChnl,T_RfCfgPara *pRfCfgParam);
UINT32 BspSetRfCfgFreqCarrInfo(T_DestCarrInfoAllChans *pCarrInfoAllChans);
VOID BspSetFixBandFreqFlag(UINT32 flag);
UINT32 BspGetFixBandFreqFlag(VOID);
VOID BspGetRfCarrCfgInfo(UINT32 dir,UINT32 rfmode ,UINT32 carrno,UINT32 frq,UINT32 *chninfo,UINT32 *channum,UINT32 *cellid);
UINT32 BspSetFixedBandLoFreqCallBack(pGetFixedBandLoFreq pCallBackFunc);
UINT32 BspGetNbFreqOffset(UINT32 bspChn, UINT32 dir, UINT32 carrNo, INT32* offset);
VOID BspGetRfCarrCfgInfoByCellId(UINT32 dir,UINT32 rfmode ,UINT32 carrno,UINT32 cellid,UINT32 *chninfo,UINT32 *channum);
T_ChanRfCfgPara *GetRfCfgPara_original(UINT32 bspChan,UINT32 dir);
UINT32 BspAddRfCfgPara_original(UINT32 bspChan, UINT32 dir, T_RfCfgPara *pRfCfgPara);
UINT32 BspInitRruCfgPara_original(UINT32 chan, UINT32 dir);
UINT32 BspSetLoFreqBlackoutCallBack(pGetLoFreqBlackout pCallBackFunc);
pGetLoFreqBlackout BspGetLoFreqBlackoutCallBack(VOID);
VOID setFreqFbBandFlag(UINT32 bspChan,UINT32 flag);
VOID setFreqFbBandFlag(UINT32 bspChan,UINT32 flag);
UINT32 BspGetFilterFreqRangeModule(UINT32 ulTrxDir, UINT32 ulBspChnl, UINT32 *pulMinFreq, UINT32 *pulMaxFreq);
UINT32 getRxOpenLoopPowCailtFlag();
UINT32 BspBandNcoFreqInit(VOID);
//coverity[cert_dcl60_cpp_violation:SUPPRESS]
VOID setRxOpenLoopPowCailtFlag(UINT32 flag);
UINT32 getFreqFbBandFlag(UINT32 bspChan);
//coverity[cert_dcl60_cpp_violation:SUPPRESS]
UINT32 showbspcfg(UINT32 chan,UINT32 dir);
UINT32 getFreqNcoConstFlag(VOID);
UINT32 BspClearTxRxRfCfg(VOID);
UINT32 BspGetCarrRadioMixMode();
UINT32 BspFreqGetBoardLofCallback(__BspBoardLoFreqDef pFunc);
UINT32 BspSetFreqRepairLoFreqShowCallBack(FUNC_FREQ_GET_FLAG pCallBackFunc);
VOID BspInitInstGetRfFpgaTddioSwitch(FuncTypeGetRfFpgaTddioSwitch p);
UINT32 showrfcfgchangetime(VOID);
UINT32 BspInitRruCfgParaForBothDirections(UINT32 bspChn);
UINT32 BspChangeRfCfgDir(UINT32 bspChn);
UINT32 BspSetUMTSRssiOptimizeSw(UINT32 bspChn, UINT32 carrNo, UINT32 sw);
UINT32 BspGetUMTSRssiOptimizeSw(UINT32 bspChn, UINT32 carrNo);
UINT32 BspGetCarrCopyType(UINT32 dir, UINT32 chan, UINT32 carrNo);

#ifdef __cplusplus
}
#endif
#endif 





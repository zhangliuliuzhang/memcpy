
#include "bsppub.h"
#include "bspcomm.h"
#include "freqcfgcommon.h"
#include "chnmapcommon.h"
#include "funccommon_a.h"
#include "exprn.h"
#include "chnmap_a.h"
#include "rruinfo.h"
#include "funccommon_chncfg.h"

static __BspBoardLoFreqDef pFreqGetPllFreq = NULL;
#define RFCFG_PARAM_CHK(Ret, Flag, Dir, Chnl, Carr, RadioMod, RfFreq, FreqBw) \
{                                                                             \
    if (0 == (Flag))                                                          \
    {                                                                         \
        if (((RadioMod) == BSP_ERROR) ||                                      \
            ((RfFreq)   == BSP_ERROR) ||                                      \
            ((FreqBw)   == BSP_ERROR))                                        \
        {                                                                     \
            dbgErr("%s>>Dir'%d Chnl'%d Carr'%d Radio|Freq|Bw Get Error!\n",   \
                   __FUNCTION__, (Dir), (Chnl), (Carr));                      \
            return (Ret);                                                     \
        }                                                                     \
    }                                                                         \
    else                                                                      \
    {                                                                         \
        if (((RadioMod) == 0) || ((RfFreq) == 0) || ((FreqBw) == 0))          \
        {                                                                     \
            dbgErr("%s>>Dir'%d Chnl'%d Carr'%d Radio&Freq&Bw Get Error!\n",   \
                   __FUNCTION__, (Dir), (Chnl), (Carr));                      \
            return (Ret);                                                     \
        }                                                                     \
    }                                                                         \
}

FUNC_UNFIX_LO_CALC_COM pfCalcUnifixLoCom = NULL;

UINT32 BspUnfixLoCalcComCallBack(FUNC_UNFIX_LO_CALC_COM pFunc)
{
    INPUT_POINTER_CHECK(pFunc);
    pfCalcUnifixLoCom = pFunc;
    return BSP_OK;
}

static UINT32 s_ulRfCfgBwpSetFlowFlag = 0;
static UINT32 s_ulCfrCarrInfoFlag = 0;
static UINT32 s_aulRfCfgDbgManuCfgFlag[2] = {0xFFFF, 0xFFFF};

static T_ChanRfCfgPara *pRfCfgHead = NULL;
static T_ChanRfCfgPara *pRfCfgHead_original = NULL;//保存真实大包配置信息传递给DSP，解决IC3.0支持GSM制式载波通道小区信息传递异常问题
static pGetRfFreqRange pGetFilterRangeFreq = NULL;
static pGetRfFreqNcoStep pGetRfCfgNcoStep = NULL;
static pSetNbTxFreqOffset pSetNbTxGuardOffset = NULL;
static pSetNbRxFreqOffset pSetNbRxGuardOffset = NULL;
static pSetRfCfgBwpCall  pSetRfCfgBwpFunc = NULL;
static pGetRfCfgBwpCall  pGetRfCfgBwpFunc = NULL;
static pGetRfBandFreqRange pGetFilterBandFreq = NULL;
static pGetChnBndMap  BspGetChnBandMap = NULL;
static pGetLoFreqBlackout pGetLoFreqBlackoutFunc = NULL;
static UINT32 s_filterIbwObwSpecialCfg = 0xFFFFFFFF;

static pGetFixedBandLoFreq pGetFixedBandLoFreqFunc = NULL;

static UINT32 g_uCarrBw = 100000;
static UINT32 s_fixrffreqflag = 0;
pHandlePrePostLoReCfg pFuncHandlePreLoReCfg = NULL;
pHandlePrePostLoReCfg pFuncHandlePostLoReCfg = NULL;
pHandleReCfgLoFreq pFuncHandleReCfgLoFreq = NULL;

INT32 s_ulNbTxFreqOffset[BSP_MAX_TX_CHAN][BSP_MAX_CARR_NUM] = {0};
INT32 s_ulNbRxFreqOffset[BSP_MAX_TX_CHAN][BSP_MAX_CARR_NUM] = {0};

UINT32 s_ulUmtsRssiOptimizeFlag[BSP_MAX_TX_CHAN][BSP_MAX_CARR_NUM] = {0};


static T_DestCarrInfoAllChans *gCarrInfoAllChans_Cmmn = NULL;
static __BspBoardLoFreqDef _BoardLoFreqDef = NULL;
static UINT32 trbcase = 0;
static FUNC_FREQ_GET_FLAG pFuncRepairLoFreqShowFlag = NULL;

FuncTypeGetRfFpgaTddioSwitch FuncInstGetRfFpgaTddioSwitch = 0;

UINT32 g_RfCfgChangeTime = 0;

VOID BspInitInstGetRfFpgaTddioSwitch(FuncTypeGetRfFpgaTddioSwitch p)
{
    INPUT_POINTER_CHECK_RETURN(p)
    FuncInstGetRfFpgaTddioSwitch = p;
}

/**********************************************************************
* 函数名称: BspInitRfCfg
* 功能描述: 清除射频配置
* 输出参数:
*   无
* 返 回 值: BSP_OK / BSP_ERROR
************************************************************************/
void BspSetRfCfgDefault(void)
{
	pRfCfgHead = NULL;
}

/**********************************************************************
* 函数名称: BspSetNbTxFreqOffset(UINT32 bspChn, UINT32 carrNo, INT32 offset)
* 功能描述: 设置NB inband模式下 下行载波频点偏移量
* 输入参数:
*   bspChn ：通道号
*   carrNo ：载波号
*   offset ：偏移量, 单位Hz
* 输出参数:
*   无
* 返 回 值: BSP_OK / BSP_ERROR
************************************************************************/
UINT32 BspSetNbTxFreqOffset(UINT32 bspChn, UINT32 carrNo, INT32 offset)
{
    UINT32 retVal = BSP_OK;
    UINT32 chipidx = 0;
    UINT32 difChn = 0;
    pSetNbTxFreqOffset pSetNbTxFreqOffFunc = NULL;

    if(bspChn >= BSP_MAX_TX_CHAN)
    {
        return BSP_ERROR;
    }
    if(carrNo >= BSP_MAX_CARR_NUM)
    {
        return BSP_ERROR;
    }

    retVal |= BspGetDifInfoByBspChn(bspChn, TX, &chipidx, &difChn);
    if (BSP_OK != retVal)
    {
        dbgErr("%s>>bspChan'%d BspGetDifInfoByBspChn Get Error!\n",__FUNCTION__, bspChn);
        BspLog(LOG_LEVEL_0,"[%s] bspChn'%d BspGetDifInfoByBspChn Get Error! \n",__FUNCTION__,bspChn);
        return BSP_ERROR;
    }

    pSetNbTxFreqOffFunc = BspGetNbTxFreqOffsetCallBack();
    if (NULL != pSetNbTxFreqOffFunc)
    {
        retVal = pSetNbTxFreqOffFunc(difChn, carrNo, BSP_RADIO_STANDARD_NB_IOT, offset);
        BspLog(LOG_LEVEL_0,"[%s] difChn'%d, carrNo'%d, offset'%dHz, retVal'%d \n",
                    __FUNCTION__,difChn,carrNo,offset,retVal);
    }

    s_ulNbTxFreqOffset[bspChn][carrNo] = offset; /*单位HZ*/

    return retVal;
}
/**********************************************************************
* 函数名称: BspSetNbRxFreqOffset(UINT32 bspChn, UINT32 carrNo, INT32 offset)
* 功能描述: 设置NB inband模式下 上行载波频点偏移量
* 输入参数:
*   bspChn ：通道号
*   carrNo ：载波号
*   offset ：偏移量, 单位Hz
* 输出参数:
*   无
* 返 回 值: BSP_OK / BSP_ERROR
************************************************************************/
UINT32 BspSetNbRxFreqOffset(UINT32 bspChn, UINT32 carrNo, INT32 offset)
{
    UINT32 retVal = BSP_OK;
    UINT32 chipidx = 0;
    UINT32 difChn = 0;
    pSetNbRxFreqOffset pSetNbRxFreqOffFunc = NULL;

    if(bspChn >= BSP_MAX_RX_CHAN)
    {
        return BSP_ERROR;
    }
    if(carrNo >= BSP_MAX_CARR_NUM)
    {
        return BSP_ERROR;
    }

    retVal |= BspGetDifInfoByBspChn(bspChn, RX, &chipidx, &difChn);
    if (BSP_OK != retVal)
    {
        dbgErr("%s>>bspChan'%d BspGetDifInfoByBspChn Get Error!\n",__FUNCTION__, bspChn);
        BspLog(LOG_LEVEL_0,"[%s] bspChn'%d BspGetDifInfoByBspChn Get Error! \n",__FUNCTION__,bspChn);
        return BSP_ERROR;
    }

    pSetNbRxFreqOffFunc = BspGetNbRxFreqOffsetCallBack();
    if (NULL != pSetNbRxFreqOffFunc)
    {
        retVal = pSetNbRxFreqOffFunc(difChn, carrNo, BSP_RADIO_STANDARD_NB_IOT, offset);
        BspLog(LOG_LEVEL_0,"[%s] difChn'%d, carrNo'%d, offset'%dHz, retVal'%d \n",__FUNCTION__,difChn,carrNo,offset,retVal);
    }

    s_ulNbRxFreqOffset[bspChn][carrNo] = offset; /*单位HZ*/

    return retVal;
}
/**********************************************************************************
* 函数名称: BspGetNbFreqOffset(UINT32 bspChn, UINT32 dir, UINT32 carrNo, INT32* offset)
* 功能描述: 获取NB inband、guardband模式下 上下行载波频点偏移量
* 输入参数:
*   bspChn ：通道号
*   dir    ：方向
*   carrNo ：载波号
* 输出参数:
*   offset ：偏移量
* 返 回 值: BSP_OK / BSP_ERROR
************************************************************************************/
UINT32 BspGetNbFreqOffset(UINT32 bspChn, UINT32 dir, UINT32 carrNo, INT32* offset)
{
    if(bspChn >= BSP_MAX_RX_CHAN)
    {
        return BSP_ERROR;
    }
    if(carrNo >= BSP_MAX_CARR_NUM)
    {
        return BSP_ERROR;
    }
    if(TX == dir)
    {
        *offset = s_ulNbTxFreqOffset[bspChn][carrNo];
    }
    else
    {
        //coverity[cert_int32_c_violation:SUPPRESS]
        *offset =  -1*s_ulNbRxFreqOffset[bspChn][carrNo];
    }
    dbgInfoEx("bspChn =%d,carrNo = %d dir=%d offset%d\n", bspChn, carrNo,dir,*offset);

    return BSP_OK;
}

VOID BspSetFixBandFreqFlag(UINT32 flag)
{
   s_fixrffreqflag = flag;
}

UINT32 BspGetFixBandFreqFlag(VOID)
{
    return s_fixrffreqflag;
}

UINT32 BspSetHandlePreLoReCfgFunc(pHandlePrePostLoReCfg func)
{
    pFuncHandlePreLoReCfg = func;
    return BSP_OK;
}

UINT32 BspSetHandlePostLoReCfgFunc(pHandlePrePostLoReCfg func)
{
    pFuncHandlePostLoReCfg = func;
    return BSP_OK;
}

UINT32 BspSetHandleReCfgLoFreqFunc(pHandleReCfgLoFreq func)
{
    pFuncHandleReCfgLoFreq = func;
    return BSP_OK;
}

#if 0
static T_MifCfgTbl *pMifCfgTbl = NULL;
static UINT32 g_MifCfgTblSize = 0;

T_MifCfgTbl * BspGetMifCfgTbl(VOID)
{
    return pMifCfgTbl;
}
UINT32 BspGetMifCfgTblSize(VOID)
{
    return g_MifCfgTblSize;
}
UINT32 BspSetMifCfgTbl(T_MifCfgData*ptMifCfgData,UINT32 mifCfgDataSize)
{
    INPUT_POINTER_CHECK(ptMifCfgData);

    g_MifCfgTblSize = mifCfgDataSize;
    pMifCfgTbl=ptMifCfgData;

    return BSP_OK;
}
#endif
static T_DPD_UL_FB_BAND_NCO_INFO *s_pBandNco = NULL;
 T_DPD_UL_FB_BAND_NCO_INFO s_alBandNcoFreq_BandNco[] =
{
    {{  0, 0, 0, 0,  0, 0, 0, 0}},  //UL
    {{  0, 0, 0, 0,  0, 0, 0, 0}},  //DL
    {{  0, 0, 0, 0,  0, 0, 0, 0}},  //PRX
};
UINT32 BspBandNcoFreqInit(VOID)
{
    s_pBandNco  = s_alBandNcoFreq_BandNco;
    return BSP_OK;
}

T_DPD_UL_FB_BAND_NCO_INFO *BspGetDpdUlFbBandNco(VOID)
{
    return s_pBandNco;
}
static UINT32 g_FreqNcoConstFlag = 0;
VOID setFreqNcoConstFlag(UINT32 flag)
{
    g_FreqNcoConstFlag = flag;
}

UINT32 getFreqNcoConstFlag(VOID)
{
    return g_FreqNcoConstFlag;
}

static UINT32 g_getrecalLoFlag[2][32] = {0,};
VOID setNeedRecalLoFlag(UINT32 dir, UINT32 chan, UINT32 flag)
{
    g_getrecalLoFlag[dir][chan] = flag;
}
UINT32 getNeedRecalLoFlag(UINT32 dir, UINT32 chan)
{
    return g_getrecalLoFlag[dir][chan];
}

static UINT32 g_RxOpenLoopPowCailtFlag = 0;
VOID setRxOpenLoopPowCailtFlag(UINT32 flag)
{
       g_RxOpenLoopPowCailtFlag = flag;
}

UINT32 getRxOpenLoopPowCailtFlag()
{
    return g_RxOpenLoopPowCailtFlag;
}


UINT32 g_FreqFbBandFlag[MAX_TX_CHANNEL] = {0};
VOID setFreqFbBandFlag(UINT32 bspChan,UINT32 flag)
{
    g_FreqFbBandFlag[bspChan] = flag;
}
UINT32 getFreqFbBandFlag(UINT32 bspChan)
{
    return g_FreqFbBandFlag[bspChan];
}

UINT32 BspSetCfrCarrInfoFlag(UINT32 cfrCarrInfoFlag)
{
    s_ulCfrCarrInfoFlag = cfrCarrInfoFlag;
    return BSP_OK;
}
UINT32 BspGetCfrCarrInfoFlag(VOID)
{
    return s_ulCfrCarrInfoFlag;
}

static T_MifCfgTbl MifCfgTbl = {0,};
static UINT32 g_MifCfgInitFlag = 0;
static UINT32 s_uBandStub = 0;
//static UINT32 g_MifCfgMode = 0;

T_MifCfgTbl * BspGetMifCfgTbl(VOID)
{
    T_MifCfgTbl *ptRet = NULL;

    if(g_MifCfgInitFlag == 1)
    {
        ptRet = &MifCfgTbl;
    }
    return ptRet;
}
UINT32 BspSetMifCfgTbl(T_MifCfgData*ptMifCfgData,UINT32 mifCfgDataSize)
{
    INPUT_POINTER_CHECK(ptMifCfgData);

    MifCfgTbl.mifCfgData=ptMifCfgData;
    MifCfgTbl.mifCfgCarrNum = mifCfgDataSize;

    g_MifCfgInitFlag = 1;
    return BSP_OK;
}
#if 0
UINT32 BspSetMifCfgMode(UINT32 ulMode)
{
    g_MifCfgMode = ulMode;
    return BSP_OK;
}
UINT32 BspGetMifCfgMode(VOID)
{
    return g_MifCfgMode;
}
#endif
/* ulCfgFlag: 0- BBU AUTO CFG, 1- DBG MANU CFG */
UINT32 BspSetRfCfgDbgManuCfgFlag(UINT32 ulTrxType, UINT32 ulCfgFlag)
{
    s_aulRfCfgDbgManuCfgFlag[ulTrxType % 2] = ulCfgFlag;

//  dbgInfo("%s>>Trx'%d CfgFlag(0:BbuAuto 1:DbgManu)= %d\n", __FUNCTION__,
//          ulTrxType, s_aulRfCfgDbgManuCfgFlag[ulTrxType % 2]);

    return BSP_OK;
}

/* Return: 0- BBU AUTO CFG, 1- DBG MANU CFG */
UINT32 BspGetRfCfgDbgManuCfgFlag(UINT32 ulTrxType)
{
    UINT32 ulManuCfgFlag = 0;

    ulManuCfgFlag = s_aulRfCfgDbgManuCfgFlag[ulTrxType % 2];
//  dbgInfo("%s>>Trx'%d CfgFlag(0:BbuAuto 1:DbgManu)= %d\n",
//          __FUNCTION__, ulTrxType, ulManuCfgFlag);

    return ulManuCfgFlag;
}

pGetRfFreqRange BspGetFilterRangeFreqCallBack(VOID)
{
   return pGetFilterRangeFreq;
}

UINT32 BspSetFilterRangeFreqCallBack(pGetRfFreqRange pCallBackFunc)
{
    pGetFilterRangeFreq = pCallBackFunc;

   return BSP_OK;
}

pGetRfBandFreqRange BspGetBandFilterRangeFreqCallBack(VOID)
{
    return pGetFilterBandFreq;
}

UINT32 BspSetBandFilterRangeFreqCallBack(pGetRfBandFreqRange pCallBackFunc)
{
    pGetFilterBandFreq = pCallBackFunc;
    return BSP_OK;
}

UINT32 BspGetChnBndCallBack(pGetChnBndMap pCallBackFunc)
{
    BspGetChnBandMap = pCallBackFunc;
    return BSP_OK;
}

pGetRfFreqNcoStep BspGetRfFreqNcoStepCallBack(VOID)
{
   return pGetRfCfgNcoStep;
}

UINT32 BspSetRfFreqNcoStepCallBack(pGetRfFreqNcoStep pCallBackFunc)
{
    pGetRfCfgNcoStep = pCallBackFunc;

   return BSP_OK;
}

pSetNbTxFreqOffset BspGetNbTxFreqOffsetCallBack(VOID)
{
   return pSetNbTxGuardOffset;
}

UINT32 BspSetNbTxFreqOffsetCallBack(pSetNbTxFreqOffset pCallBackFunc)
{
    pSetNbTxGuardOffset = pCallBackFunc;

   return BSP_OK;
}

pSetNbRxFreqOffset BspGetNbRxFreqOffsetCallBack(VOID)
{
   return pSetNbRxGuardOffset;
}

UINT32 BspSetNbRxFreqOffsetCallBack(pSetNbRxFreqOffset pCallBackFunc)
{
    pSetNbRxGuardOffset = pCallBackFunc;

   return BSP_OK;
}

pSetRfCfgBwpCall BspSetRfCfgBwpGetCallBack(VOID)
{
   return pSetRfCfgBwpFunc;
}

UINT32 BspSetRfCfgBwpSetCallBack(pSetRfCfgBwpCall pCallBackFunc)
{
    pSetRfCfgBwpFunc = pCallBackFunc;

   return BSP_OK;
}

UINT32 BspSetFixedBandLoFreqCallBack(pGetFixedBandLoFreq pCallBackFunc)
{
    pGetFixedBandLoFreqFunc = pCallBackFunc;

   return BSP_OK;
}


/* Started by AICoder, pid:we84d5a79cke55014d240903b07417147cb06beb */
pGetLoFreqBlackout BspGetLoFreqBlackoutCallBack(VOID)
{
    return pGetLoFreqBlackoutFunc;
}

UINT32 BspSetLoFreqBlackoutCallBack(pGetLoFreqBlackout pCallBackFunc)
{
    pGetLoFreqBlackoutFunc = pCallBackFunc;
    return BSP_OK;
}
/* Ended by AICoder, pid:we84d5a79cke55014d240903b07417147cb06beb */

pGetRfCfgBwpCall BspGetRfCfgBwpGetCallBack(VOID)
{
   return pGetRfCfgBwpFunc;
}

UINT32 BspGetRfCfgBwpSetCallBack(pGetRfCfgBwpCall pCallBackFunc)
{
    pGetRfCfgBwpFunc = pCallBackFunc;

   return BSP_OK;
}

UINT32 BspGetPllFreqCallback(__BspBoardLoFreqDef pFunc)
{
    INPUT_POINTER_CHECK(pFunc);
    if(pFreqGetPllFreq == NULL)
    {
        pFreqGetPllFreq = pFunc;
    }

    return BSP_OK;
}

UINT32 BspFreqGetBoardLofCallback(__BspBoardLoFreqDef pFunc)
{
    INPUT_POINTER_CHECK(pFunc);
    _BoardLoFreqDef = pFunc;
    return BSP_OK;
}

UINT32 BspGetIbwObwSpeicalCfg(VOID)
{
    return s_filterIbwObwSpecialCfg;
}

UINT32 BspSetIbwObwSpeicalCfg(UINT32 cfg)
{
    return s_filterIbwObwSpecialCfg = cfg;
}

UINT32 BspSetFreqRepairLoFreqShowCallBack(FUNC_FREQ_GET_FLAG pCallBackFunc)
{
    pFuncRepairLoFreqShowFlag = pCallBackFunc;
    return BSP_OK;
}

#if 0
UINT32 BspIfIbwObwNeedSpecialCfg()
{
    UINT32 ulTrxDir = 1;//TX
    UINT32 ulBspChnl =0;
    UINT32 pulMinFreq = 0;
    UINT32 pulMaxFreq = 0;

    if(BSP_OK != BspGetFilterFreqRange(ulTrxDir, ulBspChnl, &pulMinFreq, &pulMaxFreq))
    {
        dbgErr("%s:GetFilterRangeError!\n", __FUNCTION__);
         return BSP_ERROR;
    }

    if(pulMaxFreq - pulMinFreq > 160000)
    {
        return BSP_OK;
    }

   return BSP_ERROR;
}
#endif

UINT32 BspSetRfCfgBwp(UINT32 ulBwpKHz)
{
    UINT32 ulFuncRet = BSP_OK;
    pSetRfCfgBwpCall pSetBwpFunc = NULL;

    pSetBwpFunc = BspSetRfCfgBwpGetCallBack();
    if (NULL != pSetBwpFunc)
    {
        BspSetBwpCfgFlowFlag(0, 32, 0);
        ulFuncRet = pSetBwpFunc(ulBwpKHz);
    }

    return ulFuncRet;
}

UINT32 BspGetRfCfgBwp(VOID)
{
    UINT32 ulBwpKHz = 0;
    pGetRfCfgBwpCall pGetBwpFunc = NULL;

    pGetBwpFunc = BspGetRfCfgBwpGetCallBack();
    if (NULL != pGetBwpFunc)
    {
        ulBwpKHz = pGetBwpFunc();
        if (0 == ulBwpKHz)
        {
            ulBwpKHz = BSP_ERROR;
        }
    }
    else
    {
        ulBwpKHz = BSP_ERROR;
    }

    return ulBwpKHz;
}

UINT32 BspSetBwpCfgFlowFlag(UINT32 ulSetType, UINT32 ulChkBitOff, UINT32 ulSetBitOff)
{
    UINT32 ulChkCmpFlag = 0;
    UINT32 ulModifyFlag = 0;

    ulChkCmpFlag = (s_ulRfCfgBwpSetFlowFlag >> ulChkBitOff) & 0x01;
    if (ulChkBitOff > 31)
    {
        ulModifyFlag = 1;
    }
    else if (0x01 == ulChkCmpFlag)
    {
        ulModifyFlag = 1;
    }
    else
    {
        ulModifyFlag = 0;
    }

    if (1 == ulModifyFlag)
    {
        if (0 == ulSetType)
        {
            s_ulRfCfgBwpSetFlowFlag = BIT_SET(ulSetBitOff);
        }
        else if (1 == ulSetType)
        {
            s_ulRfCfgBwpSetFlowFlag |= BIT_SET(ulSetBitOff);
        }
        else
        {
            s_ulRfCfgBwpSetFlowFlag &= BIT_REV(ulSetBitOff);
        }
    }

    return BSP_OK;
}

static UINT32 NewCarrInfo(T_RfCfgPara *dst, T_RfCfgPara *src)
{
    UINT32 maxCarrNum = BspGetBspCarrNum();
    dst->carrInfo = (T_CarrInfo *)malloc(maxCarrNum*sizeof(T_CarrInfo));
    if (dst->carrInfo == NULL)
    {
        return BSP_ERROR;
    }
    memcpy(dst->carrInfo,src->carrInfo,src->carrNum*sizeof(T_CarrInfo));
    dst->carrNum = src->carrNum;
    return BSP_OK;
}

T_ChanRfCfgPara *GetRfCfgPara(UINT32 bspChan,UINT32 dir)
{
    T_ChanRfCfgPara *pRfCfg = pRfCfgHead;

    while (pRfCfg)
    {
        if (bspChan == pRfCfg->bspChan && dir == pRfCfg->dir)
        {
            return pRfCfg;
        }
        pRfCfg = pRfCfg->next;
    }

    return NULL;
}

T_ChanRfCfgPara *GetRfCfgPara_original(UINT32 bspChan,UINT32 dir)
{
    T_ChanRfCfgPara *pRfCfg = pRfCfgHead_original;

    while (pRfCfg)
    {
        if (bspChan == pRfCfg->bspChan && dir == pRfCfg->dir)
        {
            return pRfCfg;
        }
        pRfCfg = pRfCfg->next;
    }
    dbgInfo("%s>>BspChnl'%d Dir'%d\n",__FUNCTION__, bspChan, dir);
    return NULL;
}

T_ChanRfCfgPara *AddRfCfgPara(UINT32 bspChan,UINT32 dir,T_RfCfgPara *pRfCfgPara)
{
    T_ChanRfCfgPara *pRfCfg = pRfCfgHead;
    T_ChanRfCfgPara *pTemp = NULL;

    while (pRfCfg)
    {
        if (bspChan == pRfCfg->bspChan && dir == pRfCfg->dir)
        {
            return pRfCfg;
        }
        if (pRfCfg->next == NULL)
        {
            break;
        }
        pRfCfg = pRfCfg->next;
    }

    /* 新分配 */
    pTemp = (T_ChanRfCfgPara *)malloc(sizeof(T_ChanRfCfgPara));
    if (pTemp == NULL)
    {
        return NULL;
    }
    memset(pTemp,0,sizeof(T_ChanRfCfgPara));

    if (pRfCfgHead == NULL)
    {
        pRfCfgHead = pTemp;
    }
    else
    {
        pRfCfg->next = pTemp;
    }

    pTemp->bspChan = bspChan;
    pTemp->dir     = dir;
    pTemp->centerFreq = BSP_ERROR;
    NewCarrInfo(&pTemp->para,pRfCfgPara);

    return pTemp;
}

static T_ChanRfCfgPara *AddRfCfgPara_original(UINT32 bspChan,UINT32 dir,T_RfCfgPara *pRfCfgPara)
{
    T_ChanRfCfgPara *pRfCfg = pRfCfgHead_original;
    T_ChanRfCfgPara *pTemp = NULL;

    while (pRfCfg)
    {
        if (bspChan == pRfCfg->bspChan && dir == pRfCfg->dir)
        {
            return pRfCfg;
        }
        if (pRfCfg->next == NULL)
        {
            break;
        }
        pRfCfg = pRfCfg->next;
    }

    /* 新分配 */
    pTemp = (T_ChanRfCfgPara *)malloc(sizeof(T_ChanRfCfgPara));
    if (pTemp == NULL)
    {
        return NULL;
    }
    memset(pTemp,0,sizeof(T_ChanRfCfgPara));

    if (pRfCfgHead_original == NULL)
    {
        pRfCfgHead_original = pTemp;
    }
    else
    {
        pRfCfg->next = pTemp;
    }

    pTemp->bspChan = bspChan;
    pTemp->dir     = dir;
    pTemp->centerFreq = BSP_ERROR;
    NewCarrInfo(&pTemp->para,pRfCfgPara);

    dbgInfo("%s>>BspChnl'%d Dir'%d CarrSum  %d\n",__FUNCTION__, bspChan, dir, pRfCfgPara->carrNum);

    return pTemp;
}

UINT32 BspAddRfCfgPara(UINT32 bspChan, UINT32 dir, T_RfCfgPara *pRfCfgPara)
{
    UINT32 maxCarrNum = BspGetBspCarrNum();
    T_ChanRfCfgPara *pRfCfg = AddRfCfgPara(bspChan, dir, pRfCfgPara);
    INPUT_POINTER_CHECK(pRfCfg);

    pRfCfg->para.carrNum = pRfCfgPara->carrNum;

    if (NULL == pRfCfg->para.carrInfo)
    {
        dbgErr("%s>>Error! BspChnl'%d Dir'%d pCarrInfo cannot NULL!\n",
               __FUNCTION__, bspChan, dir);
        return BSP_ERROR;
    }

    if (pRfCfgPara->carrNum > maxCarrNum)
    {
        dbgErr("%s>>Error! BspChnl'%d Dir'%d CarrSum Over! CarrSum(1~%d)= %d\n",
               __FUNCTION__, bspChan, dir, maxCarrNum, pRfCfgPara->carrNum);
        return BSP_ERROR;
    }

    memcpy(pRfCfg->para.carrInfo, pRfCfgPara->carrInfo, pRfCfgPara->carrNum * sizeof(T_CarrInfo));
    dbgInfoEx("%s>>BspChnl'%d Dir'%d CarrSum  %d\n",__FUNCTION__, bspChan, dir, pRfCfgPara->carrNum);
    return BSP_OK;
}

UINT32 BspAddRfCfgPara_original(UINT32 bspChan, UINT32 dir, T_RfCfgPara *pRfCfgPara)
{
    UINT32 maxCarrNum = BspGetBspCarrNum();
    T_ChanRfCfgPara *pRfCfg = AddRfCfgPara_original(bspChan, dir, pRfCfgPara);
    INPUT_POINTER_CHECK(pRfCfg);

    pRfCfg->para.carrNum = pRfCfgPara->carrNum;

    if (NULL == pRfCfg->para.carrInfo)
    {
        dbgErr("%s>>Error! BspChnl'%d Dir'%d pCarrInfo cannot NULL!\n",
               __FUNCTION__, bspChan, dir);
        return BSP_ERROR;
    }

    if (pRfCfgPara->carrNum > maxCarrNum)
    {
        dbgErr("%s>>Error! BspChnl'%d Dir'%d CarrSum Over! CarrSum(1~%d)= %d\n",
               __FUNCTION__, bspChan, dir, maxCarrNum, pRfCfgPara->carrNum);
        return BSP_ERROR;
    }

    memcpy(pRfCfg->para.carrInfo, pRfCfgPara->carrInfo, pRfCfgPara->carrNum * sizeof(T_CarrInfo));
    dbgInfo("%s>>BspChnl'%d Dir'%d CarrSum  %d\n",__FUNCTION__, bspChan, dir, pRfCfgPara->carrNum);
    return BSP_OK;
}

T_RfCfgPara * BspGetRfCfgPara(UINT32 bspChan, UINT32 dir)
{
    T_ChanRfCfgPara *pChanRfCfg = GetRfCfgPara(bspChan,dir);
    if (pChanRfCfg == NULL)
    {
        return NULL;
    }
    return (T_RfCfgPara *)&(pChanRfCfg->para);
}

static T_DestCarrInfoAllChans *BspGetCarrInfoAllChansCmmn(void)
{
    if (gCarrInfoAllChans_Cmmn == NULL)
    {
        gCarrInfoAllChans_Cmmn = (T_DestCarrInfoAllChans *)malloc(sizeof(T_DestCarrInfoAllChans));
        if (gCarrInfoAllChans_Cmmn == NULL)
        {
            return NULL;
        }
        memset_s(gCarrInfoAllChans_Cmmn, sizeof(T_DestCarrInfoAllChans), 0, sizeof(T_DestCarrInfoAllChans));
    }
    return gCarrInfoAllChans_Cmmn;
}

static VOID setcarrin()
{
    T_DestCarrInfoAllChans *carrInfoAllChn = BspGetCarrInfoAllChansCmmn();
    if (carrInfoAllChn == NULL)
    {
        return;
    }
    memset_s(carrInfoAllChn,sizeof(T_DestCarrInfoAllChans),0,sizeof(T_DestCarrInfoAllChans));
    if(trbcase == 0){
        carrInfoAllChn->txCarrInfo[2].carrInfo[0].carrNo =0;
        carrInfoAllChn->txCarrInfo[2].carrInfo[0].radioMode = 1;
        carrInfoAllChn->txCarrInfo[2].carrInfo[0].freq = 940000;
        carrInfoAllChn->txCarrInfo[2].carrInfo[0].bandWidth = 5000;
        carrInfoAllChn->txCarrInfo[2].carrInfo[0].cellid = 0;
        carrInfoAllChn->txCarrInfo[2].carrNum = 1;

        carrInfoAllChn->rxCarrInfo[6].carrInfo[0].carrNo =0;
        carrInfoAllChn->rxCarrInfo[6].carrInfo[0].radioMode = 1;
        carrInfoAllChn->rxCarrInfo[6].carrInfo[0].freq = 895000;
        carrInfoAllChn->rxCarrInfo[6].carrInfo[0].bandWidth = 5000;
        carrInfoAllChn->rxCarrInfo[6].carrInfo[0].cellid = 0;
        carrInfoAllChn->rxCarrInfo[6].carrNum = 1;

        carrInfoAllChn->rxCarrInfo[7].carrInfo[0].carrNo =0;
        carrInfoAllChn->rxCarrInfo[7].carrInfo[0].radioMode = 1;
        carrInfoAllChn->rxCarrInfo[7].carrInfo[0].freq = 900000;
        carrInfoAllChn->rxCarrInfo[7].carrInfo[0].bandWidth = 5000;
        carrInfoAllChn->rxCarrInfo[7].carrNum = 1;
        carrInfoAllChn->rxCarrInfo[7].carrInfo[0].cellid = 1;

        carrInfoAllChn->txCarrInfo[3].carrInfo[0].carrNo =0;
        carrInfoAllChn->txCarrInfo[3].carrInfo[0].radioMode = 1;
        carrInfoAllChn->txCarrInfo[3].carrInfo[0].freq = 945000;
        carrInfoAllChn->txCarrInfo[3].carrInfo[0].bandWidth = 5000;
        carrInfoAllChn->txCarrInfo[3].carrNum = 1;
        carrInfoAllChn->txCarrInfo[3].carrInfo[0].cellid = 1;
    }

    if(trbcase ==1){
        carrInfoAllChn->rxCarrInfo[3].carrInfo[0].carrNo =0;
        carrInfoAllChn->rxCarrInfo[3].carrInfo[0].radioMode = 1;
        carrInfoAllChn->rxCarrInfo[3].carrInfo[0].freq = 900000;
        carrInfoAllChn->rxCarrInfo[3].carrInfo[0].bandWidth = 5000;
        carrInfoAllChn->rxCarrInfo[3].carrNum = 1;
        carrInfoAllChn->txCarrInfo[3].carrInfo[0].cellid = 0;

        carrInfoAllChn->txCarrInfo[2].carrInfo[0].carrNo =0;
        carrInfoAllChn->txCarrInfo[2].carrInfo[0].radioMode = 1;
        carrInfoAllChn->txCarrInfo[2].carrInfo[0].freq = 940000;
        carrInfoAllChn->txCarrInfo[2].carrInfo[0].bandWidth = 5000;
        carrInfoAllChn->txCarrInfo[2].carrInfo[0].cellid = 0;
        carrInfoAllChn->txCarrInfo[2].carrNum = 1;
    }
    if(trbcase ==2){
        carrInfoAllChn->txCarrInfo[2].carrInfo[0].carrNo =0;
        carrInfoAllChn->txCarrInfo[2].carrInfo[0].radioMode = 1;
        carrInfoAllChn->txCarrInfo[2].carrInfo[0].freq = 940000;
        carrInfoAllChn->txCarrInfo[2].carrInfo[0].bandWidth = 5000;
        carrInfoAllChn->txCarrInfo[2].carrInfo[0].cellid = 0;
        carrInfoAllChn->txCarrInfo[2].carrNum = 1;

        carrInfoAllChn->rxCarrInfo[6].carrInfo[0].carrNo =0;
        carrInfoAllChn->rxCarrInfo[6].carrInfo[0].radioMode = 1;
        carrInfoAllChn->rxCarrInfo[6].carrInfo[0].freq = 895000;
        carrInfoAllChn->rxCarrInfo[6].carrInfo[0].bandWidth = 5000;
        carrInfoAllChn->rxCarrInfo[6].carrInfo[0].cellid = 0;
        carrInfoAllChn->rxCarrInfo[6].carrNum = 2;

        carrInfoAllChn->rxCarrInfo[7].carrInfo[0].carrNo =0;
        carrInfoAllChn->rxCarrInfo[7].carrInfo[0].radioMode = 1;
        carrInfoAllChn->rxCarrInfo[7].carrInfo[0].freq = 895000;
        carrInfoAllChn->rxCarrInfo[7].carrInfo[0].bandWidth = 5000;
        carrInfoAllChn->rxCarrInfo[7].carrNum = 2;
        carrInfoAllChn->rxCarrInfo[7].carrInfo[0].cellid = 0;

        carrInfoAllChn->txCarrInfo[3].carrInfo[0].carrNo =1;
        carrInfoAllChn->txCarrInfo[3].carrInfo[0].radioMode = 1;
        carrInfoAllChn->txCarrInfo[3].carrInfo[0].freq = 945000;
        carrInfoAllChn->txCarrInfo[3].carrInfo[0].bandWidth = 5000;
        carrInfoAllChn->txCarrInfo[3].carrNum = 1;
        carrInfoAllChn->txCarrInfo[3].carrInfo[0].cellid = 1;

        carrInfoAllChn->rxCarrInfo[6].carrInfo[1].carrNo =1;
        carrInfoAllChn->rxCarrInfo[6].carrInfo[1].radioMode = 1;
        carrInfoAllChn->rxCarrInfo[6].carrInfo[1].freq = 900000;
        carrInfoAllChn->rxCarrInfo[6].carrInfo[1].bandWidth = 5000;
        carrInfoAllChn->rxCarrInfo[6].carrInfo[1].cellid = 1;

        carrInfoAllChn->rxCarrInfo[7].carrInfo[1].carrNo =1;
        carrInfoAllChn->rxCarrInfo[7].carrInfo[1].radioMode = 1;
        carrInfoAllChn->rxCarrInfo[7].carrInfo[1].freq = 900000;
        carrInfoAllChn->rxCarrInfo[7].carrInfo[1].bandWidth = 5000;
        carrInfoAllChn->rxCarrInfo[7].carrInfo[1].cellid = 1;
    }
    carrInfoAllChn->txChanNum = 4;
    carrInfoAllChn->rxChanNum = 8;
}

UINT32 BspSetRfCfgFreqCarrInfo(T_DestCarrInfoAllChans *pCarrInfoAllChans)
{
    errno_t errNo;
    T_DestCarrInfoAllChans *carrInfoAllChn = BspGetCarrInfoAllChansCmmn();

    if(NULL == pCarrInfoAllChans || carrInfoAllChn == NULL)
    {
        return BSP_ERROR;
    }
    //coverity[cert_pre31_c_violation:SUPPRESS]
    BspLog(LOG_LEVEL_0,"%s:%p enter\n",__FUNCTION__,pCarrInfoAllChans);
    errNo=memcpy_s(carrInfoAllChn,sizeof(T_DestCarrInfoAllChans),pCarrInfoAllChans,sizeof(T_DestCarrInfoAllChans));
    CHECK_RET_WARNING(errNo, "memcpy_s gCarrInfoAllChans_Cmmn errNo:%d", errNo);

    return BSP_OK;
}

UINT32 BspGetRfChCfgFreqCarrInfo(UINT32 bspChan, UINT32 dir,UINT32 rfmode ,UINT32 carrno)
{
    T_DestCarrInfoChan  *chancarrinfo = NULL;
    UINT32 i = 0;
    T_DestCarrInfoAllChans *carrInfoAllChn = BspGetCarrInfoAllChansCmmn();

    if(bspChan >= BSP_MAX_CHAN_NUM || carrInfoAllChn == NULL)
    {
        return BSP_ERROR;
    }

    if(dir == RX)
    {
        chancarrinfo = &(carrInfoAllChn->rxCarrInfo[bspChan]);
    }
    else
    {
        chancarrinfo = &(carrInfoAllChn->txCarrInfo[bspChan]);
    }

    for(i=0;i<chancarrinfo->carrNum;i++)
    {
        if((rfmode == chancarrinfo->carrInfo[i].radioMode)&& (carrno == chancarrinfo->carrInfo[i].carrNo))
        {
            return BSP_OK;
        }
    }

    return BSP_ERROR;
}


VOID BspGetRfCarrCfgInfo(UINT32 dir,UINT32 rfmode ,UINT32 carrno,UINT32 frq,UINT32 *chninfo,UINT32 *channum,UINT32 *cellid)
{
    T_DestCarrInfoChan  *chancarrinfo = NULL;
    UINT32 i = 0;
    UINT32 chnidx = 0;
    UINT32 chn = 0;
    T_DestCarrInfoAllChans *carrInfoAllChn = BspGetCarrInfoAllChansCmmn();

    if((NULL == chninfo) || (NULL == channum) || (carrInfoAllChn == NULL))
        return ;

    if(dir == RX)
    {
        chancarrinfo = carrInfoAllChn->rxCarrInfo;
        chn = BspGetRxChannel();
    }
    else
    {
        chancarrinfo = carrInfoAllChn->txCarrInfo;
        chn = BspGetTxChannel();
    }

    for(chnidx=0;chnidx<chn;chnidx++)
    {
        if(chancarrinfo[chnidx].carrNum > BSP_MAX_CARR_NUM)
            break;
        for(i=0;i<chancarrinfo[chnidx].carrNum;i++)
        {
            if((rfmode == chancarrinfo[chnidx].carrInfo[i].radioMode)&& (carrno == chancarrinfo[chnidx].carrInfo[i].carrNo)\
                &&(frq == chancarrinfo[chnidx].carrInfo[i].freq))
            {
                *(chninfo++) = chnidx;
                *channum = *channum+(UINT32)1;
                *cellid = chancarrinfo[chnidx].carrInfo[i].cellid;
                if(*channum > (UINT32)BSP_MAX_CHAN_NUM)
                    return;
            }
        }
    }

    return;
}

VOID BspGetRfCarrCfgInfoByCellId(UINT32 dir,UINT32 rfmode ,UINT32 carrno,UINT32 cellid,UINT32 *chninfo,UINT32 *channum)
{
    T_DestCarrInfoChan  *chancarrinfo = NULL;
    UINT32 i = 0;
    UINT32 chnidx = 0;
    UINT32 chn = 0;
    T_DestCarrInfoAllChans *carrInfoAllChn = BspGetCarrInfoAllChansCmmn();

    if((NULL == chninfo) || (NULL == channum)|| (0xff == cellid) || (carrInfoAllChn == NULL))
        return ;

    if(dir == RX)
    {
        chancarrinfo = carrInfoAllChn->rxCarrInfo;
        chn = BspGetRxChannel();
    }
    else
    {
        chancarrinfo = carrInfoAllChn->txCarrInfo;
        chn = BspGetTxChannel();
    }

    for(chnidx=0;chnidx<chn;chnidx++)
    {
        if(chancarrinfo[chnidx].carrNum > BSP_MAX_CARR_NUM)
            break;
        for(i=0;i<chancarrinfo[chnidx].carrNum;i++)
        {
            if((rfmode == chancarrinfo[chnidx].carrInfo[i].radioMode)&& (carrno == chancarrinfo[chnidx].carrInfo[i].carrNo)\
                &&(cellid == chancarrinfo[chnidx].carrInfo[i].cellid))
            {
                *(chninfo++) = chnidx;
                *channum = *channum+(UINT32)1;
                if(*channum > (UINT32)BSP_MAX_CHAN_NUM)
                    return;
            }
        }
    }

    return;
}


UINT32 BspRecordLoFreq(UINT32 dir, UINT32 bspChan, UINT32 freq)
{
    T_ChanRfCfgPara *pRfCfg;
    UINT32 chanNum = (dir == TX) ? BspGetTxBspChanNum() : BspGetRxBspChanNum();

    if (bspChan >= chanNum)
    {
        return BSP_ERROR;
    }

    pRfCfg = GetRfCfgPara(bspChan,dir);
    if (pRfCfg == NULL)
    {
        return BSP_ERROR;
    }

    pRfCfg->rfpllFreq = freq;
//  dbgInfo("%s>Trx'%d Chnl'%d RecLoFreq= %d\n", __FUNCTION__,
//          dir, bspChan, pRfCfg->rfpllFreq);

    return BSP_OK;
}

UINT32 BspRecordCenterFreq(UINT32 dir, UINT32 bspChan, UINT32 freq)
{
    T_ChanRfCfgPara *pRfCfg;
    UINT32 chanNum = (dir == TX) ? BspGetTxBspChanNum() : BspGetRxBspChanNum();

    if (bspChan >= chanNum)
    {
        return BSP_ERROR;
    }

    pRfCfg = GetRfCfgPara(bspChan,dir);
    if (pRfCfg == NULL)
    {
        return BSP_ERROR;
    }

    pRfCfg->centerFreq = freq;
    return BSP_OK;
}

UINT32 BspGetCenterFreq(UINT32 dir, UINT32 chan)
{
    T_ChanRfCfgPara *pRfCfg;
    UINT32 bspChan = 0;
    UINT32 chanNum = (dir == TX) ? BspGetTxBspChanNum() : BspGetRxBspChanNum();

    if (chan >= chanNum)
    {
        return BSP_ERROR;
    }
    if (BspGetBspChnByRfChn(chan,dir,&bspChan) != BSP_OK)
    {
        return BSP_ERROR;
    }

    pRfCfg = GetRfCfgPara(bspChan,dir);
    if (pRfCfg == NULL)
    {
        return BSP_ERROR;
    }

    return pRfCfg->centerFreq;
}

UINT32 BspGetRfCfgCarrSum(UINT32 dir, UINT32 chan)
{
    UINT32 bspChan = 0;
    UINT32 ulMaxCarrSum = 0;
    UINT32 retVal = BSP_OK;
    T_ChanRfCfgPara *pRfCfg;
    const CHAR *pChDirNameStr = NULL;
    T_RruRfCfgInfo tRruCfgInfo = {0};
    UINT32 chanNum = (dir == TX) ? BspGetTxBspChanNum() : BspGetRxBspChanNum();

    CHNL_DIR_TYPE_NAME_STR(dir, pChDirNameStr);

    if (chan >= chanNum)
    {
        dbgErr("%s>>Error! ParamChnl Over! %sChnl(0~%d)= %d\n",
               __FUNCTION__, pChDirNameStr, chanNum - 1, chan);
        return BSP_ERROR;
    }
    if (BspGetBspChnByRfChn(chan, dir, &bspChan) != BSP_OK)
    {
        dbgErr("%s>>%sChnl'%d BspChnl Get Error!\n",
               __FUNCTION__, pChDirNameStr, chan);
        return BSP_ERROR;
    }

    pRfCfg = GetRfCfgPara(bspChan, dir);
    if (pRfCfg == NULL)
    {
        dbgInfoEx("%s>>%sChnl'%d RfCfgParam Get Error!\n",
               __FUNCTION__, pChDirNameStr, chan);
        return BSP_ERROR;
    }

#if (1)
    ulMaxCarrSum = BspGetBspCarrNum();
    BspGetChnlCfgCarrPara(chan, &tRruCfgInfo);
    retVal = BspChkRruCfgParamValid(dir, ulMaxCarrSum, &tRruCfgInfo);
    if(retVal != BSP_OK)
    {
        dbgInfoEx("%s>>Error! %sChnl'%d RfCfgParam Invalid!\n",
               __FUNCTION__, pChDirNameStr, chan);
        return BSP_ERROR;
    }
#endif

    return pRfCfg->para.carrNum;
}

UINT32 BspGetRfCfgCarrMode(UINT32 dir, UINT32 chan)
{
    UINT32 bspChan = 0;
    UINT32 ulMaxCarrSum = 0;
    UINT32 retVal = BSP_OK;
    T_ChanRfCfgPara *pRfCfg;
    const CHAR *pChDirNameStr = NULL;
    T_RruRfCfgInfo tRruCfgInfo = {0};
    UINT32 carrIndex = 0;
    UINT32 chanRadio = 0;
    UINT32 chanNum = (dir == TX) ? BspGetTxBspChanNum() : BspGetRxBspChanNum();

    CHNL_DIR_TYPE_NAME_STR(dir, pChDirNameStr);

    if (chan >= chanNum)
    {
        dbgErr("%s>>Error! ParamChnl Over! %sChnl(0~%d)= %d\n",
               __FUNCTION__, pChDirNameStr, chanNum - 1, chan);
        return BSP_ERROR;
    }
    if (BspGetBspChnByRfChn(chan, dir, &bspChan) != BSP_OK)
    {
        dbgErr("%s>>%sChnl'%d BspChnl Get Error!\n",
               __FUNCTION__, pChDirNameStr, chan);
        return BSP_ERROR;
    }

    pRfCfg = GetRfCfgPara(bspChan, dir);
    if (pRfCfg == NULL)
    {
        dbgErr("%s>>%sChnl'%d RfCfgParam Get Error!\n",
               __FUNCTION__, pChDirNameStr, chan);
        return BSP_ERROR;
    }

    ulMaxCarrSum = BspGetBspCarrNum();
    BspGetChnlCfgCarrPara(chan, &tRruCfgInfo);
    retVal = BspChkRruCfgParamValid(dir, ulMaxCarrSum, &tRruCfgInfo);
    if(retVal != BSP_OK)
    {
        dbgErr("%s>>Error! %sChnl'%d RfCfgParam Invalid!\n",
               __FUNCTION__, pChDirNameStr, chan);
        return BSP_ERROR;
    }
    for (carrIndex = 0; carrIndex < pRfCfg->para.carrNum; carrIndex++)
    {
         chanRadio |= pRfCfg->para.carrInfo[carrIndex].radioMode;
    }

    return chanRadio;
}

UINT32 BspGetFreqBw(UINT32 dir, UINT32 chan, UINT32 carrNo)
{
    UINT32 bspChan = 0;
    UINT32 carrIndex = 0;
    UINT32 retVal = BSP_OK;
    T_ChanRfCfgPara *pRfCfg;
    const CHAR *pChDirNameStr = NULL;
    T_RruRfCfgInfo tRruCfgInfo = {0};
    UINT32 chanNum = (dir == TX) ? BspGetTxBspChanNum() : BspGetRxBspChanNum();

    CHNL_DIR_TYPE_NAME_STR(dir, pChDirNameStr);
    if (chan >= chanNum)
    {
        dbgErr("%s>>Error! ParamChnl Over! %sChnl(0~%d)= %d\n",
               __FUNCTION__, pChDirNameStr, chanNum - 1, chan);
        return BSP_ERROR;
    }
    if (BspGetBspChnByRfChn(chan,dir,&bspChan) != BSP_OK)
    {
        dbgErr("%s>>%sChnl'%d Carr'%d BspChnl Get Error!\n",
               __FUNCTION__, pChDirNameStr, chan, carrNo);
        return BSP_ERROR;
    }

    pRfCfg = GetRfCfgPara(bspChan,dir);
    if (pRfCfg == NULL)
    {
        dbgErr("%s>>%sChnl'%d Carr'%d RfCfgParam Get Error!\n",
               __FUNCTION__, pChDirNameStr, chan, carrNo);
        return BSP_ERROR;
    }
#if (1)
    BspGetChnlCfgCarrPara(chan, &tRruCfgInfo);
    retVal = BspChkRruCfgParamValid(dir, carrNo, &tRruCfgInfo);
    if(retVal != BSP_OK)
    {
        dbgInfoEx("%s>>Error! %sChnl'%d Carr'%d RrufgParam Invalid!\n",
               __FUNCTION__, pChDirNameStr, chan, carrNo);
        return BSP_ERROR;
    }
#endif

    for (carrIndex = 0; carrIndex < pRfCfg->para.carrNum; carrIndex++)
    {
        if (carrNo == pRfCfg->para.carrInfo[carrIndex].carrNo)
            break;
    }
    if (carrIndex == pRfCfg->para.carrNum)
    {
        dbgInfoEx("%s>>Error! %sChnl'%d Carr'%d RfCfgParam Invalid!\n",
                     __FUNCTION__, pChDirNameStr, chan, carrNo);
        return BSP_ERROR;
    }
    else
    {
        return pRfCfg->para.carrInfo[carrIndex].bandWidth;
    }
}

UINT32 BspGetCarrBwByRfCfg(UINT32 dir, UINT32 chan, UINT32 carrNo, UINT32 radioMode)
{
    UINT32 bspChan = 0;
    UINT32 carrIndex = 0;
    /*UINT32 retVal = BSP_OK;*/
    T_ChanRfCfgPara *pRfCfg = NULL;
    const CHAR *pChDirNameStr = NULL;
    UINT32 chanNum = (dir == TX) ? BspGetTxBspChanNum() : BspGetRxBspChanNum();

    CHNL_DIR_TYPE_NAME_STR(dir, pChDirNameStr);
    if (chan >= chanNum)
    {
        dbgErr("%s>>Error! ParamChnl Over! %sChnl(0~%d)= %d\n",
               __FUNCTION__, pChDirNameStr, chanNum - 1, chan);
        return BSP_ERROR;
    }
    if (BspGetBspChnByRfChn(chan,dir,&bspChan) != BSP_OK)
    {
        dbgErr("%s>>%sChnl'%d Carr'%d BspChnl Get Error!\n",
               __FUNCTION__, pChDirNameStr, chan, carrNo);
        return BSP_ERROR;
    }

    pRfCfg = GetRfCfgPara(bspChan,dir);
    INPUT_POINTER_CHECK(pRfCfg);

    for (carrIndex = 0; carrIndex < pRfCfg->para.carrNum; carrIndex++)
    {
        if (carrNo == pRfCfg->para.carrInfo[carrIndex].carrNo &&
            radioMode == pRfCfg->para.carrInfo[carrIndex].radioMode)
        {
            return pRfCfg->para.carrInfo[carrIndex].bandWidth;
        }
    }

    dbgInfoEx("%s>>Error! %sChnl'%d Carr'%d RfCfgParam Invalid!\n",
                 __FUNCTION__, pChDirNameStr, chan, carrNo);
    return BSP_ERROR;
}

UINT32 BspGetCarrBw(UINT32 dir, UINT32 chan, UINT32 carrNo, UINT32 radioMode)
{
    UINT32 bspChan = 0;
    UINT32 carrIndex = 0;
    UINT32 retVal = BSP_OK;
    T_ChanRfCfgPara *pRfCfg;
    const CHAR *pChDirNameStr = NULL;
    T_RruRfCfgInfo tRruCfgInfo = {0};
    UINT32 chanNum = (dir == TX) ? BspGetTxBspChanNum() : BspGetRxBspChanNum();

    CHNL_DIR_TYPE_NAME_STR(dir, pChDirNameStr);
    if (chan >= chanNum)
    {
        dbgErr("%s>>Error! ParamChnl Over! %sChnl(0~%d)= %d\n",
               __FUNCTION__, pChDirNameStr, chanNum - 1, chan);
        return BSP_ERROR;
    }
    if (BspGetBspChnByRfChn(chan,dir,&bspChan) != BSP_OK)
    {
        dbgErr("%s>>%sChnl'%d Carr'%d BspChnl Get Error!\n",
               __FUNCTION__, pChDirNameStr, chan, carrNo);
        return BSP_ERROR;
    }

    pRfCfg = GetRfCfgPara(bspChan,dir);
    INPUT_POINTER_CHECK(pRfCfg);

    BspGetChnlCfgCarrPara(chan, &tRruCfgInfo);
    retVal = BspChkRruCfgParamValid(dir, carrNo, &tRruCfgInfo);
    if(retVal != BSP_OK)
    {
        dbgErr("%s>>Error! %sChnl'%d Carr'%d RfCfgParam Invalid!\n",
               __FUNCTION__, pChDirNameStr, chan, carrNo);
        return BSP_ERROR;
    }

    for (carrIndex = 0; carrIndex < pRfCfg->para.carrNum; carrIndex++)
    {
        if (carrNo == pRfCfg->para.carrInfo[carrIndex].carrNo &&
            radioMode == pRfCfg->para.carrInfo[carrIndex].radioMode)
        {
            return pRfCfg->para.carrInfo[carrIndex].bandWidth;
        }
    }

    dbgErr("%s>>Error! %sChnl'%d Carr'%d RfCfgParam Invalid!\n",
                 __FUNCTION__, pChDirNameStr, chan, carrNo);
    return BSP_ERROR;
}

UINT32 BspGetCarrFreq(UINT32 dir, UINT32 chan, UINT32 carrNo)
{
    UINT32 bspChan = 0;
    UINT32 carrIndex = 0;
    UINT32 retVal = BSP_OK;
    T_ChanRfCfgPara *pRfCfg;
    const CHAR *pChDirNameStr = NULL;
    T_RruRfCfgInfo tRruCfgInfo = {0};
    UINT32 chanNum = (dir == TX) ? BspGetTxBspChanNum() : BspGetRxBspChanNum();

    CHNL_DIR_TYPE_NAME_STR(dir, pChDirNameStr);

    if (chan >= chanNum)
    {
        dbgErr("%s>>Error! ParamChnl Over! %sChnl(0~%d)= %d\n",
               __FUNCTION__, pChDirNameStr, chanNum - 1, chan);
        return BSP_ERROR;
    }
    if (BspGetBspChnByRfChn(chan,dir,&bspChan) != BSP_OK)
    {
        dbgErr("%s>>%sChnl'%d Carr'%d BspChnl Get Error!\n",
               __FUNCTION__, pChDirNameStr, chan, carrNo);
        return BSP_ERROR;
    }

    pRfCfg = GetRfCfgPara(bspChan,dir);
    if (pRfCfg == NULL)
    {
        dbgErr("%s>>%sChnl'%d Carr'%d RfCfgParam Get Error!\n",
               __FUNCTION__, pChDirNameStr, chan, carrNo);
        return BSP_ERROR;
    }

#if (1)
    BspGetChnlCfgCarrPara(chan, &tRruCfgInfo);
    retVal = BspChkRruCfgParamValid(dir, carrNo, &tRruCfgInfo);
    if(retVal != BSP_OK)
    {
        dbgInfoEx("%s>>Error! %sChnl'%d Carr'%d RrufgParam Invalid!\n",
               __FUNCTION__, pChDirNameStr, chan, carrNo);
        return BSP_ERROR;
    }
#endif

    for (carrIndex = 0; carrIndex < pRfCfg->para.carrNum; carrIndex++)
    {
        if (carrNo == pRfCfg->para.carrInfo[carrIndex].carrNo)
            break;
    }
    if (carrIndex == pRfCfg->para.carrNum)
    {
        dbgInfoEx("%s>>Error! %sChnl'%d Carr'%d RfCfgParam Invalid!\n",
                     __FUNCTION__, pChDirNameStr, chan, carrNo);
        return BSP_ERROR;
    }
    else
    {
        return pRfCfg->para.carrInfo[carrIndex].freq;
    }
}

UINT32 BspGetChanCarrFreq(UINT32 dir, UINT32 chan, UINT32 carrNo, UINT32 radioMode)
{
    UINT32 bspChan = 0;
    UINT32 carrIndex = 0;
    /* UINT32 retVal = BSP_OK; */
    T_ChanRfCfgPara *pRfCfg;
    const CHAR *pChDirNameStr = NULL;
    /* T_RruRfCfgInfo tRruCfgInfo = {0}; */
    UINT32 chanNum = (dir == TX) ? BspGetTxBspChanNum() : BspGetRxBspChanNum();

    CHNL_DIR_TYPE_NAME_STR(dir, pChDirNameStr);

    if (chan >= chanNum)
    {
        dbgErr("%s>>Error! ParamChnl Over! %sChnl(0~%d)= %d\n",
               __FUNCTION__, pChDirNameStr, chanNum - 1, chan);
        return BSP_ERROR;
    }
    if (BspGetBspChnByRfChn(chan,dir,&bspChan) != BSP_OK)
    {
        dbgErr("%s>>%sChnl'%d Carr'%d BspChnl Get Error!\n",
               __FUNCTION__, pChDirNameStr, chan, carrNo);
        return BSP_ERROR;
    }

    pRfCfg = GetRfCfgPara(bspChan,dir);
    INPUT_POINTER_CHECK(pRfCfg);
#if 0
    BspGetChnlCfgCarrPara(chan, &tRruCfgInfo);
    retVal = BspChkRruCfgParamValid(dir, carrNo, &tRruCfgInfo);
    if(retVal != BSP_OK)
    {
        dbgErr("%s>>Error! %sChnl'%d Carr'%d RfCfgParam Invalid!\n",
               __FUNCTION__, pChDirNameStr, chan, carrNo);
        return BSP_ERROR;
    }
#endif
    for (carrIndex = 0; carrIndex < pRfCfg->para.carrNum; carrIndex++)
    {
        if (carrNo == pRfCfg->para.carrInfo[carrIndex].carrNo &&
            radioMode == pRfCfg->para.carrInfo[carrIndex].radioMode)
        {
            return pRfCfg->para.carrInfo[carrIndex].freq;
        }
    }

    dbgErr("%s>>Error! %sChnl'%d Carr'%d RfCfgParam Invalid!\n",
                 __FUNCTION__, pChDirNameStr, chan, carrNo);
    return BSP_ERROR;
}

/*****************************************************************************
 * 函数名称: BspGetMultiCarrCenterFreq(*)
 * 功能描述: 获取所有载波的中心频点
 * 输入参数: ulTrxType - 通道类型, 0: RX, 1: TX
 *           ulChnl    - 通道号
 * 输出参数: 无
 * 返 回 值: 所有载波的中心频点; BSP_ERROR- 失败
 * 其它说明: 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10119095@2018-02-24, 创建
 *----------------------------------------------------------------------------
 */
UINT32 BspGetMultiCarrCenterFreq(UINT32 ulTrxType, UINT32 ulRfChnl)
{
    UINT32 ulBspChnl = 0;
    UINT32 ulCarrIdx = 0;
    UINT32 ulMaxChnlSum = 0;
    UINT32 ulMaxCarrSum = 0;
    UINT32 ulMinCarrNum = 0;
    UINT32 ulMaxCarrNum = 0;
    UINT32 ulMinBandFreq = 0;
    UINT32 ulMaxBandFreq = 0;
    UINT32 ulCarrCenterFreq = 0;
    UINT32 ulTmpRet = BSP_OK;
    const CHAR *pChDirNameStr = NULL;
    T_ChanRfCfgPara *pRfCfg = NULL;
    T_RruRfCfgInfo tRruCfgInfo = {0};

    CHNL_DIR_TYPE_NAME_STR(ulTrxType, pChDirNameStr);
    PARAM_OUTER_RANGE_CHK_WITH_RET(BSP_ERROR, ulTrxType, ulTrxType, RX, TX);

    ulMaxCarrSum = BspGetBspCarrNum();
    ulMaxChnlSum = (ulTrxType == TX) ? BspGetTxBspChanNum() : BspGetRxBspChanNum();
    if (ulRfChnl >= ulMaxChnlSum)
    {
        dbgInfoEx("%s>>Error! RfChnl Over! %sChnl(0~%d)= %d\n", __FUNCTION__,
               pChDirNameStr, ulMaxChnlSum - 1, ulRfChnl);
        return BSP_ERROR;
    }

    ulTmpRet = BspGetBspChnByRfChn(ulRfChnl, ulTrxType, &ulBspChnl);
    if (BSP_OK != ulTmpRet)
    {
        dbgInfoEx("%s>>%sChnl'%d BspChnl Get Error!\n",
               __FUNCTION__, pChDirNameStr, ulRfChnl);
        return BSP_ERROR;
    }

    pRfCfg = GetRfCfgPara(ulBspChnl, ulTrxType);
    if (NULL == pRfCfg)
    {
        dbgInfoEx("%s>>%sChnl'%d RfCfgParam Get Error!\n",
               __FUNCTION__, pChDirNameStr, ulRfChnl);
        return BSP_ERROR;
    }

    BspGetChnlCfgCarrPara(ulRfChnl, &tRruCfgInfo);
    ulTmpRet = BspChkRruCfgParamValid(ulTrxType, ulMaxCarrSum, &tRruCfgInfo);
    if (BSP_OK != ulTmpRet)
    {
        dbgInfoEx("%s>>Error! %sChnl'%d RfCfgParam Invalid!\n",
               __FUNCTION__, pChDirNameStr, ulRfChnl);
        return BSP_ERROR; /* 配置频点信息无效, 退出 */
    }

    ulMinCarrNum = 0;
    ulMaxCarrNum = 0;
    for (ulCarrIdx = 0; ulCarrIdx < pRfCfg->para.carrNum; ulCarrIdx++)
    {
        if ((0 == pRfCfg->para.carrInfo[ulCarrIdx].freq) || (BSP_ERROR == pRfCfg->para.carrInfo[ulCarrIdx].freq))
        {
            continue;
        }

        if (pRfCfg->para.carrInfo[ulMinCarrNum].freq > pRfCfg->para.carrInfo[ulCarrIdx].freq)
        {
            ulMinCarrNum = ulCarrIdx;
        }

        if (pRfCfg->para.carrInfo[ulMaxCarrNum].freq < pRfCfg->para.carrInfo[ulCarrIdx].freq)
        {
            ulMaxCarrNum = ulCarrIdx;
        }
    }

    ulMinBandFreq = pRfCfg->para.carrInfo[ulMinCarrNum].freq - pRfCfg->para.carrInfo[ulMinCarrNum].bandWidth / 2;
    ulMaxBandFreq = pRfCfg->para.carrInfo[ulMaxCarrNum].freq + pRfCfg->para.carrInfo[ulMaxCarrNum].bandWidth / 2;
    ulCarrCenterFreq = (ulMinBandFreq + ulMaxBandFreq) / 2;

    return ulCarrCenterFreq;
}

UINT32 BspGetMultiCarrMaxFreq(UINT32 ulTrxType, UINT32 ulRfChnl)
{
    UINT32 ulBspChnl = 0;
    UINT32 ulCarrIdx = 0;
    UINT32 ulMaxChnlSum = 0;
    UINT32 ulMaxCarrSum = 0;
    UINT32 ulMinCarrNum = 0;
    UINT32 ulMaxCarrNum = 0;
    /* UINT32 ulMinBandFreq = 0;
    UINT32 ulMaxBandFreq = 0;
    UINT32 ulCarrCenterFreq = 0; */
    UINT32 ulTmpRet = BSP_OK;
    const CHAR *pChDirNameStr = NULL;
    T_ChanRfCfgPara *pRfCfg = NULL;
    T_RruRfCfgInfo tRruCfgInfo = {0};

    CHNL_DIR_TYPE_NAME_STR(ulTrxType, pChDirNameStr);
    PARAM_OUTER_RANGE_CHK_WITH_RET(BSP_ERROR, ulTrxType, ulTrxType, RX, TX);

    ulMaxCarrSum = BspGetBspCarrNum();
    ulMaxChnlSum = (ulTrxType == TX) ? BspGetTxBspChanNum() : BspGetRxBspChanNum();
    if (ulRfChnl >= ulMaxChnlSum)
    {
        dbgErr("%s>>Error! RfChnl Over! %sChnl(0~%d)= %d\n", __FUNCTION__,
               pChDirNameStr, ulMaxChnlSum - 1, ulRfChnl);
        return BSP_ERROR;
    }

    ulTmpRet = BspGetBspChnByRfChn(ulRfChnl, ulTrxType, &ulBspChnl);
    if (BSP_OK != ulTmpRet)
    {
        dbgErr("%s>>%sChnl'%d BspChnl Get Error!\n",
               __FUNCTION__, pChDirNameStr, ulRfChnl);
        return BSP_ERROR;
    }

    pRfCfg = GetRfCfgPara(ulBspChnl, ulTrxType);
    if (NULL == pRfCfg)
    {
        dbgErr("%s>>%sChnl'%d RfCfgParam Get Error!\n",
               __FUNCTION__, pChDirNameStr, ulRfChnl);
        return BSP_ERROR;
    }

    BspGetChnlCfgCarrPara(ulRfChnl, &tRruCfgInfo);
    ulTmpRet = BspChkRruCfgParamValid(ulTrxType, ulMaxCarrSum, &tRruCfgInfo);
    if (BSP_OK != ulTmpRet)
    {
        dbgErr("%s>>Error! %sChnl'%d RfCfgParam Invalid!\n",
               __FUNCTION__, pChDirNameStr, ulRfChnl);
        return BSP_ERROR; /* 配置频点信息无效, 退出 */
    }

    ulMinCarrNum = 0;
    ulMaxCarrNum = 0;
    for (ulCarrIdx = 0; ulCarrIdx < pRfCfg->para.carrNum; ulCarrIdx++)
    {
        if ((0 == pRfCfg->para.carrInfo[ulCarrIdx].freq) || (BSP_ERROR == pRfCfg->para.carrInfo[ulCarrIdx].freq))
        {
            continue;
        }

        if (pRfCfg->para.carrInfo[ulMinCarrNum].freq > pRfCfg->para.carrInfo[ulCarrIdx].freq)
        {
            ulMinCarrNum = ulCarrIdx;
        }

        if (pRfCfg->para.carrInfo[ulMaxCarrNum].freq < pRfCfg->para.carrInfo[ulCarrIdx].freq)
        {
            ulMaxCarrNum = ulCarrIdx;
        }
    }

//    ulMinBandFreq = pRfCfg->para.carrInfo[ulMinCarrNum].freq - pRfCfg->para.carrInfo[ulMinCarrNum].bandWidth / 2;
//    ulMaxBandFreq = pRfCfg->para.carrInfo[ulMaxCarrNum].freq + pRfCfg->para.carrInfo[ulMaxCarrNum].bandWidth / 2;
//    ulCarrCenterFreq = (ulMinBandFreq + ulMaxBandFreq) / 2;

    return pRfCfg->para.carrInfo[ulMaxCarrNum].freq;
}

UINT32 BspGetMultiMaxFreqCarrNo(UINT32 ulTrxType, UINT32 ulRfChnl)
{
    UINT32 ulBspChnl = 0;
    UINT32 ulCarrIdx = 0;
    UINT32 ulMaxChnlSum = 0;
    UINT32 ulMaxCarrSum = 0;
    UINT32 ulMinCarrNum = 0;
    UINT32 ulMaxCarrNum = 0;
    /* UINT32 ulMinBandFreq = 0;
    UINT32 ulMaxBandFreq = 0;
    UINT32 ulCarrCenterFreq = 0; */
    UINT32 ulTmpRet = BSP_OK;
    const CHAR *pChDirNameStr = NULL;
    T_ChanRfCfgPara *pRfCfg = NULL;
    T_RruRfCfgInfo tRruCfgInfo = {0};

    CHNL_DIR_TYPE_NAME_STR(ulTrxType, pChDirNameStr);
    PARAM_OUTER_RANGE_CHK_WITH_RET(BSP_ERROR, ulTrxType, ulTrxType, RX, TX);

    ulMaxCarrSum = BspGetBspCarrNum();
    ulMaxChnlSum = (ulTrxType == TX) ? BspGetTxBspChanNum() : BspGetRxBspChanNum();
    if (ulRfChnl >= ulMaxChnlSum)
    {
        dbgErr("%s>>Error! RfChnl Over! %sChnl(0~%d)= %d\n", __FUNCTION__,
               pChDirNameStr, ulMaxChnlSum - 1, ulRfChnl);
        return BSP_ERROR;
    }

    ulTmpRet = BspGetBspChnByRfChn(ulRfChnl, ulTrxType, &ulBspChnl);
    if (BSP_OK != ulTmpRet)
    {
        dbgErr("%s>>%sChnl'%d BspChnl Get Error!\n",
               __FUNCTION__, pChDirNameStr, ulRfChnl);
        return BSP_ERROR;
    }

    pRfCfg = GetRfCfgPara(ulBspChnl, ulTrxType);
    if (NULL == pRfCfg)
    {
        dbgErr("%s>>%sChnl'%d RfCfgParam Get Error!\n",
               __FUNCTION__, pChDirNameStr, ulRfChnl);
        return BSP_ERROR;
    }

    BspGetChnlCfgCarrPara(ulRfChnl, &tRruCfgInfo);
    ulTmpRet = BspChkRruCfgParamValid(ulTrxType, ulMaxCarrSum, &tRruCfgInfo);
    if (BSP_OK != ulTmpRet)
    {
        dbgErr("%s>>Error! %sChnl'%d RfCfgParam Invalid!\n",
               __FUNCTION__, pChDirNameStr, ulRfChnl);
        return BSP_ERROR; /* 配置频点信息无效, 退出 */
    }

    ulMinCarrNum = 0;
    ulMaxCarrNum = 0;
    for (ulCarrIdx = 0; ulCarrIdx < pRfCfg->para.carrNum; ulCarrIdx++)
    {
        if ((0 == pRfCfg->para.carrInfo[ulCarrIdx].freq) || (BSP_ERROR == pRfCfg->para.carrInfo[ulCarrIdx].freq))
        {
            continue;
        }

        if (pRfCfg->para.carrInfo[ulMinCarrNum].freq > pRfCfg->para.carrInfo[ulCarrIdx].freq)
        {
            ulMinCarrNum = ulCarrIdx;
        }

        if (pRfCfg->para.carrInfo[ulMaxCarrNum].freq < pRfCfg->para.carrInfo[ulCarrIdx].freq)
        {
            ulMaxCarrNum = ulCarrIdx;
        }
    }

//    ulMinBandFreq = pRfCfg->para.carrInfo[ulMinCarrNum].freq - pRfCfg->para.carrInfo[ulMinCarrNum].bandWidth / 2;
//    ulMaxBandFreq = pRfCfg->para.carrInfo[ulMaxCarrNum].freq + pRfCfg->para.carrInfo[ulMaxCarrNum].bandWidth / 2;
//    ulCarrCenterFreq = (ulMinBandFreq + ulMaxBandFreq) / 2;

    return ulMaxCarrNum;
}


UINT32 BspGetMultiCarrMinFreq(UINT32 ulTrxType, UINT32 ulRfChnl)
{
    UINT32 ulBspChnl = 0;
    UINT32 ulCarrIdx = 0;
    UINT32 ulMaxChnlSum = 0;
    UINT32 ulMaxCarrSum = 0;
    UINT32 ulMinCarrNum = 0;
    UINT32 ulMaxCarrNum = 0;
    /* UINT32 ulMinBandFreq = 0;
    UINT32 ulMaxBandFreq = 0;
    UINT32 ulCarrCenterFreq = 0; */
    UINT32 ulTmpRet = BSP_OK;
    const CHAR *pChDirNameStr = NULL;
    T_ChanRfCfgPara *pRfCfg = NULL;
    T_RruRfCfgInfo tRruCfgInfo = {0};

    CHNL_DIR_TYPE_NAME_STR(ulTrxType, pChDirNameStr);
    PARAM_OUTER_RANGE_CHK_WITH_RET(BSP_ERROR, ulTrxType, ulTrxType, RX, TX);

    ulMaxCarrSum = BspGetBspCarrNum();
    ulMaxChnlSum = (ulTrxType == TX) ? BspGetTxBspChanNum() : BspGetRxBspChanNum();
    if (ulRfChnl >= ulMaxChnlSum)
    {
        dbgErr("%s>>Error! RfChnl Over! %sChnl(0~%d)= %d\n", __FUNCTION__,
               pChDirNameStr, ulMaxChnlSum - 1, ulRfChnl);
        return BSP_ERROR;
    }

    ulTmpRet = BspGetBspChnByRfChn(ulRfChnl, ulTrxType, &ulBspChnl);
    if (BSP_OK != ulTmpRet)
    {
        dbgErr("%s>>%sChnl'%d BspChnl Get Error!\n",
               __FUNCTION__, pChDirNameStr, ulRfChnl);
        return BSP_ERROR;
    }

    pRfCfg = GetRfCfgPara(ulBspChnl, ulTrxType);
    if (NULL == pRfCfg)
    {
        dbgErr("%s>>%sChnl'%d RfCfgParam Get Error!\n",
               __FUNCTION__, pChDirNameStr, ulRfChnl);
        return BSP_ERROR;
    }

    BspGetChnlCfgCarrPara(ulRfChnl, &tRruCfgInfo);
    ulTmpRet = BspChkRruCfgParamValid(ulTrxType, ulMaxCarrSum, &tRruCfgInfo);
    if (BSP_OK != ulTmpRet)
    {
        dbgErr("%s>>Error! %sChnl'%d RfCfgParam Invalid!\n",
               __FUNCTION__, pChDirNameStr, ulRfChnl);
        return BSP_ERROR; /* 配置频点信息无效, 退出 */
    }

    ulMinCarrNum = 0;
    ulMaxCarrNum = 0;
    for (ulCarrIdx = 0; ulCarrIdx < pRfCfg->para.carrNum; ulCarrIdx++)
    {
        if ((0 == pRfCfg->para.carrInfo[ulCarrIdx].freq) || (BSP_ERROR == pRfCfg->para.carrInfo[ulCarrIdx].freq))
        {
            continue;
        }

        if (pRfCfg->para.carrInfo[ulMinCarrNum].freq > pRfCfg->para.carrInfo[ulCarrIdx].freq)
        {
            ulMinCarrNum = ulCarrIdx;
        }

        if (pRfCfg->para.carrInfo[ulMaxCarrNum].freq < pRfCfg->para.carrInfo[ulCarrIdx].freq)
        {
            ulMaxCarrNum = ulCarrIdx;
        }
    }

//    ulMinBandFreq = pRfCfg->para.carrInfo[ulMinCarrNum].freq - pRfCfg->para.carrInfo[ulMinCarrNum].bandWidth / 2;
//    ulMaxBandFreq = pRfCfg->para.carrInfo[ulMaxCarrNum].freq + pRfCfg->para.carrInfo[ulMaxCarrNum].bandWidth / 2;
//    ulCarrCenterFreq = (ulMinBandFreq + ulMaxBandFreq) / 2;

    return pRfCfg->para.carrInfo[ulMinCarrNum].freq;
}

UINT32 BspGetMultiMinFreqCarrNo(UINT32 ulTrxType, UINT32 ulRfChnl)
{
    UINT32 ulBspChnl = 0;
    UINT32 ulCarrIdx = 0;
    UINT32 ulMaxChnlSum = 0;
    UINT32 ulMaxCarrSum = 0;
    UINT32 ulMinCarrNum = 0;
    UINT32 ulMaxCarrNum = 0;
    /* UINT32 ulMinBandFreq = 0; */
    /* UINT32 ulMaxBandFreq = 0;
    UINT32 ulCarrCenterFreq = 0; */
    UINT32 ulTmpRet = BSP_OK;
    const CHAR *pChDirNameStr = NULL;
    T_ChanRfCfgPara *pRfCfg = NULL;
    T_RruRfCfgInfo tRruCfgInfo = {0};

    CHNL_DIR_TYPE_NAME_STR(ulTrxType, pChDirNameStr);
    PARAM_OUTER_RANGE_CHK_WITH_RET(BSP_ERROR, ulTrxType, ulTrxType, RX, TX);

    ulMaxCarrSum = BspGetBspCarrNum();
    ulMaxChnlSum = (ulTrxType == TX) ? BspGetTxBspChanNum() : BspGetRxBspChanNum();
    if (ulRfChnl >= ulMaxChnlSum)
    {
        dbgErr("%s>>Error! RfChnl Over! %sChnl(0~%d)= %d\n", __FUNCTION__,
               pChDirNameStr, ulMaxChnlSum - 1, ulRfChnl);
        return BSP_ERROR;
    }

    ulTmpRet = BspGetBspChnByRfChn(ulRfChnl, ulTrxType, &ulBspChnl);
    if (BSP_OK != ulTmpRet)
    {
        dbgErr("%s>>%sChnl'%d BspChnl Get Error!\n",
               __FUNCTION__, pChDirNameStr, ulRfChnl);
        return BSP_ERROR;
    }

    pRfCfg = GetRfCfgPara(ulBspChnl, ulTrxType);
    if (NULL == pRfCfg)
    {
        dbgErr("%s>>%sChnl'%d RfCfgParam Get Error!\n",
               __FUNCTION__, pChDirNameStr, ulRfChnl);
        return BSP_ERROR;
    }

    BspGetChnlCfgCarrPara(ulRfChnl, &tRruCfgInfo);
    ulTmpRet = BspChkRruCfgParamValid(ulTrxType, ulMaxCarrSum, &tRruCfgInfo);
    if (BSP_OK != ulTmpRet)
    {
        dbgErr("%s>>Error! %sChnl'%d RfCfgParam Invalid!\n",
               __FUNCTION__, pChDirNameStr, ulRfChnl);
        return BSP_ERROR; /* 配置频点信息无效, 退出 */
    }

    ulMinCarrNum = 0;
    ulMaxCarrNum = 0;
    for (ulCarrIdx = 0; ulCarrIdx < pRfCfg->para.carrNum; ulCarrIdx++)
    {
        if ((0 == pRfCfg->para.carrInfo[ulCarrIdx].freq) || (BSP_ERROR == pRfCfg->para.carrInfo[ulCarrIdx].freq))
        {
            continue;
        }

        if (pRfCfg->para.carrInfo[ulMinCarrNum].freq > pRfCfg->para.carrInfo[ulCarrIdx].freq)
        {
            ulMinCarrNum = ulCarrIdx;
        }

        if (pRfCfg->para.carrInfo[ulMaxCarrNum].freq < pRfCfg->para.carrInfo[ulCarrIdx].freq)
        {
            ulMaxCarrNum = ulCarrIdx;
        }
    }

//    ulMinBandFreq = pRfCfg->para.carrInfo[ulMinCarrNum].freq - pRfCfg->para.carrInfo[ulMinCarrNum].bandWidth / 2;
//    ulMaxBandFreq = pRfCfg->para.carrInfo[ulMaxCarrNum].freq + pRfCfg->para.carrInfo[ulMaxCarrNum].bandWidth / 2;
//    ulCarrCenterFreq = (ulMinBandFreq + ulMaxBandFreq) / 2;

    return ulMinCarrNum;
}


UINT32 BspGetCarrMode(UINT32 dir, UINT32 chan, UINT32 carrNo)
{
    UINT32 bspChan = 0;
    UINT32 carrIndex = 0;
    UINT32 retVal = BSP_OK;
    T_ChanRfCfgPara *pRfCfg;
    const CHAR *pChDirNameStr = NULL;
    T_RruRfCfgInfo tRruCfgInfo = {0};
    UINT32 chanNum = (dir == TX) ? BspGetTxBspChanNum() : BspGetRxBspChanNum();

    CHNL_DIR_TYPE_NAME_STR(dir, pChDirNameStr);

    if (chan >= chanNum)
    {
        dbgInfoEx("%s>>Error! ParamChnl Over! %sChnl(0~%d)= %d\n",
               __FUNCTION__, pChDirNameStr, chanNum - 1, chan);
        return BSP_ERROR;
    }
    if (BspGetBspChnByRfChn(chan,dir,&bspChan) != BSP_OK)
    {
        dbgInfoEx("%s>>%sChnl'%d Carr'%d BspChnl Get Error!\n",
               __FUNCTION__, pChDirNameStr, chan, carrNo);
        return BSP_ERROR;
    }

    pRfCfg = GetRfCfgPara(bspChan,dir);
    if (pRfCfg == NULL)
    {
        dbgInfoEx("%s>>%sChnl'%d Carr'%d RfCfgParam Get Error!\n",
               __FUNCTION__, pChDirNameStr, chan, carrNo);
        return BSP_ERROR;
    }

#if (1)
    BspGetChnlCfgCarrPara(chan, &tRruCfgInfo);
    retVal = BspChkRruCfgParamValid(dir, carrNo, &tRruCfgInfo);
    if (retVal != BSP_OK)
    {
    //  dbgErr("%s>>Error! %sChnl'%d Carr'%d RfCfgParam Invalid!\n",
    //         __FUNCTION__, pChDirNameStr, chan, carrNo);
        return BSP_ERROR;
    }
#endif

    for (carrIndex = 0; carrIndex < pRfCfg->para.carrNum; carrIndex++)
    {
        if (carrNo == pRfCfg->para.carrInfo[carrIndex].carrNo)
            break;
    }
    if (carrIndex == pRfCfg->para.carrNum)
    {
        dbgInfoEx("%s>>Error! %sChnl'%d Carr'%d RfCfgParam Invalid!\n",
                     __FUNCTION__, pChDirNameStr, chan, carrNo);
        return BSP_ERROR;
    }
    else
    {
        return pRfCfg->para.carrInfo[carrIndex].radioMode;
    }
}

UINT32 BspSetCenterFreq(UINT32 dir, UINT32 chan, UINT32 freq)
{
    T_ChanRfCfgPara *pRfCfg;
    UINT32 bspChan = 0;
    UINT32 chanNum = (dir == TX) ? BspGetTxChannel() : BspGetRxChannel();

    BspLog(LOG_LEVEL_0,"%s(%d,%d,%d) enter\n",__FUNCTION__,dir,chan,freq);

    if (chan >= chanNum)
    {
        return BSP_ERROR;
    }
    if (BspGetBspChnByRfChn(chan,dir,&bspChan) != BSP_OK)
    {
        return BSP_ERROR;
    }

    pRfCfg = GetRfCfgPara(bspChan,dir);
    if (pRfCfg == NULL)
    {
        return BSP_ERROR;
    }
    if(NULL != pfCalcUnifixLoCom)
    {
        pRfCfg->centerFreqSrc = 0;
    }
    else
    {
        pRfCfg->centerFreqSrc = 1;
    }
    pRfCfg->centerFreq    = freq;

    BspLog(LOG_LEVEL_0,"%s(%d,%d,%d) ok\n",__FUNCTION__,dir,chan,freq);
    return BSP_OK;
}

UINT32 BspGetCenterFreqSrc(UINT32 dir, UINT32 bspChan)
{
    T_ChanRfCfgPara *pRfCfg;
    UINT32 chanNum = (dir == TX) ? BspGetTxBspChanNum() : BspGetRxBspChanNum();

    if (bspChan >= chanNum)
    {
        return BSP_ERROR;
    }

    pRfCfg = GetRfCfgPara(bspChan,dir);
    if (pRfCfg == NULL)
    {
        return BSP_ERROR;
    }

    return pRfCfg->centerFreqSrc;
}


UINT32 BspGetFilterFreqRangeModule(UINT32 ulTrxDir, UINT32 ulBspChnl, UINT32 *pulMinFreq, UINT32 *pulMaxFreq)
{
    UINT32 ulMinFreqKHz = 0;
    UINT32 ulMaxFreqKHz = 0;
    UINT32 ulMaxChnlSum = 0;
    /* UINT32 ulTmpRet  = BSP_OK; */
    UINT32 ulFuncRet = BSP_OK;
    const CHAR *pTrxNameStr = NULL;
    T_RruRfModuleInfo tRfModuleInfo = {0, };

    CHNL_DIR_TYPE_NAME_STR(ulTrxDir, pTrxNameStr);
    dbgInfoEx("%s: pTrxNameStr: %p\n", __FUNCTION__, pTrxNameStr);
    ulMaxChnlSum = (TX == ulTrxDir) ? BspGetTxChannel() : BspGetRxChannel();
    dbgInfoEx("%s: ulMaxChnlSum:%d\n",__FUNCTION__, ulMaxChnlSum);

    /* PARAM_OUTER_RANGE_CHK_WITH_RET(BIT_SET(0), TrxDir, ulTrxDir, RX, TX); */
    /* PARAM_OUTER_RANGE_CHK_WITH_RET(BIT_SET(1), ChnlNo, ulBspChnl, 0, ulMaxChnlSum - 1); */

    BspGetRruRfModuleInfo(ulBspChnl, &tRfModuleInfo);
    if (TX == ulTrxDir)
    {
        ulMinFreqKHz = tRfModuleInfo.ulRuTxStartFreq;
        ulMaxFreqKHz = tRfModuleInfo.ulRuTxEndFreq;
    }
    else
    {
        ulMinFreqKHz = tRfModuleInfo.ulRuRxStartFreq;
        ulMaxFreqKHz = tRfModuleInfo.ulRuRxEndFreq;
    }
    if (NULL != pulMinFreq)
    {
        *pulMinFreq = ulMinFreqKHz;
    }

    if (NULL != pulMaxFreq)
    {
        *pulMaxFreq = ulMaxFreqKHz;
    }
    return ulFuncRet;
}


UINT32 BspGetRfModuleFreq(UINT32 chan,UINT32 dir)
{
    UINT32 rfModuleFreq = 0;
    UINT32 minFreq = 0;
    UINT32 maxFreq = 0;

    BspGetFilterFreqRangeModule(dir,chan,&minFreq,&maxFreq);

    if((minFreq != 0)&&(maxFreq != 0))
    {
       rfModuleFreq = (minFreq+maxFreq)/2;
    }
    dbgInfoEx("%s:chan%d,dir%d,rfModuleFreq%d,minFreq%d,maxFreq%d\n",\
        __FUNCTION__,chan,dir,rfModuleFreq,minFreq,maxFreq);
    return rfModuleFreq;
}

UINT32 BspGetRfChCenterFreq(UINT32 rfChan, UINT32 dir, UINT32* rfCenterFreq)
{
    UINT32 bspChan = 0;
    UINT32 chanNum = (dir == TX) ? BspGetTxChannel() : BspGetRxChannel();

    INPUT_POINTER_CHECK(rfCenterFreq);
    if (rfChan >= chanNum)
    {
        dbgErr("chan [%u] over max value\r\n", rfChan);
        return BSP_ERROR;
    }
    if (BspGetBspChnByRfChn(rfChan,dir,&bspChan) != BSP_OK)
    {
        dbgErr(">BspGetBspChnByRfChn chan [%u] [%u] convert error\r\n", rfChan, dir);
        return BSP_ERROR;
    }
    *rfCenterFreq = BspGetRfModuleFreq(bspChan, dir);
    return BSP_OK;
}

UINT32 BspGetLoFreq(UINT32 dir, UINT32 chan)
{
    T_ChanRfCfgPara *pRfCfg;
    UINT32 bspChan = 0;
    UINT32 chanNum = (dir == TX) ? BspGetTxChannel() : BspGetRxChannel();
    UINT32 LoFreq = 0;
    if (chan >= chanNum)
    {
        return BSP_ERROR;
    }
    if (NULL != _BoardLoFreqDef)
    {
        return _BoardLoFreqDef(dir, chan);
    }

    if (BspGetBspChnByRfChn(chan,dir,&bspChan) != BSP_OK)
    {
        return BSP_ERROR;
    }
    if (NULL != pFreqGetPllFreq)
    {
        return pFreqGetPllFreq(dir, chan);
    }

    pRfCfg = GetRfCfgPara(bspChan,dir);
    if (pRfCfg == NULL)
    {
        return BSP_ERROR;
    }
    if(1 == BspGetCfrCarrInfoFlag())
    {
        LoFreq = BspGetCenterFreq(dir,bspChan);
        return LoFreq;
    }
    LoFreq = pRfCfg->rfpllFreq;
    if((0 == LoFreq)&&(NULL != pGetFixedBandLoFreqFunc))
    {
        LoFreq = pGetFixedBandLoFreqFunc(bspChan,dir);
    }
    return LoFreq;
}

/* 后续BspGetLoFreq只给app使用， BspGetLoFreqChanged给BSP内部使用*/
UINT32 BspGetLoFreqChanged(UINT32 dir, UINT32 chan)
{
    T_ChanRfCfgPara *pRfCfg;
    UINT32 bspChan = 0;
    UINT32 chanNum = (dir == TX) ? BspGetTxChannel() : BspGetRxChannel();
    UINT32 LoFreq = 0;
    if (chan >= chanNum)
    {
        return BSP_ERROR;
    }
    if (NULL != _BoardLoFreqDef)
    {
        return _BoardLoFreqDef(dir, chan);
    }

    if (BspGetBspChnByRfChn(chan,dir,&bspChan) != BSP_OK)
    {
        return BSP_ERROR;
    }

    pRfCfg = GetRfCfgPara(bspChan,dir);
    if (pRfCfg == NULL)
    {
        if(NULL != pFuncRepairLoFreqShowFlag)
        {
            return 0;
        }
        return BSP_ERROR;
    }
    if(1 == BspGetCfrCarrInfoFlag())
    {
        LoFreq = BspGetCenterFreq(dir,bspChan);
        return LoFreq;
    }
    LoFreq = pRfCfg->rfpllFreq;
    if((0 == LoFreq)&&(NULL != pGetFixedBandLoFreqFunc))
    {
        LoFreq = pGetFixedBandLoFreqFunc(bspChan,dir);
    }
    return LoFreq;
}

UINT32 TestBspGetFixLoFreq(UINT32 chan,UINT32 dir)
{
    UINT32 bspChan = 0;
    UINT32 chanNum = (dir == TX) ? BspGetTxChannel() : BspGetRxChannel();
    UINT32 LoFreq = 0;
    if (chan >= chanNum)
    {
        return BSP_ERROR;
    }
    if (BspGetBspChnByRfChn(chan,dir,&bspChan) != BSP_OK)
    {
        return BSP_ERROR;
    }
    if(NULL != pGetFixedBandLoFreqFunc)
    {
        LoFreq = pGetFixedBandLoFreqFunc(bspChan,dir);
    }
    return LoFreq;
}

UINT32 BspSetLoFreq(UINT32 trx,UINT32 chan, UINT32 freq)
{
    T_ChanRfCfgPara *pRfCfg;
    UINT32 bspChan = 0;
    UINT32 chanNum = (trx == TX) ? BspGetTxChannel() : BspGetRxChannel();

    BspLog(LOG_LEVEL_0,"%s(%d,%d,%d) enter\n",__FUNCTION__,trx,chan,freq);

    if (chan >= chanNum)
    {
        return BSP_ERROR;
    }
    if (BspGetBspChnByRfChn(chan,trx,&bspChan) != BSP_OK)
    {
        return BSP_ERROR;
    }

    pRfCfg = GetRfCfgPara(bspChan,trx);
    if (pRfCfg == NULL)
    {
        return BSP_ERROR;
    }

    pRfCfg->rfpllFreq = freq;
    pRfCfg->rfpllFreqSrc = 1;

    BspLog(LOG_LEVEL_0,"%s(%d,%d,%d) ok\n",__FUNCTION__,trx,chan,freq);
    return BSP_OK;
}

UINT32 BspGetLoFreqSrc(UINT32 dir, UINT32 bspChan)
{
    T_ChanRfCfgPara *pRfCfg;
    UINT32 chanNum = (dir == TX) ? BspGetTxBspChanNum() : BspGetRxBspChanNum();

    if (bspChan >= chanNum)
    {
        return BSP_ERROR;
    }

    pRfCfg = GetRfCfgPara(bspChan,dir);
    if (pRfCfg == NULL)
    {
        return BSP_ERROR;
    }

    return pRfCfg->rfpllFreqSrc;
}

UINT32 BspInitRruCfgPara(UINT32 chan, UINT32 dir)
{
    UINT32 loop;
    UINT32 bspChan;
    UINT32 ulMaxCarrSum = 0;
    UINT32 ulGetFreqBwpKHz = 0;
    UINT32 tmpRet = BSP_OK;
    UINT32 retVal = BSP_OK;
    UINT32 ulFilterMinFreq = 0;
    UINT32 ulFilterMaxFreq = 0;
    const CHAR *pTrxNameStr = NULL;
    T_RruRfCfgInfo tRruCfgInfo = {0};
    T_ChanRfCfgPara *pRfCfg = NULL;
    pGetRfFreqRange pFuncGetFreqRange = NULL;
    UINT32 bandNo = 0;
    pGetRfBandFreqRange pFuncGetBandFreqRange = NULL;
    UINT32 ulBandFilterMinFreq[BSP_MAX_BAND_PER_CH] = {0};
    UINT32 ulBandFilterMaxFreq[BSP_MAX_BAND_PER_CH] = {0};

    dbgInfoEx("\n%s>>Chan %d dir %d Start!\n",__FUNCTION__, chan, dir);
    ulGetFreqBwpKHz = BspGetRfCfgBwp();
    ulMaxCarrSum = BspGetBspCarrNum();
    CHNL_DIR_TYPE_NAME_STR(dir, pTrxNameStr);

    if (BspGetBspChnByRfChn(chan,dir,&bspChan) != BSP_OK)
    {
        retVal |= BIT_SET(0);
        dbgErr("%s>>%sChnl'%d BspChnByRfChn Get Error!\n",
               __FUNCTION__, pTrxNameStr, chan);
        return retVal;
    }


    pRfCfg = GetRfCfgPara(bspChan,dir);


    INPUT_POINTER_CHECK(pRfCfg);
    if (pRfCfg->para.carrNum > BSP_MAX_CARR_NUM)
    {
        retVal |= BIT_SET(1);
        dbgErr("%s>>Error! %s Chnl'%d CarrSum Over; Carr(0~%d)= %d\n", __FUNCTION__,
               pTrxNameStr, chan, BSP_MAX_CARR_NUM - 1, pRfCfg->para.carrNum);
        return retVal;
    }

    pFuncGetFreqRange = BspGetFilterRangeFreqCallBack();
    if (NULL != pFuncGetFreqRange)
    {
        if (BSP_OK  != pFuncGetFreqRange(dir, bspChan, &ulFilterMinFreq, &ulFilterMaxFreq))
        {
            retVal |= BIT_SET(2);
            ulFilterMinFreq = 0xFFFFFFFF;
            ulFilterMaxFreq = 0;
            dbgErr("%s>>%sChnl'%d FilterRangeFreq Get Error!\n",
                   __FUNCTION__, pTrxNameStr, chan);
        }
    }
    else
    {
        ulFilterMinFreq = 0;
        ulFilterMaxFreq = 0xFFFFFFFF;
    }

    pFuncGetBandFreqRange = BspGetBandFilterRangeFreqCallBack();
    if (NULL != pFuncGetBandFreqRange)
    {
        for(bandNo = 0; bandNo < BSP_MAX_BAND_PER_CH;bandNo++)
        {
            pFuncGetBandFreqRange(dir, bspChan, bandNo,&ulBandFilterMinFreq[bandNo], &ulBandFilterMaxFreq[bandNo]);
        }
    }


    tmpRet = BspGetChnlCfgCarrPara(chan,&tRruCfgInfo);


    if (tmpRet != BSP_OK)
    {
        retVal |= BIT_SET(3);
        dbgErr("%s>>%sChnl'%d ChnlCfgCarrPara Get Error!\n",
               __FUNCTION__, pTrxNameStr, chan);
    }

    if (dir == RX)
    {
        tRruCfgInfo.rxCfgCarrSum = pRfCfg->para.carrNum;
        tRruCfgInfo.rxCenterFreq = pRfCfg->centerFreq;
        tRruCfgInfo.rxRfRangeMinFreq = ulFilterMinFreq;
        tRruCfgInfo.rxRfRangeMaxFreq = ulFilterMaxFreq;
        tRruCfgInfo.rxRfRangeMinFreqB2 = ulBandFilterMinFreq[1];
        tRruCfgInfo.rxRfRangeMaxFreqB2 = ulBandFilterMaxFreq[1];
        dbgInfoEx("%s>>dir RX carrNum %d, centerFreq %d, ulFilterMinFreq %d, ulFilterMaxFreq %d bandFilterMin %d, Max %d\n",__FUNCTION__,
                   pRfCfg->para.carrNum, pRfCfg->centerFreq,ulFilterMinFreq,ulFilterMaxFreq, ulBandFilterMinFreq[1],ulBandFilterMaxFreq[1]);
        for (loop = 0; loop < pRfCfg->para.carrNum; loop++)
        {
            if (pRfCfg->para.carrInfo)
            {
                tRruCfgInfo.carr[loop].carrRxNo    = pRfCfg->para.carrInfo[loop].carrNo;
                tRruCfgInfo.carr[loop].carrRxFreq  = pRfCfg->para.carrInfo[loop].freq;
                if (ulGetFreqBwpKHz == BSP_ERROR)
                {
                    tRruCfgInfo.carr[loop].carrRxBw = pRfCfg->para.carrInfo[loop].bandWidth;
                }
                else
                {
                    tRruCfgInfo.carr[loop].carrRxBw = ulGetFreqBwpKHz;
                }
                tRruCfgInfo.carr[loop].carrRxRadio = pRfCfg->para.carrInfo[loop].radioMode;
                dbgInfoEx("%s>>dir RX loop %d, carrNo %d, Freq %d, ulGetFreqBwpKHz %d  bandWidth %d mode %d\n",__FUNCTION__,
                            loop, pRfCfg->para.carrInfo[loop].carrNo,pRfCfg->para.carrInfo[loop].freq,ulGetFreqBwpKHz,
                            pRfCfg->para.carrInfo[loop].bandWidth,pRfCfg->para.carrInfo[loop].radioMode);
            }
        }
    }
    else
    {
        tRruCfgInfo.txCfgCarrSum = pRfCfg->para.carrNum;
        tRruCfgInfo.txCenterFreq = pRfCfg->centerFreq;
        tRruCfgInfo.txRfRangeMinFreq = ulFilterMinFreq;
        tRruCfgInfo.txRfRangeMaxFreq = ulFilterMaxFreq;
        tRruCfgInfo.txRfRangeMinFreqB2 = ulBandFilterMinFreq[1];
        tRruCfgInfo.txRfRangeMaxFreqB2 = ulBandFilterMaxFreq[1];
        dbgInfoEx("%s>>dir TX carrNum %d, centerFreq %d, ulFilterMinFreq %d, ulFilterMaxFreq %d bandFilterMin %d, Max %d\n",__FUNCTION__,
                   pRfCfg->para.carrNum, pRfCfg->centerFreq,ulFilterMinFreq,ulFilterMaxFreq, ulBandFilterMinFreq[1],ulBandFilterMaxFreq[1]);
        for (loop = 0; loop < pRfCfg->para.carrNum; loop++)
        {
            if (pRfCfg->para.carrInfo)
            {
                tRruCfgInfo.carr[loop].carrTxNo    = pRfCfg->para.carrInfo[loop].carrNo;
                tRruCfgInfo.carr[loop].carrTxFreq  = pRfCfg->para.carrInfo[loop].freq;
                if (ulGetFreqBwpKHz == BSP_ERROR)
                {
                    tRruCfgInfo.carr[loop].carrTxBw = pRfCfg->para.carrInfo[loop].bandWidth;
                }
                else
                {
                    tRruCfgInfo.carr[loop].carrTxBw = ulGetFreqBwpKHz;
                }
                tRruCfgInfo.carr[loop].carrTxRadio = pRfCfg->para.carrInfo[loop].radioMode;
                dbgInfoEx("%s>>dir TX loop %d, carrNo %d, Freq %d, ulGetFreqBwpKHz %d  bandWidth %d mode %d\n",__FUNCTION__,
                            loop, pRfCfg->para.carrInfo[loop].carrNo,pRfCfg->para.carrInfo[loop].freq,ulGetFreqBwpKHz,
                            pRfCfg->para.carrInfo[loop].bandWidth,pRfCfg->para.carrInfo[loop].radioMode);
            }
        }
    }

    if (dir == RX)
    {
        for (bandNo = 0; bandNo < BSP_MAX_BAND_PER_CH; bandNo++)
        {
            tRruCfgInfo.rxbandFreq[bandNo] = BspGetBandFreq(dir, chan, bandNo);
            dbgInfoEx("%s>>dir RX bandNo %d, rxbandFreq %d\n",__FUNCTION__, bandNo, BspGetBandFreq(dir, chan, bandNo));
        }
    }
    else
    {
        for (bandNo = 0; bandNo < BSP_MAX_BAND_PER_CH; bandNo++)
        {
            tRruCfgInfo.txbandFreq[bandNo] = BspGetBandFreq(dir, chan, bandNo);
            dbgInfoEx("%s>>dir TX bandNo %d, txbandFreq %d\n",__FUNCTION__, bandNo, BspGetBandFreq(dir, chan, bandNo));
        }
    }
    tmpRet = BspChkRruCfgParamValid(dir, ulMaxCarrSum, &tRruCfgInfo);
    if(tmpRet != BSP_OK)
    {
        retVal |= BIT_SET(4);
        dbgErr("%s>>%sChnl'%d RruCfgParaData Check Error!\n",
               __FUNCTION__, pTrxNameStr, chan);
    }


    tmpRet = BspSetRruCfgPara(chan, &tRruCfgInfo);


    if(tmpRet != BSP_OK)
    {
        retVal |= BIT_SET(5);
        dbgErr("%s>>%sChnl'%d RruCfgPara Set Error!\n",
               __FUNCTION__, pTrxNameStr, chan);
    }
    dbgInfoEx("%s>>Chan %d End!\n",__FUNCTION__, chan);
    return retVal;
}

UINT32 BspInitRruCfgPara_original(UINT32 chan, UINT32 dir)
{
    UINT32 loop;
    UINT32 bspChan;
    /*UINT32 ulMaxCarrSum = 0;*/
    UINT32 ulGetFreqBwpKHz = 0;
    UINT32 tmpRet = BSP_OK;
    UINT32 retVal = BSP_OK;
    UINT32 ulFilterMinFreq = 0;
    UINT32 ulFilterMaxFreq = 0;
    const CHAR *pTrxNameStr = NULL;
    T_RruRfCfgInfo tRruCfgInfo = {0};
    T_ChanRfCfgPara *pRfCfg = NULL;
    pGetRfFreqRange pFuncGetFreqRange = NULL;
    UINT32 bandNo = 0;
    pGetRfBandFreqRange pFuncGetBandFreqRange = NULL;
    UINT32 ulBandFilterMinFreq[BSP_MAX_BAND_PER_CH] = {0};
    UINT32 ulBandFilterMaxFreq[BSP_MAX_BAND_PER_CH] = {0};

    dbgInfo("\n%s>>Chan %d dir %d Start!\n",__FUNCTION__, chan, dir);
    ulGetFreqBwpKHz = BspGetRfCfgBwp();
    /*ulMaxCarrSum = BspGetBspCarrNum();*/
    CHNL_DIR_TYPE_NAME_STR(dir, pTrxNameStr);

    if (BspGetBspChnByRfChn(chan,dir,&bspChan) != BSP_OK)
    {
        retVal |= BIT_SET(0);
        dbgErr("%s>>%sChnl'%d BspChnByRfChn Get Error!\n",
               __FUNCTION__, pTrxNameStr, chan);
        return retVal;
    }


    pRfCfg = GetRfCfgPara_original(bspChan,dir);


    INPUT_POINTER_CHECK(pRfCfg);
    if (pRfCfg->para.carrNum > BSP_MAX_CARR_NUM)
    {
        retVal |= BIT_SET(1);
        dbgErr("%s>>Error! %s Chnl'%d CarrSum Over; Carr(0~%d)= %d\n", __FUNCTION__,
               pTrxNameStr, chan, BSP_MAX_CARR_NUM - 1, pRfCfg->para.carrNum);
        return retVal;
    }

    pFuncGetFreqRange = BspGetFilterRangeFreqCallBack();
    if (NULL != pFuncGetFreqRange)
    {
        if (BSP_OK  != pFuncGetFreqRange(dir, bspChan, &ulFilterMinFreq, &ulFilterMaxFreq))
        {
            retVal |= BIT_SET(2);
            ulFilterMinFreq = 0xFFFFFFFF;
            ulFilterMaxFreq = 0;
            dbgErr("%s>>%sChnl'%d FilterRangeFreq Get Error!\n",
                   __FUNCTION__, pTrxNameStr, chan);
        }
    }
    else
    {
        ulFilterMinFreq = 0;
        ulFilterMaxFreq = 0xFFFFFFFF;
    }

    pFuncGetBandFreqRange = BspGetBandFilterRangeFreqCallBack();
    if (NULL != pFuncGetBandFreqRange)
    {
        for(bandNo = 0; bandNo < BSP_MAX_BAND_PER_CH;bandNo++)
        {
            pFuncGetBandFreqRange(dir, bspChan, bandNo,&ulBandFilterMinFreq[bandNo], &ulBandFilterMaxFreq[bandNo]);
        }
    }

    //coverity[cert_int31_c_violation:SUPPRESS]
    tmpRet = BspGetChnlCfgCarrPara_original(chan,&tRruCfgInfo);


    if (tmpRet != BSP_OK)
    {
        retVal |= BIT_SET(3);
        dbgErr("%s>>%sChnl'%d ChnlCfgCarrPara Get Error!\n",
               __FUNCTION__, pTrxNameStr, chan);
    }

    if (dir == RX)
    {
        tRruCfgInfo.rxCfgCarrSum = pRfCfg->para.carrNum;
        tRruCfgInfo.rxCenterFreq = pRfCfg->centerFreq;
        tRruCfgInfo.rxRfRangeMinFreq = ulFilterMinFreq;
        tRruCfgInfo.rxRfRangeMaxFreq = ulFilterMaxFreq;
        tRruCfgInfo.rxRfRangeMinFreqB2 = ulBandFilterMinFreq[1];
        tRruCfgInfo.rxRfRangeMaxFreqB2 = ulBandFilterMaxFreq[1];
        dbgInfo("%s>>dir RX carrNum %d, centerFreq %d, ulFilterMinFreq %d, ulFilterMaxFreq %d bandFilterMin %d, Max %d\n",__FUNCTION__,
                   pRfCfg->para.carrNum, pRfCfg->centerFreq,ulFilterMinFreq,ulFilterMaxFreq, ulBandFilterMinFreq[1],ulBandFilterMaxFreq[1]);
        for (loop = 0; loop < pRfCfg->para.carrNum; loop++)
        {
            if (pRfCfg->para.carrInfo)
            {
                tRruCfgInfo.carr[loop].carrRxNo    = pRfCfg->para.carrInfo[loop].carrNo;
                tRruCfgInfo.carr[loop].carrRxFreq  = pRfCfg->para.carrInfo[loop].freq;
                if (ulGetFreqBwpKHz == BSP_ERROR)
                {
                    tRruCfgInfo.carr[loop].carrRxBw = pRfCfg->para.carrInfo[loop].bandWidth;
                }
                else
                {
                    tRruCfgInfo.carr[loop].carrRxBw = ulGetFreqBwpKHz;
                }
                tRruCfgInfo.carr[loop].carrRxRadio = pRfCfg->para.carrInfo[loop].radioMode;
                dbgInfo("%s>>dir RX loop %d, carrNo %d, Freq %d, ulGetFreqBwpKHz %d  bandWidth %d mode %d\n",__FUNCTION__,
                            loop, pRfCfg->para.carrInfo[loop].carrNo,pRfCfg->para.carrInfo[loop].freq,ulGetFreqBwpKHz,
                            pRfCfg->para.carrInfo[loop].bandWidth,pRfCfg->para.carrInfo[loop].radioMode);
            }
        }
    }
    else
    {
        tRruCfgInfo.txCfgCarrSum = pRfCfg->para.carrNum;
        tRruCfgInfo.txCenterFreq = pRfCfg->centerFreq;
        tRruCfgInfo.txRfRangeMinFreq = ulFilterMinFreq;
        tRruCfgInfo.txRfRangeMaxFreq = ulFilterMaxFreq;
        tRruCfgInfo.txRfRangeMinFreqB2 = ulBandFilterMinFreq[1];
        tRruCfgInfo.txRfRangeMaxFreqB2 = ulBandFilterMaxFreq[1];
        dbgInfo("%s>>dir TX carrNum %d, centerFreq %d, ulFilterMinFreq %d, ulFilterMaxFreq %d bandFilterMin %d, Max %d\n",__FUNCTION__,
                   pRfCfg->para.carrNum, pRfCfg->centerFreq,ulFilterMinFreq,ulFilterMaxFreq, ulBandFilterMinFreq[1],ulBandFilterMaxFreq[1]);
        for (loop = 0; loop < pRfCfg->para.carrNum; loop++)
        {
            if (pRfCfg->para.carrInfo)
            {
                tRruCfgInfo.carr[loop].carrTxNo    = pRfCfg->para.carrInfo[loop].carrNo;
                tRruCfgInfo.carr[loop].carrTxFreq  = pRfCfg->para.carrInfo[loop].freq;
                if (ulGetFreqBwpKHz == BSP_ERROR)
                {
                    tRruCfgInfo.carr[loop].carrTxBw = pRfCfg->para.carrInfo[loop].bandWidth;
                }
                else
                {
                    tRruCfgInfo.carr[loop].carrTxBw = ulGetFreqBwpKHz;
                }
                tRruCfgInfo.carr[loop].carrTxRadio = pRfCfg->para.carrInfo[loop].radioMode;
                dbgInfo("%s>>dir TX loop %d, carrNo %d, Freq %d, ulGetFreqBwpKHz %d  bandWidth %d mode %d\n",__FUNCTION__,
                            loop, pRfCfg->para.carrInfo[loop].carrNo,pRfCfg->para.carrInfo[loop].freq,ulGetFreqBwpKHz,
                            pRfCfg->para.carrInfo[loop].bandWidth,pRfCfg->para.carrInfo[loop].radioMode);
            }
        }
    }

    if (dir == RX)
    {
        for (bandNo = 0; bandNo < BSP_MAX_BAND_PER_CH; bandNo++)
        {
            tRruCfgInfo.rxbandFreq[bandNo] = BspGetBandFreq(dir, chan, bandNo);
            dbgInfo("%s>>dir RX bandNo %d, rxbandFreq %d\n",__FUNCTION__, bandNo, BspGetBandFreq(dir, chan, bandNo));
        }
    }
    else
    {
        for (bandNo = 0; bandNo < BSP_MAX_BAND_PER_CH; bandNo++)
        {
            tRruCfgInfo.txbandFreq[bandNo] = BspGetBandFreq(dir, chan, bandNo);
            dbgInfo("%s>>dir TX bandNo %d, txbandFreq %d\n",__FUNCTION__, bandNo, BspGetBandFreq(dir, chan, bandNo));
        }
    }
    /*tmpRet = BspChkRruCfgParamValid(dir, ulMaxCarrSum, &tRruCfgInfo);
    if(tmpRet != BSP_OK)
    {
        retVal |= BIT_SET(4);
        dbgErr("%s>>%sChnl'%d RruCfgParaData Check Error!\n",
               __FUNCTION__, pTrxNameStr, chan);
    }*/
    //coverity[cert_int31_c_violation:SUPPRESS]
    tmpRet = BspSetRruCfgPara_original(chan, &tRruCfgInfo);

    if(tmpRet != BSP_OK)
    {
        retVal |= BIT_SET(5);
        dbgErr("%s>>%sChnl'%d RruCfgPara Set Error!\n",
               __FUNCTION__, pTrxNameStr, chan);
    }
    dbgInfo("%s>>Chan %d End!\n",__FUNCTION__, chan);
    return retVal;
}

/* NCO级数 1：单级NCO，即载波NCO，2：两级NCO，载波NCO和频段NCO;
   注意：该级数与是否单频、双频无光，仅与机型支持的OBW带宽有关，超过载波NCO范围时需启用频段NCO */
UINT32 g_aNcoGrade[MAX_CHAN_PER_CHIP][2] = {CARR_NCO_ONLY,};
UINT32 BspGetBoardNcoGrade(UINT32 bspchan,UINT32 dir)
{
    if((bspchan>=MAX_CHAN_PER_CHIP)||(dir>=2))
    {
        dbgInfo("%s:bspchan%d,dir%d err\n",__FUNCTION__,bspchan,dir);
        return g_aNcoGrade[bspchan%MAX_CHAN_PER_CHIP][dir];
    }
    return g_aNcoGrade[bspchan][dir];
}
UINT32 BspSetBoardNcoGrade(UINT32 bspchan,UINT32 dir,UINT32 grade)
{
    if((bspchan>=MAX_CHAN_PER_CHIP)||(dir>=2))
    {
        dbgInfo("%s:bspchan%d,dir%d err\n",__FUNCTION__,bspchan,dir);
        g_aNcoGrade[bspchan%MAX_CHAN_PER_CHIP][dir] = CARR_NCO_ONLY;
        return BSP_ERROR;
    }
    g_aNcoGrade[bspchan][dir] = grade;
    return BSP_OK;
}
PFuncCfrCarrInfoUpdate *pFuncCfrCarrInfoCfg = NULL;

UINT32 BspSetCfrCarrCfgUpdateFunc(PFuncCfrCarrInfoUpdate pFunc)
{
    pFuncCfrCarrInfoCfg = pFunc;
    return BSP_OK;
}

UINT32 BspInitRruTxDifCfgPara(UINT32 chan)
{
    T_RruBandCfgInfo difCfg = {0};
    T_RruBandCfgInfo difOutCfg = {0};
    T_RruDifBandInfo *difBandCfg;
    T_ChanRfCfgPara *pRfCfg;
    UINT32 loop= 0;
    UINT32 uTmp = 0;
    UINT32 bspChan = 0;

    UINT32 ulGetFreqBwpKHz = 0;
    UINT32 bandNo = 0;
    UINT32 freqNcoConstFlag = 0;
    UINT32 freqDynaFlag = BspIsFreqCfgDynamic();
    UINT32 isLoFreqNeedChangeFlag = getNeedRecalLoFlag(TX,0);
    UINT32 ubandidx[2] ={0};
    UINT32 uOutCarr[2] ={0};
    INT32 alBandNcoFreq[3][64] = {0};
    T_DPD_UL_FB_BAND_NCO_INFO *pDpdUlFbBandNco = NULL;
    UINT32 protocol                    = 0;
    UINT32 carrNo = 0;
    UINT32 carrRadio = 0;
    UINT32 ret = BSP_OK;
    UINT32 existItem = 0;

    dbgInfoEx("\n%s>>Chan %d Start!\n",__FUNCTION__, chan);
    if (BspGetBspChnByRfChn(chan,TX,&bspChan) != BSP_OK)
    {
        dbgErr("%s BspGetBspChnByRfChn(%d,TX) return error\n",__FUNCTION__,chan);
        return BSP_ERROR;
    }

    pDpdUlFbBandNco = BspGetDpdUlFbBandNco();
    if(NULL != pDpdUlFbBandNco)
    {
        alBandNcoFreq[TX][bspChan] = pDpdUlFbBandNco[TX].bandNcoInfo[bspChan];
    }
    pRfCfg = GetRfCfgPara(bspChan,TX);
    INPUT_POINTER_CHECK(pRfCfg);
    INPUT_POINTER_CHECK(pRfCfg->para.carrInfo);

    /*BspGetRruTxDifCfgPara(chan, &difCfg);*/
    freqNcoConstFlag = getFreqNcoConstFlag();
    ulGetFreqBwpKHz = BspGetRfCfgBwp();
    difCfg.loFreq = pRfCfg->rfpllFreq;
#ifdef DDPDIC3_R8998G
#else
    /* 临时只赋频段0的参数 */
    difBandCfg = &difCfg.info[0];
    difBandCfg->bandfreq = pRfCfg->centerFreq;
#endif

    dbgInfoEx("%s: carrNum %d \n",__FUNCTION__, pRfCfg->para.carrNum);
    for (loop = 0; loop < pRfCfg->para.carrNum; loop++)
    {
        if ((BspGetBandFlg(TX, chan) != DIF_ONE_BAND) && (BspGetBandFlg(TX, chan) != DIF_MULT_BAND))
        {
            difBandCfg = &difCfg.info[0];
            if((CARR_NCO_ONLY == BspGetBoardNcoGrade(bspChan,TX))||
                (CARR_FREQ_NCO_DLPOST_NCO2 == BspGetBoardNcoGrade(bspChan,TX)))
            {
                difBandCfg->bandfreq = pRfCfg->centerFreq;
            }
            else
            {
                difBandCfg->bandfreq = BspGetBandFreq(TX, chan, bandNo);
            }
            dbgInfoEx("%s:one and multi Carrloop %d, bandfreq %d\n",__FUNCTION__,loop, difBandCfg->bandfreq);
        }
        /*else dpdic_ic3 走else
        {
           if (pRfCfg->para.carrInfo)
            {
                bandNo = BspGetCarrBandFlag(TX, chan, pRfCfg->para.carrInfo[loop].carrNo);//0
                bandNo = (bandNo >= DIF_CFG_BAND_NCO)? (DIF_CFG_BAND_NCO-1) : bandNo;
                difBandCfg = &difCfg.info[bandNo];
                difBandCfg->bandfreq = BspGetBandFreq(TX, chan, bandNo);
            }
            dbgInfoEx("%s:Zero branch Carrloop %d bandfreq %d\n",__FUNCTION__,loop,difBandCfg->bandfreq);
        }   */
        uTmp  = ubandidx[bandNo];
        if (pRfCfg->para.carrInfo)
        {
            difBandCfg->carr[uTmp].carrNo    = pRfCfg->para.carrInfo[loop].carrNo;
            difBandCfg->carr[uTmp].carrFreq  = pRfCfg->para.carrInfo[loop].freq;
            if (ulGetFreqBwpKHz == BSP_ERROR)
            {
                difBandCfg->carr[uTmp].carrBw = pRfCfg->para.carrInfo[loop].bandWidth;
            }
            else
            {
                difBandCfg->carr[uTmp].carrBw = ulGetFreqBwpKHz;
            }
            difBandCfg->carr[uTmp].carrRadio = pRfCfg->para.carrInfo[loop].radioMode;

            if((freqNcoConstFlag && (freqDynaFlag == 0)) || (freqNcoConstFlag && (freqDynaFlag == 1) && (isLoFreqNeedChangeFlag == 0)))
            {
                difBandCfg->carr[uTmp].carrNco   = difBandCfg->carr[uTmp].carrFreq - difBandCfg->bandfreq - CONST_FREQ_NCO_TX;
                dbgInfo("[%s]CarrLoop%2d, carrFreq %d - bandfreq %d - CONST_FREQ_NCO_TX %d = carrNco %d\n", __FUNCTION__,
                           loop, difBandCfg->carr[uTmp].carrFreq, difBandCfg->bandfreq, CONST_FREQ_NCO_TX, difBandCfg->carr[uTmp].carrNco);
            }
            else
            {
                difBandCfg->carr[uTmp].carrNco   = difBandCfg->carr[uTmp].carrFreq - difBandCfg->bandfreq - alBandNcoFreq[TX][bspChan];
                dbgInfo("[%s]CarrLoop%2d, carrFreq %d - bandfreq %d - bandNco %d = carrNco %d\n", __FUNCTION__,
                           loop, difBandCfg->carr[uTmp].carrFreq, difBandCfg->bandfreq, alBandNcoFreq[TX][bspChan], difBandCfg->carr[uTmp].carrNco);
            }
            if(difBandCfg->carr[uTmp].carrRadio == BSP_RADIO_STANDARD_5G)
            {
               #ifdef DDPDIC3_R8998G
                if( (difBandCfg->carr[uTmp].carrBw % 20000) != 0) /*载波拼接按照20M拆分，所以按照20M取余数*/
               {
                   BspSetCfrCarrInfoFlag(1);
               }
               #else
               if( (difBandCfg->carr[uTmp].carrBw % 5000) != 0) /*载波拼接按照5M拆分，所以按照5M取余数*/
               {
                   BspSetCfrCarrInfoFlag(1);
               }
               #endif
            }
            ubandidx[bandNo]++;
        }
    }

    dbgInfoEx("%s: chan %d Func End\n",__FUNCTION__, chan);

    for (loop = 0; loop < pRfCfg->para.carrNum; loop++)
    {
        carrNo = pRfCfg->para.carrInfo[loop].carrNo;
        carrRadio = pRfCfg->para.carrInfo[loop].radioMode;
        if ((BSP_RADIO_STANDARD_LTE_FDD == carrRadio) || (BSP_RADIO_STANDARD_5G == carrRadio))
        {
            existItem = 1;
            dbgInfoEx("%s:chan is %d, carrNo is %d,carrRadio is %#x \n",__FUNCTION__, chan,carrNo,carrRadio);
            break;
        }

    }


    if((NULL != pFuncCfrCarrInfoCfg)&&(0 == BspGetCfrCarrInfoFlag()))
    {
        pFuncCfrCarrInfoCfg(chan, ubandidx, &difCfg, &difOutCfg, uOutCarr, &protocol);

        if (((UINT32)1 == existItem) && ((UINT32)1 == protocol)) //FDD CPRI
        {
            dbgInfo("%s: CPRI chan is %d FDD return \n",__FUNCTION__, chan);
            return ret;
        }

        return BspSetRruTxDifCfgPara(chan,(T_RruBandCfgInfo*)&difOutCfg);

    }

    return BspSetRruTxDifCfgPara(chan,(T_RruBandCfgInfo*)&difCfg);
}
UINT32 BspSetCfgedCarrStatusInfo(UINT32 trxDir, UINT32 bspChnl,T_RfCfgPara *pRfCfgParam)
{
    UINT32 ulCarrIdx = 0;
    UINT32 ulCarrIdx_old = 0;
    UINT32 ulCarrfoundflg = DIF_CARR_NO_FOUND_FLAG;
    UINT32 ulTmpRet = BSP_OK;
    T_RfCfgPara *pRfDelParam_old = NULL;

    INPUT_POINTER_CHECK(pRfCfgParam);
    pRfDelParam_old =  BspGetRfCfgPara(bspChnl, trxDir);
    if(pRfDelParam_old == NULL)
    {
        return ulTmpRet;
    }

    for (ulCarrIdx_old = 0; ulCarrIdx_old < pRfDelParam_old->carrNum; ulCarrIdx_old++)
    {
        for (ulCarrIdx = 0; ulCarrIdx < pRfCfgParam->carrNum; ulCarrIdx++)
        {
            if(pRfCfgParam->carrInfo[ulCarrIdx].radioMode != pRfDelParam_old->carrInfo[ulCarrIdx_old].radioMode)
                continue;
            if(pRfCfgParam->carrInfo[ulCarrIdx].carrNo != pRfDelParam_old->carrInfo[ulCarrIdx_old].carrNo)
                continue;
             ulCarrfoundflg = DIF_CARR_FOUND_FLAG;
        }

        pRfDelParam_old->carrInfo[ulCarrIdx_old].cfgFlag = ulCarrfoundflg;
        ulCarrfoundflg = DIF_CARR_NO_FOUND_FLAG;
    }

    ulTmpRet = BspAddRfCfgPara(bspChnl, trxDir, pRfDelParam_old);

    return ulTmpRet;
}


UINT32 BspClearCfgCarrInfo(UINT32 trxDir, UINT32 bspChnl)
{
    UINT32 ulCarrIdx = 0;
    UINT32 ulTmpRet = BSP_OK;
    const CHAR *pChDirNameStr = NULL;
    T_ChanRfCfgPara *pRfCfgParam = NULL;
    T_RruRfCfgInfo tRruCfgInfo = {0};
    T_RruBandCfgInfo tDifCfgInfo = {0};

    CHNL_DIR_TYPE_NAME_STR(trxDir, pChDirNameStr);

    pRfCfgParam = GetRfCfgPara(bspChnl, trxDir);
    if (NULL == pRfCfgParam)
    {
        dbgErr("%s>>%sChnl'%2d RfCfgParam Get Error! pRfCfgParam cannot NULL!\n",
               __FUNCTION__, pChDirNameStr, bspChnl);
        return BSP_ERROR;
    }

//  ulTmpRet = BspGetRruCfgPara(rfChnl, &tRruCfgInfo);

    ulTmpRet = BspGetChnlCfgCarrPara(bspChnl, &tRruCfgInfo);


    if (ulTmpRet != BSP_OK)
    {
        dbgErr("%s>>%sChnl'%2d ChnlCfgCarrPara Get Error!\n",
               __FUNCTION__, pChDirNameStr, bspChnl);
    }

    if (NULL != pRfCfgParam->para.carrInfo)
    {
        for (ulCarrIdx = 0; ulCarrIdx < pRfCfgParam->para.carrNum; ulCarrIdx++)
        {
            pRfCfgParam->para.carrInfo[ulCarrIdx].carrNo    = 0;
            pRfCfgParam->para.carrInfo[ulCarrIdx].radioMode = 0;
            pRfCfgParam->para.carrInfo[ulCarrIdx].freq      = 0;
            pRfCfgParam->para.carrInfo[ulCarrIdx].bandWidth = 0;
            if (RX == trxDir)
            {
                tRruCfgInfo.rxCfgCarrSum = 0;
                tRruCfgInfo.rxCenterFreq = 0;
            //  tRruCfgInfo.rxRfRangeMinFreq = 0xFFFFFFFF;
            //  tRruCfgInfo.rxRfRangeMaxFreq = 0;
                tRruCfgInfo.carr[ulCarrIdx].carrRxNo    = pRfCfgParam->para.carrInfo[ulCarrIdx].carrNo;
                tRruCfgInfo.carr[ulCarrIdx].carrRxRadio = pRfCfgParam->para.carrInfo[ulCarrIdx].radioMode;
                tRruCfgInfo.carr[ulCarrIdx].carrRxFreq  = pRfCfgParam->para.carrInfo[ulCarrIdx].freq;
                tRruCfgInfo.carr[ulCarrIdx].carrRxBw    = pRfCfgParam->para.carrInfo[ulCarrIdx].bandWidth;
            }
            else// if (TX == trxDir)
            {
                tRruCfgInfo.txCfgCarrSum = 0;
                tRruCfgInfo.txCenterFreq = 0;
            //  tRruCfgInfo.txRfRangeMinFreq = 0xFFFFFFFF;
            //  tRruCfgInfo.txRfRangeMaxFreq = 0;
                tRruCfgInfo.carr[ulCarrIdx].carrTxNo    = pRfCfgParam->para.carrInfo[ulCarrIdx].carrNo;
                tRruCfgInfo.carr[ulCarrIdx].carrTxFreq  = pRfCfgParam->para.carrInfo[ulCarrIdx].freq;
                tRruCfgInfo.carr[ulCarrIdx].carrTxBw    = pRfCfgParam->para.carrInfo[ulCarrIdx].bandWidth;
                tRruCfgInfo.carr[ulCarrIdx].carrTxRadio = pRfCfgParam->para.carrInfo[ulCarrIdx].radioMode;

                tDifCfgInfo.info[0].carr[ulCarrIdx].carrNo    = pRfCfgParam->para.carrInfo[ulCarrIdx].carrNo;
                tDifCfgInfo.info[0].carr[ulCarrIdx].carrRadio = pRfCfgParam->para.carrInfo[ulCarrIdx].radioMode;
                tDifCfgInfo.info[0].carr[ulCarrIdx].carrFreq  = pRfCfgParam->para.carrInfo[ulCarrIdx].freq;
                tDifCfgInfo.info[0].carr[ulCarrIdx].carrBw    = pRfCfgParam->para.carrInfo[ulCarrIdx].bandWidth;
            }
        }
    }
    pRfCfgParam->para.carrNum = 0;

//  if (BSP_OK == ulTmpRet)
    {
        BspSetRruCfgPara(bspChnl, &tRruCfgInfo);
    }

    if (TX == trxDir)
    {
    //  BspSetRruTxDifCfgPara(bspChnl, (T_RruBandCfgInfo *)&tDifCfgInfo);
    }
    dbgInfoEx("%s: tDifCfgInfo.info[0].carr[0].carrBw: %d\n", __FUNCTION__, tDifCfgInfo.info[0].carr[0].carrBw);
    return BSP_OK;
}
/*****************************************************************************
*  函数名称   : BspGetTxChnMaxMinFreq
*  功能描述   : 获取Tx通道最大最小频点信息。
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   :
*             :
*  输出参数   :
*  返 回 值   : BSP_OK  - 成功;其它值为失败
*  其它说明   :
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2015-11-28 14:55:24
*----------------------------------------------------------------------------
*/

UINT32 BspGetTxChnMaxMinFreq(UINT32 bspChn,UINT32 *pMaxFreq,UINT32 *pMinFreq)
{
    T_ChanRfCfgPara *pRfCfg;
    UINT32 carr = 0;
    UINT32 minFreq = 0xFFFFFFFF;
    UINT32 maxFreq = 0;
    if(bspChn >= BspGetTxChannel())
    {
        dbgErr("[%s]bspChn=%u Over Max TxChn \n",__FUNCTION__,bspChn);
        return BSP_ERROR;
    }
    INPUT_POINTER_CHECK(pMaxFreq);
    INPUT_POINTER_CHECK(pMinFreq);
    pRfCfg = GetRfCfgPara(bspChn,TX);
    INPUT_POINTER_CHECK(pRfCfg);
    UINT32 minIdx = 0, maxIdx = 0;

    for (carr = 0; carr < pRfCfg->para.carrNum; carr++)
    {
        if(pRfCfg->para.carrInfo[carr].freq == 0)
        {
            continue;
        }
        if ((pRfCfg->para.carrInfo[carr].freq - pRfCfg->para.carrInfo[carr].bandWidth/2) < minFreq)
        {
            minFreq = pRfCfg->para.carrInfo[carr].freq - pRfCfg->para.carrInfo[carr].bandWidth/2;
            minIdx  = carr;
        }
        if ((pRfCfg->para.carrInfo[carr].freq + pRfCfg->para.carrInfo[carr].bandWidth/2) > maxFreq)
        {
            maxFreq = pRfCfg->para.carrInfo[carr].freq + pRfCfg->para.carrInfo[carr].bandWidth/2;
            maxIdx  = carr;
        }
    }
    dbgInfoEx("%s: minIdx: %d, maxIdx: %d\n", __FUNCTION__, minIdx, maxIdx);
    dbgInfoEx("maxFreq = %d ,minFreq = %d\n",maxFreq,minFreq);
    *pMinFreq = minFreq ;
    *pMaxFreq = maxFreq ;
    return BSP_OK;
}

/*****************************************************************************
*  函数名称   : BspGetRxChnMaxMinFreq
*  功能描述   : 获取Tx通道最大最小频点信息。
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   :
*             :
*  输出参数   :
*  返 回 值   : BSP_OK  - 成功;其它值为失败
*  其它说明   :
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2015-11-28 14:55:24
*----------------------------------------------------------------------------
*/

UINT32 BspGetRxChnMaxMinFreq(UINT32 bspChn,UINT32 *pMaxFreq,UINT32 *pMinFreq)
{
    T_ChanRfCfgPara *pRfCfg;
    UINT32 carr = 0;
    UINT32 minFreq = 0xFFFFFFFF;
    UINT32 maxFreq = 0;
    if(bspChn >= BspGetTxChannel())
    {
        dbgErr("[%s]bspChn=%u Over Max TxChn \n",__FUNCTION__,bspChn);
        return BSP_ERROR;
    }
    INPUT_POINTER_CHECK(pMaxFreq);
    INPUT_POINTER_CHECK(pMinFreq);
    pRfCfg = GetRfCfgPara(bspChn,RX);
    INPUT_POINTER_CHECK(pRfCfg);


    for (carr = 0; carr < pRfCfg->para.carrNum; carr++)
    {
        if(pRfCfg->para.carrInfo[carr].freq == 0)
        {
            continue;
        }
        if ((pRfCfg->para.carrInfo[carr].freq - pRfCfg->para.carrInfo[carr].bandWidth/2) < minFreq)
        {
            minFreq = pRfCfg->para.carrInfo[carr].freq - pRfCfg->para.carrInfo[carr].bandWidth/2;
        }
        if ((pRfCfg->para.carrInfo[carr].freq + pRfCfg->para.carrInfo[carr].bandWidth/2) > maxFreq)
        {
            maxFreq = pRfCfg->para.carrInfo[carr].freq + pRfCfg->para.carrInfo[carr].bandWidth/2;
        }
    }
    dbgInfoEx("maxFreq = %d ,minFreq = %d\n",maxFreq,minFreq);
    *pMinFreq = minFreq ;
    *pMaxFreq = maxFreq ;
    return BSP_OK;
}

/*****************************************************************************
*  函数名称   : BspGetTxChnMaxMinFreq
*  功能描述   : 获取Tx通道最大最小频点信息。
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   :
*             :
*  输出参数   :
*  返 回 值   : BSP_OK  - 成功;其它值为失败
*  其它说明   :
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2015-11-28 14:55:24
*----------------------------------------------------------------------------
*/

UINT32 BspGetTxChnBndMaxMinFreq(UINT32 bspChn,UINT32 bandid,UINT32 *pMaxFreq,UINT32 *pMinFreq)
{
    T_ChanRfCfgPara *pRfCfg;
    UINT32 carr = 0;
    UINT32 minFreq = 0xFFFFFFFF;
    UINT32 maxFreq = 0;
    UINT32 BndmaxFreq = 0,BndminFreq= 0;

    if(bspChn >= BspGetTxChannel())
    {
        dbgErr("[%s]bspChn=%u Over Max TxChn \n",__FUNCTION__,bspChn);
        return BSP_ERROR;
    }
    INPUT_POINTER_CHECK(pMaxFreq);
    INPUT_POINTER_CHECK(pMinFreq);
    pRfCfg = GetRfCfgPara(bspChn,TX);
    INPUT_POINTER_CHECK(pRfCfg);

    BspGetFreqInfoByBandNum(bspChn,TX,bandid,&BndminFreq,&BndmaxFreq);
    dbgInfoEx("BndminFreq = %d ,BndmaxFreq = %d\n",BndminFreq,BndmaxFreq);

    for (carr = 0; carr < pRfCfg->para.carrNum; carr++)
    {
        if(pRfCfg->para.carrInfo[carr].freq == 0)
        {
            continue;
        }

        if((pRfCfg->para.carrInfo[carr].freq <= BndmaxFreq) && (pRfCfg->para.carrInfo[carr].freq>= BndminFreq))
        {
            if ((pRfCfg->para.carrInfo[carr].freq - pRfCfg->para.carrInfo[carr].bandWidth/2) <= minFreq)
            {
                minFreq = pRfCfg->para.carrInfo[carr].freq - pRfCfg->para.carrInfo[carr].bandWidth/2;
            }
            if ((pRfCfg->para.carrInfo[carr].freq + pRfCfg->para.carrInfo[carr].bandWidth/2) >= maxFreq)
            {
                maxFreq = pRfCfg->para.carrInfo[carr].freq + pRfCfg->para.carrInfo[carr].bandWidth/2;
            }
        }
    }
    dbgInfoEx("maxFreq = %d ,minFreq = %d\n",maxFreq,minFreq);
    *pMinFreq = minFreq ;
    *pMaxFreq = maxFreq ;
    return BSP_OK;
}



/*****************************************************************************
*  函数名称   : BspGetTxChnMaxMinFreq
*  功能描述   : 获取Tx通道最大最小频点信息。
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   :
*             :
*  输出参数   :
*  返 回 值   : BSP_OK  - 成功;其它值为失败
*  其它说明   :
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2015-11-28 14:55:24
*----------------------------------------------------------------------------
*/

UINT32 BspGetRxChnBndMaxMinFreq(UINT32 bspChn,UINT32 bandid,UINT32 *pMaxFreq,UINT32 *pMinFreq)
{
    T_ChanRfCfgPara *pRfCfg;
    UINT32 carr = 0;
    UINT32 minFreq = 0xFFFFFFFF;
    UINT32 maxFreq = 0;
    UINT32 BndmaxFreq = 0,BndminFreq= 0;
    UINT32 bspChnMap = 0,bandidmap = 0;

    if(bspChn >= BspGetTxChannel())
    {
        dbgErr("[%s]bspChn=%u Over Max TxChn \n",__FUNCTION__,bspChn);
        return BSP_ERROR;
    }
    INPUT_POINTER_CHECK(pMaxFreq);
    INPUT_POINTER_CHECK(pMinFreq);

    bspChnMap = bspChn;
    bandidmap = bandid;

    if(BspGetChnBandMap != NULL )
    {
        BspGetChnBandMap(bspChn,bandid,&bspChnMap,&bandidmap);
    }

    pRfCfg = GetRfCfgPara(bspChnMap,RX);
    INPUT_POINTER_CHECK(pRfCfg);

    BspGetFreqInfoByBandNum(bspChnMap,RX,bandidmap,&BndminFreq,&BndmaxFreq);
    dbgInfoEx("BndminFreq = %d ,BndmaxFreq = %d\n",BndminFreq,BndmaxFreq);

    for (carr = 0; carr < pRfCfg->para.carrNum; carr++)
    {
        if(pRfCfg->para.carrInfo[carr].freq == 0)
        {
            continue;
        }

        if((pRfCfg->para.carrInfo[carr].freq <= BndmaxFreq) && (pRfCfg->para.carrInfo[carr].freq>= BndminFreq))
        {
            if ((pRfCfg->para.carrInfo[carr].freq - pRfCfg->para.carrInfo[carr].bandWidth/2) <= minFreq)
            {
                minFreq = pRfCfg->para.carrInfo[carr].freq - pRfCfg->para.carrInfo[carr].bandWidth/2;
            }
            if ((pRfCfg->para.carrInfo[carr].freq + pRfCfg->para.carrInfo[carr].bandWidth/2) >= maxFreq)
            {
                maxFreq = pRfCfg->para.carrInfo[carr].freq + pRfCfg->para.carrInfo[carr].bandWidth/2;
            }
        }
    }
    dbgInfoEx("maxFreq = %d ,minFreq = %d\n",maxFreq,minFreq);
    *pMinFreq = minFreq ;
    *pMaxFreq = maxFreq ;
    return BSP_OK;
}

/*********************************************************************/
static T_RfCfgPara txRfCfgPara = {0};
static T_RfCfgPara rxRfCfgPara = {0};

UINT32 DbgClrCarrInfo(UINT32 trxDir)
{
    UINT32 ulLoopCnt = 0;
    UINT32 ulChnlMaxSum = 0;

    if ((TX == trxDir) || (0xFF == trxDir))
    {
        ulChnlMaxSum = BspGetTxChannel();
        for (ulLoopCnt = 0; ulLoopCnt < ulChnlMaxSum; ulLoopCnt++)
        {
            BspClearCfgCarrInfo(trxDir, ulLoopCnt);
        }
    }

    if ((RX == trxDir) || (0xFF == trxDir))
    {
        ulChnlMaxSum = BspGetRxChannel();
        for (ulLoopCnt = 0; ulLoopCnt < ulChnlMaxSum; ulLoopCnt++)
        {
            BspClearCfgCarrInfo(trxDir, ulLoopCnt);
        }
    }

    return BSP_OK;
}

UINT32 BspClearTxRxRfCfg(VOID)
{
    UINT32 ulLoopCnt = 0;
    UINT32 ulChnlMaxSum = 0;
    UINT32 ulRet = BSP_OK;

    ulChnlMaxSum = BspGetTxChannel();
    for (ulLoopCnt = 0; ulLoopCnt < ulChnlMaxSum; ulLoopCnt++)
    {
        ulRet = BspClearCfgCarrInfo(TX, ulLoopCnt);
    }
    ulChnlMaxSum = BspGetRxChannel();
    for (ulLoopCnt = 0; ulLoopCnt < ulChnlMaxSum; ulLoopCnt++)
    {
        ulRet = BspClearCfgCarrInfo(RX, ulLoopCnt);
    }

    return ulRet;
}

static UINT32 InitFreqCarrPara()
{
    T_RfCfgPara *pRfCfgPara;

    pRfCfgPara = &txRfCfgPara;
    pRfCfgPara->carrNum = 0;
    if (pRfCfgPara->carrInfo)
    {
        memset(pRfCfgPara->carrInfo,0,sizeof(T_CarrInfo)*BspGetBspCarrNum());
    }

    pRfCfgPara = &rxRfCfgPara;
    pRfCfgPara->carrNum = 0;
    if (pRfCfgPara->carrInfo)
    {
        memset(pRfCfgPara->carrInfo,0,sizeof(T_CarrInfo)*BspGetBspCarrNum());
    }

    return BSP_OK;
}

static UINT32 SetFreqCarrPara(UINT32 dir,UINT32 carr,UINT32 freq,UINT32 bw,UINT32 radioMode, T_RfCfgPara *pRfCfgPara)
{
    UINT32 loop;
    UINT32 carrNum;
    UINT32 carrMax;
    UINT32 sameFlg;
    const CHAR *pChDirNameStr = NULL;
    const CHAR *pRadioNameStr = NULL;

    CHNL_DIR_TYPE_NAME_STR(dir, pChDirNameStr);
    STD_RADIOMODE_NAME_STR(radioMode, pRadioNameStr);

    carrMax = BspGetBspCarrNum();
    if (pRfCfgPara->carrInfo == NULL)
    {
        pRfCfgPara->carrInfo = malloc(sizeof(T_CarrInfo) * carrMax);
        INPUT_POINTER_CHECK(pRfCfgPara->carrInfo);
        memset(pRfCfgPara->carrInfo, 0, sizeof(T_CarrInfo) * carrMax);

        dbgInfo("%s>>%s Carr'%d Freq'%d Bw'%d %s: CarrInfo malloc\n",
                __FUNCTION__, pChDirNameStr, carr, freq, bw, pRadioNameStr);
    }

    carrNum = pRfCfgPara->carrNum;
    if (carrNum > carrMax)
    {
        dbgErr("%s>>%s Carr'%d CarrSum Over! CarrSum_0(0~%d)= %d\n",
               __FUNCTION__, pChDirNameStr, carr, carrMax, carrNum);
        return BSP_ERROR;
    }

    sameFlg = 0;
    for (loop = 0; loop < carrNum; loop++)
    {
        if (pRfCfgPara->carrInfo[loop].carrNo    == carr &&
            pRfCfgPara->carrInfo[loop].radioMode == radioMode)
        {
            pRfCfgPara->carrInfo[loop].freq      = freq;
            pRfCfgPara->carrInfo[loop].bandWidth = bw;

            sameFlg = 1;
            break;
        }
    }

    if (sameFlg != 0)
    {
        dbgInfo("%s>>%s Carr'%d Freq'%d Bw'%d %s OldRsv: CarrSum(0~%d)= %d\n",
                __FUNCTION__, pChDirNameStr, carr, freq, bw,
                pRadioNameStr, carrMax, pRfCfgPara->carrNum);
        return BSP_OK;
    }

    /* if ((carrNum + 1) > carrMax) */
    if (carrNum >= carrMax)
    {
        dbgErr("%s>>%s Carr'%d CarrSum Over! CarrSum_1(0~%d)= %d\n",
               __FUNCTION__, pChDirNameStr, carr, carrMax, carrNum + 1);
        return BSP_ERROR;
    }

    pRfCfgPara->carrInfo[carrNum].carrNo    = carr;
    pRfCfgPara->carrInfo[carrNum].freq      = freq;
    pRfCfgPara->carrInfo[carrNum].bandWidth = bw;
    pRfCfgPara->carrInfo[carrNum].radioMode = radioMode;
    pRfCfgPara->carrNum++;

    dbgInfo("%s>>%s Carr'%d Freq'%d Bw'%d %s NewAdd: CarrSum(0~%d)= %d\n",
            __FUNCTION__, pChDirNameStr, carr, freq, bw,
            pRadioNameStr, carrMax, pRfCfgPara->carrNum);
    return BSP_OK;
}

UINT32 setfreqpara(UINT32 dirMask,UINT32 carr,UINT32 freq,UINT32 bw,UINT32 radioMode)
{
    if (dirMask == 0)
    {
        InitFreqCarrPara();
    }

    if (dirMask & BIT_SET(TX))
    {
        SetFreqCarrPara(TX,carr,freq,bw,radioMode,&txRfCfgPara);
    }

    if (dirMask & BIT_SET(RX))
    {
        SetFreqCarrPara(RX,carr,freq,bw,radioMode,&rxRfCfgPara);
    }

    return BSP_OK;
}

UINT32 setfreq(UINT32 dirMask,UINT32 startChn,UINT32 endChn)
{
    UINT32 retVal = BSP_OK;
    UINT32 loop;
    UINT32 start, end;

    if ((dirMask & BIT_SET(TX)) && txRfCfgPara.carrNum > 0)
    {
        start = startChn;
        end   = (endChn == 0) ? BspGetTxChannel() : (endChn+1);

        dbgInfo("%s>>######## TxChnl'%2d~%2d CarrSum'%d SetRfCfg ########\n",
                __FUNCTION__, start, end - 1, txRfCfgPara.carrNum);
        for (loop = start; loop < end; loop++)
        {
            retVal |= BspSetTxRfCfg(loop, &txRfCfgPara);
        }

        BspSetRfCfgDbgManuCfgFlag(TX, 1);
    }

    if ((dirMask & BIT_SET(RX)) && rxRfCfgPara.carrNum > 0)
    {
        start = startChn;
        end   = (endChn == 0) ? BspGetRxChannel() : (endChn+1);

        dbgInfo("%s>>######## RxChnl'%2d~%2d CarrSum'%d SetRfCfg ########\n",
                __FUNCTION__, start, end - 1, rxRfCfgPara.carrNum);
        for (loop = start; loop < end; loop++)
        {
            retVal |= BspSetRxRfCfg(loop, &rxRfCfgPara);
        }

        BspSetRfCfgDbgManuCfgFlag(RX, 1);
    }

    dbgInfo("%s>>DirMask'0x%02X Chnl(%d~%d) RfFreqCfg %s!\n",
            __FUNCTION__, dirMask, startChn, endChn,
            (BSP_OK == retVal) ? "Succ" : "Error");

    return BSP_OK;
}

/*****************************************************************************
 * 函数名称: DbgSetRfCfg(*)
 * 功能描述: 单载波频点配置测试命令
 * 输入参数: ulTrxType   - 通道类型; 0: RX, 1: TX, 255: RX&TX
 *           ulChnl      - 通道编号; 范围: 0~7(or 63), 255: 所有天线
 *           ulCarr      - 载波编号; 目前只支持单载波, 固定为0
 *           ulRadioMode - 制式
 *           ulFreqKHz   - 频点
 *           ulBwKHz     - 带宽
 * 输出参数: 无
 * 返 回 值: BSP_OK- 成功; 其他- 失败
 * 其它说明: 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10119095@2018-01-02, 创建
 *----------------------------------------------------------------------------
 */
UINT32 DbgSetRfCfg(UINT32 ulTrxType, UINT32 ulChnl, UINT32 ulCarr,
             UINT32 ulRadioMode, UINT32 ulFreqKHz, UINT32 ulBwKHz)
{
    UINT32 ulChnlIdx = 0;
    UINT32 ulStaChnl = 0;
    UINT32 ulEndChnl = 0;
    UINT32 ulCarrMax = 0;
    UINT32 ulChnlMax = 0;
    UINT32 ulTmpRet  = BSP_OK;
    UINT32 ulCfgRet  = BSP_OK;
    UINT32 ulFuncRet = BSP_OK;
    const CHAR *pChDirName = NULL;
    const CHAR *pRadioName = NULL;
    T_RfCfgPara tRfCfgParam = {0, };
    T_RfCfgPara *pRfCfgPara = NULL;

    STD_RADIOMODE_NAME_STR(ulRadioMode, pRadioName);

    ulCarrMax = BspGetBspCarrNum();
    if (ulCarr >= ulCarrMax)
    {
        dbgErr("%s>>Chnl'%d Carr'%d CarrNo Over! CarrSum(0~%d)= %d\n",
               __FUNCTION__, ulChnl, ulCarr, ulCarrMax, ulCarr);
        return BSP_ERROR;
    }

    pRfCfgPara = &tRfCfgParam;
    pRfCfgPara->carrNum = 0;
    pRfCfgPara->carrInfo = malloc(sizeof(T_CarrInfo) * ulCarrMax);
    if (NULL == pRfCfgPara->carrInfo)
    {
        dbgErr("%s>>Chnl'%d Carr'%d Freq'%d Bw'%d %s: Malloc Error!\n", __FUNCTION__,
               ulChnl, ulCarr, ulFreqKHz, ulBwKHz, pRadioName);
        return BSP_ERROR;
    }
    memset(pRfCfgPara->carrInfo, 0, sizeof(T_CarrInfo) * ulCarrMax);

    pRfCfgPara->carrInfo[ulCarr].carrNo    = ulCarr;
    pRfCfgPara->carrInfo[ulCarr].radioMode = ulRadioMode;
    pRfCfgPara->carrInfo[ulCarr].freq      = ulFreqKHz;
    pRfCfgPara->carrInfo[ulCarr].bandWidth = ulBwKHz;
    pRfCfgPara->carrNum ++;

    if ((TX == ulTrxType) || (0xFF == ulTrxType))
    {
        ulChnlMax = BspGetTxChannel();
        ulStaChnl = (ulChnl < ulChnlMax) ? (ulChnl + 0) : 0;
        ulEndChnl = (ulChnl < ulChnlMax) ? (ulChnl + 1) : ulChnlMax;

        ulTmpRet = BSP_ERROR;
        for (ulChnlIdx = ulStaChnl; ulChnlIdx < ulEndChnl; ulChnlIdx++)
        {
            ulCfgRet = BspSetTxRfCfg(ulChnlIdx, pRfCfgPara);
            if (ulChnlIdx == ulStaChnl)
            {
                ulTmpRet = ulCfgRet;
            }
            else
            {
                ulTmpRet |= ulCfgRet;
            }
        }
        BspSetRfCfgDbgManuCfgFlag(TX, 1);

        CHNL_DIR_TYPE_NAME_STR(TX, pChDirName);
        if (BSP_OK == ulTmpRet)
        {
            dbgInfo("%s>>%sChnl'(%d~%d) CarrIdx'%d CarrSum'%d Freq'%d Bw'%d %s: RfCfg Succ!\n",
                    __FUNCTION__, pChDirName, ulStaChnl, ulEndChnl - 1, ulCarr,
                    pRfCfgPara->carrNum, ulFreqKHz, ulBwKHz, pRadioName);
        }
        else
        {
            dbgErr("%s>>%sChnl'(%d~%d) CarrIdx'%d CarrSum'%d Freq'%d Bw'%d %s: RfCfg Error!\n",
                   __FUNCTION__, pChDirName, ulStaChnl, ulEndChnl - 1, ulCarr,
                   pRfCfgPara->carrNum, ulFreqKHz, ulBwKHz, pRadioName);
        }

        ulFuncRet |= ulTmpRet;
    }

    if ((RX == ulTrxType) || (0xFF == ulTrxType))
    {
        ulChnlMax = BspGetRxChannel();
        ulStaChnl = (ulChnl < ulChnlMax) ? (ulChnl + 0) : 0;
        ulEndChnl = (ulChnl < ulChnlMax) ? (ulChnl + 1) : ulChnlMax;

        ulTmpRet = BSP_ERROR;
        for (ulChnlIdx = ulStaChnl; ulChnlIdx < ulEndChnl; ulChnlIdx++)
        {
            ulCfgRet = BspSetRxRfCfg(ulChnlIdx, pRfCfgPara);
            if (ulChnlIdx == ulStaChnl)
            {
                ulTmpRet = ulCfgRet;
            }
            else
            {
                ulTmpRet |= ulCfgRet;
            }
        }
        BspSetRfCfgDbgManuCfgFlag(RX, 1);

        CHNL_DIR_TYPE_NAME_STR(RX, pChDirName);
        if (BSP_OK == ulTmpRet)
        {
            dbgInfo("%s>>%sChnl'(%d~%d) CarrIdx'%d CarrSum'%d Freq'%d Bw'%d %s: RfCfg Succ!\n",
                    __FUNCTION__, pChDirName, ulStaChnl, ulEndChnl - 1, ulCarr,
                    pRfCfgPara->carrNum, ulFreqKHz, ulBwKHz, pRadioName);
        }
        else
        {
            dbgErr("%s>>%sChnl'(%d~%d) CarrIdx'%d CarrSum'%d Freq'%d Bw'%d %s: RfCfg Error!\n",
                   __FUNCTION__, pChDirName, ulStaChnl, ulEndChnl - 1, ulCarr,
                   pRfCfgPara->carrNum, ulFreqKHz, ulBwKHz, pRadioName);
        }

        ulFuncRet |= ulTmpRet;
    }

    free(pRfCfgPara->carrInfo);
    pRfCfgPara->carrInfo = NULL;

    return ulFuncRet;
}

UINT32 DbgSetCarrNco(UINT32 ulTrxDir, UINT32 ulChnl, UINT32 ulCarr, INT32 iOffFreqKHz)
{
    UINT32 ulTrxType = 0;
    UINT32 ulCarrRadio = 0;
    UINT32 ulRfFreqKHz = 0;
    UINT32 ulBandBwKHz = 0;
    UINT32 ulTmpRet = BSP_OK;
    UINT32 ulFunRet = BSP_OK;

    ulTrxType = (TX == ulTrxDir) ? TX : RX;
    ulCarrRadio = BspGetCarrMode(ulTrxType, ulChnl, ulCarr);
    ulRfFreqKHz = BspGetLoFreqChanged(ulTrxType, ulChnl) + iOffFreqKHz;
    ulBandBwKHz = BspGetFreqBw(ulTrxType, ulChnl, ulCarr);
    RFCFG_PARAM_CHK(BIT_SET(0), 0, ulTrxType, ulChnl, ulCarr, ulCarrRadio, ulRfFreqKHz, ulBandBwKHz);
    RFCFG_PARAM_CHK(BIT_SET(1), 1, ulTrxType, ulChnl, ulCarr, ulCarrRadio, ulRfFreqKHz, ulBandBwKHz);

    ulTmpRet = DbgSetRfCfg(ulTrxType, ulChnl, ulCarr, ulCarrRadio, ulRfFreqKHz, ulBandBwKHz);
    if (BSP_OK != ulTmpRet)
    {
        ulFunRet |= BIT_SET(2);
        dbgErr("%s>>Dir'%d Chnl'%d Carr'%d Radio'%d Freq'%d Bw'%d Cfg Error!\n", __FUNCTION__,
               ulTrxType, ulChnl, ulCarr, ulCarrRadio, ulRfFreqKHz, ulBandBwKHz);
    }
    else
    {
        dbgInfoEx("%s>>Dir'%d Chnl'%d Carr'%d Radio'%d Freq'%d Bw'%d Cfg Succ!\n", __FUNCTION__,
                  ulTrxType, ulChnl, ulCarr, ulCarrRadio, ulRfFreqKHz, ulBandBwKHz);
    }

    return ulFunRet;
}

UINT32 showbspcfg(UINT32 chan,UINT32 dir)
{
    UINT32 loop;
    UINT32 bspChan;
    UINT32 ulRfNcoStep = 0;
    UINT32 ulManuCfgFlg = 0;
    UINT32 ulMaxCarrSum = 0;
    UINT32 ulHwRadioStd = 0;
    UINT32 ulGetFreqBwpKHz = 0;
    UINT32 ulFreqRangeMinKHz = 0;
    UINT32 ulFreqRangeMaxKHz = 0;
    UINT32 ulMinCarrFreqKHz = 0;
    UINT32 ulMaxCarrFreqKHz = 0;
    UINT32 retVal = BSP_OK;
    const CHAR *pChDirNameStr = NULL;
    const char *pDebugInfoStr = NULL;
    const CHAR *pHwRadioStdStr = NULL;
    T_RfCfgPara *pCarr = NULL;
    T_RruRfCfgInfo tRruCfgInfo = {0};
    T_ChanRfCfgPara *pCfgPara = pRfCfgHead;
    pGetRfFreqNcoStep pGetNcoStepFunc = NULL;
    UINT32 ulB2FreqRangeMinKHz = 0;
    UINT32 ulB2FreqRangeMaxKHz = 0;

    ulGetFreqBwpKHz = BspGetRfCfgBwp();
    ulMaxCarrSum    = BspGetBspCarrNum();
    ulHwRadioStd    = BspGetRadioStandard();
    CHNL_DIR_TYPE_NAME_STR(dir, pChDirNameStr);
    STD_RADIOMODE_NAME_STR(ulHwRadioStd, pHwRadioStdStr);

    pGetNcoStepFunc = BspGetRfFreqNcoStepCallBack();
    if (NULL != pGetNcoStepFunc)
    {
        retVal = pGetNcoStepFunc(dir, chan);
        if (0 != retVal)
        {
            ulRfNcoStep = retVal;
        }
        else
        {
            ulRfNcoStep = 0x80000000;
        }
    }
    else
    {
        ulRfNcoStep = 1; /* 兼容其它方案 */
    }
    if (ulRfNcoStep >= 0x7FFFFFFF)
    {
        RedirPrintf("%s>>%sChnl'%2d RfNcoStep Get Error! NcoStep= (0x%X) %d\n",
               __FUNCTION__, pChDirNameStr, chan, ulRfNcoStep, ulRfNcoStep);
    }

    if (BspGetBspChnByRfChn(chan,dir,&bspChan) != BSP_OK)
    {
        RedirPrintf("BspGetBspChnByRfChn(%d,%d) return error\n",chan,dir);
        return BSP_ERROR;
    }

    /*BspGetChnlCfgCarrPara(chan, &tRruCfgInfo);*/
    BspGetChnlCfgCarrPara(chan,&tRruCfgInfo);


    if (TX == dir)
    {
        ulFreqRangeMinKHz = tRruCfgInfo.txRfRangeMinFreq;
        ulFreqRangeMaxKHz = tRruCfgInfo.txRfRangeMaxFreq;
        ulB2FreqRangeMinKHz = tRruCfgInfo.txRfRangeMinFreqB2;
        ulB2FreqRangeMaxKHz = tRruCfgInfo.txRfRangeMaxFreqB2;
    }
    else
    {
        ulFreqRangeMinKHz = tRruCfgInfo.rxRfRangeMinFreq;
        ulFreqRangeMaxKHz = tRruCfgInfo.rxRfRangeMaxFreq;
        ulB2FreqRangeMinKHz = tRruCfgInfo.rxRfRangeMinFreqB2;
        ulB2FreqRangeMaxKHz = tRruCfgInfo.rxRfRangeMaxFreqB2;
    }

    while (pCfgPara)
    {
        if (bspChan == pCfgPara->bspChan && dir == pCfgPara->dir)
        {
            pCarr = &pCfgPara->para;
            ulManuCfgFlg = BspGetRfCfgDbgManuCfgFlag(dir);
            if (0 == ulManuCfgFlg)
            {
                RedirPrintf("============ BBU AUTO CFG: %sNcoStep %d ============\n", pChDirNameStr, ulRfNcoStep);
            }
            else if (1 == ulManuCfgFlg)
            {
                RedirPrintf("============ DBG MANU CFG: %sNcoStep %d ============\n", pChDirNameStr, ulRfNcoStep);
            }
            else
            {
                RedirPrintf("===================================================\n");
            }

            if (0 == (pCfgPara->rfpllFreq % ulRfNcoStep))
            {
                pDebugInfoStr = "  ";
            }
            else
            {
                pDebugInfoStr = "        # Error! LoFreq Isnot NcoStep multiple";
            }
            RedirPrintf("%s rfChan : %d      bspChan: %d\n", pChDirNameStr, chan, bspChan);
            RedirPrintf("BwpFlowFlg: %d      Bwp_KHz: %d\n", s_ulRfCfgBwpSetFlowFlag, ulGetFreqBwpKHz);
            RedirPrintf("FreqRange : %d ~ %d\n", ulFreqRangeMinKHz, ulFreqRangeMaxKHz);
            RedirPrintf("FreqRange(B2): %d ~ %d\n", ulB2FreqRangeMinKHz, ulB2FreqRangeMaxKHz);
            RedirPrintf("centerFreq: %d(%s)\n", pCfgPara->centerFreq, pCfgPara->centerFreqSrc ? "APP" : "BSP");
            RedirPrintf("loFreq    : %d(%s)%s\n", pCfgPara->rfpllFreq, pCfgPara->rfpllFreqSrc ? "APP" : "BSP", pDebugInfoStr);
            RedirPrintf("HwRadioStd: %d (%s)\n", ulHwRadioStd, pHwRadioStdStr);
            RedirPrintf("carrNum   : %d\n", pCarr->carrNum);
            RedirPrintf("%-10s %-10s %-10s %-10s %-7s\n","CarrNo","RfFreqKHz","BandWidth","RadioMode","CfgFlag");
            for (loop = 0; loop < pCarr->carrNum; loop++)
            {
                /* BSP超限判断约束: 实际占用不小于90%带宽, 对应公式 BW*0.9 */
                ulMinCarrFreqKHz = pCarr->carrInfo[loop].freq - pCarr->carrInfo[loop].bandWidth * 9 / 20;
                ulMaxCarrFreqKHz = pCarr->carrInfo[loop].freq + pCarr->carrInfo[loop].bandWidth * 9 / 20;
                if (((ulMinCarrFreqKHz >= ulFreqRangeMinKHz) && (ulMinCarrFreqKHz <= ulFreqRangeMaxKHz) &&
                    (ulMaxCarrFreqKHz >= ulFreqRangeMinKHz) && (ulMaxCarrFreqKHz <= ulFreqRangeMaxKHz) ) ||
                    ((ulMinCarrFreqKHz >= ulB2FreqRangeMinKHz) && (ulMaxCarrFreqKHz <= ulB2FreqRangeMaxKHz)) )
                {
                    if (0 == (pCarr->carrInfo[loop].freq % ulRfNcoStep))
                    {
                        pDebugInfoStr = " ";
                    }
                    else
                    {
                        pDebugInfoStr = "       # Error! RfFreq Isnot NcoStep multiple";
                    }
                    RedirPrintf(" %-10d %-10d %-10d %-10d %-7d %s\n", pCarr->carrInfo[loop].carrNo,
                            pCarr->carrInfo[loop].freq, pCarr->carrInfo[loop].bandWidth,
                            pCarr->carrInfo[loop].radioMode, pCarr->carrInfo[loop].cfgFlag, pDebugInfoStr);
                }
                else
                {
                    RedirPrintf(" %-10d %-10d %-10d %-10d %-7d ## Error: RfFreqBW*0.9(%d~%d) Over FreqRange!\n",
                            pCarr->carrInfo[loop].carrNo, pCarr->carrInfo[loop].freq,
                            pCarr->carrInfo[loop].bandWidth, pCarr->carrInfo[loop].radioMode,
                            pCarr->carrInfo[loop].cfgFlag, ulMinCarrFreqKHz, ulMaxCarrFreqKHz);
                }
            }
        }
        pCfgPara = pCfgPara->next;
    }

    retVal = BspChkRruCfgParamValid(dir, ulMaxCarrSum, &tRruCfgInfo);
    if (retVal != BSP_OK)
    {
        RedirPrintf("****** Error! %sChnl'%2d RfCfgParam Invalid! ******\n", pChDirNameStr, chan);
    }

    return BSP_OK;
}

UINT32 BspRecordCarrNcoFreq(UINT32 dir, UINT32 bspChan, UINT32 carrNo, UINT32 carrNcoFreq)
{
    T_ChanRfCfgPara *pRfCfg;
    UINT32 chanNum = (dir == TX) ? BspGetTxBspChanNum() : BspGetRxBspChanNum();

    if ((bspChan >= chanNum) || (carrNo >= BSP_MAX_CARR_NUM))
    {
        return BSP_ERROR;
    }

    pRfCfg = GetRfCfgPara(bspChan,dir);
    if (pRfCfg == NULL)
    {
        return BSP_ERROR;
    }

    pRfCfg->carrNcoFreq[carrNo] = carrNcoFreq;
    return BSP_OK;
}

VOID rfcfg(UINT32 ulChnlSta, UINT32 ulChnlEnd)
{
    UINT32 ChnlIdx = 0;
    UINT32 ChnlMin = 0;
    UINT32 ChnlMax = 0;
    UINT32 ChnlSum = 0;

    ChnlMin = ulChnlSta;
    ChnlMax = max(ulChnlSta, ulChnlEnd);
    ChnlSum = BspGetTxChannel();
    ChnlMax = min(ChnlMax + 1, ChnlSum);
    for (ChnlIdx = ChnlMin; ChnlIdx < ChnlMax; ChnlIdx++)
    {
        showbspcfg(ChnlIdx, TX);
    }
    RedirPrintf("\n");

    ChnlMin = ulChnlSta;
    ChnlMax = max(ulChnlSta, ulChnlEnd);
    ChnlSum = BspGetRxChannel();
    ChnlMax = min(ChnlMax + 1, ChnlSum);
    for (ChnlIdx = ChnlMin; ChnlIdx < ChnlMax; ChnlIdx++)
    {
        showbspcfg(ChnlIdx, RX);
    }
}

UINT32 ShowRfCfgInfo(UINT32 headPrnCtrl, UINT32 rfChnl, UINT32 dir)
{
    UINT32 CarrInx = 0;
    UINT32 bspChan = 0;
    UINT32 ulMaxCarrSum = 0;
    UINT32 ulMinBwFreqKHz = 0;
    UINT32 ulMaxBwFreqKHz = 0;
    UINT32 retVal = BSP_OK;
    const CHAR *pChDirNameStr = NULL;
    const CHAR *pRadioNameStr = NULL;
    T_RruRfCfgInfo tRruCfgInfo = {0};
    T_RfCfgPara *pChCfgCarr = NULL;
    T_ChanRfCfgPara *pRfCfgParam = NULL;

    ulMaxCarrSum = BspGetBspCarrNum();
    CHNL_DIR_TYPE_NAME_STR(dir, pChDirNameStr);

    retVal = BspGetBspChnByRfChn(rfChnl, dir, &bspChan);
    if (BSP_OK != retVal)
    {
        dbgErr("%s>>%sChnl'%2d GetBspChnl Error! Ret= 0x%X\n",
               __FUNCTION__, pChDirNameStr, rfChnl, retVal);
        return BSP_ERROR;
    }

    pRfCfgParam = GetRfCfgPara(bspChan, dir);

    if (NULL == pRfCfgParam)
    {
        dbgErr("%s>>%sChnl'%2d RfCfgParam Get Error! pRfCfgParam cannot NULL!\n",
               __FUNCTION__, pChDirNameStr, rfChnl);
        return BSP_ERROR;
    }

//  BspGetRruCfgPara(rfChnl, &tRruCfgInfo);
    /*BspGetChnlCfgCarrPara(rfChnl, &tRruCfgInfo);*/

    BspGetChnlCfgCarrPara(rfChnl,&tRruCfgInfo);



    retVal = BspChkRruCfgParamValid(dir, ulMaxCarrSum, &tRruCfgInfo);
    if (retVal != BSP_OK)
    {
        dbgErr("%s>>Error! %sChnl'%2d RfCfgParam Invalid! Ret= 0x%X\n",
               __FUNCTION__, pChDirNameStr, rfChnl, retVal);
    //  return BSP_ERROR;
    }

    if (TX == dir)
    {
        ulMinBwFreqKHz = tRruCfgInfo.txRfRangeMinFreq;
        ulMaxBwFreqKHz = tRruCfgInfo.txRfRangeMaxFreq;
    }
    else
    {
        ulMinBwFreqKHz = tRruCfgInfo.rxRfRangeMinFreq;
        ulMaxBwFreqKHz = tRruCfgInfo.rxRfRangeMaxFreq;
    }

    pChCfgCarr = &pRfCfgParam->para;
    if (NULL == pChCfgCarr->carrInfo)
    {
        dbgErr("%s>>%sChnl'%2d pParaCarrInfo Error! pParaCarrInfo cannot NULL!\n",
               __FUNCTION__, pChDirNameStr, rfChnl);
        return BSP_ERROR;
    }

    if (0 != headPrnCtrl)
    {
        dbgInfo("RfCfgParam(%s) CarrSum'%d: MinBwFreq MaxBwFreq Center(%s) LoFreq(%s) CarrFreqKHz CarrBwKHz FreqOffsetKHz CarrRadioMode   DifIfType\n",
                (BSP_OK == retVal) ? "ChkValid" : "ChkError", pChCfgCarr->carrNum,
                pRfCfgParam->centerFreqSrc ? "App" : "Bsp",
                pRfCfgParam->rfpllFreqSrc ? "App" : "Bsp");
    }

    for (CarrInx = 0; CarrInx < pChCfgCarr->carrNum; CarrInx++)
    {
        STD_RADIOMODE_NAME_STR(pChCfgCarr->carrInfo[CarrInx].radioMode, pRadioNameStr);

        dbgInfo("%sChnl[Rf'%2d Bsp'%2d] CarrNo'%2d:  %-8d  %-8d  %-10d  %-10d  %-10d  %-9d %-12d %-2d: %s %-2d\n",
                pChDirNameStr, rfChnl, bspChan, pChCfgCarr->carrInfo[CarrInx].carrNo, ulMinBwFreqKHz,
                ulMaxBwFreqKHz, pRfCfgParam->centerFreq, pRfCfgParam->rfpllFreq,
                pChCfgCarr->carrInfo[CarrInx].freq, pChCfgCarr->carrInfo[CarrInx].bandWidth, pChCfgCarr->carrInfo[CarrInx].freqOffset,
                pChCfgCarr->carrInfo[CarrInx].radioMode, pRadioNameStr, pChCfgCarr->carrInfo[CarrInx].difIfType);
    }

    return BSP_OK;
}

UINT32 prnrfcfginfo(UINT32 staRfChnl, UINT32 endRfChnl)
{
    UINT32 ChnlIdx = 0;
    UINT32 ChnlMin = 0;
    UINT32 ChnlMax = 0;
    UINT32 headPrnFlag = 0;
    UINT32 retVal = BSP_OK;

    headPrnFlag = 255;
    ChnlMin = staRfChnl;
    ChnlMax = max(staRfChnl, endRfChnl);
    ChnlMax = min(ChnlMax + 1, BspGetTxChannel());
    for (ChnlIdx = ChnlMin; ChnlIdx < ChnlMax; ChnlIdx++)
    {
        retVal |= ShowRfCfgInfo(headPrnFlag, ChnlIdx, TX);
        headPrnFlag = 0;
    }

//  headPrnFlag = 255;
    ChnlMin = staRfChnl;
    ChnlMax = max(staRfChnl, endRfChnl);
    ChnlMax = min(ChnlMax + 1, BspGetRxChannel());
    for (ChnlIdx = ChnlMin; ChnlIdx < ChnlMax; ChnlIdx++)
    {
        retVal |= ShowRfCfgInfo(headPrnFlag, ChnlIdx, RX);
        headPrnFlag = 0;
    }

    return retVal;
}

UINT32 BspRfCfgInfoCollect(VOID)
{
    rfcfg(0, 7);

    return BSP_OK;
}

UINT32 BspGetCfgCarrNum(VOID)
{
    UINT32 bspChan = 0;
    /* UINT32 carrIndex = 0; */
    /* UINT32 retVal = BSP_OK; */
    T_ChanRfCfgPara *pRfCfg;
    /* UINT8 *pChDirNameStr = NULL;
    UINT32 uCarrNo = 0; */
    UINT32 uchan = 0;

    while(uchan<BspGetTxChanNum())
    {
        pRfCfg = GetRfCfgPara(bspChan,TX);
      uchan++;

        if (pRfCfg == NULL)
        {
            continue;
        }
        else
        {
            return pRfCfg->para.carrNum;

        }
    }
    return BSP_ERROR;

}

UINT32 BspGetBw(VOID)
{
    UINT32 freqBw = 0;

    UINT32 uCarrNo = 0;
    UINT32 uchan = 0;

    if(s_uBandStub !=0)
    {
        return s_uBandStub;   /*不配置小区时测试使用*/

    }
    while(uchan<BspGetTxChanNum())
    {
        while(uCarrNo<MAX_CARR_NUM)
        {
           freqBw = BspGetFreqBw(TX, uchan, uCarrNo);
           if(freqBw != BSP_ERROR)
           {
               return freqBw;
        }
            uCarrNo++;
        }
        uchan++;
    }
    return BSP_ERROR;

}
VOID BspSetBwStub(UINT32 uBw)
{
    s_uBandStub = uBw;
}


/*****************************************************************************
 * 函数名称: BspRecordBandFlag(*)
 * 功能描述: 记录当前配置信息属于单频还是双频
 * 输入参数: dir            - 通道类型, 0: RX, 1: TX
 *           bspChan    - 通道号
 *           flag       - 1：单频 2: 双频
 * 输出参数: 无
 * 返 回 值: BSP_OK -  成功; BSP_ERROR- 失败
 * 其它说明: 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *
 *----------------------------------------------------------------------------
 */

UINT32 BspRecordBandFlag(UINT32 dir, UINT32 bspChan, UINT32 flag)
{
    T_ChanRfCfgPara *pRfCfg;
    UINT32 chanNum = (dir == TX) ? BspGetTxBspChanNum() : BspGetRxBspChanNum();

    if (bspChan >= chanNum)
    {
        return BSP_ERROR;
    }

    pRfCfg = GetRfCfgPara(bspChan,dir);
    if (pRfCfg == NULL)
    {
        return BSP_ERROR;
    }

    pRfCfg->bandFlag = flag;
    return BSP_OK;
}


/*****************************************************************************
 * 函数名称: BspGetBandFlg(*)
 * 功能描述: 查询当前配置信息属于单频还是双频
 * 输入参数: dir            - 通道类型, 0: RX, 1: TX
 *           bspChan    - 通道号
 * 输出参数: 无
 * 返 回 值:  1：单频 2: 双频
 * 其它说明: 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *
 *----------------------------------------------------------------------------
 */

UINT32 BspGetBandFlg(UINT32 dir, UINT32 chan)
{
    T_ChanRfCfgPara *pRfCfg;
    UINT32 bspChan = 0;
    UINT32 chanNum = (dir == TX) ? BspGetTxBspChanNum() : BspGetRxBspChanNum();

    if (chan >= chanNum)
    {
        return BSP_ERROR;
    }
    if (BspGetBspChnByRfChn(chan,dir,&bspChan) != BSP_OK)
    {
        return BSP_ERROR;
    }

    pRfCfg = GetRfCfgPara(bspChan,dir);
    if (pRfCfg == NULL)
    {
        return BSP_ERROR;
    }

    return pRfCfg->bandFlag;
}

/*****************************************************************************
 * 函数名称: BspGetSmallBwFlg(*)
 * 功能描述: 查询当前配置信息是否有小带宽载波.
 * 输入参数: dir            - 通道类型, 0: RX, 1: TX
 *           bspChan    - 通道号
 * 输出参数: 无
 * 返 回 值:  1：单频 2: 双频
 * 其它说明: 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *
 *----------------------------------------------------------------------------
 */
UINT32 BspGetSmallBwFlg(UINT32 dir, UINT32 chan)
{
    T_ChanRfCfgPara *pRfCfg;
    UINT32 retval = BSP_OK;
    UINT32 carrNum = 0;
    UINT32 bspChan = 0;

    if (BspGetBspChnByRfChn(chan,dir,&bspChan) != BSP_OK)
    {
        return BSP_ERROR;
    }

    pRfCfg = GetRfCfgPara(bspChan,dir);
    if (pRfCfg == NULL)
    {
        return BSP_ERROR;
    }

    for(carrNum = 0; carrNum < pRfCfg->para.carrNum; carrNum++)
    {
        if(BANDWIDTH_5M == pRfCfg->para.carrInfo[carrNum].bandWidth)
        {
            retval |= DIF_SMALL_BW_5M;
        }

        if(BANDWIDTH_10M == pRfCfg->para.carrInfo[carrNum].bandWidth)
        {
            retval |= DIF_SMALL_BW_10M;
        }

        if(BANDWIDTH_15M == pRfCfg->para.carrInfo[carrNum].bandWidth)
        {
            retval |= DIF_SMALL_BW_15M;
        }

        if(BANDWIDTH_20M == pRfCfg->para.carrInfo[carrNum].bandWidth)
        {
            retval |= DIF_SMALL_BW_20M;
        }
    }

    return retval;
}

/*****************************************************************************
 * 函数名称: BspRecordBandFreq(*)
 * 功能描述: 记录频段中心频点
 * 输入参数: dir            - 通道类型, 0: RX, 1: TX
 *           bspChan    - 通道号
 *           bandNo     - 频段号
 *           bandFreq   - 频段中心频点
 * 输出参数: 无
 * 返 回 值: BSP_OK - 成功  BSP_ERROR - 失败
 * 其它说明: 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *
 *----------------------------------------------------------------------------
 */
UINT32 BspRecordBandFreq(UINT32 dir, UINT32 bspChan, UINT32 bandNo, UINT32 bandFreq)
{
    T_ChanRfCfgPara *pRfCfg;
    UINT32 chanNum = (dir == TX) ? BspGetTxBspChanNum() : BspGetRxBspChanNum();

    if ((bspChan >= chanNum) || (bandNo >= BSP_MAX_BAND_PER_CH))
    {
        return BSP_ERROR;
    }

    pRfCfg = GetRfCfgPara(bspChan,dir);
    if (pRfCfg == NULL)
    {
        return BSP_ERROR;
    }

    pRfCfg->bandFreq[bandNo] = bandFreq;
    return BSP_OK;
}

UINT32 BspGetCarrNcoFreq(UINT32 dir, UINT32 chan, UINT32 carrNo)
{
    T_ChanRfCfgPara *pRfCfg;
    UINT32 bspChan = 0;
    UINT32 chanNum = (dir == TX) ? BspGetTxBspChanNum() : BspGetRxBspChanNum();

    if ((chan >= chanNum) || (carrNo >= BSP_MAX_CARR_NUM))
    {
        return BSP_ERROR;
    }
    if (BspGetBspChnByRfChn(chan,dir,&bspChan) != BSP_OK)
    {
        return BSP_ERROR;
    }

    pRfCfg = GetRfCfgPara(bspChan,dir);
    if (pRfCfg == NULL)
    {
        return BSP_ERROR;
    }

    return pRfCfg->carrNcoFreq[carrNo];
}

/*****************************************************************************
 * 函数名称: BspRecordBandFreq(*)
 * 功能描述: 获取频段中心频点
 * 输入参数: dir            - 通道类型, 0: RX, 1: TX
 *           bspChan    - 通道号
 *           bandNo     - 频段号
 * 输出参数: 无
 * 返 回 值: BSP_OK - 成功  BSP_ERROR - 失败
 * 其它说明: 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *
 *----------------------------------------------------------------------------
 */
UINT32 BspGetBandFreq(UINT32 dir, UINT32 chan, UINT32 bandNo)
{
    T_ChanRfCfgPara *pRfCfg;
    UINT32 bspChan = 0;
    UINT32 chanNum = (dir == TX) ? BspGetTxBspChanNum() : BspGetRxBspChanNum();

    if ((chan >= chanNum) || (bandNo >= BSP_MAX_BAND_PER_CH))
    {
        return BSP_ERROR;
    }
    if (BspGetBspChnByRfChn(chan,dir,&bspChan) != BSP_OK)
    {
        return BSP_ERROR;
    }

    pRfCfg = GetRfCfgPara(bspChan,dir);
    if (pRfCfg == NULL)
    {
        return BSP_ERROR;
    }

    return pRfCfg->bandFreq[bandNo];
}


/*****************************************************************************
 * 函数名称: BspRecordBandFreq(*)
 * 功能描述: 记录载波的频段号
 * 输入参数: dir            - 通道类型, 0: RX, 1: TX
 *           bspChan    - 通道号
 *           carrNo     - 载波号
 *           bandNo     - 频段号
 * 输出参数: 无
 * 返 回 值: BSP_OK - 成功  BSP_ERROR - 失败
 * 其它说明: 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *
 *----------------------------------------------------------------------------
 */
UINT32 BspRecordCarrBandFlag(UINT32 dir, UINT32 bspChan, UINT32 carrNo, UINT32 bandNo)
{
    T_ChanRfCfgPara *pRfCfg;
    UINT32 chanNum = (dir == TX) ? BspGetTxBspChanNum() : BspGetRxBspChanNum();

    if((bspChan >= chanNum) || (bandNo >= BSP_MAX_BAND_PER_CH) || (carrNo >= BSP_MAX_CARR_NUM))
    {
        return BSP_ERROR;
    }

    pRfCfg = GetRfCfgPara(bspChan,dir);
    if (pRfCfg == NULL)
    {
        return BSP_ERROR;
    }

    pRfCfg->carrBandFlag[carrNo] =bandNo;
    return BSP_OK;
}

/*****************************************************************************
 * 函数名称: BspRecordBandFreq(*)
 * 功能描述: 查询载波的频段号
 * 输入参数: dir            - 通道类型, 0: RX, 1: TX
 *           bspChan    - 通道号
 *           carrNo     - 载波号
 * 输出参数: 无
 * 返 回 值: 频段号
 * 其它说明: 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *
 *----------------------------------------------------------------------------
 */
UINT32 BspGetCarrBandFlag(UINT32 dir, UINT32 chan, UINT32 carrNo)
{
    T_ChanRfCfgPara *pRfCfg;
    UINT32 bspChan = 0;
    UINT32 chanNum = (dir == TX) ? BspGetTxBspChanNum() : BspGetRxBspChanNum();

    if ((chan >= chanNum) || (carrNo >= BSP_MAX_CARR_NUM))
    {
        return BSP_ERROR;
    }
    if (BspGetBspChnByRfChn(chan,dir,&bspChan) != BSP_OK)
    {
        return BSP_ERROR;
    }

    pRfCfg = GetRfCfgPara(bspChan,dir);
    if (pRfCfg == NULL)
    {
        return BSP_ERROR;
    }

    return pRfCfg->carrBandFlag[carrNo];
}

/*****************************************************************************
 * 函数名称: BspRecordBandFreq(*)
 * 功能描述: 查询载波在对应频段内的载波号
 * 输入参数: dir            - 通道类型, 0: RX, 1: TX
 *           bspChan    - 通道号
 *           carrNo     - 载波号
 * 输出参数: 无
 * 返 回 值: 频段号
 * 其它说明: 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *
 *----------------------------------------------------------------------------
 */

UINT32 BspGetBandCarrNo(UINT32 dir, UINT32 chan, UINT32 carrNo)
{
    T_ChanRfCfgPara *pRfCfg;
    UINT32 bspChan = 0;
    UINT32 bandNo = 0;
    UINT32 loop = 0;
    UINT32 cnt  = 0;
    UINT32 chanNum = (dir == TX) ? BspGetTxBspChanNum() : BspGetRxBspChanNum();

    if ((chan >= chanNum) || (carrNo >= BSP_MAX_CARR_NUM))
    {
        return BSP_ERROR;
    }
    if (BspGetBspChnByRfChn(chan,dir,&bspChan) != BSP_OK)
    {
        return BSP_ERROR;
    }

    pRfCfg = GetRfCfgPara(bspChan,dir);
    if (pRfCfg == NULL)
    {
        return BSP_ERROR;
    }

    bandNo = BspGetCarrBandFlag(dir, chan, carrNo);
    for (loop = 0; loop< min(BSP_MAX_CARR_NUM,carrNo+1); loop++)
    {
        if (pRfCfg->carrBandFlag[loop] == bandNo)
        {
            cnt++;
        }
    }
    return cnt-1;
}

UINT32 testUnfixLoCalc(VOID)
{
    if(NULL != pfCalcUnifixLoCom)
    {
        return pfCalcUnifixLoCom(&txRfCfgPara);
    }
    dbgErr("pftestCalCUnifixLo is Null");
    return BSP_ERROR;
}

UINT32 BspGetChanFreqIbw(UINT32 dir, UINT32 chanNo)
{
    UINT32 retVal  = 0;
    /* UINT32 bwSum   = 0; */
    UINT32 maxFreq = 0;
    UINT32 minFreq = 0;

    if (dir == TX)
    {
        retVal = BspGetTxChnMaxMinFreq(chanNo,&maxFreq,&minFreq);
    }
    else
    {
        retVal = BspGetRxChnMaxMinFreq(chanNo,&maxFreq,&minFreq);
    }
    if (retVal != BSP_OK)
    {
        return 0;
    }
    return (maxFreq - minFreq);
}

VOID  BspSetCarrCfgBw(UINT32 uCarrBw)
{
     g_uCarrBw = uCarrBw;
}

UINT32 BspGetCarrCfgBw(VOID)
{
   return   g_uCarrBw ;
}

/**********************************************************************
* 函数名称: BspSetTransceiverLoFreq(*)
* 功能描述: (动态本振方案)高层关功放后,重配本振动作.
* 输入参数: trx-上下行     chan-通道号     freq-本振频点
* 输出参数: 无
* 返 回 值:
* 其它说明: 不同transceiver所对应动作不同,高层动作统一,故平台定义该接口,挂回调由单板实现.
* ---------------------------------------------------------------------------
* 修改日期         修改人    修改内容
* 2020-11-03
***********************************************************************
*/
UINT32 BspSetTransceiverLoFreq(UINT32 trx, UINT32 chan, UINT32 freq)
{
    BspLog(LOG_LEVEL_0,"[%s] trx'%d chan %d freq %d\n",__FUNCTION__,trx, chan, freq);

    if(FuncInstGetRfFpgaTddioSwitch) 
    {
        FuncInstGetRfFpgaTddioSwitch();
    }

    if (pFuncHandleReCfgLoFreq)
    {
        return pFuncHandleReCfgLoFreq(trx, chan, freq);
    }
    return BSP_OK;
}

/**********************************************************************
* 函数名称: BspHandlePrePaCtrl(*)
* 功能描述: (动态本振方案)高层关功放后,重配本振前动作.停掉transceiver tracking动作,以及重配本振时保证外围开关稳定
* 输入参数: trx-上下行     chan-通道号
* 输出参数: 无
* 返 回 值:
* 其它说明: 不同transceiver所对应动作不同,高层动作统一,故平台定义该接口,挂回调由单板实现.
* ---------------------------------------------------------------------------
* 修改日期         修改人    修改内容
* 2020-11-03
***********************************************************************
*/
UINT32 BspHandlePreLoReCfg(UINT32 trx, UINT32 chan)
{
    BspLog(LOG_LEVEL_0,"[%s] trx'%d chan %d\n",__FUNCTION__,trx, chan);

    if(FuncInstGetRfFpgaTddioSwitch) 
    {
        FuncInstGetRfFpgaTddioSwitch();
    }

    if (pFuncHandlePreLoReCfg)
    {
        return pFuncHandlePreLoReCfg(trx, chan);
    }
    return BSP_OK;
}

/**********************************************************************
* 函数名称: BspHandlePostPaCtrl(*)
* 功能描述: (动态本振方案)高层重配本振完成后,开功放前动作.
* 输入参数: trx-上下行     chan-通道号
* 输出参数: 无
* 返 回 值: 1:新方案   0:其他老方案
* 其它说明: 不同transceiver所对应动作不同,高层动作统一,故平台定义该接口,挂回调由单板实现.
* ---------------------------------------------------------------------------
* 修改日期         修改人    修改内容
* 2020-11-03
***********************************************************************
*/
UINT32 BspHandlePostLoReCfg(UINT32 trx, UINT32 chan)
{
    BspLog(LOG_LEVEL_0,"[%s] trx'%d chan %d\n",__FUNCTION__,trx, chan);

    if(FuncInstGetRfFpgaTddioSwitch) 
    {
        FuncInstGetRfFpgaTddioSwitch();
    }

    if (pFuncHandlePostLoReCfg)
    {
        return pFuncHandlePostLoReCfg(trx, chan);
    }
    return BSP_OK;
}

static void prnrxcarr1()
{
    UINT32 antidx=0;
    UINT32 carridx=0;
    T_DestCarrInfoAllChans *carrInfoAllChn = BspGetCarrInfoAllChansCmmn();

    if (carrInfoAllChn == NULL)
    {
        return;
    }
    dbgInfo("rxChanNum %d\n",carrInfoAllChn->rxChanNum);
    for(antidx=0;antidx<carrInfoAllChn->rxChanNum;antidx++)
    {
        dbgInfo("chanNo %d\n",carrInfoAllChn->rxCarrInfo[antidx].chanNo);
        dbgInfo("carrNum %d\n",carrInfoAllChn->rxCarrInfo[antidx].carrNum);
        for(carridx=0;carridx<carrInfoAllChn->rxCarrInfo[antidx].carrNum;carridx++)
        {
            dbgInfo("carrNo %d,radioMode %d,freq %d,bandWidth %d\n",
                    carrInfoAllChn->rxCarrInfo[antidx].carrInfo[carridx].carrNo,
                    carrInfoAllChn->rxCarrInfo[antidx].carrInfo[carridx].radioMode,
                    carrInfoAllChn->rxCarrInfo[antidx].carrInfo[carridx].freq,
                    carrInfoAllChn->rxCarrInfo[antidx].carrInfo[carridx].bandWidth
                    );
        }
    }
}
static void prntxcarr1()
{
    UINT32 antidx=0;
    UINT32 carridx=0;
    T_DestCarrInfoAllChans *carrInfoAllChn = BspGetCarrInfoAllChansCmmn();

    if (carrInfoAllChn == NULL)
    {
        return;
    }
    dbgInfo("txChanNum %d\n",carrInfoAllChn->txChanNum);
    for(antidx=0;antidx<carrInfoAllChn->txChanNum;antidx++)
    {
        dbgInfo("chanNo %d\n",carrInfoAllChn->txCarrInfo[antidx].chanNo);
        dbgInfo("carrNum %d\n",carrInfoAllChn->txCarrInfo[antidx].carrNum);
        for(carridx=0;carridx<carrInfoAllChn->txCarrInfo[antidx].carrNum;carridx++)
        {
            dbgInfo("carrNo %d,radioMode %d,freq %d,bandWidth %d\n",
                    carrInfoAllChn->txCarrInfo[antidx].carrInfo[carridx].carrNo,
                    carrInfoAllChn->txCarrInfo[antidx].carrInfo[carridx].radioMode,
                    carrInfoAllChn->txCarrInfo[antidx].carrInfo[carridx].freq,
                    carrInfoAllChn->txCarrInfo[antidx].carrInfo[carridx].bandWidth
                    );
        }
    }
}
/*获取所有小区的载波制式，用于区分单模混模*/
UINT32 BspGetCarrRadioMixMode()
{
    UINT32 carrNum = 0;
    UINT32 chan = 0;
    UINT32 carr = 0;
    UINT32 carrRadio = 0;
    UINT32 mixMode = 0;
    T_ChanRfCfgPara *pRfCfg = NULL;

    for(chan = 0; chan < BspGetTxChannel(); chan++)
    {
        carrNum = BspGetRfCfgCarrSum(TX,chan);
        if (carrNum == BSP_ERROR)
        {  /*劈裂时打印刷屏 增加开关*/
            dbgInfoEx("%s,chan:%d get carrNum error!\n",__FUNCTION__,chan);
            continue;  /*小区劈裂 部分通道可以没有配置*/
        }
        pRfCfg = GetRfCfgPara(chan, TX);
        if (pRfCfg == NULL)
        {
            dbgErr("%s>> Chnl'%d RfCfgParam Get Error!\n",
                   __FUNCTION__, chan);
            return BSP_ERROR;
        }
        for(carr = 0; carr < carrNum; carr++)   /*BspGetRfCfgCarrSum 已经加了足够的校验*/
        {
            carrRadio = pRfCfg->para.carrInfo[carr].radioMode;
            dbgInfoEx("chan:%d carr %d carrRadio 0x%x\n",chan,carr, carrRadio);
            mixMode |= carrRadio;
        }
    }
    return mixMode;
}

UINT32 showrfcfgchangetime(VOID)
{
    dbgInfo("Mode [%s]\t Change Times[%u]\n", (g_RfCfgChangeTime % 2 == 0)? "Normal" : "AC", g_RfCfgChangeTime);
    return BSP_OK;
}

/* Started by AICoder, pid:k2312y1e00of1be14eb60abc90676821a96451e2 */
UINT32 BspInitRruCfgParaForBothDirections(UINT32 bspChn)
{
    UINT32 retVal = BSP_OK;
    retVal |= BspInitRruCfgPara(bspChn, TX);
    retVal |= BspInitRruCfgPara(bspChn, RX);
    return retVal;
}

UINT32 BspChangeRfCfgDir(UINT32 bspChn)
{
    UINT32 retVal = BSP_OK;
    T_ChanRfCfgPara *pRftxCfg = GetRfCfgPara(bspChn, TX);
    T_ChanRfCfgPara *pRfrxCfg = GetRfCfgPara(bspChn, RX);

    INPUT_POINTER_CHECK(pRftxCfg);
    INPUT_POINTER_CHECK(pRfrxCfg);

    pRfrxCfg->dir = TX;
    pRftxCfg->dir = RX;

    retVal = BspInitRruCfgParaForBothDirections(bspChn);

    if (retVal  != BSP_OK)
    {
        retVal = BSP_ERROR;
        dbgErr("%s, change rf cfg dir err!\n", __FUNCTION__);
    }
    else
    {
        g_RfCfgChangeTime++;
        //Default is Normal Mode, Odd Order is AC Mode, Even Order is Normal, so below mod 2
        dbgInfo("Mode [%s]\t Change Times[%u]\n", (g_RfCfgChangeTime % 2 == 0) ? "Normal" : "AC", g_RfCfgChangeTime);
    }

    return retVal;
}
/* Ended by AICoder, pid:k2312y1e00of1be14eb60abc90676821a96451e2 */

UINT32 BspSetUMTSRssiOptimizeSw(UINT32 bspChn, UINT32 carrNo, UINT32 sw)
{
    BspLog(LOG_LEVEL_0,"[%s] bspChn'%d carrNo %d  sw %d! \n",__FUNCTION__, bspChn, carrNo, sw);
    if ((bspChn >= BspGetRxBspChanNum()) || (carrNo >=BSP_MAX_CARR_NUM))
    {
        return BSP_ERROR;
    }
    s_ulUmtsRssiOptimizeFlag[bspChn][carrNo] = sw;
    return BSP_OK;
}

UINT32 BspGetUMTSRssiOptimizeSw(UINT32 bspChn, UINT32 carrNo)
{
    if ((bspChn >= BspGetRxBspChanNum()) || (carrNo >=BSP_MAX_CARR_NUM))
    {
        return BSP_ERROR;
    }
    return s_ulUmtsRssiOptimizeFlag[bspChn][carrNo];
}

UINT32 BspGetCarrCopyType(UINT32 dir, UINT32 chan, UINT32 carrNo)
{
    UINT32 bspChan = 0;
    UINT32 carrIndex = 0;
    UINT32 retVal = BSP_OK;
    T_ChanRfCfgPara *pRfCfg = NULL;
    const CHAR *pChDirNameStr = NULL;
    T_RruRfCfgInfo tRruCfgInfo = {0};
    UINT32 chanNum = (dir == TX) ? BspGetTxBspChanNum() : BspGetRxBspChanNum();

    CHNL_DIR_TYPE_NAME_STR(dir, pChDirNameStr);

    if (chan >= chanNum)
    {
        dbgInfo("%s>>Error! ParamChnl Over! %sChnl(0~%d)= %d\n",
               __FUNCTION__, pChDirNameStr, chanNum - 1, chan);
        return BSP_ERROR;
    }
    if (BspGetBspChnByRfChn(chan,dir,&bspChan) != BSP_OK)
    {
        dbgInfo("%s>>%sChnl'%d Carr'%d BspChnl Get Error!\n",
               __FUNCTION__, pChDirNameStr, chan, carrNo);
        return BSP_ERROR;
    }

    pRfCfg = GetRfCfgPara(bspChan,dir);
    if (pRfCfg == NULL)
    {
        dbgInfo("%s>>%sChnl'%d Carr'%d RfCfgParam Get Error!\n",
               __FUNCTION__, pChDirNameStr, chan, carrNo);
        return BSP_ERROR;
    }

    BspGetChnlCfgCarrPara(chan, &tRruCfgInfo);
    retVal = BspChkRruCfgParamValid(dir, carrNo, &tRruCfgInfo);
    if (retVal != BSP_OK)
    {
        return BSP_ERROR;
    }

    for (carrIndex = 0; carrIndex < pRfCfg->para.carrNum; carrIndex++)
    {
        if (carrNo == pRfCfg->para.carrInfo[carrIndex].carrNo)
            break;
    }
    if (carrIndex == pRfCfg->para.carrNum)
    {
        dbgInfo("%s>>Error! %sChnl'%d Carr'%d RfCfgParam Invalid!\n",
                     __FUNCTION__, pChDirNameStr, chan, carrNo);
        return BSP_ERROR;
    }
    else
    {
        return pRfCfg->para.carrInfo[carrIndex].carrCopyType;
    }
}

/*****************************************************************************
* 版权所有(C) 2017, ZTE Corp. ZXSDR-RRU Platform BSP
*----------------------------------------------------------------------------
* 模 块 名 : bsp
* 文件名称 : timedelay_opt.h
* 文件标识 : {[N/A]}
* 内容摘要 : 本文件提供了时延接口声明
* 注意事项 : 无
* 作    者 :   10090699
* 创建日期 : 2017-03-08
* 当前版本 : Ver1.0
*----------------------------------------------------------------------------
* 变更记录 :
*
* $记录1
* 变 更 单: $0000000(N/A)
* 责 任 人: 10090699
* 修改日戳: 2017-03-08
* 变更说明: 创建文件
*----------------------------------------------------------------------------
*/

#ifndef _FUNCLIB_TIMEDELAY_IC4_2_INTERFACE_H_
#define _FUNCLIB_TIMEDELAY_IC4_2_INTERFACE_H_


#ifdef __cplusplus
extern "C" {
#endif


#include "timedelayapi.h"

#define RADIO_5G_FRAME_FLAG  0
#define RADIO_LTE_FRAME_FLAG 1
#define RADIO_FRAME_FLAG_NUM 2
typedef UINT32 (*FUN_DPD_SEND_FRDIFF_PTR)(UINT32 bspChn,UINT32 frOffSetNs,UINT32 tddRamFrOffSetNs); 
typedef UINT32 (*FUNC_BSP_SAVE_UEADV_FOR_FPGA)(VOID);
UINT32 BspSetT34(UINT32 optIndex, UINT32 t34Delay);
UINT32 BspSetOptCarrDelay(UINT32 uChan,UINT32 uRadioMode,T_BspCarrDelayItem *ptCarrDelayItem);
UINT32 BspSetOptCarrDelay_Check(UINT32 uChan,UINT32 uRadioMode,T_BspCarrDelayItem *ptCarrDelayItem);
UINT32 BspSetOptCarrDelayQcell(UINT32 uChan,UINT32 uRadioMode,T_BspCarrDelayItem *ptCarrDelayItem,UINT32 uiCarrDlyFlag);
UINT32 BspSetOptCarrDelayQcellByDir(UINT32 uChan,UINT32 uRadioMode,T_BspCarrDelayItem *ptCarrDelayItem, UINT32 dir);
UINT32 BspSetCpeTxTimingAdvance(UINT32 cellId, UINT32 radioMod, UINT32 cpeMode);
VOID BspSetDpdFrDiffCallBackInit(FUN_DPD_SEND_FRDIFF_PTR pFRDiffPtr);
INT32 BspGetFrameAlignmentVal(UINT32 bandId, UINT32 radioMode);
UINT32 BspGetT12T34Delay(T_RruDelayReq *pTRruDelay);
UINT32 BspGetTaDelay(UINT32 *pTaDelay);
UINT32 BspGetDelayTbuffMax(T_TbuffCarrInfo *pTbuffCarrInfo, UINT32 *pTbuffMax);
UINT32 BspGetDelayTbuff(T_TbuffCarrInfo *pTbuffCarrInfo,  UINT32 *pTbuff);
UINT32 BspSetSlaveToffset(UINT32 logNo, UINT32 toffset);
UINT32 BspSetSlaveRfRxFrameDelay(UINT32 logNo, UINT32 taDelay, UINT32 hwLinkDelay);
UINT32 BspSetRfRxFrameDelay(UINT32 optIndex, UINT32 taDelay, UINT32 hwLinkDelay);
UINT32 BspJudgeIsMainOpt(UINT32 optIndex);
UINT32 BspSetSwRadioModeAndFrOffSet(UINT32 uiRadioMode, INT32 chip);
/* Started by AICoder, pid:vf4e76a60dqd56b1408408aa107c4806be691917 */
UINT32 BspGetFddUeAdvance(VOID);
VOID BspSetFuncSaveUeAdv(FUNC_BSP_SAVE_UEADV_FOR_FPGA pFunc);
UINT32 BspSetFddUeAdvance(UINT32 tmpVal);
/* Ended by AICoder, pid:vf4e76a60dqd56b1408408aa107c4806be691917 */
#ifdef __cplusplus
}
#endif
#endif 



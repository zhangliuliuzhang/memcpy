/*****************************************************************************
* 版权所有(C) 2017, ZTE Corp. ZXSDR-RRU Platform BSP
*----------------------------------------------------------------------------
* 模 块 名 : bsp
* 文件名称 : timedelay_opt.h
* 文件标识 : {[N/A]}
* 内容摘要 : 本文件提供了时延接口声明
* 注意事项 : 无
* 作    者 :   10090699
* 创建日期 : 2017-03-08
* 当前版本 : Ver1.0
*----------------------------------------------------------------------------
* 变更记录 :
*
* $记录1
* 变 更 单: $0000000(N/A)
* 责 任 人: 10090699
* 修改日戳: 2017-03-08
* 变更说明: 创建文件
*----------------------------------------------------------------------------
*/

#ifndef _FUNCLIB_TIMEDELAY_IC4_2_DEBUG_H_
#define _FUNCLIB_TIMEDELAY_IC4_2_DEBUG_H_

#include "timedelay_ic4_2.h"

#ifdef __cplusplus
extern "C" {
#endif


#define maxFrAlignRecNum 4  /*funclib记录高层下发帧头信息的最大次数*/

typedef struct tagT_FrAlignParaFuncWc
{
    UINT32 bandId;     /*频段号*/
    UINT32 radioMode;  /*制式*/
    INT32 frameDelay;  /*高层下发的帧头调整量*/
    INT32 frameDelayns;  /*传给HAL层帧头调整量,单位ns*/
}T_FrAlignParaFuncWc;

UINT32 setFddCarrDly(UINT32 chan,UINT32 radio,UINT32 carrNo,UINT32 dlFwdDelay,UINT32 ulFwdDelay,UINT32 dlRvsDelay,UINT32 ulRvsDelay);
VOID showtddioadvgapval(VOID);
VOID showcpetimeadvcfg(VOID);
VOID dbgSaveIoUeAdvGapVal(UINT32 radio, UINT32 ueAdvValNs, UINT32 ueGapValNs, UINT32 mixModAdvComp);
VOID dbgSaveCpeTimeAdvCfg(UINT32 cellId, UINT32 radioMod, UINT32 cpeMode);
UINT32 dbgGetCpeTxTimingAdvNs(VOID);
VOID dbgSetCpeTxTimingAdvNs(UINT32 ulCpeAdvNs);
VOID dbgSaveFrameAlignment(UINT32 bandId, UINT32 radioMode, INT32 lFrameDelayApp, INT32 lFrameDelayHal);
VOID showupdatecarrdlyrecord(UINT32 bspChan);
VOID showupdatecarrdlyrecordByDir(UINT32 bspChan, UINT32 dir);
VOID dbgSaveUpdateCarrDlyRecordByDir(UINT32 difChan, UINT32 dir, UINT32 carrNum);
VOID dbgSaveUpdateCarrDlyRecord(UINT32 difChan, UINT32 carrNum);
UINT32 dbgFddDlyReportInfoSave(UINT32 radio, T_NewRruOptDelayPara *ptOptDelayPara);
#ifdef __cplusplus
}
#endif
#endif 



/*****************************************************************************
* 版权所有(C) 2017, ZTE Corp. ZXSDR-RRU Platform BSP
*----------------------------------------------------------------------------
* 模 块 名 : bsp
* 文件名称 : timedelay_opt.h
* 文件标识 : {[N/A]}
* 内容摘要 : 本文件提供了时延接口声明
* 注意事项 : 无
* 作    者 :   10090699
* 创建日期 : 2017-03-08
* 当前版本 : Ver1.0
*----------------------------------------------------------------------------
* 变更记录 :
*
* $记录1
* 变 更 单: $0000000(N/A)
* 责 任 人: 10090699
* 修改日戳: 2017-03-08
* 变更说明: 创建文件
*----------------------------------------------------------------------------
*/

#ifndef _FUNCLIB_TIMEDELAY_IC4_2_H_
#define _FUNCLIB_TIMEDELAY_IC4_2_H_



#ifdef __cplusplus
extern "C" {
#endif


#include "bsppub.h"
#include "bspcomm.h"
#include "ichaladaptbspapi.h"
#include "ichaladaptcommon.h"
#include "ichaldbg_ic4_2.h"
#include "funccommon_carrmap.h"
#include "funccommon_log.h"
#include "chnmap_a.h"
#include "dif_dly_api.h"
#include "freqcfgcommon.h"

#define SINGEL_NR_NODE (UINT32)(13021)  /* 单位 ns, (1600)/122.88*1000 */
#define MIX_NR_MODE    (UINT32)(20313)  /* 单位 ns, (624)/30.72*1000 */

#define AC_TYPE_DL (0)
#define AC_TYPE_UL (1)
#define MAX_TDD_NUM ((UINT32)4)

#define ROE_TIME_MEAS_ERROR 3
UINT32 IcHalRoeIqDemapperTimeMeasApiForCpri(UINT32 chanIndex, UINT32 uT12);
UINT32 IcHalRoeCpriLinkRebuildApi(UINT32 chanIndex);
UINT32 IcHalRoeCpriDempperBufToP2DelayApi(UINT32 ulChanIndex, UINT32 uDir);

typedef enum _RX_DLY_LINK_NODE_STA
{
    RX_OPT_EXTERN_IC = 0,       /*上行IC光口前外部处理延时节点，包括FPGA+IC机型或多片机型*/
    RX_OPT_DPDIC,          /*上行IC光口处理延时点*/
    RX_DUC_DPDIC,          /*上行IC载波处理延时点*/
    RX_ULCHAN_DPDIC,       /*上行IC DLPOST处理延时点*/
    RX_J204_DPDIC,         /*上行IC 204处理延时点*/
    RX_ULCHAN_EXTERN_IC,             /*上行IC中频后外部处理延时节点，对于IC内部光口到中频之间传出IC在FPGA处理后再传回来的情况，归结到此部分节点延时*/
    RRU_RX_DLY_LINK_NODE_NUM
}RX_DLY_LINK_NODE_STA;

/*RRU下行光口、中频延时的链路节点，节点状态用3bit来表示*/
typedef enum _TX_DLY_LINK_NODE_STA
{
    TX_OPT_EXTERN_IC = 0,       /*下行IC光口前外部处理延时节点，包括FPGA+IC机型或多片机型*/
    TX_OPT_DPDIC,               /*下行IC光口处理延时点*/
    TX_DUC_DPDIC,               /*下行IC载波处理延时点*/
    TX_CFR_DPDIC,               /*下行IC CFR处理延时点*/
    TX_DPD_DPDIC,               /*下行IC DPD处理延时点*/
    TX_DLPOST_DPDIC,            /*下行IC DLPOST处理延时点*/
    TX_J204_DPDIC,              /*下行IC 204处理延时点*/
    TX_DLPOST_EXTERN_IC,        /*下行IC中频后外部处理延时节点，对于IC内部光口到中频之间传出IC在FPGA处理后再传回来的情况，归结到此部分节点延时*/
    RRU_TX_DLY_LINK_NODE_NUM
}TX_DLY_LINK_NODE_STA;

/*下行结构体定义*/
typedef struct tagT_RruTxChanDlyLinkSta
{
    /*对于IC光口前部分处理延时节点,表示如下:*/
    /*0代表单片纯IC,固定为0;*/
    /*1代表有外扩FPGA,需要从FPGA获取;*/
    UINT8 tx_opt_extern_ic[RADIO_MAP_TYPE_NUM];
    /*下面IC内部的节点统一定义表示 0代表纯IC内部通过，1代表IC中频代表旁路通过，光口代表转发通过，2代表IC内部完全不过，即纯FPGA，其他预留*/
    UINT8 tx_opt_dpdic[RADIO_MAP_TYPE_NUM];         /*下行IC光口处理延时点*/
    UINT8 tx_duc_dpdic[RADIO_MAP_TYPE_NUM];         /*下行IC载波处理延时点*/
    UINT8 tx_cfr_dpdic[RADIO_MAP_TYPE_NUM];         /*下行IC CFR处理延时点*/
    UINT8 tx_dpd_dpdic[RADIO_MAP_TYPE_NUM];         /*下行IC DPD处理延时点*/
    UINT8 tx_dlpost_dpdic[RADIO_MAP_TYPE_NUM];      /*下行IC DLPOST处理延时点*/
    UINT8 tx_j204_dpdic[RADIO_MAP_TYPE_NUM];        /*下行IC 204处理延时点*/
    /*对于IC中频后部分处理延时节点,表示如下:*/
    /*0代表纯IC,固定为0;*/
    /*1代表有外扩FPGA,需要从FPGA获取;*/
    UINT8 tx_dlpost_extern_ic[RADIO_MAP_TYPE_NUM];
}T_RruTxChanDlyLinkSta;

typedef struct tagT_RruTxDlyLinkSta
{
    UINT32 txchanmask;          /*通道掩码*/
    T_RruTxChanDlyLinkSta txchandlylinksta;/*通道时延链路节点的状态*/
}T_RruTxDlyLinkSta;

/*上行结构体定义*/
typedef struct tagT_RruRxChanDlyLinkSta
{
    /*对于IC光口前部分处理延时节点,表示如下:*/
    /*0代表单片纯IC,固定为0;*/
    /*1代表有外扩FPGA,需要从FPGA获取;*/
    UINT8 rx_opt_extern_ic[RADIO_MAP_TYPE_NUM];          /*上行IC光口前外部处理延时节点，包括FPGA+IC机型或多片机型*/
    /*下面IC内部的节点统一定义表示 0代表纯IC内部通过，1代表IC中频代表旁路通过，光口代表转发通过，中频，2代表IC内部完全不过，即纯FPGA，其他预留*/
    UINT8 rx_opt_dpdic[RADIO_MAP_TYPE_NUM];             /*上行IC光口处理延时点*/
    UINT8 rx_duc_dpdic[RADIO_MAP_TYPE_NUM];             /*上行IC载波处理延时点*/
    UINT8 rx_ulchan_dpdic[RADIO_MAP_TYPE_NUM];          /*上行IC DLPOST处理延时点*/
    UINT8 rx_j204_dpdic[RADIO_MAP_TYPE_NUM];            /*上行IC 204处理延时点*/
    /*对于IC中频后部分处理延时节点,表示如下:*/
    /*0代表纯IC,固定为0;*/
    /*1代表有外扩FPGA,需要从FPGA获取;*/
    UINT8 rx_ulchan_extern_ic[RADIO_MAP_TYPE_NUM];      /*上行IC中频后外部处理延时节点，对于IC内部光口到中频之间传出IC在FPGA处理后再传回来的情况，归结到此部分节点延时*/
}T_RruRxChanDlyLinkSta;

typedef struct tagT_RruRxDlyLinkSta
{
    UINT32 rxchanmask;      /*通道掩码*/
    T_RruRxChanDlyLinkSta rxchandlylinksta;/*通道时延链路节点的状态*/
}T_RruRxDlyLinkSta;

typedef struct tagT_RruDeltDly
{
    UINT32 uiRadioMode;       //制式
    UINT32 uiFrType;          //帧头类型
    INT32 uiTrxDeltaDelay;   //delta时延调整值
}T_RruDeltDly;

typedef struct tagT_RruChipTranDly
{
    UINT32 chipTranDly_Dl;      /*下行方向片间传输延时*/
    UINT32 chipTranDly_Ul;      /*上行方向片间传输延时*/
    UINT32 chipShareTranDly_Dl;      /*下行方向片间传输延时在负荷分担场景时的额外变化量*/
    UINT32 chipShareTranDly_Ul;      /*上行方向片间传输延时在负荷分担场景时的额外变化量*/
}T_RruChipTranDly;

typedef struct tagT_RruChipTranDlyAllChip
{
    T_RruChipTranDly allChipTranDly[MAX_DPD_IC_NUM];      /*下行方向片间传输延时*/
}T_RruChipTranDlyAllChip;

typedef struct tagT_CarrDlyReport
{
    UINT32 radio;
    T_RruSlaveChipDlyInfo  carrDlyInfo;
}T_FddCarrDlyReportPara;


typedef struct tag_T12DIFFInfo
{
    UINT32 optWorkRate;
    UINT32 ulDiffNs;
}T_T12DIFFInfo;

typedef UINT32 (*pGetTddIdByChanFunc)(UINT32 antMask, UINT32 dir);

UINT32 BspInitChipTransmitDlyAll(T_RruChipTranDly *chipTranDlyAll, UINT32 chipnum);
UINT32 BspInitChipTransmitDlyOneChip(UINT32 chipId);
UINT32 BspSetShareChipTransmitDlyOneChip(VOID);
UINT32 BspInitFddDlyInfo(UINT32 radio, T_RruSlaveChipDlyInfo *ptSlaveChipDlyPara);
UINT32 BspRxDlyLinkStaInit(T_RruRxDlyLinkSta *p_rxDlyLinkSta, UINT32 num);
UINT32 BspTxDlyLinkStaInit(T_RruTxDlyLinkSta *p_txDlyLinkSta, UINT32 num);
UINT32 BspDeltDlyInit(UINT32 dir, T_BspHalAdaptLinkDeltDly *p_DeltDly, UINT32 num);
UINT32 BspInitJ204AndRfDly(UINT32 dir, UINT32 *rfdly, UINT32 chanNum);
UINT32 BspGetChipTransmitDlyByChipId(UINT32 chipId, UINT32 *chipTrandly_dl, UINT32 *chipTrandly_ul);
UINT32 BspGetChipShareTransmitDlyByChipId(UINT32 chipId, UINT32 *chipTrandly_dl, UINT32 *chipTrandly_ul);
UINT32 BspSetChipTransmitDly(UINT32 chipTrandly_dl, UINT32 chipTrandly_ul);
UINT32 BspGetCurrChipTransmitDly(UINT32 *chipTrandly_dl, UINT32 *chipTrandly_ul);
UINT32 BspGetFddInitDlyInfoByMod(UINT32 radio, T_RruSlaveChipDlyInfo *ptSlaveChipDlyPara);
UINT32 BspGetRxLinkSta(UINT32 bspChan, UINT32 linkNo, UINT32 radio, UINT32 *linkSta);
UINT32 BspGetTxLinkSta(UINT32 bspChan, UINT32 linkNo, UINT32 radio, UINT32 *linkSta);
UINT32 BspGetDeltDly(UINT32 dir, T_BspHalAdaptLinkDeltDly *p_DeltDly, UINT32 *deltDlyNum);
UINT32 BspGetRxOptExternDly_IC(UINT32 bspChan, UINT32 radio, UINT32 *dly);
UINT32 BspGetTxIcPreDly(UINT32 bspChan, UINT32 radio, UINT32 *dly);
UINT32 BspGetRxIcPostDly(UINT32 bspChan, UINT32 radio, UINT32 *dly);
UINT32 BspGetTxIcPostDly(UINT32 bspChan, UINT32 radio, UINT32 *dly);
UINT32 BspGetRxIcPreDly(UINT32 bspChan, UINT32 radio, UINT32 *dly);
UINT32 BspGetTddTnValue(UINT32 optIndex, UINT32 *tnVal);
UINT32 BspGetFddTnValue(UINT32 optIndex, UINT32 *tnVal);
UINT32 BspGetTddTbDelayULValue(UINT32 optIndex, UINT32 *tbDelayUl);
UINT32 BspGetFddTbDelayULValue(UINT32 optIndex, UINT32 *tbDelayUl);
UINT32 BspGetTddTbDelayDLValue(UINT32 optIndex, UINT32 *tbDelayDl);
UINT32 BspGetFddTbDelayDLValue(UINT32 optIndex, UINT32 *tbDelayDl);
UINT32 BspGetTddToffsetDelayValue(UINT32 optIndex, UINT32 *offsetDelay);
UINT32 BspGetFddToffsetDelayValue(UINT32 optIndex, UINT32 *offsetDelay);
UINT32 BspSetTddToffsetDelayValue(UINT32 optIndex, UINT32 offsetDelay);
UINT32 BspSetTddSlaveToffsetDelayValue(UINT32 optIndex, UINT32 offsetDelay);
UINT32 BspHalAdaptCpriFwdToffsetCfg(UINT32 logicOptNo, UINT32 toffset);
UINT32 BspHalAdaptCpriRvsToffsetCfg(UINT32 logicOptNo, UINT32 toffset);
UINT32 BspGetT2aDelayValue(UINT32 radioMode, UINT32 *dly);
UINT32 BspGetTa3DelayValue(UINT32 radioMode, UINT32 *dly);
UINT32 BspUpdateCarrDlyOneChan(UINT32 bspChn);
UINT32 BspUpdateCarrDlyOneChanByDir(UINT32 bspChn, UINT32 dir);
UINT32 BspGetUeAdvVal(UINT32 cellId, UINT32 radioMod, UINT32 cpeMode, UINT32 *cpeAdvanceVal);
UINT32 BspUpdateIoUeAdvGapVal(VOID);
UINT32 BspRecordUeAdvModeChange(UINT32 cellId, UINT32 radioMod, UINT32 cpeMode);
VOID BspSetCpeAdvChangeFlag(UINT32 flag);
UINT32 BspGetTa(VOID);
UINT32 BspSetTddCarr40KMAbility(UINT32 en);
UINT32 BspGetTddCarr40KMAbility(VOID);
UINT32 BspGetCpeAdvChangeFlag(UINT32 tddIndex);
UINT32 BspClrCpeAdvChangeFlag(UINT32 tddIndex);
INT32 BspGetGpsFrameNoOffset(VOID);
VOID BspSetFrameAlignmentChangeFlag(UINT32 bandId, UINT32 flag);
VOID BspSaveOptWorkMode(UINT32 optWorkMode);
UINT32 BspGetSavedOptWorkMode(VOID);
UINT32 BspSetTddTimeDelaySupportFddFlag(INT32 flag) ;
UINT32 BspIcRecoverRxDagcErr(void);
UINT32 BspIcRecoverRxDagcErrFdd(void);
UINT32 BspSetAcDlTaDly(UINT32 uiDifChan, UINT32 uiCarrNo, UINT32 uiRadioMode, INT8 delayTa, INT32 dlyThr);
VOID bspSetCarrDelayValue(UINT32 fwdDlyNs, UINT32 revDlyNs);
VOID bspSetTestMod(UINT32 utestSwtich);
VOID showcarrdelayvalue(VOID);
INT32 BspSetDifCarrDlyInteval(INT32 difDlyInterval);
INT32 BspGetDifCarrDlyInterval();
INT32 BspCompareCarrByFreq(const void* carra, const void* carrb,void *pContext);
UINT32 BspExtractTnrCarrAndSort(const T_ChanRfCfgPara* pSrc,T_CarrInfo *pRfCarrCfgTnr,UINT32 tnrCarrNum);
UINT32 BspExtractTnrCarrSum(const T_ChanRfCfgPara* pSrc,UINT32 *carrNum);
UINT32 BspAllocDlyByInterval(UINT32 difChan, T_CarrInfo *pRfCarrCfg,UINT32 carrNum);
UINT32 BspSetTxCarrDelayAdj(UINT32 difChan, T_ChanRfCfgPara *pRfCfg);
UINT32 BspGetOptStatus(UINT32 optId);
T_AC_INDEX_MAP* BspGetDlyAcIndexMap(VOID);
UINT32 BspSetDlyIoConfig(UINT32 chan, UINT32 radioMode);
UINT32 BspGetDlyUlIoCfg(UINT32 difChan,T_BspHalAdaptUtUlIoPara * pUtIo);
UINT32 BspGetDlyDlIoCfg(UINT32 difChan,T_BspHalAdaptUtDlIoPara * pUtIo);
UINT32 BspSetTddIdByChanFunc(pGetTddIdByChanFunc utdoaFunc);
UINT32 BspGetTddIdByChanFunc(UINT32 chan, UINT32 trx);
UINT32 BspGetDlyDlIoCfg01(UINT32 difChan,T_BspHalAdaptUtDlIoPara * pUtIo);
UINT32 BspGetDlyDlIoCfg02(UINT32 difChan,T_BspHalAdaptUtDlIoPara * pUtIo);
UINT32 BspGetDlyDlIoCfg03(UINT32 difChan,T_BspHalAdaptUtDlIoPara * pUtIo);
UINT32 BspGetDlyDlIoCfg04(UINT32 difChan,T_BspHalAdaptUtDlIoPara * pUtIo);
UINT32 BspGetDlyDlIoCfg05(UINT32 difChan,T_BspHalAdaptUtDlIoPara * pUtIo);
UINT32 BspGetDlyDlIoCfg06(UINT32 difChan,T_BspHalAdaptUtDlIoPara * pUtIo);
UINT32 BspGetDlyDlIoCfg07(UINT32 difChan,T_BspHalAdaptUtDlIoPara * pUtIo);
UINT32 BspCalcFddULTbDelayVal(UINT32 optIndex, UINT32 *tbDelay);
UINT32 BspCalcFddDLTbDelayVal(UINT32 optIndex, UINT32 *tbDelay);
UINT32 BspInitFddToffsetVal(UINT32 val);
UINT32 BspGetSlaveChipToffset(UINT32* pVal);
UINT32 BspInitFddFixLinkDly(UINT32 val);
UINT32 BspGetSlaveChipFixLinkDly(UINT32* pVal);
#ifdef __cplusplus
}
#endif
#endif 



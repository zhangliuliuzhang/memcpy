/*****************************************************************************
* 版权所有(C) 2017, ZTE Corp. ZXSDR-RRU Platform BSP
*----------------------------------------------------------------------------
* 模 块 名 : bsp
* 文件名称 : timedelaycommon.h
* 文件标识 : {[N/A]}
* 内容摘要 : 
* 注意事项 : 无
* 作    者 :   10090699
* 创建日期 : 2017-03-08
* 当前版本 : Ver1.0
*----------------------------------------------------------------------------
* 变更记录 :
*
* $记录1
* 变 更 单: $0000000(N/A)
* 责 任 人: 10090699
* 修改日戳: 2017-03-08
* 变更说明: 创建文件
*----------------------------------------------------------------------------
*/

#ifndef _FUNCLIB_TIMEDELAYCOMMON_H_
#define _FUNCLIB_TIMEDELAYCOMMON_H_



#ifdef __cplusplus
extern "C" {
#endif

#include "timedelayapi.h"
#include "funccommon_log.h"

typedef struct tagT_FrAlignPara
{
	UINT32  radio;   /* 制式 */
    UINT32  Tc;      /* 配置标准单位,默认3.84M,单位KHz */
    UINT32  FpgaClk; /* FPGA时钟,单位KHz */
    UINT32  rruClk;  /* 整版时钟,单位KHz */
    UINT32  frClk;   /* CC:10ms */
}T_FrAlignPara;

typedef enum
{
    E_TIME_DELAY_STUB_INIT_NO     = (UINT32)0,   
    E_TIME_DELAY_STUB_INIT_YES    = (UINT32)1,
    E_TIME_DELAY_STUB_TYPE_ADD    = (UINT32)2,
    E_TIME_DELAY_STUB_TYPE_FUNC   = (UINT32)3,
    E_TIME_DELAY_STUB_MAX_OPT_NUM = (UINT32)20
}E_TIME_DELAY_STUB;

typedef struct T_timeDelayStubInfo
{
    UINT32 t2aInit[E_TIME_DELAY_STUB_MAX_OPT_NUM];
    UINT32 ta3Init[E_TIME_DELAY_STUB_MAX_OPT_NUM];
    UINT32 t2a[E_TIME_DELAY_STUB_MAX_OPT_NUM];
    UINT32 ta3[E_TIME_DELAY_STUB_MAX_OPT_NUM];
    UINT32        frAlignInit;
    T_FrAlignPara frAlignPara[8];
}T_timeDelayStubInfo;

typedef struct T_timeDelayRadioInfo
{
    UINT32 radioModeNum;
    UINT32 radioMode[PRODUCT_MODE_MAXNUM];
    UINT32 t2aInit[PRODUCT_MODE_MAXNUM];
    UINT32 t2a[PRODUCT_MODE_MAXNUM];
    UINT32 ta3Init[PRODUCT_MODE_MAXNUM];
    UINT32 ta3[PRODUCT_MODE_MAXNUM];
}T_timeDelayRadioInfo;
    
#define TIME_DELAY_STUB_OPT_CHECK(a)                  \
{                                                     \
    if((a) >= E_TIME_DELAY_STUB_MAX_OPT_NUM)          \
    {                                                 \
        dbgErr("[%s]opt out of range\n",__FUNCTION__);\
        return BSP_ERROR;                             \
    }                                                 \
}

typedef UINT32 (*FUNC_SetBoardAlignment)(UINT32 radio,INT32 framerDelay);
typedef UINT32 (*FUNC_GetDelayByOpt)(UINT32 opt);

UINT32 BspInitRfT2aDelay(UINT32 opt, UINT32 rfT2a);
UINT32 BspInitBbT2aDelay(UINT32 opt, UINT32 bbT2a);

UINT32 BspInitRfTa3Delay(UINT32 opt, UINT32 rfTa3);
UINT32 BspInitBbTa3Delay(UINT32 opt, UINT32 bbTa3);
UINT32 BspInitRfFrAlignPara(T_FrAlignPara *frPara,UINT32 num);
UINT32 BspSetFixedDelay(VOID);

#ifdef __cplusplus
}
#endif
#endif 



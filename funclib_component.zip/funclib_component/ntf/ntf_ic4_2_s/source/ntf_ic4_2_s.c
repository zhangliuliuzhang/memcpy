/*****************************************************************************
* 版权所有(C) 2017, ZTE Corp. ZXSDR-RRU Platform BSP
*----------------------------------------------------------------------------
* 模 块 名 : BSP
* 文件名称 : ntf_ic4_2_s.c
* 文件标识 : {[N/A]}
* 内容摘要 :
* 注意事项 : 无
* 作    者 : 10102065
* 创建日期 : 2017-2-27 14:45:34
* 当前版本 : Ver1.0
*----------------------------------------------------------------------------
* 变更记录 :
* $记录1
* 变 更 单: $0000000(N/A)
* 责 任 人: 10102065
* 修改日戳: 2017-2-27 14:45:34
* 变更说明: 创建文件

*----------------------------------------------------------------------------
*/
#include "bsppub.h"
#include "zprintf.h"
#include "bsperrcode.h"
#include "vxadp.h"
#include "ntf_ic4_2_s.h"
#include "ru_basedef.h"
#include "ntfcommon.h"
#include "exprn.h"
#include <math.h>
#include <unistd.h>
#include "dpdcommon.h"
#include "lo_common.h"
#include "devdrv_lo.h"
#include "powerctrl_ic4_2.h"
#include "vectorvswr_ic4_2.h"
#include "pa_ic4_2_ctrl.h"
#include "resource_alloc_maintain.h"
#include "pa_ic4_2_gridvolt.h"
#include "chnmap_a.h"
#include "gainctrlcommon.h"
#include "cfrcommon.h"
#include "dlyapi.h"
#include "funccommon_a.h"
#include "papt_maintain.h"
#include "freqcfg_ic4_2.h"
#include "vectorvswrapi.h"
#include "funccommon.h"

#ifndef BSP_BIT
#define BSP_BIT(n)      (1UL << (n))  /* 对bit[n]掩码 */
#endif
/*驻波比的告警门限*/
#define HIGH_VSWR_ALARM       (2000000)
/*驻波比位置检测*/
#define VSWR_MAX_TEST_POINT           (1000)

static UINT32 NtfCheckPll(void);
static UINT32 NtfCheckTxDac(void);
static UINT32 NtfCheckRxAdc(void);
static UINT32 NtfCheckPrxAdc(void);
static UINT32 NtfTxPowerCheck(void);
static UINT32 NtfGetPaVswrVal(void);
static UINT32 NtfTxAttCheck(void);
static UINT32 NtfTxFlatCheck(void);
static UINT32 NtfRxPowerCheck(void);

typedef struct
{
    FLOAT real;
    FLOAT image;
}TComplex;

/* J204 建链状态相关寄存器 */
static UINT32 s_204linkRegAddr[3][2] =
{
    /* ul b0      fb b0  */
    {0xc7e0009c,0xc7e0089c}, /* sync state lane*4 */
    {0xc7e0005c,0xc7e0085c}, /* crc check lane*4 */
    {0xc7e00054,0xc7e00854}, /* crc err lane*4 */
};
static INT32 s_attVal[BSP_MAX_TX_CHAN] = {0};
static INT32 s_fwd[4][MAX_TX_CHANNEL] = {0};
static INT32 s_tssi[4][MAX_TX_CHANNEL] = {0};
static FLOAT s_vswrAv[BSP_MAX_CHAN_NUM] = {0};
static FLOAT s_vswr[VSWR_MAX_TEST_POINT] = {0};
static TComplex s_comGamma[VSWR_MAX_TEST_POINT] = {0};
static DOUBLE s_fLocation[BSP_MAX_CHAN_NUM] = {0.0};
static DOUBLE s_gammaPhaseDiff[BSP_MAX_CHAN_NUM] = {0.0};
INT32  lTxAttFwd[BSP_MAX_TX_CHAN][7] = {0};
INT32 g_lAttVal[BSP_MAX_TX_CHAN]={0};
UINT8  g_testType = 0;
UINT8  g_testMode = 0;
T_NtfAvoidItem g_ntfAvoidItem[E_NTF_CHECK_MAX_NUM] = {0};
UINT32 g_ntftestType = NTF_NEAR_DETECTION;
UINT32 g_NtfCheckNewSolution = BSP_NTF_OLD_SOLUTION;

static T_RruNtfItems s_RruNtfItems[]=
{
    /*时钟和本振锁定检查*/
    {"RF PLL CHECK     ",   NtfCheckPll,       BSP_OK,    NTF_ITEM_WAIT,    0,   E_NTF_PLL_CHECK, NTF_CONTINUE_TEST},
    /*DAC接口校验*/
    {"TX DAC CHECK     ",   NtfCheckTxDac,     BSP_OK,    NTF_ITEM_WAIT,    0,   E_NTF_TX_DAC_CHECK, NTF_CONTINUE_TEST},
    /*接收ADC接口校验*/
    {"RX ADC CHECK     ",   NtfCheckRxAdc,     BSP_OK,    NTF_ITEM_WAIT,    0,   E_NTF_RX_ADC_CHECK, NTF_CONTINUE_TEST},
    /*反馈ADC接口校验*/
    {"PRX ADC CHECK    ",   NtfCheckPrxAdc,    BSP_OK,    NTF_ITEM_WAIT,    0,   E_NTF_PRX_ADC_CHECK, NTF_CONTINUE_TEST},
    /*下行模拟链路增益检测*/
    {"TX FWD CHECK     ",   NtfTxPowerCheck,   BSP_OK,    NTF_ITEM_WAIT,    0,   E_NTF_TX_FWD_CHECK, NTF_CONTINUE_TEST},
    /*发射ATT线性度检查*/
    //{"TX ATT CHECK     ",   NtfTxAttCheck ,    BSP_OK,    NTF_ITEM_WAIT,    0,   E_NTF_TX_ATT_CHECK, NTF_CONTINUE_TEST},
    /*下行链路平坦度检查*/
    {"TX FLATNESS CHECK",   NtfTxFlatCheck,    BSP_OK,    NTF_ITEM_WAIT,    0,   E_NTF_TX_FLATNESS_CHECK, NTF_CONTINUE_TEST},
    /*驻波比检测*/
    {"VSWR CHECK       ",   NtfGetPaVswrVal,   BSP_OK,    NTF_ITEM_WAIT,    0,   E_NTF_VSWR_CHECK, NTF_CONTINUE_TEST},
    /*上行增益检查*/
    {"RSSI CHECK       ",   NtfRxPowerCheck,   BSP_OK,    NTF_ITEM_WAIT,    0,   E_NTF_RSSI_CHECK, NTF_CONTINUE_TEST},
};


void BspSetPowEnable(UINT32 chan, UINT32 sw)
{
    BspSetPaPowTxSwitch(chan, sw); /* 开小信号放大器 */
    BspSetPaSwitch(chan, sw);      /* 开pa */
    BspSetTxSwitch(chan, sw);      /* 开Tx */
}

/*****************************************************************************
*  函数名称   : NtfCheckPll(*)
*  功能描述   : 封装后的自检项，获取中频、RF PLL时钟状态
*  输入参数   : 无
*  输出参数   : 无
*  返 回 值   : 返回值
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A)
*----------------------------------------------------------------------------*/
static UINT32 NtfCheckPll(void)
{
    UINT32 retTx   = BSP_OK;
    UINT32 retPrx  = BSP_OK;
    UINT32 retRx   = BSP_OK;
    UINT32 retVal  = BSP_OK;
    UINT32 devNo   = 0;
    UINT32 loop    = 0;
    UINT32 txChnNum  = BspGetTxChannel();
    UINT32 prxChnNum = BspGetPrxChannel();
    UINT32 rxChnNum  = BspGetRxChannel();
    T_RfPllCfgPriv *pRfPllCfg = NULL;
    TRruDeviceDescription tRfDev = {0};

    /*下行锁相环锁定状态检测*/
    for(loop = 0; loop < txChnNum; loop++)
    {
        NTF_CHECK_CHN_FOR_EACH(loop, TX, E_NTF_PLL_CHECK);
        if(BSP_OK == BspChipInfoGetByRfPathDef(loop, TX, DEVICE_TYPE_RFPLL, &tRfDev))
        {
            devNo = BspLoPllDevIdToDevNo(tRfDev.ulDeviceId);
            pRfPllCfg = BspGetRfPllCfgPriv(devNo);
            INPUT_POINTER_CHECK(pRfPllCfg);
            INPUT_POINTER_CHECK(pRfPllCfg->pChkLd);
            retTx |= pRfPllCfg->pChkLd(tRfDev.ulDeviceIndex);
            dbgInfo("%s pll tx check result ulRetTx[index = %d]:[0x%08x]\n", __FUNCTION__, loop, retTx);
        }
    }

    /*反馈通道锁相环锁定检测*/
    for(loop = 0; loop < prxChnNum; loop++)
    {
        NTF_CHECK_CHN_FOR_EACH(loop, TX, E_NTF_PLL_CHECK);
        if(BSP_OK == BspChipInfoGetByRfPathDef(loop, PRX, DEVICE_TYPE_RFPLL, &tRfDev))
        {
            devNo = BspLoPllDevIdToDevNo(tRfDev.ulDeviceId);
            pRfPllCfg = BspGetRfPllCfgPriv(devNo);
            INPUT_POINTER_CHECK(pRfPllCfg);
            INPUT_POINTER_CHECK(pRfPllCfg->pChkLd);
            retPrx |= pRfPllCfg->pChkLd(tRfDev.ulDeviceIndex);
            dbgInfo("%s pll prx check result ulRetPrx[index = %d]:[0x%08x]\n", __FUNCTION__, loop, retPrx);
        }
    }

    /*接受通道锁相环锁定检测*/
    for(loop = 0; loop < rxChnNum; loop++)
    {
        NTF_CHECK_CHN_FOR_EACH(loop, RX, E_NTF_PLL_CHECK);
        if(BSP_OK == BspChipInfoGetByRfPathDef(loop, RX, DEVICE_TYPE_RFPLL, &tRfDev))
        {
            devNo = BspLoPllDevIdToDevNo(tRfDev.ulDeviceId);
            pRfPllCfg = BspGetRfPllCfgPriv(devNo);
            INPUT_POINTER_CHECK(pRfPllCfg);
            INPUT_POINTER_CHECK(pRfPllCfg->pChkLd);
            retRx |= pRfPllCfg->pChkLd(tRfDev.ulDeviceIndex);
            dbgInfo("%s pll rx check result ulRetRx[index = %d]:[0x%08x]\n", __FUNCTION__, loop, retRx);
        }
    }
    /*所有通道时钟的锁定状态，只要有个不锁定即认为RF PLL不正常*/
    retVal = (retTx | retPrx | retRx );
    /* Started by AICoder, pid:1aa17z1552w9add1436a0a9ba038af26d030eb15 */
    if(retVal != BSP_OK)
    {
        if(NTF_NEAR_DETECTION == g_testType)
        {
            s_RruNtfItems[E_RF_PLL_CHECK].endNtf = NTF_PAUSE_TEST;
        }
    }
    /* Ended by AICoder, pid:1aa17z1552w9add1436a0a9ba038af26d030eb15 */
    return retVal;
}

/*****************************************************************************
*  函数名称   : NtfCheckTxDac(*)
*  功能描述   : 诊断TX DAC是否正常
*  输入参数   : 无
*  输出参数   : 无
*  返 回 值   : 返回值
*  其它说明   : 如果204测试不通过，则进行底层serdes测试
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A)
*----------------------------------------------------------------------------*/
UINT32 NtfCheckTxDac(void)
{
    NTF_CHK_ITEM(E_NTF_TX_DAC_CHECK, TX);
    UINT32 mtsNum = 1;/*后续根据不同机型添加MTS数量*/
    UINT32 index  = 0;
    UINT32 retVal = 0;
    ntf_MTS_Switch pMTS_SwitchNtf = NULL;

    /*204层下行DAC测试*/
    for(index = 0; index < mtsNum; index++)
    {
        pMTS_SwitchNtf = Ntf_MTSSwitch();
        if(pMTS_SwitchNtf != NULL)
        {
            pMTS_SwitchNtf();
            BspSysMsDelay(1000);
            retVal |= pMTS_SwitchNtf();
            dbgInfo("%s The function pointer [pMTS_SwitchNtf] is ok.\n",__FUNCTION__);
        }
    }
    /* Started by AICoder, pid:x443b26fc4z8a5014bf7090c50cd8a2edb11211a */
    if(retVal != BSP_OK)
    {
        retVal = BSP_ERROR;
        if(NTF_NEAR_DETECTION == g_testType)
        {
            s_RruNtfItems[E_TX_DAC_CHECK].endNtf = NTF_PAUSE_TEST;
        }
    }
    /* Ended by AICoder, pid:x443b26fc4z8a5014bf7090c50cd8a2edb11211a */
    return retVal;
}

/*ADC 检测*/
static UINT32 BspGetDpdicToMts204Status(UINT32 chipId, UINT32 mask, UINT32 *pstatus)
{
    UINT32 ret = BSP_OK;
    UINT32 status = 0;
    UINT32 index = 0;
    UINT32 ulLinkStatRegData[4] = {0};
    UINT32 fbLinkStatRegData[4] = {0};
    UINT32 ulCrcCheckRegData[4] = {0};
    UINT32 fbCrcCheckRegData[4] = {0};
    UINT32 regAddr = 0;

    INPUT_POINTER_CHECK(pstatus);

    /* 204建链状态记录 */
    for(index = 0; index < 4; index++)
    {
        /* ul sync state */
        regAddr = s_204linkRegAddr[0][0] + index *4;
        ret |= BspHalAdaptDpdicRegRd(0, regAddr, 0, &ulLinkStatRegData[index]);
        if(ulLinkStatRegData[index] != (UINT32)0x20001)
        {
            status |= BSP_BIT(index);
        }
        /* fb sync state */
        regAddr = s_204linkRegAddr[0][1] + index * 4;
        ret |= BspHalAdaptDpdicRegRd(0, regAddr, 0, &fbLinkStatRegData[index]);
        if(fbLinkStatRegData[index] != (UINT32)0x20001)
        {
            status |= BSP_BIT(index + 4);
        }
    }

    regAddr = s_204linkRegAddr[2][0];
    ret |= BspHalAdaptDpdicRegWr(0, regAddr, 0, 0x0f);/*清除RX上行*/
    BspSysMsDelay(100);

    regAddr = s_204linkRegAddr[2][1];
    ret |= BspHalAdaptDpdicRegWr(0, regAddr, 0, 0x0f);/*清除FB反馈*/
    BspSysMsDelay(100);

    /* 204 CRC误码记录 */
    for(index = 0; index < 4; index++)
    {
        /* ul crc check */
        regAddr = s_204linkRegAddr[1][0] + index * 4;
        ret |= BspHalAdaptDpdicRegRd(0, regAddr, 0, &ulCrcCheckRegData[index]);
        if(ulCrcCheckRegData[index] != 0)
        {
            status |= BSP_BIT(index + 8);
        }
        /* fb crc check */
        regAddr = s_204linkRegAddr[1][1] + index * 4;
        ret |= BspHalAdaptDpdicRegRd(0, regAddr, 0, &fbCrcCheckRegData[index]);
        if(fbCrcCheckRegData[index] != 0)
        {
            status |= BSP_BIT(index + 12);
        }
    }

    dbgInfo("%s status = [0x%08x]\n", __FUNCTION__, status);
    *pstatus = status & mask;
    return ret;
}

/*****************************************************************************
*  函数名称   : NtfCheckRxAdc(*)
*  功能描述   : 诊断RX ADC是否正常
*  输入参数   : 无
*  输出参数   : 无
*  返 回 值   : 返回值
*  其它说明   : 无
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A)
*----------------------------------------------------------------------------*/
UINT32 NtfCheckRxAdc(void)
{
    NTF_CHK_ITEM(E_NTF_RX_ADC_CHECK,RX);
    UINT32 chipId   = 0;
    UINT32 statusRx = 0;
    UINT32 rxMask   = 0;

    rxMask = BspGetAdcStatusMask();
    if(BspGetDpdicToMts204Status(chipId, rxMask, &statusRx) != BSP_OK)
    {
        dbgInfo("%s exe  check rx ADC IC42 <==204== MTS  failed\n",__FUNCTION__);
        return BSP_ERROR;
    }
    /* Started by AICoder, pid:97f30o6a47f75fb14d6b0985f0137326d6819fbe */
    if(statusRx != BSP_OK)
    {
        if(NTF_NEAR_DETECTION == g_testType)
        {
            s_RruNtfItems[E_RX_ADC_CHECK].endNtf = NTF_PAUSE_TEST;
        }
    }
    /* Ended by AICoder, pid:97f30o6a47f75fb14d6b0985f0137326d6819fbe */
    return (statusRx == 0) ? BSP_OK : BSP_ERROR;
}

/*****************************************************************************
*  函数名称   : NtfCheckPrxAdc(*)
*  功能描述   : 诊断RX ADC是否正常
*  输入参数   : 无
*  输出参数   : 无
*  返 回 值   : 返回值
*  其它说明   : 无
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A)
*----------------------------------------------------------------------------*/
UINT32 NtfCheckPrxAdc(void)
{
    NTF_CHK_ITEM(E_NTF_PRX_ADC_CHECK, TX);
    UINT32 chipId   = 0;
    UINT32 statusRx = 0;
    UINT32 prxMask  = 0;

    prxMask = BspGetAdcStatusMask();
    if(BspGetDpdicToMts204Status(chipId, prxMask, &statusRx) != BSP_OK)
    {
        dbgInfo("%s exe check prx ADC IC42 <==204== MTS failed\n",__FUNCTION__);
        return BSP_ERROR;
    }
    /* Started by AICoder, pid:0a3cb726ac02afb14c7d090530ad8b26722186fa */
    if(statusRx != BSP_OK)
    {
        if(NTF_NEAR_DETECTION == g_testType)
        {
            s_RruNtfItems[E_PRX_ADC_CHECK].endNtf = NTF_PAUSE_TEST;
        }
    }
    /* Ended by AICoder, pid:0a3cb726ac02afb14c7d090530ad8b26722186fa */
    return (statusRx == 0) ? BSP_OK : BSP_ERROR;
}

/**********************************************************************
* 函数名称: NtfGetPreAnalyseCarrRadioMode
* 功能描述: 根据载波的通道号获取载波制式，硬件自检下每个通道只有单载波配置
* 输入参数: bspChan 通道号
* 输出参数: 无
* 返  回  值: 无
* 其它说明  : 无
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A)
*----------------------------------------------------------------------------*/
UINT32 NtfGetPreAnalyseCarrRadioMode(UINT32 bspChan, UINT32 *radioMode)
{
    UINT32 retVal  = BSP_OK;
    UINT32 difChan = 0;
    UINT32 chipId  = 0;
    UINT32 radio   = 0;
    T_ChanRfCfgPara *pRfCfg = NULL;

    INPUT_POINTER_CHECK(radioMode);

    retVal = BspGetDifInfoByBspChn(bspChan, TX, &chipId, &difChan);
    if (BSP_OK != retVal)
    {
        dbgErr("[%s] bspChan[%d] Get difChan[%d] Error!\n",__FUNCTION__, bspChan, difChan);
        return retVal;
    }
    pRfCfg = GetRfCfgPara(bspChan,TX);
    if (NULL == pRfCfg)
    {
        dbgErr("[%s]difChan'%d pRfCfg Get Error!\n",__FUNCTION__, difChan);
        return BSP_ERROR;
    }
    if(1 < pRfCfg->para.carrNum) /* 硬件自检下每个通道只有单lte载波配置 */
    {
        dbgErr("[%s]  carrNum:%d over range!\n",__FUNCTION__,pRfCfg->para.carrNum);
        return BSP_ERROR;
    }

    radio = pRfCfg->para.carrInfo[0].radioMode;
    if((BSP_RADIO_STANDARD_LTE_TDD | BSP_RADIO_STANDARD_LTE_FDD) & radio)
    {
        *radioMode = radio;
        dbgInfo("%s: chan = %d radioMode = %d \n",__FUNCTION__, difChan,radio);
        return BSP_OK;
    }
    else
    {
        dbgErr("[%s] radioMode:%d is error !\n",__FUNCTION__,radio);
        return BSP_ERROR;
    }
}

/*****************************************************************************
*  函数名称   : BspGetDefaultAtt(UINT32 ulChan)
*  功能描述   : 获取定标之后的att值
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : 无
*  输出参数   : 无
*  返 回 值   : 返回值
*  其它说明   :
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A), 10229672 2015.9.11 创建
*----------------------------------------------------------------------------
*/
UINT32 BspGetDefaultAtt(UINT32 ulChan, UINT32 SigPow, INT32 *lAttVal)
{
    INT32  lTssi = 0;
    INT32  lFwd = 0;
    UINT32 ulLoop = 0;
    INT32  lAttTemp = -1750;

    INPUT_POINTER_CHECK(lAttVal);
    BspSignalSwitchOri(ulChan,SigPow,SWITCH_ON);
    BspSetPaSwitch(ulChan, SWITCH_ON);
    for(ulLoop = 0; ulLoop < 10; ulLoop++)
    {
        BspSetTxGain(ulChan, lAttTemp);
        BspSysMsDelay(10000);

        BspGetTxIfTssi(ulChan, 0, &lTssi);
        BspGetFwdCpIfTssi(ulChan, 0, &lFwd);

        dbgInfo("%s Chan=%d,Loop=%d, Att=%d, Tssi=%d, Fwd=%d\n", __FUNCTION__, ulChan, ulLoop, lAttTemp, lTssi, lFwd);

        if((lTssi == 0) || (lFwd == 0))
        {
            continue;
        }

        if(abs(lTssi-lFwd) >= 100)
        {
            lAttTemp += (lTssi - lFwd) * 0.8;
            dbgInfo("%s lAttTemp is %d\n",__FUNCTION__, lAttTemp);
            if(lAttTemp > -300)
            {
                break;
            }
        }
        else
        {
            break;
        }
    }
    BspSignalSwitchOri(ulChan, 0, SWITCH_OFF);
    *lAttVal = ((lAttTemp - 25) / 50) * 50;
    dbgInfo("%s lAttTemp=%d, lAttVal=%d\n",__FUNCTION__, lAttTemp, *lAttVal);
    return BSP_OK;
}

/* Started by AICoder, pid:tf0344dbcd46ac1147f30b9dd1320f302d10e7ab */
/*****************************************************************************
*  函数名称   : BspGetDefaultAtt(UINT32 ulChanMask)
*  功能描述   : 获取定标之后的att值，按通道掩码批量处理
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : ulChanMask - 通道掩码
*               SigPow     - 发射功率
*               lAttVal    - 存储每个通道的ATT值的数组
*  输出参数   : 无
*  返 回 值   : 返回值
*  其它说明   :
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A), 10229672 2015.9.11 创建
*----------------------------------------------------------------------------
*/
UINT32 BspGetChanMaskDefaultAtt(UINT32 ulChanMask, UINT32 *SigPow, INT32 *lAttVal)
{
    UINT32 chan = 0;
    INT32  lTssi = 0;
    INT32  lFwd = 0;
    UINT32 ulLoop = 0;
    UINT32 attTempVal = 0;
    INT32  lAttTemp[BSP_MAX_TX_CHAN] = {0};
    UINT32 breakMask = 0;
    UINT32 txChnNum = BspGetTxChannel();

    INPUT_POINTER_CHECK(lAttVal);
    INPUT_POINTER_CHECK(SigPow);

    /*初始化所有通道的ATT值*/
    for (chan = 0; chan < txChnNum; chan++)
    {
        if (ulChanMask & BSP_BIT_SET(chan))
        {
            lAttTemp[chan] = -1750;
            BspSignalSwitchOri(chan, SigPow[chan], SWITCH_ON);
            BspSetPaSwitch(chan, SWITCH_ON);
        }
    }

    for (ulLoop = 0; ulLoop < 10; ulLoop++)
    {
        for (chan = 0; chan < txChnNum; chan++)
        {
            if (ulChanMask & BSP_BIT_SET(chan))
            {
                BspSetTxGain(chan, lAttTemp[chan]);
            }
        }
        BspSysMsDelay(10000); // 统一延时

        for (chan = 0; chan < txChnNum; chan++)
        {
            if (ulChanMask & BSP_BIT_SET(chan))
            {
                BspGetTxIfTssi(chan, 0, &lTssi);
                BspGetFwdCpIfTssi(chan, 0, &lFwd);

                dbgInfo("%s Chan=%d,Loop=%d, Att=%d, Tssi=%d, Fwd=%d\n", __FUNCTION__, chan, ulLoop, lAttTemp[chan], lTssi, lFwd);

                if ((lTssi == 0) || (lFwd == 0)) {
                    continue;
                }
                if (abs(lTssi - lFwd) >= 100)
                {
                    attTempVal =  lAttTemp[chan];
                    lAttTemp[chan] += (lTssi - lFwd) * 0.8;
                    dbgInfo("%s chan:%d lAttTemp is %d\n", __FUNCTION__, chan, lAttTemp[chan]);
                    if (lAttTemp[chan] > -300)
                    {
                        lAttTemp[chan] = attTempVal;
                        breakMask |= BSP_BIT_SET(chan);
                    }
                }
                else
                {
                    breakMask |= BSP_BIT_SET(chan);
                }
            }
        }
        if(ulChanMask == breakMask)
        {
            break;
        }
    }

    for (chan = 0; chan < txChnNum; chan++)
    {
        if (ulChanMask & BSP_BIT_SET(chan))
        {
            BspSignalSwitchOri(chan, 0, SWITCH_OFF);
            lAttVal[chan] = ((lAttTemp[chan] - 25) / 50) * 50;
            dbgInfo("%s chan:%d lAttTemp=%d, lAttVal=%d\n", __FUNCTION__, chan, lAttTemp[chan], lAttVal[chan]);
        }
    }

    return BSP_OK;
}

static UINT32 BspNtfGetDefaultAtt(void)
{
    UINT32 chan = 0;
    UINT32 ulPow = 1000;
    UINT32 retVal = BSP_OK;
    INT32  attVal[BSP_MAX_TX_CHAN] = {0};
    UINT32 sigPow[BSP_MAX_TX_CHAN] = {0};
    UINT32 txChnNum = BspGetTxChannel();
    UINT32 ulChanMask = 0;

    // 构建通道掩码
    for (chan = 0; chan < txChnNum; chan++)
    {
        NTF_CHECK_CHN_FOR_EACH(chan, TX, E_NTF_TX_FWD_CHECK);
        if(BspGetPaNormalFlag(chan) == PA_UNNORMAL)
        {
            continue;
        }
        ulChanMask |= BSP_BIT_SET(chan);
        sigPow[chan] = ulPow;
        if(1 == BspGetNtfPowFlag())
        {
            BspGetRruPathRatedPower(chan,&ulPow);
            ulPow /= 2;
            sigPow[chan] = ulPow;
        }
    }

    BspGetChanMaskDefaultAtt(ulChanMask, sigPow, attVal);

    for (chan = 0; chan < txChnNum; chan++)
    {
        if (ulChanMask & BSP_BIT_SET(chan))
        {
            s_attVal[chan] = attVal[chan];

            if (attVal[chan] > -300)
            {
                dbgInfo("%s Chan%d PA or TX/PRX Gain Abnormal, att is %d!\n", __FUNCTION__, chan, attVal[chan]);
                s_RruNtfItems[E_TX_FWD_CHECK].errorChan |= BSP_BIT_SET(chan);
                retVal = BSP_ERROR;
            }
            else if (attVal[chan] > -600)
            {
                dbgInfo("%s Chan%d PA or TX/PRX Gain Notice, att is %d!\n", __FUNCTION__, chan, attVal[chan]);
                retVal |= BSP_NOTICE;
            }
            else
            {
                dbgInfo("%s Chan%d PA or TX/PRX Gain OK, att is %d!\n", __FUNCTION__, chan, attVal[chan]);
            }
        }
    }

    if (BSP_ERROR == retVal) /*2个通道一个ERROR,一个NOTICE,也返回ERROR*/
    {
        dbgInfo("%s BSP_ERROR in NtfTxPowerCheck!\n", __FUNCTION__);
        return BSP_ERROR;
    }

    return retVal;
}
/* Ended by AICoder, pid:tf0344dbcd46ac1147f30b9dd1320f302d10e7ab */

UINT32 BspTxFullPowerCheck(void)
{
    UINT32 chan = 0;
    UINT32 ulPow = 1000;
    UINT32 retVal = BSP_OK;
    UINT32 txChnNum  = BspGetTxChannel();

    for(chan = 0; chan < txChnNum; chan++)
    {
        NTF_CHECK_CHN_FOR_EACH(chan, TX, E_NTF_TX_FWD_CHECK);
        if(BspGetPaNormalFlag(chan) == PA_UNNORMAL)
        {
            continue;
        }
        if(1 == BspGetNtfPowFlag())
        {
            BspGetRruPathRatedPower(chan, &ulPow);
            ulPow /= 2;
        }
        BspSignalSwitchOri(chan,ulPow,SWITCH_ON);
        BspSetPaSwitch(chan, SWITCH_ON);
        BspSetTxGain(chan, s_attVal[chan]);
        BspSysMsDelay(15000);
        powshow();

        BspGetTxIfTssi(chan, 0, &s_tssi[0][chan]);
        BspGetFwdCpIfTssi(chan, 0, &s_fwd[0][chan]);
        dbgInfo("%s Chan=%d, Att=%d, Tssi=%d, Fwd=%d\n", __FUNCTION__, chan, s_attVal[chan], s_tssi[0][chan], s_fwd[0][chan]);

        /* 开环定标时，门限值为±4db */
        if(abs(s_fwd[0][chan] - s_tssi[0][chan]) > 400)
        {
            dbgInfo("%s Chan%d PA or TX/PRX Gain Abnormal, Fwd is %d, TSSI is %d!\n", __FUNCTION__, chan, s_fwd[0][chan], s_tssi[0][chan]);
            s_RruNtfItems[E_TX_FWD_CHECK].errorChan |= BSP_BIT_SET(chan);
            retVal = BSP_ERROR;
        }
        else
        {
            dbgInfo("%s Chan%d TX/PRX Gain Normal!\n", __FUNCTION__, chan);
        }
        BspSetPaSwitch(chan, SWITCH_OFF);
        BspSignalSwitchOri(chan, 0, SWITCH_OFF);
    }
    if(BSP_ERROR == retVal)
    {
        dbgInfo("%s BSP_ERROR in NtfTxPowerCheck!\n", __FUNCTION__);
        return BSP_ERROR;
    }

    return retVal;
}

static UINT32 BspSetCarrDbPow(UINT32 bspChn, UINT32 carrIndex, UINT32 carrPow, UINT32 radioMode)
{
    UINT32 retVal = BSP_OK;
    UINT32 ratePow = 0;
    INT32  carrDbPow = 0;

    retVal |= BspGetRruPathRatedPower(bspChn, &ratePow);
    retVal |= BspCarrPowUpdate(bspChn, carrIndex, carrPow, radioMode);
    carrDbPow = 1000.0 * log10((DOUBLE)carrPow / ((DOUBLE)ratePow + 0.000001));   /* + 900 中频TSG源功率较低，TDD需要天线口功率配制为30dbm*/
    dbgInfo("%s radioMode %d carrPow %d carrDbPow %d ulRatePow %d\n", __FUNCTION__, radioMode, carrPow, carrDbPow, ratePow);
    retVal |= BspSetTxPcGain(bspChn, carrIndex, radioMode, carrDbPow);
    return retVal;
}

/* Started by AICoder, pid:b5d7ai4b40bfe51149710b5fa023f173222602bb */
static UINT32 BspTxReducePowerCheck(void)
{
    UINT32 chan      = 0;
    UINT32 loop      = 0;
    UINT32 pwr       = 1000;
    UINT32 powChan   = 0;
    UINT32 retVal    = BSP_OK;
    UINT32 radioMode = 0;
    UINT32 sigPow[BSP_MAX_TX_CHAN] = {0};
    UINT32 txChnNum  = BspGetTxChannel();
    UINT32 ulChanMask = 0; // 通道掩码

    // 构建通道掩码
    for (chan = 0; chan < txChnNum; chan++)
    {
        NTF_CHECK_CHN_FOR_EACH(chan, TX, E_NTF_TX_FWD_CHECK);
        if(BspGetPaNormalFlag(chan) == PA_UNNORMAL)
        {
            continue;
        }
        ulChanMask |= BSP_BIT_SET(chan);
        sigPow[chan] = pwr;
        if(1 == BspGetNtfPowFlag())
        {
            BspGetRruPathRatedPower(chan,&pwr);
            pwr /= 2;
            sigPow[chan] = pwr;
        }
        BspSignalSwitchOri(chan, pwr, SWITCH_ON);
        BspSetPaSwitch(chan, SWITCH_ON);
    }

    for (loop = 1; loop < 4; loop++)
    {
        for (chan = 0; chan < txChnNum; chan++)
        {
            if (ulChanMask & BSP_BIT_SET(chan))
            {
                powChan = sigPow[chan] / pow(2, loop);   /*每次降3db*/
                NtfGetPreAnalyseCarrRadioMode(chan, &radioMode);
                BspSetCarrDbPow(chan, 0, powChan, radioMode);
                dbgInfo("%s Chan%d Loop %d PowChan is %d!\n", __FUNCTION__, chan, loop, powChan);
            }
        }
        BspSysMsDelay(15000); // 统一延时

        for (chan = 0; chan < txChnNum; chan++)
        {
            if (ulChanMask & BSP_BIT_SET(chan))
            {
                BspGetFwdCpIfTssi(chan, 0, &s_fwd[loop][chan]);
                BspGetTxIfTssi(chan, 0, &s_tssi[loop][chan]);
                dbgInfo("%s Chan%d Last TSSI is %d, FWD is %d; Now TSSI is %d, FWD is %d!\n", __FUNCTION__, chan,
                        s_tssi[loop - 1][chan], s_fwd[loop - 1][chan], s_tssi[loop][chan], s_fwd[loop][chan]);
                if (abs(s_fwd[loop][chan] - (s_fwd[loop - 1][chan] - 300)) > 200)
                {
                    dbgInfo("%s Chan%d PA or TXATT or FBATT or TX/PRX Gain Abnormal!\n", __FUNCTION__, chan);
                    s_RruNtfItems[E_TX_FWD_CHECK].errorChan |= BSP_BIT_SET(chan);
                    retVal = BSP_ERROR;
                }
                else
                {
                    dbgInfo("%s Chan%d TXATT Normal, TSSI is %d, FWD is %d!\n", __FUNCTION__, chan, s_tssi[loop][chan], s_fwd[loop][chan]);
                }
            }
        }
    }

    for (chan = 0; chan < txChnNum; chan++)
    {
        if (ulChanMask & BSP_BIT_SET(chan))
        {
            BspSetPaSwitch(chan, SWITCH_OFF);
            BspSignalSwitchOri(chan, 0, SWITCH_OFF);
        }
    }

    if (BSP_ERROR == retVal)
    {
        dbgInfo("%s BSP_ERROR in NtfTxPowerCheck!\n", __FUNCTION__);
        return BSP_ERROR;
    }
    else
    {
        dbgInfo("%s BSP_OK in NtfTxPowerCheck!\n", __FUNCTION__);
    }

    return retVal;
}
/* Ended by AICoder, pid:b5d7ai4b40bfe51149710b5fa023f173222602bb */

static UINT32 NtfTxPowerCheck(void)
{
    NTF_CHK_ITEM(E_NTF_TX_FWD_CHECK, TX);
    UINT32 retVal = BSP_OK;

    retVal = BspNtfGetDefaultAtt();
    if(BSP_ERROR == retVal)
    {
       return BSP_ERROR;
    }

    retVal |= BspTxFullPowerCheck();
    if(BSP_ERROR == retVal)
    {
       return BSP_ERROR;
    }

    /* Started by AICoder, pid:c6cddg4fe0o89f9149780b1400d4ef041d741ec3 */
    if(MODE_ONLY_FDD == BspGetFddTddCoExistSta())
    {
        retVal |= BspTxReducePowerCheck();
    }
    /* Ended by AICoder, pid:c6cddg4fe0o89f9149780b1400d4ef041d741ec3 */

    return retVal;
}

static BOOL NtfTxAttChnChkIsSkip(UINT32 chn)
{
    BOOL res = FALSE;

    if(BspGetPaNormalFlag(chn) == PA_UNNORMAL)
    {
        res = TRUE;
    }

    if(AAU_PA_TYPE_GaN == BspGetPaType(chn))
    {
        res = TRUE;
    }

    return res;
}

static UINT32 NtfTxAttChnPaSwitch(UINT32 chn)
{
    if(SWITCH_OFF == BspGetPaSwitch(chn))
    {
        BspSetPaSwitch(chn, SWITCH_ON);
    }

    return BSP_OK;
}

UINT32 BspSignalSwitchOri(UINT32 ulChan,UINT32 ulCarrPow,UINT32 ulSwitch)
{
    UINT32 ulRetVal    = BSP_OK;
    UINT32 ulRadioMode   = 0;

    ulRetVal |= NtfGetPreAnalyseCarrRadioMode(ulChan, &ulRadioMode);
    ulRetVal |= BspSetCarrDbPow(ulChan, 0, ulCarrPow, ulRadioMode);/*设置数字功率*/
    ulRetVal |= BspSetNtfTsgSwitch(ulChan, 0, ulRadioMode, ulSwitch);/*打开或者关闭Tsg*/
    powshow();
    return ulRetVal;
}

UINT32 NtfGetThresholdByLoop(UINT32 ulLoop)
{
    UINT32 ulThreshold =0;

    if(ulLoop == 2)
    {
        ulThreshold = 150;  //门限150
    }
    else if(3 == ulLoop)
    {
        ulThreshold = 200;//门限200
    }
    else
    {
        ulThreshold = 300;//门限300
    }

    return  ulThreshold;//返回门限

}

/* Started by AICoder, pid:29a06a1371374681a58e71bf4e2027d0 */
/* Started by AI-VerifyCI-CodeComplexity, pid:29a06a1371374681a58e71bf4e2027d0 */
/*****************************************************************************
*  函数名称   : NtfTxAttCheck(*)
*  功能描述   : 发射ATT线性度检查
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : 无
*  输出参数   : 无
*  返 回 值   : 返回值
*  其它说明   :
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A), 10229672 2015.9.11 创建
*----------------------------------------------------------------------------
*/
// 获取通道数据并设置初始信号功率
UINT32 NtfGetChanMaskAndPow(UINT32 *ulChanMask, UINT32 *sigPow)
{
    UINT32 chan = 0;
    UINT32 ulPow = 1000;
    UINT32 txChnNum  = BspGetTxChannel();

    for(chan = 0; chan < txChnNum; chan++)
    {
        NTF_CHECK_CHN_FOR_EACH(chan, TX, E_NTF_TX_ATT_CHECK);
        if(BspGetPaNormalFlag(chan) == PA_UNNORMAL)
        {
            continue;
        }
        if(SWITCH_OFF == BspGetPaSwitch(chan))
        {
            BspSetPaSwitch(chan, SWITCH_ON);
        }
        *ulChanMask |= BSP_BIT_SET(chan);
        sigPow[chan] = ulPow;
        if(1 == BspGetNtfPowFlag())
        {
            BspGetRruPathRatedPower(chan, &ulPow);
            ulPow /= 2;
            sigPow[chan] = ulPow;
        }
    }
    return BSP_OK;
}

UINT32 NtfTxAttCheck(void)
{
    UINT32 chan = 0;
    INT32  lDefaultAtt[BSP_MAX_TX_CHAN] = {0};
    UINT32 ulRet = BSP_OK;
    UINT32 txChnNum  = BspGetTxChannel();
    INT32  attVal[BSP_MAX_TX_CHAN] = {0};
    UINT32 sigPow[BSP_MAX_TX_CHAN] = {0};
    UINT32 ulChanMask = 0;
    UINT32 loop = 0;
    INT32  lChangedAtt = 0;
    UINT32 ulThreshold = 0;
    USHORT usErrFlag[BSP_MAX_TX_CHAN] = {0};

    NtfGetChanMaskAndPow(&ulChanMask, sigPow);
    BspGetChanMaskDefaultAtt(ulChanMask, sigPow, attVal);
    BspSysMsDelay(2000);
    for (chan = 0; chan < txChnNum; chan++)
    {
        if (ulChanMask & BSP_BIT_SET(chan))
        {
            lDefaultAtt[chan] = attVal[chan];
            BspSignalSwitchOri(chan, sigPow[chan], SWITCH_ON);
        }
    }
    BspSysMsDelay(10000);
    for (chan = 0; chan < txChnNum; chan++)
    {
        if (ulChanMask & BSP_BIT_SET(chan))
        {
            BspGetFwdCpIfTssi(chan, 0, &lTxAttFwd[chan][0]);/*基准功率*/
            dbgInfo("%s Chan%d Default Att is %d,Fwd is %d!\n",__FUNCTION__, chan,lDefaultAtt[chan], lTxAttFwd[chan][0]);
        }
    }

    for (loop = 1; loop < 4; loop++)
    {
        ulThreshold = NtfGetThresholdByLoop(loop);
        for (chan = 0; chan < txChnNum; chan++)
        {
            if (ulChanMask & BSP_BIT_SET(chan))
            {
                lChangedAtt = 100*pow(2,loop-1);
                BspSetTxGain(chan, lDefaultAtt[chan] - lChangedAtt);
            }
        }
        BspSysMsDelay(7000);
        for (chan = 0; chan < txChnNum; chan++)
        {
            if (ulChanMask & BSP_BIT_SET(chan))
            {
                BspGetFwdCpIfTssi(chan, 0, &lTxAttFwd[chan][loop]);
                if(abs(lTxAttFwd[chan][loop] - (lTxAttFwd[chan][0]-lChangedAtt))>ulThreshold)
                {
                    dbgInfo("%s Chan%d loop:%d TXATT Linearity Abnormal,ATT is %d,FWD is %d!\n", __FUNCTION__, chan, loop, lDefaultAtt[chan]-lChangedAtt,lTxAttFwd[chan][loop]);
                    if(0 == usErrFlag[chan])
                    {
                        //s_RruNtfItems[E_TX_ATT_CHECK].errorChan |= BSP_BIT_SET(chan);
                        usErrFlag[chan] = 1;
                    }
                    ulRet = BSP_ERROR;
                }
                else
                {
                    dbgInfo("%s Chan%d loop:%d TXATT Linearity Normal,ATT is %d,FWD is %d!\n", __FUNCTION__, chan, loop, lDefaultAtt[chan]-lChangedAtt,lTxAttFwd[chan][loop]);
                }
                if(loop == 3)
                {
                    BspSignalSwitchOri(chan, 0, SWITCH_OFF);
                }
            }
        }
    }

    if(BSP_OK == ulRet)
    {
        dbgInfo("BSP_OK in NtfTxAttCheck!\n");
    }
    else
    {
        dbgInfo("BSP_ERROR in NtfTxAttCheck!\n");
    }

    return ulRet;
}
/* Ended by AI-VerifyCI-CodeComplexity, pid:29a06a1371374681a58e71bf4e2027d0 */
/* Ended by AICoder, pid:29a06a1371374681a58e71bf4e2027d0 */

static UINT32 NtfTxFreqBandFlatCheck(UINT32 chan, UINT32 freq)
{
    UINT32 retVal = BSP_OK;
    UINT32 threshold = 0;
    INT32  openLoopPow = 0;
    INT32  closeLoopPow = 0;
    UINT32 pwr = 1000;
    T_RfCfgPara *pRfCfg = NULL;

    pRfCfg = BspGetRfCfgPara(chan, TX);
    if(NULL == pRfCfg)
    {
        dbgErr("[%s] chan %d pRfCfgPara in NULL \n",__FUNCTION__, chan);
        return BSP_ERROR;
    }

    if(1 == BspGetNtfPowFlag())
    {
        BspGetRruPathRatedPower(chan, &pwr);
        pwr /= 2;
    }
    threshold = BspGetTssiFwdDiffThreshold();
    pRfCfg->carrInfo[0].freq = freq;
    BspSetTxRfCfg(chan, pRfCfg);
    BspSignalSwitchOri(chan,pwr,SWITCH_ON);

    BspSetPaSwitch(chan, SWITCH_ON);

    BspTxOpenLoopPowCail(chan); /* 开环 */
    BspSysMsDelay(10000);
    BspGetFwdCpIfTssi(chan, 0, &openLoopPow);
    BspSetTxGain(chan, s_attVal[chan]); /* 闭环 */
    BspSysMsDelay(10000);
    BspGetFwdCpIfTssi(chan, 0, &closeLoopPow);

    if(abs(openLoopPow - closeLoopPow) > threshold)
    {
        s_RruNtfItems[E_TX_FLATNESS_CHECK].errorChan |= BSP_BIT_SET(chan);
        dbgInfo("--%s--:Chan%d FlatNess Check Abnormal, Freq %d, Set Fwd is %d, Get Fwd is %d, Threshold is %d!\n",
                __FUNCTION__, chan, freq, openLoopPow, closeLoopPow, threshold);
        retVal = BSP_ERROR;
    }
    else
    {
        dbgInfo("--%s--:Chan%d FlatNess Check Normal, Freq %d, Set Fwd is %d, Get Fwd is %d, Threshold is %d!\n",
                __FUNCTION__, chan, freq, openLoopPow, closeLoopPow, threshold);
    }
    BspSetPaSwitch(chan, SWITCH_OFF);
    BspSignalSwitchOri(chan, 0, SWITCH_OFF);

    return retVal;
}

/*****************************************************************************
*  函数名称: NtfTxFlatCheck()
*  功能描述: 下行链路平坦度检查
*  输入参数: 无
*  输出参数: 无
*  返 回 值: 返回值
*  其它说明: 无
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A)
*----------------------------------------------------------------------------*/
static UINT32 NtfTxFlatCheck(void)
{
    UINT32 retVal = BSP_OK;
    UINT32 chan = 0;
    UINT32 centerFreq = 0;
    UINT32 lowerFreq = 0;
    UINT32 upperFreq = 0;
    UINT32 txChnNum = BspGetTxChannel();
    T_RruRfModuleInfo tRfModuleInfo = {0};

    for(chan = 0; chan < txChnNum; chan++)
    {
        NTF_CHECK_CHN_FOR_EACH(chan, TX, E_NTF_TX_FLATNESS_CHECK);
        /* 获取下行起始和终止频点 */
        BspGetRruRfModuleInfo(chan, &tRfModuleInfo);
        lowerFreq = (INT32)tRfModuleInfo.ulRuTxStartFreq;
        upperFreq = (INT32)tRfModuleInfo.ulRuTxEndFreq;
        centerFreq = (lowerFreq + upperFreq) / 2;
        dbgInfo("Chan%d lowerFreq %d, upperFreq %d, centerFreq %d!\n", chan, lowerFreq, upperFreq, centerFreq);

        retVal |= NtfTxFreqBandFlatCheck(chan, lowerFreq + 10000);  /*低频点*/
        retVal |= NtfTxFreqBandFlatCheck(chan, upperFreq - 10000);  /*高频点*/
        retVal |= NtfTxFreqBandFlatCheck(chan, centerFreq);         /*中频点*/
    }

    if(BSP_OK == retVal)
    {
        dbgInfo("BSP_OK in NtfTxFlatCheck!\n");
    }
    else
    {
        dbgInfo("BSP_ERROR in NtfTxFlatCheck!\n");
    }
    return retVal;
}

static UINT32 BspNtfUpdateVswrComps(UINT32 bspChan, UINT32 freqKHz)
{
    UINT32 uRet = BSP_OK;
    T_RfCfgPara *pRfCfg = NULL;
    T_RfChanCfgEn rfChanCfgEn = {0};

    if(BSP_OK != BspCheckTxChannel(bspChan))
    {
        dbgErr("[%s]Para Error.\n",__FUNCTION__);
        return BSP_ERROR;
    }

    pRfCfg = BspGetRfCfgPara(bspChan, TX);
    if(NULL == pRfCfg)
    {
        dbgErr("[%s] chan %d pRfCfgPara in NULL \n",__FUNCTION__, bspChan);
        return BSP_ERROR;
    }
    pRfCfg->carrInfo[0].freq = freqKHz;
    rfChanCfgEn.carrNum = 1;
    rfChanCfgEn.carrInfo = malloc(sizeof(T_SingCarrCfgEn) * 1 );
    INPUT_POINTER_CHECK(rfChanCfgEn.carrInfo);
    (VOID)memset_s(rfChanCfgEn.carrInfo, sizeof(T_SingCarrCfgEn)*1, 0, sizeof(T_SingCarrCfgEn)*1);
    rfChanCfgEn.carrInfo[0].delOrAddFlag = pRfCfg->carrInfo[0].cfgFlag;
    rfChanCfgEn.carrInfo[0].carrId = pRfCfg->carrInfo[0].carrNo;
    rfChanCfgEn.carrInfo[0].carrRadio = pRfCfg->carrInfo[0].radioMode;
    dbgInfo("[%s] bspChan:%d carrNo:%d radio:%d delOrAddFlag:%d\n",__FUNCTION__,bspChan,rfChanCfgEn.carrInfo[0].carrId,
                    rfChanCfgEn.carrInfo[0].carrRadio,rfChanCfgEn.carrInfo[0].delOrAddFlag);
    uRet |= BspResourceAllocCfg(TX, bspChan, &rfChanCfgEn);
    uRet |= BspResourceAllocCfg(RX, bspChan, &rfChanCfgEn);
    free(rfChanCfgEn.carrInfo);

    uRet |= BspSetTxRfCfg(bspChan, pRfCfg);
    uRet |= BspHalAdaptSetDlCarrGainSw(bspChan,pRfCfg->carrInfo[0].radioMode,pRfCfg->carrInfo[0].carrNo,SWITCH_ON);
    uRet |= BspCfrChnInfoUpdateByBspChn(bspChan);
    uRet |= BspDpdSetCellInfo(bspChan, 0);

    return uRet;
}

static UINT32 BspGetAntennaVswr(UINT32 chan)
{
    UINT32 vswr = 0;
    UINT32 radioMode = 0;

    NtfGetPreAnalyseCarrRadioMode(chan, &radioMode);
    if(BSP_RADIO_STANDARD_LTE_FDD & radioMode)
    {
        if(DPD_VSWR_FUNC_SUPPORT == BspIsSupportDpdVswr(chan))
        {
            vswr = BspGetPaVswrVal(chan,0, ANTENNA_VSWR_MODE);
        }
        else
        {
            vswr = BspGetPaVswrVal(chan,0, PA_VSWR_MODE);
        }
    }
    if(BSP_RADIO_STANDARD_LTE_TDD & radioMode)
    {
        if(DPD_VSWR_FUNC_SUPPORT == BspIsSupportDpdVswr(chan))
        {
            vswr = (UINT32)BspCalcVswrByVector(chan, 0);
        }
        else
        {
            BspGetScalarVswr(chan, &vswr);
        }
    }

    return vswr;
}

static UINT32 BspTestGetSpaVswr(UINT32 chan, FLOAT *pVswr, TComplex *pGamma)
{
    UINT32 vswr = 0;
    T_VswrTaoInfo tVswrTaoInfo = {0};
    UINT32 txChnNum = BspGetTxChannel();

    INPUT_POINTER_CHECK(pVswr);
    INPUT_POINTER_CHECK(pGamma);
    if(chan >= txChnNum)
    {
        dbgErr("%s %d Para Error, chan = %d\n", __FUNCTION__, __LINE__, chan);
        return BSP_ERROR;
    }

    vswr = BspGetAntennaVswr(chan);
    if((BSP_INVALID_VALUE != vswr) && (BSP_ERROR != vswr))
    {
        memset_s(&tVswrTaoInfo, sizeof(T_VswrTaoInfo), 0, sizeof(T_VswrTaoInfo));
        BspGetVswrTao(chan, &tVswrTaoInfo);
        pGamma->real = (FLOAT)(tVswrTaoInfo.sVswrTaoRealRem) / 1e4;
        pGamma->image = (FLOAT)(tVswrTaoInfo.sVswrTaoImagRem) / 1e4;
        *pVswr = (FLOAT)vswr / 1e6;
        return BSP_OK;
    }
    else
    {
        return BSP_ERROR;
    }
}

/*****************************************************************************
*  函数名称   : BspCollectVswrData
*  功能描述   : 驻波值计算
*  输入参数   : 无
*  输出参数   : lowerFreq, upperFreq, FreqStep 单位KHz
*  返 回 值   : 无
*  其它说明   : 无
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A)
*----------------------------------------------------------------------------*/
static UINT32 BspCollectVswrData(UINT32 chan, UINT32 lowerFreq, UINT32 upperFreq, UINT32 FreqStep, INT32 *phaseDiff)
{
    UINT32 retVal = BSP_OK;
    UINT32 freq = 0;
    UINT32 pow = 1000;
    UINT32 radioMode = 0;
    UINT32 bandWidth = 0;
    UINT32 i = 0;
    T_RruRfCfgInfo tRruCfgPara = {0};
    T_RruVswrInfo tRruCfgPara_5g = {0};
    T_VswrPosValcRst posVal = {0};
    T_VswrPosCalcPara para = {0};

    INPUT_POINTER_CHECK(phaseDiff);
    if(chan >= BSP_MAX_TX_CHAN)
    {
        dbgErr("[%s]:Chan is %d, out bounds error!\n",__FUNCTION__,chan);
        return BSP_ERROR;
    }

    if(1 == BspGetNtfPowFlag())
    {
        BspGetRruPathRatedPower(chan, &pow);
        pow /= 2;
    }
    BspSetTxGain(chan, s_attVal[chan]);
    BspSignalSwitchOri(chan,pow,SWITCH_ON);
    BspSetPaSwitch(chan, SWITCH_ON);

    NtfGetPreAnalyseCarrRadioMode(chan, &radioMode);

    retVal |= BspGetChnlCfgCarrPara(chan, &tRruCfgPara);
    tRruCfgPara.carr[0].carrTxNo = 0;
    tRruCfgPara.carr[0].carrTxRadio = radioMode;
    tRruCfgPara.txCfgCarrSum = 1;
    tRruCfgPara.carr[0].carrPow = pow;
    tRruCfgPara.txCenterFreq = BspGetLoFreq(TX, chan);
    bandWidth = BspGetFreqBw(TX, chan, 0);
    retVal |= BspSetRruCfgPara(chan, &tRruCfgPara);

    if(BSP_RADIO_STANDARD_LTE_FDD & radioMode)
    {
        retVal |= BspGetChnlCfgCarrPara_5G(chan, &tRruCfgPara_5g);
        tRruCfgPara_5g.uiCarrNum = 1;
        tRruCfgPara_5g.carr->uiCarrNo = 0;
        tRruCfgPara_5g.carr->iFraAHeadAdj = abs(IcHalApiGetFrTmVal(0, radioMode) * 3.84 / 1000);
        retVal |= BspSetRruCfgPara_5G(chan, &tRruCfgPara_5g);
    }
    retVal |= BspInitDpd(chan,0);
    retVal |= setWaitDspMode(WAIT_DSP_SLOW);
    retVal |= BspSetDpdVswrMode(0);
    /* Started by AICoder, pid:803dd4fbfaqe494144ed0aa7805e076f7e67539c */
    if(BspGetNtfSupportMulitToneVswrFlag() == NTF_NO_SUPP_MULIT_TONE_VSWR)
    {
        for(freq = ((UINT32)lowerFreq + bandWidth/2), i = 0; freq <= ((UINT32)upperFreq - bandWidth/2); freq += (UINT32)FreqStep, i++)
        {
            if(i >= VSWR_MAX_TEST_POINT)
            {
                dbgErr("[%s]:i is %d, out bounds error!\n",__FUNCTION__,i);
                break;
            }
            retVal |= BspNtfUpdateVswrComps(chan, freq);

            /* 清零:GammaL, VSWR */
            s_comGamma[i].real = 0;
            s_comGamma[i].image = 0;
            s_vswr[i] = 0;
            BspSysMsDelay(1000);
            retVal |= BspTestGetSpaVswr(chan, &(s_vswr[i]), &(s_comGamma[i]));
            dbgInfo("chan %d freq %d vswr = %f\n", chan, freq, s_vswr[i]);
            dbgInfo("gammaL = %.5f + %.5fj\n", s_comGamma[i].real, s_comGamma[i].image);
        }
    }
    else
    {
        BspSetDpdMultiVswrFlag(1);
        BspGetVswrPosCalcPara(chan, 0, &para);
        BspGetAveragePhaseByVector(chan, 0, para, &posVal);
        *phaseDiff = posVal.phaseDiff;
        BspSysMsDelay(1000);
    }
    /* Ended by AICoder, pid:803dd4fbfaqe494144ed0aa7805e076f7e67539c */
    BspSetPaSwitch(chan, SWITCH_OFF);
    BspSignalSwitchOri(chan, 0, SWITCH_OFF);

    return retVal;
}

INT32 BspCalcVswrStatistic(INT32 chan, UINT32 count, FLOAT * pAverage)
{
    INT32 i = 0;
    FLOAT sum = 0;

    INPUT_POINTER_CHECK(pAverage);
    if(count > VSWR_MAX_TEST_POINT)/*判断有效点数*/
    {
        dbgErr("%s %d input too many point %d \n", __FUNCTION__, __LINE__, count);
        return BSP_ERROR;
    }
    for(i = 0; i < count; i++)/*求平均*/
    {
        sum += s_vswr[i];
    }

    if(pAverage)
    {
        *pAverage = sum / count;
    }

    return BSP_OK;
}

static VOID BspComplexDiv1(TComplex *c1, TComplex *c2, TComplex *result)
{
    FLOAT d1 = 0.0;
    FLOAT d2 = 0.0;
    FLOAT d3 = 0.0;

    INPUT_POINTER_CHECK_RETURN(c1);
    INPUT_POINTER_CHECK_RETURN(c2);
    INPUT_POINTER_CHECK_RETURN(result);

    d1=c1->real*c2->real+c1->image*c2->image;
    d2=c2->real*c2->real+c2->image*c2->image;
    d3=c1->image*c2->real-c1->real*c2->image;

    if(d2 > 0.000001 || d2 < -0.000001)
    {
        result->real = d1/d2;
        result->image = d3/d2;
    }
    else
    {
        result->real = 0.0;
        result->image = 0.0;
    }
}

UINT32 BspCalcPhaseDiff(TComplex *pComplex, UINT32 count, FLOAT *average)
{
    UINT32 i        = 0;
    TComplex comDiv = {0.0};
    FLOAT angle     = 0.0;
    FLOAT angleSum  = 0.0;

    if(count > VSWR_MAX_TEST_POINT)
    {
        dbgErr("%s %d too many point %d\n", __FUNCTION__, __LINE__, count);
        return BSP_ERROR;
    }
    INPUT_POINTER_CHECK(pComplex);
    INPUT_POINTER_CHECK(average);
    for(i = 0; i < count - 1; i++)
    {
        BspComplexDiv1(&(pComplex[i+1]), &(pComplex[i]), &comDiv);
        angle = atan2(comDiv.image, comDiv.real);
        dbgInfoEx("%s %d div = %.5f + %.5fj angle = %.5f\n", __FUNCTION__, __LINE__, comDiv.real, comDiv.image, angle);
        angleSum += angle;
    }

    *average = angleSum / (count - 1);
    return BSP_OK;
}

/* Started by AICoder, pid:f10a71fc44tc9251429a095a10c6482ec3508f92 */
DOUBLE BspGetVswrThreByBandWidth(UINT32 width)
{
    DOUBLE thre = 0.0;

    if(width < 100000)
    {
        thre = -4.0;
    }
    else if(width <= 250000)
    {
        thre = -1.5;
    }
    else
    {
        thre = -0.7;
    }

    return thre;
}
/* Ended by AICoder, pid:f10a71fc44tc9251429a095a10c6482ec3508f92 */

static INT32 BspJudgeVswrPos(UINT32 chan, UINT32 count, INT32 phaseDiff)
{
    FLOAT fGammaPhaseDiff = 0;
    UINT32 freqStep = BspGetNtfVswrStep();
    UINT32 bandWidth = 0;
    T_RruRfModuleInfo tRfModuleInfo = {0};
    DOUBLE thre = 0.0;

    if(chan >= BSP_MAX_CHAN_NUM)
    {
        dbgErr("[%s]:Chan is %d, out bounds error!\n",__FUNCTION__,chan);
        return BSP_ERROR;
    }
    BspGetRruRfModuleInfo(chan, &tRfModuleInfo);
    bandWidth = tRfModuleInfo.ulRuTxEndFreq - tRfModuleInfo.ulRuTxStartFreq;
    thre = BspGetVswrThreByBandWidth(bandWidth);
    /* Started by AICoder, pid:xdbb6ob24fn3ff31425d0a7070a001294ce7400f */
    if(BspGetNtfSupportMulitToneVswrFlag() == NTF_NO_SUPP_MULIT_TONE_VSWR)
    {
        BspCalcPhaseDiff(s_comGamma, count, &fGammaPhaseDiff);
        s_fLocation[chan] = -1.0 * 0.7 * 3 * 100000 / 4 / 3.14 / freqStep * fGammaPhaseDiff;
    }
    else
    {
        fGammaPhaseDiff = (FLOAT)phaseDiff;
        s_fLocation[chan] = (-1.0 * 0.7 * fGammaPhaseDiff) / (24.0 * 360.0);
    }
    /* Ended by AICoder, pid:xdbb6ob24fn3ff31425d0a7070a001294ce7400f */
    dbgInfo("GammaL phase diff average = %f fLocation = %f\n", fGammaPhaseDiff, s_fLocation[chan]);
    s_gammaPhaseDiff[chan] = fGammaPhaseDiff;
    /* 驻波位置判断 */
    if(s_fLocation[chan] < thre)
    {
        dbgPrn("Vswr Rru Internal Fault!\n");
        return INSIDE_VSWR;    /*内部驻波，点VSWR灯*/
    }
    else if(s_fLocation[chan] < 1.0)
    {
        dbgPrn("Vswr Rru Fuzzy Region Fault!\n");
        return FUZZY_REGION;    /*模糊区，点VSWR灯*/
    }
    else
    {
        dbgPrn("Vswr Rru External Fault, Location is %.2fm!\n", s_fLocation[chan]);
        return OUTSIDE_VSWR;     /*外部驻波，不点VSWR灯*/
    }
}

/*****************************************************************************
*  函数名称   : NtfVswrPosCheck
*  功能描述   : 硬件自检驻波比及位置检测
*  输入参数   : 无
*  输出参数   : 无
*  返 回 值   : 返回值
*  其它说明   : 无
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A)
*----------------------------------------------------------------------------*/
INT32 BspVswrPosCheck(UINT32 chan, UINT32 lowerFreq, UINT32 upperFreq, UINT32 freqStep)
{
    UINT32 retVal       = 0;
    UINT32 count        = 0;
    FLOAT  fVswrAverage = 0;
    UINT32 bandWidth  = 0;
    INT32  phaseDiff = 0;
    DOUBLE dVswrAverage = 0.0;

    if(chan >= BSP_MAX_CHAN_NUM)
    {
        dbgErr("[%s]:Chan is %d, out bounds error!\n",__FUNCTION__,chan);
        return BSP_ERROR;
    }
    bandWidth = BspGetFreqBw(TX, chan, 0);
    count = (upperFreq - lowerFreq - bandWidth + freqStep) / freqStep;
    dbgInfo("upFeq = [%d], lowFeq = [%d], count = [%d] \n", upperFreq, lowerFreq, count);

    if(count > VSWR_MAX_TEST_POINT)
    {
        dbgErr("%s %d too many point %d\n", __FUNCTION__, __LINE__, count);
        return BSP_ERROR;
    }

    /* Started by AICoder, pid:2cb44j6d67rea8e14d6308eb102bf03b59f2aa70 */
    BspCollectVswrData(chan, lowerFreq, upperFreq, freqStep, &phaseDiff);
    if(BspGetNtfSupportMulitToneVswrFlag() == NTF_NO_SUPP_MULIT_TONE_VSWR)
    {
        BspCalcVswrStatistic(chan, count, &fVswrAverage);
    }
    else
    {
        BspGetMultiVectorVswrVal(&dVswrAverage);
        fVswrAverage = (FLOAT)dVswrAverage;
    }
    /* Ended by AICoder, pid:2cb44j6d67rea8e14d6308eb102bf03b59f2aa70 */

    dbgInfo("Chan%d NtfGetPaVswrVal, VSWR is %.2f!\n",chan,fVswrAverage);
    if(1.6 <= fVswrAverage)
    {
        dbgInfo("BSP_ERROR in Chan%d NtfGetPaVswrVal!\n",chan);
        s_vswrAv[chan] = fVswrAverage;

        retVal = BspJudgeVswrPos(chan, count, phaseDiff);//获取驻波位置，当驻波比异常时，判断驻波位置，确定是内部异常还是外部异常
    }
    else
    {
        dbgInfo("BSP_OK in Chan%d NtfGetPaVswrVal!\n",chan);
    }

    return retVal;
}

UINT32 BspVswrPosCheckAll(VOID)
{
    INT32 retTemp = 0;
    INT32 lowerFreq = 0;
    INT32 upperFreq = 0;
    UINT32 freqStep = BspGetNtfVswrStep();
    UINT32 txChan = 0;
    UINT32 txChnNum = BspGetTxChannel();
    T_RruRfModuleInfo tRfModuleInfo = {0};

    for(txChan = 0; txChan < txChnNum; txChan++)
    {
        NTF_CHECK_CHN_FOR_EACH(txChan, TX, E_NTF_VSWR_CHECK);
        if(BspGetPaNormalFlag(txChan) == PA_UNNORMAL)
        {
            continue;
        }
        /* 获取下行起始和终止频点 */
        BspGetRruRfModuleInfo(txChan, &tRfModuleInfo);
        lowerFreq = (INT32)tRfModuleInfo.ulRuTxStartFreq;
        upperFreq = (INT32)tRfModuleInfo.ulRuTxEndFreq;

        retTemp = BspVswrPosCheck(txChan, lowerFreq + 1000, upperFreq - 1000, freqStep); /*-2:内部，-1外部，-4模糊区*/
        if(BSP_OK != retTemp)
        {
            s_RruNtfItems[E_VSWR_CHECK].errorChan |= BSP_BIT_SET(txChan);
        }
        BspSetVswrPosVal(txChan, retTemp);
    }

    for(txChan = 0; txChan < txChnNum; txChan++)
    {
        NTF_CHECK_CHN_FOR_EACH(txChan, TX, E_NTF_VSWR_CHECK);
        if(BspGetPaNormalFlag(txChan) == PA_UNNORMAL)
        {
            continue;
        }
        if(0 != BspGetVswrPosVal(txChan))
        {
            return BSP_NOTICE;
        }
    }

    return BSP_OK;
}

static UINT32 NtfVswrCheck(UINT32 flag)
{
    NTF_CHK_ITEM(E_NTF_VSWR_CHECK, TX);
    UINT32 txChan = 0;
    UINT32 retVal = BSP_OK;
    UINT32 vswr = 0;
    UINT32 pwr = 1000;
    UINT32 radioMode = 0;
    UINT32 txChnNum = BspGetTxChannel();

    if(DPD_VSWR_FUNC_SUPPORT == flag)
    {
        retVal = BspVswrPosCheckAll();//矢量检测,驻波比及驻波位置都要检测
        return retVal;
    }
    else
    {
        for(txChan = 0; txChan < txChnNum; txChan++)//标量检测，只检测驻波比
        {
            NTF_CHECK_CHN_FOR_EACH(txChan, TX, E_NTF_VSWR_CHECK);
            if(1 == BspGetNtfPowFlag())
            {
                BspGetRruPathRatedPower(txChan, &pwr);
                pwr /= 2;
            }
            BspSignalSwitchOri(txChan,pwr,SWITCH_ON);
            BspSetPaSwitch(txChan, SWITCH_ON);
            BspSysMsDelay(15000);

            NtfGetPreAnalyseCarrRadioMode(txChan, &radioMode);
            if(BSP_RADIO_STANDARD_LTE_FDD & radioMode)
            {
                vswr = BspGetPaVswrVal(txChan, 0, PA_VSWR_MODE);
            }
            if(BSP_RADIO_STANDARD_LTE_TDD & radioMode)
            {
                retVal |= BspGetScalarVswr(txChan, &vswr);
            }

            if(vswr > BspGetNtfScalarVswrThre())
            {
                s_RruNtfItems[E_VSWR_CHECK].errorChan |= BSP_BIT_SET(txChan);
                dbgInfo("BSP_NOTICE in Chan%d NtfGetPaVswrVal, VSWR is %d!\n", txChan, vswr);
                retVal |= BSP_NOTICE;
            }
            else
            {
                dbgInfo("BSP_OK in Chan%d NtfGetPaVswrVal!\n", txChan);
                retVal |= BSP_OK;
            }
            BspSetPaSwitch(txChan, SWITCH_OFF);
            BspSignalSwitchOri(txChan, 0, SWITCH_OFF);

        }
    }

    return retVal;
}

/*****************************************************************************
*  函数名称   : NtfGetPaVswrVal(*)
*  功能描述   : 获取VSWR驻波比
*  输入参数   : 无
*  输出参数   : 无
*  返 回 值   : 返回值
*  其它说明   : 无
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A)
*----------------------------------------------------------------------------*/
UINT32 NtfGetPaVswrVal(void)
{
    UINT32 retVal = BSP_OK;
    UINT32 txChan = 0;
    UINT32 count = 0;
    UINT32 flag = 0;
    UINT32 txChnNum  = BspGetTxChannel();

    for(txChan = 0; txChan < txChnNum; txChan++)
    {
        if(BspGetPaNormalFlag(txChan) == txChan)
        {
           continue;
        }
        if(DPD_VSWR_FUNC_SUPPORT != BspIsSupportDpdVswr(txChan))
        {
            count++;
        }
    }
    if(0 == count)
    {
        flag = DPD_VSWR_FUNC_SUPPORT;
    }
    else
    {
        flag = DPD_VSWR_FUNC_NOT_SUPPORT;
    }

    dbgInfo("%s: flag = %d \n",__FUNCTION__,flag);
    retVal = NtfVswrCheck(flag);

    return retVal;
}

/*****************************************************************************
*  函数名称   : NtfRxPowerCheck(*)
*  功能描述   : 上行链路增益检测
*  输入参数   : 无
*  输出参数   : 无
*  返 回 值   : 返回值
*  其它说明   : 无
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A)
*----------------------------------------------------------------------------*/
static UINT32 NtfRxPowerCheck(VOID)
{
    UINT32 retVal = BSP_OK;
    UINT32 chan = 0;
    UINT32 radioMode = 0;
    INT32  threshHold = 0;
    INT32  rssiDbm = 0;
    INT32  rssiDbfs = 0;
    UINT32 rxChnNum  = BspGetRxChannel();

    for(chan = 0; chan < rxChnNum; chan++)
    {
        BspSetPowEnable(chan, SWITCH_OFF);
        BspSetLnaSwitch(chan, SWITCH_ON);
        BspSetRxSwitch(chan, SWITCH_ON);
    }

    BspSysMsDelay(1000);
    for(chan = 0; chan < BspGetRxChannel(); chan++)
    {
        NTF_CHECK_CHN_FOR_EACH(chan, RX, E_NTF_RSSI_CHECK);
        NtfGetPreAnalyseCarrRadioMode(chan, &radioMode);
        BspGetRssiPowInfoByMode(chan, 0, radioMode, 0, 0, &rssiDbm, &rssiDbfs);

        if(BSP_RADIO_STANDARD_LTE_FDD & radioMode)
        {
            threshHold = FDD_LTE_RSSI_BW_10M_THRESHOLD;
        }
        if(BSP_RADIO_STANDARD_LTE_TDD & radioMode)
        {
            threshHold = TDD_LTE_RSSI_BW_20M_THRESHOLD;
        }

        if(rssiDbm < threshHold || rssiDbm >= 0)
        {
            s_RruNtfItems[E_RSSI_CHECK].errorChan |= BSP_BIT_SET(chan);
            retVal = BSP_ERROR;
            dbgInfo("%s BSP_ERROR in Chan%d NtfCheckLteRssi %d!\n", __FUNCTION__, chan, rssiDbm);
        }
        else
        {
            dbgInfo("%s BSP_OK in Chan%d NtfCheckLteRssi! RSSI:%d\n", __FUNCTION__, chan, rssiDbm);
        }
    }

    return retVal;
}

UINT32 BspNtfSlaveChipSelfCheck(NtfSelfTestResult *result, UINT32 strLen)
{
    UINT32 retVal = BSP_OK;
    INT32 buffWriteLen = 0;
    INT32 returnLen = 0;
    const char *resultStr = NULL;
    UINT32 chan = 0;
    UINT32 chanNum = BspGetTxChannel();
    UINT32 rpuId = BspGetRpuId();
    time_t timeStart = 0;
    time_t timeEnd = 0;
    UINT32 loop = 0;
    UINT32 itemNum = sizeof(s_RruNtfItems)/sizeof(T_RruNtfItems);

    INPUT_POINTER_CHECK(result);
    returnLen = snprintf_s(result->hwInfo + buffWriteLen, strLen - buffWriteLen,"Slave Chip %d NTF Items Info:\n", rpuId);
    SNPRINTFS_RETTURN_CHECK(returnLen, strLen, buffWriteLen);
    buffWriteLen += returnLen;

    for(loop = 0; loop < itemNum; loop++)
    {
        if(s_RruNtfItems[loop].runFlag == 0)
        {
            dbgInfo("\n-------------begin %s-------------\n", s_RruNtfItems[loop].pItemName);
            timeStart = time(NULL);
            if(timeStart == -1)
            {
                dbgInfo("get time error !\n");
            }
            retVal = s_RruNtfItems[loop].RruNtfItemFunc();
            resultStr = BspGetNtfCheckResult(retVal);
            INPUT_POINTER_CHECK(resultStr);
            returnLen = snprintf_s(result->hwInfo + buffWriteLen, strLen - buffWriteLen,"%s: %s\n",s_RruNtfItems[loop].pItemName,resultStr);
            SNPRINTFS_RETTURN_CHECK(returnLen, strLen, buffWriteLen);
            buffWriteLen += returnLen;
            result->ledResult = retVal;
        }
        if(s_RruNtfItems[loop].errorChan != 0x0)
        {
            returnLen = snprintf_s(result->hwInfo + buffWriteLen, strLen - buffWriteLen,"ChanMask: %#X\n",s_RruNtfItems[loop].errorChan);
            SNPRINTFS_RETTURN_CHECK(returnLen, strLen, buffWriteLen);
            buffWriteLen += returnLen;
            if(strncmp(s_RruNtfItems[loop].pItemName, "VSWR CHECK", 10))
            {
                for(chan = 0; chan < chanNum; chan ++)
                {
                    if(s_vswrAv[chan] > 1.6)
                    {
                        if(s_gammaPhaseDiff[chan] < 0.0)
                        {
                            returnLen = snprintf_s(result->hwInfo + buffWriteLen, strLen - buffWriteLen,"Chan %d: Location=%f\n", chan, s_fLocation[chan]);
                            SNPRINTFS_RETTURN_CHECK(returnLen, strLen, buffWriteLen);
                            buffWriteLen += returnLen;
                            result->vswrFlag[chan] = OUTSIDE_VSWR;
                        }
                        else if(s_gammaPhaseDiff[chan] < 0.625)
                        {
                            returnLen = snprintf_s(result->hwInfo + buffWriteLen, strLen - buffWriteLen,"Chan %d: FuzzyRegion\n", chan);
                            SNPRINTFS_RETTURN_CHECK(returnLen, strLen, buffWriteLen);
                            buffWriteLen += returnLen;
                            result->vswrFlag[chan] = FUZZY_REGION;
                        }
                        else
                        {
                            returnLen = snprintf_s(result->hwInfo + buffWriteLen, strLen - buffWriteLen,"Chan %d: InternalVswr\n", chan);
                            SNPRINTFS_RETTURN_CHECK(returnLen, strLen, buffWriteLen);
                            buffWriteLen += returnLen;
                            result->vswrFlag[chan] = INSIDE_VSWR;
                        }
                    }
                }
            }
        }

        timeEnd = time(NULL);
        if(timeEnd == -1)
        {
            dbgInfo("get time error !\n");
        }
        dbgInfo("\n-------------end %s----return %d, run time %ld seconds\n", s_RruNtfItems[loop].pItemName, retVal, timeEnd - timeStart);
    }

    return BSP_OK;
}

void BspSetNtfSlaveChipCheckFlag(UINT32 item, UINT32 flag)
{
    if(item >= E_MAX_SLAVE_NTF_ITEMS)
    {
        dbgInfo("item %d is over max %d!\n", item, E_MAX_SLAVE_NTF_ITEMS);
        return ;
    }
    s_RruNtfItems[item].runFlag = flag;
    return ;
}

/*****************************************************************************
*  函数名称   : BspDetectOneItem
*  功能描述   : 进行某一项自检
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : 无
*  输出参数   : 无
*  返 回 值   : 返回值
*  其它说明   :
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A), 10229672  2017.8.2 创建
*----------------------------------------------------------------------------
*/
static UINT32 BspDetectOneItem(UINT32 ulLoop)
{
    UINT32 ulRet = BSP_OK;
    UINT32 (*pfItemFunc)() = NULL;
//    char file[100] = "DiagOneItem_s.txt";
    time_t ulTime = 0;
    time_t ulTime1 = 0;
//    INT32  ret = 0;

    dbgInfo("\n-------------begin %s save file-------------\n", s_RruNtfItems[ulLoop].pItemName);
//    BspSaveStdout2File(file);
    ulTime = time(NULL);
    if(ulTime == -1)
    {
        dbgInfo("get time error !\n");
    }

    dbgInfo("\n-------------begin %s-------------\n", s_RruNtfItems[ulLoop].pItemName);
    BspLog(LOG_LEVEL_0,"-------------begin %s-------------\n", s_RruNtfItems[ulLoop].pItemName);
    pfItemFunc = s_RruNtfItems[ulLoop].RruNtfItemFunc;
    ulRet = pfItemFunc();

    ulTime1 = time(NULL);
    if(ulTime1 == -1)
    {
        dbgInfo("get time error !\n");
    }
    dbgInfo("\n-------------end %s----return %d, run time %ld seconds\n", s_RruNtfItems[ulLoop].pItemName, ulRet, ulTime1 - ulTime);
    BspLog(LOG_LEVEL_0,"-------------end %s----return %d, run time %d seconds\n", s_RruNtfItems[ulLoop].pItemName, ulRet, ulTime1 - ulTime);
//    BspRestoreStdout();

//    ret = BspSystem("cat DiagOneItem_s.txt");
//    CHECK_RET_WARNING(ret, "cat failed, ret:%d", ret);
//    ret = BspSystem("cat DiagOneItem_s.txt >> report_m.txt");
//    CHECK_RET_WARNING(ret, "redirection failed, ret:%d", ret);
//    ret = BspSystem("rm -f DiagOneItem_s.txt");
//    CHECK_RET_WARNING(ret, "rm failed, ret:%d", ret);
    return ulRet;
}

/*****************************************************************************
*  函数名称   : DetectRruItems(*)
*  功能描述   : 开始自检项检测
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : 无
*  输出参数   : 无
*  返 回 值   : 返回值
*  其它说明   :
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A), 尧小安@2019-10-10 13:26:17 移植到TRMB24 单板
*----------------------------------------------------------------------------
*/
static UINT32 DetectRruItems(VOID)
{
    UINT32 ulRet = BSP_OK;
    UINT32 ret = BSP_OK;
    UINT32 ulItemNum = 0;
    UINT32 ulLoop = 0;
    UINT32 ulChan = 0;
    UINT32 txChnNum  = BspGetTxChannel();

    /*自检开始*/
//    s_NtfState = NTF_BEGIN;
    dbgPrn("Start RRU NTF ITEMS CHECK!!\n");
//    ret |= BspNtfLedRunTask();
    (VOID)exprnquit();
//    ret |= BspDiagInit();
    ulItemNum = sizeof(s_RruNtfItems)/sizeof(T_RruNtfItems);
    dbgPrn("NTF_ITEMS_TotalNum = %d\n",ulItemNum);

//    ret = BspSystem("rm -f report.txt");
//    CHECK_RET_WARNING(ret, "rm failed, ret:%d", ret);
    for(ulLoop = 0; ulLoop < ulItemNum; ulLoop++)
    {
        for(ulChan = 0; ulChan < txChnNum; ulChan++)
        {
            ret |= BspSetPaSwitch(ulChan, SWITCH_OFF);
        }
        dbgInfo("|*********************************** ulLoop = %d **********************************|\n", ulLoop);
        ulRet = BspDetectOneItem(ulLoop);
        s_RruNtfItems[ulLoop].funcRet = ulRet;
        /*记录已执行完毕的检测项*/
        s_RruNtfItems[ulLoop].runFlag = NTF_ITEM_RUN;
        /* Started by AICoder, pid:77b30zce5321689142b00852e0fb03181c15d402 */
        if(NTF_PAUSE_TEST == s_RruNtfItems[ulLoop].endNtf)
        {
            break;
        }
        /* Ended by AICoder, pid:77b30zce5321689142b00852e0fb03181c15d402 */
    }

//    /*自检结束*/
//    s_NtfState = NTF_END;
    return ret;
}

/* Started by AICoder, pid:4ae877415a4c6da14a8e0b5ea014879d8749f2bd */
UINT32 BspNtfSlaveChipCheck(void)
{
    char file[100] = "DiagOneItemSlave.txt";
    INT32  ret = 0;
    UINT32 retry = 0;
    UINT32 size = 0;
    CHAR tftpCmd[100] = {0};
    CHAR ip[]="198.33.33.100";
    INT32 snpRet = 0;
    CHAR localFilePath[100] = "/report_s.txt";
    CHAR remoteFilePath[100] = "../ata/report_s.txt";
    struct stat fileStat = {0};
    UINT32 rpuId = BspGetRpuId();
    CHAR command[100] = "";
    UINT32 retVal = BSP_OK;

    BspSaveStdout2File(file);
    retVal = DetectRruItems();
    BspRestoreStdOut();

    snpRet = snprintf_s(localFilePath, sizeof(localFilePath), "/report_s%u.txt", rpuId);
    SNPRINTF_S_CHECK(snpRet, sizeof(localFilePath));
    snpRet = snprintf_s(remoteFilePath, sizeof(remoteFilePath), "../ata/report_s%u.txt", rpuId);
    SNPRINTF_S_CHECK(snpRet, sizeof(remoteFilePath));
    snpRet = snprintf_s(command, sizeof(command), "rm -f %s", localFilePath);
    SNPRINTF_S_CHECK(snpRet, sizeof(command));
    ret = BspSystem(command);
    CHECK_RET_WARNING(ret, "rm failed, ret:%d", ret);
    ret = BspSystem("cat DiagOneItemSlave.txt");
    CHECK_RET_WARNING(ret, "cat failed, ret:%d", ret);
    snpRet = snprintf_s(command, sizeof(command), "cat DiagOneItemSlave.txt >> %s", localFilePath);
    SNPRINTF_S_CHECK(snpRet, sizeof(command));
    ret = BspSystem(command);
    CHECK_RET_WARNING(ret, "redirection failed, ret:%d", ret);
    ret = BspSystem("rm -f DiagOneItemSlave.txt");
    CHECK_RET_WARNING(ret, "rm failed, ret:%d", ret);
    if(rpuId == 0)
    {
        snpRet = snprintf_s(command, sizeof(command), "mv %s /ata/%s", localFilePath, localFilePath);
        SNPRINTF_S_CHECK(snpRet, sizeof(command));
        ret = BspSystem(command);
        CHECK_RET_WARNING(ret, "mv failed, ret:%d", ret);
    }
    else
    {
        for(retry = 0; retry < 3; retry++)
        {
            snpRet = snprintf_s(tftpCmd,sizeof(tftpCmd),"tftp -p -l %s -r %s %s",localFilePath,remoteFilePath,ip);
            SNPRINTF_S_CHECK(snpRet, sizeof(tftpCmd));
            dbgInfo("%s: %s from %s \n",__FUNCTION__,remoteFilePath,localFilePath);
            ret = BspSystem(tftpCmd);
            CHECK_RET_WARNING(ret, "tftp failed, ret:%d", ret);
            BspSysMsDelay(100);
            dbgInfo("%s[PUT]: %s ( try %d times )\n",__FUNCTION__,localFilePath,retry);
            if((stat(localFilePath,&fileStat) == 0) && ((size=fileStat.st_size) > 0))
            {
                dbgInfo("%s: Put %s(%d bytes) from %s succ.\n",__FUNCTION__,localFilePath,size,ip);
                break;
            }
        }
    }

    return retVal;
}
/* Ended by AICoder, pid:4ae877415a4c6da14a8e0b5ea014879d8749f2bd */

static VOID BspSetClkAlmMask(UINT32 ulMode)
{
    UINT32 chanIdx   = 0;
    UINT32 txChnNum  = BspGetTxChannel();

    if(ulMode == 1)
    {
        for (chanIdx = 0; chanIdx < txChnNum; chanIdx++)
        {
            HalPaptPaAbnormalMask(chanIdx,0);
            HalPaptDaAbnormalMask(chanIdx,0);
            dbgInfo("Chan:%d Pa Abnormal Mask Success!\n",chanIdx);
        }
    }
    else
    {
        for (chanIdx = 0; chanIdx < txChnNum; chanIdx++)
        {
            HalPaptPaAbnormalMask(chanIdx,1);
            HalPaptDaAbnormalMask(chanIdx,1);
        }
    }
}

/*****************************************************************************
*  函数名称   : StartToDetection()
*  功能描述   : 自检入口
*  输入参数   : 无
*  输出参数   : 无
*  返 回 值   :   BSP_ERROR --执行成功
                             BSP_OK -- 执行失败
*  其它说明   : 0xff -- 定义为非自检状态
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A),  yc     @2019-09-11 20:38:55 创建
*****************************************************************************/
static UINT32 StartToDetection(void)
{
    if(NTF_NEAR_DETECTION == g_testType)   //从片
    {
        /* 屏蔽功放告警 */
        BspSetClkAlmMask(1);
    }
    /*开始自检项检测*/
    BspNtfSlaveChipCheck();

    BspSetClkAlmMask(0);

    return BSP_OK;
}

UINT32 dbgntf = 0;
UINT32 ntfnewtest(VOID);
/*****************************************************************************
*  函数名称   : BspInnerTestStart()
*  功能描述   : RRU单板启动自检
*  输入参数   : ptReqInfo -- 高层下发的自检信息，我们只用到 wTestType
*  输出参数   : 无
*  返 回 值   : BSP_OK, 其它值为失败
*  其它说明   : NTF 自检接口给DTM 调用
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A),  yc     @2019-09-11 20:38:55 创建
*****************************************************************************/
UINT32 BspInnerTestStart(TDetectReqInfo *ptReqInfo)
{
    UINT32 ulRet = BSP_OK;
    UINT32 txChnNum  = BspGetTxChannel();
    UINT32 ulChan = 0;

    INPUT_POINTER_CHECK(ptReqInfo);
    if((NTF_FAR_DETECTION != ptReqInfo->wTestType)&&(NTF_NEAR_DETECTION != ptReqInfo->wTestType))
    {
        return BSP_ERROR_INVALID_PARA;
    }
    if(dbgntf == 1)
    {
        dbgInfo("BspInnerTestStart...dbgntf\n");
        ntfnewtest();
    }
    dbgInfo("BspInnerTestStart...\n");
    BspSysMsDelay(1000);/*1s*/

    /*保存标志*/
    g_testType = ptReqInfo->wTestType;//0,光纤触发
    g_testMode = 1;  /*自检模式*/
    dbgInfo("g_testMode = %d,g_testType = %d\n", g_testMode, g_testType);
    BspLog(LOG_LEVEL_0,"%s g_testMode = %d,g_testType = %d\n",  __FUNCTION__, g_testMode, g_testType);
    exprnquit(); /*关闭断链打印*/
    for(ulChan = 0; ulChan < txChnNum; ulChan++)
    {
        BspSetPowEnable(ulChan, SWITCH_ON);
        BspSetLnaSwitch(ulChan, SWITCH_OFF);
        BspSetRxSwitch(ulChan, SWITCH_OFF);
        showcarrcfg(0, ulChan);
    }
    BspSetPaVibas(0);
    BspSysMsDelay(5000);
    powshow();

    ulRet |= StartToDetection();
    BspLog(LOG_LEVEL_0,"%s end ret:%d\n",  __FUNCTION__, ulRet);

    return ulRet ;
}

UINT32 BspSetNtfSolutionCfg(UINT32 solution)
{
    g_NtfCheckNewSolution = solution;
    return BSP_OK;
}

UINT32 BspGetNtfSolutionCfg(VOID)
{
    return g_NtfCheckNewSolution;
}

UINT32 BspInitNtfAvoidCfg(VOID)
{
    UINT32 itemIndex = 0;

    for (itemIndex = 0; itemIndex < E_NTF_CHECK_MAX_NUM; itemIndex++)
    {
        g_ntfAvoidItem[itemIndex].chanMask[TX] = 0;
        g_ntfAvoidItem[itemIndex].chanMask[RX] = 0;
    }

    return BSP_OK;
}

UINT32 BspSetChanNtfAvoidFlag(T_RruNtfAvoidFlag *ptRruNtfAvoidPara)
{
    UINT32 itemNum = 0;
    UINT32 itemIndex = 0;
    UINT32 itemType = 0;

    INPUT_POINTER_CHECK(ptRruNtfAvoidPara);

    itemNum = ptRruNtfAvoidPara->itemNum;

    if (itemNum > E_NTF_CHECK_MAX_NUM)
    {
        dbgInfo("%s, itemNum > NTF AVOID ITEM MAX!\n", __FUNCTION__);
        return BSP_ERROR;
    }

    BspInitNtfAvoidCfg();

    for(itemIndex = 0; itemIndex < itemNum; itemIndex++)
    {
//        g_ntfAvoidItem[itemIndex].type = ptRruNtfAvoidPara->atNtfAvoidItem[itemIndex].type;
        itemType = ptRruNtfAvoidPara->atNtfAvoidItem[itemIndex].type;
        g_ntfAvoidItem[itemType].chanMask[TX] = ptRruNtfAvoidPara->atNtfAvoidItem[itemIndex].chanMask[TX];
        g_ntfAvoidItem[itemType].chanMask[RX] = ptRruNtfAvoidPara->atNtfAvoidItem[itemIndex].chanMask[RX];
        dbgInfo("%s, itemType：%d chanMask:[TX:0x%x,RX:0x%x]\n", __FUNCTION__, itemType, g_ntfAvoidItem[itemType].chanMask[TX],g_ntfAvoidItem[itemType].chanMask[RX]);
        BspLog(LOG_LEVEL_0,"%s, itemType：%d chanMask:[TX:0x%x,RX:0x%x]\n", __FUNCTION__, itemType, g_ntfAvoidItem[itemType].chanMask[TX],g_ntfAvoidItem[itemType].chanMask[RX]);
    }
    BspSetNtfSolutionCfg(BSP_NTF_NEW_SOLUTION);
    return BSP_OK;
}

T_NtfAvoidItem g_ntfCfg[E_NTF_CHECK_MAX_NUM] =
{//  Item                     rxchnmask   txchnmask
    {E_NTF_PWR_CHECK,         {0xf,       0xf}},
    {E_NTF_PLL_CHECK,         {0x0,       0x4}},
    {E_NTF_OPT_STATUS_CHECK,  {0x0,       0x0}},
    {E_NTF_TX_DAC_CHECK,      {0x0,       0x6}},
    {E_NTF_RX_ADC_CHECK,      {0x0,       0x0}},
    {E_NTF_PRX_ADC_CHECK,     {0x0,       0x6}},
    {E_NTF_FPGA_CHECK,        {0x0,       0x0}},
    {E_NTF_TX_FWD_CHECK,      {0x0,       0x6}},
    {E_NTF_TX_ATT_CHECK,      {0xc,       0x6}},
    {E_NTF_TX_FLATNESS_CHECK, {0x0,       0x0}},
    {E_NTF_VSWR_CHECK,        {0x0,       0x0}},
    {E_NTF_CIRCULATOR_CHECK,  {0x0,       0x0}},
    {E_NTF_RSSI_CHECK,        {0x0,       0x0}},
};

UINT32 g_ntfCfgNum = NELEMENTS(g_ntfCfg);

UINT32 ntftestdata(UINT32 item, UINT32 rxChanMask, UINT32 txChanMask)
{
    if(item >= E_NTF_CHECK_MAX_NUM)
    {
        dbgInfo(" item:%d > %d err\n",item, E_NTF_CHECK_MAX_NUM);
        return BSP_ERROR;
    }
    g_ntfCfg[item].chanMask[TX] = txChanMask;
    g_ntfCfg[item].chanMask[RX] = rxChanMask;
    dbgInfo(" item:%d txChanMask:0x%x rxChanMask:0x%x\n",item, g_ntfCfg[item].chanMask[TX], g_ntfCfg[item].chanMask[RX]);

    return BSP_OK;
}

// TEST APP INTERFACE !!!
UINT32 ntfnewtest(VOID)
{
    T_NtfAvoidItem *ptntfCfg = g_ntfCfg;
    UINT32 ntfCfgNum = g_ntfCfgNum;

    T_RruNtfAvoidFlag *ptRruNtfAvoidFlag = (T_RruNtfAvoidFlag *)malloc(sizeof(T_RruNtfAvoidFlag) + ntfCfgNum * sizeof(T_NtfAvoidItem));
    if (NULL == ptRruNtfAvoidFlag)
    {
        dbgInfo("%s, malloc err!\n", __FUNCTION__);
        return BSP_ERROR;
    }

    ptRruNtfAvoidFlag->itemNum = ntfCfgNum;
    memset_s(ptRruNtfAvoidFlag->atNtfAvoidItem, ntfCfgNum * sizeof(T_NtfAvoidItem), 0, ntfCfgNum * sizeof(T_NtfAvoidItem)); // Ensure uninitialized memory is not used
    memcpy_s((VOID *)&(ptRruNtfAvoidFlag->atNtfAvoidItem), ntfCfgNum * sizeof(T_NtfAvoidItem), ptntfCfg, ntfCfgNum * sizeof(T_NtfAvoidItem));
    //TEST APP INTERFACE -_-!
    if (BspSetChanNtfAvoidFlag(ptRruNtfAvoidFlag) != BSP_OK)
    {
        free(ptRruNtfAvoidFlag);
        return BSP_ERROR;
    }

    free(ptRruNtfAvoidFlag);
    ptRruNtfAvoidFlag = NULL; // Set the pointer to NULL after freeing the memory

    return BSP_OK;
}

void rrutest(void)
{
    /********
        自检测试函数
        ***********/
    TDetectReqInfo atReqInfo = {0};
    atReqInfo.wTestType  = 1;/*0代表光纤触发,近端，两种触发模式,后台网管和光纤自环*/

    dbgInfo(" far det start...\n");
    BspInnerTestStart(&atReqInfo);
}


UINT32 BspNtfSkipItemByChnMask(UINT32 item, UINT32 dir)
{
    UINT32 itemLoop = 0;
    UINT32 action = BSP_NTF_SKIP_CHK;

    for (itemLoop = 0; itemLoop < E_NTF_CHECK_MAX_NUM && dir < 2; itemLoop++)
    {
        if (g_ntfAvoidItem[itemLoop].chanMask[dir] != 0)
        {
            action = BSP_NTF_NEED_CHK;
            return action;
        }
    }

    return action;
}

BOOL NtfIsNeedCheck(UINT32 item, UINT32 dir)
{
    if (NTF_NEAR_DETECTION == g_testType)
    {
        return TRUE;
    }

    if (BSP_NTF_NEW_SOLUTION != BspGetNtfSolutionCfg())
    {
        return TRUE;
    }

    if (BspNtfSkipItemByChnMask(item, dir) == BSP_NTF_SKIP_CHK)
    {
        return FALSE;
    }

    return TRUE;
}

UINT32 BspGetChnNtfState(UINT32 bspChn, UINT32 dir, UINT32 chkItem)
{
    UINT32 retNtfState = BSP_NTF_SKIP_CHK;

    if (NTF_NEAR_DETECTION == g_testType)
    {
        return BSP_NTF_NEED_CHK;
    }

    if (BSP_NTF_NEW_SOLUTION != BspGetNtfSolutionCfg())
    {
        return BSP_NTF_NEED_CHK;
    }

    if (g_ntfAvoidItem[chkItem].chanMask[dir] & BSP_BIT(bspChn))
    {
        retNtfState = BSP_NTF_NEED_CHK;
    }

    return retNtfState;
}

VOID showntfcfg(VOID)
{
    UINT32 itemIndex = 0;
    UINT32 numItems = NELEMENTS(g_ntfAvoidItem); // 计算数组长度

    dbgInfo("\nchn\tdir\tPWR(%d)\tPLL(%d)\tOPT(%d)\tTXADC(%d)\tRXADC(%d)\tPRXADC(%d)\tFWD(%d)\tTXATT(%d)\tVSWR(%d)\tRSSI(%d)\n",
                       E_NTF_PWR_CHECK,        E_NTF_PLL_CHECK,
                       E_NTF_OPT_STATUS_CHECK, E_NTF_TX_DAC_CHECK,
                       E_NTF_RX_ADC_CHECK,     E_NTF_PRX_ADC_CHECK,
                       E_NTF_TX_FWD_CHECK,     E_NTF_TX_ATT_CHECK,
                       E_NTF_VSWR_CHECK,       E_NTF_RSSI_CHECK);

    for (itemIndex = 0; itemIndex < numItems; itemIndex++) // 使用计算得出的数组长度
    {
        dbgInfo("itemIndex:%d, txMask:0x%x, rxMask:0x%x\n",itemIndex, g_ntfAvoidItem[itemIndex].chanMask[TX], g_ntfAvoidItem[itemIndex].chanMask[RX]);
    }

    return ;
}

/*****************************************************************************
*  函数名称   : BspGetNtfItemResult()
*  功能描述   : 获取自检结果信息
*  输入参数   : ptTestRlt -- 自检结果信息
*  输出参数   : 无
*  返 回 值   : BSP_OK, 其它值为失败
*  其它说明   : 自检完结果上报给APP调用,高层传入13项，BSP结果按type类型填到对用的数组索引中
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A),  yc     @2019-09-11 20:38:55 创建
*****************************************************************************/
UINT32 BspGetNtfItemResult(T_RruNtfResult *ptRruNtfResultPara)
{
    UINT32 ulLoop = 0;
    UINT32 actualItemNum = 0;
    UINT32 itemType = 0;
    UINT32 dir = TX;
    UINT32 checkResult = 0;
    UINT32 errorChan = 0;
    UINT32 ntfItemNum = sizeof(s_RruNtfItems)/sizeof(T_RruNtfItems);
    UINT32 chan = 0;
    UINT32 chanNum = BspGetTxChannel();
    INPUT_POINTER_CHECK(ptRruNtfResultPara);

    for(ulLoop = 0;ulLoop < ntfItemNum; ulLoop++)
    {
        //ptRruNtfResultPara->atNtfItemResult[itemType].type = 0xffff;/* 将自检类型初始化为0xffff代表未自检 */
        itemType = s_RruNtfItems[ulLoop].itemType;
        if(itemType >= E_NTF_CHECK_MAX_NUM)
        {
            dbgInfo("%s loop:%d itemType:%d >= itemNumMax:%d err\n", __FUNCTION__, ulLoop, itemType, E_NTF_CHECK_MAX_NUM);
            BspLog(LOG_LEVEL_0,"%s loop:%d itemType:%d > itemNumMax:%d err\n", __FUNCTION__, ulLoop, itemType, E_NTF_CHECK_MAX_NUM);
            continue;
        }
        /* Started by AICoder, pid:4a70b325bbh12581479809e11075535f7996afc7 */
        checkResult = s_RruNtfItems[ulLoop].funcRet;
        if(E_NTF_RSSI_CHECK == itemType || E_NTF_RX_ADC_CHECK == itemType)
        {
            dir = RX;
        }
        else
        {
            dir = TX;
        }
        errorChan = s_RruNtfItems[ulLoop].errorChan;
        ptRruNtfResultPara->atNtfItemResult[itemType].type = itemType;
        if(NTF_ITEM_RUN == s_RruNtfItems[ulLoop].runFlag)
        {
            ptRruNtfResultPara->atNtfItemResult[itemType].checkResult = checkResult;
        }
        else
        {
            ptRruNtfResultPara->atNtfItemResult[itemType].checkResult = BSP_NO_EXCUTE;
        }
        ptRruNtfResultPara->atNtfItemResult[itemType].chanResultMask[dir] = errorChan;
        dbgInfo("%s loop:%d itemType:%d, dir:%d checkResult:%d errorChan:0x%x\n", __FUNCTION__,
                ulLoop, itemType, dir, ptRruNtfResultPara->atNtfItemResult[itemType].checkResult, errorChan);
        BspLog(LOG_LEVEL_0,"%s loop:%d itemType:%d, dir:%d checkResult:%d errorChan:0x%x\n", __FUNCTION__,
                ulLoop, itemType, dir, ptRruNtfResultPara->atNtfItemResult[itemType].checkResult, errorChan);
        actualItemNum++;
        /* Ended by AICoder, pid:4a70b325bbh12581479809e11075535f7996afc7 */
    }
    /* Started by AICoder, pid:z61d1c13108cc9b14f1a0b3dd05ee32cf174e388 */
    for(chan = 0; chan < chanNum; chan++)
    {
        ptRruNtfResultPara->vswr.vswrAv[chan] = (UINT32)(s_vswrAv[chan] * 1000);
        ptRruNtfResultPara->vswr.phaseDiff[chan] = (UINT32)(s_gammaPhaseDiff[chan] * 1000);
        ptRruNtfResultPara->vswr.location[chan] = (UINT32)(s_fLocation[chan] * 1000);
        ptRruNtfResultPara->vswr.vswrPosFlag[chan] = BspGetVswrPosVal(chan);
    }
    /* Ended by AICoder, pid:z61d1c13108cc9b14f1a0b3dd05ee32cf174e388 */
    //ptRruNtfResultPara->itemNum = actualItemNum;
    dbgInfo("%s actualItemNum:%d \n", __FUNCTION__, actualItemNum);
    BspLog(LOG_LEVEL_0,"%s actualItemNum:%d \n", __FUNCTION__, actualItemNum);

    return BSP_OK;
}

/*****************************************************************************
*  函数名称   : BspSetRruNtfResult()
*  功能描述   : 自检结果汇总成检测结果文件,从片打桩
*  输入参数   : ptTestRlt -- 自检结果信息
*  输出参数   : 无
*  返 回 值   : BSP_OK, 其它值为失败
*  其它说明   : 自检完结果上报给APP调用
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A),  yc     @2019-09-11 20:38:55 创建
*****************************************************************************/
UINT32 BspSetRruNtfResult(T_RruNtfResult *ptRruNtfResultPara)
{
    INPUT_POINTER_CHECK(ptRruNtfResultPara);
    return BSP_OK;
}

/* Started by AICoder, pid:pce2b55ad1kd197145af08b5a0fb64216820c242 */
UINT32 BspSetTsgSelfTestInfo(void)
{
    T_TsgSelfTestInfo info = {0};
    UINT32 retVal = BSP_OK;

    info.uiTsgSelfTestFlag = 1;
    retVal = BspHalAdaptSetTsgSelfTestInfo(&info);
    return retVal;
}
/* Ended by AICoder, pid:pce2b55ad1kd197145af08b5a0fb64216820c242 */

/*****************************************************************************
 * 版权所有(C) 2010, ZTE Corp. RRU Bsp Platform
 *----------------------------------------------------------------------------
 * 模 块 名 : BSP
 * 文件名称 : ntf_ic4_2_s.h
 * 文件标识 : {[N/A]}
 * 内容摘要 : ntf_ic4_2_s 自检功能头文件
 * 注意事项 :
 * 创建日期 : 2012-09-23 14:44:07
 * 当前版本 : Ver1.0
 *----------------------------------------------------------------------------
 * 变更记录 :
  *----------------------------------------------------------------------------
 */
/*rssi门限*/
#define TDD_LTE_RSSI_BW_20M_THRESHOLD  	(-10350)
#define FDD_LTE_RSSI_BW_20M_THRESHOLD  	(-10450)
#define FDD_LTE_RSSI_BW_10M_THRESHOLD   (-10800)

/*检测属性: 内部故障还是外部故障*/
#define NTF_INTERNAL_FAULT            (0)    /*内部故障认为需要更换单板*/
#define NTF_EXTERNAL_FAULT            (1)

/*返回结果类型*/
#define TEST_SUCC_TYPE                (0)
#define TEST_FAIL_TYPE                (1)
#define TEST_NOTICE_TYPE              (2)
#define TEST_PRINT_TYPE               (3)
#define TEST_NOTICE_INFO_TYPE         (4)

#define BSP_NTF_NEED_CHK                    (1)
#define BSP_NTF_SKIP_CHK                    (0)
#define BSP_NTF_NEW_SOLUTION                (1)
#define BSP_NTF_OLD_SOLUTION                (0)

#define BSP_NTF_BOARD_CHECK                 (0xFFFFFFFF)
#define BSP_NTF_NOT_CHECK                   (0)

#define NTF_NO_SUPP_MULIT_TONE_VSWR     (0)
#define NTF_SUPP_MULIT_TONE_VSWR        (1)

/*自检项执行标志*/
#define NTF_ITEM_RUN                  (0) /*已执行完毕*/
#define NTF_ITEM_WAIT                 (1) /*待执行*/

#define NTF_CHECK_CHN_FOR_EACH(chn, dir, item)                      \
({                                                                  \
    if (BSP_NTF_SKIP_CHK == BspGetChnNtfState(chn, dir, item))      \
    {                                                               \
        dbgInfo("item：%d chn:%d dir:%d Not NeedCheck\n",item, chn, dir); \
        continue;                                                   \
    }                                                               \
})

#define NTF_CHK_ITEM(item, dir)                         \
({  if (FALSE == NtfIsNeedCheck(item, dir))             \
    {                                                   \
        dbgInfo("item：%d dir:%d Not NeedCheck\n",item, dir);  \
        return BSP_OK;                                  \
    }                                                   \
})

BOOL NtfIsNeedCheck(UINT32 item, UINT32 dir);
UINT32 BspGetChnNtfState(UINT32 bspChn, UINT32 dir, UINT32 chkItem);
UINT32 BspSignalSwitchOri(UINT32 ulChan,UINT32 ulCarrPow,UINT32 ulSwitch);
UINT32 BspInnerTestStart(TDetectReqInfo *ptReqInfo);


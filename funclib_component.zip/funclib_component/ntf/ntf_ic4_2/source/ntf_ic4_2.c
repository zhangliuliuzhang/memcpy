/*****************************************************************************
* 版权所有(C) 2017, ZTE Corp. ZXSDR-RRU Platform BSP
*----------------------------------------------------------------------------
* 模 块 名 : BSP
* 文件名称 : wfs_fdd.c
* 文件标识 : {[N/A]}
* 内容摘要 :
* 注意事项 : 无
* 作    者 : 10102065
* 创建日期 : 2017-2-27 14:45:34
* 当前版本 : Ver1.0
*----------------------------------------------------------------------------
* 变更记录 :
* $记录1
* 变 更 单: $0000000(N/A)
* 责 任 人: 10102065
* 修改日戳: 2017-2-27 14:45:34
* 变更说明: 创建文件

*----------------------------------------------------------------------------
*/

#include "bsppub.h"
#include "boardid.h"
//#include "bspcomm.h"
#include "optadpt.h"
#include "devdrv_dac.h"
#include "regdrv_access.h"
#include "regdrv_accesstbl.h"
#include "ntf_ic4_2.h"
#include "secure_func.h"
#include <math.h>
#include <unistd.h>
#include "funccommon_chncfg.h"
#include "lo_common.h"
#include "powerctrl_comps_ic4_2.h"
#include "dpdcommon.h"
#include "powerctrl_ic4_2_dbg.h"
#include "powerctrlcommon.h"
#include "powerctrl_ic4_2.h"
#include "pwr_a.h"
#include "freqcfg_ic4_2.h"
#include "devdrv_lo.h"
#include "optctrl_cpri_ic4_2.h"

#include "regtbl.h"
#include "paapi.h"
#include "systemcallapi.h"
#include "resource_alloc_maintain.h"
// #include "boardsocmsg.h"
#include "gainctrlcommon.h"
#include "funccommon_carrmap.h"
#include "vectorvswr_ic4_2.h"
#include "dlyapi.h"
#include "funccommon_chncfg.h"
#include "papt_maintain.h"
#include "stdlib.h"
#include "cpri_reg.h"
#include "pacommon.h"
#include "pa_ic4_2_ctrl.h"
#include "pa_ic4_2_gridvolt.h"
#include "ichaladapt_ic4_2.h"
#include "cfrcommon.h"
//#include "sfp.h"
#include "vectorvswrcommon.h"
#include "ntfcommon.h"
#include "funccommon_a.h"
/*********************************
**********************************/
/**************************************************************************
 *                        宏
 **************************************************************************/
/*@@@@@@@@@@@@@@@@@@@@@@@@@@@公共宏定义@@@@@@@@@@@@@@@@@@@@@@@@@@@*/
/*版本状态*/
#define NTF_NORMAL_MODE               (0)   /*正常模式*/
#define NTF_DETECTION_MODE            (1)   /*自检模式*/

/*检测属性: 内部故障还是外部故障*/
#define NTF_INTERNAL_FAULT            (0)    /*内部故障认为需要更换单板*/
#define NTF_EXTERNAL_FAULT            (1)

/*点灯标志*/
#define NTF_NEED_LED                  (0)
#define NTF_NO_NEED_LED               (1)

/*检测项属性 : 是否继续执行*/
#define NTF_CONTINUE_TEST             (0)
#define NTF_PAUSE_TEST                (1)

/*驻波比的告警门限*/
#define HIGH_VSWR_ALARM               (2000000)

/*定义的自检结果文件字符长度*/
#define MAX_FILE_PATH_LEN             (80)
#define MAX_FILE_NAME_LEN             (70)
#define MAX_ITEM_NAME                 (25)
#define NTF_RAW_FILE_DIR              "/ata/"
#define MAX_FILE_SIZE_1M               1048576 //1024*1024 = 1M

#define NTF_SEGMENT_LINE              "QQQQQQQQ" /*分隔符，区分上报数据和本地数据*/

#define NTF_RESULT_SUCC               "Succ"
#define NTF_RESULT_FAIL               "Fail"
#define NTF_RESULT_NOTICE             "Notice"     

#define NTF_RECORD_MAX_NUM            (5)  /*能记录的最大故障数*/

#ifndef BSP_BIT
#define BSP_BIT(n)      (1UL << (n))  /* 对bit[n]掩码 */
#endif


#ifndef SWITCH_OFF
#define SWITCH_OFF                      0
#endif

#ifndef SWITCH_ON
#define SWITCH_ON                       1
#endif

/***************************自检结果告警码*********************************/
/*测试结果告警码*/
#define BSP_NTF_FINAL_RESULT_OK             ((UINT32)0)
#define BSP_NTF_FINAL_RESULT_ERROR          ((UINT32)30001)
#define BSP_NTF_NEED_CHK                    (1)
#define BSP_NTF_SKIP_CHK                    (0)

#define NTF_CHECK_CHN_FOR_EACH(chn)                      \
({                                                                  \
    if (BSP_NTF_SKIP_CHK == BspGetChnNtfState(chn))      \
    {                                                               \
        dbgInfo("chn:%d Not NeedCheck\n", chn); \
        continue;                                                   \
    }                                                               \
})

/**************************************************************************
 *                         数据类型                                       *
 **************************************************************************/
/*@@@@@@@@@@@@@@@@@@@@@@@@@公共数据类型@@@@@@@@@@@@@@@@@@@@@@@@@@@*/


/*检测项定义*/
/*检测项名称/函数名称及函数入参/检测项属性/检测项/是否点灯*/
typedef struct tagT_RruNtfItem
{
    const char *pItemName;              /*检测项名称，如FPGA加载*/
    UINT32 (*RruNtfItemFunc)(void); /*检测项函数*/
    UINT32 ulFuncRet;               /*检测项返回值*/
    UINT32 ulItemInfo;              /*检测项属性，0 内部属于硬件故障，1 外部属于非硬件故障*/
    UINT32 ulLightLed;              /*检测项结果是否点灯 0 点灯 1 不点灯*/
    UINT32 ulLedType;               /*点灯类型*/
    UINT32 ulEndNtf;                /*检测项异常是否继续 0 继续 1 结束自检*/
    UINT32 ulRunFlag;               /*检测项是否执行 0 未执行 1 已执行*/
    UINT32 ulErrCode;               /*检测项错误码*/
    UINT8 ucCodePara[60];          /*错误码告警参数*/
    UINT32 cErrorChan;              /*异常通道号*/
}TRruNtfItem;

/**************************************************************************
 *                         全局变量定义                                   *
 **************************************************************************/
/*@@@@@@@@@@@@@@@@@@@@@@@@@公共全局变量@@@@@@@@@@@@@@@@@@@@@@@@@@@*/

UINT8  g_testType = 0;
UINT8  g_testMode = 0;
UINT32 s_chanMask = 0;
DOUBLE fLocation[BSP_MAX_TX_CHAN] = {0.0};
static DOUBLE s_gammaPhaseDiff[BSP_MAX_TX_CHAN] = {0.0};
INT16  g_vswrPosVal[MAX_TX_CHAN] = {0};
UINT32 g_vswrPosEn = 0;
static FLOAT g_vswr[VSWR_MAX_TEST_POINT];
static TComplex g_comSpa[VSWR_MAX_TEST_POINT];
static TComplex g_comGamma[VSWR_MAX_TEST_POINT];
static INT16    g_StdOutFile  = 0;
static INT32    g_InitLogFile = 0;
PwrVoltThreshold pwr48vVoltThreshold ={35000, 55000};
INT32 g_lAttVal[BSP_MAX_TX_CHAN]={0};
INT32  lFwd[4][MAX_TX_CHANNEL] = {0};
INT32  lTssi[4][MAX_TX_CHANNEL] = {0};
INT32  lTxAttFwd[7] = {0};
UINT32 VswrHighFlag[BSP_MAX_TX_CHAN] = {0};
static FLOAT vswrAv[BSP_MAX_TX_CHAN] = {0};
/* J204 建链状态相关寄存器 */
static UINT32 s_204linkRegAddr[3][2] = 
{
    /* ul b0      fb b0  */
    {0xc7e0009c,0xc7e0089c}, /* sync state lane*4 */
    {0xc7e0005c,0xc7e0085c}, /* crc check lane*4 */
    {0xc7e00054,0xc7e00854}, /* crc err lane*4 */
};
static funcSetFixLoFreqCallBack pSetFixLoFreqCallBack = NULL;
static UINT32 offPa[8] = { 1, 1, 1, 1, 1, 1, 1, 1};//打桩制造异常，对应下行链路异常
static UINT32 offLna[8] = { 1, 1, 1, 1, 1, 1, 1, 1};//打桩制造异常，对应干扰底噪检测

static UINT32 InitDetectionResultFile(TRruTestResult *ptResult);
static UINT32 GetResultFileName(char *pucFileName, UINT32 ulLen);
static UINT32 DetectRruItems(void);
UINT32 NtfRecordDetectionResult (UINT32 ulAlmType,UINT32 ulOp,TCodeInfo *ptCode,const char*pcInfo,FLOAT fVswrLoc);
static UINT32 NtfInitDetectionResultFile(void);
static UINT32 StartToDetection(void);
static UINT32 BspNtfChkVswr(VOID);
VOID BspSetPowEnable(UINT32 chan, UINT32 sw);
static UINT32 NtfTxFreqBandFlatCheck(UINT32 chan, UINT32 freq, UINT32 ulPow);
/*start自检项函数*/
static UINT32 NtfTxAttCheck(void);
static UINT32 NtfGetOptStatus(void);
static UINT32 NtfGetPaVswrVal(void);
static UINT32 NtfTxFlatCheck(void);
static UINT32 NtfCirculatorCheck(void);
static UINT32 GetResultFilePath(char *pucFilePath, UINT32 ulLen);
static UINT32 NtfTxReduceAttCheck(UINT32 ulChan, INT32 lDefaultAtt);




/*@@@@@@@@@@@@@@@@@@@@@@@@@FDD LTE局部函数@@@@@@@@@@@@@@@@@@@@@@@@*/
/**************************************************************************
*                         全局函数声明
**************************************************************************/

static TRruNtfItem s_RruNtfItems[]=
{
    /*电源异常检查*/
    {"PWR CHECK        ",   NtfCheckPwr,       BSP_OK,  NTF_INTERNAL_FAULT, NTF_NEED_LED,  
        BSP_LED_ID_ALM,   NTF_CONTINUE_TEST,     NTF_ITEM_WAIT,  0x40001,    {0x0},             0},
    /*时钟和本振锁定检查*/
    {"RF PLL CHECK     ",   NtfCheckPll,       BSP_OK,  NTF_INTERNAL_FAULT, NTF_NEED_LED,  
        BSP_LED_ID_ALM,   NTF_CONTINUE_TEST,     NTF_ITEM_WAIT,  0x40002,    {0x0},             0}, 
    /*光口状态诊断*/
    {"OPT STATUS CHECK ",   NtfGetOptStatus,   BSP_OK,  NTF_INTERNAL_FAULT, NTF_NO_NEED_LED,  
        BSP_LED_ID_ALM,   NTF_CONTINUE_TEST,     NTF_ITEM_WAIT,  0x40003,    {0x0},             0},    
    /*DAC接口校验*/
    {"TX DAC CHECK     ",   NtfCheckTxDac,     BSP_OK,  NTF_INTERNAL_FAULT, NTF_NEED_LED,  
        BSP_LED_ID_ALM,   NTF_CONTINUE_TEST,     NTF_ITEM_WAIT,  0x40004,    {0x0},             0},
    /*接收ADC接口校验*/
    {"RX ADC CHECK     ",   NtfCheckRxAdc,     BSP_OK,  NTF_INTERNAL_FAULT, NTF_NEED_LED,  
        BSP_LED_ID_ALM,   NTF_CONTINUE_TEST,     NTF_ITEM_WAIT,  0x40005,    {0x0},             0},        
    /*反馈ADC接口校验*/
    {"PRX ADC CHECK    ",   NtfCheckPrxAdc,    BSP_OK,  NTF_INTERNAL_FAULT, NTF_NEED_LED,  
        BSP_LED_ID_ALM,   NTF_CONTINUE_TEST,     NTF_ITEM_WAIT,  0x40006,    {0x0},             0},
    /*下行模拟链路增益检测*/
    {"TX FWD CHECK     ",   NtfTxPowerCheck,   BSP_OK,  NTF_INTERNAL_FAULT, NTF_NEED_LED,  
        BSP_LED_ID_ALM,   NTF_CONTINUE_TEST,     NTF_ITEM_WAIT,  0x40008,    {0x0},             0}, 
    /*下行链路平坦度检查*/
    {"TX FLATNESS CHECK",   NtfTxFlatCheck,    BSP_OK,  NTF_INTERNAL_FAULT, NTF_NEED_LED,
        BSP_LED_ID_RF0,   NTF_CONTINUE_TEST,     NTF_ITEM_WAIT,  0x40009,    {0x0},             0},
    /*驻波比检测*/
    {"VSWR CHECK       ",   NtfGetPaVswrVal,   BSP_OK,  NTF_INTERNAL_FAULT, NTF_NEED_LED,  
        BSP_LED_ID_RF0,   NTF_CONTINUE_TEST,     NTF_ITEM_WAIT,  0x4000a,    {0x0},             0},
    /*上行增益检查*/
    {"RSSI CHECK       ",   NtfRxPowerCheck,   BSP_OK,  NTF_INTERNAL_FAULT, NTF_NO_NEED_LED,  
        BSP_LED_ID_ALM,   NTF_PAUSE_TEST,     NTF_ITEM_WAIT,  0x4000c,    {0x0},             0},
};

UINT32 BspGetChnNtfState(UINT32 bspChn)
{
    UINT32 retNtfState = BSP_NTF_SKIP_CHK;

    if (NTF_NEAR_DETECTION == g_testType)
    {
        return BSP_NTF_NEED_CHK;
    }

    if (s_chanMask & BSP_BIT(bspChn))
    {
        retNtfState = BSP_NTF_NEED_CHK;
    }

    return retNtfState;
}

void BspSetChanMask(UINT32 mask)
{
    s_chanMask = mask;
    return;
}

void BspSetTestType(UINT32 type)
{
    g_testType = type;
}

/**********************************************************************
* 函数名称: NtfGetPreAnalyseCarrRadioMode
* 功能描述: 根据载波的通道号获取载波制式，硬件自检下每个通道只有单载波配置
* 输入参数: bspChan 通道号
* 输出参数: 无
* 返  回  值: >=BSP_MAX_CHAN_NUM 代表出错
            < BSP_MAX_CHAN_NUM 代表获取的载波需要
************************************************************************/
UINT32 NtfGetPreAnalyseCarrRadioMode(UINT32 bspChan, UINT32 *radioMode)
{
    UINT32 retVal      = BSP_OK;
    UINT32 difChan     = 0;
    UINT32 chipId      = 0;
    UINT32 ulRadioMode = 0;
    T_ChanRfCfgPara *pRfCfg = NULL;

    INPUT_POINTER_CHECK(radioMode);
    
    retVal |= BspGetDifInfoByBspChn(bspChan, 1, &chipId, &difChan);
    if (BSP_OK != retVal)
    {
        dbgErr("[%s] bspChan[%d] Get difChan[%d] Error!\n",__FUNCTION__, bspChan, difChan);
        return retVal;
    }

    pRfCfg = GetRfCfgPara(bspChan,TX);
    if (NULL == pRfCfg)
    {
        dbgErr("[%s]difChan'%d pRfCfg Get Error!\n",__FUNCTION__, difChan);
        return BSP_ERROR;
    }

    if(1 < pRfCfg->para.carrNum)      //硬件自检下每个通道只有单lte载波配置
    {
        dbgErr("[%s]  carrNum:%d over range!\n",__FUNCTION__,pRfCfg->para.carrNum);
        return BSP_ERROR;
    }

    ulRadioMode = pRfCfg->para.carrInfo[0].radioMode;
    if((BSP_RADIO_STANDARD_LTE_TDD|BSP_RADIO_STANDARD_5G|BSP_RADIO_STANDARD_LTE_FDD|BSP_RADIO_STANDARD_FDD_5G)&ulRadioMode)
    {
        *radioMode = ulRadioMode;
        dbgInfo("%s: chan = %d radioMode = %d \n",__FUNCTION__, difChan,ulRadioMode);
        return BSP_OK;
    }
    else
    {
        dbgErr("[%s] radioMode:%d is error !\n",__FUNCTION__,ulRadioMode);
        return BSP_ERROR;
    }      
}

static UINT32 BspSetCarrDbPow(UINT32 bspChn, UINT32 carrIndex, UINT32 carrPow, UINT32 radioMode)
{
    UINT32 retVal = BSP_OK;
    UINT32 ulRatePow = 0;
    INT32  carrDbPow = 0;

    retVal |= BspGetRruPathRatedPower(bspChn, &ulRatePow);
    retVal |= BspCarrPowUpdate(bspChn, carrIndex, carrPow, radioMode);
    carrDbPow = 1000.0 * log10((DOUBLE)carrPow / ((DOUBLE)ulRatePow + 0.000001)) + 900;   /*中频TSG源功率较低，TDD需要天线口功率配制为30dbm*/
    dbgInfo("radioMode %d carrPow %d carrDbPow %d ulRatePow %d\n", radioMode, carrPow, carrDbPow, ulRatePow);
    retVal |= BspSetTxPcGain(bspChn, carrIndex, radioMode, carrDbPow);
    return retVal;
}


UINT32 BspSignalSwitchOri(UINT32 ulChan,UINT32 ulCarrPow,UINT32 ulSwitch)
{
    UINT32 ulRetVal    = BSP_OK;
    UINT32 ulRadioMode   = 0;

    ulRetVal |= NtfGetPreAnalyseCarrRadioMode(ulChan, &ulRadioMode);
    ulRetVal |= BspSetCarrDbPow(ulChan, 0, ulCarrPow, ulRadioMode);/*设置数字功率*/
    ulRetVal |= BspSetNtfTsgSwitch(ulChan, 0, ulRadioMode, ulSwitch);/*打开或者关闭Tsg*/
    powshow();
    return ulRetVal;
}

static UINT32 BspNtfUpdateVswrComps(UINT32 bspChan, UINT32 uFreqKHz)
{
    UINT32 uRet = BSP_OK;
    T_RfCfgPara *pRfCfg = NULL;
    T_RfChanCfgEn rfChanCfgEn = {0};
    //T_DestCarrInfoAllChans carrInfoAllChans = {0};

    if(BSP_OK != BspCheckTxChannel(bspChan))
    {
        dbgErr("[%s]Para Error.\n",__FUNCTION__);
        return BSP_ERROR;
    }

    pRfCfg = BspGetRfCfgPara(bspChan, TX);
    if(NULL == pRfCfg)
    {
        dbgErr("[%s] chan %d pRfCfgPara in NULL \n",__FUNCTION__, bspChan);
        return BSP_ERROR;
    }
    //uRet |= BspGetRxPcGain(bspChan,pRfCfg->carrInfo[0].carrNo,pRfCfg->carrInfo[0].radioMode,&carrGain);
    pRfCfg->carrInfo[0].freq = uFreqKHz;
    /*
    carrInfoAllChans.txChanNum = 1;
    carrInfoAllChans.txCarrInfo[0].chanNo = bspChan;
    carrInfoAllChans.txCarrInfo[0].carrNum = 1;
    carrInfoAllChans.txCarrInfo[0].carrInfo[0].carrNo = pRfCfg->carrInfo[0].carrNo;
    carrInfoAllChans.txCarrInfo[0].carrInfo[0].radioMode = pRfCfg->carrInfo[0].radioMode;
    carrInfoAllChans.txCarrInfo[0].carrInfo[0].freq = pRfCfg->carrInfo[0].freq;
    carrInfoAllChans.txCarrInfo[0].carrInfo[0].bandWidth = pRfCfg->carrInfo[0].bandWidth;
    carrInfoAllChans.txCarrInfo[0].carrInfo[0].delOrAddFlag = pRfCfg->carrInfo[0].cfgFlag;

    carrInfoAllChans.rxChanNum = 1;
    carrInfoAllChans.rxCarrInfo[0].chanNo = bspChan;
    carrInfoAllChans.rxCarrInfo[0].carrNum = 1;
    carrInfoAllChans.rxCarrInfo[0].carrInfo[0].carrNo = pRfCfg->carrInfo[0].carrNo;
    carrInfoAllChans.rxCarrInfo[0].carrInfo[0].radioMode = pRfCfg->carrInfo[0].radioMode;
    carrInfoAllChans.rxCarrInfo[0].carrInfo[0].freq = pRfCfg->carrInfo[0].freq;
    carrInfoAllChans.rxCarrInfo[0].carrInfo[0].bandWidth = pRfCfg->carrInfo[0].bandWidth;
    carrInfoAllChans.rxCarrInfo[0].carrInfo[0].delOrAddFlag = pRfCfg->carrInfo[0].cfgFlag;
    dbgInfo("[%s] bspChan:%d carrNum:%d carrNo:%d radio:%d freq:%d bandWidth:%d delOrAddFlag:%d \n",__FUNCTION__,carrInfoAllChans.rxCarrInfo[0].chanNo,carrInfoAllChans.rxCarrInfo[0].carrNum,
    carrInfoAllChans.rxCarrInfo[0].carrInfo[0].carrNo,carrInfoAllChans.rxCarrInfo[0].carrInfo[0].radioMode,carrInfoAllChans.rxCarrInfo[0].carrInfo[0].freq,
    carrInfoAllChans.rxCarrInfo[0].carrInfo[0].bandWidth,carrInfoAllChans.rxCarrInfo[0].carrInfo[0].delOrAddFlag);
    uRet |= BspAnalyseRfcCfgFreqCarrInfo(&carrInfoAllChans);
    */
    rfChanCfgEn.carrNum = 1;
    rfChanCfgEn.carrInfo =  malloc(sizeof(T_SingCarrCfgEn) * 1 );
    INPUT_POINTER_CHECK(rfChanCfgEn.carrInfo);
    (VOID)memset_s(rfChanCfgEn.carrInfo, sizeof(T_SingCarrCfgEn)*1, 0, sizeof(T_SingCarrCfgEn)*1);
    rfChanCfgEn.carrInfo[0].delOrAddFlag = pRfCfg->carrInfo[0].cfgFlag;
    rfChanCfgEn.carrInfo[0].carrId = pRfCfg->carrInfo[0].carrNo;
    rfChanCfgEn.carrInfo[0].carrRadio = pRfCfg->carrInfo[0].radioMode;
    dbgInfo("[%s] bspChan:%d carrNo:%d radio:%d delOrAddFlag:%d\n",__FUNCTION__,bspChan,rfChanCfgEn.carrInfo[0].carrId,
                    rfChanCfgEn.carrInfo[0].carrRadio,rfChanCfgEn.carrInfo[0].delOrAddFlag);
    uRet |= BspResourceAllocCfg(TX, bspChan, &rfChanCfgEn);
    uRet |= BspResourceAllocCfg(RX, bspChan, &rfChanCfgEn);
    free(rfChanCfgEn.carrInfo);
    
    uRet |= BspSetTxRfCfg(bspChan, pRfCfg);
    //uRet |= BspSetRxRfCfg(bspChan, pRfCfg);
    //uRet |= BspUpdateTddCfg(2);
    //uRet |= BspUpdateCarrDelay(bspChan);
    uRet |= BspHalAdaptSetDlCarrGainSw(bspChan,pRfCfg->carrInfo[0].radioMode,pRfCfg->carrInfo[0].carrNo,SWITCH_ON);
    //uRet |= BspSetRxPcGain(bspChan,pRfCfg->carrInfo[0].carrNo,pRfCfg->carrInfo[0].radioMode,carrGain);
    uRet |= BspCfrChnInfoUpdateByBspChn(bspChan);
    uRet |= BspDpdSetCellInfo(bspChan, 0);

    return uRet;
}

/**************************************************************************
*                        函数实现
**************************************************************************/

/*所有自检项*/
/*****************************************************************************
*  函数名称   : NtfCheckPwr()
*  功能描述   : 电源自检需要分别对输入电压和单板上电源模块的输出电压进行异常检查
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : 无
*  输出参数   : 无
*  返 回 值   : 返回值
*  其它说明   :
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A), 10229672 2015.9.11  chuangjian
*----------------------------------------------------------------------------
*/
UINT32 NtfCheckPwr(void)
{
    UINT32 status   = 0;
    UINT32 ulRetVal = BSP_OK;
    UINT32 volt     = 0;

    status = BspGetPowerStatus();

    if (status & (BSP_POWER_48V_LOW_ALARM|BSP_POWER_48V_HIGH_ALARM))/*bit0 1 分别代表输入欠压、过压*/
    {
        dbgInfo("PWR INPUT VOLT ALARM in NtfCheckPwr!\n");
        //s_RruNtfItems[0].ulEndNtf = NTF_PAUSE_TEST;
        ulRetVal = BSP_NOTICE;
    }

    volt = BspGetPaVolt(0);
    if((volt > pwr48vVoltThreshold.voltUpThreshold) || (volt < pwr48vVoltThreshold.voltLowThreshold))
    {
        dbgInfo("BSP_ERROR in NtfCheckPwr!\n");
        ulRetVal = BSP_ERROR;
    }

    return ulRetVal;
}


/*****************************************************************************
*  函数名称   : NtfCheckPll(*)
*  功能描述   : 封装后的自检项，获取中频、RF PLL时钟状态
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : 无
*  输出参数   : 无
*  返 回 值   : 返回值
*  其它说明   :
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A), 10229672 chuangjian
*----------------------------------------------------------------------------
*/
UINT32 NtfCheckPll(void)
{
    UINT32 ulRetTx   = BSP_OK;
    UINT32 ulRetPrx  = BSP_OK;
    UINT32 ulRetRx   = BSP_OK;
    UINT32 ulRet     = BSP_OK;
    UINT32 devNo     = 0;
    UINT32 ulLoop    = 0;
    UINT32 txChnNum  = BspGetTxChannel();
    UINT32 prxChnNum = BspGetPrxChannel();
    UINT32 rxChnNum  = BspGetRxChannel();

    T_RfPllCfgPriv *pRfPllCfg = NULL;
    TRruDeviceDescription tRfDev = {0};

    /*下行锁相环锁定状态检测*/
    for( ulLoop = 0; ulLoop<txChnNum; ulLoop++ )
    {
            if(BSP_OK == BspChipInfoGetByRfPathDef(ulLoop, TX, DEVICE_TYPE_RFPLL, &tRfDev))
            {
                devNo = BspLoPllDevIdToDevNo(tRfDev.ulDeviceId);
                pRfPllCfg = BspGetRfPllCfgPriv(devNo);
                INPUT_POINTER_CHECK(pRfPllCfg);
                INPUT_POINTER_CHECK(pRfPllCfg->pChkLd);
                ulRetTx |= pRfPllCfg->pChkLd(tRfDev.ulDeviceIndex);
                dbgInfo("pll tx check result ulRetTx[index = %d]:[0x%08x]\n", ulLoop, ulRetTx);
            }
    }

    /*反馈通道锁相环锁定检测*/
    for( ulLoop = 0; ulLoop < prxChnNum; ulLoop++ )
    {
            if(BSP_OK == BspChipInfoGetByRfPathDef(ulLoop, PRX, DEVICE_TYPE_RFPLL, &tRfDev))
            {
                devNo = BspLoPllDevIdToDevNo(tRfDev.ulDeviceId);
                pRfPllCfg = BspGetRfPllCfgPriv(devNo);
                INPUT_POINTER_CHECK(pRfPllCfg);
                INPUT_POINTER_CHECK(pRfPllCfg->pChkLd);
                ulRetPrx |= pRfPllCfg->pChkLd(tRfDev.ulDeviceIndex);
                dbgInfo("pll prx check result ulRetPrx[index = %d]:[0x%08x]\n", ulLoop, ulRetPrx);
            }
    }

    /*接受通道锁相环锁定检测*/
    for( ulLoop = 0; ulLoop<rxChnNum; ulLoop++ )
    {
            if(BSP_OK == BspChipInfoGetByRfPathDef(ulLoop, RX, DEVICE_TYPE_RFPLL, &tRfDev))
            {
                devNo = BspLoPllDevIdToDevNo(tRfDev.ulDeviceId);
                pRfPllCfg = BspGetRfPllCfgPriv(devNo);
                INPUT_POINTER_CHECK(pRfPllCfg);
                INPUT_POINTER_CHECK(pRfPllCfg->pChkLd);
                ulRetRx |= pRfPllCfg->pChkLd(tRfDev.ulDeviceIndex);
                dbgInfo("pll rx check result ulRetRx[index = %d]:[0x%08x]\n", ulLoop, ulRetRx);
            }
    }
    /*所有通道时钟的锁定状态，只要有个不锁定即认为RF PLL不正常*/
    ulRet = (ulRetTx | ulRetPrx | ulRetRx );
    /* Started by AICoder, pid:j94fb53f1bg15a414bf60ac4907bd51c993625dd */
    if(ulRet != BSP_OK)
    {
        s_RruNtfItems[1].ulEndNtf = NTF_PAUSE_TEST;
    }
    /* Ended by AICoder, pid:j94fb53f1bg15a414bf60ac4907bd51c993625dd */
    return ulRet;
}


/*****************************************************************************
*  函数名称   : NtfGetOptStatus(*)
*  功能描述   : 诊断RRU光口状态是否正常
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : PhyOpticNo  RRU物理光口号,OpticRxPowThreshold    光接收功率异常判断门限
                OpticTxPowThreshold 光发送功率异常判断门限
*  输出参数   : 无
*  返 回 值   : 返回值
*  其它说明   :
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A), 10229672 2015.9.11 创建
*----------------------------------------------------------------------------
*/
UINT32 NtfGetOptStatus(void)
{
    UINT32 ulRet = BSP_OK;
    UINT32 ulUpOpt = 0;
    T_RruSfpInfo tSfpInfo = {0};

    if(BspGetOptSelfTestStatus(0) == 1)/*光纤自环状态下*/
    {
        dbgInfo("NO CHECK in NtfCheckOpt, in Opt Selftest Status!\n");
        return BSP_OK;
    }

    ulUpOpt = BspGetPhyNoBySfpNo(0);
    ulRet = BspGetOptStatus(ulUpOpt);
    /*检测光模块是否在位 bit0*/
    if(ulRet & 0x01)
    {
        dbgInfo("Opt%d Is Not Exist!\n",ulUpOpt);
        dbgInfo("BSP_NOTICE in NtfCheckOpt!\n");
        return BSP_NOTICE;
    }
    if(BSP_OK == BspGetSfpInfo(ulUpOpt,&tSfpInfo))
    {
        if((UINT32)0 != BspGetOptSignalRateAlarm(ulUpOpt))
        {
            dbgInfo("Cfg OptSpeed Abnormal,Abnormal Status is %d!\n",BspGetOptSignalRateAlarm(ulUpOpt));
            dbgInfo("BSP_NOTICE in NtfCheckOpt!\n");
            return BSP_NOTICE;
        }

        if((10*log10((FLOAT)(tSfpInfo.tSfpDigiDiagInfo.ulRxPower))-40) < (-12))
        {
            dbgInfo("Rx Power Abnormal, Please Replace Optical module or Check Optical fiber!\n");
            dbgInfo("BSP_NOTICE in NtfCheckOpt!\n");
            return BSP_NOTICE;
        }

        if((10*log10((FLOAT)(tSfpInfo.tSfpDigiDiagInfo.ulTxPower))-40) < (-9))//发射功率
        {
            dbgInfo("Tx Power Abnormal, Please Replace Optical module or Check Optical fiber!\n");
            dbgInfo("BSP_NOTICE in NtfCheckOpt!\n");
            return BSP_NOTICE;
        }
    }

    dbgInfo("BSP_OK in NtfCheckOpt!\n");
    return BSP_OK;
}

/*****************************************************************************
*  函数名称   : NtfCheckTxDac(*)
*  功能描述   : 诊断TX DAC是否正常
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : 无
*  输出参数   : 无
*  返 回 值   : 返回值
*  其它说明   : 如果204测试不通过，则进行底层serdes测试
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A), 10229672 2015.9.11 创建
*----------------------------------------------------------------------------
*/

UINT32 NtfCheckTxDac(void)
{
    UINT32 mtsNum     = 1;/*后续根据不同机型添加MTS数量*/
    UINT32 index      = 0;
    INT32  ret        = 0;
    ntf_MTS_Switch pMTS_SwitchNtf = NULL;
   // mtsNum = BspGetMtsDevNum();/*获取整机MTS数量*/

    /*204层下行DAC测试*/
    for (index = 0; index < mtsNum; index++)
    {
        pMTS_SwitchNtf = Ntf_MTSSwitch();
        if(pMTS_SwitchNtf != NULL)
        {
            pMTS_SwitchNtf();
            BspSysMsDelay(1000);
            ret |= pMTS_SwitchNtf();
            dbgInfoEx("The function pointer[pMTS_SwitchNtf]  is ok.\n");
        }
    }
    /* Started by AICoder, pid:j94fb53f1bg15a414bf60ac4907bd51c993625dd */
    if(ret != BSP_OK)
    {
        ret = BSP_ERROR;
        s_RruNtfItems[3].ulEndNtf = NTF_PAUSE_TEST;
    }
    /* Ended by AICoder, pid:j94fb53f1bg15a414bf60ac4907bd51c993625dd */
    return ret;
}

/*ADC 检测*/
UINT32 BspGetDpdicToMts204Status(UINT32 chipId, UINT32 mask, UINT32* pstatus)
{
    UINT32 ret = BSP_OK;
    UINT32 status = 0;
    UINT32 index = 0;
    UINT32 ulLinkStatRegData[4] = {0};
    UINT32 fbLinkStatRegData[4] = {0};
    UINT32 ulCrcCheckRegData[4] = {0};
    UINT32 fbCrcCheckRegData[4] = {0};
    UINT32 regAddr = 0;

    INPUT_POINTER_CHECK(pstatus);

        /* 204建链状态记录 */
    for(index=0; index<4; index++)
    {
        /* ul sync state */
        regAddr = s_204linkRegAddr[0][0] + index*4; 
        ret |= BspHalAdaptDpdicRegRd(0, regAddr, 0, &ulLinkStatRegData[index]);
        if (ulLinkStatRegData[index] != (UINT32)0x20001)
        {
            status |= BSP_BIT(index);
        }
        /* fb sync state */
        regAddr = s_204linkRegAddr[0][1] + index*4; 
        ret |= BspHalAdaptDpdicRegRd(0, regAddr, 0, &fbLinkStatRegData[index]);
        if (fbLinkStatRegData[index] != (UINT32)0x20001)
        {
            status |= BSP_BIT(index+4);
        }        
    }

    regAddr = s_204linkRegAddr[2][0]; 
    ret |= BspHalAdaptDpdicRegWr(0, regAddr, 0, 0x0f);/*清除RX上行*/
    BspSysMsDelay(100);

    regAddr = s_204linkRegAddr[2][1]; 
    ret |= BspHalAdaptDpdicRegWr(0, regAddr, 0, 0x0f);/*清除FB反馈*/
    BspSysMsDelay(100);

        /* 204 CRC误码记录 */
    for(index=0; index<4; index++)
    {
        /* ul crc check */
        regAddr = s_204linkRegAddr[1][0] + index*4; 
        ret |= BspHalAdaptDpdicRegRd(0, regAddr, 0, &ulCrcCheckRegData[index]); 
        if (ulCrcCheckRegData[index] != 0)
        {
            status |= BSP_BIT(index+8);
        }     
        /* fb crc check */
        regAddr = s_204linkRegAddr[1][1] + index*4; 
        ret |= BspHalAdaptDpdicRegRd(0, regAddr, 0, &fbCrcCheckRegData[index]);
        if (fbCrcCheckRegData[index] != 0)
        {
            status |= BSP_BIT(index+12);
        }              
    }

    dbgInfo("status = [0x%08x]\n", status);
    *pstatus = status & mask;
    return ret;
}


/*****************************************************************************
*  函数名称   : NtfCheckRxAdc(*)
*  功能描述   : 诊断RX ADC是否正常
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : 无
*  输出参数   : 无
*  返 回 值   : 返回值
*  其它说明   :
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A), 10229672 2015.9.11 创建
*----------------------------------------------------------------------------
*/
UINT32 NtfCheckRxAdc(void)
{
    UINT32 chipId   = 0;
    UINT32 statusRx = 0;
    UINT32 rxMask   = 0;

    rxMask = BspGetAdcStatusMask();
    if (BspGetDpdicToMts204Status(chipId, rxMask, &statusRx) != BSP_OK)
    {
        dbgInfo("exx  check rx ADC IC42 <==204== MTS  failed\n");
        return BSP_ERROR;
    }
    /* Started by AICoder, pid:j94fb53f1bg15a414bf60ac4907bd51c993625dd */
    if(statusRx != BSP_OK)
    {
        s_RruNtfItems[4].ulEndNtf = NTF_PAUSE_TEST;
    }
    /* Ended by AICoder, pid:j94fb53f1bg15a414bf60ac4907bd51c993625dd */
    return (statusRx == 0) ? BSP_OK : BSP_ERROR;
}

/*****************************************************************************
*  函数名称   : NtfCheckPrxAdc(*)
*  功能描述   : 诊断RX ADC是否正常
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : 无
*  输出参数   : 无
*  返 回 值   : 返回值
*  其它说明   :
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A), 10229672 2015.9.11 创建
*----------------------------------------------------------------------------
*/
UINT32 NtfCheckPrxAdc(void)
{
    UINT32 chipId   = 0;
    UINT32 statusRx = 0;
    UINT32 prxMask  = 0;

    prxMask = BspGetAdcStatusMask();
    if (BspGetDpdicToMts204Status(chipId, prxMask, &statusRx) != BSP_OK)
    {
        dbgInfo("exe check prx ADC IC42 <==204== MTS failed\n");
        return BSP_ERROR;
    }
    /* Started by AICoder, pid:j94fb53f1bg15a414bf60ac4907bd51c993625dd */
    if(statusRx != BSP_OK)
    {
        s_RruNtfItems[5].ulEndNtf = NTF_PAUSE_TEST;
    }
    /* Ended by AICoder, pid:j94fb53f1bg15a414bf60ac4907bd51c993625dd */
    return (statusRx == 0) ? BSP_OK : BSP_ERROR;
}



/*****************************************************************************
*  函数名称   : NtfTxPowerCheck(*)
*  功能描述   : 下行链路增益检测
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : 无
*  输出参数   : 无
*  返 回 值   : 返回值
*  其它说明   :
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A), 10229672 2015.9.11 创建
*----------------------------------------------------------------------------
*/
UINT32 NtfTxPowerCheck(VOID)
{
    UINT32 ulRet = BSP_OK;

    ulRet = BspNtfGetDefaultAtt();
    if (BSP_ERROR == ulRet)
    {
       return BSP_ERROR;
    }

    ulRet |= BspTxFullPowerCheck();
    if (BSP_ERROR == ulRet)
    {
       return BSP_ERROR;
    }

    /* Started by AICoder, pid:c6cddg4fe0o89f9149780b1400d4ef041d741ec3 */
    if(MODE_ONLY_FDD == BspGetFddTddCoExistSta())
    {
        ulRet |= BspTxReducePowerCheck();
    }
    /* Ended by AICoder, pid:c6cddg4fe0o89f9149780b1400d4ef041d741ec3 */
    return ulRet;
}

/*****************************************************************************
*  函数名称   : NtfTxAttCheck(*)
*  功能描述   : 发射ATT线性度检查
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : 无
*  输出参数   : 无
*  返 回 值   : 返回值
*  其它说明   :
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A), 10229672 2015.9.11 创建
*----------------------------------------------------------------------------
*/
UINT32 NtfTxAttCheck(void)
{
    UINT32 ulChan = 0;
    INT32  lDefaultAtt = 0;
    UINT32 ulPow = 1000;
    INT32 lAttVal = 0;
    UINT32 ulRet = BSP_OK;
    UINT32 txChnNum  = BspGetTxChannel();

    for(ulChan = 0; ulChan < txChnNum; ulChan++)
    {
        if(BspGetPaNormalFlag(ulChan) == PA_UNNORMAL)
        {
            continue;
        }
        if(SWITCH_OFF == BspGetPaSwitch(ulChan))
        {
            BspSetPaSwitch(ulChan, SWITCH_ON);
        }
        if(1 == BspGetNtfPowFlag())
        {
            BspGetRruPathRatedPower(ulChan,&ulPow);
            ulPow /= 2;
        }

        BspGetDefaultAtt(ulChan, ulPow, &lAttVal);
        BspSignalSwitchOri(ulChan, ulPow, SWITCH_ON);

        lDefaultAtt = lAttVal;

        BspSysMsDelay(2000);
        BspGetFwdCpIfTssi(ulChan, 0, &lTxAttFwd[0]);/*基准功率*/
        dbgInfo("Chan%d Default Att is %d,Fwd is %d!\n",ulChan,lDefaultAtt,lTxAttFwd[0]);

        ulRet |= NtfTxReduceAttCheck(ulChan, lDefaultAtt);

        BspSignalSwitchOri(ulChan, 0,SWITCH_OFF);
    }

    if(BSP_OK == ulRet)
    {
        dbgInfo("BSP_OK in NtfTxAttCheck!\n");
    }
    else
    {
        dbgInfo("BSP_ERROR in NtfTxAttCheck!\n");
    }

    return ulRet;
}


/*****************************************************************************
*  函数名称   : NtfGetPaVswrVal(*)
*  功能描述   : 封装后的自检项，获取VSWR驻波比
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : 无
*  输出参数   : 无
*  返 回 值   : 返回值
*  其它说明   :
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A), 10229672 changjian
*----------------------------------------------------------------------------
*/
UINT32 NtfGetPaVswrVal(void)
{
    UINT32 ulRet = BSP_OK;
    UINT32 ulTxChan = 0;
    UINT32 ulCount = 0;
    UINT32 flag = 0;
    UINT32 txChnNum  = BspGetTxChannel();

    for(ulTxChan = 0; ulTxChan < txChnNum; ulTxChan++)
    {
       if(BspGetPaNormalFlag(ulTxChan) == ulTxChan)
       {
           continue;
       }
       if(DPD_VSWR_FUNC_SUPPORT != BspIsSupportDpdVswr(ulTxChan))
       {
          ulCount ++;
       }
    }
    if(0 == ulCount)
    {
        flag = DPD_VSWR_FUNC_SUPPORT;
    }
    else
    {
        flag = DPD_VSWR_FUNC_NOT_SUPPORT;
    }
    
    dbgInfo("%s: flag = %d \n",__FUNCTION__,flag);
    ulRet = NtfVswrCheck(flag);

    return ulRet;
}

/*****************************************************************************
*  函数名称: NtfTxFlatCheck()
*  功能描述: 下行链路平坦度检查
*  输入参数: 无
*  输出参数: 无
*  返 回 值: 返回值
*  其它说明: 无
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A), 10229672 创建
*----------------------------------------------------------------------------*/
static UINT32 NtfTxFlatCheck(VOID)
{
    UINT32 ulRet = BSP_OK;
    UINT32 ulChan = 0;
    UINT32 ulPow = 1000;
    UINT32 centerFreq = 0;
    UINT32 lowerFreq = 0;
    UINT32 upperFreq = 0;
    UINT32 txChnNum = BspGetTxChannel();
    T_RruRfModuleInfo tRfModuleInfo = {0};

    for(ulChan = 0; ulChan < txChnNum; ulChan++)
    {
        if(1 == BspGetNtfPowFlag())
        {
            BspGetRruPathRatedPower(ulChan,&ulPow);
            ulPow /= 2;
        }
        if(SWITCH_OFF == BspGetPaSwitch(ulChan))
        {
            ulRet |= BspSetPaSwitch(ulChan, SWITCH_ON);
        }

        /* 获取下行起始和终止频点 */
        BspGetRruRfModuleInfo(ulChan, &tRfModuleInfo);
        lowerFreq = (INT32)tRfModuleInfo.ulRuTxStartFreq;
        upperFreq = (INT32)tRfModuleInfo.ulRuTxEndFreq;
        centerFreq = (lowerFreq + upperFreq) / 2;
        dbgInfo("Chan%d lowerFreq %d, upperFreq %d, centerFreq %d!\n", ulChan, lowerFreq, upperFreq, centerFreq);

        if(NULL != pSetFixLoFreqCallBack)
        {
            ulRet |= pSetFixLoFreqCallBack(ulChan, centerFreq);
        }
        ulRet |= NtfTxFreqBandFlatCheck(ulChan, lowerFreq + 10000, ulPow);        /*低频点*/
        ulRet |= NtfTxFreqBandFlatCheck(ulChan, upperFreq - 10000, ulPow);        /*高频点*/
        ulRet |= NtfTxFreqBandFlatCheck(ulChan, centerFreq, ulPow);       /*中频点*/
    }

    if(BSP_OK == ulRet)
    {
        dbgPrn("BSP_OK in NtfTxFlatCheck!\n");
    }
    else
    {
        dbgPrn("BSP_ERROR in NtfTxFlatCheck!\n");
    }
    return ulRet;
}

/*****************************************************************************
*  函数名称   : NtfRxPowerCheck(*)
*  功能描述   : 封装后的自检项，上行链路增益检测
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : 无
*  输出参数   : 无
*  返 回 值   : 返回值
*  其它说明   :
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A), 10229672 chuangjian
*----------------------------------------------------------------------------
*/

UINT32 NtfRxPowerCheck(VOID)
{
    UINT32 ulRet = BSP_OK;
    UINT32 ulChan = 0;
    UINT32 ulRadioMode = 0;
    INT32  lThreshHold = 0;
    INT32  lRssiDbm = 0;
    INT32  lRssiDbfs = 0;
    UINT32 txChnNum  = BspGetTxChannel();

    for (ulChan = 0; ulChan < txChnNum; ulChan++)
    {
        BspSetPowEnable(ulChan, SWITCH_OFF);
        BspSetLnaSwitch(ulChan, SWITCH_ON);
        BspSetRxSwitch(ulChan, SWITCH_ON);
    }

    //打桩制造异常
    for (int idx = 0; idx < 8; idx++)
    {
        if(0 == offLna[idx])
        {
            BspSetLnaSwitch(idx, SWITCH_OFF);
            BspSetRxSwitch(idx, SWITCH_OFF);
        }
    }
    BspSysMsDelay(1000);
    for(ulChan = 0; ulChan < BspGetRxChannel(); ulChan++)
    {
        ulRet |= NtfGetPreAnalyseCarrRadioMode(ulChan, &ulRadioMode);
        BspGetRssiPowInfoByMode(ulChan, 0, ulRadioMode, 0, 0, &lRssiDbm, &lRssiDbfs);
        
        if((BSP_RADIO_STANDARD_LTE_FDD|BSP_RADIO_STANDARD_FDD_5G)&ulRadioMode)
        {
            lThreshHold = FDD_LTE_RSSI_BW_20M_THRESHOLD;
        }
        if((BSP_RADIO_STANDARD_LTE_TDD|BSP_RADIO_STANDARD_5G)&ulRadioMode)
        {
            lThreshHold = TDD_LTE_RSSI_BW_20M_THRESHOLD;
        }

        if(lRssiDbm < lThreshHold || lRssiDbm >= 0)
        {
            s_RruNtfItems[9].cErrorChan |= BSP_BIT_SET(ulChan);
            ulRet = BSP_ERROR;
            dbgInfo("BSP_ERROR in Chan%d NtfCheckLteRssi %d!\n",ulChan, lRssiDbm);
        }
        else
        {
            dbgInfo("BSP_OK in Chan%d NtfCheckLteRssi! RSSI:%d\n",ulChan, lRssiDbm);
        }
    }

    return ulRet;
}

VOID str_replace(INT8 *buf, INT8 src, INT8 des)
{
    INPUT_POINTER_CHECK_RETURN(buf);

    while (*buf != '\0')
    {
        if (src == *buf)
        {
            *buf = des;
        }
        buf++;
    }
}


/*****************************************************************************
*  函数名称   : BspGetLteBandWidth()
*  功能描述   : 根据双工范围获取最接近的带宽
*  输入参数   : ulChan,通道号
*  输出参数   :
*  返 回 值   : ulBand,带宽
*  其它说明   :
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A),  yubo 创建
*****************************************************************************/

UINT32 BspGetLteBandWidth(UINT32 ulChan)
{
	UINT32 ulStartFreq = 0;
	UINT32 ulEndFreq = 0;
	UINT32 ulRruBandwidth = 0;
	UINT32 ulBand = NTF_TSG_LTE_BAND_TYPE_5M;
	T_RruRfModuleInfo tRfModuleInfo ={0};
	
    BspGetRruRfModuleInfo(ulChan, &tRfModuleInfo);
    ulStartFreq = tRfModuleInfo.ulRuRxStartFreq;
    ulEndFreq = tRfModuleInfo.ulRuRxEndFreq;
    ulRruBandwidth = abs(ulEndFreq-ulStartFreq);//检测的双工范围
    
	if(ulRruBandwidth>=17500)
	{
	   ulBand = NTF_TSG_LTE_BAND_TYPE_20M;
	}
	else if(ulRruBandwidth>=12500)
	{
	   ulBand = NTF_TSG_LTE_BAND_TYPE_15M;
	}
	else if(ulRruBandwidth>=7500)
	{
	   ulBand = NTF_TSG_LTE_BAND_TYPE_10M;
	}
	else if(ulRruBandwidth>=4000)
	{
	   ulBand = NTF_TSG_LTE_BAND_TYPE_5M;
	}
	else if(ulRruBandwidth>=2200)
	{
	   ulBand = NTF_TSG_LTE_BAND_TYPE_3M;
	}
	else
	{
	   ulBand = NTF_TSG_LTE_BAND_TYPE_1M4;
	}

    return ulBand;    
}

UINT32 BspStopOptAdapt(UINT32 ulCtrl)
{
    if(ulCtrl == 1)
    {
        optadptoff();/*关自适应*/
    }
    else
    {
        optadpton();/*开自适应*/
    }
	return BSP_OK;
}

UINT32 BspSetNtfVswrPosSign(VOID)
{
	g_vswrPosEn = 1;

    return BSP_OK;
}

/*****************************************************************************
*  函数名称   : InitDetectionResultFile()
*  功能描述   : 初始化自检结果记录文件
*  输入参数   : ptResult -- 初始化值
*  输出参数   : 无
*  返 回 值   : BSP_OK, 其它值为失败
*  其它说明   :
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A),  yc     @2019-09-11 20:38:55 创建
*****************************************************************************/
static UINT32 InitDetectionResultFile(TRruTestResult *ptResult)
{
    FILE *fp = NULL;
    INT32 ret = 0;
    UINT32 ulRet = BSP_OK;
    CHAR aucResultFile[80]={0};
    char aucFileName[70]={0};
    const UINT8 * pucFileDir = (UINT8*)"/ata/";

    INPUT_POINTER_CHECK(ptResult);

    /*构造文件名称*/
    GetResultFileName(&aucFileName[0],sizeof(aucFileName));
  //sprintf(aucResultFile,"%s%s",pucFileDir,&aucFileName[0]);
    ret=snprintf_s(aucResultFile,sizeof(aucResultFile),"%s%s",pucFileDir,&aucFileName[0]);
    SNPRINTF_S_CHECK(ret,sizeof(aucResultFile));
    dbgInfo("aucResultFile name = %s\n",aucResultFile);

    fp = fopen(aucResultFile, "r+b");
    if(fp == NULL)
    {
        fp = fopen(aucResultFile, "w+b");
        INPUT_POINTER_CHECK(fp);
    }
    if(fseek(fp,0,SEEK_SET) != 0)
    {
        dbgErr("%s: fseek error\n", __FUNCTION__);
        ret = fclose(fp);
		FCLOSE_CHECK(ret);
        return BSP_ERROR;
    }
    ulRet = fwrite(ptResult, 1, sizeof(TRruTestResult), fp);

    if (sizeof(TRruTestResult) != ulRet)
    {
	    ret = fclose(fp);
		FCLOSE_CHECK(ret);
        return BSP_ERROR;
    }
    ret = fclose(fp);
	FCLOSE_CHECK(ret);
    BspChmod(aucResultFile,"644");
    return BSP_OK;
}

/*****************************************************************************
*  函数名称   : BspSetTestMode()
*  功能描述   : 设置自检状态
*  输入参数   : 无
*  输出参数   : 无
*  返 回 值   : BSP_OK, 其它值为失败
*  其它说明   :
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A),  10229672 创建
*****************************************************************************/
UINT32 BspSetTestMode(UINT8 ucTestMode,UINT8 ucTestType,UINT8 ucFlag)//1 0 1
{
    FILE *fp = NULL;
	INT32  iRet = 0;
	INT32 fprtRet = 0;
    char aucResultFile[MAX_FILE_PATH_LEN]={0};
	
    GetResultFilePath(&aucResultFile[0], sizeof(aucResultFile));
    
    fp = fopen(aucResultFile, "r+b");/*文件生成后，不能删除文件中存储的检测结果*/
    if ( fp == NULL)
    {    
        fp = fopen(aucResultFile, "w+b");
        if(fp==NULL)
        {
        	return BSP_ERROR;
        }
    } 
	else if(ucFlag == 1)/*重新检测需要清除文件*/
	{    
	    iRet = fclose(fp);
		FCLOSE_CHECK(iRet);
        fp = fopen(aucResultFile, "w+b");
        if(fp==NULL)
        {
        	return BSP_ERROR;
        }
    }	
    if (fseek(fp,0,SEEK_SET) != 0)
    {
        dbgErr("%s: fseek error\n", __FUNCTION__);
        iRet = fclose(fp);
		FCLOSE_CHECK(iRet);
        return BSP_ERROR;
    }
    fprtRet = fprintf(fp,"TestMode=%d,TestType=%d\n",ucTestMode,ucTestType);
	FPRINTF_CHECK(fprtRet);
    iRet = fclose(fp);
	FCLOSE_CHECK(iRet);
    return BSP_OK;
}

VOID BspSetPowEnable(UINT32 chan, UINT32 sw)
{
    BspSetPaPowTxSwitch(chan, sw);//开小信号放大器
    BspSetPaSwitch(chan, sw);//开pa
    BspSetTxSwitch(chan, sw);//开Tx
}

/*****************************************************************************
*  函数名称   : BspGetInnerTestResult()
*  功能描述   : 获取自检结果信息
*  输入参数   : ptTestRlt -- 自检结果信息
*  输出参数   : 无
*  返 回 值   : BSP_OK, 其它值为失败
*  其它说明   : 给DTM 调用,获取完结果之后需要清除触发标志位
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A),  yc     @2019-09-11 20:38:55 创建
*****************************************************************************/
UINT32  BspGetInnerTestResult (TRruTestResult *ptTestRlt)
{
    UINT32 ulRet = BSP_OK;

    INPUT_POINTER_CHECK(ptTestRlt);
    ulRet |= NtfGetDetectionResult(ptTestRlt);
    /*获取结果之后，需要清除自检触发标志信息*/
    ulRet |= BspSetTestMode(0, g_testType, 0);
    if(BSP_ERROR==ulRet)
    {
    	dbgInfo("Flash is full,creat file FAIL!!!\n");
    }
    return ulRet;
}

/*****************************************************************************
*  函数名称   : BspInnerTestStart()
*  功能描述   : RRU单板启动自检
*  输入参数   : ptReqInfo -- 高层下发的自检信息，我们只用到 wTestType
*  输出参数   : 无
*  返 回 值   : BSP_OK, 其它值为失败
*  其它说明   : NTF 自检接口给DTM 调用
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A),  yc     @2019-09-11 20:38:55 创建
*****************************************************************************/
UINT32 BspInnerTestStart(TDetectReqInfo *ptReqInfo)
{
    UINT32 ulRet = BSP_OK;
    UINT32 txChnNum  = BspGetTxChannel();
    UINT32 ulChan = 0;

    INPUT_POINTER_CHECK(ptReqInfo);
    if((NTF_FAR_DETECTION != ptReqInfo->wTestType)&&(NTF_NEAR_DETECTION != ptReqInfo->wTestType))
    {
        return BSP_ERROR_INVALID_PARA;
    }
    dbgInfo("BspInnerTestStart...\n");
    BspSysMsDelay(1000);/*1s*/
    
    /*保存标志*/
    g_testType = ptReqInfo->wTestType;//0,光纤触发
    g_testMode = 1;  /*自检模式*/
    dbgInfo("g_testMode = %d,g_testType = %d\n", g_testMode, g_testType);
    exprnquit(); /*关闭断链打印*/
    for(ulChan = 0; ulChan < txChnNum; ulChan++)
    {
        BspSetPowEnable(ulChan, SWITCH_ON);
        BspSetLnaSwitch(ulChan, SWITCH_OFF);
        BspSetRxSwitch(ulChan, SWITCH_OFF);
        showcarrcfg(0, ulChan);
    }
    BspSetPaVibas(0);
    BspSysMsDelay(5000);
    powshow();

    ulRet |= BspSetTestMode(g_testMode,g_testType,1);  
    if(BSP_ERROR==ulRet)	
    {
    	dbgInfo("Flash is full,creat file FAIL!!!\n");
    }
    ulRet |= StartToDetection(); 
    return ulRet ;
}

/*****************************************************************************
*  函数名称   : BspGetTestMode()
*  功能描述   : 获取自检状态
*  输入参数   : 无
*  输出参数   : 无
*  返 回 值   : BSP_OK, 其它值为失败
*  其它说明   :
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A),  10229672 创建
*****************************************************************************/
UINT32 BspGetTestMode(UINT8 *ucTestMode,UINT8 *ucTestType)
{
    FILE *fp = NULL;
    INT32 ulTemp0 = 0;
    INT32 ulTemp1 = 0;
	INT32  iRet = 0;
    char aucResultFile[MAX_FILE_PATH_LEN]={0};
    /* UINT32 ulRet = BSP_OK; */
    INPUT_POINTER_CHECK(ucTestMode);
    INPUT_POINTER_CHECK(ucTestType);
	
    GetResultFilePath(&aucResultFile[0],sizeof(aucResultFile));
    
    fp = fopen(aucResultFile, "r");
    if ( fp == NULL )
    {
        return BSP_ERROR;
    }

	if(EOF == fscanf_s(fp,"TestMode=%d,TestType=%d",&ulTemp0,&ulTemp1))
	{
        dbgErr("%s: fscanf_s fail!\n", __FUNCTION__);
	}
    *ucTestMode = (UINT8)ulTemp0;
    *ucTestType = (UINT8)ulTemp1;
    iRet = fclose(fp);
	FCLOSE_CHECK(iRet);
    return BSP_OK;
}

static VOID BspSetClkAlmMask(UINT32 ulMode)
{
    UINT32 chanIdx   = 0;
    UINT32 txChnNum  = BspGetTxChannel();

    if(ulMode == 1)
    {
        for (chanIdx = 0; chanIdx < txChnNum; chanIdx++)
        {
            HalPaptPaAbnormalMask(chanIdx,0);
            HalPaptDaAbnormalMask(chanIdx,0);
            dbgInfo("Chan:%d Pa Abnormal Mask Success!\n",chanIdx);
        }
    }
    else
    {
        for (chanIdx = 0; chanIdx < txChnNum; chanIdx++)
        {
            HalPaptPaAbnormalMask(chanIdx,1);
            HalPaptDaAbnormalMask(chanIdx,1);
        }
    }
}

/*****************************************************************************
*  函数名称   : StartToDetection()
*  功能描述   : 自检入口
*  输入参数   : 无
*  输出参数   : 无
*  返 回 值   :   BSP_ERROR --执行成功
                             BSP_OK -- 执行失败
*  其它说明   : 0xff -- 定义为非自检状态
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A),  yc     @2019-09-11 20:38:55 创建
*****************************************************************************/
static UINT32 StartToDetection(void)
{
    UINT32 ulLogOpt = 0;

    if(NTF_NEAR_DETECTION == g_testType)
    {
        /* 屏蔽功放告警 */
        BspSetClkAlmMask(1);
    }
    /*开始自检项检测*/
    DetectRruItems();
    
    /*自检结束之后，后台网管发起的硬件自检，由BSP复位，光纤自环发起的，由高层复位*/
    if(NTF_FAR_DETECTION == g_testType)
    {
        /*如果是远端自检等待一段时间任何复位，目前暂定10s*/
        BspSysMsDelay(10000);/*10s*/

        dbgInfo(" Far Detection End ,reboot...\n");
        BspBoardReset();
        return BSP_OK;
    }

    IcHalCpriInternalLoopback(0,0);
    BspHalAdaptGetMainLogicOpt(&ulLogOpt);
    IcHalCpriMidFreqBfnSel(ulLogOpt);
    BspSetClkAlmMask(0);

    return BSP_OK;
}

/*****************************************************************************
*  函数名称   : GetResultFileName()
*  功能描述   : 获取自检结果文件的文件名
*  输入参数   : 无
*  输出参数   : pucFileName -- 文件名
*  返 回 值   :   BSP_ERROR --执行成功
                             BSP_OK -- 执行失败
*  其它说明   :
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A),  yc     @2019-09-11 20:38:55 创建
*****************************************************************************/
static UINT32 GetResultFileName(char *pucFileName, UINT32 ulLen)
{
    T_BspInventoryInfo tInventoryInfo={0};
    rsize_t bufLenSize = (rsize_t)ulLen;
    INT32 ret = 0;

    INPUT_POINTER_CHECK(pucFileName);
    /*获取整机系列号*/
    BspGetRruInventory(&tInventoryInfo);
    /*构造文件名*/
    ret=snprintf_s(pucFileName,bufLenSize,"RRUNTF_%s_RawData.txt",tInventoryInfo.acSerialNumber);
    SNPRINTF_S_CHECK(ret,bufLenSize);
    return BSP_OK;
}

/*****************************************************************************
*  函数名称   : GetResultFilePath()
*  功能描述   : 获取自检结果文件的文件名
*  输入参数   : 无
*  输出参数   : pucFileName -- 文件名
*  返 回 值   :   BSP_ERROR --执行成功
                             BSP_OK -- 执行失败
*  其它说明   :
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A),  yc     @2019-09-11 20:38:55 创建
*****************************************************************************/
static UINT32 GetResultFilePath(char *pucFilePath, UINT32 ulLen)
{
    INT32  snpRet=0;
    char aucFileName[MAX_FILE_NAME_LEN]={0};
    INPUT_POINTER_CHECK(pucFilePath);
    /*构造文件名称*/
    GetResultFileName(&aucFileName[0],sizeof(aucFileName));
    snpRet = snprintf_s(pucFilePath,ulLen,"%s%s",NTF_RAW_FILE_DIR,&aucFileName[0]);
    SNPRINTF_S_CHECK(snpRet,ulLen);
    return BSP_OK;
}

/**********************************************************************
* 函数名称： BspDiagInit
* 功能描述： diagnose init
* 输入参数：
* 输出参数： 无
* 返 回 值： 无
* 其它说明：
* 修改日期        版本号     修改人	      修改内容
***********************************************************************
*  $0000000(N/A), ZKH@2014-11
*---------------------------------------------------------------------*/
static UINT32 BspDiagInit(VOID)
{
   UINT32 ulChan = 0;
   UINT32 paVolt = 0;
   UINT32 txChnNum  = BspGetTxChannel();
	/* reset dpd */
   for (ulChan = 0; ulChan < txChnNum; ulChan++)
   {
       BspGetPaDefaultVolt(ulChan,&paVolt);
       if (0 == paVolt)
       {
           paVolt = 48000;
       }
       dbgInfo("[%s] ulChan%u, paVolt%u\n", __FUNCTION__, ulChan, paVolt);
       BspSetPaVolt(ulChan, (INT32)paVolt);
       BspInitDpd(ulChan,0);
   }
   return BSP_OK;
}

/*****************************************************************************
 *  函数名称   : BspRestoreStdout()
 *  功能描述   : restore standard output
 *  读全局变量 : 无
 *  写全局变量 : 无
 *  输入参数   : 无
 *  输出参数   : 无
 *  返 回 值   : 0 - success, 其它值为失败
 *  其它说明   :
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *  $0000000(N/A), ZKH@2014-10
 *----------------------------------------------------------------------------
 */
static VOID BspRestoreStdout(VOID)
{
    dup2(g_StdOutFile, STDOUT_FILENO);
    close(g_InitLogFile);
}

/*****************************************************************************
*  函数名称   : BspDetectOneItem
*  功能描述   : 进行某一项自检
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : 无
*  输出参数   : 无
*  返 回 值   : 返回值
*  其它说明   :
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A), 10229672  2017.8.2 创建
*----------------------------------------------------------------------------
*/
UINT32 BspDetectOneItem(UINT32 ulLoop)
{
    UINT32 ulRet = BSP_OK;
    UINT32 (*pfItemFunc)() = NULL;
    char file[100] = "DiagOneItem.txt";
    time_t ulTime = 0;
    time_t ulTime1 = 0;
    INT32  ret = 0;
#ifdef UT_FT_TEST
    return BSP_OK;
#endif
    BspSaveStdout2File(file);
    ulTime = time(NULL);
    if(ulTime == -1)
    {
        dbgInfo("get time error !\n");
    }

    dbgInfo("\n-------------begin %s-------------\n", s_RruNtfItems[ulLoop].pItemName);
    pfItemFunc = s_RruNtfItems[ulLoop].RruNtfItemFunc;
    ulRet = pfItemFunc();

    ulTime1 = time(NULL);
    if(ulTime1 == -1)
    {
        dbgInfo("get time error !\n");
    }
    dbgInfo("\n-------------end %s----return %d, run time %ld seconds\n",
        s_RruNtfItems[ulLoop].pItemName, ulRet, ulTime1 - ulTime);
    BspRestoreStdout();

    ret = BspSystem("cat DiagOneItem.txt");
    CHECK_RET_WARNING(ret, "cat failed, ret:%d", ret);
    ret = BspSystem("cat DiagOneItem.txt >> report.txt");
    CHECK_RET_WARNING(ret, "redirection failed, ret:%d", ret);
    ret = BspSystem("rm -f DiagOneItem.txt");
    CHECK_RET_WARNING(ret, "rm failed, ret:%d", ret);
    return ulRet;
}

/* Started by AICoder, pid:649571a9eeh3580147b80b0be0743046eed31fd4 */
UINT32 BspRecordVswrLocation(void)
{
    UINT32 retVal = BSP_OK;
    UINT32 chan = 0;
    CHAR   pcChan[20] = {0};
    UINT32 chanNum = BspGetTxChannel();
    INT32  snpRet = 0;

    if(chanNum >= BSP_MAX_TX_CHAN)
    {
        dbgErr("[%s]:Chan is %d, out bounds error!\n",__FUNCTION__,chanNum);
        return BSP_ERROR;
    }
    for(chan = 0; chan < chanNum; chan ++)
    {
        if(vswrAv[chan] > 1.6)
        {
            if(g_vswrPosVal[chan] == OUTSIDE_VSWR_TEST_POINT)
            {
                snpRet = snprintf_s(pcChan, 20, "Chan(%#X)", chan);
                SNPRINTF_S_CHECK(snpRet, sizeof(pcChan));
                retVal |= NtfRecordDetectionResult(TEST_PRINT_TYPE, 0, NULL, pcChan, 0);
                retVal |= NtfRecordDetectionResult(TEST_PRINT_TYPE, 0, NULL, " Location=", 0);
                retVal |= NtfRecordDetectionResult(TEST_NOTICE_INFO_TYPE, 0, NULL, NULL, fLocation[chan]);
            }
            if(g_vswrPosVal[chan] == UNCERTAIN_VSWR_TEST_POINT)
            {
                snpRet = snprintf_s(pcChan, 20, "Chan(%#X)", chan);
                SNPRINTF_S_CHECK(snpRet, sizeof(pcChan));
                retVal |= NtfRecordDetectionResult(TEST_PRINT_TYPE, 0, NULL, pcChan, 0);
                retVal |= NtfRecordDetectionResult(TEST_PRINT_TYPE, 0, NULL, "FuzzyRegion", 0);
            }
            if(g_vswrPosVal[chan] == INSIDE_VSWR_TEST_POINT)
            {
                snpRet = snprintf_s(pcChan, 20, "Chan(%#X)", chan);
                SNPRINTF_S_CHECK(snpRet, sizeof(pcChan));
                retVal |= NtfRecordDetectionResult(TEST_PRINT_TYPE, 0, NULL, pcChan, 0);
                retVal |= NtfRecordDetectionResult(TEST_PRINT_TYPE, 0, NULL, "InternalVswr", 0);
            }
        }
    }
    return retVal;
}
/* Ended by AICoder, pid:649571a9eeh3580147b80b0be0743046eed31fd4 */

/*****************************************************************************
*  函数名称   : DetectRruItems(*)
*  功能描述   : 开始自检项检测
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : 无
*  输出参数   : 无
*  返 回 值   : 返回值
*  其它说明   :
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A), 尧小安@2019-10-10 13:26:17 移植到TRMB24 单板
*----------------------------------------------------------------------------
*/
UINT32 NtfRecordResult(UINT32 ulLoop)
{
    UINT32 ret = BSP_OK;
    INT32 retVal = 0;
    char   pcChan[20] = {0};

    if(NTF_ITEM_RUN == s_RruNtfItems[ulLoop].ulRunFlag)
        {
            ret |= NtfRecordDetectionResult(TEST_PRINT_TYPE, 0, NULL, s_RruNtfItems[ulLoop].pItemName, 0);
            if(BSP_OK == s_RruNtfItems[ulLoop].ulFuncRet)
            {
                ret |= NtfRecordDetectionResult(TEST_PRINT_TYPE, 0, NULL, "SUCC\n", 0);
            }
            else if(BSP_NOTICE == s_RruNtfItems[ulLoop].ulFuncRet)
            {
                ret |= NtfRecordDetectionResult(TEST_PRINT_TYPE, 0, NULL, "NOTICE ", 0);
                if(ulLoop > 5)
                {
                    retVal = snprintf_s(pcChan, 20, "ChanMask(%#X)", s_RruNtfItems[ulLoop].cErrorChan);
                    SNPRINTF_S_CHECK(retVal, sizeof(pcChan));
                    ret |= NtfRecordDetectionResult(TEST_PRINT_TYPE, 0, NULL, pcChan, 0);
                    if(8 == ulLoop)/*记录驻波位置*/
                    {
                        ret |= BspRecordVswrLocation();
                    }
                }
                ret |= NtfRecordDetectionResult(TEST_PRINT_TYPE, 0, NULL, "\n", 0);
            }
            else
            {
                ret |= NtfRecordDetectionResult(TEST_PRINT_TYPE, 0, NULL, "FAIL ", 0);
                if(ulLoop > 5)
                {
                    retVal = sprintf_s(pcChan, 20, "ChanMask(%#X)", s_RruNtfItems[ulLoop].cErrorChan);
                    SNPRINTF_S_CHECK(retVal, sizeof(pcChan));
                    ret |= NtfRecordDetectionResult(TEST_PRINT_TYPE, 0, NULL, pcChan, 0);
                }
                ret |= NtfRecordDetectionResult(TEST_PRINT_TYPE, 0, NULL, "\n", 0);
            }
        }
        else
        {
            ret |= NtfRecordDetectionResult(TEST_PRINT_TYPE, 0, NULL, s_RruNtfItems[ulLoop].pItemName, 0);
            ret |= NtfRecordDetectionResult(TEST_PRINT_TYPE, 0, NULL, "Not Excute\n",0);
        }
    return ret;
}


static UINT32 DetectRruItems(VOID)
{
    UINT32 ulRet = BSP_OK;
    UINT32 ulFinalRet = BSP_OK;
    UINT32 ret = BSP_OK;
    UINT32 ulItemNum = 0;
    UINT32 ulLoop = 0;
    UINT32 ulChan = 0;
    CHAR   aucPara[60] = {0};
    UINT32 ulParaLen = 0;
    time_t retVal = 0;
    time_t ulTimeRet = 0;
    time_t timep = 0;
    char   ucItemStr[300] = "NTF Abnormal Items:\n";/*用于存储原始数据，最后写入自检结果文件后面*/
    struct tm *pTm = NULL;
    TCodeInfo tTCodeInfo = {0};
    UINT32 txChnNum  = BspGetTxChannel();

    ulTimeRet = time(&timep);
    if(ulTimeRet == ((time_t)(-1)))
    {
        dbgErr("%s(%d) warning! > time ret'%ld! \n", __FUNCTION__, __LINE__, ((long)ulTimeRet));
    }

    /*自检开始*/
    dbgPrn("Start RRU NTF ITEMS CHECK!!\n");
    (VOID)exprnquit();
    ret |= BspDiagInit();
    ulItemNum = sizeof(s_RruNtfItems)/sizeof(TRruNtfItem);
    dbgPrn("NTF_ITEMS_TotalNum = %d\n",ulItemNum);

    ret = BspSystem("rm -f report.txt");
    CHECK_RET_WARNING(ret, "rm failed, ret:%u", ret);
    for(ulLoop = 0; ulLoop < ulItemNum; ulLoop++)
    {
        memset_s((INT8 *)&tTCodeInfo, sizeof(TCodeInfo), 0, sizeof(TCodeInfo));
        for(ulChan = 0; ulChan < txChnNum; ulChan++)
        {
            ret |= BspSetPaSwitch(ulChan, SWITCH_OFF);
        }
        dbgInfo("|*********************************** ulLoop = %d **********************************|\n", ulLoop);
        ulRet = BspDetectOneItem(ulLoop);
        s_RruNtfItems[ulLoop].ulFuncRet = ulRet;
        /*记录已执行完毕的检测项*/
        s_RruNtfItems[ulLoop].ulRunFlag = NTF_ITEM_RUN;

        if((BSP_OK != ulRet) && (BSP_NOTICE != ulRet))
        {
            BspSetNtfResult(BSP_ERROR);
            /*有任何一项内部属性不正常，则认为总自检结果不正常*/
            if(NTF_INTERNAL_FAULT == s_RruNtfItems[ulLoop].ulItemInfo)
            {
                ulFinalRet = BSP_ERROR;
                /*内部故障才能写入告警码，外部故障不算故障类型*/
                tTCodeInfo.dwCode = BSP_NTF_FINAL_RESULT_ERROR;
            }
            /*返回值转换成字符串，写入原始文件*/
            retVal = snprintf_s(aucPara, sizeof(aucPara), "%u", ulRet);
            if(((retVal) < (INT32)0) || ((retVal) > (sizeof(aucPara))))
            {
                dbgErr("%s(%d) warning! > snprintf_s ret'%ld max'%zu! \n", __FUNCTION__, __LINE__, (long)retVal,(size_t)(sizeof(aucPara)));
            }
            strncpy_s((char *)tTCodeInfo.aucPara, sizeof(aucPara), aucPara, sizeof(aucPara));
            ulParaLen = sizeof(tTCodeInfo.aucPara);
            tTCodeInfo.aucPara[ulParaLen-1] = '\0';
            /*保存带有告警的原始信息*/
            strncat_s(ucItemStr, sizeof(ucItemStr), s_RruNtfItems[ulLoop].pItemName, (sizeof(ucItemStr) - strnlen_s(ucItemStr, sizeof(ucItemStr)) -1));

            /*判断是否需要继续检测*/
            if(NTF_CONTINUE_TEST == s_RruNtfItems[ulLoop].ulEndNtf)
            {
                if(BSP_ERROR == ulFinalRet)
                {
                    /*只有内部故障时才能写入fail，外部故障不能写入fail*/
                    ret |= NtfRecordDetectionResult(TEST_FAIL_TYPE, NTF_CONTINUE_TEST, &tTCodeInfo, NULL, 0);
                }
                dbgPrn("---Items Detect Continue\n");
                continue;
            }
            else if(NTF_PAUSE_TEST == s_RruNtfItems[ulLoop].ulEndNtf)
            {
                if(BSP_ERROR == ulFinalRet)
                {
                    /*只有内部故障时才能写入fail，外部故障不能写入fail*/
                    ret |= NtfRecordDetectionResult(TEST_FAIL_TYPE, NTF_PAUSE_TEST, &tTCodeInfo, NULL, 0);
                }
                dbgPrn("---Items Detect End!!!\n");
                break;
            }
        }
    }

    /*添加空格行*/
    ret |= NtfRecordDetectionResult(TEST_PRINT_TYPE, 0, NULL, "\n", 0);
    ret |= NtfRecordDetectionResult(TEST_PRINT_TYPE, 0, NULL,
            "Attentions:If internal attribute item fails,the result fails.But,external attribute item fails,the result may succ.\n", 0);
    ret |= NtfRecordDetectionResult(TEST_PRINT_TYPE, 0, NULL, "========DETAILS========\n", 0);
    /*保存自检结果*/
    if(BSP_OK == ulFinalRet)
    {
        /*无内部故障作为自检结果中的一种，必须写入自检结果文件*/
        tTCodeInfo.dwCode = BSP_NTF_FINAL_RESULT_OK;
        tTCodeInfo.aucPara[0] = '0';
        ret |= NtfRecordDetectionResult(TEST_SUCC_TYPE, 0, NULL, NULL, 0);
    }
    else
    {
        /*检测完成之后，将故障检测项的原始数据打印在结果最后*/
        ret |= NtfRecordDetectionResult(TEST_PRINT_TYPE, 0, NULL, ucItemStr, 0);
        /*添加空格行*/
        ret |= NtfRecordDetectionResult(TEST_PRINT_TYPE, 0, NULL, " ", 0);
    }
    /*分隔字符*/
    ret |= NtfRecordDetectionResult(TEST_PRINT_TYPE, 0, NULL, "\n", 0);
    ret |= NtfRecordDetectionResult(TEST_PRINT_TYPE, 0, NULL, "NTF Items Info:\n", 0);

    /*将所有执行过的检测项打印在文件最后*/
    for(ulLoop = 0; ulLoop < ulItemNum; ulLoop++)
    {
        ret |= NtfRecordResult(ulLoop);
    }

    ret |= NtfRecordDetectionResult(TEST_PRINT_TYPE, 0, NULL, "\n========NTF TIME INFO=======\n", 0);
    /*生成文件的时间,东八区相差8小时，不连BBU校准是绝对时间，校准后是相对时间*/
    ret |= NtfRecordDetectionResult(TEST_PRINT_TYPE, 0, NULL, "CreatNtfFileTime:", 0);
    pTm = localtime(&timep);
    if(NULL != pTm)
    {
        ret |= NtfRecordDetectionResult(TEST_PRINT_TYPE, 0, NULL, asctime(pTm), 0);
    }
    //ret |= NtfRecordVerInfo();
    ret |= NtfRecordDetectionResult(TEST_PRINT_TYPE, 0, NULL, "\n===============================\n", 0);
    retVal = BspSystem("cp /report.txt /ata/");
    CHECK_RET_WARNING(ret, "cp failed, ret:%ld", ((long)retVal));

    /*自检结束*/
    BspSetNtfLedRunState(NTF_END);
    return ret;
}

/*****************************************************************************
*  函数名称   : BspGetDefaultAtt(UINT32 ulChan)
*  功能描述   : 获取定标之后的att值
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : 无
*  输出参数   : 无
*  返 回 值   : 返回值
*  其它说明   :
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A), 10229672 2015.9.11 创建
*----------------------------------------------------------------------------
*/
UINT32 BspGetDefaultAtt(UINT32 ulChan, UINT32 SigPow, INT32 *lAttVal)
{
    INT32  lTssi = 0;
    INT32  lFwd = 0;
    UINT32 ulLoop = 0;
    INT32  lAttTemp = -1750;

    INPUT_POINTER_CHECK(lAttVal);
    BspSignalSwitchOri(ulChan,SigPow,SWITCH_ON);
    BspSetPaSwitch(ulChan, SWITCH_ON);
    for(ulLoop = 0; ulLoop < 10; ulLoop++)
    {
        BspSetTxGain(ulChan, lAttTemp);
        BspSysMsDelay(10000);

        BspGetTxIfTssi(ulChan, 0, &lTssi);
        BspGetFwdCpIfTssi(ulChan, 0, &lFwd);

		dbgInfo("Chan=%d,Loop=%d, Att=%d, Tssi=%d, Fwd=%d\n",ulChan, ulLoop, lAttTemp, lTssi, lFwd);

		if((lTssi == 0) || (lFwd == 0))
        {
        	continue;
        }
		
        if(abs(lTssi-lFwd) >= 100)
        {
            lAttTemp += (lTssi - lFwd) * 0.8;
            dbgInfo("lAttTemp is %d\n",lAttTemp);
            if(lAttTemp > -300)
            {
                break;
            }
        }
        else
        {
            break;
        }
    }
    BspSignalSwitchOri(ulChan, 0, SWITCH_OFF);
    *lAttVal = ((lAttTemp - 25) / 50) * 50;
	dbgInfo("lAttTemp=%d, lAttVal=%d\n",lAttTemp, *lAttVal);
    return BSP_OK;
}

/*****************************************************************************
*  函数名称   : NtfCirculatorCheck(*)
*  功能描述   : 封装后的自检项，环形器检测
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : 无
*  输出参数   : 无
*  返 回 值   : 返回值
*  其它说明   :
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A), 10229672 chuangjian
*----------------------------------------------------------------------------
*/

static UINT32 NtfCirculatorCheck(void)
{  
    return BSP_OK;
}

/* 陈永红 下行链路增益自检之前，加入一个小功率驻波检测，在双工中心频点发射-25dBFs(20W)的单音，如果驻波小于2.5，则正常进行后面流程，如果驻波不小于2.5，则后续的下行链路增益、ATT线性和驻波自检均在数字域回退6dB功率情况下进行自检检测 */
static UINT32 BspNtfChkVswr(VOID)
{
    UINT32 ulChan = 0;
	UINT32 ulPow = 1000;
	UINT32 ulVswr = 0;
    UINT32 ulRet = BSP_OK;
    UINT32 txChnNum  = BspGetTxChannel();

    for (ulChan = 0; ulChan < txChnNum; ulChan++)
    {
        if(BspGetPaNormalFlag(ulChan) == PA_UNNORMAL)
        {
            continue;
        }
        if(1 == BspGetNtfPowFlag())
        {
            BspGetRruPathRatedPower(ulChan,&ulPow);
            ulPow /= 2;
        }
        ulRet |= BspSignalSwitchOri(ulChan, ulPow, SWITCH_ON);
		if(SWITCH_OFF == BspGetPaSwitch(ulChan))
        {
            BspSetPaSwitch(ulChan, SWITCH_ON);
        }
        BspSysMsDelay(2000); 
		ulRet |= BspGetScalarVswr(ulChan, &ulVswr);
        /* 驻波大于等于2.5 认为没接负载，后面的检测流程要回退6dB */
		if(ulVswr >= 2500000)
        {
            VswrHighFlag[ulChan] = 1;
		}

		ulRet |= BspSignalSwitchOri(ulChan, 0, SWITCH_OFF);
	}

    return ulRet;
}

UINT32 BspNtfGetDefaultAtt(VOID)
{
    UINT32 ulChan = 0;
	UINT32 ulPow = 1000;
    UINT32 ulRet = BSP_OK;
	INT32  lAttVal = 0;
    UINT32 txChnNum  = BspGetTxChannel();

	for(ulChan = 0; ulChan < txChnNum; ulChan++)
    {
        NTF_CHECK_CHN_FOR_EACH(ulChan);
        if(BspGetPaNormalFlag(ulChan) == PA_UNNORMAL)
        {
            continue;
        }
        if(1 == BspGetNtfPowFlag())
        {
            BspGetRruPathRatedPower(ulChan,&ulPow);
            ulPow /= 2;
        }
        BspGetDefaultAtt(ulChan,ulPow, &lAttVal);
        g_lAttVal[ulChan] = lAttVal;

		if(lAttVal > -300)
	    {
	        dbgInfo("Chan%d PA or TX/PRX Gain Abnormal,att is %d!\n",ulChan,lAttVal);
            s_RruNtfItems[6].cErrorChan += BSP_BIT_SET(ulChan);
	 	    ulRet = BSP_ERROR;
	    }
	    else if(lAttVal > -600)
	    {
	        dbgInfo("Chan%d PA or TX/PRX Gain Notice,att is %d!\n",ulChan,lAttVal);
	        ulRet |= BSP_NOTICE;
	    }
	    else
	    {
	        dbgInfo("Chan%d PA or TX/PRX Gain OK,att is %d!\n",ulChan,lAttVal);
	    }
	}

	if(BSP_ERROR == ulRet)/*2个通道一个ERROR,一个NOTICE,也返回ERROR*/
    {
        dbgInfo("BSP_ERROR in NtfTxPowerCheck!\n");        
        return BSP_ERROR;
    }

	return ulRet;
}

UINT32 BspTxFullPowerCheck(VOID)
{
    UINT32 ulChan = 0;
	UINT32 ulPow = 1000;
	UINT32 ulRet = BSP_OK;
    UINT32 txChnNum  = BspGetTxChannel();
	
    for(ulChan = 0;ulChan < txChnNum; ulChan++)
    {  	
        NTF_CHECK_CHN_FOR_EACH(ulChan);
        if(BspGetPaNormalFlag(ulChan) == PA_UNNORMAL)
        {
            continue;
        }
		if(1 == BspGetNtfPowFlag())
        {
            BspGetRruPathRatedPower(ulChan,&ulPow);
            ulPow /= 2;
        }
        BspSignalSwitchOri(ulChan,ulPow,SWITCH_ON);

        if(SWITCH_OFF == BspGetPaSwitch(ulChan))
        {
            BspSetPaSwitch(ulChan, SWITCH_ON);
        }
        for (int idx = 0; idx < 8; idx++)
        {
            if(0 == offPa[idx])
            {
                BspSetPaSwitch(idx, SWITCH_OFF);
            }
        }

        BspSetTxGain(ulChan, g_lAttVal[ulChan]);
        BspSysMsDelay(15000);
        dbgInfoEx("%s >> Chan%d Start!\n",__FUNCTION__,ulChan);
        powshow();
        BspGetTxIfTssi(ulChan, 0, &lTssi[0][ulChan]);
        BspGetFwdCpIfTssi(ulChan, 0, &lFwd[0][ulChan]);

		dbgInfo("Chan=%d,ulPow=%d, Att=%d, Tssi=%d, Fwd=%d\n",ulChan, ulPow, g_lAttVal[ulChan], lTssi[0][ulChan], lFwd[0][ulChan]);

        //开环定标时，门限值为±4db
        if(abs(lFwd[0][ulChan] - lTssi[0][ulChan]) > 400)
        {
            dbgInfo("Chan%d PA or TX/PRX Gain Abnormal,Fwd is %d,TSSI is %d!\n",ulChan,lFwd[0][ulChan],lTssi[0][ulChan]);
            s_RruNtfItems[6].cErrorChan += BSP_BIT_SET(ulChan);
            ulRet = BSP_ERROR;
        }
        else
        {
            dbgInfo("Chan%d TX/PRX Gain Normal!\n",ulChan);
        }
        ulRet |= BspSignalSwitchOri(ulChan,0,SWITCH_OFF);
    }
    if(BSP_ERROR == ulRet)
    {    
        dbgInfo("BSP_ERROR in NtfTxPowerCheck!\n");		 
        return BSP_ERROR;
    }

	return ulRet;
}

UINT32 BspTxReducePowerCheck(VOID)
{
    UINT32 ulChan                    = 0;
    UINT32 ulLoop                    = 0;
    USHORT usErrFlag[MAX_TX_CHANNEL] = {0};
    UINT32 ulPow                     = 1000;
    UINT32 ulPowChan                 = 0;
    UINT32 ulRet                     = BSP_OK;
    UINT32 ulRadioMode               = 0;
    UINT32 txChnNum                  = BspGetTxChannel();
	
    for (ulChan=0; ulChan < txChnNum; ulChan++)
    {
        NTF_CHECK_CHN_FOR_EACH(ulChan);
        if(1 == BspGetNtfPowFlag())
        {
            BspGetRruPathRatedPower(ulChan,&ulPow);
            ulPow /= 2;
        }

        ulRet |= BspSignalSwitchOri(ulChan,ulPow,SWITCH_ON);
        ulRet |= NtfGetPreAnalyseCarrRadioMode(ulChan, &ulRadioMode);
        if(BspGetPaNormalFlag(ulChan) == PA_UNNORMAL)
        {
            continue;
        }

        for (ulLoop = 1; ulLoop < 4; ulLoop++)
        {    
			//调节增益，每次衰减3db
            ulPowChan = ulPow / pow(2, ulLoop);   /*每次降3db*/
            ulRet |= BspSetCarrDbPow(ulChan, 0, ulPowChan, ulRadioMode);
            dbgInfo("Chan%d Loop %d PowChan is %d!\n", ulChan, ulLoop , ulPowChan);
            BspSysMsDelay(10000);
            ulRet |= BspGetFwdCpIfTssi(ulChan, 0, &lFwd[ulLoop][ulChan]);
            ulRet |= BspGetTxIfTssi(ulChan, 0, &lTssi[ulLoop][ulChan]);
            dbgInfo("Chan%d Last TSSI is %d,FWD is %d,Now TSSI is %d,FWD is %d!\n", ulChan, lTssi[ulLoop - 1][ulChan], lFwd[ulLoop - 1][ulChan], lTssi[ulLoop][ulChan], lFwd[ulLoop][ulChan]);
            if(abs(lFwd[ulLoop][ulChan] - (lFwd[ulLoop - 1][ulChan] - 300)) > 200)
            {
                dbgInfo("Chan%d PA or TXATT or FBATT or TX/PRX Gain Abnormal!\n",ulChan);
                dbgInfo("Chan%d Last TSSI is %d,FWD is %d,Now TSSI is %d,FWD is %d!\n", ulChan, lTssi[ulLoop - 1][ulChan], lFwd[ulLoop - 1][ulChan], lTssi[ulLoop][ulChan], lFwd[ulLoop][ulChan]);
		        if(0 == usErrFlag[ulChan])
		        {
		            s_RruNtfItems[6].cErrorChan += BSP_BIT_SET(ulChan);
		            usErrFlag[ulChan] = 1;
		        }
                ulRet = BSP_ERROR;
            }
            else
            {
                dbgInfo("Chan%d TXATT Normal,TSSI is %d,FWD is %d!\n",ulChan,lTssi[ulLoop][ulChan],lFwd[ulLoop][ulChan]);
            }
        } 
        ulRet |= BspSignalSwitchOri(ulChan,0,SWITCH_OFF);
    }
	
    if(BSP_ERROR==ulRet)
    {        
        dbgInfo("BSP_ERROR in NtfTxPowerCheck!\n");        
        return BSP_ERROR;
    }
    else/*0或者NOTICE*/
    {        
        dbgInfo("BSP_OK in NtfTxPowerCheck!\n");                
    }

	return ulRet;
}



UINT32 NtfGetThresholdByLoop(UINT32 ulLoop)
{
    UINT32 ulThreshold =0;
	
    if(ulLoop == 2)
	{
	    ulThreshold = 150;	//门限150
	}
	else if(3 == ulLoop)
	{
	    ulThreshold = 200;//门限200
	}
	else 
	{
	    ulThreshold = 300;//门限300
	}

	return  ulThreshold;//返回门限

}

static UINT32 NtfTxReduceAttCheck(UINT32 ulChan, INT32 lDefaultAtt)
{
    UINT32 ulLoop = 0;
	INT32  lChangedAtt = 0;
	UINT32 ulRetTmp = BSP_OK;
	UINT32 ulThreshold = 0;
    USHORT usErrFlag[MAX_TX_CHANNEL] = {0};
	UINT32 ulRet = BSP_OK;

    if(ulChan >= BspGetTxChannel())
    {
        dbgErr("[%s]:Chan is %d, out bounds error!\n",__FUNCTION__,ulChan);
        return BSP_ERROR;
    }
	
    for(ulLoop=1;ulLoop<5;ulLoop++)
	{
	    lChangedAtt = 100*pow(2,ulLoop-1);
		ulRetTmp = BspSetTxGain(ulChan, lDefaultAtt-lChangedAtt);
	    if(ulRetTmp!=BSP_ERROR_INVALID_PARA)
	    {
	        ulThreshold = NtfGetThresholdByLoop(ulLoop);
	        BspSysMsDelay(5000);
	        BspGetFwdCpIfTssi(ulChan, 0, &lTxAttFwd[ulLoop]);
	        if(abs(lTxAttFwd[ulLoop]-(lTxAttFwd[0]-lChangedAtt))>ulThreshold)
	        {
	            dbgInfo("Chan%d TXATT Linearity Abnormal,ATT is %d,FWD is %d!\n",ulChan,lDefaultAtt-lChangedAtt,lTxAttFwd[ulLoop]); 
	            if(0==usErrFlag[ulChan])
                {
                    s_RruNtfItems[7].cErrorChan += BSP_BIT_SET(ulChan);
                    usErrFlag[ulChan] = 1;
                }
	            ulRet = BSP_ERROR;                    
	        }
	        else
	        {
	            dbgInfo("Chan%d TXATT Linearity Normal,ATT is %d,FWD is %d!\n",ulChan,lDefaultAtt-lChangedAtt,lTxAttFwd[ulLoop]);
	        }
	    }
	}

	return ulRet;
}


static VOID BspComplexDiv1(TComplex *c1, TComplex *c2, TComplex *result)
{
    FLOAT d1 = 0.0;
    FLOAT d2 = 0.0;
    FLOAT d3 = 0.0;

    INPUT_POINTER_CHECK_RETURN(c1);
    INPUT_POINTER_CHECK_RETURN(c2);
    INPUT_POINTER_CHECK_RETURN(result);

    d1=c1->real*c2->real+c1->image*c2->image;
    d2=c2->real*c2->real+c2->image*c2->image;
    d3=c1->image*c2->real-c1->real*c2->image;

    if(d2 != 0)
    {
        result->real = d1/d2;
        result->image = d3/d2;
    }
    else
    {
        result->real = 0.0;
        result->image = 0.0;
    }
}

INT32 BspCalcPhaseDiff(TComplex *pComplex, UINT32 count, FLOAT *average, FLOAT *minimum)
{
    UINT32 i        = 0;
    TComplex comDiv = {0.0};
    FLOAT angle     = 0.0;
    FLOAT angleSum  = 0.0;
    FLOAT mini      = 0.0;

    if(count > VSWR_MAX_TEST_POINT)
	{
		dbgErr("%s %d too many point %d\n", __FUNCTION__, __LINE__, count);
		return BSP_ERROR;
	}   
    INPUT_POINTER_CHECK(pComplex);
    INPUT_POINTER_CHECK(average);
    STRCHR_CHECK(minimum);
    for(i = 0; i < count - 1; i++)
    {
        BspComplexDiv1(&(pComplex[i+1]), &(pComplex[i]), &comDiv);
        angle = atan2(comDiv.image, comDiv.real);

        if(angle < mini)
        {
            mini = angle;
        }

        dbgInfoEx("%s %d div = %.5f + %.5fj angle = %.5f\n", __FUNCTION__, __LINE__, comDiv.real, comDiv.image, angle);
        angleSum += angle;
    }

    if(average)
    {
        *average = angleSum / (count - 1);
    }

    if(minimum)
    {
        *minimum = mini;
    }

    return 0;
}

/* Started by AICoder, pid:f10a71fc44tc9251429a095a10c6482ec3508f92 */
DOUBLE BspGetVswrThreByBandWidth(UINT32 width)
{
    DOUBLE thre = 0.0;

    if(width < 100000)
    {
        thre = -4.0;
    }
    else if(width <= 250000)
    {
        thre = -1.5;
    }
    else
    {
        thre = -0.7;
    }

    return thre;
}
/* Ended by AICoder, pid:f10a71fc44tc9251429a095a10c6482ec3508f92 */

/*****************************************************************************
*  函数名称   : BspJudgeVswrPos
*  功能描述   : calculate spa phase diff and gamma phase diff,
                judge vswr internal fault or external fault.
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : 无
*  输出参数   : 无
*  返 回 值   : 返回值
*  其它说明   :
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A), liyongzhe @2016-01-07  创建
*----------------------------------------------------------------------------
*/
INT32 BspJudgeVswrPos(UINT32 chan, UINT32 count, INT32 phaseDiff)
{
    UINT32 radioMode = 0;
    FLOAT fGammaPhaseDiff = 0;
    UINT32 freqStep = BspGetNtfVswrStep();
    UINT32 bandWidth = 0;
    T_RruRfModuleInfo tRfModuleInfo = {0};
    DOUBLE thre = 0.0;
    
    if(chan >= BSP_MAX_TX_CHAN)
    {
        dbgErr("[%s]:Chan is %d, out bounds error!\n",__FUNCTION__,chan);
        return BSP_ERROR;
    }

    BspGetRruRfModuleInfo(chan, &tRfModuleInfo);
    bandWidth = tRfModuleInfo.ulRuTxEndFreq - tRfModuleInfo.ulRuTxStartFreq;
    thre = BspGetVswrThreByBandWidth(bandWidth);
    NtfGetPreAnalyseCarrRadioMode(chan, &radioMode);
    if((BSP_RADIO_STANDARD_LTE_FDD|BSP_RADIO_STANDARD_FDD_5G)&radioMode)
    {
        BspCalcPhaseDiff(g_comGamma, count, &fGammaPhaseDiff, NULL);
        fLocation[chan] = -1.0 * 0.7 * 3 * 100000 / 4 / 3.14 / freqStep * fGammaPhaseDiff;
    }
    if((BSP_RADIO_STANDARD_LTE_TDD|BSP_RADIO_STANDARD_5G)&radioMode)
    {

        fGammaPhaseDiff = (FLOAT)phaseDiff;
        fLocation[chan] = (-1.0 * 0.7 * fGammaPhaseDiff) / (24.0 * 360.0);
    }
    s_gammaPhaseDiff[chan] = fGammaPhaseDiff;
    dbgInfo("GammaL phase diff average = %f fLocation = %f\n", fGammaPhaseDiff, fLocation[chan]);

    if(fLocation[chan] < thre)
    {
        dbgPrn("Vswr Rru Internal Fault!\n");
        return INSIDE_VSWR_TEST_POINT;    /*内部驻波，点VSWR灯*/
    }
    else if(fLocation[chan] < 1.0)
    {
        dbgPrn("Vswr Rru Fuzzy Region Fault!\n");
        return UNCERTAIN_VSWR_TEST_POINT;    /*模糊区，点VSWR灯*/
    }
    else
    {
        dbgPrn("Vswr Rru External Fault, Location is %.2fm!\n", fLocation[chan]);
        return OUTSIDE_VSWR_TEST_POINT;     /*外部驻波，不点VSWR灯*/
    }

}

/*****************************************************************************
 *  函数名称   : BspGetAntennaVswr(*)
 *  功能描述   : 根据离线参数判断使用标量驻波还是矢量驻波
 *  读全局变量 : 无
 *  写全局变量 : 无
 *  输入参数   : chan    -  发射通道号
 *  输出参数   : 无
 *  返 回 值   : 驻波比值*1000000，驻波比，无法获取驻波比时返回BSP_INVALID_VALUE
 *  其它说明   : RRU公共接口函数
 *  工装使用申明: 工装使用接口，请注意波及
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *  $0000000(N/A),  ZKH       @2013-11     创建
 *  $0000000(N/A),  liyongzhe @2016-01-07  移植
 *----------------------------------------------------------------------------
 */
UINT32 BspGetAntennaVswr(UINT32 chan)
{
    UINT32 vswr = 0;

	if(DPD_VSWR_FUNC_SUPPORT == BspIsSupportDpdVswr(chan))
	{
		/* ANTENNA model */
		vswr = BspGetPaVswrVal(chan,0, ANTENNA_VSWR_MODE);
	}
	else
	{
		/* PA model */
		vswr = BspGetPaVswrVal(chan,0, PA_VSWR_MODE);
	}

	return vswr;
}

static UINT32 BspGetAntennaVswr_Tdd(UINT32 chan)
{
    UINT32 vswr = 0;

    if(DPD_VSWR_FUNC_SUPPORT == BspIsSupportDpdVswr(chan))
    {
        vswr = (UINT32)BspCalcVswrByVector(chan, 0);
    }
    else
    {
        BspGetScalarVswr(chan, &vswr);
    }

    return vswr;
}
/*****************************************************************************
 *  函数名称   : BspTestGetSpaVswr
 *  功能描述   : get vswr value, Spa and Gamma L
 *  输入参数   : ulTxChan: channel number
 *  输出参数   : pVswr: the calculated vswr value, unit is 1e-5
 				 pGamma: the calculated gammaL value, this is complex number
				 pSpa: Spa is a complex number
 *  返 回 值   : BSP_OK-成功，BSP_ERROR-失败
 *  其它说明   : this is for factory test only
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *  $0000000(N/A),  ZKH       @2014-08     创建
 *  $0000000(N/A),  liyongzhe @2016-01-07  移植
 *----------------------------------------------------------------------------
 */
UINT32 BspTestGetSpaVswr(UINT32 chan, FLOAT * pVswr, TComplex * pSpa, TComplex * pGamma)
{
    UINT32 vswr = 0;
	T_VswrTaoInfo tVswrTaoInfo = {0};
    UINT32 txChnNum = BspGetTxChannel();

    INPUT_POINTER_CHECK(pVswr);
    INPUT_POINTER_CHECK(pSpa);
    INPUT_POINTER_CHECK(pGamma);
	if (chan >= txChnNum)
	{
		dbgErr("%s %d Para Error, chan = %d\n", __FUNCTION__, __LINE__, chan);
		return BSP_ERROR;
	}
    /*根据离线参数决定使用标量驻波或者矢量驻波*/
    vswr = BspGetAntennaVswr(chan);

	if((BSP_ERROR_INVALID_PARA != vswr) && (BSP_ERROR != vswr ) && (BSP_EXCEPT_VSWR_VAL != vswr))
	{

		    memset_s(&tVswrTaoInfo, sizeof(T_VswrTaoInfo), 0, sizeof(T_VswrTaoInfo));
		    BspGetVswrTao(chan, &tVswrTaoInfo);
			pGamma->real = (FLOAT)(tVswrTaoInfo.sVswrTaoRealRem) / 1e4;
			pGamma->image = (FLOAT)(tVswrTaoInfo.sVswrTaoImagRem) / 1e4;

			BspGetVswrSpa(chan, &tVswrTaoInfo);
			pSpa->real = (FLOAT)(tVswrTaoInfo.sVswrTaoRealRem) / 1e5;
			pSpa->image = (FLOAT)(tVswrTaoInfo.sVswrTaoImagRem) / 1e5;

		*pVswr = (FLOAT)vswr / 1e6;

	    return BSP_OK;
	}
	else
	{
		return BSP_ERROR;
	}
}

static UINT32 BspTestGetSpaVswr_Tdd(UINT32 chan, FLOAT *pVswr, TComplex *pGamma)
{
    UINT32 vswr = 0;
    T_VswrTaoInfo tVswrTaoInfo = {0};
    UINT32 txChnNum = BspGetTxChannel();

    INPUT_POINTER_CHECK(pVswr);
    INPUT_POINTER_CHECK(pGamma);
    if(chan >= txChnNum)
    {
        dbgErr("%s %d Para Error, chan = %d\n", __FUNCTION__, __LINE__, chan);
        return BSP_ERROR;
    }

    vswr = BspGetAntennaVswr_Tdd(chan);
    if((BSP_INVALID_VALUE != vswr) && (BSP_ERROR != vswr))
    {
        memset_s(&tVswrTaoInfo, sizeof(T_VswrTaoInfo), 0, sizeof(T_VswrTaoInfo));
        BspGetVswrTao(chan, &tVswrTaoInfo);
        pGamma->real = (FLOAT)(tVswrTaoInfo.sVswrTaoRealRem) / 1e4;
        pGamma->image = (FLOAT)(tVswrTaoInfo.sVswrTaoImagRem) / 1e4;
        *pVswr = (FLOAT)vswr / 1e6;
        return BSP_OK;
    }
    else
    {
        return BSP_ERROR;
    }
}
/*****************************************************************************
*  函数名称   : BspCollectVswrData
*  功能描述   : collect vswr related data
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : 无
*  输出参数   : lowerFreq, upperFreq, FreqStep 单位KHz
*  返 回 值   : 无
*  其它说明   :
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A), ZKH       @2015-11    创建
*  $0000000(N/A), liyongzhe @2016-01-07 移植
*----------------------------------------------------------------------------
*/
static UINT32 BspCollectVswrData(UINT32 chan, UINT32 lowerFreq, UINT32 upperFreq, UINT32 FreqStep)
{
	UINT32 retVal = BSP_OK;
    UINT32 ulFreq = 0;
    UINT32 ulPow = 1000;
	UINT32 ulRadioMode = 0; 
    UINT32 ulBandWidth = 0;
    INT32  lAttVal = 0;
    UINT32 i = 0;
    T_RruRfCfgInfo tRruCfgPara={0};

    if(chan >= BSP_MAX_TX_CHAN)
    {
        dbgErr("[%s]:Chan is %d, out bounds error!\n",__FUNCTION__,chan);
        return BSP_ERROR;
    }

    retVal |= BspGetChnlCfgCarrPara(chan,&tRruCfgPara);
    if(1 == BspGetNtfPowFlag())
    {
        BspGetRruPathRatedPower(chan,&ulPow);
        ulPow /= 2;
    }
	BspGetDefaultAtt(chan, ulPow, &lAttVal);
    g_lAttVal[chan] = lAttVal;
	BspSetTxGain(chan, g_lAttVal[chan]);
      	
	BspSignalSwitchOri(chan,ulPow,SWITCH_ON);

    /*开功放*/
    if(SWITCH_OFF==BspGetPaSwitch(chan))
    {
        BspSetPaSwitch(chan, SWITCH_ON);
    }
    retVal |= NtfGetPreAnalyseCarrRadioMode(chan, &ulRadioMode);

    tRruCfgPara.carr[0].carrTxNo = 0;
	tRruCfgPara.carr[0].carrTxRadio = ulRadioMode;
	//tRruCfgPara.carr[0].carrTxBw =0;
	tRruCfgPara.txCfgCarrSum =1;
	tRruCfgPara.carr[0].carrPow = ulPow;
	tRruCfgPara.txCenterFreq = BspGetLoFreq(TX, chan);
    ulBandWidth = BspGetFreqBw(1,chan,0);
	retVal |= BspSetRruCfgPara(chan, &tRruCfgPara);
	retVal |= BspInitDpd(chan,0);
	retVal |= setWaitDspMode(WAIT_DSP_SLOW);
	for(ulFreq = ((UINT32)lowerFreq + ulBandWidth/2), i = 0; ulFreq <= ((UINT32)upperFreq - ulBandWidth/2); ulFreq += (UINT32)FreqStep, i++)
	{
        if(i >= VSWR_MAX_TEST_POINT)
        {
            dbgErr("[%s]:i is %d, out bounds error!\n",__FUNCTION__,i);
            break;
        }
		retVal |= BspNtfUpdateVswrComps((UINT32)chan,ulFreq);

        /* 清零:SPA, GammaL, VSWR */
		g_comSpa[i].real = 0;
		g_comSpa[i].image = 0; 
		g_comGamma[i].real = 0;
		g_comGamma[i].image = 0;
		g_vswr[i] = 0;
        BspSysMsDelay(1000);
		retVal |= BspTestGetSpaVswr(chan, &(g_vswr[i]), &(g_comSpa[i]), &(g_comGamma[i]));
        BspSysMsDelay(1000);
        retVal |= BspTestGetSpaVswr(chan, &(g_vswr[i]), &(g_comSpa[i]), &(g_comGamma[i]));
        dbgInfo("chan %d freq %d vswr = %f\n", chan, ulFreq, g_vswr[i]);
        dbgInfo("spa = %.5f + %.5fj gammaL = %.5f + %.5fj\n",
			g_comSpa[i].real, g_comSpa[i].image, 
			g_comGamma[i].real, g_comGamma[i].image);
    } 
	retVal |= BspSignalSwitchOri(chan,ulPow,SWITCH_OFF);

    return retVal;
}

UINT32 BspCollectVswrData_Tdd(UINT32 chan, INT32 *phaseDiff)
{
    UINT32 retVal = BSP_OK;
    UINT32 ulPow = 1000;
    UINT32 ulRadioMode = 0;
    INT32  lAttVal = 0;
    T_RruRfCfgInfo tRruCfgPara = {0};
    T_RruVswrInfo tRruCfgPara_5g = {0};
    T_VswrPosValcRst posVal = {0};
    T_VswrPosCalcPara para = {0};

    INPUT_POINTER_CHECK(phaseDiff);
    if(chan >= BSP_MAX_TX_CHAN)
    {
        dbgErr("[%s]:Chan is %d, out bounds error!\n",__FUNCTION__,chan);
        return BSP_ERROR;
    }

    if(1 == BspGetNtfPowFlag())
    {
        BspGetRruPathRatedPower(chan,&ulPow);
        ulPow /= 2;
    }
    retVal |= BspGetDefaultAtt(chan, ulPow, &lAttVal);
    g_lAttVal[chan] = lAttVal;
    retVal |= BspSetTxGain(chan, g_lAttVal[chan]);
    retVal |= BspSignalSwitchOri(chan, ulPow, SWITCH_ON);
    BspSysMsDelay(1000);

    /*开功放*/
    if(SWITCH_OFF == BspGetPaSwitch(chan))
    {
        retVal |= BspSetPaSwitch(chan, SWITCH_ON);
    }
    retVal |= NtfGetPreAnalyseCarrRadioMode(chan, &ulRadioMode);
    retVal |= BspGetChnlCfgCarrPara(chan, &tRruCfgPara);
    tRruCfgPara.carr[0].carrTxNo = 0;
    tRruCfgPara.carr[0].carrTxRadio = ulRadioMode;
    tRruCfgPara.txCfgCarrSum = 1;
    tRruCfgPara.carr[0].carrPow = ulPow;
    tRruCfgPara.txCenterFreq = BspGetLoFreq(TX, chan);
    dbgInfo("LoFreq is %d \n", tRruCfgPara.txCenterFreq);
    retVal |= BspSetRruCfgPara(chan, &tRruCfgPara);
    retVal |= BspGetChnlCfgCarrPara_5G(chan, &tRruCfgPara_5g);
    tRruCfgPara_5g.uiCarrNum = 1;
    tRruCfgPara_5g.carr->uiCarrNo = 0;
    tRruCfgPara_5g.carr->iFraAHeadAdj = abs(IcHalApiGetFrTmVal(0,ulRadioMode) * 3.84 /1000);
    retVal |= BspSetRruCfgPara_5G(chan, &tRruCfgPara_5g);
    retVal |= BspInitDpd(chan, 0);
    retVal |= setWaitDspMode(WAIT_DSP_SLOW);

    BspSetDpdMultiVswrFlag(1);
    BspGetVswrPosCalcPara(chan, 0, &para);
    BspGetAveragePhaseByVector(chan, 0, para, &posVal);
    *phaseDiff = posVal.phaseDiff;

    BspSysMsDelay(1000);
    retVal |= BspSignalSwitchOri(chan, ulPow, SWITCH_OFF);
    return retVal;
}
/*****************************************************************************
*  函数名称   : BspCalcVswrAverage
*  功能描述   : calculate vswr average value
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : 无
*  输出参数   : 驻波比的平均值*pAverage
*  返 回 值   : 返回值
*  其它说明   :
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A), ZKH       @2015-11    创建
*  $0000000(N/A), liyongzhe @2016-01-07 移植
*----------------------------------------------------------------------------
*/
INT32 BspCalcVswrStatistic(INT32 chan, INT32 band, UINT32 count, FLOAT * pAverage)
{
	int i = 0;
	FLOAT sum = 0;
	
    INPUT_POINTER_CHECK(pAverage);
    if(count > VSWR_MAX_TEST_POINT)/*判断有效点数*/
	{
		dbgErr("%s %d input too many point %d \n", __FUNCTION__, __LINE__, count);
		return BSP_ERROR;
	}   
	for(i = 0; i < count; i++)/*求平均*/
	{
		sum+=g_vswr[i];
	}

	if(pAverage)
	{
		*pAverage = sum/count;
	}

	return BSP_OK;
}

/*****************************************************************************
*  函数名称   : NtfVswrPosCheck
*  功能描述   : vswr positon calculate and check
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : 无
*  输出参数   : 无
*  返 回 值   : 返回值
*  其它说明   :
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A), ZKH       @2015-11    创建
*  $0000000(N/A), liyongzhe @2016-01-07 移植
*----------------------------------------------------------------------------
*/
INT32 BspVswrPosCheck(UINT32 chan, UINT32 lowerFreq, UINT32 upperFreq, UINT32 FreqStep)
{
	INT32    ret        = 0;
	UINT32 count        = 0;
    FLOAT  fVswrAverage = 0;
    UINT32 ulRadioMode  = 0;
    UINT32 ulBandWidth  = 0;
    INT32  phaseDiff = 0;
    DOUBLE dVswrAverage = 0.0;
    
    if(chan >= BSP_MAX_TX_CHAN)
    {
        dbgErr("[%s]:Chan is %d, out bounds error!\n",__FUNCTION__,chan);
        return BSP_ERROR;
    }
    ulBandWidth = BspGetFreqBw(1,chan,0);
    count = (upperFreq - lowerFreq - ulBandWidth + FreqStep) / FreqStep;
    dbgInfo("upFeq = [%d], lowFeq = [%d], count = [%d] \n", upperFreq, lowerFreq, count);

    if(count > VSWR_MAX_TEST_POINT)
	{
		dbgErr("%s %d too many point %d\n", __FUNCTION__, __LINE__, count);
		return BSP_ERROR;
	}   

    ret |= NtfGetPreAnalyseCarrRadioMode(chan, &ulRadioMode);
    
    if((BSP_RADIO_STANDARD_LTE_FDD|BSP_RADIO_STANDARD_FDD_5G)&ulRadioMode)
    {
        BspCollectVswrData(chan, lowerFreq, upperFreq, FreqStep);
        BspCalcVswrStatistic(chan, 0, count, &fVswrAverage);
    }
    if((BSP_RADIO_STANDARD_LTE_TDD|BSP_RADIO_STANDARD_5G)&ulRadioMode)
    {
        BspCollectVswrData_Tdd(chan, &phaseDiff);
        BspGetMultiVectorVswrVal(&dVswrAverage);
        fVswrAverage = (FLOAT)dVswrAverage;
    }

    dbgInfo("Chan%d NtfGetPaVswrVal, VSWR is %.2f!\n",chan,fVswrAverage);
	if(1.6 <= fVswrAverage)
	{	
	    dbgInfo("BSP_ERROR in Chan%d NtfGetPaVswrVal!\n",chan);
	    vswrAv[chan] = fVswrAverage;
		
		ret |= BspJudgeVswrPos(chan, count, phaseDiff);//获取驻波位置，当驻波比异常时，判断驻波位置，确定是内部异常还是外部异常
	}
	else
	{
	    dbgInfo("BSP_OK in Chan%d NtfGetPaVswrVal!\n",chan);
	}
	
	return ret;
}

UINT32 BspVswrPosCheckAll(VOID)
{
	INT32 retTemp = 0;
	INT32 lowerFreq = 0;
	INT32 upperFreq = 0;
	INT32 FreqStep = 2000;  /*step is 2MHz*/
    UINT32 ulTxChan = 0;
    INT32 aret[MAX_TX_CHAN] = {0};
    UINT32 txChnNum = BspGetTxChannel();
    T_RruRfModuleInfo tRfModuleInfo = {0};

    for(ulTxChan = 0; ulTxChan < txChnNum; ulTxChan++)
    {
        if(BspGetPaNormalFlag(ulTxChan) == PA_UNNORMAL)
        {
            continue;
        }
        /* 获取下行起始和终止频点 */
        BspGetRruRfModuleInfo(ulTxChan, &tRfModuleInfo);
        lowerFreq = (INT32)tRfModuleInfo.ulRuTxStartFreq;
        upperFreq = (INT32)tRfModuleInfo.ulRuTxEndFreq;

        retTemp = BspVswrPosCheck(ulTxChan, lowerFreq + 1000, upperFreq - 1000, FreqStep);/*-2:内部，-1外部，-4模糊区*/
        if(BSP_OK!=retTemp)
        {
            s_RruNtfItems[8].cErrorChan +=BSP_BIT_SET(ulTxChan);
        }

        aret[ulTxChan] = retTemp;
        g_vswrPosVal[ulTxChan] = retTemp;
        BspSetVswrPosVal(ulTxChan, retTemp);
    }

    //有通道过驻波时，返回BSP_NOTICE，不再返回BSP_ERROR
    for(ulTxChan = 0; ulTxChan < txChnNum; ulTxChan++)
    {
        if(BspGetPaNormalFlag(ulTxChan) == PA_UNNORMAL)
        {
            continue;
        }
    	if(0 != aret[ulTxChan])
    	{
            return BSP_NOTICE;
    	}
    }

    return BSP_OK;
}

UINT32 NtfVswrCheck(UINT32 flag)
{
    UINT32 ulTxChan = 0;
	UINT32 ulRet = BSP_OK;
	UINT32 ulVswr = 0;
	UINT32 ulRadioMode = 0;
	UINT32 ulPow = 1000;
	INT32 lAttVal = 0;
    UINT32 txChnNum = BspGetTxChannel();

    if(DPD_VSWR_FUNC_SUPPORT == flag)
    {
	    ulRet = BspVswrPosCheckAll();//矢量检测,驻波比及驻波位置都要检测
		return ulRet;
	}
	else
	{
        for(ulTxChan = 0;ulTxChan < txChnNum; ulTxChan++)//标量检测，只检测驻波位置
        {
            if(1 == BspGetNtfPowFlag())
            {
                BspGetRruPathRatedPower(ulTxChan,&ulPow);
                ulPow /= 2;
            }
        	BspGetDefaultAtt(ulTxChan,ulPow, &lAttVal);
        	BspSignalSwitchOri(ulTxChan,ulPow,SWITCH_ON);

            if(SWITCH_OFF==BspGetPaSwitch(ulTxChan))
            {
                BspSetPaSwitch(ulTxChan,SWITCH_ON);
            }
            BspSysMsDelay(2000); 

            NtfGetPreAnalyseCarrRadioMode(ulTxChan, &ulRadioMode);
    
            if((BSP_RADIO_STANDARD_LTE_FDD|BSP_RADIO_STANDARD_FDD_5G)&ulRadioMode)
            {
                ulVswr = BspGetPaVswrVal(ulTxChan,0,PA_VSWR_MODE);//获取驻波比
            }
            if((BSP_RADIO_STANDARD_LTE_TDD|BSP_RADIO_STANDARD_5G)&ulRadioMode)
            {
                ulRet |= BspGetScalarVswr(ulTxChan, &ulVswr);
            }

            if(ulVswr > BspGetNtfScalarVswrThre())
            {                
                 s_RruNtfItems[8].cErrorChan += BSP_BIT_SET(ulTxChan);
                 dbgInfo("BSP_NOTICE in Chan%d NtfGetPaVswrVal, VSWR is %d!\n",ulTxChan,ulVswr);
			     ulRet |= BSP_NOTICE;
			}
			else
			{
			     dbgInfo("BSP_OK in Chan%d NtfGetPaVswrVal!\n",ulTxChan); 
			     ulRet |= BSP_OK;
			}
			BspSignalSwitchOri(ulTxChan,ulPow,SWITCH_OFF);

		}
	}

	return ulRet;
}






/*****************************************************************************
*  函数名称   : PrintNtfInfo()
*  功能描述   : 打印当前NTF 状态信息
*  输入参数   : 无
*  输出参数   : 无
*  返 回 值   :   BSP_ERROR --执行成功
                             BSP_OK -- 执行失败
*  其它说明   :
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A),  yc     @2019-06-26 20:38:55 创建
*****************************************************************************/
UINT32 PrintNtfInfo(void)
{
    char aucResultFileName[70] = {0};
    UINT32 ulRet = BSP_OK;
    UINT32 uLoop = 0;
    TRruTestResult tTestRlt={0};
    dbgInfo("<----------NTF current Status Info.---------> \n");
    if (1 == g_testMode)
    {
        dbgInfo("    Mode : NTF mode.\n ");
    }
    else
    {
        dbgInfo("    Mode : Not NTF mode. \n");
    }
    
    if(0 == g_testType)
    {
        dbgInfo("    Trigger Type: Near. \n");
    }
    else if(1 == g_testType)
    {
        dbgInfo("    Trigger Type: Far. \n");
    }
    else
    {
        dbgInfo("    Trigger Type: Unknowable. \n");
    }
    GetResultFileName(&aucResultFileName[0],sizeof(aucResultFileName));
    dbgInfo("    NTF Result File Name(/ata/) : %s \n",&aucResultFileName[0]);

    if (BSP_OK != NtfGetDetectionResult(&tTestRlt))
    {
        dbgInfo("Get Detection Result Error.\n ");
        return BSP_ERROR;
    }
    dbgInfo("    NTF Detection Result: %x  (0:Ok.1:Alarm.2:unknowable)\n",tTestRlt.wRlt);
    dbgInfo("    Detection Alarm Info: \n");
    dbgInfo("    Alarm Num:  %d\n",tTestRlt.wCodeNum);
    ulRet = tTestRlt.wCodeNum < NTF_RECORD_MAX_NUM ? tTestRlt.wCodeNum : NTF_RECORD_MAX_NUM;
    for(uLoop = 0;uLoop < ulRet;uLoop++)
    {
        dbgInfo("    No. : %d\n",uLoop);
        dbgInfo("    Alarm Code : %d\n",tTestRlt.atCodeInfo[uLoop].dwCode);
        dbgInfo("    Alarm Para : %s\n\n",tTestRlt.atCodeInfo[uLoop].aucPara);
    }
    dbgInfo("<----------NTF current Status Info.--------->\n");
    return BSP_OK;
}

/*****************************************************************************
*  函数名称   : NtfInitDetectionResultFile()
*  功能描述   : 创建NTF原始文件
*  输入参数   : 无
*  输出参数   : 无
*  返 回 值   : BSP_ERROR --执行成功
                BSP_OK -- 执行失败
*  其它说明   :
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A),  10229672     @2019-6-22 20:38:55 创建
*****************************************************************************/
static UINT32 NtfInitDetectionResultFile(void)
{
    FILE *fp = NULL;
    char aucResultFile[MAX_FILE_PATH_LEN]={0};
    char aucResultFileTmp[MAX_FILE_PATH_LEN]={0};
    UINT32 ulRet = BSP_OK;
    INT32 ret = 0;
    INT32 fclsRet = 0;
    
    ulRet = GetResultFilePath(&aucResultFile[0],sizeof(aucResultFile));

    CHECK_RET_WARNING(ulRet, "NtfInitDetectionResultFile ret:%d", ulRet);
        /*构造文件名bak，保留上一次自检结果的原始文件*/
     //sprintf((INT8*)aucResultFileTmp,"%s.bak",aucResultFile);
	ret=snprintf_s(aucResultFileTmp,sizeof(aucResultFileTmp),"%s.bak",aucResultFile);
	SNPRINTF_S_CHECK(ret,sizeof(aucResultFileTmp));
	/*删除原来保留的历史文件*/
	ulRet = remove(aucResultFileTmp);
	if(BSP_OK != ulRet)
	{
		dbgInfo("remove Bak_File Fail in NtfInitDetectionResultFile\n");
	}
	/*重命名上一次自检结果文件为bak*/
	ulRet = rename(aucResultFile, aucResultFileTmp);
	if(BSP_OK != ulRet)
	{
		dbgInfo("rename Bak_File Fail in NtfInitDetectionResultFile\n");
	}
	/*删除上一次生成的自检结果文件*/
	ulRet = remove(aucResultFile);
	if(BSP_OK != ulRet)
	{
		dbgInfo("remove Bak_File Fail in NtfInitDetectionResultFile\n");
	}

	fp = fopen(aucResultFile, "w+b");
	if (fp == NULL)
	{
		return BSP_ERROR;
	}
    fclsRet = fclose(fp);
    if((INT32)0 != fclsRet)
    {
    	return BSP_ERROR;
    }

	BspChmod(aucResultFile,"644");
	return BSP_OK;

}

/* Started by AICoder, pid:0ae9b1cbe608d4c14ec10a748017d030dd36ed2b */
UINT32 BspGetNtfileLen(CHAR *aucResultFile, INT64 *size)
{
    FILE *pFile = NULL;
    INT64 liTmpSize = 0;

    INPUT_POINTER_CHECK(size);
    // 指定目录列表，这里仅使用根目录 "/"
    CHAR * const cDirList[1] = {"/"};
    rsize_t rDirListSize = 1;

    // 尝试打开文件
    (void)zte_fopen_s(&pFile, aucResultFile, "rb", cDirList, rDirListSize);
    if (pFile == NULL)
    {
        liTmpSize = 0;
    }
    else
    {
        // 移动文件指针到文件末尾
        (void)fseek(pFile, 0, SEEK_END);

        // 获取文件大小
        liTmpSize = ftell(pFile);
        if((liTmpSize) < ((INT64)0))
        {
            dbgErr("%s(%d) warning! > ftell ret'%lld! \n", __FUNCTION__, __LINE__, liTmpSize);
        }
        // 关闭文件
        (void)zte_fclose_s(pFile);
    }

    // 设置输出参数为文件大小
    *size = liTmpSize;

    return BSP_OK;
}
/* Ended by AICoder, pid:0ae9b1cbe608d4c14ec10a748017d030dd36ed2b */

/*****************************************************************************
*  函数名称   : NtfRecordDetectionResult()
*  功能描述   : 记录检测结果文件
*  输入参数   : 无
*  输出参数   : 无
*  返 回 值   : ulAlmType --0，成功；1，失败；2，不确定；3，打印信息；
                ulOp -- 0，继续；1-终止
                ulErrCode---错误码
                pInfo----打印信息
*  其它说明   :
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A),  10229672     @2019-10-20 20:38:55 创建
*****************************************************************************/
UINT32  NtfRecordDetectionResult (UINT32 ulAlmType,UINT32 ulOp,TCodeInfo *ptCode,const char*pcInfo,FLOAT fVswrLoc)
{
    FILE *fp = NULL;
    static UINT8 ucFlag = 0;
    char aucResultFile[MAX_FILE_PATH_LEN]={0};
    UINT32 ulRet = BSP_OK;
	INT32 fprtRet = 0;
	INT32 fclsRet = 0;
	INT64 ulFileSize = 0;

    STRCHR_CHECK(ptCode);
    STRCHR_CHECK(pcInfo);

    ulRet = GetResultFilePath(&aucResultFile[0], sizeof(aucResultFile));
    if(BSP_OK != ulRet)
    {
        dbgInfo("GetResultFilePath Fail in NtfRecordDetectionResult\n");
        return BSP_ERROR;
    }
    ulRet = BspGetNtfileLen(aucResultFile, &ulFileSize);

    if(BSP_OK != ulRet || ulFileSize > MAX_FILE_SIZE_1M)
    {
    	dbgInfo("GetResultFilePath file size get fail or size over ret %d size %lld\n",ulRet,ulFileSize);
        return BSP_OK;
    }

    fp = fopen(aucResultFile, "a+b");
    if ( fp == NULL )
    {
        return BSP_ERROR;
    }
    if(NULL != ptCode)
    {
        dbgInfo("ptCode->aucPara = %s in NtfRecordDetectionResult",ptCode->aucPara);
    }

    switch(ulAlmType)
    {
        case TEST_SUCC_TYPE:
            fprtRet = fprintf(fp,"%s\n",NTF_RESULT_SUCC);
			FPRINTF_CHECK(fprtRet);
            fprtRet = fprintf(fp,"%s\n",NTF_SEGMENT_LINE);
			FPRINTF_CHECK(fprtRet);
            break;
        case TEST_FAIL_TYPE:
            if( 0 == ucFlag )
            {
                ucFlag = 1;
                fprtRet = fprintf(fp,"%s\n",NTF_RESULT_FAIL);
				FPRINTF_CHECK(fprtRet);
            }
            if( NULL != ptCode )
            {
                fprtRet = fprintf(fp,"%d\n",ptCode->dwCode);
				FPRINTF_CHECK(fprtRet);
                fprtRet = fprintf(fp,"%s\n",ptCode->aucPara);
				FPRINTF_CHECK(fprtRet);
            }
            if( NTF_PAUSE_TEST== ulOp )
            {
                fprtRet = fprintf(fp,"%s\n",NTF_SEGMENT_LINE);
				FPRINTF_CHECK(fprtRet);
                ucFlag = 0;
            }
            break;
        case TEST_NOTICE_TYPE:
            fprtRet = fprintf(fp,"%s\n",NTF_RESULT_NOTICE);            
            FPRINTF_CHECK(fprtRet);
			fprtRet = fprintf(fp,"%s\n",NTF_SEGMENT_LINE);
            FPRINTF_CHECK(fprtRet);
			break;
        case TEST_PRINT_TYPE:
            if( NULL != pcInfo )
            {
                fprtRet = fprintf(fp,"%s",pcInfo);
				FPRINTF_CHECK(fprtRet);
            }
            break;
        case TEST_NOTICE_INFO_TYPE:            
            fprtRet = fprintf(fp,"%.2fm",fVswrLoc);
			FPRINTF_CHECK(fprtRet);
            break;
        default:
            break;
    }
    fclsRet = fclose(fp);
	FCLOSE_CHECK(fclsRet);
    return BSP_OK;
}
/*****************************************************************************
*  函数名称   : NtfResultMap()
*  功能描述   : 结果映射
*  输入参数   : 无
*  输出参数   : 无
*  返 回 值   : pInfo--结果
                ucLen -- 字符长度
*  其它说明   :
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A),  10229672     @2019-06-20 20:38:55 创建
*****************************************************************************/
static UINT32  NtfResultMap( INT8 *pInfo, UINT8 ucLen )
{
    INT8 buf[MAX_FILE_PATH_LEN]={0};
    UINT32 ulLen = 0;

    if( NULL == pInfo || ucLen>MAX_FILE_PATH_LEN)
    {
        return BSP_ERROR;
    }
    memcpy_s( buf, ucLen, pInfo, ucLen );

    ulLen = sizeof(NTF_RESULT_SUCC);
    dbgInfoEx("%s: ulLen: %d\n", __FUNCTION__, ulLen);
    if( 0 == memcmp(NTF_RESULT_SUCC,buf,(sizeof(NTF_RESULT_SUCC)-1) ) )
    {
        dbgInfoEx("%s\n",NTF_RESULT_SUCC);
        return TEST_SUCC_TYPE;
    }
    else if( 0 == memcmp(NTF_RESULT_FAIL,buf,(sizeof(NTF_RESULT_FAIL)-1) ))
    {
        dbgInfoEx("%s\n",NTF_RESULT_FAIL);
        return TEST_FAIL_TYPE;
    }
    else if( 0 == memcmp(NTF_RESULT_NOTICE,buf,(sizeof(NTF_RESULT_NOTICE)-1) ))
    {
        dbgInfoEx("%s\n",NTF_RESULT_NOTICE);
        return TEST_NOTICE_TYPE;
    }

    return BSP_ERROR;
}
/*****************************************************************************
*  函数名称   : NtfGetDetectionResult()
*  功能描述   : 获取
*  输入参数   : 无
*  输出参数   : 无
*  返 回 值   : ptTestRlt--结果
*  其它说明   :
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A),  10229672     @2019-06-26 20:38:55 创建
*****************************************************************************/
UINT32 NtfGetDetectionResult (TRruTestResult *ptTestRlt)
{
    FILE *fp = NULL;
    /* UINT32 ulCnt = 0; */
    UINT32 ulRetVal = BSP_OK;
    UINT32 ulRet = BSP_ERROR;
    INT32 ulTemp0 = 0;
    INT32 ulTemp1=0;
	INT32 fret = 0;
    char arr[MAX_FILE_PATH_LEN]={0};
    const char* s="rru hardware fault";
    char aucResultFile[MAX_FILE_PATH_LEN]={0};
    if( NULL == ptTestRlt )
    {
        return BSP_ERROR;
    }

    GetResultFilePath(&aucResultFile[0], sizeof(aucResultFile));
    fp = fopen(aucResultFile, "r");
    if (fp == NULL)
    {
        return BSP_ERROR;
    }

	if(EOF == fscanf_s(fp,"TestMode=%d,TestType=%d",&ulTemp0,&ulTemp1))
	{
       dbgErr("%s: fscanf_s fail!\n", __FUNCTION__);
	}
    memset_s(arr,sizeof(arr),0,sizeof(arr));
    while ((fgets (arr, MAX_FILE_PATH_LEN, fp)) != NULL)
    {
        if( 0 == memcmp(arr,"\n",1) )
        {
            continue;
        }    
        ulRet = NtfResultMap((INT8*)arr,MAX_FILE_PATH_LEN);
        if( TEST_FAIL_TYPE == ulRet )
        {        
            ptTestRlt->wRlt = ulRet;
			ptTestRlt->wCodeNum = 1;
            ptTestRlt->atCodeInfo[0].dwCode = 30001;
			memcpy_s(ptTestRlt->atCodeInfo[0].aucPara,(strnlen_s(s,100)+1),s,(strnlen_s(s,100)+1));
            break;
        }  
        else
        {
            ptTestRlt->wRlt = TEST_SUCC_TYPE;
        }
    }

    fret = fclose(fp);
	FCLOSE_CHECK(fret);
	
    return ulRetVal;
}

void rrutest(void)
{   
    /********
        自检测试函数
        ***********/        
    TDetectReqInfo atReqInfo = {0};
    atReqInfo.wTestType  = 0;/*0代表光纤触发,近端，两种触发模式,后台网管和光纤自环*/
    
    dbgInfo(" far det start...\n");
    BspInnerTestStart(&atReqInfo);
}

/*****************************************************************************
*  函数名称: BspGetLastTestInfo()
*  功能描述: 获取自检状态信息
*  输入参数: ptTestInfo -- 自检状态结构体
*  输出参数: 无
*  返 回 值: BSP_OK, 其它值为失败
*  其它说明: 给DTM 调用
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A),  10229672     @2019-06-11 20:38:55 创建
*****************************************************************************/
UINT32 BspGetLastTestInfo(TRruSelfTestInfo *ptTestInfo)
{
    UINT32 ret=BSP_OK;

    if(NULL == ptTestInfo)
    {
        return BSP_ERROR_NULL_POINTER;/*指针判空*/
    }
    ret = BspGetTestMode(&g_testMode, &g_testType);
    ptTestInfo->ucSelfTestTag =g_testMode;
    ptTestInfo->ucSelfTestType =g_testType;
    return ret;
}


static UINT32 NtfTxFreqBandFlatCheck(UINT32 chan, UINT32 freq, UINT32 ulPow)
{
    UINT32 ulRet = BSP_OK;
    UINT32 threshold = 0;
    INT32  openLoopPow = 0;
    INT32  closeLoopPow = 0;
    UINT32 ulRadioMode = 0;
    T_RfCfgPara *pRfCfg = NULL;

    if(BSP_OK != BspCheckTxChannel(chan))
    {
        dbgErr("[%s]Para Error.\n",__FUNCTION__);
        return BSP_ERROR;
    }

    pRfCfg = BspGetRfCfgPara(chan, TX);
    if(NULL == pRfCfg)
    {
        dbgErr("[%s] chan %d pRfCfgPara in NULL \n",__FUNCTION__, chan);
        return BSP_ERROR;
    }
    
    threshold = BspGetTssiFwdDiffThreshold();
    ulRet |= NtfGetPreAnalyseCarrRadioMode(chan, &ulRadioMode);
    if((BSP_RADIO_STANDARD_LTE_FDD|BSP_RADIO_STANDARD_FDD_5G)&ulRadioMode)
    {
        threshold = 500;
        dbgInfo("FDD Chan%d Threshold is %d!\n", chan,threshold);   
    }

    pRfCfg->carrInfo[0].freq = freq;
    ulRet |= BspSetTxRfCfg(chan, pRfCfg);
    ulRet |= BspSignalSwitchOri(chan, ulPow, SWITCH_ON);
    ulRet |= BspTxOpenLoopPowCail(chan);
    BspSysMsDelay(10000);
    ulRet |= BspGetFwdCpIfTssi(chan, 0, &openLoopPow);

    ulRet |= BspSetTxGain(chan, g_lAttVal[chan]);
    BspSysMsDelay(10000);
    ulRet |= BspGetFwdCpIfTssi(chan, 0, &closeLoopPow);

    if(abs(openLoopPow - closeLoopPow) > threshold)
    {
        s_RruNtfItems[7].cErrorChan |= BSP_BIT_SET(chan);
        dbgInfo("--%s--:Chan%d FlatNess Check Abnormal, Freq %d, Set Fwd is %d, Get Fwd is %d, Threshold is %d!\n",
                __FUNCTION__, chan, freq, openLoopPow, closeLoopPow, threshold);
        ulRet = BSP_ERROR;
    }
    else
    {
        dbgInfo("--%s--:Chan%d FlatNess Check Normal, Freq %d, Set Fwd is %d, Get Fwd is %d, Threshold is %d!\n",
                __FUNCTION__, chan, freq, openLoopPow, closeLoopPow, threshold);
    }
    ulRet |= BspSignalSwitchOri(chan, 0, SWITCH_OFF);

    return ulRet;
}

/* Started by AICoder, pid:ofd15i3d9bh64da14d0c0808d0b9621fb6c6b58f */
UINT32 BspSetRruNtfItems(UINT32 item, UINT32 flag, UINT32 ret, UINT32 errChan)
{
    if(item > 9)
    {
        return BSP_ERROR;
    }
    s_RruNtfItems[item].ulRunFlag = flag;
    s_RruNtfItems[item].ulFuncRet = ret;
    s_RruNtfItems[item].cErrorChan = errChan;
    return BSP_OK;
}
/* Ended by AICoder, pid:ofd15i3d9bh64da14d0c0808d0b9621fb6c6b58f */

/* Started by AICoder, pid:6afe4ye3d477f96145ba0a513004102d50e3fe3f */
UINT32 BspSetChanVswrAverage(UINT32 chan, FLOAT val)
{
    if(chan >= BSP_MAX_TX_CHAN)
    {
        dbgErr("[%s]:Chan is %d, out bounds error!\n",__FUNCTION__,chan);
        return BSP_ERROR;
    }

    vswrAv[chan] = val;
    return BSP_OK;
}

UINT32 BspSetChanGammaPhaseDiff(UINT32 chan, FLOAT val)
{
    if(chan >= BSP_MAX_TX_CHAN)
    {
        dbgErr("[%s]:Chan is %d, out bounds error!\n",__FUNCTION__,chan);
        return BSP_ERROR;
    }

    s_gammaPhaseDiff[chan] = val;
    return BSP_OK;
}
/* Ended by AICoder, pid:6afe4ye3d477f96145ba0a513004102d50e3fe3f */

/*****************************************************************************
*  函数名称   : BspGetNtfItemResult()
*  功能描述   : 获取自检结果信息,打桩
*  输入参数   : ptTestRlt -- 自检结果信息
*  输出参数   : 无
*  返 回 值   : BSP_OK, 其它值为失败
*  其它说明   : 自检完结果上报给APP调用
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A),  yc     @2019-09-11 20:38:55 创建
*****************************************************************************/
UINT32 BspGetNtfItemResult(T_RruNtfResult *ptRruNtfResultPara)
{
    INPUT_POINTER_CHECK(ptRruNtfResultPara);
    return BSP_OK;
}

/*****************************************************************************
*  函数名称   : BspSetRruNtfResult()
*  功能描述   : 自检结果汇总成检测结果文件,打桩
*  输入参数   : ptTestRlt -- 自检结果信息
*  输出参数   : 无
*  返 回 值   : BSP_OK, 其它值为失败
*  其它说明   : 自检完结果上报给APP调用
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A),  yc     @2019-09-11 20:38:55 创建
*****************************************************************************/
UINT32 BspSetRruNtfResult(T_RruNtfResult *ptRruNtfResultPara)
{
    INPUT_POINTER_CHECK(ptRruNtfResultPara);
    return BSP_OK;
}

VOID bspHwTestInit(VOID)
{
    return;
}

UINT32 bspHwTest(UINT32 type, UINT32 chnmask, UINT32 *result)
{
    UINT32 txChnNum  = BspGetTxChannel();
    UINT32 ulChan = 0;
    UINT32 retVal = BSP_OK;

    INPUT_POINTER_CHECK(result);
    for(ulChan = 0; ulChan < txChnNum; ulChan++)
    {
        BspSetPowEnable(ulChan, SWITCH_ON);
        BspSetLnaSwitch(ulChan, SWITCH_OFF);
        BspSetRxSwitch(ulChan, SWITCH_OFF);
    }
    BspSetClkAlmMask(1);
    g_testType = 1;/* 配置远端 */
    s_chanMask = chnmask;
    switch(type)
    {
       case 1:// 下行模拟链路增益
           retVal = NtfTxPowerCheck();
           *result = retVal;
           return retVal;
       case 2:// PA异常测试
           return retVal;
       case 3://发射ATT线性度测试
           return retVal;
       case 6://干扰底噪检测
           retVal = NtfRxPowerCheck();
           *result = retVal;
           return retVal;
       default:
           dbgInfo("Test No'%d is not suported!",type);
           break;
    }
    return BSP_OK;
}

UINT32 BspHwTestGetResult(UINT32 type, UINT32 chnmask)
{
    UINT32 result = BSP_OK;

    bspHwTest(type, chnmask, &result);
    dbgInfo("result = %d\n",result);
    return BSP_OK;
}

VOID bspHwTestPost(VOID)
{
    return;
}

/* Started by AICoder, pid:pce2b55ad1kd197145af08b5a0fb64216820c242 */
UINT32 BspSetTsgSelfTestInfo(void)
{
    T_TsgSelfTestInfo info = {0};
    UINT32 retVal = BSP_OK;

    info.uiTsgSelfTestFlag = 1;
    retVal = BspHalAdaptSetTsgSelfTestInfo(&info);
    return retVal;
}
/* Ended by AICoder, pid:pce2b55ad1kd197145af08b5a0fb64216820c242 */

/* Started by AICoder, pid:z4538s57ffif01d14ed80801d0f8f7140dd97ef3 */
//打桩制造异常
VOID setPaError(UINT32 star, UINT32 end, UINT32 isAtt)
{
    if(7 < end)
    {
        dbgErr("Chan Num is Error!\n");
        return;
    }
    if(0 == isAtt)
    {
        for (int idx = star; idx <= end; idx++)
        {
            offPa[idx] = 0;
        }
    }
}

//打桩制造异常
VOID setPaOk(UINT32 star, UINT32 end, UINT32 isAtt)
{
    if(7 < end)
    {
        dbgErr("Chan Num is Error!\n");
        return;
    }
    if(0 == isAtt)
    {
        for (int idx = star; idx <= end; idx++)
        {
            offPa[idx] = 1;
        }
    }
}

//打桩制造异常
VOID setLnaError(UINT32 star, UINT32 end)
{
    if(7 < end)
    {
        dbgErr("Chan Num is Error!\n");
        return;
    }
    for (int idx = star; idx <= end; idx++)
    {
        offLna[idx] = 0;
    }
}

//打桩制造异常
VOID setLnaOk(UINT32 star, UINT32 end)
{
    if(7 < end)
    {
        dbgErr("Chan Num is Error!\n");
        return;
    }
    for (int idx = star; idx <= end; idx++)
    {
        offLna[idx] = 1;
    }
}
/* Ended by AICoder, pid:z4538s57ffif01d14ed80801d0f8f7140dd97ef3 */

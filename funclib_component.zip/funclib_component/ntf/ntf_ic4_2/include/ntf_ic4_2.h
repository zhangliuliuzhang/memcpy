/*****************************************************************************
 * 版权所有(C) 2010, ZTE Corp. RRU Bsp Platform
 *----------------------------------------------------------------------------
 * 模 块 名 : BSP
 * 文件名称 : ntf_ic4_2.h
 * 文件标识 : {[N/A]}
 * 内容摘要 : ntf_ic4_2 自检功能头文件
 * 注意事项 : 
 * 创建日期 : 2012-09-23 14:44:07
 * 当前版本 : Ver1.0
 *----------------------------------------------------------------------------
 * 变更记录 :
  *----------------------------------------------------------------------------
 */
#ifndef _NTF_IC4_2_H_
#define _NTF_IC4_2_H_
     
#ifdef __cplusplus
     extern "C" {
#endif


//硬件自检高层发源时，需要设置的接收带宽
#define NTF_TSG_LTE_BAND_TYPE_1M4     1400
#define NTF_TSG_LTE_BAND_TYPE_3M      3000
#define NTF_TSG_LTE_BAND_TYPE_5M      5000
#define NTF_TSG_LTE_BAND_TYPE_10M     10000
#define NTF_TSG_LTE_BAND_TYPE_15M     15000
#define NTF_TSG_LTE_BAND_TYPE_20M     20000

/*判断准则*/

#define TDD_LTE_RSSI_BW_20M_THRESHOLD  	(-10350)
#define FDD_LTE_RSSI_BW_20M_THRESHOLD  	(-10450)
/*自检项执行标志*/
#define NTF_ITEM_RUN                  (0) /*已执行完毕*/
#define NTF_ITEM_WAIT                 (1) /*待执行*/
#define BSP_NOTICE                    (0x100)

/*驻波比位置检测*/
#define VSWR_MAX_TEST_POINT           (1000)
#define OUTSIDE_VSWR_TEST_POINT       (-1)
#define UNCERTAIN_VSWR_TEST_POINT     (-4)
#define INSIDE_VSWR_TEST_POINT        (-2)

/*返回结果类型*/
#define TEST_SUCC_TYPE                (0)
#define TEST_FAIL_TYPE                (1)
#define TEST_NOTICE_TYPE              (2)
#define TEST_PRINT_TYPE               (3)
#define TEST_NOTICE_INFO_TYPE         (4)

typedef struct
{
    FLOAT real;
    FLOAT image;
}TComplex;

typedef UINT32 (*funcSetFixLoFreqCallBack)(UINT32 chan, UINT32 loFreq);

UINT32 BspInnerTestStart(TDetectReqInfo *ptReqInfo);
UINT32 BspGetLastTestInfo(TRruSelfTestInfo *ptTestInfo);
UINT32 BspGetInnerTestResult(TRruTestResult *ptTestRlt);
UINT32 BspStopOptAdapt(UINT32 ulCtrl);
UINT32 NtfRecordResult(UINT32 ulLoop);
UINT32 BspSetRruNtfItems(UINT32 item, UINT32 flag, UINT32 ret, UINT32 errChan);
UINT32 NtfRecordDetectionResult(UINT32 ulAlmType,UINT32 ulOp,TCodeInfo *ptCode,const char*pcInfo,FLOAT fVswrLoc);
INT32 BspVswrPosCheck(UINT32 chan, UINT32 lowerFreq, UINT32 upperFreq, UINT32 FreqStep);
UINT32 BspCollectVswrData_Tdd(UINT32 chan, INT32 *phaseDiff);
INT32 BspJudgeVswrPos(UINT32 chan, UINT32 count, INT32 phaseDiff);
UINT32 NtfGetPreAnalyseCarrRadioMode(UINT32 bspChan, UINT32 *radioMode);
void rrutest(void);
UINT32 BspSetAdcStatusMask(UINT32 mask);
UINT32 NtfGetThresholdByLoop(UINT32 ulLoop);
VOID BspSetPowEnable(UINT32 chan, UINT32 sw);
UINT32 PrintNtfInfo(void);
UINT32 BspGetLastTestInfo(TRruSelfTestInfo *ptTestInfo);
INT32 BspCalcVswrStatistic(INT32 chan, INT32 band, UINT32 count, FLOAT * pAverage);
UINT32 BspGetNtfileLen(CHAR *aucResultFile, INT64 *size);
INT32 BspCalcPhaseDiff(TComplex *pComplex, UINT32 count, FLOAT *average, FLOAT *minimum);
UINT32 BspGetDefaultAtt(UINT32 ulChan, UINT32 SigPow, INT32 *lAttVal);
INT32 BspCalcVswrStatistic(INT32 chan, INT32 band, UINT32 count, FLOAT * pAverage);
UINT32 BspSignalSwitchOri(UINT32 ulChan,UINT32 ulCarrPow,UINT32 ulSwitch);
UINT32 BspRecordVswrLocation(void);
UINT32 BspSetChanVswrAverage(UINT32 chan, FLOAT val);
UINT32 BspSetChanGammaPhaseDiff(UINT32 chan, FLOAT val);
void NtfLedRunFuntion(void);
UINT32 NtfGetDetectionResult (TRruTestResult *ptTestRlt);
UINT32 BspTxFullPowerCheck(VOID);
UINT32 NtfCheckPwr(void);
UINT32 NtfCheckTxDac(void);
UINT32 NtfCheckRxAdc(void);
UINT32 NtfCheckPrxAdc(void);
UINT32 NtfCheckPll(void);
UINT32 BspGetDpdicToMts204Status(UINT32 chipId, UINT32 mask, UINT32* pstatus);
VOID bspHwTestInit(VOID);
VOID bspHwTestPost(VOID);
UINT32 bspHwTest(UINT32 type, UINT32 chnmask, UINT32* result);
UINT32 BspHwTestGetResult(UINT32 type, UINT32 chnmask);
UINT32 NtfTxPowerCheck(VOID);
UINT32 NtfRxPowerCheck(VOID);
void BspSetChanMask(UINT32 mask);
void BspSetTestType(UINT32 type);
UINT32 BspGetChnNtfState(UINT32 bspChn);
VOID setPaError(UINT32 star, UINT32 end, UINT32 isAtt);
VOID setPaOk(UINT32 star, UINT32 end, UINT32 isAtt);
VOID setLnaError(UINT32 star, UINT32 end);
VOID setLnaOk(UINT32 star, UINT32 end);
UINT32 BspTxReducePowerCheck(VOID);
UINT32 BspNtfGetDefaultAtt(VOID);
UINT32 NtfVswrCheck(UINT32 flag);
DOUBLE BspGetVswrThreByBandWidth(UINT32 width);
#ifdef __cplusplus
}
#endif

#endif  /* _NTF_IC4_2_H_ */


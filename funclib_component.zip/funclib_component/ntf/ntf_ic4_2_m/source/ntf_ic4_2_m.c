/*****************************************************************************
* 版权所有(C) 2017, ZTE Corp. ZXSDR-RRU Platform BSP
*----------------------------------------------------------------------------
* 模 块 名 : BSP
* 文件名称 : ntf_ic4_2_m.c
* 文件标识 : {[N/A]}
* 内容摘要 :
* 注意事项 : 无
* 作    者 : 10102065
* 创建日期 : 2017-2-27 14:45:34
* 当前版本 : Ver1.0
*----------------------------------------------------------------------------
* 变更记录 :
* $记录1
* 变 更 单: $0000000(N/A)
* 责 任 人: 10102065
* 修改日戳: 2017-2-27 14:45:34
* 变更说明: 创建文件

*----------------------------------------------------------------------------
*/
#include "bsppub.h"
#include "zprintf.h"
#include "bsperrcode.h"
#include "vxadp.h"
#include "ntf_ic4_2_m.h"
#include "ru_basedef.h"
#include "ntfcommon.h"
#include "resource_alloc_api.h"
#include "optctrl_cpri_ic4_2.h"
#include "sfp.h"
#include "ichaladapt_ic4_2.h"
#include "cpri_reg.h"
#include "lo_common.h"
#include "rruinfo.h"
//#include "functionwrapper.h"
#include "funccommon_a.h"
#include "optadpt.h"

#ifndef SWITCH_OFF
#define SWITCH_OFF                      0
#endif

#ifndef SWITCH_ON
#define SWITCH_ON                       1
#endif

/***************************自检结果告警码*********************************/
/*测试结果告警码*/
#define BSP_NTF_FINAL_RESULT_OK             ((UINT32)0)
#define BSP_NTF_FINAL_RESULT_ERROR          ((UINT32)30001)

/*定义的自检结果文件字符长度*/
#define MAX_FILE_PATH_LEN             (80)
#define MAX_FILE_NAME_LEN             (70)
#define MAX_ITEM_NAME                 (25)
#define NTF_RAW_FILE_DIR              "/ata/"
#define MAX_FILE_SIZE_1M               1048576 //1024*1024 = 1M

/*检测项属性 : 是否继续执行*/
#define NTF_CONTINUE_TEST             (0)
#define NTF_PAUSE_TEST                (1)

#define NTF_SEGMENT_LINE              "QQQQQQQQ" /*分隔符，区分上报数据和本地数据*/
#define NTF_RESULT_SUCC               "Succ"
#define NTF_RESULT_FAIL               "Fail"
#define NTF_RESULT_NOTICE             "Notice"

#define NTF_RECORD_MAX_NUM            (5)  /*能记录的最大故障数*/

#define NTF_SKIP_ITEM(itemType)                         \
({  \
    if((itemType == E_NTF_FPGA_CHECK) || (itemType == E_NTF_CIRCULATOR_CHECK) || (itemType == E_NTF_TX_ATT_CHECK)) \
    { \
        continue;\
    } \
})

static UINT32 NtfCheckPwr(void);
static UINT32 NtfCheckPll(void);
static UINT32 NtfGetOptStatus(void);
UINT32 BspSetTestMode(UINT8 ucTestMode,UINT8 ucTestType,UINT8 ucFlag);
UINT32 NtfGetDetectionResult (TRruTestResult *ptTestRlt);

static PwrVoltThreshold s_pwr48vVoltThreshold = {35000, 55000};
static T_RruNtfItems s_RruNtfItems[]=
{
    /*电源异常检查*/
    {"PWR CHECK        ",   NtfCheckPwr,       BSP_OK,    NTF_ITEM_WAIT,    0,  E_NTF_PWR_CHECK, NTF_CONTINUE_TEST},
    /*光口状态诊断*/
    {"OPT STATUS CHECK ",   NtfGetOptStatus,   BSP_OK,    NTF_ITEM_WAIT,    0,  E_NTF_OPT_STATUS_CHECK, NTF_CONTINUE_TEST},
};

typedef struct tagNtfItemInfo
{
    UINT32 type;       // 检测类型
    const char *pItemName;          /*检测项名称，如FPGA加载*/
}T_NtfItemInfo;


T_NtfItemInfo g_ntfItemInfo[E_NTF_CHECK_MAX_NUM] =
{//  Item                     检测项名称
    {E_NTF_PWR_CHECK,         "PWR CHECK        "},
    {E_NTF_PLL_CHECK,         "RF PLL CHECK     "},
    {E_NTF_OPT_STATUS_CHECK,  "OPT STATUS CHECK "},
    {E_NTF_TX_DAC_CHECK,      "TX DAC CHECK     "},
    {E_NTF_RX_ADC_CHECK,      "RX ADC CHECK     "},
    {E_NTF_PRX_ADC_CHECK,     "PRX ADC CHECK    "},
    {E_NTF_FPGA_CHECK,        "FPGA CHECK       "},
    {E_NTF_TX_FWD_CHECK,      "TX FWD CHECK     "},
    {E_NTF_TX_ATT_CHECK,      "TX ATT CHECK     "},
    {E_NTF_TX_FLATNESS_CHECK, "TX FLATNESS CHECK"},
    {E_NTF_VSWR_CHECK,        "VSWR CHECK       "},
    {E_NTF_CIRCULATOR_CHECK,  "CIRCULATOR CHECK " },
    {E_NTF_RSSI_CHECK,        "RSSI CHECK       "},
};

UINT8  g_testType = 0;
UINT8  g_testMode = 0;
T_NtfAvoidItem g_ntfAvoidItem[E_NTF_CHECK_MAX_NUM] = {0};
UINT32 g_ntftestType = NTF_NEAR_DETECTION;
UINT32 g_NtfCheckNewSolution = BSP_NTF_OLD_SOLUTION;

/*****************************************************************************
*  函数名称   : NtfCheckPwr()
*  功能描述   : 电源自检需要分别对输入电压和单板上电源模块的输出电压进行异常检查
*  输入参数   : 无
*  输出参数   : 无
*  返 回 值   : 返回值
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A)
*----------------------------------------------------------------------------*/
static UINT32 NtfCheckPwr(void)
{
    UINT32 status = 0;
    UINT32 retVal = BSP_OK;
    UINT32 volt   = 0;

    NTF_CHK_ITEM(E_NTF_PWR_CHECK, TX);
    status = BspGetPowerStatus();

    if(status & (BSP_POWER_48V_LOW_ALARM|BSP_POWER_48V_HIGH_ALARM))/*bit0 1 分别代表输入欠压、过压*/
    {
        dbgInfo("PWR INPUT VOLT ALARM in NtfCheckPwr!\n");
        retVal = BSP_NOTICE;
    }

    volt = BspGetPaVolt(0);
    if((volt > s_pwr48vVoltThreshold.voltUpThreshold) || (volt < s_pwr48vVoltThreshold.voltLowThreshold))
    {
        dbgInfo("BSP_ERROR in NtfCheckPwr!\n");
        retVal = BSP_ERROR;
    }

    return retVal;
}

/*****************************************************************************
*  函数名称   : NtfGetOptStatus(*)
*  功能描述   : 诊断RRU光口状态是否正常
*  输入参数   : PhyOpticNo  RRU物理光口号
*              OpticRxPowThreshold 光接收功率异常判断门限
               OpticTxPowThreshold 光发送功率异常判断门限
*  输出参数   : 无
*  返 回 值   : 返回值
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A)
*----------------------------------------------------------------------------*/
static UINT32 NtfGetOptStatus(void)
{
    UINT32 retVal = BSP_OK;
    UINT32 upOpt = 0;
    T_RruSfpInfo tSfpInfo = {0};

    NTF_CHK_ITEM(E_NTF_OPT_STATUS_CHECK, TX);
    if(BspGetOptSelfTestStatus(0) == 1)/*光纤自环状态下*/
    {
        dbgInfo("NO CHECK in NtfCheckOpt, in Opt Selftest Status!\n");
        return BSP_OK;
    }

    upOpt = BspGetPhyNoBySfpNo(0);
    retVal = BspGetOptStatus(upOpt);
    /*检测光模块是否在位 bit0*/
    if(retVal & 0x01)
    {
        dbgInfo("Opt%d Is Not Exist!\n",upOpt);
        dbgInfo("BSP_NOTICE in NtfCheckOpt!\n");
        return BSP_NOTICE;
    }
    if(BSP_OK == BspGetSfpInfo(upOpt,&tSfpInfo))
    {
        if((UINT32)0 != BspGetOptSignalRateAlarm(upOpt))
        {
            dbgInfo("Cfg OptSpeed Abnormal,Abnormal Status is %d!\n",BspGetOptSignalRateAlarm(upOpt));
            dbgInfo("BSP_NOTICE in NtfCheckOpt!\n");
            return BSP_NOTICE;
        }

        if((10*log10((FLOAT)(tSfpInfo.tSfpDigiDiagInfo.ulRxPower))-40) < (-12))
        {
            dbgInfo("Rx Power Abnormal, Please Replace Optical module or Check Optical fiber!\n");
            dbgInfo("BSP_NOTICE in NtfCheckOpt!\n");
            return BSP_NOTICE;
        }

        if((10*log10((FLOAT)(tSfpInfo.tSfpDigiDiagInfo.ulTxPower))-40) < (-9))
        {
            dbgInfo("Tx Power Abnormal, Please Replace Optical module or Check Optical fiber!\n");
            dbgInfo("BSP_NOTICE in NtfCheckOpt!\n");
            return BSP_NOTICE;
        }
    }

    dbgInfo("BSP_OK in NtfCheckOpt!\n");
    return BSP_OK;
}

UINT32 BspNtfMainChipSelfCheck(NtfSelfTestResult *result, UINT32 strLen)
{
    UINT32 retVal = BSP_OK;
    INT32 buffWriteLen = 0;
    INT32 returnLen = 0;
    const char *resultStr = NULL;
    time_t timeStart = 0;
    time_t timeEnd = 0;
    UINT32 loop = 0;
    UINT32 itemNum = sizeof(s_RruNtfItems)/sizeof(T_RruNtfItems);

    INPUT_POINTER_CHECK(result);
    returnLen = snprintf_s(result->hwInfo + buffWriteLen, strLen - buffWriteLen,"Main Chip NTF Items Info:\n");
    SNPRINTFS_RETTURN_CHECK(returnLen, strLen, buffWriteLen);
    buffWriteLen += returnLen;

    for(loop = 0; loop < itemNum; loop++)
    {
        if(s_RruNtfItems[loop].runFlag == 0)
        {
            dbgInfo("\n-------------begin %s-------------\n", s_RruNtfItems[loop].pItemName);
            timeStart = time(NULL);
            if(timeStart == -1)
            {
                dbgInfo("get time error !\n");
            }
            retVal = s_RruNtfItems[loop].RruNtfItemFunc();
            resultStr = BspGetNtfCheckResult(retVal);
            INPUT_POINTER_CHECK(resultStr);
            returnLen = snprintf_s(result->hwInfo + buffWriteLen, strLen - buffWriteLen,"%s: %s\n",s_RruNtfItems[loop].pItemName,resultStr);
            SNPRINTFS_RETTURN_CHECK(returnLen, strLen, buffWriteLen);
            buffWriteLen += returnLen;
            result->ledResult = retVal;
        }
        timeEnd = time(NULL);
        if(timeEnd == -1)
        {
            dbgInfo("get time error !\n");
        }
        dbgInfo("\n-------------end %s----return %d, run time %ld seconds\n", s_RruNtfItems[loop].pItemName, retVal, timeEnd - timeStart);
    }

    return BSP_OK;
}

UINT32 BspNtfMainChipCheck(NtfSelfTestResult *result, UINT32 strLen)
{
    char file[100] = "DiagOneItem.txt";
    INT32  ret = 0;

    INPUT_POINTER_CHECK(result);

    ret = BspSystem("rm -f report.txt");
    CHECK_RET_WARNING(ret, "rm failed, ret:%d", ret);

    BspSaveStdout2File(file);
    BspNtfMainChipSelfCheck(result, strLen);
    BspRestoreStdOut();

    ret = BspSystem("cat DiagOneItem.txt");
    CHECK_RET_WARNING(ret, "cat failed, ret:%d", ret);
    ret = BspSystem("cat DiagOneItem.txt >> report.txt");
    CHECK_RET_WARNING(ret, "redirection failed, ret:%d", ret);
    ret = BspSystem("rm -f DiagOneItem.txt");
    CHECK_RET_WARNING(ret, "rm failed, ret:%d", ret);

    return BSP_OK;
}

void BspSetNtfMainChipCheckFlag(UINT32 item, UINT32 flag)
{
    if(item >= E_MAX_MAIN_NTF_ITEMS)
    {
        dbgInfo("item %d is over max %d!\n", item, E_MAX_MAIN_NTF_ITEMS);
        return ;
    }
    s_RruNtfItems[item].runFlag = flag;
    return ;
}

UINT32 BspSetNtfSolutionCfg(UINT32 solution)
{
    g_NtfCheckNewSolution = solution;
    return BSP_OK;
}

UINT32 BspGetNtfSolutionCfg(VOID)
{
    return g_NtfCheckNewSolution;
}

UINT32 BspStopOptAdapt(UINT32 ulCtrl)
{
    if(ulCtrl == 1)
    {
        optadptoff();/*关自适应*/
    }
    else
    {
        optadpton();/*开自适应*/
    }
    return BSP_OK;
}

/**********************************************************************
* 函数名称： BspDiagInit
* 功能描述： diagnose init
* 输入参数：
* 输出参数： 无
* 返 回 值： 无
* 其它说明：
* 修改日期        版本号     修改人         修改内容
***********************************************************************
*  $0000000(N/A), ZKH@2014-11
*---------------------------------------------------------------------*/
static UINT32 BspDiagInit(VOID)
{
   UINT32 ulChan = 0;
   UINT32 paVolt = 0;
   UINT32 txChnNum  = BspGetTxChannel();
    /* reset dpd */
   for (ulChan = 0; ulChan < txChnNum; ulChan++)
   {
       BspGetPaDefaultVolt(ulChan,&paVolt);
       if (0 == paVolt)
       {
           paVolt = 48000;
       }
       dbgInfo("[%s] ulChan%u, paVolt%u\n", __FUNCTION__, ulChan, paVolt);
       BspSetPaVolt(ulChan, (INT32)paVolt);
//       BspInitDpd(ulChan,0);
   }
   return BSP_OK;
}

/*****************************************************************************
*  函数名称   : BspDetectOneItem
*  功能描述   : 进行某一项自检
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : 无
*  输出参数   : 无
*  返 回 值   : 返回值
*  其它说明   :
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A), 10229672  2017.8.2 创建
*----------------------------------------------------------------------------
*/
static UINT32 BspDetectOneItem(UINT32 ulLoop)
{
    UINT32 ulRet = BSP_OK;
    UINT32 (*pfItemFunc)() = NULL;
    char file[100] = "DiagOneItem_m.txt";
    time_t ulTime = 0;
    time_t ulTime1 = 0;
    INT32  ret = 0;

    dbgInfo("\n-------------begin %s save file-------------\n", s_RruNtfItems[ulLoop].pItemName);
    BspSaveStdout2File(file);
    ulTime = time(NULL);
    if(ulTime == -1)
    {
        dbgInfo("get time error !\n");
    }

    dbgInfo("\n-------------begin %s-------------\n", s_RruNtfItems[ulLoop].pItemName);
    BspLog(LOG_LEVEL_0,"-------------begin %s-------------\n", s_RruNtfItems[ulLoop].pItemName);
    pfItemFunc = s_RruNtfItems[ulLoop].RruNtfItemFunc;
    ulRet = pfItemFunc();

    ulTime1 = time(NULL);
    if(ulTime1 == -1)
    {
        dbgInfo("get time error !\n");
    }
    dbgInfo("\n-------------end %s----return %d, run time %ld seconds\n", s_RruNtfItems[ulLoop].pItemName, ulRet, ulTime1 - ulTime);
    BspLog(LOG_LEVEL_0,"-------------end %s----return %d, run time %d seconds\n", s_RruNtfItems[ulLoop].pItemName, ulRet, ulTime1 - ulTime);
    BspRestoreStdOut();

    ret = BspSystem("cat DiagOneItem_m.txt");
    CHECK_RET_WARNING(ret, "cat failed, ret:%d", ret);
    ret = BspSystem("cat DiagOneItem_m.txt >> report_m.txt");
    CHECK_RET_WARNING(ret, "redirection failed, ret:%d", ret);
    ret = BspSystem("rm -f DiagOneItem_m.txt");
    CHECK_RET_WARNING(ret, "rm failed, ret:%d", ret);
    return ulRet;
}

/*****************************************************************************
*  函数名称   : DetectRruItems(*)
*  功能描述   : 开始自检项检测
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : 无
*  输出参数   : 无
*  返 回 值   : 返回值
*  其它说明   :
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A), 尧小安@2019-10-10 13:26:17 移植到TRMB24 单板
*----------------------------------------------------------------------------
*/
static UINT32 DetectRruItems(VOID)
{
    UINT32 ulRet = BSP_OK;
//    UINT32 ulFinalRet = BSP_OK;
    UINT32 ret = BSP_OK;
    UINT32 ulItemNum = 0;
    UINT32 ulLoop = 0;

    /*自检开始*/
    BspSetNtfLedRunState(NTF_BEGIN);
    dbgPrn("Start RRU NTF ITEMS CHECK!!\n");
    (VOID)exprnquit();
    ret |= BspDiagInit();
    ulItemNum = sizeof(s_RruNtfItems)/sizeof(T_RruNtfItems);
    dbgPrn("NTF_ITEMS_TotalNum = %d\n",ulItemNum);

    ret = BspSystem("rm -f report_m.txt");
    CHECK_RET_WARNING(ret, "rm failed, ret:%d", ret);
    for(ulLoop = 0; ulLoop < ulItemNum; ulLoop++)
    {
        dbgInfo("|*********************************** ulLoop = %d **********************************|\n", ulLoop);
        ulRet = BspDetectOneItem(ulLoop);
        s_RruNtfItems[ulLoop].funcRet = ulRet;
        /*记录已执行完毕的检测项*/
        s_RruNtfItems[ulLoop].runFlag = NTF_ITEM_RUN;
    }
    ret = BspSystem("mv /report_m.txt /ata/");
    CHECK_RET_WARNING(ret, "mv failed, ret:%d", ret);

    /*自检结束*/
    //s_NtfState = NTF_END;
    return ret;
}

/*****************************************************************************
*  函数名称   : StartToDetection()
*  功能描述   : 自检入口
*  输入参数   : 无
*  输出参数   : 无
*  返 回 值   :   BSP_ERROR --执行成功
                             BSP_OK -- 执行失败
*  其它说明   : 0xff -- 定义为非自检状态
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A),  yc     @2019-09-11 20:38:55 创建
*****************************************************************************/
static UINT32 StartToDetection(void)
{
    UINT32 ulLogOpt = 0;

    /*开始自检项检测*/
    DetectRruItems();

    //IcHalCpriInternalLoopback(0,0);
    BspHalAdaptGetMainLogicOpt(&ulLogOpt);
    IcHalCpriMidFreqBfnSel(ulLogOpt);

    return BSP_OK;
}

/*****************************************************************************
*  函数名称   : BspInnerTestStart()
*  功能描述   : RRU单板启动自检
*  输入参数   : ptReqInfo -- 高层下发的自检信息，我们只用到 wTestType
*  输出参数   : 无
*  返 回 值   : BSP_OK, 其它值为失败
*  其它说明   : NTF 自检接口给DTM 调用
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A),  yc     @2019-09-11 20:38:55 创建
*****************************************************************************/
UINT32 BspInnerTestStart(TDetectReqInfo *ptReqInfo)
{
    UINT32 ulRet = BSP_OK;
//    UINT32 txChnNum  = BspGetTxChannel();
//    UINT32 ulChan = 0;

    INPUT_POINTER_CHECK(ptReqInfo);
    if((NTF_FAR_DETECTION != ptReqInfo->wTestType)&&(NTF_NEAR_DETECTION != ptReqInfo->wTestType))
    {
        return BSP_ERROR_INVALID_PARA;
    }
    dbgInfo("BspInnerTestStart...\n");
    BspSysMsDelay(1000);/*1s*/

    /*保存标志*/
    g_testType = ptReqInfo->wTestType;//0,光纤触发
    g_testMode = 1;  /*自检模式*/
    dbgInfo("g_testMode = %d,g_testType = %d\n", g_testMode, g_testType);
    BspLog(LOG_LEVEL_0,"%s g_testMode = %d,g_testType = %d\n",  __FUNCTION__, g_testMode, g_testType);
    exprnquit(); /*关闭断链打印*/

    ulRet |= BspSetTestMode(g_testMode,g_testType,1);
    if(BSP_ERROR==ulRet)
    {
        dbgInfo("Flash is full,creat file FAIL!!!\n");
    }
    ulRet |= StartToDetection();
    BspLog(LOG_LEVEL_0,"%s end ret:%d\n",  __FUNCTION__, ulRet);
    return ulRet ;
}

/*****************************************************************************
*  函数名称   : GetResultFileName()
*  功能描述   : 获取自检结果文件的文件名
*  输入参数   : 无
*  输出参数   : pucFileName -- 文件名
*  返 回 值   :   BSP_ERROR --执行成功
                             BSP_OK -- 执行失败
*  其它说明   :
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A),  yc     @2019-09-11 20:38:55 创建
*****************************************************************************/
static UINT32 GetResultFileName(char *pucFileName, UINT32 ulLen)
{
    T_BspInventoryInfo tInventoryInfo={0};
    rsize_t bufLenSize = (rsize_t)ulLen;
    INT32 ret = 0;

    INPUT_POINTER_CHECK(pucFileName);
    /*获取整机系列号*/
    BspGetRruInventory(&tInventoryInfo);
    /*构造文件名*/
    ret=snprintf_s(pucFileName,bufLenSize,"RRUNTF_%s_RawData.txt",tInventoryInfo.acSerialNumber);
    SNPRINTF_S_CHECK(ret,bufLenSize);
    return BSP_OK;
}

/*****************************************************************************
*  函数名称   : GetResultFilePath()
*  功能描述   : 获取自检结果文件的文件名
*  输入参数   : 无
*  输出参数   : pucFileName -- 文件名
*  返 回 值   :   BSP_ERROR --执行成功
                             BSP_OK -- 执行失败
*  其它说明   :
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A),  yc     @2019-09-11 20:38:55 创建
*****************************************************************************/
static UINT32 GetResultFilePath(char *pucFilePath, UINT32 ulLen)
{
    INT32  snpRet=0;
    char aucFileName[MAX_FILE_NAME_LEN]={0};
    INPUT_POINTER_CHECK(pucFilePath);
    /*构造文件名称*/
    GetResultFileName(&aucFileName[0],sizeof(aucFileName));
    snpRet = snprintf_s(pucFilePath,ulLen,"%s%s",NTF_RAW_FILE_DIR,&aucFileName[0]);
    SNPRINTF_S_CHECK(snpRet,ulLen);
    return BSP_OK;
}

/*****************************************************************************
*  函数名称   : BspGetTestMode()
*  功能描述   : 获取自检状态
*  输入参数   : 无
*  输出参数   : 无
*  返 回 值   : BSP_OK, 其它值为失败
*  其它说明   :
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A),  10229672 创建
*****************************************************************************/
UINT32 BspGetTestMode(UINT8 *ucTestMode,UINT8 *ucTestType)
{
    FILE *fp = NULL;
    INT32 ulTemp0 = 0;
    INT32 ulTemp1 = 0;
    INT32  iRet = 0;
    CHAR * const cDirList[1] = {"/"};
    rsize_t rDirListSize = 1;
    char aucResultFile[MAX_FILE_PATH_LEN]={0};
    /* UINT32 ulRet = BSP_OK; */
    INPUT_POINTER_CHECK(ucTestMode);
    INPUT_POINTER_CHECK(ucTestType);

    GetResultFilePath(&aucResultFile[0],sizeof(aucResultFile));

    (void)zte_fopen_s(&fp, aucResultFile, "r", cDirList, rDirListSize);
    if ( fp == NULL )
    {
        return BSP_ERROR;
    }

    if(EOF == fscanf_s(fp,"TestMode=%d,TestType=%d",&ulTemp0,&ulTemp1))
    {
        dbgErr("%s: fscanf_s fail!\n", __FUNCTION__);
    }
    *ucTestMode = (UINT8)ulTemp0;
    *ucTestType = (UINT8)ulTemp1;
    iRet = fclose(fp);
    FCLOSE_CHECK(iRet);
    return BSP_OK;
}

/*****************************************************************************
*  函数名称: BspGetLastTestInfo()
*  功能描述: 获取自检状态信息
*  输入参数: ptTestInfo -- 自检状态结构体
*  输出参数: 无
*  返 回 值: BSP_OK, 其它值为失败
*  其它说明: 给DTM 调用
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A),  10229672     @2019-06-11 20:38:55 创建
*****************************************************************************/
UINT32 BspGetLastTestInfo(TRruSelfTestInfo *ptTestInfo)
{
    UINT32 ulRet = BSP_OK;

    if(NULL == ptTestInfo)
    {
        return BSP_ERROR_NULL_POINTER;
    }
    ulRet = BspGetTestMode(&g_testMode, &g_testType);
    ptTestInfo->ucSelfTestTag = g_testMode;
    ptTestInfo->ucSelfTestType = g_testType;
    return ulRet;
}

UINT32 BspInitNtfAvoidCfg(VOID)
{
    UINT32 itemIndex = 0;

    for (itemIndex = 0; itemIndex < E_NTF_CHECK_MAX_NUM; itemIndex++)
    {
        g_ntfAvoidItem[itemIndex].chanMask[TX] = 0;
        g_ntfAvoidItem[itemIndex].chanMask[RX] = 0;
    }

    return BSP_OK;
}

UINT32 BspSetChanNtfAvoidFlag(T_RruNtfAvoidFlag *ptRruNtfAvoidPara)
{
    UINT32 itemNum = 0;
    UINT32 itemIndex = 0;
    UINT32 itemType = 0;

    INPUT_POINTER_CHECK(ptRruNtfAvoidPara);

    itemNum = ptRruNtfAvoidPara->itemNum;

    if (itemNum > E_NTF_CHECK_MAX_NUM)
    {
        dbgInfo("%s, itemNum > NTF AVOID ITEM MAX!\n", __FUNCTION__);
        return BSP_ERROR;
    }

    BspInitNtfAvoidCfg();

    for(itemIndex = 0; itemIndex < itemNum; itemIndex++)
    {
        itemType = ptRruNtfAvoidPara->atNtfAvoidItem[itemIndex].type;
        g_ntfAvoidItem[itemType].chanMask[TX] = ptRruNtfAvoidPara->atNtfAvoidItem[itemIndex].chanMask[TX];
        g_ntfAvoidItem[itemType].chanMask[RX] = ptRruNtfAvoidPara->atNtfAvoidItem[itemIndex].chanMask[RX];
        dbgInfo("%s, itemType：%d chanMask:[TX:0x%x,RX:0x%x]\n", __FUNCTION__, itemType, g_ntfAvoidItem[itemType].chanMask[TX],g_ntfAvoidItem[itemType].chanMask[RX]);
        BspLog(LOG_LEVEL_0,"%s, itemType：%d chanMask:[TX:0x%x,RX:0x%x]\n", __FUNCTION__, itemType, g_ntfAvoidItem[itemType].chanMask[TX],g_ntfAvoidItem[itemType].chanMask[RX]);
    }
    BspSetNtfSolutionCfg(BSP_NTF_NEW_SOLUTION);
    return BSP_OK;
}

T_NtfAvoidItem g_ntfCfg[E_NTF_CHECK_MAX_NUM] =
{//  Item                     rxchnmask   txchnmask
    {E_NTF_PWR_CHECK,         {0xf,       0xf}},
    {E_NTF_PLL_CHECK,         {0x0,       0x4}},
    {E_NTF_OPT_STATUS_CHECK,  {0x0,       0x0}},
    {E_NTF_TX_DAC_CHECK,      {0x0,       0x6}},
    {E_NTF_RX_ADC_CHECK,      {0x0,       0x0}},
    {E_NTF_PRX_ADC_CHECK,     {0x0,       0x6}},
    {E_NTF_FPGA_CHECK,        {0x0,       0x0}},
    {E_NTF_TX_FWD_CHECK,      {0x0,       0x6}},
    {E_NTF_TX_ATT_CHECK,      {0xc,       0x0}},
    {E_NTF_TX_FLATNESS_CHECK, {0x0,       0x0}},
    {E_NTF_VSWR_CHECK,        {0x0,       0x0}},
    {E_NTF_CIRCULATOR_CHECK,  {0x0,       0x0}},
    {E_NTF_RSSI_CHECK,        {0x0,       0x0}},
};

UINT32 g_ntfCfgNum = NELEMENTS(g_ntfCfg);

UINT32 ntftestdata(UINT32 item, UINT32 rxChanMask, UINT32 txChanMask)
{
    if(item >= E_NTF_CHECK_MAX_NUM)
    {
        dbgInfo(" item:%d > %d err\n",item, E_NTF_CHECK_MAX_NUM);
        return BSP_ERROR;
    }
    g_ntfCfg[item].chanMask[TX] = txChanMask;
    g_ntfCfg[item].chanMask[RX] = rxChanMask;
    dbgInfo(" item:%d txChanMask:0x%x rxChanMask:0x%x\n",item, g_ntfCfg[item].chanMask[TX], g_ntfCfg[item].chanMask[RX]);

    return BSP_OK;
}

// TEST APP INTERFACE !!!
UINT32 ntfnewtest(VOID)
{
    T_NtfAvoidItem *ptntfCfg = g_ntfCfg;
    UINT32 ntfCfgNum = g_ntfCfgNum;

    T_RruNtfAvoidFlag *ptRruNtfAvoidFlag = (T_RruNtfAvoidFlag *)malloc(sizeof(T_RruNtfAvoidFlag) + ntfCfgNum * sizeof(T_NtfAvoidItem));
    if (NULL == ptRruNtfAvoidFlag)
    {
        dbgInfo("%s, malloc err!\n", __FUNCTION__);
        return BSP_ERROR;
    }

    ptRruNtfAvoidFlag->itemNum = ntfCfgNum;
    memset_s(ptRruNtfAvoidFlag->atNtfAvoidItem, ntfCfgNum * sizeof(T_NtfAvoidItem), 0, ntfCfgNum * sizeof(T_NtfAvoidItem)); // Ensure uninitialized memory is not used
    memcpy_s((VOID *)&(ptRruNtfAvoidFlag->atNtfAvoidItem), ntfCfgNum * sizeof(T_NtfAvoidItem), ptntfCfg, ntfCfgNum * sizeof(T_NtfAvoidItem));
    //TEST APP INTERFACE -_-!
    if (BspSetChanNtfAvoidFlag(ptRruNtfAvoidFlag) != BSP_OK)
    {
        free(ptRruNtfAvoidFlag);
        return BSP_ERROR;
    }

    free(ptRruNtfAvoidFlag);
    ptRruNtfAvoidFlag = NULL; // Set the pointer to NULL after freeing the memory

    return BSP_OK;
}

void rrutest(void)
{
    /********
        自检测试函数
        ***********/
    TDetectReqInfo atReqInfo = {0};
    atReqInfo.wTestType  = 1;/*0代表光纤触发,近端，两种触发模式,后台网管和光纤自环*/

    dbgInfo(" far det start...\n");
    BspInnerTestStart(&atReqInfo);
}

UINT32 BspNtfSkipItemByChnMask(UINT32 item, UINT32 dir)
{
    UINT32 itemLoop = 0;
    UINT32 action = BSP_NTF_SKIP_CHK;

    for (itemLoop = 0; itemLoop < E_NTF_CHECK_MAX_NUM && dir < 2; itemLoop++)
    {
        if (g_ntfAvoidItem[itemLoop].chanMask[dir] != 0)
        {
            action = BSP_NTF_NEED_CHK;
            return action;
        }
    }

    return action;
}

BOOL NtfIsNeedCheck(UINT32 item, UINT32 dir)
{
    if (NTF_NEAR_DETECTION == g_testType)
    {
        return TRUE;
    }

    if (BSP_NTF_NEW_SOLUTION != BspGetNtfSolutionCfg())
    {
        return TRUE;
    }


    if (BspNtfSkipItemByChnMask(item, dir) == BSP_NTF_SKIP_CHK)
    {
        return FALSE;
    }

    return TRUE;
}

UINT32 BspGetChnNtfState(UINT32 bspChn, UINT32 dir, UINT32 chkItem)
{
    UINT32 retNtfState = BSP_NTF_SKIP_CHK;

    if (NTF_NEAR_DETECTION == g_testType)
    {
        return BSP_NTF_NEED_CHK;
    }

    if (BSP_NTF_NEW_SOLUTION != BspGetNtfSolutionCfg())
    {
        return BSP_NTF_NEED_CHK;
    }

    if (g_ntfAvoidItem[chkItem].chanMask[dir] & BSP_BIT(bspChn))
    {
        retNtfState = BSP_NTF_NEED_CHK;
    }

    return retNtfState;
}

VOID showntfcfg(VOID)
{
    UINT32 itemIndex = 0;
    UINT32 numItems = NELEMENTS(g_ntfAvoidItem); // 计算数组长度

    dbgInfo("\nchn\tdir\tPWR(%d)\tPLL(%d)\tOPT(%d)\tTXADC(%d)\tRXADC(%d)\tPRXADC(%d)\tFWD(%d)\tTXATT(%d)\tVSWR(%d)\tRSSI(%d)\n",
                       E_NTF_PWR_CHECK,        E_NTF_PLL_CHECK,
                       E_NTF_OPT_STATUS_CHECK, E_NTF_TX_DAC_CHECK,
                       E_NTF_RX_ADC_CHECK,     E_NTF_PRX_ADC_CHECK,
                       E_NTF_TX_FWD_CHECK,     E_NTF_TX_ATT_CHECK,
                       E_NTF_VSWR_CHECK,       E_NTF_RSSI_CHECK);

    for (itemIndex = 0; itemIndex < numItems; itemIndex++) // 使用计算得出的数组长度
    {
        dbgInfo("itemIndex:%d, txMask:0x%x, rxMask:0x%x\n",itemIndex, g_ntfAvoidItem[itemIndex].chanMask[TX], g_ntfAvoidItem[itemIndex].chanMask[RX]);
    }

    return ;
}

/*****************************************************************************
*  函数名称   : NtfResultMap()
*  功能描述   : 结果映射
*  输入参数   : 无
*  输出参数   : 无
*  返 回 值   : pInfo--结果
                ucLen -- 字符长度
*  其它说明   :
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A),  10229672     @2019-06-20 20:38:55 创建
*****************************************************************************/
static UINT32  NtfResultMap( INT8 *pInfo, UINT8 ucLen )
{
    INT8 buf[MAX_FILE_PATH_LEN]={0};
    UINT32 ulLen = 0;

    if( NULL == pInfo || ucLen>MAX_FILE_PATH_LEN)
    {
        return BSP_ERROR;
    }
    memcpy_s( buf, ucLen, pInfo, ucLen );

    ulLen = sizeof(NTF_RESULT_SUCC);
    dbgInfoEx("%s: ulLen: %d\n", __FUNCTION__, ulLen);
    if( 0 == memcmp(NTF_RESULT_SUCC,buf,(sizeof(NTF_RESULT_SUCC)-1) ) )
    {
        dbgInfoEx("%s\n",NTF_RESULT_SUCC);
        return TEST_SUCC_TYPE;
    }
    else if( 0 == memcmp(NTF_RESULT_FAIL,buf,(sizeof(NTF_RESULT_FAIL)-1) ))
    {
        dbgInfoEx("%s\n",NTF_RESULT_FAIL);
        return TEST_FAIL_TYPE;
    }
    else if( 0 == memcmp(NTF_RESULT_NOTICE,buf,(sizeof(NTF_RESULT_NOTICE)-1) ))
    {
        dbgInfoEx("%s\n",NTF_RESULT_NOTICE);
        return TEST_NOTICE_TYPE;
    }

    return BSP_ERROR;
}

/*****************************************************************************
*  函数名称   : NtfGetDetectionResult()
*  功能描述   : 获取
*  输入参数   : 无
*  输出参数   : 无
*  返 回 值   : ptTestRlt--结果
*  其它说明   :
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A),  10229672     @2019-06-26 20:38:55 创建
*****************************************************************************/
UINT32 NtfGetDetectionResult (TRruTestResult *ptTestRlt)
{
    FILE *fp = NULL;
    UINT32 ulRetVal = BSP_OK;
    UINT32 ulRet = BSP_ERROR;
    INT32 ulTemp0 = 0;
    INT32 ulTemp1=0;
    INT32 fret = 0;
    CHAR * const cDirList[1] = {"/"};
    rsize_t rDirListSize = 1;
    char arr[MAX_FILE_PATH_LEN]={0};
    const char* s="rru hardware fault";
    char aucResultFile[MAX_FILE_PATH_LEN]={0};
    if( NULL == ptTestRlt )
    {
        return BSP_ERROR;
    }

    GetResultFilePath(&aucResultFile[0], sizeof(aucResultFile));
    (void)zte_fopen_s(&fp, aucResultFile, "r", cDirList, rDirListSize);
    if (fp == NULL)
    {
        return BSP_ERROR;
    }

    if(EOF == fscanf_s(fp,"TestMode=%d,TestType=%d",&ulTemp0,&ulTemp1))
    {
       dbgErr("%s: fscanf_s fail!\n", __FUNCTION__);
    }
    memset_s(arr,sizeof(arr),0,sizeof(arr));
    while (0 == zte_fgets_s(arr, sizeof(arr), sizeof(arr), fp))
    {
        if( 0 == memcmp(arr,"\n",1) )
        {
            continue;
        }
        ulRet = NtfResultMap((INT8*)arr,MAX_FILE_PATH_LEN);
        if( TEST_FAIL_TYPE == ulRet )
        {
            ptTestRlt->wRlt = ulRet;
            ptTestRlt->wCodeNum = 1;
            ptTestRlt->atCodeInfo[0].dwCode = 30001;
            memcpy_s(ptTestRlt->atCodeInfo[0].aucPara,(strnlen_s(s,100)+1),s,(strnlen_s(s,100)+1));
            break;
        }
        else
        {
            ptTestRlt->wRlt = TEST_SUCC_TYPE;
        }
    }

    fret = fclose(fp);
    FCLOSE_CHECK(fret);

    return ulRetVal;
}

/*****************************************************************************
*  函数名称   : BspSetTestMode()
*  功能描述   : 设置自检状态
*  输入参数   : 无
*  输出参数   : 无
*  返 回 值   : BSP_OK, 其它值为失败
*  其它说明   :
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A),  10229672 创建
*****************************************************************************/
UINT32 BspSetTestMode(UINT8 ucTestMode,UINT8 ucTestType,UINT8 ucFlag)//1 0 1
{
    FILE *fp = NULL;
    INT32  iRet = 0;
    INT32 fprtRet = 0;
    CHAR * const cDirList[1] = {"/"};
    rsize_t rDirListSize = 1;
    char aucResultFile[MAX_FILE_PATH_LEN]={0};

    GetResultFilePath(&aucResultFile[0], sizeof(aucResultFile));
    (void)zte_fopen_s(&fp, aucResultFile, "r+b", cDirList, rDirListSize);
    if ( fp == NULL)
    {
        (void)zte_fopen_s(&fp, aucResultFile, "w+b", cDirList, rDirListSize);
        if(fp==NULL)
        {
            return BSP_ERROR;
        }
    }
    else if(ucFlag == 1)/*重新检测需要清除文件*/
    {
        iRet = fclose(fp);
        FCLOSE_CHECK(iRet);
        (void)zte_fopen_s(&fp, aucResultFile, "w+b", cDirList, rDirListSize);
        if(fp==NULL)
        {
            return BSP_ERROR;
        }
    }
    if (fseek(fp,0,SEEK_SET) != 0)
    {
        dbgErr("%s: fseek error\n", __FUNCTION__);
        iRet = fclose(fp);
        FCLOSE_CHECK(iRet);
        return BSP_ERROR;
    }
    fprtRet = fprintf(fp,"TestMode=%d,TestType=%d\n",ucTestMode,ucTestType);
    FPRINTF_CHECK(fprtRet);
    iRet = fclose(fp);
    FCLOSE_CHECK(iRet);
    return BSP_OK;
}

/*****************************************************************************
*  函数名称   : BspGetInnerTestResult()
*  功能描述   : 获取自检结果信息
*  输入参数   : ptTestRlt -- 自检结果信息
*  输出参数   : 无
*  返 回 值   : BSP_OK, 其它值为失败
*  其它说明   : 从文件获取结果给APP调用,获取完结果之后需要清除触发标志位
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A),  yc     @2019-09-11 20:38:55 创建
*****************************************************************************/
UINT32  BspGetInnerTestResult(TRruTestResult *ptTestRlt)
{
    UINT32 ulRet = BSP_OK;

    INPUT_POINTER_CHECK(ptTestRlt);
    ulRet |= NtfGetDetectionResult(ptTestRlt);
    /*获取结果之后，需要清除自检触发标志信息*/
    ulRet |= BspSetTestMode(0, g_testType, 0);
    if(BSP_ERROR==ulRet)
    {
        dbgInfo("Flash is full,creat file FAIL!!!\n");
    }
    return ulRet;
}

/*****************************************************************************
*  函数名称   : PrintNtfInfo()
*  功能描述   : 打印当前NTF 状态信息
*  输入参数   : 无
*  输出参数   : 无
*  返 回 值   :   BSP_ERROR --执行成功
                             BSP_OK -- 执行失败
*  其它说明   :
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A),  yc     @2019-06-26 20:38:55 创建
*****************************************************************************/
UINT32 PrintNtfInfo(void)
{
    char aucResultFileName[70] = {0};
    UINT32 ulRet = BSP_OK;
    UINT32 uLoop = 0;
    TRruTestResult tTestRlt={0};
    dbgInfo("<----------NTF current Status Info.---------> \n");
    if (1 == g_testMode)
    {
        dbgInfo("    Mode : NTF mode.\n ");
    }
    else
    {
        dbgInfo("    Mode : Not NTF mode. \n");
    }

    if(0 == g_testType)
    {
        dbgInfo("    Trigger Type: Near. \n");
    }
    else if(1 == g_testType)
    {
        dbgInfo("    Trigger Type: Far. \n");
    }
    else
    {
        dbgInfo("    Trigger Type: Unknowable. \n");
    }
    GetResultFileName(&aucResultFileName[0],sizeof(aucResultFileName));
    dbgInfo("    NTF Result File Name(/ata/) : %s \n",&aucResultFileName[0]);

    if (BSP_OK != NtfGetDetectionResult(&tTestRlt))
    {
        dbgInfo("Get Detection Result Error.\n ");
        return BSP_ERROR;
    }
    dbgInfo("    NTF Detection Result: %x  (0:Ok.1:Alarm.2:unknowable)\n",tTestRlt.wRlt);
    dbgInfo("    Detection Alarm Info: \n");
    dbgInfo("    Alarm Num:  %d\n",tTestRlt.wCodeNum);
    ulRet = tTestRlt.wCodeNum < NTF_RECORD_MAX_NUM ? tTestRlt.wCodeNum : NTF_RECORD_MAX_NUM;
    for(uLoop = 0;uLoop < ulRet;uLoop++)
    {
        dbgInfo("    No. : %d\n",uLoop);
        dbgInfo("    Alarm Code : %d\n",tTestRlt.atCodeInfo[uLoop].dwCode);
        dbgInfo("    Alarm Para : %s\n\n",tTestRlt.atCodeInfo[uLoop].aucPara);
    }
    dbgInfo("<----------NTF current Status Info.--------->\n");
    return BSP_OK;
}

/*****************************************************************************
*  函数名称   : BspGetNtfItemResult()
*  功能描述   : 获取自检结果信息
*  输入参数   : ptTestRlt -- 自检结果信息
*  输出参数   : 无
*  返 回 值   : BSP_OK, 其它值为失败
*  其它说明   : 自检完结果上报给APP调用,高层传入13项，BSP结果按type类型填到对用的数组索引中
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A),  yc     @2019-09-11 20:38:55 创建
*****************************************************************************/
UINT32 BspGetNtfItemResult(T_RruNtfResult *ptRruNtfResultPara)
{
    UINT32 ulLoop = 0;
    UINT32 actualItemNum = 0;
    UINT32 itemType = 0;
    UINT32 dir = TX;
    UINT32 checkResult = 0;
    UINT32 errorChan = 0;
//    UINT32 resultLen = 0;
    UINT32 ntfItemNum = sizeof(s_RruNtfItems)/sizeof(T_RruNtfItems);
    INPUT_POINTER_CHECK(ptRruNtfResultPara);

//    resultLen = 13;
//    ptRruNtfResultPara->itemNum = 13;
    for(ulLoop = 0;ulLoop < ntfItemNum; ulLoop++)
    {
        //ptRruNtfResultPara->atNtfItemResult[itemType].type = 0xffff;/* 将自检类型初始化为0xffff代表未自检 */
        itemType = s_RruNtfItems[ulLoop].itemType;
        if(itemType >= E_NTF_CHECK_MAX_NUM)
        {
            dbgInfo("%s loop:%d itemType:%d > itemNumMax:%d err\n", __FUNCTION__, ulLoop, itemType, E_NTF_CHECK_MAX_NUM);
            BspLog(LOG_LEVEL_0,"%s loop:%d itemType:%d >= itemNumMax:%d err\n", __FUNCTION__, ulLoop, itemType, E_NTF_CHECK_MAX_NUM);
            continue;
        }
        if((NTF_ITEM_RUN == s_RruNtfItems[ulLoop].runFlag )) //&& (TRUE == NtfIsNeedCheck(itemType, TX))
        {
            checkResult = s_RruNtfItems[ulLoop].funcRet;
            errorChan = s_RruNtfItems[ulLoop].errorChan;
            ptRruNtfResultPara->atNtfItemResult[itemType].type = itemType;
            ptRruNtfResultPara->atNtfItemResult[itemType].checkResult = checkResult;
            ptRruNtfResultPara->atNtfItemResult[itemType].chanResultMask[dir] = errorChan;
            dbgInfo("%s loop:%d itemType:%d, dir:%d checkResult:%d errorChan:0x%x\n", __FUNCTION__, ulLoop, itemType, dir, checkResult, errorChan);
            BspLog(LOG_LEVEL_0,"%s loop:%d itemType:%d, dir:%d checkResult:%d errorChan:0x%x\n", __FUNCTION__, ulLoop, itemType, dir, checkResult, errorChan);
            actualItemNum++;
        }
    }
    //ptRruNtfResultPara->itemNum = actualItemNum;
    dbgInfo("%s actualItemNum:%d \n", __FUNCTION__, actualItemNum);
    BspLog(LOG_LEVEL_0,"%s actualItemNum:%d \n", __FUNCTION__, actualItemNum);

    return BSP_OK;
}

UINT32 BspGetNtfileLen(CHAR *aucResultFile, INT64 *size)
{
    FILE *pFile = NULL;
    INT64 liTmpSize = 0;

    INPUT_POINTER_CHECK(size);
    // 指定目录列表，这里仅使用根目录 "/"
    CHAR * const cDirList[1] = {"/"};
    rsize_t rDirListSize = 1;

    // 尝试打开文件
    (void)zte_fopen_s(&pFile, aucResultFile, "rb", cDirList, rDirListSize);
    if (pFile == NULL)
    {
        liTmpSize = 0;
    }
    else
    {
        // 移动文件指针到文件末尾
        (void)fseek(pFile, 0, SEEK_END);

        // 获取文件大小
        liTmpSize = ftell(pFile);
        if((liTmpSize) < ((INT64)0))
        {
            dbgErr("%s(%d) warning! > ftell ret'%lld! \n", __FUNCTION__, __LINE__, liTmpSize);
        }
        // 关闭文件
        (void)zte_fclose_s(pFile);
    }

    // 设置输出参数为文件大小
    *size = liTmpSize;

    return BSP_OK;
}

/*****************************************************************************
*  函数名称   : NtfRecordDetectionResult()
*  功能描述   : 记录检测结果文件
*  输入参数   : 无
*  输出参数   : 无
*  返 回 值   : ulAlmType --0，成功；1，失败；2，不确定；3，打印信息；
                ulOp -- 0，继续；1-终止
                ulErrCode---错误码
                pInfo----打印信息
*  其它说明   :
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A),  10229672     @2019-10-20 20:38:55 创建
*****************************************************************************/
UINT32  NtfRecordDetectionResult (UINT32 ulAlmType,UINT32 ulOp,TCodeInfo *ptCode,const char*pcInfo,FLOAT fVswrLoc)
{
    FILE *fp = NULL;
    static UINT8 ucFlag = 0;
    char aucResultFile[MAX_FILE_PATH_LEN]={0};
    UINT32 ulRet = BSP_OK;
    INT32 fprtRet = 0;
    INT32 fclsRet = 0;
    INT64 ulFileSize = 0;
    CHAR * const cDirList[1] = {"/"};
    rsize_t rDirListSize = 1;

    STRCHR_CHECK(ptCode);
    STRCHR_CHECK(pcInfo);

    ulRet = GetResultFilePath(&aucResultFile[0], sizeof(aucResultFile));
    if(BSP_OK != ulRet)
    {
        dbgInfo("GetResultFilePath Fail in NtfRecordDetectionResult\n");
        return BSP_ERROR;
    }
    ulRet = BspGetNtfileLen(aucResultFile, &ulFileSize);

    if(BSP_OK != ulRet || ulFileSize > MAX_FILE_SIZE_1M)
    {
        dbgInfo("GetResultFilePath file size get fail or size over ret %d size %lld\n",ulRet,ulFileSize);
        return BSP_OK;
    }

    (void)zte_fopen_s(&fp, aucResultFile, "a+b", cDirList, rDirListSize);
    if ( fp == NULL )
    {
        return BSP_ERROR;
    }
    if(NULL != ptCode)
    {
        dbgInfo("ptCode->aucPara = %s in NtfRecordDetectionResult",ptCode->aucPara);
    }

    switch(ulAlmType)
    {
        case TEST_SUCC_TYPE:
            fprtRet = fprintf(fp,"%s\n",NTF_RESULT_SUCC);
            FPRINTF_CHECK(fprtRet);
            fprtRet = fprintf(fp,"%s\n",NTF_SEGMENT_LINE);
            FPRINTF_CHECK(fprtRet);
            break;
        case TEST_FAIL_TYPE:
            if( 0 == ucFlag )
            {
                ucFlag = 1;
                fprtRet = fprintf(fp,"%s\n",NTF_RESULT_FAIL);
                FPRINTF_CHECK(fprtRet);
            }
            if( NULL != ptCode )
            {
                fprtRet = fprintf(fp,"%d\n",ptCode->dwCode);
                FPRINTF_CHECK(fprtRet);
                fprtRet = fprintf(fp,"%s\n",ptCode->aucPara);
                FPRINTF_CHECK(fprtRet);
            }
            if( NTF_PAUSE_TEST== ulOp )
            {
                fprtRet = fprintf(fp,"%s\n",NTF_SEGMENT_LINE);
                FPRINTF_CHECK(fprtRet);
                ucFlag = 0;
            }
            break;
        case TEST_NOTICE_TYPE:
            fprtRet = fprintf(fp,"%s\n",NTF_RESULT_NOTICE);
            FPRINTF_CHECK(fprtRet);
            fprtRet = fprintf(fp,"%s\n",NTF_SEGMENT_LINE);
            FPRINTF_CHECK(fprtRet);
            break;
        case TEST_PRINT_TYPE:
            if( NULL != pcInfo )
            {
                fprtRet = fprintf(fp,"%s",pcInfo);
                FPRINTF_CHECK(fprtRet);
            }
            break;
        case TEST_NOTICE_INFO_TYPE:
            fprtRet = fprintf(fp,"%.2fm",fVswrLoc);
            FPRINTF_CHECK(fprtRet);
            break;
        default:
            break;
    }
    fclsRet = fclose(fp);
    FCLOSE_CHECK(fclsRet);
    return BSP_OK;
}

/* Started by AICoder, pid:c794dddeac344366a06dfe83f3b83b96 */
/* Started by AI-VerifyCI-CodeComplexity, pid:c794dddeac344366a06dfe83f3b83b96 */
// 获取检查结果的字符串表示
const char* getCheckResultString(UINT32 checkResult)
{
    switch (checkResult)
    {
        case BSP_OK:
            return "SUCC";
        case BSP_NOTICE:
            return "NOTICE ";
        case BSP_NO_EXCUTE:
            return "No Excute ";
        default:
            return "FAIL ";
    }
}

/* 打印时间信息 */
/* Started by AICoder, pid:v2c8f486176635114f390baff0389120548827d8 */
UINT32 NtfRecordTimeInfo()
{
    UINT32 ret = BSP_OK;
    time_t ulTimeRet = 0;
    time_t timep = 0;
    struct tm tmBuffer; // 用于存储时间信息的缓冲区
    struct tm *pTm = NULL;
    char buffer[26] = {0}; // strftime 需要的缓冲区大小

    ret |= NtfRecordDetectionResult(TEST_PRINT_TYPE, 0, NULL, "\n========NTF TIME INFO=======\n", 0);
    /*生成文件的时间,东八区相差8小时，不连BBU校准是绝对时间，校准后是相对时间*/
    ret |= NtfRecordDetectionResult(TEST_PRINT_TYPE, 0, NULL, "CreatNtfFileTime:", 0);

    ulTimeRet = time(&timep);
    TIME_CHECK(ulTimeRet);
    pTm = localtime_r(&timep, &tmBuffer);
    /* Started by AICoder, pid:4239054c3c1f4bad97d0cf1cfa0a5f63 */
    /* Started by AI-VerifyCI-KwCov, pid:4239054c3c1f4bad97d0cf1cfa0a5f63 */
    if (NULL != pTm)
    {
        if (0 == strftime(buffer, sizeof(buffer), "%a %b %d %H:%M:%S %Y\n", pTm))
        {
            dbgErr("Failed to format time string\n");
        }
        else
        {
            ret |= NtfRecordDetectionResult(TEST_PRINT_TYPE, 0, NULL, buffer, 0);
        }
    }
    /* Ended by AI-VerifyCI-KwCov, pid:4239054c3c1f4bad97d0cf1cfa0a5f63 */
    /* Ended by AICoder, pid:4239054c3c1f4bad97d0cf1cfa0a5f63 */

    return ret;
}
/* Ended by AICoder, pid:v2c8f486176635114f390baff0389120548827d8 */

/* Started by AICoder, pid:649571a9eeh3580147b80b0be0743046eed31fd4 */
static UINT32 BspRecordVswrLocation(T_NtfVswr *info)
{
    UINT32 retVal = BSP_OK;
    UINT32 chan = 0;
    CHAR   pcChan[20] = {0};
    UINT32 chanNum = BspGetTxChannel();
    INT32  snpRet = 0;
    UINT32 vswrPos = 0;

    INPUT_POINTER_CHECK(info);
    if(chanNum >= BSP_MAX_TX_CHAN)
    {
        dbgErr("[%s]:Chan is %d, out bounds error!\n",__FUNCTION__,chanNum);
        return BSP_ERROR;
    }
    for(chan = 0; chan < chanNum; chan ++)
    {
        vswrPos = BspGetVswrPosVal(chan);
        if(vswrPos != 0)
        {
            if(vswrPos == OUTSIDE_VSWR)
            {
                snpRet = snprintf_s(pcChan, 20, " Chan(%#X)", chan);
                SNPRINTF_S_CHECK(snpRet, sizeof(pcChan));
                retVal |= NtfRecordDetectionResult(TEST_PRINT_TYPE, 0, NULL, pcChan, 0);
                retVal |= NtfRecordDetectionResult(TEST_PRINT_TYPE, 0, NULL, " Location=", 0);
                retVal |= NtfRecordDetectionResult(TEST_NOTICE_INFO_TYPE, 0, NULL, NULL, info->location[chan] / 1000.0);
            }
            else if(vswrPos == FUZZY_REGION)
            {
                snpRet = snprintf_s(pcChan, 20, " Chan(%#X)", chan);
                SNPRINTF_S_CHECK(snpRet, sizeof(pcChan));
                retVal |= NtfRecordDetectionResult(TEST_PRINT_TYPE, 0, NULL, pcChan, 0);
                retVal |= NtfRecordDetectionResult(TEST_PRINT_TYPE, 0, NULL, "FuzzyRegion ", 0);
            }
            else
            {
                snpRet = snprintf_s(pcChan, 20, " Chan(%#X)", chan);
                SNPRINTF_S_CHECK(snpRet, sizeof(pcChan));
                retVal |= NtfRecordDetectionResult(TEST_PRINT_TYPE, 0, NULL, pcChan, 0);
                retVal |= NtfRecordDetectionResult(TEST_PRINT_TYPE, 0, NULL, "InternalVswr ", 0);
            }
        }
    }
    retVal |= NtfRecordDetectionResult(TEST_PRINT_TYPE, 0, NULL, "\n", 0);
    return retVal;
}
/* Ended by AICoder, pid:649571a9eeh3580147b80b0be0743046eed31fd4 */

/*****************************************************************************
*  函数名称   : BspSetRruNtfResult()
*  功能描述   : 自检结果汇总成检测结果文件
*  输入参数   : ptTestRlt -- 自检结果信息
*  输出参数   : 无
*  返 回 值   : BSP_OK, 其它值为失败
*  其它说明   : 自检完结果上报给APP调用
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A),  yc     @2019-09-11 20:38:55 创建
*****************************************************************************/
UINT32 BspSetRruNtfResult(T_RruNtfResult *ptRruNtfResultPara)
{
    UINT32 ret = BSP_OK;
    INT32 retVal = BSP_OK;
    UINT32 ulLoop = 0;
    UINT32 itemType = 0;
    char   pcChan[20] = {0};
    UINT32 dir = TX;
    UINT32 checkResult = 0;
    UINT32 errorChan = 0;
    UINT32 finalRet = BSP_OK;
    TCodeInfo tTCodeInfo = {0};
    CHAR   aucPara[60] = {0};
    UINT32 ulParaLen = 0;
    UINT32 chanNum = BspGetTxChannel();
    char   ucItemStr[300] = "NTF Abnormal Items:\n";/*用于存储原始数据，最后写入自检结果文件后面*/
    INPUT_POINTER_CHECK(ptRruNtfResultPara);
//
    UINT32 ulItemNum = ptRruNtfResultPara->itemNum;
    BspLog(LOG_LEVEL_0,"%s start ItemNum:%d\n",  __FUNCTION__, ulItemNum);

    for(ulLoop = 0; ulLoop < ulItemNum; ulLoop++)
    {
        memset_s((INT8 *)&tTCodeInfo, sizeof(TCodeInfo), 0, sizeof(TCodeInfo));
        itemType = ptRruNtfResultPara->atNtfItemResult[ulLoop].type;
        checkResult = ptRruNtfResultPara->atNtfItemResult[ulLoop].checkResult;
        /* Started by AICoder, pid:3d2a8a2b65j705214e23092aa0381d102bb213e7 */
        NTF_SKIP_ITEM(itemType);
        /* Ended by AICoder, pid:3d2a8a2b65j705214e23092aa0381d102bb213e7 */
        if(BSP_ERROR == checkResult)
        {
            finalRet = BSP_ERROR;
            tTCodeInfo.dwCode = BSP_NTF_FINAL_RESULT_ERROR;
            /*返回值转换成字符串，写入原始文件*/
            retVal = snprintf_s(aucPara, sizeof(aucPara), "%u", checkResult);
            SNPRINTF_S_CHECK(retVal, sizeof(aucPara));
            strncpy_s((char *)tTCodeInfo.aucPara, sizeof(aucPara), aucPara, sizeof(aucPara));
            ulParaLen = sizeof(tTCodeInfo.aucPara);
            tTCodeInfo.aucPara[ulParaLen-1] = '\0';
            /*保存带有告警的原始信息*/
            strncat_s(ucItemStr, sizeof(ucItemStr), g_ntfItemInfo[itemType].pItemName, (sizeof(ucItemStr) - strnlen_s(ucItemStr, sizeof(ucItemStr)) -1));
            if(ulLoop == (ulItemNum - 1))
            {
                /*只有内部故障时才能写入fail，外部故障不能写入fail*/
                ret |= NtfRecordDetectionResult(TEST_FAIL_TYPE, NTF_PAUSE_TEST, &tTCodeInfo, NULL, 0);
            }
            else
            {
                /*只有内部故障时才能写入fail，外部故障不能写入fail*/
                ret |= NtfRecordDetectionResult(TEST_FAIL_TYPE, NTF_CONTINUE_TEST, &tTCodeInfo, NULL, 0);
            }
            BspSetNtfResult(BSP_ERROR);
        }
    }
    /*添加空格行*/
    ret |= NtfRecordDetectionResult(TEST_PRINT_TYPE, 0, NULL, "\n", 0);
    ret |= NtfRecordDetectionResult(TEST_PRINT_TYPE, 0, NULL,
            "Attentions:If internal attribute item fails,the result fails.But,external attribute item fails,the result may succ.\n", 0);
    ret |= NtfRecordDetectionResult(TEST_PRINT_TYPE, 0, NULL, "========DETAILS========\n", 0);

    /*保存自检结果*/
    if(BSP_OK == finalRet)
    {
        /*无内部故障作为自检结果中的一种，必须写入自检结果文件*/
        tTCodeInfo.dwCode = BSP_NTF_FINAL_RESULT_OK;
        tTCodeInfo.aucPara[0] = '0';
        ret |= NtfRecordDetectionResult(TEST_SUCC_TYPE, 0, NULL, NULL, 0);
    }
    else
    {
        /*检测完成之后，将故障检测项的原始数据打印在结果最后*/
        ret |= NtfRecordDetectionResult(TEST_PRINT_TYPE, 0, NULL, ucItemStr, 0);
        /*添加空格行*/
        ret |= NtfRecordDetectionResult(TEST_PRINT_TYPE, 0, NULL, " ", 0);
    }

    /*分隔字符*/
    ret |= NtfRecordDetectionResult(TEST_PRINT_TYPE, 0, NULL, "\n", 0);
    ret |= NtfRecordDetectionResult(TEST_PRINT_TYPE, 0, NULL, "NTF Items Info:\n", 0);

    for(ulLoop = 0; ulLoop < chanNum; ulLoop++)
    {
        BspSetVswrPosVal(ulLoop, ptRruNtfResultPara->vswr.vswrPosFlag[ulLoop]);
    }
    /*将所有执行过的检测项打印在文件最后*/
    for(ulLoop = 0; ulLoop < ulItemNum; ulLoop++)
    {
        itemType = ptRruNtfResultPara->atNtfItemResult[ulLoop].type;
        checkResult = ptRruNtfResultPara->atNtfItemResult[ulLoop].checkResult;
        /* Started by AICoder, pid:3d2a8a2b65j705214e23092aa0381d102bb213e7 */
        NTF_SKIP_ITEM(itemType);
        /* Ended by AICoder, pid:3d2a8a2b65j705214e23092aa0381d102bb213e7 */
        if(E_NTF_RSSI_CHECK == itemType || E_NTF_RX_ADC_CHECK == itemType)
        {
            dir = RX;
        }
        else
        {
            dir = TX;
        }
        errorChan = ptRruNtfResultPara->atNtfItemResult[ulLoop].chanResultMask[dir];
        dbgInfo("%s loop:%d itemType:%d, %s dir:%d checkResult:%d errorChan:0x%x\n", __FUNCTION__, ulLoop, itemType, g_ntfItemInfo[itemType].pItemName, dir, checkResult, errorChan);
        BspLog(LOG_LEVEL_0,"%s loop:%d itemType:%d, %s dir:%d checkResult:%d errorChan:0x%x\n", __FUNCTION__, ulLoop, itemType, g_ntfItemInfo[itemType].pItemName, dir, checkResult, errorChan);
        ret |= NtfRecordDetectionResult(TEST_PRINT_TYPE, 0, NULL, g_ntfItemInfo[itemType].pItemName, 0);
        ret |= NtfRecordDetectionResult(TEST_PRINT_TYPE, 0, NULL, getCheckResultString(checkResult), 0);
        if((BSP_OK != checkResult) && (BSP_NO_EXCUTE != checkResult))
        {
            retVal = snprintf_s(pcChan, 20, "ChanMask(%#x)", errorChan);
            SNPRINTF_S_CHECK(retVal, sizeof(pcChan));
            ret |= NtfRecordDetectionResult(TEST_PRINT_TYPE, 0, NULL, pcChan, 0);
        }
        ret |= NtfRecordDetectionResult(TEST_PRINT_TYPE, 0, NULL, "\n", 0);
        /* Started by AICoder, pid:g2729f61fdl006614cc2092a60eab51572550f32 */
        if(E_NTF_VSWR_CHECK == ulLoop)/*记录驻波位置*/
        {
            ret |= BspRecordVswrLocation(&(ptRruNtfResultPara->vswr));
        }
        /* Ended by AICoder, pid:g2729f61fdl006614cc2092a60eab51572550f32 */
    }

    ret |= NtfRecordTimeInfo();
    ret |= NtfRecordDetectionResult(TEST_PRINT_TYPE, 0, NULL, "\n===============================\n", 0);

    /*自检结束之后，后台网管发起的硬件自检，由BSP复位，光纤自环发起的，由高层复位*/
    if(NTF_FAR_DETECTION == g_testType)
    {
        /*如果是远端自检等待一段时间任何复位，目前暂定10s*/
        BspSysMsDelay(10000);/*10s*/
        dbgInfo("%s Far Detection End ,reboot...\n", __FUNCTION__);
        BspLog(LOG_LEVEL_0,"%s Far Detection End ,reboot...\n", __FUNCTION__);
        BspBoardReset();
        return BSP_OK;
    }
    return BSP_OK;
}
/* Ended by AI-VerifyCI-CodeComplexity, pid:c794dddeac344366a06dfe83f3b83b96 */
/* Ended by AICoder, pid:c794dddeac344366a06dfe83f3b83b96 */

void rrutestNew(void)
{
    /********
        自检测试函数
        ***********/
    TDetectReqInfo atReqInfo = {0};
    T_RruNtfResult rruNtfResultPara = {0};

    atReqInfo.wTestType  = 1;/*0代表光纤触发,近端，两种触发模式,后台网管和光纤自环*/

    dbgInfo(" far det start...\n");
    BspInnerTestStart(&atReqInfo);
    ntfnewtest();

    BspGetNtfItemResult(&rruNtfResultPara);
    BspSetRruNtfResult(&rruNtfResultPara);
}

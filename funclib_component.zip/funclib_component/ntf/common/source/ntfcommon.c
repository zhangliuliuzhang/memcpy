/*****************************************************************************
* 版权所有(C) 2017, ZTE Corp. ZXSDR-RRU Platform BSP
*----------------------------------------------------------------------------
* 模 块 名 : BSP
* 文件名称 : ntfcommon.c
* 文件标识 : {[N/A]}
* 内容摘要 :
* 注意事项 : 无
* 作    者 : 10102065
* 创建日期 : 2017-2-27 14:45:34
* 当前版本 : Ver1.0
*----------------------------------------------------------------------------
* 变更记录 :
* $记录1
* 变 更 单: $0000000(N/A)
* 责 任 人: 10102065
* 修改日戳: 2017-2-27 14:45:34
* 变更说明: 创建文件

*----------------------------------------------------------------------------
*/
#include "ntfcommon.h"
#include "bsppub.h"
#include "secure_func.h"
#include "ru_univdef.h"
#include "zprintf.h"
#ifndef MULT_PROGRESS_S
#include "ledctrl_a.h"
#endif
#include "vxadp.h"

static UINT32 s_vswrPosVal[BSP_MAX_CHAN_NUM] = {0};
static INT16  s_stdOutFile  = 0;
static INT32  s_initLogFile = 0;
static UINT32 s_NtfState = NTF_BEGIN;
static UINT32 s_ntfResult = BSP_OK;

const char* BspGetNtfCheckResult(UINT32 result)
{
    switch(result)
    {
        case BSP_OK:
            return "SUCC";
        case BSP_ERROR:
            return "FAIL";
        case BSP_NOTICE:
            return "NOTICE";
        default:
            return "FAIL";
    }
}

UINT32 BspSetVswrPosVal(UINT32 chan, UINT32 vswr)
{
	if(chan >= BSP_MAX_CHAN_NUM)
	{
        return BSP_ERROR;
	}
    s_vswrPosVal[chan] = vswr;
    return BSP_OK;
}

UINT32 BspGetVswrPosVal(UINT32 chan)
{
	if(chan >= BSP_MAX_CHAN_NUM)
	{
        return BSP_ERROR;
	}
    return s_vswrPosVal[chan];
}

UINT32 BspSaveStdout2File(const char *filename)
{
    INT32 retVal = 0;

    INPUT_POINTER_CHECK(filename);
    s_stdOutFile = dup(STDOUT_FILENO);
    s_initLogFile = open(filename, O_CREAT | O_RDWR, 0664);
    if(-1 == s_initLogFile)
    {
        dbgErr("open file error.\n");
        return BSP_ERROR;
    }
    /* 重定向 */
    retVal = dup2(s_initLogFile, STDOUT_FILENO);
    if(-1 == retVal)
    {
        dbgErr("can't redirect fd error\n");
        return BSP_ERROR;
    }

    return BSP_OK;
}

void BspRestoreStdOut(void)
{
    dup2(s_stdOutFile, STDOUT_FILENO);
    close(s_initLogFile);
}

/* Started by AICoder, pid:odeba7a392s277a144750906613721645415bb07 */
void BspSetNtfLedRunState(UINT32 sta)
{
    s_NtfState = sta;
    return ;
}

void BspSetNtfResult(UINT32 result)
{
    s_ntfResult = result;
    return ;
}

#ifndef MULT_PROGRESS_S
/*****************************************************************************
*  函数名称   : NtfLedRun(*)
*  功能描述   : 点RUN灯任务
*  输入参数   : 无
*  输出参数   : 无
*  返 回 值   : 返回值
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A)
*----------------------------------------------------------------------------*/
void NtfLedRunFuntion(void)
{
    UINT32 brightTime = 500;    /* 点亮运行灯的时间 */
    UINT32 txChan = 0;
    UINT32 tmpSign = 0;
    UINT32 txChnNum  = BspGetTxChannel();
    static UINT32 ledState = 0;

    if(NTF_BEGIN == s_NtfState)
    {
        BspLedCtrl_Ntf(BSP_LED_ID_RUN, SWITCH_OFF);
        BspLedCtrl_Ntf(BSP_LED_ID_ALM, SWITCH_OFF);
        BspLedCtrl_Ntf(BSP_LED_ID_LINK0, SWITCH_OFF);
        BspLedCtrl_Ntf(BSP_LED_ID_LINK1, SWITCH_OFF);
        BspLedCtrl_Ntf(BSP_LED_ID_VSWR, SWITCH_OFF);
        BspLedCtrl_Ntf(BSP_LED_ID_ACT, SWITCH_OFF);
        BspSysMsDelay(brightTime);
        BspLedCtrl_Ntf(BSP_LED_ID_RUN, SWITCH_ON);
        BspLedCtrl_Ntf(BSP_LED_ID_ALM, SWITCH_ON);
        BspLedCtrl_Ntf(BSP_LED_ID_LINK0, SWITCH_ON_G);
        BspLedCtrl_Ntf(BSP_LED_ID_LINK1, SWITCH_ON_G);
        BspLedCtrl_Ntf(BSP_LED_ID_VSWR, SWITCH_ON);
        BspLedCtrl_Ntf(BSP_LED_ID_ACT, SWITCH_ON);
        BspSysMsDelay(brightTime);
        ledState = 3;
    }
    else if(NTF_END == s_NtfState)
    {
        if(s_ntfResult == BSP_ERROR)
        {
            if(1 == ledState)
            {
                BspSysMsDelay(brightTime);
                return;
            }
            BspSysMsDelay(brightTime);
            BspLedCtrl_Ntf(BSP_LED_ID_RUN, SWITCH_ON);
            BspLedCtrl_Ntf(BSP_LED_ID_ALM, SWITCH_ON);
            BspLedCtrl_Ntf(BSP_LED_ID_LINK0, SWITCH_OFF);
            BspLedCtrl_Ntf(BSP_LED_ID_LINK1, SWITCH_OFF);
            BspLedCtrl_Ntf(BSP_LED_ID_VSWR, SWITCH_OFF);
            BspLedCtrl_Ntf(BSP_LED_ID_ACT, SWITCH_OFF);
            ledState = 1;
        }
        else
        {
            if(2 == ledState)
            {
                BspSysMsDelay(brightTime);
                return;
            }
            BspSysMsDelay(brightTime);
            BspLedCtrl_Ntf(BSP_LED_ID_VSWR, SWITCH_OFF);
            BspLedCtrl_Ntf(BSP_LED_ID_ALM, SWITCH_OFF);
            BspLedCtrl_Ntf(BSP_LED_ID_LINK0, SWITCH_ON_G);
            BspLedCtrl_Ntf(BSP_LED_ID_LINK1, SWITCH_ON_G);
            BspLedCtrl_Ntf(BSP_LED_ID_RUN, SWITCH_ON);
            BspLedCtrl_Ntf(BSP_LED_ID_ACT, SWITCH_ON);
            ledState = 2;
        }

        for(txChan = 0; txChan < txChnNum; txChan++)
        {
            /*驻波模糊和内部区，点VSWR灯*/
            if((INSIDE_VSWR == BspGetVswrPosVal(txChan)) || (FUZZY_REGION == BspGetVswrPosVal(txChan)))
            {
                tmpSign++;
                if(INSIDE_VSWR == BspGetVswrPosVal(txChan))
                {
                    BspLedCtrl_Ntf(BSP_LED_ID_ALM, SWITCH_ON);
                }
            }
        }
        if(0 != tmpSign)/*驻波模糊和内部区，点VSWR灯*/
        {
            BspSysMsDelay(brightTime);
            BspLedCtrl_Ntf(BSP_LED_ID_VSWR, SWITCH_ON);
        }
        else
        {
            BspSysMsDelay(brightTime);
            BspLedCtrl_Ntf(BSP_LED_ID_VSWR, SWITCH_OFF);
        }
    }
}
#endif

UINT32 ledRunSw = 1;
UINT32 BspSetLedRunSw(UINT32 sw)
{
    ledRunSw = sw;
    return ledRunSw;
}

#ifndef MULT_PROGRESS_S
void NtfLedRun(void)
{
    while(ledRunSw)
    {
        NtfLedRunFuntion();
#ifdef UT_FT_TEST
        return;
#endif
    }
}

UINT32 BspNtfLedRunTask(void)
{
    UINT32 retVal = BSP_OK;
    INT32  value  = 0;
    static UINT32 ledFlag = 0;

    (void)BspDisableLedCtrl();
    if(0 == ledFlag)
    {
        value = taskSpawn("NtfLedRunTask", 60, 0, ((UINT32)1024*10), (FUNCPTR)NtfLedRun, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
        if(ERROR == value)
        {
            retVal = BSP_ERROR;
            dbgInfo("!!! Creat NtfLedRunTask Error !!!\n");
        }
        ledFlag = 1;
    }
    return retVal;
}
#endif
/* Ended by AICoder, pid:odeba7a392s277a144750906613721645415bb07 */

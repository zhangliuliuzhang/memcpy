/*****************************************************************************
 * 版权所有(C) 2010, ZTE Corp. RRU Bsp Platform
 *----------------------------------------------------------------------------
 * 模 块 名 : BSP
 * 文件名称 : ntfcommon.h
 * 文件标识 : {[N/A]}
 * 内容摘要 : ntfcommon 自检功能头文件
 * 注意事项 :
 * 创建日期 : 2012-09-23 14:44:07
 * 当前版本 : Ver1.0
 *----------------------------------------------------------------------------
 * 变更记录 :
  *----------------------------------------------------------------------------
 */
#ifndef _NTF_COMMON_H_
#define _NTF_COMMON_H_
#ifdef __cplusplus
     extern "C" {
#endif

#include "ru_univdef.h"

/*自检项执行标志*/
#define BSP_NOTICE      (0x100)
#define BSP_NO_EXCUTE   (0x200)
/*驻波比位置检测*/
#define OUTSIDE_VSWR     (1)
#define FUZZY_REGION     (2)
#define INSIDE_VSWR      (3)
/*检测项属性 : 是否继续执行*/
#define NTF_CONTINUE_TEST             (0)
#define NTF_PAUSE_TEST                (1)
/*自检状态指示*/
#define NTF_BEGIN                     (0)
#define NTF_END                       (1)
/*自检触发方式*/
#define NTF_NEAR_DETECTION            (0x0)  /*近端*/
#define NTF_FAR_DETECTION             (0x1)  /*远端*/
#define NTF_NO_DETECTION              (0xf)  /*非自检状态*/

#define SNPRINTFS_RETTURN_CHECK(_snpRet, _strLen,_writeLen)               \
    if (((_snpRet) < 0) || ((_snpRet) > (_strLen - _writeLen)))             \
    {                                                                     \
        dbgErr("%s:The strlen is out of max len !\n",__FUNCTION__);      \
        return _writeLen;                                                 \
    }

typedef enum
{
    E_PWR_CHECK,
    E_OPT_STATUS_CHECK,
    E_MAX_MAIN_NTF_ITEMS
}E_BSP_MAIN_NTF_ITEMS;

typedef enum
{
    E_RF_PLL_CHECK = 0,
    E_TX_DAC_CHECK,
    E_RX_ADC_CHECK,
    E_PRX_ADC_CHECK,
    E_TX_FWD_CHECK,
    //E_TX_ATT_CHECK,
    E_TX_FLATNESS_CHECK,
    E_VSWR_CHECK,
    E_RSSI_CHECK,
    E_MAX_SLAVE_NTF_ITEMS
}E_BSP_SLAVE_NTF_ITEMS;

typedef struct
{
    UINT32 voltLowThreshold;
    UINT32 voltUpThreshold;
}PwrVoltThreshold;

typedef struct
{
    CHAR   *hwInfo;    /* 自检结果 */
    UINT32 ledResult;  /* 指示是否要点灯 */
    UINT32 vswrFlag[BSP_MAX_TX_CHAN];   /* 内部驻波为3，模糊区为2，外部为1 */
}NtfSelfTestResult;

typedef struct tagT_RruNtfItems
{
    const char *pItemName;          /*检测项名称，如FPGA加载*/
    UINT32 (*RruNtfItemFunc)(void); /*检测项函数*/
    UINT32 funcRet;                 /*检测项返回值*/
    UINT32 runFlag;                 /*检测项是否执行 0 需执行 1 不执行*/
    UINT32 errorChan;               /*异常通道号*/
    UINT32 itemType;
    UINT32 endNtf;                /*检测项异常是否继续 0 继续 1 结束自检*/
}T_RruNtfItems;

const char* BspGetNtfCheckResult(UINT32 result);
UINT32 BspSetVswrPosVal(UINT32 chan, UINT32 vswr);
UINT32 BspGetVswrPosVal(UINT32 chan);
UINT32 BspSaveStdout2File(const char *filename);
void BspRestoreStdOut(void);
UINT32 BspNtfLedRunTask(void);
void BspSetNtfResult(UINT32 result);
void BspSetNtfTestType(UINT32 type);
void NtfLedRun(void);
UINT32 BspSetLedRunSw(UINT32 sw);

#ifdef __cplusplus
}
#endif
#endif  /*_NTF_COMMON_H_*/

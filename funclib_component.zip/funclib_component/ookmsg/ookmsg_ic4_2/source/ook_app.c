/*********************************************************************
 * 版权所有 (C)深圳市中兴通讯股份有限公司。
 * 
 * 文件名称： ook_app.c
 * 文件标识：
 * 内容摘要： 应用层实现的实现
 * 其它说明：
 * 当前版本： 1.0
 * 作   者：
 * 完成日期：
 * 
 * 修改记录1：
 *    修改日期：
 *    版 本 号：
 *    修 改 人：
 *    修改内容：

 **********************************************************************/
#include "math.h"
#include "bsppub.h"
#include "exprn.h"
#include "systemcallapi.h"
#include "funccommon.h"
#include "ook_msg.h"
#include "vxadp.h"
#include "chnmap_a.h"
#include "rftable_padacset.h"
#include "crc.h"
#include "fpgaloadprocess.h"
#include "ook_app.h"
#include "tddcfg_ic4_2.h"
#include "regdrv.h"
#include "regdrv_access.h"
#include "freqcfg_ic4_2.h"
#include "rftable.h"
#include "funccommon_a.h"
#include "rftableinit.h"
#include "powerctrl_comps_ic4_2.h"
#include "powerctrl_ic4_2.h"
#include "gainctrlapi.h"
#include "papt_common.h"
#include "hardfeaturewrapperrfctrl.h"
#include "rftableinit.h"
#include "rftable_common.h"
#include "devdrv_tempsensor.h"
/**************************************************************************
 *                        宏定义
 **************************************************************************/

/**************************************************************************
 *
 *                         外部变量声明
 **************************************************************************/
static char *ook_app_prn = "OokApp";
/**************************************************************************
 *                         局部函数声明
 **************************************************************************/
#ifndef OOK_CHAN_CHECK
#define OOK_CHAN_CHECK(chan)                     \
    if ((chan) >= BspGetTxChannel())             \
    {                                            \
        OokPrint(PM_ERROR,"chan error!\n",__FUNCTION__); \
        return BSP_ERROR;                        \
    }
#endif

#ifndef OOK_PORTID_CHECK
#define OOK_PORTID_CHECK(portId)                     \
    if ((portId) >= OOK_MAX_PORTID)             \
    {                                            \
        OokPrint(PM_ERROR,"portId error!\n",__FUNCTION__); \
        return BSP_ERROR;                        \
    }
#endif
#define OokPrint(level,fmt...)    PmPrint(PmAutoAdd(DEFAULT_PM_LEVEL,ook_app_prn),(level)|PM_PREFIX,##fmt)
#define RFTBL_NON_EXISTENT        (2)
/**************************************************************************
 *                         全局函数声明
 **************************************************************************/
UINT32 g_ulSlavePortLinkSta[OOK_MAX_PORTID] = {1,1,1};
UINT32 g_ulSlavePortInitSta[OOK_MAX_PORTID] = {2,2,2};
UINT32 g_ulHeartBeatLossCnt[OOK_MAX_PORTID] = {0};
UINT32 g_ulHeartBeatOkCnt[OOK_MAX_PORTID] = {0};
UINT32 g_ulSlaveInitThread[OOK_MAX_PORTID] = {0};
UINT32 g_ulSlaveVerUpdateCnt[OOK_MAX_PORTID] = {0};
T_OokMsgAlmGetAck g_ulSlavePortPmosAlm[OOK_MAX_PORTID] = {0};
UINT32 g_ulSlaveVerUpdateSw = 0;
CHAR s_acFilePathName[][64] = {
        "ata/cali/PaDacSet",
        "ata/cali/FilterGain",
        "ata/cali/PaBasicInfo",
        "ata/cali/PaCurrentCali",
        "ata/cali/PaTempGain",
        "ata/cali/qitaoxing",
        "ata/cali/RruInfo",
        "ata/cali/RxRssi",
        "ata/cali/TxFwd",
        "ata/cali/TxFwdAnalog",
        "ata/cali/TxGain",
        "ata/cali/TxRevAnalog",
        "ata/cali/PaEnergySavingAdj",
        "ata/cali/SscEmbedLut",
};
T_SlavePortTempVolt g_ulSlavePortTemp[OOK_MAX_PORTID] = {0};
static char  g_cpuVer[OOK_MAX_PORTID][44] = {0};   /*长度由子端决定 不再定义宏*/
static char  g_fpgaVer[OOK_MAX_PORTID][44] = {0};
/**************************************************************************


 **************************************************************************/


/*********************************1 常规控制功能*****************************************/
/*****************************************************************************
 *  函数名称   : BspOokgGetSlaveLinkSta(*)
 *  功能描述   : 母端获取子端的建链状态 --0x01
 *  读全局变量 : 无
 *  写全局变量 : 无
 *  输入参数   : portId: 子端端口号，入参需要保证当前配置在子板上，不在母板
 *  输出参数   : pLinkSta: 建链状态 0：建链 其他非建链
 *  返 回 值   : BSP_OK, 无异常; 否则异常
 *  其它说明   : 内部接口，正式流程未调用
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
*----------------------------------------------------------------------------
*/
UINT32 BspOokgGetSlaveLinkSta(UINT32 portId, T_OokMsgLinkStaAck *pLinkSta)
{
    UINT32 retVal = BSP_OK;
    T_OokMsgLinkSta tmpLink = {0};
    T_SlavePortBaseInfo tmpInfo = {0};

    OOK_PORTID_CHECK(portId);
    INPUT_POINTER_CHECK(pLinkSta);
    srand(tickGet());
    tmpLink.randCode = rand();
    dbgInfoEx("tmpLink.randCode 0x%x\n", tmpLink.randCode);
    tmpLink.moduleGroupId = BspGetModuleGroupId();
    tmpLink.boardGroupId = BspGetBoardGroupId();
    tmpLink.boardTypeId = BspGetBoardTypeId();
    tmpLink.hwChangeId = BspGetHardwareChangeId();
    tmpLink.mcuLen = BspGetFileLen("mcu.bit.bin");
    tmpLink.epldLen = BspGetFileLen("epld.bit.bin");

    retVal = OokMsgGetSlaveLinkSta(portId, &tmpLink, pLinkSta);
    if(BSP_OK == retVal)
    {
        tmpInfo.moduleGroupId = pLinkSta->moduleGroupId;
        tmpInfo.boardGroupId = pLinkSta->boardGroupId;
        tmpInfo.boardTypeId = pLinkSta->boardTypeId;
        tmpInfo.hwChangeId = pLinkSta->hwChangeId;
        tmpInfo.rfChanNum = pLinkSta->rfChnNum;
        tmpInfo.cpuType = pLinkSta->cpuType;
        tmpInfo.linkSta = pLinkSta->ackData+1;
        memcpy_s(tmpInfo.rruName,sizeof(tmpInfo.rruName), pLinkSta->rfsBrdType, sizeof(pLinkSta->rfsBrdType));
        memset_s(g_cpuVer[portId], sizeof(g_cpuVer[portId]), 0 ,sizeof(g_cpuVer[portId]));
        memset_s(g_fpgaVer[portId], sizeof(g_fpgaVer[portId]), 0 ,sizeof(g_fpgaVer[portId]));
        memcpy_s(g_cpuVer[portId],sizeof(g_cpuVer[portId]), pLinkSta->cpuVer, sizeof(pLinkSta->cpuVer));
        memcpy_s(g_fpgaVer[portId],sizeof(g_fpgaVer[portId]), pLinkSta->fpgaVer, sizeof(pLinkSta->fpgaVer));
        BspSetSlavePortBaseInfo(portId, &tmpInfo);
    }

    return retVal;
}

UINT32 getLinkSta(UINT32 portId)
{
    T_OokMsgLinkStaAck linkSta = {0};
    UINT32 retVal = BSP_OK;

    retVal = BspOokgGetSlaveLinkSta(portId, &linkSta);
    return retVal;
}

/*恢复子端状态为上电默认值--针对子端复位场景*/
UINT32 BspResetSlavePortSta(UINT32 portId, UINT32 type)
{
    if(portId >= OOK_MAX_PORTID)
    {
        return BSP_ERROR;
    }
    if(0 == type)
    {
        g_ulSlavePortLinkSta[portId] = 1;
    }
    else
    {
        g_ulSlavePortInitSta[portId] = 2;
    }

    return BSP_OK;
}

/*上报存储的建链状态给高层*/
UINT32 BspGetSlavePortSta(UINT32 portId, UINT32 type)
{
    if(portId >= OOK_MAX_PORTID)
    {
        return BSP_ERROR;
    }
    if(0 == type)
    {
        return g_ulSlavePortLinkSta[portId];
    }
    else
    {
        return g_ulSlavePortInitSta[portId];
    }
}

UINT32 BspClrSlavePortSta(UINT32 portId, UINT32 type)
{
    if(portId >= OOK_MAX_PORTID)
    {
        return BSP_ERROR;
    }
    if(0 == type)
    {
        g_ulSlavePortLinkSta[portId] = 1;
    }
    else
    {
        g_ulSlavePortInitSta[portId] = 1;
    }

    return BSP_OK;
}
/*0x02获取子端心跳状态*/
UINT32 BspOokGetSlaveHeartBeat(UINT32 portId, UINT32 *pHeartBeat)
{
    UINT32 retVal = BSP_OK;

    INPUT_POINTER_CHECK(pHeartBeat);
    retVal = OokMsgGetSlaveHeartBeat(portId, pHeartBeat);
    return retVal;
}

UINT32 getHeartBeat(UINT32 portId)
{
    UINT32 sta = 0;
    UINT32 retVal = BSP_OK;

    retVal = BspOokGetSlaveHeartBeat(portId,&sta);
    if(BSP_OK != retVal)
    {
       dbgErr("portId %d ookmsg error\n", portId);
    }
    return sta;
}

/*0x03设置子端通道射频开关*/
UINT32 BspOokSetSlaveRfSwitch(UINT32 chan, UINT32 swType, UINT32 sw, UINT32 swDly)
{
    T_OokMsgRfSwitch tmpSwitch = {0};
    UINT32 retVal = BSP_OK;
    UINT32 portId = 0;

    retVal = BspGetPortIdByBspChn(chan,TX,&portId);  /*通过bsp通道转到portid*/
    if((retVal != BSP_OK)||(portId == 0xf))
    {   /*丝印报错 或者通道号传的是母端的通道*/
        dbgErr("%s chan %d swType %d sw %d failed\n", __FUNCTION__, chan, swType, sw);
        return BSP_ERROR;
    }
    tmpSwitch.rfChn = chan%2;
    tmpSwitch.switchType = swType;
    tmpSwitch.onOffType = sw;
    tmpSwitch.delayMs = swDly;
    retVal = OokMsgSetSlaveRfSwitch(portId, &tmpSwitch);

    return retVal;
}

/*0x04设置子端的led灯*/
UINT32 BspOokSetSlaveLedSwitch(UINT32 portId, UINT32 ledType, UINT32 ctrlType, UINT32 onTimeMs, UINT32 offTimeMs)
{
    T_OokMsgLedSwitch tmpSwitch = {0};
    UINT32 retVal = BSP_OK;

    tmpSwitch.ledType = ledType;
    tmpSwitch.ctrlType = ctrlType;
    tmpSwitch.onTimeMs = onTimeMs;
    tmpSwitch.offTimeMs = offTimeMs;
    retVal = OokMsgSetSlaveLedSwitch(portId, &tmpSwitch);
    return retVal;
}

UINT32 BspOokSetSlaveGridVolt(UINT32 portId, UINT8 dacChipIdx, UINT8 innerChan, UINT16 voltMv)
{
    T_OokMsgGridVoltCfg volt = {0};
    UINT32 retVal = BSP_OK;

    volt.dacChipIdx = dacChipIdx;
    volt.innerChan = innerChan;
    volt.voltMv = voltMv;
    retVal = OokMsgSetSlaveGridVolt(portId, &volt);
    return retVal;
}

/*0x6 离线表下载请求*/
UINT32 BspOokRfTblDownLoadReq(UINT32 portId, UINT32 tblType)
{
    T_OokMsgRfTblDownLoadReq rfTblReq = {0};
    T_OokMsgRfTblDownLoadReqAck rfTblReqAck = {0};
    UINT32 retVal = BSP_OK;
    UINT32 fileLen = 0;
    UINT8 *pucBuf = NULL;
    char   acFilePathName[64] = {"ata/cali/PaDacSet.txt"};
    UINT32 calcCrc32 = 0;
    UINT32 loop = 0;

    fileLen = BspGetFileLen("ata/cali/PaDacSet.txt");
    if((BSP_ERROR == fileLen)||(ERROR_NULL_POINTER == fileLen))
    {
         dbgErr("portId %d get rftbl %d failed\n", portId, tblType);
         return BSP_ERROR;
    }
    pucBuf = malloc(fileLen);
    if(NULL == pucBuf)
    {
        return BSP_ERROR;
    }
    memset_s(pucBuf, fileLen, 0, fileLen);
    if (BSP_OK != BspLoadFile(acFilePathName, (CHAR *)pucBuf, &fileLen))
    {
        free(pucBuf);
        return BSP_ERROR;
    }
    for(loop = 0; loop < fileLen; loop++)
    {
        dbgInfoEx("0x%02x ",pucBuf[loop]);
        if(7 == loop%8)
        {
            dbgInfoEx("\n");
        }
    }
    dbgInfoEx("\n");
    calcCrc32 = BspCountCrc32(CRC32_INIT_VAL, pucBuf, fileLen);
    rfTblReq.fileSize  = fileLen;  /*这里正式流程应该是先读本地文件，如果没有 传0  送下去比对 */
    rfTblReq.crc32 = calcCrc32;
    rfTblReq.reserve[0] = tblType;
    retVal = OokMsgRfTblDownLoadReq(portId, &rfTblReq, &rfTblReqAck);

    free(pucBuf);
    return retVal;
}

/*0x7 离线表下载*/
UINT32 BspOokRfTblDownLoad(UINT32 portId, UINT32 tblType)
{
    T_OokMsgRfTblDownLoad rfTbl = {0};
    T_OokMsgRfTblDownLoadAck rfTblAck = {0};
    T_OokMsgRfTblDownLoadReq rfTblReq = {0};
    T_OokMsgRfTblDownLoadReqAck downReq = {0};
    UINT32 packNum = 0;
    UINT32 fileLen = 0;
    UINT8 *pucBuf = NULL;
    UINT32 calcCrc32 = 0;
    UINT32 retVal = BSP_OK;
    UINT32 loop = 0;
    UINT32 exLen = 0;
    UINT32 loopEx = 0;
    INT32  snprtRet = 0;
    char tmpFilePathName[64] = {0};
    CHAR fileTemp[64] = {0};
    CHAR uSysCmd[64] = {0};
    CHAR tmpFileName[64] = {"ata/cali/SscEmbedLut.bin"};

    if(13 == tblType)
    {
        snprtRet = snprintf_s(fileTemp, sizeof(fileTemp), "%s%d%s\0", s_acFilePathName[tblType], portId+2, ".bin");
        SNPRINTF_S_CHECK(snprtRet, sizeof(fileTemp));
        if(BSP_OK != BspIsFileExist(fileTemp))
        {
            dbgErr("%s is not exist\n", fileTemp);
            return BSP_ERROR;
        }
        snprtRet |= snprintf_s(tmpFilePathName, sizeof(tmpFilePathName), "%s%d%s\0", s_acFilePathName[tblType], portId+2, ".tar");
        snprtRet |= snprintf_s(uSysCmd, sizeof(uSysCmd), "mv %s %s",fileTemp, tmpFileName);
        BspSystem(uSysCmd);
        snprtRet |= snprintf_s(uSysCmd, sizeof(uSysCmd), "tar -jcvf %s %s\0", tmpFilePathName, tmpFileName);
        SNPRINTF_S_CHECK(snprtRet, sizeof(uSysCmd));
        BspSystem(uSysCmd);

        snprtRet = snprintf_s(uSysCmd, sizeof(uSysCmd), "rm -rf %s", tmpFileName);
        BspSystem(uSysCmd);
    }
    else
    {
        snprtRet = snprintf_s(tmpFilePathName, sizeof(tmpFilePathName), "%s%d%s\0", s_acFilePathName[tblType], portId+2, ".txt");
    }

    SNPRINTF_S_CHECK(snprtRet, sizeof(tmpFilePathName));
    dbgInfoEx("%s\n",tmpFilePathName);

    fileLen = BspGetFileLen(tmpFilePathName);
    if((BSP_ERROR == fileLen)||(ERROR_NULL_POINTER == fileLen))
    {
         dbgErr("portId %d get rftbl %d failed\n", portId, tblType);
         return BSP_ERROR;
    }
    pucBuf = (UINT8 *)malloc(fileLen);
    INPUT_POINTER_CHECK(pucBuf);
    memset_s(pucBuf, fileLen, 0, fileLen);
    if (BSP_OK != BspLoadFile(tmpFilePathName, (CHAR *)pucBuf, &fileLen))
    {
        free(pucBuf);
        return BSP_ERROR;
    }
    calcCrc32 = BspCountCrc32(CRC32_INIT_VAL, pucBuf, fileLen);

    rfTblReq.fileSize  = fileLen;  /*这里正式流程应该是先读本地文件，如果没有 传0  送下去比对 */
    rfTblReq.crc32 = calcCrc32;
    rfTblReq.tblType = tblType;
    retVal = OokMsgRfTblDownLoadReq(portId, &rfTblReq, &downReq);
    if(BSP_OK != retVal)
    {
        dbgErr("port %d download ook failed\n", portId);
        free(pucBuf);
        return retVal;
    }

    if(1 == downReq.compareResult)  /*比对不一样 需要下载校准表*/
    {
        packNum = fileLen/RFTBL_BITNUM_PER_PACK;
        dbgInfoEx("fileLen %d rfTblCrc %d packNum %d\n",fileLen, calcCrc32, packNum);
        exLen = fileLen%RFTBL_BITNUM_PER_PACK;
        for(loop = 0; loop < packNum; loop++)
        {
            rfTbl.dataOffset = 0 + loop*RFTBL_BITNUM_PER_PACK;
            rfTbl.dataSize = RFTBL_BITNUM_PER_PACK;
            rfTbl.fileType = tblType;
            memcpy_s(&rfTbl.data, RFTBL_BITNUM_PER_PACK, &pucBuf[loop*RFTBL_BITNUM_PER_PACK] ,RFTBL_BITNUM_PER_PACK);
            dbgInfoEx("\n");
            dbgInfoEx("********************pack num %d********************\n",loop);
            for(loopEx = 0; loopEx < RFTBL_BITNUM_PER_PACK; loopEx++)
            {
                dbgInfoEx("0x%02x ",rfTbl.data[loopEx]);
                if(7 == loopEx%8)
                {
                    dbgInfoEx("\n");
                }
            }
            dbgInfoEx("\n");
            retVal = OokMsgRfTblDownLoad(portId, &rfTbl, &rfTblAck);
            if(BSP_OK != retVal)
            {
                dbgErr("port %d  loop %d ook failed\n", portId, loop);
                free(pucBuf);
                return retVal;
            }
            BspSysMsDelay(1000);
        }
        dbgInfoEx("\n");
        dbgInfoEx("********************final pack********************\n");
        rfTbl.dataOffset = fileLen - exLen;
        if(rfTbl.dataOffset > 0)
        {
            rfTbl.dataSize = exLen;
            memcpy_s(&rfTbl.data, exLen, &pucBuf[fileLen - exLen] ,exLen);
            for(loopEx = 0; loopEx < exLen; loopEx++)
            {
                dbgInfoEx("0x%02x ",rfTbl.data[loopEx]);
            }
            dbgInfoEx("\n");
            retVal = OokMsgRfTblDownLoad(portId, &rfTbl, &rfTblAck);
            if(BSP_OK != retVal)
            {
                dbgErr("port %d ook failed\n", portId);
                free(pucBuf);
                return retVal;
            }
        }
    }

    free(pucBuf);
    return retVal;
}

/*0x8 离线表上传请求*/
UINT32 BspOokRfTblUpLoadReq(UINT32 portId, UINT32 tblType , T_OokMsgRfTblUpLoadReqAck *pRfTblReqAck)
{
    T_OokMsgRfTblUpLoadReq rfTblReq = {0};
    UINT32 retVal = BSP_OK;
    UINT32 fileLen = 0;
    UINT8 *pucBuf = NULL;
    UINT32 calcCrc32 = 0;
    UINT32 loop = 0;
    INT32  snprtRet = 0;
    char tmpFilePathName[64] = {0};


    INPUT_POINTER_CHECK(pRfTblReqAck);
    if(13 == tblType)
    {
        snprtRet = snprintf_s(tmpFilePathName, sizeof(tmpFilePathName), "%s%d%s\0", s_acFilePathName[tblType], portId+2, ".tar");
    }
    else
    {
        snprtRet = snprintf_s(tmpFilePathName, sizeof(tmpFilePathName), "%s%d%s\0", s_acFilePathName[tblType], portId+2, ".txt");
    }
    SNPRINTF_S_CHECK(snprtRet, sizeof(tmpFilePathName));
    dbgInfoEx("%s\n",tmpFilePathName);
    fileLen = BspGetFileLen(tmpFilePathName);
    if((BSP_ERROR == fileLen)||(ERROR_NULL_POINTER == fileLen) || 0 == fileLen)    /*存在fileLen=0的场景，接无离线文件的子端会出现*/
    {
        dbgErr("portId %d get rftbl %d failed\n", portId, tblType);
        calcCrc32 = 0;
        fileLen = 0;
        retVal = RFTBL_NON_EXISTENT;    /*上传过程母端没有文件&母端有文件，文件为空，也需要进行上传流程，返回值区分*/
    }
    else
    {
        pucBuf = malloc(fileLen);
        if(NULL == pucBuf)
        {
            return BSP_ERROR;
        }
        memset_s(pucBuf, fileLen, 0, fileLen);
        if (BSP_OK != BspLoadFile(tmpFilePathName, (CHAR *)pucBuf, &fileLen))
        {
            free(pucBuf);
            return BSP_ERROR;
        }
        for(loop = 0; loop < fileLen; loop++)
        {
            dbgInfoEx("0x%02x ",pucBuf[loop]);
            if(7 == loop%8) /*一行8个*/
            {
                dbgInfoEx("\n");
            }
        }
        dbgInfoEx("\n");
        calcCrc32 = BspCountCrc32(CRC32_INIT_VAL, pucBuf, fileLen);
    }

    rfTblReq.fileSize = fileLen;  /*这里正式流程应该是先读本地文件，如果没有 传0  送下去比对 */
    rfTblReq.crc32 = calcCrc32;
    rfTblReq.tblType = tblType;
    retVal |= OokMsgRfTblUpLoadReq(portId, &rfTblReq, pRfTblReqAck);

    free(pucBuf);
    if(BSP_OK != retVal)
    {
        dbgErr("port %d uploadreq ook failed\n", portId);
    }

    return retVal;
}

/*0x9 离线表上传*/
UINT32 BspOokRfTblUpLoad(UINT32 portId, UINT32 tblType)
{
    T_OokMsgRfTblUpLoad rfTbl = {0};
    T_OokMsgRfTblUpLoadAck rfTblAck = {0};
    UINT32 retVal = BSP_OK;
    UINT32 loop = 0;
    UINT32 fileLen = 0;
    UINT32 exLen = 0;
    T_OokMsgRfTblUpLoadReqAck upReq = {0};
    UINT8 *pucBuf = NULL;
    UINT32 rfTblCrc = 0;
    UINT32 packNum = 0;
    UINT32 loopEx = 0;
    FILE *fp = NULL;
    INT32 snprtRet = 0;
    CHAR acFilePathName[64] = {0};

    retVal = BspOokRfTblUpLoadReq(portId, tblType, &upReq);

    if(1 == upReq.compareResult || RFTBL_NON_EXISTENT == retVal)  /*比对不一样跟母端没有文件 需要下载校准表*/
    {
        fileLen = upReq.fileSize;
        pucBuf = (UINT8*)malloc(fileLen);
        INPUT_POINTER_CHECK(pucBuf);
        memset(pucBuf,0,fileLen);
        rfTblCrc = upReq.crc32;
        packNum = fileLen/RFTBL_BITNUM_PER_PACK;
        dbgInfoEx("fileLen %d rfTblCrc %d packNum %d\n",fileLen, rfTblCrc, packNum);
        /*整包数据*/
        for(loop = 0; loop < packNum; loop++)
        {
            rfTbl.dataOffset = loop*RFTBL_BITNUM_PER_PACK;
            rfTbl.dataSize = RFTBL_BITNUM_PER_PACK;
            rfTbl.tblType = tblType;
            retVal = OokMsgRfTblUpLoad(portId, &rfTbl, &rfTblAck);
            if(BSP_OK != retVal)
            {
                dbgErr("port %d  loop %d ook failed\n", portId, loop);
                free(pucBuf);
                return retVal;
            }
            /*子端回的消息里  dataOffset 和datasize的作用是什么 不应该和下发的一样吗*/
            memcpy_s(&pucBuf[loop*RFTBL_BITNUM_PER_PACK],RFTBL_BITNUM_PER_PACK, rfTblAck.data, rfTblAck.dataSize);
            dbgInfoEx("\n");
            dbgInfoEx("********************pack num %d********************\n",loop);
            for(loopEx = 0; loopEx < RFTBL_BITNUM_PER_PACK; loopEx++)
            {
                dbgInfoEx("0x%02x ",rfTblAck.data[loopEx]);
            }
            BspSysMsDelay(1000);
            dbgInfoEx("\n");
        }
        exLen = fileLen%RFTBL_BITNUM_PER_PACK;
        /*不足一包的数据*/
        dbgInfoEx("\n");
        dbgInfoEx("********************final pack********************\n");
        if(exLen > 0)
        {
            rfTbl.dataOffset = fileLen - exLen;
            rfTbl.dataSize = exLen;
            retVal = OokMsgRfTblUpLoad(portId, &rfTbl, &rfTblAck);
            if(BSP_OK != retVal)
            {
                dbgErr("port %d  loop %d ook failed\n", portId, loop);
                free(pucBuf);
                return retVal;
            }
            /*子端回的消息里  dataOffset 和datasize的作用是什么 不应该和下发的一样吗*/
            memcpy_s(&pucBuf[fileLen - exLen],exLen, rfTblAck.data, rfTblAck.dataSize);
            dbgInfo("%c  fileLen %d exLen %d\n", pucBuf[0], fileLen,exLen);
            for(loopEx = 0; loopEx < exLen; loopEx++)
            {
                dbgInfoEx("0x%02x ",rfTblAck.data[loopEx]);
                if(7 == loopEx%8) /*一行8个*/
                {
                    dbgInfoEx("\n");
                }
            }
            dbgInfoEx("\n");
        }
    }
    else
    {
       dbgInfo("not need upload\n");
#ifdef _BSP_WITH_WFS
       return BSP_OK;   /*工装要校验这里的返回值*/
#else
       return BSP_INVALID_VALUE;
#endif
    }

    if(13 == tblType)
    {
        snprtRet = snprintf_s(acFilePathName, sizeof(acFilePathName), "%s%d%s\0", s_acFilePathName[tblType], portId+2, ".tar");
    }
    else
    {
        snprtRet = snprintf_s(acFilePathName, sizeof(acFilePathName), "%s%d%s\0", s_acFilePathName[tblType], portId+2, ".txt");
    }
    SNPRINTF_S_CHECK(snprtRet, sizeof(acFilePathName));
    dbgInfoEx("%s\n",acFilePathName);
    if(0 == fileLen)
    {   /*防止产生大小为0的文件，此时校准表加载不报错*/
        dbgInfo("%s file %s fileLen is 0\n", __FUNCTION__, acFilePathName);
        free(pucBuf);
        return BSP_ERROR;
    }
    fp = fopen(acFilePathName, "w+");
    if (NULL == fp)
    {
        dbgInfo("%s fopen file %s failed\n", __FUNCTION__, acFilePathName);
        free(pucBuf);
        return BSP_ERROR;
    }
    if (-1 == fwrite(pucBuf,1,fileLen,fp))
    {
        dbgInfo("%s fwrite file Fail \n",__FUNCTION__);
        free(pucBuf);
        (void)fclose(fp);
        return BSP_ERROR;
    }
    free(pucBuf);
    (void)fclose(fp);

    return retVal;
}


UINT32 BspOokCmd(UINT32 portId, char *pCmd)
{
    UINT32 retVal = BSP_OK;
    UINT32 len = 0;

    OOK_PORTID_CHECK(portId);
    INPUT_POINTER_CHECK(pCmd);
    len = strlen(pCmd);
    if(len >= OOK_CMD_MAX_LEN)
    {
        dbgErr("cmd is too long, not support\n");
        return BSP_ERROR;
    }
    retVal = OokMsgCmd(portId,pCmd);
    return retVal;
}

UINT32 ookcmd(UINT32 portId, char *pCmd)
{
    UINT32 retVal = BSP_OK;
    OOK_PORTID_CHECK(portId);
    INPUT_POINTER_CHECK(pCmd);
    retVal = BspOokCmd(portId,pCmd);
    return retVal;
}

/*获取9124子端版本头信息 二次解压后的版本*/
UINT32 BspGetSlaveVerHeadInfo(UINT32 verType, T_PkgVerInfo *pPkgVerInfo)
{
    CHAR   acFilePathName[][64] = {
           "tmpmcu.swv",
           "tmpepld.swv",
    };
    CHAR tmpFilePathName[64] = {0};
    T_PkgVerInfo pkgVerInfo = {0};
    FILE *pf = NULL;
    INT32  lSnpRet = 0;
    UINT32 iReadLen = 0;
    UINT32 ulDataLen = 0;

    memcpy_s(&tmpFilePathName, sizeof(tmpFilePathName), &acFilePathName[verType],sizeof(tmpFilePathName));
    dbgInfoEx("%s\n",tmpFilePathName);

    pf = fopen(tmpFilePathName, "rb");
    if(NULL == pf)
    {
        dbgInfoEx("%s open file %s error!\n",__FUNCTION__ ,tmpFilePathName);
        return BSP_ERROR;
    }
    if(fseek(pf, 0 ,SEEK_SET) != 0)/*MCU 一次打包的头起始位置*/
    {
        lSnpRet = fclose(pf);
        FCLOSE_CHECK(lSnpRet);
        return BSP_ERROR;
    }
    ulDataLen =  sizeof(T_VerFileHeader);  /*MCU 一次打包的头长度*/
    iReadLen = fread((VOID *)&pkgVerInfo.tVerHeadInfo, 1, sizeof(T_VerFileHeader), pf);
    lSnpRet = fclose(pf);
    FCLOSE_CHECK(lSnpRet);
    if (iReadLen != (int)ulDataLen)
    {
       dbgErr("%s>>File Read Error! VerLen = 0x%x, ReadLen = 0x%x.\n",
              __FUNCTION__, ulDataLen, iReadLen);
       return BSP_ERROR;
    }
    pkgVerInfo.tVerHeadInfo.ulCRC32          = ntohl(pkgVerInfo.tVerHeadInfo.ulCRC32);
    pkgVerInfo.tVerHeadInfo.usVerType        = ntohs(pkgVerInfo.tVerHeadInfo.usVerType);
    pkgVerInfo.tVerHeadInfo.ulCompressedSize = ntohl(pkgVerInfo.tVerHeadInfo.ulCompressedSize);
    pkgVerInfo.tVerHeadInfo.ulCompressedCRC  = ntohl(pkgVerInfo.tVerHeadInfo.ulCompressedCRC);
    pkgVerInfo.tVerHeadInfo.ulOriginalSize   = ntohl(pkgVerInfo.tVerHeadInfo.ulOriginalSize);
    pkgVerInfo.tVerHeadInfo.ulOriginalCRC    = ntohl(pkgVerInfo.tVerHeadInfo.ulOriginalCRC);
    pkgVerInfo.tVerHeadInfo.ulCreateTime     = ntohl(pkgVerInfo.tVerHeadInfo.ulCreateTime);

    dbgInfoEx("File CRC:                             0x%x\n", pkgVerInfo.tVerHeadInfo.ulCRC32);
    dbgInfoEx("File VerType:                         0x%x\n",  pkgVerInfo.tVerHeadInfo.usVerType);
    dbgInfoEx("File Compressed Size:                 0x%x\n", pkgVerInfo.tVerHeadInfo.ulCompressedSize);
    dbgInfoEx("File Compressed CRC:                  0x%x\n", pkgVerInfo.tVerHeadInfo.ulCompressedCRC);
    dbgInfoEx("File Original Size:                   0x%x\n", pkgVerInfo.tVerHeadInfo.ulOriginalSize);
    dbgInfoEx("File Original CRC:                    0x%x\n", pkgVerInfo.tVerHeadInfo.ulOriginalCRC);
    dbgInfoEx("File Create time:                     %d\n",   pkgVerInfo.tVerHeadInfo.ulCreateTime);
    dbgInfoEx("File VerNo:                           %s\n",   pkgVerInfo.tVerHeadInfo.ucVerNo);
    if(NULL != pPkgVerInfo)   /*传空指针时当维测接口使用*/
    {
        memcpy_s(pPkgVerInfo, sizeof(T_PkgVerInfo), &pkgVerInfo,sizeof(T_PkgVerInfo));
    }

    return BSP_OK;
}

/*0xb版本比对*/
UINT32 BspOokMsgVerCmp(UINT32 portId, T_OokMsgVerCmp *pTmpCmp)
{
    UINT32 retVal = BSP_OK;
    T_OokMsgVerCmp verCmp = {0};
    T_OokMsgVerCmpAck verCmpAck = {0};
    T_PkgVerInfo pkgVerInfo[E_SLAVE_VER_NUM] = {0};

    OOK_PORTID_CHECK(portId);
    /*第一步判断是否屏蔽了版本比对*/
    retVal = BspIsFileExist("/ata/slavenoupgradeversion");
#ifdef _BSP_WITH_WFS
    retVal = BspIsFileExist("/ata/BSP/slavenoupgradeversion");      /*工装版本使用此路径*/
#endif
    if(BSP_OK == retVal)
    {
        dbgInfo("test mode, no need update slave verison\n");
        if(NULL != pTmpCmp)  /*入参为空指针时为调试接口*/
        {
           memset_s(pTmpCmp, sizeof(T_OokMsgVerCmp), 0,  sizeof(T_OokMsgVerCmp));
        }
        return BSP_OK;
    }
    /*第二步获取子端cpu版本基本信息*/
    retVal = BspGetSlaveVerHeadInfo(E_MCU_VER,&pkgVerInfo[E_MCU_VER]);
    if(BSP_OK == retVal)  /*首先保证版本解析正常 才能有后续流程*/
    {
        if(BSP_OK != strcmp((const char *)pkgVerInfo[E_MCU_VER].tVerHeadInfo.ucVerNo, g_cpuVer[portId]))
        {
            verCmp.cpuCmpResult = 1;
            verCmp.cpuCrc32 = pkgVerInfo[E_MCU_VER].tVerHeadInfo.ulOriginalCRC;
            memcpy_s(verCmp.cpuVer, sizeof(verCmp.cpuVer), pkgVerInfo[E_MCU_VER].tVerHeadInfo.ucVerNo, sizeof(pkgVerInfo[E_MCU_VER].tVerHeadInfo.ucVerNo));
        }
        else
        {
            verCmp.cpuCmpResult = 0;
        }
    }
    /*第三步获取子端epld版本基本信息*/
    retVal = BspGetSlaveVerHeadInfo(E_EPLD_VER,&pkgVerInfo[E_EPLD_VER]);
    if(BSP_OK == retVal)  /*首先保证版本解析正常 才能有后续流程*/
    {
        if(BSP_OK != strcmp((const char *)pkgVerInfo[E_EPLD_VER].tVerHeadInfo.ucVerNo, g_fpgaVer[portId]))
        {
            verCmp.fpgaCmpResult = 1;
            verCmp.fpgaCrc32 =  pkgVerInfo[E_EPLD_VER].tVerHeadInfo.ulOriginalCRC;
            memcpy_s(verCmp.fpgaVer, sizeof(verCmp.fpgaVer), pkgVerInfo[E_EPLD_VER].tVerHeadInfo.ucVerNo, sizeof(pkgVerInfo[E_EPLD_VER].tVerHeadInfo.ucVerNo));
        }
        else
        {
            verCmp.fpgaCmpResult = 0;
        }
    }

    retVal = OokMsgVerCmp(portId, &verCmp, &verCmpAck);
    if(BSP_OK != retVal)
    {
        dbgErr("OokMsgVerCmp failed\n");
        return retVal;
    }
    if(NULL != pTmpCmp)  /*入参为空指针时为调试接口*/
    {
       memcpy_s(pTmpCmp, sizeof(T_OokMsgVerCmp), &verCmp,  sizeof(T_OokMsgVerCmp));
    }

    return verCmpAck.ackData;
}

/*调试接口屏蔽版本下载和升级*/
void setversw(UINT32 flag)
{
   g_ulSlaveVerUpdateSw = flag;
}
/*版本下载*/
UINT32 BspOokVerDownLoad(UINT32 portId, UINT32 verType)
{
    T_OokMsgVerDownLoad verDown = {0};
    T_OokMsgVerDownLoadAck verDownAck = {0};
    UINT32 loop = 0;
    UINT32 fileLen = 0;
    UINT32 retVal = BSP_OK;
    UINT8 *pucBuf = NULL;
    UINT32 packNum = 0;
    UINT32 exLen = 0;
    UINT32 loopEx = 0;
    char tmpFilePathName[64] = {0};
    char acFilePathName[][64] = {
           "mcu.bit.bin",
           "epld.bit.bin",
           "sndboot.bit.bin",
    };

    memcpy_s(tmpFilePathName, sizeof(tmpFilePathName), &acFilePathName[verType],sizeof(tmpFilePathName));
    dbgInfoEx("%s\n",tmpFilePathName);
    BspLog(LOG_LEVEL_0, "portId %d  verType %d BspOokVerDownLoad \n", portId, verType);
    fileLen = BspGetFileLen(tmpFilePathName);
    if((BSP_ERROR == fileLen)||(ERROR_NULL_POINTER == fileLen))
    {
         dbgErr("portId %d get verType %d failed\n", portId, verType);
         return BSP_ERROR;
    }
    pucBuf = (UINT8 *)malloc(fileLen);
    if(NULL == pucBuf)
    {
        return BSP_ERROR;
    }
    memset_s(pucBuf, fileLen, 0, fileLen);
    if (BSP_OK != BspLoadFile(tmpFilePathName, (CHAR *)pucBuf, &fileLen))
    {
        free(pucBuf);
        return BSP_ERROR;
    }

    verDown.verType = verType;
    packNum = fileLen/RFTBL_BITNUM_PER_PACK;
    exLen = fileLen%RFTBL_BITNUM_PER_PACK;
    for(loop = 0; loop < packNum; loop++)
    {
        verDown.dataOffSet = 0 + loop*RFTBL_BITNUM_PER_PACK;
        verDown.dataSize = RFTBL_BITNUM_PER_PACK;
        memcpy_s(verDown.data, RFTBL_BITNUM_PER_PACK, &pucBuf[loop*RFTBL_BITNUM_PER_PACK] ,RFTBL_BITNUM_PER_PACK);
        if(1 == g_ulSlaveVerUpdateSw)
        {
            return BSP_ERROR;   /*调试接口停止升级*/
        }
        dbgInfoEx("\n");
        dbgInfoEx("********************pack num %d********************\n",loop);
        for(loopEx = 0; loopEx < RFTBL_BITNUM_PER_PACK; loopEx++)
        {
            dbgInfoEx("0x%02x %u",verDown.data[loopEx],pucBuf[loop*RFTBL_BITNUM_PER_PACK+loopEx]);
            if(7 == loopEx%8)
            {
                dbgInfoEx("\n");
            }
        }
        dbgInfoEx("\n");
        retVal = OokMsgVerDownLoad(portId, &verDown, &verDownAck);
        if(BSP_OK != retVal)
        {
            dbgErr("port %d  loop %d ook failed\n", portId, loop);
            dbgInfoEx("\n");
            dbgInfo("********************pack num %d********************\n",loop);
            for(loopEx = 0; loopEx < RFTBL_BITNUM_PER_PACK; loopEx++)
            {
                dbgInfo("0x%02x %u",verDown.data[loopEx],pucBuf[loop*RFTBL_BITNUM_PER_PACK+loopEx]);
                if(7 == loopEx%8)
                {
                    dbgInfoEx("\n");
                }
            }
            dbgInfoEx("\n");
            free(pucBuf);
            return retVal;
        }
        //BspSysMsDelay(1000);
    }
    dbgInfoEx("\n");
    dbgInfoEx("********************final pack********************\n");
    verDown.dataOffSet = fileLen - exLen;
    if(verDown.dataOffSet > 0)
    {
    	verDown.dataSize = exLen;
        memcpy_s(verDown.data, exLen, &pucBuf[fileLen - exLen] ,exLen);
        for(loopEx = 0; loopEx < exLen; loopEx++)
        {
            dbgInfoEx("0x%02x ",verDown.data[loopEx]);
            if(7 == loopEx%8)
            {
                dbgInfoEx("\n");
            }
        }
        dbgInfoEx("\n");
        retVal = OokMsgVerDownLoad(portId, &verDown, &verDownAck);
        if(BSP_OK != retVal)
        {
            dbgErr("port %d ook failed\n", portId);
            free(pucBuf);
            return retVal;
        }
    }

    free(pucBuf);
    return BSP_OK;
}

/*版本激活 0:不激活 1:激活*/
UINT32 BspOokMsgVerAct(UINT32 portId, UINT32 cpuFlag, UINT32 fpgaFlag, UINT32 secBootFlag)
{
    T_OokMsgVerAct verAct = {0};
    T_OokMsgVerActAck verActAck = {0};
    UINT32 retVal = BSP_OK;

    dbgInfoEx("portId %d cpuFlag %d fpgaFlag %d secBootFlag %d\n", portId, cpuFlag, fpgaFlag, secBootFlag);
    /*两个版本都正常下载才能下发激活 或者只下载了一个版本，另一个版本不用更新*/
    verAct.cpuVerActFlag = cpuFlag;
    verAct.fpgaVerActFlag = fpgaFlag;
    verAct.secBootVerActFlag = secBootFlag;
    retVal = OokMsgVerActive(portId, &verAct, &verActAck);
    if((BSP_OK == retVal)&&(BSP_OK == verActAck.ackData))
    {
        return BSP_OK;
    }

    return BSP_ERROR;
}

static UINT32 BspOokGetSlaveRruInfo(UINT32 portId)
{
    T_OokMsgGetRruInfoAck info = {0};
    UINT32 retVal = BSP_OK;

    retVal = OokMsgSlaveGetRruInfo(portId, &info);
    if((BSP_OK != retVal)||(BSP_OK != info.ackData))
    {
        return BSP_ERROR;
    }
    BspSaveSlavePortBaseInfo(portId, 0 ,E_SLAVE_RRUINFO, (void*)&info);

    return BSP_OK;
}

static UINT32 BspOokGetSlavePwrInfo(UINT32 portId)
{
    T_OokMsgGetPwrInfoAck info = {0};
    UINT32 retVal = BSP_OK;

    retVal = OokMsgSlaveGetPwrInfo(portId, &info);
    if((BSP_OK != retVal)||(BSP_OK != info.ackData))
    {
        return BSP_ERROR;
    }
    BspSaveSlavePortBaseInfo(portId, 0 ,E_SLAVE_PWRINFO, (void*)&info);

    return BSP_OK;
}

static UINT32 BspOokGetSlaveDflInfo(UINT32 portId, UINT8 index)
{
    T_OokMsgGetDflInfoAck info = {0};
    UINT32 retVal = BSP_OK;

    retVal = OokMsgSlaveGetDflInfo(portId, index, &info);
    if((BSP_OK != retVal)||(BSP_OK != info.ackData))
    {
        return BSP_ERROR;
    }
    BspSaveSlavePortBaseInfo(portId, index, E_SLAVE_DFLINFO, (void*)&info);

    return BSP_OK;
}

static UINT32 BspOokGetSlavePaInfo(UINT32 portId)
{
    T_OokMsgGetPaInfoAck info = {0};
    UINT32 retVal = BSP_OK;

    retVal = OokMsgSlaveGetPaInfo(portId, &info);
    if((BSP_OK != retVal)||(BSP_OK != info.ackData))
    {
        return BSP_ERROR;
    }
    BspSaveSlavePortBaseInfo(portId, 0 ,E_SLAVE_PAINFO, (void*)&info);

    return BSP_OK;
}

UINT32 BspUpdataSlavePortVerByOok(UINT32 portId)
{
    T_OokMsgVerCmp verCmp = {0};
    UINT32 retVal = BSP_OK;
    UINT32 cpuFlag = 0;
    UINT32 fpgaFlag = 0;
    UINT32 sw = 0;
    UINT32 loop = 0;
    UINT32 maxCmpCnt = 5;
    UINT32 chanNum = 0;
    UINT32 chanInfo[2] = {0};

    OOK_PORTID_CHECK(portId);
    (VOID)BspRegBitValRd(0, REG_2T4T_SW, 0, 0, 0, &sw);  /*1 表示非拉远*/
    if((0 == portId)&&(1 == sw))
    {
        dbgInfoEx("portId %d master\n", portId);  /*A端口由拉远切到不拉远*/
        BspOokGetSlaveRruInfo(portId);
        BspOokGetSlavePwrInfo(portId);
        BspOokGetSlaveDflInfo(portId, 0);
        BspOokGetSlaveDflInfo(portId, 1);
        BspOokGetSlavePaInfo(portId);
        BspOokClrSlaveInitAlarm(portId);/*子端启动时先清一次同步帧异常 之前在子端*/
        return E_SLAVE_NOT_UPDATE;    /*A端口不配置又接着时保留检测建链，不需要校准表版本等流程*/
    }
    retVal |= BspGetBspChnByPortId(portId, TX, &chanNum, chanInfo);
    if((BSP_OK != retVal)||(portId >= 0xf))  /*portid为0xf表示异常 此通道无子端*/
    {
         return BSP_ERROR;
    }
    for(loop = 0; loop < maxCmpCnt; loop++)
    {
        retVal = BspOokMsgVerCmp(portId, &verCmp);
        if(BSP_OK != retVal)
        {
            dbgErr("portId %d BspOokMsgVerCmp failed\n", portId);
            BspLog(LOG_LEVEL_0,"portId %d BspOokMsgVerCmp failed\n", portId);
            BspSysMsDelay(500);
            continue;
        }
        break;
    }
    if(loop == maxCmpCnt)
    {
        return E_SLAVE_LINK_ERROR;   /*多次尝试消息还报错 认为子端此时异常了 去判断子端建链状态*/
    }
    if(0 == (verCmp.cpuCmpResult + verCmp.fpgaCmpResult))
    {
        BspSlavePortRfTblInitUpdate(portId);
        BspOokGetSlaveRruInfo(portId);
        BspOokGetSlavePwrInfo(portId);
        BspOokGetSlaveDflInfo(portId, 0);
        BspOokGetSlaveDflInfo(portId, 1);
        BspOokGetSlavePaInfo(portId);
        BspClrSlaveCableGain(chanInfo[0]);  /*针对子端重新上电要把上次保存的通道插损清除掉*/
        BspClrSlaveCableGain(chanInfo[1]);
        BspSetSlaveDsaAtt(chanInfo[0],1,1900);
        BspSetSlaveDsaAtt(chanInfo[1],1,2200);
        BspClrSlaveSlavedTestData(chanInfo[0]);
        BspClrSlaveSlavedTestData(chanInfo[1]);
        BspSetTxGain(chanInfo[0],4000);
        BspSetTxGain(chanInfo[1],4000);
        g_ulSlaveVerUpdateCnt[portId] = 0;  /*为下次准备*/
        BspSetSlavePaStatus(chanInfo[0], 0);/*子端上电完成状态上报前关闭子端射频开关*/
        BspSetSlavePaStatus(chanInfo[1], 0);
        BspSetSlaveLnaStatus(chanInfo[0], 0);
        BspSetSlaveLnaStatus(chanInfo[1], 0);
        BspPaDefaultVoltInitByChan(chanInfo[0]);
        BspPaDefaultVoltInitByChan(chanInfo[1]);
        BspOokSlaveTddCfg(portId);   /*先下发tdd配置信息 主要是帧头偏移量修改有影响 帧结构不影响 放到子端初始化标志完成之前*/
        BspSysMsDelay(200);
        BspOokClrSlaveInitAlarm(portId);/*子端启动时先清一次同步帧异常 之前在子端*/
        g_ulSlavePortInitSta[portId] = 0;   /*版本升级正常+校准表已上传*/
        BspLog(LOG_LEVEL_0, "portId %d E_SLAVE_NOT_UPDATE0 \n", portId);
        return E_SLAVE_NOT_UPDATE;   /*不需要升级*/
    }
    if(g_ulSlaveVerUpdateCnt[portId] >= MAX_SLAVE_VER_UPDATE_CNT)  /*一次上电的过程 最多尝试三次版本升级*/
    {
        BspSlavePortRfTblInitUpdate(portId);
        BspOokGetSlaveRruInfo(portId);
        BspOokGetSlavePwrInfo(portId);
        BspOokGetSlaveDflInfo(portId, 0);
        BspOokGetSlaveDflInfo(portId, 1);
        BspOokGetSlavePaInfo(portId);
        BspClrSlaveCableGain(chanInfo[0]); /* 针对子端重新上电要把上次保存的通道插损清除掉*/
        BspClrSlaveCableGain(chanInfo[1]);
        BspSetSlaveDsaAtt(chanInfo[0],1,1900);
        BspSetSlaveDsaAtt(chanInfo[1],1,2200);
        BspClrSlaveSlavedTestData(chanInfo[0]);
        BspClrSlaveSlavedTestData(chanInfo[1]);
        BspSetTxGain(chanInfo[0],4000);
        BspSetTxGain(chanInfo[1],4000);
        BspSetSlavePaStatus(chanInfo[0], 0);/*子端上电完成状态上报前关闭子端射频开关*/
        BspSetSlavePaStatus(chanInfo[1], 0);
        BspSetSlaveLnaStatus(chanInfo[0], 0);
        BspSetSlaveLnaStatus(chanInfo[1], 0);
        BspPaDefaultVoltInitByChan(chanInfo[0]);
        BspPaDefaultVoltInitByChan(chanInfo[1]);
        BspOokSlaveTddCfg(portId);   /*先下发tdd配置信息 主要是帧头偏移量修改有影响 帧结构不影响 放到子端初始化标志完成之前*/
        BspSysMsDelay(200);
        BspOokClrSlaveInitAlarm(portId);/*子端启动时先清一次同步帧异常 之前在子端*/
        g_ulSlavePortInitSta[portId] = 0;  /*版本升级多次还不正常+校准表已上传*/
        g_ulSlaveVerUpdateCnt[portId] = 0; /*为插拔子端和更换子端做准备*/
        BspLog(LOG_LEVEL_0, "portId %d E_SLAVE_NOT_UPDATE1 \n", portId);
        return E_SLAVE_NOT_UPDATE;   /*多次升级还失败 和发哥确认也进心跳流程*/
    }
    g_ulSlaveVerUpdateCnt[portId]++;
    if(verCmp.cpuCmpResult == 1)
    {
        dbgInfo("***********portId %d mcu download start*********\n", portId);
        retVal = BspOokVerDownLoad(portId, E_MCU_VER);
        dbgInfo("***********portId %d mcu download end*********\n", portId);
        if(BSP_OK == retVal)
        {
            cpuFlag = 1;
        }
    }
    if(verCmp.fpgaCmpResult == 1)
    {
        dbgInfo("***********portId %d epld download start*********\n", portId);
        retVal = BspOokVerDownLoad(portId, E_EPLD_VER);
        dbgInfo("***********portId %d epld download end*********\n", portId);
        if(BSP_OK == retVal)
        {
           fpgaFlag = 1;
        }
    }
    dbgInfo("portId %d cpuFlag %d fpgaFlag %d\n", portId, cpuFlag, fpgaFlag);
    BspLog(LOG_LEVEL_0, "portId %d cpuFlag %d fpgaFlag %d\n", portId, cpuFlag, fpgaFlag);
    if(0 == (cpuFlag + fpgaFlag))
    {
        dbgErr("portId %d BspOokVerDownLoad both failed\n", portId);
        BspLog(LOG_LEVEL_0, "portId %d BspOokVerDownLoad both failed\n", portId);
        return E_SLAVE_NEED_UPDATE;
    }
    retVal = BspOokMsgVerAct(portId, cpuFlag, fpgaFlag, 0);
    BspLog(LOG_LEVEL_0, "portId %d after BspOokMsgVerAct retVal %d \n", portId, retVal);
    BspSysMsDelay(20000);  /*激活之后子端会重启 消息会断 预留子端重启的时间*/

    return E_SLAVE_LINK_ERROR;
}

UINT32 BspGetSlavePortVerStatus(UINT32 portId)
{
    OOK_PORTID_CHECK(portId);
    if((g_ulSlaveVerUpdateCnt[portId] < MAX_SLAVE_VER_UPDATE_CNT)&&(g_ulSlavePortInitSta[portId] == 0))
    {
        return BSP_OK;
    }
    return BSP_ERROR;
}
/*子端时延测量*/
UINT32 BspOokSlaveDlyMeasure(UINT32 portId, UINT32 act)
{
    T_OokMsgDlyMeas tmpMsg = {0};
    T_OokMsgDlyMeasAck tmpAck = {0};
    UINT32 retVal = BSP_OK;

    tmpMsg.action = act;
    retVal = OokMsgDlyMeasure(portId, &tmpMsg, &tmpAck);
    if(BSP_OK != retVal)
    {
        dbgErr("BspOokSlaveDlyMeasure portId %d failed\n", portId);
        return BSP_ERROR;
    }
    if(BSP_OK != tmpAck.ackData)
    {
        return BSP_ERROR;
    }

    return retVal;
}

/*子端复位*/
UINT32 BspOokSetSlaveReset(UINT32 portId)
{
     T_OokMsgReset tmpMsg = {0};
     T_OokMsgResetAck tmpAck = {0};
     UINT32 retVal = BSP_OK;

     if(portId >= OOK_MAX_PORTID)
     {
         return BSP_ERROR;
     }
     tmpMsg.rstType = 1;    /*这里1表示软复位 只有此处使用不再单独定义宏*/
     retVal = OokMsgSlaveReset(portId, &tmpMsg, &tmpAck);
     BspLog(LOG_LEVEL_0, "BspOokSetSlaveReset port %d \n", portId);
     g_ulSlavePortLinkSta[portId] = 1;   /*子端有复位时将子端的状态置为初始态*/
     g_ulSlavePortInitSta[portId] = 2;

     return retVal;
}

/*0x11子端波束配置*/
UINT32 BspOokSlaveBeamCfg(UINT32 portId, UINT32 beamWidth)
{
    T_OokMsgBeamCfg tmpMsg = {0};
    T_OokMsgBeamCfgAck tmpAck = {0};
    UINT32 retVal = BSP_OK;

    tmpMsg.beamWidth = beamWidth;
    retVal = OokMsgSlaveBeamCfg(portId, &tmpMsg, &tmpAck);
    if(BSP_OK != retVal)
    {
        dbgErr("BspOokSlaveBeamCfg portId %d failed\n", portId);
        return BSP_ERROR;
    }
    if(BSP_OK != tmpAck.ackData)
    {
        return BSP_ERROR;
    }

    return retVal;
}

/******************************子端上电初始化*****************************************
* 1解压子端版本--放在母端上电初始化处理BspLoadSlaveMcuEpldVersion
* 2建链 --建链状态获取正常
* 3 版本比对 升级
***********************************************************************************/
UINT32 BspSlavePortBuildLink(UINT32 portId)
{
    UINT32 retVal = BSP_OK;
    UINT32 sw = 0;
    UINT32 maxLinkTry = 6;  /*最大尝试建链次数*/
    T_OokMsgLinkStaAck tmpSta = {0};
    UINT32 loop = 0;

#ifdef _BSP_WITH_WFS
    BspClrSlavePortSta(portId, 1);
#endif
    OOK_PORTID_CHECK(portId);
    g_ulSlavePortPmosAlm[portId].almState = 0;
    g_ulSlavePortPmosAlm[portId].almEvent = 0;
    (VOID)BspRegBitValRd(0, REG_2T4T_SW, 0, 0, 0, &sw);  /*1 表示非拉远*/
    for(loop = 0; loop < maxLinkTry; loop++)
    {
        retVal = BspOokgGetSlaveLinkSta(portId, &tmpSta);
        if((BSP_OK == retVal)&&(BSP_OK == tmpSta.ackData))
        {
            dbgInfoEx("portId %d linksta OK\n", portId);
            break;
        }
        if(loop >= MAX_SLAVE_VER_UPDATE_CNT)
        {
             g_ulSlaveVerUpdateCnt[portId] = 0;   /*多次检测断链再清 防止反复清 反复升级*/
        }
        BspSysMsDelay(5000);
        dbgInfoEx("portId %d loop %d\n", portId, loop);
    }
    if(loop == maxLinkTry)
    {
        g_ulSlavePortLinkSta[portId] = 1;  /*给高层上报断链*/
        g_ulSlavePortInitSta[portId] = 2;
#ifndef _BSP_WITH_WFS
        BspClrRfTblLoadStaBySlavePortCfg(portId);
#endif
        return E_SLAVE_LINK_ERROR;
    }
    g_ulSlavePortLinkSta[portId] = 0;  /*给高层上报建链 先不考虑校准表和版本处理*/
    if((0 == portId)&&(1 == sw))
    {
        return E_SLAVE_LINK_OK;     /*未配置但是接A子端 不上报子端校准表告警 因为此时23通道在母端*/
    }
#ifndef _BSP_WITH_WFS
    BspClrRfTblLoadStaBySlavePortCfg(portId);
#endif
    return E_SLAVE_LINK_OK;
}

/*子端上电初始化流程 */
UINT32 BspSlavePortInit(UINT32 portId)
{
    UINT32 retVal = BSP_OK;
    UINT32 linkSta = BSP_OK;

    linkSta = BspSlavePortBuildLink(portId);
    if(E_SLAVE_LINK_OK != linkSta)
    {
        return linkSta;     /*非拉远或者不建链不需要后续动作*/
    }
    BspLog(LOG_LEVEL_0, "portId %d startup\n", portId);  /*记录上电时刻*/
    retVal = BspUpdataSlavePortVerByOok(portId);
    if(E_SLAVE_NOT_UPDATE != retVal)   /* 需要升级版本 但是下载失败或者激活失败 需要直接返回 从头再来*/
    {
        return retVal;
    }
    /*校准表比对及上传 及解析 在线上电需要注意解析过程不能影响原有的表*/
    BspLog(LOG_LEVEL_0, "portId %d startend\n", portId);  /*记录上电完成时刻*/

    return E_SLAVE_NOT_UPDATE;
}

/*子端心跳监控*/
UINT32 BspSlavePortHeartMonitor(UINT32 portId)
{
    UINT32 retVal = BSP_OK;
    UINT32 currSta = BSP_ERROR;
    UINT32 maxLossCnt = 18;  /*心跳丢失最大次数为18 只有此处使用不再单独定义宏*/
    UINT32 sw = 0;
    UINT32 heartAfterReset = 4;

    OOK_PORTID_CHECK(portId);
    (VOID)BspRegBitValRd(0, REG_2T4T_SW, 0, 0, 0, &sw);  /*1 表示非拉远*/
    retVal = BspOokGetSlaveHeartBeat(portId, &currSta);
    if((BSP_OK == currSta)&&(BSP_OK == retVal))
    {
        g_ulHeartBeatLossCnt[portId] = 0;
        g_ulHeartBeatOkCnt[portId]++;
        if(g_ulHeartBeatOkCnt[portId] > maxLossCnt)
        {
            g_ulHeartBeatOkCnt[portId] = maxLossCnt;   /*不要反复配*/
        }
        if((0 == portId)&&(1 == sw))       /*A端口接着但是没配置  23在母端时不要检测子端的pmos告警*/
        {
            g_ulSlavePortPmosAlm[portId].almState = 0;
            g_ulSlavePortPmosAlm[portId].almEvent = 0;   /*原来配A端口接着有告警，现在去掉配置之后不管实际情况都不应该报 此时23在母端*/
            g_ulSlavePortLinkSta[portId] = 0;    /*误码导致心跳丢失后恢复，需要在此重新置建链状态*/
            return E_SLAVE_HEART_OK;
        }
#ifndef _BSP_WITH_WFS        /*工装版本实时获取 不用存储的*/
        T_SlavePortTempVolt tmp = {0};
        T_OokMsgAlmGetAck almSta = {0};
        BspOokGetSlaveAlarm(portId, &almSta);
        g_ulSlavePortPmosAlm[portId].almState = almSta.almState;
        g_ulSlavePortPmosAlm[portId].almEvent = almSta.almEvent;
        BspOokGetSlaveTempAndVolt(portId, &tmp);
#endif
        g_ulSlavePortLinkSta[portId] = 0;    /*误码导致心跳丢失后恢复，需要在此重新置建链状态*/
        return E_SLAVE_HEART_OK;
    }
    else
    {
        g_ulHeartBeatLossCnt[portId]++;
        g_ulHeartBeatOkCnt[portId] = 0;
    }
    if(heartAfterReset == currSta)
    {
        dbgInfoEx("portId %d reset but not again Link\n", portId);
        BspLog(LOG_LEVEL_0, "portId %d reset but not again Link\n", portId);
        g_ulSlavePortLinkSta[portId] = 1;  /*给高层上报断链*/
        g_ulSlavePortInitSta[portId] = 2;
        return E_SLAVE_HEART_ERROR;  /*子端在复位重启后重新发起建链前心跳回特殊字段 母端直接返回建链流程*/
    }
    if(g_ulHeartBeatLossCnt[portId] >= 2)   /*按SE要求 心跳丢失2次就给高层上报断链*/
    {
        g_ulSlavePortLinkSta[portId] = 1;  /*给高层上报断链*/
        g_ulSlavePortInitSta[portId] = 2;
    }
    if(g_ulHeartBeatLossCnt[portId] >= maxLossCnt)
    {
         g_ulHeartBeatLossCnt[portId] = maxLossCnt;
         g_ulSlavePortLinkSta[portId] = 1;  /*给高层上报断链*/
         g_ulSlavePortInitSta[portId] = 2;
         return E_SLAVE_HEART_ERROR;
    }

    return E_SLAVE_HEART_TMP_STA;
}

/*任务开关*/
void slaveinitsw(UINT32 portId, UINT32 sw)
{
    if(portId >= OOK_MAX_PORTID)
    {
        return;
    }
    g_ulSlaveInitThread[portId] = sw;
}

/*单个子端的初始化任务*/
static void* BspSlaveInitProcess(UINT32 portId)
{
    UINT32 state = E_SLAVE_LINK_ERROR;   /*初始态*/
    UINT32 nextState = 0;

    if(portId >= OOK_MAX_PORTID)
    {
        return NULL;
    }
    while(1)
    {
        if (2 == g_ulSlaveInitThread[portId])   /*调试使用 2表示退出任务 只有此处使用不再单独定义宏*/
        {
            break;
        }
        if(1 == g_ulSlaveInitThread[portId])    /*调试使用 1表示任务空转 只有此处使用不再单独定义宏*/
        {
            BspSysMsDelay(10000);
            continue;
        }
        dbgInfoEx("***************portId %d present state = %d ******************\n", portId, state);
        switch (state)
        {
            case E_SLAVE_LINK_ERROR:
            case E_SLAVE_HEART_ERROR:
            {
                nextState = BspSlavePortBuildLink(portId);
                break;
            }
            case E_SLAVE_LINK_OK:
            case E_SLAVE_NEED_UPDATE:
            {
                nextState = BspUpdataSlavePortVerByOok(portId);
                break;
            }
            case E_SLAVE_NOT_UPDATE:
            case E_SLAVE_HEART_OK:
            case E_SLAVE_HEART_TMP_STA:
            {
                nextState = BspSlavePortHeartMonitor(portId);   /*心跳异常时才转到BspSlavePortInit 其他都空转*/
                break;
            }
            default:
            {
                break;
            }
        }
        if(state != nextState)
        {
            BspLog(LOG_LEVEL_0, "BspSlaveInitProcess portId %d cursta %d nextsta %d\n", portId, state, nextState);
        }
        if(E_SLAVE_LINK_ERROR == nextState)
        {
            g_ulSlavePortLinkSta[portId] = 1;   /*高层5s一次 查询   子端复位让高层能感知到  另外A端口不拉远时在此置位*/
            g_ulSlavePortInitSta[portId] = 2;
        }
        state = nextState;
        BspSysMsDelay(10000);   /*10s监控一次心跳*/
    }

    return NULL;
}

/*子端上电初始化及心跳监控任务*/
UINT32 BspSlaveThreadInit(void)
{
    UINT32 ret = BSP_OK;
    INT32  taskId0 = 0;
    INT32  taskId1 = 0;
    INT32  taskId2 = 0;
    UINT32 taskStack = 10;

    BspSetSlaveGetPaProAlmFunc(BspGetSlavePastPaProAlm);
    BspSetSlavePaProAlmRecoverFunc(BspPaProSlaveAlmRecover);
    BspSetRfTblLoadSta(TBL_KIND_OF_TXFWDANALOG, 0,0);
    BspSetRfTblLoadSta(TBL_KIND_OF_TXFWDANALOG, 1,0);
    BspSetRfTblLoadSta(TBL_KIND_OF_TXREVANALOG, 0,0);
    BspSetRfTblLoadSta(TBL_KIND_OF_TXREVANALOG, 1,0);
    BspSetRfTblLoadSta(TBL_KIND_OF_FILTERGAIN, 1,0);
    BspSetRfTblLoadSta(TBL_KIND_OF_PABASICINFO, 1,0);
    BspSetRfTblLoadSta(TBL_KIND_OF_PAENSAVADJ,1,0);
    BspSetRfTblLoadSta(TBL_KIND_OF_PATEMPGAIN,1,0);
    BspInitSlaveRfTblLoadSta();

    taskId0 = taskSpawn("BspSlave0InitProcess", 90, 0, (1024 * taskStack),
                        (FUNCPTR)BspSlaveInitProcess, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
    if (BSP_ERROR == (UINT32)taskId0)
    {
        dbgErr("port 0 create thread<%s> failed!lErrcode:%d\n", __FUNCTION__, taskId0);
        ret = BSP_ERROR;
    }

    taskId1 = taskSpawn("BspSlave1InitProcess", 90, 0, (1024 * taskStack),
                        (FUNCPTR)BspSlaveInitProcess, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0);
    if (BSP_ERROR == (UINT32)taskId1)
    {
        dbgErr("port 1 create thread<%s> failed!lErrcode:%d\n", __FUNCTION__, taskId1);
        ret |= BSP_ERROR;
    }

    taskId2 = taskSpawn("BspSlave2InitProcess", 90, 0, (1024 * taskStack),
                        (FUNCPTR)BspSlaveInitProcess, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0);
    if (BSP_ERROR == (UINT32)taskId2)
    {
        dbgErr("port 2 create thread<%s> failed!lErrcode:%d\n", __FUNCTION__, taskId2);
        ret |= BSP_ERROR;
    }

    return ret;
}
/*0x10 tdd帧结构配置*/
UINT32 BspOokSlaveTddCfg(UINT32 portId )
{
    UINT32 retVal = BSP_OK;
    T_OokMsgTddCfgAck tddCfgAck = {0};
    T_TddCfgInfoToFpga tmpCfg = {0};
    T_OokMsgTddCfg tddCfg = {0};
    UINT32 radioMode = 0;
    UINT32 frameRatio = 0;
    UINT32 speFrameRatio = 0;
    UINT32 nrUeAdv = 0;
    UINT32 period = 0;
    UINT32 dlUlSwNum = 0;

    BspRegRd(0, REG_FPGA_CPE_ADV_TIME, 0, &nrUeAdv);
    BspRegRd(0, REG_FPGA_RADIOMODE_CFG, 0, &radioMode);
    BspRegRd(0, REG_NR_PERIOD ,        0, &period); /*周期：0.5ms:0 0.625ms:1 1.25ms:2 1ms:3 2ms:4 2.5ms:5  5ms:6 10ms:7*/
    BspRegRd(0, REG_NR_PERIOD_FLAG ,   0, &dlUlSwNum); /*0:单周期 1：双周期*/
    BspGetTddIndCfgFpga(0, &tmpCfg);
    frameRatio = BspGetLteIrSubFrame();
    speFrameRatio = BspGetLteIrSpeSubFrame();
    tddCfg.radioMode = radioMode;
    tddCfg.lteSubFreame = frameRatio;
    tddCfg.lteSpeSubFreame = speFrameRatio;
    tddCfg.nrUeAdv = nrUeAdv;
    tddCfg.dlUlSwNum = dlUlSwNum+1;
    tddCfg.dlUlSwPeriod[0] = period&0xf;
    tddCfg.dlUlSwPeriod[1] = (period>>8)&0xf;
    tddCfg.dlSymbolNum[0] = tmpCfg.dlSymbolCnt[0]+ tmpCfg.dlSlotCnt[0]*14;  /*这里0 1代表两个周期*/
    tddCfg.dlSymbolNum[1] = tmpCfg.dlSymbolCnt[1]+ tmpCfg.dlSlotCnt[1]*14;
    tddCfg.ulSymbolNum[0] = tmpCfg.ulSymbolCnt[0]+ tmpCfg.ulSlotCnt[0]*14;
    tddCfg.ulSymbolNum[1] = tmpCfg.ulSymbolCnt[1]+ tmpCfg.ulSlotCnt[1]*14;

    retVal = OokMsgSlaveTddCfg(portId, &tddCfg , &tddCfgAck);
    if((BSP_OK != tddCfgAck.ackData)||(BSP_OK != retVal))
    {
        return BSP_ERROR;
    }

    return BSP_OK;
}

/*0x12 子端漏压配置*/
/* Started by AICoder, pid:f44511f0bcec4d26ab21e496cc054283 */
UINT32 BspOokSetSlavePaVolt(UINT32 portId, UINT16 volt)
{
    T_OokMsgPaVoltCfg voltCfg = {0};
    T_OokMsgPaVoltCfgAck cfgAck = {0};
    UINT32 retVal = BSP_OK;
    T_OokMsgTempVoltGetAck tmpAck = {0};
    UINT32 loopMax = 3;
    UINT32 loop = 0;

    voltCfg.volt = volt;
    for(loop = 0; loop < loopMax; loop++)
    {
        retVal = OokMsgSlavePaVoltCfg(portId, &voltCfg, &cfgAck);
        if((BSP_OK != retVal)||(BSP_OK != cfgAck.ackData))
        {
            BspLog(LOG_LEVEL_0,"%s portId %d loop %d retVal %d ackData %d \n", __FUNCTION__, portId, loop, retVal, cfgAck.ackData);
            continue;
        }
        BspSysMsDelay(2000);
        retVal = OokMsgSlaveGetTempVolt(portId, &tmpAck);
        if((BSP_OK != retVal)||(BSP_OK != tmpAck.ackData))
        {
            BspLog(LOG_LEVEL_0,"%s portId %d loop %d retVal %d ackData %d \n", __FUNCTION__, portId, loop, retVal, cfgAck.ackData);
            continue;
        }
        BspLog(LOG_LEVEL_0,"%s portId %d loop %d volt %d pwrVolt %d \n", __FUNCTION__, portId, loop, volt, tmpAck.pwrVolt);
        if(abs(tmpAck.pwrVolt - volt)*1000 > (volt*15))  /*精度在1.5%内都算正常*/
        {
            continue;
        }
        return BSP_OK;
    }

    return BSP_ERROR;
}
/* Ended by AICoder, pid:f44511f0bcec4d26ab21e496cc054283 */

/*0x13 子端温度及电压读取*/
UINT32 BspOokGetSlaveTempAndVolt(UINT32 portId, T_SlavePortTempVolt *pTempVolt)
{
    UINT32 retVal = BSP_OK;
    T_OokMsgTempVoltGetAck tmpAck = {0};
    UINT32 loopMax = BspGetReadTempCnt();
    UINT32 validCnt = 0;
    INT32  alValidBoardTemp[10] = {0};
    INT32  alValidPa0Temp[10] = {0};
    INT32  alValidPa1Temp[10] = {0};
    INT32  alValidPwrTemp[10] = {0};
    UINT32 maxCnt = 10;
    UINT32 loop = 0;

    INPUT_POINTER_CHECK(pTempVolt);
    OOK_PORTID_CHECK(portId);
    for(loop = 0; loop < loopMax; loop++)
    {
        retVal = OokMsgSlaveGetTempVolt(portId, &tmpAck);
        if((BSP_OK != retVal)||(BSP_OK != tmpAck.ackData))
        {
             continue;
        }
        alValidBoardTemp[validCnt % maxCnt] = tmpAck.boardTemp;
        alValidPa0Temp[validCnt % maxCnt] = tmpAck.paTemp[0];
        alValidPa1Temp[validCnt % maxCnt] = tmpAck.paTemp[1];
        alValidPwrTemp[validCnt % maxCnt] = tmpAck.pwrTemp;
        pTempVolt->pwrVolt = tmpAck.pwrVolt;
        validCnt++;
        BspSysMsDelay(100);
    }
    if(0 == validCnt)
    {
         return BSP_ERROR;    /*一直失败*/
    }
    pTempVolt->boardTemp = HallibGetValidTemp(alValidBoardTemp, validCnt);   /*多次读取去取中间值*/
    pTempVolt->paTemp[0] = HallibGetValidTemp(alValidPa0Temp, validCnt);
    pTempVolt->paTemp[1] = HallibGetValidTemp(alValidPa1Temp, validCnt);
    pTempVolt->pwrTemp = HallibGetValidTemp(alValidPwrTemp, validCnt);
    g_ulSlavePortTemp[portId].boardTemp = pTempVolt->boardTemp;
    g_ulSlavePortTemp[portId].paTemp[0] = pTempVolt->paTemp[0];
    g_ulSlavePortTemp[portId].paTemp[1] = pTempVolt->paTemp[1];
    g_ulSlavePortTemp[portId].pwrTemp = pTempVolt->pwrTemp;
    g_ulSlavePortTemp[portId].pwrVolt = pTempVolt->pwrVolt;
    g_ulSlavePortTemp[portId].pwrAlm = (g_ulSlavePortPmosAlm[portId].almState>>1)&0x1;

    dbgInfoEx("boardTemp %d paTemp[0] %d paTemp[1] %d pwrTemp %d pwrVolt %d pwrAlm %d\n",
      pTempVolt->boardTemp, pTempVolt->paTemp[0], pTempVolt->paTemp[1], pTempVolt->pwrTemp, pTempVolt->pwrVolt,g_ulSlavePortTemp[portId].pwrAlm);

    return BSP_OK;
}

UINT32 getslavetemp(UINT32 portId)
{
    UINT32 retVal = BSP_OK;
    T_SlavePortTempVolt tmp = {0};

    retVal = BspOokGetSlaveTempAndVolt(portId, &tmp);
    dbgInfo("boardTemp %d paTemp[0] %d paTemp[1] %d pwrTemp %d pwrVolt %d\n",
        tmp.boardTemp, tmp.paTemp[0], tmp.paTemp[1], tmp.pwrTemp, tmp.pwrVolt);

    return retVal;
}

UINT32 BspGetSlaveTempAndVolt(UINT32 portId, T_SlavePortTempVolt *pTempVolt)
{
    if(portId >= OOK_MAX_PORTID)
    {
        return BSP_ERROR;
    }
    INPUT_POINTER_CHECK(pTempVolt);
    memcpy_s(pTempVolt, sizeof(T_SlavePortTempVolt), &g_ulSlavePortTemp[portId], sizeof(T_SlavePortTempVolt));

    return BSP_OK;
}
/*0x14 子端告警获取*/
UINT32 BspOokGetSlaveAlarm(UINT32 portId, T_OokMsgAlmGetAck *pAlmGetAck)
{
    UINT32 retVal = BSP_OK;

    INPUT_POINTER_CHECK(pAlmGetAck);
    retVal = OokMsgSlaveGetAlarm(portId, pAlmGetAck);
    if((BSP_OK != retVal)||(BSP_OK != pAlmGetAck->ackData))
    {
        return BSP_ERROR;
    }
    return BSP_OK;
}

/*上报存储的PMOS状态给高层*/
UINT32 BspGetSlavePortPmosAlm(UINT32 portId, T_OokMsgAlmGetAck *pAlmSta)
{
    if(portId >= OOK_MAX_PORTID)
    {
        return BSP_ERROR;
    }
    INPUT_POINTER_CHECK(pAlmSta);
    pAlmSta->almState = g_ulSlavePortPmosAlm[portId].almState;
    pAlmSta->almEvent = g_ulSlavePortPmosAlm[portId].almEvent;

    return BSP_OK;
}
/*0x15 开关查询*/
UINT32 BspOokGetSlaveRfSwitch(UINT32 portId, T_SlavePortRfSwitchSta *pStaAck)
{
    UINT32 retVal = BSP_OK;
    T_OokMsgRfSwitchStaAck swAck = {0};

    INPUT_POINTER_CHECK(pStaAck);
    retVal = OokMsgSlaveGetRfSwitch(portId, &swAck);
    if((BSP_OK != retVal)||(BSP_OK != swAck.ackData))
    {
        return BSP_ERROR;
    }
    pStaAck->ackData = swAck.ackData;
    pStaAck->rfSwSta = swAck.rfSwSta;
    pStaAck->rfSwTestMode = swAck.rfSwTestMode;
    return BSP_OK;
}

UINT32 BspGetSlaveAlarm(UINT32 portId, T_SlavePortGetAlm *pAlmGetAck)
{
    T_OokMsgAlmGetAck ack = {0};
    UINT32 retVal = BSP_OK;

    INPUT_POINTER_CHECK(pAlmGetAck);
    retVal = BspGetSlavePortPmosAlm(portId, &ack);
    if((BSP_OK != retVal)||(BSP_OK != ack.ackData))
    {
        return BSP_ERROR;
    }

    pAlmGetAck->ackData = ack.ackData;
    pAlmGetAck->almEvent = ack.almEvent;
    pAlmGetAck->almState = ack.almState;
    return BSP_OK;
}

UINT32 BspGetSlaveRfSwitch(UINT32 portId)
{
    T_SlavePortRfSwitchSta ack = {0};
    UINT32 retVal = BSP_OK;

    retVal = BspOokGetSlaveRfSwitch(portId, &ack);
    if(BSP_OK != retVal)
    {
       dbgErr("portId %d ookmsg error\n", portId);
       return retVal;
    }
    dbgInfoEx("ackData %d rfSwSta %d rfSwTestMode %d\n", ack.ackData, ack.rfSwSta, ack.rfSwTestMode);
    return BSP_OK;
}

/*0x16 子端告警清除*/
UINT32 BspOokSlaveAlarmClr(UINT32 portId, UINT32 clrAlm, UINT32 clrAlmEvent)
{
    T_OokMsgAlmClr almClr = {0};
    T_OokMsgAlmClrAck clrAck = {0};
    UINT32 retVal = BSP_OK;

    almClr.clrAlmState = clrAlm;
    almClr.clrAlmEvent = clrAlmEvent;
    dbgInfoEx("portId %d clrAlm %d clrAlmEvent %d clr\n", portId, clrAlm, clrAlmEvent);
    retVal = OokMsgSlaveAlarmClr(portId, &almClr, &clrAck);
    if((BSP_OK != retVal)||(BSP_OK != clrAck.ackData))
    {
        return BSP_ERROR;
    }

    return BSP_OK;
}


UINT32 BspOokClrSlaveInitAlarm(UINT32 portId)
{
     UINT32 loop = 0;
     UINT32 maxTry = 5;
     T_OokMsgAlmGetAck tmpAlmAck = {0};

     for(loop = 0; loop < maxTry; loop++)
     {
         BspSysMsDelay(200);
         BspOokGetSlaveAlarm(portId, &tmpAlmAck);
         if(BSP_OK != (tmpAlmAck.almEvent &0x1000))    /*有同步帧丢失告警*/
         {
              BspOokSlaveAlarmClr(portId, 0x1000,0x1000);
         }
         else
         {
             dbgInfo("%s portId %d loop %d bit12 framealm ok\n", __FUNCTION__, portId, loop);
             break;
         }
         memset_s(&tmpAlmAck, sizeof(T_OokMsgAlmGetAck), 0, sizeof(T_OokMsgAlmGetAck) );
     }
     BspLog(LOG_LEVEL_0,"%s portId %d loop %d bit12 framealm \n", __FUNCTION__, portId, loop);
     if(loop == maxTry)
     {
         dbgInfo("%s portId %d loop %d bit12 framealm error\n", __FUNCTION__, portId, loop);
         return BSP_ERROR;
     }

     return BSP_OK;
}
/*0xe1-0x00 子端信息查询*/
UINT32 BspOokGetWfsSlaveBoardInfo(UINT32 portId, T_OokMsgWfsBoardInfoGetAck *pInfoAck)
{
    UINT32 retVal = BSP_OK;

    INPUT_POINTER_CHECK(pInfoAck);
    retVal = OokMsgSlaveGetWfsBoardInfo(portId, pInfoAck);
    if((BSP_OK != retVal)||(BSP_OK != pInfoAck->ackData))
    {
        return BSP_ERROR;
    }

    return BSP_OK;
}

/*0xe1-0x01 电流AD值查询*/
UINT32 BspOokGetSlaveCurrAdVal(UINT32 portId, UINT32 pwrIndex, UINT32 adcChan, T_OokMsgWfsCurrAdValGetAck *pAdValAck)
{
    T_OokMsgWfsCurrAdValGet adVal = {0};
    UINT32 retVal = BSP_OK;

    INPUT_POINTER_CHECK(pAdValAck);
    adVal.chipIndex = pwrIndex;
    adVal.adcChan = adcChan;
    retVal = OokMsgSlaveGetCurrAdVal(portId, &adVal, pAdValAck);
    if((BSP_OK != retVal)||(BSP_OK != pAdValAck->ackData))
    {
        return BSP_ERROR;
    }

    return BSP_OK;
}

UINT32 BspGetSlavePaCurrAdVal(UINT32 portId, UINT32 pwrIndex, UINT32 adcChan, UINT32 *pAdVal)
{
    T_OokMsgWfsCurrAdValGetAck adVal = {0};
    UINT32 retVal = BSP_OK;

    INPUT_POINTER_CHECK(pAdVal);
    retVal = BspOokGetSlaveCurrAdVal(portId, pwrIndex, adcChan, &adVal);
    *pAdVal = adVal.adVal;

    return retVal;
}

/*0xe1-0x02 电流查询*/
UINT32 BspOokGetSlavePwrCurr(UINT32 portId, UINT32 pwrIndex, UINT32 adcChan, T_OokMsgWfsPwrCurrGetAck *pCurrAck)
{
    T_OokMsgWfsPwrCurrGet curr = {0};
    UINT32 retVal = BSP_OK;

    INPUT_POINTER_CHECK(pCurrAck);
    curr.chipIndex = pwrIndex;
    curr.adcChan = adcChan;
    retVal = OokMsgSlaveGetPwrCurr(portId, &curr, pCurrAck);
    if((BSP_OK != retVal)||(BSP_OK != pCurrAck->ackData))
    {
        return BSP_ERROR;
    }

    return BSP_OK;
}

/*0xe1-0x03 校准表校验结果查询*/
UINT32 BspOokGetSlaveRfTblCrcRes(UINT32 portId, UINT32 fileType, T_OokMsgWfsRfTblCrcResGetAck *pCrcResAck)
{
    T_OokMsgWfsRfTblCrcResGet crcRes = {0};
    UINT32 retVal = BSP_OK;

    INPUT_POINTER_CHECK(pCrcResAck);
    crcRes.fileType = fileType;
    retVal = OokMsgSlaveGetRfTblCrcRes(portId, &crcRes, pCrcResAck);
    if(BSP_OK != retVal)
    {
        return BSP_ERROR;
    }

    return BSP_OK;
}

UINT32 BspSlavePortRfTblLoad(UINT32 portId)
{
    UINT32 retVal = 0;
    UINT32 index = 0;
    UINT32 fileType = 0;
    T_CaliTblInitFile* ptFileInfo = NULL;
    UINT32 result = 0;

    retVal = BspTxGainCalibInitByIndex(portId + 2);
    retVal |= BspTxFwdCalibInitByIndex(portId + 2);
    retVal |= BspRxRssiCalibInitByIndex(portId + 2);
    retVal |= BspTrxTempGainCalibInitByIndex(portId + 2);
    retVal |= BspPaTempGainCalibInitByIndex(portId + 2);
    retVal |= BspPaCurCaliInitByIndex(portId + 2);
    retVal |= _BspTxFwdAnalogCalibInitByIndex(portId + 2);
    retVal |= _BspTxRevAnalogCalibInitByIndex(portId + 2);
    ptFileInfo = (T_CaliTblInitFile*)malloc(sizeof(T_CaliTblInitFile));
    if(NULL != ptFileInfo)
    {
        BspGetRfTblInitFile(ptFileInfo); //参数初始化
        for (index = 0; index < ptFileInfo->ulFileNum; index++)
        {
            if(index >= NUM_TBL_KIND_NUM)
            {
                break;
            }
            fileType = ptFileInfo->FileMenu[index];
            ptFileInfo->InitParam[index].ulCaliLoadPath = ptFileInfo->FilePaths[index][1];
            dbgInfoEx("%s:index %d, ulCaliLoadPath %d\n", __FUNCTION__, index, ptFileInfo->InitParam[index].ulCaliLoadPath);
            _BspTblCaliInit(&ptFileInfo->InitParam[index]);
            if(TBL_KIND_OF_PAENSAVADJ == fileType)
            {
               result = _BspPaEnSavAdjCalibInit(portId + 2);
               retVal |= result;
               BspSetRfTblInitLoadSta(TBL_KIND_OF_PAENSAVADJ, portId + 2, result);
            }
            if(TBL_KIND_OF_PABASICINFO == fileType)
            {
               result = _BspPaBasicInfoCalibInit(portId + 2);
               retVal |= result;
               BspSetRfTblInitLoadSta(TBL_KIND_OF_PABASICINFO, portId + 2, result);
            }
            if(TBL_KIND_OF_FILTERGAIN == fileType)
            {
               result = _BspFilterGainCalibInit(portId + 2);
               retVal |= result;
               BspSetRfTblInitLoadSta(TBL_KIND_OF_FILTERGAIN, portId + 2, result);
            }
        }
        free(ptFileInfo);
    }
    else
    {
        BspSetRfTblInitLoadSta(TBL_KIND_OF_PAENSAVADJ, portId + 2, BSP_ERROR);
        BspSetRfTblInitLoadSta(TBL_KIND_OF_PABASICINFO, portId + 2, BSP_ERROR);
        dbgErr("ptFileInfo malloc failed\n");
    }

    return retVal;
}

/*模拟检波电路电压和温度读取*/
UINT32 BspGetSlaveRfDectorVolt(UINT32 chan, UINT32 type, UINT32 *pAdVal, INT32 *paTemp, UINT8 *pVaildFlag)
{
    UINT32 retVal = BSP_OK;
    UINT32 slaveChn = 0;
    UINT32 portId = 0;
    UINT32 portSta = 0;
    T_OokMsgAnaLogGet tmp = {0};
    T_OokMsgAnaLogGetAck tmpAck = {0};

    INPUT_POINTER_CHECK(pAdVal);
    INPUT_POINTER_CHECK(paTemp);
    INPUT_POINTER_CHECK(pVaildFlag);
    retVal = BspGetPortIdByBspChn(chan, TX, &portId);
    retVal |= BspGetPortSlaveChnByBspChn(chan, TX, &slaveChn);
    retVal |= BspGetSlavePortCfgSta(portId, &portSta);
    if((BSP_OK != retVal)||(LINK_OK != portSta))
    {
        return retVal;
    }
    tmp.slaveChn = slaveChn;
    tmp.type = 1 - type;   /*子端和母端反了*/

    retVal = OokMsgSlaveGetAnaLog(portId, &tmp, &tmpAck);
    if((BSP_OK == retVal)&&(0 == tmpAck.ackData))
    {
       *pAdVal = tmpAck.volt;
       *paTemp = tmpAck.paTemp;
       *pVaildFlag = tmpAck.vaildFlag;
       dbgInfoEx("chan%d type %d volt %d  paTemp %d VaildFlag %d\n", chan, type, *pAdVal, *paTemp, *pVaildFlag);
    }

    return retVal;
}

UINT32 getadvolt(UINT32 chan, UINT32 type)
{
    UINT32 retVal = BSP_OK;
    UINT32 adVal = 0;
    INT32 paTemp = 0;
    UINT8 flag = 0;

    retVal =  BspGetSlaveRfDectorVolt(chan, type, &adVal, &paTemp, &flag);
    dbgInfo("chan%d type %d volt %d  paTemp %d VaildFlag %d\n", chan, type, adVal, paTemp, flag);

    return retVal;
}

UINT32 BspSlavePortRfTblInitUpdate(UINT32 portId)
{
    UINT32 retVal = 0;
    UINT32 loop = 0;
    UINT32 loopEx = 0;
    UINT32 rfTblNum = 0;
    UINT32 maxTry = 3;

#ifdef _BSP_WITH_WFS
    maxTry = 1;
#endif
    rfTblNum = NELEMENTS(s_acFilePathName);
    for(loop = 0; loop < rfTblNum; loop ++)
    {
        for(loopEx = 0; loopEx < maxTry; loopEx++)  /*每个校准表上传之后增加crc校验  一次子端上电最多尝试3次*/
        {
           retVal = BspOokRfTblUpLoad(portId, loop);
           if(BSP_INVALID_VALUE == retVal)
           {
               BspLog(LOG_LEVEL_0, "BspSlavePortRfTblInitUpdate portId %d  rftblType %d loopEx %d\n", portId, loop, loopEx);
               break;
           }
        }
    }
    retVal |= BspSlavePortRfTblLoad(portId);
    BspSetRfTblLoadStaBySlavePortCfg(portId);

    return retVal;
}

/* Started by AICoder, pid:r9cf2e476d00e7e147520880c07e6d2c7b024dae */
/* Started by AICoder, pid:i63f5g3a2002b9014c060bad30e1c338a545e3f3 */
UINT32 BspGetSlavePortRfTblLoadSta(VOID)
{
    UINT32 loop = 0;
    UINT32 retVal = BSP_OK;

    // 初始化射频表加载状态
    BspSetRfTblLoadSta(TBL_KIND_OF_TXFWDANALOG, 0, 0);
    BspSetRfTblLoadSta(TBL_KIND_OF_TXFWDANALOG, 1, 0);
    BspSetRfTblLoadSta(TBL_KIND_OF_TXREVANALOG, 0, 0);
    BspSetRfTblLoadSta(TBL_KIND_OF_TXREVANALOG, 1, 0);
    BspSetRfTblLoadSta(TBL_KIND_OF_FILTERGAIN, 1, 0);
    BspSetRfTblLoadSta(TBL_KIND_OF_PABASICINFO, 1, 0);
    BspSetRfTblLoadSta(TBL_KIND_OF_PAENSAVADJ, 1, 0);
    BspSetRfTblLoadSta(TBL_KIND_OF_PATEMPGAIN, 1, 0);

    // 初始化从机射频表加载状态
    BspInitSlaveRfTblLoadSta();

    // 遍历所有端口ID，设置射频表加载状态并执行加载操作
    for (loop = 0; loop < OOK_MAX_PORTID; loop++)
    {
        slaveinitsw(loop, 1);
        BspClrRfTblLoadStaBySlavePortCfg(loop);
        retVal |= BspSlavePortRfTblLoad(loop);
        retVal |= BspSetRfTblLoadStaBySlavePortCfg(loop);
    }

    // 重置所有端口ID的初始化开关
    for (loop = 0; loop < OOK_MAX_PORTID; loop++)
    {
        slaveinitsw(loop, 0);
    }

    return retVal;
}
/* Ended by AICoder, pid:i63f5g3a2002b9014c060bad30e1c338a545e3f3 */
/* Ended by AICoder, pid:r9cf2e476d00e7e147520880c07e6d2c7b024dae */

UINT32 BspOokGetSlaveGridVolt(UINT32 portId, UINT8 dacChipIdx, UINT8 innerChan, INT16 *pVolt)
{
    T_OokMsgGridVoltGet volt = {0};
    T_OokMsgGridVoltGetAck voltAck = {0};
    UINT32 retVal = BSP_OK;

    INPUT_POINTER_CHECK(pVolt);
    volt.dacChipIdx = dacChipIdx;
    volt.innerChan = innerChan;
    retVal = OokMsgSlaveGetGridVolt(portId, &volt, &voltAck);
    if((BSP_OK != retVal)||(BSP_OK != voltAck.ackData))
    {
        return BSP_ERROR;
    }
    *pVolt = voltAck.gridVoltMv;

    return retVal;
}


static UINT32 SndBootVerUpdataByOok(UINT32 portId)
{
    BspOokCmd(portId,"checksndbootver");
    BspSysMsDelay(2000);
    if (BSP_OK != BspOokCmd(portId,"checksndbootver"))
    {
        dbgErr("Second Boot Main Ver Error!!");
        return BSP_ERROR;
    }

    if (BSP_OK != BspOokVerDownLoad(portId, 2))
    {
        dbgErr("Second Boot Ver Download Fail!!");
        return BSP_ERROR;
    }

    return BspOokMsgVerAct(portId, 0, 0 ,1);
}


UINT32 BspOokSlaveForceRfSwitch(UINT32 portId, UINT32 slaveChn, UINT32 mode)
{
    T_OokMsgForceRfSwitch ctrl = {0};
    T_OokMsgForceRfSwitchAck ctrlAck = {0};
    UINT32 retVal = BSP_OK;

    ctrl.chan =  slaveChn ;
    ctrl.modeType =  mode ;
    retVal = OokMsgSlaveForceRfSwitchCtrl(portId, &ctrl, &ctrlAck);
    if((BSP_OK != retVal)||(BSP_OK != ctrlAck.ackData))
    {
         return BSP_ERROR;
    }

    return BSP_OK;
}

/*获取子端时钟、12V欠压、同步帧头丢失告警事件 有告警时清除*/
UINT32 BspPerSlaveGetPastPaProAlm(UINT32 portId, E_SLAVE_PAPRO_ALM_TYPE almType, UINT64 *pu64EventBits)
{
    UINT32 retVal = BSP_OK;
    UINT32 almEvent = 0;
    UINT32 almState = 0;
    UINT32 portSta = 0;
    UINT32 tmpSta = 0;
    UINT32 almClr = 0;
    UINT32 almBit = 0;

    OOK_PORTID_CHECK(portId);
    INPUT_POINTER_CHECK(pu64EventBits);
    dbgInfoEx("%s portId %d almType %d\n", __FUNCTION__, portId, almType);
    *pu64EventBits = 0;
    portSta = BspGetSlavePortStatus(portId);
    if(BSP_OK != portSta)    /*断链--底层自己读的 不能依赖于高层下发的 直接报ok*/
    {
         dbgInfoEx("%s portId %d almType %d is not link\n", __FUNCTION__, portId, almType);
         return BSP_OK;
    }
    almEvent = g_ulSlavePortPmosAlm[portId].almEvent;  /*用事件判断 不用实时告警*/
    almState = g_ulSlavePortPmosAlm[portId].almState;
    switch (almType)
    {
        case SLAVE_SYSPLL_PAPRO_ALMTYPE:
            almBit = 11;
            tmpSta = almEvent&BIT_SET(11);
            break;
        case SLAVE_BRDPWR_12V_PAPRO_ALMTYPE:
            almBit = 2;
            tmpSta = almEvent&BIT_SET(2);
            break;
        case SLAVE_FRAME_PAPRO_ALMTYPE:
            almBit = 12;
            tmpSta = almEvent&BIT_SET(12);
            break;
        default:
            retVal = PAPT_NOT_SUPPORT_ALM;
            break;
    }
    dbgInfoEx("%s portId %d almType %d almEvent %d almState %d almBit %d tmpSta %d\n", __FUNCTION__, portId,
               almType, almEvent, almState, almBit, tmpSta);
    if(BSP_OK != tmpSta)
    {
        BspLog(LOG_LEVEL_0,"%s portId %d almType %d almEvent %d almState %d almBit %d tmpSta %d\n", __FUNCTION__, portId,
                almType, almEvent, almState, almBit, tmpSta);
        *pu64EventBits = 1;    /*这个参数本来是用来记录同一类告警中不同具体告警项是否有告警比如serdes分上下行 分别占bit0-1)，子端没有子检测项*/
        almClr = BIT_SET(almBit);
        /*0x1c0-1c2 bit0子端时钟异常 bit1子端12v欠压异常 bit2子端同步帧头丢失 almType 和bit对应  设置fpga使能之后会通知IC产生保护 关数据和功放*/
        BspRegBitValWr(0, REG_FPGA_PAPRO_ALM_CTRL_MASK, portId, 1, almType,almType);
        (VOID)BspOokSlaveAlarmClr(portId, almClr, almEvent);  /*高层不能校验这个接口的返回值*/
        BspSetSlavePaProAlmFlagByPortId(portId, almType,1);
    }
    else
    {
        BspSetSlavePaProAlmFlagByPortId(portId, almType,0);
        BspRegBitValWr(0, REG_FPGA_PAPRO_ALM_CTRL_MASK, portId, 0, almType,almType);
    }

    return retVal;
}

static UINT32 GetSlaveAlmTypeAndChipId(E_PaProType ePaProType, UINT32 *pChipId, E_SLAVE_PAPRO_ALM_TYPE *pAlmType)
{
    E_SLAVE_PAPRO_ALM_TYPE alarmType = 0;
    UINT32 chipId = 0;
    UINT32 retVal = BSP_OK;

    switch (ePaProType)
    {
        case E_PA_PRO_TYPE_SLAVE0_SYSPLL:
        case E_PA_PRO_TYPE_SLAVE1_SYSPLL:
        case E_PA_PRO_TYPE_SLAVE2_SYSPLL:
            chipId = ePaProType - E_PA_PRO_TYPE_SLAVE0_SYSPLL;
            alarmType = SLAVE_SYSPLL_PAPRO_ALMTYPE;
            break;
        case E_PA_PRO_TYPE_SLAVE0_BRDPWR_12V:
        case E_PA_PRO_TYPE_SLAVE1_BRDPWR_12V:
        case E_PA_PRO_TYPE_SLAVE2_BRDPWR_12V:
            chipId = ePaProType - E_PA_PRO_TYPE_SLAVE0_BRDPWR_12V;
            alarmType = SLAVE_BRDPWR_12V_PAPRO_ALMTYPE;;
            break;
        case E_PA_PRO_TYPE_SLAVE0_FRAME:
        case E_PA_PRO_TYPE_SLAVE1_FRAME:
        case E_PA_PRO_TYPE_SLAVE2_FRAME:
            chipId = ePaProType - E_PA_PRO_TYPE_SLAVE0_FRAME;
            alarmType =SLAVE_FRAME_PAPRO_ALMTYPE;
            break;
        default:
            retVal = BSP_ERROR;
            break;
    }

    *pChipId = chipId;
    *pAlmType = alarmType;

    return retVal;
}

/*获取子端的告警*/
INT32 BspGetSlavePastPaProAlm(E_PaProType ePaProType, UINT64 *pu64EventBits)
{
    UINT32 portId = 0;
    UINT32 retVal = 0;
    E_SLAVE_PAPRO_ALM_TYPE almType = 0;

    INPUT_POINTER_CHECK(pu64EventBits);
    retVal = GetSlaveAlmTypeAndChipId(ePaProType, &portId, &almType);
    if(BSP_OK != retVal)
    {
        return BSP_ERROR;
    }
    /* 对于超出子端个数范围的告警，直接返回不支持 */
    if(portId >= OOK_MAX_PORTID)
    {
        return PAPT_NOT_SUPPORT_ALM;
    }
    retVal = BspPerSlaveGetPastPaProAlm(portId, almType, pu64EventBits);

    return retVal;
}

/*清除子端告警配给fpga的掩码*/
INT32 BspPaProSlaveAlmRecover(UINT32 ulPaProAlmType, UINT64 u64EventAlmMask)
{
    E_PaProType ePaProType = 0;
    UINT32 portId = 0;
    UINT32 retVal = 0;
    E_SLAVE_PAPRO_ALM_TYPE almType = 0;
    UINT32 almEvent = 0;
    UINT32 tmpSta = 0;

    dbgInfoEx("BspPaProSlaveAlmRecover type %d  u64EventAlmMask 0x%llX \n", ulPaProAlmType, u64EventAlmMask);
    ePaProType = ulPaProAlmType;
    retVal = GetSlaveAlmTypeAndChipId(ePaProType, &portId, &almType);
    if(portId >= OOK_MAX_PORTID)
    {
        return PAPT_NOT_SUPPORT_ALM;
    }
    almEvent = g_ulSlavePortPmosAlm[portId].almEvent;
    switch (almType)
    {
        case SLAVE_SYSPLL_PAPRO_ALMTYPE:
        {
            tmpSta = almEvent&BIT_SET(11);
            break;
        }
        case SLAVE_BRDPWR_12V_PAPRO_ALMTYPE:
        {
            tmpSta = almEvent&BIT_SET(2);
            break;
        }
        case SLAVE_FRAME_PAPRO_ALMTYPE:
        {
            tmpSta = almEvent&BIT_SET(12);
            break;
        }
        default:
        {
            retVal = PAPT_NOT_SUPPORT_ALM;
            break;
        }
    }
    if(BSP_OK == tmpSta)
    {
        /*0x1c0-1c2 bit0子端时钟异常 bit1子端12v欠压异常 bit2子端同步帧头丢失 almType 和bit对应  设置fpga去使能之后会通知IC取消  产生保护 关数据和功放*/
        BspRegBitValWr(0, REG_FPGA_PAPRO_ALM_CTRL_MASK, portId, 0, almType,almType);
    }
    dbgInfoEx("%s portId %d almType %d almEvent %d tmpSta %d\n", __FUNCTION__, portId,
               almType, almEvent, tmpSta);

    return retVal;
}

#include <string.h>
#include "vxadp.h"
#include "ook_msg.h"
#include "list.h"
#include "exprn.h"
#include "funccommon.h"
#include "bsppub.h"
#include <semaphore.h>
#include <time.h>
#include "regdrv.h"
#include "regdrv_access.h"
#include "crc.h"

SEM_ID g_semOokMsg[OOK_MAX_PORTID] = {0};
static char *ook_msg_prn = "OokMsg";
#define MsgPrint(level,fmt...)    PmPrint(PmAutoAdd(DEFAULT_PM_LEVEL,ook_msg_prn),(level)|PM_PREFIX, ##fmt)
#define MsgBufPrint(level,fmt...) PmPrint(PmAutoAdd(DEFAULT_PM_LEVEL,ook_msg_prn),(level), ##fmt)

#define CREAT_BUFF(buff,send,recv)                                      \
{                                                                       \
    UINT8 *buff = NULL;                                                 \
    THpiApiPDU *send = NULL;                                            \
    THpiApiPDU *recv = NULL;                                            \
    buff = (UINT8 *)malloc(sizeof(THpiApiPDU) + sizeof(THpiApiPDU));    \
    if (NULL == buff)                                                   \
    {                                                                   \
        ulRetVal |= BIT_SET(0);                                         \
        dbgErr("%s>>TmpBuf Malloc Error!\n", __FUNCTION__);             \
        return ulRetVal;                                                \
    }                                                                   \
    memset((VOID *)buff, 0, sizeof(THpiApiPDU) + sizeof(THpiApiPDU));   \
    send = (THpiApiPDU *)&buff[0];                                      \
    recv = (THpiApiPDU *)&buff[sizeof(THpiApiPDU)];                     \
}
#define RELEASE_BUFF(buff)      free(buff);


UINT32 msgresendcount = 2;   /*调用太频繁阻塞高层OP 临时修改*/
UINT32 g_ulOokRdAddrCnt[OOK_MAX_PORTID] = {0};
UINT32 g_ulOokPrnFlag = 0;
UINT8 g_serialNo = 0;
UINT32 g_ulTestCnt = 0;
UINT32 g_ulOokWaitTime = 100;   /*默认100ms 后续结合子端情况调整*/

UINT32 g_ulOokMsgEnable[OOK_MAX_PORTID] = {0};

void ookprnon(VOID)
{
    g_ulOokPrnFlag = 1;
}

void ookprnoff(VOID)
{
    g_ulOokPrnFlag = 0;
}
/*ook 功能初始化*/
UINT32 BspOokMsgInit(void)
{
    UINT32 loop = 0;
    /*信号量初始化*/
    for(loop = 0; loop < OOK_MAX_PORTID; loop++)
    {
        BspRegWr(0, OOK_NORMAL_UART_CTRL, loop*0x10,0);
        g_semOokMsg[loop] = semBCreate(SEM_Q_FIFO,SEM_FULL);
        if(NULL == g_semOokMsg[loop])
        {
            dbgErr("portId %d Fail to create power Measure semaphore\n", loop);
            return BSP_ERROR;
        }
    }

    return BSP_OK;
}

/*OOK消息发送接口*/
UINT32 OokSendMsg(UINT16 portId, TookFrameApiPDU *pSend)
{
    UINT32 retVal = 0;
    UINT32 sendlen = 0;
    UINT32 loop = 0;
    UINT32 chip = 0;
    UINT8 tmpData[MAX_SEND_LEN_PER_PACK]= {0};

    dbgInfoEx("OokSendMsg enter\n");
    INPUT_POINTER_CHECK(pSend);
    sendlen = OOK_NTOHS(pSend->head.dataLen) + sizeof(TookFrameHeader);  /*（消息头+消息定义）+ 帧头*/

    if(sendlen >= MAX_SEND_LEN_PER_PACK)
    {
         dbgErr("sendlen is over 512\n");   /*超过fpga最大能力的直接报错，拆包在app层实现*/
         return BSP_ERROR;
    }

    retVal = BspRegWr(chip, OOK_RAM_WR_ADDR_NUM, portId*0x10, sendlen);
    memcpy_s(tmpData,sendlen,(UINT8*)pSend,sendlen);
    for(loop = 0; loop < sendlen; loop++)
    {
        retVal |= BspRegWr(chip, OOK_RAM_WR_ADDR, portId*0x10,loop);
        retVal |= BspRegWr(chip, OOK_RAM_WR_DATA, portId*0x10, tmpData[loop]);
        retVal |= BspRegWr(chip, OOK_RAM_WR_EN, portId*0x10, 1);
        retVal |= BspRegWr(chip, OOK_RAM_WR_EN, portId*0x10, 0);
        dbgInfoEx("loop %d  tmpData[loop] 0x%x \n", loop, tmpData[loop]);
    }
    retVal |= BspRegWr(chip, OOK_RAM_WR_FINISH_FLAG, portId*0x10, 1);
    retVal |= BspRegWr(chip, OOK_RAM_WR_FINISH_FLAG, portId*0x10, 0);

    return retVal;
}
UINT32 calcCurrRdAddrDelt(UINT32 preCnt, UINT32 nextCnt)
{
    INT32 tmp = 0;
    UINT32 len = 0;

    tmp = nextCnt - preCnt;
    if(tmp >= 0)
    {
        len = tmp;
    }
    else
    {
        len = tmp + MAX_RECV_LEN_PER_PACK;
    }

    return len;
}
UINT8 getOokRecvLen(UINT32 portId, TookFrameHeader *pFrameHead)
{
    UINT32 addr = 0;
    TookFrameHeader tmp = {0};
    UINT32 loop = 0;
    UINT8 *pData = NULL;
    UINT32 tmpData = 0;

    addr = g_ulOokRdAddrCnt[portId];
    pData = malloc(sizeof(TookFrameHeader));
    /* Started by AICoder, pid:fb4c31bb06y655314f940af5b0bf0d19542294f1 */
    if(NULL == pData)
    {
        dbgErr("%s malloc failed\n", __func__);
        return MAX_RECV_LEN_ONE_PACK-1;   /*适配外部调用接口判断*/
    }
    /* Ended by AICoder, pid:fb4c31bb06y655314f940af5b0bf0d19542294f1 */
    for(loop = 0; loop< sizeof(TookFrameHeader);loop++)
    {
        BspRegWr(0,OOK_RAM_RD_ADDR, portId*0x10, addr+1);
        BspRegRd(0,OOK_RAM_RD_DATA, portId*0x10,&tmpData);
        pData[loop] = (UINT8)tmpData;
        dbgInfoEx("tmpData %d\n",tmpData);
        addr++;
    }
    memcpy_s((UINT8*)&tmp,sizeof(TookFrameHeader),pData,sizeof(TookFrameHeader));
    free(pData);
    dbgInfoEx("%d\n",tmp.startFlag1);
    dbgInfoEx("%d\n",tmp.startFlag2);
    if(NULL != pFrameHead)
    {
        memcpy_s(pFrameHead,sizeof(TookFrameHeader),&tmp,sizeof(TookFrameHeader));
    }
    return OOK_NTOHS(tmp.dataLen);
}

void PrintOokData(TookFrameApiPDU *ptOokMsg)
{
    UINT8* pData = 0;
    UINT32 loop = 0;
    UINT32 dataLen = 0;

    INPUT_POINTER_CHECK_RETURN(ptOokMsg);
    dataLen = OOK_NTOHS(ptOokMsg->head.dataLen) + sizeof(TookFrameHeader);
    dbgInfoEx("send: lend = %d ptOokMsg->head.dataLen %d\n ", dataLen, OOK_NTOHS(ptOokMsg->head.dataLen));
    if (1 == g_ulOokPrnFlag)
    {
        pData = (UINT8*)&(ptOokMsg->head);
        for(loop = 0; loop < dataLen; loop++)
        {
            dbgInfo("%02X ",*pData++);
        }
        dbgInfo("\n");
    }
}
/*回读的消息合法性校验 crc+消息头*/
UINT32 OokRecvMsgCheck(TookFrameApiPDU *pRecv,TookFrameApiPDU *pSend)
{
    INPUT_POINTER_CHECK(pSend);
    INPUT_POINTER_CHECK(pRecv);

    if((OOK_MSG_STARTFLAG1 != pRecv->head.startFlag1)||(OOK_MSG_STARTFLAG2 != pRecv->head.startFlag2))
    {
        return BSP_ERROR;
    }
    if(pRecv->msgHead.msgType != pSend->msgHead.msgType)
    {
        return BSP_ERROR;
    }
    return BSP_OK;
}

/*OOK消息接收接口*/
UINT32 OokRecvMsg(UINT32 portId, TookFrameApiPDU *pRecv)
{
    UINT32 chip = 0;
    UINT32 tmpCnt = 0;
    UINT32 loop = 0;
    UINT32 loopEx = 0;
    UINT32 maxTry = 10;  /*最大等待接收响应次数*/
    UINT32 delt = 0;
    UINT8  *pData = NULL;
    UINT32 tmpData = 0;
    UINT32 addr = 0;
    UINT32 recvLen = 0;
    TookFrameHeader frameHead = {0};
    UINT8 dataCrc = 0;

    dbgInfoEx("OokRecvMsg enter\n");
    INPUT_POINTER_CHECK(pRecv);
    for(loop = 0; loop < maxTry; loop++)
    {
        BspRegRd(chip, OOK_RAM_WR_ADDR_BACK, portId*0x10, &tmpCnt);
        delt = calcCurrRdAddrDelt(g_ulOokRdAddrCnt[portId],tmpCnt);
        addr = g_ulOokRdAddrCnt[portId];   /*代表的是地址的实际值 两次读取的差值代表的是元素的个数*/
        dbgInfoEx("portId %u delt %u addr %u  tmpCnt %u size %lu\n",portId,delt,addr,tmpCnt,sizeof(TookFrameHeader));
        if(delt > (sizeof(TookFrameHeader)+sizeof(TookMsgHeader)))
        {
             recvLen = getOokRecvLen(portId, &frameHead);
             dbgInfoEx("%s portId %d recvLen %d\n", __FUNCTION__, portId, recvLen);
             recvLen = recvLen + sizeof(TookFrameHeader);
             if((OOK_MSG_STARTFLAG1 != frameHead.startFlag1)||(OOK_MSG_STARTFLAG2 != frameHead.startFlag2))
             {
                 dbgInfoEx("frameHead.startFlag1 0x%x or frameHead.startFlag2 0x%x is invalid\n ",frameHead.startFlag1, frameHead.startFlag2);
                 return BSP_ERROR;
             }
             if(recvLen > MAX_RECV_LEN_ONE_PACK) /*收包长度不能超过子端一次写的最大长度  完整的一次收发不会超过这个数*/
             {
                 dbgErr("recvLen %d is invalid\n ",recvLen);
                 return BSP_ERROR;
             }
             if(delt >= recvLen)
             {
                 pData = malloc(sizeof(UINT8)*delt);
                 INPUT_POINTER_CHECK(pData);   /*上层直接判断是否等于OK*/
                 for(loopEx = 0; loopEx < delt; loopEx++)
                 {
                     tmpData = 0;
                     BspRegWr(0,OOK_RAM_RD_ADDR,portId*0x10,(addr+1)%MAX_RECV_LEN_PER_PACK);
                     BspRegRd(0,OOK_RAM_RD_DATA,portId*0x10,&tmpData);
                     pData[loopEx] = tmpData&0xff;
                     dbgInfoEx("loopEx %d g_ulOokRdAddrCnt 0x%x, addr 0x%x pData[loopEx] 0x%x\n",loopEx, g_ulOokRdAddrCnt[portId],addr,pData[loopEx]);
                     addr++;
                 }
                memcpy_s((UINT8*)pRecv,delt,pData,delt);  /*这里要使用send的部分信息 校验回读的信息 判断收发是否配对*/
                PrintOokData(pRecv);
                free(pData);
                break;
            }
            else
             {
                 BspSysMsDelay_Sys(g_ulOokWaitTime);  /*未收完预期长度的数据*/
             }
        }
        else
        {
            BspSysMsDelay_Sys(g_ulOokWaitTime);  /*不变则增加延时等待*/
        }
    }
    if(maxTry == loop)
    {
        return BSP_ERROR;
    }
    else
    {
        dataCrc = BspCountCRC8((UINT8*)&pRecv->msgHead, OOK_NTOHS(pRecv->head.dataLen));
        dbgInfoEx("dataCrc 0x%x pRecv->head.dataCrc 0x%x\n", dataCrc, pRecv->head.dataCrc);
        if(dataCrc != pRecv->head.dataCrc)
        {
            g_ulOokPrnFlag = 1;
            PrintOokData(pRecv);
            g_ulOokPrnFlag = 0;
            return BSP_ERROR;
        }
        return BSP_OK;
    }

}

void setookwaittime(UINT32 tmp)
{
    g_ulOokWaitTime = tmp;
}
/*一次完整的收发过程*/
UINT32 BspOokMsgProcess(UINT32 portId, TookFrameApiPDU *pSend, TookFrameApiPDU *pRecv)
{
    UINT32 retVal = 0;
    UINT32 chip = 0;
    UINT32 tmpVal = 0;

    INPUT_POINTER_CHECK(pRecv);
    INPUT_POINTER_CHECK(pSend);
    /*信号量互斥一次完整的收发流程*/
    if(BSP_OK != semTake(g_semOokMsg[portId],WAIT_FOREVER))   /*WAIT_FOREVER一直等  这里可以设置数字代表等待的最大时间  单位是10ms*/
    {
        dbgErr("%s portId%d g_semOokMsg semTake fail!\n", __FUNCTION__, portId);
        return BSP_ERROR;
    }
    BspRegRd(chip, OOK_RAM_WR_ADDR_BACK, portId*0x10, &g_ulOokRdAddrCnt[portId]);
    dbgInfoEx("portId %d g_ulOokRdAddrCnt[portId] 0x%x before ook\n", portId, g_ulOokRdAddrCnt[portId]);
    retVal = OokSendMsg(portId,pSend);
    if(BSP_OK != retVal)
    {
        tmpVal |= BIT_SET(0);
        semGive(g_semOokMsg[portId]);
        return tmpVal;
     }
     BspSysMsDelay_Sys(200);  /*fpga最多需要200ms才将数据发出去*/
     retVal = OokRecvMsg(portId,pRecv);
     if(BSP_OK != retVal)
     {
         tmpVal |= BIT_SET(1);
         semGive(g_semOokMsg[portId]);
         return tmpVal;
      }
     semGive(g_semOokMsg[portId]);

     return tmpVal;
}

/*调试接口 停止某个端口的消息*/
void setooken(UINT32 portId, UINT32 flag)
{
    if(portId >= OOK_MAX_PORTID)
    {
       return;
    }
    g_ulOokMsgEnable[portId] = flag;
    return;
}

/*注意这一层不用chan作为入参，ook_app中如果按chan进行，需要先将chan转到portid*/
/*OOK通信对外收发接口*/
UINT32 BspOokMsgProc(UINT16 portId, TookFrameApiPDU *pSend, TookFrameApiPDU *pRecv)
{
    UINT32 retVal = BSP_OK;
    UINT32 loop = 0;
    UINT32 msgType = 0;

    INPUT_POINTER_CHECK(pRecv);
    INPUT_POINTER_CHECK(pSend);

    if(0 != g_ulOokMsgEnable[portId])
    {
        BspSysMsDelay(500);
        return BSP_OK;
    }
    for(loop = 0; loop < msgresendcount; loop++)
    {
        /*这里需要填充 控制fpga实现的OOK通信的驱动接口   子接口需要有信号量互斥*/
        PrintOokData(pSend);
        msgType = pSend->msgHead.msgType;
        retVal = BspOokMsgProcess(portId, pSend, pRecv);
        if(retVal == BSP_OK)
        {
            break;
        }
    }
    if(loop == msgresendcount)
    {
        dbgInfoEx("[%s] portId %d msgType 0x%x proc fail! loop%d,Ret= 0x%04X \n",__FUNCTION__, portId, msgType,loop,retVal);
    }
    return retVal;
}


CHAR g_ookExprn[][OOK_EXPRNADD_LEN] =
{
    "OokSendMsg",
    "OokRecvMsg",
    "BspOokMsgProcess",
    "wrookram",
};

char ookPrintInfo[][OOK_EXPRNADD_LEN]=
{
    "ookexprnadd",
    "BspOokMsgInit",
    "ookexprnquit",
    "ookrecven portId",
    "ookrecvtest portId",
    "rdnookram portId,startaddr,len",
    "setookwaittime tmp",
    "setversw 1停 0开",
    "BspOokVerDownLoad portId,verType 0-mcu 1-epld",
    "BspOokMsgVerAct portId,cpuFlag,fpgaFlag 1-flag",
    "getadvolt chan, type 0-rev 1-fwd",
    "getslavetemp portId",
    "BspSlaveInitProcess",
};

UINT32 ookexprnadd(void)
{
    UINT32 printCnt = 0;
    UINT32 loop = 0;

    printCnt = sizeof(g_ookExprn) / OOK_EXPRNADD_LEN;
    for(loop = 0; loop < printCnt; loop++)
    {
        exprnadd(g_ookExprn[loop]);
    }
    return BSP_OK;
}
UINT32 ookexprnquit(VOID)
{
     return exprnquit();
}
void ookhelp(void)
{
    UINT32 loop = 0;
    for(loop = 0; loop < NELEMENTS(ookPrintInfo);loop++)
    {
        dbgInfo("%s\n",ookPrintInfo[loop]);
    }
}
void ookrecven(UINT32 portId)
{
    BspRegRd(0, OOK_RAM_WR_ADDR_BACK, portId*0x10, &g_ulOokRdAddrCnt[portId]);
    dbgInfo("recv test portId %d start addr 0x%x\n", portId, g_ulOokRdAddrCnt[portId]);
}
UINT32 ookrecvtest(UINT32 portId)
{
    TookFrameApiPDU recv = {0};
    return OokRecvMsg(portId,&recv);
}

/*打印任意一段ram的内容*/
void rdookram(UINT32 portId)
{
    UINT32 loop = 0;
    UINT32 tmpData =0;
    UINT32 startaddr = g_ulOokRdAddrCnt[portId];
    UINT32 tmpCnt = 0;
    UINT32 len = 0;

    BspRegRd(0, OOK_RAM_WR_ADDR_BACK, portId*0x10, &tmpCnt);
    len = calcCurrRdAddrDelt(startaddr,tmpCnt);
    dbgInfo("startaddr %d tmpCnt %d len %d\n",startaddr, tmpCnt, len);
    for(loop = 0; loop < len; loop++)
    {
        tmpData = 0;
        BspRegWr(0,OOK_RAM_RD_ADDR,portId*0x10,(startaddr+1)%MAX_RECV_LEN_PER_PACK);
        BspRegRd(0,OOK_RAM_RD_DATA,portId*0x10,&tmpData);
        dbgInfo("loop %d  addr 0x%x  data 0x%x\n", loop, (startaddr+1)%MAX_RECV_LEN_PER_PACK, tmpData);
        startaddr++;
    }
}

/*向fpga写数据*/
UINT32 wrookram(UINT32 portId, UINT32 len)
{
    UINT32 retVal = BSP_OK;
    UINT32 loop = 0;
    UINT32 loopEx = 0;
    UINT32 loopCnt = 0;
    UINT32 exCnt = 0;
    UINT32 tmpData = 0;
    UINT32 chip = 0;
    UINT32 finalData = 0;

    loopCnt = len/MAX_SEND_LEN_PER_PACK;   /*完整包数*/
    ookrecven(portId);
    for(loopEx = 0; loopEx < loopCnt; loopEx++)
    {
        retVal = BspRegWr(chip, OOK_RAM_WR_ADDR_NUM, portId*0x10, MAX_SEND_LEN_PER_PACK);
        for(loop = 0; loop < MAX_SEND_LEN_PER_PACK; loop++)
        {
            finalData = (tmpData + loopEx+g_ulTestCnt)%(0xff+1);
            tmpData++;
            retVal |= BspRegWr(chip, OOK_RAM_WR_ADDR, portId*0x10,loop);
            retVal |= BspRegWr(chip, OOK_RAM_WR_DATA, portId*0x10, finalData);
            retVal |= BspRegWr(chip, OOK_RAM_WR_EN, portId*0x10, 1);
            retVal |= BspRegWr(chip, OOK_RAM_WR_EN, portId*0x10, 0);
            dbgInfoEx("loop %d  finalData 0x%x \n", loop, finalData);
        }
        g_ulTestCnt++;
        retVal |= BspRegWr(chip, OOK_RAM_WR_FINISH_FLAG, portId*0x10, 1);
        retVal |= BspRegWr(chip, OOK_RAM_WR_FINISH_FLAG, portId*0x10, 0);
    }

    exCnt = len%MAX_SEND_LEN_PER_PACK;   /*不足一包的*/
    retVal = BspRegWr(chip, OOK_RAM_WR_ADDR_NUM, portId*0x10, exCnt);
    for(loop = 0; loop < exCnt; loop++)
    {
        finalData = (tmpData + loopCnt+g_ulTestCnt)%(0xff+1);
        tmpData++;
        retVal |= BspRegWr(chip, OOK_RAM_WR_ADDR, portId*0x10,loop);
        retVal |= BspRegWr(chip, OOK_RAM_WR_DATA, portId*0x10, finalData);
        retVal |= BspRegWr(chip, OOK_RAM_WR_EN, portId*0x10, 1);
        retVal |= BspRegWr(chip, OOK_RAM_WR_EN, portId*0x10, 0);
        dbgInfoEx("loop %d  finalData 0x%x \n", loop, finalData);
    }
    g_ulTestCnt++;
    retVal |= BspRegWr(chip, OOK_RAM_WR_FINISH_FLAG, portId*0x10, 1);
    retVal |= BspRegWr(chip, OOK_RAM_WR_FINISH_FLAG, portId*0x10, 0);

    return retVal;
}

/*ook 收发自环 误码测试使用*/
void ooklooptest(UINT32 portId, UINT32 len)
{
    UINT32 loop = 0;
    UINT32 loopEx = 0;
    UINT32 tmpData[MAX_SEND_LEN_PER_PACK] = {0};
    UINT32 startaddr = 0;
    UINT32 tmpCnt = 0;
    UINT32 delt = 0;
    UINT32 finalData0 = 0;
    UINT32 finalData1 = 0;
    UINT32 g_ulTestErrCnt = 0;

    if(len > 0xff)  /*对端限制的最大字节数*/
    {
        dbgErr("len is invalid\n");
        return ;
    }
    BspRegWr(0,OOK_NORMAL_UART_CTRL,portId*0x10,0);
    wrookram(portId, len);
    startaddr = g_ulOokRdAddrCnt[portId];
    BspSysMsDelay_Sys(3000);
    BspRegRd(0, OOK_RAM_WR_ADDR_BACK, portId*0x10, &tmpCnt);
    delt = calcCurrRdAddrDelt(startaddr,tmpCnt);
    if(delt < len)
    {
        dbgErr("not all received len %d ,delt %d\n",len, delt);
        return ;
    }
    //dbgInfoEx("startaddr %d tmpCnt %d delt %d\n",startaddr, tmpCnt, delt);
    for(loop = 0; loop < delt; loop++)
    {
        BspRegWr(0,OOK_RAM_RD_ADDR,portId*0x10,(startaddr+1)%MAX_RECV_LEN_PER_PACK);
        BspRegRd(0,OOK_RAM_RD_DATA,portId*0x10,&tmpData[loop]);
        dbgInfoEx("loop %d  addr 0x%x  data 0x%x\n", loop, (startaddr+1)%MAX_RECV_LEN_PER_PACK, tmpData[loop]);
        startaddr++;
    }
    for(loop = 0; loop < delt; loop++)
    {
        finalData0 = (g_ulTestCnt-1)%(0xff+1);
        finalData1 = (g_ulTestCnt)%(0xff+1);
        //dbgInfoEx("%d %d %d %d\n",finalData0,finalData1,tmpData[loop],tmpData[loop+1] );
        if((tmpData[loop] == finalData0)&&(tmpData[loop+1] == finalData1))
        {
            break;
        }
    }
    if(loop == delt)
    {
        dbgErr("failed \n");
        return ;
    }
     for(loopEx = loop; loopEx < loop+len; loopEx++)
     {
        finalData0 = (g_ulTestCnt-1+loopEx-loop)%(0xff+1);
        if(tmpData[loopEx] != finalData0)
        {
            dbgErr("loopEx %d  addr 0x%x  data 0x%x  ori 0x%x\n", loopEx, (startaddr+1)%MAX_RECV_LEN_PER_PACK, tmpData[loopEx],finalData0);
            g_ulTestErrCnt++;
        }
      }

    dbgInfo("portId %d totalllen %d g_ulTestErrCnt %d\n",portId, len, g_ulTestErrCnt);

    return;
}
/********************************************************************************************************************/
/**************************************************************************
    函数名 称： OokMsgGetSlaveLinkSta(*)
    功能 描述： 0x0001消息-通过OOK消息获取子端的建链状态，这里注意入参判断好portid是母板还是子板
    输入参数 ： portId        - 端口号
    输出参数 ： pLinkSta        建链状态
    返回值  ：  BSP_OK: 成功 其他: 失败
    其他说明 ： 无
 ***********************************************************************/
/*获取对应端口的建链状态   与子端通信决定 受网管配置影响，因为网管配置的时候已经切了2T4T开关*/
UINT32 OokMsgGetSlaveLinkSta(UINT32 portId, T_OokMsgLinkSta *pLinkSta, T_OokMsgLinkStaAck *pLinkStaAck)
{
    UINT32     retVal = BSP_OK;
    UINT8     *pucApiBuff = NULL;
    TookFrameApiPDU *send = NULL;
    TookFrameApiPDU *recv = NULL;
    UINT16 dataLen = 0;

    INPUT_POINTER_CHECK(pLinkSta);
    pucApiBuff = (UINT8 *)malloc(sizeof(TookFrameApiPDU) + sizeof(TookFrameApiPDU));   /*两个完整的结构体 一个send用 一个recv用*/
    if (NULL == pucApiBuff)
    {
        retVal |= BIT_SET(0);
        dbgErr("%s>>TmpBuf Malloc Error!\n", __FUNCTION__);
        return retVal;
    }
    memset((VOID *)pucApiBuff, 0, sizeof(TookFrameApiPDU) + sizeof(TookFrameApiPDU));

    send = (TookFrameApiPDU *)&pucApiBuff[0];                              /*send起始位置*/
    recv = (TookFrameApiPDU *)&pucApiBuff[sizeof(TookFrameApiPDU)];        /*recv起始位置*/
    dataLen = sizeof(T_OokMsgLinkSta)+ sizeof(send->msgHead);
    send->head.startFlag1 = OOK_MSG_STARTFLAG1;
    send->head.startFlag2 = OOK_MSG_STARTFLAG2;
    send->head.versionreserverd1 = 0;
    send->head.reserverd2 = 0;
    send->head.dataLen = OOK_HTONS(dataLen);
    send->head.headSum = 0;
    send->msgHead.msgType = OOK_GET_SLAVE_LINK_STA;
    send->msgHead.msgSubType = 0;
    send->msgHead.serialNo = g_serialNo;
    send->msgHead.msgInfoLength = sizeof(T_OokMsgLinkSta);

    send->msg.slaveLinkSta.randCode = OOK_HTONL(pLinkSta->randCode);
    send->msg.slaveLinkSta.moduleGroupId = OOK_HTONL(pLinkSta->moduleGroupId);
    send->msg.slaveLinkSta.boardGroupId = OOK_HTONL(pLinkSta->boardGroupId);
    send->msg.slaveLinkSta.boardTypeId = OOK_HTONL(pLinkSta->boardTypeId);
    send->msg.slaveLinkSta.hwChangeId = OOK_HTONL(pLinkSta->hwChangeId);
    send->msg.slaveLinkSta.mcuLen = OOK_HTONL(pLinkSta->mcuLen);
    send->msg.slaveLinkSta.epldLen = OOK_HTONL(pLinkSta->epldLen);
    send->head.dataCrc = BspCountCRC8((UINT8*)&send->msgHead, dataLen);
    MsgPrint(PM_DEBUG,"mcuLen %d epldLen %d\n", pLinkSta->mcuLen,pLinkSta->epldLen);
    retVal = BspOokMsgProc(portId, send, recv);
    g_serialNo++;   /*8bit 溢出之后再重新计数*/
    if (retVal != BSP_OK)
    {
        MsgPrint(PM_DEBUG,"%s portId=%d send msg error!\n",__FUNCTION__,portId);  /*子端未接一直打印*/
        free(pucApiBuff);
        return retVal;
    }

    pLinkStaAck->ackData = recv->msg.slaveLinkStaAck.ackData;
    pLinkStaAck->moduleGroupId = OOK_NTOHL(recv->msg.slaveLinkStaAck.moduleGroupId);
    pLinkStaAck->boardGroupId = OOK_NTOHL(recv->msg.slaveLinkStaAck.boardGroupId);
    pLinkStaAck->boardTypeId = OOK_NTOHL(recv->msg.slaveLinkStaAck.boardTypeId);
    pLinkStaAck->hwChangeId = OOK_NTOHL(recv->msg.slaveLinkStaAck.hwChangeId);
    MsgPrint(PM_DEBUG,"ackdata %d moduleGroupId 0x%x boardGroupId 0x%x boardTypeId 0x%x hwChangeId 0x%x\n", pLinkStaAck->ackData,
    pLinkStaAck->moduleGroupId, pLinkStaAck->boardGroupId, pLinkStaAck->boardTypeId, pLinkStaAck->hwChangeId);
    memcpy_s(&pLinkStaAck->rfsBrdType, sizeof(pLinkStaAck->rfsBrdType), &recv->msg.slaveLinkStaAck.rfsBrdType, sizeof(pLinkStaAck->rfsBrdType));
    MsgPrint(PM_DEBUG,"rfsBrdType %s \n",pLinkStaAck->rfsBrdType);
    memcpy_s(&pLinkStaAck->cpuVer, sizeof(pLinkStaAck->cpuVer), &recv->msg.slaveLinkStaAck.cpuVer, sizeof(pLinkStaAck->cpuVer));
    MsgPrint(PM_DEBUG,"cpuver %s \n", pLinkStaAck->cpuVer);
    memcpy_s(&pLinkStaAck->fpgaVer, sizeof(pLinkStaAck->fpgaVer), &recv->msg.slaveLinkStaAck.fpgaVer, sizeof(pLinkStaAck->fpgaVer));
    MsgPrint(PM_DEBUG,"fpgaVer %s \n", pLinkStaAck->fpgaVer);
    pLinkStaAck->cpuUpgradeFlag = recv->msg.slaveLinkStaAck.cpuUpgradeFlag;
    pLinkStaAck->fpgaUpgradeFlag = recv->msg.slaveLinkStaAck.fpgaUpgradeFlag;
    pLinkStaAck->fpgaDevType = OOK_NTOHL(recv->msg.slaveLinkStaAck.fpgaDevType);
    pLinkStaAck->rfTblSize = OOK_NTOHL(recv->msg.slaveLinkStaAck.rfTblSize);
    pLinkStaAck->rfTblCrc32 = OOK_NTOHL(recv->msg.slaveLinkStaAck.rfTblCrc32);
    MsgPrint(PM_DEBUG,"cpuUpgradeFlag %d  fpgaUpgradeFlag %d fpgaDevType %d rfTblSize %d rfTblCrc32 %d\n",
       pLinkStaAck->cpuUpgradeFlag, pLinkStaAck->fpgaUpgradeFlag, pLinkStaAck->fpgaDevType, pLinkStaAck->rfTblSize, pLinkStaAck->rfTblCrc32);
    pLinkStaAck->rfChnNum = recv->msg.slaveLinkStaAck.rfChnNum;
    pLinkStaAck->cpuType = recv->msg.slaveLinkStaAck.cpuType;
    MsgPrint(PM_DEBUG,"rfChnNum %d cpuType %d\n", pLinkStaAck->rfChnNum, pLinkStaAck->cpuType);

    free(pucApiBuff);
    return retVal;
}

/**************************************************************************
    函数名 称： OokMsgGetSlaveLinkSta(*)
    功能 描述： 0x0002消息-通过OOK消息获取子端的心跳状态，这里注意入参判断好portid是母板还是子板
    输入参数 ： portId        - 端口号
    输出参数 ： pLinkSta        建链状态
    返回值  ：  BSP_OK: 成功 其他: 失败
    其他说明 ： 无
 ***********************************************************************/
UINT32 OokMsgGetSlaveHeartBeat(UINT32 portId, UINT32 *pHeatSta)
{
    UINT32     retVal = BSP_OK;
    UINT8     *pucApiBuff = NULL;
    TookFrameApiPDU *send = NULL;
    TookFrameApiPDU *recv = NULL;
    UINT16 dataLen = 0;

    INPUT_POINTER_CHECK(pHeatSta);
    pucApiBuff = (UINT8 *)malloc(sizeof(TookFrameApiPDU) + sizeof(TookFrameApiPDU));   /*两个完整的结构体 一个send用 一个recv用*/
    if (NULL == pucApiBuff)
    {
        retVal |= BIT_SET(0);
        dbgErr("%s>>TmpBuf Malloc Error!\n", __FUNCTION__);
        return retVal;
    }
    memset((VOID *)pucApiBuff, 0, sizeof(TookFrameApiPDU) + sizeof(TookFrameApiPDU));

    send = (TookFrameApiPDU *)&pucApiBuff[0];                              /*send起始位置*/
    recv = (TookFrameApiPDU *)&pucApiBuff[sizeof(TookFrameApiPDU)];        /*recv起始位置*/
    dataLen = sizeof(T_OokMsgHeartBeat)+ sizeof(send->msgHead);
    send->head.startFlag1 = OOK_MSG_STARTFLAG1;
    send->head.startFlag2 = OOK_MSG_STARTFLAG2;
    send->head.versionreserverd1 = 1;
    send->head.reserverd2 = 0;
    send->head.dataLen = OOK_HTONS(dataLen);
    send->head.headSum = 0;
    send->msgHead.msgType = OOK_GET_SLAVE_HEAT_STA;
    send->msgHead.msgSubType = 0;
    send->msgHead.serialNo = g_serialNo;
    send->msgHead.msgInfoLength = sizeof(T_OokMsgHeartBeat);
    send->head.dataCrc = BspCountCRC8((UINT8*)&send->msgHead, dataLen);

    retVal = BspOokMsgProc(portId, send, recv);
    g_serialNo++;   /*8bit 溢出之后再重新计数*/
    if (retVal != BSP_OK)
    {
        MsgPrint(PM_ERROR,"%s portId=%d send msg error!\n",__FUNCTION__,portId);
        free(pucApiBuff);
        return retVal;
    }

    *pHeatSta = (UINT32)recv->msg.slaveHearBeatAck.ackData;
    MsgPrint(PM_DEBUG,"heartSta %d\n", *pHeatSta);
    free(pucApiBuff);

    return retVal;
}

/**************************************************************************
    函数名 称： OokMsgSetSlaveRfSwitch(*)
    功能 描述： 0x0003消息-设置子端射频开关
    输入参数 ： portId        - 端口号
    输出参数 ：
    返回值  ：  BSP_OK: 成功 其他: 失败
    其他说明 ： 无
 ***********************************************************************/
UINT32 OokMsgSetSlaveRfSwitch(UINT32 portId, T_OokMsgRfSwitch *pSwitch)
{
    UINT32     retVal = BSP_OK;
    UINT8     *pucApiBuff = NULL;
    TookFrameApiPDU *send = NULL;
    TookFrameApiPDU *recv = NULL;
    UINT16 dataLen = 0;
    UINT32 msgLen = 0;

    INPUT_POINTER_CHECK(pSwitch);
    pucApiBuff = (UINT8 *)malloc(sizeof(TookFrameApiPDU) + sizeof(TookFrameApiPDU));   /*两个完整的结构体 一个send用 一个recv用*/
    if (NULL == pucApiBuff)
    {
        retVal |= BIT_SET(0);
        dbgErr("%s>>TmpBuf Malloc Error!\n", __FUNCTION__);
        return retVal;
    }
    memset((VOID *)pucApiBuff, 0, sizeof(TookFrameApiPDU) + sizeof(TookFrameApiPDU));
    msgLen = sizeof(T_OokMsgRfSwitch);

    send = (TookFrameApiPDU *)&pucApiBuff[0];                              /*send起始位置*/
    recv = (TookFrameApiPDU *)&pucApiBuff[sizeof(TookFrameApiPDU)];        /*recv起始位置*/
    dataLen = msgLen+ sizeof(send->msgHead);
    send->head.startFlag1 = OOK_MSG_STARTFLAG1;
    send->head.startFlag2 = OOK_MSG_STARTFLAG2;
    send->head.versionreserverd1 = 1;
    send->head.reserverd2 = 0;
    send->head.dataLen = OOK_HTONS(dataLen);
    send->head.headSum = 0;
    send->msgHead.msgType = OOK_SET_SLAVE_RF_SWITCH;
    send->msgHead.msgSubType = 0;
    send->msgHead.serialNo = g_serialNo;
    send->msgHead.msgInfoLength = msgLen;
    send->msg.slaveRfSwitch.rfChn = pSwitch->rfChn;
    send->msg.slaveRfSwitch.switchType = pSwitch->switchType;
    send->msg.slaveRfSwitch.onOffType = pSwitch->onOffType;
    send->msg.slaveRfSwitch.delayMs = OOK_HTONS(pSwitch->delayMs);
    send->head.dataCrc = BspCountCRC8((UINT8*)&send->msgHead, dataLen);

    retVal = BspOokMsgProc(portId, send, recv);
    g_serialNo++;   /*8bit 溢出之后再重新计数*/
    if (retVal != BSP_OK)
    {
        MsgPrint(PM_DEBUG,"%s portId=%d send msg error!\n",__FUNCTION__,portId);
        free(pucApiBuff);
        return retVal;
    }

    retVal = (UINT32)recv->msg.slaveRfSwitchAck.ackData;
    free(pucApiBuff);
    return retVal;
}

/**************************************************************************
    函数名 称： OokMsgSetSlaveLedSwitch(*)
    功能 描述： 0x0004消息-设置子端LED开关
    输入参数 ： portId        - 端口号
    输出参数 ： pSwitch        开关
    返回值  ：  BSP_OK: 成功 其他: 失败
    其他说明 ： 无
 ***********************************************************************/
UINT32 OokMsgSetSlaveLedSwitch(UINT32 portId, T_OokMsgLedSwitch *pSwitch)
{
    UINT32     retVal = BSP_OK;
    UINT8     *pucApiBuff = NULL;
    TookFrameApiPDU *send = NULL;
    TookFrameApiPDU *recv = NULL;
    UINT16 dataLen = 0;
    UINT32 msgLen = 0;

    INPUT_POINTER_CHECK(pSwitch);
    pucApiBuff = (UINT8 *)malloc(sizeof(TookFrameApiPDU) + sizeof(TookFrameApiPDU));   /*两个完整的结构体 一个send用 一个recv用*/
    if (NULL == pucApiBuff)
    {
        retVal |= BIT_SET(0);
        dbgErr("%s>>TmpBuf Malloc Error!\n", __FUNCTION__);
        return retVal;
    }
    memset((VOID *)pucApiBuff, 0, sizeof(TookFrameApiPDU) + sizeof(TookFrameApiPDU));
    msgLen = sizeof(T_OokMsgLedSwitch);

    send = (TookFrameApiPDU *)&pucApiBuff[0];                              /*send起始位置*/
    recv = (TookFrameApiPDU *)&pucApiBuff[sizeof(TookFrameApiPDU)];        /*recv起始位置*/
    dataLen = msgLen+ sizeof(send->msgHead);
    send->head.startFlag1 = OOK_MSG_STARTFLAG1;
    send->head.startFlag2 = OOK_MSG_STARTFLAG2;
    send->head.versionreserverd1 = 1;
    send->head.reserverd2 = 0;
    send->head.dataLen = OOK_HTONS(dataLen);
    send->head.headSum = 0;
    send->msgHead.msgType = OOK_SET_SLAVE_LED_SWITCH;
    send->msgHead.msgSubType = 0;
    send->msgHead.serialNo = g_serialNo;
    send->msgHead.msgInfoLength = msgLen;
    send->msg.slaveLedSwitch.ledType = pSwitch->ledType;
    send->msg.slaveLedSwitch.ctrlType = pSwitch->ctrlType;
    send->msg.slaveLedSwitch.onTimeMs = OOK_HTONS(pSwitch->onTimeMs);
    send->msg.slaveLedSwitch.offTimeMs = OOK_HTONS(pSwitch->offTimeMs);
    send->head.dataCrc = BspCountCRC8((UINT8*)&send->msgHead, dataLen);

    retVal = BspOokMsgProc(portId, send, recv);
    g_serialNo++;   /*8bit 溢出之后再重新计数*/
    if (retVal != BSP_OK)
    {
        MsgPrint(PM_ERROR,"%s portId=%d send msg error!\n",__FUNCTION__,portId);
        free(pucApiBuff);
        return retVal;
    }

    retVal = (UINT32)recv->msg.slaveLedSwitchAck.ackData;
    free(pucApiBuff);
    return retVal;
}

/**************************************************************************
    函数名 称： OokMsgSetSlaveGridVolt(*)
    功能 描述： 0x0005消息-设置子端栅压
    输入参数 ： portId        - 端口号
    输出参数 ： pSwitch       - 栅压配置信息
    返回值  ：  BSP_OK: 成功 其他: 失败
    其他说明 ： 无
 ***********************************************************************/
UINT32 OokMsgSetSlaveGridVolt(UINT32 portId, T_OokMsgGridVoltCfg *pSwitch)
{
    UINT32     retVal = BSP_OK;
    UINT8     *pucApiBuff = NULL;
    TookFrameApiPDU *send = NULL;
    TookFrameApiPDU *recv = NULL;
    UINT16 dataLen = 0;
    UINT32 msgLen = 0;

    INPUT_POINTER_CHECK(pSwitch);
    pucApiBuff = (UINT8 *)malloc(sizeof(TookFrameApiPDU) + sizeof(TookFrameApiPDU));   /*两个完整的结构体 一个send用 一个recv用*/
    if (NULL == pucApiBuff)
    {
        retVal |= BIT_SET(0);
        dbgErr("%s>>TmpBuf Malloc Error!\n", __FUNCTION__);
        return retVal;
    }
    memset((VOID *)pucApiBuff, 0, sizeof(TookFrameApiPDU) + sizeof(TookFrameApiPDU));
    msgLen = sizeof(T_OokMsgGridVoltCfg);

    send = (TookFrameApiPDU *)&pucApiBuff[0];                              /*send起始位置*/
    recv = (TookFrameApiPDU *)&pucApiBuff[sizeof(TookFrameApiPDU)];        /*recv起始位置*/
    dataLen = msgLen+ sizeof(send->msgHead);
    send->head.startFlag1 = OOK_MSG_STARTFLAG1;
    send->head.startFlag2 = OOK_MSG_STARTFLAG2;
    send->head.versionreserverd1 = 1;
    send->head.reserverd2 = 0;
    send->head.dataLen = OOK_HTONS(dataLen);
    send->head.headSum = 0;
    send->msgHead.msgType = OOK_SET_SLAVE_GRID_VOLT;
    send->msgHead.msgSubType = 0;
    send->msgHead.serialNo = g_serialNo;
    send->msgHead.msgInfoLength = msgLen;
    send->msg.slaveGridVoltCfg.dacChipIdx = pSwitch->dacChipIdx;
    send->msg.slaveGridVoltCfg.innerChan = pSwitch->innerChan;
    send->msg.slaveGridVoltCfg.voltMv = OOK_HTONS(pSwitch->voltMv);
    send->head.dataCrc = BspCountCRC8((UINT8*)&send->msgHead, dataLen);

    retVal = BspOokMsgProc(portId, send, recv);
    g_serialNo++;   /*8bit 溢出之后再重新计数*/
    if (retVal != BSP_OK)
    {
        MsgPrint(PM_ERROR,"%s portId=%d send msg error!\n",__FUNCTION__,portId);
        free(pucApiBuff);
        return retVal;
    }

    retVal = (UINT32)recv->msg.slaveGridVoltCfgAck.ackData;
    free(pucApiBuff);

    return retVal;
}

/**************************************************************************
    函数名 称： OokMsgRfTblDownLoadReq(*)
    功能 描述： 0x0006消息-离线参数下载请求
    输入参数 ： portId        -
    输出参数 ：        -
    返回值  ：  BSP_OK: 成功 其他: 失败
    其他说明 ： 无
 ***********************************************************************/
UINT32 OokMsgRfTblDownLoadReq(UINT32 portId, T_OokMsgRfTblDownLoadReq *pRfTblReq, T_OokMsgRfTblDownLoadReqAck *pRfTblReqAck)
{
    UINT32     retVal = BSP_OK;
    UINT8     *pucApiBuff = NULL;
    TookFrameApiPDU *send = NULL;
    TookFrameApiPDU *recv = NULL;
    UINT16 dataLen = 0;
    UINT32 msgLen = 0;

    INPUT_POINTER_CHECK(pRfTblReq);
    INPUT_POINTER_CHECK(pRfTblReqAck);
    pucApiBuff = (UINT8 *)malloc(sizeof(TookFrameApiPDU) + sizeof(TookFrameApiPDU));   /*两个完整的结构体 一个send用 一个recv用*/
    if (NULL == pucApiBuff)
    {
        retVal |= BIT_SET(0);
        dbgErr("%s>>TmpBuf Malloc Error!\n", __FUNCTION__);
        return retVal;
    }
    memset((VOID *)pucApiBuff, 0, sizeof(TookFrameApiPDU) + sizeof(TookFrameApiPDU));
    msgLen = sizeof(T_OokMsgRfTblDownLoadReq);

    send = (TookFrameApiPDU *)&pucApiBuff[0];                              /*send起始位置*/
    recv = (TookFrameApiPDU *)&pucApiBuff[sizeof(TookFrameApiPDU)];        /*recv起始位置*/
    dataLen = msgLen+ sizeof(send->msgHead);
    send->head.startFlag1 = OOK_MSG_STARTFLAG1;
    send->head.startFlag2 = OOK_MSG_STARTFLAG2;
    send->head.versionreserverd1 = 1;
    send->head.reserverd2 = 0;
    send->head.dataLen = OOK_HTONS(dataLen);
    send->head.headSum = 0;
    send->msgHead.msgType = OOK_RFTBL_DOWNLOAD_REQ;
    send->msgHead.msgSubType = 0;
    send->msgHead.serialNo = g_serialNo;
    send->msgHead.msgInfoLength = msgLen;
    send->msg.rfTblDownLoadReq.fileSize = OOK_HTONL(pRfTblReq->fileSize);
    send->msg.rfTblDownLoadReq.crc32 = OOK_HTONL(pRfTblReq->crc32);
    send->msg.rfTblDownLoadReq.tblType = pRfTblReq->tblType;
    send->head.dataCrc = BspCountCRC8((UINT8*)&send->msgHead, dataLen);

    MsgPrint(PM_DEBUG,"fileSize 0x%x crc32 0x%x tblType %d\n",pRfTblReq->fileSize, pRfTblReq->crc32, pRfTblReq->tblType);
    retVal = BspOokMsgProc(portId, send, recv);
    g_serialNo++;   /*8bit 溢出之后再重新计数*/
    if (retVal != BSP_OK)
    {
        MsgPrint(PM_ERROR,"%s portId=%d send msg error!\n",__FUNCTION__,portId);
        free(pucApiBuff);
        return retVal;
    }

    pRfTblReqAck->ackData = recv->msg.rfTblDownLoadReqAck.ackData;
    pRfTblReqAck->compareResult = recv->msg.rfTblDownLoadReqAck.compareResult;
    pRfTblReqAck->fileSize = OOK_NTOHL(recv->msg.rfTblDownLoadReqAck.fileSize);
    pRfTblReqAck->crc32 = OOK_NTOHL(recv->msg.rfTblDownLoadReqAck.crc32);
    MsgPrint(PM_DEBUG,"compareResult 0x%x fileSize 0x%x crc32 0x%x\n", pRfTblReqAck->compareResult, pRfTblReqAck->fileSize,pRfTblReqAck->crc32);
    free(pucApiBuff);
    return retVal;
}

/**************************************************************************
    函数名 称： OokMsgRfTblDownLoad(*)
    功能 描述： 0x0007消息-离线参数下载
    输入参数 ： portId        - 端口号
    输出参数 ：
    返回值  ：  BSP_OK: 成功 其他: 失败
    其他说明 ： 无
 ***********************************************************************/
UINT32 OokMsgRfTblDownLoad(UINT32 portId, T_OokMsgRfTblDownLoad *pRfTbl, T_OokMsgRfTblDownLoadAck *pRfTblAck)
{
    UINT32     retVal = BSP_OK;
    UINT8     *pucApiBuff = NULL;
    TookFrameApiPDU *send = NULL;
    TookFrameApiPDU *recv = NULL;
    UINT16 dataLen = 0;
    UINT32 msgLen = 0;

    INPUT_POINTER_CHECK(pRfTbl);
    INPUT_POINTER_CHECK(pRfTblAck);
    pucApiBuff = (UINT8 *)malloc(sizeof(TookFrameApiPDU) + sizeof(TookFrameApiPDU));   /*两个完整的结构体 一个send用 一个recv用*/
    if (NULL == pucApiBuff)
    {
        retVal |= BIT_SET(0);
        dbgErr("%s>>TmpBuf Malloc Error!\n", __FUNCTION__);
        return retVal;
    }
    memset((VOID *)pucApiBuff, 0, sizeof(TookFrameApiPDU) + sizeof(TookFrameApiPDU));
    msgLen = sizeof(T_OokMsgRfTblDownLoad);

    send = (TookFrameApiPDU *)&pucApiBuff[0];                              /*send起始位置*/
    recv = (TookFrameApiPDU *)&pucApiBuff[sizeof(TookFrameApiPDU)];        /*recv起始位置*/
    dataLen = msgLen+ sizeof(send->msgHead);
    send->head.startFlag1 = OOK_MSG_STARTFLAG1;
    send->head.startFlag2 = OOK_MSG_STARTFLAG2;
    send->head.versionreserverd1 = 1;
    send->head.reserverd2 = 0;
    send->head.dataLen = OOK_HTONS(dataLen);
    send->head.headSum = 0;
    send->msgHead.msgType = OOK_RFTBL_DOWNLOAD;
    send->msgHead.msgSubType = 0;
    send->msgHead.serialNo = g_serialNo;
    send->msgHead.msgInfoLength = msgLen;
    send->msg.rfTblDownLoad.dataOffset = OOK_HTONL(pRfTbl->dataOffset);
    send->msg.rfTblDownLoad.dataSize = pRfTbl->dataSize;
    send->msg.rfTblDownLoad.fileType = pRfTbl->fileType;
    memcpy_s(send->msg.rfTblDownLoad.data, sizeof(send->msg.rfTblDownLoad.data), pRfTbl->data, pRfTbl->dataSize);
    send->head.dataCrc = BspCountCRC8((UINT8*)&send->msgHead, dataLen);
    retVal = BspOokMsgProc(portId, send, recv);
    g_serialNo++;   /*8bit 溢出之后再重新计数*/
    if (retVal != BSP_OK)
    {
        MsgPrint(PM_ERROR,"%s portId=%d send msg error!\n",__FUNCTION__,portId);
        free(pucApiBuff);
        return retVal;
    }

    pRfTblAck->ackData = recv->msg.rfTblDownLoadAck.ackData;
    pRfTblAck->fileSize = OOK_NTOHL(recv->msg.rfTblDownLoadAck.fileSize);
    pRfTblAck->crc32 = OOK_NTOHL(recv->msg.rfTblDownLoadReq.crc32);
    MsgPrint(PM_DEBUG,"ackData 0x%x fileSize 0x%x crc32 0x%x\n", pRfTblAck->ackData, pRfTblAck->fileSize,pRfTblAck->crc32);

    free(pucApiBuff);
    return retVal;
}

/**************************************************************************
    函数名 称： OokMsgRfTblDownLoadReq(*)
    功能 描述： 0x0008消息-离线参数上传请求
    输入参数 ： portId        -
    输出参数 ：        -
    返回值  ：  BSP_OK: 成功 其他: 失败
    其他说明 ： 无
 ***********************************************************************/
UINT32 OokMsgRfTblUpLoadReq(UINT32 portId, T_OokMsgRfTblUpLoadReq *pRfTblReq, T_OokMsgRfTblUpLoadReqAck *pRfTblReqAck)
{
    UINT32     retVal = BSP_OK;
    UINT8     *pucApiBuff = NULL;
    TookFrameApiPDU *send = NULL;
    TookFrameApiPDU *recv = NULL;
    UINT16 dataLen = 0;
    UINT32 msgLen = 0;

    INPUT_POINTER_CHECK(pRfTblReq);
    INPUT_POINTER_CHECK(pRfTblReqAck);
    pucApiBuff = (UINT8 *)malloc(sizeof(TookFrameApiPDU) + sizeof(TookFrameApiPDU));   /*两个完整的结构体 一个send用 一个recv用*/
    if (NULL == pucApiBuff)
    {
        retVal |= BIT_SET(0);
        dbgErr("%s>>TmpBuf Malloc Error!\n", __FUNCTION__);
        return retVal;
    }
    memset((VOID *)pucApiBuff, 0, sizeof(TookFrameApiPDU) + sizeof(TookFrameApiPDU));
    msgLen = sizeof(T_OokMsgRfTblUpLoadReq);

    send = (TookFrameApiPDU *)&pucApiBuff[0];                              /*send起始位置*/
    recv = (TookFrameApiPDU *)&pucApiBuff[sizeof(TookFrameApiPDU)];        /*recv起始位置*/
    dataLen = msgLen+ sizeof(send->msgHead);
    send->head.startFlag1 = OOK_MSG_STARTFLAG1;
    send->head.startFlag2 = OOK_MSG_STARTFLAG2;
    send->head.versionreserverd1 = 1;
    send->head.reserverd2 = 0;
    send->head.dataLen = OOK_HTONS(dataLen);
    send->head.headSum = 0;
    send->msgHead.msgType = OOK_RFTBL_UPLOAD_REQ;
    send->msgHead.msgSubType = 0;
    send->msgHead.serialNo = g_serialNo;
    send->msgHead.msgInfoLength = msgLen;
    send->msg.rfTblUpLoadReq.fileSize = OOK_HTONL(pRfTblReq->fileSize);
    send->msg.rfTblUpLoadReq.crc32 = OOK_HTONL(pRfTblReq->crc32);
    send->msg.rfTblUpLoadReq.tblType = pRfTblReq->tblType;
    send->head.dataCrc = BspCountCRC8((UINT8*)&send->msgHead, dataLen);
    MsgPrint(PM_DEBUG,"fileSize 0x%x crc32 0x%x tblType 0x%x\n",pRfTblReq->fileSize, pRfTblReq->crc32, pRfTblReq->tblType);

    retVal = BspOokMsgProc(portId, send, recv);
    g_serialNo++;   /*8bit 溢出之后再重新计数*/
    if (retVal != BSP_OK)
    {
        MsgPrint(PM_ERROR,"%s portId=%d send msg error!\n",__FUNCTION__,portId);
        free(pucApiBuff);
        return retVal;
    }

    pRfTblReqAck->ackData = recv->msg.rfTblUpLoadReqAck.ackData;
    pRfTblReqAck->compareResult = recv->msg.rfTblUpLoadReqAck.compareResult;
    pRfTblReqAck->fileSize = OOK_NTOHL(recv->msg.rfTblUpLoadReqAck.fileSize);
    pRfTblReqAck->crc32 = OOK_NTOHL(recv->msg.rfTblUpLoadReqAck.crc32);

    MsgPrint(PM_DEBUG,"ackData 0x%x compareResult 0x%x fileSize 0x%x crc32 0x%x \n",
    pRfTblReqAck->ackData, pRfTblReqAck->compareResult, pRfTblReqAck->fileSize, pRfTblReqAck->crc32);
    free(pucApiBuff);

    return retVal;
}

/**************************************************************************
    函数名 称： OokMsgRfTblUpLoad(*)
    功能 描述： 0x0009消息-离线参数上传
    输入参数 ： portId        - 端口号
    输出参数 ：
    返回值  ：  BSP_OK: 成功 其他: 失败
    其他说明 ： 无
 ***********************************************************************/
UINT32 OokMsgRfTblUpLoad(UINT32 portId, T_OokMsgRfTblUpLoad *pRfTbl, T_OokMsgRfTblUpLoadAck *pRfTblAck)
{
    UINT32     retVal = BSP_OK;
    UINT8     *pucApiBuff = NULL;
    TookFrameApiPDU *send = NULL;
    TookFrameApiPDU *recv = NULL;
    UINT16 dataLen = 0;
    UINT32 msgLen = 0;

    INPUT_POINTER_CHECK(pRfTbl);
    INPUT_POINTER_CHECK(pRfTblAck);
    pucApiBuff = (UINT8 *)malloc(sizeof(TookFrameApiPDU) + sizeof(TookFrameApiPDU));   /*两个完整的结构体 一个send用 一个recv用*/
    if (NULL == pucApiBuff)
    {
        retVal |= BIT_SET(0);
        dbgErr("%s>>TmpBuf Malloc Error!\n", __FUNCTION__);
        return retVal;
    }
    memset((VOID *)pucApiBuff, 0, sizeof(TookFrameApiPDU) + sizeof(TookFrameApiPDU));
    msgLen = sizeof(T_OokMsgRfTblUpLoad);

    send = (TookFrameApiPDU *)&pucApiBuff[0];                              /*send起始位置*/
    recv = (TookFrameApiPDU *)&pucApiBuff[sizeof(TookFrameApiPDU)];        /*recv起始位置*/
    dataLen = msgLen+ sizeof(send->msgHead);
    send->head.startFlag1 = OOK_MSG_STARTFLAG1;
    send->head.startFlag2 = OOK_MSG_STARTFLAG2;
    send->head.versionreserverd1 = 1;
    send->head.reserverd2 = 0;
    send->head.dataLen = OOK_HTONS(dataLen);
    send->head.headSum = 0;
    send->msgHead.msgType = OOK_RFTBL_UPLOAD;
    send->msgHead.msgSubType = 0;
    send->msgHead.serialNo = g_serialNo;
    send->msgHead.msgInfoLength = msgLen;
    send->msg.rfTblUpLoad.dataOffset = OOK_HTONL(pRfTbl->dataOffset);
    send->msg.rfTblUpLoad.dataSize = pRfTbl->dataSize;
    send->msg.rfTblUpLoad.tblType = pRfTbl->tblType;
    send->head.dataCrc = BspCountCRC8((UINT8*)&send->msgHead, dataLen);
    MsgPrint(PM_DEBUG,"%s dataSize= 0x%x dataOffset 0x%x\n",__FUNCTION__,send->msg.rfTblUpLoad.dataSize, send->msg.rfTblUpLoad.dataOffset);

    retVal = BspOokMsgProc(portId, send, recv);
    g_serialNo++;   /*8bit 溢出之后再重新计数*/
    if (retVal != BSP_OK)
    {
        MsgPrint(PM_ERROR,"%s portId=%d send msg error!\n",__FUNCTION__,portId);
        free(pucApiBuff);
        return retVal;
    }

    pRfTblAck->ackData = recv->msg.rfTblUpLoadAck.ackData;
    pRfTblAck->dataOffset =  OOK_NTOHL(recv->msg.rfTblUpLoadAck.dataOffset);
    pRfTblAck->dataSize = recv->msg.rfTblUpLoadAck.dataSize;
    memcpy_s(pRfTblAck->data, sizeof(recv->msg.rfTblUpLoadAck.data),recv->msg.rfTblUpLoadAck.data,pRfTbl->dataSize);
    MsgPrint(PM_DEBUG,"ackData 0x%x dataOffset 0x%x dataSize 0x%x\n",pRfTblAck->ackData,  pRfTblAck->dataOffset, pRfTblAck->dataSize);
    MsgPrint(PM_DEBUG,"%s\n",pRfTblAck->data);
    free(pucApiBuff);
    return retVal;
}


/**************************************************************************
    函数名 称： OokMsgCmd(*)
    功能 描述： 0x00a消息-ookcmd
    输入参数 ： portId        - 端口号
    输出参数 ：
    返回值  ：  BSP_OK: 成功 其他: 失败
    其他说明 ： 无
 ***********************************************************************/
UINT32 OokMsgCmd(UINT32 portId, char *pCmd)
{
    UINT32     retVal = BSP_OK;
    UINT8     *pucApiBuff = NULL;
    TookFrameApiPDU *send = NULL;
    TookFrameApiPDU *recv = NULL;
    UINT16 dataLen = 0;
    T_OokMsgCmdAck ookCmdAck = {0};

    INPUT_POINTER_CHECK(pCmd);
    pucApiBuff = (UINT8 *)malloc(sizeof(TookFrameApiPDU) + sizeof(TookFrameApiPDU));   /*两个完整的结构体 一个send用 一个recv用*/
    if (NULL == pucApiBuff)
    {
        retVal |= BIT_SET(0);
        dbgErr("%s>>TmpBuf Malloc Error!\n", __FUNCTION__);
        return retVal;
    }
    memset((VOID *)pucApiBuff, 0, sizeof(TookFrameApiPDU) + sizeof(TookFrameApiPDU));

    send = (TookFrameApiPDU *)&pucApiBuff[0];                              /*send起始位置*/
    recv = (TookFrameApiPDU *)&pucApiBuff[sizeof(TookFrameApiPDU)];        /*recv起始位置*/
    dataLen = sizeof(T_OokMsgCmd)+ sizeof(send->msgHead);
    send->head.startFlag1 = OOK_MSG_STARTFLAG1;
    send->head.startFlag2 = OOK_MSG_STARTFLAG2;
    send->head.versionreserverd1 = 1;
    send->head.reserverd2 = 0;
    send->head.dataLen = OOK_HTONS(dataLen);
    send->head.headSum = 0;
    send->msgHead.msgType = OOK_TEST_CMD;
    send->msgHead.msgSubType = 0;
    send->msgHead.serialNo = g_serialNo;
    send->msgHead.msgInfoLength = sizeof(T_OokMsgCmd);

    memcpy_s(&send->msg.slaveOokCmd, strlen(pCmd), pCmd, strlen(pCmd));
    send->head.dataCrc = BspCountCRC8((UINT8*)&send->msgHead, dataLen);
    retVal = BspOokMsgProc(portId, send, recv);
    g_serialNo++;   /*8bit 溢出之后再重新计数*/
    if (retVal != BSP_OK)
    {
        MsgPrint(PM_ERROR,"%s portId=%d send msg error!\n",__FUNCTION__,portId);
        free(pucApiBuff);
        return retVal;
    }
    memcpy_s(&ookCmdAck, sizeof(T_OokMsgCmdAck), &recv->msg.slaveOokCmdAck, sizeof(T_OokMsgCmdAck));
    retVal = recv->msg.slaveOokCmdAck.ackData;
    dbgInfo("%s\n",ookCmdAck.printBuff);

    free(pucApiBuff);
    return retVal;
}

/*0xb版本比较*/
UINT32 OokMsgVerCmp(UINT32 portId, T_OokMsgVerCmp *pVerCmp, T_OokMsgVerCmpAck *pVerCmpAck)
{
    UINT32     retVal = BSP_OK;
    UINT8     *pucApiBuff = NULL;
    TookFrameApiPDU *send = NULL;
    TookFrameApiPDU *recv = NULL;
    UINT16 dataLen = 0;

    INPUT_POINTER_CHECK(pVerCmp);
    INPUT_POINTER_CHECK(pVerCmpAck);
    pucApiBuff = (UINT8 *)malloc(sizeof(TookFrameApiPDU) + sizeof(TookFrameApiPDU));   /*两个完整的结构体 一个send用 一个recv用*/
    if (NULL == pucApiBuff)
    {
        retVal |= BIT_SET(0);
        dbgErr("%s>>TmpBuf Malloc Error!\n", __FUNCTION__);
        return retVal;
    }
    memset((VOID *)pucApiBuff, 0, sizeof(TookFrameApiPDU) + sizeof(TookFrameApiPDU));

    send = (TookFrameApiPDU *)&pucApiBuff[0];                              /*send起始位置*/
    recv = (TookFrameApiPDU *)&pucApiBuff[sizeof(TookFrameApiPDU)];        /*recv起始位置*/
    dataLen = sizeof(T_OokMsgVerCmp)+ sizeof(send->msgHead);
    send->head.startFlag1 = OOK_MSG_STARTFLAG1;
    send->head.startFlag2 = OOK_MSG_STARTFLAG2;
    send->head.versionreserverd1 = 1;
    send->head.reserverd2 = 0;
    send->head.dataLen = OOK_HTONS(dataLen);
    send->head.headSum = 0;
    send->msgHead.msgType = OOK_VER_CMP;
    send->msgHead.msgSubType = 0;
    send->msgHead.serialNo = g_serialNo;
    send->msgHead.msgInfoLength = sizeof(T_OokMsgVerCmp);
    send->msg.slaveVerCmp.cpuCmpResult = pVerCmp->cpuCmpResult;
    send->msg.slaveVerCmp.cpuCrc32 = OOK_HTONL(pVerCmp->cpuCrc32);
    memcpy_s(send->msg.slaveVerCmp.cpuVer,sizeof(send->msg.slaveVerCmp.cpuVer),pVerCmp->cpuVer,sizeof(pVerCmp->cpuVer));
    send->msg.slaveVerCmp.fpgaCmpResult = pVerCmp->fpgaCmpResult;
    send->msg.slaveVerCmp.fpgaCrc32 = OOK_HTONL(pVerCmp->fpgaCrc32);
    memcpy_s(send->msg.slaveVerCmp.fpgaVer,sizeof(send->msg.slaveVerCmp.fpgaVer),pVerCmp->cpuVer,sizeof(pVerCmp->fpgaVer));
    MsgPrint(PM_DEBUG, "cpuCmpResult 0x%x cpuCrc32 0x%x cpuVer %s\n",pVerCmp->cpuCmpResult, pVerCmp->cpuCrc32, pVerCmp->cpuVer);
    MsgPrint(PM_DEBUG, "fpgaCmpResult 0x%x fpgaCrc32 0x%x fpgaVer %s\n",pVerCmp->fpgaCmpResult, pVerCmp->fpgaCrc32, pVerCmp->fpgaVer);
    send->head.dataCrc = BspCountCRC8((UINT8*)&send->msgHead, dataLen);
    retVal = BspOokMsgProc(portId, send, recv);
    g_serialNo++;   /*8bit 溢出之后再重新计数*/
    if (retVal != BSP_OK)
    {
        MsgPrint(PM_ERROR,"%s portId=%d send msg error!\n",__FUNCTION__,portId);
        free(pucApiBuff);
        return retVal;
    }
    pVerCmpAck->ackData = recv->msg.slaveVerCmpAck.ackData;
    MsgPrint(PM_DEBUG, "ackData 0x%x\n",pVerCmpAck->ackData);

    free(pucApiBuff);
    return retVal;
}

/*0xc版本下载*/
UINT32 OokMsgVerDownLoad(UINT32 portId, T_OokMsgVerDownLoad *pVerDown, T_OokMsgVerDownLoadAck *pVerDownAck)
{
    UINT32     retVal = BSP_OK;
    UINT8     *pucApiBuff = NULL;
    TookFrameApiPDU *send = NULL;
    TookFrameApiPDU *recv = NULL;
    UINT16 dataLen = 0;

    INPUT_POINTER_CHECK(pVerDown);
    INPUT_POINTER_CHECK(pVerDownAck);
    pucApiBuff = (UINT8 *)malloc(sizeof(TookFrameApiPDU) + sizeof(TookFrameApiPDU));   /*两个完整的结构体 一个send用 一个recv用*/
    if (NULL == pucApiBuff)
    {
        retVal |= BIT_SET(0);
        dbgErr("%s>>TmpBuf Malloc Error!\n", __FUNCTION__);
        return retVal;
    }
    memset((VOID *)pucApiBuff, 0, sizeof(TookFrameApiPDU) + sizeof(TookFrameApiPDU));

    send = (TookFrameApiPDU *)&pucApiBuff[0];                              /*send起始位置*/
    recv = (TookFrameApiPDU *)&pucApiBuff[sizeof(TookFrameApiPDU)];        /*recv起始位置*/
    dataLen = sizeof(T_OokMsgVerDownLoad)+ sizeof(send->msgHead);
    send->head.startFlag1 = OOK_MSG_STARTFLAG1;
    send->head.startFlag2 = OOK_MSG_STARTFLAG2;
    send->head.versionreserverd1 = 1;
    send->head.reserverd2 = 0;
    send->head.dataLen = OOK_HTONS(dataLen);
    send->head.headSum = 0;
    send->msgHead.msgType = OOK_VER_DOWNLOAD;
    send->msgHead.msgSubType = 0;
    send->msgHead.serialNo = g_serialNo;
    send->msgHead.msgInfoLength = sizeof(T_OokMsgVerDownLoad);

    send->msg.slaveVerDownLoad.verType = pVerDown->verType;
    send->msg.slaveVerDownLoad.dataOffSet = OOK_HTONL(pVerDown->dataOffSet);
    send->msg.slaveVerDownLoad.dataSize = pVerDown->dataSize;
    memcpy_s(&send->msg.slaveVerDownLoad.data,sizeof(send->msg.slaveVerDownLoad.data),&pVerDown->data,sizeof(pVerDown->data));
    send->head.dataCrc = BspCountCRC8((UINT8*)&send->msgHead, dataLen);
    MsgPrint(PM_DEBUG, "dataCrc 0x%x\n", send->head.dataCrc);
    MsgPrint(PM_DEBUG, "verType 0x%x dataOffSet 0x%x  dataSize 0x%x\n",pVerDown->verType, pVerDown->dataOffSet, pVerDown->dataSize);
    MsgPrint(PM_DEBUG, "dataoffset 0x%x\n",send->msg.slaveVerDownLoad.dataOffSet);
    retVal = BspOokMsgProc(portId, send, recv);
    g_serialNo++;   /*8bit 溢出之后再重新计数*/
    if (retVal != BSP_OK)
    {
        MsgPrint(PM_ERROR,"%s portId=%d send msg error!\n",__FUNCTION__,portId);
        free(pucApiBuff);
        return retVal;
    }
    pVerDownAck->ackData = recv->msg.slaveVerDownLoadAck.ackData;
    pVerDownAck->fileSize = OOK_NTOHL(recv->msg.slaveVerDownLoadAck.fileSize);
    pVerDownAck->crc32 = OOK_NTOHL(recv->msg.slaveVerDownLoadAck.crc32);
    MsgPrint(PM_DEBUG, "ackData 0x%x fileSize 0x%x crc32 0x%x\n",pVerDownAck->ackData, pVerDownAck->fileSize, pVerDownAck->crc32);

    free(pucApiBuff);
    return retVal;
}

/*0xd版本激活*/
UINT32 OokMsgVerActive(UINT32 portId, T_OokMsgVerAct *pVerAct, T_OokMsgVerActAck *pVerActAck)
{
    UINT32     retVal = BSP_OK;
    UINT8     *pucApiBuff = NULL;
    TookFrameApiPDU *send = NULL;
    TookFrameApiPDU *recv = NULL;
    UINT16 dataLen = 0;

    INPUT_POINTER_CHECK(pVerAct);
    INPUT_POINTER_CHECK(pVerActAck);
    pucApiBuff = (UINT8 *)malloc(sizeof(TookFrameApiPDU) + sizeof(TookFrameApiPDU));   /*两个完整的结构体 一个send用 一个recv用*/
    if (NULL == pucApiBuff)
    {
        retVal |= BIT_SET(0);
        dbgErr("%s>>TmpBuf Malloc Error!\n", __FUNCTION__);
        return retVal;
    }
    memset((VOID *)pucApiBuff, 0, sizeof(TookFrameApiPDU) + sizeof(TookFrameApiPDU));

    send = (TookFrameApiPDU *)&pucApiBuff[0];                              /*send起始位置*/
    recv = (TookFrameApiPDU *)&pucApiBuff[sizeof(TookFrameApiPDU)];        /*recv起始位置*/
    dataLen = sizeof(T_OokMsgVerAct)+ sizeof(send->msgHead);
    send->head.startFlag1 = OOK_MSG_STARTFLAG1;
    send->head.startFlag2 = OOK_MSG_STARTFLAG2;
    send->head.versionreserverd1 = 1;
    send->head.reserverd2 = 0;
    send->head.dataLen = OOK_HTONS(dataLen);
    send->head.headSum = 0;
    send->msgHead.msgType = OOK_VER_ACT;
    send->msgHead.msgSubType = 0;
    send->msgHead.serialNo = g_serialNo;
    send->msgHead.msgInfoLength = sizeof(T_OokMsgVerAct);

    send->msg.slaveVerAct.cpuVerActFlag = pVerAct->cpuVerActFlag;
    send->msg.slaveVerAct.fpgaVerActFlag = pVerAct->fpgaVerActFlag;
    send->msg.slaveVerAct.secBootVerActFlag = pVerAct->secBootVerActFlag;
    send->head.dataCrc = BspCountCRC8((UINT8*)&send->msgHead, dataLen);
    MsgPrint(PM_DEBUG, "cpuVerActFlag 0x%x fpgaVerActFlag 0x%x  secBootVerActFlag 0x%x\n",
                        pVerAct->cpuVerActFlag, pVerAct->fpgaVerActFlag, pVerAct->secBootVerActFlag);
    retVal = BspOokMsgProc(portId, send, recv);
    g_serialNo++;   /*8bit 溢出之后再重新计数*/
    if (retVal != BSP_OK)
    {
        MsgPrint(PM_ERROR,"%s portId=%d send msg error!\n",__FUNCTION__,portId);
        free(pucApiBuff);
        return retVal;
    }
    pVerActAck->ackData = recv->msg.slaveVerActAck.ackData;
    MsgPrint(PM_DEBUG, "ackData 0x%x \n", pVerActAck->ackData);

    free(pucApiBuff);
    return retVal;
}

/*0xe时延测量*/
UINT32 OokMsgDlyMeasure(UINT32 portId, T_OokMsgDlyMeas *pDlyMeas, T_OokMsgDlyMeasAck *pDlyMeasAck)
{
    UINT32     retVal = BSP_OK;
    UINT8     *pucApiBuff = NULL;
    TookFrameApiPDU *send = NULL;
    TookFrameApiPDU *recv = NULL;
    UINT16 dataLen = 0;

    INPUT_POINTER_CHECK(pDlyMeas);
    INPUT_POINTER_CHECK(pDlyMeasAck);
    pucApiBuff = (UINT8 *)malloc(sizeof(TookFrameApiPDU) + sizeof(TookFrameApiPDU));   /*两个完整的结构体 一个send用 一个recv用*/
    if (NULL == pucApiBuff)
    {
        retVal |= BIT_SET(0);
        dbgErr("%s>>TmpBuf Malloc Error!\n", __FUNCTION__);
        return retVal;
    }
    memset((VOID *)pucApiBuff, 0, sizeof(TookFrameApiPDU) + sizeof(TookFrameApiPDU));

    send = (TookFrameApiPDU *)&pucApiBuff[0];                              /*send起始位置*/
    recv = (TookFrameApiPDU *)&pucApiBuff[sizeof(TookFrameApiPDU)];        /*recv起始位置*/
    dataLen = sizeof(T_OokMsgDlyMeas)+ sizeof(send->msgHead);
    send->head.startFlag1 = OOK_MSG_STARTFLAG1;
    send->head.startFlag2 = OOK_MSG_STARTFLAG2;
    send->head.versionreserverd1 = 1;
    send->head.reserverd2 = 0;
    send->head.dataLen = OOK_HTONS(dataLen);
    send->head.headSum = 0;
    send->msgHead.msgType = OOK_DLY_MEAS;
    send->msgHead.msgSubType = 0;
    send->msgHead.serialNo = g_serialNo;
    send->msgHead.msgInfoLength = sizeof(T_OokMsgDlyMeas);

    send->msg.slaveDlyMeas.action = pDlyMeas->action;
    send->msg.slaveDlyMeas.dlyNs = OOK_HTONL(pDlyMeas->dlyNs);
    send->head.dataCrc = BspCountCRC8((UINT8*)&send->msgHead, dataLen);
    MsgPrint(PM_DEBUG, "action 0x%x dlyNs 0x%x \n", send->msg.slaveDlyMeas.action,  send->msg.slaveDlyMeas.dlyNs);
    retVal = BspOokMsgProc(portId, send, recv);
    g_serialNo++;   /*8bit 溢出之后再重新计数*/
    if (retVal != BSP_OK)
    {
        MsgPrint(PM_ERROR,"%s portId=%d send msg error!\n",__FUNCTION__,portId);
        free(pucApiBuff);
        return retVal;
    }
    pDlyMeasAck->ackData = recv->msg.slaveDlyMeasAck.ackData;
    MsgPrint(PM_DEBUG, "ackData 0x%x \n", pDlyMeasAck->ackData);

    free(pucApiBuff);
    return retVal;
}


/*0xf子端复位*/
UINT32 OokMsgSlaveReset(UINT32 portId, T_OokMsgReset *pReset, T_OokMsgResetAck *pResetAck)
{
    UINT32     retVal = BSP_OK;
    UINT8     *pucApiBuff = NULL;
    TookFrameApiPDU *send = NULL;
    TookFrameApiPDU *recv = NULL;
    UINT16 dataLen = 0;

    INPUT_POINTER_CHECK(pReset);
    INPUT_POINTER_CHECK(pResetAck);
    pucApiBuff = (UINT8 *)malloc(sizeof(TookFrameApiPDU) + sizeof(TookFrameApiPDU));   /*两个完整的结构体 一个send用 一个recv用*/
    if (NULL == pucApiBuff)
    {
        retVal |= BIT_SET(0);
        dbgErr("%s>>TmpBuf Malloc Error!\n", __FUNCTION__);
        return retVal;
    }
    memset((VOID *)pucApiBuff, 0, sizeof(TookFrameApiPDU) + sizeof(TookFrameApiPDU));

    send = (TookFrameApiPDU *)&pucApiBuff[0];                              /*send起始位置*/
    recv = (TookFrameApiPDU *)&pucApiBuff[sizeof(TookFrameApiPDU)];        /*recv起始位置*/
    dataLen = sizeof(T_OokMsgReset)+ sizeof(send->msgHead);
    send->head.startFlag1 = OOK_MSG_STARTFLAG1;
    send->head.startFlag2 = OOK_MSG_STARTFLAG2;
    send->head.versionreserverd1 = 1;
    send->head.reserverd2 = 0;
    send->head.dataLen = OOK_HTONS(dataLen);
    send->head.headSum = 0;
    send->msgHead.msgType = OOK_BOARD_RESET;
    send->msgHead.msgSubType = 0;
    send->msgHead.serialNo = g_serialNo;
    send->msgHead.msgInfoLength = sizeof(T_OokMsgReset);

    send->msg.slaveReset.rstType = pReset->rstType;
    send->head.dataCrc = BspCountCRC8((UINT8*)&send->msgHead, dataLen);
    MsgPrint(PM_DEBUG, "rstType 0x%x \n", send->msg.slaveReset.rstType);
    retVal = BspOokMsgProc(portId, send, recv);
    g_serialNo++;   /*8bit 溢出之后再重新计数*/
    if (retVal != BSP_OK)
    {
        MsgPrint(PM_ERROR,"%s portId=%d send msg error!\n",__FUNCTION__,portId);
        free(pucApiBuff);
        return retVal;
    }
    pResetAck->ackData = recv->msg.slaveResetAck.ackData;
    MsgPrint(PM_DEBUG, "ackData 0x%x \n",  pResetAck->ackData);

    free(pucApiBuff);
    return retVal;
}

/*0x10 TDD配置*/
UINT32 OokMsgSlaveTddCfg(UINT32 portId, T_OokMsgTddCfg *pTddCfg, T_OokMsgTddCfgAck *pTddCfgAck)
{
    UINT32     retVal = BSP_OK;
    UINT8     *pucApiBuff = NULL;
    TookFrameApiPDU *send = NULL;
    TookFrameApiPDU *recv = NULL;
    UINT16 dataLen = 0;
    UINT32 loop = 0;

    INPUT_POINTER_CHECK(pTddCfg);
    INPUT_POINTER_CHECK(pTddCfg);
    pucApiBuff = (UINT8 *)malloc(sizeof(TookFrameApiPDU) + sizeof(TookFrameApiPDU));   /*两个完整的结构体 一个send用 一个recv用*/
    if (NULL == pucApiBuff)
    {
        retVal |= BIT_SET(0);
        dbgErr("%s>>TmpBuf Malloc Error!\n", __FUNCTION__);
        return retVal;
    }
    memset((VOID *)pucApiBuff, 0, sizeof(TookFrameApiPDU) + sizeof(TookFrameApiPDU));

    send = (TookFrameApiPDU *)&pucApiBuff[0];                              /*send起始位置*/
    recv = (TookFrameApiPDU *)&pucApiBuff[sizeof(TookFrameApiPDU)];        /*recv起始位置*/
    dataLen = sizeof(T_OokMsgTddCfg)+ sizeof(send->msgHead);
    send->head.startFlag1 = OOK_MSG_STARTFLAG1;
    send->head.startFlag2 = OOK_MSG_STARTFLAG2;
    send->head.versionreserverd1 = 1;
    send->head.reserverd2 = 0;
    send->head.dataLen = OOK_HTONS(dataLen);
    send->head.headSum = 0;
    send->msgHead.msgType = OOK_TDD_CFG;
    send->msgHead.msgSubType = 0;
    send->msgHead.serialNo = g_serialNo;
    send->msgHead.msgInfoLength = sizeof(T_OokMsgTddCfg);

    send->msg.slaveTddCfg.radioMode = pTddCfg->radioMode;
    send->msg.slaveTddCfg.lteSubFreame = pTddCfg->lteSubFreame;
    send->msg.slaveTddCfg.lteSpeSubFreame = pTddCfg->lteSpeSubFreame;
    send->msg.slaveTddCfg.nrUeAdv = pTddCfg->nrUeAdv;
    send->msg.slaveTddCfg.dlUlSwNum = pTddCfg->dlUlSwNum;
    MsgPrint(PM_DEBUG, "lteSubFreame %d lteSpeSubFreame %d dlUlSwNum %d radioMode 0x%x \n",
    pTddCfg->lteSubFreame, pTddCfg->lteSpeSubFreame, pTddCfg->dlUlSwNum, pTddCfg->radioMode);
    for(loop = 0; loop < 4; loop++)
    {
        send->msg.slaveTddCfg.dlUlSwPeriod[loop] = OOK_HTONL(pTddCfg->dlUlSwPeriod[loop]);
        send->msg.slaveTddCfg.dlSymbolNum[loop] = pTddCfg->dlSymbolNum[loop];
        send->msg.slaveTddCfg.ulSymbolNum[loop] = pTddCfg->ulSymbolNum[loop];
        MsgPrint(PM_DEBUG, "%d %d %d\n",pTddCfg->dlUlSwPeriod[loop],pTddCfg->dlSymbolNum[loop],pTddCfg->ulSymbolNum[loop]);
    }
    send->head.dataCrc = BspCountCRC8((UINT8*)&send->msgHead, dataLen);
    retVal = BspOokMsgProc(portId, send, recv);
    g_serialNo++;   /*8bit 溢出之后再重新计数*/
    if (retVal != BSP_OK)
    {
        MsgPrint(PM_ERROR,"%s portId=%d send msg error!\n",__FUNCTION__,portId);
        free(pucApiBuff);
        return retVal;
    }
    pTddCfgAck->ackData = recv->msg.slaveTddCfgAck.ackData;
    MsgPrint(PM_DEBUG, "ackData 0x%x \n",  pTddCfgAck->ackData);

    free(pucApiBuff);
    return retVal;
}

/*0x11 波束配置*/
UINT32 OokMsgSlaveBeamCfg(UINT32 portId, T_OokMsgBeamCfg *pBeamCfg, T_OokMsgBeamCfgAck *pBeamCfgAck)
{
    UINT32     retVal = BSP_OK;
    UINT8     *pucApiBuff = NULL;
    TookFrameApiPDU *send = NULL;
    TookFrameApiPDU *recv = NULL;
    UINT16 dataLen = 0;

    INPUT_POINTER_CHECK(pBeamCfg);
    INPUT_POINTER_CHECK(pBeamCfgAck);
    pucApiBuff = (UINT8 *)malloc(sizeof(TookFrameApiPDU) + sizeof(TookFrameApiPDU));   /*两个完整的结构体 一个send用 一个recv用*/
    if (NULL == pucApiBuff)
    {
        retVal |= BIT_SET(0);
        dbgErr("%s>>TmpBuf Malloc Error!\n", __FUNCTION__);
        return retVal;
    }
    memset((VOID *)pucApiBuff, 0, sizeof(TookFrameApiPDU) + sizeof(TookFrameApiPDU));

    send = (TookFrameApiPDU *)&pucApiBuff[0];                              /*send起始位置*/
    recv = (TookFrameApiPDU *)&pucApiBuff[sizeof(TookFrameApiPDU)];        /*recv起始位置*/
    dataLen = sizeof(T_OokMsgBeamCfg)+ sizeof(send->msgHead);
    send->head.startFlag1 = OOK_MSG_STARTFLAG1;
    send->head.startFlag2 = OOK_MSG_STARTFLAG2;
    send->head.versionreserverd1 = 1;
    send->head.reserverd2 = 0;
    send->head.dataLen = OOK_HTONS(dataLen);
    send->head.headSum = 0;
    send->msgHead.msgType = OOK_BEAM_CFG;
    send->msgHead.msgSubType = 0;
    send->msgHead.serialNo = g_serialNo;
    send->msgHead.msgInfoLength = sizeof(T_OokMsgBeamCfg);

    send->msg.slaveBeamCfg.beamWidth = pBeamCfg->beamWidth;
    send->head.dataCrc = BspCountCRC8((UINT8*)&send->msgHead, dataLen);
    MsgPrint(PM_DEBUG, "beamWidth 0x%x \n", send->msg.slaveBeamCfg.beamWidth);
    retVal = BspOokMsgProc(portId, send, recv);
    g_serialNo++;   /*8bit 溢出之后再重新计数*/
    if (retVal != BSP_OK)
    {
        MsgPrint(PM_ERROR,"%s portId=%d send msg error!\n",__FUNCTION__,portId);
        free(pucApiBuff);
        return retVal;
    }
    pBeamCfgAck->ackData = recv->msg.slaveBeamCfgAck.ackData;
    MsgPrint(PM_DEBUG, "ackData 0x%x \n",  pBeamCfgAck->ackData);

    free(pucApiBuff);
    return retVal;
}

/*0x12 漏压配置*/
UINT32 OokMsgSlavePaVoltCfg(UINT32 portId, T_OokMsgPaVoltCfg *pCfg, T_OokMsgPaVoltCfgAck *pCfgAck)
{
    UINT32     retVal = BSP_OK;
    UINT8     *pucApiBuff = NULL;
    TookFrameApiPDU *send = NULL;
    TookFrameApiPDU *recv = NULL;
    UINT16 dataLen = 0;

    INPUT_POINTER_CHECK(pCfg);
    INPUT_POINTER_CHECK(pCfgAck);
    pucApiBuff = (UINT8 *)malloc(sizeof(TookFrameApiPDU) + sizeof(TookFrameApiPDU));   /*两个完整的结构体 一个send用 一个recv用*/
    if (NULL == pucApiBuff)
    {
        retVal |= BIT_SET(0);
        dbgErr("%s>>TmpBuf Malloc Error!\n", __FUNCTION__);
        return retVal;
    }
    memset((VOID *)pucApiBuff, 0, sizeof(TookFrameApiPDU) + sizeof(TookFrameApiPDU));

    send = (TookFrameApiPDU *)&pucApiBuff[0];                              /*send起始位置*/
    recv = (TookFrameApiPDU *)&pucApiBuff[sizeof(TookFrameApiPDU)];        /*recv起始位置*/
    dataLen = sizeof(T_OokMsgPaVoltCfg)+ sizeof(send->msgHead);
    send->head.startFlag1 = OOK_MSG_STARTFLAG1;
    send->head.startFlag2 = OOK_MSG_STARTFLAG2;
    send->head.versionreserverd1 = 1;
    send->head.reserverd2 = 0;
    send->head.dataLen = OOK_HTONS(dataLen);
    send->head.headSum = 0;
    send->msgHead.msgType = OOK_PWRVOLT_CFG;
    send->msgHead.msgSubType = 0;
    send->msgHead.serialNo = g_serialNo;
    send->msgHead.msgInfoLength = sizeof(T_OokMsgPaVoltCfg);

    send->msg.paVoltCfg.volt = OOK_HTONS(pCfg->volt);
    MsgPrint(PM_DEBUG, "volt %d \n", pCfg->volt);
    send->head.dataCrc = BspCountCRC8((UINT8*)&send->msgHead, dataLen);

    retVal = BspOokMsgProc(portId, send, recv);
    g_serialNo++;   /*8bit 溢出之后再重新计数*/
    if (retVal != BSP_OK)
    {
        MsgPrint(PM_ERROR,"%s portId=%d send msg error!\n",__FUNCTION__,portId);
        free(pucApiBuff);
        return retVal;
    }
    pCfgAck->ackData = recv->msg.paVoltCfgAck.ackData;
    MsgPrint(PM_DEBUG, "ackData 0x%x \n",  pCfgAck->ackData);
    free(pucApiBuff);

    return retVal;
}

/*0x13 温度电压获取*/
UINT32 OokMsgSlaveGetTempVolt(UINT32 portId, T_OokMsgTempVoltGetAck *pTempVoltGetAck)
{
    UINT32     retVal = BSP_OK;
    UINT8     *pucApiBuff = NULL;
    TookFrameApiPDU *send = NULL;
    TookFrameApiPDU *recv = NULL;
    UINT16 dataLen = 0;

    INPUT_POINTER_CHECK(pTempVoltGetAck);
    pucApiBuff = (UINT8 *)malloc(sizeof(TookFrameApiPDU) + sizeof(TookFrameApiPDU));   /*两个完整的结构体 一个send用 一个recv用*/
    if (NULL == pucApiBuff)
    {
        retVal |= BIT_SET(0);
        dbgErr("%s>>TmpBuf Malloc Error!\n", __FUNCTION__);
        return retVal;
    }
    memset((VOID *)pucApiBuff, 0, sizeof(TookFrameApiPDU) + sizeof(TookFrameApiPDU));

    send = (TookFrameApiPDU *)&pucApiBuff[0];                              /*send起始位置*/
    recv = (TookFrameApiPDU *)&pucApiBuff[sizeof(TookFrameApiPDU)];        /*recv起始位置*/
    dataLen = sizeof(T_OokMsgTempVoltGet)+ sizeof(send->msgHead);
    send->head.startFlag1 = OOK_MSG_STARTFLAG1;
    send->head.startFlag2 = OOK_MSG_STARTFLAG2;
    send->head.versionreserverd1 = 1;
    send->head.reserverd2 = 0;
    send->head.dataLen = OOK_HTONS(dataLen);
    send->head.headSum = 0;
    send->msgHead.msgType = OOK_TEMP_VOLT_GET;
    send->msgHead.msgSubType = 0;
    send->msgHead.serialNo = g_serialNo;
    send->msgHead.msgInfoLength = sizeof(T_OokMsgTempVoltGet);
    send->head.dataCrc = BspCountCRC8((UINT8*)&send->msgHead, dataLen);

    retVal = BspOokMsgProc(portId, send, recv);
    g_serialNo++;   /*8bit 溢出之后再重新计数*/
    if (retVal != BSP_OK)
    {
        MsgPrint(PM_ERROR,"%s portId=%d send msg error!\n",__FUNCTION__,portId);
        free(pucApiBuff);
        return retVal;
    }
    pTempVoltGetAck->ackData = recv->msg.tempVoltGetAck.ackData;
    pTempVoltGetAck->boardTemp = OOK_NTOHS(recv->msg.tempVoltGetAck.boardTemp);
    pTempVoltGetAck->paTemp[0] = OOK_NTOHS(recv->msg.tempVoltGetAck.paTemp[0]);
    pTempVoltGetAck->paTemp[1] = OOK_NTOHS(recv->msg.tempVoltGetAck.paTemp[1]);
    pTempVoltGetAck->pwrTemp = OOK_NTOHS(recv->msg.tempVoltGetAck.pwrTemp);
    pTempVoltGetAck->pwrVolt = OOK_NTOHL(recv->msg.tempVoltGetAck.pwrVolt);

    MsgPrint(PM_DEBUG, "ackData 0x%x \n",  pTempVoltGetAck->ackData);
    MsgPrint(PM_DEBUG, "boardTemp %d \n",  pTempVoltGetAck->boardTemp);
    MsgPrint(PM_DEBUG, "paTemp[0] %d \n",  pTempVoltGetAck->paTemp[0]);
    MsgPrint(PM_DEBUG, "paTemp[1] %d \n",  pTempVoltGetAck->paTemp[1]);
    MsgPrint(PM_DEBUG, "pwrTemp %d \n",    pTempVoltGetAck->pwrTemp);
    MsgPrint(PM_DEBUG, "pwrVolt %d \n",    pTempVoltGetAck->pwrVolt);
    free(pucApiBuff);

    return retVal;
}

/*0x14 告警信息查询*/
UINT32 OokMsgSlaveGetAlarm(UINT32 portId, T_OokMsgAlmGetAck *pAlmGetAck)
{
    UINT32     retVal = BSP_OK;
    UINT8     *pucApiBuff = NULL;
    TookFrameApiPDU *send = NULL;
    TookFrameApiPDU *recv = NULL;
    UINT16 dataLen = 0;

    INPUT_POINTER_CHECK(pAlmGetAck);
    pucApiBuff = (UINT8 *)malloc(sizeof(TookFrameApiPDU) + sizeof(TookFrameApiPDU));   /*两个完整的结构体 一个send用 一个recv用*/
    if (NULL == pucApiBuff)
    {
        retVal |= BIT_SET(0);
        dbgErr("%s>>TmpBuf Malloc Error!\n", __FUNCTION__);
        return retVal;
    }
    memset((VOID *)pucApiBuff, 0, sizeof(TookFrameApiPDU) + sizeof(TookFrameApiPDU));

    send = (TookFrameApiPDU *)&pucApiBuff[0];                              /*send起始位置*/
    recv = (TookFrameApiPDU *)&pucApiBuff[sizeof(TookFrameApiPDU)];        /*recv起始位置*/
    dataLen = sizeof(T_OokMsgAlmGet)+ sizeof(send->msgHead);
    send->head.startFlag1 = OOK_MSG_STARTFLAG1;
    send->head.startFlag2 = OOK_MSG_STARTFLAG2;
    send->head.versionreserverd1 = 1;
    send->head.reserverd2 = 0;
    send->head.dataLen = OOK_HTONS(dataLen);
    send->head.headSum = 0;
    send->msgHead.msgType = OOK_ALM_GET;
    send->msgHead.msgSubType = 0;
    send->msgHead.serialNo = g_serialNo;
    send->msgHead.msgInfoLength = sizeof(T_OokMsgAlmGet);
    send->head.dataCrc = BspCountCRC8((UINT8*)&send->msgHead, dataLen);

    retVal = BspOokMsgProc(portId, send, recv);
    g_serialNo++;   /*8bit 溢出之后再重新计数*/
    if (retVal != BSP_OK)
    {
        MsgPrint(PM_ERROR,"%s portId=%d send msg error!\n",__FUNCTION__,portId);
        free(pucApiBuff);
        return retVal;
    }
    pAlmGetAck->ackData = recv->msg.almGetAck.ackData;
    pAlmGetAck->almState = OOK_NTOHL(recv->msg.almGetAck.almState);
    pAlmGetAck->almEvent = OOK_NTOHL(recv->msg.almGetAck.almEvent);
    MsgPrint(PM_DEBUG, "ackData 0x%x \n",  pAlmGetAck->ackData);
    MsgPrint(PM_DEBUG, "almState 0x%x \n",  pAlmGetAck->almState);
    MsgPrint(PM_DEBUG, "almEvent 0x%x \n",  pAlmGetAck->almEvent);
    free(pucApiBuff);

    return retVal;
}

/*0x15 开关状态查询*/
UINT32 OokMsgSlaveGetRfSwitch(UINT32 portId, T_OokMsgRfSwitchStaAck *pStaAck)
{
    UINT32     retVal = BSP_OK;
    UINT8     *pucApiBuff = NULL;
    TookFrameApiPDU *send = NULL;
    TookFrameApiPDU *recv = NULL;
    UINT16 dataLen = 0;

    INPUT_POINTER_CHECK(pStaAck);
    pucApiBuff = (UINT8 *)malloc(sizeof(TookFrameApiPDU) + sizeof(TookFrameApiPDU));   /*两个完整的结构体 一个send用 一个recv用*/
    if (NULL == pucApiBuff)
    {
        retVal |= BIT_SET(0);
        dbgErr("%s>>TmpBuf Malloc Error!\n", __FUNCTION__);
        return retVal;
    }
    memset((VOID *)pucApiBuff, 0, sizeof(TookFrameApiPDU) + sizeof(TookFrameApiPDU));

    send = (TookFrameApiPDU *)&pucApiBuff[0];                              /*send起始位置*/
    recv = (TookFrameApiPDU *)&pucApiBuff[sizeof(TookFrameApiPDU)];        /*recv起始位置*/
    dataLen = sizeof(T_OokMsgRfSwitchSta)+ sizeof(send->msgHead);
    send->head.startFlag1 = OOK_MSG_STARTFLAG1;
    send->head.startFlag2 = OOK_MSG_STARTFLAG2;
    send->head.versionreserverd1 = 1;
    send->head.reserverd2 = 0;
    send->head.dataLen = OOK_HTONS(dataLen);
    send->head.headSum = 0;
    send->msgHead.msgType = OOK_SWITCH_GET;
    send->msgHead.msgSubType = 0;
    send->msgHead.serialNo = g_serialNo;
    send->msgHead.msgInfoLength = sizeof(T_OokMsgRfSwitchSta);
    send->head.dataCrc = BspCountCRC8((UINT8*)&send->msgHead, dataLen);

    retVal = BspOokMsgProc(portId, send, recv);
    g_serialNo++;   /*8bit 溢出之后再重新计数*/
    if (retVal != BSP_OK)
    {
        MsgPrint(PM_ERROR,"%s portId=%d send msg error!\n",__FUNCTION__,portId);
        free(pucApiBuff);
        return retVal;
    }
    pStaAck->ackData = recv->msg.rfSwStaAck.ackData;
    pStaAck->rfSwTestMode = OOK_NTOHS(recv->msg.rfSwStaAck.rfSwTestMode);
    pStaAck->rfSwSta = OOK_NTOHS(recv->msg.rfSwStaAck.rfSwSta);
    MsgPrint(PM_DEBUG, "ackData 0x%x \n",  pStaAck->ackData);
    MsgPrint(PM_DEBUG, "rfSwTestMode 0x%x \n",  pStaAck->rfSwTestMode);
    MsgPrint(PM_DEBUG, "rfSwSta 0x%x \n",  pStaAck->rfSwSta);
    free(pucApiBuff);

    return retVal;
}

/*0x16 子端告警清除*/
UINT32 OokMsgSlaveAlarmClr(UINT32 portId, T_OokMsgAlmClr *pAlmClr, T_OokMsgAlmClrAck *pAlmClrAck)
{
    UINT32     retVal = BSP_OK;
    UINT8     *pucApiBuff = NULL;
    TookFrameApiPDU *send = NULL;
    TookFrameApiPDU *recv = NULL;
    UINT16 dataLen = 0;

    INPUT_POINTER_CHECK(pAlmClr);
    INPUT_POINTER_CHECK(pAlmClrAck);
    pucApiBuff = (UINT8 *)malloc(sizeof(TookFrameApiPDU) + sizeof(TookFrameApiPDU));   /*两个完整的结构体 一个send用 一个recv用*/
    if (NULL == pucApiBuff)
    {
        retVal |= BIT_SET(0);
        dbgErr("%s>>TmpBuf Malloc Error!\n", __FUNCTION__);
        return retVal;
    }
    memset_s((VOID *)pucApiBuff, sizeof(TookFrameApiPDU) + sizeof(TookFrameApiPDU), 0, sizeof(TookFrameApiPDU) + sizeof(TookFrameApiPDU));

    send = (TookFrameApiPDU *)&pucApiBuff[0];                              /*send起始位置*/
    recv = (TookFrameApiPDU *)&pucApiBuff[sizeof(TookFrameApiPDU)];        /*recv起始位置*/
    dataLen = sizeof(T_OokMsgAlmClr)+ sizeof(send->msgHead);
    send->head.startFlag1 = OOK_MSG_STARTFLAG1;
    send->head.startFlag2 = OOK_MSG_STARTFLAG2;
    send->head.versionreserverd1 = 1;
    send->head.reserverd2 = 0;
    send->head.dataLen = OOK_HTONS(dataLen);
    send->head.headSum = 0;
    send->msgHead.msgType = OOK_ALM_CLEAR;
    send->msgHead.msgSubType = 0;
    send->msgHead.serialNo = g_serialNo;
    send->msgHead.msgInfoLength = sizeof(T_OokMsgAlmClr);
    send->msg.almClr.clrAlmState = OOK_HTONL(pAlmClr->clrAlmState);
    send->msg.almClr.clrAlmEvent = OOK_HTONL(pAlmClr->clrAlmEvent);
    send->head.dataCrc = BspCountCRC8((UINT8*)&send->msgHead, dataLen);
    MsgPrint(PM_DEBUG, "clrAlmState 0x%x \n", send->msg.almClr.clrAlmState);
    MsgPrint(PM_DEBUG, "clrAlmEvent 0x%x \n", send->msg.almClr.clrAlmEvent);

    retVal = BspOokMsgProc(portId, send, recv);
    g_serialNo++;   /*8bit 溢出之后再重新计数*/
    if (retVal != BSP_OK)
    {
        MsgPrint(PM_ERROR,"%s portId=%d send msg error!\n",__FUNCTION__,portId);
        free(pucApiBuff);
        return retVal;
    }
    pAlmClrAck->ackData = recv->msg.almClrAck.ackData;
    MsgPrint(PM_DEBUG, "ackData 0x%x \n",  pAlmClrAck->ackData);
    free(pucApiBuff);

    return retVal;
}

/*0x18-0x00 子端资产信息查询-版本信息*/
UINT32 OokMsgSlaveGetVerInfo(UINT32 portId, T_OokMsgGetVerInfoAck *pVerAck)
{
    UINT32     retVal = BSP_OK;
    UINT8     *pucApiBuff = NULL;
    TookFrameApiPDU *send = NULL;
    TookFrameApiPDU *recv = NULL;
    UINT16 dataLen = 0;

    INPUT_POINTER_CHECK(pVerAck);
    pucApiBuff = (UINT8 *)malloc(sizeof(TookFrameApiPDU) + sizeof(TookFrameApiPDU));   /*两个完整的结构体 一个send用 一个recv用*/
    if (NULL == pucApiBuff)
    {
        retVal |= BIT_SET(0);
        dbgErr("%s>>TmpBuf Malloc Error!\n", __FUNCTION__);
        return retVal;
    }
    memset_s((VOID *)pucApiBuff, sizeof(TookFrameApiPDU) * 2, 0, sizeof(TookFrameApiPDU) * 2);

    send = (TookFrameApiPDU *)&pucApiBuff[0];                              /*send起始位置*/
    recv = (TookFrameApiPDU *)&pucApiBuff[sizeof(TookFrameApiPDU)];        /*recv起始位置*/
    dataLen = sizeof(T_OokMsgGetRfsRruInfo)+ sizeof(send->msgHead);
    send->head.startFlag1 = OOK_MSG_STARTFLAG1;
    send->head.startFlag2 = OOK_MSG_STARTFLAG2;
    send->head.versionreserverd1 = 1;
    send->head.reserverd2 = 0;
    send->head.dataLen = OOK_HTONS(dataLen);
    send->head.headSum = 0;
    send->msgHead.msgType = OOK_ASSET_INFO_GET;
    send->msgHead.msgSubType = OOK_VER_INFO_GET;
    send->msgHead.serialNo = g_serialNo;
    send->msgHead.msgInfoLength = sizeof(T_OokMsgGetRfsRruInfo);
    send->head.dataCrc = BspCountCRC8((UINT8*)&send->msgHead, dataLen);

    retVal = BspOokMsgProc(portId, send, recv);
    g_serialNo++;   /*8bit 溢出之后再重新计数*/
    if (retVal != BSP_OK)
    {
        MsgPrint(PM_ERROR,"%s portId=%d send msg error!\n",__FUNCTION__,portId);
        free(pucApiBuff);
        return retVal;
    }
    pVerAck->ackData = recv->msg.verInfoAck.ackData;
    pVerAck->versionFlag = recv->msg.verInfoAck.versionFlag;
    pVerAck->versionInfo = recv->msg.verInfoAck.versionInfo;
    MsgPrint(PM_DEBUG, "ackData 0x%x \n",  pVerAck->ackData);
    MsgPrint(PM_DEBUG, "versionFlag 0x%x \n",  pVerAck->versionFlag);
    MsgPrint(PM_DEBUG, "versionInfo 0x%x \n",  pVerAck->versionInfo);
    free(pucApiBuff);

    return retVal;
}

/*0x18-0x01 子端资产信息查询-RRU信息*/
UINT32 OokMsgSlaveGetRruInfo(UINT32 portId, T_OokMsgGetRruInfoAck *pRruAck)
{
    UINT32     retVal = BSP_OK;
    UINT8     *pucApiBuff = NULL;
    TookFrameApiPDU *send = NULL;
    TookFrameApiPDU *recv = NULL;
    UINT16 dataLen = 0;

    INPUT_POINTER_CHECK(pRruAck);
    pucApiBuff = (UINT8 *)malloc(sizeof(TookFrameApiPDU) + sizeof(TookFrameApiPDU));   /*两个完整的结构体 一个send用 一个recv用*/
    if (NULL == pucApiBuff)
    {
        retVal |= BIT_SET(0);
        dbgErr("%s>>TmpBuf Malloc Error!\n", __FUNCTION__);
        return retVal;
    }
    memset_s((VOID *)pucApiBuff, sizeof(TookFrameApiPDU) * 2, 0, sizeof(TookFrameApiPDU) * 2);

    send = (TookFrameApiPDU *)&pucApiBuff[0];                              /*send起始位置*/
    recv = (TookFrameApiPDU *)&pucApiBuff[sizeof(TookFrameApiPDU)];        /*recv起始位置*/
    dataLen = sizeof(T_OokMsgGetRfsRruInfo)+ sizeof(send->msgHead);
    send->head.startFlag1 = OOK_MSG_STARTFLAG1;
    send->head.startFlag2 = OOK_MSG_STARTFLAG2;
    send->head.versionreserverd1 = 1;
    send->head.reserverd2 = 0;
    send->head.dataLen = OOK_HTONS(dataLen);
    send->head.headSum = 0;
    send->msgHead.msgType = OOK_ASSET_INFO_GET;
    send->msgHead.msgSubType = OOK_RRU_INFO_GET;
    send->msgHead.serialNo = g_serialNo;
    send->msgHead.msgInfoLength = sizeof(T_OokMsgGetRfsRruInfo);
    send->head.dataCrc = BspCountCRC8((UINT8*)&send->msgHead, dataLen);

    retVal = BspOokMsgProc(portId, send, recv);
    g_serialNo++;   /*8bit 溢出之后再重新计数*/
    if (retVal != BSP_OK)
    {
        MsgPrint(PM_ERROR,"%s portId=%d send msg error!\n",__FUNCTION__,portId);
        free(pucApiBuff);
        return retVal;
    }
    pRruAck->ackData = recv->msg.rruInfoAck.ackData;
    memcpy_s(pRruAck->rruBarCode, sizeof(pRruAck->rruBarCode),
            recv->msg.rruInfoAck.rruBarCode, sizeof(pRruAck->rruBarCode));
    memcpy_s(pRruAck->vendorUnitFamilyType, sizeof(pRruAck->vendorUnitFamilyType),
            recv->msg.rruInfoAck.vendorUnitFamilyType, sizeof(pRruAck->vendorUnitFamilyType));
    memcpy_s(pRruAck->vendorUnitTypeNumber, sizeof(pRruAck->vendorUnitTypeNumber),
            recv->msg.rruInfoAck.vendorUnitTypeNumber, sizeof(pRruAck->vendorUnitTypeNumber));
    memcpy_s(pRruAck->vendorUnitPid, sizeof(pRruAck->vendorUnitPid),
            recv->msg.rruInfoAck.vendorUnitPid, sizeof(pRruAck->vendorUnitPid));
    pRruAck->verdorUnitPidFlag = recv->msg.rruInfoAck.verdorUnitPidFlag;
    pRruAck->rruPaNum = recv->msg.rruInfoAck.rruPaNum;
    pRruAck->rruDflNum = recv->msg.rruInfoAck.rruDflNum;
    pRruAck->rruPwrNum = recv->msg.rruInfoAck.rruPwrNum;
    pRruAck->rruPibNum = recv->msg.rruInfoAck.rruPibNum;
    pRruAck->rruAntNum = recv->msg.rruInfoAck.rruAntNum;
    pRruAck->antNum = recv->msg.rruInfoAck.antNum;
    pRruAck->rruRatedPowerTx = OOK_NTOHL(recv->msg.rruInfoAck.rruRatedPowerTx);
    memcpy_s(pRruAck->bomCode, sizeof(pRruAck->bomCode), recv->msg.rruInfoAck.bomCode, sizeof(pRruAck->bomCode));
    memcpy_s(pRruAck->supplerCode, sizeof(pRruAck->supplerCode), recv->msg.rruInfoAck.supplerCode, sizeof(pRruAck->supplerCode));
    memcpy_s(pRruAck->productTime, sizeof(pRruAck->productTime), recv->msg.rruInfoAck.productTime, sizeof(pRruAck->productTime));
    pRruAck->serviceTime = OOK_NTOHL(recv->msg.rruInfoAck.serviceTime);
    memcpy_s(pRruAck->lastServiceDate, sizeof(pRruAck->lastServiceDate), recv->msg.rruInfoAck.lastServiceDate, sizeof(pRruAck->lastServiceDate));
    memcpy_s(pRruAck->vendorName, sizeof(pRruAck->vendorName), recv->msg.rruInfoAck.vendorName, sizeof(pRruAck->vendorName));

    MsgPrint(PM_DEBUG, "ackData 0x%x \n",             pRruAck->ackData);
    MsgPrint(PM_DEBUG, "rruBarCode %s \n",            pRruAck->rruBarCode);
    MsgPrint(PM_DEBUG, "vendorUnitFamilyType %s \n",  pRruAck->vendorUnitFamilyType);
    MsgPrint(PM_DEBUG, "vendorUnitTypeNumber %s \n",  pRruAck->vendorUnitTypeNumber);
    MsgPrint(PM_DEBUG, "vendorUnitPid %s \n",         pRruAck->vendorUnitPid);
    MsgPrint(PM_DEBUG, "verdorUnitPidFlag %d \n",     pRruAck->verdorUnitPidFlag);
    MsgPrint(PM_DEBUG, "rruPaNum %d \n",              pRruAck->rruPaNum);
    MsgPrint(PM_DEBUG, "rruDflNum %d \n",             pRruAck->rruDflNum);
    MsgPrint(PM_DEBUG, "rruPwrNum %d \n",             pRruAck->rruPwrNum);
    MsgPrint(PM_DEBUG, "rruPibNum %d \n",             pRruAck->rruPibNum);
    MsgPrint(PM_DEBUG, "rruAntNum %d \n",             pRruAck->rruAntNum);
    MsgPrint(PM_DEBUG, "antNum %d \n",                pRruAck->antNum);
    MsgPrint(PM_DEBUG, "rruRatedPowerTx %d \n",       pRruAck->rruRatedPowerTx);
    MsgPrint(PM_DEBUG, "bomCode %s \n",               pRruAck->bomCode);
    MsgPrint(PM_DEBUG, "supplerCode %s \n",           pRruAck->supplerCode);
    MsgPrint(PM_DEBUG, "productTime %s \n",           pRruAck->productTime);
    MsgPrint(PM_DEBUG, "serviceTime %d \n",           pRruAck->serviceTime);
    MsgPrint(PM_DEBUG, "lastServiceDate %s \n",       pRruAck->lastServiceDate);
    MsgPrint(PM_DEBUG, "vendorName %s \n",            pRruAck->vendorName);
    free(pucApiBuff);

    return retVal;
}

/*0x18-0x02 子端资产信息查询-单板信息*/
UINT32 OokMsgSlaveGetBoardInfo(UINT32 portId, T_OokMsgGetBoardInfoAck *pBoardAck)
{
    UINT32     retVal = BSP_OK;
    UINT8     *pucApiBuff = NULL;
    TookFrameApiPDU *send = NULL;
    TookFrameApiPDU *recv = NULL;
    UINT16 dataLen = 0;

    INPUT_POINTER_CHECK(pBoardAck);
    pucApiBuff = (UINT8 *)malloc(sizeof(TookFrameApiPDU) + sizeof(TookFrameApiPDU));   /*两个完整的结构体 一个send用 一个recv用*/
    if (NULL == pucApiBuff)
    {
        retVal |= BIT_SET(0);
        dbgErr("%s>>TmpBuf Malloc Error!\n", __FUNCTION__);
        return retVal;
    }
    memset_s((VOID *)pucApiBuff, sizeof(TookFrameApiPDU) * 2, 0, sizeof(TookFrameApiPDU) * 2);

    send = (TookFrameApiPDU *)&pucApiBuff[0];                              /*send起始位置*/
    recv = (TookFrameApiPDU *)&pucApiBuff[sizeof(TookFrameApiPDU)];        /*recv起始位置*/
    dataLen = sizeof(T_OokMsgGetRfsRruInfo)+ sizeof(send->msgHead);
    send->head.startFlag1 = OOK_MSG_STARTFLAG1;
    send->head.startFlag2 = OOK_MSG_STARTFLAG2;
    send->head.versionreserverd1 = 1;
    send->head.reserverd2 = 0;
    send->head.dataLen = OOK_HTONS(dataLen);
    send->head.headSum = 0;
    send->msgHead.msgType = OOK_ASSET_INFO_GET;
    send->msgHead.msgSubType = OOK_BOARD_INFO_GET;
    send->msgHead.serialNo = g_serialNo;
    send->msgHead.msgInfoLength = sizeof(T_OokMsgGetRfsRruInfo);
    send->head.dataCrc = BspCountCRC8((UINT8*)&send->msgHead, dataLen);

    retVal = BspOokMsgProc(portId, send, recv);
    g_serialNo++;   /*8bit 溢出之后再重新计数*/
    if (retVal != BSP_OK)
    {
        MsgPrint(PM_ERROR,"%s portId=%d send msg error!\n",__FUNCTION__,portId);
        free(pucApiBuff);
        return retVal;
    }
    pBoardAck->ackData = recv->msg.boardInfoAck.ackData;
    memcpy_s(pBoardAck->boardBarCode, sizeof(pBoardAck->boardBarCode),
            recv->msg.boardInfoAck.boardBarCode, sizeof(pBoardAck->boardBarCode));
    memcpy_s(pBoardAck->boardName, sizeof(pBoardAck->boardName),
            recv->msg.boardInfoAck.boardName, sizeof(pBoardAck->boardName));
    memcpy_s(pBoardAck->productTime, sizeof(pBoardAck->productTime),
            recv->msg.boardInfoAck.productTime, sizeof(pBoardAck->productTime));
    pBoardAck->serviceTime = OOK_NTOHL(recv->msg.boardInfoAck.serviceTime);
    memcpy_s(pBoardAck->lastServiceDate, sizeof(pBoardAck->lastServiceDate), recv->msg.boardInfoAck.lastServiceDate, sizeof(pBoardAck->lastServiceDate));
    memcpy_s(pBoardAck->vendorName, sizeof(pBoardAck->vendorName), recv->msg.boardInfoAck.vendorName, sizeof(pBoardAck->vendorName));

    MsgPrint(PM_DEBUG, "ackData 0x%x \n",       pBoardAck->ackData);
    MsgPrint(PM_DEBUG, "boardBarCode %s \n",    pBoardAck->boardBarCode);
    MsgPrint(PM_DEBUG, "boardName %s \n",       pBoardAck->boardName);
    MsgPrint(PM_DEBUG, "productTime %s \n",     pBoardAck->productTime);
    MsgPrint(PM_DEBUG, "serviceTime %d \n",     pBoardAck->serviceTime);
    MsgPrint(PM_DEBUG, "lastServiceDate %s \n", pBoardAck->lastServiceDate);
    MsgPrint(PM_DEBUG, "vendorName %s \n",      pBoardAck->vendorName);
    free(pucApiBuff);

    return retVal;
}

/*0x18-0x03 子端资产信息查询-电源信息*/
UINT32 OokMsgSlaveGetPwrInfo(UINT32 portId, T_OokMsgGetPwrInfoAck *pPwrAck)
{
    UINT32     retVal = BSP_OK;
    UINT8     *pucApiBuff = NULL;
    TookFrameApiPDU *send = NULL;
    TookFrameApiPDU *recv = NULL;
    UINT16 dataLen = 0;

    INPUT_POINTER_CHECK(pPwrAck);
    pucApiBuff = (UINT8 *)malloc(sizeof(TookFrameApiPDU) + sizeof(TookFrameApiPDU));   /*两个完整的结构体 一个send用 一个recv用*/
    if (NULL == pucApiBuff)
    {
        retVal |= BIT_SET(0);
        dbgErr("%s>>TmpBuf Malloc Error!\n", __FUNCTION__);
        return retVal;
    }
    memset_s((VOID *)pucApiBuff, sizeof(TookFrameApiPDU) * 2, 0, sizeof(TookFrameApiPDU) * 2);

    send = (TookFrameApiPDU *)&pucApiBuff[0];                              /*send起始位置*/
    recv = (TookFrameApiPDU *)&pucApiBuff[sizeof(TookFrameApiPDU)];        /*recv起始位置*/
    dataLen = sizeof(T_OokMsgGetRfsRruInfo)+ sizeof(send->msgHead);
    send->head.startFlag1 = OOK_MSG_STARTFLAG1;
    send->head.startFlag2 = OOK_MSG_STARTFLAG2;
    send->head.versionreserverd1 = 1;
    send->head.reserverd2 = 0;
    send->head.dataLen = OOK_HTONS(dataLen);
    send->head.headSum = 0;
    send->msgHead.msgType = OOK_ASSET_INFO_GET;
    send->msgHead.msgSubType = OOK_PWR_INFO_GET;
    send->msgHead.serialNo = g_serialNo;
    send->msgHead.msgInfoLength = sizeof(T_OokMsgGetRfsRruInfo);
    send->head.dataCrc = BspCountCRC8((UINT8*)&send->msgHead, dataLen);

    retVal = BspOokMsgProc(portId, send, recv);
    g_serialNo++;   /*8bit 溢出之后再重新计数*/
    if (retVal != BSP_OK)
    {
        MsgPrint(PM_ERROR,"%s portId=%d send msg error!\n",__FUNCTION__,portId);
        free(pucApiBuff);
        return retVal;
    }
    pPwrAck->ackData = recv->msg.pwrInfoAck.ackData;
    memcpy_s(pPwrAck->pwrBarCode, sizeof(pPwrAck->pwrBarCode),
            recv->msg.pwrInfoAck.pwrBarCode, sizeof(pPwrAck->pwrBarCode));
    memcpy_s(pPwrAck->pwrType, sizeof(pPwrAck->pwrType),
            recv->msg.pwrInfoAck.pwrType, sizeof(pPwrAck->pwrType));
    pPwrAck->defaultPwrVolt = OOK_NTOHL(recv->msg.pwrInfoAck.defaultPwrVolt);
    pPwrAck->pwrVoltUp = OOK_NTOHL(recv->msg.pwrInfoAck.pwrVoltUp);
    pPwrAck->pwrVoltDown = OOK_NTOHL(recv->msg.pwrInfoAck.pwrVoltDown);
    pPwrAck->pwrFactoryId = OOK_NTOHL(recv->msg.pwrInfoAck.pwrFactoryId);
    memcpy_s(pPwrAck->productTime, sizeof(pPwrAck->productTime),
            recv->msg.pwrInfoAck.productTime, sizeof(pPwrAck->productTime));
    pPwrAck->serviceTime = OOK_NTOHL(recv->msg.pwrInfoAck.serviceTime);
    memcpy_s(pPwrAck->lastServiceDate, sizeof(pPwrAck->lastServiceDate), recv->msg.pwrInfoAck.lastServiceDate, sizeof(pPwrAck->lastServiceDate));
    memcpy_s(pPwrAck->vendorName, sizeof(pPwrAck->vendorName), recv->msg.pwrInfoAck.vendorName, sizeof(pPwrAck->vendorName));

    MsgPrint(PM_DEBUG, "ackData 0x%x \n",       pPwrAck->ackData);
    MsgPrint(PM_DEBUG, "pwrBarCode %s \n",      pPwrAck->pwrBarCode);
    MsgPrint(PM_DEBUG, "pwrType %s \n",         pPwrAck->pwrType);
    MsgPrint(PM_DEBUG, "defaultPwrVolt %d \n",  pPwrAck->defaultPwrVolt);
    MsgPrint(PM_DEBUG, "pwrVoltUp %d \n",       pPwrAck->pwrVoltUp);
    MsgPrint(PM_DEBUG, "pwrVoltDown %d \n",     pPwrAck->pwrVoltDown);
    MsgPrint(PM_DEBUG, "pwrFactoryId %d \n",    pPwrAck->pwrFactoryId);
    MsgPrint(PM_DEBUG, "productTime %s \n",     pPwrAck->productTime);
    MsgPrint(PM_DEBUG, "serviceTime %d \n",     pPwrAck->serviceTime);
    MsgPrint(PM_DEBUG, "lastServiceDate %s \n", pPwrAck->lastServiceDate);
    MsgPrint(PM_DEBUG, "vendorName %s \n",      pPwrAck->vendorName);
    free(pucApiBuff);

    return retVal;
}

/*0x18-0x04 子端资产信息查询-功放信息*/
UINT32 OokMsgSlaveGetPaInfo(UINT32 portId, T_OokMsgGetPaInfoAck *pPaAck)
{
    UINT32     retVal = BSP_OK;
    UINT8     *pucApiBuff = NULL;
    TookFrameApiPDU *send = NULL;
    TookFrameApiPDU *recv = NULL;
    UINT16 dataLen = 0;

    INPUT_POINTER_CHECK(pPaAck);
    pucApiBuff = (UINT8 *)malloc(sizeof(TookFrameApiPDU) + sizeof(TookFrameApiPDU));   /*两个完整的结构体 一个send用 一个recv用*/
    if (NULL == pucApiBuff)
    {
        retVal |= BIT_SET(0);
        dbgErr("%s>>TmpBuf Malloc Error!\n", __FUNCTION__);
        return retVal;
    }
    memset_s((VOID *)pucApiBuff, sizeof(TookFrameApiPDU) * 2, 0, sizeof(TookFrameApiPDU) * 2);

    send = (TookFrameApiPDU *)&pucApiBuff[0];                              /*send起始位置*/
    recv = (TookFrameApiPDU *)&pucApiBuff[sizeof(TookFrameApiPDU)];        /*recv起始位置*/
    dataLen = sizeof(T_OokMsgGetRfsRruInfo)+ sizeof(send->msgHead);
    send->head.startFlag1 = OOK_MSG_STARTFLAG1;
    send->head.startFlag2 = OOK_MSG_STARTFLAG2;
    send->head.versionreserverd1 = 1;
    send->head.reserverd2 = 0;
    send->head.dataLen = OOK_HTONS(dataLen);
    send->head.headSum = 0;
    send->msgHead.msgType = OOK_ASSET_INFO_GET;
    send->msgHead.msgSubType = OOK_PA_INFO_GET;
    send->msgHead.serialNo = g_serialNo;
    send->msgHead.msgInfoLength = sizeof(T_OokMsgGetRfsRruInfo);
    send->head.dataCrc = BspCountCRC8((UINT8*)&send->msgHead, dataLen);

    retVal = BspOokMsgProc(portId, send, recv);
    g_serialNo++;   /*8bit 溢出之后再重新计数*/
    if (retVal != BSP_OK)
    {
        MsgPrint(PM_ERROR,"%s portId=%d send msg error!\n",__FUNCTION__,portId);
        free(pucApiBuff);
        return retVal;
    }
    pPaAck->ackData = recv->msg.paInfoAck.ackData;
    memcpy_s(pPaAck->paBarCode, sizeof(pPaAck->paBarCode),
            recv->msg.paInfoAck.paBarCode, sizeof(pPaAck->paBarCode));
    memcpy_s(pPaAck->boardName, sizeof(pPaAck->boardName),
            recv->msg.paInfoAck.boardName, sizeof(pPaAck->boardName));
    pPaAck->paPath = recv->msg.paInfoAck.paPath;
    memcpy_s(pPaAck->paTxFreq, sizeof(pPaAck->paTxFreq),
            recv->msg.paInfoAck.paTxFreq, sizeof(pPaAck->paTxFreq));
    pPaAck->paFactoryId = OOK_NTOHL(recv->msg.paInfoAck.paFactoryId);
    memcpy_s(pPaAck->productTime, sizeof(pPaAck->productTime),
            recv->msg.paInfoAck.productTime, sizeof(pPaAck->productTime));
    pPaAck->serviceTime = OOK_NTOHL(recv->msg.paInfoAck.serviceTime);
    memcpy_s(pPaAck->lastServiceDate, sizeof(pPaAck->lastServiceDate), recv->msg.paInfoAck.lastServiceDate, sizeof(pPaAck->lastServiceDate));
    memcpy_s(pPaAck->vendorName, sizeof(pPaAck->vendorName), recv->msg.paInfoAck.vendorName, sizeof(pPaAck->vendorName));

    MsgPrint(PM_DEBUG, "ackData 0x%x \n",       pPaAck->ackData);
    MsgPrint(PM_DEBUG, "paBarCode %s \n",       pPaAck->paBarCode);
    MsgPrint(PM_DEBUG, "boardName %s \n",       pPaAck->boardName);
    MsgPrint(PM_DEBUG, "paPath %d \n",          pPaAck->paPath);
    MsgPrint(PM_DEBUG, "paTxFreq %s \n",        pPaAck->paTxFreq);
    MsgPrint(PM_DEBUG, "paFactoryId %d \n",     pPaAck->paFactoryId);
    MsgPrint(PM_DEBUG, "productTime %s \n",     pPaAck->productTime);
    MsgPrint(PM_DEBUG, "serviceTime %d \n",     pPaAck->serviceTime);
    MsgPrint(PM_DEBUG, "lastServiceDate %s \n", pPaAck->lastServiceDate);
    MsgPrint(PM_DEBUG, "vendorName %s \n",      pPaAck->vendorName);
    free(pucApiBuff);

    return retVal;
}

/*0x18-0x05 子端资产信息查询-双工信息*/
UINT32 OokMsgSlaveGetDflInfo(UINT32 portId, UINT8 filedIndex, T_OokMsgGetDflInfoAck *pDflAck)
{
    UINT32     retVal = BSP_OK;
    UINT8     *pucApiBuff = NULL;
    TookFrameApiPDU *send = NULL;
    TookFrameApiPDU *recv = NULL;
    UINT16 dataLen = 0;

    INPUT_POINTER_CHECK(pDflAck);
    pucApiBuff = (UINT8 *)malloc(sizeof(TookFrameApiPDU) + sizeof(TookFrameApiPDU));   /*两个完整的结构体 一个send用 一个recv用*/
    if (NULL == pucApiBuff)
    {
        retVal |= BIT_SET(0);
        dbgErr("%s>>TmpBuf Malloc Error!\n", __FUNCTION__);
        return retVal;
    }
    memset_s((VOID *)pucApiBuff, sizeof(TookFrameApiPDU) * 2, 0, sizeof(TookFrameApiPDU) * 2);

    send = (TookFrameApiPDU *)&pucApiBuff[0];                              /*send起始位置*/
    recv = (TookFrameApiPDU *)&pucApiBuff[sizeof(TookFrameApiPDU)];        /*recv起始位置*/
    dataLen = sizeof(T_OokMsgGetRfsRruInfo)+ sizeof(send->msgHead);
    send->head.startFlag1 = OOK_MSG_STARTFLAG1;
    send->head.startFlag2 = OOK_MSG_STARTFLAG2;
    send->head.versionreserverd1 = 1;
    send->head.reserverd2 = 0;
    send->head.dataLen = OOK_HTONS(dataLen);
    send->head.headSum = 0;
    send->msgHead.msgType = OOK_ASSET_INFO_GET;
    send->msgHead.msgSubType = OOK_DFL_INFO_GET;
    send->msgHead.serialNo = g_serialNo;
    send->msgHead.msgInfoLength = sizeof(T_OokMsgGetRfsRruInfo);
    send->msg.rfsInfo.filedIndex = filedIndex;
    send->head.dataCrc = BspCountCRC8((UINT8*)&send->msgHead, dataLen);

    retVal = BspOokMsgProc(portId, send, recv);
    g_serialNo++;   /*8bit 溢出之后再重新计数*/
    if (retVal != BSP_OK)
    {
        MsgPrint(PM_ERROR,"%s portId=%d send msg error!\n",__FUNCTION__,portId);
        free(pucApiBuff);
        return retVal;
    }
    pDflAck->ackData = recv->msg.dflInfoAck.ackData;
    memcpy_s(pDflAck->dflBarCode, sizeof(pDflAck->dflBarCode),
            recv->msg.dflInfoAck.dflBarCode, sizeof(pDflAck->dflBarCode));
    memcpy_s(pDflAck->boardName, sizeof(pDflAck->boardName),
            recv->msg.dflInfoAck.boardName, sizeof(pDflAck->boardName));
    pDflAck->dflAntNum = recv->msg.dflInfoAck.dflAntNum;
    memcpy_s(pDflAck->dflRxFreq, sizeof(pDflAck->dflRxFreq),
            recv->msg.dflInfoAck.dflRxFreq, sizeof(pDflAck->dflRxFreq));
    memcpy_s(pDflAck->dflTxFreq, sizeof(pDflAck->dflTxFreq),
            recv->msg.dflInfoAck.dflTxFreq, sizeof(pDflAck->dflTxFreq));
    pDflAck->dflFactoryId = OOK_NTOHL(recv->msg.dflInfoAck.dflFactoryId);
    memcpy_s(pDflAck->productTime, sizeof(pDflAck->productTime),
            recv->msg.dflInfoAck.productTime, sizeof(pDflAck->productTime));
    pDflAck->serviceTime = OOK_NTOHL(recv->msg.dflInfoAck.serviceTime);
    memcpy_s(pDflAck->lastServiceDate, sizeof(pDflAck->lastServiceDate), recv->msg.dflInfoAck.lastServiceDate, sizeof(pDflAck->lastServiceDate));
    memcpy_s(pDflAck->vendorName, sizeof(pDflAck->vendorName), recv->msg.dflInfoAck.vendorName, sizeof(pDflAck->vendorName));

    MsgPrint(PM_DEBUG, "ackData 0x%x \n",       pDflAck->ackData);
    MsgPrint(PM_DEBUG, "dflBarCode %s \n",      pDflAck->dflBarCode);
    MsgPrint(PM_DEBUG, "boardName %s \n",       pDflAck->boardName);
    MsgPrint(PM_DEBUG, "dflAntNum %d \n",       pDflAck->dflAntNum);
    MsgPrint(PM_DEBUG, "dflRxFreq %s \n",       pDflAck->dflRxFreq);
    MsgPrint(PM_DEBUG, "dflTxFreq %s \n",       pDflAck->dflTxFreq);
    MsgPrint(PM_DEBUG, "dflFactoryId %d \n",    pDflAck->dflFactoryId);
    MsgPrint(PM_DEBUG, "productTime %s \n",     pDflAck->productTime);
    MsgPrint(PM_DEBUG, "serviceTime %d \n",     pDflAck->serviceTime);
    MsgPrint(PM_DEBUG, "lastServiceDate %s \n", pDflAck->lastServiceDate);
    MsgPrint(PM_DEBUG, "vendorName %s \n",      pDflAck->vendorName);
    free(pucApiBuff);

    return retVal;
}

/*0x18-0x06 子端资产信息查询-天线信息*/
UINT32 OokMsgSlaveGetAntInfo(UINT32 portId, T_OokMsgGetAntInfoAck *pAntAck)
{
    UINT32     retVal = BSP_OK;
    UINT8     *pucApiBuff = NULL;
    TookFrameApiPDU *send = NULL;
    TookFrameApiPDU *recv = NULL;
    UINT16 dataLen = 0;

    INPUT_POINTER_CHECK(pAntAck);
    pucApiBuff = (UINT8 *)malloc(sizeof(TookFrameApiPDU) + sizeof(TookFrameApiPDU));   /*两个完整的结构体 一个send用 一个recv用*/
    if (NULL == pucApiBuff)
    {
        retVal |= BIT_SET(0);
        dbgErr("%s>>TmpBuf Malloc Error!\n", __FUNCTION__);
        return retVal;
    }
    memset_s((VOID *)pucApiBuff, sizeof(TookFrameApiPDU) * 2, 0, sizeof(TookFrameApiPDU) * 2);

    send = (TookFrameApiPDU *)&pucApiBuff[0];                              /*send起始位置*/
    recv = (TookFrameApiPDU *)&pucApiBuff[sizeof(TookFrameApiPDU)];        /*recv起始位置*/
    dataLen = sizeof(T_OokMsgGetRfsRruInfo)+ sizeof(send->msgHead);
    send->head.startFlag1 = OOK_MSG_STARTFLAG1;
    send->head.startFlag2 = OOK_MSG_STARTFLAG2;
    send->head.versionreserverd1 = 1;
    send->head.reserverd2 = 0;
    send->head.dataLen = OOK_HTONS(dataLen);
    send->head.headSum = 0;
    send->msgHead.msgType = OOK_ASSET_INFO_GET;
    send->msgHead.msgSubType = OOK_ANT_INFO_GET;
    send->msgHead.serialNo = g_serialNo;
    send->msgHead.msgInfoLength = sizeof(T_OokMsgGetRfsRruInfo);
    send->head.dataCrc = BspCountCRC8((UINT8*)&send->msgHead, dataLen);

    retVal = BspOokMsgProc(portId, send, recv);
    g_serialNo++;   /*8bit 溢出之后再重新计数*/
    if (retVal != BSP_OK)
    {
        MsgPrint(PM_ERROR,"%s portId=%d send msg error!\n",__FUNCTION__,portId);
        free(pucApiBuff);
        return retVal;
    }
    pAntAck->ackData = recv->msg.antInfoAck.ackData;
    memcpy_s(pAntAck->antBarCode, sizeof(pAntAck->antBarCode),
            recv->msg.antInfoAck.antBarCode, sizeof(pAntAck->antBarCode));
    memcpy_s(pAntAck->boardName, sizeof(pAntAck->boardName),
            recv->msg.antInfoAck.boardName, sizeof(pAntAck->boardName));
    pAntAck->antNum = recv->msg.antInfoAck.antNum;
    pAntAck->antFactoryId = OOK_NTOHL(recv->msg.antInfoAck.antFactoryId);
    memcpy_s(pAntAck->productTime, sizeof(pAntAck->productTime),
            recv->msg.antInfoAck.productTime, sizeof(pAntAck->productTime));
    pAntAck->serviceTime = OOK_NTOHL(recv->msg.antInfoAck.serviceTime);
    memcpy_s(pAntAck->lastServiceDate, sizeof(pAntAck->lastServiceDate), recv->msg.antInfoAck.lastServiceDate, sizeof(pAntAck->lastServiceDate));
    memcpy_s(pAntAck->vendorName, sizeof(pAntAck->vendorName), recv->msg.antInfoAck.vendorName, sizeof(pAntAck->vendorName));

    MsgPrint(PM_DEBUG, "ackData 0x%x \n",       pAntAck->ackData);
    MsgPrint(PM_DEBUG, "antBarCode %s \n",      pAntAck->antBarCode);
    MsgPrint(PM_DEBUG, "boardName %s \n",       pAntAck->boardName);
    MsgPrint(PM_DEBUG, "antNum %d \n",          pAntAck->antNum);
    MsgPrint(PM_DEBUG, "antFactoryId %d \n",    pAntAck->antFactoryId);
    MsgPrint(PM_DEBUG, "productTime %s \n",     pAntAck->productTime);
    MsgPrint(PM_DEBUG, "serviceTime %d \n",     pAntAck->serviceTime);
    MsgPrint(PM_DEBUG, "lastServiceDate %s \n", pAntAck->lastServiceDate);
    MsgPrint(PM_DEBUG, "vendorName %s \n",      pAntAck->vendorName);
    free(pucApiBuff);

    return retVal;
}

/*0xe1-0x00 子端信息查询*/
UINT32 OokMsgSlaveGetWfsBoardInfo(UINT32 portId, T_OokMsgWfsBoardInfoGetAck *pInfoAck)
{
    UINT32     retVal = BSP_OK;
    UINT8     *pucApiBuff = NULL;
    TookFrameApiPDU *send = NULL;
    TookFrameApiPDU *recv = NULL;
    UINT16 dataLen = 0;

    INPUT_POINTER_CHECK(pInfoAck);
    pucApiBuff = (UINT8 *)malloc(sizeof(TookFrameApiPDU) + sizeof(TookFrameApiPDU));   /*两个完整的结构体 一个send用 一个recv用*/
    if (NULL == pucApiBuff)
    {
        retVal |= BIT_SET(0);
        dbgErr("%s>>TmpBuf Malloc Error!\n", __FUNCTION__);
        return retVal;
    }
    memset_s((VOID *)pucApiBuff, sizeof(TookFrameApiPDU) + sizeof(TookFrameApiPDU), 0, sizeof(TookFrameApiPDU) + sizeof(TookFrameApiPDU));

    send = (TookFrameApiPDU *)&pucApiBuff[0];                              /*send起始位置*/
    recv = (TookFrameApiPDU *)&pucApiBuff[sizeof(TookFrameApiPDU)];        /*recv起始位置*/
    dataLen = sizeof(T_OokMsgWfsBoardInfoGet)+ sizeof(send->msgHead);
    send->head.startFlag1 = OOK_MSG_STARTFLAG1;
    send->head.startFlag2 = OOK_MSG_STARTFLAG2;
    send->head.versionreserverd1 = 1;
    send->head.reserverd2 = 0;
    send->head.dataLen = OOK_HTONS(dataLen);
    send->head.headSum = 0;
    send->msgHead.msgType = OOK_WFS_INFO_GET;
    send->msgHead.msgSubType = OOK_WFS_BOARD_INFO_GET;
    send->msgHead.serialNo = g_serialNo;
    send->msgHead.msgInfoLength = sizeof(T_OokMsgWfsBoardInfoGet);
    send->head.dataCrc = BspCountCRC8((UINT8*)&send->msgHead, dataLen);

    retVal = BspOokMsgProc(portId, send, recv);
    g_serialNo++;   /*8bit 溢出之后再重新计数*/
    if (retVal != BSP_OK)
    {
        MsgPrint(PM_ERROR,"%s portId=%d send msg error!\n",__FUNCTION__,portId);
        free(pucApiBuff);
        return retVal;
    }
    pInfoAck->ackData = recv->msg.boardInfoGetAck.ackData;
    pInfoAck->moduleGroupId = OOK_NTOHL(recv->msg.boardInfoGetAck.moduleGroupId);
    pInfoAck->boardGroupId = OOK_NTOHL(recv->msg.boardInfoGetAck.boardGroupId);
    pInfoAck->boardTypeId = OOK_NTOHL(recv->msg.boardInfoGetAck.boardTypeId);
    pInfoAck->hwChangeId = OOK_NTOHL(recv->msg.boardInfoGetAck.hwChangeId);
    pInfoAck->HwCustomIdAId = OOK_NTOHL(recv->msg.boardInfoGetAck.HwCustomIdAId);
    pInfoAck->HwCustomIdBId = OOK_NTOHL(recv->msg.boardInfoGetAck.HwCustomIdBId);
    pInfoAck->bomidCrc = OOK_NTOHS(recv->msg.boardInfoGetAck.bomidCrc);
    pInfoAck->epldId = recv->msg.boardInfoGetAck.epldId;
    pInfoAck->dacTestResult = recv->msg.boardInfoGetAck.dacTestResult;
    pInfoAck->mcuTestResult = recv->msg.boardInfoGetAck.mcuTestResult;
    pInfoAck->epldTestResult = recv->msg.boardInfoGetAck.epldTestResult;
    pInfoAck->txLogicChanNum = recv->msg.boardInfoGetAck.txLogicChanNum;
    memcpy_s(pInfoAck->cpuVer, sizeof(pInfoAck->cpuVer),recv->msg.boardInfoGetAck.cpuVer, sizeof(pInfoAck->cpuVer));
    memcpy_s(pInfoAck->fpgaVer, sizeof(pInfoAck->fpgaVer), recv->msg.boardInfoGetAck.fpgaVer, sizeof(pInfoAck->fpgaVer));
    memcpy_s(pInfoAck->firBootVer, sizeof(pInfoAck->firBootVer), recv->msg.boardInfoGetAck.firBootVer, sizeof(pInfoAck->firBootVer));
    memcpy_s(pInfoAck->secBootVer, sizeof(pInfoAck->secBootVer), recv->msg.boardInfoGetAck.secBootVer, sizeof(pInfoAck->secBootVer));
    memcpy_s(pInfoAck->barCode, sizeof(pInfoAck->barCode), recv->msg.boardInfoGetAck.barCode, sizeof(pInfoAck->barCode));
    MsgPrint(PM_DEBUG, "ackData 0x%x \n",         pInfoAck->ackData);
    MsgPrint(PM_DEBUG, "moduleGroupId 0x%x \n",   pInfoAck->moduleGroupId);
    MsgPrint(PM_DEBUG, "boardGroupId 0x%x \n",    pInfoAck->boardGroupId);
    MsgPrint(PM_DEBUG, "boardTypeId 0x%x \n",     pInfoAck->boardTypeId);
    MsgPrint(PM_DEBUG, "hwChangeId 0x%x \n",      pInfoAck->hwChangeId);
    MsgPrint(PM_DEBUG, "HwCustomIdAId 0x%x \n",   pInfoAck->HwCustomIdAId);
    MsgPrint(PM_DEBUG, "HwCustomIdBId 0x%x \n",   pInfoAck->HwCustomIdBId);
    MsgPrint(PM_DEBUG, "bomidCrc 0x%x \n",        pInfoAck->bomidCrc);
    MsgPrint(PM_DEBUG, "epldId 0x%x \n",          pInfoAck->epldId);
    MsgPrint(PM_DEBUG, "dacTestResult 0x%x \n",   pInfoAck->dacTestResult);
    MsgPrint(PM_DEBUG, "mcuTestResult 0x%x \n",   pInfoAck->mcuTestResult);
    MsgPrint(PM_DEBUG, "epldTestResult 0x%x \n",  pInfoAck->epldTestResult);
    MsgPrint(PM_DEBUG, "txLogicChanNum 0x%x \n",  pInfoAck->txLogicChanNum);
    MsgPrint(PM_DEBUG, "cpuVer %s\n",             pInfoAck->cpuVer);
    MsgPrint(PM_DEBUG, "fpgaVer %s\n",            pInfoAck->fpgaVer);
    MsgPrint(PM_DEBUG, "firBootVer %s\n",         pInfoAck->firBootVer);
    MsgPrint(PM_DEBUG, "secBootVer %s\n",         pInfoAck->secBootVer);
    MsgPrint(PM_DEBUG, "barCode %s\n",            pInfoAck->barCode);
    free(pucApiBuff);

    return retVal;
}

/*0xe1-0x01 电流AD值查询*/
UINT32 OokMsgSlaveGetCurrAdVal(UINT32 portId, T_OokMsgWfsCurrAdValGet *pAdVal, T_OokMsgWfsCurrAdValGetAck *pAdValAck)
{
    UINT32     retVal = BSP_OK;
    UINT8     *pucApiBuff = NULL;
    TookFrameApiPDU *send = NULL;
    TookFrameApiPDU *recv = NULL;
    UINT16 dataLen = 0;

    INPUT_POINTER_CHECK(pAdVal);
    INPUT_POINTER_CHECK(pAdValAck);
    pucApiBuff = (UINT8 *)malloc(sizeof(TookFrameApiPDU) + sizeof(TookFrameApiPDU));   /*两个完整的结构体 一个send用 一个recv用*/
    if (NULL == pucApiBuff)
    {
        retVal |= BIT_SET(0);
        dbgErr("%s>>TmpBuf Malloc Error!\n", __FUNCTION__);
        return retVal;
    }
    memset_s((VOID *)pucApiBuff, sizeof(TookFrameApiPDU) + sizeof(TookFrameApiPDU), 0, sizeof(TookFrameApiPDU) + sizeof(TookFrameApiPDU));

    send = (TookFrameApiPDU *)&pucApiBuff[0];                              /*send起始位置*/
    recv = (TookFrameApiPDU *)&pucApiBuff[sizeof(TookFrameApiPDU)];        /*recv起始位置*/
    dataLen = sizeof(T_OokMsgWfsCurrAdValGet)+ sizeof(send->msgHead);
    send->head.startFlag1 = OOK_MSG_STARTFLAG1;
    send->head.startFlag2 = OOK_MSG_STARTFLAG2;
    send->head.versionreserverd1 = 1;
    send->head.reserverd2 = 0;
    send->head.dataLen = OOK_HTONS(dataLen);
    send->head.headSum = 0;
    send->msgHead.msgType = OOK_WFS_INFO_GET;
    send->msgHead.msgSubType = OOK_CURR_AD_VAL_GET;
    send->msgHead.serialNo = g_serialNo;
    send->msgHead.msgInfoLength = sizeof(T_OokMsgWfsCurrAdValGet);

    send->msg.adValGet.chipIndex = pAdVal->chipIndex;
    send->msg.adValGet.adcChan = pAdVal->adcChan;
    send->head.dataCrc = BspCountCRC8((UINT8*)&send->msgHead, dataLen);
    MsgPrint(PM_DEBUG, "chipIndex 0x%x adcChan 0x%x \n", send->msg.adValGet.chipIndex, send->msg.adValGet.adcChan);

    retVal = BspOokMsgProc(portId, send, recv);
    g_serialNo++;   /*8bit 溢出之后再重新计数*/
    if (retVal != BSP_OK)
    {
        MsgPrint(PM_ERROR,"%s portId=%d send msg error!\n",__FUNCTION__,portId);
        free(pucApiBuff);
        return retVal;
    }
    pAdValAck->ackData = recv->msg.adValGetAck.ackData;
    pAdValAck->adVal = OOK_NTOHL(recv->msg.adValGetAck.adVal);
    MsgPrint(PM_DEBUG, "ackData 0x%x \n",         pAdValAck->ackData);
    MsgPrint(PM_DEBUG, "adVal   %d \n",           pAdValAck->adVal);
    free(pucApiBuff);

    return retVal;
}

/*0xe1-0x02 电流查询*/
UINT32 OokMsgSlaveGetPwrCurr(UINT32 portId, T_OokMsgWfsPwrCurrGet *pCurr, T_OokMsgWfsPwrCurrGetAck *pCurrAck)
{
    UINT32     retVal = BSP_OK;
    UINT8     *pucApiBuff = NULL;
    TookFrameApiPDU *send = NULL;
    TookFrameApiPDU *recv = NULL;
    UINT16 dataLen = 0;

    INPUT_POINTER_CHECK(pCurr);
    INPUT_POINTER_CHECK(pCurrAck);
    pucApiBuff = (UINT8 *)malloc(sizeof(TookFrameApiPDU) + sizeof(TookFrameApiPDU));   /*两个完整的结构体 一个send用 一个recv用*/
    if (NULL == pucApiBuff)
    {
        retVal |= BIT_SET(0);
        dbgErr("%s>>TmpBuf Malloc Error!\n", __FUNCTION__);
        return retVal;
    }
    memset_s((VOID *)pucApiBuff, sizeof(TookFrameApiPDU) + sizeof(TookFrameApiPDU), 0, sizeof(TookFrameApiPDU) + sizeof(TookFrameApiPDU));

    send = (TookFrameApiPDU *)&pucApiBuff[0];                              /*send起始位置*/
    recv = (TookFrameApiPDU *)&pucApiBuff[sizeof(TookFrameApiPDU)];        /*recv起始位置*/
    dataLen = sizeof(T_OokMsgWfsPwrCurrGet)+ sizeof(send->msgHead);
    send->head.startFlag1 = OOK_MSG_STARTFLAG1;
    send->head.startFlag2 = OOK_MSG_STARTFLAG2;
    send->head.versionreserverd1 = 1;
    send->head.reserverd2 = 0;
    send->head.dataLen = OOK_HTONS(dataLen);
    send->head.headSum = 0;
    send->msgHead.msgType = OOK_WFS_INFO_GET;
    send->msgHead.msgSubType = OOK_PWR_CURR_GET;
    send->msgHead.serialNo = g_serialNo;
    send->msgHead.msgInfoLength = sizeof(T_OokMsgWfsPwrCurrGet);

    send->msg.pwrCurrGet.chipIndex = pCurr->chipIndex;
    send->msg.pwrCurrGet.adcChan = pCurr->adcChan;
    send->head.dataCrc = BspCountCRC8((UINT8*)&send->msgHead, dataLen);
    MsgPrint(PM_DEBUG, "chipIndex 0x%x adcChan 0x%x \n", send->msg.pwrCurrGet.chipIndex, send->msg.pwrCurrGet.adcChan);

    retVal = BspOokMsgProc(portId, send, recv);
    g_serialNo++;   /*8bit 溢出之后再重新计数*/
    if (retVal != BSP_OK)
    {
        MsgPrint(PM_ERROR,"%s portId=%d send msg error!\n",__FUNCTION__,portId);
        free(pucApiBuff);
        return retVal;
    }
    pCurrAck->ackData = recv->msg.pwrCurrGetAck.ackData;
    pCurrAck->currVal = OOK_NTOHL(recv->msg.pwrCurrGetAck.currVal);
    MsgPrint(PM_DEBUG, "ackData 0x%x \n",         pCurrAck->ackData);
    MsgPrint(PM_DEBUG, "currVal %d \n",           pCurrAck->currVal);
    free(pucApiBuff);

    return retVal;
}

/*0xe1-0x03 离线文件校验结果查询*/
UINT32 OokMsgSlaveGetRfTblCrcRes(UINT32 portId, T_OokMsgWfsRfTblCrcResGet *pCrcRes, T_OokMsgWfsRfTblCrcResGetAck *pCrcResAck)
{
    UINT32     retVal = BSP_OK;
    UINT8     *pucApiBuff = NULL;
    TookFrameApiPDU *send = NULL;
    TookFrameApiPDU *recv = NULL;
    UINT16 dataLen = 0;

    INPUT_POINTER_CHECK(pCrcRes);
    INPUT_POINTER_CHECK(pCrcResAck);
    pucApiBuff = (UINT8 *)malloc(sizeof(TookFrameApiPDU) + sizeof(TookFrameApiPDU));   /*两个完整的结构体 一个send用 一个recv用*/
    if (NULL == pucApiBuff)
    {
        retVal |= BIT_SET(0);
        dbgErr("%s>>TmpBuf Malloc Error!\n", __FUNCTION__);
        return retVal;
    }
    memset_s((VOID *)pucApiBuff, sizeof(TookFrameApiPDU) + sizeof(TookFrameApiPDU), 0, sizeof(TookFrameApiPDU) + sizeof(TookFrameApiPDU));

    send = (TookFrameApiPDU *)&pucApiBuff[0];                              /*send起始位置*/
    recv = (TookFrameApiPDU *)&pucApiBuff[sizeof(TookFrameApiPDU)];        /*recv起始位置*/
    dataLen = sizeof(T_OokMsgWfsRfTblCrcResGet)+ sizeof(send->msgHead);
    send->head.startFlag1 = OOK_MSG_STARTFLAG1;
    send->head.startFlag2 = OOK_MSG_STARTFLAG2;
    send->head.versionreserverd1 = 1;
    send->head.reserverd2 = 0;
    send->head.dataLen = OOK_HTONS(dataLen);
    send->head.headSum = 0;
    send->msgHead.msgType = OOK_WFS_INFO_GET;
    send->msgHead.msgSubType = OOK_RFTBL_CRC_GET;
    send->msgHead.serialNo = g_serialNo;
    send->msgHead.msgInfoLength = sizeof(T_OokMsgWfsRfTblCrcResGet);
    send->msg.RfTblCrcResGet.fileType = pCrcRes->fileType;
    send->head.dataCrc = BspCountCRC8((UINT8*)&send->msgHead, dataLen);
    MsgPrint(PM_DEBUG, "fileType 0x%x\n", send->msg.RfTblCrcResGet.fileType);

    retVal = BspOokMsgProc(portId, send, recv);
    g_serialNo++;   /*8bit 溢出之后再重新计数*/
    if (retVal != BSP_OK)
    {
        MsgPrint(PM_ERROR,"%s portId=%d send msg error!\n",__FUNCTION__,portId);
        free(pucApiBuff);
        return retVal;
    }
    pCrcResAck->ackData = recv->msg.RfTblCrcResGetAck.ackData;
    MsgPrint(PM_DEBUG, "ackData 0x%x \n", pCrcResAck->ackData);
    free(pucApiBuff);

    return retVal;
}

UINT32 OokMsgSlaveGetAnaLog(UINT32 portId, T_OokMsgAnaLogGet *pVal, T_OokMsgAnaLogGetAck *pValAck)
{
    UINT32     retVal = BSP_OK;
    UINT8     *pucApiBuff = NULL;
    TookFrameApiPDU *send = NULL;
    TookFrameApiPDU *recv = NULL;
    UINT16 dataLen = 0;

    INPUT_POINTER_CHECK(pVal);
    INPUT_POINTER_CHECK(pValAck);
    pucApiBuff = (UINT8 *)malloc(sizeof(TookFrameApiPDU) + sizeof(TookFrameApiPDU));   /*两个完整的结构体 一个send用 一个recv用*/
    if (NULL == pucApiBuff)
    {
        retVal |= BIT_SET(0);
        dbgErr("%s>>TmpBuf Malloc Error!\n", __FUNCTION__);
        return retVal;
    }
    memset_s((VOID *)pucApiBuff, sizeof(TookFrameApiPDU) + sizeof(TookFrameApiPDU), 0, sizeof(TookFrameApiPDU) + sizeof(TookFrameApiPDU));

    send = (TookFrameApiPDU *)&pucApiBuff[0];                              /*send起始位置*/
    recv = (TookFrameApiPDU *)&pucApiBuff[sizeof(TookFrameApiPDU)];        /*recv起始位置*/
    dataLen = sizeof(T_OokMsgAnaLogGet)+ sizeof(send->msgHead);
    send->head.startFlag1 = OOK_MSG_STARTFLAG1;
    send->head.startFlag2 = OOK_MSG_STARTFLAG2;
    send->head.versionreserverd1 = 1;
    send->head.reserverd2 = 0;
    send->head.dataLen = OOK_HTONS(dataLen);
    send->head.headSum = 0;
    send->msgHead.msgType = OOK_ANALOG_GET;
    send->msgHead.msgSubType = 0;
    send->msgHead.serialNo = g_serialNo;
    send->msgHead.msgInfoLength = sizeof(T_OokMsgAnaLogGet);

    send->msg.AnaLogGet.slaveChn = pVal->slaveChn;
    send->msg.AnaLogGet.type = pVal->type;
    send->head.dataCrc = BspCountCRC8((UINT8*)&send->msgHead, dataLen);
    MsgPrint(PM_DEBUG, "slaveChn 0x%x type 0x%x \n", pVal->slaveChn, pVal->type);

    retVal = BspOokMsgProc(portId, send, recv);
    g_serialNo++;   /*8bit 溢出之后再重新计数*/
    if (retVal != BSP_OK)
    {
        MsgPrint(PM_ERROR,"%s portId=%d send msg error!\n",__FUNCTION__,portId);
        free(pucApiBuff);
        return retVal;
    }
    pValAck->ackData = recv->msg.AnaLogGetAck.ackData;
    pValAck->volt = OOK_NTOHL(recv->msg.AnaLogGetAck.volt);
    pValAck->paTemp = OOK_NTOHL(recv->msg.AnaLogGetAck.paTemp);
    pValAck->vaildFlag = recv->msg.AnaLogGetAck.vaildFlag;
    MsgPrint(PM_DEBUG, "ackData 0x%x \n",         pValAck->ackData);
    MsgPrint(PM_DEBUG, "volt   %d \n",            pValAck->volt);
    MsgPrint(PM_DEBUG, "paTemp %d \n",            pValAck->paTemp);
    MsgPrint(PM_DEBUG, "vaildFlag  %d \n",        pValAck->vaildFlag);
    free(pucApiBuff);

    return retVal;
}

/*0x19 DAC栅压获取*/
UINT32 OokMsgSlaveGetGridVolt(UINT32 portId, T_OokMsgGridVoltGet *pVolt, T_OokMsgGridVoltGetAck *pVoltAck)
{
    UINT32     retVal = BSP_OK;
    UINT8     *pucApiBuff = NULL;
    TookFrameApiPDU *send = NULL;
    TookFrameApiPDU *recv = NULL;
    UINT16 dataLen = 0;

    INPUT_POINTER_CHECK(pVolt);
    INPUT_POINTER_CHECK(pVoltAck);
    pucApiBuff = (UINT8 *)malloc(sizeof(TookFrameApiPDU) + sizeof(TookFrameApiPDU));   /*两个完整的结构体 一个send用 一个recv用*/
    if (NULL == pucApiBuff)
    {
        retVal |= BIT_SET(0);
        dbgErr("%s>>TmpBuf Malloc Error!\n", __FUNCTION__);
        return retVal;
    }
    memset_s((VOID *)pucApiBuff, sizeof(TookFrameApiPDU) * 2, 0, sizeof(TookFrameApiPDU) * 2);

    send = (TookFrameApiPDU *)&pucApiBuff[0];                              /*send起始位置*/
    recv = (TookFrameApiPDU *)&pucApiBuff[sizeof(TookFrameApiPDU)];        /*recv起始位置*/
    dataLen = sizeof(T_OokMsgGridVoltGet)+ sizeof(send->msgHead);
    send->head.startFlag1 = OOK_MSG_STARTFLAG1;
    send->head.startFlag2 = OOK_MSG_STARTFLAG2;
    send->head.versionreserverd1 = 1;
    send->head.reserverd2 = 0;
    send->head.dataLen = OOK_HTONS(dataLen);
    send->head.headSum = 0;
    send->msgHead.msgType = OOK_GRID_VOLT_GET;
    send->msgHead.msgSubType = 0;
    send->msgHead.serialNo = g_serialNo;
    send->msgHead.msgInfoLength = sizeof(T_OokMsgGridVoltGet);
    send->msg.gridVoltGet.dacChipIdx = pVolt->dacChipIdx;
    send->msg.gridVoltGet.innerChan = pVolt->innerChan;
    send->head.dataCrc = BspCountCRC8((UINT8*)&send->msgHead, dataLen);
    MsgPrint(PM_DEBUG, "dacChipIdx 0x%x \n", send->msg.gridVoltGet.dacChipIdx);
    MsgPrint(PM_DEBUG, "innerChan 0x%x \n", send->msg.gridVoltGet.innerChan);

    retVal = BspOokMsgProc(portId, send, recv);
    g_serialNo++;   /*8bit 溢出之后再重新计数*/
    if (retVal != BSP_OK)
    {
        MsgPrint(PM_ERROR,"%s portId=%d send msg error!\n",__FUNCTION__,portId);
        free(pucApiBuff);
        return retVal;
    }
    pVoltAck->ackData = recv->msg.gridVoltGetAck.ackData;
    pVoltAck->gridVoltMv = OOK_NTOHS(recv->msg.gridVoltGetAck.gridVoltMv);
    MsgPrint(PM_DEBUG, "ackData 0x%x \n",    pVoltAck->ackData);
    MsgPrint(PM_DEBUG, "gridVoltMv %d \n",   pVoltAck->gridVoltMv);
    free(pucApiBuff);

    return retVal;
}

/*0x1a 强制模式控制子端开关*/
UINT32 OokMsgSlaveForceRfSwitchCtrl(UINT32 portId, T_OokMsgForceRfSwitch *pCtrl, T_OokMsgForceRfSwitchAck *pCtrlAck)
{
    UINT32     retVal = BSP_OK;
    TookFrameApiPDU *pucApiBuff = NULL;
    TookFrameApiPDU *send = NULL;
    TookFrameApiPDU *recv = NULL;
    UINT16 dataLen = 0;

    INPUT_POINTER_CHECK(pCtrl);
    INPUT_POINTER_CHECK(pCtrlAck);
    pucApiBuff = (TookFrameApiPDU *)malloc(sizeof(TookFrameApiPDU) + sizeof(TookFrameApiPDU));   /*两个完整的结构体 一个send用 一个recv用*/
    if (NULL == pucApiBuff)
    {
        retVal |= BIT_SET(0);
        dbgErr("%s>>TmpBuf Malloc Error!\n", __FUNCTION__);
        return retVal;
    }
    memset_s((VOID *)pucApiBuff, sizeof(TookFrameApiPDU) * 2, 0, sizeof(TookFrameApiPDU) * 2);

    send = &pucApiBuff[0];        /*send起始位置*/
    recv = &pucApiBuff[1];        /*recv起始位置*/
    dataLen = sizeof(T_OokMsgForceRfSwitch)+ sizeof(send->msgHead);
    send->head.startFlag1 = OOK_MSG_STARTFLAG1;
    send->head.startFlag2 = OOK_MSG_STARTFLAG2;
    send->head.versionreserverd1 = 1;
    send->head.reserverd2 = 0;
    send->head.dataLen = OOK_HTONS(dataLen);
    send->head.headSum = 0;
    send->msgHead.msgType = OOK_FORCE_SWITCH_CTRL;
    send->msgHead.msgSubType = 0;
    send->msgHead.serialNo = g_serialNo;
    send->msgHead.msgInfoLength = sizeof(T_OokMsgForceRfSwitch);
    send->msg.forceRfSwitch.chan = pCtrl->chan;
    send->msg.forceRfSwitch.modeType = pCtrl->modeType;
    send->head.dataCrc = BspCountCRC8((UINT8*)&send->msgHead, dataLen);
    MsgPrint(PM_DEBUG, "chan %d modeType %d\n", pCtrl->chan, pCtrl->modeType);

    retVal = BspOokMsgProc(portId, send, recv);
    g_serialNo++;   /*8bit 溢出之后再重新计数*/
    if (retVal != BSP_OK)
    {
        MsgPrint(PM_ERROR,"%s portId=%d send msg error!\n",__FUNCTION__,portId);
        free(pucApiBuff);
        return retVal;
    }
    pCtrlAck->ackData = recv->msg.forceRfSwitchAck.ackData;
    MsgPrint(PM_DEBUG, "ackData 0x%x \n",    pCtrlAck->ackData);
    free(pucApiBuff);

    return retVal;
}

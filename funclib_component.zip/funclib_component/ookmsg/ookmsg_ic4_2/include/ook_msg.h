/*****************************************************************************
* 版权所有(C), ZTE Corp. ZXSDR-RRU Platform BSP
*----------------------------------------------------------------------------
* 模块名   : bsp
* 文件名称 : ook_msg.h
* 文件标识 : {[N/A]}
* 内容摘要 : 本文件提供了单板的结构体、变量、参数配置
* 注意事项 : 无
* 作   者 :
* 创建日期 :
* 当前版本 :
*----------------------------------------------------------------------------
*/

#ifndef _OOKMSG_H_
#define _OOKMSG_H_

#ifdef __cplusplus
extern "C"{
#endif

#include "bsppub.h"
#include "bspcomm.h"
#include "rruinfo.h"

#define OOK_CHAN_CHECK(chan)                     \
    if ((chan) >= BspGetTxChannel())             \
    {                                            \
        dbgErr("%s:chan error!\n",__FUNCTION__); \
        return BSP_ERROR;                        \
    }

#define MAX_OOK_MSG_BODY      (512)    /*具体长度待确定*/
#define OOK_HTONL(a)           htonl(a)    /*将主机数转换成无符号长整型的网络字节顺序*/
#define OOK_HTONS(a)           htons(a)    /*是将一个无符号长整形数从网络字节顺序转换为主机字节顺序*/
#define OOK_NTOHL(a)           ntohl(a)
#define OOK_NTOHS(a)           ntohs(a)
#define OOK_MAX_PORTID                    (3)
#define MAX_SEND_LEN_PER_PACK             (512)
#define MAX_RECV_LEN_PER_PACK             (2048)
#define OOK_EXPRNADD_LEN                  (100)
#define OOK_MSG_STARTFLAG1                (0X7E)
#define OOK_MSG_STARTFLAG2                (0XEF)
#define OOK_CMD_MAX_LEN                   (240)
#define MAX_RECV_LEN_ONE_PACK             (256)
#define MAX_SLAVE_VER_UPDATE_CNT          (3)

typedef enum E_SLAVE_VER_INDEX
{
    E_MCU_VER,
    E_EPLD_VER,
    E_SLAVE_VER_NUM
}E_Slave_Ver_Index;

typedef enum E_SLAVEPORT_STA
{
    E_SLAVE_LINK_OK,
    E_SLAVE_LINK_ERROR,
    E_SLAVE_NOT_UPDATE,
    E_SLAVE_NEED_UPDATE,
    E_SLAVE_HEART_ERROR,
    E_SLAVE_HEART_OK,
	E_SLAVE_HEART_TMP_STA,
}E_Slave_Sta;
/*************************** API Layer Information ****************************/

#pragma pack(1)

/* 0x01消息--子端建链消息 */
typedef struct tagT_OokMsgLinkSta
{
    UINT32 randCode;
    UINT32 moduleGroupId;
    UINT32 boardGroupId;
    UINT32 boardTypeId;
    UINT32 hwChangeId;
    UINT32 mcuLen;    /*版本长度*/
    UINT32 epldLen;
    UINT8 reserve[8];
} T_OokMsgLinkSta;

typedef struct tagT_OokMsgLinkStaAck
{
    UINT32 moduleGroupId;
    UINT32 boardGroupId;
    UINT32 boardTypeId;
    UINT32 hwChangeId;
    UINT8 rfsBrdType[32];  /*子端单板类型*/
    UINT8 cpuVer[44];
    UINT8 fpgaVer[44];
    UINT32 fpgaDevType;      /*子端FPGA类型0紫光*/
    UINT32 rfTblSize;        /*子端离线参数大小*/
    UINT32 rfTblCrc32;      /*子端离线参数CRC*/
    UINT8 ackData;
    UINT8 cpuUpgradeFlag;    /*子端cpu升级状态 0正常 1失败*/
    UINT8 fpgaUpgradeFlag;   /*子端fpga升级状态 0正常 1失败*/
    UINT8 cpuType;
    UINT8 rfChnNum;
    UINT8 reserve[15];
}T_OokMsgLinkStaAck;

/* 0x02消息--子端心跳消息 */
typedef struct tagT_OokMsgHeartBeat
{
}T_OokMsgHeartBeat;

typedef struct tagT_OokMsgHeartBeatAck
{
    UINT8 ackData;
}T_OokMsgHeartBeatAck;

/* 0x03消息--射频开关控制消息 */
typedef struct tagT_OokMsgRfSwitch
{
    UINT8 rfChn;       /*子端通道号*/
    UINT8 switchType;  /*开关类型*/
    UINT8 onOffType;   /*开关模式*/
    UINT16 delayMs;    /*开关延时 单位ms*/
    UINT8 reserve[3];
}T_OokMsgRfSwitch;

typedef struct tagT_OokMsgRfSwitchAck
{
    UINT8 ackData;
}T_OokMsgRfSwitchAck;

/* 0x04消息--LED控制消息 */
typedef struct tagT_OokMsgLedSwitch
{
    UINT8 ledType;   /*1 run灯 2 alm灯*/
    UINT8 ctrlType;  /*0-常灭 1-常亮 2-闪烁*/
    UINT16 onTimeMs; /*常亮 时间单位ms, 闪烁时生效*/
    UINT16 offTimeMs;/*常灭 时间单位ms, 闪烁时生效*/
    UINT8 reserve[2];
}T_OokMsgLedSwitch;
typedef struct tagT_OokMsgLedSwitchAck
{
    UINT8 ackData;
}T_OokMsgLedSwitchAck;

/* 0x05消息--栅压配置消息 */
typedef struct tagT_OokMsgGridVoltCfg
{
    UINT8 dacChipIdx;
    UINT8 innerChan;
    UINT16 voltMv;
    UINT8 reserve[4];
}T_OokMsgGridVoltCfg;
typedef struct tagT_OokMsgGridVoltCfgAck
{
    UINT8 ackData;
}T_OokMsgGridVoltCfgAck;

/* 0x06消息--离线参数表下载请求消息 */
typedef struct tagT_OokMsgRfTblDownLoadReq
{
    UINT32 fileSize;  /*离线参数表文件大小*/
    UINT32 crc32;     /*离线文件crc*/
    UINT8  tblType;
    UINT8 reserve[3];
}T_OokMsgRfTblDownLoadReq;

typedef struct tagT_OokMsgRfTblDownLoadReqAck
{
    UINT8 ackData;
    UINT8 compareResult; /*0 比较结果一样不升级  1不一样需要升级*/
    UINT32 fileSize;  /*本地离线参数表文件大小*/
    UINT32 crc32;     /*本地离线文件crc*/
    UINT8 reserve[4];
}T_OokMsgRfTblDownLoadReqAck;

/* 0x07消息--离线参数表下载 */
#define RFTBL_BITNUM_PER_PACK   (230)
typedef struct tagT_OokMsgRfTblDownLoad
{
    UINT8 reserve[4];
    UINT8 fileType;       /*离线文件类型*/
    UINT32 dataOffset;     /*地址偏移*/
    UINT8 dataSize;       /*一包数据大小*/
    UINT8 data[RFTBL_BITNUM_PER_PACK];      /*数据*/
}T_OokMsgRfTblDownLoad;

typedef struct tagT_OokMsgRfTblDownLoadAck
{
    UINT8 ackData;
    UINT32 fileSize;  /*本地离线参数表文件大小*/
    UINT32 crc32;     /*本地离线文件crc*/
    UINT8 reserve[4];
}T_OokMsgRfTblDownLoadAck;

/* 0x08消息--离线参数表上传请求消息 */
typedef struct tagT_OokMsgRfTblUpLoadReq
{
    UINT32 fileSize;  /*离线参数表文件大小*/
    UINT32 crc32;     /*本地子端离线文件crc*/
    UINT8  tblType;
    UINT8 reserve[3];
}T_OokMsgRfTblUpLoadReq;

typedef struct tagT_OokMsgRfTblUpLoadReqAck
{
    UINT8 ackData;
    UINT8 compareResult; /*0 比较结果一样不升级  1不一样需要升级*/
    UINT32 fileSize;  /*本地离线参数表文件大小*/
    UINT32 crc32;     /*本地离线文件crc*/
    UINT8 reserve[4];
}T_OokMsgRfTblUpLoadReqAck;

/* 0x09消息--离线参数表上传 */
typedef struct tagT_OokMsgRfTblUpLoad
{
    UINT32 dataOffset;     /*地址偏移*/
    UINT8 dataSize;       /*一包数据大小*/
    UINT8 tblType;
    UINT8 reserve[2];
}T_OokMsgRfTblUpLoad;

typedef struct tagT_OokMsgRfTblUpLoadAck
{
    UINT8 ackData;
    UINT8 reserve[4];
    UINT32 dataOffset;     /*地址偏移*/
    UINT8 dataSize;       /*一包数据大小*/
    UINT8 data[230];      /*数据*/
}T_OokMsgRfTblUpLoadAck;

/*0xa ookcmd 消息定义 */
typedef struct tagT_OokMsgCmd
{
    UINT8 cmdBuff[OOK_CMD_MAX_LEN];/* data */
}T_OokMsgCmd;
typedef struct tagT_OokMsgCmdAck
{
    UINT8 printBuff[OOK_CMD_MAX_LEN -1];/* data */
    UINT8 ackData;
}T_OokMsgCmdAck;

/*0xb 版本比较 消息定义 */
typedef struct tagT_OokMsgVerCmp
{
    UINT8 cpuCmpResult;  /*0 一致 1不一致*/
    UINT8 cpuVer[44];     /*子端cpu 版本号 crc*/
    UINT32 cpuCrc32;
    UINT8 fpgaCmpResult;  /*0 一致 1不一致*/
    UINT8 fpgaVer[44];
    UINT32 fpgaCrc32;
    UINT8 reserve[4];
}T_OokMsgVerCmp;
typedef struct tagT_OokMsgVerCmpAck
{
    UINT8 ackData;
}T_OokMsgVerCmpAck;

/*0xc 版本下载 消息定义 */
typedef struct tagT_OokMsgVerDownLoad
{
    UINT8 verType;  /*cpu:0 1:fpga*/
    UINT8 reserve[4];
    UINT32 dataOffSet;  /*地址偏移 从0开始*/
    UINT8 dataSize;
    UINT8 data[230];
}T_OokMsgVerDownLoad;

typedef struct tagT_OokMsgDownLoadAck
{
    UINT8 ackData;
    UINT32 fileSize;
    UINT32 crc32;
    UINT8 reserve[4];
}T_OokMsgVerDownLoadAck;

/*0xd 版本激活 消息定义 */
typedef struct tagT_OokMsgVerAct
{
    UINT8 cpuVerActFlag;  /*cpu版本激活标志 0:不激活 1:激活*/
    UINT8 fpgaVerActFlag;   /*fpga版本激活标志 0:不激活 1:激活*/
    UINT8 secBootVerActFlag;   /*boot版本激活标志 0:不激活 1:激活*/
    UINT8 reserve[4];
}T_OokMsgVerAct;

typedef struct tagT_OokMsgVerActAck
{
    UINT8 ackData;
}T_OokMsgVerActAck;

/*0xe 时延测量 消息定义 */
typedef struct tagT_OokMsgDlyMeas
{
    UINT8 action;  /*1开始 2结束*/
    UINT8 reserve[3];
    UINT32 dlyNs;   /*时延: 单位ns*/
}T_OokMsgDlyMeas;

typedef struct tagT_OokMsgDlyMeasAck
{
    UINT8 ackData;
}T_OokMsgDlyMeasAck;

/*0xf 复位 消息定义 */
typedef struct tagT_OokMsgReset
{
    UINT8 rstType;  /*1: 软复位*/
    UINT8 reserve[3];
}T_OokMsgReset;

typedef struct tagT_OokMsgResetAck
{
    UINT8 ackData;
}T_OokMsgResetAck;

/*0x10 TDD配置 消息定义 */
typedef struct tagT_OokMsgTddCfg
{
    UINT8 radioMode;        /*0-NR 1-LTE 2-LV*/
    UINT8 lteSubFreame;     /*LTE子帧配比0-6*/
    UINT8 lteSpeSubFreame;  /*LTE特殊子帧配比0-9*/
    UINT8 nrUeAdv;          /*NR UE提前量*/
    UINT8 dlUlSwNum;        /*1-单周期 2-双周期*/
    UINT32 dlUlSwPeriod[4];
    UINT8 dlSymbolNum[4];
    UINT8 ulSymbolNum[4];
    UINT8 reserve[8];
}T_OokMsgTddCfg;

typedef struct tagT_OokMsgTddCfgAck
{
    UINT8 ackData;
}T_OokMsgTddCfgAck;

/*0x11 波束配置*/
typedef struct tagT_OokMsgBeamCfg
{
    UINT8 beamWidth;  /*0-H60V30 1-H60V60 2-H30V30 3-H30V60*/
    UINT8 reserve[3];
}T_OokMsgBeamCfg;

typedef struct tagT_OokMsgBeamCfgAck
{
    UINT8 ackData;
}T_OokMsgBeamCfgAck;

/*0x12 漏压配置*/
typedef struct tagT_OokMsgPaVoltCfg
{
    UINT16 volt;
    UINT8 reserve[2];
}T_OokMsgPaVoltCfg;

typedef struct tagT_OokMsgPaVoltCfgAck
{
    UINT8 ackData;
}T_OokMsgPaVoltCfgAck;

/*0x13 温度电压查询*/
typedef struct tagT_OokMsgTempVoltGet
{
}T_OokMsgTempVoltGet;

typedef struct tagT_OokMsgTempVoltGetAck
{
    UINT8 ackData;
    INT16 boardTemp;
    INT16 paTemp[2];
    UINT8 reserv1[4];
    INT16 pwrTemp;
    UINT32 pwrVolt;
    UINT8 reserve2[4];
}T_OokMsgTempVoltGetAck;

/*0x14 告警信息查询*/
typedef struct tagT_OokMsgAlmGet
{
}T_OokMsgAlmGet;

typedef struct tagT_OokMsgAlmGetAck
{
    UINT8 ackData;
    UINT32 almState;
    UINT32 almEvent;
    UINT8 reserve[8];
}T_OokMsgAlmGetAck;

/*0x15 开关查询*/
typedef struct tagT_OokMsgRfSwitchSta
{
}T_OokMsgRfSwitchSta;

typedef struct tagT_OokMsgRfSwitchStaAck
{
    UINT8 ackData;
    UINT16 rfSwTestMode;
    UINT16 rfSwSta;
    UINT8 reserve[4];
}T_OokMsgRfSwitchStaAck;

/*0x16 子端告警清除*/
typedef struct tagT_OokMsgAlmClr
{
    UINT32 clrAlmState;
    UINT32 clrAlmEvent;
    UINT8 reserve[3];
}T_OokMsgAlmClr;

typedef struct tagT_OokMsgAlmClrAck
{
    UINT8 ackData;
}T_OokMsgAlmClrAck;

/*0x18 子端资产信息查询*/
typedef struct tagT_OokMsgGetRfsRruInfo
{
    UINT8 filedIndex;
}T_OokMsgGetRfsRruInfo;

/*子端资产信息查询-版本信息*/
typedef struct tagT_OokMsgGetVerInfoAck
{
    UINT8 ackData;
    UINT8 versionFlag;
    UINT8 versionInfo;
}T_OokMsgGetVerInfoAck;

/*子端资产信息查询-RRU信息*/
typedef struct tagT_OokMsgGetRruInfoAck
{
    UINT8 ackData;
    UINT8 rruBarCode[20];
    UINT8 vendorUnitFamilyType[10];
    UINT8 vendorUnitTypeNumber[20];
    UINT8 vendorUnitPid[8];
    UINT8 verdorUnitPidFlag;
    UINT8 rruPaNum;
    UINT8 rruDflNum;
    UINT8 rruPwrNum;
    UINT8 rruPibNum;
    UINT8 rruAntNum;
    UINT8 antNum;
    UINT32 rruRatedPowerTx;
    UINT8 bomCode[20];
    UINT8 supplerCode[20];
    UINT8 productTime[12];
    UINT32 serviceTime;
    UINT8 lastServiceDate[12];
    UINT8 vendorName[20];
}T_OokMsgGetRruInfoAck;

/*子端资产信息查询-单板信息*/
typedef struct tagT_OokMsgGetBoardInfoAck
{
    UINT8 ackData;
    UINT8 boardBarCode[20];
    UINT8 boardName[20];
    UINT8 productTime[12];
    UINT32 serviceTime;
    UINT8 lastServiceDate[12];
    UINT8 vendorName[20];
}T_OokMsgGetBoardInfoAck;

/*子端资产信息查询-电源信息*/
typedef struct tagT_OokMsgGetPwrInfoAck
{
    UINT8 ackData;
    UINT8 pwrBarCode[20];
    UINT8 pwrType[8];
    UINT32 defaultPwrVolt;
    UINT32 pwrVoltUp;
    UINT32 pwrVoltDown;
    UINT32 pwrFactoryId;
    UINT8 productTime[12];
    UINT32 serviceTime;
    UINT8 lastServiceDate[12];
    UINT8 vendorName[20];
}T_OokMsgGetPwrInfoAck;

/*子端资产信息查询-功放信息*/
typedef struct tagT_OokMsgGetPaInfoAck
{
    UINT8 ackData;
    UINT8 paBarCode[20];
    UINT8 boardName[20];
    UINT8 paPath;
    UINT8 paTxFreq[20];
    UINT32 paFactoryId;
    UINT8 productTime[12];
    UINT32 serviceTime;
    UINT8 lastServiceDate[12];
    UINT8 vendorName[20];
}T_OokMsgGetPaInfoAck;

/*子端资产信息查询-双工信息*/
typedef struct tagT_OokMsgGetDflInfoAck
{
    UINT8 ackData;
    UINT8 dflBarCode[48];
    UINT8 boardName[20];
    UINT8 dflAntNum;
    UINT8 dflRxFreq[20];
    UINT8 dflTxFreq[20];
    UINT32 dflFactoryId;
    UINT8 productTime[12];
    UINT32 serviceTime;
    UINT8 lastServiceDate[12];
    UINT8 vendorName[20];
}T_OokMsgGetDflInfoAck;

/*子端资产信息查询-天线信息*/
typedef struct tagT_OokMsgGetAntInfoAck
{
    UINT8 ackData;
    UINT8 antBarCode[20];
    UINT8 boardName[20];
    UINT8 antNum;
    UINT32 antFactoryId;
    UINT8 productTime[12];
    UINT32 serviceTime;
    UINT8 lastServiceDate[12];
    UINT8 vendorName[20];
}T_OokMsgGetAntInfoAck;

/*0xe1-0x00 工装子端信息查询*/
typedef struct tagT_OokMsgWfsBoardInfoGet
{
}T_OokMsgWfsBoardInfoGet;

typedef struct tagT_OokMsgWfsBoardInfoGetAck
{
    UINT8 ackData;
    UINT32 moduleGroupId;
    UINT32 boardGroupId;
    UINT32 boardTypeId;
    UINT32 hwChangeId;
    UINT32 HwCustomIdAId;
    UINT32 HwCustomIdBId;
    UINT16 bomidCrc;
    UINT8 dacTestResult;
    UINT8 mcuTestResult;
    UINT8 epldTestResult;
    UINT8 epldId;
    UINT8 txLogicChanNum;
    UINT8 cpuVer[44];
    UINT8 fpgaVer[44];
    UINT8 firBootVer[32];
    UINT8 secBootVer[32];
    UINT8 barCode[20];
    UINT8 resver1[4];
}T_OokMsgWfsBoardInfoGetAck;

/*0xe1-0x01 工装电流AD值查询*/
typedef struct tagT_OokMsgWfsCurrAdValGet
{
    UINT8 chipIndex;
    UINT8 adcChan;
    UINT8 resver1[2];
}T_OokMsgWfsCurrAdValGet;

typedef struct tagT_OokMsgWfsCurrAdValGetAck
{
    UINT8 ackData;
    UINT32 adVal;
    UINT8 resver[3];
}T_OokMsgWfsCurrAdValGetAck;

/*0xe1-0x02 工装电流查询*/
typedef struct tagT_OokMsgWfsPwrCurrGet
{
    UINT8 chipIndex;
    UINT8 adcChan;
    UINT8 resver1[2];
}T_OokMsgWfsPwrCurrGet;

typedef struct tagT_OokMsgWfsPwrCurrGetAck
{
    UINT8 ackData;
    UINT32 currVal;
    UINT8 resver[3];
}T_OokMsgWfsPwrCurrGetAck;

/*0xe1-0x03 工装离线表校验结果查询*/
typedef struct tagT_OokMsgWfsRfTblCrcResGet
{
    UINT8 fileType;
    UINT8 resver[3];
}T_OokMsgWfsRfTblCrcResGet;

typedef struct tagT_OokMsgWfsRfTblCrcResGetAck
{
    UINT8 ackData;
}T_OokMsgWfsRfTblCrcResGetAck;

/*0x17模拟检波电路*/
typedef struct tagT_OokMsgAnaLogGet
{
    UINT8 slaveChn;
    UINT8 type;
    UINT8 res[6];
}T_OokMsgAnaLogGet;

typedef struct tagT_OokMsgAnaLogGetAck
{
    UINT8 ackData;
    UINT32 volt;
    INT32 paTemp;
    UINT8 vaildFlag;
    UINT8 res[4];
}T_OokMsgAnaLogGetAck;

/*0x19 DAC栅压获取*/
typedef struct tagT_OokMsgGridVoltGet
{
    UINT8 dacChipIdx;
    UINT8 innerChan;
    UINT8 resver[2];
}T_OokMsgGridVoltGet;

typedef struct tagT_OokMsgGridVoltGetAck
{
    UINT8 ackData;
    INT16 gridVoltMv;
    UINT8 resver;
}T_OokMsgGridVoltGetAck;

/*0x1a 组合开关*/
typedef struct tagT_OokMsgForceRfSwitch
{
    UINT8 chan;
    UINT8 modeType; /*0 恢复 1 下行长发反馈长收*/
    UINT8 resver[6];
}T_OokMsgForceRfSwitch;

typedef struct tagT_OokMsgForceRfSwitchAck
{
    UINT8 ackData;
}T_OokMsgForceRfSwitchAck;

/*OOK帧基础信息*/
typedef struct tagTookFrameHeader
{
    UINT8 startFlag1;
    UINT8 startFlag2;
    UINT8 versionreserverd1;
    UINT8 reserverd2;
    UINT16 dataLen;
    UINT8 dataCrc;
    UINT8 headSum;
}TookFrameHeader;   /*OOK数据帧的帧头格式*/

typedef struct tagTookMsgHeader
{
    UINT8 msgType;
    UINT8 msgSubType;
    UINT8 serialNo;
    UINT8 msgInfoLength;
    UINT8 reserved[4];
}TookMsgHeader;   /*OOK消息的消息头*/

typedef struct tagTookFrameApiPDU
{
    TookFrameHeader head;
    TookMsgHeader msgHead;
    union
    {
        UINT8 buf[MAX_OOK_MSG_BODY];     /*返回的数据起始地址的时候 以此成员取数据*/
        /* 0x01消息 */
        T_OokMsgLinkSta                   slaveLinkSta;
        T_OokMsgLinkStaAck                slaveLinkStaAck;
        /* 0x02消息 */
        T_OokMsgHeartBeat                 slaveHearBeat;
        T_OokMsgHeartBeatAck              slaveHearBeatAck;
        /* 0x03消息 */
        T_OokMsgRfSwitch                  slaveRfSwitch;
        T_OokMsgRfSwitchAck               slaveRfSwitchAck;
        /* 0x04消息 */
        T_OokMsgLedSwitch                 slaveLedSwitch;
        T_OokMsgLedSwitchAck              slaveLedSwitchAck;
        /* 0x05消息 */
        T_OokMsgGridVoltCfg               slaveGridVoltCfg;
        T_OokMsgGridVoltCfgAck            slaveGridVoltCfgAck;
        /* 0x06消息 */
        T_OokMsgRfTblDownLoadReq          rfTblDownLoadReq;
        T_OokMsgRfTblDownLoadReqAck       rfTblDownLoadReqAck;
        /* 0x07消息 */
        T_OokMsgRfTblDownLoad             rfTblDownLoad;
        T_OokMsgRfTblDownLoadAck          rfTblDownLoadAck;
        /* 0x08消息 */
        T_OokMsgRfTblUpLoadReq            rfTblUpLoadReq;
        T_OokMsgRfTblUpLoadReqAck         rfTblUpLoadReqAck;
        /* 0x09消息 */
        T_OokMsgRfTblUpLoad               rfTblUpLoad;
        T_OokMsgRfTblUpLoadAck            rfTblUpLoadAck;
        /* 0xa消息 */
        T_OokMsgCmd                       slaveOokCmd;
        T_OokMsgCmdAck                    slaveOokCmdAck;
        /* 0xb消息 */
        T_OokMsgVerCmp                    slaveVerCmp;
        T_OokMsgVerCmpAck                 slaveVerCmpAck;
        /* 0xc消息 */
        T_OokMsgVerDownLoad               slaveVerDownLoad;
        T_OokMsgVerDownLoadAck            slaveVerDownLoadAck;
        /* 0xd消息 */
        T_OokMsgVerAct                    slaveVerAct;
        T_OokMsgVerActAck                 slaveVerActAck;
        /* 0xe消息 */
        T_OokMsgDlyMeas                   slaveDlyMeas;
        T_OokMsgDlyMeasAck                slaveDlyMeasAck;
        /* 0xf消息 */
        T_OokMsgReset                     slaveReset;
        T_OokMsgResetAck                  slaveResetAck;
        /* 0x10消息 */
        T_OokMsgTddCfg                    slaveTddCfg;
        T_OokMsgTddCfgAck                 slaveTddCfgAck;
        /* 0x11消息 */
        T_OokMsgBeamCfg                   slaveBeamCfg;
        T_OokMsgBeamCfgAck                slaveBeamCfgAck;
        /* 0x12消息 */
        T_OokMsgPaVoltCfg                 paVoltCfg;
        T_OokMsgPaVoltCfgAck              paVoltCfgAck;
        /* 0x13消息 */
        T_OokMsgTempVoltGet               tempVoltGet;
        T_OokMsgTempVoltGetAck            tempVoltGetAck;
        /* 0x14消息 */
        T_OokMsgAlmGet                    almGet;
        T_OokMsgAlmGetAck                 almGetAck;
        /* 0x15消息 */
        T_OokMsgRfSwitchSta               rfSwSta;
        T_OokMsgRfSwitchStaAck            rfSwStaAck;
        /* 0x16消息 */
        T_OokMsgAlmClr                    almClr;
        T_OokMsgAlmClrAck                 almClrAck;
        /* 0x18资产信息消息 */
        T_OokMsgGetRfsRruInfo             rfsInfo;
        T_OokMsgGetVerInfoAck             verInfoAck;
        T_OokMsgGetRruInfoAck             rruInfoAck;
        T_OokMsgGetBoardInfoAck           boardInfoAck;
        T_OokMsgGetPwrInfoAck             pwrInfoAck;
        T_OokMsgGetPaInfoAck              paInfoAck;
        T_OokMsgGetDflInfoAck             dflInfoAck;
        T_OokMsgGetAntInfoAck             antInfoAck;
        /* 0xe1-0x00工装消息 */
        T_OokMsgWfsBoardInfoGet           boardInfoGet;
        T_OokMsgWfsBoardInfoGetAck        boardInfoGetAck;
        /* 0xe1-0x01工装消息 */
        T_OokMsgWfsCurrAdValGet           adValGet;
        T_OokMsgWfsCurrAdValGetAck        adValGetAck;
        /* 0xe1-0x02工装消息 */
        T_OokMsgWfsPwrCurrGet             pwrCurrGet;
        T_OokMsgWfsPwrCurrGetAck          pwrCurrGetAck;
        /* 0xe1-0x03离线表校验结果查询消息 */
        T_OokMsgWfsRfTblCrcResGet             RfTblCrcResGet;
        T_OokMsgWfsRfTblCrcResGetAck          RfTblCrcResGetAck;
        /*0x17消息*/
        T_OokMsgAnaLogGet                 AnaLogGet;
        T_OokMsgAnaLogGetAck              AnaLogGetAck;
        /*0x19消息*/
        T_OokMsgGridVoltGet               gridVoltGet;
        T_OokMsgGridVoltGetAck            gridVoltGetAck;
        /*0x1a消息*/
        T_OokMsgForceRfSwitch             forceRfSwitch;
        T_OokMsgForceRfSwitchAck          forceRfSwitchAck;
    }msg;
}TookFrameApiPDU;



#pragma pack()
#define OOK_GET_SLAVE_LINK_STA                      0x0001   /*建链状态*/
#define OOK_GET_SLAVE_HEAT_STA                      0x0002   /*心跳*/
#define OOK_SET_SLAVE_RF_SWITCH                     0x0003   /*射频开关*/
#define OOK_SET_SLAVE_LED_SWITCH                    0x0004   /*LED控制*/
#define OOK_SET_SLAVE_GRID_VOLT                     0x0005   /*栅压控制*/
#define OOK_RFTBL_DOWNLOAD_REQ                      0x0006   /*离线参数下载请求*/
#define OOK_RFTBL_DOWNLOAD                          0x0007   /*离线参数下载*/
#define OOK_RFTBL_UPLOAD_REQ                        0x0008   /*离线参数上传请求*/
#define OOK_RFTBL_UPLOAD                            0x0009   /*离线参数上传*/
#define OOK_TEST_CMD                                0x000a   /*ookcmd调测命令*/
#define OOK_VER_CMP                                 0x000b   /*版本比较*/
#define OOK_VER_DOWNLOAD                            0x000c   /*版本下载*/
#define OOK_VER_ACT                                 0x000d   /*版本激活*/
#define OOK_DLY_MEAS                                0x000e   /*时延测量*/
#define OOK_BOARD_RESET                             0x000f   /*子端复位*/
#define OOK_TDD_CFG                                 0x0010   /*tdd配置*/
#define OOK_BEAM_CFG                                0x0011   /*波束配置*/
#define OOK_PWRVOLT_CFG                             0x0012   /*漏压配置*/
#define OOK_TEMP_VOLT_GET                           0x0013   /*温度电压查询*/
#define OOK_ALM_GET                                 0x0014   /*子端告警查询*/
#define OOK_SWITCH_GET                              0x0015   /*开关查询*/

#define OOK_ALM_CLEAR                               0x0016   /*子端告警清除*/
#define OOK_ANALOG_GET                              0x0017   /*模拟检波电路*/
#define OOK_ASSET_INFO_GET                          0x0018   /*子端资产信息查询*/
#define OOK_GRID_VOLT_GET                           0x0019   /*DAC栅压查询*/
#define OOK_FORCE_SWITCH_CTRL                       0x001A   /*强制模式控制开关*/
#define OOK_WFS_INFO_GET                            0x00e1   /*工装信息查询*/


#define OOK_WFS_BOARD_INFO_GET                      0x0000   /*工装子端信息查询*/
#define OOK_CURR_AD_VAL_GET                         0x0001   /*工装电流AD值查询*/
#define OOK_PWR_CURR_GET                            0x0002   /*工装电流查询*/
#define OOK_RFTBL_CRC_GET                            0x0003   /*工装离线表校验结果查询*/

#define OOK_VER_INFO_GET                            0x0000   /*子端资产信息查询-版本信息*/
#define OOK_RRU_INFO_GET                            0x0001   /*子端资产信息查询-RRU信息*/
#define OOK_BOARD_INFO_GET                          0x0002   /*子端资产信息查询-单板信息*/
#define OOK_PWR_INFO_GET                            0x0003   /*子端资产信息查询-电源信息*/
#define OOK_PA_INFO_GET                             0x0004   /*子端资产信息查询-功放信息*/
#define OOK_DFL_INFO_GET                            0x0005   /*子端资产信息查询-双工信息*/
#define OOK_ANT_INFO_GET                            0x0006   /*子端资产信息查询-天线信息*/



UINT32 BspOokMsgInit(void);
UINT32 OokMsgGetSlaveLinkSta(UINT32 portId, T_OokMsgLinkSta *pLinkSta, T_OokMsgLinkStaAck *pLinkStaAck);
UINT32 OokMsgCmd(UINT32 portId, char *pCmd);
UINT32 OokMsgGetSlaveHeartBeat(UINT32 portId, UINT32 *pHeatSta);
UINT32 OokMsgSetSlaveRfSwitch(UINT32 portId, T_OokMsgRfSwitch *pSwitch);
UINT32 OokMsgSetSlaveLedSwitch(UINT32 portId, T_OokMsgLedSwitch *pSwitch);
UINT32 OokMsgSetSlaveGridVolt(UINT32 portId, T_OokMsgGridVoltCfg *pSwitch);
UINT32 OokMsgRfTblUpLoad(UINT32 portId, T_OokMsgRfTblUpLoad *pRfTbl, T_OokMsgRfTblUpLoadAck *pRfTblAck);
UINT32 OokMsgRfTblUpLoadReq(UINT32 portId, T_OokMsgRfTblUpLoadReq *pRfTblReq, T_OokMsgRfTblUpLoadReqAck *pRfTblReqAck);
UINT32 OokMsgRfTblDownLoad(UINT32 portId, T_OokMsgRfTblDownLoad *pRfTbl, T_OokMsgRfTblDownLoadAck *pRfTblAck);
UINT32 OokMsgRfTblDownLoadReq(UINT32 portId, T_OokMsgRfTblDownLoadReq *pRfTblReq, T_OokMsgRfTblDownLoadReqAck *pRfTblReqAck);
UINT32 OokMsgVerCmp(UINT32 portId, T_OokMsgVerCmp *pVerCmp, T_OokMsgVerCmpAck *pVerCmpAck);
UINT32 OokMsgVerDownLoad(UINT32 portId, T_OokMsgVerDownLoad *pVerDown, T_OokMsgVerDownLoadAck *pVerDownAck);
UINT32 OokMsgVerActive(UINT32 portId, T_OokMsgVerAct *pVerAct, T_OokMsgVerActAck *pVerActAck);
UINT32 OokMsgDlyMeasure(UINT32 portId, T_OokMsgDlyMeas *pDlyMeas, T_OokMsgDlyMeasAck *pDlyMeasAck);
UINT32 OokMsgSlaveReset(UINT32 portId, T_OokMsgReset *pReset, T_OokMsgResetAck *pResetAck);
UINT32 OokMsgSlaveTddCfg(UINT32 portId, T_OokMsgTddCfg *pTddCfg, T_OokMsgTddCfgAck *pTddCfgAck);
UINT32 OokMsgSlaveBeamCfg(UINT32 portId, T_OokMsgBeamCfg *pBeamCfg, T_OokMsgBeamCfgAck *pBeamCfgAck);
UINT32 OokMsgSlavePaVoltCfg(UINT32 portId, T_OokMsgPaVoltCfg *pCfg, T_OokMsgPaVoltCfgAck *pCfgAck);
UINT32 OokMsgSlaveGetTempVolt(UINT32 portId, T_OokMsgTempVoltGetAck *pTempVoltGetAck);
UINT32 OokMsgSlaveGetAlarm(UINT32 portId, T_OokMsgAlmGetAck *pAlmGetAck);
UINT32 OokMsgSlaveGetRfSwitch(UINT32 portId, T_OokMsgRfSwitchStaAck *pStaAck);
UINT32 OokMsgSlaveAlarmClr(UINT32 portId, T_OokMsgAlmClr *pAlmClr, T_OokMsgAlmClrAck *pAlmClrAck);
UINT32 OokMsgSlaveGetWfsBoardInfo(UINT32 portId, T_OokMsgWfsBoardInfoGetAck *pInfoAck);
UINT32 OokMsgSlaveGetCurrAdVal(UINT32 portId, T_OokMsgWfsCurrAdValGet *pAdVal, T_OokMsgWfsCurrAdValGetAck *pAdValAck);
UINT32 OokMsgSlaveGetPwrCurr(UINT32 portId, T_OokMsgWfsPwrCurrGet *pCurr, T_OokMsgWfsPwrCurrGetAck *pCurrAck);
UINT32 OokMsgSlaveGetAnaLog(UINT32 portId, T_OokMsgAnaLogGet *pVal, T_OokMsgAnaLogGetAck *pValAck);
UINT32 OokMsgSlaveGetGridVolt(UINT32 portId, T_OokMsgGridVoltGet *pVolt, T_OokMsgGridVoltGetAck *pVoltAck);
UINT32 OokMsgSlaveGetRruInfo(UINT32 portId, T_OokMsgGetRruInfoAck *pRruAck);
UINT32 OokMsgSlaveGetPwrInfo(UINT32 portId, T_OokMsgGetPwrInfoAck *pPwrAck);
UINT32 OokMsgSlaveGetDflInfo(UINT32 portId, UINT8 filedIndex, T_OokMsgGetDflInfoAck *pDflAck);
UINT32 OokMsgSlaveGetPaInfo(UINT32 portId, T_OokMsgGetPaInfoAck *pPaAck);
UINT32 OokMsgSlaveGetRfTblCrcRes(UINT32 portId, T_OokMsgWfsRfTblCrcResGet *pCrcRes, T_OokMsgWfsRfTblCrcResGetAck *pCrcResAck);
UINT32 OokMsgSlaveForceRfSwitchCtrl(UINT32 portId, T_OokMsgForceRfSwitch *pCtrl, T_OokMsgForceRfSwitchAck *pCtrlAck);
#ifdef __cplusplus
}
#endif

#endif  /* _DSPMSG_H_ */

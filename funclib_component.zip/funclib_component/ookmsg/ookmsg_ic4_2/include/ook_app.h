/*********************************************************************
* 版权所有 (C)深圳市中兴通讯股份有限公司。
* 
* 文件名称： dpd_app.h
* 文件标识：
* 内容摘要：应用层实现的实现的头文件
* 其它说明：
* 当前版本：
* 作   者：
* 完成日期：
* 
* 修改记录1：
*    修改日期：
*    版 本 号：
*    修 改 人：
*    修改内容：

**********************************************************************/

#ifndef FUNCLIB_OOK_APP_H
#define FUNCLIB_OOK_APP_H
#include "ook_msg.h"

#ifdef __cplusplus

extern "C"
{
#endif

/**************************************************************************
 *                      宏定义                                         *
 **************************************************************************/

/*************************************************************************
 *                        函数申明                                      *
 **************************************************************************/

UINT32 BspOokgGetSlaveLinkSta(UINT32 portId, T_OokMsgLinkStaAck *pLinkSta);
UINT32 BspOokCmd(UINT32 portId, char *pCmd);
UINT32 BspOokSlaveBeamCfg(UINT32 portId, UINT32 beamWidth);
UINT32 BspOokSetSlaveReset(UINT32 portId);
UINT32 BspSlavePortVerLoad(UINT32 portId);
UINT32 BspSlavePortInit(UINT32 portId);
UINT32 BspGetSlaveTempAndVolt(UINT32 portId, T_SlavePortTempVolt *pTempVolt);
UINT32 BspOokGetSlaveTempAndVolt(UINT32 portId, T_SlavePortTempVolt *pTempVolt);
UINT32 BspOokGetSlaveAlarm(UINT32 portId, T_OokMsgAlmGetAck *pAlmGetAck);
UINT32 BspGetSlavePortPmosAlm(UINT32 portId, T_OokMsgAlmGetAck *pAlmSta);
UINT32 BspOokSlaveTddCfg(UINT32 portId );
UINT32 BspSlaveThreadInit(void);
UINT32 BspOokSetSlaveRfSwitch(UINT32 chan, UINT32 swType, UINT32 sw, UINT32 swDly);
UINT32 BspOokGetSlaveRfSwitch(UINT32 portId, T_SlavePortRfSwitchSta *pStaAck);
UINT32 BspOokGetWfsSlaveBoardInfo(UINT32 portId, T_OokMsgWfsBoardInfoGetAck *pInfoAck);
UINT32 BspOokGetSlaveCurrAdVal(UINT32 portId, UINT32 pwrIndex, UINT32 adcChan, T_OokMsgWfsCurrAdValGetAck *pAdValAck);
UINT32 BspOokGetSlavePwrCurr(UINT32 portId, UINT32 pwrIndex, UINT32 adcChan, T_OokMsgWfsPwrCurrGetAck *pCurrAck);
UINT32 BspGetSlavePortSta(UINT32 portId, UINT32 type);
UINT32 BspClrSlavePortSta(UINT32 portId, UINT32 type);
UINT32 BspOokRfTblDownLoad(UINT32 portId, UINT32 tblType);
UINT32 BspOokSlaveAlarmClr(UINT32 portId, UINT32 clrAlm, UINT32 clrAlmEvent);
UINT32 BspSlavePortRfTblInitUpdate(UINT32 portId);
UINT32 BspGetSlaveRfDectorVolt(UINT32 chan, UINT32 type, UINT32 *pAdVal, INT32 *paTemp, UINT8 *pVaildFlag);
UINT32 BspOokGetSlaveGridVolt(UINT32 portId, UINT8 dacChipIdx, UINT8 innerChan, INT16 *pVolt);
UINT32 BspGetSlavePaCurrAdVal(UINT32 portId, UINT32 pwrIndex, UINT32 adcChan, UINT32 *pAdVal);
UINT32 BspOokGetSlaveRfTblCrcRes(UINT32 portId, UINT32 fileType, T_OokMsgWfsRfTblCrcResGetAck *pCrcResAck);
UINT32 BspGetSlavePortVerStatus(UINT32 portId);
UINT32 BspOokSetSlavePaVolt(UINT32 portId, UINT16 volt);
UINT32 BspOokSlaveForceRfSwitch(UINT32 portId, UINT32 slaveChn, UINT32 mode);
UINT32 BspGetSlaveAlarm(UINT32 portId, T_SlavePortGetAlm *pAlmGetAck);
INT32 BspGetSlavePastPaProAlm(E_PaProType ePaProType, UINT64 *pu64EventBits);
INT32 BspPaProSlaveAlmRecover(UINT32 ulPaProAlmType, UINT64 u64EventAlmMask);
UINT32 BspOokClrSlaveInitAlarm(UINT32 portId);
void slaveinitsw(UINT32 portId, UINT32 sw);
UINT32 BspGetSlavePortRfTblLoadSta(VOID);
UINT32 BspResetSlavePortSta(UINT32 portId, UINT32 type);
#ifdef __cplusplus
}
#endif

#endif  /* FUNCLIB_OOK_APP_H */


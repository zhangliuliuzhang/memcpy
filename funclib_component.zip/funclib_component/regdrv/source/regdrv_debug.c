/*****************************************************************************
 * 版权所有(C) 2014, ZTE Corp. ZXSDR-RRU Platform BSP
 *----------------------------------------------------------------------------
 * 模 块 名 : BSP
 * 文件名称 : regdrv_debug.c
 * 文件标识 : {[N/A]}
 * 内容摘要 : 本文件主要提供寄存器调试命令的实现。
 * 注意事项 : 无
 * 作    者 : 王飞
 * 创建日期 : 2017-02-05 10:28:34
 * 当前版本 : Ver1.0
 *----------------------------------------------------------------------------
 * 变更记录 :
 *
 * $记录1
 * 变 更 单:
 * 责 任 人:
 * 修改日戳:
 * 变更说明:

 *----------------------------------------------------------------------------
 */
#include "regdrv_debug.h"
#include "rruinfo.h"
#include "regdrv_pincfg.h"
#include "regdrv_access.h"
#include "spibus_common.h"
/**************************************************************************
 *                        宏定义
 **************************************************************************/
 
/**************************************************************************
*                         数据类型                                       *
**************************************************************************/

/**************************************************************************
*                         全局变量定义                                   *
**************************************************************************/

/**************************************************************************
 *                         函数实现
 **************************************************************************/
#if 0

/*****************************************************************************
*  函数名称   : BspGetEpldReg
*  功能描述   : Epld寄存器读取接口
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : usAddr---地址
*  输出参数   : 无
*  返 回 值   : 寄存器值
*  其它说明   : 无
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2017-02-16 14:55:24    创建
*----------------------------------------------------------------------------
*/

UINT32 BspGetReg(UINT32 regType,UINT32 chipId, UINT32 addr)
{
    UINT32 regVal = 0;
    if(regType > DEV_REG_ACCESS_TYPE_MAX)
    {
        dbgInfo("[%s]Reg Type  %d Error \n",__FUNCTION__,regType);
        return BSP_ERROR;
    }
    T_Reg_Drv_Access *pRegAcessSpi = NULL; 
    pRegAcessSpi = BspGetRegAccess(regType);
    if(NULL != pRegAcessSpi->pRegRd)
    {
        pRegAcessSpi->pRegRd(chipId,addr,&regVal);
    }
    return regVal;
}
/*****************************************************************************
*  函数名称   : BspSetEpldReg
*  功能描述   : Epld寄存器写入接口
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : usAddr---地址
*  输出参数   : 无
*  返 回 值   : BSP_OK
*  其它说明   : 无
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2017-02-16 14:55:24    创建
*----------------------------------------------------------------------------
*/
void BspSetReg(UINT32 regType, UINT32 chipId, UINT32 addr, UINT32 value)
{
    if(regType > DEV_REG_ACCESS_TYPE_MAX)
    {
        dbgInfo("[%s]Reg Type  %d Error \n",__FUNCTION__,regType);
    }
    T_Reg_Drv_Access *pRegAcessSpi = NULL; 
    pRegAcessSpi = BspGetRegAccess(regType);
    if(NULL != pRegAcessSpi->pRegWr)
    {
        pRegAcessSpi->pRegWr(chipId,addr,value);
    }   
}

void wrepld(UINT32 addr,UINT32 val)
{
    UINT32 busType = DEV_REG_ACCESS_LOCAL_BUS;
    UINT8  devId[8] = {0};
    TRruDeviceDescription fpgaDev = {0};

    snprintf(devId,sizeof(devId),"Epld0");
    if (BSP_OK != BspDevInfoGetByDevIdName((UINT8*)devId, &fpgaDev))
    {
        return ;
    }
    if (strstr(fpgaDev.acBusName,"SPI"))
    {
        busType = DEV_REG_ACCESS_SPI_BUS;
    }
    
    BspSetReg(DEV_REG_ACCESS_SPI_BUS,2, addr, val);
}

void rdepld(UINT32 addr,UINT32 len)
{
    static UINT16 defaultNum=128;
    UINT32 loop;
    UINT32 data;
    UINT32 delta,start;
    UINT32 busType = DEV_REG_ACCESS_LOCAL_BUS;
    UINT8  devId[8] = {0};
    TRruDeviceDescription epldDev = {0};

    snprintf(devId,sizeof(devId),"Epld0");
    if (BSP_OK != BspDevInfoGetByDevIdName((UINT8*)devId, &epldDev))
    {
        return ;
    }
    if (strstr(epldDev.acBusName,"SPI"))
    {
        busType = DEV_REG_ACCESS_SPI_BUS;
    }
    len = (len) ? len : defaultNum;
    defaultNum = len;

    delta = addr & 0x7;
    start = addr - delta;
    len  += delta;
    dbgInfo("\n Epld     =+0= =+1= =+2= =+3= =+4= =+5= =+6= =+7=\n");
    for (loop = 0; loop < len; loop++)
    {
        if (!((loop*2)&0xF))
        {
            dbgInfo("\n%08X: ",start+loop);
        }
        if(start+loop < addr)
        {
            dbgInfo("     ");
        }
        else
        {
            data = BspGetReg(busType,epldDev.ulDeviceIndex,start+loop);
            dbgInfo("  %02X ", data);
        }
    }
    dbgInfo("\n");
}

void wrfpga(UINT32 chip,UINT32 addr,UINT32 val)
{
    UINT32 busType = DEV_REG_ACCESS_LOCAL_BUS;
    UINT8  devId[8] = {0};
    TRruDeviceDescription fpgaDev = {0};

    snprintf(devId,sizeof(devId),"Fpga%d",chip);
    if (BSP_OK != BspDevInfoGetByDevIdName((UINT8*)devId, &fpgaDev))
    {
        return ;
    }
    if (strstr(fpgaDev.acBusName,"SPI"))
    {
        busType = DEV_REG_ACCESS_SPI_BUS;
    }
    
    BspSetReg(busType,chip, addr, val);
}
void rdfpga(UINT32 chip,UINT32 addr,UINT32 len)
{
    static UINT16 defaultNum=128;
    UINT32 loop;
    UINT32 data;
    UINT32 delta, start;
    UINT32 busType = DEV_REG_ACCESS_LOCAL_BUS;
    UINT8  devId[8] = {0};
    TRruDeviceDescription fpgaDev = {0};

    snprintf(devId,sizeof(devId),"Fpga%d",chip);
    if (BSP_OK != BspDevInfoGetByDevIdName((UINT8*)devId, &fpgaDev))
    {
        return ;
    }
    if (strstr(fpgaDev.acBusName,"SPI"))
    {
        busType = DEV_REG_ACCESS_SPI_BUS;
    }
    
    len = (len) ? len : defaultNum;
    defaultNum = len;

    delta = addr & 0x7;
    start = addr - delta;
    len  += delta;
    dbgInfo("\n Fpga     = + 0 =  == + 1 =  = + 2 =  = + 3 =  = + 4 =  = + 5 =  = + 6 =  = + 7 = \n");
    for (loop = 0; loop < len; loop++)
    {
        if (!((loop*2)&0xF))
        {
            dbgInfo("\n%08X: ", start+loop);
        }
        if (start+loop < addr)
        {
            dbgInfo("         ");
        }
        else
        {
            data = BspGetReg(busType,chip,start+loop);
            dbgInfo("%08X ", data);
        }
    }
    dbgInfo("\n");
}
UINT32 rdsocfpga(UINT32 chip,UINT32 addr,UINT32 len)
{
    UINT32 blkNo        = 0;
    UINT32 blkBaseAddr  = 0;
    UINT32 offsetAddr   = 0;
    UINT32 readData     = 0;
    UINT32 loop         = 0;
    
    UINT32 socaddr      = 0xA0000000;    
    UINT32 ret          = 0;   
    UINT32 phyAddr      = 0;

    phyAddr = socaddr + addr*4;
    for (loop = 0; loop < len; loop++)
    {
        ret = BspGetMemBlockFromPhyAddr(phyAddr + 4 * loop, &blkNo, &blkBaseAddr);
        if(BSP_OK!=ret)
        {
            dbgInfo("can't get blk\n");
            return ret;
        }
        
        offsetAddr = (phyAddr + 4 * loop - blkBaseAddr)/4;       

        dbgInfoEx("blkNo = %d blkBaseAddr =0x%x offsetAddr = 0x%x\n", blkNo, blkBaseAddr,offsetAddr);
        BspRegDomainRd(chip, blkNo, offsetAddr, &readData);
        dbgPrn("readData(addr:0x%x) = 0x%08x\n", phyAddr + 4 * loop, readData);
    }

    if (1 ==  len)
    {
        return readData;
    }
    else
    {
        return len;
    }
}
UINT32 wrsocfpga(UINT32 chip,UINT32 addr,UINT32 val)
{
    UINT32 blkNo        = 0;
    UINT32 blkBaseAddr  = 0;
    UINT32 offsetAddr   = 0;
    UINT32 readData     = 0;
    UINT32 loop         = 0;
    
    UINT32 socaddr      = 0xA0000000;    
    UINT32 ret          = 0;   
    UINT32 phyAddr      = 0;

    phyAddr = socaddr + addr*4;
    

    ret = BspGetMemBlockFromPhyAddr(phyAddr , &blkNo, &blkBaseAddr);
    if(BSP_OK!=ret)
    {
        dbgInfo("can't get blk\n");
        return ret;
    }
    offsetAddr = (phyAddr  - blkBaseAddr)/4;
    dbgPrn("blkBaseAddr =0x%x offsetAddr = 0x%x phyaddr = 0x%x \n",  blkBaseAddr,offsetAddr,phyAddr);
    return BspRegDomainWr(chip, blkNo, offsetAddr, val);
   
}
#endif


static UINT32 s_uSocPhyBaseAddr = 0xA0000000;
static UINT32 s_uEpldPhyBaseAddr = 0x7fb00000;
static UINT32 s_uIfcPhyBaseAddr = 0x1530000;
/*****************************************************************************
*  函数名称   : BspSetSocPhyBaseAddr
*  功能描述   : SPI类型FPGA寄存器读写接口
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : usAddr---地址
*  输出参数   : 无
*  返 回 值   : BSP_OK
*  其它说明   : 无
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2017-02-16 14:55:24    创建
*----------------------------------------------------------------------------
*/
UINT32 BspSetSocPhyBaseAddr(UINT32 chipId, UINT32 SocBaseAddr)
{
    s_uSocPhyBaseAddr = SocBaseAddr;
	return BSP_OK;
}

/*****************************************************************************
*  函数名称   : BspSetEpldPhyBaseAddr
*  功能描述   : 
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : usAddr---地址
*  输出参数   : 无
*  返 回 值   : BSP_OK
*  其它说明   : 无
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2017-02-16 14:55:24    创建
*----------------------------------------------------------------------------
*/
UINT32 BspSetEpldPhyBaseAddr(UINT32 chipId, UINT32 EpldBaseAddr)
{
	s_uEpldPhyBaseAddr = EpldBaseAddr;
	return BSP_OK;
}

/*****************************************************************************
*  函数名称   : BspSetIfcPhyBaseAddr
*  功能描述   : 
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : usAddr---地址
*  输出参数   : 无
*  返 回 值   : BSP_OK
*  其它说明   : 无
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2017-02-16 14:55:24    创建
*----------------------------------------------------------------------------
*/
UINT32 BspSetIfcPhyBaseAddr(UINT32 chipId, UINT32 IfcBaseAddr)
{
	s_uIfcPhyBaseAddr = IfcBaseAddr;
	return BSP_OK;
}
/*****************************************************************************
*  函数名称   : BspGetRegSpi
*  功能描述   : SPI类型FPGA寄存器读写接口
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : usAddr---地址
*  输出参数   : 无
*  返 回 值   : 寄存器值
*  其它说明   : 无
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2017-02-16 14:55:24    创建
*----------------------------------------------------------------------------
*/
static UINT32 BspGetRegSpi(UINT32 chipId, UINT32 addr,UINT32 *data)
{
    UINT32 ret = BSP_OK;
    T_Reg_Drv_Access *pRegAcessSpi = NULL; 
    INPUT_POINTER_CHECK(data);
    pRegAcessSpi = BspGetRegAccess(DEV_REG_ACCESS_SPI_BUS);
    INPUT_POINTER_CHECK(pRegAcessSpi);
    if(NULL != pRegAcessSpi->pRegRd)
    {
        ret = pRegAcessSpi->pRegRd(chipId,addr,data);
    }

    return ret;
}

/*****************************************************************************
*  函数名称   : BspSetRegSpi
*  功能描述   : SPI类型FPGA寄存器读写接口
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : usAddr---地址
*  输出参数   : 无
*  返 回 值   : BSP_OK
*  其它说明   : 无
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2017-02-16 14:55:24    创建
*----------------------------------------------------------------------------
*/
static VOID BspSetRegSpi(UINT32 chipId, UINT32 addr, UINT32 data)
{    
    T_Reg_Drv_Access *pRegAcessSpi = NULL; 
    pRegAcessSpi = BspGetRegAccess(DEV_REG_ACCESS_SPI_BUS);
    if(NULL != pRegAcessSpi->pRegWr)
    {
        pRegAcessSpi->pRegWr(chipId,addr,data);
    }   
}

static VOID BspSetRegSpiMask(UINT32 chipId, UINT32 addr, UINT32 data, UINT32 mask)
{    
    T_Reg_Drv_Access *pRegAcessSpi = NULL; 
    pRegAcessSpi = BspGetRegAccess(DEV_REG_ACCESS_SPI_BUS);
    if(NULL != pRegAcessSpi->pWrMask)
    {
        pRegAcessSpi->pWrMask(chipId,addr,data,mask);
    }   
}


/*****************************************************************************
*  函数名称   : BspGetReg
*  功能描述   : 寄存器读写接口
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : usAddr---地址
*  输出参数   : 无
*  返 回 值   : 寄存器值
*  其它说明   : 无
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2017-02-16 14:55:24    创建
*----------------------------------------------------------------------------
*/
static UINT32 BspGetRegLocalBus(UINT32 chipId, UINT32 addr,UINT32 *data)
{
    UINT32 ret          = BSP_OK;
    UINT32 blkNo        = 0;
    UINT32 blkBaseAddr  = 0;
    UINT32 offsetAddr   = 0;
    UINT32 readData     = 0;    
    UINT32 socaddr      = s_uSocPhyBaseAddr;     
    UINT32 phyAddr      = 0;
    UINT32 busWidth     = 0;

    ret = BspGetMemBlockFromPhyAddr(socaddr, &blkNo, &blkBaseAddr,&busWidth);
    if(BSP_OK!=ret)
    {
        dbgInfo("can't get blk\n");
        return ret;
    }
    if(busWidth == 0)
    {
        dbgInfoEx("[%s]get busWidth is zero ! busWidth = 1\n",__FUNCTION__);
        busWidth = 1;
    }
    phyAddr = socaddr + addr*busWidth;

    offsetAddr = (phyAddr - blkBaseAddr)/busWidth;
    dbgInfoEx("blkNo = %d blkBaseAddr =0x%x offsetAddr = 0x%x\n", blkNo, blkBaseAddr,offsetAddr);
    ret = BspRegDomainRd(chipId, blkNo, offsetAddr, &readData);
    dbgInfoEx("readData(phyaddr:0x%x offsetAddr:0x%x) = 0x%08x\n", phyAddr,addr,readData);

    *data = readData;
    return ret;
}

/*****************************************************************************
*  函数名称   : BspSetRegLocalBus
*  功能描述   : 寄存器读写接口
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : usAddr---地址
*  输出参数   : 无
*  返 回 值   : BSP_OK
*  其它说明   : 无
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2017-02-16 14:55:24    创建
*----------------------------------------------------------------------------
*/
static UINT32 BspSetRegLocalBus(UINT32 chipId, UINT32 addr, UINT32 data)
{    
    UINT32 blkNo        = 0;
    UINT32 blkBaseAddr  = 0;
    UINT32 offsetAddr   = 0;
    /* UINT32 readData     = 0;     */
    UINT32 socaddr      = s_uSocPhyBaseAddr;    
    UINT32 ret          = 0;   
    UINT32 phyAddr      = 0;
    UINT32 busWidth     = 0;

    dbgInfoEx("%s>>Chip'%d Addr'%d: SocAddr= 0x%08X\n", __FUNCTION__,
              chipId, addr, s_uSocPhyBaseAddr);
    ret = BspGetMemBlockFromPhyAddr(socaddr, &blkNo, &blkBaseAddr, &busWidth);
    if(BSP_OK!=ret)
    {
        dbgErr("[%s] BlockNo Get Error!\n", __FUNCTION__);
        return ret;
    }
    if(busWidth == 0)
    {
        dbgInfoEx("[%s]get busWidth is zero ! busWidth = 1\n",__FUNCTION__);
        busWidth = 1;
    }
    phyAddr = socaddr + addr*busWidth;

    offsetAddr = (phyAddr - blkBaseAddr)/busWidth;
    dbgInfoEx("blkNo = %d blkBaseAddr =0x%x offsetAddr = 0x%x\n", blkNo, blkBaseAddr,offsetAddr);
    dbgInfoEx("blkBaseAddr =0x%x offsetAddr = 0x%x phyaddr = 0x%x \n",  blkBaseAddr,offsetAddr,phyAddr);
    return BspRegDomainWr(chipId, blkNo, offsetAddr, data);
}

static UINT32 BspSetRegLocalBusMask(UINT32 chipId, UINT32 addr, UINT32 data, UINT32 mask)
{    
    UINT32 blkNo        = 0;
    UINT32 blkBaseAddr  = 0;
    UINT32 offsetAddr   = 0;
    /* UINT32 readData     = 0;     */
    UINT32 socaddr      = s_uSocPhyBaseAddr;    
    UINT32 ret          = 0;   
    UINT32 phyAddr      = 0;
    UINT32 busWidth     = 0;

    ret = BspGetMemBlockFromPhyAddr(socaddr, &blkNo, &blkBaseAddr,&busWidth);
    if(BSP_OK!=ret)
    {
        dbgInfo("can't get blk\n");
        return ret;
    }
    if(busWidth == 0)
    {
        dbgInfoEx("[%s]get busWidth is zero ! busWidth = 1\n",__FUNCTION__);
        busWidth = 1;
    }
    phyAddr = socaddr + addr*busWidth;

    offsetAddr = (phyAddr - blkBaseAddr)/busWidth;
    dbgInfoEx("blkBaseAddr =0x%x offsetAddr = 0x%x phyaddr = 0x%x \n",  blkBaseAddr,offsetAddr,phyAddr);
    return BspRegDomainWrMask(chipId, blkNo, offsetAddr, data, mask);
}


/*****************************************************************************
*  函数名称   : BspGetReg
*  功能描述   : 寄存器读写接口
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : usAddr---地址
*  输出参数   : 无
*  返 回 值   : 寄存器值
*  其它说明   : 无
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2017-02-16 14:55:24    创建
*----------------------------------------------------------------------------
*/
UINT32 BspGetReg(UINT32 regType, UINT32 chipId, UINT32 addr, UINT32 *data)
{
    UINT32 ret = BSP_OK;
   if(regType == DEV_REG_ACCESS_SPI_BUS)
   {
        ret = BspGetRegSpi(chipId, addr, data);
   }
   if((regType == DEV_REG_ACCESS_LOCAL_BUS)      ||
      (regType == DEV_REG_ACCESS_LOCAL_BUS_8BIT) ||
      (regType == DEV_REG_ACCESS_LOCAL_BUS_32BIT))
   {
        ret = BspGetRegLocalBus(chipId, addr, data);
   }
   return ret ;
}

/*****************************************************************************
*  函数名称   : BspSetReg
*  功能描述   : 寄存器读写接口
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : usAddr---地址
*  输出参数   : 无
*  返 回 值   : BSP_OK
*  其它说明   : 无
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2017-02-16 14:55:24    创建
*----------------------------------------------------------------------------
*/
VOID BspSetReg(UINT32 regType, UINT32 chipId, UINT32 addr, UINT32 data)
{
   /* UINT32 ret = BSP_OK; */
   if(regType == DEV_REG_ACCESS_SPI_BUS)
   {
        BspSetRegSpi(chipId, addr, data);
   }
   if((regType == DEV_REG_ACCESS_LOCAL_BUS)      ||
      (regType == DEV_REG_ACCESS_LOCAL_BUS_8BIT) ||
      (regType == DEV_REG_ACCESS_LOCAL_BUS_32BIT))
   {
        BspSetRegLocalBus(chipId, addr, data);
   }   
}

VOID BspSetRegMask(UINT32 regType, UINT32 chipId, UINT32 addr, UINT32 data, UINT32 mask)
{
   /* UINT32 ret = BSP_OK; */
   if(regType == DEV_REG_ACCESS_SPI_BUS)
   {
        BspSetRegSpiMask(chipId, addr, data, mask);
   }
   if((regType == DEV_REG_ACCESS_LOCAL_BUS)      ||
      (regType == DEV_REG_ACCESS_LOCAL_BUS_8BIT) ||
      (regType == DEV_REG_ACCESS_LOCAL_BUS_32BIT))
   {
        BspSetRegLocalBusMask(chipId, addr, data, mask);
   }   
}

VOID BspSetFpgaRegMask(UINT32 chipId, UINT32 addr, UINT32 val, UINT32 mask)
{
    UINT32 busType = DEV_REG_ACCESS_LOCAL_BUS;
    char  devId[8] = {0};
    TRruDeviceDescription fpgaDev = {0};
    int snpRet;

    snpRet = snprintf_s(devId,sizeof(devId),"Fpga%d",chipId);
    SNPRINTF_S_CHECK(snpRet, sizeof(devId));
    if (BSP_OK != BspDevInfoGetByDevIdName(devId, &fpgaDev))
    {
        return ;
    }
    if (strstr(fpgaDev.acBusName,"SPI"))
    {
        busType = DEV_REG_ACCESS_SPI_BUS;
    }
    if (strstr(fpgaDev.acBusName,"LOCALBUS"))
    {
        busType = DEV_REG_ACCESS_LOCAL_BUS;
    }
    
    BspSetRegMask(busType, chipId, addr, val, mask);
}


VOID BspSetFpgaReg(UINT32 chipId, UINT32 addr, UINT32 val)
{
    UINT32 busType = DEV_REG_ACCESS_LOCAL_BUS;
    char  devId[8] = {0};
    TRruDeviceDescription fpgaDev = {0};
    int snpRet;

    snpRet = snprintf_s(devId,sizeof(devId),"Fpga%d",chipId);
    SNPRINTF_S_CHECK(snpRet, sizeof(devId));
    if (BSP_OK != BspDevInfoGetByDevIdName(devId, &fpgaDev))
    {
        return ;
    }
    if (strstr(fpgaDev.acBusName,"SPI"))
    {
        busType = DEV_REG_ACCESS_SPI_BUS;
    }
    if (strstr(fpgaDev.acBusName,"LOCALBUS"))
    {
        busType = DEV_REG_ACCESS_LOCAL_BUS;
    }

    BspSetReg(busType, chipId, addr, val);
}

UINT32 BspGetFpgaReg(UINT32 chipId, UINT32 addr)
{
    UINT32 ret;
    UINT32 busType = DEV_REG_ACCESS_LOCAL_BUS;
    char  devId[8] = {0};
    TRruDeviceDescription fpgaDev = {0};
    UINT32 data;
    int snpRet;

    snpRet = snprintf_s(devId,sizeof(devId),"Fpga%d",chipId);
    SNPRINTF_S_CHECK(snpRet, sizeof(devId));
    if (BSP_OK != BspDevInfoGetByDevIdName(devId, &fpgaDev))
    {
        return BSP_ERROR;
    }
    if (strstr(fpgaDev.acBusName,"SPI"))
    {
        busType = DEV_REG_ACCESS_SPI_BUS;
    }
    if (strstr(fpgaDev.acBusName,"LOCALBUS"))
    {
        busType = DEV_REG_ACCESS_LOCAL_BUS;
    }

    ret = BspGetReg(busType, chipId, addr, &data);
    if (ret != BSP_OK)
    {
        return BSP_ERROR;
    }
    
    return data;
}

VOID BspSetEpldRegMask(UINT32 addr, UINT32 val, UINT32 mask)
{
    UINT32 epldId       = 0;
    UINT32 epldBusType  = 0;
    /*SpiGetFpgaIdByName("Epld0", &epldId, &epldBusType);  */
    if (BSP_OK != SpiGetFpgaIdByName("Epld0", &epldId, &epldBusType))
    {
        dbgErr("get epldId failed\n");
        epldBusType = 0;
        epldId      = 0;
        return ;
    }
    BspSetSocPhyBaseAddr(0,s_uEpldPhyBaseAddr);
    BspSetRegMask(epldBusType,epldId, addr, val, mask);
}


VOID BspSetEpldReg(UINT32 addr, UINT32 val)
{
    UINT32 epldId       = 0;
    UINT32 epldBusType  = 0;

    /*SpiGetFpgaIdByName("Epld0", &epldId, &epldBusType); */
    if (BSP_OK != SpiGetFpgaIdByName("Epld0", &epldId, &epldBusType))
    {
        dbgErr("get epldId failed\n");
        epldBusType = 0;
        epldId      = 0;
        return ;
    }

    BspSetSocPhyBaseAddr(0,s_uEpldPhyBaseAddr);
    BspSetReg(epldBusType,epldId, addr, val);
}

UINT32 BspGetEpldReg(UINT32 addr)
{
    UINT32 epldId       = 0;
    UINT32 epldBusType  = 0;
    UINT32 epldVal      = 0;
    /*SpiGetFpgaIdByName("Epld0", &epldId, &epldBusType); */
    if (BSP_OK != SpiGetFpgaIdByName("Epld0", &epldId, &epldBusType))
    {
        dbgErr("get epldId failed\n");
        epldBusType = 0;
        epldId      = 0;
        return BSP_ERROR;
    }

    BspSetSocPhyBaseAddr(0,s_uEpldPhyBaseAddr);
    BspGetReg(epldBusType, epldId, addr, &epldVal);
    return epldVal;
}


VOID wrepld(UINT32 addr,UINT32 val)
{
    BspSetEpldReg(addr, val);
}

VOID rdepld(UINT32 addr,UINT32 len)
{
    static UINT32 defaultNum    =   128; 
    UINT32 loop     = 0;
    UINT32 data     = 0;
    UINT32 delta    = 0;
    UINT32 start    = 0;

    len = (len) ? len : defaultNum;
    defaultNum = len;

    delta = addr & 0x7;
    start = addr - delta;
    len  += delta;
    dbgInfo("\n      =+0= =+1= =+2= =+3= =+4= =+5= =+6= =+7=\n");
    
    for (loop = 0; loop < len; loop++)
    {
        if (!((loop*2)&0xF))
        {
            dbgInfo("\n%04X: ", start+loop);
        }
        if (start+loop < addr)
        {
            dbgInfo("     ");
        }
        else
        {
            data = BspGetEpldReg(start+loop);
            dbgInfo("%04X ", data);
        }
    }
    dbgInfo("\n");
}


VOID wrfpga(UINT32 chip,UINT32 addr,UINT32 val)
{
    BspSetFpgaReg(chip,addr,val);
}

static UINT32 RdFpgaForSpiBus(UINT32 chip,UINT32 addr,UINT32 len)
{
    static UINT16 defaultNum    =   128; 
    UINT32 loop     = 0;
    UINT32 data     = 0;
    UINT32 delta    = 0;
    UINT32 start    = 0;
    UINT32 ulRet    = BSP_OK;

    len = (len) ? len : defaultNum;
    defaultNum = len;

    delta = addr & 0x7;
    start = addr - delta;
    len  += delta;
    RedirPrintf("\n      =+0= =+1= =+2= =+3= =+4= =+5= =+6= =+7=\n");
    dtsLog("\n      =+0= =+1= =+2= =+3= =+4= =+5= =+6= =+7=\n");
    
    for (loop = 0; loop < len; loop++)
    {
        if (!((loop*2)&0xF))
        {
            RedirPrintf("\n%04X: ", start+loop);
            dtsLog("\n%04X: ", start+loop);
        }
        if (start+loop < addr)
        {
            RedirPrintf("     ");
            dtsLog("     ");
        }
        else
        {
            data = BspGetFpgaReg(chip,start+loop);
            RedirPrintf("%04X ", data);
            dtsLog("%04X ", data);
        }
    }
    RedirPrintf("\n");
    dtsLog("\n");
    return ulRet;
}


static UINT32 RdFpgaForLocalBus(UINT32 chip,UINT32 addr,UINT32 len)
{
    UINT32 ret          = BSP_OK;
    UINT32 readData     = 0;
    UINT32 loop         = 0;

    len = (len) ? len : 1;
    for (loop = 0; loop < len; loop++)
    {
        readData = BspGetFpgaReg(chip,addr+loop);
        RedirPrintf("readData(offsetAddr:0x%x) = 0x%08x\n", addr+loop ,readData);
        dtsLog("readData(offsetAddr:0x%x) = 0x%08x\n", addr+loop ,readData);
    }

    return ret;
}



UINT32 rdfpga(UINT32 chip,UINT32 addr,UINT32 len)
{
    UINT32 ret = BSP_OK;    
    char  devId[8] = {0};
    TRruDeviceDescription fpgaDev = {0};
    int snpRet = 0;

    snpRet = snprintf_s(devId,sizeof(devId),"Fpga%d",chip);
    SNPRINTF_S_CHECK(snpRet, sizeof(devId));
    dtsLogEx("%s %d,0x%x,%d\n",__FUNCTION__,chip,addr,len);
    if (BSP_OK != BspDevInfoGetByDevIdName(devId, &fpgaDev))
    {
        return BSP_ERROR;
    }
    
    if (strstr(fpgaDev.acBusName,"SPI"))
    {        
        ret = RdFpgaForSpiBus(chip,addr,len);
    }
    else if (strstr(fpgaDev.acBusName,"LOCALBUS"))
    {
        ret = RdFpgaForLocalBus(chip,addr,len);
    }
    
    return ret;
}

VOID rdifc(UINT32 chip,UINT32 addr,UINT32 len)
{
    static UINT16 defaultNum    =   128;
    UINT32 loop     = 0;
    UINT32 data     = 0;
    UINT32 delta    = 0;
    UINT32 start    = 0;

    len = (len) ? len : defaultNum;
    defaultNum = len;

    delta = addr & 0x7;
    start = addr - delta;
    len  += delta;
    dbgInfo("\n      =+0= =+1= =+2= =+3= =+4= =+5= =+6= =+7=\n");

    for (loop = 0; loop < len; loop++)
    {
        if (!((loop*2)&0xF))
        {
            dbgInfo("\n%04X: ", start+loop);
        }
        if (start+loop < addr)
        {
            dbgInfo("     ");
        }
        else
        {
            //data = BspGetEpldReg(start+loop);
            BspSetSocPhyBaseAddr(0,s_uIfcPhyBaseAddr);
            BspGetRegLocalBus(chip, start+loop, &data);
            dbgInfo("%04X ", data);
        }
    }
    dbgInfo("\n");
}
VOID wrifc(UINT32 chip,UINT32 addr,UINT32 val)
{
    BspSetSocPhyBaseAddr(0,s_uIfcPhyBaseAddr);
    BspSetRegLocalBus(chip, addr, val);
}



/*****************************************************************************
 * 版权所有(C) 2014, ZTE Corp. ZXSDR-RRU Platform BSP
 *----------------------------------------------------------------------------
 * 模 块 名 : BSP
 * 文件名称 : regdrv_pincfg.c
 * 文件标识 : {[N/A]}
 * 内容摘要 : 本文件主要提供寄存器单bit 用于管脚配置的实现。
 * 注意事项 : 无
 * 作    者 : 王飞
 * 创建日期 : 2017-02-05 10:28:34
 * 当前版本 : Ver1.0
 *----------------------------------------------------------------------------
 * 变更记录 :
 *
 * $记录1
 * 变 更 单:
 * 责 任 人:
 * 修改日戳:
 * 变更说明:

 *----------------------------------------------------------------------------
 */
#include "regdrv_pincfg.h"
#include "regdrv_access.h"
/**************************************************************************
 *                        宏定义
 **************************************************************************/
 
/**************************************************************************
*                         数据类型                                       *
**************************************************************************/
static UINT32 s_ulPinDirInversInitFlag = 0;

static T_Reg_Drv_Tbl s_regDrvTbl = {0};

/**************************************************************************
*                         全局变量定义                                   *
**************************************************************************/

/**************************************************************************
 *                         函数实现
 **************************************************************************/

T_PRE_REG_INIT  g_atPreInitFunc[DEV_REG_ACCESS_TYPE_MAX];
/**************************************************************************
* 函数名称: BspRegDrvWr_Spi
* 功能描述: spi 管脚寄存器写操作
* 输入参数: chipIdx         :芯片id
*         : addr            :寄存器地址
*         : bit             :寄存器操作bit
*         : val             :寄存器值
* 输出参数: 无
* 返 回 值: BSP_OK /BSP_ERROR
* 其它说明:
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2017-02-16 14:55:24    创建
*----------------------------------------------------------------------------
*/
static UINT32 BspRegDrvWr_Spi(UINT32 chipIdx,UINT32 addr, UINT32 bit, UINT32 val)
{
    UINT32 mask    = 1  << bit;
	UINT32 regVal  = val<< bit;
    T_Reg_Drv_Access *pRegAcessSpi = NULL; 
    pRegAcessSpi = BspGetRegAccess(DEV_REG_ACCESS_SPI_BUS);
	if(NULL != pRegAcessSpi->pWrMask)
	{
		pRegAcessSpi->pWrMask(chipIdx,addr,regVal,mask);
	}
	return BSP_OK;
}
/**************************************************************************
* 函数名称: BspRegDrvRd_Spi
* 功能描述: spi 管脚寄存器读操作
* 输入参数: chipIdx         :芯片id
*         : addr            :寄存器地址
*         : bit             :寄存器操作bit
* 输出参数: pVal            :读取bit数据
* 返 回 值: BSP_OK /BSP_ERROR
* 其它说明:
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2017-02-16 14:55:24    创建
*----------------------------------------------------------------------------
*/
static UINT32 BspRegDrvRd_Spi(UINT32 chipIdx,UINT32 addr, UINT32 bit, UINT32 *pVal)
{
    UINT32 regVal = 0;
    T_Reg_Drv_Access *pRegAcessSpi = NULL; 
    INPUT_POINTER_CHECK(pVal);
    pRegAcessSpi = BspGetRegAccess(DEV_REG_ACCESS_SPI_BUS);
	if(NULL != pRegAcessSpi->pRegRd)
	{        
		pRegAcessSpi->pRegRd(chipIdx,addr,&regVal);
	}
    *pVal = (regVal>>bit)&0x1;
	return BSP_OK;
}
/*****************************************************************************
*  函数名称   : BspGetDrvRegLocalBus
*  功能描述   : 寄存器读写接口
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : usAddr---地址
*  输出参数   : 无
*  返 回 值   : 寄存器值
*  其它说明   : 无
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2017-02-16 14:55:24    创建
*----------------------------------------------------------------------------
*/

static UINT32 BspGetDrvRegLocalBus(UINT32 chipId, UINT32 addr,UINT32 *data)
{
    UINT32 ret          = BSP_OK;
    UINT32 blkNo        = 0;
    UINT32 blkBaseAddr  = 0;
    UINT32 offsetAddr   = 0;    
    UINT32 busWidth     = 0;
    INPUT_POINTER_CHECK(data);
    ret |=BspGetMemBlockFromPhyAddr(addr,&blkNo, &blkBaseAddr,&busWidth);
    if(BSP_OK!=ret)
    {
        dbgInfo("can't get blk\n");
        return ret;
    }
    if(busWidth == 0)
    {
        dbgInfo("[%s]get busWidth is zero ! busWidth = 1\n",__FUNCTION__);
        busWidth = 1;
    }
    offsetAddr = (addr - blkBaseAddr)/busWidth;       
    dbgInfoEx("blkNo = %d blkBaseAddr =0x%x offsetAddr = 0x%x\n", blkNo, blkBaseAddr,offsetAddr);
    ret |= BspRegDomainRd(chipId, blkNo, offsetAddr, data);
    
    dbgInfoEx("readData(addr:0x%x) = 0x%08x\n", addr , *data);
    return ret;
    
}
/*****************************************************************************
*  函数名称   : BspSetDrvRegLocalBus
*  功能描述   : 寄存器读写接口
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : usAddr---地址
*  输出参数   : 无
*  返 回 值   : BSP_OK
*  其它说明   : 无
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2017-02-16 14:55:24    创建
*----------------------------------------------------------------------------
*/

static UINT32 BspSetDrvRegLocalBus(UINT32 chipId, UINT32 addr, UINT32 value,UINT32 mask)
{    
    UINT32 blkNo        = 0;
    UINT32 blkBaseAddr  = 0;
    UINT32 offsetAddr   = 0;    
    /* UINT32 loop         = 0;       */
    UINT32 ret          = 0;        
    UINT32 busWidth     = 0;
     
    ret |=BspGetMemBlockFromPhyAddr(addr,&blkNo, &blkBaseAddr,&busWidth);
    if(BSP_OK!=ret)
    {
        dbgInfo("can't get blk\n");
        return ret;
    }
    if(busWidth == 0)
    {
        dbgInfo("[%s]get busWidth is zero ! busWidth = 1\n",__FUNCTION__);
        busWidth = 1;
    }
    offsetAddr = (addr  - blkBaseAddr)/busWidth;
    dbgInfoEx("blkBaseAddr =0x%x offsetAddr = 0x%x phyaddr = 0x%x \n",  blkBaseAddr,offsetAddr,addr);
    return BspRegDomainWrMask(chipId, blkNo, offsetAddr, value,mask);
}

/**************************************************************************
* 函数名称: BspRegDrvWr_LocalBus
* 功能描述: localbus 管脚寄存器写操作
* 输入参数: chipIdx         :芯片id
*         : addr            :寄存器地址
*         : bit             :寄存器操作bit
*         : val             :寄存器值
* 输出参数: 无
* 返 回 值: BSP_OK /BSP_ERROR
* 其它说明:
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2017-02-16 14:55:24    创建
*----------------------------------------------------------------------------
*/
static UINT32 BspRegDrvWr_LocalBus(UINT32 chipIdx,UINT32 addr, UINT32 bit, UINT32 val)
{
    UINT32 mask      = 1  << bit;
	UINT32 regVal    = val<< bit;
    UINT32 ret       = BSP_OK;
    dbgInfoEx("addr = 0x%x bit = 0x%x val = 0x%x\n",addr, bit, regVal);
    ret = BspSetDrvRegLocalBus(chipIdx, addr,regVal,mask);
	return ret;
}
/**************************************************************************
* 函数名称: BspRegDrvRd_LocalBus
* 功能描述: localbus管脚寄存器读操作
* 输入参数: chipIdx         :芯片id
*         : addr            :寄存器地址
*         : bit             :寄存器操作bit
* 输出参数: pVal            :读取bit数据
* 返 回 值: BSP_OK /BSP_ERROR
* 其它说明:
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2017-02-16 14:55:24    创建
*----------------------------------------------------------------------------
*/
static UINT32 BspRegDrvRd_LocalBus(UINT32 chipIdx,UINT32 addr, UINT32 bit ,UINT32 *pVal)
{
    UINT32 readVal = 0;
    UINT32 retVal  = BSP_OK;
    /* T_Reg_Drv_Access *pRegAcessLocalBus = NULL; */ 
    INPUT_POINTER_CHECK(pVal);
    retVal = BspGetDrvRegLocalBus(chipIdx, addr, &readVal);
    *pVal = (readVal>>bit)&0x1;
	return retVal;
}



/**************************************************************************
* 函数名称: BspRegDrvWr_Gpio
* 功能描述: GPIO 管脚寄存器写操作
* 输入参数: chipIdx         :芯片id
*         : addr            :寄存器地址
*         : bit             :寄存器操作bit
*         : val             :寄存器值
* 输出参数: 无
* 返 回 值: BSP_OK /BSP_ERROR
* 其它说明: GPIO 属于CPU管脚，所有芯片数为1,在这里不传入芯片号,为了兼容架构,
*         : 函数入参需要带芯片号,函数内部不使用
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2017-02-16 14:55:24    创建
*----------------------------------------------------------------------------
*/
static UINT32 BspRegDrvWr_Gpio(UINT32 chipIdx,UINT32 addr, UINT32 bit, UINT32 val)
{    
    T_Reg_Drv_Access *pRegAcessGpio = NULL; 
    pRegAcessGpio = BspGetRegAccess(DEV_REG_ACCESS_GPIO);
	if(NULL != pRegAcessGpio->pRegWr)
	{
		pRegAcessGpio->pRegWr(addr,bit,val);
	}
	return BSP_OK;
}
/**************************************************************************
* 函数名称: BspRegDrvDir_Gpio
* 功能描述: GPIO 管脚寄存器设置方向操作
* 输入参数: chipIdx         :芯片id
*         : addr            :寄存器地址
*         : bit             :寄存器操作bit
*         : val             :寄存器值
* 输出参数: 无
* 返 回 值: BSP_OK /BSP_ERROR
* 其它说明: GPIO 属于CPU管脚，所有芯片数为1,在这里不传入芯片号,为了兼容架构,
*         : 函数入参需要带芯片号,函数内部不使用
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2017-02-16 14:55:24    创建
*----------------------------------------------------------------------------
*/
static UINT32 BspRegDrvDir_Gpio(UINT32 chipIdx,UINT32 addr, UINT32 bit, UINT32 val)
{    
    T_Reg_Drv_Access *pRegAcessGpio = NULL; 
    pRegAcessGpio = BspGetRegAccess(DEV_REG_ACCESS_GPIO);
	if(NULL != pRegAcessGpio->pWrDir)
	{
		pRegAcessGpio->pWrDir(addr,bit,val);
	}
	return BSP_OK;
}
/**************************************************************************
* 函数名称: BspRegDrvRd_Gpio
* 功能描述: GPIO 管脚寄存器读操作
* 输入参数: chipIdx         :芯片id
*         : addr            :寄存器地址
*         : bit             :寄存器操作bit
* 输出参数: pVal            :读取bit数据
* 返 回 值: BSP_OK /BSP_ERROR
* 其它说明:
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2017-02-16 14:55:24    创建
*----------------------------------------------------------------------------
*/
static UINT32 BspRegDrvRd_Gpio(UINT32 chipIdx,UINT32 addr, UINT32 bit,UINT32 *pVal)
{
    /* UINT32 regVal = BSP_OK; */
    T_Reg_Drv_Access *pRegAcessGpio = NULL; 
    INPUT_POINTER_CHECK(pVal);
    pRegAcessGpio = BspGetRegAccess(DEV_REG_ACCESS_GPIO);
	if(NULL != pRegAcessGpio->pRegRd)
	{
        pRegAcessGpio->pRegRd(addr,bit,pVal);
	}
    return BSP_OK;
}
static T_Reg_Drv_Cfg  s_regDrvPin[DEV_REG_ACCESS_TYPE_MAX] =
{
    [DEV_REG_ACCESS_SPI_BUS] =
    {
        .pFuncPinSet    = BspRegDrvWr_Spi,
        .pFuncPinDirSet = BspRegDrvWr_Spi,
        .pFuncPinGet    = BspRegDrvRd_Spi,
	},
    [DEV_REG_ACCESS_LOCAL_BUS] =
    {
        .pFuncPinSet    = BspRegDrvWr_LocalBus,
        .pFuncPinDirSet = BspRegDrvWr_LocalBus,
        .pFuncPinGet    = BspRegDrvRd_LocalBus,
	},
    [DEV_REG_ACCESS_GPIO] =
    {
        .pFuncPinSet    = BspRegDrvWr_Gpio,
        .pFuncPinDirSet = BspRegDrvDir_Gpio,
        .pFuncPinGet    = BspRegDrvRd_Gpio,
	},
    [DEV_REG_ACCESS_LOCAL_BUS_8BIT] =
    {
        .pFuncPinSet    = BspRegDrvWr_LocalBus,
        .pFuncPinDirSet = BspRegDrvWr_LocalBus,
        .pFuncPinGet    = BspRegDrvRd_LocalBus,
	},
};

UINT32 BspSetPinDirInversFlag(UINT32 ulInversFlag)
{
    s_ulPinDirInversInitFlag = ulInversFlag;

	return BSP_OK;
}

/**************************************************************************
* 函数名称: BspSetRegDrvData
* 功能描述: 配置寄存器管脚信息表
* 输入参数: pRegTbl         :寄存器信息表
*         : regTblNum       :表个数
* 输出参数: 无           
* 返 回 值: BSP_OK /BSP_ERROR
* 其它说明:
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2017-02-16 14:55:24    创建
*----------------------------------------------------------------------------
*/
UINT32 BspSetRegDrvData(_T_Reg_Drv_Tbl * pRegTbl, UINT32 regTblNum)
{
    s_regDrvTbl.pTRegTbl = pRegTbl;
	s_regDrvTbl.num      = regTblNum;
	return BSP_OK;
}
/**************************************************************************
* 函数名称: BspGetRegDrvPin
* 功能描述: 
* 输入参数: idx       
*         : 无
* 输出参数: 无           
* 返 回 值: BSP_OK /BSP_ERROR
* 其它说明:
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2017-02-16 14:55:24    创建
*----------------------------------------------------------------------------
*/
T_Reg_Drv_Cfg* BspGetRegDrvPin(UINT32 idx)
{
    if(idx>=DEV_REG_ACCESS_TYPE_MAX)
    {
        return NULL;
	}
	return &(s_regDrvPin[idx]);
}
/**************************************************************************
* 函数名称: BspRegPinWr
* 功能描述: pin管脚寄存器写操作
* 输入参数: regPinIdx       :寄存器pin 管脚idx号
*         : val             :寄存器val
* 输出参数: 无
* 返 回 值: BSP_OK /BSP_ERROR
* 其它说明:
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2017-02-16 14:55:24    创建
*----------------------------------------------------------------------------
*/
UINT32 BspRegPinWr(UINT32 regPinIdx, UINT32 val)
{
    UINT32 regType = 0;
    UINT32 addr    = 0;
    UINT32 bit     = 0;
    UINT32 chipIdx = 0;
    if((NULL != s_regDrvTbl.pTRegTbl)&&(regPinIdx<s_regDrvTbl.num))
    {
        regType = s_regDrvTbl.pTRegTbl[regPinIdx].regType;
        chipIdx = s_regDrvTbl.pTRegTbl[regPinIdx].chipIdx;
        if((regType > DEV_REG_ACCESS_TYPE_MIN)&&(regType < DEV_REG_ACCESS_TYPE_MAX))
        {
            addr = s_regDrvTbl.pTRegTbl[regPinIdx].regAddr;
            bit  = s_regDrvTbl.pTRegTbl[regPinIdx].bitNum;
            if(NULL != s_regDrvPin[regType].pFuncPinSet)
            {
                if (REG_PIN_TYPE_OUTPUT_INVERS&((s_regDrvTbl.pTRegTbl[regPinIdx].defVal>>REG_PIN_VAL_BIT_INVERS_STATE)&REG_PIN_DEF_VAL_MASK))
                {
                    val = ((val==1)?0:1);
                }
                dbgInfoEx("%s>> chipIdx:%d,addr:%#x,bit:%d,val:%d\r\n",__func__,chipIdx,addr,bit,val);
                s_regDrvPin[regType].pFuncPinSet(chipIdx,addr,bit,val);
            }
        }
    }
    return BSP_OK;
}

/**************************************************************************
* 函数名称: BspRegPinRd
* 功能描述: pin管脚寄存器读操作
* 输入参数: regPinIdx       :寄存器pin 管脚id
*         : 
* 输出参数: 无
* 返 回 值: val 寄存器读取bit 数据
* 其它说明:
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2017-02-16 14:55:24    创建
*----------------------------------------------------------------------------
*/
UINT32 BspRegPinRd(UINT32 regPinIdx)
{
	UINT32 regType   = 0;
	UINT32 addr	    = 0;
	UINT32 bit 	    = 0;
	UINT32 regVal    = 0;
    UINT32 chipIdx   = 0;
	if((NULL != s_regDrvTbl.pTRegTbl)&&(regPinIdx<s_regDrvTbl.num))
	{
		regType = s_regDrvTbl.pTRegTbl[regPinIdx].regType;
        chipIdx = s_regDrvTbl.pTRegTbl[regPinIdx].chipIdx;
		if((regType > DEV_REG_ACCESS_TYPE_MIN) && (regType < DEV_REG_ACCESS_TYPE_MAX))
		{
			addr = s_regDrvTbl.pTRegTbl[regPinIdx].regAddr;
			bit  = s_regDrvTbl.pTRegTbl[regPinIdx].bitNum;
			if(NULL != s_regDrvPin[regType].pFuncPinGet)
			{
				s_regDrvPin[regType].pFuncPinGet(chipIdx,addr,bit,&regVal);
				if (REG_PIN_TYPE_INPUT_INVERS&((s_regDrvTbl.pTRegTbl[regPinIdx].defVal>>REG_PIN_VAL_BIT_INVERS_STATE)&REG_PIN_DEF_VAL_MASK))
				{
					regVal = ((regVal==1)?0:1);
				}
			}
		}
	}
	return regVal;
}


/**************************************************************************
* 函数名称: BspRegPinSetDir
* 功能描述: pin管脚寄存器方向设置
* 输入参数: regPinIdx       :寄存器pin 管脚idx号
*         : val             :寄存器val
* 输出参数: 无
* 返 回 值: BSP_OK /BSP_ERROR
* 其它说明:
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2017-02-16 14:55:24    创建
*----------------------------------------------------------------------------
*/
UINT32 BspRegPinSetDir(UINT32 regPinIdx, UINT32 val)
{
    UINT32 regType = 0;
    UINT32 addr    = 0;
    UINT32 bit     = 0;
    UINT32 chipIdx = 0;
    if((NULL != s_regDrvTbl.pTRegTbl)&&(regPinIdx<s_regDrvTbl.num))
    {
        regType = s_regDrvTbl.pTRegTbl[regPinIdx].regType;
        chipIdx = s_regDrvTbl.pTRegTbl[regPinIdx].chipIdx;
        if((regType>DEV_REG_ACCESS_TYPE_MIN)&&(regType<DEV_REG_ACCESS_TYPE_MAX))
        {
            addr = s_regDrvTbl.pTRegTbl[regPinIdx].regAddr;
            bit  = s_regDrvTbl.pTRegTbl[regPinIdx].bitNum;
            if(NULL != s_regDrvPin[regType].pFuncPinDirSet)
            {
                if (REG_PIN_TYPE_DIR_INVERS &((s_regDrvTbl.pTRegTbl[regPinIdx].defVal>>REG_PIN_VAL_BIT_INVERS_STATE)&REG_PIN_DEF_VAL_MASK))
                {
                    val = ((val==1)?0:1);
                }
                s_regDrvPin[regType].pFuncPinDirSet(chipIdx,addr,bit,val);
            //  dbgInfo("%s>>Chip'%d Addr'%d Bit'%d Dir(0:in 1:out)'%d: DefCfg= 0x%04X\n",
            //          __FUNCTION__, chipIdx, addr, bit, val,
            //          s_regDrvTbl.pTRegTbl[regPinIdx].defVal);
            }
        }
    }
    return BSP_OK;
}
/**************************************************************************
* 函数名称: BspCpuGpioInit
* 功能描述: BspCpuGpioInit
* 输入参数: 
*         : 
* 输出参数: 无
* 返 回 值: BSP_OK /BSP_ERROR
* 其它说明:
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2017-02-16 14:55:24    创建
*----------------------------------------------------------------------------
*/
UINT32 BspCpuGpioInit(VOID)
{
	UINT32 ulRetVal = BSP_OK;
    const char   *pcInitStr = "NULL";
    static UINT32 initSta = 0xFF;
    
    if (initSta == 0xFF)
    {
        initSta = 0;
        if (g_atPreInitFunc[DEV_REG_ACCESS_GPIO].pPinInit != NULL)
        {
            pcInitStr = "Start";
            ulRetVal = g_atPreInitFunc[DEV_REG_ACCESS_GPIO].pPinInit();
        }
        else
        {           
            pcInitStr = "Error";
        //  ulRetVal = BSP_ERROR;
        }
    }
    else
    {
        pcInitStr = "Already";
    //  printf("BspCpuGpioInit Init already!\n");
    }
    
    dbgInfo("%s>>Zxw11200Gpio PinInit %s!\n", __FUNCTION__, pcInitStr);
    return ulRetVal;
}

/**************************************************************************
* 函数名称: BspRegDrvPinInit
* 功能描述: pin管脚寄存器初始化
* 输入参数: 无
* 输出参数: 无
* 返 回 值: BSP_OK /BSP_ERROR
* 其它说明:
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2017-02-16 14:55:24    创建
*----------------------------------------------------------------------------
*/
UINT32 BspRegDrvPinInit()
{
    UINT32 regLoop = 0;
    UINT32 regDir  = 0;
    UINT32 regVal  = 0;
    /* UINT32 regChipIdx = 0; */

  /*  for(ulLoop = DEV_REG_ACCESS_TYPE_MIN+1; ulLoop < DEV_REG_ACCESS_TYPE_MAX; ulLoop++)
    {
        if(NULL != g_atPreInitFunc[ulLoop].pPinInit)
        {
            g_atPreInitFunc[ulLoop].pPinInit();
        }
    }*/
    regVal |= BspCpuGpioInit();
    
    for(regLoop = 0; regLoop < s_regDrvTbl.num; regLoop++)
    {
	    regDir = s_regDrvTbl.pTRegTbl[regLoop].defVal&REG_PIN_DEF_VAL_MASK;
	    regVal = (s_regDrvTbl.pTRegTbl[regLoop].defVal>>REG_PIN_DEF_VAL_BIT)&(REG_PIN_DEF_VAL_MASK);
        if(regVal != REG_PIN_TYPE_OUTPUT_DEF  )
        {
            if(regVal == REG_PIN_TYPE_OUTPUT_LOW)
            {
                regVal = 0;
            }
            else
            {
                regVal = 1;
            }
            BspRegPinWr(regLoop,regVal);
        }
        if(regDir != REG_PIN_TYPE_DEF)
        {
            if(((UINT32)0) == s_ulPinDirInversInitFlag)
            {
                if(regDir == REG_PIN_TYPE_OUTPUT)
                {
                    regDir = 0;
                }
                else
                {
                    regDir = 1;
                }
            }
            else
            {
                if(regDir == REG_PIN_TYPE_OUTPUT)
                {
                    regDir = 1;
                }
                else
                {
                    regDir = 0;
                }
            }
        
            BspRegPinSetDir(regLoop,regDir);
        }
    }
    return BSP_OK;
}


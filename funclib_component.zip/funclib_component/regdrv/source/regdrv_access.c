/*****************************************************************************
 * 版权所有(C) 2014, ZTE Corp. ZXSDR-RRU Platform BSP
 *----------------------------------------------------------------------------
 * 模 块 名 : BSP
 * 文件名称 : regdrv_access.c
 * 文件标识 : {[N/A]}
 * 内容摘要 : 本文件主要提供寄存器访问的具体实现模块
 * 注意事项 : 无
 * 作    者 : 王飞
 * 创建日期 : 2017-02-05 10:28:34
 * 当前版本 : Ver1.0
 *----------------------------------------------------------------------------
 * 变更记录 :
 *
 * $记录1
 * 变 更 单:
 * 责 任 人:
 * 修改日戳:
 * 变更说明:

 *----------------------------------------------------------------------------
 */
#include <string.h>
#include "regdrv_access.h"
#include "spibus_common.h"
#include "bspcommon.h"

/**************************************************************************
 *                        宏定义
 **************************************************************************/
#define LOCAL_BUS_32BIT_REG_RW_WAIT_CNT             2000

#define DDR_SHARE_REG_LOCAL_RW_FLAG                 BIT_SET(31)
#define DDR_SHARE_REG_REMOTE_RW_FLAG                BIT_SET(30)
#define DDR_SHARE_REG_LOCAL_IDLE_STATUS             BIT_SET(29)
#define DDR_SHARE_REG_REMOTE_IDLE_STATUS            BIT_SET(28)

#define REG_TBL_CHECK()                             \
    if (NULL == s_pRegAddrTbl)                      \
    {                                               \
        dbgErr("%s>>Error! pRegAddrTbl Is Null!\n", \
               __FUNCTION__);                       \
        return BSP_ERROR;                           \
    }

/**************************************************************************
*                         数据类型                                       *
**************************************************************************/

/**************************************************************************
*                         全局变量定义                                   *
**************************************************************************/
static T_Reg_Drv_Access s_regAccess[DEV_REG_ACCESS_TYPE_MAX]={{0,},};
static T_Reg_Tbl  *s_pRegAddrTbl     = NULL;
static UINT32  s_RegNum     = 0;
static T_Reg_Head *s_pRegHeadTbl     = NULL;
static UINT32       s_regHeadTblNum   = 0;

static SEM_ID s_localBusSem  = NULL;
// static UINT32 s_aulMcsDdrRegAccessFlag[4] = {0, 0, 0, 0};

/**************************************************************************
 *                         函数实现
 **************************************************************************/
#if (0)
UINT32 BspSetDdrRegAccessFlag(UINT32 ulChipIdx, UINT32 ulCfgOrClr, UINT32 ulAccessMask)
{
	UINT32 ulFunRet = BSP_OK;

    if (0 == ulCfgOrClr)
    {
        s_aulMcsDdrRegAccessFlag[ulChipIdx % 4] |= ulAccessMask;
    }
    else
    {
        s_aulMcsDdrRegAccessFlag[ulChipIdx % 4] &= ~ulAccessMask;
    }
    dbgInfo("%s>>Chip'%d Mode(0:Cfg 1:Clr)'%d RegAccessMaskFlag= 0x%08X\n",
            __FUNCTION__, ulChipIdx, ulCfgOrClr, ulAccessMask);

    return ulFunRet;
}

UINT32 BspGetDdrRegAccessFlag(UINT32 ulChipIdx)
{
	UINT32 ulAccessFlag = 0;

    ulAccessFlag = s_aulMcsDdrRegAccessFlag[ulChipIdx % 4];
    return ulAccessFlag;
}

UINT32 BspGetDdrRegRwCtrlMask(UINT32 ulChipIdx, UINT32 *pulAccessFlag, UINT32 *pulMask)
{
    UINT32 ulSetMaskRet = 0;
    UINT32 ulAccessFlag = 0;
    UINT32 ulFunRet = BSP_OK;

    ulAccessFlag = BspGetDdrRegAccessFlag(ulChipIdx);
    if (0 == (ulAccessFlag & DDR_REG_MCS_LOAD_WORK_FLAG))
    {
        ulFunRet = BSP_ERROR;
        dbgErr("%s>>Error! Chip'%d McsVer Not Work!\n", __FUNCTION__, ulChipIdx);
    }

    if (0 == (ulAccessFlag & DDR_REG_FLAG_DATA_INIT_SET))
    {
        if (0 == (ulAccessFlag & DDR_REG_FLAG_DATA_CFG_FLAG))
        {
            ulSetMaskRet = 0x0000FFFF;
        }
        else
        {
            ulSetMaskRet = 0xFFFFFFFF;
        }
    }
    else
    {
        ulSetMaskRet = 0xFFFFFFFF;
    }

    if (NULL != pulAccessFlag)
    {
        *pulAccessFlag = ulAccessFlag;
    }

    if (NULL != pulMask)
    {
        *pulMask = ulSetMaskRet;
    }

    return ulFunRet;
}
#endif

/**************************************************************************
* 函数名称: BspSetRegTblHeadData
* 功能描述:
* 输入参数: pHead:      寄存器表头信息
*         : headLen:  表长度
* 输出参数: 无
* 返 回 值: BSP_OK /BSP_ERROR
* 其它说明:
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2017-02-16 14:55:24    创建
*----------------------------------------------------------------------------
*/
UINT32 BspSetRegTblHeadData(T_Reg_Head *pHead,UINT32 headLen)
{   
    s_pRegHeadTbl       =   pHead;
    s_regHeadTblNum     =   headLen;
    return BSP_OK;
}
/**************************************************************************
* 函数名称: BspSetRegTblData
* 功能描述:
* 输入参数: pTbl   寄存器表
* 输出参数: 无
* 返 回 值: BSP_OK /BSP_ERROR
* 其它说明:
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2017-02-16 14:55:24    创建
*----------------------------------------------------------------------------
*/
UINT32 BspSetRegTblData(T_Reg_Tbl *pTbl, UINT32 num)
{
    s_pRegAddrTbl = pTbl;
    s_RegNum = num;
    return BSP_OK;
}
/**************************************************************************
* 函数名称: BspGetMapVirtAddr
* 功能描述:
* 输入参数: chipId  :芯片号
*         : ulIdx   : 寄存器序列id
* 输出参数: 无
* 返 回 值: BSP_OK /BSP_ERROR
* 其它说明:
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2017-02-16 14:55:24    创建
*----------------------------------------------------------------------------
*/
UINT32 BspGetMapVirtAddr(UINT32 chipId, UINT32 idx, unsigned long *addr)
{
    UINT32 funcDomainIdx=0;

    REG_TBL_CHECK();
    if (idx >= REG_MACRO_MAX)
    {
        dbgErr("%s>>ChipId'%d RegIdx'%d MapVirtAddr Get Error!\n",
               __FUNCTION__, chipId, idx);
        return BSP_ERROR;
    }

    if (s_pRegAddrTbl[idx].initFlag == REG_FUNC_NOT_INIT)
    {
        dbgInfoEx("%s>>Error! ChipId'%d RegIdx'%d RegTbl Not Inited!\n",
                  __FUNCTION__, chipId, idx);
        return BSP_ERROR;
    }
    funcDomainIdx = s_pRegAddrTbl[idx].regFuncDomainId;
    *addr = s_pRegHeadTbl[funcDomainIdx].virtualBaseAddr[chipId] + s_pRegAddrTbl[idx].regAddr;
    
    return BSP_OK;

}

/*****************************************************************************
*  函数名称   : BspGetReservedMemAddr(*)
*  功能描述   : 返回某个模块需要的内存保留区地址
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : ucModuleId - 0:BSP 1:OSS 6:User-define
*  输出参数   :
*  返 回 值   : 某个模块许可使用的保留区内存地址，如果模块号不存在，则返回
*               sysPhysMemTop();
*  其它说明   :
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A), chenjinsong@2010-9-15 11:15:46
*----------------------------------------------------------------------------
*/
unsigned long BspGetReservedMemAddr(UINT8 ucModuleId)
{
    unsigned long virAddr = 0;
    UINT32 retVal = BSP_OK;

    retVal = BspGetMapVirtAddr(0, ucModuleId, &virAddr);
    if (retVal != BSP_OK)
    {
        dbgInfoEx("%s>>ModuleId'%d MapVirtAddr Get Error!\n",
                  __FUNCTION__, ucModuleId);
        return BSP_ERROR;
    }
    return virAddr;
}

/*****************************************************************************
*  函数名称   : BspRegWr_LocalBus
*  功能描述   : localbus 寄存器写
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : chip      :芯片号
*             : offSet    :寄存器序列id
*             : Val       :寄存器值
*  输出参数   : 无
*  返 回 值   :BSP_OK/BSP_ERROR;
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2017-02-16 14:55:24    创建
*----------------------------------------------------------------------------
*/
static UINT32 BspRegWr_LocalBus(UINT32 chip, UINT32 offSet, UINT32 val)
{
    semTake(s_localBusSem, WAIT_FOREVER);
    uintptr_t pOffSet = (uintptr_t)offSet;
    *(T_LOACLABUS_REG*)pOffSet = (T_LOACLABUS_REG)val;
    semGive(s_localBusSem);
    return BSP_OK;
}
/*****************************************************************************
*  函数名称   : BspRegRd_LocalBus
*  功能描述   : localbus 寄存器读
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : ulChip      :芯片号
*             : ulOffset    :寄存器序列id
*  输出参数   : Val         :寄存器值
*  返 回 值   : BSP_OK/BSP_ERROR;
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2017-02-16 14:55:24    创建
*----------------------------------------------------------------------------
*/
static UINT32 BspRegRd_LocalBus(UINT32 chip, UINT32 offSet, UINT32 *pVal)
{
    semTake(s_localBusSem, WAIT_FOREVER);
    uintptr_t pOffSet = (uintptr_t)offSet;
    *pVal = (UINT32)*(T_LOACLABUS_REG*)pOffSet;
    semGive(s_localBusSem);
    return BSP_OK;
}
/*****************************************************************************
*  函数名称   : BspRegWrMask_LocalBus
*  功能描述   : localbus 寄存器掩码写
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : chip      :芯片号
*             : offSet    :寄存器序列id
*             : val       :寄存器值
*             : mask
*  输出参数   : 无
*  返 回 值   : BSP_OK/BSP_ERROR;
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), wangfei @2017-02-16 14:55:24    创建
*----------------------------------------------------------------------------
*/
static UINT32 BspRegWrMask_LocalBus(UINT32 chip, UINT32 offSet, UINT32 val, UINT32 mask)
{
    T_LOACLABUS_REG regVal  = 0;
    T_LOACLABUS_REG setVal  = (T_LOACLABUS_REG)val;
    T_LOACLABUS_REG regMask = (T_LOACLABUS_REG)mask;
    semTake(s_localBusSem, WAIT_FOREVER);
    uintptr_t pOffSet = (uintptr_t)offSet;
    regVal  = (UINT32)*(T_LOACLABUS_REG*)pOffSet;
    setVal &= regMask;
    regVal &=(~regMask);
    setVal |= regVal;
    *(T_LOACLABUS_REG*)pOffSet = setVal;
    semGive(s_localBusSem);    
    return BSP_OK;
}

/*****************************************************************************
*  函数名称   : BspRegWr_LocalBus
*  功能描述   : localbus 寄存器写
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : chip      :芯片号
*             : offSet    :寄存器序列id
*             : Val       :寄存器值
*  输出参数   : 无
*  返 回 值   :BSP_OK/BSP_ERROR;
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2017-02-16 14:55:24    创建
*----------------------------------------------------------------------------
*/
static UINT32 BspRegWr_LocalBus_8BIT(UINT32 chip, UINT32 offSet, UINT32 val)
{
    semTake(s_localBusSem, WAIT_FOREVER);
    uintptr_t pOffSet = (uintptr_t)offSet;
    *(T8_LOACLABUS_REG*)pOffSet = (T8_LOACLABUS_REG)val;
    semGive(s_localBusSem);
    return BSP_OK;
}
/*****************************************************************************
*  函数名称   : BspRegRd_LocalBus
*  功能描述   : localbus 寄存器读
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : ulChip      :芯片号
*             : ulOffset    :寄存器序列id
*  输出参数   : Val         :寄存器值
*  返 回 值   : BSP_OK/BSP_ERROR;
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2017-02-16 14:55:24    创建
*----------------------------------------------------------------------------
*/
static UINT32 BspRegRd_LocalBus_8BIT(UINT32 chip, UINT32 offSet, UINT32 *pVal)
{
    semTake(s_localBusSem, WAIT_FOREVER);
    uintptr_t pOffSet = (uintptr_t)offSet;
    *pVal = (UINT8)*(T8_LOACLABUS_REG*)pOffSet;
    semGive(s_localBusSem);
    return BSP_OK;
}
/*****************************************************************************
*  函数名称   : BspRegWrMask_LocalBus
*  功能描述   : localbus 寄存器掩码写
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : chip      :芯片号
*             : offSet    :寄存器序列id
*             : val       :寄存器值
*             : mask
*  输出参数   : 无
*  返 回 值   : BSP_OK/BSP_ERROR;
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), wangfei @2017-02-16 14:55:24    创建
*----------------------------------------------------------------------------
*/
static UINT32 BspRegWrMask_LocalBus_8BIT(UINT32 chip, UINT32 offSet, UINT32 val, UINT32 mask)
{
    T8_LOACLABUS_REG regVal  = 0;
    T8_LOACLABUS_REG setVal  = (T8_LOACLABUS_REG)val;
    T8_LOACLABUS_REG regMask = (T8_LOACLABUS_REG)mask;
    semTake(s_localBusSem, WAIT_FOREVER);
    uintptr_t pOffSet = (uintptr_t)offSet;
    regVal  = (UINT8)*(T8_LOACLABUS_REG*)pOffSet;
    setVal &= regMask;
    regVal &=(~regMask);
    setVal |= regVal;
    *(T8_LOACLABUS_REG*)pOffSet = setVal;
    semGive(s_localBusSem);
    return BSP_OK;
}

/*****************************************************************************
*  函数名称: BspRegWr_LocalBus_32BIT
*  功能描述: localbus共享内存寄存器写
*  输入参数: chip  - 芯片号
*          : offSet- 寄存器序列id
*          : val   - 寄存器值
*  输出参数: 无
*  返 回 值: BSP_OK/BSP_ERROR;
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 10119095@2019-02-30 14:55:24    创建
*----------------------------------------------------------------------------
*/
static UINT32 BspRegWr_LocalBus_32BIT(UINT32 chip, UINT32 offSet, UINT32 val)
{
    T_LOACLABUS_REG ulRegValWr = 0;
  
    semTake(s_localBusSem, WAIT_FOREVER);
    uintptr_t pOffSet = (uintptr_t)offSet;
    ulRegValWr = (T_LOACLABUS_REG)((val & 0x0000FFFF) | 0x5A000000);
    *(T_LOACLABUS_REG *)pOffSet = ulRegValWr;
    semGive(s_localBusSem);

    dbgInfoEx("%s>>Chip'%d ParaVal'0x%04X: WrReg[0x%08X]= 0x%08X\n",
              __FUNCTION__, chip, val, offSet, ulRegValWr);
    return BSP_OK;
}

/*****************************************************************************
*  函数名称: BspRegRd_LocalBus_32BIT
*  功能描述: localbus共享内存寄存器读
*  输入参数: chip  - 芯片号
*          : offSet- 寄存器序列id
*  输出参数: pVal  - 寄存器值
*  返 回 值: BSP_OK/BSP_ERROR;
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 10119095@2019-02-30 14:55:24    创建
*----------------------------------------------------------------------------
*/
static UINT32 BspRegRd_LocalBus_32BIT(UINT32 chip, UINT32 offSet, UINT32 *pVal)
{
    T_LOACLABUS_REG ulRdRegVal = 0;

    semTake(s_localBusSem, WAIT_FOREVER);
    uintptr_t pOffSet = (uintptr_t)offSet;
    ulRdRegVal = *(T_LOACLABUS_REG *)pOffSet;
    if (NULL != pVal)
    {
        *pVal = (UINT32)ulRdRegVal & 0xFFFF;
    }
    semGive(s_localBusSem);

    dbgInfoEx("%s>>Chip'%d RdReg[0x%08X]= 0x%08X\n", __FUNCTION__, chip, offSet, ulRdRegVal);

    return BSP_OK;
}

/*****************************************************************************
*  函数名称   : BspRegWrMask_LocalBus_32BIT
*  功能描述   : localbus 寄存器掩码写
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : chip      :芯片号
*             : offSet    :寄存器序列id
*             : val       :寄存器值
*             : mask
*  输出参数   : 无
*  返 回 值   : BSP_OK/BSP_ERROR;
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), wangfei @2017-02-16 14:55:24    创建
*----------------------------------------------------------------------------
*/
static UINT32 BspRegWrMask_LocalBus_32BIT(UINT32 chip, UINT32 offSet, UINT32 val, UINT32 mask)
{
    T_LOACLABUS_REG ulRdRegVal = 0;
    T_LOACLABUS_REG ulRegValWr = 0;
    T_LOACLABUS_REG ulValMask  = 0;

    semTake(s_localBusSem, WAIT_FOREVER);
    uintptr_t pOffSet = (uintptr_t)offSet;
    ulValMask  = (T_LOACLABUS_REG)(mask & 0x0000FFFF);

    ulRdRegVal  = *(T_LOACLABUS_REG *)pOffSet;
    ulRdRegVal &= 0x0000FFFF;

    ulRegValWr  = 0x5A000000;
    ulRegValWr |= ulRdRegVal & (~ulValMask);
    ulRegValWr |= (T_LOACLABUS_REG)val & ulValMask;
    *(T_LOACLABUS_REG *)pOffSet = ulRegValWr;

    semGive(s_localBusSem);    

    dbgInfoEx("%s>>Chip'%d Val'0x%04X Msk'0x%04X: WrReg[0x%08X]= 0x%08X\n",
              __FUNCTION__, chip, val, mask, offSet, ulRegValWr);
    return BSP_OK;
}

/*****************************************************************************
*  函数名称   : BspRegDrvLocalBus_SemInit(*)
*  功能描述   : localbus访问信号量
*  读全局变量 : 
*  写全局变量 : 
*  输入参数   : 
*  输出参数   : 
*  返 回 值   : BSP_OK: 成功，BSP_ERROR其它值表示失败
*  其它说明   : 
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A), wangfei2017 -03-26 12:04:22, 添加函数代码
*----------------------------------------------------------------------------
*/
static UINT32 BspRegLocalBus_SemInit()
{
    s_localBusSem = semBCreate(SEM_Q_FIFO, SEM_FULL);
    
    if (s_localBusSem == NULL)
    {
        return BSP_ERROR;
    }
    return BSP_OK;

}
T_Reg_Drv_Access regDrv[DEV_REG_ACCESS_TYPE_MAX]=
{
    /*DEV_REG_ACCESS_TYPE_MIN*/
    {0,},
    /*DEV_REG_ACCESS_SPI_BUS  挂接在funcinit中，在spi总线初始化当中挂接*/
    {0,},
    /*DEV_REG_ACCESS_LOCAL_BUS*/
    {BspRegWr_LocalBus,BspRegRd_LocalBus,BspRegWrMask_LocalBus},
    /*DEV_REG_ACCESS_GPIO 挂接在funcinit中，在gpio总线初始化当中挂接*/
    {0,},
    /*DEV_REG_ACCESS_LOCAL_BUS_8BIT*/
	{BspRegWr_LocalBus_8BIT,BspRegRd_LocalBus_8BIT,BspRegWrMask_LocalBus_8BIT},
    /*DEV_REG_ACCESS_LOCAL_BUS_32BIT*/
    {BspRegWr_LocalBus_32BIT,BspRegRd_LocalBus_32BIT,BspRegWrMask_LocalBus_32BIT},
};
/*****************************************************************************
*  函数名称   : BspSetRegAccess
*  功能描述   : 寄存器访问方式挂接
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : 无
*  输出参数   : 无
*  返 回 值   : BSP_OK/BSP_ERROR;
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2017-02-16 14:55:24    创建
*----------------------------------------------------------------------------
*/    
static UINT32 BspSetRegAccess(VOID)
{       
    /* Init Semphar */
    BspRegLocalBus_SemInit();
    /*just set localbus drv here,spi\gpio drv func seted befor main run */
    memcpy(&(s_regAccess[DEV_REG_ACCESS_LOCAL_BUS]),&(regDrv[DEV_REG_ACCESS_LOCAL_BUS]),sizeof(T_Reg_Drv_Access));
    memcpy(&(s_regAccess[DEV_REG_ACCESS_LOCAL_BUS_8BIT]),&(regDrv[DEV_REG_ACCESS_LOCAL_BUS_8BIT]),sizeof(T_Reg_Drv_Access));
    memcpy(&(s_regAccess[DEV_REG_ACCESS_LOCAL_BUS_32BIT]),&(regDrv[DEV_REG_ACCESS_LOCAL_BUS_32BIT]),sizeof(T_Reg_Drv_Access));
 
    return BSP_OK;
}
/*****************************************************************************
*  函数名称   : BspRegAccessInit
*  功能描述   : 寄存器访问初始化
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : 无 
*  输出参数   : 无
*  返 回 值   : BSP_OK/BSP_ERROR;
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2017-02-16 14:55:24    创建
*----------------------------------------------------------------------------
*/
UINT32 BspRegAccessInit(VOID)
{    
    return BspSetRegAccess();
}
/**************************************************************************
* 函数名称: BspGetRegAccess
* 功能描述:
* 输入参数: 无
* 输出参数: 无
* 返 回 值: BSP_OK 执行成功
*           其它   执行失败
* 其它说明:
* 修改日期       版本号           修改人    修改内容
* ------------------------------------------------------------------------
* 2015年12月22日 Wangfei   创建
**************************************************************************/
T_Reg_Drv_Access* BspGetRegAccess(UINT32 idx)
{
    if(idx >= DEV_REG_ACCESS_TYPE_MAX)
    {
        return NULL;
    }
    return &(s_regAccess[idx]);
}

/**************************************************************************
* 函数名称: BspRegDomainWrMask
* 功能描述: 根据功能类型id和掩码写寄存器地址
* 输入参数: chip            :芯片id
*         : funcDomainIdx   :寄存器功能类型id
*         : offSet          :寄存器偏移地址
*         : val             :寄存器值
*         : mask            :寄存器掩码
* 输出参数: 无
* 返 回 值: BSP_OK /BSP_ERROR
* 其它说明:
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2017-02-16 14:55:24    创建
*----------------------------------------------------------------------------
*/
UINT32 BspRegDomainWrMask(UINT32 chipIdx,UINT32 funcDomainIdx,UINT32 offSet, UINT32 val, UINT32 mask)
{
    UINT32 accessType   = 0;
    UINT32 regOffSet    = 0;
    UINT32 chipNo       = 0;
    T_Reg_Head *pRegHeadTbl = &s_pRegHeadTbl[funcDomainIdx];
    
    if((pRegHeadTbl->initFlag == REG_FUNC_NOT_INIT) /*|| (ulCoreId>=IntPub_UnitFunc_Dif_CommCfg_GetTotalIcChipNum_Base())*/)
    {
        //dbgInfo("%d regHead not inited\n",funcDomainIdx);
        return BSP_ERROR;
    }
    if (pRegHeadTbl->pcbCheck && pRegHeadTbl->pcbCheck(chipIdx)!=BSP_OK)
    {
        dbgInfoEx("regHead,chip=%d funcDomainIdx=%d check error\n",chipIdx,funcDomainIdx);
        return BSP_ERROR;
    }

    if (((pRegHeadTbl->accessType == DEV_REG_ACCESS_LOCAL_BUS)        || \
         (pRegHeadTbl->accessType == DEV_REG_ACCESS_LOCAL_BUS_8BIT)   || \
         (pRegHeadTbl->accessType == DEV_REG_ACCESS_LOCAL_BUS_32BIT)) && \
         (pRegHeadTbl->busWidth > 0))
    {
        offSet *=  pRegHeadTbl->busWidth;
    }
    
    regOffSet = pRegHeadTbl->virtualBaseAddr[chipIdx] + offSet - pRegHeadTbl->subSectFlag;
    dbgInfoEx("ID:%d,FuncDomainIdx:%d,RegOffset:0x%08x(%#lx+%#x-%#x)\n",chipIdx, funcDomainIdx, regOffSet,
        pRegHeadTbl->virtualBaseAddr[chipIdx],offSet, pRegHeadTbl->subSectFlag);

    if(funcDomainIdx < s_regHeadTblNum  )
    {
        accessType = pRegHeadTbl->accessType;
        if((accessType>DEV_REG_ACCESS_TYPE_MIN)&&(accessType<DEV_REG_ACCESS_TYPE_MAX))
        {
            if(NULL != s_regAccess[accessType].pWrMask)
            {
				/***此处为CERT ERR30-C误告警，后面代码会对fp空指针判断，如下抑制告警***/
                //coverity[cert_int30_c_violation:SUPPRESS]
                chipNo = chipIdx + pRegHeadTbl->chipIndex;
                /***此处为CERT ERR31-C误告警，后面代码会对fp空指针判断，如下抑制告警***/
            	//coverity[cert_int31_c_violation:SUPPRESS]
                return s_regAccess[accessType].pWrMask(chipNo,regOffSet,val,mask);
            }
        }
    }

    return BSP_ERROR;
}
/**************************************************************************
* 函数名称: BspRegDomainWr
* 功能描述: 根据功能类型id 写寄存器地址
* 输入参数: chip            :芯片id
*         : funcDomainIdx   :寄存器功能类型id
*         : offSet          :寄存器偏移地址
*         : val             :寄存器值
* 输出参数: 无
* 返 回 值: BSP_OK /BSP_ERROR
* 其它说明:
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2017-02-16 14:55:24    创建
*----------------------------------------------------------------------------
*/
UINT32 BspRegDomainWr(UINT32 chipIdx,UINT32 funcDomainIdx, UINT32 offSet, UINT32 val)
{
    UINT32 accessType   =   0;
    UINT32 regOffSet    =   0;
    UINT32 chipNo       =   0;
    T_Reg_Head *pRegHeadTbl = &s_pRegHeadTbl[funcDomainIdx];
    
    if (pRegHeadTbl->initFlag == REG_FUNC_NOT_INIT)
    {
        //dbgInfo("%d regHead not inited\n",funcDomainIdx);
        return BSP_ERROR;
    }
    if (pRegHeadTbl->pcbCheck && pRegHeadTbl->pcbCheck(chipIdx)!=BSP_OK)
    {
        dbgInfoEx("regHead,chip=%d funcDomainIdx=%d check error\n",chipIdx,funcDomainIdx);
        return BSP_ERROR;
    }

    if (((pRegHeadTbl->accessType == DEV_REG_ACCESS_LOCAL_BUS)        || \
         (pRegHeadTbl->accessType == DEV_REG_ACCESS_LOCAL_BUS_8BIT)   || \
         (pRegHeadTbl->accessType == DEV_REG_ACCESS_LOCAL_BUS_32BIT)) && \
         (pRegHeadTbl->busWidth > 0))
    {
        offSet *=  pRegHeadTbl->busWidth;
    }
    
    regOffSet = pRegHeadTbl->virtualBaseAddr[chipIdx] + offSet - pRegHeadTbl->subSectFlag;
    dbgInfoEx( "ID:%d,FuncDomainIdx:%d,RegOffset:0x%08x(%#lx+%#x-%#x)\n",
        chipIdx, funcDomainIdx, regOffSet,
        pRegHeadTbl->virtualBaseAddr[chipIdx],offSet, pRegHeadTbl->subSectFlag);

    if(funcDomainIdx < s_regHeadTblNum  )
    {
        accessType = pRegHeadTbl->accessType;
        if((accessType>DEV_REG_ACCESS_TYPE_MIN)&&(accessType<DEV_REG_ACCESS_TYPE_MAX))
        {
            if(NULL != s_regAccess[accessType].pRegWr)
            {
				/***此处为CERT ERR30-C误告警，后面代码会对fp空指针判断，如下抑制告警***/
                //coverity[cert_int30_c_violation:SUPPRESS]
                chipNo = chipIdx + pRegHeadTbl->chipIndex;
                /***此处为CERT ERR31-C误告警，后面代码会对fp空指针判断，如下抑制告警***/
            	//coverity[cert_int31_c_violation:SUPPRESS]
                return s_regAccess[accessType].pRegWr(chipNo,regOffSet,val);
            }
        }
    }

    return BSP_ERROR;
}
/**************************************************************************
* 函数名称: BspRegDomainRd
* 功能描述: 根据功能类型id 读取寄存器
* 输入参数: chip            :芯片id
*         : funcDomainIdx   :寄存器功能类型id
*         : offSet          :寄存器偏移地址
* 输出参数: pval            :寄存器值
* 返 回 值: BSP_OK /BSP_ERROR
* 其它说明:
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2017-02-16 14:55:24    创建
*----------------------------------------------------------------------------
*/
UINT32 BspRegDomainRd(UINT32 chipIdx,UINT32 funcDomainIdx, UINT32 offSet,UINT32 *pVal)
{
    UINT32 accessType   = 0;
    UINT32 regOffset    = 0;
    UINT32 chipNo       = 0;
    T_Reg_Head *pRegHeadTbl = &s_pRegHeadTbl[funcDomainIdx];

    INPUT_POINTER_CHECK(pVal);
    if((pRegHeadTbl->initFlag == REG_FUNC_NOT_INIT))
    {
        //dbgInfo("%d regHead not inited\n",funcDomainIdx);
        return BSP_ERROR;
    }   
    if (pRegHeadTbl->pcbCheck && pRegHeadTbl->pcbCheck(chipIdx)!=BSP_OK)
    {
        dbgInfoEx("regHead,chip=%d funcDomainIdx=%d check error\n",chipIdx,funcDomainIdx);
        return BSP_ERROR;
    }

    if (((pRegHeadTbl->accessType == DEV_REG_ACCESS_LOCAL_BUS)        || \
         (pRegHeadTbl->accessType == DEV_REG_ACCESS_LOCAL_BUS_8BIT)   || \
         (pRegHeadTbl->accessType == DEV_REG_ACCESS_LOCAL_BUS_32BIT)) && \
         (pRegHeadTbl->busWidth > 0))
    {
        offSet *=  pRegHeadTbl->busWidth;
    }

    regOffset = pRegHeadTbl->virtualBaseAddr[chipIdx] + offSet - pRegHeadTbl->subSectFlag;
    dbgInfoEx( "ID:%d,FuncDomainIdx:%d,RegOffset:0x%08x(%#lx+%#x-%#x)\n", chipIdx, funcDomainIdx, regOffset,
    pRegHeadTbl->virtualBaseAddr[chipIdx],offSet, pRegHeadTbl->subSectFlag);

    if(funcDomainIdx < s_regHeadTblNum  )
    {
        accessType = pRegHeadTbl->accessType;
        if((accessType>DEV_REG_ACCESS_TYPE_MIN)&&(accessType<DEV_REG_ACCESS_TYPE_MAX))
        {
            if(NULL != s_regAccess[accessType].pRegRd)
            {
				/***此处为CERT ERR30-C误告警，后面代码会对fp空指针判断，如下抑制告警***/
                //coverity[cert_int30_c_violation:SUPPRESS]
                chipNo = chipIdx + pRegHeadTbl->chipIndex;
				/***此处为CERT ERR31-C误告警，后面代码会对fp空指针判断，如下抑制告警***/
            	//coverity[cert_int31_c_violation:SUPPRESS]
                return s_regAccess[accessType].pRegRd(chipNo,regOffset,pVal);
            }
        }
    }
    return BSP_ERROR;
}



/**************************************************************************
* 函数名称: BspRegWrVal
* 功能描述: 根据寄存器功能id写寄存器
* 输入参数: chip            :芯片id
*         : regIdx          :寄存器功能id
*         : offSet          :寄存器偏移地址
*         : val             :寄存器值
* 输出参数: 无
* 返 回 值: BSP_OK /BSP_ERROR
* 其它说明:
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2017-02-16 14:55:24    创建
*----------------------------------------------------------------------------
*/
static UINT32 BspRegWrVal(UINT32 chip,E_REG_FUNCID_DEF regIdx, UINT32 offSet, UINT32 val)
{
    UINT32 funcDomainIdx =   0;
    UINT32 regOffSet     =   0;
   
    funcDomainIdx   = s_pRegAddrTbl[regIdx].regFuncDomainId;
    regOffSet       = s_pRegAddrTbl[regIdx].regAddr + offSet;
    dbgInfoEx("WrReg chip[%d] funcinx[%d] offset[%d] value[%d] \n",chip, regIdx, offSet,  val);
    return BspRegDomainWr(chip,funcDomainIdx,regOffSet,val);
}


/**************************************************************************
* 函数名称: BspRegWrMask
* 功能描述: 根据寄存器功能id写寄存器
* 输入参数: chip            :芯片id
*         : regIdx          :寄存器功能id
*         : offSet          :寄存器偏移地址
*         : val             :寄存器值
* 输出参数: 无
* 返 回 值: BSP_OK /BSP_ERROR
* 其它说明:
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2017-02-16 14:55:24    创建
*----------------------------------------------------------------------------
*/
UINT32 BspRegWrMask(UINT32 chip,E_REG_FUNCID_DEF regIdx, UINT32 offSet, UINT32 val)
{
    UINT32 funcDomainIdx = 0;
    UINT32 regOffSet     = 0;    
    UINT32 mask          = 0;
    
    funcDomainIdx   = s_pRegAddrTbl[regIdx].regFuncDomainId;
    regOffSet       = s_pRegAddrTbl[regIdx].regAddr + offSet;
    mask            = s_pRegAddrTbl[regIdx].regMask;
    dbgInfoEx("WrReg chip[%d] funcinx[%d] offset[0x%x] value[0x%x] mask[0x%x] \n",chip, regIdx, offSet,  val,mask);
    return BspRegDomainWrMask(chip,funcDomainIdx,regOffSet,val,mask);
}
static T_Reg_Access reg[REG_ACCESS_MAX]=
{
    /*REG_ACCESS_VAL*/
    [REG_ACCESS_VAL] =
    {
        .pRegAccessWr         = BspRegWrVal,        
    },
    /*REG_ACCESS_MASK  */
    [REG_ACCESS_MASK] =
    {
        .pRegAccessWr         = BspRegWrMask,        
    },
    

};

static UINT32 GetRegBitOffset(UINT32 val)
{
    UINT32 loop = 0;
    UINT32 bitNum = sizeof(UINT32)*8;
    for (loop = 0; loop < bitNum; loop++)
    {
        if (val & (1<<loop))
        {
            break;
        }
    }
    return loop;
}

/**************************************************************************
* 函数名称: BspRegWr
* 功能描述: 根据寄存器功能id写寄存器
* 输入参数: chip            :芯片id
*         : regIdx          :寄存器功能id
*         : offSet          :寄存器偏移地址
*         : val             :寄存器值
* 输出参数: 无
* 返 回 值: BSP_OK /BSP_ERROR
* 其它说明:
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2017-02-16 14:55:24    创建
*----------------------------------------------------------------------------
*/
UINT32 BspRegWr(UINT32 chip,E_REG_FUNCID_DEF regIdx, UINT32 offSet, UINT32 val)
{
    UINT32 isMaskType = REG_ACCESS_VAL;/*默认为非掩码方式*/
    UINT32 bitOffset;
    UINT32 data = val;
    
    REG_TBL_CHECK();
     
    if((s_pRegAddrTbl[regIdx].initFlag == REG_FUNC_NOT_INIT) /*|| (ulCoreId>=IntPub_UnitFunc_Dif_CommCfg_GetTotalIcChipNum_Base())*/)
    {
        dbgInfoEx("%d reg not inited\n",regIdx);
        return BSP_ERROR;
    }
    isMaskType   = s_pRegAddrTbl[regIdx].isMask;
    if (isMaskType)
    {
        bitOffset = GetRegBitOffset(s_pRegAddrTbl[regIdx].regMask);
        data <<= bitOffset;
    }
    
    if(reg[isMaskType].pRegAccessWr != NULL )
    {
        return reg[isMaskType].pRegAccessWr(chip,regIdx, offSet,data);
    }
    dbgInfoEx("%d reg pRegWr is NULL\n",regIdx);
    return BSP_ERROR;
}


/**************************************************************************
* 函数名称: BspRegRd
* 功能描述: 根据寄存器功能id 读寄存器
* 输入参数: chip            :芯片id
*         : regIdx          :寄存器功能id
*         : offSet          :寄存器偏移地址
* 输出参数: pval            :寄存器值
* 返 回 值: BSP_OK /BSP_ERROR
* 其它说明:
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2017-02-16 14:55:24    创建
*----------------------------------------------------------------------------
*/
UINT32 BspRegRd(UINT32 chip,E_REG_FUNCID_DEF regIdx, UINT32 offSet,UINT32 *pVal)
{    
    UINT32 retVal;
    UINT32 funcDomainIdx = 0;
    UINT32 regOffSet     = 0;
    UINT32 data          = 0;
    UINT32 bitOffset     = 0;
    INPUT_POINTER_CHECK(pVal);
    REG_TBL_CHECK();

    if((s_pRegAddrTbl[regIdx].initFlag == REG_FUNC_NOT_INIT) /*|| (ulCoreId>=IntPub_UnitFunc_Dif_CommCfg_GetTotalIcChipNum_Base())*/)
    {
        dbgInfoEx("%d reg not inited\n",regIdx);
        return BSP_ERROR;
    }
    funcDomainIdx = s_pRegAddrTbl[regIdx].regFuncDomainId;
    regOffSet     = s_pRegAddrTbl[regIdx].regAddr + offSet;
    dbgInfoEx("RdReg chip[%d] funcinx[%d] offset[%d]  \n",chip, regIdx, offSet);

    retVal = BspRegDomainRd(chip,funcDomainIdx, regOffSet,&data);
    if (s_pRegAddrTbl[regIdx].isMask)
    {
        bitOffset = GetRegBitOffset(s_pRegAddrTbl[regIdx].regMask);
        *pVal = (data & s_pRegAddrTbl[regIdx].regMask) >> bitOffset;
    }
    else
    {
        *pVal = data;
    }
    return retVal;
}
/**************************************************************************
* 函数名称: BspRegWrMask
* 功能描述: 根据寄存器功能id和掩码写寄存器
* 输入参数: chip            :芯片id
*         : regIdx          :寄存器功能id
*         : offSet          :寄存器偏移地址
*         : val             :寄存器值
*         : mask            :寄存器掩码
* 输出参数: 无        
* 返 回 值: BSP_OK /BSP_ERROR
* 其它说明:
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2017-02-16 14:55:24    创建
*----------------------------------------------------------------------------
*/
UINT32 BspRegBitWrMask(UINT32 chip,E_REG_FUNCID_DEF regIdx,UINT32 offSet, UINT32 val, UINT32 mask)
{
    UINT32 funcDomainIdx=0;
    UINT32 regOffSet=0;
    /* UINT32 ulValue_New =0; */
    /* UINT32 ulMask_New = 0; */
    
    REG_TBL_CHECK();
    
    if((s_pRegAddrTbl[regIdx].initFlag== REG_FUNC_NOT_INIT) /*|| (ulCoreId>=IntPub_UnitFunc_Dif_CommCfg_GetTotalIcChipNum_Base())*/)
    {
        dbgInfoEx("%d reg not inited\n",regIdx);
        return BSP_ERROR;
    }
    funcDomainIdx   =   s_pRegAddrTbl[regIdx].regFuncDomainId;
    regOffSet       =   s_pRegAddrTbl[regIdx].regAddr + offSet;   
    
    dbgInfoEx("WrRegMask chip[%d] funcinx[%d] offset[%d] value[%d] mask[%d]\n",chip, regIdx, offSet,  val,  mask);
    return BspRegDomainWrMask(chip,funcDomainIdx,regOffSet,val,  mask);


}
/**************************************************************************
* 函数名称: BspRegBitValWr
* 功能描述: 根据寄存器功能id 按照bit进行写寄存器
* 输入参数: chip            :芯片id
*         : regIdx          :寄存器功能id
*         : offSet          :寄存器偏移地址
*         : val             :寄存器值
*         : bitLow          :低bit
*         : bitHigh         :高big
* 输出参数: 无     
* 返 回 值: BSP_OK /BSP_ERROR
* 其它说明:
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2017-02-16 14:55:24    创建
*----------------------------------------------------------------------------
*/
UINT32 BspRegBitValWr(UINT32 chip,E_REG_FUNCID_DEF regIdx,UINT32 offSet, UINT32 val, UINT32 bitLow, UINT32 bitHigh)
{
    UINT32 mask = 0;
    if(bitLow > bitHigh)
    {
        return BSP_ERROR;
    }

    REG_TBL_CHECK();
    
    if((s_pRegAddrTbl[regIdx].initFlag == REG_FUNC_NOT_INIT) /*|| (ulCoreId>=IntPub_UnitFunc_Dif_CommCfg_GetTotalIcChipNum_Base())*/)
    {
        dbgInfoEx("%d reg not inited\n",regIdx);
        return BSP_ERROR;
    }
    mask = ((1<<(bitHigh-bitLow+1))-1)<<bitLow;
    return BspRegBitWrMask(chip,regIdx,offSet,(val<<bitLow),mask);
}
/**************************************************************************
* 函数名称: BspRegBitValRd
* 功能描述: 根据寄存器功能id 按照bit进行写寄存器
* 输入参数: chip            :芯片id
*         : regIdx          :寄存器功能id
*         : offSet          :寄存器偏移地址
*         : bitLow          :低bit
*         : bitHigh         :高big
* 输出参数: pval            :寄存器值   
* 返 回 值: BSP_OK /BSP_ERROR
* 其它说明:
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2017-02-16 14:55:24    创建
*----------------------------------------------------------------------------
*/
UINT32 BspRegBitValRd(UINT32 chip,E_REG_FUNCID_DEF regIdx, UINT32 ulOffset,UINT32 bitLow,UINT32 bitHigh,UINT32 *pVal)
{
    UINT32 ret           = BSP_OK;
    UINT32 regRdVal      = 0;   
    UINT32 mask          = 0;   
    UINT32 funcDomainIdx = 0;
    UINT32 regOffSet     = 0;
        
    INPUT_POINTER_CHECK(pVal);
    REG_TBL_CHECK();

    if((s_pRegAddrTbl[regIdx].initFlag == REG_FUNC_NOT_INIT) /*|| (ulCoreId>=IntPub_UnitFunc_Dif_CommCfg_GetTotalIcChipNum_Base())*/)
    {
        dbgInfoEx("%d reg not inited\n",regIdx);
        return BSP_ERROR;
    }
     
    funcDomainIdx=s_pRegAddrTbl[regIdx].regFuncDomainId;
    regOffSet = s_pRegAddrTbl[regIdx].regAddr + ulOffset;

    mask = (( 1 << ( bitHigh-bitLow+1 )) - 1) << bitLow; 
    
    ret = BspRegDomainRd(chip,funcDomainIdx,regOffSet,&regRdVal);
    
    *pVal=(regRdVal & mask)>>bitLow;
    
    return ret;

}


BOOL BspMemNcIsExist()
{
    const char *filename = "/dev/memnc";
    if (BspIsFileExist(filename) == BSP_OK)
    {
        return TRUE;
    }
    return FALSE;
}

static UINT32 BspDoMemMap(unsigned long virAddr,unsigned long phyAddr,UINT32 size,unsigned long *pVirAddr, UINT32 ulType)
{
    int iSpaceProt = PROT_READ | PROT_WRITE;
    int iFd = -1; /* 打开内存设备的文件描述符 */

    switch(ulType)
    {
        //黑匣子类的映射到memnc
        case MMAP_TYPE_MEMNC:
        {
            if(TRUE == BspMemNcIsExist())
            {
                iFd = open("/dev/memnc", O_RDWR | O_SYNC);
            }
            else
            {
                iFd = open("/dev/cachedmem", O_RDWR | O_SYNC);
            }
            break;
        }
        //跟其他进程共享内存使用的，如何MCS、DSP共享内存的使用
        case MMAP_TYPE_MEMCASHE:
        {
            iFd = open("/dev/cachedmem", O_RDWR | O_SYNC);
            break;
        }
        //映射其他寄存器内存，使用mem
        case MMAP_TYPE_MEM:
        {
            #if(CPU_FAMILY == ARM64)
             iFd = open("/dev/cachedmem", O_RDWR | O_SYNC);
            #else
            iFd = open("/dev/mem", O_RDWR | O_SYNC);
            #endif
            break;
        }
        default:
        {
            #if(CPU_FAMILY == ARM64)
            iFd = open("/dev/cachedmem", O_RDWR | O_SYNC);
            #else
            iFd = open("/dev/mem", O_RDWR | O_SYNC);
            #endif
            break;
        }
    }

    if (iFd >= 0)
    {
        *pVirAddr = (unsigned long)mmap((VOID *)virAddr, size, iSpaceProt, MAP_SHARED, iFd, phyAddr);
        if (*pVirAddr == -1)
        {
            close(iFd);
            *pVirAddr = 0;
            dbgErr("%s>>ParamAddr(Phy'0x%08lX Vir'0x%08lX): Mmap Error!\n",
                   __FUNCTION__, phyAddr, virAddr);
            return BSP_ERROR;
        }
    }
    else
    {
        dbgErr("%s>>ParamAddr(Phy'0x%08lX Vir'0x%08lX): Open /dev/mem Error!\n",
               __FUNCTION__, phyAddr, virAddr);
        return BSP_ERROR;
    }
    close(iFd);
    dbgInfo("%s>>ParamAddr(Phy'0x%08lX Vir'0x%08lX): pVirAddr= 0x%08lX, size= %#x\n",
            __FUNCTION__, phyAddr, virAddr, *pVirAddr, size);
    return BSP_OK;
}

/**************************************************************************
* 函数名称: BspSetRegVirAddr
* 功能描述: 分配寄存器虚拟地址
* 输入参数: 无
* 输出参数: 无
* 返 回 值: BSP_OK /BSP_ERROR
* 其它说明:
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2017-02-16 14:55:24    创建
*----------------------------------------------------------------------------
*/
#if 1
UINT32 BspInitRegVirAddr(VOID)
{
    UINT32 regFuncLoop    = 0;
    UINT32 chipLoop       = 0;
    unsigned long virAddr = 0;
    UINT32 chipNum        = 0;
    UINT32 funcDomainType = 0;
   
    for(regFuncLoop = 0; regFuncLoop < s_regHeadTblNum; regFuncLoop ++)
    {
        if(s_pRegHeadTbl[regFuncLoop].initFlag == REG_FUNC_NOT_INIT)
        {
            //dbgInfoEx("%d regHead not inited\n",regFuncLoop);
            continue;
        }
        if((DEV_REG_ACCESS_LOCAL_BUS       == s_pRegHeadTbl[regFuncLoop].accessType) || \
           (DEV_REG_ACCESS_LOCAL_BUS_8BIT  == s_pRegHeadTbl[regFuncLoop].accessType) || \
           (DEV_REG_ACCESS_LOCAL_BUS_32BIT == s_pRegHeadTbl[regFuncLoop].accessType))
        {
            chipNum = s_pRegHeadTbl[regFuncLoop].chipNum;
            if(regFuncLoop == s_pRegHeadTbl[regFuncLoop].regFuncDomainType)
            {
                for(chipLoop = 0; chipLoop < chipNum; chipLoop++)
                {
                    if (0 != (s_pRegHeadTbl[regFuncLoop].mmapMaskFlag & BIT_SET(chipLoop)))
                    {
                        continue;
                    }

                    BspDoMemMap(s_pRegHeadTbl[regFuncLoop].virtualBaseAddr[chipLoop],s_pRegHeadTbl[regFuncLoop].mapPhyBaseAddr[chipLoop],s_pRegHeadTbl[regFuncLoop].maxSize,&virAddr,s_pRegHeadTbl[regFuncLoop].regFuncDomainType);

                    s_pRegHeadTbl[regFuncLoop].virtualBaseAddr[chipLoop]= virAddr;
                }
            }
        }
        else
        {
            chipNum = s_pRegHeadTbl[regFuncLoop].chipNum;
            for(chipLoop = 0; chipLoop < chipNum; chipLoop++)          
            {
                s_pRegHeadTbl[regFuncLoop].virtualBaseAddr[chipLoop]=s_pRegHeadTbl[regFuncLoop].mapPhyBaseAddr[chipLoop];
            }
        }
    }

    for(regFuncLoop = 0; regFuncLoop < s_regHeadTblNum; regFuncLoop ++)
    {
        if(0 == s_pRegHeadTbl[regFuncLoop].initFlag)
        {
            //dbgInfoEx("%d regHead not inited\n",regFuncLoop);
            continue;
        }

        if((DEV_REG_ACCESS_LOCAL_BUS       == s_pRegHeadTbl[regFuncLoop].accessType) || \
           (DEV_REG_ACCESS_LOCAL_BUS_8BIT  == s_pRegHeadTbl[regFuncLoop].accessType) || \
           (DEV_REG_ACCESS_LOCAL_BUS_32BIT == s_pRegHeadTbl[regFuncLoop].accessType))
        {
            chipNum = s_pRegHeadTbl[regFuncLoop].chipNum;
            if(regFuncLoop != s_pRegHeadTbl[regFuncLoop].regFuncDomainType)
            {
                for(chipLoop = 0; chipLoop < chipNum; chipLoop++)
                {
                    funcDomainType = s_pRegHeadTbl[regFuncLoop].regFuncDomainType;
                    if(funcDomainType >= s_regHeadTblNum)
                    {
                        continue;
                    }
                    virAddr = s_pRegHeadTbl[funcDomainType].virtualBaseAddr[chipLoop] - \
                              s_pRegHeadTbl[funcDomainType].mapPhyBaseAddr[chipLoop]  + \
                              s_pRegHeadTbl[regFuncLoop].mapPhyBaseAddr[chipLoop];
                    s_pRegHeadTbl[regFuncLoop].virtualBaseAddr[chipLoop] = virAddr;
                }
            }
        }
    }

   return BSP_OK;
}
#endif
#if 0
/**************************************************************************
* 函数名称: BspSetRegVirAddr
* 功能描述: 分配寄存器虚拟地址
* 输入参数: 无
* 输出参数: 无
* 返 回 值: BSP_OK /BSP_ERROR
* 其它说明:
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2017-02-16 14:55:24    创建
*----------------------------------------------------------------------------
*/
UINT32 BspInitRegVirAddr(VOID)
{
    UINT32 regFuncLoop    = 0;
    UINT32 chipLoop       = 0;
    UINT32 virAddr        = 0;
    UINT32 chipNum        = 0;
    UINT32 funcDomainType = 0;
    UINT32 regAccessType  = 0;
    for(regFuncLoop = 0;regFuncLoop < s_regHeadTblNum ; regFuncLoop ++)
    {
        if(s_pRegHeadTbl[regFuncLoop].initFlag == REG_FUNC_NOT_INIT)
        {
            dbgInfoEx("%d regHead not inited\n",regFuncLoop);
            continue;
        }
        chipNum         = s_pRegHeadTbl[regFuncLoop].chipNum;
        funcDomainType  = s_pRegHeadTbl[regFuncLoop].regFuncDomainType; 
        regAccessType   = s_pRegHeadTbl[regFuncLoop].accessType;
        for(chipLoop = 0;chipLoop < chipNum; chipLoop++)
        {
            s_pRegHeadTbl[regFuncLoop].virtualBaseAddr[chipLoop]=s_pRegHeadTbl[regFuncLoop].mapPhyBaseAddr[chipLoop];
            if((regAccessType == DEV_REG_ACCESS_LOCAL_BUS)&& (funcDomainType <= s_regHeadTblNum))
            {
                if(regFuncLoop ==s_pRegHeadTbl[regFuncLoop].regFuncDomainType)
                {
                    BspDoMemMap(s_pRegHeadTbl[regFuncLoop].mapPhyBaseAddr[chipLoop],s_pRegHeadTbl[regFuncLoop].maxSize,&virAddr);                   
                }
                else
                {                 
                    virAddr    = s_pRegHeadTbl[funcDomainType].virtualBaseAddr[chipLoop] - \
                    s_pRegHeadTbl[funcDomainType].mapPhyBaseAddr[chipLoop] + s_pRegHeadTbl[regFuncLoop].mapPhyBaseAddr[chipLoop];                    
                }
                s_pRegHeadTbl[regFuncLoop].virtualBaseAddr[chipLoop] = virAddr;
            }
        }
    }
    return BSP_OK;
}
#endif

/**************************************************************************
* 函数名称: BspGetRegAddrAndMask
* 功能描述: 根据寄存器功能id 和off 获取寄存器地址
* 输入参数: chip    - 芯片id
*         : regIdx  - 寄存器功能id
*         : offset  - 寄存器偏移地址
* 输出参数: pRegAddr- 寄存器地址
*         : pValMask- 数据读写Mask值
* 返 回 值: BSP_OK - 成功; 其它 - 失败
* 其它说明: 用于测试调试打印
*--------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A),  10119095@2017-02-16 14:55:24    创建
*--------------------------------------------------------------------------
*/
UINT32 BspGetRegAddrAndMask(UINT32 chip, UINT32 regIdx, UINT32 offset,
                                   UINT32 *pRegAddr, UINT32 *pValMask)
{
    UINT32 ulRegTrueAddr = 0;
    UINT32 ulWrRdValMask = 0;
    UINT32 ulFuncRet = BSP_OK;

    if (NULL == s_pRegAddrTbl)
    {
        ulFuncRet |= BIT_SET(0);
        dbgInfoEx("%s>>Error! Chip'%d RegIdx'%d RegAddrTbl is Null!\n",
                  __FUNCTION__, chip, regIdx);
        return ulFuncRet;
    }

    if (REG_FUNC_NOT_INIT == s_pRegAddrTbl[regIdx].initFlag)
    {
        ulFuncRet |= BIT_SET(1);
        dbgInfoEx("%s>>Error! Chip'%d RegIdx'%d RegAddrTbl not Init!\n",
                  __FUNCTION__, chip, regIdx);
        return ulFuncRet;
    }

    ulRegTrueAddr = s_pRegAddrTbl[regIdx].regAddr + offset;
    if (NULL != pRegAddr)
    {
        *pRegAddr = ulRegTrueAddr;
    }

    if (REG_ACCESS_MASK == s_pRegAddrTbl[regIdx].isMask)
    {
        ulWrRdValMask = s_pRegAddrTbl[regIdx].regMask;
    }
    else
    {
    //  ulWrRdValMask = 0x80000000; /* 非掩码方式输出regMask标志 */
    }

    if (NULL != pValMask)
    {
        *pValMask = ulWrRdValMask;
    }

    return ulFuncRet;
}

VOID ShowRegAddrAndMask(UINT32 chip, UINT32 regIdx, UINT32 offset)
{
    UINT32 ulRegAddr = 0;
    UINT32 ulValMask = 0;
    UINT32 ulFuncRet = BSP_OK;

    ulFuncRet = BspGetRegAddrAndMask(chip, regIdx, offset, &ulRegAddr, &ulValMask);
    if (BSP_OK == ulFuncRet)
    {
        dbgInfo("%s>>Chip'%d RegIdx'%2d offset'0x%04X: Addr= 0x%04X, Mask= 0x%04X\n",
                __FUNCTION__, chip, regIdx, offset, ulRegAddr, ulValMask);
    }
    else
    {
        dbgErr("%s>>Chip'%d RegIdx'%2d offset'0x%04X GetAddrAndMask Error!\n",
                __FUNCTION__, chip, regIdx, offset);
    }
}

/**************************************************************************
* 函数名称: BspGetDifChanOffset
* 功能描述: 获取中频通道偏移
* 输入参数: 无
* 输出参数: 无
* 返 回 值: BSP_OK /BSP_ERROR
* 其它说明:
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2017-02-16 14:55:24    创建
*----------------------------------------------------------------------------
*/
UINT32 BspGetDifChanOffset(E_REG_FUNCID_DEF funcIdx, UINT32* pOffSet)
{
    UINT32 regHeadIndex=0;

    REG_TBL_CHECK();
    
    if(0==s_pRegAddrTbl[funcIdx].initFlag)
    {
        dbgInfoEx("%d reg not inited\n",funcIdx);
        return BSP_ERROR;
    }
    regHeadIndex = s_pRegAddrTbl[funcIdx].regFuncDomainId;
    if(s_pRegHeadTbl[regHeadIndex].initFlag == REG_FUNC_NOT_INIT)
    {
        //dbgInfoEx("%d regHead not inited\n",regHeadIndex);
        return BSP_ERROR;
    }
    *pOffSet = s_pRegHeadTbl[regHeadIndex].chanInter;

    return BSP_OK;
}
/**************************************************************************
* 函数名称: BspGetMemBlockFromPhyAddr
* 功能描述: 获取物理地址功能模块以及地址
* 输入参数: 无
* 输出参数: 无
* 返 回 值: BSP_OK /BSP_ERROR
* 其它说明:
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2017-02-16 14:55:24    创建
*----------------------------------------------------------------------------
*/
UINT32 BspGetMemBlockFromPhyAddr(UINT32 phyAddr, UINT32 *pBlock, UINT32 *pBlockBasePhyAddr, UINT32 *busWidth)
{
    UINT32 loop            = 0;
    UINT32 loopChip        = 0;
    UINT32 chipNum         = 0;
    UINT32 foundFlag       = 0;
    INPUT_POINTER_CHECK(pBlock);
    INPUT_POINTER_CHECK(pBlockBasePhyAddr);
    INPUT_POINTER_CHECK(busWidth);
    
    for (loop = 0; loop < s_regHeadTblNum; loop++)
    {
        dbgInfoEx("Lp'%d Domain'%d HeadTblSum'%d ChipSum'%d Width'%d Init'%d\n",
                  loop, s_pRegHeadTbl[loop].regFuncDomainType,
                  s_regHeadTblNum, s_pRegHeadTbl[loop].chipNum,
                  s_pRegHeadTbl[loop].busWidth,
                  s_pRegHeadTbl[loop].initFlag);

        chipNum = s_pRegHeadTbl[loop].chipNum;
        for (loopChip = 0; loopChip < chipNum; loopChip++)
        {
            dbgInfoEx("Lp'%d Chip'%d Access(%d:OK)'%d Size'0x%08X Base'0x%08lX SocAddr'0x%08X Max'0x%08lX\n",
                      loop, loopChip, DEV_REG_ACCESS_LOCAL_BUS_32BIT, s_pRegHeadTbl[loop].accessType,
                      s_pRegHeadTbl[loop].maxSize, s_pRegHeadTbl[loop].mapPhyBaseAddr[loopChip], phyAddr,
                      s_pRegHeadTbl[loop].mapPhyBaseAddr[loopChip] + s_pRegHeadTbl[loop].maxSize);
            if ((s_pRegHeadTbl[loop].initFlag == 1) &&
                ((s_pRegHeadTbl[loop].accessType == DEV_REG_ACCESS_LOCAL_BUS)        ||
                 (s_pRegHeadTbl[loop].accessType == DEV_REG_ACCESS_LOCAL_BUS_8BIT)   ||
                 (s_pRegHeadTbl[loop].accessType == DEV_REG_ACCESS_LOCAL_BUS_32BIT)) &&
                (s_pRegHeadTbl[loop].regFuncDomainType == loop) &&
                (s_pRegHeadTbl[loop].mapPhyBaseAddr[loopChip] <= phyAddr) &&
                ((s_pRegHeadTbl[loop].mapPhyBaseAddr[loopChip] + s_pRegHeadTbl[loop].maxSize) > phyAddr))
            {
                *pBlock             = loop;
                *pBlockBasePhyAddr  = s_pRegHeadTbl[loop].mapPhyBaseAddr[loopChip];
                *busWidth           = s_pRegHeadTbl[loop].busWidth;
                foundFlag = 1;
                dbgInfoEx("%s>>Block'%d PhyAddr'0x%08X BusWidth'%d, foundFlag=%d\n", __FUNCTION__,
                          *pBlock, *pBlockBasePhyAddr, *busWidth, foundFlag);
                return BSP_OK;
            }
        }
    }
    return BSP_ERROR;
    
}



/**************************************************************************
* 函数名称: BspGetMemBlockFromPhyAddr
* 功能描述: 获取物理地址功能模块以及地址
* 输入参数: 无
* 输出参数: 无
* 返 回 值: BSP_OK /BSP_ERROR
* 其它说明:
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2017-02-16 14:55:24    创建
*----------------------------------------------------------------------------
*/
/*有问题*/
UINT32  BspGetMemBlockFromOffSetAddr(UINT32 offSetAddr, UINT32 *pBlock, UINT32 *pBlockBasePhyAddr)
{
    UINT32 loop            = 0;
    UINT32 loopChip        = 0;
    UINT32 chipNum         = 0;
    UINT32 foundFlag       = 0;
    UINT32 mapPhy          = 0;
    

    for (loop = 0; loop < s_regHeadTblNum;loop++)
    {
        chipNum = s_pRegHeadTbl[loop].chipNum ;
        
        for(loopChip =0 ;loopChip < chipNum ; loopChip++)
        {
            if(s_pRegHeadTbl[loop].subSectFlag == 0)
            {
                mapPhy = offSetAddr *s_pRegHeadTbl[loop].busWidth + s_pRegHeadTbl[loop].mapPhyBaseAddr[loopChip];
                
            }
            if(s_pRegHeadTbl[loop].subSectFlag != 0)
            {
                mapPhy = offSetAddr *s_pRegHeadTbl[loop].busWidth + ( s_pRegHeadTbl[loop].mapPhyBaseAddr[loopChip] - s_pRegHeadTbl[loop].subSectFlag) ;
            }
            if ((s_pRegHeadTbl[loop].initFlag == 1) &&
                ((s_pRegHeadTbl[loop].accessType == DEV_REG_ACCESS_LOCAL_BUS)        ||
                 (s_pRegHeadTbl[loop].accessType == DEV_REG_ACCESS_LOCAL_BUS_8BIT)   ||
                 (s_pRegHeadTbl[loop].accessType == DEV_REG_ACCESS_LOCAL_BUS_32BIT)) &&
                (s_pRegHeadTbl[loop].regFuncDomainType == loop) &&
                (s_pRegHeadTbl[loop].mapPhyBaseAddr[loopChip] <= mapPhy) &&
                ((s_pRegHeadTbl[loop].mapPhyBaseAddr[loopChip] +
                 s_pRegHeadTbl[loop].maxSize) > mapPhy))
                {
                    *pBlock = loop;
                    *pBlockBasePhyAddr = s_pRegHeadTbl[loop].mapPhyBaseAddr[loopChip];
                    foundFlag = 1;
                    dbgInfoEx("%s: foundFlag: %d\n", __FUNCTION__, foundFlag);
                    return BSP_OK;
                }
        }
        
    }    
    return BSP_ERROR;
    
}

static UINT32 GetRegChipInfo(UINT32 regIdx,UINT32 *chipNo,UINT32 *chipNum)
{
	UINT32 chipNumMax = 0;
	UINT32 chipNumReal = 0;
	UINT32 chipInfo = 0;
	UINT32 loop;

    REG_TBL_CHECK();
    if (regIdx >= REG_MACRO_MAX)
	{
		return BSP_ERROR;
	}
    if (s_pRegAddrTbl[regIdx].initFlag == REG_FUNC_NOT_INIT)
    {
        dbgInfoEx("%d reg not inited\n",regIdx);
        return BSP_ERROR;
    }

    if ((s_pRegAddrTbl[regIdx].chipInfo & REG_MULTI_CHIP_SUPORT) != REG_MULTI_CHIP_SUPORT)
    {
    	return BSP_ERROR;
    }

	dbgInfoEx("regidx:%d, regaddr:%#lx, chipInfo:%#x\n",
			regIdx, s_pRegAddrTbl[regIdx].regAddr, s_pRegAddrTbl[regIdx].chipInfo);

	chipNumMax = *chipNum;
	chipInfo = s_pRegAddrTbl[regIdx].chipInfo & REG_MULTI_CHIP_MASK;
	for (chipNumReal=loop=0; loop<chipNumMax; ++loop)
	{
		if (chipInfo & (1<<loop))
		{
			chipNo[chipNumReal++] = loop;
		}
	}
	*chipNum = chipNumReal;
	dbgInfoEx("chipInfo:%#x,chipNum:%d\n",chipInfo,chipNumReal);

    return BSP_OK;
}

UINT32 BspGetRegChip(UINT32 regIdx,UINT32 *chipNo,UINT32 *chipNum)
{
    INPUT_POINTER_CHECK(chipNo);
    INPUT_POINTER_CHECK(chipNum);
    if (*chipNum < 1)/* 根据后面实际的打表调整,目前暂定1 */
    {
        return BSP_ERROR;
    }

    /* 根据寄存器可获取到宏对应的芯片索引列表 */
    if (BSP_OK != GetRegChipInfo(regIdx,chipNo,chipNum))
    {
		*chipNo = 0;
		*chipNum= 1;
    }

    return BSP_OK; 
}

/**************************************************************************
* 函数名称: BspGetRegTabVal
* 功能描述: 获取Regtable value
* 输入参数: 无
* 输出参数: 无
* 返 回 值: BSP_OK /BSP_ERROR
* 其它说明:
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2017-02-16 14:55:24    创建
*----------------------------------------------------------------------------
*/
UINT32 BspGetRegTabVal(UINT32 funcIdx, UINT32* pRegVal)
{
    /* UINT32 regHeadIndex=0; */

    REG_TBL_CHECK();
    
    if(0==s_pRegAddrTbl[funcIdx].initFlag)
    {
        dbgInfoEx("%d reg not inited\n",funcIdx);
        return BSP_ERROR;
    }
   *pRegVal = s_pRegAddrTbl[funcIdx].regVal;    

    return BSP_OK;
}

/**************************************************************************
* 函数名称: BspGetRegTabAdd
* 功能描述: 获取Regtable Address
* 输入参数: 无
* 输出参数: 无
* 返 回 值: BSP_OK /BSP_ERROR
* 其它说明:
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 孙博@2019-07-09 11:55:24    创建
*----------------------------------------------------------------------------
*/
UINT32 BspGetRegTabAdd(UINT32 funcIdx, UINT32* pRegAdd)
{
    REG_TBL_CHECK();
    if(NULL == pRegAdd)
    {
        dbgInfoEx("pRegAdd is NULL!\n");
        return BSP_ERROR;
    }
    if(funcIdx >= REG_MACRO_MAX)
    {
        dbgInfoEx("funcIdx[%d] is out of range!\n", funcIdx);
        return BSP_ERROR;
    }
    *pRegAdd = s_pRegAddrTbl[funcIdx].regAddr;

    return BSP_OK;
}

UINT32 BspRegTblValInit(VOID)
{
   UINT32 loop         = 0;
   UINT32 chip         = 0;
   UINT32 chipBusType  = 0;
   UINT32 retVal       = BSP_OK;

   for (loop = 0; loop < s_RegNum; loop++)
   {
       if (s_pRegAddrTbl[loop].regProperty != REG_NEED_INIT)
       {
           continue;
       }

       if(s_pRegAddrTbl[loop].regFuncDomainId == 1)
       {
           retVal |=SpiGetFpgaIdByName("Fpga0", &chip, &chipBusType);
       }
       if((retVal != BSP_OK)||(chip >= MAX_CHIP_NUM))
       {
           continue;
       }
       BspRegWr(chip,loop,0,s_pRegAddrTbl[loop].regVal);
   }
   return BSP_OK;
}



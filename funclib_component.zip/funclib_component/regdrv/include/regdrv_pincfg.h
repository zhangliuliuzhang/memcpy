/*****************************************************************************
 * 版权所有(C) 2014, ZTE Corp. ZXSDR-RRU Platform BSP
 *----------------------------------------------------------------------------
 * 模 块 名 : BSP
 * 文件名称 : regdrv_pincfg.h
 * 文件标识 : {[N/A]}
 * 内容摘要 : 本文件主要提供寄存器单bit 用于管脚配置的实现。
 * 注意事项 : 无
 * 作    者 : 王飞
 * 创建日期 : 2017-02-05 10:28:34
 * 当前版本 : Ver1.0
 *----------------------------------------------------------------------------
 * 变更记录 :
 *
 * $记录1
 * 变 更 单:
 * 责 任 人:
 * 修改日戳:
 * 变更说明:

 *----------------------------------------------------------------------------
 */
#ifndef BSP_REG_DRV_PINCFG_H_INCLUDED
#define BSP_REG_DRV_PINCFG_H_INCLUDED

#ifdef __cplusplus
extern "C" {
#endif

#include "regdrv_comm.h"



/**************************************************************************
 *                        宏定义
 **************************************************************************/

/* 表明管脚需要初始化为输入还是输出状态 */
#define REG_PIN_TYPE_DEF              (0)
#define REG_PIN_TYPE_OUTPUT           (1)
#define REG_PIN_TYPE_INPUT            (2)

/* 输出管脚初始化值所占用的bit */
#define REG_PIN_DEF_VAL_BIT           (8)
#define REG_PIN_DEF_VAL_MASK          (0xff)


/* 表明输出管脚初始化值 */
#define REG_PIN_TYPE_OUTPUT_DEF       (0)
#define REG_PIN_TYPE_OUTPUT_LOW       (1)
#define REG_PIN_TYPE_OUTPUT_HIGH      (2)

#define REG_PIN_VAL_BIT_INVERS_STATE  (16)
/* 表明输出管脚初始化值 */
#define REG_PIN_TYPE_OUTPUT_NOINVERS  (0<<0)
#define REG_PIN_TYPE_OUTPUT_INVERS    (1<<0)
#define REG_PIN_TYPE_DIR_NOINVERS     (0<<1)
#define REG_PIN_TYPE_DIR_INVERS       (1<<1)
#define REG_PIN_TYPE_INPUT_NOINVERS   (0<<2)
#define REG_PIN_TYPE_INPUT_INVERS     (1<<2)

#define REG_DEV_ID_BIT_OFFSET         (24)
#define REG_DEV_ID_MASK               (0xff)


#define PIN_TYPE_DIR_INVERS  (REG_PIN_TYPE_DIR_INVERS<<REG_PIN_VAL_BIT_INVERS_STATE)
#define PIN_TYPE_OUT_INVERS  (REG_PIN_TYPE_OUTPUT_INVERS<<REG_PIN_VAL_BIT_INVERS_STATE)
#define PIN_TYPE_OUT_DEF     (REG_PIN_TYPE_OUTPUT|(REG_PIN_TYPE_OUTPUT_DEF<<REG_PIN_DEF_VAL_BIT))
#define PIN_TYPE_OUT_LOW     (REG_PIN_TYPE_OUTPUT|(REG_PIN_TYPE_OUTPUT_LOW<<REG_PIN_DEF_VAL_BIT))
#define PIN_TYPE_OUT_HIGH    (REG_PIN_TYPE_OUTPUT|(REG_PIN_TYPE_OUTPUT_HIGH<<REG_PIN_DEF_VAL_BIT))
#define PIN_TYPE_DEF_LOW     (REG_PIN_TYPE_OUTPUT_DEF|(REG_PIN_TYPE_OUTPUT_LOW<<REG_PIN_DEF_VAL_BIT))
#define PIN_TYPE_DEF_HIGH    (REG_PIN_TYPE_OUTPUT_DEF|(REG_PIN_TYPE_OUTPUT_HIGH<<REG_PIN_DEF_VAL_BIT))
#define PIN_TYPE_IN_DEF      (REG_PIN_TYPE_INPUT)
#define PIN_TYPE_IN_INVERS  (REG_PIN_TYPE_INPUT_INVERS<<REG_PIN_VAL_BIT_INVERS_STATE)

#define BSP_SET_REG_DRV(idx,chip,type,addr,bitnum,defval)   \
    [idx] =                                       \
    {   .chipIdx = chip,                          \
        .regType = type,                          \
        .regAddr = addr,                          \
        .bitNum  = bitnum,                        \
        .defVal  = defval                         \
    }

#define BSP_SET_DEV_REG_TBL_MODIFY(idx,chip,type,addr,bitnum,defval)   \
        {idx,chip,type,addr,bitnum,defval}
/**************************************************************************
*                         全局变量定义                                   *
**************************************************************************/

/**************************************************************************
*                         数据类型                                       *
**************************************************************************/
typedef UINT32 (*pRegPinSet)(UINT32 idx,UINT32 addr, UINT32 regBit , UINT32 val);
typedef UINT32 (*pRegPinGet)(UINT32 idx,UINT32 addr, UINT32 regBit , UINT32 *pVal);
typedef UINT32 (*pReg_PreInit)();

typedef struct tag_reg_pre_init
{
    pReg_PreInit  pPinInit;      /* 芯片初始化接口 */
}T_PRE_REG_INIT;
typedef struct _T_Dev_Reg_Cfg
{
    pRegPinSet   pFuncPinSet;
    pRegPinSet   pFuncPinDirSet;
    pRegPinGet   pFuncPinGet;
}T_Reg_Drv_Cfg;

typedef struct _T_Reg_Drv_Tbl_
{
    UINT32   chipIdx;
    UINT32   regType;
    UINT32   regAddr;
    UINT32   bitNum;
    UINT32   defVal;
}_T_Reg_Drv_Tbl;

typedef struct _T_Dev_Reg_Tbl_Modify_
{
	UINT32   modiIdx;
    UINT32   chipIdx;
	UINT32   regType;
	UINT32   regAddr;
	UINT32   bitNum;
	UINT32   defVal;
}_T_Dev_Reg_Tbl_Modify;



typedef struct _T_Dev_Reg_
{
    _T_Reg_Drv_Tbl *   pTRegTbl;
    UINT32              num;
}T_Reg_Drv_Tbl;


/**************************************************************************
*                         函数声明
**************************************************************************/
extern T_PRE_REG_INIT  g_atPreInitFunc[DEV_REG_ACCESS_TYPE_MAX];
UINT32 BspRegPinSetDir(UINT32 regPinIdx, UINT32 val);
UINT32 BspSetRegDrvData(_T_Reg_Drv_Tbl * pRegTbl, UINT32 regTblNum);
UINT32 BspRegDrvPinInit();
UINT32 BspCpuGpioInit(VOID);

UINT32 BspSetPinDirInversFlag(UINT32 ulInversFlag);

#ifdef __cplusplus
}
#endif
#endif /* BSP_REG_DRV_PINCFG_H_INCLUDED */



/*****************************************************************************
 * 版权所有(C) 2014, ZTE Corp. ZXSDR-RRU Platform BSP
 *----------------------------------------------------------------------------
 * 模 块 名 : BSP
 * 文件名称 : regdv_pintbl.h
 * 文件标识 : {[N/A]}
 * 内容摘要 : 本文件主要提供寄存器管脚打表定义
 * 注意事项 : 无
 * 作    者 : 王飞
 * 创建日期 : 2017-02-05 10:28:34
 * 当前版本 : Ver1.0
 *----------------------------------------------------------------------------
 * 变更记录 :
 *
 * $记录1
 * 变 更 单:
 * 责 任 人:
 * 修改日戳:
 * 变更说明:

 *----------------------------------------------------------------------------
 */
#ifndef BSP_REG_PIN_TBL_H_INCLUDED
#define BSP_REG_PIN_TBL_H_INCLUDED

#ifdef __cplusplus
extern "C" {
#endif


/**************************************************************************
 *                        宏定义
 **************************************************************************/


/**************************************************************************
*                         全局变量定义                                   *
**************************************************************************/

/**************************************************************************
*                         数据类型                                       *
**************************************************************************/
/****************************** 器件管脚寄存器定义段 ********************************/

/*****CLK 时钟 管脚定义*****/
#define REG_SPI_CLK_PLL_OE(id)       REG_SPI_OE_CLK_PLL##id
#define REG_SPI_CLK_PLL_PD(id)       REG_SPI_PD_CLK_PLL##id
#define REG_SPI_CLK_PLL_LE(id)       REG_SPI_LE_CLK_PLL##id
#define REG_SPI_CLK_PLL_SYNC(id)     REG_SPI_SYNC_CLK_PLL##id
#define REG_SPI_CLK_PLL_HOLDOVER(id) REG_SPI_HOLDOVER_CLK_PLL##id
#define REG_SPI_CLK_PLL_LD(id)       REG_SPI_LD_CLK_PLL##id 
#define REG_SPI_CLK_PLL_LD1(id)      REG_SPI_LD1_CLK_PLL##id 
#define REG_SPI_CLK_PLL_LD2(id)      REG_SPI_LD2_CLK_PLL##id
#define REG_SPI_CLK_PLL_LD3(id)      REG_SPI_LD3_CLK_PLL##id 
#define REG_SPI_CLK_PLL_LOS1(id)     REG_SPI_LOS1_CLK_PLL##id 
#define REG_SPI_CLK_PLL_LOS2(id)     REG_SPI_LOS2_CLK_PLL##id 
#define REG_SPI_CLK_PLL_MOSI(id)     REG_SPI_MOSI_CLK_PLL##id 
#define REG_SPI_CLK_PLL_MISO(id)     REG_SPI_MISO_CLK_PLL##id
#define REG_SPI_CLK_PLL_SCK(id)      REG_SPI_SCK_CLK_PLL##id 
#define REG_SPI_CLK_PLL_DIR(id)      REG_SPI_DIR_CLK_PLL##id  
#define REG_SPI_CLK_PLL_RST(id)      REG_SPI_RST_CLK_PLL##id  
#define REG_SPI_CLK_PLL_INT(id)      REG_SPI_INT_CLK_PLL##id   
#define REG_SPI_CLK_AD9379_SYNC(id)  REG_SPI_SYNC_CLK_AD9379##id 

/* Ad9545 只有RST管脚控制; SI5381 有RST、OE管脚控制 */
#define REG_PIN_SPI_CLK_PLL(id)          \
        REG_SPI_CLK_PLL_LE(id),          \
        REG_SPI_CLK_PLL_SYNC(id),        \
        REG_SPI_CLK_PLL_HOLDOVER(id),    \
        REG_SPI_CLK_PLL_LD(id),          \
        REG_SPI_CLK_PLL_LD1(id),         \
        REG_SPI_CLK_PLL_LD2(id),         \
        REG_SPI_CLK_PLL_LD3(id),         \
        REG_SPI_CLK_PLL_LOS1(id),        \
        REG_SPI_CLK_PLL_LOS2(id),        \
        REG_SPI_CLK_PLL_MOSI(id),        \
        REG_SPI_CLK_PLL_MISO(id),        \
        REG_SPI_CLK_PLL_SCK(id),         \
        REG_SPI_CLK_PLL_DIR(id),         \
        REG_SPI_CLK_PLL_RST(id),         \
        REG_SPI_CLK_PLL_INT(id),         \
        REG_SPI_CLK_PLL_OE(id),          \
        REG_SPI_CLK_PLL_PD(id)           \

/*****************本振 LO PLL*****************************/
#define REG_SPI_LO_PLL_CE_TX(id)        REG_SPI_CE_LO_PLL_TX##id   /*片选*/
#define REG_SPI_LO_PLL_SE_TX(id)        REG_SPI_LE_LO_PLL_TX##id   /*LO 输出使能*/
#define REG_SPI_LO_PLL_LD_TX(id)        REG_SPI_LD_LO_PLL_TX##id   /*LD LO 锁定*/
#define REG_SPI_LO_PLL_PD_TX(id)        REG_SPI_PD_LO_PLL_TX##id   /*PD LO 电源供电使能 */
#define REG_SPI_LO_PLL_RST_TX(id)       REG_SPI_RST_LO_PLL_TX##id  /* LO RST */
#define REG_SPI_LO_PLL_MUXOUT_TX(id)    REG_SPI_MUXOUT_LO_PLL_TX##id  /* LO MuxOut */
#define REG_SPI_LO_PLL_MOSI_TX(id)      REG_SPI_MOSI_LO_PLL_TX##id
#define REG_SPI_LO_PLL_MISO_TX(id)      REG_SPI_MISO_LO_PLL_TX##id
#define REG_SPI_LO_PLL_SCK_TX(id)       REG_SPI_SCK_LO_PLL_TX##id
#define REG_SPI_LO_PLL_DIR_TX(id)       REG_SPI_DIR_LO_PLL_TX##id
    
#define REG_SPI_LO_PLL_CE_RX(id)        REG_SPI_CE_LO_PLL_RX##id   /*CE LO 片选*/
#define REG_SPI_LO_PLL_SE_RX(id)        REG_SPI_LE_LO_PLL_RX##id   /*SE LO 输出使能*/
#define REG_SPI_LO_PLL_LD_RX(id)        REG_SPI_LD_LO_PLL_RX##id   /*LD LO 锁定*/
#define REG_SPI_LO_PLL_PD_RX(id)        REG_SPI_PD_LO_PLL_RX##id   /*PD LO 电源供电使能 */
#define REG_SPI_LO_PLL_RST_RX(id)       REG_SPI_RST_LO_PLL_RX##id  /* LO RST */
#define REG_SPI_LO_PLL_MUXOUT_RX(id)    REG_SPI_MUXOUT_LO_PLL_RX##id  /* LO MUXOUT */
#define REG_SPI_LO_PLL_MOSI_RX(id)      REG_SPI_MOSI_LO_PLL_RX##id
#define REG_SPI_LO_PLL_MISO_RX(id)      REG_SPI_MISO_LO_PLL_RX##id
#define REG_SPI_LO_PLL_SCK_RX(id)       REG_SPI_SCK_LO_PLL_RX##id
#define REG_SPI_LO_PLL_DIR_RX(id)       REG_SPI_DIR_LO_PLL_RX##id

#define REG_SPI_LO_PLL_CE_FB(id)        REG_SPI_CE_LO_PLL_FB##id   /*CE LO 片选*/
#define REG_SPI_LO_PLL_SE_FB(id)        REG_SPI_LE_LO_PLL_FB##id   /*SE LO 输出使能*/
#define REG_SPI_LO_PLL_LD_FB(id)        REG_SPI_LD_LO_PLL_FB##id   /*LD LO 锁定*/
#define REG_SPI_LO_PLL_PD_FB(id)        REG_SPI_PD_LO_PLL_FB##id   /*PD LO 电源供电使能 */
#define REG_SPI_LO_PLL_RST_FB(id)       REG_SPI_RST_LO_PLL_FB##id  /* LO RST */
#define REG_SPI_LO_PLL_MUXOUT_FB(id)    REG_SPI_MUXOUT_LO_PLL_FB##id  /* LO MUXOUT */
#define REG_SPI_LO_PLL_MOSI_FB(id)      REG_SPI_MOSI_LO_PLL_FB##id
#define REG_SPI_LO_PLL_MISO_FB(id)      REG_SPI_MISO_LO_PLL_FB##id
#define REG_SPI_LO_PLL_SCK_FB(id)       REG_SPI_SCK_LO_PLL_FB##id
#define REG_SPI_LO_PLL_DIR_FB(id)       REG_SPI_DIR_LO_PLL_FB##id
    
#define REG_SPI_FPGA3_CS(id)          REG_SPI_FPGA3_CS##id
#define REG_SPI_FPGA3_SCK(id)         REG_SPI_FPGA3_SCK##id    
#define REG_SPI_FPGA3_MISO(id)        REG_SPI_FPGA3_MISO##id
#define REG_SPI_FPGA3_MOSI(id)        REG_SPI_FPGA3_MOSI##id
#define REG_SPI_FPGA3_DIR(id)         REG_SPI_FPGA3_DIR##id

#define REG_PIN_SPI_LO_PLL_TX(id)                           \
        REG_SPI_LO_PLL_CE_TX(id),    /*CE LO 片选*/         \
        REG_SPI_LO_PLL_SE_TX(id),    /*SE LO 输出使能*/     \
        REG_SPI_LO_PLL_LD_TX(id),    /*LD LO 锁定*/         \
        REG_SPI_LO_PLL_PD_TX(id),    /*PD LO 电源供电使能 */\
        REG_SPI_LO_PLL_RST_TX(id),   /* LO RST */           \
        REG_SPI_LO_PLL_MUXOUT_TX(id),   /* LO MUXOUT*/      \
        REG_SPI_LO_PLL_MOSI_TX(id),                         \
        REG_SPI_LO_PLL_MISO_TX(id),                         \
        REG_SPI_LO_PLL_SCK_TX(id),                          \
        REG_SPI_LO_PLL_DIR_TX(id)                           \
        
#define REG_PIN_SPI_LO_PLL_RX(id)                           \
        REG_SPI_LO_PLL_CE_RX(id),    /*CE LO 片选*/         \
        REG_SPI_LO_PLL_SE_RX(id),    /*SE LO 输出使能*/     \
        REG_SPI_LO_PLL_LD_RX(id),    /*LD LO 锁定*/         \
        REG_SPI_LO_PLL_PD_RX(id),    /*PD LO 电源供电使能 */\
        REG_SPI_LO_PLL_RST_RX(id),   /* LO RST */           \
        REG_SPI_LO_PLL_MUXOUT_RX(id),   /* LO MUXOUT */     \
        REG_SPI_LO_PLL_MOSI_RX(id),                         \
        REG_SPI_LO_PLL_MISO_RX(id),                         \
        REG_SPI_LO_PLL_SCK_RX(id),                          \
        REG_SPI_LO_PLL_DIR_RX(id)                           \

#define REG_PIN_SPI_LO_PLL_FB(id)                           \
        REG_SPI_LO_PLL_CE_FB(id),    /*CE LO 片选*/         \
        REG_SPI_LO_PLL_SE_FB(id),    /*SE LO 输出使能*/     \
        REG_SPI_LO_PLL_LD_FB(id),    /*LD LO 锁定*/         \
        REG_SPI_LO_PLL_PD_FB(id),    /*PD LO 电源供电使能 */\
        REG_SPI_LO_PLL_RST_FB(id),   /* LO RST */           \
        REG_SPI_LO_PLL_MUXOUT_FB(id),   /* LO MUXOUT */     \
        REG_SPI_LO_PLL_MOSI_FB(id),                         \
        REG_SPI_LO_PLL_MISO_FB(id),                         \
        REG_SPI_LO_PLL_SCK_FB(id),                          \
        REG_SPI_LO_PLL_DIR_FB(id)                           \

/*****************EPLD(PA) *****************************/
#define REG_SPI_EPLD_RST(id)            REG_SPI_RST_EPLD##id   
#define REG_SPI_EPLD_CS(id)             REG_SPI_CS_EPLD##id   
#define REG_SPI_EPLD_MOSI(id)           REG_SPI_MOSI_EPLD##id
#define REG_SPI_EPLD_MISO(id)           REG_SPI_MISO_EPLD##id
#define REG_SPI_EPLD_SCK(id)            REG_SPI_SCK_EPLD##id
#define REG_SPI_EPLD_DIR(id)            REG_SPI_DIR_EPLD##id

#define REG_PIN_SPI_EPLD(id)            \
        REG_SPI_EPLD_RST(id),           \
        REG_SPI_EPLD_CS(id),            \
        REG_SPI_EPLD_MOSI(id),          \
        REG_SPI_EPLD_MISO(id),          \
        REG_SPI_EPLD_SCK(id),           \
        REG_SPI_EPLD_DIR(id)            \

    
/*****************DAC *****************************/
    
#define REG_SPI_DAC_RST_TX(id)          REG_SPI_RST_DAC_TX##id   
#define REG_SPI_DAC_TXEN_TX(id)         REG_SPI_TXEN_DAC_TX##id   
#define REG_SPI_DAC_POWDOWN_TX(id)      REG_SPI_POWDOWN_DAC_TX##id   
#define REG_SPI_DAC_CS_TX(id)           REG_SPI_CS_DAC_TX##id   
#define REG_SPI_DAC_MOSI_TX(id)         REG_SPI_MOSI_DAC_TX##id
#define REG_SPI_DAC_MISO_TX(id)         REG_SPI_MISO_DAC_TX##id
#define REG_SPI_DAC_SCK_TX(id)          REG_SPI_SCK_DAC_TX##id
#define REG_SPI_DAC_DIR_TX(id)          REG_SPI_DIR_DAC_TX##id
#define REG_SPI_DAC_ALAMR_TX(id)        REG_SPI_ALAMR_DAC_TX##id
    
#define REG_PIN_SPI_DAC_TX(id)                      \
        REG_SPI_DAC_RST_TX(id),                         \
        REG_SPI_DAC_TXEN_TX(id),                        \
        REG_SPI_DAC_POWDOWN_TX(id),                     \
        REG_SPI_DAC_CS_TX(id),                          \
        REG_SPI_DAC_MOSI_TX(id),                        \
        REG_SPI_DAC_MISO_TX(id),                        \
        REG_SPI_DAC_SCK_TX(id),                         \
        REG_SPI_DAC_DIR_TX(id),                         \
        REG_SPI_DAC_ALAMR_TX(id)                        \

#define REG_SPI_TEMP_RST(id)          REG_SPI_TEMP_RST##id
#define REG_SPI_TEMP_CS(id)           REG_SPI_TEMP_CS##id
#define REG_SPI_TEMP_EN(id)           REG_SPI_TEMP_EN##id

#define REG_PIN_SPI_TEMP(id)                      \
        REG_SPI_TEMP_RST(id),                         \
        REG_SPI_TEMP_CS(id),                          \
        REG_SPI_TEMP_EN(id)                          \

/*****************DAC GRIDVOLT*****************************/
    
#define REG_SPI_DAC_GRIDVOLT_RST_TX(id)          REG_SPI_RST_DAC_GRIDVOLT_TX##id   
#define REG_SPI_DAC_GRIDVOLT_TXEN_TX(id)         REG_SPI_TXEN_DAC_GRIDVOLT_TX##id   
#define REG_SPI_DAC_GRIDVOLT_POWDOWN_TX(id)      REG_SPI_POWDOWN_DAC_GRIDVOLT_TX##id   
#define REG_SPI_DAC_GRIDVOLT_CS_TX(id)           REG_SPI_CS_DAC_GRIDVOLT_TX##id   
#define REG_SPI_DAC_GRIDVOLT_MOSI_TX(id)         REG_SPI_MOSI_DAC_GRIDVOLT_TX##id
#define REG_SPI_DAC_GRIDVOLT_MISO_TX(id)         REG_SPI_MISO_DAC_GRIDVOLT_TX##id
#define REG_SPI_DAC_GRIDVOLT_SCK_TX(id)          REG_SPI_SCK_DAC_GRIDVOLT_TX##id
#define REG_SPI_DAC_GRIDVOLT_DIR_TX(id)          REG_SPI_DIR_DAC_GRIDVOLT_TX##id
#define REG_SPI_DAC_GRIDVOLT_ALAMR_TX(id)        REG_SPI_ALAMR_DAC_GRIDVOLT_TX##id
    
#define REG_PIN_SPI_DAC_GRIDVOLT_TX(id)                      \
        REG_SPI_DAC_GRIDVOLT_RST_TX(id),                         \
        REG_SPI_DAC_GRIDVOLT_TXEN_TX(id),                        \
        REG_SPI_DAC_GRIDVOLT_POWDOWN_TX(id),                     \
        REG_SPI_DAC_GRIDVOLT_CS_TX(id),                          \
        REG_SPI_DAC_GRIDVOLT_MOSI_TX(id),                        \
        REG_SPI_DAC_GRIDVOLT_MISO_TX(id),                        \
        REG_SPI_DAC_GRIDVOLT_SCK_TX(id),                         \
        REG_SPI_DAC_GRIDVOLT_DIR_TX(id),                         \
        REG_SPI_DAC_GRIDVOLT_ALAMR_TX(id)                        \


/*****************DAC GRIDVOLT*****************************/
    
#define REG_SPI_DAC_GRIDVOLT_RST_RX(id)          REG_SPI_RST_DAC_GRIDVOLT_RX##id   
#define REG_SPI_DAC_GRIDVOLT_RXEN_RX(id)         REG_SPI_RXEN_DAC_GRIDVOLT_RX##id   
#define REG_SPI_DAC_GRIDVOLT_POWDOWN_RX(id)      REG_SPI_POWDOWN_DAC_GRIDVOLT_RX##id   
#define REG_SPI_DAC_GRIDVOLT_CS_RX(id)           REG_SPI_CS_DAC_GRIDVOLT_RX##id   
#define REG_SPI_DAC_GRIDVOLT_MOSI_RX(id)         REG_SPI_MOSI_DAC_GRIDVOLT_RX##id
#define REG_SPI_DAC_GRIDVOLT_MISO_RX(id)         REG_SPI_MISO_DAC_GRIDVOLT_RX##id
#define REG_SPI_DAC_GRIDVOLT_SCK_RX(id)          REG_SPI_SCK_DAC_GRIDVOLT_RX##id
#define REG_SPI_DAC_GRIDVOLT_DIR_RX(id)          REG_SPI_DIR_DAC_GRIDVOLT_RX##id
#define REG_SPI_DAC_GRIDVOLT_ALAMR_RX(id)        REG_SPI_ALAMR_DAC_GRIDVOLT_RX##id
    
#define REG_PIN_SPI_DAC_GRIDVOLT_RX(id)                      \
        REG_SPI_DAC_GRIDVOLT_RST_RX(id),                         \
        REG_SPI_DAC_GRIDVOLT_RXEN_RX(id),                        \
        REG_SPI_DAC_GRIDVOLT_POWDOWN_RX(id),                     \
        REG_SPI_DAC_GRIDVOLT_CS_RX(id),                          \
        REG_SPI_DAC_GRIDVOLT_MOSI_RX(id),                        \
        REG_SPI_DAC_GRIDVOLT_MISO_RX(id),                        \
        REG_SPI_DAC_GRIDVOLT_SCK_RX(id),                         \
        REG_SPI_DAC_GRIDVOLT_DIR_RX(id),                         \
        REG_SPI_DAC_GRIDVOLT_ALAMR_RX(id)                        \

/***************** TX DATT *****************************/
#define REG_SPI_DATT_CS_TX(id)           REG_SPI_CS_DATT_TX##id   
#define REG_SPI_DATT_MOSI_TX(id)         REG_SPI_MOSI_DATT_TX##id
#define REG_SPI_DATT_MISO_TX(id)         REG_SPI_MISO_DATT_TX##id
#define REG_SPI_DATT_SCK_TX(id)          REG_SPI_SCK_DATT_TX##id
#define REG_SPI_DATT_DIR_TX(id)          REG_SPI_DIR_DATT_TX##id
    
#define REG_PIN_SPI_DATT_TX(id)                      \
        REG_SPI_DATT_CS_TX(id),                      \
        REG_SPI_DATT_MOSI_TX(id),                    \
        REG_SPI_DATT_MISO_TX(id),                    \
        REG_SPI_DATT_SCK_TX(id),                     \
        REG_SPI_DATT_DIR_TX(id)                      \

/***************** RX DATT *****************************/
#define REG_SPI_DATT_CS_RX(id)           REG_SPI_CS_DATT_RX##id   
#define REG_SPI_DATT_MOSI_RX(id)         REG_SPI_MOSI_DATT_RX##id
#define REG_SPI_DATT_MISO_RX(id)         REG_SPI_MISO_DATT_RX##id
#define REG_SPI_DATT_SCK_RX(id)          REG_SPI_SCK_DATT_RX##id
#define REG_SPI_DATT_DIR_RX(id)          REG_SPI_DIR_DATT_RX##id
    
#define REG_PIN_SPI_DATT_RX(id)                      \
        REG_SPI_DATT_CS_RX(id),                      \
        REG_SPI_DATT_MOSI_RX(id),                    \
        REG_SPI_DATT_MISO_RX(id),                    \
        REG_SPI_DATT_SCK_RX(id),                     \
        REG_SPI_DATT_DIR_RX(id)                      \
        
/***************** TX DVGA *****************************/
#define REG_SPI_DVGA_CS_TX(id)           REG_SPI_CS_DVGA_TX##id   
#define REG_SPI_DVGA_MOSI_TX(id)         REG_SPI_MOSI_DVGA_TX##id
#define REG_SPI_DVGA_MISO_TX(id)         REG_SPI_MISO_DVGA_TX##id
#define REG_SPI_DVGA_SCK_TX(id)          REG_SPI_SCK_DVGA_TX##id
#define REG_SPI_DVGA_DIR_TX(id)          REG_SPI_DIR_DVGA_TX##id
    
#define REG_PIN_SPI_DVGA_TX(id)                      \
        REG_SPI_DVGA_CS_TX(id),                      \
        REG_SPI_DVGA_MOSI_TX(id),                    \
        REG_SPI_DVGA_MISO_TX(id),                    \
        REG_SPI_DVGA_SCK_TX(id),                     \
        REG_SPI_DVGA_DIR_TX(id)                      \

/***************** RX DVGA *****************************/
#define REG_SPI_DVGA_CS_RX(id)           REG_SPI_CS_DVGA_RX##id   
#define REG_SPI_DVGA_MOSI_RX(id)         REG_SPI_MOSI_DVGA_RX##id
#define REG_SPI_DVGA_MISO_RX(id)         REG_SPI_MISO_DVGA_RX##id
#define REG_SPI_DVGA_SCK_RX(id)          REG_SPI_SCK_DVGA_RX##id
#define REG_SPI_DVGA_DIR_RX(id)          REG_SPI_DIR_DVGA_RX##id
    
#define REG_PIN_SPI_DVGA_RX(id)                      \
        REG_SPI_DVGA_CS_RX(id),                      \
        REG_SPI_DVGA_MOSI_RX(id),                    \
        REG_SPI_DVGA_MISO_RX(id),                    \
        REG_SPI_DVGA_SCK_RX(id),                     \
        REG_SPI_DVGA_DIR_RX(id)                      \
/***************************** ADC *****************************/
    
#define REG_SPI_ADC_RST_RX(id)          REG_SPI_RST_ADC_RX##id   
#define REG_SPI_ADC_POWDOWN_RX(id)      REG_SPI_POWDOWN_ADC_RX##id   
#define REG_SPI_ADC_CS_RX(id)           REG_SPI_CS_ADC_RX##id   
#define REG_SPI_ADC_MOSI_RX(id)         REG_SPI_MOSI_ADC_RX##id
#define REG_SPI_ADC_MISO_RX(id)         REG_SPI_MISO_ADC_RX##id
#define REG_SPI_ADC_SCK_RX(id)          REG_SPI_SCK_ADC_RX##id
#define REG_SPI_ADC_DIR_RX(id)          REG_SPI_DIR_ADC_RX##id
    
#define REG_SPI_ADC_RST_PRX(id)         REG_SPI_RST_ADC_PRX##id   
#define REG_SPI_ADC_POWDOWN_PRX(id)     REG_SPI_POWDOWN_ADC_PRX##id   
#define REG_SPI_ADC_CS_PRX(id)          REG_SPI_CS_ADC_PRX##id   
#define REG_SPI_ADC_MOSI_PRX(id)        REG_SPI_MOSI_ADC_PRX##id
#define REG_SPI_ADC_MISO_PRX(id)        REG_SPI_MISO_ADC_PRX##id
#define REG_SPI_ADC_SCK_PRX(id)         REG_SPI_SCK_ADC_PRX##id
#define REG_SPI_ADC_DIR_PRX(id)         REG_SPI_DIR_ADC_PRX##id
    
#define REG_PIN_SPI_ADC_RX(id)                          \
        REG_SPI_ADC_RST_RX(id),                         \
        REG_SPI_ADC_POWDOWN_RX(id),                     \
        REG_SPI_ADC_CS_RX(id),                          \
        REG_SPI_ADC_MOSI_RX(id),                        \
        REG_SPI_ADC_MISO_RX(id),                        \
        REG_SPI_ADC_SCK_RX(id),                         \
        REG_SPI_ADC_DIR_RX(id)                          \
    
#define REG_PIN_SPI_ADC_PRX(id)                          \
        REG_SPI_ADC_RST_PRX(id),                         \
        REG_SPI_ADC_POWDOWN_PRX(id),                     \
        REG_SPI_ADC_CS_PRX(id),                          \
        REG_SPI_ADC_MOSI_PRX(id),                        \
        REG_SPI_ADC_MISO_PRX(id),                        \
        REG_SPI_ADC_SCK_PRX(id),                         \
        REG_SPI_ADC_DIR_PRX(id)                          \
    
    
/************************* TRANSIVER ************************************/
#define REG_SPI_TRANSIVER_CS(id)          REG_SPI_CS_TRANSIVER##id   
#define REG_SPI_TRANSIVER_RST(id)         REG_SPI_RST_TRANSIVER##id 
#define REG_SPI_TRANSIVER_TXEN(id)        REG_SPI_TX0EN_TRANSIVER##id   
//#define REG_SPI_TRANSIVER_EN(id)        REG_SPI_TX1EN_TRANSIVER##id
#define REG_SPI_TRANSIVER_RX0EN(id)       REG_SPI_RX0EN_TRANSIVER##id   
#define REG_SPI_TRANSIVER_RX1EN(id)       REG_SPI_RX1EN_TRANSIVER##id   
#define REG_SPI_TRANSIVER_SYSREF(id)      REG_SPI_SYSREF_TRANSIVER##id  
#define REG_SPI_TRANSIVER_MOSI(id)        REG_SPI_MOSI_TRANSIVER##id         
#define REG_SPI_TRANSIVER_MISO(id)        REG_SPI_MISO_TRANSIVER##id 
#define REG_SPI_TRANSIVER_SCK(id)         REG_SPI_SCK_TRANSIVER##id
#define REG_SPI_TRANSIVER_DIR(id)         REG_SPI_DIR_TRANSIVER##id

    
#define REG_PIN_SPI_TRANSIVER(id)                      \
        REG_SPI_TRANSIVER_CS(id),                      \
        REG_SPI_TRANSIVER_RST(id),                     \
        REG_SPI_TRANSIVER_TXEN(id),                    \
        REG_SPI_TRANSIVER_RX0EN(id),                   \
        REG_SPI_TRANSIVER_RX1EN(id),                   \
        REG_SPI_TRANSIVER_SYSREF(id),                  \
        REG_SPI_TRANSIVER_MOSI(id),                    \
        REG_SPI_TRANSIVER_MISO(id),                    \
        REG_SPI_TRANSIVER_SCK(id),                     \
        REG_SPI_TRANSIVER_DIR(id)                      \

/************************* CLK BUFFER ************************************/

#define REG_SPI_BUFFER_CS(id)          REG_SPI_CS_BUFFER##id 
#define REG_SPI_BUFFER_CLK(id)         REG_SPI_CLK_BUFFER##id  
#define REG_SPI_BUFFER_MOSI(id)        REG_SPI_MOSI_BUFFER##id    
#define REG_SPI_BUFFER_MISO(id)        REG_SPI_MISO_BUFFER##id   
#define REG_SPI_BUFFER_DIR(id)         REG_SPI_DIR_BUFFER##id     
#define REG_SPI_BUFFER_CE(id)          REG_SPI_CE_BUFFER##id   
 
/* S680 */
#define REG_PIN_SPI_BUFFER(id)                  \
    REG_SPI_BUFFER_CS(id),                      \
    REG_SPI_BUFFER_CLK(id),                     \
    REG_SPI_BUFFER_MOSI(id),                    \
    REG_SPI_BUFFER_MISO(id),                    \
    REG_SPI_BUFFER_DIR(id),                     \
    REG_SPI_BUFFER_CE(id)
    
/************************* TXATT ************************************/
#define REG_PIN_SPI_RFATT_TX(id)                \
    REG_PIN_SPI_RFATT_CS_TX(id)                \

#define REG_PIN_SPI_RFATT_CS_TX(id)   REG_SPI_CS_RFDATT_TX##id

/************************* RXATT ************************************/
#define REG_PIN_SPI_RFATT_RX(id)                \
    REG_PIN_SPI_RFATT_CS_RX(id)                 \
    

#define REG_PIN_SPI_RFATT_CS_RX(id)   REG_SPI_CS_RFDATT_RX##id

/************************* PRXATT ************************************/
#define REG_PIN_SPI_RFATT_PRX(id)                \
    REG_PIN_SPI_RFATT_CS_PRX(id)                 \
    
#define REG_PIN_SPI_RFATT_CS_PRX(id)   REG_SPI_CS_RFDATT_PRX##id

/************************* PRXVGA ************************************/
#define REG_PIN_SPI_RFVGA_PRX(id)                \
    REG_PIN_SPI_RFVGA_CS_PRX(id)                 \
    
#define REG_PIN_SPI_RFVGA_CS_PRX(id)   REG_SPI_CS_RFVGA_PRX##id
/************************* TXVGA************************************/
#define REG_PIN_SPI_RFVGA_TX(id)                \
    REG_PIN_SPI_RFVGA_CS_TX(id),                 \
    REG_PIN_SPI_RFVGA_FA_TX(id)                 \
    
#define REG_PIN_SPI_RFVGA_CS_TX(id)   REG_SPI_CS_RFVGA_TX##id
#define REG_PIN_SPI_RFVGA_FA_TX(id)   REG_SPI_FA_RFVGA_TX##id
/************************* RXVGA************************************/  
#define REG_PIN_SPI_RFVGA_RX(id)                \
    REG_PIN_SPI_RFVGA_CS_RX(id)                 \

#define REG_PIN_SPI_RFVGA_CS_RX(id)   REG_SPI_CS_RFVGA_RX##id    
/***************************** CONVERTER *****************************/
    
#define REG_SPI_CONVERTER_RST_RX(id)          REG_SPI_RST_CONVERTER_RX##id   
#define REG_SPI_CONVERTER_POWDOWN_RX(id)      REG_SPI_POWDOWN_CONVERTER_RX##id   
#define REG_SPI_CONVERTER_CS_RX(id)           REG_SPI_CS_CONVERTER_RX##id   
#define REG_SPI_CONVERTER_MOSI_RX(id)         REG_SPI_MOSI_CONVERTER_RX##id
#define REG_SPI_CONVERTER_MISO_RX(id)         REG_SPI_MISO_CONVERTER_RX##id
#define REG_SPI_CONVERTER_SCK_RX(id)          REG_SPI_SCK_CONVERTER_RX##id
#define REG_SPI_CONVERTER_DIR_RX(id)          REG_SPI_DIR_CONVERTER_RX##id
    
#define REG_SPI_CONVERTER_RST_TX(id)         REG_SPI_RST_CONVERTER_TX##id   
#define REG_SPI_CONVERTER_POWDOWN_TX(id)     REG_SPI_POWDOWN_CONVERTER_TX##id   
#define REG_SPI_CONVERTER_CS_TX(id)          REG_SPI_CS_CONVERTER_TX##id   
#define REG_SPI_CONVERTER_MOSI_TX(id)        REG_SPI_MOSI_CONVERTER_TX##id
#define REG_SPI_CONVERTER_MISO_TX(id)        REG_SPI_MISO_CONVERTER_TX##id
#define REG_SPI_CONVERTER_SCK_TX(id)         REG_SPI_SCK_CONVERTER_TX##id
#define REG_SPI_CONVERTER_DIR_TX(id)         REG_SPI_DIR_CONVERTER_TX##id
    
#define REG_PIN_SPI_CONVERTER_RX(id)                          \
        REG_SPI_CONVERTER_RST_RX(id),                         \
        REG_SPI_CONVERTER_POWDOWN_RX(id),                     \
        REG_SPI_CONVERTER_CS_RX(id),                          \
        REG_SPI_CONVERTER_MOSI_RX(id),                        \
        REG_SPI_CONVERTER_MISO_RX(id),                        \
        REG_SPI_CONVERTER_SCK_RX(id),                         \
        REG_SPI_CONVERTER_DIR_RX(id)                          \
    
#define REG_PIN_SPI_CONVERTER_TX(id)                          \
        REG_SPI_CONVERTER_RST_TX(id),                         \
        REG_SPI_CONVERTER_POWDOWN_TX(id),                     \
        REG_SPI_CONVERTER_CS_TX(id),                          \
        REG_SPI_CONVERTER_MOSI_TX(id),                        \
        REG_SPI_CONVERTER_MISO_TX(id),                        \
        REG_SPI_CONVERTER_SCK_TX(id),                         \
        REG_SPI_CONVERTER_DIR_TX(id)                          \


/***************************** SHIFTER *****************************/
    
#define REG_SPI_SHIFTER_RST_RX(id)          REG_SPI_RST_SHIFTER_RX##id   
#define REG_SPI_SHIFTER_POWDOWN_RX(id)      REG_SPI_POWDOWN_SHIFTER_RX##id   
#define REG_SPI_SHIFTER_CS_RX(id)           REG_SPI_CS_SHIFTER_RX##id   
#define REG_SPI_SHIFTER_MOSI_RX(id)         REG_SPI_MOSI_SHIFTER_RX##id
#define REG_SPI_SHIFTER_MISO_RX(id)         REG_SPI_MISO_SHIFTER_RX##id
#define REG_SPI_SHIFTER_SCK_RX(id)          REG_SPI_SCK_SHIFTER_RX##id
#define REG_SPI_SHIFTER_DIR_RX(id)          REG_SPI_DIR_SHIFTER_RX##id
    
#define REG_SPI_SHIFTER_RST_TX(id)         REG_SPI_RST_SHIFTER_TX##id   
#define REG_SPI_SHIFTER_POWDOWN_TX(id)     REG_SPI_POWDOWN_SHIFTER_TX##id   
#define REG_SPI_SHIFTER_CS_TX(id)          REG_SPI_CS_SHIFTER_TX##id   
#define REG_SPI_SHIFTER_MOSI_TX(id)        REG_SPI_MOSI_SHIFTER_TX##id
#define REG_SPI_SHIFTER_MISO_TX(id)        REG_SPI_MISO_SHIFTER_TX##id
#define REG_SPI_SHIFTER_SCK_TX(id)         REG_SPI_SCK_SHIFTER_TX##id
#define REG_SPI_SHIFTER_DIR_TX(id)         REG_SPI_DIR_SHIFTER_TX##id
    
#define REG_PIN_SPI_SHIFTER_RX(id)                          \
        REG_SPI_SHIFTER_RST_RX(id),                         \
        REG_SPI_SHIFTER_POWDOWN_RX(id),                     \
        REG_SPI_SHIFTER_CS_RX(id),                          \
        REG_SPI_SHIFTER_MOSI_RX(id),                        \
        REG_SPI_SHIFTER_MISO_RX(id),                        \
        REG_SPI_SHIFTER_SCK_RX(id),                         \
        REG_SPI_SHIFTER_DIR_RX(id)                          \
    
#define REG_PIN_SPI_SHIFTER_TX(id)                          \
        REG_SPI_SHIFTER_RST_TX(id),                         \
        REG_SPI_SHIFTER_POWDOWN_TX(id),                     \
        REG_SPI_SHIFTER_CS_TX(id),                          \
        REG_SPI_SHIFTER_MOSI_TX(id),                        \
        REG_SPI_SHIFTER_MISO_TX(id),                        \
        REG_SPI_SHIFTER_SCK_TX(id),                         \
        REG_SPI_SHIFTER_DIR_TX(id)                          \
    

/***************************** VVA *****************************/
    
#define REG_SPI_VVA_RST(id)          REG_SPI_VVA_RST##id   
#define REG_SPI_VVA_POWDOWN(id)      REG_SPI_VVA_POWDOWN##id   
#define REG_SPI_VVA_CS(id)           REG_SPI_VVA_CS##id   
#define REG_SPI_VVA_MOSI(id)         REG_SPI_VVA_MOSI##id
#define REG_SPI_VVA_MISO(id)         REG_SPI_VVA_MISO##id
#define REG_SPI_VVA_SCK(id)          REG_SPI_VVA_SCK##id
#define REG_SPI_VVA_DIR(id)          REG_SPI_VVA_DIR##id
    

    
#define REG_PIN_SPI_VVA(id)                          \
        REG_SPI_VVA_RST(id),                         \
        REG_SPI_VVA_POWDOWN(id),                     \
        REG_SPI_VVA_CS(id),                          \
        REG_SPI_VVA_MOSI(id),                        \
        REG_SPI_VVA_MISO(id),                        \
        REG_SPI_VVA_SCK(id),                         \
        REG_SPI_VVA_DIR(id)                          \
    




/***************************** RFEM *****************************/
    
#define REG_SPI_RFEM_RST(id)          REG_SPI_RFEM_RST##id   
#define REG_SPI_RFEM_POWDOWN(id)      REG_SPI_RFEM_POWDOWN##id   
#define REG_SPI_RFEM_CS(id)           REG_SPI_RFEM_CS##id   
#define REG_SPI_RFEM_MOSI(id)         REG_SPI_RFEM_MOSI##id
#define REG_SPI_RFEM_MISO(id)         REG_SPI_RFEM_MISO##id
#define REG_SPI_RFEM_SCK(id)          REG_SPI_RFEM_SCK##id
#define REG_SPI_RFEM_DIR(id)          REG_SPI_RFEM_DIR##id
    
#define REG_PIN_SPI_RFEM(id)                          \
        REG_SPI_RFEM_RST(id),                         \
        REG_SPI_RFEM_POWDOWN(id),                     \
        REG_SPI_RFEM_CS(id),                          \
        REG_SPI_RFEM_MOSI(id),                        \
        REG_SPI_RFEM_MISO(id),                        \
        REG_SPI_RFEM_SCK(id),                         \
        REG_SPI_RFEM_DIR(id)                          \
    
/***************** board FLASH *****************************/
#define REG_SPI_FLASH_CS(id)           REG_SPI_CS_FLASH##id   
#define REG_SPI_FLASH_MOSI(id)         REG_SPI_MOSI_FLASH##id
#define REG_SPI_FLASH_MISO(id)         REG_SPI_MISO_FLASH##id
#define REG_SPI_FLASH_SCK(id)          REG_SPI_SCK_FLASH##id
#define REG_SPI_FLASH_DIR(id)          REG_SPI_DIR_FLASH##id
#define REG_SPI_FLASH_WP(id)           REG_SPI_WP_FLASH##id
#define REG_SPI_FLASH_RESET(id)        REG_SPI_RESET_FLASH##id
    
#define REG_PIN_SPI_FLASH(id)                      \
        REG_SPI_FLASH_CS(id),                      \
        REG_SPI_FLASH_MOSI(id),                    \
        REG_SPI_FLASH_MISO(id),                    \
        REG_SPI_FLASH_SCK(id),                     \
        REG_SPI_FLASH_DIR(id),                      \
        REG_SPI_FLASH_WP(id),                       \
        REG_SPI_FLASH_RESET(id)                      \


#define REG_SPI_FPGA_LOAD_CS(id)          REG_SPI_CS_FPGA_LOAD##id 
#define REG_SPI_FPGA_LOAD_CLK(id)         REG_SPI_CLK_FPGA_LOAD##id  
#define REG_SPI_FPGA_LOAD_DIR(id)         REG_SPI_DIR_FPGA_LOAD##id    
#define REG_SPI_FPGA_LOAD_SET_DATA(id)    REG_SPI_SET_DATA_FPGA_LOAD##id   
#define REG_SPI_FPGA_LOAD_UNLOCK(id)      REG_SPI_UNLOCK_FPGA_LOAD##id     
#define REG_SPI_FPGA_LOAD_LOCK(id)        REG_SPI_LOCK_FPGA_LOAD##id  
#define REG_SPI_FPGA_LOAD_DIN(id)         REG_SPI_DIN_FPGA_LOAD##id 
#define REG_SPI_FPGA_LOAD_CFG(id)         REG_SPI_CFG_FPGA_LOAD##id  
#define REG_SPI_FPGA_LOAD_CFG_DONE(id)    REG_SPI_CFG_DONE_FPGA_LOAD##id    
#define REG_SPI_FPGA_LOAD_STATUS(id)      REG_SPI_STATUS_FPGA_LOAD##id   
#define REG_SPI_FPGA_LOAD_GET_BUSY(id)    REG_SPI_GET_BUSY_LOAD##id     
#define REG_SPI_FPGA_LOAD_RESET(id)       REG_SPI_RESET_FPGA_LOAD##id 

 
#define REG_PIN_SPI_FPGALOAD(id)            \
    REG_SPI_FPGA_LOAD_CS(id),               \
    REG_SPI_FPGA_LOAD_CLK(id),              \
    REG_SPI_FPGA_LOAD_DIR(id),              \
    REG_SPI_FPGA_LOAD_SET_DATA(id),         \
    REG_SPI_FPGA_LOAD_UNLOCK(id),           \
    REG_SPI_FPGA_LOAD_LOCK(id),             \
    REG_SPI_FPGA_LOAD_DIN(id),              \
    REG_SPI_FPGA_LOAD_CFG(id),              \
    REG_SPI_FPGA_LOAD_CFG_DONE(id),         \
    REG_SPI_FPGA_LOAD_STATUS(id),           \
    REG_SPI_FPGA_LOAD_GET_BUSY(id),         \
    REG_SPI_FPGA_LOAD_RESET(id)             \


#define REG_SPI_DEVICE_MOSI(id)     REG_SPI_MOSI_DEVICE##id 
#define REG_SPI_DEVICE_MISO(id)     REG_SPI_MISO_DEVICE##id
#define REG_SPI_DEVICE_SCK(id)      REG_SPI_SCK_DEVICE##id 
#define REG_SPI_DEVICE_DIR(id)      REG_SPI_DIR_DEVICE##id  
#define REG_SPI_DEVICE_CS(id)       REG_SPI_CS_DEVICE##id  

#define REG_PIN_SPI_DEVICE(id)              \
    REG_SPI_DEVICE_MOSI(id),                \
    REG_SPI_DEVICE_MISO(id),                \
    REG_SPI_DEVICE_SCK(id),                 \
    REG_SPI_DEVICE_DIR(id),                 \
    REG_SPI_DEVICE_CS(id)                   \



#define REG_PIN_SPI_CS_EEPROM(id)   REG_SPI_CS_EEPROM##id


#define REG_PIN_SPI_EEPROM(id)              \
    REG_PIN_SPI_CS_EEPROM(id)               \



#define REG_IIC_SDI(name,id)                REG_IIC_##name##_SDI##id
#define REG_IIC_SDO(name,id)                REG_IIC_##name##_SDO##id
#define REG_IIC_SCL(name,id)                REG_IIC_##name##_SCL##id
#define REG_IIC_DIR(name,id)                REG_IIC_##name##_DIR##id


#define REG_PIN_IIC_SW_CTRL(id)                  \
    REG_IIC_SDI(SW,id),                     \
    REG_IIC_SDO(SW,id),                     \
    REG_IIC_SCL(SW,id),                     \
    REG_IIC_DIR(SW,id)


#define REG_PIN_IIC_PWR_CTRL(id)                  \
    REG_IIC_SDI(PWR_CTRL,id),                     \
    REG_IIC_SDO(PWR_CTRL,id),                     \
    REG_IIC_SCL(PWR_CTRL,id),                     \
    REG_IIC_DIR(PWR_CTRL,id)
#define REG_PIN_IIC_PA_EEPROM(id)                 \
    REG_IIC_SDI(PA_EEPROM,id),                    \
    REG_IIC_SDO(PA_EEPROM,id),                    \
    REG_IIC_SCL(PA_EEPROM,id),                    \
    REG_IIC_DIR(PA_EEPROM,id)

#define REG_PIN_IIC_BOARD_EEPROM(id)                 \
    REG_IIC_SDI(BOARD_EEPROM,id),                    \
    REG_IIC_SDO(BOARD_EEPROM,id),                    \
    REG_IIC_SCL(BOARD_EEPROM,id),                    \
    REG_IIC_DIR(BOARD_EEPROM,id)

#define REG_PIN_IIC_PWR(id)                 \
    REG_IIC_SDI(PWR,id),                    \
    REG_IIC_SDO(PWR,id),                    \
    REG_IIC_SCL(PWR,id),                    \
    REG_IIC_DIR(PWR,id)

#define REG_PIN_IIC_PWR_EEPROM(id)                 \
    REG_IIC_SDI(PWR_EEPROM,id),                    \
    REG_IIC_SDO(PWR_EEPROM,id),                    \
    REG_IIC_SCL(PWR_EEPROM,id),                    \
    REG_IIC_DIR(PWR_EEPROM,id)

#define REG_PIN_IIC_PWR_TEMP(id)                 \
    REG_IIC_SDI(PWR_TEMP,id),                    \
    REG_IIC_SDO(PWR_TEMP,id),                    \
    REG_IIC_SCL(PWR_TEMP,id),                    \
    REG_IIC_DIR(PWR_TEMP,id)


#define REG_PIN_IIC_PMB(id)                 \
    REG_IIC_SDI(PMB,id),                    \
    REG_IIC_SDO(PMB,id),                    \
    REG_IIC_SCL(PMB,id),                    \
    REG_IIC_DIR(PMB,id)

#define REG_PIN_IIC_SFP(id)                 \
    REG_IIC_SDI(SFP,id),                    \
    REG_IIC_SDO(SFP,id),                    \
    REG_IIC_SCL(SFP,id),                    \
    REG_IIC_DIR(SFP,id)

#define REG_PIN_IIC_FPGA_TEMP(id)                 \
    REG_IIC_SDI(FPGA_TEMP,id),                    \
    REG_IIC_SDO(FPGA_TEMP,id),                    \
    REG_IIC_SCL(FPGA_TEMP,id),                    \
    REG_IIC_DIR(FPGA_TEMP,id)


#define REG_PIN_IIC_PA_TEMP(id)                 \
    REG_IIC_SDI(PA_TEMP,id),                    \
    REG_IIC_SDO(PA_TEMP,id),                    \
    REG_IIC_SCL(PA_TEMP,id),                    \
    REG_IIC_DIR(PA_TEMP,id)


#define REG_PIN_IIC_DAC(id)                 \
    REG_IIC_SDI(DAC,id),                    \
    REG_IIC_SDO(DAC,id),                    \
    REG_IIC_SCL(DAC,id),                    \
    REG_IIC_DIR(DAC,id)
    
#define REG_PIN_IIC_BOARD_TEMP(id)          \
    REG_IIC_SDI(BOARD_TEMP,id),           \
    REG_IIC_SDO(BOARD_TEMP,id),           \
    REG_IIC_SCL(BOARD_TEMP,id),           \
    REG_IIC_DIR(BOARD_TEMP,id)

#define REG_PIN_IIC_BOARD_PWR(id)          \
    REG_IIC_SDI(BOARD_PWR,id),           \
    REG_IIC_SDO(BOARD_PWR,id),           \
    REG_IIC_SCL(BOARD_PWR,id),           \
    REG_IIC_DIR(BOARD_PWR,id)

#define REG_PIN_IIC_ADC(id)                 \
    REG_IIC_SDI(ADC,id),                    \
    REG_IIC_SDO(ADC,id),                    \
    REG_IIC_SCL(ADC,id),                    \
    REG_IIC_DIR(ADC,id)

#define REG_PIN_IIC_HUMIDITY(id)                 \
    REG_IIC_SDI(HUMIDITY,id),                    \
    REG_IIC_SDO(HUMIDITY,id),                    \
    REG_IIC_SCL(HUMIDITY,id),                    \
    REG_IIC_DIR(HUMIDITY,id)

#define REG_PIN_IIC_REPEATER(id)                 \
    REG_IIC_SDI(REPEATER,id),                    \
    REG_IIC_SDO(REPEATER,id),                    \
    REG_IIC_SCL(REPEATER,id),                    \
    REG_IIC_DIR(REPEATER,id)

/*****************IIC BUS SWITCH *********************/
#define REG_IIC_BUS_SWITCH_RST(id)       REG_RST_IIC_BUS_SWITCH##id  
#define REG_PIN_IIC_BUS_SWITCH(id) \
       REG_IIC_BUS_SWITCH_RST(id)

/************************* PWR ************************************/
#define REG_PIN_PWR_ADJUST_GPIO(id)           REG_PIN_GPIO_PWR_ADJUST##id
#define REG_PIN_PWR_GPIO(id)                 \
        REG_PIN_PWR_ADJUST_GPIO(id)          \

typedef enum _REG_DRV_PIN_ADDR_DEF
{
    DRV_REG_EPLD_RESET,
    DRV_REG_FPGA0_RESET,
    DRV_REG_FPGA1_RESET,
        
    /* LED点灯寄存器 */
    REG_LED_START,
    REG_LED_RUN,
    REG_LED_RUN_SLOW,
    REG_LED_ALM,
    REG_LED_VSWR,
    REG_LED_ACT,
    REG_LED_DPI,
    REG_LED_OPT0_GREEN,
    REG_LED_OPT0_RED,
    REG_LED_OPT1_GREEN,
    REG_LED_OPT1_RED,
    REG_LED_OPT2_GREEN,
    REG_LED_OPT2_RED,
    REG_LED_OPT3_GREEN,
    REG_LED_OPT3_RED,
    REG_LED_RGPS_GREEN,
    REG_LED_RGPS_RED,
    REG_LED_LTE_RED,
    REG_LED_LTE_GREEN,
    REG_LED_NR_RED,
    REG_LED_NR_GREEN,
    REG_LED_OPT0_CPUEN,
    REG_LED_OPT1_CPUEN,
    REG_LED_OPT2_CPUEN,
    REG_LED_OPT3_CPUEN,
    REG_LED_RGPS_CPUEN,

    REG_PIN_MCS0_UART_SW,
    REG_PIN_MCS1_UART_SW,
    REG_PIN_SOC0_UART_SW,
    REG_PIN_SOC1_UART_SW,

    /* 主板发送到从板的AD9379 同步信号*/
    REG_SOC_AD9379_SYNC,       
    REG_SOC_I2CBUSSWICH_RESET,
    
    /* 主光口选择后选择的时钟*/
    REG_CLK_SEL_BB_FPGA0,       
    REG_CLK_SEL_BB_FPGA1,       
    /* fpga laod */
    
    /*漏水检测*/
    REG_LEAKAGE_DETECTION,

    /* CLK时钟 寄存器*/
    REG_PIN_SPI_CLK_PLL(0),
    REG_PIN_SPI_CLK_PLL(1),
    REG_PIN_SPI_CLK_PLL(2),
    REG_PIN_SPI_CLK_PLL(3),
    REG_PIN_SPI_CLK_PLL(4),
    /* TX LO 寄存器*/
    REG_PIN_SPI_LO_PLL_TX(0),
    REG_PIN_SPI_LO_PLL_TX(1),
    REG_PIN_SPI_LO_PLL_TX(2),
    REG_PIN_SPI_LO_PLL_TX(3),
    REG_PIN_SPI_LO_PLL_TX(4),
    REG_PIN_SPI_LO_PLL_TX(5),
    REG_PIN_SPI_LO_PLL_TX(6),
    REG_PIN_SPI_LO_PLL_TX(7),
    REG_PIN_SPI_LO_PLL_TX(8),
    /* TX DAC 寄存器*/
    REG_PIN_SPI_DAC_TX(0),
    REG_PIN_SPI_DAC_TX(1),
    REG_PIN_SPI_DAC_TX(2),
    REG_PIN_SPI_DAC_TX(3),
    REG_PIN_SPI_DAC_TX(4),
    REG_PIN_SPI_DAC_TX(5),
    REG_PIN_SPI_DAC_TX(6),
    REG_PIN_SPI_DAC_TX(7),
    REG_PIN_SPI_DAC_TX(8),
    REG_PIN_SPI_DAC_TX(9),
    REG_PIN_SPI_DAC_TX(10),
    REG_PIN_SPI_DAC_TX(11),
    REG_PIN_SPI_DAC_TX(12),
    REG_PIN_SPI_DAC_TX(13),
    REG_PIN_SPI_DAC_TX(14),
    REG_PIN_SPI_DAC_TX(15),

    /* temp 寄存器*/
    REG_PIN_SPI_TEMP(0),
    REG_PIN_SPI_TEMP(1),
    REG_PIN_SPI_TEMP(2),
    REG_PIN_SPI_TEMP(3),
    REG_PIN_SPI_TEMP(4),
    REG_PIN_SPI_TEMP(5),
    REG_PIN_SPI_TEMP(6),
    /* TX DAC GRIDVOLT寄存器*/
    REG_PIN_SPI_DAC_GRIDVOLT_TX(0),
    REG_PIN_SPI_DAC_GRIDVOLT_TX(1),
    REG_PIN_SPI_DAC_GRIDVOLT_TX(2),
    REG_PIN_SPI_DAC_GRIDVOLT_TX(3),
    REG_PIN_SPI_DAC_GRIDVOLT_TX(4),
    REG_PIN_SPI_DAC_GRIDVOLT_TX(5),
    REG_PIN_SPI_DAC_GRIDVOLT_TX(6),
    REG_PIN_SPI_DAC_GRIDVOLT_TX(7),
    REG_PIN_SPI_DAC_GRIDVOLT_TX(8),  
    REG_PIN_SPI_DAC_GRIDVOLT_TX(9),
    REG_PIN_SPI_DAC_GRIDVOLT_TX(10),
    REG_PIN_SPI_DAC_GRIDVOLT_TX(11),
    REG_PIN_SPI_DAC_GRIDVOLT_TX(12),
    REG_PIN_SPI_DAC_GRIDVOLT_TX(13),
    REG_PIN_SPI_DAC_GRIDVOLT_TX(14),
    REG_PIN_SPI_DAC_GRIDVOLT_TX(15),
    REG_PIN_SPI_DAC_GRIDVOLT_TX(16),
    REG_PIN_SPI_DAC_GRIDVOLT_TX(17),
    REG_PIN_SPI_DAC_GRIDVOLT_TX(18),
    REG_PIN_SPI_DAC_GRIDVOLT_TX(19),
    REG_PIN_SPI_DAC_GRIDVOLT_TX(20),
    REG_PIN_SPI_DAC_GRIDVOLT_TX(21),
    REG_PIN_SPI_DAC_GRIDVOLT_TX(22),
    REG_PIN_SPI_DAC_GRIDVOLT_TX(23),
    REG_PIN_SPI_DAC_GRIDVOLT_TX(24),
    REG_PIN_SPI_DAC_GRIDVOLT_TX(25),
    REG_PIN_SPI_DAC_GRIDVOLT_TX(26),  
    REG_PIN_SPI_DAC_GRIDVOLT_TX(27),
    REG_PIN_SPI_DAC_GRIDVOLT_TX(28),
    REG_PIN_SPI_DAC_GRIDVOLT_TX(29),
    REG_PIN_SPI_DAC_GRIDVOLT_TX(30),
    REG_PIN_SPI_DAC_GRIDVOLT_TX(31),
    REG_PIN_SPI_DAC_GRIDVOLT_TX(32),
    REG_PIN_SPI_DAC_GRIDVOLT_TX(33),
    REG_PIN_SPI_DAC_GRIDVOLT_TX(34),
    REG_PIN_SPI_DAC_GRIDVOLT_TX(35),
    REG_PIN_SPI_DAC_GRIDVOLT_TX(36),
    REG_PIN_SPI_DAC_GRIDVOLT_TX(37),
    REG_PIN_SPI_DAC_GRIDVOLT_TX(38),
    REG_PIN_SPI_DAC_GRIDVOLT_TX(39),
    REG_PIN_SPI_DAC_GRIDVOLT_TX(40),
    REG_PIN_SPI_DAC_GRIDVOLT_TX(41),
    REG_PIN_SPI_DAC_GRIDVOLT_TX(42),
    REG_PIN_SPI_DAC_GRIDVOLT_TX(43),
    REG_PIN_SPI_DAC_GRIDVOLT_TX(44),
    REG_PIN_SPI_DAC_GRIDVOLT_TX(45),
    REG_PIN_SPI_DAC_GRIDVOLT_TX(46),
    REG_PIN_SPI_DAC_GRIDVOLT_TX(47),
    REG_PIN_SPI_DAC_GRIDVOLT_TX(48),
    REG_PIN_SPI_DAC_GRIDVOLT_TX(49),
    REG_PIN_SPI_DAC_GRIDVOLT_TX(50),
    REG_PIN_SPI_DAC_GRIDVOLT_TX(51),
    REG_PIN_SPI_DAC_GRIDVOLT_TX(52),
    REG_PIN_SPI_DAC_GRIDVOLT_TX(53),
    REG_PIN_SPI_DAC_GRIDVOLT_TX(54),
    REG_PIN_SPI_DAC_GRIDVOLT_TX(55),
    REG_PIN_SPI_DAC_GRIDVOLT_TX(56),
    REG_PIN_SPI_DAC_GRIDVOLT_TX(57),
    REG_PIN_SPI_DAC_GRIDVOLT_TX(58),
    REG_PIN_SPI_DAC_GRIDVOLT_TX(59),
    REG_PIN_SPI_DAC_GRIDVOLT_TX(60),
    REG_PIN_SPI_DAC_GRIDVOLT_TX(61),
    REG_PIN_SPI_DAC_GRIDVOLT_TX(62),
    REG_PIN_SPI_DAC_GRIDVOLT_TX(63),
    REG_PIN_SPI_DAC_GRIDVOLT_TX(64),
    REG_PIN_SPI_DAC_GRIDVOLT_TX(65),
    REG_PIN_SPI_DAC_GRIDVOLT_TX(66),
    REG_PIN_SPI_DAC_GRIDVOLT_TX(67),
    REG_PIN_SPI_DAC_GRIDVOLT_TX(68),
    REG_PIN_SPI_DAC_GRIDVOLT_TX(69),
    REG_PIN_SPI_DAC_GRIDVOLT_TX(70),
    REG_PIN_SPI_DAC_GRIDVOLT_TX(71),
    REG_PIN_SPI_DAC_GRIDVOLT_TX(72),
    REG_PIN_SPI_DAC_GRIDVOLT_TX(73),
    REG_PIN_SPI_DAC_GRIDVOLT_TX(74),
    REG_PIN_SPI_DAC_GRIDVOLT_TX(75),
    REG_PIN_SPI_DAC_GRIDVOLT_TX(76),
    REG_PIN_SPI_DAC_GRIDVOLT_TX(77),
    REG_PIN_SPI_DAC_GRIDVOLT_TX(78),
    REG_PIN_SPI_DAC_GRIDVOLT_TX(79),

    REG_PIN_SPI_DAC_GRIDVOLT_RX(0),
    REG_PIN_SPI_DAC_GRIDVOLT_RX(1),
    REG_PIN_SPI_DAC_GRIDVOLT_RX(2),
    REG_PIN_SPI_DAC_GRIDVOLT_RX(3),
    REG_PIN_SPI_DAC_GRIDVOLT_RX(4),
    REG_PIN_SPI_DAC_GRIDVOLT_RX(5),
    REG_PIN_SPI_DAC_GRIDVOLT_RX(6),
    REG_PIN_SPI_DAC_GRIDVOLT_RX(7),

    /* TX VGA 寄存器*/
    REG_PIN_SPI_RFVGA_TX(0),
    REG_PIN_SPI_RFVGA_TX(1),
    REG_PIN_SPI_RFVGA_TX(2),
    REG_PIN_SPI_RFVGA_TX(3),
    REG_PIN_SPI_RFVGA_TX(4),
    REG_PIN_SPI_RFVGA_TX(5),
    REG_PIN_SPI_RFVGA_TX(6),
    REG_PIN_SPI_RFVGA_TX(7),
    /*RX VGA 寄存器*/
    REG_PIN_SPI_RFVGA_RX(0),
    REG_PIN_SPI_RFVGA_RX(1),
    REG_PIN_SPI_RFVGA_RX(2),
    REG_PIN_SPI_RFVGA_RX(3),
    REG_PIN_SPI_RFVGA_RX(4),
    REG_PIN_SPI_RFVGA_RX(5),
    REG_PIN_SPI_RFVGA_RX(6),
    REG_PIN_SPI_RFVGA_RX(7),
    REG_PIN_SPI_RFVGA_RX(8),
    REG_PIN_SPI_RFVGA_RX(9),
    REG_PIN_SPI_RFVGA_RX(10),
    REG_PIN_SPI_RFVGA_RX(11),
    REG_PIN_SPI_RFVGA_RX(12),
    REG_PIN_SPI_RFVGA_RX(13),
    REG_PIN_SPI_RFVGA_RX(14),
    REG_PIN_SPI_RFVGA_RX(15),
    /* TX RFATT 寄存器*/
    REG_PIN_SPI_RFATT_TX(0),
    REG_PIN_SPI_RFATT_TX(1),
    REG_PIN_SPI_RFATT_TX(2),
    REG_PIN_SPI_RFATT_TX(3),
    REG_PIN_SPI_RFATT_TX(4),
    REG_PIN_SPI_RFATT_TX(5),
    REG_PIN_SPI_RFATT_TX(6),
    REG_PIN_SPI_RFATT_TX(7),
    REG_PIN_SPI_RFATT_TX(8),
    REG_PIN_SPI_RFATT_TX(9),
    REG_PIN_SPI_RFATT_TX(10),
    REG_PIN_SPI_RFATT_TX(11),
    REG_PIN_SPI_RFATT_TX(12),
    REG_PIN_SPI_RFATT_TX(13),
    REG_PIN_SPI_RFATT_TX(14),
    REG_PIN_SPI_RFATT_TX(15),
    REG_PIN_SPI_RFATT_TX(16),
    REG_PIN_SPI_RFATT_TX(17),
    REG_PIN_SPI_RFATT_TX(18),
    REG_PIN_SPI_RFATT_TX(19),
    REG_PIN_SPI_RFATT_TX(20),
    REG_PIN_SPI_RFATT_TX(21),
    REG_PIN_SPI_RFATT_TX(22),
    REG_PIN_SPI_RFATT_TX(23),
    REG_PIN_SPI_RFATT_TX(24),
    REG_PIN_SPI_RFATT_TX(25),
    REG_PIN_SPI_RFATT_TX(26),
    REG_PIN_SPI_RFATT_TX(27),
    REG_PIN_SPI_RFATT_TX(28),
    REG_PIN_SPI_RFATT_TX(29),
    REG_PIN_SPI_RFATT_TX(30),
    REG_PIN_SPI_RFATT_TX(31),
    /* RX RFATT 寄存器*/
    REG_PIN_SPI_RFATT_RX(0),
    REG_PIN_SPI_RFATT_RX(1),
    REG_PIN_SPI_RFATT_RX(2),
    REG_PIN_SPI_RFATT_RX(3),
    REG_PIN_SPI_RFATT_RX(4),
    REG_PIN_SPI_RFATT_RX(5),
    REG_PIN_SPI_RFATT_RX(6),
    REG_PIN_SPI_RFATT_RX(7),
    REG_PIN_SPI_RFATT_RX(8),
    REG_PIN_SPI_RFATT_RX(9),
    REG_PIN_SPI_RFATT_RX(10),
    REG_PIN_SPI_RFATT_RX(11),
    REG_PIN_SPI_RFATT_RX(12),
    REG_PIN_SPI_RFATT_RX(13),
    REG_PIN_SPI_RFATT_RX(14),
    REG_PIN_SPI_RFATT_RX(15),
    REG_PIN_SPI_RFATT_RX(16),
    REG_PIN_SPI_RFATT_RX(17),
    REG_PIN_SPI_RFATT_RX(18),
    REG_PIN_SPI_RFATT_RX(19),
    REG_PIN_SPI_RFATT_RX(20),
    REG_PIN_SPI_RFATT_RX(21),
    REG_PIN_SPI_RFATT_RX(22),
    REG_PIN_SPI_RFATT_RX(23),
    REG_PIN_SPI_RFATT_RX(24),
    REG_PIN_SPI_RFATT_RX(25),
    REG_PIN_SPI_RFATT_RX(26),
    REG_PIN_SPI_RFATT_RX(27),
    REG_PIN_SPI_RFATT_RX(28),
    REG_PIN_SPI_RFATT_RX(29),
    REG_PIN_SPI_RFATT_RX(30),
    REG_PIN_SPI_RFATT_RX(31),    
    /* PRX RFATT 寄存器*/
    REG_PIN_SPI_RFATT_PRX(0),
    REG_PIN_SPI_RFATT_PRX(1),
    REG_PIN_SPI_RFATT_PRX(2),
    REG_PIN_SPI_RFATT_PRX(3),
    REG_PIN_SPI_RFATT_PRX(4),
    REG_PIN_SPI_RFATT_PRX(5),
    REG_PIN_SPI_RFATT_PRX(6),
    REG_PIN_SPI_RFATT_PRX(7),
    REG_PIN_SPI_RFATT_PRX(8),
    REG_PIN_SPI_RFATT_PRX(9),
    REG_PIN_SPI_RFATT_PRX(10),
    REG_PIN_SPI_RFATT_PRX(11),
    REG_PIN_SPI_RFATT_PRX(12),
    REG_PIN_SPI_RFATT_PRX(13),
    REG_PIN_SPI_RFATT_PRX(14),
    REG_PIN_SPI_RFATT_PRX(15),
    REG_PIN_SPI_RFATT_PRX(16),
    REG_PIN_SPI_RFATT_PRX(17),
    REG_PIN_SPI_RFATT_PRX(18),
    REG_PIN_SPI_RFATT_PRX(19),
    REG_PIN_SPI_RFATT_PRX(20),
    REG_PIN_SPI_RFATT_PRX(21),
    REG_PIN_SPI_RFATT_PRX(22),
    REG_PIN_SPI_RFATT_PRX(23),
    REG_PIN_SPI_RFATT_PRX(24),
    REG_PIN_SPI_RFATT_PRX(25),
    REG_PIN_SPI_RFATT_PRX(26),
    REG_PIN_SPI_RFATT_PRX(27),
    REG_PIN_SPI_RFATT_PRX(28),
    REG_PIN_SPI_RFATT_PRX(29),
    REG_PIN_SPI_RFATT_PRX(30),
    REG_PIN_SPI_RFATT_PRX(31),
    /* PRX RFVGA 寄存器*/
    REG_PIN_SPI_RFVGA_PRX(0),
    REG_PIN_SPI_RFVGA_PRX(1),
    REG_PIN_SPI_RFVGA_PRX(2),
    REG_PIN_SPI_RFVGA_PRX(3),
    REG_PIN_SPI_RFVGA_PRX(4),
    REG_PIN_SPI_RFVGA_PRX(5),
    REG_PIN_SPI_RFVGA_PRX(6),
    REG_PIN_SPI_RFVGA_PRX(7),    
     /* PRX ADC 寄存器*/
    REG_PIN_SPI_ADC_PRX(0),
    REG_PIN_SPI_ADC_PRX(1),
    REG_PIN_SPI_ADC_PRX(2),
    REG_PIN_SPI_ADC_PRX(3),
    REG_PIN_SPI_ADC_PRX(4),
    REG_PIN_SPI_ADC_PRX(5),
    REG_PIN_SPI_ADC_PRX(6),
    REG_PIN_SPI_ADC_PRX(7),
     /* RX ADC 寄存器*/
    REG_PIN_SPI_ADC_RX(0),
    REG_PIN_SPI_ADC_RX(1),
    REG_PIN_SPI_ADC_RX(2),
    REG_PIN_SPI_ADC_RX(3),
    REG_PIN_SPI_ADC_RX(4),
    REG_PIN_SPI_ADC_RX(5),
    REG_PIN_SPI_ADC_RX(6),
    REG_PIN_SPI_ADC_RX(7),
    REG_PIN_SPI_ADC_RX(8),
    REG_PIN_SPI_ADC_RX(9),
    REG_PIN_SPI_ADC_RX(10),
    REG_PIN_SPI_ADC_RX(11),
    REG_PIN_SPI_ADC_RX(12),
    REG_PIN_SPI_ADC_RX(13),
    REG_PIN_SPI_ADC_RX(14),
    REG_PIN_SPI_ADC_RX(15),
    /* RX LO 寄存器*/
    REG_PIN_SPI_LO_PLL_RX(0),
    REG_PIN_SPI_LO_PLL_RX(1),
    REG_PIN_SPI_LO_PLL_RX(2),
    REG_PIN_SPI_LO_PLL_RX(3),
    REG_PIN_SPI_LO_PLL_RX(4),
    REG_PIN_SPI_LO_PLL_RX(5),
    REG_PIN_SPI_LO_PLL_RX(6),
    REG_PIN_SPI_LO_PLL_RX(7),
    /*PRX LO 寄存器*/
    REG_PIN_SPI_LO_PLL_FB(0),
    REG_PIN_SPI_LO_PLL_FB(1),
    REG_PIN_SPI_LO_PLL_FB(2),
    REG_PIN_SPI_LO_PLL_FB(3),
    REG_PIN_SPI_LO_PLL_FB(4),
    REG_PIN_SPI_LO_PLL_FB(5),
    REG_PIN_SPI_LO_PLL_FB(6),
    REG_PIN_SPI_LO_PLL_FB(7),    
     /* TRANSIVER 寄存器*/
    REG_PIN_SPI_TRANSIVER(0),
    REG_PIN_SPI_TRANSIVER(1),
    REG_PIN_SPI_TRANSIVER(2),
    REG_PIN_SPI_TRANSIVER(3),
    REG_PIN_SPI_TRANSIVER(4),
    REG_PIN_SPI_TRANSIVER(5),
    REG_PIN_SPI_TRANSIVER(6),
    REG_PIN_SPI_TRANSIVER(7),
    REG_PIN_SPI_TRANSIVER(8),
    REG_PIN_SPI_TRANSIVER(9),
    REG_PIN_SPI_TRANSIVER(10),
    REG_PIN_SPI_TRANSIVER(11),
    REG_PIN_SPI_TRANSIVER(12),
    REG_PIN_SPI_TRANSIVER(13),
    REG_PIN_SPI_TRANSIVER(14),
    REG_PIN_SPI_TRANSIVER(15),
    REG_PIN_SPI_TRANSIVER(16),
    REG_PIN_SPI_TRANSIVER(17),
    REG_PIN_SPI_TRANSIVER(18),
    REG_PIN_SPI_TRANSIVER(19),
    REG_PIN_SPI_TRANSIVER(20),
    REG_PIN_SPI_TRANSIVER(21),
    REG_PIN_SPI_TRANSIVER(22),
    REG_PIN_SPI_TRANSIVER(23),
    REG_PIN_SPI_TRANSIVER(24),
    REG_PIN_SPI_TRANSIVER(25),
    REG_PIN_SPI_TRANSIVER(26),
    REG_PIN_SPI_TRANSIVER(27),
    REG_PIN_SPI_TRANSIVER(28),
    REG_PIN_SPI_TRANSIVER(29),
    REG_PIN_SPI_TRANSIVER(30),
    REG_PIN_SPI_TRANSIVER(31),
     /* CLK BUFFER 寄存器*/
    REG_PIN_SPI_BUFFER(0),
    REG_PIN_SPI_BUFFER(1),
    REG_PIN_SPI_BUFFER(2),
    REG_PIN_SPI_BUFFER(3),
    REG_PIN_SPI_BUFFER(4),
    REG_PIN_SPI_BUFFER(5),
    REG_PIN_SPI_BUFFER(6),
    REG_PIN_SPI_BUFFER(7),
    /* FPGALOAD寄存器*/
    REG_PIN_SPI_FPGALOAD(0),
    REG_PIN_SPI_FPGALOAD(1),
    REG_PIN_SPI_FPGALOAD(2),
    REG_PIN_SPI_FPGALOAD(3),
    REG_PIN_SPI_FPGALOAD(4),
    REG_PIN_SPI_FPGALOAD(5),
    REG_PIN_SPI_FPGALOAD(6),    
    REG_PIN_SPI_FPGALOAD(7),       

    /* SW DEVICE EpldPa*/
    REG_PIN_SPI_DEVICE(0),
    REG_PIN_SPI_DEVICE(1),

    /*SPI FLASH*/
    REG_PIN_SPI_FLASH(0),

    /*SPI EEPROM*/
    REG_PIN_SPI_EEPROM(0),
    REG_PIN_SPI_EEPROM(1),
    REG_PIN_SPI_EEPROM(2),
    REG_PIN_SPI_EEPROM(3),
    REG_PIN_SPI_EEPROM(4),
    REG_PIN_SPI_EEPROM(5),
    REG_PIN_SPI_EEPROM(6),
    REG_PIN_SPI_EEPROM(7),

    /*II2 EEPROM*/
    REG_PIN_IIC_PA_EEPROM(0),
    REG_PIN_IIC_PA_EEPROM(1),
    REG_PIN_IIC_PA_EEPROM(2),
    REG_PIN_IIC_PA_EEPROM(3),
    REG_PIN_IIC_PA_EEPROM(4),
    REG_PIN_IIC_PA_EEPROM(5),
    REG_PIN_IIC_PA_EEPROM(6),
    REG_PIN_IIC_PA_EEPROM(7),
    REG_PIN_IIC_PA_EEPROM(8),
    REG_PIN_IIC_PA_EEPROM(9),
    REG_PIN_IIC_PA_EEPROM(10),
    REG_PIN_IIC_PA_EEPROM(11),
    REG_PIN_IIC_PA_EEPROM(12),
    REG_PIN_IIC_PA_EEPROM(13),
    REG_PIN_IIC_PA_EEPROM(14),
    REG_PIN_IIC_PA_EEPROM(15),

    REG_PIN_IIC_BOARD_EEPROM(0),
    REG_PIN_IIC_BOARD_EEPROM(1),
    REG_PIN_IIC_BOARD_EEPROM(2),
    REG_PIN_IIC_BOARD_EEPROM(3),
    /*0.85V 电源*/
    REG_PIN_IIC_PWR_CTRL(4),
    REG_PIN_IIC_PWR_CTRL(5),
    REG_PIN_IIC_PWR_CTRL(6),
    /* FEM TEMP IIC */
    REG_PIN_IIC_PA_TEMP(0),
    REG_PIN_IIC_PA_TEMP(1),
    REG_PIN_IIC_PA_TEMP(2),
    REG_PIN_IIC_PA_TEMP(3),
    REG_PIN_IIC_PA_TEMP(4),
    REG_PIN_IIC_PA_TEMP(5),
    REG_PIN_IIC_PA_TEMP(6),
    REG_PIN_IIC_PA_TEMP(7),
    REG_PIN_IIC_PA_TEMP(8),
    REG_PIN_IIC_PA_TEMP(9),
    REG_PIN_IIC_PA_TEMP(10),
    REG_PIN_IIC_PA_TEMP(11),
    REG_PIN_IIC_PA_TEMP(12),
    REG_PIN_IIC_PA_TEMP(13),
    REG_PIN_IIC_PA_TEMP(14),
    REG_PIN_IIC_PA_TEMP(15),
    /* SW IIC */
	REG_PIN_IIC_SW_CTRL(0),
    /* PWR IIC */
    REG_PIN_IIC_PWR(0),
    REG_PIN_IIC_PWR(1),
    REG_PIN_IIC_PWR(2),
    /* PMB IIC */
    REG_PIN_IIC_PMB(0),
    REG_PIN_IIC_PMB(1),
    REG_PIN_IIC_PMB(2),
    REG_PIN_IIC_PMB(3),
    /* SFP IIC */
    REG_PIN_IIC_SFP(0),
    REG_PIN_IIC_SFP(1),
    REG_PIN_IIC_SFP(2),
    REG_PIN_IIC_SFP(3),
    /* FPGA TEMP IIC */
    REG_PIN_IIC_FPGA_TEMP(0),
    REG_PIN_IIC_FPGA_TEMP(1),
    REG_PIN_IIC_FPGA_TEMP(2),
    /* DAC IIC */
    REG_PIN_IIC_DAC(0),
    REG_PIN_IIC_DAC(1),
    /*EPLD SPI*/
    REG_PIN_SPI_EPLD(0),
    REG_PIN_SPI_EPLD(1),
    REG_PIN_SPI_EPLD(2),
    REG_PIN_SPI_EPLD(3),
    REG_PIN_SPI_EPLD(4),
    REG_PIN_SPI_EPLD(5),
    REG_PIN_SPI_EPLD(6),
    REG_PIN_SPI_EPLD(7),

     /* TX CONVERTER 寄存器*/
    REG_PIN_SPI_CONVERTER_TX(0),
    REG_PIN_SPI_CONVERTER_TX(1),
    REG_PIN_SPI_CONVERTER_TX(2),
    REG_PIN_SPI_CONVERTER_TX(3),
    REG_PIN_SPI_CONVERTER_TX(4),
    REG_PIN_SPI_CONVERTER_TX(5),
    REG_PIN_SPI_CONVERTER_TX(6),
    REG_PIN_SPI_CONVERTER_TX(7),
    REG_PIN_SPI_CONVERTER_TX(8),
    REG_PIN_SPI_CONVERTER_TX(9),
    REG_PIN_SPI_CONVERTER_TX(10),
    REG_PIN_SPI_CONVERTER_TX(11),
    REG_PIN_SPI_CONVERTER_TX(12),
    REG_PIN_SPI_CONVERTER_TX(13),
    REG_PIN_SPI_CONVERTER_TX(14),
    REG_PIN_SPI_CONVERTER_TX(15),
    REG_PIN_SPI_CONVERTER_TX(16),
    
     /* RX CONVERTER 寄存器*/
    REG_PIN_SPI_CONVERTER_RX(0),
    REG_PIN_SPI_CONVERTER_RX(1),
    REG_PIN_SPI_CONVERTER_RX(2),
    REG_PIN_SPI_CONVERTER_RX(3),
    REG_PIN_SPI_CONVERTER_RX(4),
    REG_PIN_SPI_CONVERTER_RX(5),
    REG_PIN_SPI_CONVERTER_RX(6),
    REG_PIN_SPI_CONVERTER_RX(7),
    REG_PIN_SPI_CONVERTER_RX(8),
    REG_PIN_SPI_CONVERTER_RX(9),
    REG_PIN_SPI_CONVERTER_RX(10),
    REG_PIN_SPI_CONVERTER_RX(11),
    REG_PIN_SPI_CONVERTER_RX(12),
    REG_PIN_SPI_CONVERTER_RX(13),
    REG_PIN_SPI_CONVERTER_RX(14),
    REG_PIN_SPI_CONVERTER_RX(15),
    REG_PIN_SPI_CONVERTER_RX(16),

     /* TX SHIFTER 寄存器*/
    REG_PIN_SPI_SHIFTER_TX(0),
    REG_PIN_SPI_SHIFTER_TX(1),
    REG_PIN_SPI_SHIFTER_TX(2),
    REG_PIN_SPI_SHIFTER_TX(3),
    REG_PIN_SPI_SHIFTER_TX(4),
    REG_PIN_SPI_SHIFTER_TX(5),
    REG_PIN_SPI_SHIFTER_TX(6),
    REG_PIN_SPI_SHIFTER_TX(7),
    REG_PIN_SPI_SHIFTER_TX(8),
    REG_PIN_SPI_SHIFTER_TX(9),
    REG_PIN_SPI_SHIFTER_TX(10),
    REG_PIN_SPI_SHIFTER_TX(11),
    REG_PIN_SPI_SHIFTER_TX(12),
    REG_PIN_SPI_SHIFTER_TX(13),
    REG_PIN_SPI_SHIFTER_TX(14),
    REG_PIN_SPI_SHIFTER_TX(15),
     /* RX SHIFTER 寄存器*/
    REG_PIN_SPI_SHIFTER_RX(0),
    REG_PIN_SPI_SHIFTER_RX(1),
    REG_PIN_SPI_SHIFTER_RX(2),
    REG_PIN_SPI_SHIFTER_RX(3),
    REG_PIN_SPI_SHIFTER_RX(4),
    REG_PIN_SPI_SHIFTER_RX(5),
    REG_PIN_SPI_SHIFTER_RX(6),
    REG_PIN_SPI_SHIFTER_RX(7),	
    REG_PIN_SPI_SHIFTER_RX(8),
    REG_PIN_SPI_SHIFTER_RX(9),
    REG_PIN_SPI_SHIFTER_RX(10),
    REG_PIN_SPI_SHIFTER_RX(11),
    REG_PIN_SPI_SHIFTER_RX(12),
    REG_PIN_SPI_SHIFTER_RX(13),
    REG_PIN_SPI_SHIFTER_RX(14),
    REG_PIN_SPI_SHIFTER_RX(15),	

    /* TX ATT */
    REG_PIN_SPI_DATT_TX(0),
    REG_PIN_SPI_DATT_TX(1),
    REG_PIN_SPI_DATT_TX(2),
    REG_PIN_SPI_DATT_TX(3),
    REG_PIN_SPI_DATT_TX(4),
    REG_PIN_SPI_DATT_TX(5),
    REG_PIN_SPI_DATT_TX(6),
    REG_PIN_SPI_DATT_TX(7),

    /* RX ATT */
    REG_PIN_SPI_DATT_RX(0),
    REG_PIN_SPI_DATT_RX(1),
    REG_PIN_SPI_DATT_RX(2),
    REG_PIN_SPI_DATT_RX(3),
    REG_PIN_SPI_DATT_RX(4),
    REG_PIN_SPI_DATT_RX(5),
    REG_PIN_SPI_DATT_RX(6),
    REG_PIN_SPI_DATT_RX(7),

    /* TX VGA */
    REG_PIN_SPI_DVGA_TX(0),
    REG_PIN_SPI_DVGA_TX(1),
    REG_PIN_SPI_DVGA_TX(2),
    REG_PIN_SPI_DVGA_TX(3),
    REG_PIN_SPI_DVGA_TX(4),
    REG_PIN_SPI_DVGA_TX(5),
    REG_PIN_SPI_DVGA_TX(6),
    REG_PIN_SPI_DVGA_TX(7),

    /* RX VGA */
    REG_PIN_SPI_DVGA_RX(0),
    REG_PIN_SPI_DVGA_RX(1),
    REG_PIN_SPI_DVGA_RX(2),
    REG_PIN_SPI_DVGA_RX(3),
    REG_PIN_SPI_DVGA_RX(4),
    REG_PIN_SPI_DVGA_RX(5),
    REG_PIN_SPI_DVGA_RX(6),
    REG_PIN_SPI_DVGA_RX(7),    
    
    /*SOC FPGA/BOARD TEMP*/
    REG_PIN_IIC_BOARD_TEMP(0),
    REG_PIN_IIC_BOARD_TEMP(1),
    REG_PIN_IIC_BOARD_TEMP(2),

    /*TPS53667*/
    REG_PIN_IIC_BOARD_PWR(0),

    /*IIC BUS SWITCH*/
    REG_PIN_IIC_BUS_SWITCH(0),
    REG_PIN_IIC_BUS_SWITCH(1),
    REG_PIN_SPI_VVA(0),
    REG_PIN_SPI_VVA(1),
    REG_PIN_SPI_VVA(2),
    REG_PIN_SPI_VVA(3),
    REG_PIN_SPI_VVA(4),
    REG_PIN_SPI_VVA(5),
    REG_PIN_SPI_VVA(6),
    REG_PIN_SPI_VVA(7), 

    REG_PIN_SPI_RFEM(0),
    REG_PIN_SPI_RFEM(1),
    REG_PIN_SPI_RFEM(2),
    REG_PIN_SPI_RFEM(3),
    REG_PIN_SPI_RFEM(4),
    REG_PIN_SPI_RFEM(5),
    REG_PIN_SPI_RFEM(6),
    REG_PIN_SPI_RFEM(7),
    REG_PIN_SPI_RFEM(8),
    REG_PIN_SPI_RFEM(9),
    REG_PIN_SPI_RFEM(10),
    REG_PIN_SPI_RFEM(11),
    REG_PIN_SPI_RFEM(12),
    REG_PIN_SPI_RFEM(13),
    REG_PIN_SPI_RFEM(14),
    REG_PIN_SPI_RFEM(15),	

    REG_PIN_SPI_RFEM(16),
    REG_PIN_SPI_RFEM(17),
    REG_PIN_SPI_RFEM(18),
    REG_PIN_SPI_RFEM(19),
    REG_PIN_SPI_RFEM(20),
    REG_PIN_SPI_RFEM(21),
    REG_PIN_SPI_RFEM(22),
    REG_PIN_SPI_RFEM(23),
    REG_PIN_SPI_RFEM(24),
    REG_PIN_SPI_RFEM(25),
    REG_PIN_SPI_RFEM(26),
    REG_PIN_SPI_RFEM(27),
    REG_PIN_SPI_RFEM(28),
    REG_PIN_SPI_RFEM(29),
    REG_PIN_SPI_RFEM(30),
    REG_PIN_SPI_RFEM(31),

    DRV_REG_FPGA2_RESET,
    DRV_REG_FPGA3_RESET,
    DRV_REG_FPGA4_RESET,
    DRV_REG_FPGA5_RESET,
    DRV_REG_FPGA6_RESET,
    DRV_REG_FPGA7_RESET, 

     /* TX ATT */
    REG_PIN_SPI_DATT_TX(8),
    REG_PIN_SPI_DATT_TX(9),
    REG_PIN_SPI_DATT_TX(10),
    REG_PIN_SPI_DATT_TX(11),
    REG_PIN_SPI_DATT_TX(12),
    REG_PIN_SPI_DATT_TX(13),
    REG_PIN_SPI_DATT_TX(14),
    REG_PIN_SPI_DATT_TX(15),

    /* RX ATT */
    REG_PIN_SPI_DATT_RX(8),
    REG_PIN_SPI_DATT_RX(9),
    REG_PIN_SPI_DATT_RX(10),
    REG_PIN_SPI_DATT_RX(11),
    REG_PIN_SPI_DATT_RX(12),
    REG_PIN_SPI_DATT_RX(13),
    REG_PIN_SPI_DATT_RX(14),
    REG_PIN_SPI_DATT_RX(15),	

    DRV_REG_FPGA0_WR,
    DRV_REG_FPGA1_WR,
    DRV_REG_FPGA2_WR,
    DRV_REG_FPGA3_WR,
    DRV_REG_FPGA4_WR,
    DRV_REG_FPGA5_WR,
    DRV_REG_FPGA6_WR,
    DRV_REG_FPGA7_WR, 	
    REG_PIN_IIC_ADC(0),
    REG_PIN_IIC_PWR_EEPROM(0),
    REG_PIN_IIC_PWR_TEMP(0),

    FPGA_LOAD0_SEL,
    FPGA_LOAD1_SEL,
    FPGA_LOAD2_SEL,

    IFFPGA0_RESET_COM,
    IFFPGA1_RESET_COM,

    DPDIC_EPLD_OE_EN,

    REG_PIN_IIC_HUMIDITY(0),

    /*R8998G_D4A光模块在位*/
    REG_PIN_GPIO_OPT0_EXIST,
    REG_PIN_GPIO_OPT1_EXIST,

    REG_PIN_PWR_GPIO(21),
    REG_PIN_PWR_GPIO(22),
    REG_PIN_PWR_GPIO(23),
    REG_PIN_PWR_GPIO(24),

    REG_SPI_FPGA3_CS(0),
    REG_SPI_FPGA3_SCK(0), 
    REG_SPI_FPGA3_MISO(0),
    REG_SPI_FPGA3_MOSI(0),
    REG_SPI_FPGA3_DIR(0),

	REG_PLC_WARN,
	REG_ID0,
	REG_ID1,
	REG_ID2,
	REG_ID3,
	REG_48V_REG_0,
	REG_48V_REG_1,
	REG_48V_REG_2,
	REG_48V_REG_3,
	REG_PLC_RESET,
	REG_SERDES0_ABS,
	REG_SERDES1_ABS,

    REG_DPDIC_ARM_BOOT0,
    REG_DPDIC_ARM_RST,

    REG_S1_RESET,

    FPGA_LOAD3_SEL,
    REG_PIN_IIC_REPEATER(0),
    REG_PIN_IIC_REPEATER(1),
    REG_GPIO_OUTPUT_MODE,
    IC_LOAD_STA,
    REG_DRV_PIN_MAX,
    REG_FAN_REG_0,
    REG_FAN_REG_1,

    REG_PWR_TEMP_CS,
    GPIO_PWR_TEMP_CS0,/*电源头温度使用SPI adapt模式使用*/
    GPIO_PWR_TEMP_CS1,

    REG_THUNDER_WARN, /*直流防雷告警检测*/
} REG_DRV_PIN_ADDR_DEF;

/**************************************************************************
*                         函数声明
**************************************************************************/


#ifdef __cplusplus
}
#endif
#endif /* BSP_REG_PIN_TBL_H_INCLUDED */




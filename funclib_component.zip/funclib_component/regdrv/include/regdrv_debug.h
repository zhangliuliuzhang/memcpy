/*****************************************************************************
 * 版权所有(C) 2014, ZTE Corp. ZXSDR-RRU Platform BSP
 *----------------------------------------------------------------------------
 * 模 块 名 : BSP
 * 文件名称 : regdrv_debug.h
 * 文件标识 : {[N/A]}
 * 内容摘要 : 本文件主要提供regdrv层的设备驱动的实现。
 * 注意事项 : 无
 * 作    者 : 王飞
 * 创建日期 : 2017-02-05 10:28:34
 * 当前版本 : Ver1.0
 *----------------------------------------------------------------------------
 * 变更记录 :
 *
 * $记录1
 * 变 更 单:
 * 责 任 人:
 * 修改日戳:
 * 变更说明:

 *----------------------------------------------------------------------------
 */
#ifndef BSP_REG_DRV_DEBUG_H_INCLUDED
#define BSP_REG_DRV_DEBUG_H_INCLUDED

#ifdef __cplusplus
extern "C" {
#endif

#include "bspcomm.h"


/**************************************************************************
 *                        宏定义
 **************************************************************************/

/**************************************************************************
*                         全局变量定义                                   *
**************************************************************************/

/**************************************************************************
*                         数据类型                                       *
**************************************************************************/
/**************************************************************************
*                         函数声明
**************************************************************************/
VOID   wrfpga(UINT32 chip,UINT32 addr,UINT32 val);
UINT32 rdfpga(UINT32 chip,UINT32 addr,UINT32 len);

VOID BspSetFpgaRegMask(UINT32 chipId, UINT32 addr, UINT32 val, UINT32 mask);
VOID BspSetFpgaReg(UINT32 chipId, UINT32 addr, UINT32 val);
UINT32 BspGetFpgaReg(UINT32 chipId, UINT32 addr);
VOID BspSetEpldRegMask(UINT32 addr, UINT32 val, UINT32 mask);
VOID BspSetEpldReg(UINT32 addr, UINT32 val);
UINT32 BspGetEpldReg(UINT32 addr);

UINT32 BspSetSocPhyBaseAddr(UINT32 chipId, UINT32 SocBaseAddr);

UINT32 BspGetReg(UINT32 regType,UINT32 chipId, UINT32 addr,UINT32 *data);
VOID BspSetReg(UINT32 regType, UINT32 chipId, UINT32 addr, UINT32 data);
VOID BspSetRegMask(UINT32 regType, UINT32 chipId, UINT32 addr, UINT32 data, UINT32 mask);

VOID rdifc(UINT32 chip,UINT32 addr,UINT32 len);
VOID wrifc(UINT32 chip,UINT32 addr,UINT32 val);
UINT32 BspSetEpldPhyBaseAddr(UINT32 chipId, UINT32 EpldBaseAddr);
UINT32 BspSetIfcPhyBaseAddr(UINT32 chipId, UINT32 IfcBaseAddr);
VOID wrepld(UINT32 addr,UINT32 val);

#ifdef __cplusplus
}
#endif
#endif /* BSP_REG_DRV_DEBUG_H_INCLUDED */




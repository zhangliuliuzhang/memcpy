/*****************************************************************************
 * 版权所有(C) 2014, ZTE Corp. ZXSDR-RRU Platform BSP
 *----------------------------------------------------------------------------
 * 模 块 名 : BSP
 * 文件名称 : regdrv_access.h
 * 文件标识 : {[N/A]}
 * 内容摘要 : 本文件主要提供寄存器访问的具体实现模块
 * 注意事项 : 无
 * 作    者 : 王飞
 * 创建日期 : 2017-02-05 10:28:34
 * 当前版本 : Ver1.0
 *----------------------------------------------------------------------------
 * 变更记录 :
 *
 * $记录1
 * 变 更 单:
 * 责 任 人:
 * 修改日戳:
 * 变更说明:

 *----------------------------------------------------------------------------
 */
#ifndef BSP_REG_DRV_ACCESS_H_INCLUDED
#define BSP_REG_DRV_ACCESS_H_INCLUDED

#ifdef __cplusplus
extern "C" {
#endif

#include "regdrv_comm.h"
#include "regdrv_accesstbl.h"


/**************************************************************************
 *                        宏定义
 **************************************************************************/
#define REG_FUNC_INIT                          1
#define REG_FUNC_NOT_INIT                      0

#define REG_MULTI_CHIP_SUPORT                  (0x5A000000)
#define REG_MULTI_CHIP_MASK                    (0x00FFFFFF)

#define DDR_REG_MCS_LOAD_WORK_FLAG             BIT_SET(0)
#define DDR_REG_FLAG_DATA_CFG_FLAG             BIT_SET(1)
#define DDR_REG_FLAG_DATA_INIT_SET             BIT_SET(31)

#define MMAP_TYPE_MEM                           0
#define MMAP_TYPE_MEMCASHE                      1
#define MMAP_TYPE_MEMNC                         2

/**************************************************************************
*                         全局变量定义                                   *
**************************************************************************/

/**************************************************************************
*                         数据类型                                       *
**************************************************************************/

typedef volatile UINT32 T_LOACLABUS_REG;
typedef volatile UINT8 T8_LOACLABUS_REG;


typedef UINT32 (*pRegWrite)(UINT32 Idx, E_REG_FUNCID_DEF addr, UINT32 val);
typedef UINT32 (*pRegRead)(UINT32 Idx, E_REG_FUNCID_DEF addr, UINT32 *pVal);
typedef UINT32 (*pRegWriteMask)(UINT32 Idx, E_REG_FUNCID_DEF addr, UINT32 val, UINT32 mask);
typedef struct _T_Reg_DRV_ACCESS
{
    pRegWrite       pRegWr;
    pRegRead        pRegRd;
    pRegWriteMask   pWrMask;
    pRegWrite       pWrDir;

}T_Reg_Drv_Access;

/* =============统一寄存器打表结构定义===========================  */


/* =============单板使用============  */

/* =============统一寄存器打表结构定义:功能域头部信息============  */

typedef struct _T_Reg_Head_
{
    UINT32   regFuncDomainType;                          /* 指示寄存器的分类信息:中频、光口*/
    UINT32   accessType;                                 /* 指示寄存器的总线类型:spi总线、local bus*/
    UINT32   busWidth;                                   /* 总线位宽, 字节数 */
    UINT32   chanInter;                                  /* 模块内部的偏移*/
    UINT32   chipNum;                                    /* 芯片数,需要地址映射的芯片数*/
    unsigned long   mapPhyBaseAddr[MAX_CHIP_NUM];        /* RawPhyBaseAddr,是该片的内部编址基地址 */
    unsigned long   rawPhyBaseAddr[MAX_CHIP_NUM];        /* 是在第一片中的映射物理地址基地址*/
    UINT32   maxSize;                                    /* 模块最大空间   */
    unsigned long   virtualBaseAddr[MAX_CHIP_NUM];       /* 模块虚拟基地址   */
    UINT32   initFlag;                                   /* 模块初始化标记 */
    UINT32   subSectFlag;                                /* 从某个sect细分出来的子sect，offset访问受限*/
    UINT32   (*pcbCheck)(UINT32 chip);                   /* 访问入口检查校验函数 */
    UINT32   mmapType;
    UINT32   mmapMaskFlag;                               /* 设置mmap标志(0有效), Bit[0]表示第一个设备; 对于多片不需要mmap的设备配置1跳过 */
    UINT32   chipIndex;                                  /* 功能模块所在chip号 */
} T_Reg_Head;

/* =============统一寄存器打表结构定义:功能域寄存器定义(宏定义作为数组下标索引)============  */

typedef struct _T_Reg_Tbl_
{
    UINT32   regFuncDomainId;                /* 寄存器分类信息id :中频,光口,DDR*/
    UINT32   regProperty;                    /* 寄存器属性,是否需要初始化 */
    unsigned long   regAddr;                        /* 寄存器地址 */
    UINT32   regMask;                        /* 寄存器掩码 */
    UINT32   isMask;                         /* 掩码、非掩码 */
    UINT32   regVal;                         /* 寄存器数据 */
    UINT32   initFlag;
    UINT32   chipInfo;                       /* 多个芯片都有该寄存器,最高8bit是支持与否标志位,其余bit位置1表示该芯片号有效 */
} T_Reg_Tbl;

/* 器件驱动管脚定义相关结构体 */

#define BSP_SET_REG_TBL(idx,domain,addr,ismask,mask,val,type)          \
    [idx] =  /* 寄存器id */                                \
    {                                                      \
        .regFuncDomainId    =   domain,                    \
        .regAddr            =   addr,                      \
        .isMask             =   ismask,                    \
        .regMask            =   mask,                      \
        .regVal             =   val,                       \
        .regProperty        =   type,                      \
        .initFlag           =   REG_FUNC_INIT,             \
    }

#define BSP_CLR_REG_TBL(idx,domain,addr,ismask,mask,val,type)          \
    [idx] =  /* 寄存器id */                                \
    {                                                      \
        .regFuncDomainId    =   domain,                    \
        .regAddr            =   addr,                      \
        .isMask             =   ismask,                    \
        .regMask            =   mask,                      \
        .regVal             =   val,                       \
        .regProperty        =   type,                      \
        .initFlag           =   REG_FUNC_NOT_INIT,         \
    }

#define BSP_SET_REG_TBL_MULTICHIP(idx,domain,addr,ismask,mask,val,type,chip)          \
    [idx] =  /* 寄存器id */                                \
    {                                                      \
        .regFuncDomainId    =   domain,                    \
        .regAddr            =   addr,                      \
        .isMask             =   ismask,                    \
        .regMask            =   mask,                      \
        .regVal             =   val,                       \
        .regProperty        =   type,                      \
        .chipInfo           =   REG_MULTI_CHIP_SUPORT|chip,\
        .initFlag           =   REG_FUNC_INIT,             \
    }


#define REG_ACCESS_VAL     0  /*寄存器读写正常方式非掩码方式访问*/
#define REG_ACCESS_MASK    1  /*寄存器读写MASK 掩码方式访问*/
#define REG_ACCESS_MAX     2

typedef UINT32 (*pRegWr)(UINT32 chip,E_REG_FUNCID_DEF regIdx, UINT32 offSet, UINT32 val);
typedef UINT32 (*pRegRd)(UINT32 chip,E_REG_FUNCID_DEF regIdx, UINT32 offSet, UINT32 *pVal);

typedef struct _T_Reg_Access_  /*掩码方式访问/非掩码方式访问,先增加写操作,后续如果有读操作,在增加*/ 
{
    pRegWr    pRegAccessWr;    
}T_Reg_Access;



/**************************************************************************
*                         函数声明
**************************************************************************/
T_Reg_Drv_Access* BspGetRegAccess(UINT32 idx);
UINT32 BspGetDifChanOffset(E_REG_FUNCID_DEF funcIdx, UINT32* pOffSet);
UINT32 BspRegWr(UINT32 chip,E_REG_FUNCID_DEF regIdx, UINT32 offSet, UINT32 val);
UINT32 BspRegRd(UINT32 chip,E_REG_FUNCID_DEF regIdx, UINT32 offSet,UINT32 *pVal);
UINT32 BspRegBitValRd(UINT32 chip, E_REG_FUNCID_DEF regIdx, UINT32 offset, UINT32 bitLow, UINT32 bitHigh, UINT32 * pVal);
UINT32 BspRegBitValWr(UINT32 chip, E_REG_FUNCID_DEF regIdx, UINT32 offSet, UINT32 val, UINT32 bitLow, UINT32 bitHigh);
UINT32 BspGetMemBlockFromPhyAddr(UINT32 phyAddr, UINT32 *pBlock, UINT32 *pBlockBasePhyAddr,UINT32 *busWidth);
UINT32 BspRegDomainRd(UINT32 chipIdx,UINT32 funcDomainIdx, UINT32 offSet,UINT32 *pVal);
UINT32 BspRegDomainWr(UINT32 chipIdx,UINT32 funcDomainIdx, UINT32 offSet, UINT32 val);
UINT32 BspRegDomainWrMask(UINT32 chipIdx,UINT32 funcDomainIdx,UINT32 offSet, UINT32 val, UINT32 mask);
UINT32 BspInitRegVirAddr(VOID);
UINT32 BspRegAccessInit(VOID);
UINT32 BspSetRegTblHeadData(T_Reg_Head *pHead,UINT32 headLen);
UINT32 BspSetRegTblData(T_Reg_Tbl *pTbl,UINT32 num);
UINT32 BspGetRegChip(UINT32 regIdx,UINT32 *chipNo,UINT32 *chipNum);
UINT32 BspGetRegAddrAndMask(UINT32 chip, UINT32 regIdx, UINT32 offset, UINT32 *pRegAddr, UINT32 *pValMask);
UINT32 BspGetRegTabVal(UINT32 funcIdx, UINT32* pRegVal);
UINT32 BspGetRegTabAdd(UINT32 funcIdx, UINT32* pRegAdd);

UINT32 BspSetDdrRegAccessFlag(UINT32 ulChipIdx, UINT32 ulCfgOrClr, UINT32 ulAccessMask);
UINT32 BspRegTblValInit(VOID);


#ifdef __cplusplus
}
#endif
#endif /* BSP_REG_DRV_ACCESS_H_INCLUDED */




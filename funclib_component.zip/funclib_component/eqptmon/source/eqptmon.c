/*****************************************************************************
 * 版权所有(C) 2017, ZTE Corp. ZXSDR-RRU Platform BSP
 *----------------------------------------------------------------------------
 * 模 块 名 : BSP
 * 文件名称 : eqptmon.c
 * 文件标识 : {[N/A]}
 * 内容摘要 : 外围检测管脚获取平台文件
 * 注意事项 : 无
 *-------------------------------------------------------------------------- */
#include <bsppub.h>
#include "eqptmonapi.h"
#include "regdrv_pintbl.h"
#include "regdrv.h"
#include "regdrv_accesstbl.h"
#include "rruinfo.h"
#include "funccommonapi.h"

#define NO_LEAKAGE_WATER    (UINT32)(0)
#define LEAKAGE_WATER       (UINT32)(1)

static UINT32 CheckLeakageWater = 0;
static GET_SLAVE_PORT_ALM pGetSlavePortAlm = NULL;
BspJudgeCheckLeakageWaterFun JudgeCheckLeakageWater = NULL;

UINT32 BspGetSlavePortAlmCallBack(GET_SLAVE_PORT_ALM pFuncCallback)
{
    pGetSlavePortAlm = pFuncCallback;
    return BSP_OK;
}

//漏水检测集测较难制造，底层打桩制造出漏水告警：验证网管上报漏水告警流程
UINT32 BspSetCheckLeakageWaterFlag(UINT32 flag)
{
    CheckLeakageWater = flag;

    return BSP_OK;
}

/*********************************************************************
* BspCheckLeakageWaterState
* 功能描述：IC4.2通过检测GPIO：GP0_15来判别是否进水。
* 输入参数： 
* 
* 输出参数：无
* 返 回 值：0代表没有进水，1代表进水
* 其它说明：
*********************************************************************/
UINT32 BspCheckLeakageWaterState(void)
{
    UINT32 state         = BSP_OK;
    UINT32 regPinId      = 0;
    UINT32 hardId_B      = 0;
    UINT32 LeakWaterFlag = 0;
    UINT32 retVal = BSP_ERROR;

    if(NULL != JudgeCheckLeakageWater)
    {
        retVal = JudgeCheckLeakageWater();
        if(BSP_OK == retVal)
        {
            dbgInfoEx("[%s]: The bomid does not support water leakage detection. \n ", __FUNCTION__);
            return BSP_ERROR;
        }
    }

    hardId_B = BspGetHardwareCustomId_B();

    LeakWaterFlag = ((hardId_B & 0x02) >> 1);  //bomid第六个ID的bit1 1:支持漏水检测，0：不支持
    dbgInfoEx("[%s]: LeakWaterFlag = %d. \n", __FUNCTION__, LeakWaterFlag);

    if(LeakWaterFlag == 1)
    {
        regPinId = REG_LEAKAGE_DETECTION;
        state = BspRegPinRd(regPinId);
    }
    else
    {
        dbgInfoEx("[%s]: The bomid does not support water leakage detection. \n", __FUNCTION__);
        return BSP_ERROR;
    }

    if(1 == CheckLeakageWater)
    {
        return CheckLeakageWater;
    }

    return state;
}

/*FG信号，低电平表示正常 */
UINT32 BspCheckFanFG(UINT32 fanNo)
{
    UINT32 fanFG = 0;

    fanFG = BspRegPinRd(REG_FAN_REG_0 + fanNo);

    return fanFG;
}

UINT32 BspCheckSlaveLeakageWaterState(UINT32 portId)
{
    UINT32 portSta = 0;
    T_SlavePortGetAlm almSta = {0};
    UINT32 alm = 0;
    UINT32 status = 0;
    UINT32 retVal = BSP_OK;

    portSta = BspGetSlavePortStatus(portId);
    if(BSP_OK == portSta)
    {
        if(NULL != pGetSlavePortAlm)
        {
            retVal = pGetSlavePortAlm(portId, &almSta);
            CHECK_RETVAL(BspGetSlavePortAlm, retVal);
            alm = almSta.almState;
            if(alm & BIT_SET(14))  /*bit14：漏水告警*/
            {
                status = LEAKAGE_WATER;
            }
            else
            {
                status = NO_LEAKAGE_WATER;
            }
        }
    }

    dbgInfoEx("portId'%d, portSta'%d, alm'0x%04x(0:OK,1:Alarm)\n", portId, portSta, status);
    return status;
}

UINT32 BspSetNoSupportCheckLeakageWaterFun(BspJudgeCheckLeakageWaterFun ucFunc)
{
    INPUT_POINTER_CHECK(ucFunc);
    JudgeCheckLeakageWater = ucFunc;
    return BSP_OK;
}

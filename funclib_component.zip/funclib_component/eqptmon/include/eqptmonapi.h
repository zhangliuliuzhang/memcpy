/*****************************************************************************
 * 版权所有(C) 2022, ZTE Corp. ZXSDR-RRU Platform BSP
 *----------------------------------------------------------------------------
 * 模 块 名 : BSP
 * 文件名称 : eqptmonapi.h
 * 文件标识 : {[N/A]}
 * 内容摘要 : 外围设备监函数控头文件
 * 注意事项 : 无
 *-------------------------------------------------------------------------- */
#ifndef BSP_EQPT_MON_API_H_INCLUDED
#define BSP_EQPT_MON_API_H_INCLUDED

#ifdef __cplusplus
extern "C" {
#endif

#include "funccommon.h"

typedef UINT32 (*GET_SLAVE_PORT_ALM)(UINT32 portId, T_SlavePortGetAlm *pStaAck);
typedef UINT32 (*BspJudgeCheckLeakageWaterFun)(VOID);
UINT32 BspCheckLeakageWaterState(VOID);
UINT32 BspCheckFanFG(UINT32 fanNo);
UINT32 BspCheckSlaveLeakageWaterState(UINT32 portId);
UINT32 BspGetSlavePortAlmCallBack(GET_SLAVE_PORT_ALM pFuncCallback);
UINT32 BspSetNoSupportCheckLeakageWaterFun(BspJudgeCheckLeakageWaterFun ucFunc);

#ifdef __cplusplus
}
#endif
#endif

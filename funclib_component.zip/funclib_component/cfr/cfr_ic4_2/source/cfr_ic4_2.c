/*****************************************************************************
* 版权所有(C) 2021,  ZTE Corp. ZXSDR-RRU Platform BSP
*----------------------------------------------------------------------------
* 模 块 名 : CFR
* 文件名称 : cfr_ic4_2.c
* 文件标识 : {[N/A]}
* 内容摘要 : 本文件主要提供DPDIC4.2的CFR模块配置功能
* 注意事项 : 无
* 作    者 : 徐利波10307448
* 创建日期 : 2022-02-17
* 当前版本 : Ver1.0
*----------------------------------------------------------------------------
* 变更记录 :
*
* $记录1
* 变 更 单: $0000000(N/A)
* 责 任 人: 徐利波10307448
* 修改日戳: 2022-02-17
* 变更说明: 创建文件
*----------------------------------------------------------------------------
*/

#include "bspcomm.h"
#include "bsppub.h"
#include "cfr_ic4_2_cpgcal.h"
#include "cfr_ic4_2.h"
#include "freqcfgcommon.h"
#include "ichaladaptbspapi.h"
//#include "ichaladapt_ic4_2.h"
#include "ichaladapt_cfr_ic4_2.h"
#include "math.h"
#include "freqcfg_ic4_2.h"
#include "funccommonapi.h"
#include "funccommon.h"

/**************************************************************************
*                         全局变量定义                                   *
**************************************************************************/
UINT32 g_speCfrCfgFlag = 0;
UINT32 g_CfrGateInitFlag = 0;
UINT32 g_pCfrDymParaTblLen = 0;
UINT32 g_difChnChgHwMask = 0;
UINT32 g_cfrDssStartedSave = 0;
T_CfrGateCfgGroup *s_pCfrGateCfgGroup = NULL;
T_BspHalAdaptCfrParCommPara *s_pCfrParPara = NULL;
T_BspHalAdaptDpdParCommPara *s_pDpdParPara = NULL;
T_BspHalAdaptCfrParaHardCpg *s_pCfrHWCpgPara = NULL;
T_BspHalAdaptDifCommCfrPara *s_pCfrCommPara = NULL;
UINT32 g_cfrChnDssFlag = CFR_CARR_NO_EXIST_DSS; /*削峰通道是否存在频谱共享指示标志, 1:存在; 0:不存在*/
UINT32 g_cfrDssCarrMap[BSP_MAX_CARR_NUM][BSP_MAX_CARR_NUM] = {0}; /*Dss关系映射表,行号以及表中存储数值x均为削峰通道内载波序号;若x不为0,则x与所在行号一起索引得到的两个载波为Dss */
UINT32 g_cfrDssGroupFlag[BSP_MAX_CARR_NUM] = {0}; /*该数组中,所有值为的1元素,它们下标索引号对应载波为具有Dss关系的一组载波*/
UINT32	g_aulNBCarrMode[MAX_TX_CHANNEL][BSP_MAX_CARR_NUM]={0};
UINT32 g_refreshCfrCpgFlag[BSP_IC42_MAX_TX_CHAN_NUM] = {0};
static FUN_GET_POWCTRL_TSSI_INFO pGetTssiPowInfo = NULL;
static T_AllChnCpgCarrInfo *s_pAllChnCpgCarrInfo = NULL;
static FUN_GET_POWCTRL_Tx_IF_TSSI pGetTxIfTssiPow = NULL;
/**************************************************************************
 *                        宏定义
 **************************************************************************/
/**************************************************************************
*                         数据类型                                       *
**************************************************************************/
/**************************************************************************
 *                         函数声明
 **************************************************************************/
static VOID ClrExcessCpgCarrInfo(UINT32 bspChan);
UINT32 BspSetDssCfrOriginCoefAndRecordExcessCarr(UINT32 difChan, UINT32 carrIndex, UINT32 carrRadio, UINT32 carrBw, UINT32 coefLen, const INT32 *pCoefPara);
/**************************************************************************
 *                         函数实现
 **************************************************************************/
/*** g_speCfrCfgFlag 为是否支持动态频谱共享标志 ***/
UINT32 BspSetSpeCfrCfg(UINT32 speFlag)
{
    g_speCfrCfgFlag = speFlag;

    return BSP_OK;
}
UINT32 BspGetSpeCfrCfg(UINT32 *speFlag)
{
    INPUT_POINTER_CHECK(speFlag);

    *speFlag = g_speCfrCfgFlag;
    dbgInfoEx("%s|g_speCfrCfgFlag:%d\n",__FUNCTION__, g_speCfrCfgFlag);

    return BSP_OK;
}


/*****************************************************************************
*  函数名称   : BspSetCfrGateInitFlag
*  功能描述   : 配置初始化门限的时刻，配置CFR是门限初始化用CFR中的载波信息，配频传
               时延参数的时候用的载波信息为通道预存的信息，此接口只用于算法新提供
               的门限表中，自动匹配门限的方法中
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : gateFlag     - 0是配置CFR时的门限初始化，1是配频时的门限初始化
*  输出参数   : 无
*  返 回 值   : BSP_OK  - 成功;其它值为失败
*  其它说明   :
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 刘巨波@2017-05-28 14:55:24
*----------------------------------------------------------------------------
*/
UINT32 BspSetCfrGateInitFlag(UINT32 gateFlag)
{
    g_CfrGateInitFlag = gateFlag;
    return BSP_OK;
}

UINT32 BspGetCfrGateInitFlag(UINT32 *gateFlag)
{
    INPUT_POINTER_CHECK(gateFlag);

    *gateFlag = g_CfrGateInitFlag;
    dbgInfoEx("[%s] g_CfrGateInitFlag:%d\n",__FUNCTION__, g_CfrGateInitFlag);

    return BSP_OK;
}

/*****************************************************************************
*  函数名称   : BspCfrCfg
*  功能描述   : CFR削峰门限配置
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : difChn     - cfr中频通道号
*  输出参数   : 无
*  返 回 值   : BSP_OK  - 成功;其它值为失败
*  其它说明   :
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2017-05-28 14:55:24
*----------------------------------------------------------------------------
*/
UINT32 BspCfrCfg(UINT32 difChan)
{
    UINT32 ret = BSP_OK;
    UINT32 freqBand = 0;
    UINT32 loop = 0;
    FLOAT fGateCoef = 1.0;
    UINT32 cfrGate[E_CFR_THR_NUM] = {0};
    UINT32 cfrWin[E_CFR_THR_NUM]  = {0};
    UINT32 cfrWinLevel[E_CFR_THR_NUM] = {0};
    UINT32 cfrDelt[E_CFR_THR_NUM] = {0};

    INPUT_DIFCHAN_CHECK(difChan);

    ret |= BspGetCfrGatePara(difChan, cfrGate);
    ret |= BspGetCfrGateCoef(difChan, &fGateCoef);

    for(loop = 0; loop < E_CFR_THR_NUM; loop++)
    {
        cfrGate[loop] = (UINT32)((DOUBLE)cfrGate[loop] * fGateCoef + 0.5);
    }

    ret |= BspGetCfrWinPara(difChan, cfrWin);
    ret |= BspGetCfrDeltPara(difChan, cfrDelt);
    ret |= BspGetCfrWinLevelPara(difChan,cfrWinLevel);
    ret |= BspHalAdaptSetCfrGate(difChan, freqBand, cfrGate, E_CFR_THR_NUM);
    ret |= BspSetCfrGateCfg(difChan, E_CFR_THR_NUM, cfrGate);
    ret |= BspHalAdaptSetCfrWin(difChan, freqBand, cfrWin, E_CFR_THR_NUM);
    ret |= BspHalAdaptSetCfrDelt(difChan, freqBand, cfrDelt, E_CFR_THR_NUM);
    ret |= BspHalAdaptSetCfrWinlevel(difChan, freqBand, cfrWinLevel, E_CFR_THR_NUM);

    return ret;
}

/*****************************************************************************
*  函数名称   : BspCfrSetSwitch
*  功能描述   : CFR 开关
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : difChan       - 中频通道号
*             :
*  输出参数   : 无
*  返 回 值   : BSP_OK  - 成功;其它值为失败
*  其它说明   :
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2015-11-28 14:55:24
*----------------------------------------------------------------------------
*/
UINT32 BspCfrSetSwitch(UINT32 difChan,UINT32 cfrOnOff)
{
	UINT32 cfrOutMode = 0;
    UINT32 freqBand = 0;
	cfrOutMode = (cfrOnOff == CFR_FUNC_ON)?IC_CFR_ON:IC_CFR_OFF;
    return BspHalAdaptSetCfrSwitch(difChan, freqBand, cfrOutMode);
}

/*****************************************************************************
*  函数名称   : BspCfrSetEnable
*  功能描述   : CFR Enable
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : difChan       - 中频通道号
*             :
*  输出参数   : 无
*  返 回 值   : BSP_OK  - 成功;其它值为失败
*  其它说明   :
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2015-11-28 14:55:24
*----------------------------------------------------------------------------
*/
UINT32 BspCfrSetEnable(UINT32 difChan)
{
    return BspCfrSetSwitch(difChan, CFR_FUNC_ON);
}

/*****************************************************************************
*  函数名称   : BspCfrSetDisable
*  功能描述   : CFR Disable
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : difChan       - 中频通道号
*             :
*  输出参数   : 无
*  返 回 值   : BSP_OK  - 成功;其它值为失败
*  其它说明   :
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2015-11-28 14:55:24
*----------------------------------------------------------------------------
*/
UINT32 BspCfrSetDisable(UINT32 difChan)
{
    return BspCfrSetSwitch(difChan, CFR_FUNC_OFF);
}

/*****************************************************************************
*  函数名称   : BspChnMaskToDif
*  功能描述   : 将BSP通道掩码转换为中频通道掩码
*  输入参数   : bspChnMask   - BSP通道掩码
*  输出参数   : difChnMask   - 中频通道掩码
*  返 回 值   : BSP_OK  - 成功;其它值为失败
*  其它说明   : 通道号与bit位对应。
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 10307448徐利波@2022-04-29 10:48:26
*----------------------------------------------------------------------------
*/
UINT32 BspChnMaskToDif(UINT32 bspChnMask, UINT32 *difChnMask)
{
    UINT32 retVal         = BSP_OK;
    UINT32 chipidx        = 0;
    UINT32 bspChn         = 0;
	UINT32 difChn         = 0;
    UINT32 bitValue       = 0;
    UINT32 difChnMaskTemp = 0;

    INPUT_POINTER_CHECK(difChnMask);

    for(bspChn = 0; bspChn < BspGetTxChanNum(); bspChn++)
    {
        retVal  = BspGetDifInfoByBspChn(bspChn, TX, &chipidx, &difChn);
        if (BSP_OK != retVal)
        {
            dbgInfoEx("%s>>bspChan'%d BspGetDifInfoByBspChn Get Error!\n",__FUNCTION__, bspChn);
            return BSP_ERROR;
        }

        bitValue = GET_BIT(bspChnMask, bspChn);
        WRITE_BIT(difChnMaskTemp, difChn, bitValue);
    }

    *difChnMask = difChnMaskTemp;

    return retVal;
}

/*****************************************************************************
*  函数名称   : BspCHgChnMaskToHw
*  功能描述   : 剔除改配中频通道掩码中CPG系数为软件计算的部分
*  输入参数   : difChnChgMask   - 改配中频通道掩码
*  输出参数   : difChnHwMask   - CPG系数采用硬件计算的改配中频通道掩码
*  返 回 值   : BSP_OK  - 成功;其它值为失败
*  其它说明   : 通道号与bit位对应。
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 10307448徐利波@2022-04-29 15:23:06
*----------------------------------------------------------------------------
*/
UINT32 BspCHgChnMaskToHw(UINT32 difChnChgMask, UINT32 *difChnHwMask)
{
    UINT32 retVal = BSP_OK;
	UINT32 difChn = 0;

    INPUT_POINTER_CHECK(difChnHwMask);

    if(s_pCfrCommPara == NULL)
    {
        dbgInfoEx("%s>> s_pCfrCommPara not initialized!\n",__FUNCTION__);
        return BSP_ERROR;
    }

    for(difChn = 0; difChn < BspGetTxChanNum(); difChn++)
    {
        if(CFR_CPG_CPU_CAL == s_pCfrCommPara->uiCpgMode[difChn])
        {
            CLEAR_BIT(difChnChgMask, difChn);
        }
    }

    *difChnHwMask = difChnChgMask;
    g_difChnChgHwMask = difChnChgMask;

    return retVal;
}

/** 获取削峰硬件计算存在改配的通道掩码 **/
UINT32 BspGetDifChnHwMask(UINT32 *chnMask)
{
    INPUT_POINTER_CHECK(chnMask);

    *chnMask = g_difChnChgHwMask;
    dbgInfoEx("%s|g_difChnChgHwMask: 0x%x \n",__FUNCTION__, g_difChnChgHwMask);

    return BSP_OK;
}


/*****************************************************************************
*  函数名称   : BspCfrCarrJudgeDss
*  功能描述   : 判断两载波是否存在频谱共享
*  输入参数   : difchan:中频通道号
               freqBand:频段号
               carrNo1:T_CfrChnBandInfo中的载波序号，非载波号
               carrNo2:T_CfrChnBandInfo中的载波序号，非载波号
               pChnInfo：削峰通道中的载波信息
*  输出参数   : dssFlag: 是否动态频谱共享标志（1：频谱共享；0：非频谱共享）
*  返 回 值   : BSP_OK  - 成功;其它值为失败
*  其它说明   : DSS四种场景:1.c1右与c2左重叠, 2.c2右与c1左, 3.c1被c2全覆盖, 4.c2被c1全覆盖
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 10307448徐利波@2022-10-24 09:29:48
*----------------------------------------------------------------------------
*/
UINT32 BspCfrCarrJudgeDss(UINT32 difchan, UINT32 freqBand, UINT32 carrNo1, UINT32 carrNo2, T_CfrChnBandInfo *pChnInfo, UINT32 *dssFlag)
{
    INT32 carr1FreqUp  = 0;
    INT32 carr1FreqLow = 0;
    INT32 carr2FreqUp  = 0;
    INT32 carr2FreqLow = 0;
    UINT32 carrDssflag  = CFR_CARR_NO_EXIST_DSS;

    INPUT_POINTER_CHECK(pChnInfo);
    INPUT_POINTER_CHECK(dssFlag);

    if (pChnInfo->usedFlag[freqBand] == CFR_BAND_NOT_USED)
    {
        dbgInfoEx("[%s] Error, the band %d is not used! \n", __FUNCTION__, freqBand);
        return BSP_ERROR;
    }
    
    carr1FreqUp = pChnInfo->carrInfo[freqBand][carrNo1].freq + (pChnInfo->carrInfo[freqBand][carrNo1].carrBw)/2;
    carr1FreqLow = pChnInfo->carrInfo[freqBand][carrNo1].freq - (pChnInfo->carrInfo[freqBand][carrNo1].carrBw)/2;

    carr2FreqUp = pChnInfo->carrInfo[freqBand][carrNo2].freq + (pChnInfo->carrInfo[freqBand][carrNo2].carrBw)/2;
    carr2FreqLow = pChnInfo->carrInfo[freqBand][carrNo2].freq - (pChnInfo->carrInfo[freqBand][carrNo2].carrBw)/2;

    if( ((carr1FreqLow <= carr2FreqLow) && ((carr1FreqUp - carr2FreqLow) > CFR_DSS_MERGE_MIN_BW)) || (((carr2FreqUp - carr1FreqLow) > CFR_DSS_MERGE_MIN_BW) && (carr2FreqUp <= carr1FreqUp))
        || ((carr2FreqLow <= carr1FreqLow) && ((carr2FreqUp - carr1FreqLow) > CFR_DSS_MERGE_MIN_BW)) || (((carr1FreqUp - carr2FreqLow) > CFR_DSS_MERGE_MIN_BW) && (carr1FreqUp <= carr2FreqUp)) )
    {
        carrDssflag = CFR_CARR_EXIST_DSS;
        dbgInfoEx("[%s] difchan'%d, index'%d(carrNo'%d radio'0x%x feq:%d ~ %d) and index'%d(carrNo'%d radio'0x%x feq:%d ~ %d) is DSS.\n",__FUNCTION__,difchan,
            carrNo1,pChnInfo->carrInfo[freqBand][carrNo1].carrNo,pChnInfo->carrInfo[freqBand][carrNo1].carrRadio,carr1FreqLow,carr1FreqUp,
            carrNo2,pChnInfo->carrInfo[freqBand][carrNo2].carrNo,pChnInfo->carrInfo[freqBand][carrNo2].carrRadio,carr2FreqLow,carr2FreqUp);
    }

    *dssFlag = carrDssflag;

    return BSP_OK;
}

/*****************************************************************************
*  函数名称   : BspCfrInitCarrDssMap
*  功能描述   : 初始化削峰通道内载波频谱共享关系映射表
*  输入参数   : difChn ： 中频通道号
*  输出参数   : 全局变量 g_cfrDssCarrMap, 记录了通道内所有DSS载波: 载波频谱共享映射表(全局变量),
                大小为8X8，表中数值i若不为0, 则表示载波i与该行号对应的载波频谱共享。
*  返 回 值   : BSP_OK  - 成功;其它值为失败
*  其它说明   : IC4.2 削峰只考虑 LTE 或 NR 两种载波的频谱共享。
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 10307448徐利波@2022-10-24 20:09:05
*----------------------------------------------------------------------------
*/
UINT32 BspCfrInitCarrDssMap(UINT32 difChn)
{
    UINT32 retVal    = BSP_OK;
    UINT32 rowLoop   = 0;
    UINT32 colLoop   = 0;
    UINT32 freqBand  = 0;
    UINT32 sharedNum = 0;
    UINT32 index     = 0;
    UINT32 dssFlag   = CFR_CARR_NO_EXIST_DSS;
    T_CfrChnBandInfo *pChnInfo = NULL;

    pChnInfo = BspGetCfrChnInfo(difChn);
    if (pChnInfo == NULL)
    {
        dbgInfoEx("[%s]Get Cfr Dif Chn[%d] Info Error \n", __FUNCTION__, difChn);
        return BSP_ERROR;
    }

    for (index = 0; index < pChnInfo->bandCarrNum[freqBand]; index++)
    {
        if (pChnInfo->carrInfo[freqBand][index].carrFlag == CFR_CARR_INVALID)
        {
            continue;
        }

        dbgInfoEx("[%s] [validCarr] chn'%d, index'%d, carrNo'%d, radio'0x%x, carrBw'%d, carrFreq'%d, pow'%d\n", __FUNCTION__, \
                difChn, index, pChnInfo->carrInfo[freqBand][index].carrNo, pChnInfo->carrInfo[freqBand][index].carrRadio, \
                pChnInfo->carrInfo[freqBand][index].carrBw, pChnInfo->carrInfo[freqBand][index].freq, pChnInfo->carrInfo[freqBand][index].powerMw);
    }

    for (rowLoop = 0; rowLoop < BSP_MAX_CARR_NUM; rowLoop++)
    {
        for (colLoop = 0; colLoop < BSP_MAX_CARR_NUM; colLoop++)
        {
            g_cfrDssCarrMap[rowLoop][colLoop] = CFR_CARR_NO_EXIST_DSS;
        }
    }
    
    for (rowLoop = 0; rowLoop < BSP_MAX_CARR_NUM; rowLoop++)
    {
        if ( (pChnInfo->carrInfo[freqBand][rowLoop].carrFlag == CFR_CARR_INVALID) 
            || (pChnInfo->carrInfo[freqBand][rowLoop].carrRadio == BSP_RADIO_STANDARD_GSM) 
            || (pChnInfo->carrInfo[freqBand][rowLoop].carrRadio == BSP_RADIO_STANDARD_UMTS)
            || (pChnInfo->carrInfo[freqBand][rowLoop].carrRadio == BSP_RADIO_STANDARD_NB_IOT))
        {
            continue;
        }

        sharedNum = 0;
        for (colLoop = rowLoop+1; colLoop < BSP_MAX_CARR_NUM; colLoop++)
        {
            if ( (pChnInfo->carrInfo[freqBand][colLoop].carrFlag == CFR_CARR_INVALID) 
                || (pChnInfo->carrInfo[freqBand][colLoop].carrRadio == BSP_RADIO_STANDARD_GSM) 
                || (pChnInfo->carrInfo[freqBand][colLoop].carrRadio == BSP_RADIO_STANDARD_UMTS)
                || (pChnInfo->carrInfo[freqBand][colLoop].carrRadio == BSP_RADIO_STANDARD_NB_IOT))
            {
                continue;
            }

            retVal |= BspCfrCarrJudgeDss(difChn, freqBand, rowLoop, colLoop, pChnInfo, &dssFlag);
            if (CFR_CARR_EXIST_DSS == dssFlag)
            {
                g_cfrDssCarrMap[rowLoop][sharedNum++] = colLoop;
                g_cfrChnDssFlag = CFR_CARR_EXIST_DSS;
            }
        } 
    }

    for (index = 0; index < 8; index++)
    {
        dbgInfoEx("[%s] dssmap carrIndex'%d <--> (Find non-zero val:) %d, %d, %d, %d, %d, %d, %d, %d. \n",__FUNCTION__, index, \
                g_cfrDssCarrMap[index][0], g_cfrDssCarrMap[index][1], g_cfrDssCarrMap[index][2], g_cfrDssCarrMap[index][3], \
                g_cfrDssCarrMap[index][4],g_cfrDssCarrMap[index][5],g_cfrDssCarrMap[index][6],g_cfrDssCarrMap[index][7]);
    }

    return retVal;
}

/*****************************************************************************
*  函数名称   : BspCfrInitDSSCarrGroup
*  功能描述   : 筛选出具有频谱共享关系的一组载波
*  输入参数   : row ： 全局变量 g_cfrDssCarrMap 中遍历行与列时第一个数值不为零的行号。
*  输出参数   : g_cfrDssGroupFlag ：具有频谱共享关系的载波编号对应下标置1的全局变量一维数组
*  返 回 值   : BSP_OK  - 成功;其它值为失败
*  其它说明   : IC4.2 削峰只考虑 LTE 或 NR 两种载波的频谱共享。
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 10307448徐利波@2022-10-28 20:33:00
*----------------------------------------------------------------------------
*/
UINT32 BspCfrInitDSSCarrGroup(UINT32 row)
{
    UINT32 retVal = BSP_OK;
    UINT32 index  = 0;

    if (row >= BSP_MAX_CARR_NUM)
    {
        return BSP_ERROR;
    }
    
    g_cfrDssGroupFlag[row] = CFR_CARR_EXIST_DSS;

    for (index = 0; index < BSP_MAX_CARR_NUM; index++)
    {
        if (0 == g_cfrDssCarrMap[row][index])
        {
            break;
        }

        retVal |= BspCfrInitDSSCarrGroup(g_cfrDssCarrMap[row][index]);
        g_cfrDssCarrMap[row][index] = 0;
    }  

    return retVal;
}

/*****************************************************************************
*  函数名称   : BspCfrSetDssCarrInfo
*  功能描述   : 设置通道内DSS载波信息
*  输入参数   : difChn ： 中频通道号
*  输出参数   : pChnInfo ：原带宽较大载波为主载波,被共享载波置为无效;主载波带宽为共享后频谱
                          最左到最右宽度,频点为共享频谱的中心,主载功率:若用实时功率则直接
                          线性相加,若用配置功率则求和后减去功率谱密度低载波的重叠部分。
*  返 回 值   : BSP_OK  - 成功;其它值为失败
*  其它说明   : 1、IC4.2 削峰只考虑 LTE 或 NR 两种载波的频谱共享;
               2、DSS硬件计算场景才向HAL层传递载波信息用于功率的计算;
               3、该接口调用一次仅处理一组频谱共享的载波,并不是一次处理完通道内所有的DSS载波。
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 10307448徐利波@2022-10-28 21:02:13
*----------------------------------------------------------------------------
*/
UINT32 BspCfrSetDssCarrInfo(UINT32 difChn, T_CfrChnBandInfo *pChnInfo)
{
    UINT32 retVal         = BSP_OK;
    UINT32 band           = 0;
    UINT32 carrBw         = 0;
    UINT32 carrFreq       = 0;
    UINT32 dssBw          = 0;
    UINT32 cpgBw          = 0;
    UINT32 maxBwCarrIndex = 0;
    UINT32 maxBwCarrNo    = 0;
    UINT32 maxBwCarrRadio = 0;
    UINT32 maxCarrBw      = 0;
    UINT32 maxDssFreq     = 0;
    UINT32 index          = 0;
    UINT32 cpgMode        = 0;
    UINT32 minDssFreq     = 0xffffffff;
    UINT32 bspChn         = 0;
    UINT32 dssCarrPow     = 0;
    T_BspHalAdaptCfrDssCarrInfo sharedCarr = {0};

    INPUT_POINTER_CHECK(pChnInfo);

    if(s_pCfrCommPara == NULL)
    {
        dbgInfoEx("%s Get CFR Commom Para Error!\n",__FUNCTION__);
        return BSP_ERROR;
    }
    cpgMode = s_pCfrCommPara->uiCpgMode[difChn];

    /*寻找大带宽的主载波并获取共享频谱左右频点边界*/
    for (index = 0; index < BSP_MAX_CARR_NUM; index++)
    {
        if (g_cfrDssGroupFlag[index] != 0)
        {
            carrBw = pChnInfo->carrInfo[band][index].carrBw;
            carrFreq = pChnInfo->carrInfo[band][index].freq;

            if (maxCarrBw < carrBw)
            {
                maxCarrBw = carrBw;
                maxBwCarrIndex = index;
            }

            if (maxDssFreq < (carrFreq + (carrBw / 2)))
            {
                maxDssFreq = carrFreq + (carrBw / 2);
            }

            if (minDssFreq > (carrFreq - (carrBw / 2)))
            {
                minDssFreq = carrFreq - (carrBw / 2);
            }

            dbgInfoEx("[%s] Chn'%d, index'%d, carrNo'%d, radio'0x%x, carrBw'%d, freq'%d, pow'%d, is dss carr. \n", __FUNCTION__, difChn, index, \
                pChnInfo->carrInfo[band][index].carrNo, pChnInfo->carrInfo[band][index].carrRadio, carrBw, carrFreq, pChnInfo->carrInfo[band][index].powerMw);
        }
    }

    /*统计被共享的载波并置为无效*/
    for (index = 0; index < BSP_MAX_CARR_NUM; index++)
    {
        if ((g_cfrDssGroupFlag[index] != 0) && (index != maxBwCarrIndex))
        {
            /*硬件计算模式,需保存被共享载波的信息,并传递至中频*/
            if(cpgMode == CFR_CPG_HW_CAL)
            {
                sharedCarr.uiCarrId[sharedCarr.uiCarrNum % DLCFR_CFR_CPG_ONLINE_MAX_CARR] = pChnInfo->carrInfo[band][index].carrNo;
                sharedCarr.uiCarrRadio[sharedCarr.uiCarrNum % DLCFR_CFR_CPG_ONLINE_MAX_CARR] = pChnInfo->carrInfo[band][index].carrRadio;
                sharedCarr.uiCarrNum += 1;
                dbgInfoEx("[%s] Send to Hal: Chn'%d, carrNo'%d, carrRadio'0x%x. \n", __FUNCTION__,
                        difChn, pChnInfo->carrInfo[band][index].carrNo, pChnInfo->carrInfo[band][index].carrRadio);
            }

            pChnInfo->carrInfo[band][index].carrFlag = CFR_CARR_INVALID;
        }
    }
    dbgInfoEx("[%s] Send to Hal MaxBwCarr: Chn'%d, index'%d, carrNo'%d, radio'0x%x, originBw'%d, MaxDssBw'%d(MaxFeq'%d-MinFeq'%d). \n", \
            __FUNCTION__, difChn, maxBwCarrIndex, pChnInfo->carrInfo[band][maxBwCarrIndex].carrNo, pChnInfo->carrInfo[band][maxBwCarrIndex].carrRadio, \
            pChnInfo->carrInfo[band][maxBwCarrIndex].carrBw, (maxDssFreq - minDssFreq),maxDssFreq,minDssFreq);

    dssBw = maxDssFreq - minDssFreq;
    retVal |= BspUpdateUsableCpgBw(dssBw, &cpgBw);
    retVal |= BspGetBspChnInfoByDifChn(difChn, TX, &bspChn);
    retVal |= BspGetDssCarrPow(bspChn, pChnInfo, &dssCarrPow);

    pChnInfo->carrInfo[band][maxBwCarrIndex].powerMw = dssCarrPow;
    pChnInfo->carrInfo[band][maxBwCarrIndex].carrBw = cpgBw;
    pChnInfo->carrInfo[band][maxBwCarrIndex].freq = (maxDssFreq + minDssFreq) / 2;
    pChnInfo->carrInfo[band][maxBwCarrIndex].carrFlag = CFR_CARR_DSS_OWNER;
    maxBwCarrNo = pChnInfo->carrInfo[band][maxBwCarrIndex].carrNo;
    maxBwCarrRadio = pChnInfo->carrInfo[band][maxBwCarrIndex].carrRadio;

    if(cpgMode == CFR_CPG_HW_CAL)
    {
        retVal |= BspHalAdaptCfrSetDssCarrInfo(difChn, maxBwCarrNo, maxBwCarrRadio, &sharedCarr);
    }

    return retVal;
}

/*****************************************************************************
*  函数名称   : BspCfrDssSetHwCpgCfg
*  功能描述   : 频谱共享场景下的削峰在线计算CPG配置
*  输入参数   : difChn ： 中频通道号
*  输出参数   : 无
*  返 回 值   : BSP_OK  - 成功;其它值为失败
*  其它说明   : 无
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 10307448徐利波@2022-10-25 09:21:41
*----------------------------------------------------------------------------
*/
UINT32 BspCfrDssSetHwCpgCfg(UINT32 difChn)
{
    UINT32 retVal         = BSP_OK;
    UINT32 retValOfSetCfrCoef = BSP_OK;
    UINT32 bandLoop       = 0;
    UINT32 carrLoop       = 0;
    UINT32 cnt            = 0;
    UINT32 carrBw         = 0;
    UINT32 cfrBw          = 0;
    UINT32 cfrFs          = 0;
    UINT32 carrPowMw      = 0;
    UINT32 carrNo         = 0;
    UINT32 hwChnMask      = 0;
    UINT32 originCoefLen  = 0;
    UINT32 originValidLen = 0;
    UINT32 carrRadio      = 0;
    UINT32 staPowStepFreq = 0;
    UINT32 deltPowFreq    = 0;
    UINT32 ratedPower     = 0;
    UINT32 symNum         = 0;
    UINT32 uiFreqWord     = 0;
    UINT32 rowLoop        = 0;
    UINT32 colLoop        = 0;
    UINT32 groupLoop      = 0;
    INT32 freqWord        = 0;
    INT32 fi              = 0;
    DOUBLE wei            = 0.0;
    DOUBLE giTemp         = 0.0;
    DOUBLE giTempMax      = 1.0;
    DOUBLE gi             = 0.0;
    DOUBLE ciSq           = 0.0;
    DOUBLE pci            = 0.0;
    UINT32 chnChgFlag     = CFR_CHN_NO_CHANGE;
    T_CfrChnBandInfo *pChnInfo = NULL;
    T_CfrCpgPara cfrCpgPara = {0};
    T_BspHalAdaptCfrParaHardCpg cfrHWCpgPara = {0};
    T_BspHalAdaptDifCommCfrPara cfrCommPara = {0};

    retVal |= BspGetDifChnHwMask(&hwChnMask);
    retVal |= BspGetCfrFsByDifChn(difChn,&cfrFs);
    retVal |= BspGetCfrKiCommPara(&cfrHWCpgPara);
    retVal |= BspGetCfrCommPara(&cfrCommPara);
    retVal |= BspGetRruPathRatedPower(difChn, &ratedPower); 

    if (CFR_CHN_CHANGE == GET_BIT(hwChnMask, difChn))
    {
        chnChgFlag = CFR_CHN_CHANGE;
    }

    dbgInfoEx("[%s] chn'%u, cfrFs:%u, chgFlag'%u, ratedPower:%u \n", __FUNCTION__, difChn, cfrFs, chnChgFlag, ratedPower);

    pChnInfo = BspGetCfrChnInfo(difChn);
    if (pChnInfo == NULL)
    {
        dbgInfoEx("[%s]Get Cfr Dif Chn[%d] Info Error \n", __FUNCTION__, difChn);
        BspLog(LOG_LEVEL_0,"[%s] Get Cfr Chn[%d] Rf Para Error! \n", __FUNCTION__,difChn);
        return BSP_ERROR;
    }

    for (groupLoop = 0; groupLoop < CFR_CHN_DSS_GROUP_MAX_NUM; groupLoop++)
    {
        g_cfrDssStartedSave = CFR_STOP_GET_DSS_GROUP;

        for (rowLoop = 0; rowLoop < BSP_MAX_CARR_NUM; rowLoop++)
        {
            for (colLoop = 0; colLoop < BSP_MAX_CARR_NUM; colLoop++)
            {
                if (0 == g_cfrDssCarrMap[rowLoop][colLoop])
                {
                    break;
                }

                if (CFR_START_GET_DSS_GROUP == g_cfrDssStartedSave)
                {
                    if (CFR_CARR_EXIST_DSS == g_cfrDssGroupFlag[ g_cfrDssCarrMap[rowLoop][colLoop] ])
                    {
                        retVal |= BspCfrInitDSSCarrGroup(rowLoop);
                    }
                }
                else
                {
                    retVal |= BspCfrInitDSSCarrGroup(rowLoop);
                    g_cfrDssStartedSave = CFR_START_GET_DSS_GROUP;
                }
            }
        }

        for (cnt = 0; cnt < BSP_MAX_CARR_NUM; cnt++)
        {
            if (g_cfrDssGroupFlag[cnt] != 0)
            {
                dbgInfoEx("[%s] groupLoop'%d, g_cfrDssGroupFlag: %d %d %d %d %d %d %d %d\n", __FUNCTION__, groupLoop, g_cfrDssGroupFlag[0],g_cfrDssGroupFlag[1],
                        g_cfrDssGroupFlag[2],g_cfrDssGroupFlag[3],g_cfrDssGroupFlag[4],g_cfrDssGroupFlag[5],g_cfrDssGroupFlag[6],g_cfrDssGroupFlag[7]);

                retVal |= BspCfrSetDssCarrInfo(difChn, pChnInfo);
                memset_s(g_cfrDssGroupFlag, sizeof(UINT32) * BSP_MAX_CARR_NUM, 0, sizeof(UINT32) * BSP_MAX_CARR_NUM);
                break;
            }
        }
    }

    for (cnt = 0; cnt < pChnInfo->bandCarrNum[0]; cnt++)
    {
        if (pChnInfo->carrInfo[0][cnt].carrFlag == CFR_CARR_INVALID)
        {
            continue;
        }

        dbgInfoEx("[%s] After DSS deal ChnInfo: difChn'%d, index'%u, carrNo'%d, radio'0x%x, carrBw'%d, Freq'%d, pow'%u \n", \
                __FUNCTION__, difChn, cnt, pChnInfo->carrInfo[0][cnt].carrNo, pChnInfo->carrInfo[0][cnt].carrRadio, \
                pChnInfo->carrInfo[0][cnt].carrBw, pChnInfo->carrInfo[0][cnt].freq, pChnInfo->carrInfo[0][cnt].powerMw);
    }

    retVal |= BspCfrCpgGetGiTempMax(difChn, 0, pChnInfo, &giTempMax);  /*非单边滤波削峰，滤波后带宽写0即可*/

    BspCheckCpgCarrNumValid();

    for (bandLoop = 0; bandLoop < E_CFR_BAND_MAX; bandLoop ++)
    {
        if (pChnInfo->usedFlag[bandLoop] == CFR_BAND_NOT_USED)
        {
            continue;
        }

        if (chnChgFlag == CFR_CHN_CHANGE)
        {
            retVal |= BspHalAdaptCfrCleanGi(difChn, bandLoop);
            retVal |= BspHalAdaptCfrSetDlpreKiIndexDvSel(difChn, bandLoop);
            retVal |= BspHalAdaptCfrSetCpgUpdateMode(difChn, bandLoop);
            retVal |= BspHalAdaptCfrClrOriginCoefCarrInfo(difChn, bandLoop);

            if (cfrCommPara.uiThrSel[difChn] == 1)
            {
                symNum = cfrHWCpgPara.uiSymNum0[difChn];
            }
            else
            {
                symNum = cfrHWCpgPara.uiSymNum1[difChn];
            }

            retVal |= BspHalAdaptCfrSetDlpreKiIndexNum(difChn, bandLoop, symNum);
        }

        retVal |= BspHalAdaptCfrCleanWord(difChn, bandLoop);
        
        for (carrLoop = 0; carrLoop < pChnInfo->bandCarrNum[bandLoop]; carrLoop++)
        {
            if (pChnInfo->carrInfo[bandLoop][carrLoop].carrFlag == CFR_CARR_INVALID)
            {
                continue;
            }

            fi = pChnInfo->carrInfo[bandLoop][carrLoop].carrFi;
            carrNo = pChnInfo->carrInfo[bandLoop][carrLoop].carrNo;
            carrBw = pChnInfo->carrInfo[bandLoop][carrLoop].carrBw;
            carrPowMw = pChnInfo->carrInfo[bandLoop][carrLoop].powerMw;
            carrRadio = pChnInfo->carrInfo[bandLoop][carrLoop].carrRadio;

            retVal |= BspCfrCpgGetWei(cfrFs, carrRadio, &wei);
            retVal |= BspGetCfrRadioBwFromBspBw(carrRadio, carrBw, &cfrBw);

            deltPowFreq = 31;
            if (carrRadio == RADIO_STANDARD_GSM)
            {
                if (carrPowMw > 0)
                {
                    deltPowFreq = (UINT32)round(10 * log10(ratedPower/carrPowMw));
                }
                
                retVal |= BspHalAdaptGetGsmPowLevel(difChn, carrNo, carrRadio, &staPowStepFreq);
            }
 
            retVal |= BspGetCfrCpgCoef_IC4_2(difChn,cfrBw,cfrFs, &cfrCpgPara);
            CONTINUE_IF_EXP((retVal != BSP_OK));
            CONTINUE_IF_EXP((retValOfSetCfrCoef != BSP_OK) && (retValOfSetCfrCoef != BSP_INVALID_VALUE));
            if (NULL == cfrCpgPara.pCoefPara)
            {
                continue;
            }

            originCoefLen = cfrCpgPara.coefLen;
            ciSq = 0;
            for (cnt = 0; cnt < (originCoefLen - 1); cnt++)
            {
                ciSq += pow(cfrCpgPara.pCoefPara[cnt], 2);
            }
      
            pci = 2 * ciSq + pow(cfrCpgPara.pCoefPara[originCoefLen - 1], 2);
            giTemp = (DOUBLE)(wei / sqrt(pci));
            retVal |= BspCfrGetCarrGi(difChn, carrNo, carrRadio, giTemp, giTempMax, &gi);
            if (BSP_OK != retVal)
            {
                return BSP_ERROR;
            }

            if(cfrCommPara.uiDelayEqualFlag[difChn] == 1)//如果是等时延
            {
                if (cfrCpgPara.vaildLen < 512)
                {
                    originValidLen = 509;
                }
                else
                {
                    originValidLen = cfrCommPara.uiCpgCoefLenHalfMax[difChn];
                }
            }
            else
            {
                originValidLen = cfrCpgPara.vaildLen;
            }

            if (chnChgFlag == CFR_CHN_CHANGE)
            {
                retVal |= BspHalAdaptCfrSetGi(difChn, bandLoop, carrNo, carrRadio, (UINT32)gi);
                retValOfSetCfrCoef = BspSetDssCfrOriginCoefAndRecordExcessCarr(difChn, carrNo, carrRadio, carrBw,originValidLen, &cfrCpgPara.pCoefPara[CPG_COEF_LEN_HALF_MAX_768 - originValidLen]);
                retVal |= BspHalAdaptSetDlpreKiIndexGsm(difChn, carrNo, carrRadio, staPowStepFreq, deltPowFreq);
                retVal |= BspHalAdaptCfrSetcfgFlag(difChn, bandLoop);
            }

            DIV_CHK_PRN_RET(cfrFs)
            freqWord = round(((DOUBLE)fi/cfrFs) * pow(2, 32));
            uiFreqWord = (UINT32)((freqWord < 0) ? (freqWord + pow(2,32)) : freqWord);

            dbgInfoEx("[%s] giTemp:%f, pci:%f, freqWord:0x%x, cfrBw'%u \n", __FUNCTION__, giTemp, pci, freqWord, cfrBw);
            dbgInfoEx("[%s] difChn'%u, carrIndex'%u, carrRadio'0x%x, carrPowMw'%u, carrBw'%u, carrFi:%d, wei:%f, gi:%f, uiFreqWord:%u\n",
                        __FUNCTION__, difChn, carrNo, carrRadio, carrPowMw, carrBw, fi, wei, gi, uiFreqWord);

            retVal |= BspHalAdaptCfrSetWord(difChn, bandLoop, carrNo, carrRadio, uiFreqWord);
        }
    }

    return retVal;
}

/*****************************************************************************
*  函数名称   : BspCfrDssSetCpuCpgCfg
*  功能描述   : 频谱共享场景下的软计算cpg系数初始化
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : difChan - 中频通道
*  输出参数   : 无
*  返 回 值   : BSP_OK  - 成功;其它值为失败
*  其它说明   : DSS软件计算：采用合并载波归一处理，带宽为最左到最右的宽度；
               功率取两载波中最大值，带宽和功率值归一到带宽较大的载波上。
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 10307448徐利波@2022-11-22 20:56:46
*----------------------------------------------------------------------------
*/
UINT32 BspCfrDssSetCpuCpgCfg(UINT32 difChn)
{
    UINT32 ret           = BSP_OK;
    UINT32 bandLoop      = 0;
    UINT32 carrLoop      = 0;
    UINT32 carrBw        = 0;
    UINT32 cfrBw         = 0;
    UINT32 cpgCoefBw     = 0;
    INT32 carrPowMw      = 0;
    UINT32 carrRadio     = 0;
    UINT32 carrNo        = 0;
    UINT32 cnt           = 0;
    DOUBLE Ki            = 0;
    DOUBLE wei           = 0.0;
    DOUBLE giTemp        = 0.0;
    DOUBLE giTempMax     = 1.0;
    DOUBLE gi            = 0.0;
    DOUBLE sumBandGK     = 0.0;
    DOUBLE ciSq          = 0.0;
    DOUBLE pci           = 0.0;
    DOUBLE *pCpgReal     = NULL;
    DOUBLE *pCpgImag     = NULL;
    INT32 fi             = 0;
    DOUBLE tempData      = 0.0;
    DOUBLE dQn           = 0.0;
    UINT32 ulDelayMode   = 0;
    UINT32 cfrFs         = 0;
    UINT32 bandNum       = 0;
    UINT32 cpgVaildLen   = 0;
    UINT32 originCoefLen = 0;
    UINT32 rowLoop       = 0;
    UINT32 colLoop       = 0;
    UINT32 groupLoop     = 0;
    UINT32 filterBw      = 0;
    INT32 filterFi       = 0;
    UINT32 ulCpgLen      = CFR_CPG_RAM_768;
    UINT32 appPowMw      = 0;
    UINT32 realPowMw     = 0;
    INT32 tssiPowDbm     = 0;
    INT32 tssiPowDbfs    = 0;
    DOUBLE powMw         = 0.0;
    UINT32 cpgCalcFlag   = 0;
    UINT32 powShareFlag  = 1;
    FUN_GET_POWCTRL_TSSI_INFO pGetTssiPowInfo = NULL;
    T_CfrChnBandInfo *pChnInfo = NULL;
    T_CfrCpgPara cfrCpgPara = {0};
    T_BspHalAdaptDifCommCfrPara *difPara = NULL;
	
    INPUT_DIFCHAN_CHECK(difChn);
    difPara = BspHalAdaptGetDifCfrPara();
    if(NULL != difPara)
    {
        ulDelayMode = difPara->uiDelayEqualFlag[difChn];
        ulCpgLen = difPara->uiCpgCoefLenHalfMax[difChn];
        dbgInfoEx("[%s] DlyMode is %d,CPG Len is %d\n ",__FUNCTION__,ulDelayMode,ulCpgLen);
    }

    ret |= BspGetCfrFsByDifChn(difChn,&cfrFs);
    ret |= BspGetRefreshCfrCpgFlag(difChn, &cpgCalcFlag);

    dbgInfoEx("[%s] chn'%u, cfrFs'%u, cpgReshFlag'%u. \n", __FUNCTION__, difChn, cfrFs, cpgCalcFlag);

    /* kw告警修改,考虑32/64位系统, 所以用ULONG */
    pCpgReal = (DOUBLE *)malloc(sizeof(DOUBLE) * CFR_CPG_RAM_768);    
    INPUT_POINTER_CHECK(pCpgReal);

    pCpgImag = (DOUBLE *)malloc((sizeof(DOUBLE) * CFR_CPG_RAM_768));
    if (pCpgImag == NULL)
    {
        free(pCpgReal);
        pCpgReal = NULL;
        dbgInfoEx("[%s]cpg space malloc error \n", __FUNCTION__);
        return BSP_ERROR;
    }

    memset(pCpgReal, 0, (sizeof(DOUBLE) * CFR_CPG_RAM_768));
    memset(pCpgImag, 0, (sizeof(DOUBLE) * CFR_CPG_RAM_768));

    pChnInfo = BspGetCfrChnInfo(difChn);
    if (pChnInfo == NULL)
    {
        dbgInfoEx("[%s]Get Cfr Dif Chn[%d] Info Error \n", __FUNCTION__, difChn);
        BspLog(LOG_LEVEL_0,"[%s] Get Cfr Chn[%d] Rf Para Error! \n", __FUNCTION__,difChn);
        free(pCpgImag);
        free(pCpgReal);
        pCpgReal = NULL;
        pCpgImag = NULL;
        return BSP_ERROR;
    }

    for (groupLoop = 0; groupLoop < CFR_CHN_DSS_GROUP_MAX_NUM; groupLoop++)
    {
        g_cfrDssStartedSave = CFR_STOP_GET_DSS_GROUP;

        for (rowLoop = 0; rowLoop < BSP_MAX_CARR_NUM; rowLoop++)
        {
            for (colLoop = 0; colLoop < BSP_MAX_CARR_NUM; colLoop++)
            {
                if (0 == g_cfrDssCarrMap[rowLoop][colLoop])
                {
                    break;
                }

                if (CFR_START_GET_DSS_GROUP == g_cfrDssStartedSave)
                {
                    if (CFR_CARR_EXIST_DSS == g_cfrDssGroupFlag[ g_cfrDssCarrMap[rowLoop][colLoop] ])
                    {
                        ret |= BspCfrInitDSSCarrGroup(rowLoop);
                    }
                }
                else
                {
                    ret |= BspCfrInitDSSCarrGroup(rowLoop);
                    g_cfrDssStartedSave = CFR_START_GET_DSS_GROUP;
                }
            }
        }

        for (cnt = 0; cnt < BSP_MAX_CARR_NUM; cnt++)
        {
            if (g_cfrDssGroupFlag[cnt] != 0)
            {
                dbgInfoEx("[%s] groupLoop'%d, g_cfrDssGroupFlag: %d %d %d %d %d %d %d %d\n", __FUNCTION__, groupLoop, g_cfrDssGroupFlag[0],g_cfrDssGroupFlag[1],
                        g_cfrDssGroupFlag[2],g_cfrDssGroupFlag[3],g_cfrDssGroupFlag[4],g_cfrDssGroupFlag[5],g_cfrDssGroupFlag[6],g_cfrDssGroupFlag[7]);

                ret |= BspCfrSetDssCarrInfo(difChn, pChnInfo);
                memset_s(g_cfrDssGroupFlag, sizeof(UINT32) * BSP_MAX_CARR_NUM, 0, sizeof(UINT32) * BSP_MAX_CARR_NUM);
                break;
            }
        }
    }

    for (cnt = 0; cnt < pChnInfo->bandCarrNum[0]; cnt++)
    {
        if (pChnInfo->carrInfo[0][cnt].carrFlag == CFR_CARR_INVALID)
        {
            continue;
        }

        dbgInfoEx("[%s] After DSS deal ChnInfo: difChn'%d, index'%u, carrNo'%d, radio'0x%x, carrBw'%d, Freq'%d, pow'%u \n", \
                __FUNCTION__, difChn, cnt, pChnInfo->carrInfo[0][cnt].carrNo, pChnInfo->carrInfo[0][cnt].carrRadio, \
                pChnInfo->carrInfo[0][cnt].carrBw, pChnInfo->carrInfo[0][cnt].freq, pChnInfo->carrInfo[0][cnt].powerMw);
    }

    ret |= BspCfrCpgGetGiTempMax(difChn, 0, pChnInfo, &giTempMax);  /*非单边滤波削峰，滤波后带宽写0即可*/

    for (bandLoop = 0; bandLoop < E_CFR_BAND_MAX; bandLoop ++)
    {
        if (pChnInfo->usedFlag[bandLoop] == CFR_BAND_NOT_USED)
        {
            continue;
        }
        bandNum ++;
        cpgVaildLen = 0;
        for (carrLoop = 0; carrLoop < pChnInfo->bandCarrNum[bandLoop]; carrLoop++)
        {
            if (pChnInfo->carrInfo[bandLoop][carrLoop].carrFlag == CFR_CARR_INVALID)
            {
                continue;
            }

            carrNo      = pChnInfo->carrInfo[bandLoop][carrLoop].carrNo;
            appPowMw    = pChnInfo->carrInfo[bandLoop][carrLoop].powerMw;
            carrBw      = pChnInfo->carrInfo[bandLoop][carrLoop].carrBw;
            carrRadio   = pChnInfo->carrInfo[bandLoop][carrLoop].carrRadio;
            fi          = pChnInfo->carrInfo[bandLoop][carrLoop].carrFi;
            cpgCoefBw   = carrBw;

            if (BSP_OK == BspJudgeCarrFilterByCpg(difChn, TX, carrNo, carrRadio))
            {
                ret |= BspGetFilterBw(difChn, carrNo, carrRadio, &filterBw);
                ret |= BspUpdateUsableCpgBw(filterBw, &cpgCoefBw);
                ret |= BspGetCfrFreqFiOffset(difChn, carrNo, carrRadio, &filterFi);
                appPowMw = (UINT32)((appPowMw * cpgCoefBw) / carrBw);
                fi = filterFi;
            }

            pGetTssiPowInfo = BspGetTssiPowInfoCallBackInit();
            RETURN_VAL_DO_IF_EXP(pGetTssiPowInfo == NULL, BSP_ERROR, free(pCpgReal); free(pCpgImag));
            pGetTssiPowInfo(difChn, carrRadio, carrNo, &tssiPowDbm, &tssiPowDbfs);
            powMw = pow(10, (tssiPowDbm * 1.0 / 100 / 10));
            realPowMw = (UINT32)powMw;
            ret |= BspJudgeCfrCpgRefreshCarrPow(cpgCalcFlag, powShareFlag, appPowMw, realPowMw, &carrPowMw);
            ret = BspGetCfrRadioBwFromBspBw(carrRadio, cpgCoefBw, &cfrBw);
            if (pChnInfo->carrInfo[bandLoop][carrLoop].carrFlag == CFR_CARR_DSS_OWNER)
            {
                carrPowMw = appPowMw;
            }

            dbgInfoEx("[%s] chn'%u, carrNo'%u, carrRadio'0x%x, carrPowMw'%u, appPowMw'%u, realPowMw'%u, carrBw'%u, cfrBw'%u, fi'%d.\n",
                    __FUNCTION__, difChn, carrNo, carrRadio, carrPowMw, appPowMw, realPowMw, carrBw, cfrBw, fi);

            if (0 != cfrFs)
            {
                dQn = 2.0 * CFR_PI * fi / cfrFs;/*KHZ*/
            }
            Ki = (DOUBLE)sqrt(carrPowMw);

            ret |= BspCfrCpgGetWei(cfrFs, carrRadio, &wei);
            ret |= BspGetCfrCpgCoef_IC4_2(difChn,cfrBw,cfrFs, &cfrCpgPara);
            if (ret != BSP_OK)
            {
                continue;
            }

            if(1 == ulDelayMode)//如果是等时延，cfr的CPG长度固定
            {
                cpgVaildLen = ulCpgLen;
            }
            else
            {
                cpgVaildLen = (cpgVaildLen>cfrCpgPara.vaildLen)?cpgVaildLen:cfrCpgPara.vaildLen;
            }

            originCoefLen = cfrCpgPara.coefLen;
            ciSq = 0;
            for (cnt = 0; cnt < (originCoefLen - 1); cnt++)
            {
                ciSq += pow(cfrCpgPara.pCoefPara[cnt], 2);
            }

            pci = (DOUBLE)(2 * ciSq + pow(cfrCpgPara.pCoefPara[originCoefLen - 1], 2));
            giTemp = (DOUBLE)(wei / sqrt(pci));
            ret |= BspCfrGetCarrGi(difChn, carrNo, carrRadio, giTemp, giTempMax, &gi);
            if (BSP_OK != ret)
            {
                free(pCpgReal);
                free(pCpgImag);
                pCpgReal = NULL;
                pCpgImag = NULL;
                return BSP_ERROR;
            }

            sumBandGK += gi * Ki;

            for (cnt = 0; cnt < originCoefLen; cnt++)
            {
                tempData = ((originCoefLen - 1 - cnt) * (-1.0) * dQn);
                pCpgReal[cnt] += ((DOUBLE)(Ki * gi * cos(tempData))) * (DOUBLE)cfrCpgPara.pCoefPara[cnt];
                pCpgImag[cnt] += ((DOUBLE)(Ki * gi * sin(tempData))) * (DOUBLE)cfrCpgPara.pCoefPara[cnt];
            }
        }

        if ((sumBandGK >= (-(DOUBLE)EPSINON)) && (sumBandGK <= (DOUBLE)EPSINON))
        {
            ret |= BspCfrDataSave_CpuCal(difChn, bandLoop, pCpgReal, pCpgImag, CFR_CPG_RAM_768, 1, cpgVaildLen);
            ret |= BSP_ERROR;
            BspLog(LOG_LEVEL_0, "[%s] Error, chan:%u cfr sumBandGK is zero! \n", __FUNCTION__, difChn);
        }
        else
        {
            ret |= BspCfrDataSave_CpuCal(difChn, bandLoop, pCpgReal, pCpgImag, CFR_CPG_RAM_768, sumBandGK,cpgVaildLen);
        }
        dbgInfoEx("%s>>DifChnl'%d BandIdx'%d sumBandGK'%f CpgInitCpuCal OK! DataSave %s!\n",
                __FUNCTION__, difChn, bandLoop, sumBandGK, (BSP_OK == ret) ? "Succ" : "Fail");

        memset(pCpgReal, 0, sizeof(DOUBLE)*originCoefLen);
        memset(pCpgImag, 0, sizeof(DOUBLE)*originCoefLen);
        sumBandGK = 0.0;
    }
    ret |= BspCfrSetBandNum(difChn,bandNum);

    free(pCpgReal);
    free(pCpgImag);
    pCpgReal = NULL;
    pCpgImag = NULL;

    return ret;
}

/*****************************************************************************
*  函数名称   : BspCfrSetCpgPara_HwCal
*  功能描述   : 配置削峰硬件计算 CPG 所需参数
*  输入参数   : bspChn   - BSP通道号
*  输出参数   : 无
*  返 回 值   : BSP_OK  - 成功;其它值为失败
*  其它说明   : 无
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 10307448徐利波@2022-04-30 10:43:40
*----------------------------------------------------------------------------
*/
UINT32 BspCfrSetCpgPara_HwCal(UINT32 bspChn)
{
    UINT32 retVal   = BSP_OK;
    UINT32 freqBand = 0;
    UINT32 suspend  = CFR_CPG_HW_CAL_STOP;
    UINT32 difChn   = 0;
    UINT32 chipidx  = 0;
    T_CfrChnBandInfo *pChnInfo = NULL;

    retVal = BspGetDifInfoByBspChn(bspChn, TX, &chipidx, &difChn);
    if (BSP_OK != retVal)
    {
        dbgInfoEx("%s>>bspChan'%d BspGetDifInfoByBspChn Get Error!\n",__FUNCTION__, bspChn);
        return BSP_ERROR;
    }

    retVal |= BspHalAdaptCfrSetCpgSuspend(difChn, freqBand, suspend);  

    pChnInfo = BspGetCfrChnInfo(difChn);
    if (pChnInfo == NULL)
    {
        dbgInfoEx("[%s]Get Cfr Dif Chn[%d] Info Error \n", __FUNCTION__, difChn);
        return BSP_ERROR;
    }

    ClrExcessCpgCarrInfo(bspChn);
    /* 使用全局变量前先进行初始化 */
    g_cfrChnDssFlag = CFR_CARR_NO_EXIST_DSS;

    retVal |= BspCfrInitCarrDssMap(difChn);
    retVal |= BspHalAdaptCfrCleanDlpreKiPowSel(difChn, freqBand);
    if (CFR_CARR_EXIST_DSS == g_cfrChnDssFlag)
    {
        dbgInfoEx("[%s]: difChn'%d  Cfr Cpg Use DSS Hardware Calculation! \n", __FUNCTION__,difChn);
        retVal |= BspCfrDssSetHwCpgCfg(difChn);
    }
    else
    {
        retVal |= BspCfrSetHwCpgCfg(difChn);
    }
    suspend = CFR_CPG_HW_CAL_START;
    retVal |= BspHalAdaptCfrSetCpgSuspend(difChn, freqBand, suspend);
    BspSysMsDelay(80);

    #if 0 /* 暂时屏蔽，待新机型需要该功能再打开注释 */
    retVal |= BspHalAdaptCfrSetCpgFreqCalStr(difChn, freqBand);
    BspSysMsDelay(100);
    retVal |= BspHalAdaptCfrSetCpgFreqCalStr(difChn, freqBand);
    #endif

    return retVal;
}

/*****************************************************************************
*  函数名称   : BspCfrSetCpgPara_CpuCal
*  功能描述   : 配置削峰软件计算 CPG 系数
*  输入参数   : bspChn   - BSP通道号
*  输出参数   : 无
*  返 回 值   : BSP_OK  - 成功;其它值为失败
*  其它说明   : 无
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 10307448徐利波@2022-04-30 10:42:14
*----------------------------------------------------------------------------
*/
UINT32 BspCfrSetCpgPara_CpuCal(UINT32 bspChn)
{
    UINT32 retVal   = BSP_OK;
    UINT32 difChn   = 0;
    UINT32 chipidx  = 0;

    retVal = BspCfrCpgDataMemApply();
    if(retVal == BSP_ERROR)
    {
        dbgInfoEx("[%s]Cfr Cpg Data Apply Mem Error \n", __FUNCTION__);
        return BSP_ERROR;
    }

    /* 使用全局变量前先进行初始化 */
    g_cfrChnDssFlag = CFR_CARR_NO_EXIST_DSS;
    retVal |= BspGetDifInfoByBspChn(bspChn, TX, &chipidx, &difChn);
    retVal |= BspCfrInitCarrDssMap(difChn);

    if (CFR_CARR_EXIST_DSS == g_cfrChnDssFlag)
    {
        dbgInfoEx("[%s]: difChn'%d  Cfr Cpg Use DSS CPU Calculation! \n", __FUNCTION__,difChn);
        retVal |= BspCfrDssSetCpuCpgCfg(difChn);
    }
    else
    {
        retVal |= BspCpgInit(difChn);
    }

    retVal |= BspSetCpgCfg(difChn);

    return retVal;
}

/*****************************************************************************
*  函数名称   : BspCfrJudgeCpgMode
*  功能描述   : 判断当前通道使用软计算或硬件计算
*  输入参数   : difChn   - 中频通道号
*  输出参数   : cpgMode  - 该通道最终使用的CP计算方式
*  返 回 值   : BSP_OK  - 成功;其它值为失败
*  其它说明   : 公共参数表中原为软计算则保持不变；若为硬件计算，基于等时延方案考虑，
               通道载波数大于等于8且无gsm制式时，改为软件计算。
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 10307448徐利波@2022-12-22 09:28:57
*----------------------------------------------------------------------------
*/
UINT32 BspCfrJudgeCpgMode(UINT32 difChn, UINT32 *cpgMode)
{
    UINT32 retVal   = BSP_OK;
    UINT32 modeFlag = 0;
    UINT32 index    = 0;
    UINT32 gsmFlag  = 0;
    T_ChanRfCfgPara *pRfCfg = NULL;

    pRfCfg = GetRfCfgPara(difChn, TX);
    if(NULL == pRfCfg)
    {
        dbgInfoEx("[%s] line %d: get pRfCfg Err!\n", __FUNCTION__, __LINE__);
        return BSP_ERROR;
    }

    if(difChn < CFR_CHAN_MAX_NUM)
    {
        modeFlag = s_pCfrCommPara->uiCpgMode[difChn];
    }
    else
    {
        dbgInfoEx("[%s] difChn out of range!\n",__FUNCTION__);
        return BSP_ERROR;
    } 

    if (CFR_CPG_CPU_CAL == modeFlag)
    {
        dbgInfoEx("[%s] difChn'%d uses the original CPU Calculation! \n",__FUNCTION__,difChn);
        *cpgMode = modeFlag;
        return retVal;
    }
    
    for (index = 0; index < pRfCfg->para.carrNum; index++)
    {
        if (RADIO_STANDARD_GSM == pRfCfg->para.carrInfo[index].radioMode)
        {
            gsmFlag = 1;
            break;
        }
    }

    if ((pRfCfg->para.carrNum >= 8) && (0 == gsmFlag))
    {
        dbgInfoEx("[%s] difChn'%d carrNum'%d changes from hardware to CPU Calculation! \n",__FUNCTION__,difChn,pRfCfg->para.carrNum);

        retVal = BspHalAdaptSetDlpreKiIndexType(difChn);
        *cpgMode = CFR_CPG_CPU_CAL;

        return retVal;
    }

    dbgInfoEx("[%s] difChn'%d uses the original Hardware Calculation! \n",__FUNCTION__,difChn);
    *cpgMode = CFR_CPG_HW_CAL;

    return retVal;
}

UINT32 BspUpdateCpgbwToFilter(UINT32 difChn, T_CfrChnBandInfo *pChnInfo)
{
    UINT32 bandLoop = 0;
    UINT32 carrLoop = 0;
    UINT32 carrNo = 0;
    UINT32 radio = 0;
    UINT32 carrBw = 0;

    for(bandLoop = 0; bandLoop < pChnInfo->bandNum; bandLoop++)
    {
        if (pChnInfo->usedFlag[bandLoop] == CFR_BAND_NOT_USED)
        {
            continue;
        }

        for(carrLoop = 0; carrLoop < pChnInfo->bandCarrNum[bandLoop]; carrLoop++)
        {
            if (pChnInfo->carrInfo[bandLoop][carrLoop].carrFlag == CFR_CARR_INVALID)
            {
                continue;
            }

            carrNo = pChnInfo->carrInfo[bandLoop][carrLoop].carrNo;
            radio = pChnInfo->carrInfo[bandLoop][carrLoop].carrRadio;
            carrBw = pChnInfo->carrInfo[bandLoop][carrLoop].carrBw;

            // if (BSP_RADIO_STANDARD_FDD_5G == radio || BSP_RADIO_STANDARD_UMTS == radio )
            // {
                /*由于不同制式均执行保存流程,此处不判断接口返回值*/
                BspSetDlFilterCpgBw(difChn, carrNo, radio, carrBw);
            // }
        }
    }

    return BSP_OK;
}

/*****************************************************************************
*  函数名称   : BspCfrClrHwCpgRam
*  功能描述   : 清空CPG硬件计算原型系数ram以及制式与原型系数的映射关系
*  输入参数   : bspChnChgMask   - 由APP下发的BSP改配通道掩码，改配通道对应bit置1
*  输出参数   : 无
*  返 回 值   : BSP_OK  - 成功;其它值为失败
*  其它说明   : 当通道制式或带宽改配时由APP调用此接口。
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 10307448徐利波@2022-04-28 19:44:46
*----------------------------------------------------------------------------
*/
UINT32 BspCfrClrHwCpgRam(UINT32 bspChnChgMask)
{
    UINT32 retVal        = BSP_OK;
    UINT32 freqBand      = 0;
	UINT32 difChn        = 0;
    UINT32 difChnChgMask = 0;
    UINT32 difChnHwMask  = 0;
    UINT32 suspend       = CFR_CPG_HW_CAL_STOP;

    dbgInfoEx("[%s] The modified bspChannel mask from APP is 0x%x. \n",__FUNCTION__,bspChnChgMask);

    retVal = BspChnMaskToDif(bspChnChgMask, &difChnChgMask);
    retVal |= BspCHgChnMaskToHw(difChnChgMask, &difChnHwMask);

    dbgInfoEx("[%s] The hardware modified difChn mask is 0x%x. \n",__FUNCTION__,difChnHwMask);

    for(difChn = 0; difChn < BspGetTxChanNum(); difChn++)
    {
        if(CFR_CPG_HW_CAL == GET_BIT(difChnHwMask, difChn))
        {
            retVal |= BspHalAdaptCfrSetCpgSuspend(difChn, freqBand, suspend);
        }
    }

    retVal |= BspHalAdaptCfrSetchnChgHwMask(difChnHwMask);
    retVal |= BspHalAdaptSetCpgParaRangeCarrNum();
    retVal |= BspHalAdaptCfrSetBlock0Ram1Len();
    BspLog(LOG_LEVEL_0,"[%s] appMask'0x%x, hwMask'0x%x \n", __FUNCTION__,bspChnChgMask,difChnHwMask);

    return retVal;
}

/*****************************************************************************
*  函数名称   : BspCfrSetCpgPara
*  功能描述   : 配置削峰 CPG 系数
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : difChn   - 中频通道
*  输出参数   : 无
*  返 回 值   : BSP_OK  - 成功;其它值为失败
*  其它说明   : 配置CFR模块接口，封装后用于给高层调用。
               通过挂接后APP调用接口名为：UINT32 BspSetCfrCpgPara(UINT32 bspChn)
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2015-11-28 14:55:24
*----------------------------------------------------------------------------
*/
UINT32 BspCfrSetCpgPara(UINT32 bspChn)
{
    UINT32 retVal          = BSP_OK;
    UINT32 difChn          = 0;
    UINT32 chipidx         = 0;
    UINT32 mode            = 0;
    UINT32 ulCfrByPassMode = 0;
    UINT32 cpgMode         = 0;
    UINT32 freqBand        = 0;
    T_CfrChnBandInfo *pCfrDifChnInfo = NULL;

    INPUT_POINTER_CHECK(s_pCfrCommPara);
    dbgInfoEx(" ======= CFR CFG START ======= \n");

    retVal  = BspGetDifInfoByBspChn(bspChn, TX, &chipidx, &difChn);

    mode = BspGetCfrWorkMode();
    if (mode == CFR_NORMAL_MODE)
    {
        retVal = BspCfrChnInfoUpdateByBspChn(bspChn);
        if (retVal != BSP_OK)
        {
            dbgInfoEx("[%s]Cfr Get Chn Info Error \n",__FUNCTION__);
            return BSP_ERROR;
        }
    }

    pCfrDifChnInfo = BspGetCfrChnInfo(difChn);
    if((NULL == pCfrDifChnInfo) || (pCfrDifChnInfo->centerFreq == 0))
    {
        dbgInfoEx("[%s] error, get cfr commom para or Chn[%d] Info fail! \n", __FUNCTION__, difChn);
        return BSP_ERROR;
    }

    ulCfrByPassMode = s_pCfrCommPara->uiCfrBypassMode[difChn];
    if (CFR_ZERODLY_BYPASS == ulCfrByPassMode)
    {
        retVal |= BspCfrDisable(difChn);
        dbgInfoEx("[%s] Chn %d Cfr Bypass Mode(%d) is Zero Dly ByPass\n",__FUNCTION__,difChn,ulCfrByPassMode);
        return retVal;
    }

    if (BspGetCfrFuncFlag() == CFR_FUNC_NOT_INIT)
    {
        dbgInfoEx("[%s]FUNC CFR NOT INIT \n", __FUNCTION__);
        return BSP_ERROR;
    }

    retVal |= BspCfrDisable(difChn);
    retVal |= BspCfrGateInit(difChn);
    if (retVal != BSP_OK)
    {
        dbgInfoEx("[%s]Cfr Gate NULL \n",__FUNCTION__);
        return BSP_ERROR;
    }

    retVal |= BspSetCfrCfg(difChn);
    retVal |= BspCfrSetBbTssiCfg(difChn);
    retVal |= BspHalAdaptCfrSetSymstrGsmSel(difChn, freqBand);
    retVal |= BspCfrJudgeCpgMode(difChn, &cpgMode);
    retVal |= BspHalAdaptCfrSetCpgMode(difChn, freqBand, cpgMode);

    if(cpgMode == CFR_CPG_CPU_CAL)
    {
        retVal |= BspCfrSetCpgPara_CpuCal(bspChn);
    }
    else
    {
        retVal |= BspCfrSetCpgPara_HwCal(bspChn);
    }

    retVal |= BspSetCfrDelay(difChn);
    retVal |= BspCfrSetTddSwPara(difChn);
    retVal |= BspCfrSetCpgLen(difChn);
    retVal |= BspCfrEnable(difChn);
//    retVal |= BspUpdateCpgbwToFilter(difChn, pCfrDifChnInfo);

    dbgInfoEx("%s>>RfCh'%d SetCpgPara OK! CfrWorkMode(%d:NORMAL)= %d\n",
                __FUNCTION__, bspChn, CFR_NORMAL_MODE, mode);
    dbgInfoEx(" ======= CFR CFG END ======= \n");
    BspLog(LOG_LEVEL_0,"[%s] chn:%d, cpgMode:%s, ret:%s.\n", __FUNCTION__, difChn, (cpgMode==0)?"cpu calc":"hw calc", (retVal==BSP_OK)?"OK":"Error");

    return retVal;
}

/*****************************************************************************
*  函数名称   : BspCfrGetVerInfo
*  功能描述   : 获取 FPGA CFR 版本号
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : chip   - fpga 芯片号
*  输出参数   : 无
*  返 回 值   : BSP_OK  - 成功;其它值为失败
*  其它说明   :
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2015-11-28 14:55:24
*----------------------------------------------------------------------------
*/
UINT32 BspCfrGetVerInfo(UINT32 chip)
{
    UINT32 cfrVerYear = 0;
    UINT32 cfrVerData = 0;
    UINT32 cfrVerTime = 0;

    /*IcHalApiGetCfrVer(chip,&cfrVerYear,&cfrVerData,&cfrVerTime);*/
    dbgInfoEx("%-20s %2x-%x-%2x %2x:00 \n", "FPGA_CFR_VER:",cfrVerYear,(cfrVerData>>0x8)&0xF,cfrVerData&0xFF,cfrVerTime );
    return BSP_OK;
}

/*****************************************************************************
*  函数名称   : BspCfrParaMemInfoInit_IC4_2
*  功能描述   : Dpdic4.2 CFR 所需要空间初始化
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   :
*  输出参数   : 无
*  返 回 值   :BSP_OK;
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2015-11-28 14:55:24
*----------------------------------------------------------------------------
*/
UINT32 BspCfrParaMemInfoInit_IC4_2(VOID)
{
    UINT32 ret = BSP_OK;
    UINT32 difChnNum = 0;
    T_CfrModule *pCfrModule = NULL;
    pCfrModule = (T_CfrModule *)BspGetCfrModuleInfo();

    INPUT_POINTER_CHECK(pCfrModule);

    difChnNum   = BspGetCfrDifChnNum();

	if(pCfrModule->cfrPara.pWinLevel != NULL)
	{
		return BSP_OK;
	}

	pCfrModule->cfrPara.pWinLevel = (T_CfrThrInfo *)malloc(sizeof(T_CfrThrInfo) * difChnNum);

	if (pCfrModule->cfrPara.pWinLevel == NULL)
	{
		free(pCfrModule->cfrPara.pWin);
		free(pCfrModule->cfrPara.pDelt);
		free(pCfrModule->cfrPara.pGate);
		pCfrModule->cfrPara.pWin    = NULL;
		pCfrModule->cfrPara.pDelt   = NULL;
		pCfrModule->cfrPara.pGate   = NULL;
		pCfrModule->initFlag = CFR_FUNC_NOT_INIT;
		dbgInfoEx("[%s]Cfr pWinLevel malloc fail \n", __FUNCTION__);
		return BSP_ERROR;
	}
	pCfrModule->initFlag = CFR_FUNC_INIT;

    return ret;
}

/*****************************************************************************
*  函数名称   : BspCfrParaMemInfoInit
*  功能描述   : Dpdic4.2 CFR 所需要空间初始化
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   :
*  输出参数   : 无
*  返 回 值   :BSP_OK;
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2015-11-28 14:55:24
*----------------------------------------------------------------------------
*/
UINT32 BspCfrParaMemInfoInit(VOID)
{
	UINT32 retVal = BSP_OK;

	retVal |= BspCfrParaMemInfoInit_IC4_2();

	return retVal;
}

/*****************************************************************************
*  函数名称   : BspGetCpgFsByDifChn_IC4_2
*  功能描述   : CPG速率获取（CPG速率 = 削峰采样率 * CPG相数）
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : difChn：中频通道号
*  输出参数   : *pCpgFs：Cpg速率
*  返 回 值   :BSP_OK;
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2015-11-28 14:55:24
*----------------------------------------------------------------------------
*/
UINT32 BspGetCpgFsByDifChn_IC4_2(UINT32 difChn,UINT32 *pCpgFs)
{
    UINT32 sampleRate = 0;
    UINT32 phaseFlag  = 0;
    UINT32 phaseNum   = 0;

    INPUT_POINTER_CHECK(pCpgFs);

    if(s_pCfrCommPara == NULL)
    {
        dbgInfoEx("%s Get CFR Commom Para Error!\n",__FUNCTION__);
        return BSP_ERROR;
    }

    sampleRate = s_pCfrCommPara->uiCfrSample[difChn];
    phaseFlag = s_pCfrCommPara->uiCpgPhase[difChn];

    switch (phaseFlag)
    {
        case 1:
        {
            phaseNum = CFR_CPG_PHASE_1;
            break;
        }
        case 2:
        {
            phaseNum = CFR_CPG_PHASE_2;
            break;
        }
        case 4:
        {
            phaseNum = CFR_CPG_PHASE_4;
            break;
        }
        default:
        {
            dbgInfoEx("%s Get CFR phaseNum is invalid!\n",__FUNCTION__);
            return BSP_ERROR;
        }
    }

    *pCpgFs = phaseNum*sampleRate;

    return BSP_OK;
}

UINT32 BspGetCfrCommPara(T_BspHalAdaptDifCommCfrPara *pCfrCommPara)
{
    if(s_pCfrCommPara == NULL)
	{
        dbgInfoEx("[%s] s_pCfrCommPara is not initialized！\n", __FUNCTION__);
		return BSP_ERROR;
	}
    memcpy_s(pCfrCommPara, sizeof(T_BspHalAdaptDifCommCfrPara), s_pCfrCommPara, sizeof(T_BspHalAdaptDifCommCfrPara));

    return BSP_OK;
}

/*****************************************************************************
*  函数名称   : BspInitCfrCommPara
*  功能描述   : 削峰静态参数（主体）初始化
*  读全局变量 : 无
*  写全局变量 : 将处理后的静态参数保存于全局变量 s_pCfrCommPara
*  输入参数   : pCfrCommPara - 静态参数结构体
*  输出参数   : 无
*  返 回 值   : BSP_OK  - 成功;其它值为失败
*  其它说明   : 根据40KM拉远能力方案，无线制式不含GSM和NB时，FDD通道CPG最大半长初始化为509。
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 徐利波@2023-03-29 08:48:37
*----------------------------------------------------------------------------
*/
UINT32 BspInitCfrCommPara(T_BspHalAdaptDifCommCfrPara *pCfrCommPara)
{
    UINT32 stdRadio = 0;
    UINT32 chnLoop = 0;
    UINT32 gnbFlag = 0;
    INPUT_POINTER_CHECK(pCfrCommPara);

    stdRadio = BspGetRadioStandard();

    if ((BSP_RADIO_STANDARD_GSM == (stdRadio & BSP_RADIO_STANDARD_GSM)) || (BSP_RADIO_STANDARD_NB_IOT == (stdRadio & BSP_RADIO_STANDARD_NB_IOT)))
    {
        gnbFlag = RADIO_SUPPORT_GSM_OR_NB;
    }

    if (gnbFlag != RADIO_SUPPORT_GSM_OR_NB)
    {
        BspLog(LOG_LEVEL_0,"[%s] stdRadio'0x%x, newHalMaxCpgLen'%u \n", __FUNCTION__, stdRadio, CFR_CPG_LEN_HAL_MAX_ULV);

        for(chnLoop = 0; chnLoop < CFR_CHAN_MAX_NUM; chnLoop ++)
        {
            pCfrCommPara->uiCpgCoefLenHalfMax[chnLoop] = CFR_CPG_LEN_HAL_MAX_ULV;
        }
    }

    s_pCfrCommPara = pCfrCommPara;

    return BspHalAdaptDifCfrParaInit(pCfrCommPara);
}

UINT32 BspGetCfrKiCommPara(T_BspHalAdaptCfrParaHardCpg *pCfrHWCpgPara)
{
    if(s_pCfrHWCpgPara == NULL)
	{
        dbgInfoEx("[%s] s_pCfrHWCpgPara is not initialized！\n", __FUNCTION__);
		return BSP_ERROR;
	}
    memcpy_s(pCfrHWCpgPara, sizeof(T_BspHalAdaptCfrParaHardCpg), s_pCfrHWCpgPara, sizeof(T_BspHalAdaptCfrParaHardCpg));

    return BSP_OK;
}

/**  削峰硬件计算Ki表等参数初始化  **/
UINT32 BspInitKiCommPara(T_BspHalAdaptCfrParaHardCpg *pCfrHWCpgPara)
{
    INPUT_POINTER_CHECK(pCfrHWCpgPara);
    s_pCfrHWCpgPara = pCfrHWCpgPara;
    return BspHalAdaptCfrCommParaCpgInit(pCfrHWCpgPara);
}

/**  削峰硬件计算Kn表等参数初始化  **/
UINT32 BspInitKnCommPara(T_BspHalAdaptCfrKnWordPara *pCfrKnWordPara)
{
    INPUT_POINTER_CHECK(pCfrKnWordPara);
    return BspHalAdaptKnWordLutParaInit(pCfrKnWordPara);
}

/**  削峰硬件计算频段靠前摆放参数初始化  **/
UINT32 BspInitRangeBandPara(void)
{
    return BspHalAdaptCpgeParaRangeFreqInit();
}

/** 设置削峰静态门控初始化 **/
UINT32 BspInitCfrSetCpgGateBypass(void)
{
    return BspHalAdaptCfrSetCpgGateBypassInit();
}

/**  获取削峰峰均比参数  **/
UINT32 BspGetCfrParPara(T_BspHalAdaptCfrParCommPara *pCfrParPara)
{
    if(s_pCfrParPara == NULL)
	{
        dbgInfoEx("[%s] s_pCfrParPara is not initialized！\n", __FUNCTION__);
		return BSP_ERROR;
	}
    memcpy_s(pCfrParPara, sizeof(T_BspHalAdaptCfrParCommPara), s_pCfrParPara, sizeof(T_BspHalAdaptCfrParCommPara));

    return BSP_OK;
}

/**  削峰峰均比参数初始化  **/
UINT32 BspInitCfrParPara(T_BspHalAdaptCfrParCommPara *pCfrParPara)
{
    INPUT_POINTER_CHECK(pCfrParPara);
    s_pCfrParPara = pCfrParPara;

    return BspHalAdaptCfrParCfgCommParaInit(pCfrParPara);
}

/**  获取DPD峰均比参数  **/
UINT32 BspGetDpdParPara(T_BspHalAdaptDpdParCommPara *pDpdParPara)
{
    if(s_pDpdParPara == NULL)
	{
        dbgInfoEx("[%s] s_pDpdParPara is not initialized！\n", __FUNCTION__);
		return BSP_ERROR;
	}
    memcpy_s(pDpdParPara, sizeof(T_BspHalAdaptDpdParCommPara), s_pDpdParPara, sizeof(T_BspHalAdaptDpdParCommPara));

    return BSP_OK;
}

/**  DPD峰均比参数初始化  **/
UINT32 BspInitDpdParPara(T_BspHalAdaptDpdParCommPara *pDpdParPara)
{
    INPUT_POINTER_CHECK(pDpdParPara);
    s_pDpdParPara = pDpdParPara;

    return BspHalAdaptDpdParCfgCommParaInit(pDpdParPara);
}
 
/** 削峰动态参数获取 **/
UINT32 BspCfrDymParaInit(UINT32 dymTblLen, T_CfrGateCfgGroup *pCfrGateCfgGroup)
{
    g_pCfrDymParaTblLen = dymTblLen;
    INPUT_POINTER_CHECK(pCfrGateCfgGroup);
    s_pCfrGateCfgGroup = pCfrGateCfgGroup;

    return BSP_OK;
}

/** 削峰在线计算某通道载波靠前摆放初始化 **/
UINT32 BspSetCpgParaRangeCarrInit(void)
{
    UINT32 retVal = BSP_OK;

    retVal |= BspHalAdaptSetCpgParaRangeCarrInit();

    return retVal;
}

/** 设置CPG在线计算频段频率控制字速率初始化 **/
UINT32 BspCfrSetFreqWordFsInit(void)
{
    UINT32 retVal = BSP_OK;

    retVal = BspHalAdaptCfrSetFreqWordFsInit();

    return retVal;  
}

/** 设置dlpre内部Ki索引计算功率选择参数（DSS场景）*/
UINT32 BspCfrSetDlpreKiPowSelInit(void)
{
    UINT32 retVal = BSP_OK;

    retVal = BspHalAdaptCfrSetDlpreKiPowSelInit();

    return retVal;  
}

/** 设置在线计算BBTSSI相关配置 */
UINT32 BspCfrSetBbTssiCfg(UINT32 difchn)
{
    UINT32 retVal = BSP_OK;

    retVal = BspHalAdaptSetBbTssiCfg(difchn);

    return retVal; 
}

/* 削峰门限窗长等参数初始化 */
UINT32 BspInitCfrGatePara(UINT32 difchn)
{
    UINT32 retVal = BSP_OK;
    UINT32 loop = 0;
    UINT32 tddFddMode = 0;

    if(s_pCfrCommPara != NULL)
    {
        tddFddMode = s_pCfrCommPara->uiCfrPeakMode[difchn];
    }
    dbgInfoEx("[%s] The duplex mode of difchn %d is %s. \n", __FUNCTION__, difchn, ((tddFddMode == CFR_CHAN_TDD_DX)?("TDD"):("FDD")));

    for(loop = 0; loop < g_pCfrDymParaTblLen; loop++)
    {
        if((tddFddMode == CFR_CHAN_TDD_DX) && (tddFddMode == s_pCfrGateCfgGroup[loop].tddFddFlag))
        {
            retVal = BspCfrGateInit_IC4_2(difchn, tddFddMode, s_pCfrGateCfgGroup[loop].dynPara, NULL, s_pCfrGateCfgGroup[loop].tblLen);
            if(retVal != BSP_OK)
            {
                dbgInfoEx("%s get cfr Dym Para Err! retVal'%d\n",__FUNCTION__,retVal);
                return BSP_ERROR;
            }
            break;
        }

        if((tddFddMode == CFR_CHAN_FDD_DX) && (tddFddMode == s_pCfrGateCfgGroup[loop].tddFddFlag))
        {
            retVal = BspCfrGateInit_IC4_2(difchn, tddFddMode, NULL, s_pCfrGateCfgGroup[loop].dynPara, s_pCfrGateCfgGroup[loop].tblLen);
            if(retVal != BSP_OK)
            {
                dbgInfoEx("%s get cfr Dym Para Err! retVal'%d\n",__FUNCTION__,retVal);
                return BSP_ERROR;
            }
            break;
        }
    }

    return BSP_OK;
}

/*****************************************************************************
*  函数名称   : BspCfrSetDelay
*  功能描述   : CFR时延配置
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : difChn：中频通道号
*  输出参数   : 无
*  返 回 值   :BSP_OK;
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 刘巨波@2015-11-28 14:55:24
*----------------------------------------------------------------------------
*/
UINT32 BspCfrSetDelay(UINT32 difChn)
{
    UINT32 ret       = BSP_OK;
    UINT32 cpgMaxlen = 0;
    UINT32 loop      = 0;
    UINT32 freqBand  = 0;
    UINT32 cfrWinLevel[E_CFR_THR_NUM] = {0};
    T_BspHalAdaptCfrDlyCalcPara pDlyPara = {0};
    
    ret = BspGetCfrWinLevelPara(difChn,cfrWinLevel);
    ret |= BspCfrGetCpgVaildLen(difChn, &cpgMaxlen);
    if(ret != BSP_OK)
    {
        dbgInfoEx("[%s]Cfr Get Cpg Len Error \n", __FUNCTION__);
        return BSP_ERROR;
    }

    pDlyPara.uiCpgLen = cpgMaxlen;

    for(loop = 0; loop < E_CFR_THR_NUM; loop++)
    {
        pDlyPara.uiCfrWinLevel[loop] = cfrWinLevel[loop];
    }

    dbgInfoEx("[%s] difChn:%u, cpglen:%u, winlevel:%u %u %u\n ",__FUNCTION__, difChn, pDlyPara.uiCpgLen,
                pDlyPara.uiCfrWinLevel[0], pDlyPara.uiCfrWinLevel[1], pDlyPara.uiCfrWinLevel[2]);

    ret |= BspHalAdaptCfrSetDelay(difChn, freqBand, &pDlyPara);

    return ret;
}

/* 设置TDD展宽拍数 */
UINT32 BspCfrSetTddSwPara(UINT32 difChn)
{
    UINT32 ret       = BSP_OK;
    UINT32 cpgMaxlen = 0;
    UINT32 loop      = 0;
    UINT32 freqBand  = 0;
    UINT32 cfrWinLevel[E_CFR_THR_NUM] = {0};
    T_BspHalAdaptCfrDlyCalcPara pDlyPara = {0};
    
    ret = BspGetCfrWinLevelPara(difChn,cfrWinLevel);
    ret |= BspCfrGetCpgVaildLen(difChn, &cpgMaxlen);
    if(ret != BSP_OK)
    {
        dbgInfoEx("[%s]Cfr Get Cpg Len Error \n", __FUNCTION__);
        return BSP_ERROR;
    }

    pDlyPara.uiCpgLen = cpgMaxlen;

    for(loop = 0; loop < E_CFR_THR_NUM; loop++)
    {
        pDlyPara.uiCfrWinLevel[loop] = cfrWinLevel[loop];
    }

    dbgInfoEx("%s difChn:%d cpglen:%d winlevel:%d %d %d\n ",__FUNCTION__,difChn,pDlyPara.uiCpgLen,pDlyPara.uiCfrWinLevel[0],pDlyPara.uiCfrWinLevel[1],pDlyPara.uiCfrWinLevel[2]);

    ret |= BspHalAdaptCfrSetTddsw(difChn, freqBand, &pDlyPara);

    return ret;
}

/* 设置CPG半长 */
UINT32 BspCfrSetCpgLen(UINT32 difChn)
{
    UINT32 ret       = BSP_OK;
    UINT32 cpgMaxlen = 0;
    UINT32 freqBand  = 0;

    ret |= BspCfrGetCpgVaildLen(difChn, &cpgMaxlen);
    if(ret != BSP_OK)
    {
        dbgInfoEx("[%s]Cfr Get Cpg Len Error \n", __FUNCTION__);
        return BSP_ERROR;
    }

    dbgInfoEx("[%s] difChn:%d, cpglen:%d  \n ",__FUNCTION__,difChn,cpgMaxlen);

    ret |= BspHalAdaptCfrSetCpgLen(difChn, freqBand, cpgMaxlen);

    return ret;
}

/*****************************************************************************
*  函数名称   : BspInitCfrModuleFunc
*  功能描述   : CFR 功能模块接口挂接
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   :
*  输出参数   : 无
*  返 回 值   :BSP_OK;
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2015-11-28 14:55:24
*----------------------------------------------------------------------------
*/
UINT32 BspInitCfrModuleFunc(VOID)
{
    UINT32 ulTmpRet         = BSP_OK;
    UINT32 ulFuncRet        = BSP_OK;
    UINT32 difChnNum        = 0;
    UINT32 difChnNumPerChip = 0;
    T_CfrModule *pCfrModule = NULL;
    UINT32 cfrInitFlag      = CFR_FUNC_NOT_INIT;

    difChnNum        = BspGetDifChnTotalNum();
    difChnNumPerChip = BspGetDifChnNumPerChip();
    ulTmpRet         = BspSetCfrDifChnNum(difChnNum);
    ulTmpRet        |= BspSetCfrDifChnNumPerChip(difChnNumPerChip);
    if (ulTmpRet != BSP_OK)
    {
    	ulFuncRet |= BIT_SET(0);
    }

    cfrInitFlag = BspGetCfrFuncFlag();
    if (cfrInitFlag == CFR_FUNC_INIT)
    {
        return BSP_OK;
    }

    ulTmpRet  = BspCfrFuncMemInfoInit();
    ulTmpRet |= BspCfrParaMemInfoInit();
    BspCfrFsByDifBackInit(BspGetCpgFsByDifChn_IC4_2);
    if (ulTmpRet != BSP_OK)
    {
    	ulFuncRet |= BIT_SET(1);
        dbgInfoEx("[%s]Cfr Func Mem Error!The function module not used\n", __FUNCTION__);
    }

    pCfrModule = (T_CfrModule *)BspGetCfrModuleInfo();
    INPUT_POINTER_CHECK(pCfrModule);

    /** 动态频谱共享 ***/
    #if 0
    BspGetSpeCfrCfg(&speCfrCfgFlag);
    if( 0 == speCfrCfgFlag )
    {
        BspSetCfrCarrPowCfgFunc(BspGetCfrCarrPowInfo);
        BspSetCfrCarrCfgUpdateFunc(BspUpdateCfrCarrInfo);
    }
    #endif

    pCfrModule->cfrFunc.pGateInit   = BspInitCfrGatePara; 
    pCfrModule->cfrFunc.pCfrCfg     = BspCfrCfg; /* 削峰门限、窗长等动态参数配置 */
    pCfrModule->cfrFunc.pCpgInit    = BspCfrCpgInit_CpuCal;
    pCfrModule->cfrFunc.pCpgCfg     = BspCfrCpgCfg_CpuCal;
    pCfrModule->cfrFunc.pDisable    = BspCfrSetDisable;
    pCfrModule->cfrFunc.pEnable     = BspCfrSetEnable;
    pCfrModule->cfrFunc.pCfgCpgPara = BspCfrSetCpgPara;
    pCfrModule->cfrFunc.pCfrVer     = BspCfrGetVerInfo;
    pCfrModule->cfrFunc.pCfrDelay   = BspCfrSetDelay;

    return ulFuncRet;
}

/*****************************************************************************
*  函数名称   : BspInitCfrFilterPara
*  功能描述   : CFR 结构参数配置
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   :
*  输出参数   : 无
*  返 回 值   :BSP_OK;
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2015-11-28 14:55:24
*----------------------------------------------------------------------------
*/
UINT32 BspInitCfrHbf1FilterPara(UINT32 difChn,INT32* pCoef,UINT32 coefLen)
{
	return BspHalAdaptSetCfrHb1Coef(difChn, pCoef,coefLen);
}

/*****************************************************************************
*  函数名称   : BspInitCfrHbf0FilterPara
*  功能描述   : CFR 结构参数配置
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   :
*  输出参数   : 无
*  返 回 值   :BSP_OK;
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2015-11-28 14:55:24
*----------------------------------------------------------------------------
*/
UINT32 BspInitCfrHbf0FilterPara(UINT32 difChn,INT32* pCoef,UINT32 coefLen)
{
	return BspHalAdaptSetCfrHb0Coef(difChn, pCoef,coefLen);
}

/*****************************************************************************
*  函数名称   : BspSetCfrOutMode
*  功能描述   : CFR输出模式（用于调试接口）
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : difChn:中频通道号 
               mode：输出模式，0，零延时旁路；1，等延时旁路；2，正常削峰输出；3，抵消脉冲模式
*  输出参数   : 无
*  返 回 值   :BSP_OK;
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2015-11-28 14:55:24
*----------------------------------------------------------------------------
*/
UINT32 BspSetCfrOutMode(UINT32 difChn, UINT32 mode)
{
    UINT32 freqBand = 0;

    return BspHalAdaptSetCfrOutMode(difChn, freqBand, mode);
}

/*****************************************************************************
*  函数名称   : BspGetCpgMaxLen_IC4_2
*  功能描述   : 获取当前配置中最大的CPG长度
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : rfchan： 射频通道号
               difChan：中频通道号
*  输出参数   : cpgLen：最大cpg长度
*  返 回 值   : BSP_OK  - 成功;其它值为失败
*  其它说明   :
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 刘巨波@2021-05-29 14:55:24
*----------------------------------------------------------------------------/
*/
UINT32 BspGetCpgMaxLen_IC4_2(UINT32 rfchan, UINT32 difChan, UINT32 *cpgLen)
{
    UINT32 ret = BSP_OK;
    UINT32 cpgmaxlen = 0;
    UINT32 carrLoop = 0;
    UINT32 cfrFs = 0;
    UINT32 cfrBw = 0;
    UINT32 carrBw = 0;
    UINT32 carrRadio = 0;
    UINT32 bandLoop = 0;
    T_CfrCpgPara cfrCpgPara = {0};
    T_RruBandCfgInfo *pRruRfCfgInfo = NULL;

    INPUT_POINTER_CHECK(cpgLen);
    
    ret = BspGetCfrFsByDifChn(difChan,&cfrFs);
    if (ret == BSP_ERROR)
    {
        dbgInfoEx("[%s]difchan %d get fs error!\n", __FUNCTION__, difChan);
        return BSP_ERROR;
    }

    pRruRfCfgInfo = malloc(sizeof(T_RruBandCfgInfo));
    if (NULL == pRruRfCfgInfo)
    {
        dbgInfoEx("[%s]RfChn %d RfCfgInfoMalloc Error!\n", __FUNCTION__, rfchan);
        return BSP_ERROR;
    }
    memset(pRruRfCfgInfo, 0, sizeof(T_RruBandCfgInfo));

    ret = BspGetRruTxDifCfgPara(rfchan, pRruRfCfgInfo);
    if(ret != BSP_OK)
    {
        free(pRruRfCfgInfo);
        dbgInfoEx("[%s]RfChn %d Cfr Chn Info Update Error!\n",__FUNCTION__,rfchan);
        return BSP_ERROR;
    }

    for(bandLoop = 0; bandLoop < E_CFR_BAND_MAX; bandLoop ++)
    {
        if(pRruRfCfgInfo->info[bandLoop].bandfreq == 0)
        {
            continue;
        }
        for(carrLoop = 0 ; carrLoop < BSP_MAX_CARR_NUM; carrLoop++)
        {
            if(pRruRfCfgInfo->info[bandLoop].carr[carrLoop].carrFreq == 0)
            {
                continue;
            }
            carrBw = pRruRfCfgInfo->info[bandLoop].carr[carrLoop].carrBw;
            carrRadio = pRruRfCfgInfo->info[bandLoop].carr[carrLoop].carrRadio;
            ret = BspGetCfrRadioBwFromBspBw(carrRadio, carrBw, &cfrBw);
            ret |= BspGetCfrCpgCoef_IC4_2(difChan,cfrBw,cfrFs, &cfrCpgPara);
            if(ret == BSP_OK)
            {
                cpgmaxlen = (cpgmaxlen>cfrCpgPara.vaildLen)?cpgmaxlen:cfrCpgPara.vaildLen;
            }
        }
    }
    *cpgLen = cpgmaxlen;
    free(pRruRfCfgInfo);

    return BSP_OK;
}

/*****************************************************************************
*  函数名称   : BspSetDlyPara
*  功能描述   : 根据CGP长度设置中频时延
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : difChn:中频通道号 
             pRfCfgPara：载波配置
*  输出参数   : 无
*  返 回 值   :BSP_OK;
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2015-11-28 14:55:24
*----------------------------------------------------------------------------
*/
UINT32 BspSetDlyPara(UINT32 chan, UINT32 *pReservePara)
{
    UINT32 ret         = BSP_OK;
    UINT32 cpgmaxlen   = 0;
    UINT32 bspChan     = 0;
    UINT32 difChan     = 0;
    UINT32 loop        = 0;
    UINT32 ulDelayMode = 0;
    UINT32 chipId      = 0;
    UINT32 cfrWinLevel[E_CFR_THR_NUM]    = {0};
    T_BspHalAdaptDlyCfgCfrPara pDlyPara  = {0};

    if (NULL == pReservePara)
    {
        dbgInfoEx("%s:Input Pointer is NULL,but it is ok! \n",__FUNCTION__);
    }

    ret = BspGetBspChnByRfChn(chan, TX, &bspChan);
	if (BSP_OK != ret)
	{
		dbgInfoEx("%s>>TxChnl'%d BspGetBspChnByRfChn Get Error!\n",
			   __FUNCTION__, chan);
		return BSP_ERROR;
	}

    ret = BspGetDifInfoByBspChn(bspChan, TX, &chipId, &difChan);
    if (BSP_OK != ret)
    {
        dbgInfoEx("%s>>bspChan'%d BspGetDifInfoByBspChn Get Error!\n",
               __FUNCTION__, bspChan);
        return BSP_ERROR;
    }

    if(s_pCfrCommPara == NULL)
    {
        dbgInfoEx("%s Get CFR Commom Para Error!",__FUNCTION__);
        return BSP_ERROR;
    }

    BspSetCfrGateInitFlag(CFR_GATE_INIT_CFG_FREQ);

    ulDelayMode = s_pCfrCommPara->uiDelayEqualFlag[difChan];
    if(ulDelayMode == CFR_EQ_DLY)
    {
        cpgmaxlen = s_pCfrCommPara->uiCpgCoefLenHalfMax[difChan];
    }
    else
    {
        ret = BspGetCpgMaxLen_IC4_2(chan,difChan, &cpgmaxlen);
        if(BSP_OK != ret)
        {
            cpgmaxlen = CFR_CPG_RAM_768;
            dbgInfoEx("%s get cpg error!\n",__FUNCTION__);
        }
    }

    pDlyPara.uiCpgLen = cpgmaxlen;
    pDlyPara.uiCfrGrade = s_pCfrCommPara->uiCfrGrade[difChan];
    pDlyPara.uiCpgPhase = s_pCfrCommPara->uiCpgPhase[difChan];
    pDlyPara.uiCfrBypassMode = s_pCfrCommPara->uiCfrBypassMode[difChan];

    ret = BspCfrGateInit(difChan);
    if (ret != BSP_OK)
	{
		dbgInfoEx("[%s]Cfr Gate NULL \n",__FUNCTION__);
        BspSetCfrGateInitFlag(CFR_GATE_INIT_CFG_CFR);
		return BSP_ERROR;
	}

    ret |= BspGetCfrWinLevelPara(difChan,cfrWinLevel);
    for(loop = 0; loop < E_CFR_THR_NUM; loop++)
    {
        pDlyPara.uiCfrWinLevel[loop] = cfrWinLevel[loop];
    }
    dbgInfoEx("%s gradeNum:%d phaseNum:%d cpgLen:%d bypassmode:%d winlevel:%d %d %d\n",__FUNCTION__,\
            pDlyPara.uiCfrGrade,pDlyPara.uiCpgPhase,pDlyPara.uiCpgLen,pDlyPara.uiCfrBypassMode,\
            pDlyPara.uiCfrWinLevel[0],pDlyPara.uiCfrWinLevel[1],pDlyPara.uiCfrWinLevel[2]);

    ret |= BspHalAdaptSetDlyPara(difChan, &pDlyPara);
    BspSetCfrGateInitFlag(CFR_GATE_INIT_CFG_CFR);

    return ret;
}

/*****************************************************************************
*  函数名称   : BspGetCfrChnBwInfo
*  功能描述   : 获取当前配置的IBW和OBW
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : difchan:中频通道号
               bandId:频段号
*  输出参数   : obw: obw
               ibw: ibw
*  返 回 值   : BSP_OK  - 成功;其它值为失败
*  其它说明   :
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 刘巨波@2021-05-29 14:55:24
*----------------------------------------------------------------------------
*/
UINT32 BspGetCfrChnBwInfo(UINT32 difchan, UINT32 bandId, UINT32 *obw,UINT32 *ibw)
{
    UINT32 ret          = BSP_OK;
    UINT32 carrNum      = 0;
    UINT32 bwSum        = 0;
    UINT32 loop         = 0;
    UINT32 freqMax      = 0;
    UINT32 carrBwMin    = 0;
    UINT32 carrBwMax    = 0;
    UINT32 carrBw       = 0;
    UINT32 carrFreq     = 0;
    UINT32 gateInitFlag = 0;
    UINT32 rfChan       = 0;
    UINT32 freqMin      = 0xFFFFFFFF;
    T_CfrChnBandInfo *pCfrDifChnInfo = NULL;
    T_RruBandCfgInfo *pRruRfCfgInfo = NULL;

    INPUT_POINTER_CHECK(obw);
    INPUT_POINTER_CHECK(ibw);
    
    BspGetCfrGateInitFlag(&gateInitFlag);
    if(gateInitFlag != CFR_GATE_INIT_CFG_FREQ)
    {
        pCfrDifChnInfo = BspGetCfrChnInfo(difchan);
        if (pCfrDifChnInfo == NULL)
        {
            dbgInfoEx("[%s]Get Cfr Dif Chn[%d] Info Error!\n", __FUNCTION__, difchan);
            return BSP_ERROR;
        }
        if (pCfrDifChnInfo->usedFlag[bandId] == CFR_BAND_NOT_USED)
        {
            *obw = 0;
            dbgInfoEx("%s>>DifChnl'%d Band'%d CfrBandNotUsed; OBW= %d\n",
                    __FUNCTION__, difchan, bandId,*obw);
            return BSP_OK;
        }
        carrNum = pCfrDifChnInfo->bandCarrNum[bandId];
    }
    else
    {
        ret = BspGetRfChnInfoByDifChn(difchan,TX,&rfChan);
        if (BSP_OK != ret)
        {
            dbgInfoEx("%s>>difchan'%d BspGetRfChnInfoByDifChn Get Error!\n",
                   __FUNCTION__, difchan);
            return BSP_ERROR;
        }

        pRruRfCfgInfo = malloc(sizeof(T_RruBandCfgInfo));
        if (NULL == pRruRfCfgInfo)
        {
            dbgInfoEx("[%s]RfChn %d RfCfgInfoMalloc Error!\n", __FUNCTION__, rfChan);
            return BSP_ERROR;
        }
        memset(pRruRfCfgInfo, 0, sizeof(T_RruBandCfgInfo));

        ret = BspGetRruTxDifCfgPara(rfChan, pRruRfCfgInfo);
        if(ret != BSP_OK)
        {
            free(pRruRfCfgInfo);
            dbgInfoEx("[%s]RfChn %d Cfr Chn Info Update Error!\n",__FUNCTION__,rfChan);
            return BSP_ERROR;
        }
        carrNum = BSP_MAX_CARR_NUM;
    }
    
    for(loop = 0; loop < carrNum; loop ++)
    {
        if(gateInitFlag != CFR_GATE_INIT_CFG_FREQ)
        {
            CONTINUE_IF_EXP(pCfrDifChnInfo->carrInfo[bandId][loop].carrFlag == CFR_CARR_INVALID);
            if (pCfrDifChnInfo->carrInfo[bandId][loop].powerMw == 0)
            {
                continue;
            }
            carrBw = pCfrDifChnInfo->carrInfo[bandId][loop].carrBw;
            carrFreq = pCfrDifChnInfo->carrInfo[bandId][loop].freq;
        }
        else
        {
            if(pRruRfCfgInfo->info[bandId].carr[loop].carrFreq == 0)
            {
                continue;
            }
            carrBw = pRruRfCfgInfo->info[bandId].carr[loop].carrBw;
            carrFreq = pRruRfCfgInfo->info[bandId].carr[loop].carrFreq;
        }
        dbgInfoEx("%s difchan'%d band'%d loop'%d freq'%d carrBw'%d\n",
                    __FUNCTION__,difchan,bandId,loop,carrFreq,carrBw);
        
        if(carrFreq < freqMin)
        {
            freqMin = carrFreq;
            carrBwMin = carrBw;
        }
        if(carrFreq > freqMax)
        {
            freqMax = carrFreq;
            carrBwMax = carrBw;
        }
        bwSum += carrBw;
    }

    *obw = bwSum;
    *ibw = (freqMax + carrBwMax/2) - (freqMin - carrBwMin/2);
    dbgInfoEx("%s difchan'%d band'%d OBW'%d IBW'%d\n",__FUNCTION__,difchan,bandId,*obw,*ibw);
    
    if(pRruRfCfgInfo != NULL)
    {
        free(pRruRfCfgInfo);
    }

    return BSP_OK;
}

/*****************************************************************************
*  函数名称   : BspCfrGateInit_TDD
*  功能描述   : TDD根据obw和ibw比值自动初始化削峰动态参数
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : difchan:中频通道号
               pTddPara:TDD规则表
               len：TDD表格大小
*  输出参数   : 无
*  返 回 值   : BSP_OK  - 成功;其它值为失败
*  其它说明   : 接口先实现，待算法提供具体表格后对gateinit接口单板下用新接口挂接
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 刘巨波@2021-05-29 14:55:24
*----------------------------------------------------------------------------
*/
UINT32 BspCfrGateInit_TDD(UINT32 difchan, T_CfrDynPara_TDD *pTddPara, UINT32 len)
{
    UINT32 ret    = BSP_OK;
    UINT32 ibw    = 0;
    UINT32 obw    = 0;
    FLOAT bwCoef  = 0.0;
    UINT32 loop   = 0;
    UINT32 bandId = 0;
    UINT32 index  = 0;
    UINT32 cfrGate[E_CFR_THR_NUM] = {0};
    UINT32 cfrDelt[E_CFR_THR_NUM] = {0};
    UINT32 cfrWin[E_CFR_THR_NUM]  = {0}; 
    UINT32 cfrWinLevel[E_CFR_THR_NUM] = {0};

    ret = BspGetCfrChnBwInfo(difchan,bandId,&obw,&ibw);
    if(ret != BSP_OK)
    {
        dbgInfoEx("%s difchan'%d band'%d get CFR BW info error!\n",__FUNCTION__,difchan,bandId);
        return BSP_ERROR;
    }

    if((obw == 0) || (ibw == 0))
    {
        dbgInfoEx("%s difchan'%d band'%d get CFR BW info is zero, not need init gate!\n",
                __FUNCTION__,difchan,bandId);
        return BSP_OK;
    }

    bwCoef = (FLOAT)obw/(FLOAT)ibw;
    dbgInfoEx("%s difchan'%d band'%d bwCoef(%f)=obw(%d)/ibw(%d)\n",
            __FUNCTION__,difchan,bandId,bwCoef,obw,ibw);

    for(loop = 0; loop < len; loop++)
    {
        if((bwCoef > pTddPara[loop].lowbound) && (bwCoef <= pTddPara[loop].upbound))
        {
            index = loop;
            break;
        }
    }

    if(loop >= len)
    {
        index = len-1;
        dbgInfoEx("%s difchan'%d band'%d bwcoef'%f not found gate,switch full bw gate!\n",__FUNCTION__,difchan,bandId,bwCoef);
    }
    dbgInfoEx("%s index:%d \n",__FUNCTION__,index);

    for(loop = 0; loop < E_CFR_THR_NUM; loop++)
    {
        cfrGate[loop] = pTddPara[index].cfrgate[loop];
        cfrDelt[loop] = pTddPara[index].cfrdelt[loop];
        cfrWin[loop] = pTddPara[index].cfrwin[loop];
        cfrWinLevel[loop] = pTddPara[index].cfrwinlevel[loop];
        dbgInfoEx("%s cfrGate[%d]:%d \n",__FUNCTION__,loop,cfrGate[loop]);
        dbgInfoEx("%s cfrDelt[%d]:%d \n",__FUNCTION__,loop,cfrDelt[loop]);
        dbgInfoEx("%s cfrWin[%d]:%d \n",__FUNCTION__,loop,cfrWin[loop]);
        dbgInfoEx("%s cfrWinLevel[%d]:%d \n",__FUNCTION__,loop,cfrWinLevel[loop]);
    }

    ret = BspSetCfrGatePara(difchan, cfrGate);
    ret |= BspSetCfrWinPara(difchan, cfrWin);
    ret |= BspSetCfrDeltPara(difchan, cfrDelt);
    ret |= BspSetCfrWinLevelPara(difchan, cfrWinLevel);

    return ret;
}

/*****************************************************************************
*  函数名称   : BspGetCfrChnMixRadioInfo
*  功能描述   : 获取通道所有载波制式信息，通过或操作输出混合制式值(配置FDD削峰动态参数相关)
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : difchan:中频通道号
*  输出参数   : mixRadio: 通道混模制式
*  返 回 值   : BSP_OK  - 成功;其它值为失败
*  其它说明   : 若通道只存在LTE制式或只存在NR制式时，需要对其载波数进行判断。
               若是单载波，则将制式值最高位置1；若是多载波，则不进行最高位置0。
               对于NR制式，无论获取值为0x2000还是0x4000，求取混模时均采用0x4000计算。
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 10307448徐利波@2022-03-12 10:21:14
*----------------------------------------------------------------------------
*/ 
UINT32 BspGetCfrChnMixRadioInfo(UINT32 difchan, UINT32 *mixRadio)
{
    UINT32 bandLoop   = 0;
    UINT32 carrLoop   = 0;
    UINT32 chnRadio   = 0;
    UINT32 chnCarrNum = 0;
    T_CfrChnBandInfo *pCfrDifChnInfo = NULL;

    INPUT_POINTER_CHECK(mixRadio);

    pCfrDifChnInfo = BspGetCfrChnInfo(difchan);
    if (pCfrDifChnInfo == NULL)
    {
        dbgInfoEx("[%s]Get Cfr Chn[%d] Info Error!\n", __FUNCTION__, difchan);
        return BSP_ERROR;
    }

    for(bandLoop = 0; bandLoop < pCfrDifChnInfo->bandNum; bandLoop++)
    {
        CONTINUE_IF_EXP(pCfrDifChnInfo->usedFlag[bandLoop] == CFR_BAND_NOT_USED);

        for(carrLoop = 0; carrLoop < pCfrDifChnInfo->bandCarrNum[bandLoop]; carrLoop++)
        {
            CONTINUE_IF_EXP(pCfrDifChnInfo->carrInfo[bandLoop][carrLoop].carrFlag == CFR_CARR_INVALID);

            if (pCfrDifChnInfo->carrInfo[bandLoop][carrLoop].carrRadio == RADIO_STANDARD_5G)
            {
                chnRadio |= RADIO_STANDARD_5G_RESERVED;
            }
            else
            {
                chnRadio |= pCfrDifChnInfo->carrInfo[bandLoop][carrLoop].carrRadio;
            } 

            if (chnCarrNum <= (UINT_MAX - 1)) 
            {
                chnCarrNum = chnCarrNum + 1;
            }  
        }
    }

    /******  单LTE或单NR的单载波时，将混模制式最高位置1  ***********/
    if ((chnRadio == RADIO_STANDARD_LTE_FDD) || (chnRadio == RADIO_STANDARD_5G_RESERVED))
    {
        if (chnCarrNum == 1)
        {
            chnRadio |= 0x80000000;
        }
    }

    *mixRadio = chnRadio;

    return BSP_OK;
}

/*****************************************************************************
*  函数名称   : BspGetCfrChnMinBwInfo
*  功能描述   : 获取当前通道最小带宽(配置FDD削峰动态参数相关)
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : difchan:中频通道号
*  输出参数   : minBw: 通道最小带宽
*  返 回 值   : BSP_OK  - 成功;其它值为失败
*  其它说明   : 1、当通道中包含L或V或LV制式时，求取结果为L或V或LV的最小带宽；否则求取整个通道最小带宽。
*              2、若通道中存在GSM载波且带宽为0，则将GSM带宽当做200k参与计算。
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 10307448徐利波@2022-03-12 10:21:30
*----------------------------------------------------------------------------
*/
UINT32 BspGetCfrChnMinBwInfo(UINT32 difchan, UINT32 *minBw)
{
    UINT32 bandLoop = 0;
    UINT32 carrLoop = 0;
    UINT32 lvFlag   = 0;
    UINT32 lvMinBw  = 0xFFFFFFFF;
    UINT32 splMinBw = 0xFFFFFFFF;
    T_CfrChnBandInfo *pCfrDifChnInfo = NULL;

    INPUT_POINTER_CHECK(minBw);

    pCfrDifChnInfo = BspGetCfrChnInfo(difchan);
    if (pCfrDifChnInfo == NULL)
    {
        dbgInfoEx("[%s]Get Cfr Chn[%d] Info Error!\n", __FUNCTION__, difchan);
        return BSP_ERROR;
    }

    for(bandLoop = 0; bandLoop < pCfrDifChnInfo->bandNum; bandLoop++)
    {
        CONTINUE_IF_EXP(pCfrDifChnInfo->usedFlag[bandLoop] == CFR_BAND_NOT_USED);

        for(carrLoop = 0; carrLoop < pCfrDifChnInfo->bandCarrNum[bandLoop]; carrLoop++)
        {
            if (pCfrDifChnInfo->carrInfo[bandLoop][carrLoop].carrFlag == CFR_CARR_VALID)
            {
                if ((pCfrDifChnInfo->carrInfo[bandLoop][carrLoop].carrRadio == RADIO_STANDARD_LTE_FDD) 
                    || (pCfrDifChnInfo->carrInfo[bandLoop][carrLoop].carrRadio == RADIO_STANDARD_5G) 
                    || (pCfrDifChnInfo->carrInfo[bandLoop][carrLoop].carrRadio == RADIO_STANDARD_5G_RESERVED))
                {
                    lvMinBw = (lvMinBw < pCfrDifChnInfo->carrInfo[bandLoop][carrLoop].carrBw) ? lvMinBw : pCfrDifChnInfo->carrInfo[bandLoop][carrLoop].carrBw;
                    lvFlag = CFR_CHN_EXIST_LV;
                }
                else if ((pCfrDifChnInfo->carrInfo[bandLoop][carrLoop].carrRadio == RADIO_STANDARD_GSM)
                        && (pCfrDifChnInfo->carrInfo[bandLoop][carrLoop].carrBw == 0))
                {
                    splMinBw = (splMinBw < 200) ? splMinBw : 200;
                }
                else
                {
                    splMinBw = (splMinBw < pCfrDifChnInfo->carrInfo[bandLoop][carrLoop].carrBw) ? splMinBw : pCfrDifChnInfo->carrInfo[bandLoop][carrLoop].carrBw;
                }
            }
        }
    }

    if (lvFlag == CFR_CHN_EXIST_LV)
    {
        *minBw = lvMinBw;
    }
    else
    {
        *minBw = splMinBw;
    }
    
    return BSP_OK;
}

/*****************************************************************************
*  函数名称   : BspSelectCfrGatePara
*  功能描述   : FDD根据混模制式和最小带宽选取对应的削峰动态参数
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : difchan:中频通道号
               len：FDD动态参数表格大小
               pFddPara:FDD削峰动态参数表
*  输出参数   : index: 动态参数表的行索引
*  返 回 值   : BSP_OK  - 成功;其它值为失败
*  其它说明   : 无
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 10307448徐利波@2022-03-16 10:27:43
*----------------------------------------------------------------------------
*/
UINT32 BspSelectCfrGatePara(UINT32 difchan, UINT32 len, T_CfrDynPara_FDD *pFddPara, UINT32 *index)
{
    UINT32 ret         = BSP_OK;
    UINT32 chnMixRadio = 0;
    UINT32 chnMinBw    = 0;
    UINT32 loop        = 0;
    UINT32 paraIndex   = 0;

    INPUT_POINTER_CHECK(index);
    INPUT_POINTER_CHECK(pFddPara);

    ret = BspGetCfrChnMixRadioInfo(difchan, &chnMixRadio);
    ret |= BspGetCfrChnMinBwInfo(difchan, &chnMinBw);

    dbgInfoEx("[%s] chnMixRadio:0x%x, chnMinBw:%d \n",__FUNCTION__, chnMixRadio, chnMinBw);

    for(loop = 0; loop < len; loop++)
    {
        if(chnMixRadio == pFddPara[loop].radio)
        {
            if((chnMinBw > pFddPara[loop].lowbound) && (chnMinBw <= pFddPara[loop].upbound))
            {
                paraIndex = loop;
                break;
            }
        }
    }

    if(loop >= len)
    {
        paraIndex = len-1;
        dbgInfoEx("%s difchan'%d mixRadio'0x%x, minBw'%d not found gate,switch the last gate!\n",__FUNCTION__,difchan,chnMixRadio,chnMinBw);
    }

    *index = paraIndex;

    return ret;
}

/*****************************************************************************
*  函数名称   : BspCfrGateInit_FDD
*  功能描述   : FDD初始化削峰动态参数
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : difchan:中频通道号
               pFddPara:FDD规则表
               len：FDD动态参数表格大小
*  输出参数   : 无
*  返 回 值   : BSP_OK  - 成功;其它值为失败
*  其它说明   : 无
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 10307448徐利波@2022-03-08 14:21:55
*----------------------------------------------------------------------------
*/
UINT32 BspCfrGateInit_FDD(UINT32 difchan, T_CfrDynPara_FDD *pFddPara, UINT32 len)
{
    UINT32 ret   = BSP_OK;
    UINT32 index = 0;
    UINT32 loop = 0;
    UINT32 cfrGate[E_CFR_THR_NUM] = {0};
    UINT32 cfrDelt[E_CFR_THR_NUM] = {0};
    UINT32 cfrWin[E_CFR_THR_NUM]  = {0};
    UINT32 cfrWinLevel[E_CFR_THR_NUM] = {0};

    ret = BspSelectCfrGatePara(difchan, len, pFddPara, &index);
    for(loop = 0; loop < E_CFR_THR_NUM; loop++)
    {
        if(index < len)
        {
            cfrGate[loop] = pFddPara[index].cfrgate[loop] ;
            cfrDelt[loop] = pFddPara[index].cfrdelt[loop];
            cfrWin[loop] = pFddPara[index].cfrwin[loop];
            cfrWinLevel[loop] = pFddPara[index].cfrwinlevel[loop];
            dbgInfoEx("[%s] cfrGate[%d]:%d \n", __FUNCTION__, loop, cfrGate[loop]);
            dbgInfoEx("[%s] cfrDelt[%d]:%d \n", __FUNCTION__, loop, cfrDelt[loop]);
            dbgInfoEx("[%s] cfrWin[%d]:%d \n", __FUNCTION__, loop, cfrWin[loop]);
            dbgInfoEx("[%s] cfrWinLevel[%d]:%d \n", __FUNCTION__, loop, cfrWinLevel[loop]);
        }
    }

    ret |= BspSetCfrGatePara(difchan, cfrGate);
    ret |= BspSetCfrDeltPara(difchan, cfrDelt);
    ret |= BspSetCfrWinPara(difchan, cfrWin);
    ret |= BspSetCfrWinLevelPara(difchan, cfrWinLevel);

    return ret;
}

/*****************************************************************************
*  函数名称   : BspCfrGateInit_IC4_2
*  功能描述   : 算法提供TDD和FDD的配置动态参数规则，如门限、窗长等，后续算法提供每个
               机型表格，直接根据表格自动初始化动态参数
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : difchan:中频通道号
               radioflag:制式标志，0:TDD 1:FDD
               pTddPara:TDD规则表
               pFddPara:FDD规则表
               len：表格大小
*  输出参数   : 无
*  返 回 值   : BSP_OK  - 成功;其它值为失败
*  其它说明   : 接口先实现，待算法提供具体表格后对gateinit接口单板下用新接口挂接
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 10307448徐利波@2022-03-8 14:20:13 
*----------------------------------------------------------------------------
*/
UINT32 BspCfrGateInit_IC4_2(UINT32 difchan, UINT32 radioflag, T_CfrDynPara_TDD *pTddPara, T_CfrDynPara_FDD *pFddPara, UINT32 len)
{
    UINT32 ret = BSP_OK;

    ret = BspSetCfrGateCoef(difchan);

    if(radioflag == CFR_CHAN_TDD_DX)
    {
        INPUT_POINTER_CHECK(pTddPara);
        ret |= BspCfrGateInit_TDD(difchan,pTddPara,len);
    }
    else if(radioflag == CFR_CHAN_FDD_DX)
    {
        INPUT_POINTER_CHECK(pFddPara);
        ret |= BspCfrGateInit_FDD(difchan,pFddPara,len); 
    }
    else
    {
        dbgInfoEx("%s radio flag is error!",__FUNCTION__);
        return BSP_ERROR;
    }

    return ret;
}

/*****************************************************************************
*  函数名称   : BspSetNBCarrMode
*  功能描述   : 设定NB 载波模式
*  读全局变量 :
*  写全局变量 :
*  输入参数   : ulChan   - Tx通道号
*             : ulCarr   - 载波号
*             : ulMode   - 载波模式
                0,1--inband; 2--guardband;  3--standalone
*  输出参数   :
*  返 回 值   :
*  其它说明   :
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A), 10229672 2019.12.4, 创建
*******************************************************************************/
UINT32 BspSetNBCarrMode(UINT32 ulChan, UINT32 ulCarr, UINT32 ulMode)
{
    UINT32 retVal  = BSP_OK;
	UINT32 chipidx = 0;
	UINT32 difChn  = 0;

    if((ulChan >= MAX_TX_CHANNEL)||(ulCarr >= BSP_MAX_CARR_NUM))
    {
        return BSP_ERROR;
	}

    retVal |= BspGetDifInfoByBspChn(ulChan, TX, &chipidx, &difChn);

    if(BSP_OK == retVal)
    {
    	g_aulNBCarrMode[difChn][ulCarr]=ulMode;
    }

    return retVal;
}

UINT32 BspGetNBCarrMode(UINT32 difChn,UINT32 ulCarr)
{
	UINT32 ulMode = 0;

	if((difChn >= MAX_TX_CHANNEL)||(ulCarr >= BSP_MAX_CARR_NUM))
    {
        return BSP_ERROR;
	}

	ulMode = g_aulNBCarrMode[difChn][ulCarr];

    return ulMode;
}

/**********************************************************************
* 函数名称：BspSetUmtsCpgCoef
* 功能描述：设置U单边滤波后的CPG系数
* 输入参数：参数0:bsp通道 ，参数1:制式 ，参数2:带宽，参数3:U单边滤波开启标志，1开启，0关闭
* 返 回 值: BSP_OK  - 成功;其它值为失败
* 其它说明：IC4.2未使用 cfgflag 标志
***********************************************************************/
UINT32 BspSetUmtsCpgCoef(UINT32 bspChan, UINT32 ulCarrId, UINT32 radioMod, UINT32 umtsBw, UINT32 cfgflag)
{
    UINT32 retVal   = BSP_OK;
    UINT32 difChn   = 0;
    UINT32 chipidx  = 0;
    UINT32 cpgMode  = 0;
    UINT32 freqBand = 0;
    UINT32 suspend  = CFR_CPG_HW_CAL_STOP;
    UINT32 mode     = 0;
    UINT32 chnChgMask = 0;
    UINT32 ulCfrByPassMode = 0;
    T_CfrChnBandInfo *pCfrDifChnInfo = NULL;

    BspLog(LOG_LEVEL_0, "[%s]: bspChan'%d, ulCarrId'%d, radioMod'%d, bandwidth'%d \n", __FUNCTION__, bspChan, ulCarrId, radioMod, umtsBw);
    retVal = BspGetDifInfoByBspChn(bspChan, TX, &chipidx, &difChn);
    SET_BIT(chnChgMask, bspChan);
    retVal |= BspCfrClrHwCpgRam(chnChgMask);

    mode = BspGetCfrWorkMode();
    if (mode == CFR_NORMAL_MODE)
    {
        retVal = BspCfrChnInfoUpdateByBspChn(bspChan);
        if (retVal != BSP_OK)
        {
            dbgInfoEx("[%s]Cfr Get Chn Info Error \n",__FUNCTION__);
            return BSP_ERROR;
        }
    }

    pCfrDifChnInfo = BspGetCfrChnInfo(difChn);
    if((NULL == pCfrDifChnInfo) || (pCfrDifChnInfo->centerFreq == 0))
    {
        dbgInfoEx("[%s] error, get cfr commom para or Chn[%d] Info fail! \n", __FUNCTION__, difChn);
        return BSP_ERROR;
    }

    INPUT_POINTER_CHECK(s_pCfrCommPara);
    if(difChn < CFR_CHAN_MAX_NUM)
    {
        cpgMode = s_pCfrCommPara->uiCpgMode[difChn];
    }
    else
    {
        dbgInfoEx("[%s] difChn out of range!\n",__FUNCTION__);
        return BSP_ERROR;
    }

    ulCfrByPassMode = s_pCfrCommPara->uiCfrBypassMode[difChn];
    if (CFR_ZERODLY_BYPASS == ulCfrByPassMode)
    {
        retVal |= BspCfrDisable(difChn);
        dbgInfoEx("[%s] Chn %d Cfr Bypass Mode(%d) is Zero Dly ByPass\n",__FUNCTION__,difChn,ulCfrByPassMode);
        return retVal;
    }

    if (BspGetCfrFuncFlag() == CFR_FUNC_NOT_INIT)
    {
        dbgInfoEx("[%s]FUNC CFR NOT INIT \n", __FUNCTION__);
        return BSP_ERROR;
    }

    retVal |= BspCfrDisable(difChn);
    //retVal |= BspCfrGateInit(difChn);
    if (retVal != BSP_OK)
    {
        dbgInfoEx("[%s]Cfr Gate NULL \n",__FUNCTION__);
        return BSP_ERROR;
    }

    //retVal |= BspSetCfrCfg(difChn);
    retVal |= BspCfrSetBbTssiCfg(difChn);
    retVal |= BspHalAdaptCfrSetSymstrGsmSel(difChn, freqBand);
    retVal |= BspHalAdaptCfrSetCpgMode(difChn, freqBand, cpgMode);

    if(cpgMode == CFR_CPG_CPU_CAL)
    {
        dbgInfoEx("[%s]: difChn'%d UMTS Filter Cfr Cpg Use CPU Calculation! \n", __FUNCTION__, difChn);

        retVal = BspCfrCpgDataMemApply();
        if(retVal == BSP_ERROR)
        {
            dbgInfoEx("[%s] Cfr Cpg Data Apply Mem Error \n", __FUNCTION__);
            BspLog(LOG_LEVEL_0, "[%s] Cfr Cpg Data Apply Mem Error \n", __FUNCTION__);
            return BSP_ERROR;
        }

        retVal |= BspCfrSetCpgParaCpuCalByRadio(difChn, ulCarrId, BSP_RADIO_STANDARD_UMTS, umtsBw);
        retVal |= BspSetCpgCfg(difChn);
    }
    else
    {
        dbgInfoEx("[%s]: difChn'%d  Flter Cfr Cpg Use Hardware Calculation! \n", __FUNCTION__, difChn);

        retVal |= BspHalAdaptCfrSetCpgSuspend(difChn, freqBand, suspend);
        retVal |= BspCfrSetUmtsCpgPara_HwCal(difChn, ulCarrId, umtsBw);
        suspend = CFR_CPG_HW_CAL_START;
        retVal |= BspHalAdaptCfrSetCpgSuspend(difChn, freqBand, suspend);
        BspSysMsDelay(80);
    }

    retVal |= BspSetCfrDelay(difChn);
    retVal |= BspCfrSetTddSwPara(difChn);
    retVal |= BspCfrSetCpgLen(difChn);
    retVal |= BspCfrEnable(difChn);
    BspLog(LOG_LEVEL_0, "[%s] exit ret%d\n", __FUNCTION__, retVal);

    return retVal;
}

UINT32 BspSetSideFilterCpgCoef(UINT32 bspChan, UINT32 carrNo, UINT32 radioMode, UINT32 bandwidth)
{
    UINT32 retVal  = BSP_OK;
    UINT32 difChan = 0;
    UINT32 chipId  = 0;
    UINT32 cpgMode = 0;
    UINT32 freqBand = 0;
    UINT32 suspend  = CFR_CPG_HW_CAL_STOP;
    UINT32 mode     = 0;
    UINT32 chnChgMask = 0;
    UINT32 cfrByPassMode = 0;
    T_CfrChnBandInfo *pCfrDifChnInfo = NULL;

    BspLog(LOG_LEVEL_0, "[%s]: bspChan%d,carrNo%d,radioMode%d,bandwidth%d\n", __FUNCTION__, bspChan, carrNo, radioMode, bandwidth);

    retVal = BspGetDifInfoByBspChn(bspChan, TX, &chipId, &difChan);
    RETURN_VAL_DO_IF_EXP(BSP_OK != retVal, BSP_ERROR, BspLog(LOG_LEVEL_0, "%s>>bspChan'%d BspGetDifInfoByBspChn Get Error!\n", __FUNCTION__, bspChan));
    RETURN_VAL_DO_IF_EXP(difChan >= CFR_CHAN_MAX_NUM, BSP_ERROR, BspLog(LOG_LEVEL_0, "[%s] difChan out of range!\n", __FUNCTION__));

    SET_BIT(chnChgMask, bspChan);
    retVal |= BspCfrClrHwCpgRam(chnChgMask);

    mode = BspGetCfrWorkMode();
    if(CFR_NORMAL_MODE == mode)
    {
        retVal |= BspCfrChnInfoUpdateByBspChn(bspChan);
        RETURN_VAL_DO_IF_EXP(BSP_OK != retVal, BSP_ERROR, BspLog(LOG_LEVEL_0, "[%s]Cfr Get Chn Info Error \n", __FUNCTION__));
    }

    pCfrDifChnInfo = BspGetCfrChnInfo(difChan);
    RETURN_VAL_DO_IF_EXP(((NULL == pCfrDifChnInfo) || (pCfrDifChnInfo->centerFreq == 0)), BSP_ERROR, BspLog(LOG_LEVEL_0, "[%s] error, get cfr commom para or Chn[%d] info fail! \n", __FUNCTION__, difChan));

    INPUT_POINTER_CHECK(s_pCfrCommPara);
    cpgMode = s_pCfrCommPara->uiCpgMode[difChan];

    cfrByPassMode = s_pCfrCommPara->uiCfrBypassMode[difChan];
    if(CFR_ZERODLY_BYPASS == cfrByPassMode)
    {
        retVal |= BspCfrDisable(difChan);
        BspLog(LOG_LEVEL_0, "[%s] Chn %d Cfr Bypass Mode(%d) is Zero Dly ByPass\n", __FUNCTION__, difChan, cfrByPassMode);
        return retVal;
    }

    RETURN_VAL_DO_IF_EXP(CFR_FUNC_NOT_INIT == BspGetCfrFuncFlag(), BSP_ERROR, BspLog(LOG_LEVEL_0, "[%s]FUNC CFR NOT INIT \n", __FUNCTION__));

    retVal |= BspCfrDisable(difChan);
    RETURN_VAL_DO_IF_EXP(BSP_OK != retVal, BSP_ERROR, BspLog(LOG_LEVEL_0, "[%s]Cfr Gate NULL \n", __FUNCTION__));

    retVal |= BspCfrSetBbTssiCfg(difChan);
    retVal |= BspHalAdaptCfrSetSymstrGsmSel(difChan, freqBand);
    retVal |= BspHalAdaptCfrSetCpgMode(difChan, freqBand, cpgMode);

    if(CFR_CPG_HW_CAL == cpgMode)
    {
        BspLog(LOG_LEVEL_0, "[%s]: difChan'%d Side Filter Cfr Cpg Use Hardware Calculation! \n", __FUNCTION__, difChan);

        retVal |= BspHalAdaptCfrSetCpgSuspend(difChan, freqBand, suspend);
        retVal |= BspCfrSetSideFilterCpgPara_HwCal(difChan, carrNo, radioMode, bandwidth);
        suspend = CFR_CPG_HW_CAL_START;
        retVal |= BspHalAdaptCfrSetCpgSuspend(difChan, freqBand, suspend);
        BspSysMsDelay(80);
    }
    else
    {
    	BspLog(LOG_LEVEL_0, "[%s]: difChn'%d Side Filter Cfr Cpg Use CPU Calculation! \n", __FUNCTION__, difChan);

        retVal = BspCfrCpgDataMemApply();
        if(retVal == BSP_ERROR)
        {
            BspLog(LOG_LEVEL_0, "[%s] Cfr Cpg Data Apply Mem Error \n", __FUNCTION__);
            return BSP_ERROR;
        }

        retVal |= BspCfrSetCpgParaCpuCalByRadio(difChan, carrNo, radioMode, bandwidth);
        retVal |= BspSetCpgCfg(difChan);
    }

    retVal |= BspSetCfrDelay(difChan);
    retVal |= BspCfrSetTddSwPara(difChan);
    retVal |= BspCfrSetCpgLen(difChan);
    retVal |= BspCfrEnable(difChan);

    BspLog(LOG_LEVEL_0, "[%s] exit ret%d\n", __FUNCTION__, retVal);

    return retVal;
}

UINT32 testsidefilter(UINT32 bspChan, UINT32 carrNo, UINT32 radio, UINT32 bandWidth, INT32 nco1)
{
    UINT32  ret = BSP_OK;
    INT32 freq = 0;

    ret = BspGetRcfCoefByBandWith(bspChan, radio, bandWidth);
    RETURN_VAL_DO_IF_EXP(BSP_OK != ret, BSP_ERROR, dbgErr("[%s] getRfcCoefByBandWith error\n", __FUNCTION__));

    ret |= BspSetSideFilterDlCoef(bspChan, carrNo, radio, bandWidth);
    RETURN_VAL_DO_IF_EXP(BSP_OK != ret, BSP_ERROR, dbgErr("[%s] set coef tx share failed\n", __FUNCTION__));

    ret |= BspSetSideFilterTxNco(bspChan, carrNo, radio, nco1);
    RETURN_VAL_DO_IF_EXP(BSP_OK != ret, BSP_ERROR, dbgErr("[%s] set tx nco1 failed\n", __FUNCTION__));

    freq = BspGetChanCarrFreq(TX, bspChan, carrNo, radio);
    RETURN_VAL_DO_IF_EXP((((INT32)BSP_ERROR == freq) || ((INT32)ERROR_NULL_POINTER == freq) || (0 == freq)), BSP_ERROR, dbgErr("[%s] get freq:%d error\n", __FUNCTION__, freq));

    ret |= BspSetSideFilterTxCarrFreq(bspChan, carrNo, radio, (INT32)(freq - nco1));
    RETURN_VAL_DO_IF_EXP(BSP_OK != ret, BSP_ERROR, dbgErr("[%s] set tx carrier freq failed\n", __FUNCTION__));

    ret |= BspSetSideFilterCpgCoef(bspChan, carrNo, radio, bandWidth);
    RETURN_VAL_DO_IF_EXP(BSP_OK != ret, BSP_ERROR, dbgErr("[%s] set cpg share failed\n", __FUNCTION__));

    return ret;
}

/*解决powctrl\cfr 互相调用问题*/
UINT32 BspSetTssiPowInfoCallBackInit(FUN_GET_POWCTRL_TSSI_INFO pGetTssi)
{
    pGetTssiPowInfo = pGetTssi;
    return BSP_OK;
}

FUN_GET_POWCTRL_TSSI_INFO BspGetTssiPowInfoCallBackInit(void)
{
    return pGetTssiPowInfo;
}

UINT32 BspSetTxIfTssiCallBackInit(FUN_GET_POWCTRL_Tx_IF_TSSI pGetTxIfTssi)
{
    pGetTxIfTssiPow = pGetTxIfTssi;
    return BSP_OK;
}

FUN_GET_POWCTRL_Tx_IF_TSSI BspGetTxIfTssiCallBackInit(VOID)
{
    return pGetTxIfTssiPow;
}

UINT32 BspGetRefreshCpgPowFlag(UINT32 bspChn, UINT32 *cpgPowFlag)
{
    UINT32 retVal = BSP_OK;
    UINT32 bandNo = 0;
    INT32 txIfTssiDbm = 0;
    INT32 ratePowDbm = 0;
    UINT32 ratePowMw = 0;
    UINT32 powFlag = BSP_REFRESH_CPG_BY_APP_POW;
    FUN_GET_POWCTRL_Tx_IF_TSSI pGetTxIfTssiPow = BspGetTxIfTssiCallBackInit();

    INPUT_POINTER_CHECK(cpgPowFlag);
    INPUT_POINTER_CHECK(pGetTxIfTssiPow);

    retVal |= pGetTxIfTssiPow(bspChn, bandNo, &txIfTssiDbm);
    retVal |= BspGetRruPathRatedPower(bspChn, &ratePowMw);
    if (0 == ratePowMw)
    {
        dbgInfo("[%s] error, bspChn'%u, ratePowMw'%d \n", __FUNCTION__, bspChn, ratePowMw);
        return BSP_ERROR;
    }
    ratePowDbm = 1000.0 * log10((DOUBLE)ratePowMw);

    /*实时功率高于额定功率减10db的差, 则用实时载波功率计算CPG*/
    if (txIfTssiDbm >= (ratePowDbm - 1000))
    {
        powFlag = BSP_REFRESH_CPG_BY_REAL_POW;
    }

    *cpgPowFlag = powFlag;
    dbgInfoEx("[%s] bspChn'%u, ratePowMw'%d, txIfTssiDbm'%d, ratePowDbm'%d, powFlag'%u \n",
                __FUNCTION__, bspChn, ratePowMw, txIfTssiDbm, ratePowDbm, *cpgPowFlag);

    return retVal;
}

/*被qsort调用,降序*/
INT32 BspCompareDescendOrder(const VOID *a, const VOID *b)
{
    INPUT_POINTER_CHECK(a);
    INPUT_POINTER_CHECK(b);
    const UINT32 *aa = (const UINT32*)a;
    const UINT32 *bb = (const UINT32*)b;
    return (*aa != *bb) ? (*bb - *aa) : 0;
}

/*对一组Dss载波中同频点同带宽的载波功率进行计算合并,处理完的载波索引信息保存在dssGroupFlag[]数组中*/
UINT32 BspDssPowforSameFreqBw(UINT32 bspChn, UINT32 dssGroupFlag[], UINT32 arrLen, T_CfrChnBandInfo *pChnInfo)
{
    UINT32 retVal = BSP_OK;
    UINT32 index = 0;
    UINT32 loop = 0;
    UINT32 freqBand = 0;
    UINT32 carrCopyFlag1 = OAM_CARR_COPY_TYPE_NO_COPY;
    UINT32 carrCopyFlag2 = OAM_CARR_COPY_TYPE_NO_COPY;
    UINT32 carrNo = 0;
    UINT32 radioMode = 0;
    UINT32 carrBw = 0;
    UINT32 carrFreq = 0;
    UINT32 carrPowMw = 0;
    UINT32 carrNo2 = 0;
    UINT32 radioMode2 = 0;
    UINT32 carrBw2 = 0;
    UINT32 carrFreq2 = 0;
    UINT32 carrPowMw2 = 0;

    INPUT_POINTER_CHECK(dssGroupFlag);
    INPUT_POINTER_CHECK(pChnInfo);

    for (index = 0; index < arrLen; index++)
    {
        if (dssGroupFlag[index] != 0)
        {
            for (loop = index + 1; loop < arrLen; loop++)
            {
                if (dssGroupFlag[loop] != 0)
                {
                    carrNo = pChnInfo->carrInfo[freqBand][index].carrNo;
                    radioMode = pChnInfo->carrInfo[freqBand][index].carrRadio;
                    carrBw = pChnInfo->carrInfo[freqBand][index].carrBw;
                    carrFreq = pChnInfo->carrInfo[freqBand][index].freq;
                    carrPowMw = pChnInfo->carrInfo[freqBand][index].powerMw;

                    carrNo2 = pChnInfo->carrInfo[freqBand][loop].carrNo;
                    radioMode2 = pChnInfo->carrInfo[freqBand][loop].carrRadio;
                    carrBw2 = pChnInfo->carrInfo[freqBand][loop].carrBw;
                    carrFreq2 = pChnInfo->carrInfo[freqBand][loop].freq;
                    carrPowMw2 = pChnInfo->carrInfo[freqBand][loop].powerMw;

                    if ((carrFreq == carrFreq2) && (carrBw == carrBw2))
                    {
                        retVal |= BspHalAdaptGetCarrCopyFlag(bspChn, TX, carrNo, radioMode, &carrCopyFlag1);
                        retVal |= BspHalAdaptGetCarrCopyFlag(bspChn, TX, carrNo2, radioMode2, &carrCopyFlag2);
                        /*LTE劈裂产生的DSS,将配置功率直接相加;功率共享以及其他频谱共享情况取两者中较大功率后忽略其中一载波.注:载波复制标志只有LTE有,U劈裂没有该标志*/
                        if (((OAM_CARR_COPY_TYPE_CARR_COPY_MAIN == carrCopyFlag1) && (OAM_CARR_COPY_TYPE_CARR_COPY_ADJUNCT == carrCopyFlag2))
                        || ((OAM_CARR_COPY_TYPE_CARR_COPY_MAIN == carrCopyFlag2) && (OAM_CARR_COPY_TYPE_CARR_COPY_ADJUNCT == carrCopyFlag1)))
                        {
                            pChnInfo->carrInfo[freqBand][index].powerMw = carrPowMw + carrPowMw2;
                        }
                        else
                        {
                            pChnInfo->carrInfo[freqBand][index].powerMw = carrPowMw >= carrPowMw2 ? carrPowMw : carrPowMw2;
                        }
                        dssGroupFlag[loop] = 0;
                        dbgInfoEx("[%s] bspChn'%u, (carrNo1'%u, radio1'0x%x), (carrNo2'%u, radio2'0x%x), freq'%u, Bw'%u, Flag1'%u, Flag2'%u, pow'%d, freq and bw are the same.\n", \
                        __FUNCTION__, bspChn, carrNo, radioMode, carrNo2, radioMode2, carrFreq, carrBw, carrCopyFlag1, carrCopyFlag2, pChnInfo->carrInfo[freqBand][index].powerMw);
                    }
                }
            }
        }
    }

    return retVal;
}

/*通过配置功率解耦的方式计算DSS载波功率：劈裂载波功率进行相加,功率共享的载波其中一载波不考虑其功率;常规带宽重叠部分舍弃功率谱密度小的那份功率*/
UINT32 BspGetDssCarrCfgPow(UINT32 bspChn, T_CfrChnBandInfo *pChnInfo, UINT32 *dssCarrPow)
{
    UINT32 retVal = BSP_OK;
    UINT32 index = 0;
    UINT32 loop = 0;
    UINT32 freqBand = 0;
    UINT32 dssGroupFlag[BSP_MAX_CARR_NUM] = {0};
    UINT32 dssBorderFreq[BSP_MAX_CARR_NUM * 2] = {0};
    DOUBLE maxPowDensity = 0.0;
    UINT32 sumDssPow = 0;
    UINT32 carrBw = 0;
    UINT32 carrFreq = 0;
    UINT32 carrPowMw = 0;
    UINT32 carrFreqL = 0;
    UINT32 carrFreqR = 0;
    UINT32 borderL = 0;
    UINT32 borderR = 0;

    INPUT_POINTER_CHECK(pChnInfo);
    INPUT_POINTER_CHECK(dssCarrPow);
    memcpy_s(dssGroupFlag, BSP_MAX_CARR_NUM*sizeof(UINT32), g_cfrDssGroupFlag, BSP_MAX_CARR_NUM*sizeof(UINT32));

    /*先处理中心频点相同且带宽相等的载波功率折算*/
    retVal = BspDssPowforSameFreqBw(bspChn, dssGroupFlag, BSP_MAX_CARR_NUM, pChnInfo);

    /*记录DSS载波的边界频点*/
    for (index = 0; index < BSP_MAX_CARR_NUM; index++)
    {
        if (dssGroupFlag[index] != 0)
        {
            carrFreq = pChnInfo->carrInfo[freqBand][index].freq;
            carrBw = pChnInfo->carrInfo[freqBand][index].carrBw;
            dssBorderFreq[loop++] = carrFreq - (carrBw / 2);
            dssBorderFreq[loop++] = carrFreq + (carrBw / 2);
            dbgInfoEx("[%s] Record the borderFreq(borderL'%u and borderR'%u) of carr(chan'%u, carrNo'%u, radio'0x%x, frep'%u, carrBw'%u, pow'%u).\n",
                    __FUNCTION__, dssBorderFreq[loop-2], dssBorderFreq[loop-1], bspChn, pChnInfo->carrInfo[freqBand][index].carrNo, \
                    pChnInfo->carrInfo[freqBand][index].carrRadio, carrFreq, carrBw, pChnInfo->carrInfo[freqBand][index].powerMw);
        }
    }

    /*对 dssBorderFreq 进行降序排列*/
    qsort(dssBorderFreq, BSP_MAX_CARR_NUM*2, sizeof(dssBorderFreq[0]), BspCompareDescendOrder);

    /*根据频点区间,分段计算功率并进行累加*/
    for (loop = 0; loop < (BSP_MAX_CARR_NUM * 2 - 1); loop++)
    {
        borderR = dssBorderFreq[loop];
        borderL = dssBorderFreq[loop + 1];

        if (0 == borderL)
        {
            break;
        }

        if (borderL == borderR)
        {
            continue;;
        }

        /*寻找包含该带宽区间载波中的最大功率谱密度*/
        maxPowDensity = 0.0;
        for (index = 0; index < BSP_MAX_CARR_NUM; index++)
        {
            if (dssGroupFlag[index] != 0)
            {
                carrFreq = pChnInfo->carrInfo[freqBand][index].freq;
                carrBw = pChnInfo->carrInfo[freqBand][index].carrBw;
                carrPowMw = pChnInfo->carrInfo[freqBand][index].powerMw;
                carrFreqL = carrFreq - (carrBw / 2);
                carrFreqR = carrFreq + (carrBw / 2);

                if ((carrFreqL <= borderL) && (borderR <= carrFreqR))
                {
                    if (0 != carrBw)
                    {
                        maxPowDensity = maxPowDensity > (carrPowMw/(DOUBLE)carrBw) ? maxPowDensity : (carrPowMw/(DOUBLE)carrBw);
                        dbgInfoEx("[%s] bwLoop'%u, borderFreq(%u and %u) is found in carr(chan'%u, index'%u, freq'%u, bw'%u, pow'%u) with a density of %.3f.\n",
                            __FUNCTION__, loop, borderL, borderR, bspChn, index, carrFreq, carrBw, carrPowMw, maxPowDensity);
                    }
                }
            }
        }

        sumDssPow += (borderR - borderL) * maxPowDensity;
        dbgInfoEx("[%s] bspChn'%u, borderL'%u, borderR'%u, maxPowDensity'%.3f, sumDssPow'%u.\n",
            __FUNCTION__, bspChn, borderL, borderR, maxPowDensity, sumDssPow);
    }

    *dssCarrPow = sumDssPow;

    return retVal;
}

/*获取 g_cfrDssGroupFlag 标记的一组Dss载波合并后的功率*/
UINT32 BspGetDssCarrPow(UINT32 bspChn, T_CfrChnBandInfo *pChnInfo, UINT32 *dssCarrPow)
{
    UINT32 retVal = BSP_OK;
    UINT32 powFlag = 0;
    UINT32 index = 0;
    UINT32 freqBand = 0;
    UINT32 carrRadio = 0;
    UINT32 carrNo = 0;
    UINT32 realPowMw = 0;
    UINT32 dssPowMw = 0;
    INT32 tssiPowDbm = 0;
    INT32 tssiPowDbfs = 0;
    FUN_GET_POWCTRL_TSSI_INFO pGetTssiPowInfo = NULL;

    INPUT_POINTER_CHECK(pChnInfo);
    INPUT_POINTER_CHECK(dssCarrPow);

    retVal |= BspGetRefreshCpgPowFlag(bspChn, &powFlag);

    if (BSP_REFRESH_CPG_BY_REAL_POW == powFlag)
    {
        for (index = 0; index < BSP_MAX_CARR_NUM; index++)
        {
            if (g_cfrDssGroupFlag[index] != 0)
            {
                carrNo      = pChnInfo->carrInfo[freqBand][index].carrNo;
                carrRadio   = pChnInfo->carrInfo[freqBand][index].carrRadio;

                pGetTssiPowInfo = BspGetTssiPowInfoCallBackInit();
                INPUT_POINTER_CHECK(pGetTssiPowInfo);
                pGetTssiPowInfo(bspChn, carrRadio, carrNo, &tssiPowDbm, &tssiPowDbfs);
                if (0 == tssiPowDbm)
                {
                    continue;
                }
                realPowMw = (UINT32)pow(10, (tssiPowDbm * 1.0 / 100 / 10));

                dssPowMw += realPowMw;
                dbgInfoEx("[%s] powFlag'%u, bspChn'%u, carrNo'%u, carrRadio'0x%x, realPowMw'%u, dssPowMw'%u \n",
                        __FUNCTION__, powFlag, bspChn, carrNo, carrRadio, realPowMw, dssPowMw);
            }
        }

        *dssCarrPow = dssPowMw;
        return retVal;
    }

    retVal |= BspGetDssCarrCfgPow(bspChn, pChnInfo, dssCarrPow);

    return retVal;
}

UINT32 BspGetRefreshCfrCpgFlag(UINT32 bspChn, UINT32 *flag)
{
    if (bspChn >= BSP_IC42_MAX_TX_CHAN_NUM)
    {
        dbgInfoEx("[%s] bspChn[%u] out of range!\n", __FUNCTION__, bspChn);
        return BSP_ERROR;
    }

    *flag = g_refreshCfrCpgFlag[bspChn];

    return BSP_OK;
}

UINT32 BspSetRefreshCfrCpgFlag(UINT32 bspChn, UINT32 flag)
{
    if (bspChn >= BSP_IC42_MAX_TX_CHAN_NUM)
    {
        dbgInfoEx("[%s] bspChn[%u] out of range!\n", __FUNCTION__, bspChn);
        return BSP_ERROR;
    }

    g_refreshCfrCpgFlag[bspChn] = flag;

    return BSP_OK;
}

UINT32 BspRefreshCfrCpgTbl(UINT32 bspChn)
{
    UINT32 retVal = BSP_OK;
    UINT32 cpgMode = 0;
    UINT32 difChn = 0;
    UINT32 chipidx = 0;
    UINT32 cpgPowFlag = 0;

    retVal |= BspGetDifInfoByBspChn(bspChn, TX, &chipidx, &difChn);
    retVal |= BspCfrJudgeCpgMode(difChn, &cpgMode);
    retVal |= BspGetRefreshCpgPowFlag(bspChn, &cpgPowFlag);

    if(cpgMode == CFR_CPG_CPU_CAL)
    {
        dbgInfoEx("[%s]: difChn'%d  cfr cpg will be refreshed using real power. \n", __FUNCTION__,difChn);
        retVal |= BspSetRefreshCfrCpgFlag(bspChn, cpgPowFlag);
        retVal |= BspCfrSetCpgPara_CpuCal(bspChn);
        retVal |= BspSetRefreshCfrCpgFlag(bspChn, BSP_REFRESH_CPG_BY_APP_POW);
    }

    return retVal;
}

UINT32 BspJudgeCfrCpgRefreshCarrPow(UINT32 cpgCalcFlag, UINT32 powShareFlag, INT32 appPowMw, INT32 realPowMw, INT32 *carrPowMw)
{
    INPUT_POINTER_CHECK(carrPowMw);

    *carrPowMw = ((cpgCalcFlag != 0) && (powShareFlag != 0)) ? realPowMw : appPowMw;

    return BSP_OK;
}

/* Started by AICoder, pid:wf8e6ab358ba3a014bc00af6e0ae3111d2995dbb */
static T_AllChnCpgCarrInfo* GetExcessCpgCarrInfo(VOID)
{
    if (s_pAllChnCpgCarrInfo == NULL)
    {
        s_pAllChnCpgCarrInfo = (T_AllChnCpgCarrInfo*)malloc(sizeof(T_AllChnCpgCarrInfo));
        if (s_pAllChnCpgCarrInfo != NULL)
        {
            memset_s(s_pAllChnCpgCarrInfo, sizeof(T_AllChnCpgCarrInfo), 0, sizeof(T_AllChnCpgCarrInfo));
        }
    }
    return s_pAllChnCpgCarrInfo;
}
/* Ended by AICoder, pid:wf8e6ab358ba3a014bc00af6e0ae3111d2995dbb */

/* Started by AICoder, pid:a5d79ze4e4yae19142c40b3b60c98d3c9793bc5e */
/**
 * 函数名称: BspSetExcessCpgCarrInfo
 * 功能描述: 设置超配载波信息
 * 输入参数: difChan - 中频通道号
 *           radioMode - 载波制式
 *           carrId - 载波索引
 * 输出参数: 无
 * 返回值:    无
*/
VOID BspSetExcessCpgCarrInfo(UINT32 difChan, UINT32 radioMode, UINT32 carrId)
{
    UINT32 bspChan = 0;
    UINT32 carrNum = 0;
    UINT32 maxChanNum = BspGetTxChannel();
    T_AllChnCpgCarrInfo* pAllChnCpgCarrInfo = GetExcessCpgCarrInfo();

    INPUT_POINTER_CHECK_RETURN(pAllChnCpgCarrInfo);
    BspGetBspChnInfoByDifChn(difChan, TX, &bspChan);
    CHECK_CHAN_VALID(bspChan, maxChanNum, IC42_MAX_CHAN_NUM);

    carrNum = pAllChnCpgCarrInfo->carrNum[bspChan];
    if (pAllChnCpgCarrInfo->totalCarrNum >= MAX_EXCEED_CPG_RAM_CARR_NUM || carrNum >= MAX_EXCEED_CPG_RAM_CARR_NUM)
    {
        dbgInfo("%s, The number of excess cpg carr already equal to MAX_EXCEED_CPG_RAM_CARR_NUM! \n", __FUNCTION__);
        return;
    }
    BspLog(LOG_LEVEL_0, "%s, Set excess cpg carr info, bspChan:%d, carrIndex: %d, radioMode: %d\n", __FUNCTION__, bspChan, carrId, radioMode);
    pAllChnCpgCarrInfo->chnCpgCarrInfo[bspChan][carrNum].radioMode = radioMode;
    pAllChnCpgCarrInfo->chnCpgCarrInfo[bspChan][carrNum].carrIndex = carrId;
    pAllChnCpgCarrInfo->carrNum[bspChan]++;
    pAllChnCpgCarrInfo->totalCarrNum++;
}
/* Ended by AICoder, pid:a5d79ze4e4yae19142c40b3b60c98d3c9793bc5e */

UINT32 BspSetDssCfrOriginCoefAndRecordExcessCarr(UINT32 difChan, UINT32 carrIndex, UINT32 carrRadio, UINT32 carrBw, UINT32 coefLen, const INT32 *pCoefPara)
{
    UINT32 retVal = BSP_OK;

    retVal = BspHalAdaptDssCfrSetOriginCoef(difChan, carrIndex, carrRadio, carrBw, coefLen, pCoefPara);
    if (retVal == BSP_INVALID_VALUE)
    {
        BspSetExcessCpgCarrInfo(difChan, carrRadio, carrIndex);
    }

    return retVal;
}

/* Started by AICoder, pid:c690321be47fedd140d6097af0616530fc0592ef */
/**
 * 函数名称: ClrExcessCpgCarrInfo
 * 功能描述: 根据bspChan使用memset_s清空s_pAllChnCpgCarrInfo的信息
 * 输入参数: bspChan - BSP通道号
 * 输出参数: 无
 * 返回值: 无
*/
static VOID ClrExcessCpgCarrInfo(UINT32 bspChan)
{
    UINT32 maxChanNum = BspGetTxChannel();
    T_AllChnCpgCarrInfo* pAllChnCpgCarrInfo = GetExcessCpgCarrInfo();

    INPUT_POINTER_CHECK_RETURN(pAllChnCpgCarrInfo);
    CHECK_CHAN_VALID(bspChan, maxChanNum, IC42_MAX_CHAN_NUM);

    if(pAllChnCpgCarrInfo->carrNum[bspChan] > 0)
    {
        pAllChnCpgCarrInfo->totalCarrNum -= pAllChnCpgCarrInfo->carrNum[bspChan];
        pAllChnCpgCarrInfo->carrNum[bspChan] = 0;
        memset_s(&(pAllChnCpgCarrInfo->chnCpgCarrInfo[bspChan][0]), sizeof(T_ChnCpgCarrInfo) * MAX_EXCEED_CPG_RAM_CARR_NUM, 0, sizeof(T_ChnCpgCarrInfo) * MAX_EXCEED_CPG_RAM_CARR_NUM);
        BspLog(LOG_LEVEL_0, "%s, clr all excess cpg carr info in bspChan:%d \n", __FUNCTION__, bspChan);
    }
}
/* Ended by AICoder, pid:c690321be47fedd140d6097af0616530fc0592ef */

static VOID ClrAllExcessCpgCarrInfo(VOID)
{
    UINT32 loop = 0;
    UINT32 maxChanNum = BspGetTxChannel();

    maxChanNum = maxChanNum < IC42_MAX_CHAN_NUM ? maxChanNum : IC42_MAX_CHAN_NUM;
    for(loop = 0; loop < maxChanNum; ++loop)
    {
        ClrExcessCpgCarrInfo(loop);
    }
}

static UINT32 GetCpgCarrExcessStatus(VOID)
{
    UINT32 retVal = NOT_EXCEED_CPG_RAM;
    UINT32 bspChan = 0;
    UINT32 difChan = 0;
    UINT32 bandLoop = 0;
    UINT32 carrLoop = 0;
    UINT32 carrCnt = 0;
    UINT32 bandCarrNum = 0;
    UINT32 alarmFlag = 0;
    UINT32 cpgMode = 0;
    T_CfrChnBandInfo *pCfrDifChnInfo = NULL;
    T_DifChanOriginCoefPara *cpgOriginCoefPara = NULL;
    UINT32 maxChanNum = BspGetTxChannel();
    T_ChanRfCfgPara *pRfCfg = NULL;

    cpgOriginCoefPara = (T_DifChanOriginCoefPara*)malloc(sizeof(T_DifChanOriginCoefPara));
    if(cpgOriginCoefPara == NULL)
    {
        BspLog(LOG_LEVEL_0, "%s, cpgOriginCoefPara is NULL! \n", __FUNCTION__);
        return FAIL_TO_GET_CPG_RAM_STATUS;
    }
    memset_s(cpgOriginCoefPara, sizeof(T_DifChanOriginCoefPara), 0, sizeof(T_DifChanOriginCoefPara));

    maxChanNum = maxChanNum < IC_CHAN_MAX_NUM ? maxChanNum : IC_CHAN_MAX_NUM;
    for(difChan = 0; difChan < maxChanNum; ++difChan)
    {
        BspCfrJudgeCpgMode(difChan, &cpgMode);
        CONTINUE_IF_EXP((cpgMode == CFR_CPG_CPU_CAL))

        BspGetBspChnInfoByDifChn(difChan, TX, &bspChan);
        pRfCfg = GetRfCfgPara(bspChan, TX);
        if(pRfCfg == NULL)
        {
            dbgErr("%s, pRfCfg is NULL!\n", __FUNCTION__);
            free(cpgOriginCoefPara);
            return FAIL_TO_GET_CPG_RAM_STATUS;
        }
        CONTINUE_IF_EXP((pRfCfg->para.carrNum == 0))

        carrCnt = 0;
        pCfrDifChnInfo = BspGetCfrChnInfo(difChan);
        if(pCfrDifChnInfo != NULL)
        {
            for (bandLoop = 0; bandLoop < E_CFR_BAND_MAX; bandLoop ++)
            {
                CONTINUE_IF_EXP(pCfrDifChnInfo->usedFlag[bandLoop] == CFR_BAND_NOT_USED)
                bandCarrNum = pCfrDifChnInfo->bandCarrNum[bandLoop];
                bandCarrNum = bandCarrNum < DLCFR_CFR_CPG_ONLINE_MAX_CARR ? bandCarrNum : DLCFR_CFR_CPG_ONLINE_MAX_CARR;
                for (carrLoop = 0; carrLoop < bandCarrNum; carrLoop++)
                {
                    CONTINUE_IF_EXP(pCfrDifChnInfo->carrInfo[bandLoop][carrLoop].carrFlag == CFR_CARR_INVALID)
                    cpgOriginCoefPara->atOriginCoefPara[difChan].uiCarrId[carrLoop] = pCfrDifChnInfo->carrInfo[bandLoop][carrLoop].carrNo;
                    cpgOriginCoefPara->atOriginCoefPara[difChan].uiCarrBw[carrLoop] = pCfrDifChnInfo->carrInfo[bandLoop][carrLoop].carrBw;
                    cpgOriginCoefPara->atOriginCoefPara[difChan].uiCarrRadio[carrLoop] = pCfrDifChnInfo->carrInfo[bandLoop][carrLoop].carrRadio;
                    carrCnt++;
                }
            }
            cpgOriginCoefPara->atOriginCoefPara[difChan].uiCarrNum = carrCnt;
        }
        BspLog(LOG_LEVEL_0, "%s, cpgMode=%d, bspChan=%d difChan=%d carrCnt=%d \n", __FUNCTION__, cpgMode, bspChan, difChan, carrCnt);
    }
    if(BspHalAdaptGetCfrCpgRamAlarm(cpgOriginCoefPara, &alarmFlag) == BSP_OK)
    {
        retVal = (alarmFlag == 0) ? NOT_EXCEED_CPG_RAM : EXCEED_CPG_RAM;
    }
    else
    {
        BspLog(LOG_LEVEL_0, "%s, failed to get cfr cpg ram alarm status! \n", __FUNCTION__);
    }
    free(cpgOriginCoefPara);

    return retVal;
}

VOID BspCheckCpgCarrNumValid(VOID)
{
    UINT32 retVal = NOT_EXCEED_CPG_RAM;

    retVal = GetCpgCarrExcessStatus();
    if(retVal == NOT_EXCEED_CPG_RAM)
    {
        ClrAllExcessCpgCarrInfo();
    }
    else if(retVal == FAIL_TO_GET_CPG_RAM_STATUS)
    {
        BspLog(LOG_LEVEL_0, "%s, retVal is FAIL_TO_GET_CPG_RAM_STATUS! \n", __FUNCTION__);
    }
}
/* Started by AICoder, pid:14ccay865bf114d141600979c0654f33d168f151 */
/**
 * 函数名称: UploadExcessCarrInfo
 * 功能描述: 将pCpgCarrInfoInBsp中的参数按对应结构体字段填入pCpgCarrInfoForApp
 * 输入参数: pCpgCarrInfoForApp - 指向T_CpgAllCarrInfo类型的指针，用于存放转换后的载波信息
 *          pCpgCarrInfoInBsp - 指向T_AllChnCpgCarrInfo类型的指针，包含需要转换的载波信息
 * 输出参数: 无
 * 返回值: BSP_OK - 操作成功
 *        其他 - 操作失败
*/
static UINT32 UploadExcessCarrInfo(T_CpgAllCarrInfo *pCpgCarrInfoForApp, T_AllChnCpgCarrInfo *pCpgCarrInfoInBsp)
{
    UINT32 bspChan = 0;
    UINT32 carrInfoLoop = 0;
    UINT32 chnCarrNum = 0;
    UINT32 totalCarrCount = 0;
    UINT32 maxChanNum = BspGetTxChannel();

    INPUT_POINTER_CHECK(pCpgCarrInfoForApp);
    INPUT_POINTER_CHECK(pCpgCarrInfoInBsp);

    maxChanNum = maxChanNum < IC42_MAX_CHAN_NUM ? maxChanNum : IC42_MAX_CHAN_NUM;
    for (bspChan = 0; bspChan < maxChanNum; ++bspChan)
    {
        chnCarrNum = pCpgCarrInfoInBsp->carrNum[bspChan];
        chnCarrNum = chnCarrNum < MAX_EXCEED_CPG_RAM_CARR_NUM ? chnCarrNum : MAX_EXCEED_CPG_RAM_CARR_NUM;
        for (carrInfoLoop = 0; carrInfoLoop < chnCarrNum; ++carrInfoLoop)
        {
            pCpgCarrInfoForApp->t_cpgCarrInfo[totalCarrCount % MAX_EXCEED_CPG_RAM_CARR_NUM].bspChan = bspChan;
            pCpgCarrInfoForApp->t_cpgCarrInfo[totalCarrCount % MAX_EXCEED_CPG_RAM_CARR_NUM].radioMode = pCpgCarrInfoInBsp->chnCpgCarrInfo[bspChan][carrInfoLoop].radioMode;
            pCpgCarrInfoForApp->t_cpgCarrInfo[totalCarrCount % MAX_EXCEED_CPG_RAM_CARR_NUM].carrId = pCpgCarrInfoInBsp->chnCpgCarrInfo[bspChan][carrInfoLoop].carrIndex;
            totalCarrCount++;
            if (totalCarrCount >= MAX_EXCEED_CPG_RAM_CARR_NUM)
            {
                break;
            }
        }
        if (totalCarrCount >= MAX_EXCEED_CPG_RAM_CARR_NUM)
        {
            break;
        }
    }
    pCpgCarrInfoForApp->carrNum = totalCarrCount;

    return BSP_OK;
}
/* Ended by AICoder, pid:14ccay865bf114d141600979c0654f33d168f151 */

/* Started by AICoder, pid:hd37ci9472y4d28148980bf980579f25640590e4 */
/**
 * 函数名称: BspGetCpgRamFlag
 * 功能描述: 获取CPG RAM标志
 * 输入参数: 无
 * 输出参数: pCpgCarrInfoForApp - 指向载波信息结构体的指针
 * 返 回 值: BSP_OK - 获取超配载波信息 成功
 *          BSP_ERROR - 获取超配载波信息 失败
*/
UINT32 BspGetCpgRamFlag(T_CpgAllCarrInfo *pCpgCarrInfoForApp)
{
    T_AllChnCpgCarrInfo *pCpgCarrInfoInBsp = GetExcessCpgCarrInfo();
    UINT32 ret = BSP_ERROR;

    if(pCpgCarrInfoForApp == NULL)
    {
        return BSP_ERROR;
    }
    if(pCpgCarrInfoInBsp != NULL)
    {
        if (pCpgCarrInfoInBsp->totalCarrNum == 0)
        {
            pCpgCarrInfoForApp->carrNum = 0;
            ret = BSP_OK;
        }
        else
        {
            if(UploadExcessCarrInfo(pCpgCarrInfoForApp, pCpgCarrInfoInBsp) == BSP_OK)
            {
                ret = BSP_OK;
            }
        }
    }
    return ret;
}
/* Ended by AICoder, pid:hd37ci9472y4d28148980bf980579f25640590e4 */

/* Started by AICoder, pid:e8990ecc0bnb3e41429b0b0290a62a86a8d80ddc */
/*获取Dss流程中载波的有效标志*/
UINT32 BspGetCfrDssCarrFlag(UINT32 bspChan, UINT32 carr, UINT32 radio, UINT32 *flag)
{
    UINT32 retVal    = BSP_OK;
    UINT32 difChn    = 0;
    UINT32 carrNo    = 0;
    UINT32 carrRadio = 0;
    UINT32 chipidx   = 0;
    UINT32 bandLoop  = 0;
    UINT32 carrLoop  = 0;
    UINT32 carrFlag  = 0;
    T_CfrChnBandInfo *pChnInfo = NULL;

    INPUT_POINTER_CHECK(flag);
    retVal = BspGetDifInfoByBspChn(bspChan, TX, &chipidx, &difChn);
    pChnInfo = BspGetCfrChnInfo(difChn);
    if (pChnInfo == NULL)
    {
        dbgInfoEx("[%s]Get Cfr Dif Chn[%d] Info Error \n", __FUNCTION__, difChn);
        return BSP_ERROR;
    }
    dbgInfoEx("[%s] input: bspChan'%d, carr'%d, radio'0x%x\n", __FUNCTION__, bspChan, carr, radio);

    for (bandLoop = 0; bandLoop < E_CFR_BAND_MAX; bandLoop ++)
    {
        if (pChnInfo->usedFlag[bandLoop] == CFR_BAND_NOT_USED)
        {
            continue;
        }

        for (carrLoop = 0; carrLoop < pChnInfo->bandCarrNum[bandLoop]; carrLoop++)
        {
            carrNo    = pChnInfo->carrInfo[bandLoop][carrLoop % BSP_MAX_CARR_NUM].carrNo;
            carrRadio = pChnInfo->carrInfo[bandLoop][carrLoop % BSP_MAX_CARR_NUM].carrRadio;
            carrFlag  = pChnInfo->carrInfo[bandLoop][carrLoop % BSP_MAX_CARR_NUM].carrFlag;
            dbgInfoEx("[%s] band'%d, bandCarrNum'%d, loop'%d, carrNo'%d, carrRadio'0x%x, carrFlag'%d\n",
                    __FUNCTION__, bandLoop, pChnInfo->bandCarrNum[bandLoop], carrLoop, carrNo, carrRadio, carrFlag);

            if ((carrNo == carr) && (carrRadio == radio))
            {
                *flag = carrFlag;
                break;
            }
        }

        if (carrLoop == pChnInfo->bandCarrNum[bandLoop])
        {
            dbgErr("[%s] error, not find carr: bspChan'%u, carr'%u, radio'0x%x\n", __FUNCTION__, bspChan, carr, radio);
            return BSP_ERROR;
        }
    }
    dbgInfoEx("[%s] retVal'%d, flag'%d\n", __FUNCTION__, retVal, *flag);

    return retVal;
}
/* Ended by AICoder, pid:e8990ecc0bnb3e41429b0b0290a62a86a8d80ddc */

/* Started by AICoder, pid:72f06xaf98k012e14e61096380ab3e3f669645dd */
/**
 * 函数名称: showexcesscpgcarrinfo
 * 功能描述: 维测接口，打印带宽超配信息
 * 输入参数: 无
 * 输出参数: 无
 * 返回值: BSP_OK - 执行成功
 *        其他 - 执行失败
*/
UINT32 showexcesscpgcarrinfo(VOID)
{
    UINT32 bspChan = 0;
    UINT32 carrNum = 0;
    UINT32 carrLoop = 0;
    T_AllChnCpgCarrInfo* pAllChnCpgCarrInfo = GetExcessCpgCarrInfo();

    INPUT_POINTER_CHECK(pAllChnCpgCarrInfo);

    dbgInfo("total excess CarrNum: %u\n", pAllChnCpgCarrInfo->totalCarrNum);
    for (bspChan = 0; bspChan < IC42_MAX_CHAN_NUM; ++bspChan)
    {
        carrNum = pAllChnCpgCarrInfo->carrNum[bspChan];
        if(carrNum == 0)
        {
            continue;
        }
        dbgInfo("bspChan=%d, excess carr num= %d\n", bspChan, carrNum);
        for (carrLoop = 0; carrLoop < carrNum; ++carrLoop)
        {
            dbgInfo("radioMode=%d, carrIndex=%d \n",
            pAllChnCpgCarrInfo->chnCpgCarrInfo[bspChan][carrLoop].radioMode,
            pAllChnCpgCarrInfo->chnCpgCarrInfo[bspChan][carrLoop].carrIndex);
        }
    }

    return BSP_OK;
}
/* Ended by AICoder, pid:72f06xaf98k012e14e61096380ab3e3f669645dd */

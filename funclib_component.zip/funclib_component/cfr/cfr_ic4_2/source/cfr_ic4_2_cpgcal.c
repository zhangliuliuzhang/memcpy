/*****************************************************************************
* 版权所有(C) 2021,  ZTE Corp. ZXSDR-RRU Platform BSP
*----------------------------------------------------------------------------
* 模 块 名 : CFR
* 文件名称 : cfr_ic4_2_cpgcal.c
* 文件标识 : {[N/A]}
* 内容摘要 : 本文件主要提供DPDIC4.2中CFR模块的功能实现,主要实现的是CPG计算模式
* 注意事项 : 无
* 作    者 : 徐利波10307448
* 创建日期 : 2022-02-17
* 当前版本 : Ver1.0
*----------------------------------------------------------------------------
* 变更记录 :
*
* $记录1
* 变 更 单: $0000000(N/A)
* 责 任 人: 徐利波10307448
* 修改日戳: 2022-02-17
* 变更说明: 创建文件
*----------------------------------------------------------------------------
*/


#include <math.h>
#include "bspcomm.h"
#include "bsppub.h"
#include "cfr_ic4_2_cpgcal.h"
#include "freqcfgcommon.h"
#include "funccommon_chncfg.h"
#include "cfr_ic4_2.h"
#include "cfrcommon.h"
#include "ichaladaptbspapi.h"
//#include "ichaladapt_ic4_2.h"
#include "ichaladapt_cfr_ic4_2.h"
#include "cfr_ic4_2_coefdata.h"
#include "freqcfg_ic4_2.h"
#include "funccommon.h"

/**************************************************************************
*                         全局变量定义                                   *
**************************************************************************/
#if 0
static T_DSS_CARRCHNINFO s_tDssCarrInfo[BSP_IC4_DIF_CHAN_NUM] = {0};
static T_CfrFactor *s_pCfrFactor = NULL;
static UINT32       s_pCfrFactorLen = 0;
#endif
static T_IcCfrCpgCpuCalData *s_cfrCpgCpuCalData = NULL;

/**************************************************************************
 *                        宏定义
 **************************************************************************/
#define CFR_NO_POWER_VAL       -13700
#define ROUND(a)               ((INT32)(((a) < 0) ? ((a) - 0.5) : ((a) + 0.5)))

#define  THR_SEL        ((UINT32)(1))
#define  DELAY_EQUAL    ((UINT32)(1))
#define  VALID_LEN_MAX  ((UINT32)(512))
#define  VALID_LEN      ((UINT32)(509))
/**************************************************************************
*                         数据类型                                       *
**************************************************************************/

/**************************************************************************
 *                         函数实现
 **************************************************************************/
/*** CPG系数内存申请 ***/
UINT32 BspCfrCpgDataMemApply(VOID)
{
    UINT32 retVal = BSP_OK;
    UINT32 difChnNum    = 0;
	UINT32 chnLoop      = 0;
	UINT32 bandLoop     = 0;

    difChnNum   = BspGetCfrDifChnNum();

    if(s_cfrCpgCpuCalData == NULL)
    {
    	s_cfrCpgCpuCalData = (T_IcCfrCpgCpuCalData *)malloc(sizeof(T_IcCfrCpgCpuCalData) * difChnNum);
        if(s_cfrCpgCpuCalData == NULL)
        {
            return BSP_ERROR;
        }
		memset(s_cfrCpgCpuCalData,0,(sizeof(T_IcCfrCpgCpuCalData) * difChnNum));
		for(chnLoop = 0;chnLoop < difChnNum;chnLoop ++)
	    {
	    	for(bandLoop = 0;bandLoop < E_CFR_BAND_MAX ;bandLoop ++)
	        {
	    		s_cfrCpgCpuCalData[chnLoop].cfrBand[bandLoop].pCpgImag = NULL;
	    		s_cfrCpgCpuCalData[chnLoop].cfrBand[bandLoop].pCpgReal = NULL;
	    		s_cfrCpgCpuCalData[chnLoop].cfrBand[bandLoop].cpgLen   = 0;
			}

		}
    }

    return retVal;
}

/*cfr CPG数据存储*/
UINT32 BspCfrCpgSaveTxtDpdic4_2(UINT32 difChn, UINT32 cfrband, DOUBLE *pDataReal, DOUBLE *pDataImg, UINT32 dataLen)
{
    FILE *fin  = NULL;
    FILE *fout = NULL;
	UINT32 dataLoop = 0;
    INT32 coef = 0;
	CHAR acFileName[128] = {0};
    CHAR acFileNameR[128] = {0};
    CHAR acFileNameI[128] = {0};
    INT32 sReal = 0;
    INT32 sImag = 0;
    INT32 cnt = 0;
    INT32 ret = 0;
    
    ret = snprintf_s(acFileName, 128, "dpd3Cfr[%d][%d]_Coef.txt", difChn, cfrband);
    SNPRINTF_S_CHECK(ret, sizeof(acFileName));

    fout = fopen(acFileName,"w+");

    if (NULL == fout)
    {
        return BSP_ERROR;
    }

    for (dataLoop = 0; dataLoop < dataLen; dataLoop ++)
    {
    	coef  = (((INT32)ROUND(pDataReal[dataLoop])&0x1FFF)<<13)|((INT32)ROUND(pDataImg[dataLoop])&0x1FFF);

        ret = fprintf(fout, "%d\n", coef);
        FPRINTF_CHECK(ret);
    }
    ret = fclose(fout);
    FCLOSE_CHECK(ret);

    ret = snprintf_s(acFileNameR, 128, "dpd42Cfr[%d][%d]_RealCoef.txt", difChn, cfrband);
    SNPRINTF_S_CHECK(ret, 128);
    ret = snprintf_s(acFileNameI, 128, "dpd42Cfr[%d][%d]_ImagCoef.txt", difChn, cfrband);
    SNPRINTF_S_CHECK(ret, 128);

	fin  = fopen(acFileNameR,"w+");

	if ((NULL == fin))
	{
	   return BSP_ERROR;
	}

	fout = fopen(acFileNameI,"w+");

	if (NULL == fout)
	{
	   ret = fclose(fin);
       FCLOSE_CHECK(ret);
	   return BSP_ERROR;
	}
	cnt = -1;
	for (dataLoop = 0; dataLoop < dataLen; dataLoop ++)
	{
	   sReal  = (INT32)ROUND(pDataReal[dataLoop]);
	   sImag  = cnt*(INT32)ROUND(pDataImg[dataLoop]);
	   ret = fprintf(fin, "%d\n", sReal);
       FPRINTF_CHECK(ret);
	   ret = fprintf(fout, "%d\n", sImag);
       FPRINTF_CHECK(ret);
	}

	ret = fclose(fout);
    FCLOSE_CHECK(ret);
	ret = fclose(fin);
    FCLOSE_CHECK(ret);
	return BSP_OK;
}

/*****************************************************************************
*  函数名称   : BspCfrDataSave_CpuCal
*  功能描述   : cpg 系数保存
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : difChan - 中频通道
*  输出参数   : 无
*  返 回 值   : BSP_OK  - 成功;其它值为失败
*  其它说明   :
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2015-11-28 14:55:24
*----------------------------------------------------------------------------
*/
UINT32 BspCfrDataSave_CpuCal(UINT32 difChn, UINT32 band, DOUBLE *pCpgReal, DOUBLE *pCpgImag , UINT32 dataNum, DOUBLE sumBandGK,UINT32 vaildMaxLen)
{
    UINT32 loop = 0;

    INPUT_DIFCHAN_CHECK(difChn);
    INPUT_POINTER_CHECK(pCpgReal);
    INPUT_POINTER_CHECK(pCpgImag);

    if (band >= E_CFR_BAND_MAX)
    {
        dbgInfoEx("[%s]dif %d Band %d Error !Save Cfr Cpg Data Error \n", __FUNCTION__, difChn, band);
        return BSP_ERROR;
    }

    //除数为零判断
    if ((sumBandGK >= (-(DOUBLE)EPSINON)) && (sumBandGK <= (DOUBLE)EPSINON))
    {
        dbgErr("[%s] >> divisor sumBandGK cannot be zero !!\n", __FUNCTION__);
        return BSP_ERROR;
    }

    if (s_cfrCpgCpuCalData[difChn].cfrBand[band].pCpgImag == NULL)
    {
    	s_cfrCpgCpuCalData[difChn].cfrBand[band].pCpgImag = (INT32 *)malloc(sizeof(INT32) * dataNum);

        if (s_cfrCpgCpuCalData[difChn].cfrBand[band].pCpgImag == NULL)
        {
            dbgInfoEx("[%s]dif %d Band %d Cfr Cpg ImagData Malloc Error \n", __FUNCTION__, difChn, band);
            free(s_cfrCpgCpuCalData[difChn].cfrBand[band].pCpgReal);
            return BSP_ERROR;
        }
    }
    memset(s_cfrCpgCpuCalData[difChn].cfrBand[band].pCpgImag,0,sizeof(INT32)*dataNum);
    
    if (s_cfrCpgCpuCalData[difChn].cfrBand[band].pCpgReal == NULL)
    {
    	s_cfrCpgCpuCalData[difChn].cfrBand[band].pCpgReal = (INT32 *)malloc(sizeof(INT32) * dataNum);

        if (s_cfrCpgCpuCalData[difChn].cfrBand[band].pCpgReal == NULL)
        {
            dbgInfoEx("[%s]dif %d Band %d Cfr Cpg RealData Malloc Error \n", __FUNCTION__, difChn, band);
            free(s_cfrCpgCpuCalData[difChn].cfrBand[band].pCpgImag);
            return BSP_ERROR;
        }
    }
    memset(s_cfrCpgCpuCalData[difChn].cfrBand[band].pCpgReal,0,sizeof(INT32)*dataNum);

    if (s_cfrCpgCpuCalData[difChn].cfrBand[band].pCoef == NULL)
	{
		s_cfrCpgCpuCalData[difChn].cfrBand[band].pCoef = (INT32 *)malloc(sizeof(INT32) * dataNum);

		if (s_cfrCpgCpuCalData[difChn].cfrBand[band].pCoef == NULL)
		{
			dbgInfoEx("[%s]dif %d Band %d Cfr Cpg RealData Malloc Error \n", __FUNCTION__, difChn, band);
			free(s_cfrCpgCpuCalData[difChn].cfrBand[band].pCpgImag);
			free(s_cfrCpgCpuCalData[difChn].cfrBand[band].pCpgReal);
			s_cfrCpgCpuCalData[difChn].cfrBand[band].pCpgImag = NULL;
			s_cfrCpgCpuCalData[difChn].cfrBand[band].pCpgReal = NULL;
			return BSP_ERROR;
		}
	}
    memset(s_cfrCpgCpuCalData[difChn].cfrBand[band].pCoef,0,sizeof(INT32)*dataNum);
	
    for (loop = 0; loop < dataNum ; loop ++)
    {
        pCpgReal[loop] = pCpgReal[loop] / sumBandGK;
        pCpgImag[loop] = pCpgImag[loop] / sumBandGK;
        s_cfrCpgCpuCalData[difChn].cfrBand[band].pCpgReal[loop] = (INT32)ROUND(pCpgReal[loop]);
        s_cfrCpgCpuCalData[difChn].cfrBand[band].pCpgImag[loop] = -1*(INT32)ROUND(pCpgImag[loop]);
        s_cfrCpgCpuCalData[difChn].cfrBand[band].pCoef[loop]    =((s_cfrCpgCpuCalData[difChn].cfrBand[band].pCpgReal[loop]&0x1FFF)<<16)|((s_cfrCpgCpuCalData[difChn].cfrBand[band].pCpgImag[loop])&0x1FFF);
        s_cfrCpgCpuCalData[difChn].cfrBand[band].flag           = IC_FLAG_USED;
        dbgInfoEx("[%s]difchn'%d band'%d cpgval'0x%x real'0x%x imag'0x%x \n",__FUNCTION__,difChn,band,s_cfrCpgCpuCalData[difChn].cfrBand[band].pCoef[loop],s_cfrCpgCpuCalData[difChn].cfrBand[band].pCpgReal[loop],s_cfrCpgCpuCalData[difChn].cfrBand[band].pCpgImag[loop]);
    }

    BspCfrCpgSaveTxtDpdic4_2(difChn,band,pCpgReal, pCpgImag, dataNum);
    s_cfrCpgCpuCalData[difChn].cfrBand[band].cpgLen = dataNum;
    s_cfrCpgCpuCalData[difChn].cfrBand[band].cpgVaildLen  = vaildMaxLen;
    return BSP_OK;
}

/*****************************************************************************
*  函数名称   :BspCfrSetBandNum
*  功能描述   :设置频段数
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : difChan - 中频通道
*  输出参数   : 无
*  返 回 值   : BSP_OK  - 成功;其它值为失败
*  其它说明   :
*            :
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2015-11-28 14:55:24
*----------------------------------------------------------------------------
*/
UINT32 BspCfrSetBandNum(UINT32 difChn,UINT32 cfrBandNum)
{
	INPUT_DIFCHAN_CHECK(difChn);

	s_cfrCpgCpuCalData[difChn].cfrBandNum = cfrBandNum;

	return BSP_OK;
}

/*****************************************************************************
*  函数名称   : BspCfrCpgGetWei
*  功能描述   : 根据制式获取削峰CPG系数计算过程中的wei值
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : cfrFs - CPG速率
               carrRadio - 载波制式
*  输出参数   : wei - wei参数
*  返 回 值   : BSP_OK  - 成功;其它值为失败
*  其它说明   : wei用于调整载波evm均衡
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 10307448徐利波@2022-03-22 11:13:12
*----------------------------------------------------------------------------
*/
UINT32 BspCfrCpgGetWei(UINT32 cfrFs, UINT32 carrRadio, DOUBLE *wei)
{
    UINT32 retVal = BSP_OK;
    DOUBLE weiFactor = 0.0;
    T_CfrWeiFactor cfrWeiFactor = {0};

    retVal = BspGetWeiCfrFactor_IC4_2(cfrFs, &cfrWeiFactor);

    switch (carrRadio)
    {
        case BSP_RADIO_STANDARD_GSM:
            weiFactor = cfrWeiFactor.wei_gsm;
            break;
        case BSP_RADIO_STANDARD_UMTS:
            weiFactor = cfrWeiFactor.wei_umts;
            break;
        case BSP_RADIO_STANDARD_LTE_FDD:
            weiFactor = cfrWeiFactor.wei_lte_fdd;
            break;
        case BSP_RADIO_STANDARD_LTE_TDD:
            weiFactor = cfrWeiFactor.wei_lte_tdd;
            break;
        case BSP_RADIO_STANDARD_5G:
            weiFactor = cfrWeiFactor.wei_nr;
            break;
        case BSP_RADIO_STANDARD_5G_RESERVED:
            weiFactor = cfrWeiFactor.wei_nr;
            break;
        case BSP_RADIO_STANDARD_NB_IOT:
            weiFactor = cfrWeiFactor.wei_nb_lot;
            break;
        default:
            weiFactor = cfrWeiFactor.wei_nr;
            break;
    }
    *wei = weiFactor;

    dbgInfoEx("[%s] wei:%f, carrRadio:0x%x,  cfrFs:%d \n", __FUNCTION__, weiFactor, carrRadio, cfrFs);

    return retVal;
}

/*****************************************************************************
*  函数名称   : BspCfrCpgGetGiTempMax
*  功能描述   : 获取削峰CPG系数计算过程中的giTemp最大值
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : difChan - 中频通道; umtsBw - 单边滤波后UMTS带宽; *pChnInfo - 通道射频信息
*  输出参数   : giTempMax - giTemp最大值
*  返 回 值   : BSP_OK  - 成功;其它值为失败
*  其它说明   :无
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 10307448徐利波@2022-03-22 11:13:12
*----------------------------------------------------------------------------
*/
UINT32 BspCfrCpgGetGiTempMax(UINT32 difChn, UINT32 umtsBw, T_CfrChnBandInfo *pChnInfo, DOUBLE *giTempMax)
{
    UINT32 ret           = BSP_OK;
    UINT32 bandLoop      = 0;
    UINT32 carrLoop      = 0;
    UINT32 cnt           = 0;
    UINT32 carrRadio     = 0;
    UINT32 carrBw        = 0;
    UINT32 cfrBw         = 0;
    UINT32 cfrFs         = 0;
    UINT32 originCoefLen = 0;
    DOUBLE wei           = 0.0;
    DOUBLE giTemp        = 0.0;
    DOUBLE giMax         = 1e-10;
    DOUBLE ciSq          = 0.0;
    DOUBLE pci           = 0.0;
    T_CfrCpgPara cfrCpgPara = {0};

    INPUT_DIFCHAN_CHECK(difChn);
	INPUT_POINTER_CHECK(giTempMax);

    ret = BspGetCfrFsByDifChn(difChn,&cfrFs);
    dbgInfoEx("[%s] difChn'%u, umtsBw'%u, cfrFs'%u \n", __FUNCTION__, difChn, umtsBw, cfrFs);

    for (bandLoop = 0; bandLoop < E_CFR_BAND_MAX; bandLoop ++)
    {
        if (pChnInfo->usedFlag[bandLoop] == CFR_BAND_NOT_USED)
        {
            continue;
        }

        for (carrLoop = 0; carrLoop < pChnInfo->bandCarrNum[bandLoop]; carrLoop++)
        {
            if (pChnInfo->carrInfo[bandLoop][carrLoop].carrFlag == CFR_CARR_INVALID)
            {
                continue;
            }

            carrBw      = pChnInfo->carrInfo[bandLoop][carrLoop].carrBw;
            carrRadio   = pChnInfo->carrInfo[bandLoop][carrLoop].carrRadio;

            ret = BspGetCfrRadioBwFromBspBw(carrRadio, carrBw, &cfrBw);
            if ((BSP_RADIO_STANDARD_UMTS == carrRadio) && (0 != umtsBw))
            {
                ret |= BspGetCfrRadioBwFromBspBw(carrRadio, umtsBw, &cfrBw);
            }

            ret |= BspCfrCpgGetWei(cfrFs, carrRadio, &wei);
            ret |= BspGetCfrCpgCoef_IC4_2(difChn,cfrBw,cfrFs, &cfrCpgPara);
            if (ret != BSP_OK)
            {
                continue;
            }

            originCoefLen = cfrCpgPara.coefLen;

            ciSq = 0;

            for (cnt = 0; cnt < (originCoefLen - 1); cnt++)
            {
                ciSq += pow(cfrCpgPara.pCoefPara[cnt], 2);
            }

            pci = 2 * ciSq + pow(cfrCpgPara.pCoefPara[originCoefLen - 1], 2);
            giTemp = wei / sqrt(pci);

            if (giTemp >= giMax)
            {
                giMax = giTemp;
            }
            dbgInfoEx("[%s] carrLoop'%u, carrRadio'0x%x, carrBw'%u, cfrBw'%u, pci'%f, wei'%f, giTemp'%f, giMax'%f,  \n", __FUNCTION__,
                    carrLoop, carrRadio, carrBw, cfrBw, pci, wei, giTemp, giMax);
        }
    }

    *giTempMax = giMax;

    return ret;
}

/*****************************************************************************
*  函数名称   : BspCfrSetHwCpgCfg
*  功能描述   : 配置削峰硬件计算CPG系数所需参数
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : difChn - 中频通道
*  输出参数   : 无
*  返 回 值   : BSP_OK  - 成功;其它值为失败
*  其它说明   : 无
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 10307448徐利波@2022-05-01 10:09:07
*----------------------------------------------------------------------------
*/
UINT32 BspCfrSetHwCpgCfg(UINT32 difChn)
{
    UINT32 ret            = BSP_OK;
    UINT32 retValOfSetCfrCoef = BSP_OK;
    UINT32 bandLoop       = 0;
    UINT32 carrLoop       = 0;
    UINT32 cnt            = 0;
    UINT32 carrBw         = 0;
    UINT32 cfrBw          = 0;
    UINT32 cfrFs          = 0;
    UINT32 carrPowMw      = 0;
    UINT32 carrNo         = 0;
    UINT32 hwChnMask      = 0;
    UINT32 originCoefLen  = 0;
    UINT32 originValidLen = 0;
    UINT32 carrRadio      = 0;
    UINT32 staPowStepFreq = 0;
    UINT32 deltPowFreq    = 0;
    UINT32 ratedPower     = 0;
    UINT32 symNum         = 0;
    UINT32 uiFreqWord     = 0;
    INT32 freqWord        = 0;
    INT32 fi              = 0;
    DOUBLE wei            = 0.0;
    DOUBLE giTemp         = 0.0;
    DOUBLE giTempMax      = 1.0;
    DOUBLE gi             = 0.0;
    DOUBLE ciSq           = 0.0;
    DOUBLE pci            = 0.0;
    UINT32 chnChgFlag     = CFR_CHN_NO_CHANGE;
    T_CfrChnBandInfo *pCfrDifChnInfo = NULL;
    T_CfrCpgPara cfrCpgPara = {0};
    T_BspHalAdaptCfrParaHardCpg cfrHWCpgPara = {0};
    T_BspHalAdaptDifCommCfrPara cfrCommPara = {0};

    ret |= BspGetDifChnHwMask(&hwChnMask);
    ret |= BspGetCfrFsByDifChn(difChn,&cfrFs);
    ret |= BspGetCfrKiCommPara(&cfrHWCpgPara);
    ret |= BspGetCfrCommPara(&cfrCommPara);
    ret |= BspGetRruPathRatedPower(difChn, &ratedPower); 

    if (CFR_CHN_CHANGE == GET_BIT(hwChnMask, difChn))
    {
        chnChgFlag = CFR_CHN_CHANGE;
    }

    dbgInfoEx("[%s] chn'%u, cfrFs:%u, chgFlag'%u, ratedPower:%u \n", __FUNCTION__, difChn, cfrFs, chnChgFlag, ratedPower);

    pCfrDifChnInfo = BspGetCfrChnInfo(difChn);
    if (pCfrDifChnInfo == NULL)
    {
        dbgInfoEx("[%s]Get Cfr Dif Chn[%d] Info Error \n", __FUNCTION__, difChn);
        BspLog(LOG_LEVEL_0,"[%s] Get Cfr Chn[%d] Rf Para Error! \n", __FUNCTION__,difChn);
        return BSP_ERROR;
    }

    ret |= BspCfrCpgGetGiTempMax(difChn, 0, pCfrDifChnInfo, &giTempMax);  /*非单边滤波削峰，滤波后带宽写0即可*/

    BspCheckCpgCarrNumValid();

    for (bandLoop = 0; bandLoop < E_CFR_BAND_MAX; bandLoop ++)
    {
        if (pCfrDifChnInfo->usedFlag[bandLoop] == CFR_BAND_NOT_USED)
        {
            continue;
        }

        if (chnChgFlag == CFR_CHN_CHANGE)
        {
            ret |= BspHalAdaptCfrCleanGi(difChn, bandLoop);
            ret |= BspHalAdaptCfrSetDlpreKiIndexDvSel(difChn, bandLoop);
            ret |= BspHalAdaptCfrSetCpgUpdateMode(difChn, bandLoop);
            ret |= BspHalAdaptCfrClrOriginCoefCarrInfo(difChn, bandLoop);

            if (cfrCommPara.uiThrSel[difChn] == 1)
            {
                symNum = cfrHWCpgPara.uiSymNum0[difChn];
            }
            else
            {
                symNum = cfrHWCpgPara.uiSymNum1[difChn];
            }

            ret |= BspHalAdaptCfrSetDlpreKiIndexNum(difChn, bandLoop, symNum);
        }

        ret |= BspHalAdaptCfrCleanWord(difChn, bandLoop);
        
        for (carrLoop = 0; carrLoop < pCfrDifChnInfo->bandCarrNum[bandLoop]; carrLoop++)
        {
            if (pCfrDifChnInfo->carrInfo[bandLoop][carrLoop].carrFlag == CFR_CARR_INVALID)
            {
                continue;
            }

            fi = pCfrDifChnInfo->carrInfo[bandLoop][carrLoop].carrFi;
            carrNo = pCfrDifChnInfo->carrInfo[bandLoop][carrLoop].carrNo;
            carrBw = pCfrDifChnInfo->carrInfo[bandLoop][carrLoop].carrBw;
            carrPowMw = pCfrDifChnInfo->carrInfo[bandLoop][carrLoop].powerMw;
            carrRadio = pCfrDifChnInfo->carrInfo[bandLoop][carrLoop].carrRadio;

            ret |= BspUpdateCarrBwByFilterCpg(difChn, carrNo, carrRadio, &fi, &carrBw);
            ret |= BspCfrCpgGetWei(cfrFs, carrRadio, &wei);
            ret |= BspGetCfrRadioBwFromBspBw(carrRadio, carrBw, &cfrBw);

            deltPowFreq = 31;
            if (carrRadio == RADIO_STANDARD_GSM)
            {
                if (carrPowMw > 0)
                {
                    deltPowFreq = (UINT32)round(10 * log10(ratedPower/carrPowMw));
                }
                
                ret |= BspHalAdaptGetGsmPowLevel(difChn, carrNo, carrRadio, &staPowStepFreq);
            }

            ret |= BspGetCfrCpgCoef_IC4_2(difChn,cfrBw,cfrFs, &cfrCpgPara);
            CONTINUE_IF_EXP((ret != BSP_OK));
            CONTINUE_IF_EXP((retValOfSetCfrCoef != BSP_OK) && (retValOfSetCfrCoef != BSP_INVALID_VALUE));
            if (NULL == cfrCpgPara.pCoefPara)
            {
                continue;
            }
            
            originCoefLen = cfrCpgPara.coefLen;
            ciSq = 0;
            for (cnt = 0; cnt < (originCoefLen - 1); cnt++)
            {
                ciSq += pow(cfrCpgPara.pCoefPara[cnt], 2);
            }
      
            pci = 2 * ciSq + pow(cfrCpgPara.pCoefPara[originCoefLen - 1], 2);
            giTemp = (DOUBLE)(wei / sqrt(pci));
            ret |= BspCfrGetCarrGi(difChn, carrNo, carrRadio, giTemp, giTempMax, &gi);
            if (BSP_OK != ret)
            {
                return BSP_ERROR;
            }

            if(cfrCommPara.uiDelayEqualFlag[difChn] == 1)//如果是等时延
            {
                if (cfrCpgPara.vaildLen < 512)
                {
                    originValidLen = 509;
                }
                else
                {
                    originValidLen = cfrCommPara.uiCpgCoefLenHalfMax[difChn];
                }
            }
            else
            {
                originValidLen = cfrCpgPara.vaildLen;
            }
            
            if (chnChgFlag == CFR_CHN_CHANGE)
            {
                ret |= BspHalAdaptCfrSetGi(difChn, bandLoop, carrNo, carrRadio, (UINT32)gi);
                retValOfSetCfrCoef = BspSetDssCfrOriginCoefAndRecordExcessCarr(difChn, carrNo, carrRadio, carrBw, originValidLen, &cfrCpgPara.pCoefPara[CPG_COEF_LEN_HALF_MAX_768 - originValidLen]);
                ret |= BspHalAdaptSetDlpreKiIndexGsm(difChn, carrNo, carrRadio, staPowStepFreq, deltPowFreq);
                ret |= BspHalAdaptCfrSetcfgFlag(difChn, bandLoop);
            }

            DIV_CHK_PRN_RET(cfrFs)
            freqWord = round(((DOUBLE)fi / cfrFs) * pow(2, 32));

            uiFreqWord = (UINT32)((freqWord < 0) ? (freqWord + pow(2,32)) : freqWord);

            dbgInfoEx("[%s] giTemp:%f, pci:%f, freqWord:0x%x, cfrBw'%u \n", __FUNCTION__, giTemp, pci, freqWord, cfrBw);
            dbgInfoEx("[%s] difChn'%u, carrIndex'%u, carrRadio'0x%x, carrPowMw'%u, carrBw'%u, carrFi:%d, wei:%f, gi:%f, uiFreqWord:%u\n",
                        __FUNCTION__, difChn, carrNo, carrRadio, carrPowMw, carrBw, fi, wei, gi, uiFreqWord);

            ret |= BspHalAdaptCfrSetWord(difChn, bandLoop, carrNo, carrRadio, uiFreqWord);
        }
    }

    return ret;
}

/*****************************************************************************
*  函数名称   : BspCfrSetUmtsCpgPara_HwCal
*  功能描述   : 设置U单边滤波后在线计算CPG系数所需参数
*  输入参数   : difChn - 中频通道, umtsBw - 单边滤波后UMTS带宽
*  输出参数   : 无
*  返 回 值   : BSP_OK  - 成功;其它值为失败
*  其它说明   : 与非单边滤波的削峰相比，波及以下两点：
               (1)需用高层传递的单边滤波后的U带宽匹配原型系数;
               (2)载波NCO计算：fi=原链路载波NCO-NCO1。
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 10307448徐利波@2022-12-13 22:13:11
*----------------------------------------------------------------------------
*/
UINT32 BspCfrSetUmtsCpgPara_HwCal(UINT32 difChn, UINT32 ulcarrNo, UINT32 umtsBw)
{
    UINT32 ret            = BSP_OK;
    UINT32 retValOfSetCfrCoef = BSP_OK;
    UINT32 bandLoop       = 0;
    UINT32 carrLoop       = 0;
    UINT32 cnt            = 0;
    UINT32 carrBw         = 0;
    UINT32 cpgCoefBw      = 0;
    UINT32 cfrBw          = 0;
    UINT32 cfrFs          = 0;
    UINT32 carrPowMw      = 0;
    UINT32 carrNo         = 0;
    UINT32 hwChnMask      = 0;
    UINT32 originCoefLen  = 0;
    UINT32 originValidLen = 0;
    UINT32 carrRadio      = 0;
    UINT32 staPowStepFreq = 0;
    UINT32 deltPowFreq    = 0;
    UINT32 ratedPower     = 0;
    UINT32 symNum         = 0;
    UINT32 uiFreqWord     = 0;
    INT32 freqWord        = 0;
    INT32 fi              = 0;
    DOUBLE wei            = 0.0;
    DOUBLE giTemp         = 0.0;
    DOUBLE giTempMax      = 1.0;
    DOUBLE gi             = 0.0;
    DOUBLE ciSq           = 0.0;
    DOUBLE pci            = 0.0;
    INT32 filterFi        = 0;
    UINT32 chnChgFlag     = CFR_CHN_NO_CHANGE;
    T_CfrChnBandInfo *pCfrDifChnInfo = NULL;
    T_CfrCpgPara cfrCpgPara = {0};
    T_BspHalAdaptCfrParaHardCpg cfrHWCpgPara = {0};
    T_BspHalAdaptDifCommCfrPara cfrCommPara = {0};

    ret |= BspGetDifChnHwMask(&hwChnMask);
    ret |= BspGetCfrFsByDifChn(difChn,&cfrFs);
    ret |= BspGetCfrKiCommPara(&cfrHWCpgPara);
    ret |= BspGetCfrCommPara(&cfrCommPara);
    ret |= BspGetRruPathRatedPower(difChn, &ratedPower); 

    chnChgFlag = GET_BIT(hwChnMask, difChn);
    dbgInfoEx("[%s] chn'%u, cfrFs:%u, chgFlag'%u, ratedPower:%u \n", __FUNCTION__, difChn, cfrFs, chnChgFlag, ratedPower);

    pCfrDifChnInfo = BspGetCfrChnInfo(difChn);
    if (pCfrDifChnInfo == NULL)
    {
        dbgInfoEx("[%s]Get Cfr Dif Chn[%d] Info Error \n", __FUNCTION__, difChn);
        BspLog(LOG_LEVEL_0,"[%s] Get Cfr Chn[%d] Rf Para Error! \n", __FUNCTION__,difChn);
        return BSP_ERROR;
    }

    ret |= BspCfrCpgGetGiTempMax(difChn, umtsBw, pCfrDifChnInfo, &giTempMax);

    BspCheckCpgCarrNumValid();

    for (bandLoop = 0; bandLoop < E_CFR_BAND_MAX; bandLoop ++)
    {
        if (pCfrDifChnInfo->usedFlag[bandLoop] == CFR_BAND_NOT_USED)
        {
            continue;
        }

        if (chnChgFlag == CFR_CHN_CHANGE)
        {
            ret |= BspHalAdaptCfrCleanGi(difChn, bandLoop);
            ret |= BspHalAdaptCfrSetDlpreKiIndexDvSel(difChn, bandLoop);
            ret |= BspHalAdaptCfrSetCpgUpdateMode(difChn, bandLoop);
            ret |= BspHalAdaptCfrClrOriginCoefCarrInfo(difChn, bandLoop);

            if (cfrCommPara.uiThrSel[difChn] == 1)
            {
                symNum = cfrHWCpgPara.uiSymNum0[difChn];
            }
            else
            {
                symNum = cfrHWCpgPara.uiSymNum1[difChn];
            }

            ret |= BspHalAdaptCfrSetDlpreKiIndexNum(difChn, bandLoop, symNum);
        }

        ret |= BspHalAdaptCfrCleanWord(difChn, bandLoop);
        
        for (carrLoop = 0; carrLoop < pCfrDifChnInfo->bandCarrNum[bandLoop]; carrLoop++)
        {
            if (pCfrDifChnInfo->carrInfo[bandLoop][carrLoop].carrFlag == CFR_CARR_INVALID)
            {
                continue;
            }

            fi = pCfrDifChnInfo->carrInfo[bandLoop][carrLoop].carrFi;
            carrNo = pCfrDifChnInfo->carrInfo[bandLoop][carrLoop].carrNo;
            carrBw = pCfrDifChnInfo->carrInfo[bandLoop][carrLoop].carrBw;
            carrPowMw = pCfrDifChnInfo->carrInfo[bandLoop][carrLoop].powerMw;
            carrRadio = pCfrDifChnInfo->carrInfo[bandLoop][carrLoop].carrRadio;
            cpgCoefBw = carrBw;

            if(BSP_OK == BspJudgeCarrIdAndRadio(ulcarrNo, carrNo, carrRadio, BSP_RADIO_STANDARD_UMTS))
            {
                ret |= BspUpdateUsableCpgBw(umtsBw, &cpgCoefBw);
                ret |= BspSetDlFilterCpgBw(difChn, carrNo, BSP_RADIO_STANDARD_UMTS, umtsBw);
                ret |= BspGetCfrFreqFiOffset(difChn, carrNo, carrRadio, &filterFi);
                fi = filterFi;
            }

            ret |= BspCfrCpgGetWei(cfrFs, carrRadio, &wei);
            ret |= BspGetCfrRadioBwFromBspBw(carrRadio, cpgCoefBw, &cfrBw);

            deltPowFreq = 31;
            if (carrRadio == RADIO_STANDARD_GSM)
            {
                if (carrPowMw > 0)
                {
                    deltPowFreq = (UINT32)round(10 * log10(ratedPower/carrPowMw));
                }
                
                ret |= BspHalAdaptGetGsmPowLevel(difChn, carrNo, carrRadio, &staPowStepFreq);
            }
 
            ret |= BspGetCfrCpgCoef_IC4_2(difChn,cfrBw,cfrFs, &cfrCpgPara);
            CONTINUE_IF_EXP((ret != BSP_OK));
            CONTINUE_IF_EXP((retValOfSetCfrCoef != BSP_OK) && (retValOfSetCfrCoef != BSP_INVALID_VALUE));
            if (NULL == cfrCpgPara.pCoefPara)
            {
                continue;
            }

            originCoefLen = cfrCpgPara.coefLen;
            ciSq = 0;
            for (cnt = 0; cnt < (originCoefLen - 1); cnt++)
            {
                ciSq += pow(cfrCpgPara.pCoefPara[cnt], 2);
            }

            pci = (DOUBLE)(2 * ciSq + pow(cfrCpgPara.pCoefPara[originCoefLen - 1], 2));
            giTemp = (DOUBLE)(wei / sqrt(pci));
            ret |= BspCfrGetCarrGi(difChn, carrNo, carrRadio, giTemp, giTempMax, &gi);
            if (BSP_OK != ret)
            {
                return BSP_ERROR;
            }

            if(cfrCommPara.uiDelayEqualFlag[difChn] == 1)//如果是等时延
            {
                if (cfrCpgPara.vaildLen < 512)
                {
                    originValidLen = 509;
                }
                else
                {
                    originValidLen = cfrCommPara.uiCpgCoefLenHalfMax[difChn];
                }
            }
            else
            {
                originValidLen = cfrCpgPara.vaildLen;
            }
            
            if (chnChgFlag == CFR_CHN_CHANGE)
            {
                ret |= BspHalAdaptCfrSetGi(difChn, bandLoop, carrNo, carrRadio, (UINT32)gi);
                retValOfSetCfrCoef = BspSetDssCfrOriginCoefAndRecordExcessCarr(difChn, carrNo, carrRadio, cpgCoefBw, originValidLen, &cfrCpgPara.pCoefPara[CPG_COEF_LEN_HALF_MAX_768 - originValidLen]);
                ret |= BspHalAdaptSetDlpreKiIndexGsm(difChn, carrNo, carrRadio, staPowStepFreq, deltPowFreq);
                ret |= BspHalAdaptCfrSetcfgFlag(difChn, bandLoop);
            }

            DIV_CHK_PRN_RET(cfrFs)
            freqWord = (INT32)round(((DOUBLE)fi / cfrFs) * pow(2, 32));
            uiFreqWord = (UINT32)((freqWord < 0) ? (freqWord + pow(2,32)) : freqWord);

            dbgInfoEx("[%s] giTemp:%f, pci:%f, freqWord:0x%x, cfrBw'%u \n", __FUNCTION__, giTemp, pci, freqWord, cfrBw);
            dbgInfoEx("[%s] difChn'%u, carrIndex'%u, carrRadio'0x%x, carrPowMw'%u, carrBw'%u, carrFi:%d, wei:%f, gi:%f, uiFreqWord:%u\n",
                        __FUNCTION__, difChn, carrNo, carrRadio, carrPowMw, carrBw, fi, wei, gi, uiFreqWord);

            ret |= BspHalAdaptCfrSetWord(difChn, bandLoop, carrNo, carrRadio, uiFreqWord);
        }
    }

    return ret;
}

UINT32 BspCfrGetCarrGi(UINT32 difChn, UINT32 carrNo, UINT32 carrRadio, DOUBLE giTemp, DOUBLE giTempMax, DOUBLE *pGi)
{
    DOUBLE gi = 0.0;
    UINT32 nbCarrMode = 0;

    INPUT_POINTER_CHECK(pGi);
    if (giTempMax >= (-EPSINON) && giTempMax <= EPSINON)
    {
        dbgInfoEx("[%s] error: giTempMax is zero!]\n",__FUNCTION__);
        return BSP_ERROR;
    }
    gi = (DOUBLE)round((giTemp / giTempMax) * pow(2, 25) / 2609);

    if (RADIO_STANDARD_NB_IOT == carrRadio)
    {
        nbCarrMode = BspGetNBCarrMode(difChn, carrNo);
        if((NB_INBAND_SAMEPCI == nbCarrMode) || (NB_INBAND_DIFFPCI == nbCarrMode))
        {
            gi = 0.0;
        }
        dbgInfoEx("[%s] NBCarrMode:[%d](0/1:IB, 2:GB, 3:STANDALONE)\n", __FUNCTION__, nbCarrMode);
    }

    *pGi = gi;
    dbgInfoEx("[%s] chan:%d, carrNo:%d, radio:%d, giTemp:%f, giTempMax:%f, gi:%f \n",
                __FUNCTION__, difChn, carrNo, carrRadio, giTemp, giTempMax, *pGi);

    return BSP_OK;
}

UINT32 BspGetSymNum(UINT32 thrSel, UINT32 symNum0, UINT32 symNum1)
{
    return ((thrSel == THR_SEL) ? symNum0 :symNum1);
}

UINT32 BspGetOriginValidLen(UINT32 delayEqualFlag, UINT32 vaildLen, UINT32 cpgCoefLenHalfMax)
{
    UINT32 originValidLen = 0;

    if (delayEqualFlag == DELAY_EQUAL)
    {
        if (vaildLen < VALID_LEN_MAX)
        {
            originValidLen = VALID_LEN;
        }
        else
        {
            originValidLen = cpgCoefLenHalfMax;
        }
    }
    else
    {
        originValidLen = vaildLen;
    }

    return originValidLen;
}

UINT32 BspCfrSetSideFilterCpgPara_HwCal(UINT32 difChn, UINT32 ulCarrId, UINT32 radioMode, UINT32 bandwidth)
{
    UINT32 ret            = BSP_OK;
    UINT32 retValOfSetCfrCoef = BSP_OK;
    UINT32 bandLoop       = 0;
    UINT32 carrLoop       = 0;
    UINT32 cnt            = 0;
    UINT32 carrBw         = 0;
    UINT32 cfrBw          = 0;
    UINT32 cpgCoefBw      = 0;
    UINT32 cfrFs          = 0;
    UINT32 carrPowMw      = 0;
    UINT32 carrNo         = 0;
    UINT32 hwChnMask      = 0;
    UINT32 originCoefLen  = 0;
    UINT32 originValidLen = 0;
    UINT32 carrRadio      = 0;
    UINT32 staPowStepFreq = 0;
    UINT32 deltPowFreq    = 0;
    UINT32 ratedPower     = 0;
    UINT32 symNum         = 0;
    UINT32 uiFreqWord     = 0;
    INT32 freqWord        = 0;
    INT32 fi              = 0;
    INT32 filterFi        = 0;
    DOUBLE wei            = 0.0;
    DOUBLE giTemp         = 0.0;
    DOUBLE giTempMax      = 1.0;
    DOUBLE gi             = 0.0;
    DOUBLE ciSq           = 0.0;
    DOUBLE pci            = 0.0;
    UINT32 chnChgFlag     = CFR_CHN_NO_CHANGE;
    T_CfrChnBandInfo *pCfrDifChnInfo = NULL;
    T_CfrCpgPara cfrCpgPara = {0};
    T_BspHalAdaptCfrParaHardCpg cfrHWCpgPara = {0};
    T_BspHalAdaptDifCommCfrPara cfrCommPara = {0};

    ret |= BspGetDifChnHwMask(&hwChnMask);
    ret |= BspGetCfrFsByDifChn(difChn, &cfrFs);
    ret |= BspGetCfrKiCommPara(&cfrHWCpgPara);
    ret |= BspGetCfrCommPara(&cfrCommPara);
    ret |= BspGetRruPathRatedPower(difChn, &ratedPower);

    chnChgFlag = GET_BIT(hwChnMask, difChn);
    dbgInfoEx("[%s] chn'%u, cfrFs:%u, chgFlag'%u, ratedPower:%u \n", __FUNCTION__, difChn, cfrFs, chnChgFlag, ratedPower);

    pCfrDifChnInfo = BspGetCfrChnInfo(difChn);
    RETURN_VAL_DO_IF_EXP(pCfrDifChnInfo == NULL, BSP_ERROR, dbgInfoEx("[%s]Get Cfr Dif Chn[%d] Info Error \n", __FUNCTION__, difChn));

    ret |= BspCfrCpgGetGiTempMax(difChn, bandwidth, pCfrDifChnInfo, &giTempMax);

    BspCheckCpgCarrNumValid();

    for (bandLoop = 0; bandLoop < E_CFR_BAND_MAX; bandLoop++)
    {
        CONTINUE_IF_EXP(pCfrDifChnInfo->usedFlag[bandLoop] == CFR_BAND_NOT_USED);

        if (chnChgFlag == CFR_CHN_CHANGE)
        {
            ret |= BspHalAdaptCfrCleanGi(difChn, bandLoop);
            ret |= BspHalAdaptCfrSetDlpreKiIndexDvSel(difChn, bandLoop);
            ret |= BspHalAdaptCfrSetCpgUpdateMode(difChn, bandLoop);
            ret |= BspHalAdaptCfrClrOriginCoefCarrInfo(difChn, bandLoop);

            symNum = BspGetSymNum(cfrCommPara.uiThrSel[difChn], cfrHWCpgPara.uiSymNum0[difChn], cfrHWCpgPara.uiSymNum1[difChn]);

            ret |= BspHalAdaptCfrSetDlpreKiIndexNum(difChn, bandLoop, symNum);
        }

        ret |= BspHalAdaptCfrCleanWord(difChn, bandLoop);

        for (carrLoop = 0; carrLoop < pCfrDifChnInfo->bandCarrNum[bandLoop]; carrLoop++)
        {
            CONTINUE_IF_EXP(pCfrDifChnInfo->carrInfo[bandLoop][carrLoop].carrFlag == CFR_CARR_INVALID);

            fi = pCfrDifChnInfo->carrInfo[bandLoop][carrLoop].carrFi;
            carrNo = pCfrDifChnInfo->carrInfo[bandLoop][carrLoop].carrNo;
            carrBw = pCfrDifChnInfo->carrInfo[bandLoop][carrLoop].carrBw;
            carrPowMw = pCfrDifChnInfo->carrInfo[bandLoop][carrLoop].powerMw;
            carrRadio = pCfrDifChnInfo->carrInfo[bandLoop][carrLoop].carrRadio;
            cpgCoefBw = carrBw;

            if(BSP_OK == BspJudgeCarrIdAndRadio(ulCarrId, carrNo, carrRadio, radioMode))
            {
                ret |= BspUpdateUsableCpgBw(bandwidth, &cpgCoefBw);
                ret |= BspSetDlFilterCpgBw(difChn, carrNo, carrRadio, bandwidth);
                ret |= BspGetCfrFreqFiOffset(difChn, carrNo, carrRadio, &filterFi);
                fi = filterFi;
            }

            ret |= BspCfrCpgGetWei(cfrFs, carrRadio, &wei);
            ret |= BspGetCfrRadioBwFromBspBw(carrRadio, cpgCoefBw, &cfrBw);
            deltPowFreq = 31;

            ret |= BspGetCfrCpgCoef_IC4_2(difChn, cfrBw, cfrFs, &cfrCpgPara);
            CONTINUE_IF_EXP((ret != BSP_OK));
            CONTINUE_IF_EXP((retValOfSetCfrCoef != BSP_OK) && (retValOfSetCfrCoef != BSP_INVALID_VALUE));
            CONTINUE_IF_EXP(NULL == cfrCpgPara.pCoefPara);

            originCoefLen = cfrCpgPara.coefLen;
            ciSq = 0;
            for (cnt = 0; cnt < (originCoefLen - 1); cnt++)
            {
                ciSq += pow(cfrCpgPara.pCoefPara[cnt], 2);
            }

            pci = (DOUBLE)(2 * ciSq + pow(cfrCpgPara.pCoefPara[originCoefLen - 1], 2));
            giTemp = (DOUBLE)(wei / sqrt(pci));
            ret |= BspCfrGetCarrGi(difChn, carrNo, carrRadio, giTemp, giTempMax, &gi);
            originValidLen = BspGetOriginValidLen(cfrCommPara.uiDelayEqualFlag[difChn], cfrCpgPara.vaildLen, cfrCommPara.uiCpgCoefLenHalfMax[difChn]);
            if (BSP_OK != ret)
            {
                return BSP_ERROR;
            }

            if (chnChgFlag == CFR_CHN_CHANGE)
            {
                ret |= BspHalAdaptCfrSetGi(difChn, bandLoop, carrNo, carrRadio, (UINT32)gi);
                retValOfSetCfrCoef = BspSetDssCfrOriginCoefAndRecordExcessCarr(difChn, carrNo, carrRadio, cpgCoefBw, originValidLen, &cfrCpgPara.pCoefPara[CPG_COEF_LEN_HALF_MAX_768 - originValidLen]);
                ret |= BspHalAdaptSetDlpreKiIndexGsm(difChn, carrNo, carrRadio, staPowStepFreq, deltPowFreq);
                ret |= BspHalAdaptCfrSetcfgFlag(difChn, bandLoop);
            }

            DIV_CHK_PRN_RET(cfrFs)
            freqWord = (INT32)round(((DOUBLE)fi / cfrFs) * pow(2, 32));
            uiFreqWord = (UINT32)((freqWord < 0) ? (freqWord + pow(2,32)) : freqWord);

            dbgInfoEx("[%s] giTemp:%f, pci:%f, freqWord:0x%x, cfrBw'%u \n", __FUNCTION__, giTemp, pci, freqWord, cfrBw);
            dbgInfoEx("[%s] difChn'%u, carrIndex'%u, carrRadio'0x%x, carrPowMw'%u, carrBw'%u, carrFi:%d, wei:%f, gi:%f, uiFreqWord:%u\n",
                        __FUNCTION__, difChn, carrNo, carrRadio, carrPowMw, carrBw, fi, wei, gi, uiFreqWord);

            ret |= BspHalAdaptCfrSetWord(difChn, bandLoop, carrNo, carrRadio, uiFreqWord);
        }
    }

    return ret;
}

/*****************************************************************************
*  函数名称   : BspCfrCpgInit_CpuCal
*  功能描述   : cpg 系数软计算初始化
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : difChan - 中频通道
*  输出参数   : 无
*  返 回 值   : BSP_OK  - 成功;其它值为失败
*  其它说明   :无
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 10307448徐利波@2022-03-03 16:08:15
*----------------------------------------------------------------------------
*/
UINT32 BspCfrCpgInit_CpuCal(UINT32 difChn)
{
    UINT32 ret           = BSP_OK;
    UINT32 bandLoop      = 0;
    UINT32 carrLoop      = 0;
    UINT32 carrBw        = 0;
    UINT32 cpgCoefBw     = 0;
    UINT32 cfrBw         = 0;
    UINT32 carrPowMw     = 0;
    UINT32 appPowMw      = 0;
    UINT32 realPowMw     = 0;
    INT32 tssiPowDbm     = 0;
    INT32 tssiPowDbfs    = 0;
    DOUBLE powMw         = 0.0;
    UINT32 carrRadio     = 0;
    UINT32 carrNo        = 0;
    UINT32 cnt           = 0;
    DOUBLE Ki            = 0;
    DOUBLE wei           = 0.0;
    DOUBLE giTemp        = 0.0;
    DOUBLE giTempMax     = 1.0;
    DOUBLE gi            = 0.0;
    DOUBLE sumBandGK     = 0.0;
    DOUBLE ciSq          = 0.0;
    DOUBLE pci           = 0.0;
    DOUBLE *pCpgReal     = NULL;
    DOUBLE *pCpgImag     = NULL;
    INT32 fi             = 0;
    DOUBLE tempData      = 0.0;
    DOUBLE dQn           = 0.0;
    UINT32 ulDelayMode   = 0;
    UINT32 cfrFs         = 0;
    UINT32 bandNum       = 0;
    UINT32 cpgVaildLen   = 0;
    UINT32 originCoefLen = 0;
    INT32 filterFi       = 0;
    UINT32 filterBw      = 0;
    UINT32 ulCpgLen      = CFR_CPG_RAM_768;
    UINT32 cpgCalcFlag   = 0;
    UINT32 powShareFlag  = 1;
    FUN_GET_POWCTRL_TSSI_INFO pGetTssiPowInfo = NULL;
    T_CfrChnBandInfo *pCfrDifChnInfo = NULL;
    T_CfrCpgPara cfrCpgPara = {0};
    T_BspHalAdaptDifCommCfrPara *difPara = NULL;

    INPUT_DIFCHAN_CHECK(difChn);
    difPara = BspHalAdaptGetDifCfrPara();
    if(NULL != difPara)
    {
        ulDelayMode = difPara->uiDelayEqualFlag[difChn];
        ulCpgLen = difPara->uiCpgCoefLenHalfMax[difChn];
        dbgInfoEx("[%s] DlyMode is %d,CPG Len is %d\n ",__FUNCTION__,ulDelayMode,ulCpgLen);
    }

    ret |= BspGetCfrFsByDifChn(difChn,&cfrFs);
    ret |= BspGetRefreshCfrCpgFlag(difChn, &cpgCalcFlag);

    dbgInfoEx("[%s] chn'%u, cfrFs'%u, cpgReshFlag'%u. \n", __FUNCTION__, difChn, cfrFs, cpgCalcFlag);

    /* kw告警修改,考虑32/64位系统, 所以用ULONG */
    pCpgReal = (DOUBLE *)malloc(sizeof(DOUBLE) * CFR_CPG_RAM_768);
    INPUT_POINTER_CHECK(pCpgReal);

    pCpgImag = (DOUBLE *)malloc((sizeof(DOUBLE) * CFR_CPG_RAM_768));
    if (pCpgImag == NULL)
    {
        free(pCpgReal);
        pCpgReal = NULL;
        dbgInfoEx("[%s]cpg space malloc error \n", __FUNCTION__);
        return BSP_ERROR;
    }

    memset(pCpgReal, 0, (sizeof(DOUBLE) * CFR_CPG_RAM_768));
    memset(pCpgImag, 0, (sizeof(DOUBLE) * CFR_CPG_RAM_768));

    pCfrDifChnInfo = BspGetCfrChnInfo(difChn);
    if (pCfrDifChnInfo == NULL)
    {
        dbgInfoEx("[%s]Get Cfr Dif Chn[%d] Info Error \n", __FUNCTION__, difChn);
        BspLog(LOG_LEVEL_0,"[%s] Get Cfr Chn[%d] Rf Para Error! \n", __FUNCTION__,difChn);
        free(pCpgImag);
        free(pCpgReal);
        return BSP_ERROR;
    }

    ret |= BspCfrCpgGetGiTempMax(difChn, 0, pCfrDifChnInfo, &giTempMax);  /*非单边滤波削峰，滤波后带宽写0即可*/

    for (bandLoop = 0; bandLoop < E_CFR_BAND_MAX; bandLoop ++)
    {
        if (pCfrDifChnInfo->usedFlag[bandLoop] == CFR_BAND_NOT_USED)
        {
            continue;
        }
        bandNum ++;
        cpgVaildLen = 0;
        for (carrLoop = 0; carrLoop < pCfrDifChnInfo->bandCarrNum[bandLoop]; carrLoop++)
        {
            if (pCfrDifChnInfo->carrInfo[bandLoop][carrLoop].carrFlag == CFR_CARR_INVALID)
            {
                continue;
            }

            carrNo      = pCfrDifChnInfo->carrInfo[bandLoop][carrLoop].carrNo;
            appPowMw    = pCfrDifChnInfo->carrInfo[bandLoop][carrLoop].powerMw;
            carrBw      = pCfrDifChnInfo->carrInfo[bandLoop][carrLoop].carrBw;
            carrRadio   = pCfrDifChnInfo->carrInfo[bandLoop][carrLoop].carrRadio;
            fi          = pCfrDifChnInfo->carrInfo[bandLoop][carrLoop].carrFi;
            cpgCoefBw   = carrBw;

            if (BSP_OK == BspJudgeCarrFilterByCpg(difChn, TX, carrNo, carrRadio))
            {
                ret |= BspGetFilterBw(difChn, carrNo, carrRadio, &filterBw);
                ret |= BspUpdateUsableCpgBw(filterBw, &cpgCoefBw);
                ret |= BspGetCfrFreqFiOffset(difChn, carrNo, carrRadio, &filterFi);
                appPowMw = (UINT32)((appPowMw * cpgCoefBw) / carrBw);
                fi = filterFi;
            }

            pGetTssiPowInfo = BspGetTssiPowInfoCallBackInit();
            RETURN_VAL_DO_IF_EXP(pGetTssiPowInfo == NULL, BSP_ERROR, free(pCpgReal); free(pCpgImag));
            pGetTssiPowInfo(difChn, carrRadio, carrNo, &tssiPowDbm, &tssiPowDbfs);
            powMw = pow(10, (tssiPowDbm * 1.0 / 100 / 10));
            realPowMw = (UINT32)powMw;
            ret |= BspJudgeCfrCpgRefreshCarrPow(cpgCalcFlag, powShareFlag, appPowMw, realPowMw, (INT32 *)&carrPowMw);
            ret |= BspGetCfrRadioBwFromBspBw(carrRadio, cpgCoefBw, &cfrBw);

            dbgInfoEx("[%s] chn'%u, carrNo'%u, carrRadio'0x%x, carrPowMw'%u, appPowMw'%u, realPowMw'%u, carrBw'%u, cfrBw'%u, fi'%d. \n",
                    __FUNCTION__, difChn, carrNo, carrRadio, carrPowMw, appPowMw, realPowMw, carrBw, cfrBw, fi);

            if (0 != cfrFs)
            {
                dQn = 2.0 * CFR_PI * fi / cfrFs;/*KHZ*/
            }
            Ki = (DOUBLE)sqrt(carrPowMw);

            ret |= BspCfrCpgGetWei(cfrFs, carrRadio, &wei);
            ret |= BspGetCfrCpgCoef_IC4_2(difChn,cfrBw,cfrFs, &cfrCpgPara);
            if (ret != BSP_OK)
            {
                continue;
            }
            CONTINUE_IF_EXP(cfrCpgPara.pCoefPara == NULL);

            if(1 == ulDelayMode)//如果是等时延，cfr的CPG长度固定
            {
                cpgVaildLen = ulCpgLen;
            }
            else
            {
                cpgVaildLen = (cpgVaildLen>cfrCpgPara.vaildLen)?cpgVaildLen:cfrCpgPara.vaildLen;
            }
            
            originCoefLen = cfrCpgPara.coefLen;
            ciSq = 0;
            for (cnt = 0; cnt < (originCoefLen - 1); cnt++)
            {
                ciSq += pow(cfrCpgPara.pCoefPara[cnt], 2);
            }

            pci = (DOUBLE)(2 * ciSq + pow(cfrCpgPara.pCoefPara[originCoefLen - 1], 2));
            giTemp = (DOUBLE)(wei / sqrt(pci));
            ret |= BspCfrGetCarrGi(difChn, carrNo, carrRadio, giTemp, giTempMax, &gi);
            if (BSP_OK != ret)
            {
                free(pCpgReal);
                free(pCpgImag);
                pCpgReal = NULL;
                pCpgImag = NULL;
                return BSP_ERROR;
            }

            sumBandGK += gi * Ki;

            for (cnt = 0; cnt < originCoefLen; cnt++)
            {
                tempData = ((originCoefLen - 1 - cnt) * (-1.0) * dQn);
                pCpgReal[cnt] += ((DOUBLE)(Ki * gi * cos(tempData))) * (DOUBLE)cfrCpgPara.pCoefPara[cnt];
                pCpgImag[cnt] += ((DOUBLE)(Ki * gi * sin(tempData))) * (DOUBLE)cfrCpgPara.pCoefPara[cnt];
            }
        }

        if ((sumBandGK >= (-(DOUBLE)EPSINON)) && (sumBandGK <= (DOUBLE)EPSINON))
        {
            ret |= BspCfrDataSave_CpuCal(difChn, bandLoop, pCpgReal, pCpgImag, CFR_CPG_RAM_768, 1, cpgVaildLen);
            ret |= BSP_ERROR;
            BspLog(LOG_LEVEL_0, "[%s] Error, chan:%u cfr sumBandGK is zero! \n", __FUNCTION__, difChn);
        }
        else
        {
            ret |= BspCfrDataSave_CpuCal(difChn, bandLoop, pCpgReal, pCpgImag, CFR_CPG_RAM_768, sumBandGK,cpgVaildLen);
        }
        dbgInfoEx("[%s] difChn'%d BandIdx'%d sumBandGK'%f CpgInitCpuCal OK! DataSave %s!\n",
                __FUNCTION__, difChn, bandLoop, sumBandGK, (BSP_OK == ret) ? "Succ" : "Fail");

        memset(pCpgReal, 0, sizeof(DOUBLE)*originCoefLen);
        memset(pCpgImag, 0, sizeof(DOUBLE)*originCoefLen);
        sumBandGK = 0.0;
    }
    ret |= BspCfrSetBandNum(difChn,bandNum);

    free(pCpgReal);
    free(pCpgImag);
    pCpgReal = NULL;
    pCpgImag = NULL;

    return ret;
}

/*****************************************************************************
*  函数名称   : BspCfrSetCpgParaCpuCalByRadio
*  功能描述   : 设置单边滤波后软计算的CPG系数
*  输入参数   : difChn - 中频通道, umtsBw - 单边滤波后UMTS带宽
*  输出参数   : 无
*  返 回 值   : BSP_OK  - 成功;其它值为失败
*  其它说明   : 与非单边滤波的削峰相比,单边滤波波及以下三点:
               (1)需用高层传递的单边滤波后的带宽匹配原型系数;
               (2)功率计算:原带宽D1,功率P1,单边滤波后带宽D2,滤波后功率P2=(D2/D1)*P1;
               (3)载波NCO计算:fi=原链路载波NCO-NCO1。
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 10307448徐利波@2022-12-13 21:54:23
*----------------------------------------------------------------------------
*/
UINT32 BspCfrSetCpgParaCpuCalByRadio(UINT32 difChn, UINT32 ulCarrId, UINT32 radio, UINT32 bw)
{
    UINT32 ret           = BSP_OK;
    UINT32 bandLoop      = 0;
    UINT32 carrLoop      = 0;
    UINT32 carrBw        = 0;
    UINT32 cfrBw         = 0;
    UINT32 cpgCoefBw     = 0;
    UINT32 carrPowMw     = 0;
    UINT32 appPowMw      = 0;
    UINT32 realPowMw     = 0;
    INT32 tssiPowDbm     = 0;
    INT32 tssiPowDbfs    = 0;
    DOUBLE powMw         = 0.0;
    UINT32 carrRadio     = 0;
    UINT32 carrNo        = 0;
    UINT32 cnt           = 0;
    DOUBLE Ki            = 0;
    DOUBLE wei           = 0.0;
    DOUBLE giTemp        = 0.0;
    DOUBLE giTempMax     = 1.0;
    DOUBLE gi            = 0.0;
    DOUBLE sumBandGK     = 0.0;
    DOUBLE ciSq          = 0.0;
    DOUBLE pci           = 0.0;
    DOUBLE *pCpgReal     = NULL;
    DOUBLE *pCpgImag     = NULL;
    INT32 fi             = 0;
    DOUBLE tempData      = 0.0;
    DOUBLE dQn           = 0.0;
    UINT32 ulDelayMode   = 0;
    UINT32 cfrFs         = 0;
    UINT32 bandNum       = 0;
    UINT32 cpgVaildLen   = 0;
    UINT32 originCoefLen = 0;
    INT32 filterFi       = 0;
    UINT32 ulCpgLen      = CFR_CPG_RAM_768;
    UINT32 cpgCalcFlag   = 0;
    UINT32 powShareFlag  = 1;
    FUN_GET_POWCTRL_TSSI_INFO pGetTssiPowInfo = NULL;
    T_CfrChnBandInfo *pCfrDifChnInfo = NULL;
    T_CfrCpgPara cfrCpgPara = {0};
    T_BspHalAdaptDifCommCfrPara *difPara = NULL;

    INPUT_DIFCHAN_CHECK(difChn);
    difPara = BspHalAdaptGetDifCfrPara();
    if(NULL != difPara)
    {
        ulDelayMode = difPara->uiDelayEqualFlag[difChn];
        ulCpgLen = difPara->uiCpgCoefLenHalfMax[difChn];
        dbgInfoEx("[%s] DlyMode is %d,CPG Len is %d\n ",__FUNCTION__,ulDelayMode,ulCpgLen);
    }

    if(s_cfrCpgCpuCalData == NULL)
    {
        dbgInfoEx("[%s]: s_cfrCpgCpuCalData not malloc ",__FUNCTION__);
        BspLog(LOG_LEVEL_0,"[%s] difChn'%d, bw'%d, s_cfrCpgCpuCalData not malloc! \n", __FUNCTION__,difChn,bw);
        return BSP_ERROR;
    }

    ret |= BspGetCfrFsByDifChn(difChn,&cfrFs);
    ret |= BspGetRefreshCfrCpgFlag(difChn, &cpgCalcFlag);

    dbgInfoEx("[%s] chn'%u, cfrFs'%u, cpgReshFlag'%u. \n", __FUNCTION__, difChn, cfrFs, cpgCalcFlag);

    /* kw告警修改,考虑32/64位系统, 所以用ULONG */
    pCpgReal = (DOUBLE *)malloc(sizeof(DOUBLE) * CFR_CPG_RAM_768);
    INPUT_POINTER_CHECK(pCpgReal);

    pCpgImag = (DOUBLE *)malloc((sizeof(DOUBLE) * CFR_CPG_RAM_768));
    if (pCpgImag == NULL)
    {
        free(pCpgReal);
        pCpgReal = NULL;
        dbgInfoEx("[%s]cpg space malloc error \n", __FUNCTION__);
        return BSP_ERROR;
    }

    memset(pCpgReal, 0, (sizeof(DOUBLE) * CFR_CPG_RAM_768));
    memset(pCpgImag, 0, (sizeof(DOUBLE) * CFR_CPG_RAM_768));

    pCfrDifChnInfo = BspGetCfrChnInfo(difChn);
    if (pCfrDifChnInfo == NULL)
    {
        dbgInfoEx("[%s]Get Cfr Dif Chn[%d] Info Error \n", __FUNCTION__, difChn);
        BspLog(LOG_LEVEL_0,"[%s] Get Cfr Chn[%d] Rf Para Error! \n", __FUNCTION__,difChn);
        free(pCpgImag);
        free(pCpgReal);
        return BSP_ERROR;
    }

    ret |= BspCfrCpgGetGiTempMax(difChn, bw, pCfrDifChnInfo, &giTempMax);

    for (bandLoop = 0; bandLoop < E_CFR_BAND_MAX; bandLoop ++)
    {
        if (pCfrDifChnInfo->usedFlag[bandLoop] == CFR_BAND_NOT_USED)
        {
            continue;
        }
        bandNum ++;
        cpgVaildLen = 0;
        for (carrLoop = 0; carrLoop < pCfrDifChnInfo->bandCarrNum[bandLoop]; carrLoop++)
        {
            if (pCfrDifChnInfo->carrInfo[bandLoop][carrLoop].carrFlag == CFR_CARR_INVALID)
            {
                continue;
            }

            carrNo      = pCfrDifChnInfo->carrInfo[bandLoop][carrLoop].carrNo;
            carrBw      = pCfrDifChnInfo->carrInfo[bandLoop][carrLoop].carrBw;
            carrRadio   = pCfrDifChnInfo->carrInfo[bandLoop][carrLoop].carrRadio;
            appPowMw    = pCfrDifChnInfo->carrInfo[bandLoop][carrLoop].powerMw;
            cpgCoefBw   = carrBw;

            pGetTssiPowInfo = BspGetTssiPowInfoCallBackInit();
            RETURN_VAL_DO_IF_EXP(pGetTssiPowInfo == NULL, BSP_ERROR, free(pCpgReal); free(pCpgImag));
            pGetTssiPowInfo(difChn, carrRadio, carrNo, &tssiPowDbm, &tssiPowDbfs);
            powMw = pow(10, (tssiPowDbm * 1.0 / 100 / 10));
            realPowMw = (UINT32)powMw;
            ret |= BspJudgeCfrCpgRefreshCarrPow(cpgCalcFlag, powShareFlag, appPowMw, realPowMw, (INT32 *)&carrPowMw);
            fi = pCfrDifChnInfo->carrInfo[bandLoop][carrLoop].carrFi;

            if(BSP_OK == BspJudgeCarrIdAndRadio(ulCarrId, carrNo, carrRadio, radio))
            {
                ret |= BspUpdateUsableCpgBw(bw, &cpgCoefBw);
                ret |= BspGetCfrFreqFiOffset(difChn, carrNo, carrRadio, &filterFi);
                ret |= BspSetDlFilterCpgBw(difChn, carrNo, radio, bw);

                fi = filterFi;
                carrPowMw = (UINT32)((carrPowMw * cpgCoefBw) / carrBw);
            }

            ret = BspGetCfrRadioBwFromBspBw(carrRadio, cpgCoefBw, &cfrBw);
            dbgInfoEx("[%s] chn'%u, carrNo'%u, carrRadio'0x%x, carrPowMw'%u, appPowMw'%u, realPowMw'%u, carrBw'%u, cfrBw'%u, fi'%d. \n",
                    __FUNCTION__, difChn, carrNo, carrRadio, carrPowMw, appPowMw, realPowMw, carrBw, cfrBw, fi);

            if (0 != cfrFs)
            {
                dQn = 2.0 * CFR_PI * fi / cfrFs;/*KHZ*/
            }
            Ki = (DOUBLE)sqrt(carrPowMw);

            ret |= BspCfrCpgGetWei(cfrFs, carrRadio, &wei);
            ret |= BspGetCfrCpgCoef_IC4_2(difChn,cfrBw,cfrFs, &cfrCpgPara);
            if (ret != BSP_OK)
            {
                continue;
            }

            if(1 == ulDelayMode)//如果是等时延，cfr的CPG长度固定
            {
                cpgVaildLen = ulCpgLen;
            }
            else
            {
                cpgVaildLen = (cpgVaildLen>cfrCpgPara.vaildLen)?cpgVaildLen:cfrCpgPara.vaildLen;
            }

            originCoefLen = cfrCpgPara.coefLen;
            ciSq = 0;
            for (cnt = 0; cnt < (originCoefLen - 1); cnt++)
            {
                if ((cfrCpgPara.pCoefPara != NULL) && (cfrCpgPara.pCoefPara[cnt] != NULL))
                {           
                    ciSq += pow(cfrCpgPara.pCoefPara[cnt], 2);
                }
            }
      
            if ((cfrCpgPara.pCoefPara != NULL) && (cfrCpgPara.pCoefPara[originCoefLen - 1] != NULL))
            {           
                pci = (DOUBLE)(2 * ciSq + pow(cfrCpgPara.pCoefPara[originCoefLen - 1], 2));
            }
            giTemp = (DOUBLE)(wei / sqrt(pci));
            ret |= BspCfrGetCarrGi(difChn, carrNo, carrRadio, giTemp, giTempMax, &gi);
            if (BSP_OK != ret)
            {
                free(pCpgReal);
                free(pCpgImag);
                pCpgReal = NULL;
                pCpgImag = NULL;
                return BSP_ERROR;
            }

            sumBandGK += gi * Ki;

            for (cnt = 0; cnt < originCoefLen; cnt++)
            {
                tempData = ((originCoefLen - 1 - cnt) * (-1.0) * dQn);
                if ((cfrCpgPara.pCoefPara != NULL) && (cfrCpgPara.pCoefPara[cnt] != NULL))
                {           
                    pCpgReal[cnt] += ((DOUBLE)(Ki * gi * cos(tempData))) * (DOUBLE)cfrCpgPara.pCoefPara[cnt];
                    pCpgImag[cnt] += ((DOUBLE)(Ki * gi * sin(tempData))) * (DOUBLE)cfrCpgPara.pCoefPara[cnt];
                }
            }
        }

        if ((sumBandGK >= (-(DOUBLE)EPSINON)) && (sumBandGK <= (DOUBLE)EPSINON))
        {
            ret |= BspCfrDataSave_CpuCal(difChn, bandLoop, pCpgReal, pCpgImag, CFR_CPG_RAM_768, 1, cpgVaildLen);
            ret |= BSP_ERROR;
            BspLog(LOG_LEVEL_0, "[%s] Error, chan:%u cfr sumBandGK is zero! \n", __FUNCTION__, difChn);
        }
        else
        {
            ret |= BspCfrDataSave_CpuCal(difChn, bandLoop, pCpgReal, pCpgImag, CFR_CPG_RAM_768, sumBandGK,cpgVaildLen);
        }
        dbgInfoEx("%s>>DifChnl'%d BandIdx'%d sumBandGK'%f CpgInitCpuCal OK! DataSave %s!\n",
                __FUNCTION__, difChn, bandLoop, sumBandGK, (BSP_OK == ret) ? "Succ" : "Fail");

        memset(pCpgReal, 0, sizeof(DOUBLE)*originCoefLen);
        memset(pCpgImag, 0, sizeof(DOUBLE)*originCoefLen);
        sumBandGK = 0.0;
    }
    ret |= BspCfrSetBandNum(difChn,bandNum);

    free(pCpgReal);
    free(pCpgImag);
    pCpgReal = NULL;
    pCpgImag = NULL;

    return ret;
}

/*****************************************************************************
*  函数名称   : BspCfrCpgCfg_CpuCal
*  功能描述   : cpg配置
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : difChan - 中频通道
*  输出参数   : 无
*  返 回 值   : BSP_OK  - 成功;其它值为失败
*  其它说明   :
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2015-11-28 14:55:24
*----------------------------------------------------------------------------
*/
UINT32 BspCfrCpgCfg_CpuCal(UINT32 difChn)
{
	UINT32 retVal = BSP_OK;
    UINT32 *pCpgCoef = NULL;
    UINT32 ulCpgLen = 0;
    UINT32 freqBand = 0;

    pCpgCoef = (UINT32 *)s_cfrCpgCpuCalData[difChn].cfrBand[0].pCoef;
    ulCpgLen = s_cfrCpgCpuCalData[difChn].cfrBand[0].cpgVaildLen;
    if((NULL == pCpgCoef)||(0 == ulCpgLen))
    {
        dbgInfoEx("Cpg is Null or CpgLen is %d ",ulCpgLen);
        return BSP_ERROR;
    }

	retVal  = BspHalAdaptCfrSetCpgTblCfg(difChn, freqBand, pCpgCoef, ulCpgLen);

    return retVal;
}

UINT32 BspCfrGetCpgVaildLen(UINT32 difChn, UINT32 *vaildlen)
{
    UINT32 retVal        = BSP_OK;
    UINT32 bandLoop      = 0;
    UINT32 carrLoop      = 0;
    UINT32 cpgVaildLen   = 0;
    UINT32 cfrBw         = 0;
    UINT32 cfrFs         = 0;
    UINT32 carrBw        = 0;
    UINT32 carrRadio     = 0;
    T_CfrCpgPara cfrCpgPara = {0};
    T_CfrChnBandInfo *pCfrDifChnInfo = NULL;
    T_BspHalAdaptDifCommCfrPara cfrCommPara = {0};

    INPUT_POINTER_CHECK(vaildlen);
    INPUT_DIFCHAN_CHECK(difChn);

    retVal = BspGetCfrCommPara(&cfrCommPara);

    if (cfrCommPara.uiCpgMode[difChn] == CFR_CPG_CPU_CAL)
    {
        if(s_cfrCpgCpuCalData == NULL)
        {
            dbgInfoEx("CFR is not init!");
            return BSP_ERROR;
        }
        
        *vaildlen = s_cfrCpgCpuCalData[difChn].cfrBand[0].cpgVaildLen;

        return retVal;
    }

    if(cfrCommPara.uiDelayEqualFlag[difChn] == 1)//硬件计算等时延
    {
        *vaildlen = cfrCommPara.uiCpgCoefLenHalfMax[difChn];

        return retVal;
    }

    /* 硬件计算不等时延: 通道Cpg有效长度为通道中各载波原型系数有效长度最大值 */
    pCfrDifChnInfo = BspGetCfrChnInfo(difChn);
    if (pCfrDifChnInfo == NULL)
    {
        dbgInfoEx("[%s]Get Cfr Dif Chn[%d] Info Error \n", __FUNCTION__, difChn);
        return BSP_ERROR;
    }

    retVal |= BspGetCfrFsByDifChn(difChn,&cfrFs);

    for (bandLoop = 0; bandLoop < E_CFR_BAND_MAX; bandLoop ++)
    {
        if (pCfrDifChnInfo->usedFlag[bandLoop] == CFR_BAND_NOT_USED)
        {
            continue;
        }

        cpgVaildLen = 0;
        for (carrLoop = 0; carrLoop < pCfrDifChnInfo->bandCarrNum[bandLoop]; carrLoop++)
        {
            if (pCfrDifChnInfo->carrInfo[bandLoop][carrLoop].carrFlag == CFR_CARR_INVALID)
            {
                continue;
            }

            carrBw      = pCfrDifChnInfo->carrInfo[bandLoop][carrLoop].carrBw;
            carrRadio   = pCfrDifChnInfo->carrInfo[bandLoop][carrLoop].carrRadio;
            retVal = BspGetCfrRadioBwFromBspBw(carrRadio, carrBw, &cfrBw); 

            retVal |= BspGetCfrCpgCoef_IC4_2(difChn,cfrBw,cfrFs, &cfrCpgPara);
            if (retVal != BSP_OK)
            {
                continue;
            }

            cpgVaildLen = (cpgVaildLen > cfrCpgPara.vaildLen) ? cpgVaildLen : cfrCpgPara.vaildLen;
        }

        *vaildlen = cpgVaildLen;
    }

    return retVal;
}

/*****************************************************************************
*  函数名称   : CfrGetCpgCfg_CpuCal_IC4_2
*  功能描述   : 获取cpg系数cpg配置
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : difChan - 中频通道
*  输出参数   : 无
*  返 回 值   : BSP_OK  - 成功;其它值为失败
*  其它说明   : 仅用于调试接口
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2015-11-28 14:55:24
*----------------------------------------------------------------------------
*/
UINT32 CfrGetCpgCfg_CpuCal_IC4_2(UINT32 difChn,INT16 *pCpgReal,INT16 * pCpgImag,UINT32 cfrLutLen)
{
	UINT32 retVal = BSP_OK;
	UINT32 pCoef[CFR_CPG_RAM_768]={0};
	UINT32 coefLoop = 0;
    UINT32 freqBand = 0;

	cfrLutLen = (cfrLutLen > CFR_CPG_RAM_768)?CFR_CPG_RAM_768:cfrLutLen;
	retVal  = BspHalAdaptCfrGetCpgTblCfg(difChn, freqBand, pCoef, cfrLutLen);

	for(coefLoop = 0;coefLoop < cfrLutLen;coefLoop ++)
	{
		pCpgReal[coefLoop] = (INT16)((pCoef[coefLoop]>>16) &0x1FFF);
		pCpgImag[coefLoop] = (INT16)(pCoef[coefLoop] &0x1FFF);
	}

	return retVal;
}

/*降低BspCfrSetCpgParaCpuCalByRadio和BspCfrSetUmtsCpgPara_HwCal的圈复杂度*/
UINT32 BspJudgeCarrIdAndRadio(UINT32 ulCarrId, UINT32 carrNo, UINT32 carrRadio, UINT32 radio)
{
    if((ulCarrId == carrNo) && (carrRadio == radio))
    {
        return BSP_OK;
    }
    return BSP_ERROR;
}

/* Started by AICoder, pid:ma5a78d431i7cc3149f30a4650fbfb4ab7e63d7b */
INT32 BspUpdateCarrBwByFilterCpg(UINT32 difChn, UINT32 carrNo, UINT32 carrRadio, INT32 *fi, UINT32 *cpgCoefBw)
{
    INT32 filterFi = 0;
    UINT32 ret = BSP_OK;
    UINT32 filterBw = 0;

    INPUT_POINTER_CHECK(fi);
    INPUT_POINTER_CHECK(cpgCoefBw);
    if (BSP_OK == BspJudgeCarrFilterByCpg(difChn, TX, carrNo, carrRadio))
    {
        ret |= BspGetFilterBw(difChn, carrNo, carrRadio, &filterBw);
        ret |= BspUpdateUsableCpgBw(filterBw, cpgCoefBw);
        ret |= BspGetCfrFreqFiOffset(difChn, carrNo, carrRadio, &filterFi);
        *fi = filterFi;
    }
    return ret;
}
/* Ended by AICoder, pid:ma5a78d431i7cc3149f30a4650fbfb4ab7e63d7b */

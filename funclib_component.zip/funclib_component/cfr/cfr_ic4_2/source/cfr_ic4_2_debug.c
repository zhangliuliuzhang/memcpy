/*****************************************************************************
* 版权所有(C) 2021,  ZTE Corp. ZXSDR-RRU Platform BSP
*----------------------------------------------------------------------------
* 模 块 名 : CFR
* 文件名称 : cfr_ic4_2_debug.c
* 文件标识 : {[N/A]}
* 内容摘要 : 本文件主要提供cfr 模块调试命令的实现。
* 注意事项 : 无
* 作    者 : 徐利波10307448
* 创建日期 : 2022-02-17
* 当前版本 : Ver1.0
*----------------------------------------------------------------------------
* 变更记录 :
*
* $记录1
* 变 更 单: $0000000(N/A)
* 责 任 人: 徐利波10307448
* 修改日戳: 2022-02-17
* 变更说明: 创建文件
*----------------------------------------------------------------------------
*/

#include "bsppub.h"
#include "bspcomm.h"
#include "cfrcommon.h"
#include "funccommon_chncfg.h"
#include "ichaladaptbspapi.h"
#include "rruinfo.h"
//#include "ichaladapt_ic4_2.h"
#include "ichaladapt_cfr_ic4_2.h"
#include "cfr_ic4_2.h"
#include "chnmap_a.h"
#include "cfr_ic4_2_cpgcal.h"

/**************************************************************************
 *                        宏定义
 **************************************************************************/
#define CFR_DEBUG_DIF_CHN           8
#define CFR_DEBUG_CARR_MAX_NUM      BSP_MAX_CARR_NUM
#define CFR_RAM_LEN  512
/**************************************************************************
*                         数据类型                                       *
**************************************************************************/


/* CFR HELP */
typedef UINT32(*CFR_TEST_FUNC)(INT32 p0, INT32 p1, INT32 p2, INT32 p3, INT32 p4, INT32 p5, INT32 p6, INT32 p7, INT32 p8, INT32 p9);

UINT32 cfron(UINT32 bspChan);
UINT32 cfroff(UINT32 bspChan);
UINT32 cfrsetgate(UINT32 bspChan, UINT32 cfrGate0, UINT32 cfrGate1, UINT32 cfrGate2);
UINT32 cfrgetgate(UINT32 bspChan);
UINT32 cfrsetdelt(UINT32 bspChan, UINT32 cfrDelt0, UINT32 cfrDelt1, UINT32 cfrDelt2);
UINT32 cfrgetdelt(UINT32 bspChan);
UINT32 cfrsetwin(UINT32 bspChan, UINT32 cfrWin0, UINT32 cfrWin1, UINT32 cfrWin2);
UINT32 cfrgetwin(UINT32 bspChan);
UINT32 cfrsetwinlevel(UINT32 bspChan, UINT32 cfrWinlevel0, UINT32 cfrWinlevel1, UINT32 cfrWinlevel2);
UINT32 cfrgetwinlevel(UINT32 bspChan);
UINT32 cfrgetcpgini(UINT32 bspChan, UINT32 cfrband, UINT32 cpgLen);
UINT32 cfrChnInfoPrint(UINT32 bspChan);
UINT32 getcfrsta(VOID);
UINT32 cfrgetpar(UINT32 bspChan, UINT32 pos, UINT32 peakFlag, UINT32 workMode);
UINT32 cfrgetpardpd(UINT32 bspChan, UINT32 peakFlag, UINT32 workMode);
UINT32 cfrsetoutmode(UINT32 bspChan, UINT32 mode);
UINT32 cfrgetschem(VOID);
UINT32 cfrsetcpg(UINT32 bspchan, char *fileName, UINT32 vaildLen);
UINT32 cfrsetparcfgfr(UINT32 bspChan, UINT32 freqband, UINT32 frDly, UINT32 symParFlagPer, UINT32 frDivSel);
UINT32 cfrsetpardpdcfgfr(UINT32 bspChan, UINT32 freqband, UINT32 frDly, UINT32 symParFlagPer, UINT32 frDivSel);
UINT32 cfrgetcpgonline(UINT32 bspChan, UINT32 ramType, UINT32 coefMode, UINT32 coefLen);
UINT32 cfrleakpeak(UINT32 bspChan, UINT32 clrFlag);
UINT32 cfrgetcpgonlinegsm(UINT32 bspChan);
UINT32 cfrgetcpgonlineinfo(UINT32 bspChan);
UINT32 cfrgetbbtssicfg(UINT32 bspChan);
UINT32 cfrsample(UINT32 bspChan, UINT32 pos0, UINT32 pos1, UINT32 sampTime, UINT32 trigMode);
UINT32 cfrgettddsw(UINT32 bspChan);
UINT32 cfrgetenergy(VOID);

static struct
{
    CFR_TEST_FUNC pFunc;
    CHAR  *pcCmd;
    CHAR  *pcParaList;
    CHAR  *pcMemo;
} stCfrHelp[] =
{
    {(CFR_TEST_FUNC)cfron, "cfron", "通道号", "打开削峰"},
    {(CFR_TEST_FUNC)cfroff, "cfroff", "通道号", "关闭削峰"},
    {(CFR_TEST_FUNC)cfrsetgate, "cfrsetgate", "通道号,一级门限,二级门限,三级门限", "设置硬削峰门限"},
    {(CFR_TEST_FUNC)cfrgetgate, "cfrgetgate", "通道号", "打印硬削峰门限"},
    {(CFR_TEST_FUNC)cfrsetdelt, "cfrsetdelt", "通道号,一级门限,二级门限,三级门限", "设置削峰筛选门限"},
    {(CFR_TEST_FUNC)cfrgetdelt, "cfrgetdelt", "通道号", "打印削峰筛选门限"},
    {(CFR_TEST_FUNC)cfrsetwin, "cfrsetwin", "通道号,一级窗长,二级窗长,三级窗长", "设置削峰搜索窗长"},
    {(CFR_TEST_FUNC)cfrgetwin, "cfrgetwin", "通道号", "打印削峰搜索窗长"},
    {(CFR_TEST_FUNC)cfrsetwinlevel, "cfrsetwinlevel", "通道号,一级窗长等级,二级窗长等级,三级窗长等级", "设置削峰窗长等级"},
    {(CFR_TEST_FUNC)cfrgetwinlevel, "cfrgetwinlevel", "通道号", "打印削峰窗长等级"},
    {(CFR_TEST_FUNC)cfrgetcpgini, "cfrgetcpgini", "通道号,频段号0/1,cpg有效长度", "打印CPG系数"},
    {(CFR_TEST_FUNC)cfrgetpar, "cfrgetpar", "通道号,Block检测位置( 0：CFR入口,1：CFR出口),检测方式（2:TDD,3:FDD）,峰值监测模式(0：软件立即启动；1：软件启动后，Fr加延时启动，默认为0)", "打印cfr峰均比状态信息"},
    {(CFR_TEST_FUNC)cfrgetpardpd, "cfrgetpardpd", "通道号,检测方式（2:TDD,3:FDD）,峰值监测模式( 0：软件立即启动,1：软件启动后，Fr加延时启动;默认为0)", "打印Dpd峰均比状态信息"},
    {(CFR_TEST_FUNC)cfrChnInfoPrint,"cfrChnInfoPrint"  , "通道号", "打印cfr 通道配置"},
	{(CFR_TEST_FUNC)cfrgetschem, "cfrgetschem", "无入参", "打印削峰主体静态参数配置"},
    {(CFR_TEST_FUNC)cfrsetoutmode, "cfrsetoutmode", "通道号,输出模式:0/1:零/等延时旁路 2:正常输出 3:抵消脉冲模式", "设置削峰输出模式"},
    {(CFR_TEST_FUNC)cfrsetcpg, "cfrsetcpg", "通道号,文件名(双引号包含,路径根目录),cpg有效长度", "离线设置CPG"},
    {(CFR_TEST_FUNC)cfrsetparcfgfr, "cfrsetparcfgfr", "通道号,频段号,延迟值,高电平持续时间(clk),帧头分频", "cfr峰均比检测帧头加延时配置"},
    {(CFR_TEST_FUNC)cfrsetpardpdcfgfr, "cfrsetpardpdcfgfr", "通道号,频段号,延迟值,高电平持续时间(clk),帧头分频(默认0)", "dpd峰均比检测帧头加延时配置"},
    {(CFR_TEST_FUNC)cfrgetcpgonline, "cfrgetcpgonline", "通道号,ram类型,原型系数model,原型系数或cpg系数长度", "获取CPG在线计算相关系数"},
    {(CFR_TEST_FUNC)cfrleakpeak, "cfrleakpeak", "通道号,清零标志(0：不清零 1：清零)", "漏峰个数统计"},
    {(CFR_TEST_FUNC)cfrgetcpgonlinegsm, "cfrgetcpgonlinegsm", "通道号", "获取CPG在线计算gsm有关参数"},
    {(CFR_TEST_FUNC)cfrgetcpgonlineinfo, "cfrgetcpgonlineinfo", "通道号", "获取CPG在线计算参数"},
    {(CFR_TEST_FUNC)cfrgetbbtssicfg, "cfrgetbbtssicfg", "通道号", "获取削峰CPG在线计算BBTSSI相关配置"},
    {(CFR_TEST_FUNC)cfrsample, "cfrsample", "通道号,第一路采数位置,第二路采数位置,采数次数,触发方式", "削峰维测采数"},
    {(CFR_TEST_FUNC)cfrgettddsw, "cfrgettddsw", "通道号", "获取tddsw扩展配置"},
    {(CFR_TEST_FUNC)cfrgetenergy, "cfrgetenergy", "无入参", "获取CFR模块节能初始化配置"},
};

typedef struct tag_cfr_port_par_debug_info
{
    UINT32 avg_pow;           /* 平均功率  */
    UINT32 par;               /* 峰均比   */
    UINT32 parCrest;          /* 峰值峰均比*/
}T_CfrPortParInfo;

typedef struct tag_cfr_0ut_par_debug_info
{
    UINT32 avg_pow;           /* 平均功率  */
    UINT32 par;               /* 峰均比   */
    UINT32 parCrest;          /* 峰值峰均比*/
}T_CfrOutParInfo;

typedef struct tag_par_debug_info
{
    UINT32 avg_pow;           /* 平均功率  */
    UINT32 par;               /* 峰均比   */
    UINT32 parCrest;          /* 峰值峰均比*/
}T_CfrParInfo;

typedef struct tag_dpd_par_debug_info
{
    DOUBLE avg_pow;           /* 平均功率  */
    DOUBLE par;               /* 峰均比   */
    DOUBLE parCrest;          /* 峰值峰均比*/
}T_DpdParInfo;

typedef struct tag_carr_debug_info
{
    UINT32 carrNo;           /* 载波号   */
    UINT32 carrBw;           /* 载波带宽*/
    UINT32 carrRadio;        /* 载波制式 */
    UINT32 freq;             /* 载波下行频点 */
    UINT32 powerMw;          /* 载波基带功率mw*/
}T_CfrDbgCarrInfo;

typedef struct tag_dpd_carr_debug_info
{
    UINT32 carrNo;           /* 载波号   */
    UINT32 carrBw;           /* 载波带宽*/
    UINT32 carrRadio;        /* 载波制式 */
    UINT32 freq;             /* 载波下行频点 */
    UINT32 powerMw;          /* 载波基带功率mw*/
}T_DpdDbgCarrInfo;

typedef struct tag_cfr_debug_info
{
    UINT32 cfrGate[E_CFR_THR_NUM];
    UINT32 cfrWin[E_CFR_THR_NUM];
    UINT32 CfrSwitchSta;
    T_CfrPortParInfo portparInfo;
    T_CfrOutParInfo outparInfo;
    T_CfrDbgCarrInfo carrdbgInfo[BSP_MAX_CARR_NUM];   /*每个频段最大8CARR计算*/
}T_CfrDebugInfo;

typedef struct tag_dpd_debug_info
{
    UINT32 cfrGate[E_CFR_THR_NUM];
    UINT32 cfrWin[E_CFR_THR_NUM];
    UINT32 CfrSwitchSta;
    T_DpdParInfo parInfo;
    T_DpdDbgCarrInfo carrdbgInfo[BSP_MAX_CARR_NUM];   /*每个频段最大8CARR计算*/
}T_DpdDebugInfo;

typedef union tag_Uint32BeFloat
{
    FLOAT fVal;
    UINT32 val;
} Uint32BeFloat;

/**************************************************************************
*                         全局变量定义                                   *
**************************************************************************/
static UINT32 s_cfrCarrNum[CFR_DEBUG_DIF_CHN] = {1, 1, 1, 1, 1, 1, 1, 1};
static UINT32 s_cfrCenterFreq[CFR_DEBUG_DIF_CHN] = {0};

static T_CfrChnInfo s_cfrCarrInfo[CFR_DEBUG_DIF_CHN] = {0};
static T_CfrChnBandInfo s_cfrBandInfo[CFR_DEBUG_DIF_CHN] = {0};
/**************************************************************************
 *                         函数实现
 **************************************************************************/

/*配置cfr 自测函数 后续用配频接口调试*/
/*配置cfr 中频通道载波数*/
static UINT32 cfrsetcarrnum(UINT32 difChn, UINT32 carrNum, UINT32 centerFreq)
{
    UINT32 ulDifChan = 0;
    if (carrNum > CFR_DEBUG_CARR_MAX_NUM)
    {
        carrNum    =   CFR_DEBUG_CARR_MAX_NUM;
    }

    ulDifChan = difChn%CFR_DEBUG_DIF_CHN;

    s_cfrCarrNum[ulDifChan]        = carrNum;
    s_cfrCenterFreq[ulDifChan]     = centerFreq;
    return s_cfrCarrNum[ulDifChan];
}
static UINT32 cfrsetcarrBw(UINT32 difChn, UINT32 carrNo, UINT32 carrBw, UINT32 carrRadio)
{
    UINT32 ulDifChan = 0;
    UINT32 ulCarrNo = 0;
    ulDifChan = difChn%CFR_DEBUG_DIF_CHN;
    ulCarrNo  = carrNo%BSP_MAX_CARR_NUM;
    s_cfrCarrInfo[ulDifChan].carr[ulCarrNo].carrBw    = carrBw;
    s_cfrCarrInfo[ulDifChan].carr[ulCarrNo].carrNo    = carrNo;
    s_cfrCarrInfo[ulDifChan].carr[ulCarrNo].carrRadio = carrRadio;
    return BSP_OK;
}
static UINT32 cfrsetcarrfreq(UINT32 difChn, UINT32 carrNo, UINT32 freq, UINT32 pow)
{
    UINT32 ulDifChan = 0;
    UINT32 ulCarrNo = 0;
    ulDifChan = difChn%CFR_DEBUG_DIF_CHN;
    ulCarrNo  = carrNo%BSP_MAX_CARR_NUM;

    s_cfrCarrInfo[ulDifChan].carr[ulCarrNo].freq      = freq;
    s_cfrCarrInfo[ulDifChan].carr[ulCarrNo].powerMw   = pow; /*传入参数pow单位为W，后续会转化为dbfs*/
    s_cfrCarrInfo[ulDifChan].carr[ulCarrNo].carrFlag  = CFR_CARR_VALID;
    return BSP_OK;
}


static UINT32 cfrcarrinfoupdate(UINT32 difChn)
{
    UINT32 carrLoop = 0;
    UINT32 bandLoop = 0;
    UINT32 carrBandNum = 0;
    INT32  powDbfs  = 0;
    UINT32 ulDifChan = 0;
    /*UINT32 ulCarrNo = 0;*/

    ulDifChan = difChn%CFR_DEBUG_DIF_CHN;

    s_cfrCarrInfo[ulDifChan].centerFreq = s_cfrCenterFreq[ulDifChan];

    for (carrLoop = 0; carrLoop < CFR_DEBUG_CARR_MAX_NUM ; carrLoop++)
    {
        if (s_cfrCarrInfo[ulDifChan].carr[carrLoop].freq != 0)
        {
            s_cfrCarrInfo[ulDifChan].carr[carrLoop].carrFi = s_cfrCarrInfo[ulDifChan].carr[carrLoop].freq - s_cfrCenterFreq[ulDifChan];
        }
    }

    s_cfrBandInfo[ulDifChan].bandNum = 1;
    s_cfrBandInfo[ulDifChan].centerFreq = s_cfrCarrInfo[ulDifChan].centerFreq;

    /*后续增加频段划分规则，目前使用一个频段*/
    for (bandLoop = 0; bandLoop < E_CFR_BAND_MAX ; bandLoop ++)
    {
        s_cfrBandInfo[ulDifChan].bandFreq[E_CFR_BAND0] = s_cfrBandInfo[ulDifChan].centerFreq;
        s_cfrBandInfo[ulDifChan].usedFlag[E_CFR_BAND0] = CFR_BAND_USED;

        for (carrLoop = 0; carrLoop < CFR_DEBUG_CARR_MAX_NUM ; carrLoop ++)
        {
            if (s_cfrCarrInfo[ulDifChan].carr[carrLoop].carrFlag == CFR_CARR_INVALID)
            {
                s_cfrBandInfo[ulDifChan].carrInfo[E_CFR_BAND0][carrLoop].carrNo      = 0xff;
            }
            else
            {
                s_cfrBandInfo[ulDifChan].carrInfo[E_CFR_BAND0][carrLoop].carrNo      = s_cfrCarrInfo[ulDifChan].carr[carrLoop].carrNo;
            }

            s_cfrBandInfo[ulDifChan].carrInfo[E_CFR_BAND0][carrLoop].carrFlag    = s_cfrCarrInfo[ulDifChan].carr[carrLoop].carrFlag;
            s_cfrBandInfo[ulDifChan].carrInfo[E_CFR_BAND0][carrLoop].carrRadio   = s_cfrCarrInfo[ulDifChan].carr[carrLoop].carrRadio;
            s_cfrBandInfo[ulDifChan].carrInfo[E_CFR_BAND0][carrLoop].freq        = s_cfrCarrInfo[ulDifChan].carr[carrLoop].freq;
            s_cfrBandInfo[ulDifChan].carrInfo[E_CFR_BAND0][carrLoop].carrBw      = s_cfrCarrInfo[ulDifChan].carr[carrLoop].carrBw;
            s_cfrBandInfo[ulDifChan].carrInfo[E_CFR_BAND0][carrLoop].carrFi      = s_cfrCarrInfo[ulDifChan].carr[carrLoop].carrFi;
            s_cfrBandInfo[ulDifChan].carrInfo[E_CFR_BAND0][carrLoop].powerMw     = s_cfrCarrInfo[ulDifChan].carr[carrLoop].powerMw;

            if (s_cfrBandInfo[ulDifChan].carrInfo[E_CFR_BAND0][carrLoop].powerMw != 0)
            {
                (void)BspCfrPowDbfs(ulDifChan, s_cfrBandInfo[ulDifChan].carrInfo[E_CFR_BAND0][carrLoop].powerMw, 16, &powDbfs);
                s_cfrBandInfo[ulDifChan].carrInfo[E_CFR_BAND0][carrLoop].powDbfs     = powDbfs;
            }

            carrBandNum ++;
        }

        s_cfrBandInfo[ulDifChan].bandCarrNum[E_CFR_BAND0] = carrBandNum;
    }
    return BSP_OK;
}


UINT32  cfrsetchninfo(UINT32 difChn)
{
    UINT32 retVal = BSP_OK;
    cfrcarrinfoupdate(difChn);
    retVal = BspSetCfrChnInfo(difChn, &s_cfrBandInfo[difChn]);
    return retVal;
}

UINT32 cfrchninfo()
{
    UINT32 retVal = BSP_OK;
    UINT32 difChn = 0;
    BspSetCfrWorkMode(CFR_TEST_MODE);

    for (difChn = 0; difChn < CFR_DEBUG_DIF_CHN; difChn ++)
    {
        retVal = cfrsetchninfo(difChn);
    }

    return retVal;
}



/********************** 调试命令 debug ***************************/

/*****************************************************************************
*  函数名称   : cfron
*  功能描述   : CFR ON
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   :
*  输出参数   : 无
*  返 回 值   :BSP_OK;
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2015-11-28 14:55:24
*----------------------------------------------------------------------------
*/

UINT32 cfron(UINT32 bspChan)
{
    UINT32 retVal = BSP_OK;
    UINT32 difChn = 0;
    UINT32 chipId = 0;
    retVal = BspGetDifInfoByBspChn(bspChan, TX, &chipId, &difChn);
    if (BSP_OK != retVal)
    {
        dbgErr("%s>>bspChan'%d BspGetDifInfoByBspChn Get Error!\n",
           __FUNCTION__, bspChan);
           return BSP_ERROR;
    }
    INPUT_CFRFUNCINIT_CHECK();
    retVal = BspCfrEnable(difChn);
    return retVal;
}

UINT32 cfronall(VOID)
{
    UINT32 retVal = BSP_OK;
    UINT32 difChn = 0;
    UINT32 chipId = 0;
    UINT32 bspChan = 0;
    UINT32 chnNum = 0;

    chnNum = BspGetTxChannel();
    for (bspChan = 0; bspChan < chnNum; bspChan++)
    {
        retVal = BspGetDifInfoByBspChn(bspChan, TX, &chipId, &difChn);
        if (BSP_OK != retVal)
        {
            dbgErr("%s>>bspChan'%d BspGetDifInfoByBspChn Get Error!\n", __FUNCTION__, bspChan);
            return BSP_ERROR;
        }
        INPUT_CFRFUNCINIT_CHECK();
        retVal = BspCfrEnable(difChn);
    }

    return retVal;
}

/*****************************************************************************
*  函数名称   : cfroff
*  功能描述   : CFR OFF
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   :
*  输出参数   : 无
*  返 回 值   :BSP_OK;
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2015-11-28 14:55:24
*----------------------------------------------------------------------------
*/

UINT32 cfroff(UINT32 bspChan)
{
    UINT32 retVal = BSP_OK;
    UINT32 difChn = 0;
    UINT32 chipId = 0;
    retVal = BspGetDifInfoByBspChn(bspChan, TX, &chipId, &difChn);
    if (BSP_OK != retVal)
    {
        dbgErr("%s>>bspChan'%d BspGetDifInfoByBspChn Get Error!\n",
           __FUNCTION__, bspChan);
           return BSP_ERROR;
    }
    INPUT_CFRFUNCINIT_CHECK();
    retVal = BspCfrDisable(difChn);
    return retVal;
}

UINT32 cfroffall(VOID)
{
    UINT32 retVal = BSP_OK;
    UINT32 difChn = 0;
    UINT32 chipId = 0;
    UINT32 bspChan = 0;
    UINT32 chnNum = 0;

    chnNum = BspGetTxChannel();
    for (bspChan = 0; bspChan < chnNum; bspChan++)
    {
        retVal = BspGetDifInfoByBspChn(bspChan, TX, &chipId, &difChn);
        if (BSP_OK != retVal)
        {
            dbgErr("%s>>bspChan'%d BspGetDifInfoByBspChn Get Error!\n",__FUNCTION__, bspChan);
            return BSP_ERROR;
        }
        INPUT_CFRFUNCINIT_CHECK();
        retVal = BspCfrDisable(difChn);
    }

    return retVal;
}

#if 0
UINT32 cfrparaver(VOID)
{
    UINT32 retVal = BSP_OK;
    UINT32 index  = 0;

    if (NULL == cfr_para_version)
    {
        dbgInfo("[%s] cfr_para_version is NULL. \n", __FUNCTION__);
        return BSP_ERROR;
    }
    
    for (index = 0; cfr_para_version[index] != '\0'; index++)
    {
        dbgInfo("%c", cfr_para_version[index]);
    }
    
    return retVal;
}
#endif

/*****************************************************************************
*  函数名称   : cfrsetgate
*  功能描述   : CFR gate
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   :
*  输出参数   : 无
*  返 回 值   :BSP_OK;
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2015-11-28 14:55:24
*----------------------------------------------------------------------------
*/

UINT32 cfrsetgate(UINT32 bspChan, UINT32 cfrGate0, UINT32 cfrGate1, UINT32 cfrGate2)
{
    UINT32 retVal = BSP_OK;
    UINT32 difChn = 0;
    UINT32 chipId = 0;
    UINT32 freqBand = 0;
    UINT32 cfrGate[E_CFR_THR_NUM] = {0};
    retVal = BspGetDifInfoByBspChn(bspChan, TX, &chipId, &difChn);
    if (BSP_OK != retVal)
    {
        dbgErr("%s>>bspChan'%d BspGetDifInfoByBspChn Get Error!\n",
           __FUNCTION__, bspChan);
           return BSP_ERROR;
    }
    INPUT_CFRFUNCINIT_CHECK();
    cfrGate[E_CFR_THR_1ST] = cfrGate0;
    cfrGate[E_CFR_THR_2ND] = cfrGate1;
    cfrGate[E_CFR_THR_3RD] = cfrGate2;
    retVal |= BspHalAdaptSetCfrGate(difChn, freqBand, cfrGate, E_CFR_THR_NUM);
    return retVal;
}
/*****************************************************************************
*  函数名称   : cfrsetdelt
*  功能描述   : CFR Delt
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   :
*  输出参数   : 无
*  返 回 值   :BSP_OK;
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2015-11-28 14:55:24
*----------------------------------------------------------------------------
*/
UINT32 cfrsetdelt(UINT32 bspChan, UINT32 cfrDelt0, UINT32 cfrDelt1, UINT32 cfrDelt2)
{
    UINT32 retVal = BSP_OK;
    UINT32 difChn = 0;
    UINT32 chipId = 0;
    UINT32 freqBand = 0;
    UINT32 cfrDelt[E_CFR_THR_NUM] = {0};
	INPUT_CFRFUNCINIT_CHECK();
    retVal = BspGetDifInfoByBspChn(bspChan, TX, &chipId, &difChn);
    if (BSP_OK != retVal)
    {
        dbgErr("%s>>bspChan'%d BspGetDifInfoByBspChn Get Error!\n",
           __FUNCTION__, bspChan);
           return BSP_ERROR;
    }
    cfrDelt[E_CFR_THR_1ST] = cfrDelt0;
    cfrDelt[E_CFR_THR_2ND] = cfrDelt1;
    cfrDelt[E_CFR_THR_3RD] = cfrDelt2;
	retVal = BspHalAdaptSetCfrDelt(difChn, freqBand, cfrDelt,E_CFR_THR_NUM);
    return retVal;
}
/*****************************************************************************
*  函数名称   : cfrsetwin
*  功能描述   : CFR win
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   :
*  输出参数   : 无
*  返 回 值   :BSP_OK;
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2015-11-28 14:55:24
*----------------------------------------------------------------------------
*/
UINT32 cfrsetwin(UINT32 bspChan, UINT32 cfrWin0, UINT32 cfrWin1, UINT32 cfrWin2)
{
    UINT32 retVal = BSP_OK;
    UINT32 difChn = 0;
    UINT32 chipId = 0;
    UINT32 freqBand = 0;
    UINT32 cfrWin[E_CFR_THR_NUM] = {0};
    retVal = BspGetDifInfoByBspChn(bspChan, TX, &chipId, &difChn);
    if (BSP_OK != retVal)
    {
        dbgErr("%s>>bspChan'%d BspGetDifInfoByBspChn Get Error!\n",
           __FUNCTION__, bspChan);
           return BSP_ERROR;
    }
    INPUT_CFRFUNCINIT_CHECK();
    cfrWin[E_CFR_THR_1ST] = cfrWin0;
    cfrWin[E_CFR_THR_2ND] = cfrWin1;
    cfrWin[E_CFR_THR_3RD] = cfrWin2;
    retVal = BspHalAdaptSetCfrWin(difChn, freqBand, cfrWin,E_CFR_THR_NUM);
    return retVal;
}

/*****************************************************************************
*  函数名称   : cfrsetwinlevel
*  功能描述   : CFR winLevel 设置
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   :
*  输出参数   : 无
*  返 回 值   :BSP_OK;
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2015-11-28 14:55:24
*----------------------------------------------------------------------------
*/
UINT32 cfrsetwinlevel(UINT32 bspChan, UINT32 cfrWinlevel0, UINT32 cfrWinlevel1, UINT32 cfrWinlevel2)
{
    UINT32 retVal = BSP_OK;
    UINT32 difChn = 0;
    UINT32 chipId = 0;
    UINT32 freqBand = 0;
    UINT32 cfrWinLevel[E_CFR_THR_NUM] = {0};
    retVal = BspGetDifInfoByBspChn(bspChan, TX, &chipId, &difChn);
    if (BSP_OK != retVal)
    {
        dbgErr("%s>>bspChan'%d BspGetDifInfoByBspChn Get Error!\n",
           __FUNCTION__, bspChan);
           return BSP_ERROR;
    }
    INPUT_CFRFUNCINIT_CHECK();
    cfrWinLevel[E_CFR_THR_1ST] = cfrWinlevel0;
    cfrWinLevel[E_CFR_THR_2ND] = cfrWinlevel1;
    cfrWinLevel[E_CFR_THR_3RD] = cfrWinlevel2;
    retVal = BspHalAdaptSetCfrWinlevel(difChn, freqBand, cfrWinLevel,E_CFR_THR_NUM);
    return retVal;
}

/*****************************************************************************
*  函数名称   : cfrgetgate
*  功能描述   : CFR gate
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   :
*  输出参数   : 无
*  返 回 值   :BSP_OK;
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2015-11-28 14:55:24
*----------------------------------------------------------------------------
*/

UINT32 cfrgetgate(UINT32 bspChan)
{
    UINT32 retVal = BSP_OK;
    UINT32 difChn = 0;
    UINT32 chipId = 0;
    UINT32 freqBand = 0;
    UINT32 cfrGate[E_CFR_THR_NUM] = {0};
    retVal = BspGetDifInfoByBspChn(bspChan, TX, &chipId, &difChn);
    if (BSP_OK != retVal)
    {
        dbgErr("%s>>bspChan'%d BspGetDifInfoByBspChn Get Error!\n",
           __FUNCTION__, bspChan);
           return BSP_ERROR;
    }
    INPUT_CFRFUNCINIT_CHECK();
    retVal = BspHalAdaptGetCfrGate(difChn, freqBand, cfrGate,E_CFR_THR_NUM);
    RedirPrintf("-----------------------------------------------------------------\n");
    RedirPrintf("%-10s [1st]0x%-6x [2nd]0x%-6x [3rd]0x%-6x \n", "[HEX] CFR_GATE:", cfrGate[E_CFR_THR_1ST], cfrGate[E_CFR_THR_2ND], cfrGate[E_CFR_THR_3RD]);
    RedirPrintf("%-10s [1st]%-8d [2nd]%-8d [3rd]%-8d \n", "[DEC] CFR_GATE:", cfrGate[E_CFR_THR_1ST], cfrGate[E_CFR_THR_2ND], cfrGate[E_CFR_THR_3RD]);
    RedirPrintf("------------------------------------------------------------------\n");
    return retVal;
}

/*****************************************************************************
*  函数名称   : cfrram
*  功能描述   : 配置CFR
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : difChn   - 中频通道
*  输出参数   : 无
*  返 回 值   : BSP_OK  - 成功;其它值为失败
*  其它说明   :配置CFR模块接口，封装后给用于给高层调用。
*             :
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2015-11-28 14:55:24
*----------------------------------------------------------------------------
*/
UINT32 cfrram(UINT32 difChn)
{
    return BSP_OK;
}

/*****************************************************************************
*  函数名称   : cfrauto
*  功能描述   : 配置CFR
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : difChn   - 中频通道
*  输出参数   : 无
*  返 回 值   : BSP_OK  - 成功;其它值为失败
*  其它说明   : 无
*            :
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2015-11-28 14:55:24
*----------------------------------------------------------------------------
*/
UINT32 cfrauto(UINT32 difChn, UINT32 cfrGate0, UINT32 cfrGate1, UINT32 cfrGate2)
{
    /*UINT32 ret = BSP_OK;*/
    cfrsetgate( difChn,  cfrGate0,  cfrGate1,  cfrGate2);
    cfroff(difChn);
    cfrram(difChn);
    cfron(difChn);

    return BSP_OK;
}

/*****************************************************************************
*  函数名称   : cfrgetdelt
*  功能描述   : CFR Delt
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   :
*  输出参数   : 无
*  返 回 值   :BSP_OK;
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2015-11-28 14:55:24
*----------------------------------------------------------------------------
*/
UINT32 cfrgetdelt(UINT32 bspChan)
{
    UINT32 retVal = BSP_OK;
    UINT32 difChn = 0;
    UINT32 chipId = 0;
    UINT32 freqBand = 0;
    UINT32 cfrDelt[E_CFR_THR_NUM] = {0};
    retVal = BspGetDifInfoByBspChn(bspChan, TX, &chipId, &difChn);
    if (BSP_OK != retVal)
    {
        RedirPrintf("%s>>bspChan'%d BspGetDifInfoByBspChn Get Error!\n",
           __FUNCTION__, bspChan);
           return BSP_ERROR;
    }
    INPUT_CFRFUNCINIT_CHECK();
    retVal = BspHalAdaptGetCfrDelt(difChn, freqBand, cfrDelt,E_CFR_THR_NUM);
    RedirPrintf("-----------------------------------------------------------------\n");
    RedirPrintf("%-10s [1st]0x%-6x [2nd]0x%-6x [3rd]0x%-6x \n", "[HEX] CFR_DELT:", cfrDelt[E_CFR_THR_1ST], cfrDelt[E_CFR_THR_2ND], cfrDelt[E_CFR_THR_3RD]);
    RedirPrintf("%-10s [1st]%-8d [2nd]%-8d [3rd]%-8d \n", "[DEC] CFR_DELT:", cfrDelt[E_CFR_THR_1ST], cfrDelt[E_CFR_THR_2ND], cfrDelt[E_CFR_THR_3RD]);
    RedirPrintf("------------------------------------------------------------------\n");
    return retVal;
}
/*****************************************************************************
*  函数名称   : cfrgetwin
*  功能描述   : CFR win
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   :
*  输出参数   : 无
*  返 回 值   :BSP_OK;
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2015-11-28 14:55:24
*----------------------------------------------------------------------------
*/
UINT32 cfrgetwin(UINT32 bspChan)
{
    UINT32 retVal = BSP_OK;
    UINT32 difChn = 0;
    UINT32 chipId = 0;
    UINT32 freqBand = 0;
    UINT32 cfrWin[E_CFR_THR_NUM] = {0};
    retVal = BspGetDifInfoByBspChn(bspChan, TX, &chipId, &difChn);
    if (BSP_OK != retVal)
    {
        dbgErr("%s>>bspChan'%d BspGetDifInfoByBspChn Get Error!\n",
           __FUNCTION__, bspChan);
           return BSP_ERROR;
    }
    INPUT_CFRFUNCINIT_CHECK();
    retVal = BspHalAdaptGetCfrWin(difChn, freqBand, cfrWin,E_CFR_THR_NUM);
    dbgInfo("-----------------------------------------------------------------\n");
    dbgInfo("%-10s [1st]0x%-6x [2nd]0x%-6x [3rd]0x%-6x \n", "[HEX] CFR_WIN:", cfrWin[E_CFR_THR_1ST], cfrWin[E_CFR_THR_2ND], cfrWin[E_CFR_THR_3RD]);
    dbgInfo("%-10s [1st]%-8d [2nd]%-8d [3rd]%-8d \n", "[DEC] CFR_WIN:", cfrWin[E_CFR_THR_1ST], cfrWin[E_CFR_THR_2ND], cfrWin[E_CFR_THR_3RD]);
    dbgInfo("------------------------------------------------------------------\n");
    return retVal;
}

/*****************************************************************************
*  函数名称   : cfrgetwinlevel
*  功能描述   : CFR winlevel打印
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   :
*  输出参数   : 无
*  返 回 值   :BSP_OK;
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2015-11-28 14:55:24
*----------------------------------------------------------------------------
*/
UINT32 cfrgetwinlevel(UINT32 bspChan)
{
    UINT32 retVal = BSP_OK;
    UINT32 difChn = 0;
    UINT32 chipId = 0;
    UINT32 freqBand = 0;
    UINT32 cfrWinLevel[E_CFR_THR_NUM] = {0};
    retVal = BspGetDifInfoByBspChn(bspChan, TX, &chipId, &difChn);
    if (BSP_OK != retVal)
    {
        dbgErr("%s>>bspChan'%d BspGetDifInfoByBspChn Get Error!\n",
           __FUNCTION__, bspChan);
           return BSP_ERROR;
    }
    INPUT_CFRFUNCINIT_CHECK();
    retVal = BspHalAdaptGetCfrWinlevel(difChn, freqBand, cfrWinLevel,E_CFR_THR_NUM);
    dbgInfo("-----------------------------------------------------------------\n");
    dbgInfo("%-10s [1st]0x%-6x [2nd]0x%-6x [3rd]0x%-6x \n", "[HEX] CFR_WIN:", cfrWinLevel[E_CFR_THR_1ST], cfrWinLevel[E_CFR_THR_2ND], cfrWinLevel[E_CFR_THR_3RD]);
    dbgInfo("%-10s [1st]%-8d [2nd]%-8d [3rd]%-8d \n", "[DEC] CFR_WIN:", cfrWinLevel[E_CFR_THR_1ST], cfrWinLevel[E_CFR_THR_2ND], cfrWinLevel[E_CFR_THR_3RD]);
    dbgInfo("------------------------------------------------------------------\n");
    return retVal;
}

/*****************************************************************************
*  函数名称   : cfrcpginfoprint
*  功能描述   : CFR cpg 打印
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   :
*  输出参数   : 无
*  返 回 值   :BSP_OK;
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2015-11-28 14:55:24
*----------------------------------------------------------------------------
*/
UINT32 cfrcpginfoprint(UINT32 addr, INT16 real, INT16 imag)
{
	UINT32 cpgRegVal = 0;

	cpgRegVal = real<<16|imag;
	dbgInfo("CpgAddr[0x%02X] HEX: Real:0x%04X  Imag:0x%04X  |  Addr[%-3d] DEC: Real:%-5d  Imag:%-5d |cpgRegVal:0x%04X\n",
	            addr, (UINT16)real, (UINT16)imag, addr, real, imag,cpgRegVal);

    return BSP_OK;
}

/*****************************************************************************
*  函数名称   : cfrgetcpgini
*  功能描述   : CFR cpg 获取
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   :
*  输出参数   : 无
*  返 回 值   :BSP_OK;
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2015-11-28 14:55:24
*----------------------------------------------------------------------------
*/
UINT32 cfrgetcpgini(UINT32 bspChan, UINT32 cfrband, UINT32 cpgLen)
{
    UINT32 retVal = BSP_OK;
    UINT32 difChn = 0;
    UINT32 chipId = 0;
    UINT32 cfrLutLen = 0;
    INT16  *pReal = NULL;
    INT16  *pImag = NULL;
    UINT32 loop   = 0;

    INPUT_CFRFUNCINIT_CHECK();
    retVal = BspGetDifInfoByBspChn(bspChan, TX, &chipId, &difChn);
    if (BSP_OK != retVal)
    {
        dbgErr("%s>>bspChan'%d BspGetDifInfoByBspChn Get Error!\n",
           __FUNCTION__, bspChan);
           return BSP_ERROR;
    }

    if(cpgLen == 0)
    {
        BspCfrGetCpgVaildLen(difChn, &cfrLutLen);
        if (cfrLutLen == 0)
        {
            dbgInfo("[%s]Cfr Get Cpg Len Error \n", __FUNCTION__);
            cfrLutLen = CFR_CPG_RAM_768;
        }
    }
    else
    {
        cfrLutLen = cpgLen;
    }

    /*  测试是否能消除kw告警 */
    if(cfrLutLen > (UINT32)CFR_CPG_RAM_768)
    {
        dbgInfo("[%s]cpg get len error \n", __FUNCTION__);
        return BSP_ERROR;
    }
    pReal = (INT16 *)malloc(sizeof(INT16) * cfrLutLen);
    if (pReal == NULL)
    {
        dbgInfo("[%s]pReal malloc fail \n", __FUNCTION__);
        return BSP_ERROR;
    }

    pImag = (INT16 *)malloc(sizeof(INT16) * cfrLutLen);
    if (pImag == NULL)
    {
        free(pReal);
        pReal = NULL;
        dbgInfo("[%s]pReal malloc fail \n", __FUNCTION__);
        return BSP_ERROR;
    }

    retVal |= BspCfrDisable(difChn);
    retVal |= CfrGetCpgCfg_CpuCal_IC4_2(difChn, pReal, pImag, cfrLutLen);
    retVal |= BspCfrEnable(difChn);

    for (loop = 0; loop < cfrLutLen; loop ++)
    {

        cfrcpginfoprint(loop, pReal[loop], pImag[loop]);
    }

    free(pReal);
    free(pImag);
    return retVal;
}

/*****************************************************************************
*  函数名称   : getcfrsta
*  功能描述   : 获取CFR状态信息
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : 无
*  输出参数   : 无
*  返 回 值   : BSP_OK  - 成功;其它值为失败
*  其它说明   : 实际无用，高层有调用，写打桩
*             :
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 喻波@2017-10-17 14:55:24
*----------------------------------------------------------------------------
*/
UINT32 getcfrsta(VOID)
{
    return BSP_OK;
}
/**************************************************************************
 * 函数名称: (*)
 * 功能描述: cfr help
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * 修改日期       修改人            修改内容
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 王飞@2015-11-28 14:55:24
 *----------------------------------------------------------------------------
 */

UINT32 cfrhelpprn(VOID)
{
    UINT32 ulLoop;
    dbgInfo("%-6s %-20s %-40s %-20s\n",
            "cmdIdx", "testFunc", "funcParaList", "Memo");

    for (ulLoop = 0; ulLoop < NELEMENTS(stCfrHelp); ulLoop++)
    {
        dbgInfo("%-6d %-20s %-40s %-20s\n", ulLoop + 1,
                stCfrHelp[ulLoop].pcCmd, stCfrHelp[ulLoop].pcParaList,
                stCfrHelp[ulLoop].pcMemo);
    }

    return BSP_OK;
}

UINT32 cfrhelp(UINT32 cmdIdx, LONG p0, LONG p1, LONG p2, LONG p3, LONG p4, LONG p5, LONG p6, LONG p7, LONG p8, LONG p9)
{
    UINT32 ulRet;

    if (cmdIdx > NELEMENTS(stCfrHelp))
    {
        dbgInfo("ERROR!cmdIdx=%d should must be in [1,%d]\n", cmdIdx, NELEMENTS(stCfrHelp));
        return BSP_ERROR;
    }

    if (0 == cmdIdx)
    {
        ulRet = cfrhelpprn();
    }
    else
    {
        ulRet = stCfrHelp[cmdIdx-1].pFunc(p0, p1, p2, p3, p4, p5, p6, p7, p8, p9);
    }

    return ulRet;
}

UINT32 cfrChnInfoPrint(UINT32 bspChan)
{
    T_CfrChnBandInfo *pCfrDifChn = NULL;
    UINT32 bandLoop  = 0;
    UINT32 carrLoop  = 0;
    UINT32 retVal    = BSP_OK;
    UINT32 difChn = 0;
    UINT32 chipId = 0;
    retVal = BspGetDifInfoByBspChn(bspChan, TX, &chipId, &difChn);
    if (BSP_OK != retVal)
    {
        dbgErr("%s>>bspChan'%d BspGetDifInfoByBspChn Get Error!\n",
           __FUNCTION__, bspChan);
           return BSP_ERROR;
    }
    pCfrDifChn = BspGetCfrChnInfo(difChn);
    if (pCfrDifChn == NULL)
    {
        dbgInfo("[%s]Cfr Chn Info NULL \n ", __FUNCTION__);
        return BSP_ERROR;
    }

    dbgInfo("================== Cfr Chn ID %d Info ======================\n\n", difChn);
    dbgInfo("[1]CfrChn\t [2]centerFreq  [3]bandNum\t \n\n");
    dbgInfo("[1]%-6d\t [2]%-10d\t [3]%-7d\t\n\n", difChn, pCfrDifChn->centerFreq, pCfrDifChn->bandNum);
    dbgInfo("================== Cfr Band   Info =========================\n\n");
    dbgInfo("[1]bandId\t [2]bandFreq\t [3]bandCarrNum\t\n");

    for (bandLoop = 0 ; bandLoop < E_CFR_BAND_MAX ; bandLoop ++)
    {
        if (pCfrDifChn->usedFlag[bandLoop] == CFR_BAND_NOT_USED)
        {
            continue;
        }

        dbgInfo("[1]%-6d\t [2]%-8d\t [3]%-11d\t \n", bandLoop, pCfrDifChn->bandFreq[bandLoop], pCfrDifChn->bandCarrNum[bandLoop]);
    }

    dbgInfo("\n");
    dbgInfo("================== Cfr Carr   Info =========================\n\n");
    dbgInfo("[1]CfrNo\t [2]UseF\t [3]radio\t [4]CarrBw\t [5]CfrBand\t [6]carrFreq\t [7]Fi    \t [8]carrPow\t [9]carrDbfs\t [10]carrGi\t \n\n");

    for (bandLoop = 0 ; bandLoop < E_CFR_BAND_MAX ; bandLoop ++)
    {
        for (carrLoop = 0 ; carrLoop < BSP_MAX_CARR_NUM; carrLoop ++)
        {
            dbgInfo("[1]%-5d\t [2]%-4d\t [3]0x%-3x\t [4]%-6d\t [5]%-7d\t [6]%-8d\t [7]%-6d\t [8]%-7d\t [9]%-7d\t [10]%-7d\t\n",
                    pCfrDifChn->carrInfo[bandLoop][carrLoop].carrNo,
                    pCfrDifChn->carrInfo[bandLoop][carrLoop].carrFlag,
                    pCfrDifChn->carrInfo[bandLoop][carrLoop].carrRadio,
                    pCfrDifChn->carrInfo[bandLoop][carrLoop].carrBw,
                    bandLoop,
                    pCfrDifChn->carrInfo[bandLoop][carrLoop].freq,
                    pCfrDifChn->carrInfo[bandLoop][carrLoop].carrFi,
                    pCfrDifChn->carrInfo[bandLoop][carrLoop].powerMw,
                    pCfrDifChn->carrInfo[bandLoop][carrLoop].powDbfs,
                    pCfrDifChn->carrInfo[bandLoop][carrLoop].carrGi
                   );
        }
    }

    return BSP_OK;
}

UINT32 cfrsetoutmode(UINT32 bspChan, UINT32 mode)
{
    UINT32 retVal = BSP_OK;
    UINT32 difChn = 0;
    UINT32 chipId = 0;
    retVal = BspGetDifInfoByBspChn(bspChan, TX, &chipId, &difChn);
    if (BSP_OK != retVal)
    {
        dbgErr("%s>>bspChan'%d BspGetDifInfoByBspChn Get Error!\n",
           __FUNCTION__, bspChan);
           return BSP_ERROR;
    }
	retVal = BspSetCfrOutMode(difChn,mode);
    return retVal;
}

UINT32 BspGetDpdParBitcut(UINT32 *DpdBitCut)
{
    UINT32 retVal = BSP_OK;
    UINT32 parBitCut = 0;
    UINT32 parBitCutId = 0;
    T_BspHalAdaptDpdParCommPara dpdParPara = {0};

    INPUT_POINTER_CHECK(DpdBitCut);
    retVal = BspGetDpdParPara(&dpdParPara);
    parBitCutId = dpdParPara.uiBitcutId; 

    switch(parBitCutId)
    {
        case 0:
        {
            parBitCut = 12;
            break;
        }
        case 1:
        {
            parBitCut = 8;
            break;
        }
        case 2:
        {
            parBitCut = 4;
            break;
        }
        case 3:
        {
            parBitCut = 0;
            break;
        }
        default:
        {
            return BSP_ERROR;
        }
    }

    *DpdBitCut = parBitCut;

    return retVal;
}

UINT32 BspGetCfrParBitcut(UINT32 *CfrBitCut)
{
    UINT32 retVal = BSP_OK;
    UINT32 parBitCut = 0;
    UINT32 parBitCutId = 0;
    T_BspHalAdaptCfrParCommPara cfrParPara = {0};

    INPUT_POINTER_CHECK(CfrBitCut);
    retVal = BspGetCfrParPara(&cfrParPara);
    parBitCutId = cfrParPara.uiBitcutId; 

    switch(parBitCutId)
    {
        case 0:
        {
            parBitCut = 12;
            break;
        }
        case 1:
        {
            parBitCut = 8;
            break;
        }
        case 2:
        {
            parBitCut = 4;
            break;
        }
        case 3:
        {
            parBitCut = 0;
            break;
        }
        default:
        {
            return BSP_ERROR;
        }
    }

    *CfrBitCut = parBitCut;

    return retVal;
}

/*****************************************************************************
*  函数名称   : cfrgetcpgonline
*  功能描述   : 获取CPG在线计算相关系数
*  输入参数   : bspChan : BSP通道号
               ramType ：控制操作与CPG计算有关的ram类型。0：Kn; 1:cpg原型系数; 2:cpg系数
               coefMode ：原型系数model，只有当uiRamType为2时有效，取值范围1-5
               coefLen ：原型系数长度或者cpg系数长度
*  输出参数   : 无
*  返 回 值   : BSP_OK  - 成功;其它值为失败
*  其它说明   : 无
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 徐利波@2022-06-21 
*----------------------------------------------------------------------------
*/
UINT32 cfrgetcpgonline(UINT32 bspChan, UINT32 ramType, UINT32 coefMode, UINT32 coefLen)
{
    UINT32 retVal   = BSP_OK;
    UINT32 chipId   = 0;
    UINT32 difChn   = 0;

    retVal = BspGetDifInfoByBspChn(bspChan, TX, &chipId, &difChn);
    if (BSP_OK != retVal)
    {
        dbgErr("%s>>bspChan'%d BspGetDifInfoByBspChn Get Error!\n",
           __FUNCTION__, bspChan);
           return BSP_ERROR;
    }

    retVal = BspHalAdaptCfrGetCpgOnLine(difChn, ramType, coefMode, coefLen);

    return retVal;
}

/*****************************************************************************
*  函数名称   : cfrleakpeak
*  功能描述   : 漏峰个数统计
*  输入参数   : bspChan : BSP通道号
               clrFlag ：清零标志。0：不清零 1：清零
*  输出参数   : 无
*  返 回 值   : BSP_OK  - 成功;其它值为失败
*  其它说明   : 漏峰清零高电平有效，先配1不清零，20ms后配0清0；然后开启漏峰统计使能，获取漏峰个数上报值
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 徐利波@2022-06-21 
*----------------------------------------------------------------------------
*/
UINT32 cfrleakpeak(UINT32 bspChan, UINT32 clrFlag)
{
    UINT32 retVal   = BSP_OK;
    UINT32 chipId   = 0;
    UINT32 difChn   = 0;

    retVal = BspGetDifInfoByBspChn(bspChan, TX, &chipId, &difChn);
    if (BSP_OK != retVal)
    {
        dbgErr("%s>>bspChan'%d BspGetDifInfoByBspChn Get Error!\n",
           __FUNCTION__, bspChan);
           return BSP_ERROR;
    }

    retVal = BspHalAdaptCfrLeakPeak(difChn, clrFlag);

    return retVal;
}

/*****************************************************************************
*  函数名称   : cfrgetcpgonlinegsm
*  功能描述   : 获取CPG在线计算gsm有关参数
*  输入参数   : bspChan : BSP通道号
*  输出参数   : 无
*  返 回 值   : BSP_OK  - 成功;其它值为失败
*  其它说明   : 无
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 徐利波@2022-06-21 
*----------------------------------------------------------------------------
*/
UINT32 cfrgetcpgonlinegsm(UINT32 bspChan)
{
    UINT32 retVal   = BSP_OK;
    UINT32 chipId   = 0;
    UINT32 difChn   = 0;

    retVal = BspGetDifInfoByBspChn(bspChan, TX, &chipId, &difChn);
    if (BSP_OK != retVal)
    {
        dbgErr("%s>>bspChan'%d BspGetDifInfoByBspChn Get Error!\n",
           __FUNCTION__, bspChan);
           return BSP_ERROR;
    }

    retVal = BspHalAdaptCfrGetCpgOnLineGsm(difChn);

    return retVal;
}

/*****************************************************************************
*  函数名称   : cfrgetcpgonlineinfo
*  功能描述   : 获取CPG在线计算参数
*  输入参数   : bspChan : BSP通道号
*  输出参数   : 无
*  返 回 值   : BSP_OK  - 成功;其它值为失败
*  其它说明   : 无
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 徐利波@2022-06-21 
*----------------------------------------------------------------------------
*/
UINT32 cfrgetcpgonlineinfo(UINT32 bspChan)
{
    UINT32 retVal   = BSP_OK;
    UINT32 chipId   = 0;
    UINT32 difChn   = 0;

    retVal = BspGetDifInfoByBspChn(bspChan, TX, &chipId, &difChn);
    if (BSP_OK != retVal)
    {
        dbgErr("%s>>bspChan'%d BspGetDifInfoByBspChn Get Error!\n",
           __FUNCTION__, bspChan);
           return BSP_ERROR;
    }

    retVal |= BspHalAdaptCfrGetCpgOnLineStatic(difChn);
    retVal |= BspHalAdaptCfrGetCpgOnLineStage(difChn);
    retVal |= BspHalAdaptCfrGetCpgOnLineCarrer(difChn);

    return retVal;
}

/*****************************************************************************
*  函数名称   : cfrgetbbtssicfg
*  功能描述   : 获取削峰CPG在线计算BBTSSI相关配置
*  输入参数   : bspChan : BSP通道号
*  输出参数   : 无
*  返 回 值   : BSP_OK  - 成功;其它值为失败
*  其它说明   : 无
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 徐利波@2022-06-21 
*----------------------------------------------------------------------------
*/
UINT32 cfrgetbbtssicfg(UINT32 bspChan)
{
    UINT32 retVal   = BSP_OK;
    UINT32 chipId   = 0;
    UINT32 difChn   = 0;

    retVal = BspGetDifInfoByBspChn(bspChan, TX, &chipId, &difChn);
    if (BSP_OK != retVal)
    {
        dbgErr("%s>>bspChan'%d BspGetDifInfoByBspChn Get Error!\n",
           __FUNCTION__, bspChan);
           return BSP_ERROR;
    }

    retVal = BspHalAdaptGetBbTssiCfg(difChn);

    return retVal;
}

/*****************************************************************************
*  函数名称   : cfrsample
*  功能描述   : 削峰维测采数
*  输入参数   : bspChan : BSP通道号
               pos0 : 第一路各输出采数位置。0:cdc0输出,1:k0_gain,2:cfr自厂家,3:gain2,4:异厂家,5:自异合路
               pos1 : 第二路各输出采数位置。0:cdc0输出,1:k0_gain,2:cfr自厂家,3:gain2,4:异厂家,5:自异合路
               sampTime : 采数次数
               trigMode : 触发方式配置 0：盲采 1：帧头+延时触发写 2：帧头+延时触发停
*  输出参数   : 无
*  返 回 值   : BSP_OK  - 成功;其它值为失败
*  其它说明   : 无
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 徐利波@2022-06-21 
*----------------------------------------------------------------------------
*/
UINT32 cfrsample(UINT32 bspChan, UINT32 pos0, UINT32 pos1, UINT32 sampTime, UINT32 trigMode)
{
    UINT32 retVal   = BSP_OK;
    UINT32 chipId   = 0;
    UINT32 difChn   = 0;

    retVal = BspGetDifInfoByBspChn(bspChan, TX, &chipId, &difChn);
    if (BSP_OK != retVal)
    {
        dbgErr("%s>>bspChan'%d BspGetDifInfoByBspChn Get Error!\n",
           __FUNCTION__, bspChan);
           return BSP_ERROR;
    }

    retVal = BspHalAdaptCfrGetSample(difChn, pos0, pos1, sampTime, trigMode);

    return retVal;
}

/*****************************************************************************
*  函数名称   : cfrsetparcfgfr
*  功能描述   : 削峰block峰均比检测帧头加延时配置
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : bspChan : BSP通道号
               freqband ： 频段号
               frDly : fr延迟值
               symParFlagPer ： fr + dly 后，高电平持续时间，单位为clk，26bit无符号数。
               frDivSel ：帧头分频，默认配成0。0：fr；1：fr/2；2：fr/4；3：fr/8。
*  输出参数   : 无
*  返 回 值   : BSP_OK  - 成功;其它值为失败
*  其它说明   : 无
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 徐利波@2022-04-11 17:05:06
*----------------------------------------------------------------------------
*/
UINT32 cfrsetparcfgfr(UINT32 bspChan, UINT32 freqband, UINT32 frDly, UINT32 symParFlagPer, UINT32 frDivSel)
{
    UINT32 retVal   = BSP_OK;
    UINT32 chipId   = 0;
    UINT32 difChn   = 0;

    retVal = BspGetDifInfoByBspChn(bspChan, TX, &chipId, &difChn);
    if (BSP_OK != retVal)
    {
        dbgErr("%s>>bspChan'%d BspGetDifInfoByBspChn Get Error!\n",
           __FUNCTION__, bspChan);
           return BSP_ERROR;
    }

    retVal = BspHalAdaptSetCfrParCfgFr(difChn, freqband, frDly, symParFlagPer, frDivSel);
    if (retVal != BSP_OK)
    {
        dbgErr("[%s]Set Cfr Par Fr Error \n",__FUNCTION__);
        return BSP_ERROR;
    }

    return retVal;
}

/*****************************************************************************
*  函数名称   : cfrsetpardpdcfgfr
*  功能描述   : DPD block峰均比检测帧头加延时配置
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : bspChan : BSP通道号
               freqband ： 频段号
               frDly : fr延迟值
               symParFlagPer ： fr + dly 后，高电平持续时间，单位为clk，26bit无符号数。
               frDivSel ：帧头分频，默认配成0。0：fr；1：fr/2；2：fr/4；3：fr/8。
*  输出参数   : 无
*  返 回 值   : BSP_OK  - 成功;其它值为失败
*  其它说明   : 无
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 徐利波@2022-05-05 14:07:36
*----------------------------------------------------------------------------
*/
UINT32 cfrsetpardpdcfgfr(UINT32 bspChan, UINT32 freqband, UINT32 frDly, UINT32 symParFlagPer, UINT32 frDivSel)
{
    UINT32 retVal   = BSP_OK;
    UINT32 chipId   = 0;
    UINT32 difChn   = 0;

    retVal = BspGetDifInfoByBspChn(bspChan, TX, &chipId, &difChn);
    if (BSP_OK != retVal)
    {
        dbgErr("%s>>bspChan'%d BspGetDifInfoByBspChn Get Error!\n",
           __FUNCTION__, bspChan);
           return BSP_ERROR;
    }

    retVal = BspHalAdaptSetDpdParCfgFr(difChn, freqband, frDly, symParFlagPer, frDivSel);
    if (retVal != BSP_OK)
    {
        dbgErr("[%s]Set Dpd Par Fr Error \n",__FUNCTION__);
        return BSP_ERROR;
    }

    return retVal;
}

/*****************************************************************************
*  函数名称   : cfrgetpar
*  功能描述   : 获取CFR状态信息
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : bspChan : BSP通道号
*              pos : Block检测位置，0：CFR入口；1：CFR出口
               peakFlag ： 检测方式。0：自检包络；1：自检包络+TDD；2：TDD；3：常高，FDD机型设为3。
               workMode ：峰值监测模式。0：软件立即启动；1：软件启动后，Fr加延时启动。默认为0。
*  输出参数   : 无
*  返 回 值   : BSP_OK  - 成功;其它值为失败
*  其它说明   : 若需要将接口中 workMode 配置为1，在此之前，需要先执行检测帧头加延时配置接口
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 徐利波@2022-04-11 17:05:06
*----------------------------------------------------------------------------
*/
UINT32 cfrgetpar(UINT32 bspChan, UINT32 pos, UINT32 peakFlag, UINT32 workMode)
{
    UINT32 retVal   = BSP_OK;
    UINT32 difChn   = 0;
    UINT32 loop     = 0;
    UINT32 len      = 32;
    UINT32 chipId   = 0;
    UINT32 bitCut   = 0;
    UINT32 freqBand = 0;
    DOUBLE P3       = 0.0;
	DOUBLE P2       = 0.0;
	DOUBLE P1       = 0.0;
	DOUBLE avg_pow  = 0.0;
	DOUBLE par      = 0.0;
	DOUBLE peak     = 0.0;
    DOUBLE gate_db  = 0.0;
    UINT32 cfrGate[E_CFR_THR_NUM] = {0};
    UINT32 *cfrParData = NULL; 
    T_BspHalAdaptDifCommCfrPara cfrCommPara = {0};

    retVal = BspGetDifInfoByBspChn(bspChan, TX, &chipId, &difChn);
    if (BSP_OK != retVal)
    {
        dbgErr("%s>>bspChan'%d BspGetDifInfoByBspChn Get Error!\n",
           __FUNCTION__, bspChan);
           return BSP_ERROR;
    }

    retVal = BspHalAdaptGetCfrGate(difChn, freqBand, cfrGate,E_CFR_THR_NUM);

    if (0 == peakFlag)
    {
        retVal = BspGetCfrCommPara(&cfrCommPara);
        if (retVal != BSP_OK)
        {
            dbgErr("%s>>get CfrCommPara error!\n",__FUNCTION__);
            return retVal;
        }

        if (CFR_CHAN_TDD_DX == cfrCommPara.uiCfrPeakMode[difChn])
        {
            peakFlag = 1;
        }

        if (CFR_CHAN_FDD_DX == cfrCommPara.uiCfrPeakMode[difChn])
        {
            peakFlag = 0;
        }
    }
    
    retVal |= BspGetCfrParBitcut(&bitCut);
    if(retVal != BSP_OK)
    {
        dbgErr("%s>>get par bitcut error!\n",__FUNCTION__);
        return retVal;
    }
    
    cfrParData = (UINT32 *)malloc(sizeof(UINT32) * len*3);
    if (cfrParData == NULL)
    {
        dbgInfo("[%s]pReal malloc fail \n", __FUNCTION__);
        return BSP_ERROR;
    }
    memset(cfrParData,0,sizeof(UINT32)*len*3);

    retVal = BspHalAdaptCfrGetPar(difChn, freqBand, peakFlag, workMode, pos, cfrParData);
    if (retVal != BSP_OK)
    {
        dbgErr("[%s]Get Cfr Par Error \n",__FUNCTION__);
        free(cfrParData);
        cfrParData = NULL;
        return BSP_ERROR;
    }

    for(loop = 0; loop < len; loop++)
    {
        P1 += cfrParData[loop];
        P2  = max(P2,cfrParData[len+loop]);
        P3 +=  cfrParData[loop+len+len];
    }

    P1 = P1/((DOUBLE)len);
    P3 = P3/((DOUBLE)len);

    P1 = (abs(P1 - 0.0) < EPSINON) ? 0.0 : 10 * log10((DOUBLE)(P1));
    P2 = (abs(P2 - 0.0) < EPSINON) ? 0.0 : 10 * log10((DOUBLE)(P2));
    P3 = (abs(P3 - 0.0) < EPSINON) ? 0.0 : 10 * log10((DOUBLE)(P3));
    dbgInfo("difChn:%d P1:%f P2:%f P3:%f\n",difChn,P1,P2,P3);

    gate_db = (DOUBLE)(20 * log10(cfrGate[E_CFR_THR_1ST]/1.6465));
    avg_pow = P1 + ((DOUBLE)(bitCut*10))*log10(2);
    par     = P3 - P1;
    peak    = P2 - P1;	
    dbgInfo("avg_power: %f \n",avg_pow);
    dbgInfo("par@0.01%%: %f \n",par);
    dbgInfo("par@crest: %f \n",peak);
    dbgInfo("par@abs: %f \n",avg_pow + peak);
    dbgInfo("gate_db: %f \n",gate_db);
    dbgInfo("abs-gate_db: %f \n",avg_pow + peak - gate_db);

    free(cfrParData);

    return retVal;
}

/*****************************************************************************
*  函数名称   : cfrgetpardpd
*  功能描述   : 获取DPD峰均比状态信息
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : bspChan : BSP通道号
               peakFlag ： 检测方式。0：自检包络；1：自检包络+TDD；2：TDD；3：常高，FDD机型设为3。
               workMode ：峰值监测模式。0：软件立即启动；1：软件启动后，Fr加延时启动。默认为0。
*  输出参数   : 无
*  返 回 值   : BSP_OK  - 成功;其它值为失败
*  其它说明   : 若需要将接口中 workMode 配置为1，在此之前，需要先执行检测帧头加延时配置接口
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 徐利波@2022-05-05 14:14:36
*----------------------------------------------------------------------------
*/
UINT32 cfrgetpardpd(UINT32 bspChan, UINT32 peakFlag, UINT32 workMode)
{
    UINT32 retVal   = BSP_OK;
    UINT32 difChn   = 0;
    UINT32 loop     = 0;
    UINT32 len      = 32;
    UINT32 chipId   = 0;
    UINT32 bitCut   = 0;
    UINT32 freqBand = 0;
    DOUBLE P3       = 0.0;
	DOUBLE P2       = 0.0;
	DOUBLE P1       = 0.0;
	DOUBLE avg_pow  = 0.0;
	DOUBLE par      = 0.0;
	DOUBLE peak     = 0.0;
    DOUBLE gate_db  = 0.0;
    UINT32 cfrGate[E_CFR_THR_NUM] = {0};
    UINT32 *cfrParData = NULL; 
    T_BspHalAdaptDifCommCfrPara cfrCommPara = {0};

    retVal = BspGetDifInfoByBspChn(bspChan, TX, &chipId, &difChn);
    if (BSP_OK != retVal)
    {
        dbgErr("%s>>bspChan'%d BspGetDifInfoByBspChn Get Error!\n",
           __FUNCTION__, bspChan);
           return BSP_ERROR;
    }
    
    retVal = BspHalAdaptGetCfrGate(difChn, freqBand, cfrGate,E_CFR_THR_NUM);

    if (0 == peakFlag)
    {
        retVal = BspGetCfrCommPara(&cfrCommPara);
        if (retVal != BSP_OK)
        {
            dbgErr("%s>>get CfrCommPara error!\n",__FUNCTION__);
            return retVal;
        } 

        if (CFR_CHAN_TDD_DX == cfrCommPara.uiCfrPeakMode[difChn])
        {
            peakFlag = 1;
        }

        if (CFR_CHAN_FDD_DX == cfrCommPara.uiCfrPeakMode[difChn])
        {
            peakFlag = 0;
        }
    }

    retVal |= BspGetDpdParBitcut(&bitCut);
    if(retVal != BSP_OK)
    {
        dbgErr("%s>>get par bitcut error!\n",__FUNCTION__);
        return retVal;
    }
    
    cfrParData = (UINT32 *)malloc(sizeof(UINT32) * len*3);
    if (cfrParData == NULL)
    {
        dbgInfo("[%s]pReal malloc fail \n", __FUNCTION__);
        return BSP_ERROR;
    }
    memset(cfrParData,0,sizeof(UINT32)*len*3);

    retVal = BspHalAdaptDpdGetPar(difChn, freqBand, peakFlag, workMode, cfrParData);
    if (retVal != BSP_OK)
    {
        dbgErr("[%s]Get Dpd Par Error \n",__FUNCTION__);
        free(cfrParData);
        cfrParData = NULL;
        return BSP_ERROR;
    }

    for(loop = 0; loop < len; loop++)
    {
        P1 += cfrParData[loop];
        P2  = max(P2,cfrParData[len+loop]);
        P3 +=  cfrParData[loop+len+len];
    }

    P1 = P1/((DOUBLE)len);
    P3 = P3/((DOUBLE)len);

    P1 = (abs(P1 - 0.0) < EPSINON) ? 0.0 : 10 * log10((DOUBLE)(P1));
    P2 = (abs(P2 - 0.0) < EPSINON) ? 0.0 : 10 * log10((DOUBLE)(P2));
    P3 = (abs(P3 - 0.0) < EPSINON) ? 0.0 : 10 * log10((DOUBLE)(P3));
    dbgInfo("chn'%d P1'%f P2'%f P3'%f\n",difChn,P1,P2,P3);

    gate_db = (DOUBLE)(20 * log10(cfrGate[E_CFR_THR_1ST]/1.6465));
    avg_pow = P1 + ((DOUBLE)(bitCut*10))*log10(2);
    par     = P3 - P1;
    peak    = P2 - P1;
    dbgInfo("avg_power: %f \n",avg_pow);
    dbgInfo("par@0.01%%: %f \n",par);
    dbgInfo("par@crest: %f \n",peak);
    dbgInfo("par@abs: %f \n",avg_pow + peak);
    dbgInfo("gate_db: %f \n",gate_db);
    dbgInfo("abs-gate_db: %f \n",avg_pow + peak - gate_db);

    free(cfrParData);

    return retVal;
}

UINT32 BspGetCfrParDbgInfo(UINT32 bspChan, UINT32 pos, UINT32 peakFlag, UINT32 workMode, T_CfrParInfo *pCfrParInfo)
{
    UINT32 retVal = BSP_OK;
    UINT32 difChn = 0;
    UINT32 loop = 0;
    UINT32 len = 32;
    UINT32 chipId = 0;
    UINT32 bitCut = 0;
    UINT32 freqBand = 0;
    DOUBLE P3 = 0.0;
    DOUBLE P2 = 0.0;
    DOUBLE P1 = 0.0;
    UINT32 *cfrParData = NULL;

    INPUT_POINTER_CHECK(pCfrParInfo);
    retVal = BspGetDifInfoByBspChn(bspChan, TX, &chipId, &difChn);
    if (BSP_OK != retVal)
    {
        dbgErr("%s>>bspChan'%d BspGetDifInfoByBspChn Get Error!\n",__FUNCTION__, bspChan);
           return BSP_ERROR;
    }

    retVal |= BspGetCfrParBitcut(&bitCut);
    if(retVal != BSP_OK)
    {
        dbgErr("%s>>get par bitcut error!\n",__FUNCTION__);
        return retVal;
    }

    cfrParData = (UINT32 *)malloc(sizeof(UINT32) * len*3);
    if (cfrParData == NULL)
    {
        dbgErr("[%s]pReal malloc fail \n",__FUNCTION__);
        return BSP_ERROR;
    }

    memset(cfrParData,0,sizeof(UINT32) * len*3);

    retVal = BspHalAdaptCfrGetPar(difChn, freqBand, peakFlag, workMode, pos, cfrParData);
    if (retVal != BSP_OK)
    {
        dbgErr("[%s]Get Cfr Par Error \n",__FUNCTION__);
        free(cfrParData);
        cfrParData = NULL;
        return BSP_ERROR;
    }

    for(loop = 0; loop < len; loop++)
    {
        P1 += cfrParData[loop];
        P2 = max(P2,cfrParData[len+loop]);
        P3 += cfrParData[loop+len+len];
    }

    if (len != BSP_OK)
    {
        P1 = P1/((DOUBLE)len);
        P3 = P3/((DOUBLE)len);
    }
    else
    {
        dbgErr("[%s]Get Cfr Par Error \n",__FUNCTION__);
        free(cfrParData);
        return BSP_ERROR;
    }

    if(P1 > 0)
    {
        P1 = 10 * log10((DOUBLE)(P1));
    }
    else
    {
        dbgErr("[%s]Get Cfr Par Error \n",__FUNCTION__);
        free(cfrParData);
        cfrParData = NULL;
        return BSP_ERROR;
    }
    if(P2 > 0)
    {
        P2 = 10 * log10((DOUBLE)(P2));
    }
    else
    {
        dbgErr("[%s]Get Cfr Par Error \n",__FUNCTION__);
        free(cfrParData);
        cfrParData = NULL;
        return BSP_ERROR;
    }
    if(P3 > 0)
    {
        P3 = 10 * log10((DOUBLE)(P3));
    }
    else
    {
        dbgErr("[%s]Get Cfr Par Error \n",__FUNCTION__);
        free(cfrParData);
        cfrParData = NULL;
        return BSP_ERROR;
    }

    dbgInfoEx("chn'%d P1'%f P2'%f P3'%f\n",difChn, P1, P2, P3);
    pCfrParInfo->avg_pow = (UINT32)(P1 + ((DOUBLE)(bitCut*10))*log10(2));
    pCfrParInfo->par = (UINT32)(P3 - P1);
    pCfrParInfo->parCrest = (UINT32)(P2 - P1);

    free(cfrParData);
    cfrParData = NULL;

    return retVal;
}

UINT32 BspGetDpdParDbgInfo(UINT32 bspChan, UINT32 peakFlag, UINT32 workMode, T_DpdParInfo *pCfrParInfo)
{
    UINT32 retVal = BSP_OK;
    UINT32 difChn = 0;
    UINT32 loop = 0;
    UINT32 len = 32;
    UINT32 chipId = 0;
    UINT32 bitCut = 0;
    UINT32 freqBand = 0;
    DOUBLE P3 = 0.0;
    DOUBLE P2 = 0.0;
    DOUBLE P1 = 0.0;
    UINT32 *cfrParData = NULL;

    INPUT_POINTER_CHECK(pCfrParInfo);
    retVal = BspGetDifInfoByBspChn(bspChan, TX, &chipId, &difChn);
    if (BSP_OK != retVal)
    {
        dbgErr("%s>>bspChan'%d BspGetDifInfoByBspChn Get Error!\n",__FUNCTION__, bspChan);
           return BSP_ERROR;
    }

    retVal |= BspGetDpdParBitcut(&bitCut);
    if(retVal != BSP_OK)
    {
        dbgErr("%s>>get par bitcut error!\n",__FUNCTION__);
        return retVal;
    }

    cfrParData = (UINT32 *)malloc(sizeof(UINT32) * len*3);
    if (cfrParData == NULL)
    {
        dbgErr("[%s]pReal malloc fail \n",__FUNCTION__);
        return BSP_ERROR;
    }

    memset(cfrParData,0,sizeof(UINT32) * len*3);

    retVal = BspHalAdaptDpdGetPar(difChn, freqBand, peakFlag, workMode, cfrParData);
    if (retVal != BSP_OK)
    {
        dbgErr("[%s]Get Dpd Par Error \n",__FUNCTION__);
        free(cfrParData);
        cfrParData = NULL;
        return BSP_ERROR;
    }

    for(loop = 0; loop < len; loop++)
    {
        P1 += cfrParData[loop];
        P2 = max(P2,cfrParData[len+loop]);
        P3 += cfrParData[loop+len+len];
    }

    if (len != BSP_OK)
    {
        P1 = P1/((DOUBLE)len);
        P3 = P3/((DOUBLE)len);
    }
    else
    {
        dbgErr("[%s]Get Dpd Par Error \n",__FUNCTION__);
        free(cfrParData);
        return BSP_ERROR;
    }

    if(P1 > 0)
    {
        P1 = 10 * log10((DOUBLE)(P1));
    }
    else
    {
        dbgErr("[%s]Get Dpd Par Error \n",__FUNCTION__);
        free(cfrParData);
        cfrParData = NULL;
        return BSP_ERROR;
    }
    if(P2 > 0)
    {
        P2 = 10 * log10((DOUBLE)(P2));
    }
    else
    {
        dbgErr("[%s]Get Dpd Par Error \n",__FUNCTION__);
        free(cfrParData);
        cfrParData = NULL;
        return BSP_ERROR;
    }
    if(P3 > 0)
    {
        P3 = 10 * log10((DOUBLE)(P3));
    }
    else
    {
        dbgErr("[%s]Get Dpd Par Error \n",__FUNCTION__);
        free(cfrParData);
        cfrParData = NULL;
        return BSP_ERROR;
    }

    dbgInfoEx("chn'%d P1'%f P2'%f P3'%f\n",difChn, P1, P2, P3);
    pCfrParInfo->avg_pow = P1 + ((DOUBLE)(bitCut*10))*log10(2);
    pCfrParInfo->par = P3 - P1;
    pCfrParInfo->parCrest = P2 - P1;

    free(cfrParData);
    cfrParData = NULL;

    return retVal;
}

UINT32 cfrgetschem(VOID)
{
    UINT32 retVal = BSP_OK;
    UINT32 difChn = 0;
    UINT32 chipId = 0;
    UINT32 bspChan = 0;
    T_BspHalAdaptDifCommCfrPara cfrCommPara = {0};

    retVal = BspGetCfrCommPara(&cfrCommPara);
    if (retVal != BSP_OK)
    {
        dbgErr("%s>>get CfrCommPara error!\n",__FUNCTION__);
        return retVal;
    }

    dbgInfo("[0]bspChan [1]difChn [2]双工方式 [3]级数 [4]采样率 [5]时钟 [6]上插倍数 [7]相数 [8]等延时标志 [9]最大半长 [10]旁路模式 [11]切输出保护 [12]最大cpg长度 [13]主备表切换保护 [14]软硬计算标志 [15]门限来源 [16]门限索引来源\n");
    for (bspChan = 0; bspChan < BspGetTxBspChanNum(); bspChan++)  //TX
    {
        retVal = BspGetDifInfoByBspChn(bspChan, TX, &chipId, &difChn);
        if (BSP_OK != retVal)
        {
            dbgErr("%s>>bspChan'%d BspGetDifInfoByBspChn Get Error!\n",
               __FUNCTION__, bspChan);
               return BSP_ERROR;
        }

        dbgInfo("[0]%d  ",bspChan);
        dbgInfo("[1]%d  ",difChn);
        dbgInfo("[2]%d  ",cfrCommPara.uiCfrPeakMode[difChn]);
        dbgInfo("[3]%d  ",cfrCommPara.uiCfrGrade[difChn]);
        dbgInfo("[4]%d  ",cfrCommPara.uiCfrSample[difChn]);
        dbgInfo("[5]%d  ",cfrCommPara.uiCfrClk[difChn]);
        dbgInfo("[6]%d  ",cfrCommPara.uiInter[difChn]);
        dbgInfo("[7]%d  ",cfrCommPara.uiCpgPhase[difChn]);
        dbgInfo("[8]%d  ",cfrCommPara.uiDelayEqualFlag[difChn]);
        dbgInfo("[9]%d  ",cfrCommPara.uiCpgCoefLenHalfMax[difChn]);
        dbgInfo("[10]%d  ",cfrCommPara.uiCfrBypassMode[difChn]);
        dbgInfo("[11]%d  ",cfrCommPara.uiCfrProtectMode[difChn]);
        dbgInfo("[12]%d  ",cfrCommPara.uiCpgLen[difChn]);
        dbgInfo("[13]%d  ",cfrCommPara.uiCpgMsLutProtect[difChn]);
        dbgInfo("[14]%d  ",cfrCommPara.uiCpgMode[difChn]);
        dbgInfo("[15]%d  ",cfrCommPara.uiThrSel[difChn]);
        dbgInfo("[16]%d  ",cfrCommPara.uiDlpreEpld[difChn]);
        dbgInfo("\n");
    }

    return BSP_OK;
}

/*****************************************************************************
 *  函数名称   : cfrsetcpg
 *  功能描述   : cpg系数配置
 *  读全局变量 : 无
 *  写全局变量 : 无
 *  输入参数   : 无
 *  输出参数   : pSem     - 信号量指针
 *  返 回 值   : BSP_OK, 无异常; 否则异常
 *  其它说明   :
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
*----------------------------------------------------------------------------*/
UINT32 cfrsetcpg(UINT32 bspchan, char *fileName, UINT32 vaildLen)
{
    UINT32 ulRetVal = BSP_OK;
    UINT32 filelen = 0;
    UINT32 ulChipId  = 0;
    UINT32 ulDifChnl = 0;
    UINT32 loop = 0;
    UINT32 num = 0;
    UINT32 freqBand = 0;
    FILE   *fp = NULL;
    char   lineData[32] = {0};
    UINT32 cpgDate[CFR_CPG_RAM_768] = {0};

    INPUT_POINTER_CHECK(fileName);

    ulRetVal = BspGetDifInfoByBspChn(bspchan, TX, &ulChipId, &ulDifChnl);
    if (BSP_OK != ulRetVal)
    {
        dbgErr("%s>>BspChnl'%d DifInfoByBspChn Get Error!\n", __FUNCTION__, bspchan);
        return BSP_ERROR;
    }

    if (BSP_ERROR == (filelen = BspGetFileLen(fileName)))
    {
        dbgErr("Get file [%s] content Length failed Err\n", fileName);
        return NULL;
    }
    dbgInfo("get file filelen is %d\n",filelen);

    if((fp = fopen(fileName,"r")) == NULL)
    {
        dbgErr("Error: file [%s] name too short or file not exist\n", fileName);
        return NULL;
    }

    while (!feof(fp) && fgets(lineData,sizeof(lineData)-1,fp) != NULL)
    {
        lineData[31] = '\0';
        if(num < CFR_CPG_RAM_768)
        {
            cpgDate[num] = strtoul(lineData,0,0);
            memset(lineData,0,sizeof(lineData));
            num++;
        }
        else
        {
            num++;
            memset(lineData,0,sizeof(lineData));
        }
        
    }

    if(num > CFR_CPG_RAM_768)
    {
    
        (void)fclose(fp);
        dbgErr("date num'%d is over load!\n",num);
        return BSP_ERROR;
    }
    dbgInfo("date num is %d\n",num);
    for(loop = 0; loop < CFR_CPG_RAM_768; loop++)
    {
        dbgInfoEx("[%d]:0x%04X\n",loop,cpgDate[loop]);
    }
    ulRetVal  = BspHalAdaptCfrSetCpgTblCfg(ulDifChnl, freqBand, cpgDate, vaildLen);
    (void)fclose(fp);
    return ulRetVal;
}

UINT32 ChangeUint32ToBeFloat(UINT32 *data)
{
    Uint32BeFloat change = {0};

    INPUT_POINTER_CHECK(data);
    //coverity[cert_flp36_c_violation:SUPPRESS]
    change.fVal = (FLOAT)(*data);
    change.val = htonl(change.val);
    memcpy_s(data, sizeof(UINT32), &(change.val), sizeof(UINT32));

    return BSP_OK;
}

UINT32 BspGetCfrDiagnosisInfo(UINT32 bspChan, UINT32 pos,UINT32 peakFlag, UINT32 workMode, T_CfrDebugInfo *pCfrDbgInfo)
{
    UINT32 carrLoop  = 0;
    UINT32 retVal = BSP_OK;
    UINT32 difChn = 0;
    UINT32 chipId = 0;
    UINT32 CfrOnOff = 0;
    UINT32 bandLoop = 0;
    T_CfrChnBandInfo *pCfrDifChn = NULL;
    T_CfrParInfo CfrParInfo = {0};
    UINT32 cfrGate[E_CFR_THR_NUM] = {0};
    UINT32 cfrWin[E_CFR_THR_NUM] = {0};


    retVal = BspGetDifInfoByBspChn(bspChan, TX, &chipId, &difChn);
    if (BSP_OK != retVal)
    {
        dbgErr("%s>>bspChan'%d BspGetDifInfoByBspChn Get Error!\n",__FUNCTION__, bspChan);
        return BSP_ERROR;
    }
    pCfrDifChn = BspGetCfrChnInfo(difChn);
    if (pCfrDifChn == NULL)
    {
        dbgErr("[%s]Cfr Chn Info NULL \n ",__FUNCTION__);
        return BSP_ERROR;
    }

    for (bandLoop = 0 ; bandLoop < E_CFR_BAND_MAX ; bandLoop ++)
    {
        for (carrLoop = 0 ; carrLoop < BSP_MAX_CARR_NUM; carrLoop ++)
        {
         pCfrDbgInfo->carrdbgInfo[carrLoop].carrNo = pCfrDifChn->carrInfo[bandLoop][carrLoop].carrNo;
         pCfrDbgInfo->carrdbgInfo[carrLoop].carrBw = pCfrDifChn->carrInfo[bandLoop][carrLoop].carrBw;
         pCfrDbgInfo->carrdbgInfo[carrLoop].carrRadio = pCfrDifChn->carrInfo[bandLoop][carrLoop].carrRadio;
         pCfrDbgInfo->carrdbgInfo[carrLoop].freq = pCfrDifChn->carrInfo[bandLoop][carrLoop].freq;
         pCfrDbgInfo->carrdbgInfo[carrLoop].powerMw = pCfrDifChn->carrInfo[bandLoop][carrLoop].powerMw;
            dbgInfoEx("[1]%d\t [2]%d\t  [3]%d\t [4]%d\t [5]%d\t\n",
                    pCfrDbgInfo->carrdbgInfo[carrLoop].carrNo,
                    pCfrDbgInfo->carrdbgInfo[carrLoop].carrBw,
                    pCfrDbgInfo->carrdbgInfo[carrLoop].carrRadio,
                    pCfrDbgInfo->carrdbgInfo[carrLoop].freq,
                    pCfrDbgInfo->carrdbgInfo[carrLoop].powerMw);
        }
    }

    BspHalAdaptGetCfrGate(difChn, bandLoop, cfrGate, E_CFR_THR_NUM);
    pCfrDbgInfo->cfrGate[E_CFR_THR_1ST] = cfrGate[E_CFR_THR_1ST];
    pCfrDbgInfo->cfrGate[E_CFR_THR_2ND] = cfrGate[E_CFR_THR_2ND];
    pCfrDbgInfo->cfrGate[E_CFR_THR_3RD] = cfrGate[E_CFR_THR_3RD];
    dbgInfoEx("%-10s [1st]0x%-6x [2nd]0x%-6x [3rd]0x%-6x \n", "[HEX] CFR_GATE:", pCfrDbgInfo->cfrGate[E_CFR_THR_1ST], pCfrDbgInfo->cfrGate[E_CFR_THR_2ND], pCfrDbgInfo->cfrGate[E_CFR_THR_3RD]);
    dbgInfoEx("%-10s [1st]%-8d [2nd]%-8d [3rd]%-8d \n", "[DEC] CFR_GATE:", pCfrDbgInfo->cfrGate[E_CFR_THR_1ST], pCfrDbgInfo->cfrGate[E_CFR_THR_2ND], pCfrDbgInfo->cfrGate[E_CFR_THR_3RD]);

    BspHalAdaptGetCfrWin(difChn, bandLoop, cfrWin, E_CFR_THR_NUM);
    pCfrDbgInfo->cfrWin[E_CFR_THR_1ST] = cfrWin[E_CFR_THR_1ST];
    pCfrDbgInfo->cfrWin[E_CFR_THR_2ND] = cfrWin[E_CFR_THR_2ND];
    pCfrDbgInfo->cfrWin[E_CFR_THR_3RD] = cfrWin[E_CFR_THR_3RD];
    dbgInfoEx("%-10s [1st]0x%-6x [2nd]0x%-6x [3rd]0x%-6x \n", "[HEX] CFR_WIN:", pCfrDbgInfo->cfrWin[E_CFR_THR_1ST], pCfrDbgInfo->cfrWin[E_CFR_THR_2ND], pCfrDbgInfo->cfrWin[E_CFR_THR_3RD]);
    dbgInfoEx("%-10s [1st]%-8d [2nd]%-8d [3rd]%-8d \n", "[DEC] CFR_WIN:", pCfrDbgInfo->cfrWin[E_CFR_THR_1ST], pCfrDbgInfo->cfrWin[E_CFR_THR_2ND], pCfrDbgInfo->cfrWin[E_CFR_THR_3RD]);


    BspGetCfrParDbgInfo(bspChan, 0, peakFlag, workMode, &CfrParInfo);
    pCfrDbgInfo->portparInfo.avg_pow = CfrParInfo.avg_pow;
    pCfrDbgInfo->portparInfo.par = CfrParInfo.par;
    pCfrDbgInfo->portparInfo.parCrest = CfrParInfo.parCrest;
    dbgInfoEx("avg_power: %d\n",pCfrDbgInfo->portparInfo.avg_pow);
    dbgInfoEx("par@0.01%%: %d\n",pCfrDbgInfo->outparInfo.par);
    dbgInfoEx("par@crest: %d\n",pCfrDbgInfo->portparInfo.parCrest);

    BspGetCfrParDbgInfo(bspChan, 1, peakFlag, workMode, &CfrParInfo);
    pCfrDbgInfo->outparInfo.avg_pow = CfrParInfo.avg_pow;
    pCfrDbgInfo->outparInfo.par = CfrParInfo.par;
    pCfrDbgInfo->outparInfo.parCrest = CfrParInfo.parCrest;
    dbgInfoEx("avg_power: %d\n",pCfrDbgInfo->outparInfo.avg_pow);
    dbgInfoEx("par@0.01%%: %d\n",pCfrDbgInfo->outparInfo.par);
    dbgInfoEx("par@crest: %d\n",pCfrDbgInfo->outparInfo.parCrest);

    BspHalAdaptGetCfrSwitch(difChn, &CfrOnOff);
    dbgInfoEx("%s>> CfrOnOff:%d\n", __FUNCTION__, CfrOnOff);
    pCfrDbgInfo->CfrSwitchSta = CfrOnOff;
    dbgInfoEx("%s>> CfrSwitchSta:%d\n", __FUNCTION__, pCfrDbgInfo->CfrSwitchSta);

    return BSP_OK;
}

UINT32 BspWrCfrDiagnosisInfoToFile(VOID)
{
    UINT32 chanNum  = 0;
    UINT32 difChan  = 0;
    UINT32 cfrSwitch  = 0;
    UINT32 retVal = BSP_OK;
    UINT32 bspChan  = 0;
    UINT32 ret = BSP_OK;
    INT32 iRet = BSP_OK;
    FILE *fp = NULL;
    INT32 fclsRet = 0;
    T_CfrDebugInfo CfrDbgInfo = {0};
    const char *pFilePath1 = "/cfrinfo_OFF.bin";
    const char *pFilePath2 = "/cfrinfo_ON.bin";

    retVal = BspHalAdaptGetCfrSwitch(difChan, &cfrSwitch);
    if(BSP_OK != retVal)
    {
        dbgErr("%s>>cHalApiGetCfrSwitch Get status Error!\n",__FUNCTION__);
        return BSP_ERROR;
    }
    if(cfrSwitch == 0)
    {
        iRet |= fopen_s(&fp, pFilePath1, "wb+");
    }
    else
    {
        iRet |= fopen_s(&fp, pFilePath2, "wb+");
    }
    FOPEN_S_CHECK(iRet);
    INPUT_POINTER_CHECK(fp);
    chanNum = BspGetTxChannel();
    for (bspChan = 0; bspChan < chanNum; bspChan++)
    {
        BspGetCfrDiagnosisInfo(bspChan, 0, 0, 0, &CfrDbgInfo);
        ret = fwrite(&CfrDbgInfo, 1, sizeof(T_CfrDebugInfo), fp);
        if(ret < sizeof(T_CfrDebugInfo))
        {
            dbgErr("<%s>: Write file error!\n",__FUNCTION__);
            fclsRet = fclose(fp);
            FCLOSE_CHECK(fclsRet);
            return BSP_ERROR;
        }
    }
    fclsRet = fclose(fp);
    FCLOSE_CHECK(fclsRet);

    return BSP_OK;
}

UINT32 cfrgettddsw(UINT32 bspChan)
{
    UINT32 retVal    = BSP_OK;
    UINT32 difChn = 0;
    UINT32 chipId = 0;
    retVal = BspGetDifInfoByBspChn(bspChan, TX, &chipId, &difChn);
    if (BSP_OK != retVal)
    {
        dbgErr("%s>>bspChan'%d Get DifInfo Error!\n",
           __FUNCTION__, bspChan);
           return BSP_ERROR;
    }

    retVal = BspHalAdaptCfrGetTddsw(difChn);

    return BSP_OK;
}

UINT32 cfrgetenergy(VOID)
{
    UINT32 retVal = BSP_OK;

    retVal = BspHalAdaptCfrGetEnergy();

    return retVal;
}

UINT32 cfrprnon(VOID)
{
    exprnadd("BspCfrClrHwCpgRam");
    exprnadd("BspCfrSetCpgPara");
    exprnadd("BspInitCfrGatePara");
    exprnadd("BspSelectCfrGatePara");
    exprnadd("BspCfrJudgeCpgMode");
    exprnadd("BspCfrSetDelay");
    exprnadd("BspCfrSetCpgLen");
    exprnadd("BspCfrSetCpgPara_CpuCal");
    exprnadd("BspCfrSetCpgPara_HwCal");
    exprnadd("BspCfrDssSetCpuCpgCfg");
    exprnadd("BspCfrCpgInit_CpuCal");
    exprnadd("BspCfrDssSetHwCpgCfg");
    exprnadd("BspCfrSetHwCpgCfg");
    exprnadd("BspSetUmtsCpgCoef");
    exprnadd("BspCfrSetCpgParaCpuCalByRadio");
    exprnadd("BspCfrSetUmtsCpgPara_HwCal");
    exprnadd("BspRefreshCfrCpgTbl");
    exprnadd("BspCfrSetDssCarrInfo");
    exprnadd("BspSetCfrGateCoef");
    exprnadd("BspCfrGetCarrGi");
    exprnadd("BspGetRefreshCpgPowFlag");
    exprnadd("BspGetDssCarrPow");
    exprnadd("BspCfrCarrJudgeDss");
    exprnadd("BspGetDssCarrCfgPow");
    exprnadd("BspDssPowforSameFreqBw");
    exprnadd("BspGetCfrAdjacentCpgBw");
    exprnadd("BspUpdateUsableCpgBw");
    exprnadd("BspJudgeCarrFilter");
    exprnadd("BspCfrInitCarrDssMap");
    return BSP_OK;
}


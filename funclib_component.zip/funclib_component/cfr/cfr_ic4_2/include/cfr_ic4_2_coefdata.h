/*****************************************************************************
* 版权所有(C) 2021,  ZTE Corp. ZXSDR-RRU Platform BSP
*----------------------------------------------------------------------------
* 模 块 名 : CFR
* 文件名称 : cfr_ic4_2_coefdata.h
* 文件标识 : {[N/A]}
* 内容摘要 : 本文件主要提供DPDIC4.2削峰模块下cpg以及滤波器系数的参数信息
* 注意事项 : 无
* 作    者 : 徐利波10307448
* 创建日期 : 2022-02-17
* 当前版本 : Ver1.0
*----------------------------------------------------------------------------
* 变更记录 :
*   
* $记录1
* 变 更 单: $0000000(N/A)
* 责 任 人: 徐利波10307448
* 修改日戳: 2022-02-17
* 变更说明: 创建文件
*----------------------------------------------------------------------------
*/

#ifndef FUNCLIB_cfr_ic4_2_COEFDATA_H_INCLUDED
#define FUNCLIB_cfr_ic4_2_COEFDATA_H_INCLUDED

#ifdef __cplusplus
extern "C" {
#endif

#include "bsppub.h"
#include "cfrcommon.h"
/**************************************************************************
 *                        宏定义                                              
 **************************************************************************/


/**************************************************************************
*                         数据类型                                       *
**************************************************************************/


/**************************************************************************
 *                         函数接口
 **************************************************************************/

UINT32 CfrCpgCoefTblInit_IC4_2(UINT32 fsRate,T_CfrCpgPara *pCpgPara, UINT32 cpgTblLen);
UINT32 CfrFactorTblInit_IC4_2(UINT32 fsRate, T_CfrWeiFactor *pCfrWeiFactor, UINT32 cfrFactorTblLen);
UINT32 BspGetWeiCfrFactor_IC4_2(UINT32 factorRate, T_CfrWeiFactor *pWeiCfrFactor);
/*
UINT32 BspCfrHbf0ParaChange(INT32 *pCoef);
UINT32 BspCfrHbf1ParaChange(INT32 *pCoef);

*/
UINT32 BspCfrHbfParaInitAll(VOID);
UINT32 BspCfrHbfParaInit(UINT32 difChn);
UINT32 BspGetCfrCpgCoef_IC4_2(UINT32 difChn,UINT32 cfrBw,UINT32 rate,T_CfrCpgPara *pCpgPara);
UINT32 cfrcpgcoefprn(UINT32 carrRadio, UINT32 carrBw,UINT32 cpgFs);

#ifdef __cplusplus
}
#endif
#endif //FUNCLIB_CFR_FPGA_H_INCLUDED


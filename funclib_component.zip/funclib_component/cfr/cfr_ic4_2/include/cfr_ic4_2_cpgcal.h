/*****************************************************************************
* 版权所有(C) 2021,  ZTE Corp. ZXSDR-RRU Platform BSP
*----------------------------------------------------------------------------
* 模 块 名 : CFR
* 文件名称 : cfr_ic4_2_cpgcal.h
* 文件标识 : {[N/A]}
* 内容摘要 : 本文件主要提供DPDIC4.2削峰模块CPG系数计算相关
* 注意事项 : 无
* 作    者 : 徐利波10307448
* 创建日期 : 2022-02-17
* 当前版本 : Ver1.0
*----------------------------------------------------------------------------
* 变更记录 :
*   
* $记录1
* 变 更 单: $0000000(N/A)
* 责 任 人: 徐利波10307448
* 修改日戳: 2022-02-17
* 变更说明: 创建文件
*----------------------------------------------------------------------------
*/

#ifndef FUNCLIB_CFR_CPGCPU_CAL_H_INCLUDED
#define FUNCLIB_CFR_CPGCPU_CAL_H_INCLUDED
#define IC_DATA_INVALID   (UINT32)0xFFFFFFFF

#define IC_FLAG_USED     (UINT32)1
#define IC_FLAG_NOTUSED   IC_DATA_INVALID

#ifdef __cplusplus
extern "C" {
#endif

#include "bsppub.h"
#include "cfrcommon.h"
#include "funccommon_chncfg.h"

/**************************************************************************
 *                        宏定义                                              
 **************************************************************************/
#define CPG_COEF_LEN_HALF_MAX_768      768  /* 削峰CPG系数最大半长768 */

/**************************************************************************
*                         数据类型                                       *
**************************************************************************/

typedef struct tag_ic_cfr_cpg_band_data
{
    INT32 *pCpgReal;
    INT32 *pCpgImag;
    UINT32 cpgLen;
    INT32 *pCoef;
    UINT32 cpgVaildLen;
    UINT32 flag;
}T_IcCfrCpgBandData;

typedef struct tag_cfr_cpg_cpu_data
{
	T_IcCfrCpgBandData cfrBand[E_CFR_BAND_MAX];
	UINT32 cfrBandNum;
}T_IcCfrCpgCpuCalData;

typedef struct _T_DSS_CFRCARRINFO{
    UINT32 carrNoNew;
    UINT32 carrDssFlag;//1:不重叠;2:重叠
    UINT32 carrCAFlag[2];//数组索引:carrDssFlag:0的，索引只有0表示当前载波:carrDssFlag为1:(0:重叠载波的前一个制式的描述;1:重叠载波的后一个制式的描述);数组的含义0:不聚合;1,2,3表示聚合载波的索引
    UINT32 carrNoOld[2];
    UINT32 carrRadio[2];
}T_DSS_CFRCARRINFO;

typedef struct _T_DSS_CARRBANDINFO{	
	T_DSS_CFRCARRINFO tCarrInfo[BSP_MAX_CARR_NUM];
	UINT32 uCarrNum;
}T_DSS_CARRBANDINFO;

typedef struct _T_DSS_CARRBINFO{
	T_DSS_CARRBANDINFO tCarrInfo[2];
	UINT32 uBandNum;
}T_DSS_CARRCHNINFO;

enum CARR_CA_STATUS_
{
	CARR_IS_NOT_AGGREGATION = 0,
	CARR_IS_AGGREGATION = 1,
};

enum CARR_OVERLAP_STATUS_
{
	CARR_NOT_OVERLAP = 1,
	CARR_OVERLAP = 2,
};

/**************************************************************************
 *                         函数接口
 **************************************************************************/
UINT32 BspCfrCpgCfg_CpuCal(UINT32 difChn);
UINT32 BspCfrCpgInit_CpuCal(UINT32 difChn);
UINT32 BspCfrSetHwCpgCfg(UINT32 difChn);
UINT32 BspGetCfrCarrPowInfo(UINT32 uChn,UINT32	uBandId, UINT32 uCarrNo, UINT32 uCarrMode, UINT32 uCarrBw, UINT32 *pCarrPowMw);
UINT32 BspUpdateCfrCarrInfo(UINT32 uChn, UINT32* pCarrNo, T_RruBandCfgInfo* pCarrCfg, T_RruBandCfgInfo* pOutCarrCfg, UINT32 *pOutCarrNum, UINT32 *pProtocol);
UINT32 BspCfrCpgDataMemApply(VOID);
UINT32 BspCfrGetCpgVaildLen(UINT32 difChn, UINT32 *vaildlen);
UINT32 CfrGetCpgCfg_CpuCal_IC4_2(UINT32 difChn,INT16 *pCpgReal,INT16 * pCpgImag,UINT32 cfrLutLen);
UINT32 BspCfrCpgGetGiTempMax(UINT32 difChn, UINT32 umtsBw, T_CfrChnBandInfo *pChnInfo, DOUBLE *giTempMax);
UINT32 BspCfrCpgGetWei(UINT32 cfrFs, UINT32 carrRadio, DOUBLE *wei);
UINT32 BspCfrDataSave_CpuCal(UINT32 difChn, UINT32 band, DOUBLE *pCpgReal, DOUBLE *pCpgImag , UINT32 dataNum, DOUBLE sumBandGK,UINT32 vaildMaxLen);
UINT32 BspCfrSetBandNum(UINT32 difChn,UINT32 cfrBandNum);
UINT32 BspCfrGetCarrGi(UINT32 difChn, UINT32 carrNo, UINT32 carrRadio, DOUBLE giTemp, DOUBLE giTempMax, DOUBLE *pGi);
UINT32 BspCfrSetCpgParaCpuCalByRadio(UINT32 difChn, UINT32 ulCarrId, UINT32 radio, UINT32 bw);
UINT32 BspCfrSetUmtsCpgPara_HwCal(UINT32 difChn, UINT32 ulcarrNo, UINT32 umtsBw);
UINT32 BspCfrSetSideFilterCpgPara_HwCal(UINT32 difChn, UINT32 ulCarrId, UINT32 radioMode, UINT32 bandwidth);
UINT32 BspJudgeCarrIdAndRadio(UINT32 ulCarrId, UINT32 carrNo, UINT32 carrRadio, UINT32 radio);
INT32 BspUpdateCarrBwByFilterCpg(UINT32 difChn, UINT32 carrNo, UINT32 carrRadio, INT32 *fi, UINT32 *cpgCoefBw);
/*
UINT32 showdsscfrcarrinfo(UINT32 uChn);
UINT32 testdsscfrcarrinfo(UINT32 uChn);
UINT32 BspUpdateCfrCarrInfoBandCheckBw(UINT32 uChn, UINT32 uCarrNum, T_RruDifBandInfo* pDifCfg, T_RruDifBandInfo* pDifOut, UINT32* pCarrout);
UINT32 printfcpgsoftsave(UINT32 difChn);
UINT32 BspGetCfrBandMaxPow(UINT32 difChnl, UINT32 bandId, INT32 *pCarrMaxPow);
UINT32 testltecaflag(UINT32 uMode, UINT32 uBw);
*/

#ifdef __cplusplus
}
#endif
#endif //FUNCLIB_CFR_CPGCPU_CAL_H_INCLUDED

/*****************************************************************************
* 版权所有(C) 2021,  ZTE Corp. ZXSDR-RRU Platform BSP
*----------------------------------------------------------------------------
* 模 块 名 : CFR
* 文件名称 : cfr_ic4_2.h
* 文件标识 : {[N/A]}
* 内容摘要 : 本文件主要提供DPDIC4.2的CFR模块配置功能
* 注意事项 : 无
* 作    者 : 徐利波10307448
* 创建日期 : 2022-02-17
* 当前版本 : Ver1.0
*----------------------------------------------------------------------------
* 变更记录 :
*   
* $记录1
* 变 更 单: $0000000(N/A)
* 责 任 人: 徐利波10307448
* 修改日戳: 2022-02-17
* 变更说明: 创建文件
*----------------------------------------------------------------------------
*/

#ifndef FUNCLIB_cfr_ic4_2_H_INCLUDED
#define FUNCLIB_cfr_ic4_2_H_INCLUDED

#ifdef __cplusplus
extern "C" {
#endif

#include "bsppub.h"
#include "cfrcommon.h"
//#include "ichaladapt_ic4_2.h"
#include "ichaladapt_cfr_ic4_2.h"
/**************************************************************************
 *                        宏定义                                              
 **************************************************************************/
#define CFR_PI                  3.1415926535
#define CFR_DSS_CPG_VALID_LEN      (241)
#define CFR_EQDLY_BYPASS        1
#define CFR_ZERODLY_BYPASS      0
#define CFR_EQ_DLY              1
#define CFR_ZERO_DLY            0
#define IC_CFR_ON                   (UINT32)0x1
#define IC_CFR_OFF                  (UINT32)0x0
#define IC_CFR_OUTPUT_MODE   		(UINT32)0x2  /* CFR 使能 */
#define IC_CFR_ORG_IQ_DATA_MODE     (UINT32)0x1  /* 等延时旁路 */
#define IC_CFR_INPUT_IQ_DATA_MODE   (UINT32)0x0  /* 零延时旁路 */
#define CFR_GATE_INIT_CFG_FREQ           1  /* 配频中的门限初始化 */
#define CFR_GATE_INIT_CFG_CFR            0  /* 配CFR中的门限初始化 */
#define CFR_CHN_EXIST_LV                 1  /* 削峰通道中存在LTE或NR制式载波 */
#define CFR_CHN_NO_EXIST_LV              0  /* 削峰通道中不存在LTE或NR制式载波 */
#define CFR_CPG_PHASE_1                  1  /* 削峰CPG相数，单相 */
#define CFR_CPG_PHASE_2                  2  /* 削峰CPG相数，2phase */
#define CFR_CPG_PHASE_4                  4  /* 削峰CPG相数，4phase */
#define CFR_CHAN_TDD_DX                  2  /* 削峰通道为TDD双工 */
#define CFR_CHAN_FDD_DX                  3  /* 削峰通道为FDD双工 */
#define CFR_CPG_HW_CAL_START             0  /* 削峰CPG系数硬件计算开始 */
#define CFR_CPG_HW_CAL_STOP              1  /* 削峰CPG系数硬件计算暂停 */
#define CFR_CHN_CHANGE                   1  /* 削峰通道发生制式或带宽改配，需要更新用于计算CPG的原型系数 */
#define CFR_CHN_NO_CHANGE                0  /* 削峰通道未发生制式或带宽改配，不需要更新用于计算CPG的原型系数 */
#define CFR_SIGNAL_FROM_CPU              1  /* 信号来源于CPU */
#define CFR_SIGNAL_FROM_DLPRE            0  /* 信号来源于dlpre */
#define CFR_CHAN_MAX_NUM             IC_CHAN_MAX_NUM        /* 削峰中频最大通道数 */
#define SET_BIT(data, pos)           (data |= (1 << pos))   /* 将位置为pos的比特置1，pos取值从0开始 */
#define CLEAR_BIT(data, pos)         (data &= ~(1 << pos))  /* 将位置为pos的比特置0，pos取值从0开始 */
#define GET_BIT(data, pos)           ((data >> pos) & 1)    /* 获取位置为pos的比特值，pos取值从0开始 */
#define REVERSE_BIT(data, pos)       (GET_BIT(data, pos) ? CLEAR_BIT(data, pos) : SET_BIT(data, pos))    /* 将位置为pos的比特取反 */
#define WRITE_BIT(data, pos, flag)   (flag ? (SET_BIT(data, pos)) : (CLEAR_BIT(data, pos)))  /* 将位置为pos的比特置1或0，pos取值从0开始 */
#define CFR_CARR_EXIST_DSS               1  /* 削峰通道内两载波为频谱共享 */
#define CFR_CARR_NO_EXIST_DSS            0  /* 削峰通道内两载波不是频谱共享关系 */
#define CFR_START_GET_DSS_GROUP          1  /* 开始寻找一组具有DSS关系的载波 */
#define CFR_STOP_GET_DSS_GROUP           0  /* 未开始寻找一组具有DSS关系的载波 */
#define CFR_CHN_DSS_GROUP_MAX_NUM        4  /* 单通道内载波具有DSS关系的最大组数 */
#define CFR_DSS_MERGE_MIN_BW            800 /* DSS合并载波处理时，判断为频谱共享的最小重叠带宽：0.8M */
#define CFR_CPG_LEN_HAL_MAX_GNB         765 /* FDD机型 radiocfg.txt 中含有G或NB制式时的最大CPG半长 */
#define CFR_CPG_LEN_HAL_MAX_ULV         509 /* FDD机型 radiocfg.txt 中不包含G和NB制式时的最大CPG半长 */
#define RADIO_SUPPORT_GSM_OR_NB         (1) /* 整机无线制式支持 GSM 或 NB */
#define BSP_REFRESH_CPG_BY_APP_POW  ((UINT32)0)  /* CFR采用载波配置功率刷新CPG */
#define BSP_REFRESH_CPG_BY_REAL_POW ((UINT32)1)  /* CFR采用实时bbtssi载波功率刷新CPG */
#define FAIL_TO_GET_CPG_RAM_STATUS      (2)  /* 判断是否超出cpg能力时失败 */
#define EXCEED_CPG_RAM                  (1)  /* 超出cpg能力标志 */
#define NOT_EXCEED_CPG_RAM              (0)  /* 没有超出cpg能力 */
#define CHECK_CHAN_VALID(bspChan, chanNum, maxArrayChanNum)                             \
{                                                                                       \
    chanNum = (chanNum < maxArrayChanNum) ? chanNum : maxArrayChanNum;                  \
    if (bspChan >= chanNum)                                                             \
    {                                                                                   \
        dbgErr("%s, bspChan=%d is invalid! \n", __FUNCTION__, bspChan);                 \
        return;                                                                         \
    }                                                                                   \
}
/**************************************************************************
*                         数据类型                                       *
**************************************************************************/

/*CFR动态参数TDD*/
typedef struct tagCfrDynPara_TDD
{
    FLOAT lowbound;  //IBW/OBW下边界
    FLOAT upbound;  //IBW/OBW上边界
    UINT32 cfrgate[E_CFR_THR_NUM];      //削峰门限，E_CFR_THR_NUM为3，均按3级填满，实际2级削峰，最后一级可补0
    UINT32 cfrwin[E_CFR_THR_NUM] ;      //削峰窗长
    UINT32 cfrdelt[E_CFR_THR_NUM];      //检测门限
    UINT32 cfrwinlevel[E_CFR_THR_NUM];  //削峰窗长等级
}T_CfrDynPara_TDD;

/*CFR动态参数FDD*/
typedef struct tagCfrDynPara_FDD
{
    UINT32 radio;                       //混模制式
    UINT32 lowbound;                    //通道最小带宽下边界
    UINT32 upbound;                     //通道最小带宽上边界
    UINT32 cfrgate[E_CFR_THR_NUM];      //削峰门限
    UINT32 cfrwin[E_CFR_THR_NUM] ;      //削峰窗长
    UINT32 cfrdelt[E_CFR_THR_NUM];      //检测门限
    UINT32 cfrwinlevel[E_CFR_THR_NUM];  //削峰窗长等级
}T_CfrDynPara_FDD;

/* 配置方案表(用于定义数据和配置方案的对应关系) */
typedef struct tagT_CfrGateCfgGroup
{
    UINT32   tddFddFlag;    /* TDD或FDD标志 */
    VOID*    dynPara;       /* 第1层数据地址 */
    UINT32   tblLen;        /* 第1层数据组数 */
}T_CfrGateCfgGroup;

typedef struct tagT_ChnCpgCarrInfo
{
    UINT32 radioMode;
    UINT32 carrIndex;
}T_ChnCpgCarrInfo;

typedef struct tagT_ChnCpgAllCarrInfo
{
    UINT32 totalCarrNum;
    UINT32 carrNum[IC42_MAX_CHAN_NUM];
    T_ChnCpgCarrInfo chnCpgCarrInfo[IC42_MAX_CHAN_NUM][MAX_EXCEED_CPG_RAM_CARR_NUM];
}T_AllChnCpgCarrInfo;

typedef UINT32 (*FUN_GET_POWCTRL_TSSI_INFO)(UINT32 bspChn, UINT32 carrMode, UINT32 bspCarrNo, INT32 *pTssiDbm, INT32 *pTssiDbfs);
typedef UINT32 (*FUN_GET_POWCTRL_Tx_IF_TSSI)(UINT32 bspChn, UINT32 ulBand, INT32 *pTxIfTssiDbm);

/**************************************************************************
 *                         函数接口
 **************************************************************************/

UINT32 BspInitCfrModuleFunc(VOID);
UINT32 BspSetSpeCfrCfg(UINT32 speFlag);
UINT32 BspGetCfrCpgCoef_IC4_2(UINT32 difChn,UINT32 cfrBw,UINT32 rate,T_CfrCpgPara *pCpgPara);
UINT32 BspCfrHbfParaInit(UINT32 difChn);
UINT32 BspGetCfrChnBwInfo(UINT32 difchan, UINT32 bandId, UINT32 *obw,UINT32 *ibw);
UINT32 BspCfrGateInit_TDD(UINT32 difchan, T_CfrDynPara_TDD *pTddPara, UINT32 len);
UINT32 BspCfrGateInit_FDD(UINT32 difchan, T_CfrDynPara_FDD *pFddPara, UINT32 len);
UINT32 BspCfrGateInit_IC4_2(UINT32 difchan, UINT32 radioflag, T_CfrDynPara_TDD *pTddPara, T_CfrDynPara_FDD *pFddPara, UINT32 len);
UINT32 BspSetDlyPara(UINT32 difChan, UINT32 *pReservePara);
UINT32 BspCfrDymParaInit(UINT32 dymTblLen, T_CfrGateCfgGroup *pCfrGateCfgGroup);
UINT32 BspInitCfrCommPara(T_BspHalAdaptDifCommCfrPara *pCfrCommPara);
UINT32 BspInitCfrDymPara(VOID);
UINT32 BspInitKiCommPara(T_BspHalAdaptCfrParaHardCpg *pCfrHWCpgPara);
UINT32 BspInitKnCommPara(T_BspHalAdaptCfrKnWordPara *pCfrKnWordPara);
UINT32 BspInitCfrParPara(T_BspHalAdaptCfrParCommPara *pCfrParPara);
UINT32 BspInitDpdParPara(T_BspHalAdaptDpdParCommPara *pDpdParPara);
UINT32 BspInitCfrHbf1FilterPara(UINT32 difChn,INT32* pCoef,UINT32 coefLen);
UINT32 BspInitCfrHbf0FilterPara(UINT32 difChn,INT32* pCoef,UINT32 coefLen);
UINT32 BspSetCfrOutMode(UINT32 difChn, UINT32 mode);
UINT32 BspGetDifChnHwMask(UINT32 *chnMask);
UINT32 BspCfrSetFreqWordFsInit(void);
UINT32 BspSetCpgParaRangeCarrInit(void);
UINT32 BspGetCfrCommPara(T_BspHalAdaptDifCommCfrPara *pCfrCommPara);
UINT32 BspGetCfrParPara(T_BspHalAdaptCfrParCommPara *pCfrParPara);
UINT32 BspGetCfrKiCommPara(T_BspHalAdaptCfrParaHardCpg *pCfrHWCpgPara);
UINT32 BspGetCpgFsByDifChn_IC4_2(UINT32 difChn,UINT32 *pCfrFs);
UINT32 BspInitRangeBandPara(void);
UINT32 BspInitCfrSetCpgGateBypass(void);
UINT32 BspGetDpdParPara(T_BspHalAdaptDpdParCommPara *pDpdParPara);
UINT32 BspCfrSetDlpreKiPowSelInit(void);
UINT32 BspCfrSetTddSwPara(UINT32 difChn);
UINT32 BspCfrSetCpgLen(UINT32 difChn);
UINT32 BspCfrSetBbTssiCfg(UINT32 difchn);
UINT32 BspCfrClrHwCpgRam(UINT32 bspChnChgMask);
UINT32 BspCfrCarrJudgeDss(UINT32 difchan, UINT32 freqBand, UINT32 carrNo1, UINT32 carrNo2, T_CfrChnBandInfo *pChnInfo, UINT32 *dssFlag);
UINT32 BspCfrInitCarrDssMap(UINT32 difChn);
UINT32 BspCfrInitDSSCarrGroup(UINT32 row);
UINT32 BspCfrSetDssCarrInfo(UINT32 difChn, T_CfrChnBandInfo *pChnInfo);
UINT32 BspGetDssCarrCfgPow(UINT32 bspChn, T_CfrChnBandInfo *pChnInfo, UINT32 *dssCarrPow);
UINT32 BspCfrDssSetHwCpgCfg(UINT32 difChn);
UINT32 BspSetNBCarrMode(UINT32 ulChan, UINT32 ulCarr, UINT32 ulMode);
UINT32 BspCfrJudgeCpgMode(UINT32 difChn, UINT32 *cpgMode);
UINT32 BspSetUmtsCpgCoef(UINT32 bspChan, UINT32 ulCarrId, UINT32 radioMod, UINT32 bandWidth, UINT32 cfgflag);
UINT32 BspCfrSetCpgPara_CpuCal(UINT32 bspChn);
UINT32 BspGetRefreshCfrCpgFlag(UINT32 bspChn, UINT32 *flag);
UINT32 BspRefreshCfrCpgTbl(UINT32 bspChn);
UINT32 BspSetTssiPowInfoCallBackInit(FUN_GET_POWCTRL_TSSI_INFO pGetTssi);
FUN_GET_POWCTRL_TSSI_INFO BspGetTssiPowInfoCallBackInit(void);
UINT32 BspSetTxIfTssiCallBackInit(FUN_GET_POWCTRL_Tx_IF_TSSI pGetTxIfTssi);
FUN_GET_POWCTRL_Tx_IF_TSSI BspGetTxIfTssiCallBackInit(VOID);
UINT32 BspJudgeCfrCpgRefreshCarrPow(UINT32 cpgCalcFlag, UINT32 powShareFlag, INT32 appPowMw, INT32 realPowMw, INT32 *carrPowMw);
UINT32 BspSetCfrGateCfg(UINT32 chanNo, UINT32 gateLevel, UINT32 *cfrGate);
UINT32 BspSetSideFilterCpgCoef(UINT32 bspChan, UINT32 carrNo, UINT32 radioMode, UINT32 bandwidth);
UINT32 BspSetDssCfrOriginCoefAndRecordExcessCarr(UINT32 difChan, UINT32 carrIndex, UINT32 carrRadio, UINT32 carrBw, UINT32 coefLen, const INT32 *pCoefPara);
VOID BspCheckCpgCarrNumValid(VOID);
UINT32 BspCfrDssSetCpuCpgCfg(UINT32 difChn);
UINT32 BspSetRefreshCfrCpgFlag(UINT32 bspChn, UINT32 flag);
UINT32 BspGetRefreshCpgPowFlag(UINT32 bspChn, UINT32 *cpgPowFlag);
UINT32 BspGetDssCarrPow(UINT32 bspChn, T_CfrChnBandInfo *pChnInfo, UINT32 *dssCarrPow);
UINT32 BspCfrSetCpgPara_HwCal(UINT32 bspChn);
UINT32 BspDssPowforSameFreqBw(UINT32 bspChn, UINT32 dssGroupFlag[], UINT32 arrLen, T_CfrChnBandInfo *pChnInfo);
INT32 BspCompareDescendOrder(const VOID *a, const VOID *b);
UINT32 cfrprnon(VOID);
UINT32 BspUpdateCpgbwToFilter(UINT32 difChn, T_CfrChnBandInfo *pChnInfo);
#ifdef __cplusplus
}
#endif
#endif

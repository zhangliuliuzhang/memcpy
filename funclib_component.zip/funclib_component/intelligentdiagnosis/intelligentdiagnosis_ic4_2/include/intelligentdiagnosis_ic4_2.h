/*****************************************************************************
* 版权所有(C) 2023, ZTE Corp. ZXSDR-RRU Platform BSP
*----------------------------------------------------------------------------
* 模 块 名 : bsp
* 文件名称 : intelligentdiagnosis_ic4_2.h
* 文件标识 : {[N/A]}
* 内容摘要 : 
* 注意事项 : 无
* 作    者 :
* 创建日期 : 2023-5-12
* 当前版本 : Ver1.0
*----------------------------------------------------------------------------
* 变更记录 :
*
* $记录1
* 变 更 单: $0000000(N/A)
* 责 任 人:
* 修改日戳: 2023-5-12
* 变更说明: 创建文件
*----------------------------------------------------------------------------
*/
#ifndef _FUNCLIB_DEBUG_H_
#define _FUNCLIB_DEBUG_H_

#ifdef __cplusplus
extern "C" {
#endif

#include "bsppub.h"
#include "ichaladapt_ic4_2.h"


#define VIBAS_TYPE_MUN         (8)

typedef struct tag_j204_debug_info
{
    INT32 j204RxFbLinkSta;      /*上行反馈建链状态*/
    INT32 j204TxLinkSta;        /*下行建链状态*/
}T_J204DbgInfo;

typedef struct tag_att_debug_info
{
    INT32 txAtt;
    INT32 rxAtt;
    INT32 prxAtt;
}T_AttDbgInfo;

typedef struct tag_pa_debug_info
{
    INT32 paInitSta;                           /*PA初始化状态*/
    INT32 paGridVolt[VIBAS_TYPE_MUN];           /*PA栅压*/
    INT32 paDefault;                           /*PA漏压*/
    INT32 paGirdVoltTempComp[VIBAS_TYPE_MUN];      /*PA栅压温补*/
}T_PaDbgInfo;

typedef struct tag_trx_debug_info
{
    INT32 trxInitSta;           /* trx初始化状态   */
}T_TrxDbgInfo;

typedef struct tag_Intelligent_diagnosis_debug_info
{
    T_TrxDbgInfo trxDbgInfo;
    T_AttDbgInfo attDbgInfo;
    T_PaDbgInfo paDbgInfo;
    T_J204DbgInfo j204InitSta;   /* 204c初始化状态*/
}T_IntellgentDiagnosisDbgInfo;


#ifdef __cplusplus
}
#endif
#endif 





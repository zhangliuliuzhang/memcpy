/*****************************************************************************
* 版权所有(C) 2023, ZTE Corp. ZXSDR-RRU Platform BSP
*----------------------------------------------------------------------------
* 模 块 名 : BSP
* 文件名称 : debug.c
* 文件标识 : {[N/A]}
* 内容摘要 : 本文件提供了D42故障智能诊断相关接口
* 注意事项 : 无
* 作    者   :
* 创建日期 : 2023-5-12
* 当前版本 : Ver1.0
*----------------------------------------------------------------------------
* 变更记录 :
*
* $记录1
* 变 更 单: $0000000(N/A)
* 责 任 人:
* 修改日戳: 2023-5-12
* 变更说明: 创建文件

*----------------------------------------------------------------------------
*/
#include "intelligentdiagnosis_ic4_2.h"
#include "bsppub.h"
#include "bspcomm.h"
#include "boardmodlecommon.h"
#include "ru_basedef.h"
#include "rruinfo.h"
#include "j204_ic4_2.h"
#include "chnmapcommon.h"
#include "devdrv_transceiver.h"
#include "devdrv_att.h"
#include "powerctrl_ic4_2.h"
#include "pa_ic4_2_gridvolt.h"
#include "rftable_padacset.h"
#include "rftable_common.h"
#include "funccommon_a.h"


#define J204_LANE_NUM_MAX         (8)

static INT32 BspGetTrxInitFinishSta(VOID)
{
    INT32 retVal = 0;
    UINT32 brdInitSta = 0;

    brdInitSta = BspGetBoardInitStatus();
    brdInitSta &= BIT_SET(E_POWERON_RFTR_INIT);
    retVal = (0 == brdInitSta) ? 0:1;

    return retVal;
}

static INT32 BspGetPaInitFinishSta(VOID)
{
    INT32 retVal = 0;
    UINT32 brdInitSta = 0;

    brdInitSta = BspGetBoardInitStatus();
    brdInitSta &= BIT_SET(E_POWERON_PA_INIT);
    retVal = (0 == brdInitSta) ? 0:1;

    return retVal;
}

/**************************************************************************
 * 函数名称: BspGetIcRxBringUpStatus(*)
 * 功能描述: 上行建联状态
 * 输入参数:
 * 输出参数: retVal -- 0:ok, 1:err
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * *************************************************************************/
static UINT32 BspGetIcRxBringUpStatus(VOID)
{
    UINT32 retVal = BSP_OK;
    UINT32 loopLane = 0;
    UINT32 icLaneState = 0;
    UINT32 icLaneRegVal = 0;
    UINT32 rxLaneMask = 0;
    UINT32 fbLaneMask = 0;

    rxLaneMask = BspJ204GetLaneMask(RX);
    fbLaneMask = BspJ204GetLaneMask(PRX);

    for(loopLane=0; loopLane<=J204_LANE_NUM_MAX; loopLane++)
    {
        if((0x01<<loopLane)&rxLaneMask)
        {
            BspJ204GetLinkState(RX,loopLane, &icLaneState, &icLaneRegVal);
            retVal |= icLaneState;
            dbgInfoEx("RxLane:%d, FinishedSta:%s, icLaneRegVal = %#x\n",loopLane, icLaneState==0?"OK":"ERR", icLaneRegVal);
        }
    }

    for(loopLane=0; loopLane<=J204_LANE_NUM_MAX; loopLane++)
    {
        if((0x01<<loopLane)&fbLaneMask)
        {
            BspJ204GetLinkState(PRX,loopLane, &icLaneState, &icLaneRegVal);
            retVal |= icLaneState;
            dbgInfoEx("FbLane:%d, FinishedSta:%s, icLaneRegVal = %#x\n",loopLane, icLaneState==0?"OK":"ERR", icLaneRegVal);
        }
    }

    return retVal;
}

static UINT32 BspGetTrxChipNum(VOID)
{
    TRruDeviceDescription *pDev = NULL;
    UINT32 loop = 0;
    UINT32 bspChan = 0;
    UINT32 trxChipNum = 0;

    bspChan = BspGetTxBspChanNum();
    for (loop = 0; loop < bspChan; loop++)
    {
        if (0 == BspChipInfoPtrGetByRfPathDef(loop, TX, DEVICE_TYPE_TRANSCEIVER, &pDev))
        {
            if (pDev->ulDeviceCfg != INVALID_VALUE)
            {
                trxChipNum++;
            }
        }
    }
    return trxChipNum;
}

/**************************************************************************
 * 函数名称: BspGetTrxJesdBringUpResult(*)
 * 功能描述: 下行建联状态
 * 输入参数:
 * 输出参数: retVal -- 0：ok  1：err
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * *************************************************************************/
static INT32 BspGetTrxJesdBringUpResult(VOID)
{
    UINT32 trxChipNum = 0;
    UINT32 chipId = 0;
    INT32 retVal = 0;

    trxChipNum = BspGetTrxChipNum();
    for (chipId = 0; chipId < trxChipNum; chipId ++)
    {
        retVal |= BspGetTrxJesdBringUpStatus(chipId);
    }

    return retVal;
}

static UINT32 BspGetAttDiagnosisInfo(UINT32 bspChan, T_AttDbgInfo *pAttDbgInfo)
{
    UINT32 retVal = 0;
    INT32 txAtt = 0;
    INT32 rxAtt = 0;
    INT32 prxAtt = 0;

    INPUT_POINTER_CHECK(pAttDbgInfo);

    retVal = BspGetTxAtt(bspChan, &txAtt);
    pAttDbgInfo->txAtt = txAtt;
    retVal |= BspGetRxAtt(bspChan, &rxAtt);
    pAttDbgInfo->rxAtt = rxAtt;
    retVal |= BspGetPrxAtt(bspChan, &prxAtt);
    pAttDbgInfo->prxAtt = prxAtt;
    dbgInfoEx("%s>>txAtt=%d, rxAtt=%d, prxAtt=%d\n", __FUNCTION__, pAttDbgInfo->txAtt, pAttDbgInfo->rxAtt, pAttDbgInfo->prxAtt);

    return retVal;
}

static UINT32 BspGetTrxDiagnosisInfo(T_TrxDbgInfo *pTrxDbgInfo)
{
    INT32 trxInitFinishFlag = 0;

    INPUT_POINTER_CHECK(pTrxDbgInfo);

    trxInitFinishFlag = BspGetTrxInitFinishSta();
    pTrxDbgInfo->trxInitSta = trxInitFinishFlag;
    dbgInfoEx("%s>>Trx init finished status:%d\n", __FUNCTION__, pTrxDbgInfo->trxInitSta);

    return BSP_OK;
}

static UINT32 BspGetJ204DiagnosisInfo(T_J204DbgInfo *pJ204DbgInfo)
{
    INT32 j204RxFbLinkFinishFlag = 0;
    INT32 j204TxLinkFinishFlag = 0;

    INPUT_POINTER_CHECK(pJ204DbgInfo);

    j204RxFbLinkFinishFlag = BspGetIcRxBringUpStatus();
    j204TxLinkFinishFlag = BspGetTrxJesdBringUpResult();
    pJ204DbgInfo->j204RxFbLinkSta = j204RxFbLinkFinishFlag;
    pJ204DbgInfo->j204TxLinkSta = j204TxLinkFinishFlag;
    dbgInfoEx("%s>>J204 init finished status:RxFb(%d) Tx(%d)\n", __FUNCTION__, pJ204DbgInfo->j204RxFbLinkSta, pJ204DbgInfo->j204TxLinkSta);

    return BSP_OK;
}

static UINT32 BspGetPaDiagnosisInfo(UINT32 paChan, T_PaDbgInfo *pPaDbgInfo)
{
    UINT32 index = 0;
    UINT32 retVal = 0;
    INT32 paInitFinishFlag = 0;
    UINT32 classNumIdx = 0;
    UINT32 num = 0;
    UINT32 dacChan = 0;
    UINT32 vbiasType = 0;
    INT32 gridVolt = 0;
    INT32 gridVoltTempComp = 0;
    INT32 defaultVolt = 0;
    T_PaDacSetCaliData *ptData = NULL;
    T_PaDacSetGridVoltRecord *ptRecord = NULL;

    INPUT_POINTER_CHECK(pPaDbgInfo);

    /* 获取写表数据 */
    ptData = (T_PaDacSetCaliData *)_BspGetCalibData(TBL_KIND_OF_PADACSET, index);
    if(ptData == NULL)
    {
        dbgErr("%s>>_BspGetCalibData retun null, may by no PaDacSet.txt file!\n",__FUNCTION__);
        return ERROR_NULL_POINTER;
    }
    classNumIdx = BspGetPaDacClassNumIdx(ptData, paChan);
    INPUT_POINTER_CHECK(ptData->pCaliPath[classNumIdx]);

    /* 解析后的paChan通道数据 */
    ptRecord = ptData->pCaliPath[classNumIdx][paChan].ptRecord;
    INPUT_POINTER_CHECK(ptRecord);
    /* 配置DAC:一个 PA 需要 ulRecordNum 条配置 */
    for (num = 0; num < ptData->pCaliPath[classNumIdx][paChan].ulRecordNum; num++)
    {
        dacChan = ptRecord->ulDacChanIndex;     /* DAC通道索引 */
        vbiasType = ptRecord->ulGridVoltType ;/*PA驱动类型 peak carrier driver*/

        retVal = BspGetPaGridVoltFix(paChan, vbiasType, dacChan, &gridVolt);
        retVal |= BspGetPaGridVoltTempComp(paChan, vbiasType, &gridVoltTempComp);
        pPaDbgInfo->paGridVolt [vbiasType]= gridVolt;
        dbgInfoEx("%s>>Pa girdVolt[%d]=%d\n", __FUNCTION__, vbiasType, pPaDbgInfo->paGridVolt [vbiasType]);
        pPaDbgInfo->paGirdVoltTempComp[vbiasType] = gridVoltTempComp;
        dbgInfoEx("%s>>Pa girdVoltVibas[%d]=%d\n", __FUNCTION__, vbiasType, pPaDbgInfo->paGirdVoltTempComp[vbiasType]);

        ptRecord++;
    }
    retVal |= BspGetPaDefaultVolt(paChan, (UINT32 *)&defaultVolt);
    pPaDbgInfo->paDefault = defaultVolt;
    dbgInfoEx("%s>>Pa defaultVolt=%d\n", __FUNCTION__, pPaDbgInfo->paDefault);
    paInitFinishFlag = BspGetPaInitFinishSta();
    pPaDbgInfo->paInitSta = paInitFinishFlag;
    dbgInfoEx("%s>>Pa init finished status:%d\n", __FUNCTION__, pPaDbgInfo->paInitSta);

    return retVal;
}

static UINT32 BspGetIntelligentDiagnosisInfo(UINT32 bspChan, T_IntellgentDiagnosisDbgInfo *pDiagnosisInfo)
{
    UINT32 retVal = 0;

    INPUT_POINTER_CHECK(pDiagnosisInfo);

    retVal = BspGetAttDiagnosisInfo(bspChan, &(pDiagnosisInfo->attDbgInfo));
    retVal |= BspGetTrxDiagnosisInfo(&(pDiagnosisInfo->trxDbgInfo));
    retVal |= BspGetJ204DiagnosisInfo(&(pDiagnosisInfo->j204InitSta));
    retVal |= BspGetPaDiagnosisInfo(bspChan, &(pDiagnosisInfo->paDbgInfo));

    return retVal;
}

static UINT32 BspWrDiagnosisInfoToFile(VOID)
{
    UINT32 chanNum  = 0;
    UINT32 retVal = 0;
    UINT32 bspChan  = 0;
    UINT32 ret = BSP_OK;
    INT32 iRet = 0;
    FILE *fp = NULL;
    INT32 fclsRet = 0;
    T_IntellgentDiagnosisDbgInfo diagnosisInfo = {0};
    const char *pFilePath = "/IntellgentDiagnosisDbgInfo.bin";

    iRet = fopen_s(&fp, pFilePath, "wb+");
    FOPEN_S_CHECK(iRet);
    INPUT_POINTER_CHECK(fp);

    chanNum = BspGetTxChannel();
    for (bspChan = 0; bspChan < chanNum; bspChan++)
    {
        retVal = BspGetIntelligentDiagnosisInfo(bspChan, &diagnosisInfo);
        ret = fwrite(&diagnosisInfo, 1, sizeof(T_IntellgentDiagnosisDbgInfo), fp);
        if(ret < sizeof(T_IntellgentDiagnosisDbgInfo))
        {
            dbgErr("<%s>: Write file error!\n",__FUNCTION__);
            fclsRet = fclose(fp);
            FCLOSE_CHECK(fclsRet);
            return BSP_ERROR;
        }
    }
    fclsRet = fclose(fp);
    FCLOSE_CHECK(fclsRet);

    return retVal;
}

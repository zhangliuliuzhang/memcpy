/*****************************************************************************
 * 版权所有(C) 2020, ZTE Corp. ZXSDR-RRU Platform BSP
 *----------------------------------------------------------------------------
 * 模 块 名 : BSP
 * 文件名称 : j204_block.c
 * 文件标识 : {[N/A]}
 * 内容摘要 : 本文件主要提供J204模块相关实现
 * 注意事项 : 无
 * 作    者 : wangtao 10248577
 * 创建日期 : 2020-12-10 
 * 当前版本 : Ver1.0
 *----------------------------------------------------------------------------
 * 变更记录 :
 *
 * $记录1
 * 变 更 单:
 * 责 任 人:
 * 修改日戳:
 * 变更说明:

 *----------------------------------------------------------------------------
 */
#include "j204_ic4_2.h"
#include "ichaladaptbspapi_j204.h"
#include "j204_common.h"
#include "j204_trx.h"
#include "ichaladapt_j204_ic4_2.h"
#include "devdrv_transceiver.h"
#include "rruinfo.h"
#include "chnmapcommon.h"

/**************************************************************************
 *                                 函数声明
 **************************************************************************/

/**************************************************************************
 *                                  宏定义
 **************************************************************************/
#define J204_TRX_TYPE_MAX (4)
#define J204_TRX_CHIP_MAX (4)
#define J204_TRX_SYSREF_OK (1)

/****************************************************************************
 *                               数据类型定义
 ****************************************************************************/
typedef struct tag_TransceiverCfg 
{
    UINT32                  trxDevType;
    UINT32                  chipIdMask;
    FUNC_TRX_CHECK_SYSREF   pTrxCheckSysrefFunc;  /* 检查Transcever是否收到sysref的接口 */
    FUNC_TRX_CHECK_J204LINK pTrxCheck204LinkFunc; /* 检查Transcever侧204建链状态的接口 */
    FUNC_TRX_SEND_SYSREF    pTrxSendSysrefFunc;   /* 向Transcever发送sysref信号的接口 */  
}T_TransceiverCfg;


/****************************************************************************
*                              全局变量定义                                       *
****************************************************************************/
static T_J204TrxCallBackCfg *s_pTrxFuncCfg = NULL;
static UINT32 s_trxTypeNum = 0;
static T_TransceiverCfg s_TransceiverCfg[J204_TRX_TYPE_MAX] = {0};
static UINT32 s_sysrefState[J204_TRX_TYPE_MAX] = {0};
static UINT32 s_trxInitFlag = 0;

static CHAR s_trxName[3][10] = {"MTS2PRE", "MTS", "Unknow"};

/*****************************************************************************
*                                                                            *
*                              内部函数实现                                        *
*                                                                            *
*****************************************************************************/
static UINT32 TransceiverCfgPreAnalyse(VOID)
{
    UINT32 ulTrxNameId = 0;
    UINT32 ulTrxChipId = 0;
    UINT32 txChnNum = BspGetTxChanNum();
    UINT32 chan = 0;
    UINT32 ulTmpRet = BSP_OK;
    UINT32 trxType = 0;

    if(NULL == s_pTrxFuncCfg || 0 == s_trxTypeNum || s_trxTypeNum > J204_TRX_TYPE_MAX)
    {
        return BSP_ERROR;
    }

    for(chan = 0; chan < txChnNum; chan++)
    {
        ulTmpRet = BspGetTransceiverInfoByBspChnl(chan, &ulTrxNameId, &ulTrxChipId, NULL);
        if (BSP_OK != ulTmpRet)
        {
            dbgErr("%s>>TransceiverInfo Get Error!\n", __FUNCTION__);
            return BSP_ERROR;
        }
        for(trxType=0; trxType<s_trxTypeNum; trxType++)
        {
            if(s_pTrxFuncCfg[trxType].deviceType == ulTrxNameId)
            {
                s_TransceiverCfg[trxType].trxDevType = ulTrxNameId;
                s_TransceiverCfg[trxType].chipIdMask |= (0x1 << ulTrxChipId);
                /* 如果没有初始化回调接口，则进行初始化 */
                if(NULL == s_TransceiverCfg[trxType].pTrxCheckSysrefFunc)
                {
                    s_TransceiverCfg[trxType].pTrxCheckSysrefFunc = s_pTrxFuncCfg[trxType].pTrxCheckSysrefFunc;
                    s_TransceiverCfg[trxType].pTrxSendSysrefFunc = s_pTrxFuncCfg[trxType].pTrxSendSysrefFunc;
                    s_TransceiverCfg[trxType].pTrxCheckSysrefFunc = s_pTrxFuncCfg[trxType].pTrxCheckSysrefFunc;
                }
            }
        }
    }
    s_trxInitFlag = 1;
    return BSP_OK;
}

UINT32 TransceiverSysrefCheck(VOID)
{
    UINT32 retVal = BSP_OK;
    UINT32 trxType = 0;
    UINT32 chipId = 0;
    UINT32 sysrefFlag = 0;
    FUNC_TRX_CHECK_SYSREF   pTrxCheckSysrefFunc = NULL;

    (void)memset_s(s_sysrefState, sizeof(s_sysrefState), 0, sizeof(s_sysrefState));
    for(trxType=0; trxType<s_trxTypeNum; trxType++)
    {
        pTrxCheckSysrefFunc = s_TransceiverCfg[trxType].pTrxCheckSysrefFunc;
        if(NULL == pTrxCheckSysrefFunc)
        {
            dbgErr("%s pTrxCheckSysrefFunc is null,trxType=%d\n", __func__,trxType);
            continue;
        }
        for(chipId=0; chipId<J204_TRX_CHIP_MAX; chipId++)
        {
            if(BIT_VAL(s_TransceiverCfg[trxType].chipIdMask, chipId))
            {
                retVal |= pTrxCheckSysrefFunc(chipId, &sysrefFlag);
                if(BSP_OK == retVal)
                {
                    dbgInfo("%s pTrxCheckSysrefFunc succ,trxType=%d,chipId=%d,sysrefFlag=%d\n", 
                                __func__, trxType, chipId, sysrefFlag);
                    if(J204_TRX_SYSREF_OK == sysrefFlag)
                    {
                        s_sysrefState[trxType] |= (0x1 << chipId);
                    }
                }
                else
                {
                    dbgErr("%s pTrxCheckSysrefFunc error,trxType=%d \n", __func__, trxType);              
                }
            }
        }
    }

    return retVal;
}

UINT32 TransceiverSendSysref(VOID)
{
    UINT32 retVal = BSP_OK;
    UINT32 trxType = 0;
    UINT32 chipId = 0;
    FUNC_TRX_SEND_SYSREF   pTrxSendSysrefFunc = NULL;

    for(trxType=0; trxType<s_trxTypeNum; trxType++)
    {
        pTrxSendSysrefFunc = s_TransceiverCfg[trxType].pTrxSendSysrefFunc;
        if(NULL == pTrxSendSysrefFunc)
        {
            dbgErr("%s pTrxSendSysrefFunc is null,trxType=%d \n", __func__, trxType);
            continue;
        }        
        for(chipId=0; chipId<J204_TRX_CHIP_MAX; chipId++)
        {
            /* 对于未收到sysref的transceiver再次发送sysref */
            if(BIT_VAL(s_TransceiverCfg[trxType].chipIdMask, chipId) && !BIT_VAL(s_sysrefState[trxType],chipId))
            {
                retVal |= pTrxSendSysrefFunc(chipId);
                if(BSP_OK != retVal)
                {
                    dbgErr("%s pTrxSendSysrefFunc error,trxType=%d,chipId=%d \n", __func__, trxType, chipId);
                    return BSP_ERROR;
                }
                else 
                {
                    dbgInfo("%s pTrxSendSysrefFunc succ,trxType=%d,chipId=%d \n", __func__, trxType, chipId);
                    BspSysMsDelay(1);
                }
            }
        }
    }

    return BSP_OK;
}

static UINT32 GetTrxSysrefState(VOID)
{
    UINT32 sysrefState = J204_TRX_SYSREF_OK;
    UINT32 trxType = 0;    
    for(trxType=0; trxType<s_trxTypeNum; trxType++)
    {
        if(s_TransceiverCfg[trxType].chipIdMask != s_sysrefState[trxType])
        {
            sysrefState = 0;
            break;
        }
    }
    return sysrefState;
}


static UINT32 GetTrxDevTypeName(UINT32 devType)
{
    if(DEVICE_MTS2PRE == devType)
    {
        return 0;
    }
    else if(DEVICE_MTS == devType)
    {
        return 1;
    }
    else 
    {
        return 2;
    }
}

static UINT32 GetTransceiverChipNum()
{
    TRruDeviceDescription *pDev = NULL;
    UINT32 loop;
    static UINT32 trsvChipNum = 0;

    if (trsvChipNum != 0)
    {
        return trsvChipNum;
    }
    for (loop = 0; loop < BspGetTxBspChanNum(); loop++)
    {
        if (0 == BspChipInfoPtrGetByRfPathDef(loop,TX,DEVICE_TYPE_TRANSCEIVER,&pDev))
        {
            if (pDev->ulDeviceCfg != INVALID_VALUE)
            {
                trsvChipNum++;
            }
        }
    }
    return trsvChipNum;
}


static UINT32 GetChipMaskByNum(UINT32 num)
{
    UINT32 loop = 0;
    UINT32 mask = 0;
    for(loop=0; loop<num; loop++)
    {
        mask |= BIT_SET(loop);
    }
    return mask;
}
/*****************************************************************************
*                                                                            *
*                                维测接口                                        *
*                                                                            *
*****************************************************************************/
VOID prntrxsysrefstat(void)
{
    UINT32 trxType = 0;
    UINT32 trxNameIdx = 0;
    for(trxType=0; trxType<s_trxTypeNum; trxType++)
    {   
        trxNameIdx = GetTrxDevTypeName(s_TransceiverCfg[trxType].trxDevType);
        dbgInfo("trxType=%d, trxName=%8s, chipIdMask = %#x, sysrefStat=%#x \n",
            s_TransceiverCfg[trxType].trxDevType,
            s_trxName[trxNameIdx],
            s_TransceiverCfg[trxType].chipIdMask, 
            s_sysrefState[trxType]);
    }
    return;
}

/*****************************************************************************
*                                                                            *
*                              对外接口实现                                        *
*                                                                            *
*****************************************************************************/
/*****************************************************************************
 * 函数名称: BspJ204TrxCallBackInit
 * 功能描述: 初始化204相关Transceiver的回调接口 
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值: BSP_OK/BSP_ERROR
 * 其它说明: 
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10248577@2021-08-20, 创建
 *----------------------------------------------------------------------------
 */
UINT32 BspJ204TrxCallBackCfg(T_J204TrxCallBackCfg* pTrxFuncCfg, UINT32 trxTypeNum)
{
    s_pTrxFuncCfg = pTrxFuncCfg;
    s_trxTypeNum = trxTypeNum;
    
    return TransceiverCfgPreAnalyse();   
}


/*****************************************************************************
 * 函数名称: J204TrxSysrefCheck
 * 功能描述: Transceiver侧sysref状态检查和重发 
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值: BSP_OK/BSP_ERROR
 * 其它说明: 
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10248577@2021-08-20, 创建
 *----------------------------------------------------------------------------
 */
UINT32 J204TrxSysrefCheck(UINT32 index, UINT32 grpMask, T_J204LinkCfg* pPara)
{
    UINT32 retVal = BSP_OK;
    UINT32 validFlag = 0;
    UINT32 cycleMs = 10; //10ms
    UINT32 retryMaxTimes = 10; //10*10ms=100ms
    UINT32 retryTimes = 0;

    /* 如果没有初始化Trx信息,则直接返回错误 */
    if(!s_trxInitFlag)
    {
        dbgErr("%s exit for s_trxInitFlag=%d\n", __func__, s_trxInitFlag);
        return BSP_OK;
    }
    
    do 
    {
        if(retryTimes >= retryMaxTimes)
        {
            dbgErr("%s fail to recv valid sysref, retry max times = %d\n", __func__, retryTimes);
            retVal = BSP_ERROR;
            break;
        }
        BspSysMsDelay(cycleMs);
        
        retVal = TransceiverSysrefCheck();
        validFlag = GetTrxSysrefState();
        if(BSP_OK == retVal && J204_TRX_SYSREF_OK == validFlag)
        {
            retVal = BSP_OK;
            dbgInfo("%s successfully recved sysref, retry times = %d\n", __func__, retryTimes);
            break;
        }
        
        /* 再次发送sysref */
        retVal = TransceiverSendSysref();
        CHECK_RETVAL_PRN(TransceiverSendSysref,retVal);

        retryTimes++;
        dbgInfo("%s retry to send sysref, retry times = %d\n", __func__, retryTimes);
    }
    while(validFlag != DPDIC_J204_SYSREF_VALID); 

    /* 打印结果 */
    prntrxsysrefstat();

    return retVal;
}

/*****************************************************************************
 * 函数名称: J204TrxLinkRebuild
 * 功能描述: Transceiver侧J204c重建链流程
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值: BSP_OK/BSP_ERROR
 * 其它说明:
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10248577@2021-08-20, 创建
 *----------------------------------------------------------------------------
 */
UINT32 J204TrxLinkRebuild(VOID)
{
    UINT32 ulTrsvIdx = 0;
    UINT32 ulRetVal = BSP_OK;
    UINT32 ulTrxChipSum = GetTransceiverChipNum();
    UINT32 chipIdMask = 0;

    if(ulTrxChipSum > J204_TRX_CHIP_MAX)
    {
        return BSP_ERROR;
    }

    chipIdMask = GetChipMaskByNum(ulTrxChipSum);
    for (ulTrsvIdx = 0; ulTrsvIdx < ulTrxChipSum; ulTrsvIdx++)
    {
        ulRetVal |= BspTransceiverJesdReBringUp(ulTrsvIdx);
        dbgInfoEx("%s>>Chip'%d Transceiver J204 rebuild!\n",__FUNCTION__, ulTrsvIdx);
    }
    BspSysMsDelay(1000); /* 方案要求延迟2秒 */

    /* 在所有MTS接口MTS_RestRlsrest204Serdes调用之后,
       给MTS 发送一次 sysref; 配置一次是会向所有MTS 都发送sysref 脉冲 */
    /* todo 判断为MTS或者MTS2时才发送sysref */
    ulRetVal |= BspJ204SysrefRequest(1, E_SYSREF_MODE_PULSE, 4, chipIdMask);
    dbgInfoEx("%s>>Send Sysref To Transceiver chipIdMask=%#x\n", __FUNCTION__, chipIdMask);
    BspSysMsDelay(1000); /* 方案要求延迟2秒 */

    return ulRetVal;
}

/*****************************************************************************
 * 函数名称: J204TrxGetJesdBringUpResult
 * 功能描述: Transceiver侧J204c建链结果
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值: BSP_OK/BSP_ERROR
 * 其它说明:
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10248577@2021-08-20, 创建
 *----------------------------------------------------------------------------
 */
UINT32 J204TrxGetJesdBringUpResult(VOID)
{
    UINT32 trxChipNum = 0;
    UINT32 chipId = 0;
    INT32 retVal = 0;

    trxChipNum = GetTransceiverChipNum();
    for (chipId = 0; chipId < trxChipNum; chipId ++)
    {
        retVal |= BspGetTrxJesdBringUpStatus(chipId);
    }

    return ((0 == retVal)?BSP_OK:BSP_ERROR);
}




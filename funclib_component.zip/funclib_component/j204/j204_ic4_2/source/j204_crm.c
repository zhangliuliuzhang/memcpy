/*****************************************************************************
 * 版权所有(C) 2020, ZTE Corp. ZXSDR-RRU Platform BSP
 *----------------------------------------------------------------------------
 * 模 块 名 : BSP
 * 文件名称 : j204_crm.c
 * 文件标识 : {[N/A]}
 * 内容摘要 : 本文件主要提供J204模块crm相关实现
 * 注意事项 : 无
 * 作    者 : wangtao 10248577
 * 创建日期 : 2020-12-10 
 * 当前版本 : Ver1.0
 *----------------------------------------------------------------------------
 * 变更记录 :
 *
 * $记录1
 * 变 更 单:
 * 责 任 人:
 * 修改日戳:
 * 变更说明:

 *----------------------------------------------------------------------------
 */
#include "bsppub.h"
#include "j204_ic4_2.h"
//#include "ichaladaptbspapi.h"
#include "j204_common.h"
#include "j204_crm.h"
#include "ichaladapt_j204_ic4_2.h"

/****************************************************************************
 *                                  宏定义                                     *
 ***************************************************************************/
#define J204_CRM_PRN_FORMAT "%s %s finished! [dir=%s][laneMask=%#x][mapMask=%#x][rstFlg=%d][ret=%#x]\n"


/****************************************************************************
 *                               数据类型定义                                     *
 ***************************************************************************/
typedef UINT32 (*pJ204CrmResetFunc)(UINT32 dir, UINT32 laneIdMask, UINT32 rstFlag);


/****************************************************************************
*                              全局变量定义                                       *
****************************************************************************/


/****************************************************************************
*                              全局变量                                         *
****************************************************************************/
static CHAR dirStr[3][4] = {"RX","TX","PRX"};

/*****************************************************************************
*                                                                            *
*                              内部函数实现                                        *
*                                                                            *
*****************************************************************************/
static UINT32 ResetJ204Map(UINT32 dir, UINT32 laneMask, UINT32 mapMask, UINT32 rstFlag)
{
    UINT32 retVal = BSP_OK;
    UINT32 retTotl = BSP_OK;
        
    retVal = BspHalAdaptCrmJ204SetRstLogic(dir, laneMask, mapMask, rstFlag);
    retTotl |= retVal;
    retVal = BspHalAdaptCrmJ204SetRstMap(dir, laneMask, mapMask, rstFlag);
    retTotl |= retVal;
    if(laneMask)
    {
        retVal = BspHalAdaptCrmJ204SetResetWorkLane(dir, laneMask, rstFlag);
        retTotl |= retVal;
    }
    
    /* RX和FB时，需要判断是否需要复位Ctrl */
    if((TX != dir) && (FULL_MAP_MASK == mapMask || ONE_GROUP_MASK == BspJ204GetGroupMask()))
    {
        retVal = BspHalAdaptCrmJ204SetResetCtrl(dir, laneMask, rstFlag);
        retTotl |= retVal;
    }
    
    return retTotl;
}
static UINT32 J204CrmReleaseWorkLane(UINT32 dir, UINT32 grpMask, T_J204LinkCfg* pPara)
{
    UINT32 laneMask = 0;
    UINT32 grpLoop = 0;
    UINT32 retVal = 0;
    UINT32 rstFlg = 1;
    UINT32 retTotal = BSP_OK;

    INPUT_POINTER_CHECK(pPara);
    for(grpLoop=0; grpLoop<J204_LANE_GRP_NUM; grpLoop++)
    {
        /* 未指定的Group跳过 */
        if(!BIT_VAL(grpMask, grpLoop))
        {
            continue;
        }
        laneMask = pPara->laneCfg[grpLoop][dir].laneIdMask;
        if(laneMask)
        {
            retVal = BspHalAdaptCrmJ204SetResetWorkLane(dir, laneMask, rstFlg);
            CHECK_RETVAL_PRN(BspHalAdaptCrmJ204SetResetWorkLane,retVal);
            retTotal |= retVal;
        }
        j204ExLog(J204_CRM, J204_CRM_PRN_FORMAT, __func__, 
            "BspHalAdaptCrmJ204SetResetWorkLane",dirStr[dir], laneMask, 0, rstFlg, retVal);             
    }
    
    return retTotal;
}

static UINT32 J204CrmReleaseWorkMap(UINT32 dir, UINT32 grpMask, T_J204LinkCfg* pPara)
{
    UINT32 laneMask = 0;
    UINT32 grpLoop = 0;
    UINT32 retVal = 0;
    UINT32 rstFlg = 1;
    UINT32 retTotal = BSP_OK;
    UINT32 mapMask = 0; 

    INPUT_POINTER_CHECK(pPara);
    for(grpLoop=0; grpLoop<J204_LANE_GRP_NUM; grpLoop++)
    {
        /* 未指定的Group跳过 */
        if(!BIT_VAL(grpMask, grpLoop))
        {
            continue;
        }
        laneMask = pPara->laneCfg[grpLoop][dir].laneIdMask;
        mapMask = pPara->laneCfg[grpLoop][dir].mapMask;

        retVal = BspHalAdaptCrmJ204SetRstMap(dir, laneMask, mapMask, rstFlg);
        CHECK_RETVAL_PRN(BspHalAdaptCrmJ204SetRstMap,retVal);
        retTotal |= retVal;

        j204ExLog(J204_CRM, J204_CRM_PRN_FORMAT, __func__, 
            "BspHalAdaptCrmJ204SetRstMap",dirStr[dir], laneMask, mapMask, rstFlg, retVal);             
    }
    
    return retTotal;
}

static UINT32 J204CrmReleaseLogic(UINT32 dir, UINT32 grpMask, T_J204LinkCfg* pPara)
{
    UINT32 laneMask = 0;
    UINT32 grpLoop = 0;
    UINT32 retVal = 0;
    UINT32 rstFlg = 1;
    UINT32 retTotal = BSP_OK;
    UINT32 mapMask = 0;

    INPUT_POINTER_CHECK(pPara);
    for(grpLoop=0; grpLoop<J204_LANE_GRP_NUM; grpLoop++)
    {
        /* 未指定的Group跳过 */
        if(!BIT_VAL(grpMask, grpLoop))
        {
            continue;
        }
        laneMask = pPara->laneCfg[grpLoop][dir].laneIdMask;
        mapMask = pPara->laneCfg[grpLoop][dir].mapMask;

        retVal = BspHalAdaptCrmJ204SetRstLogic(dir, laneMask, mapMask, rstFlg);
        CHECK_RETVAL_PRN(BspHalAdaptCrmJ204SetRstLogic,retVal);
        retTotal |= retVal;
        
        j204ExLog(J204_CRM, J204_CRM_PRN_FORMAT, __func__, 
            "BspHalAdaptCrmJ204SetRstLogic",dirStr[dir], laneMask, mapMask, rstFlg, retVal);             
    }
    
    return retTotal;
}

static UINT32 J204CrmReleaseCtrl(UINT32 dir, UINT32 grpMask, T_J204LinkCfg* pPara)
{
    UINT32 laneMask = 0;
    UINT32 retVal = 0;
    UINT32 rstFlg = 1;
    
    laneMask = pPara->laneCfg[J204_GROUP0][dir].laneIdMask;

    retVal = BspHalAdaptCrmJ204SetResetCtrl(dir, laneMask, rstFlg);
    CHECK_RETVAL_PRN(BspHalAdaptCrmJ204SetResetCtrl,retVal);

    j204ExLog(J204_CRM, J204_CRM_PRN_FORMAT, __func__, 
            "BspHalAdaptCrmJ204SetResetCtrl",dirStr[dir], laneMask, 0, rstFlg, retVal);

    return retVal;
}

/*****************************************************************************
*                                                                            *
*                              对外接口实现                                        *
*                                                                            *
*****************************************************************************/

/*****************************************************************************
 * 函数名称: J204CrmRelaseGlobalApb
 * 功能描述: 释放J204 Tx,Rx,Fb方向的Apb复位 
 * 输入参数: grpId - Group ID(也就是IC的J204 Block Id)
 * 输出参数: 无
 * 返 回 值: BSP_OK/BSP_ERROR
 * 其它说明: 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10248577@2021-08-20, 创建
 *----------------------------------------------------------------------------
 */
UINT32 J204CrmRelaseGlobalApb(UINT32 index, UINT32 grpMask, T_J204LinkCfg* pPara)
{
    UINT32 retVal = BSP_OK;
    UINT32 rstFlg = 1;
    
    INPUT_POINTER_CHECK(pPara);

    /* 全局Apb复位释放 */
    retVal = BspHalAdaptCrmJ204SetResetGlobalApb(rstFlg);

    return retVal;
}

/*****************************************************************************
 * 函数名称: J204CrmResetAll
 * 功能描述: 复位所有J204 
 * 输入参数: grpId - Group ID(也就是IC的J204 Block Id)
 * 输出参数: 无
 * 返 回 值: BSP_OK/BSP_ERROR
 * 其它说明: 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10248577@2021-08-20, 创建
 *----------------------------------------------------------------------------
 */
UINT32 J204CrmResetAll(UINT32 index, UINT32 grpMask, T_J204LinkCfg* pPara)
{
    UINT32 rstFlg = 0;
    UINT32 retVal = BSP_OK;
    
    INPUT_POINTER_CHECK(pPara);
    //retVal = BspHalAdaptCrmJ204SetResetGlobalApb(rstFlg);
    retVal |= BspHalAdaptCrmJ204SetResetAll(rstFlg);
    return BSP_OK;
}

/*****************************************************************************
 * 函数名称: J204CrmRelaseAllApb
 * 功能描述: 释放J204 Tx,Rx,Fb方向的Apb复位 
 * 输入参数: grpId - Group ID(也就是IC的J204 Block Id)
 * 输出参数: 无
 * 返 回 值: BSP_OK/BSP_ERROR
 * 其它说明: 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10248577@2021-08-20, 创建
 *----------------------------------------------------------------------------
 */
UINT32 J204CrmRelaseAllApb(UINT32 index, UINT32 grpMask, T_J204LinkCfg* pPara)
{
    UINT32 laneMask = 0;
    UINT32 dirLoop = 0;
    UINT32 retVal = BSP_OK;
    UINT32 retTotal = BSP_OK;
    UINT32 rstFlg = 1;
    
    INPUT_POINTER_CHECK(pPara);

    /* 全局Apb复位释放 */
    retVal = BspHalAdaptCrmJ204SetResetGlobalApb(rstFlg);

    /* Tx、Rx、Fb的Apb复位释放 */
    for(dirLoop=RX;dirLoop<=PRX;dirLoop++)
    {
        laneMask = pPara->laneCfg[J204_GROUP0][dirLoop].laneIdMask;
        
        retVal = BspHalAdaptCrmJ204SetResetApb(dirLoop, laneMask, rstFlg);
        CHECK_RETVAL_PRN(BspHalAdaptCrmJ204SetResetApb,retVal);
        retTotal |= retVal;                

        j204ExLog(J204_CRM, J204_CRM_PRN_FORMAT, __func__, 
            "BspHalAdaptCrmJ204SetResetApb",dirStr[dirLoop], laneMask, 0, rstFlg, retVal);            
    }

    return retTotal;
}

/*****************************************************************************
 * 函数名称: BspResetJ204TxMap
 * 功能描述: 复位J204 Tx的Map，用于以Map为单位的重新建链流程 
 * 输入参数: grpId - Group ID(也就是IC的J204 Block Id)
 * 输出参数: 无
 * 返 回 值: BSP_OK/BSP_ERROR
 * 其它说明: 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10248577@2021-08-20, 创建
 *----------------------------------------------------------------------------
 */
UINT32 J204CrmResetTxMap(UINT32 index, UINT32 grpMask, T_J204LinkCfg* pPara)
{
    UINT32 grpLoop = 0;   
    UINT32 retVal = 0;
    UINT32 rstFlg = 0;
    UINT32 laneMask = 0;
    UINT32 mapMask = 0;
    UINT32 retTotal = BSP_OK;
    
    INPUT_POINTER_CHECK(pPara);
    for(grpLoop=0; grpLoop<J204_LANE_GRP_NUM; grpLoop++)
    {
        /* 未指定的Group跳过 */
        if(!BIT_VAL(grpMask, grpLoop))
        {
            continue;
        }
        laneMask = pPara->laneCfg[grpLoop][TX].laneIdMask;
        mapMask = pPara->laneCfg[grpLoop][TX].mapMask; 
       
        retVal = ResetJ204Map(TX, laneMask, mapMask, rstFlg);
        CHECK_RETVAL_PRN(ResetJ204Map,retVal);
        retTotal |= retVal;
                  
        j204ExLog(J204_CRM, J204_CRM_PRN_FORMAT, __func__, 
            "ResetJ204Map",dirStr[TX], laneMask, mapMask, rstFlg, retVal);    
    }
    return retTotal;

}


/*****************************************************************************
 * 函数名称: BspReleaseJ204TxLogic
 * 功能描述: 释放J204 Tx方向的Logic软复位 
 * 输入参数: grpId - Group ID(也就是IC的J204 Block Id)
 * 输出参数: 无
 * 返 回 值: BSP_OK/BSP_ERROR
 * 其它说明: 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10248577@2021-08-20, 创建
 *----------------------------------------------------------------------------
 */
UINT32 J204CrmReleaseTxLogic(UINT32 index, UINT32 grpMask, T_J204LinkCfg* pPara)
{
    return J204CrmReleaseLogic(TX, grpMask, pPara);
}

/*****************************************************************************
 * 函数名称: BspReleaseJ204TxLogic
 * 功能描述: 释放J204 Tx方向的Logic软复位 
 * 输入参数: grpId - Group ID(也就是IC的J204 Block Id)
 * 输出参数: 无
 * 返 回 值: BSP_OK/BSP_ERROR
 * 其它说明: 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10248577@2021-08-20, 创建
 *----------------------------------------------------------------------------
 */
UINT32 J204CrmReleaseTxSysref(UINT32 index, UINT32 grpMask, T_J204LinkCfg* pPara)
{
    UINT32 laneMask = 0;
    UINT32 retVal = 0;
    UINT32 rstFlg = 1;

    INPUT_POINTER_CHECK(pPara);
    laneMask = pPara->laneCfg[J204_GROUP0][TX].laneIdMask;

    retVal = BspHalAdaptCrmJ204SetResetDlSysref(laneMask, rstFlg);
    CHECK_RETVAL_PRN(BspHalAdaptCrmJ204SetResetDlSysref,retVal);     

    j204ExLog(J204_CRM, J204_CRM_PRN_FORMAT, __func__, 
        "BspHalAdaptCrmJ204SetResetDlSysref",dirStr[TX], laneMask, 0, rstFlg, retVal);
    
    return retVal;
}

/*****************************************************************************
 * 函数名称: J204CrmReleaseTxWorkMap
 * 功能描述: 释放J204 Tx方向的WORKMAP复位释放 
 * 输入参数: grpId - Group ID(也就是IC的J204 Block Id)
 * 输出参数: 无
 * 返 回 值: BSP_OK/BSP_ERROR
 * 其它说明: 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10248577@2021-08-20, 创建
 *----------------------------------------------------------------------------
 */
UINT32 J204CrmReleaseTxWorkMap(UINT32 index, UINT32 grpMask, T_J204LinkCfg* pPara)
{
    return J204CrmReleaseWorkMap(TX, grpMask, pPara);
}

/*****************************************************************************
 * 函数名称: J204CrmReleaseTxWorkLane
 * 功能描述: 释放J204 Tx方向的WORK复位释放 
 * 输入参数: grpId - Group ID(也就是IC的J204 Block Id)
 * 输出参数: 无
 * 返 回 值: BSP_OK/BSP_ERROR
 * 其它说明: 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10248577@2021-08-20, 创建
 *----------------------------------------------------------------------------
 */
UINT32 J204CrmReleaseTxWorkLane(UINT32 index, UINT32 grpMask, T_J204LinkCfg* pPara)
{
    return J204CrmReleaseWorkLane(TX, grpMask, pPara);
}


/*****************************************************************************
 * 函数名称: J204CrmResetRxFbMap
 * 功能描述: J204 Rx及Fb方向的Map复位，用于以Map为单位的重新建链流程 
 * 输入参数: grpId - Group ID(也就是IC的J204 Block Id)
 * 输出参数: 无
 * 返 回 值: BSP_OK/BSP_ERROR
 * 其它说明: 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10248577@2021-08-20, 创建
 *----------------------------------------------------------------------------
 */
UINT32 J204CrmResetRxFbMap(UINT32 index, UINT32 grpMask, T_J204LinkCfg* pPara)
{
    UINT32 grpLoop = 0;   
    UINT32 retVal = 0;
    UINT32 rstFlg = 0;
    UINT32 laneMask = 0;
    UINT32 mapMask = 0;
    UINT32 retTotal = BSP_OK;
    
    INPUT_POINTER_CHECK(pPara);
    for(grpLoop=0; grpLoop<J204_LANE_GRP_NUM; grpLoop++)
    {
        /* 未指定的Group跳过 */
        if(!BIT_VAL(grpMask, grpLoop))
        {
            continue;
        }
        laneMask = pPara->laneCfg[grpLoop][RX].laneIdMask;
        mapMask = pPara->laneCfg[grpLoop][RX].mapMask;
   
        retVal = ResetJ204Map(RX, laneMask, mapMask, rstFlg);
        CHECK_RETVAL_PRN(ResetJ204Map,retVal);
        retTotal |= retVal;
            
        j204ExLog(J204_CRM, J204_CRM_PRN_FORMAT, __func__, 
            "ResetJ204Map",dirStr[RX], laneMask, mapMask, rstFlg, retVal);   
        
        laneMask = pPara->laneCfg[grpLoop][PRX].laneIdMask;
        mapMask = pPara->laneCfg[grpLoop][PRX].mapMask;
        
        retVal = ResetJ204Map(PRX, laneMask, mapMask, rstFlg);
        CHECK_RETVAL_PRN(ResetJ204Map,retVal);
        retTotal |= retVal;

        j204ExLog(J204_CRM, J204_CRM_PRN_FORMAT, __func__, 
            "ResetJ204Map",dirStr[PRX], laneMask, mapMask, rstFlg, retVal);    
    }
    return retTotal;
}


/*****************************************************************************
 * 函数名称: J204CrmReleaseRxFbWorkLane
 * 功能描述: J204 Rx及Fb方向的Work复位释放 
 * 输入参数: grpId - Group ID(也就是IC的J204 Block Id)
 * 输出参数: 无
 * 返 回 值: BSP_OK/BSP_ERROR
 * 其它说明: 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10248577@2021-08-20, 创建
 *----------------------------------------------------------------------------
 */
UINT32 J204CrmReleaseRxFbWorkLane(UINT32 index, UINT32 grpMask, T_J204LinkCfg* pPara)
{
    UINT32 retVal = BSP_OK;
    UINT32 retTotal = BSP_OK;
        
    retVal = J204CrmReleaseWorkLane(RX, grpMask, pPara);
    retTotal |= retVal;
    retVal = J204CrmReleaseWorkLane(PRX, grpMask, pPara);    
    retTotal |= retVal;
    
    return retTotal;      
}

/*****************************************************************************
 * 函数名称: J204CrmReleaseRxFbCtrl
 * 功能描述: J204 Rx及Fb方向的Work复位释放 
 * 输入参数: grpId - Group ID(也就是IC的J204 Block Id)
 * 输出参数: 无
 * 返 回 值: BSP_OK/BSP_ERROR
 * 其它说明: 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10248577@2021-08-20, 创建
 *----------------------------------------------------------------------------
 */
UINT32 J204CrmReleaseRxFbCtrl(UINT32 index, UINT32 grpMask, T_J204LinkCfg* pPara)
{
    UINT32 retVal = BSP_OK;
    UINT32 retTotal = BSP_OK;
        
    retVal = J204CrmReleaseCtrl(RX, grpMask, pPara);
    retTotal |= retVal;
    retVal = J204CrmReleaseCtrl(PRX, grpMask, pPara);    
    retTotal |= retVal;
    
    return retTotal;    
}

/*****************************************************************************
 * 函数名称: J204CrmReleaseRxFbWorkMap
 * 功能描述: J204 Rx及Fb方向的wWorkMap复位释放 
 * 输入参数: grpId - Group ID(也就是IC的J204 Block Id)
 * 输出参数: 无
 * 返 回 值: BSP_OK/BSP_ERROR
 * 其它说明: 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10248577@2021-08-20, 创建
 *----------------------------------------------------------------------------
 */
UINT32 J204CrmReleaseRxFbWorkMap(UINT32 index, UINT32 grpMask, T_J204LinkCfg* pPara)
{
    UINT32 retVal = BSP_OK;
    UINT32 retTotal = BSP_OK;
        
    retVal = J204CrmReleaseWorkMap(RX, grpMask, pPara);
    retTotal |= retVal;
    retVal = J204CrmReleaseWorkMap(PRX, grpMask, pPara);    
    retTotal |= retVal;
    
    return retTotal;
}


/*****************************************************************************
 * 函数名称: J204CrmReleaseRxFbLogic
 * 功能描述: J204 Rx及Fb方向的Logic复位释放 
 * 输入参数: grpId - Group ID(也就是IC的J204 Block Id)
 * 输出参数: 无
 * 返 回 值: BSP_OK/BSP_ERROR
 * 其它说明: 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10248577@2021-08-20, 创建
 *----------------------------------------------------------------------------
 */
UINT32 J204CrmReleaseRxFbLogic(UINT32 index, UINT32 grpMask, T_J204LinkCfg* pPara)
{
    UINT32 retVal = BSP_OK;
    UINT32 retTotal = BSP_OK;
        
    retVal = J204CrmReleaseLogic(RX, grpMask, pPara);
    retTotal |= retVal;
    retVal = J204CrmReleaseLogic(PRX, grpMask, pPara);    
    retTotal |= retVal;
    
    return retTotal;
}

/*****************************************************************************
 * 函数名称: J204CrmReleaseRxRfTrans
 * 功能描述: J204 Rx 射频信息传输的复位释放 
 * 输入参数: grpId - Group ID(也就是IC的J204 Block Id)
 * 输出参数: 无
 * 返 回 值: BSP_OK/BSP_ERROR
 * 其它说明: 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10248577@2021-08-20, 创建
 *----------------------------------------------------------------------------
 */
UINT32 J204CrmReleaseRxRfTrans(UINT32 index, UINT32 grpMask, T_J204LinkCfg* pPara)
{
    UINT32 retVal = BSP_OK;
    UINT32 laneMask = 0;
    UINT32 rstFlg = 1;
    UINT32 *pCmdInfo = NULL;
    UINT32 cmdSize = 0;       

    INPUT_POINTER_CHECK(pPara);

    pCmdInfo = pPara->laneCfg[J204_GROUP0][RX].pCmdInfo;
    cmdSize = pPara->laneCfg[J204_GROUP0][RX].cmdSize;    

    if(NULL == pCmdInfo || 0 == cmdSize)
    {
        /* 当单板下未传linkinfo和mapinfo数据时，则不进行射频复位释放 */
        return BSP_OK;
    }

    laneMask = pPara->laneCfg[J204_GROUP0][RX].laneIdMask;
              
    retVal = BspHalAdaptCrmJ204SetResetRf(RX, laneMask, rstFlg);
    CHECK_RETVAL_PRN(BspHalAdaptCrmJ204SetResetRf,retVal);
    
    j204ExLog(J204_CRM, J204_CRM_PRN_FORMAT, __func__, 
        "BspHalAdaptCrmJ204SetResetRf",dirStr[RX], laneMask, 0, rstFlg, retVal);   

    return retVal;
}





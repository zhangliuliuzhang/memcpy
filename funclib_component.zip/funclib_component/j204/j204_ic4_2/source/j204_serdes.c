/*****************************************************************************
 * 版权所有(C) 2020, ZTE Corp. ZXSDR-RRU Platform BSP
 *----------------------------------------------------------------------------
 * 模 块 名 : BSP
 * 文件名称 : j204_serdes.c
 * 文件标识 : {[N/A]}
 * 内容摘要 : 本文件主要提供J204模块serdes相关实现
 * 注意事项 : 无
 * 作    者 : wangtao 10248577
 * 创建日期 : 2020-12-10 
 * 当前版本 : Ver1.0
 *----------------------------------------------------------------------------
 * 变更记录 :
 *
 * $记录1
 * 变 更 单:
 * 责 任 人:
 * 修改日戳:
 * 变更说明:

 *----------------------------------------------------------------------------
 */
#include "j204_serdes.h"
#include "j204_ic4_2.h"
#include "ichaladaptbspapi_j204.h"
#include "j204_common.h"

/*  ----------------- DPDIC4.2 J204 serdes 结构 ------------------
    
    -------------- J204 lane和Serdes lane的对应关系 --------------
    204inf0: |                      block0                       |
    serdes   |         phy0            |          phy1           |
    serdes   | lane0 lane1 lane2 lane3 | lane4 lane5 lane6 lane7 |
    j204c    |  tx0   tx1   tx2   tx3  |  tx4   tx5   tx6   tx7  |
    j204c    |  fb0   fb1   rx0   rx1  |  fb2   fb3   rx2   rx3  |
    --------------------------------------------------------------
*/

/**************************************************************************
 *                                  宏定义
 **************************************************************************/
#define SERDES_PHY_NUM (2)  /* J204 Serdes Phy的个数,DPDIC4.2两个Phy */
#define TX_SERDES_LANE_NUM (8)

/****************************************************************************
 *                               数据类型定义
 ****************************************************************************/


/****************************************************************************
*                         全局变量定义                                            *
****************************************************************************/
/* 每个Phy包含4条lane */
static UINT32 s_serdesMaskGrp[SERDES_PHY_NUM] = {0x0F,0xF0};

static const CHAR dirStr[3][4] = {"RX","TX","PRX"};


/****************************************************************************
*                              全局变量                                         *
****************************************************************************/


/*****************************************************************************
*                                                                            *
*                              内部函数实现                                        *
*                                                                            *
*****************************************************************************/
static UINT32 CollectSerdesLaneMask(T_J204LinkCfg* pPara, UINT32 *laneMask)
{
    T_J204LaneCfg *pLaneCfg = NULL;
    UINT32 grpLoop = 0;
    UINT32 dirLoop = 0;
    UINT32 allLaneMask = 0;

    for(grpLoop=0; grpLoop<J204_LANE_GRP_NUM; grpLoop++)
    {
        for(dirLoop=RX;dirLoop<=PRX;dirLoop++)
        {
            pLaneCfg = &(pPara->laneCfg[grpLoop][dirLoop]);
            laneMask[dirLoop] |= BspHalAdaptJ204GetSerdesLaneMask(dirLoop, pLaneCfg->laneIdMask);
            allLaneMask |= laneMask[dirLoop];
        }
    }
    laneMask[RX] |= laneMask[PRX];
    return allLaneMask;
}

static UINT32 GetTxLaneDataRate(T_J204LinkCfg* pPara, UINT32 laneMask)
{
    T_J204LaneCfg *pLaneCfg = NULL;
    UINT32 grpLoop = 0;
    UINT32 txLaneMask = 0;
    UINT32 dataRate = 0;

    for(grpLoop=0; grpLoop<J204_LANE_GRP_NUM; grpLoop++)
    {
        pLaneCfg = &(pPara->laneCfg[grpLoop][TX]);
        txLaneMask = BspHalAdaptJ204GetSerdesLaneMask(TX, pLaneCfg->laneIdMask);
        if(txLaneMask & laneMask)
        {
            dataRate = pLaneCfg->dateRate;
            break;
        }
    }
    return dataRate;    
        
}

static UINT32 GetRxLaneDataRate(T_J204LinkCfg* pPara, UINT32 laneMask)
{
    T_J204LaneCfg *pLaneCfg = NULL;
    UINT32 grpLoop = 0;
    UINT32 rxLaneMask = 0;
    UINT32 fbLaneMask = 0;
    UINT32 dataRate = 0;

    for(grpLoop=0; grpLoop<J204_LANE_GRP_NUM; grpLoop++)
    {
        pLaneCfg = &(pPara->laneCfg[grpLoop][RX]);
        rxLaneMask = BspHalAdaptJ204GetSerdesLaneMask(RX, pLaneCfg->laneIdMask);
        if(rxLaneMask & laneMask)
        {
            dataRate = pLaneCfg->dateRate;
            break;
        }

        pLaneCfg = &(pPara->laneCfg[grpLoop][PRX]);
        fbLaneMask = BspHalAdaptJ204GetSerdesLaneMask(PRX, pLaneCfg->laneIdMask);
        if(fbLaneMask & laneMask)
        {
            dataRate = pLaneCfg->dateRate;
            break;
        } 
    }
    return dataRate;            
}

static UINT32 J204SerdesDataSwitch(UINT32 grpMask, T_J204LinkCfg* pPara, UINT32 dir, UINT32 sw)
{
    UINT32 laneIdMask = 0;
    UINT32 grpLoop = 0;
    UINT32 retVal = 0;
    UINT32 retTotal = BSP_OK;

    for(grpLoop=0; grpLoop<J204_LANE_GRP_NUM; grpLoop++)
    {
        /* 未指定的Group跳过 */
        if(!BIT_VAL(grpMask, grpLoop))
        {
            continue;
        }
        /* 由J204 lane 掩码转换为 Serdes Lane掩码 */
        laneIdMask = BspHalAdaptJ204GetSerdesLaneMask(dir, pPara->laneCfg[grpLoop][dir].laneIdMask);
        if(laneIdMask)
        {
            /* J204反馈lane属于Serdes     Rx Lane */
            dir = ((PRX == dir)? RX:dir);
            /* J204 Serdes Data Enable/Disable */
            retVal = BspHalAdaptJ204cSerdesTrxEn(dir, laneIdMask, sw);
            retTotal |= retVal;
            CHECK_SERDES_RETVAL(BspHalAdaptJ204cSerdesTrxEn,laneIdMask,dir,sw,retVal);
            
            j204ExLog(J204_SERDES,"%s BspHalAdaptJ204cSerdesTrxEn finish [dir=%s][laneMask=%#x][sw=%d][ret=0x%#x]\n",
                        __func__, dirStr[dir], laneIdMask, sw, retTotal);
        }   
    }
    
    return retTotal;
}

static UINT32 J204SerdesRxDataSwitch(UINT32 grpMask, T_J204LinkCfg* pPara, UINT32 sw)
{
    T_J204LaneCfg *pLaneCfg = NULL;
    UINT32 laneIdMask = 0;
    UINT32 grpLoop = 0;
    UINT32 dirLoop = 0;
    UINT32 retVal = 0;
    UINT32 serdesLaneMask[J204_LANE_DIR_NUM] = {0};
    UINT32 retTotal = BSP_OK;
    UINT32 rxLaneMask = 0;

    INPUT_POINTER_CHECK(pPara);

    for(grpLoop=0; grpLoop<J204_LANE_GRP_NUM; grpLoop++)
    {
        /* 未指定的Group跳过 */
        if(!BIT_VAL(grpMask, grpLoop))
        {
            continue;
        }

        /* 由J204 lane 掩码转换为 Serdes Lane掩码 */
        for(dirLoop=RX;dirLoop<=PRX;dirLoop++)
        {
            pLaneCfg = &(pPara->laneCfg[grpLoop][dirLoop]);
            serdesLaneMask[dirLoop] = BspHalAdaptJ204GetSerdesLaneMask(dirLoop, pLaneCfg->laneIdMask);
        }

        /* rx and fb serdes lane power on */
        laneIdMask = (serdesLaneMask[RX] | serdesLaneMask[PRX]);
        rxLaneMask |= laneIdMask;
        if(laneIdMask)
        {
            retVal = BspHalAdaptJ204cSerdesTrxEn(RX, laneIdMask, sw);
            retTotal |= retVal;
            CHECK_SERDES_RETVAL(BspHalAdaptJ204cSerdesTrxEn,laneIdMask,RX,0,retVal);
        }
        j204ExLog(J204_SERDES,"%s RX dataen finish [laneMask=%#x] ret=0x%#x\n",
                __func__, laneIdMask, retVal);
    }

    return retTotal;
}


static UINT32 J204SerdesSetTxLaneEq(UINT32 laneIdMask, T_J204SerdesTxEqPara *pEqPara, UINT32 txEqLaneNum)
{
    UINT32 loop = 0;
    UINT32 retVal = 0;
    UINT32 retTotal = BSP_OK;
    UINT32 eqPre;
    UINT32 eqPost;
    UINT32 eqMain;
    UINT32 laneId = 0;
    
    for(loop=0; loop<txEqLaneNum; loop++)
    {
        laneId = pEqPara[loop].laneId;
        if(laneId >= TX_SERDES_LANE_NUM)
        {
            continue;
        }
        if(BIT_VAL(laneIdMask,laneId))
        {
            eqPre = pEqPara[loop].eqPre;
            eqPost = pEqPara[loop].eqPost;
            eqMain = pEqPara[loop].eqMain;            
            retVal = BspHalAdaptAdjustJ204SerdesTxEq(BIT_SET(laneId),eqPre,eqPost,eqMain);
            CHECK_SERDES_RETVAL(BspHalAdaptAdjustJ204SerdesTxEq,laneIdMask,0,0,retVal); 
            retTotal |= retVal;
        }
    }
    
    return retTotal;    
}

static UINT32 J204UnusedSerdesPowerDown(UINT32 txLaneMask, UINT32 rxLaneMask)
{
    UINT32 retVal = BSP_OK;
    UINT32 txPDLaneMask = ((~txLaneMask)&0xFF);
    UINT32 rxPDLaneMask = ((~rxLaneMask)&0xFF);

    if(txPDLaneMask)
    {
        retVal |= BspHalAdaptJ204cSerdesPowerDown(TX, txPDLaneMask);
        CHECK_SERDES_RETVAL(BspHalAdaptJ204cSerdesPowerDown,txPDLaneMask,TX,0,retVal); 
    }

    if(rxPDLaneMask)
    {
        retVal |= BspHalAdaptJ204cSerdesPowerDown(RX, rxPDLaneMask);
        CHECK_SERDES_RETVAL(BspHalAdaptJ204cSerdesPowerDown,rxPDLaneMask,RX,0,retVal);  
    }

    BspLog(LOG_LEVEL_0,"%s TX:[USE:%#x][PD:%#x] RX:[USE:%#x][PD:%#x] ret=%d\n",
        __func__, txLaneMask,txPDLaneMask,rxLaneMask,rxPDLaneMask,retVal);

    return retVal;
}

/*****************************************************************************
 * 函数名称: J204SerdesTxPowerOn
 * 功能描述: J204 serdes上电操作 
 * 输入参数: grpId - Group ID(也就是IC的J204 Block Id)
 * 输出参数: 无
 * 返 回 值: BSP_OK/BSP_ERROR
 * 其它说明: 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10248577@2021-08-20, 创建
 *----------------------------------------------------------------------------
 */
static UINT32 J204SerdesTxPowerOn(UINT32 grpMask, T_J204LinkCfg* pPara)
{
    T_J204LaneCfg *pLaneCfg = NULL;
    UINT32 laneIdMask = 0;
    UINT32 grpLoop = 0;
    UINT32 dirLoop = 0;
    UINT32 retVal = 0;
    UINT32 serdesLaneMask[J204_LANE_DIR_NUM] = {0};
    UINT32 retTotal = BSP_OK;
    UINT32 txLaneMask = 0;    

    INPUT_POINTER_CHECK(pPara);

    for(grpLoop=0; grpLoop<J204_LANE_GRP_NUM; grpLoop++)
    {
        /* 未指定的Group跳过 */
        if(!BIT_VAL(grpMask, grpLoop))
        {
            continue;
        }
        
        /* 由J204 lane 掩码转换为 Serdes Lane掩码 */
        for(dirLoop=RX;dirLoop<=PRX;dirLoop++)
        {
            pLaneCfg = &(pPara->laneCfg[grpLoop][dirLoop]);
            serdesLaneMask[dirLoop] = BspHalAdaptJ204GetSerdesLaneMask(dirLoop, pLaneCfg->laneIdMask);
        }
        
        /* tx serdes lane power on */
        laneIdMask = serdesLaneMask[TX];
        txLaneMask |= laneIdMask;
        if(laneIdMask)
        {
            retVal = BspHalAdaptJ204cSerdesPowerOn(TX, laneIdMask);
            retTotal |= retVal;
            CHECK_SERDES_RETVAL(BspHalAdaptJ204cSerdesPowerOn,laneIdMask,TX,0,retVal);
        }
        j204ExLog(J204_SERDES,"%s TX powon finish [laneMask=%#x] ret=0x%#x\n", 
                __func__, laneIdMask, retVal);

    }

    return retTotal;    
}

/*****************************************************************************
 * 函数名称: J204SerdesRxPowerOn
 * 功能描述: J204 serdes上电操作 
 * 输入参数: grpId - Group ID(也就是IC的J204 Block Id)
 * 输出参数: 无
 * 返 回 值: BSP_OK/BSP_ERROR
 * 其它说明: 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10248577@2021-08-20, 创建
 *----------------------------------------------------------------------------
 */
static UINT32 J204SerdesRxPowerOn(UINT32 grpMask, T_J204LinkCfg* pPara)
{
    T_J204LaneCfg *pLaneCfg = NULL;
    UINT32 laneIdMask = 0;
    UINT32 grpLoop = 0;
    UINT32 dirLoop = 0;
    UINT32 retVal = 0;
    UINT32 serdesLaneMask[J204_LANE_DIR_NUM] = {0};
    UINT32 retTotal = BSP_OK;
    UINT32 rxLaneMask = 0;

    INPUT_POINTER_CHECK(pPara);

    for(grpLoop=0; grpLoop<J204_LANE_GRP_NUM; grpLoop++)
    {
        /* 未指定的Group跳过 */
        if(!BIT_VAL(grpMask, grpLoop))
        {
            continue;
        }
        
        /* 由J204 lane 掩码转换为 Serdes Lane掩码 */
        for(dirLoop=RX;dirLoop<=PRX;dirLoop++)
        {
            pLaneCfg = &(pPara->laneCfg[grpLoop][dirLoop]);
            serdesLaneMask[dirLoop] = BspHalAdaptJ204GetSerdesLaneMask(dirLoop, pLaneCfg->laneIdMask);
        }
        
        /* rx and fb serdes lane power on */
        laneIdMask = (serdesLaneMask[RX] | serdesLaneMask[PRX]);
        rxLaneMask |= laneIdMask;
        if(laneIdMask)
        {
            retVal = BspHalAdaptJ204cSerdesPowerOn(RX, laneIdMask);
            retTotal |= retVal;
            CHECK_SERDES_RETVAL(BspHalAdaptJ204cSerdesPowerOn,laneIdMask,RX,0,retVal);
        }
        j204ExLog(J204_SERDES,"%s RX powon finish [laneMask=%#x] ret=0x%#x\n", 
                __func__, laneIdMask, retVal);
    }

    return retTotal;    
}

/* Started by AICoder, pid:d282bc3444h49c114bc10b08c06a2563cc6071f4 */
UINT32 J204SerdesTxPowerOff(UINT32 grpMask, T_J204LinkCfg* pPara)
{
    T_J204LaneCfg *pLaneCfg = NULL;
    UINT32 laneIdMask = 0;
    UINT32 grpLoop = 0;
    UINT32 dirLoop = 0;
    UINT32 retVal = 0;
    UINT32 serdesLaneMask[J204_LANE_DIR_NUM] = {0};
    UINT32 retTotal = BSP_OK;

    INPUT_POINTER_CHECK(pPara);

    for(grpLoop = 0; grpLoop<J204_LANE_GRP_NUM; grpLoop++)
    {
        /* 未指定的Group跳过 */
        if(!BIT_VAL(grpMask, grpLoop))
        {
            continue;
        }

        /* 由J204 lane 掩码转换为 Serdes Lane掩码 */
        for(dirLoop=RX;dirLoop<=PRX;dirLoop++)
        {
            pLaneCfg = &(pPara->laneCfg[grpLoop][dirLoop]);
            serdesLaneMask[dirLoop] = BspHalAdaptJ204GetSerdesLaneMask(dirLoop, pLaneCfg->laneIdMask);
        }

        laneIdMask = ((serdesLaneMask[RX] | serdesLaneMask[PRX]) & (~serdesLaneMask[TX]));
        if(laneIdMask)
        {
            retVal = BspHalAdaptJ204SdsTxResetCfg(laneIdMask, 0);
            retTotal |= retVal;
            CHECK_SERDES_RETVAL(BspHalAdaptJ204SdsTxResetCfg,laneIdMask,0,0,retVal);
        }
        j204ExLog(J204_SERDES,"%s TX powoff finish [laneMask=%#x] ret=0x%#x\n",
                __func__, laneIdMask, retVal);

    }

    return retTotal;
}
/* Ended by AICoder, pid:d282bc3444h49c114bc10b08c06a2563cc6071f4 */

/*****************************************************************************
*                                                                            *
*                              对外接口实现                                        *
*                                                                            *
*****************************************************************************/

/*****************************************************************************
 * 函数名称: BspJ204SerdesLoadFirmware
 * 功能描述: J204 serdes固件加载 
 * 输入参数: grpId - Group ID(也就是IC的J204 Block Id)
 * 输出参数: 无
 * 返 回 值: BSP_OK/BSP_ERROR
 * 其它说明: 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10248577@2021-08-20, 创建
 *----------------------------------------------------------------------------
 */
UINT32 J204SerdesLoadFirmware(UINT32 index, UINT32 grpMask, T_J204LinkCfg* pPara)
{
    UINT32 phyLoop = 0;
    UINT32 retVal = BSP_OK;
    UINT32 laneMask[J204_LANE_DIR_NUM] = {0};
    UINT32 dataRate[J204_LANE_DIR_NUM] = {0};
    UINT32 allLaneMask = 0;
    UINT32 targetLaneMask = 0;
    UINT32 retTotal = BSP_OK;
    UINT32 loop = 0;

    INPUT_POINTER_CHECK(pPara);

    /* 获取全部Lane的掩码(由J204 lane 掩码转换为 Serdes Lane掩码) */
    allLaneMask = CollectSerdesLaneMask(pPara, laneMask);

    /* APB复位 -> 释放 */
    retVal = BspHalAdaptJ204SerdesPhyApbRst(allLaneMask, 0);
    retTotal |= retVal;
    BspSysUsDelay(10);
    retVal = BspHalAdaptJ204SerdesPhyApbRst(allLaneMask, 1);
    retTotal |= retVal;

    /* 固件加载是以Phy为单位进行 */
#if 0 
    for(phyLoop=0; phyLoop<SERDES_PHY_NUM; phyLoop++)
    {
#else /* 规避概率性PHY固件加载失败问题，交换PHY加载顺序 */
    for(loop=0; loop<SERDES_PHY_NUM; loop++)
    {
        phyLoop = 1 - loop;
#endif
        
        if(allLaneMask & s_serdesMaskGrp[phyLoop])
        {
            /* 获取同一个Phy内的lane掩码 */
            targetLaneMask = ((laneMask[TX] | laneMask[RX]) & s_serdesMaskGrp[phyLoop]);

            /* 获取Tx lane和Rx lane的线速率 */
            dataRate[TX] = GetTxLaneDataRate(pPara, (laneMask[TX] & s_serdesMaskGrp[phyLoop]));
            dataRate[RX] = GetRxLaneDataRate(pPara, (laneMask[RX] & s_serdesMaskGrp[phyLoop]));
            
            /* 加载固件 */
            retVal = BspHalAdaptJ204cSerdesLoadFrmware(targetLaneMask, dataRate[TX], dataRate[RX]);
            retTotal |= retVal;
            CHECK_LOADFW_RETVAL(BspHalAdaptJ204cSerdesLoadFrmware,targetLaneMask,dataRate[TX], dataRate[RX],retVal);    
        }
        j204ExLog(J204_SERDES,"%s load fimrware finish [laneMask=%#x dataRate=%d,%d] ret=0x%#x\n",
                    __func__, targetLaneMask, dataRate[TX], dataRate[RX], retTotal);

    }
       
    return retTotal;    
}

/*****************************************************************************
 * 函数名称: J204SerdesPowerDown
 * 功能描述: J204 serdes下电操作 
 * 输入参数: grpId - Group ID(也就是IC的J204 Block Id)
 * 输出参数: 无
 * 返 回 值: BSP_OK/BSP_ERROR
 * 其它说明: 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10248577@2021-08-20, 创建
 *----------------------------------------------------------------------------
 */
UINT32 J204SerdesPowerDown(UINT32 index, UINT32 grpMask, T_J204LinkCfg* pPara)
{
    T_J204LaneCfg *pLaneCfg = NULL;
    UINT32 laneIdMask = 0;
    UINT32 grpLoop = 0;
    UINT32 dirLoop = 0;
    UINT32 retVal = 0;
    UINT32 serdesLaneMask[J204_LANE_DIR_NUM] = {0};
    UINT32 retTotal = BSP_OK;

    INPUT_POINTER_CHECK(pPara);

    for(grpLoop=0; grpLoop<J204_LANE_GRP_NUM; grpLoop++)
    {
        /* 未指定的Group跳过 */
        if(!BIT_VAL(grpMask, grpLoop))
        {
            continue;
        }
        /* 由J204 lane 掩码转换为 Serdes Lane掩码 */
        for(dirLoop=RX;dirLoop<=PRX;dirLoop++)
        {
            pLaneCfg = &(pPara->laneCfg[grpLoop][dirLoop]);
            serdesLaneMask[dirLoop] = BspHalAdaptJ204GetSerdesLaneMask(dirLoop, pLaneCfg->laneIdMask);
        }
        
        /* tx serdes lane power on */
        laneIdMask = serdesLaneMask[TX];
        if(laneIdMask)
        {
            retVal = BspHalAdaptJ204cSerdesPowerDown(TX, laneIdMask);
            retTotal |= retVal;
            CHECK_RETVAL_PRN(BspHalAdaptJ204cSerdesPowerDown,retVal);
        }

        j204ExLog(J204_SERDES,"%s TX powdown finish [laneMask=%#x] ret=0x%#x\n", __func__, laneIdMask,retVal);

        /* rx and fb serdes lane power on */
        laneIdMask = (serdesLaneMask[RX] | serdesLaneMask[PRX]);
        if(laneIdMask)
        {
            retVal = BspHalAdaptJ204cSerdesPowerDown(RX, laneIdMask);
            retTotal |= retVal;
            CHECK_RETVAL_PRN(BspHalAdaptJ204cSerdesPowerDown,retVal);
        }

        j204ExLog(J204_SERDES,"%s RX powdown finish [laneMask=%#x] ret=0x%#x\n", __func__, laneIdMask,retVal);
    }

    return retTotal;    
}

/*****************************************************************************
 * 函数名称: J204SerdesAllPowerDown
 * 功能描述: J204 serdes下电操作 
 * 输入参数: grpId - Group ID(也就是IC的J204 Block Id)
 * 输出参数: 无
 * 返 回 值: BSP_OK/BSP_ERROR
 * 其它说明: 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10248577@2021-08-20, 创建
 *----------------------------------------------------------------------------
 */
UINT32 J204SerdesAllPowerDown(UINT32 index, UINT32 grpMask, T_J204LinkCfg* pPara)
{
    UINT32 txLaneIdMask = 0xFF;
    UINT32 rxLaneIdMask = 0xFF;
    UINT32 retVal = 0;
    UINT32 retTotal = BSP_OK;

    INPUT_POINTER_CHECK(pPara);

    retVal = BspHalAdaptJ204cSerdesPowerDown(TX, txLaneIdMask);
    retTotal |= retVal;
    CHECK_RETVAL_PRN(BspHalAdaptJ204cSerdesPowerDown,retVal);

    retVal = BspHalAdaptJ204cSerdesPowerDown(RX, rxLaneIdMask);
    retTotal |= retVal;
    CHECK_RETVAL_PRN(BspHalAdaptJ204cSerdesPowerDown,retVal);

    j204ExLog(J204_SERDES,"%s All Lane Powdown Finish [txLaneMask=%#x] [rxLaneMask=%#x] ret=0x%#x\n", 
            __func__, txLaneIdMask,rxLaneIdMask,retTotal);

    return retTotal;    
}

/*****************************************************************************
 * 函数名称: J204SerdesTxInit
 * 功能描述: J204 serdes Tx lane Data使能 
 * 输入参数: grpId - Group ID(也就是IC的J204 Block Id)
 * 输出参数: 无
 * 返 回 值: BSP_OK/BSP_ERROR
 * 其它说明: 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10248577@2021-08-20, 创建
 *----------------------------------------------------------------------------
 */
UINT32 J204SerdesTxInit(UINT32 index, UINT32 grpMask, T_J204LinkCfg* pPara)
{
    UINT32 en = SWITCH_ON;
    UINT32 retVal = BSP_OK;

    INPUT_POINTER_CHECK(pPara);

    /* serdes power on */
    retVal |= J204SerdesTxPowerOn(grpMask, pPara);
    CHECK_RETVAL_PRN(J204SerdesTxPowerOn,retVal);
    /* serdes data enbale */
    retVal |= J204SerdesDataSwitch(grpMask,pPara,TX, en);
    CHECK_RETVAL_PRN(J204SerdesDataSwitch,retVal);

    return retVal;
}

/*****************************************************************************
 * 函数名称: J204SerdesRxInit
 * 功能描述: J204 serdes Rx lane Data使能 
 * 输入参数: grpId - Group ID(也就是IC的J204 Block Id)
 * 输出参数: 无
 * 返 回 值: BSP_OK/BSP_ERROR
 * 其它说明: 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10248577@2021-08-20, 创建
 *----------------------------------------------------------------------------
 */
UINT32 J204SerdesRxInit(UINT32 index, UINT32 grpMask, T_J204LinkCfg* pPara)
{
    UINT32 retVal = BSP_OK;
    UINT32 retTotal = BSP_OK;
    UINT32 en = SWITCH_ON;

    INPUT_POINTER_CHECK(pPara);

    retVal = J204SerdesTxPowerOff(grpMask, pPara);
    CHECK_RETVAL_PRN(J204SerdesTxPowerOff,retVal);
    retTotal |= retVal;

    /* serdes power on */
    retVal = J204SerdesRxPowerOn(grpMask, pPara);
    CHECK_RETVAL_PRN(J204SerdesRxPowerOn,retVal);
    retTotal |= retVal;

    /* serdes data enbale */
    retVal = J204SerdesRxDataSwitch(grpMask,pPara,en);
    CHECK_RETVAL_PRN(J204SerdesRxDataSwitch,retVal);
    retTotal |= retVal;

    return retTotal;
}

/*****************************************************************************
 * 函数名称: J204SerdesSerTxEq
 * 功能描述: 配置J204 serdes Tx lane预加重参数 
 * 输入参数: grpId - Group ID(也就是IC的J204 Block Id)
 * 输出参数: 无
 * 返 回 值: BSP_OK/BSP_ERROR
 * 其它说明: 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10248577@2021-08-20, 创建
 *----------------------------------------------------------------------------
 */
UINT32 J204SerdesSetTxEq(UINT32 index, UINT32 grpMask, T_J204LinkCfg* pPara)
{
    UINT32 laneIdMask = 0;
    UINT32 grpLoop = 0;
    UINT32 retVal = 0;
    UINT32 retTotal = BSP_OK;
    T_J204SerdesTxEqPara *pEqPara = NULL;
    UINT32 txEqLaneNum = 0;

    INPUT_POINTER_CHECK(pPara);

    /* 获取预加重参数信息 */
    pEqPara = pPara->serdesTxEq.pEqPara;
    txEqLaneNum = pPara->serdesTxEq.laneNum;
    if(NULL == pEqPara || 0 == txEqLaneNum)
    {
        /* 未指定预加重参数，则不进行配置 */
        return BSP_OK;
    }

    for(grpLoop=0; grpLoop<J204_LANE_GRP_NUM; grpLoop++)
    {
        /* 未指定的Group跳过 */
        if(!BIT_VAL(grpMask, grpLoop))
        {
            continue;
        }
        /* 由J204 lane 掩码转换为 Serdes Lane掩码 */
        laneIdMask = BspHalAdaptJ204GetSerdesLaneMask(TX, pPara->laneCfg[grpLoop][TX].laneIdMask);
        if(laneIdMask)
        {
            retVal = J204SerdesSetTxLaneEq(laneIdMask, pEqPara, txEqLaneNum);
            retTotal |= retVal;
            CHECK_RETVAL_PRN(J204SerdesSetTxLaneEq,retVal);
        }

        j204ExLog(J204_SERDES,"%s J204SerdesSetTxLaneEq finish [laneMask=%#x][ret=0x%#x]\n",
                    __func__, laneIdMask, retVal);
    }
    
    return retTotal;    
}




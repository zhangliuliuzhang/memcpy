/*****************************************************************************
 * 版权所有(C) 2020, ZTE Corp. ZXSDR-RRU Platform BSP
 *----------------------------------------------------------------------------
 * 模 块 名 : BSP
 * 文件名称 : j204_crm.c
 * 文件标识 : {[N/A]}
 * 内容摘要 : 本文件主要提供J204模块crm相关实现
 * 注意事项 : 无
 * 作    者 : wangtao 10248577
 * 创建日期 : 2020-12-10 
 * 当前版本 : Ver1.0
 *----------------------------------------------------------------------------
 * 变更记录 :
 *
 * $记录1
 * 变 更 单:
 * 责 任 人:
 * 修改日戳:
 * 变更说明:

 *----------------------------------------------------------------------------
 */
#include "j204_ic4_2.h"
#include "ichaladaptbspapi_j204.h"
#include "ichaladaptbspapi_comm.h"
#include "funccommon_log.h"

/**************************************************************************
 *                                  宏定义
 **************************************************************************/
#define J204_HELP_LEN (50)

/****************************************************************************
 *                               数据类型定义
 ****************************************************************************/


/****************************************************************************
*                         全局变量定义                                            *
****************************************************************************/
UINT8 g_j204HelpPrint[][J204_HELP_LEN] =
{
    "j204Setprnsw 0x7",
    "show204link",
    "showtrxlink trxMask",
    "showj204linkpara",
    "showj204sysrefcfg",
    "showj204linkreg dir",
    "showj204cmdreg dir",
    "showj204lanemap",
    "sendpulsesysref num,mask",
    "sendcontinuesysref sw,mask",
    "showj204step",
    "show204reset",
    "j204stepdebug linkStep,stepIdx",
    "BspJ204LinkInitStep",
    "BspJ204LinkPreStep",
    "BspJ204LinkPostStep",
    "j204exthelp",
    "j204serdesexthelp",
    "j204mts2help",
    "j204mts1help",
};

/****************************************************************************
*                              全局变量                                         *
****************************************************************************/
/* J204 建链状态相关寄存器 */
static UINT32 s_204linkRegAddr[7][2] = 
{
    /* ul b0      fb b0  */
    {0xc7e0009c,0xc7e0089c}, /* sync state lane*4 */
    {0xc7e0005c,0xc7e0085c}, /* crc check lane*4 */
    {0xc7e00114,0xc7e00914}, /* ram addr err lane*4 */
    {0xc7e00270,0xc7e00a70}, /* ram addr diff lane*4 */

    {0xc7e00124,0xc7e00924}, /* sysref state */
    {0xc7e0003c,0xc7e0083c}, /* lemc offset */
    {0xC7E0105C,0xC7E0115C}  /* Tx sysref state */
};

/* J204 复位状态相关寄存器 */
static UINT32 s_J204CrmResetRegAddr[4] = 
{
    0xd4c00448, //RX block0
    0xd4c00440, //TX block0
    0xd4c0044c, //FB block0
    0xd4c0046c, //RF and GLB
};


static const CHAR dirStr[4][4] = {"RX","TX","PRX","RF"};
static const CHAR laneName[8][4] = {"F0","F1","R0","R1","F2","F3","R2","R3"};


/*****************************************************************************
*                                                                            *
*                              内部函数实现                                        *
*                                                                            *
*****************************************************************************/
VOID show204link(VOID)
{
    UINT32 index = 0;
    UINT32 regData = 0;
    UINT32 regAddr = 0;

    dbgInfo("LANE_DIR  SYNC_STATE  CRC_ERR_CHECK  RAM_ADDR_ERR  RAM_ADDR_DIFF  SYSREF_STATE  LEMC_OFFSET\n");
    for(index=0; index<8; index++)
    {
#ifdef USE_INPUT_RF_LANEMASK 
        dbgInfo("%-8s  ", laneName[index]);
#else
        /*  DIR  */
        dbgInfo("%-8s  ", index<4?"RX":"FB");
        /* LANE  */
        dbgInfo("%-6d  ", index%4);
#endif        
        /* sync state */
        regAddr = s_204linkRegAddr[0][index/4]+(index%4)*4; 
        BspHalAdaptDpdicRegRd(0, regAddr, 0, &regData);
        dbgInfo("0x%-8x  ", regData);
        /* crc state */
        regAddr = s_204linkRegAddr[1][index/4]+(index%4)*4; 
        BspHalAdaptDpdicRegRd(0, regAddr, 0, &regData);
        dbgInfo("0x%-11x  ", regData);
        /* ram addr err */
        regAddr = s_204linkRegAddr[2][index/4]+(index%4)*4; 
        BspHalAdaptDpdicRegRd(0, regAddr, 0, &regData);
        dbgInfo("0x%-10x  ", regData);
        /* ram addr diff */
        regAddr = s_204linkRegAddr[3][index/4]+(index%4)*4; 
        BspHalAdaptDpdicRegRd(0, regAddr, 0, &regData);
        dbgInfo("0x%-11x  ", regData);
        if(index%4==0)
        {
            /* sysref state */
            regAddr = s_204linkRegAddr[4][index/4]; 
            BspHalAdaptDpdicRegRd(0, regAddr, 0, &regData);
            dbgInfo("0x%-10x  ", regData);
            /* lemc offset */
            regAddr = s_204linkRegAddr[5][index/4]; 
            BspHalAdaptDpdicRegRd(0, regAddr, 0, &regData);
            dbgInfo("0x%-9x  ", regData);        
        }
        dbgInfo("\n");
    }

    regAddr = s_204linkRegAddr[6][0];
    BspHalAdaptDpdicRegRd(0, regAddr, 0, &regData);
    dbgInfo("%-8s  0x%-64x", "TX sys0", regData);

    regAddr = s_204linkRegAddr[6][1];
    BspHalAdaptDpdicRegRd(0, regAddr, 0, &regData);
    dbgInfo("%-8s  0x%-64x\n", "TX sys1", regData);

    return;    

}

VOID showtrxlink(UINT32 trxMask)
{
    UINT32 retVal = BSP_OK;

    if(!trxMask)
    {
        trxMask = 0xFF;
    }
    
    retVal = BspJ204GetTrxLinkStat(trxMask); 
    if(BSP_OK != retVal)
    {
        dbgInfo("Transceiver J204 Link Status is not OK\n");
    }

    (VOID)BspJ204PrnTrxLinkStat(trxMask);
    
    return;    

}

VOID show204reset(VOID)
{
    UINT32 index = 0;
    UINT32 regData = 0;
    UINT32 regAddr = 0;

    dbgInfo("DIR  REGADDR     RESET_STATE\n");
    for(index=0; index<NELEMENTS(s_J204CrmResetRegAddr); index++)
    {
        regAddr = s_J204CrmResetRegAddr[index];
        BspHalAdaptDpdicRegRd(0, regAddr, 0, &regData);
        dbgInfo("%-3s  0x%08x  0x%08x\n", dirStr[index], regAddr, regData);        
    }

    return;
}

UINT32 BspRecord204LinkStatus(VOID)
{
    UINT32 index = 0;
    UINT32 ulLinkStatRegData[4] = {0};
    UINT32 fbLinkStatRegData[4] = {0};
    UINT32 ulCrcCheckRegData[4] = {0};
    UINT32 fbCrcCheckRegData[4] = {0};
    UINT32 ulRwAddrDifRegData[4] = {0};
    UINT32 fbRwAddrDifRegData[4] = {0};
    UINT32 refClkRegData = 0;
    UINT32 regAddr = 0;

    /* 204建链状态及CRC误码记录 */
    for(index=0; index<4; index++)
    {
        /* ul sync state */
        regAddr = s_204linkRegAddr[0][0] + index*4; 
        BspHalAdaptDpdicRegRd(0, regAddr, 0, &ulLinkStatRegData[index]);
        /* fb sync state */
        regAddr = s_204linkRegAddr[0][1] + index*4; 
        BspHalAdaptDpdicRegRd(0, regAddr, 0, &fbLinkStatRegData[index]);
        /* ul crc check */
        regAddr = s_204linkRegAddr[1][0] + index*4; 
        BspHalAdaptDpdicRegRd(0, regAddr, 0, &ulCrcCheckRegData[index]);        
        /* fb crc check */
        regAddr = s_204linkRegAddr[1][1] + index*4; 
        BspHalAdaptDpdicRegRd(0, regAddr, 0, &fbCrcCheckRegData[index]);
        /* ul rwaddrdiff */
        regAddr = s_204linkRegAddr[3][0] + index*4;
        BspHalAdaptDpdicRegRd(0, regAddr, 0, &ulRwAddrDifRegData[index]);
        /* fb rwaddrdiff */
        regAddr = s_204linkRegAddr[3][1] + index*4;
        BspHalAdaptDpdicRegRd(0, regAddr, 0, &fbRwAddrDifRegData[index]);
    }
    BspLog(LOG_LEVEL_0, "UL LANE LINK STAT Addr[0x%08x] Data[0x%08x 0x%08x 0x%08x 0x%08x]\n",
                            s_204linkRegAddr[0][0], ulLinkStatRegData[0],ulLinkStatRegData[1],
                            ulLinkStatRegData[2],ulLinkStatRegData[3]);    
    BspLog(LOG_LEVEL_0, "FB LANE LINK STAT Addr[0x%08x] Data[0x%08x 0x%08x 0x%08x 0x%08x]\n",
                            s_204linkRegAddr[0][1], fbLinkStatRegData[0],fbLinkStatRegData[1],
                            fbLinkStatRegData[2],fbLinkStatRegData[3]);
    BspLog(LOG_LEVEL_0, "UL LANE CRC CHECK Addr[0x%08x] Data[0x%08x 0x%08x 0x%08x 0x%08x]\n",
                            s_204linkRegAddr[1][0], ulCrcCheckRegData[0],ulCrcCheckRegData[1],
                            ulCrcCheckRegData[2],ulCrcCheckRegData[3]);    
    BspLog(LOG_LEVEL_0, "FB LANE CRC CHECK Addr[0x%08x] Data[0x%08x 0x%08x 0x%08x 0x%08x]\n",
                            s_204linkRegAddr[1][1], fbCrcCheckRegData[0],fbCrcCheckRegData[1],
                            fbCrcCheckRegData[2],fbCrcCheckRegData[3]);
    BspLog(LOG_LEVEL_0, "UL LANE RWADDRDIF Addr[0x%08x] Data[0x%08x 0x%08x 0x%08x 0x%08x]\n",
                            s_204linkRegAddr[3][0], ulRwAddrDifRegData[0],ulRwAddrDifRegData[1],
                            ulRwAddrDifRegData[2],ulRwAddrDifRegData[3]);
    BspLog(LOG_LEVEL_0, "FB LANE RWADDRDIF Addr[0x%08x] Data[0x%08x 0x%08x 0x%08x 0x%08x]\n",
                            s_204linkRegAddr[3][1], fbRwAddrDifRegData[0],fbRwAddrDifRegData[1],
                            fbRwAddrDifRegData[2],fbRwAddrDifRegData[3]);
    /* CRC误码第二次记录，用于和第一次对比 */
    for(index=0; index<4; index++)
    {
        /* ul crc check */
        regAddr = s_204linkRegAddr[1][0] + index*4; 
        BspHalAdaptDpdicRegRd(0, regAddr, 0, &ulCrcCheckRegData[index]);        
        /* fb crc check */
        regAddr = s_204linkRegAddr[1][1] + index*4; 
        BspHalAdaptDpdicRegRd(0, regAddr, 0, &fbCrcCheckRegData[index]);              
    }
    BspLog(LOG_LEVEL_0, "UL LANE CRC CHECK Addr[0x%08x] Data[0x%08x 0x%08x 0x%08x 0x%08x]\n",
                            s_204linkRegAddr[1][0], ulCrcCheckRegData[0],ulCrcCheckRegData[1],
                            ulCrcCheckRegData[2],ulCrcCheckRegData[3]);    
    BspLog(LOG_LEVEL_0, "FB LANE CRC CHECK Addr[0x%08x] Data[0x%08x 0x%08x 0x%08x 0x%08x]\n",
                            s_204linkRegAddr[1][1], fbCrcCheckRegData[0],fbCrcCheckRegData[1],
                            fbCrcCheckRegData[2],fbCrcCheckRegData[3]); 

    /* DPDIC参考时钟状态 */
    regAddr = 0xd4c00c10; 
    BspHalAdaptDpdicRegRd(0, regAddr, 0, &refClkRegData);  
    BspLog(LOG_LEVEL_0, "DPDIC REF CLK STATE Addr[0x%08x] Data[0x%08x]\n",regAddr,refClkRegData);
    
    return BSP_OK;
}

VOID J204LinkInitStepDbg(UINT32 index, UINT32 grpMask, T_J204LinkCfg* pPara)
{
    switch (index)
    {
        case J204_LINK_INIT_STEP_IDX(J204_INIT_RESET_ALL):
        case J204_LINK_INIT_STEP_IDX(J204_INIT_RELEASE_APB):
        {
            show204reset();
            break;
        }
        default:
        {
            break;
        }
    }
    return;   
}

VOID J204LinkPreStepDbg(UINT32 index, UINT32 grpMask, T_J204LinkCfg* pPara)
{
    switch (index)
    {
        case J204_LINK_PRE_STEP_IDX(J204_PRE_RESET_TX):
        case J204_LINK_PRE_STEP_IDX(J204_PRE_RELEASE_TX_LOGIC):
        case J204_LINK_PRE_STEP_IDX(J204_PRE_RELEASE_TX_SYSREF):
        case J204_LINK_PRE_STEP_IDX(J204_PRE_RELEASE_TX_WORKMAP):
        case J204_LINK_PRE_STEP_IDX(J204_PRE_RELEASE_TX_WORKLANE):
        {
            show204reset();
            break;
        }
        default:
        {
            break;
        }
    }
    return;  
}

VOID J204LinkPostStepDbg(UINT32 index, UINT32 grpMask, T_J204LinkCfg* pPara)
{
    switch (index)
    {
        case J204_LINK_POST_STEP_IDX(J204_POST_RESET_RXFB):
        case J204_LINK_POST_STEP_IDX(J204_POST_RELEASE_RXFB_WORKLANE):
        case J204_LINK_POST_STEP_IDX(J204_POST_RELEASE_RXFB_CTRL):
        case J204_LINK_POST_STEP_IDX(J204_POST_RELEASE_RXFB_WORKMAP):
        case J204_LINK_POST_STEP_IDX(J204_POST_RELEASE_RXFB_LOGIC):
        case J204_LINK_POST_STEP_IDX(J204_POST_RELEASE_RF_TRANS):
        {
            show204reset();
            break;
        }
        case J204_LINK_POST_STEP_IDX(J204_POST_CLOSE_SYSREF):
        {
            BspRecord204LinkStatus();            
            break;
        }
        default:
        {
            break;
        }
    }
    return;  
}

VOID j204serdesexthelp(VOID)
{
    dbgInfo("send and recv prbs: \n");
    dbgInfo("-------------------------------------------------------------------------\n");
    dbgInfo("j204serdes_tx_prbs_en laneIdMask,prbsMode  exp: close[0xff,0]; open[0xff,1(prbs31)]\n");
    dbgInfo("j204serdes_rx_prbs_en laneIdMask,prbsMode  exp: close[0xff,0]; open[0xff,1(prbs31)]\n");
    dbgInfo("-------------------------------------------------------------------------\n");


    dbgInfo("\ncheck recv prbs: \n");
    dbgInfo("-------------------------------------------------------------------------\n");
    dbgInfo("j204serdes_rx_prbs_en 0xff,0\n");
    dbgInfo("j204serdes_rx_prbs_clr_error 0xff\n");
    dbgInfo("j204serdes_rx_prbs_en 0xff,1\n");
    dbgInfo("j204serdeshelp2 0x3,0xf\n");
    dbgInfo("-------------------------------------------------------------------------\n");

    dbgInfo("\nserdes loopback: \n");
    dbgInfo("-------------------------------------------------------------------------\n");
    dbgInfo("j204serdes_tx2rx_loop_en 0xf\n");    
    dbgInfo("-------------------------------------------------------------------------\n");

    dbgInfo("\ncheck serdes status: \n");
    dbgInfo("-------------------------------------------------------------------------\n");
    dbgInfo("j204serdeshelp1 phyIdMask,laneIdMask exp: rx_valid[1:cdr ok; 0:cdr fail]\n");
    dbgInfo("showj204phy phyid exp: Signal[1:ok; 0:fail], adaptFom[0:fail;n*10-n*100:ok;too big:fail]\n");
    dbgInfo("IcHalShowJ204SerdesEye laneIdMask\n"); 
    dbgInfo("IcHalApiGetJ204SerdesTxEq laneIdMask\n"); 
    dbgInfo("IcHalApiAdjustJ204SerdesTxEq laneIdMask,eqPre,eqPost,eqMain \n"); 
    dbgInfo("IcHalApiJ204SdsRxDataEn laneIdMask,enable \n"); 
    dbgInfo("-------------------------------------------------------------------------\n");
    
    return;
}

VOID j204mts1help(VOID)
{
    dbgInfo("check 204 link status: \n");
    dbgInfo("-------------------------------------------------------------------------\n");
    dbgInfo("MtsTest204c chip \n");
    dbgInfo("-------------------------------------------------------------------------\n");

    dbgInfo("\nprbs test: \n");
    dbgInfo("-------------------------------------------------------------------------\n");
    dbgInfo("MtsSerdesTxRxPrbs31 chip,laneId exp:laneId[0-3]\n");
    dbgInfo("MtsSerdesLoopTest chip,laneId   exp:laneId[0-3]\n");
    dbgInfo("MtsDisablePrbs chip,laneId   exp:laneId[0-3]\n");
    dbgInfo("-------------------------------------------------------------------------\n");

    dbgInfo("\nrx serdes eye: \n");
    dbgInfo("-------------------------------------------------------------------------\n");
    dbgInfo("Mts2SerdesEyeMargin chip,chan\n");
    dbgInfo("-------------------------------------------------------------------------\n"); 

    dbgInfo("\nsend 0x5a5a from map for all lanes: \n");
    dbgInfo("-------------------------------------------------------------------------\n");
    dbgInfo("send fix value in rx\n");
    dbgInfo("MtsSet204CTxMapRoute 0,0\n");
    dbgInfo("wrmts 0,0x20033080,0x5a5a\n");
    dbgInfo("recover normal data in rx\n");
    dbgInfo("MtsSet204CTxMapRoute 0,1\n");
    dbgInfo("send fix value in fb\n");
    dbgInfo("wrmts 0,0x20034000,0x11\n");
    dbgInfo("wrmts 0,0x20034004,0x3a3a\n");
    dbgInfo("-------------------------------------------------------------------------\n");

    dbgInfo("\nmts loop back\n");
    dbgInfo("-------------------------------------------------------------------------\n");
    dbgInfo("wrmts 0,0x20033aa4,0xf  exp:loopback\n");
    dbgInfo("wrmts 0,0x20033aa4,0x0  exp:recover\n");
    dbgInfo("-------------------------------------------------------------------------\n");

    dbgInfo("\nprofile: \n");
    dbgInfo("-------------------------------------------------------------------------\n");
    dbgInfo("MtsGetConfigFile \n");
    dbgInfo("-------------------------------------------------------------------------\n");

    return;

}

VOID j204mts2help(VOID)
{
    dbgInfo("check 204 link status: \n");
    dbgInfo("-------------------------------------------------------------------------\n");
    dbgInfo("Mts2Test204c chip,bank  exp: bank[0,1]\n");
    dbgInfo("-------------------------------------------------------------------------\n");
    
    dbgInfo("\nprbs test: \n");
    dbgInfo("-------------------------------------------------------------------------\n");
    dbgInfo("Mts2SerdesTxRxPrbs31 chip,bank,laneId exp:bank[0,1] laneId[0-3]\n");
    dbgInfo("Mts2SerdesLoopTest   chip,bank,laneId exp:bank[0,1] laneId[0-3] \n");
    dbgInfo("Mts2DisablePrbs   chip,bank,laneId exp:bank[0,1] laneId[0-3] \n");
    dbgInfo("-------------------------------------------------------------------------\n");

    dbgInfo("\ncheck serdes status: \n");
    dbgInfo("-------------------------------------------------------------------------\n");
    dbgInfo("Mts2rdserdes 0,0,0x804e  exp:bank0, lane offset:0x100, bit15[1:OK;0:ERR]\n");
    dbgInfo("Mts2rdserdes 0,1,0x804e  exp:bank1, lane offset:0x100, bit15[1:OK;0:ERR]\n");
    dbgInfo("Mts2Get204TxSerdesClk 0,0\n");
    dbgInfo("Mts2Get204TxSerdesClk 0,1\n");
    dbgInfo("-------------------------------------------------------------------------\n");

    dbgInfo("\nrx serdes eye: \n");
    dbgInfo("-------------------------------------------------------------------------\n");
    dbgInfo("Mts2SerdesEyeMargin chip,bank,chan\n");
    dbgInfo("Mts2rdserdes chip,bank,0x802c  exp:bank[0,1],lane offset:0x100\n");
    dbgInfo("-------------------------------------------------------------------------\n"); 

    dbgInfo("\nsample: \n");
    dbgInfo("-------------------------------------------------------------------------\n");
    dbgInfo("Mts2SingleSample chip,link,chan,place,37513 \n");
    dbgInfo("exp:link[link tx 0 rx 1 orx 2] place[place RX1-22 TX1-17 ORX1-13]\n");
    dbgInfo("FB0 exp:Mts2SingleSample 0,2,0,1,37513\n");
    dbgInfo("TX0 exp:Mts2SingleSample 0,0,0,8,37513\n");
    dbgInfo("RX0 exp:Mts2SingleSample 0,1,0,7,37513\n");
    dbgInfo("-------------------------------------------------------------------------\n");

    dbgInfo("\nprofile: \n");
    dbgInfo("-------------------------------------------------------------------------\n");
    dbgInfo("Mts2GetConfigFile \n");
    dbgInfo("-------------------------------------------------------------------------\n");

    dbgInfo("\nsend 0x5a5a from map for all lanes: \n");
    dbgInfo("-------------------------------------------------------------------------\n");
    dbgInfo("bank0\n");
    dbgInfo("wrmts2 chip,0x20033000,0x1 exp: para2[0:adc;1:fixed value]\n");
    dbgInfo("wrmts2 chip,0x20033004,0x5a5a\n");
    dbgInfo("bank1\n");
    dbgInfo("wrmts2 chip,0x20063000,0x1 exp: para2[0:adc;1:fixed value]\n");
    dbgInfo("wrmts2 chip,0x20063004,0x5a5a\n");    
    dbgInfo("-------------------------------------------------------------------------\n");

    dbgInfo("\nfdd mode: \n");
    dbgInfo("-------------------------------------------------------------------------\n");
    dbgInfo("Mts2TddCfg chip,1 exp:[0:TDD;1:FDD ON;2:FDD OFF]\n");
    dbgInfo("-------------------------------------------------------------------------\n");
    
    return;
}

VOID j204exthelp(VOID)
{
    dbgInfo("204 sample: \n");
    dbgInfo("-------------------------------------------------------------------------\n");
    dbgInfo("HalSampleJ204Cfg uiBlockId,uiLaneId,uiMId,uiSamDir,uiSamPtSel,uiSamEndFlag \n");
    dbgInfo("para3: uiMId[M mask M0-M7:map0; M8-M15:map1] \n");
    dbgInfo("para4: uiSamDir[0:DL,1:UL,2:FB] \n");
    dbgInfo("para5: uiSamPtSel tx        [1:64b66b,2:MAP output 3:MAP input  ] \n");    
    dbgInfo("                  rx and fb [1:64b66b,2:MAP input  3:MAP output ] \n");
    dbgInfo("-------------------------------------------------------------------------\n");

    dbgInfo("\n204 discramber: \n");
    dbgInfo("-------------------------------------------------------------------------\n");
    dbgInfo("wric 0xC7E01048,0  exp: tx map0 discramber [1:en]\n");
    dbgInfo("wric 0xC7E01148,0  exp: tx map1 discramber [1:en]\n");
    dbgInfo("wric 0xc7e00004,0  exp: rx map0 discramber [1:en]\n");
    dbgInfo("wric 0xc7e00704,0, exp: fb map0 discramber [1:en]\n");
    dbgInfo("-------------------------------------------------------------------------\n");

    dbgInfo("\n204 pcs loopback: \n");
    dbgInfo("-------------------------------------------------------------------------\n");
    dbgInfo("wric 0xc7e01620,0x13  exp: 66bit\n");
    dbgInfo("wric 0xc7e01620,0x3   exp: 40bit\n");
    dbgInfo("-------------------------------------------------------------------------\n");

    dbgInfo("\nsysref: \n");
    dbgInfo("-------------------------------------------------------------------------\n");
    dbgInfo("rdic 0xc7e016dc,1  sysref mux clk sel -- logic_3_0:0; logic_3_1:1\n");
    dbgInfo("rdic 0xc7e0150c,1  sysref period\n");
    dbgInfo("rdic 0xc7e01514,1  sysref width\n");
    dbgInfo("-------------------------------------------------------------------------\n");
    
    return;  
}


VOID showj204lanemap(VOID)
{
    dbgInfo("---------------------------------------------------------------------------\n");
    dbgInfo("phy      |          phy0           |          phy1           |             \n");
    dbgInfo("phy      | lane0 lane1 lane2 lane3 | lane0 lane1 lane2 lane3 |             \n");
    dbgInfo("serdes   | lane0 lane1 lane2 lane3 | lane4 lane5 lane6 lane7 |             \n");
    dbgInfo("j204c    |  tx0   tx1   tx2   tx3  |  tx4   tx5   tx6   tx7  |   *204 lane \n");
    dbgInfo("j204c    |  rx0   rx1   rx2   rx3  |  fb0   fb1   fb2   fb3  |   *204 lane \n");
    dbgInfo("rf       |  tx0   tx1   tx2   tx3  |  tx4   tx5   tx6   tx7  |   *rf lane  \n");
    dbgInfo("rf       |  fb0   fb1   rx0   rx1  |  fb2   fb3   rx2   rx3  |   *rf lane  \n");
    dbgInfo("---------------------------------------------------------------------------\n");
    return;
}


/*****************************************************************************
*                                                                            *
*                              对外接口实现                                        *
*                                                                            *
*****************************************************************************/
UINT32 j204help(VOID)
{
    UINT32 udPrintCnt = 0;
    UINT32 udCnt = 0;

    dbgInfo("j204 Help:\n");

    udPrintCnt = sizeof(g_j204HelpPrint) / J204_HELP_LEN;
    for(udCnt = 0; udCnt < udPrintCnt; udCnt++)
    {
        dbgInfo(" %s \n", g_j204HelpPrint[udCnt]);
    }

    return (UINT32)BSP_OK;
}

static __attribute((constructor)) void J204DbgIc42Init()
{
    BspJ204SetDbgFunc(J204_LINK_INIT_STEP, J204LinkInitStepDbg);
    BspJ204SetDbgFunc(J204_LINK_PRE_STEP, J204LinkPreStepDbg);
    BspJ204SetDbgFunc(J204_LINK_POST_STEP, J204LinkPostStepDbg);
}






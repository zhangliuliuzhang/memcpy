/*****************************************************************************
 * 版权所有(C) 2020, ZTE Corp. ZXSDR-RRU Platform BSP
 *----------------------------------------------------------------------------
 * 模 块 名 : BSP
 * 文件名称 : j204_block.c
 * 文件标识 : {[N/A]}
 * 内容摘要 : 本文件主要提供J204模块相关实现
 * 注意事项 : 无
 * 作    者 : wangtao 10248577
 * 创建日期 : 2020-12-10 
 * 当前版本 : Ver1.0
 *----------------------------------------------------------------------------
 * 变更记录 :
 *
 * $记录1
 * 变 更 单:
 * 责 任 人:
 * 修改日戳:
 * 变更说明:

 *----------------------------------------------------------------------------
 */
#include "j204_ic4_2.h"
#include "ichaladaptbspapi_j204.h"
#include "j204_common.h"
#include "j204_block.h"
#include "ichaladapt_j204_ic4_2.h"
#include "icopthalcomm.h"

//#include "ichaladapt_ic4_2.h"

/**************************************************************************
 *                                 函数声明
 **************************************************************************/
UINT32 BspJ204SysrefRequest(UINT32 en, UINT32 mode, UINT32 sysrefNum, UINT32 txEnMask);


/**************************************************************************
 *                                  宏定义
 **************************************************************************/
#define J204_LANE_MAX_NUM  (8)

/****************************************************************************
 *                               数据类型定义
 ****************************************************************************/
/* link参数更新处理 */
typedef struct tagT_UpdateLinkParaCfg 
{
    UINT32 routeRegAddr;
    UINT32 targetRegAddr;
}T_UpdateLinkParaCfg;

/****************************************************************************
*                         全局变量定义                                            *
****************************************************************************/

static UINT32 s_J204autoCfgDisableFlg = 0;//标志是否屏蔽204联动寄存器，1表示屏蔽，0表示允许联动配置

/****************************************************************************
*                              全局变量                                         *
****************************************************************************/
static const CHAR dirStr[3][4] = {"RX","TX","PRX"};

/* CRC错误计数记录 */
static UINT32 s_ulCrcHighBit[J204_LANE_MAX_NUM] = {0};

T_UpdateLinkParaCfg s_updateLinkParaCfg[PRX+1] = 
{
    {0x02f0, 0x169c},
    {0x11f0, 0x1698},
    {0x0af0, 0x16A0}
};

/*****************************************************************************
*                                                                            *
*                              内部函数实现                                        *
*                                                                            *
*****************************************************************************/
static UINT32 CalcJ204TxMapWorkSel(UINT32 routeRegVal)
{
    UINT32 targetRegVal = 0;
    UINT32 loop = 0;
    UINT32 tmpVal = 0;

    for(loop=0; loop<8; loop++)
    {
        tmpVal = ((routeRegVal >> (4*loop)) & 0xF);
        /* map0 */
        if(tmpVal <= 3)
        {   
            /* phy0 */
            if(loop <= 3)
            {
                targetRegVal |= (0x0<<4);
            }
            /* phy1 */
            else 
            {
                targetRegVal |= (0x1<<4);
            }
        }
        /* map1 */
        else if(tmpVal > 3 && tmpVal <= 7)
        {
            /* phy0 */
            if(loop <= 3)
            {
                targetRegVal |= (0x1<<5);
            }
            /* phy1 */
            else 
            {
                targetRegVal |= (0x0<<5);
            }
        }
        else 
        {
            continue;
        }

    }

    return targetRegVal;
}

static UINT32 CalcJ204RxFbMapWorkSel(UINT32 dir, UINT32 routeRegVal)
{
    UINT32 targetRegVal = 0;
    UINT32 loop = 0;
    UINT32 tmpVal = 0;
    UINT32 idx0 = 0, idx1= 0;

    if(PRX == dir)
    {
        idx0 = 2;
        idx1 = 4;
    }
    else 
    {
        idx0 = 4;
        idx1 = 8;        
    }
    
    /* map0 */
    for(loop=0; loop<idx0; loop++)
    {
        tmpVal = ((routeRegVal >> (4*loop)) & 0xF);
        if(tmpVal <= 3)
        {
            targetRegVal |= ((((dir==PRX)?0x1:0x0))<<4);
        }
        else if(tmpVal > 3 && tmpVal <= 7)
        {
            targetRegVal |= ((((dir==PRX)?0x0:0x1))<<4);
        }
        else 
        {
            continue;
        }
    }

    /* map1 */
    for(loop=idx0; loop<idx1; loop++)
    {
        tmpVal = ((routeRegVal >> (4*loop)) & 0xF);
        if(tmpVal <= 3)
        {
            targetRegVal |= ((((dir==PRX)?0x0:0x1))<<5);
        }
        else if(tmpVal > 3 && tmpVal <= 7)
        {
            targetRegVal |= ((((dir==PRX)?0x1:0x0))<<5);
        }
        else 
        {
            continue;
        }
    }

    return targetRegVal;
}

static VOID UpdateLinkParaReg(UINT32 dir, UINT32 *pLinkInfo, UINT32 linkSize)
{
    UINT32 retVal = BSP_OK;
    UINT32 routeRegVal = 0;
    UINT32 targetRegOrgVal = 0;
    UINT32 targetRegVal = 0, tmpVal = 0;
    UINT32 regInfo[2] = {0};
    UINT32 loop = 0;
    
    for(loop=0; loop<linkSize; loop++)
    {
        if(s_updateLinkParaCfg[dir].routeRegAddr == pLinkInfo[0])
        {
            routeRegVal = pLinkInfo[1];
        }
        if(s_updateLinkParaCfg[dir].targetRegAddr == pLinkInfo[0])
        {
            targetRegOrgVal = pLinkInfo[1];
        }
        pLinkInfo+=2;
    }

    targetRegVal = targetRegOrgVal;
    if(PRX == dir || RX == dir)
    {
        tmpVal = CalcJ204RxFbMapWorkSel(dir, routeRegVal);
        targetRegVal &= (~0x31); /* 把bit4,bit5,bit0清0 */ 
    }
    else 
    {
        tmpVal = CalcJ204TxMapWorkSel(routeRegVal);
        targetRegVal &= (~0x33); /* 把bit4,bit5,bit0,bit1清0 */
    }
    targetRegVal |= tmpVal;

    regInfo[0] = s_updateLinkParaCfg[dir].targetRegAddr;
    regInfo[1] = targetRegVal;
    retVal = BspHalAdaptJ204LinkInit(dir, 0, regInfo, 1);  /* 待后续放开 */
    CHECK_RETVAL_PRN(BspHalAdaptJ204LinkInit,retVal); 
    if(BSP_OK == retVal)
    {
        BspLog(LOG_LEVEL_0,"J204 Reg[%#x] change form [%#x] to [%#x] for route[%#x] succ!\n",
                s_updateLinkParaCfg[dir].targetRegAddr, targetRegOrgVal,targetRegVal, routeRegVal);
    }
    else 
    {
        BspLog(LOG_LEVEL_0,"J204 Reg[%#x] change form [%#x] to [%#x] for route[%#x] fail!\n",
                s_updateLinkParaCfg[dir].targetRegAddr, targetRegOrgVal,targetRegVal, routeRegVal);        
    }

    return;
}


UINT32 J204BlockLinkParaInit(UINT32 dir, UINT32 laneIdMask, T_J204LaneCfg* pLaneCfg)
{
    UINT32 retVal = BSP_OK;
    UINT32 *pLinkInfo = NULL;
    UINT32 linkSize = 0;

    pLinkInfo = pLaneCfg->pLinkInfo;
    linkSize = pLaneCfg->linkSize;

    if(NULL == pLinkInfo || 0 == linkSize)
    {
        /* 当单板下未传linkinfo和mapinfo数据时，则略过初始化 */
        return BSP_OK;
    }

    retVal = BspHalAdaptJ204LinkInit(dir, laneIdMask, pLinkInfo, linkSize);
    CHECK_RETVAL_PRN(BspHalAdaptJ204LinkInit,retVal);

    /* 
        下行map出口是采样时钟到work时钟的跨时钟，涉及到跨时钟目的端时钟选择，
        如果对应map映射到PHY0，则配置为work0时钟，若映射到PHY1，则配置为work1时钟 
        
        上行及反馈map入口是work时钟到采样时钟的跨时钟，涉及到跨时钟源端时钟选择，
        若对应的map映射来自PHY0，则选择为ul_work，若对应的map映射来自PHY1，则选择为fb_work
    */
    if(!s_J204autoCfgDisableFlg)
    {
        BspLog(LOG_LEVEL_0,"%s Don't mask linkage register\n",__FUNCTION__);
        UpdateLinkParaReg(dir, pLinkInfo, linkSize);
    }

    j204ExLog(J204_BLOCK,"%s finished [dir=%s][laneMask=%#x][linkSize=%d]\n",
        __func__, dirStr[dir], laneIdMask, linkSize);

    return retVal;    
}

static UINT32 J204BlockMapParaInit(UINT32 dir, UINT32 laneIdMask, T_J204LaneCfg* pLaneCfg)
{
    UINT32 retVal = BSP_OK;
    UINT32 *pMapInfo = NULL;
    UINT32 mapSize = 0; 

    pMapInfo = pLaneCfg->pMapInfo;
    mapSize = pLaneCfg->mapSize;
    
    if(NULL == pMapInfo || 0 == mapSize)
    {
        /* 当单板下未传linkinfo和mapinfo数据时，则略过初始化 */
        return BSP_OK;
    }

    retVal = BspHalAdaptJ204MapInit(dir, laneIdMask, pMapInfo, mapSize);
    CHECK_RETVAL_PRN(BspHalAdaptJ204MapInit,retVal);

    j204ExLog(J204_BLOCK,"%s finished [dir=%s][laneMask=%#x][mapSize=%d]\n",
        __func__, dirStr[dir], laneIdMask, mapSize);

    return retVal;    
}

static UINT32 J204BlockCmdParaInit(UINT32 dir, UINT32 laneIdMask, T_J204LaneCfg* pLaneCfg)
{
    UINT32 retVal = BSP_OK;
    UINT32 *pCmdInfo = NULL;
    UINT32 cmdSize = 0;   

    pCmdInfo = pLaneCfg->pCmdInfo;
    cmdSize = pLaneCfg->cmdSize;    
    
    if(NULL == pCmdInfo || 0 == cmdSize)
    {
        /* 当单板下未传linkinfo和mapinfo数据时，则略过初始化 */
        return BSP_OK;
    }

    retVal = BspHalAdaptJ204LinkInit(dir, laneIdMask, pCmdInfo, cmdSize);
    CHECK_RETVAL_PRN(BspHalAdaptJ204LinkInit,retVal);

    j204ExLog(J204_BLOCK,"%s finished [dir=%s][laneMask=%#x][cmdSize=%d]\n",
        __func__, dirStr[dir], laneIdMask, cmdSize);

    return retVal;    
}

static UINT32 GetDirByLane(UINT32 laneIdx)
{
    if(laneIdx<4)
    {
        return RX;
    }
    else
    {
        return PRX;
    }
}

static UINT32 GetCurMapIdMask(UINT32 dir, UINT32 grpMask, T_J204LinkCfg* pPara)
{
    UINT32 grpLoop = 0;
    UINT32 mapIdMask = 0;
    
    for(grpLoop=0; grpLoop<J204_LANE_GRP_NUM; grpLoop++)
    {
        /* 未指定的Group跳过 */
        if(!BIT_VAL(grpMask, grpLoop))
        {
            continue;
        }
        mapIdMask |= pPara->laneCfg[grpLoop][dir].mapMask;
    }
    return mapIdMask;
}

/* 规避IC4.3芯片，Sysref概率性发送失败问题 */
UINT32 J204BlockSysrefReqRetry(UINT32 dir, UINT32 mapId, T_BspHalAdaptSysrefCfg *pSysrefCfg)
{
    UINT32 retVal = BSP_OK;
    UINT32 validFlag = 0;
    UINT32 cycleMs = 10; //10ms
    UINT32 retryMaxTimes = 10; //10*10ms=100ms
    UINT32 retryTimes = 0;
    
    do 
    {
        if (TX == dir)
        {
            retVal = BspHalAdaptSysrefRspEnable(TX, 0);  /*入参laneIdMask在D42中没有用*/
        }
        /*由于Retry接口没有PRX的入参情况，将PRX与RX一起重新响应*/
        else if(RX == dir)
        {
            retVal |= BspHalAdaptSysrefRspEnable(RX,  0);
            retVal |= BspHalAdaptSysrefRspEnable(PRX, 0);
        }
        if (BSP_OK != retVal)
        {
            dbgErr("%s dir %d SysrefRspEnable failed!\n", __func__, dir);
        }

        if(retryTimes >= retryMaxTimes)
        {
            dbgErr("%s fail to recv valid sysref, retry max times = %d\n", __func__, retryTimes);
            retVal = BSP_ERROR;
            break;
        }
        BspSysMsDelay(cycleMs);
        
        validFlag = 0;
        retVal = BspHalAdaptGetSysrefValidFlag(dir, mapId, &validFlag);
        if(BSP_OK == retVal && DPDIC_J204_SYSREF_VALID == validFlag)
        {
            retVal = BSP_OK;
            dbgInfo("%s successfully recved sysref, retry times = %d\n", __func__, retryTimes);
            break;
        }
        else 
        {
            validFlag = 0;
        }
        
        /* 再次发送sysref */
        retVal = BspHalAdaptSysrefRequest(pSysrefCfg);
        CHECK_RETVAL_PRN(BspHalAdaptSysrefRequest,retVal);

        retryTimes++;
        dbgInfo("%s retry to send sysref, retry times = %d\n", __func__, retryTimes);
    }
    while(validFlag != DPDIC_J204_SYSREF_VALID);

    return retVal;
}

/*****************************************************************************
*                                                                            *
*                                维测接口                                        *
*                                                                            *
*****************************************************************************/
UINT32 sendpulsesysref(UINT32 num, UINT32 mask)
{
    UINT32 retVal = BSP_OK;
    retVal = BspJ204SysrefRequest(1, E_SYSREF_MODE_PULSE, num, mask);    
    return retVal;
}

UINT32 sendcontinuesysref(UINT32 sw, UINT32 mask)
{
    UINT32 retVal = BSP_OK;
    retVal = BspJ204SysrefRequest(sw, E_SYSREF_MODE_CONT, 0, mask);    
    return retVal;
}

/*****************************************************************************
*                                                                            *
*                              对外接口实现                                        *
*                                                                            *
*****************************************************************************/

/*****************************************************************************
 * 函数名称: BspJ204SysrefRequest
 * 功能描述: J204 Block的link、map、cmd参数配置 
 * 输入参数: en: 1表示打开，0表示关闭
 *           mode: E_SYSREF_MODE_CONT表示常发，E_SYSREF_MODE_PULSE表示发送指定个数的脉冲
 *           sysrefNum: 脉冲的个数
 *           txEnMask: sysref信号发送给哪片Transicver的掩码
 * 输出参数: 无
 * 返 回 值: BSP_OK/BSP_ERROR
 * 其它说明: 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10248577@2021-08-20, 创建
 *----------------------------------------------------------------------------
 */
UINT32 BspJ204SysrefRequest(UINT32 en, UINT32 mode, UINT32 sysrefNum, UINT32 txEnMask)
{
    T_BspHalAdaptSysrefCfg sysrefCfg = {0};
    UINT32 retVal = BSP_OK;

    if(mode >= E_SYSREF_MODE_MAX)
    {
        return BSP_ERROR;
    }

    if(txEnMask & (~TX_EN_MASK_MAX))
    {
        return BSP_ERROR;
    }
    
    sysrefCfg.mode = mode;
    sysrefCfg.sysrefEn = en;
    sysrefCfg.sysrefNum = sysrefNum;
    sysrefCfg.tsEnable = txEnMask;
    
    retVal = BspHalAdaptSysrefRequest(&sysrefCfg);
    if(BSP_OK != retVal)
    {
        return retVal;
    }

    return BSP_OK;    
}

/*****************************************************************************
 * 函数名称: J204BlockParaInit
 * 功能描述: J204 Block的link、map、cmd参数配置 
 * 输入参数: grpId - Group ID(也就是IC的J204 Block Id)
 * 输出参数: 无
 * 返 回 值: BSP_OK/BSP_ERROR
 * 其它说明: 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10248577@2021-08-20, 创建
 *----------------------------------------------------------------------------
 */
UINT32 J204BlockParaInit(UINT32 index, UINT32 grpMask, T_J204LinkCfg* pPara)
{
    T_J204LaneCfg *pLaneCfg = NULL;
    UINT32 laneIdMask = 0;
    UINT32 dirLoop = 0;
    UINT32 grpLoop = 0;
    UINT32 retVal = 0;
    UINT32 retTotal = BSP_OK;

    INPUT_POINTER_CHECK(pPara);
    
    for(grpLoop=0; grpLoop<J204_LANE_GRP_NUM; grpLoop++)
    {
        /* 未指定的Group跳过 */
        if(!BIT_VAL(grpMask, grpLoop))
        {
            continue;
        }
        for(dirLoop=RX;dirLoop<=PRX;dirLoop++)
        {
            pLaneCfg = &(pPara->laneCfg[grpLoop][dirLoop]);
            laneIdMask = pLaneCfg->laneIdMask;

            retVal = J204BlockLinkParaInit(dirLoop, laneIdMask, pLaneCfg);
            retTotal |= retVal;
            retVal = J204BlockMapParaInit(dirLoop, laneIdMask, pLaneCfg);
            retTotal |= retVal;
            retVal = J204BlockCmdParaInit(dirLoop, laneIdMask, pLaneCfg);
            retTotal |= retVal;
          
        }
    }

    return retTotal;
}

/*****************************************************************************
 * 函数名称: J204BlockSysrefGenerate
 * 功能描述: J204 Block产生sysref信号 
 * 输入参数: grpId - Group ID(也就是IC的J204 Block Id)
 * 输出参数: 无
 * 返 回 值: BSP_OK/BSP_ERROR
 * 其它说明: 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10248577@2021-08-20, 创建
 *----------------------------------------------------------------------------
 */
UINT32 J204BlockSysrefGenerate(UINT32 index, UINT32 grpMask, T_J204LinkCfg* pPara)
{
    UINT32 retVal = BSP_OK;

    INPUT_POINTER_CHECK(pPara);
    
    //产生sysref信号
    retVal = BspHalAdaptSysrefGenerate(&(pPara->sysrefCfg));
    CHECK_RETVAL_PRN(BspHalAdaptSysrefGenerate,retVal);
        
    j204ExLog(J204_BLOCK,"%s BspHalAdaptSysrefGenerate finished ret=0x%#x\n", __func__, retVal);

    return retVal;
}

/*****************************************************************************
 * 函数名称: J204BlockPreSysrefRequest
 * 功能描述: 向IC侧TX发送sysref信号 
 * 输入参数: grpId - Group ID(也就是IC的J204 Block Id)
 * 输出参数: 无
 * 返 回 值: BSP_OK/BSP_ERROR
 * 其它说明: 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10248577@2021-08-20, 创建
 *----------------------------------------------------------------------------
 */
UINT32 J204BlockPreSysrefRequest(UINT32 index, UINT32 grpMask, T_J204LinkCfg* pPara)
{
    UINT32 retVal = BSP_OK;
    UINT32 mapIdMask = 0;
    UINT32 mapId = 0;
    UINT32 clearedMapId = 0xFF;

    INPUT_POINTER_CHECK(pPara);

    mapIdMask = GetCurMapIdMask(TX, grpMask, pPara);
    for(mapId=0; mapId<DPDIC_J204_MAP_NUM_MAX; mapId++)
    {
        /* 未指定的Group跳过 */
        if(!BIT_VAL(mapIdMask, mapId))
        {
            continue;
        }
        if(0xFF == clearedMapId)
        {
            clearedMapId = mapId;
        }
        retVal |= BspHalAdaptClrMapSysrefStatus(TX, mapId);
    }
    BspSysMsDelay(100);

    /* 此处使用单板下配置的默认sysref发送参数 */
    retVal |= BspHalAdaptSysrefRequest(&(pPara->sysrefCfg));
    CHECK_RETVAL_PRN(BspHalAdaptSysrefRequest,retVal);
    BspSysMsDelay(100);

    /* 规避IC4.3芯片，Sysref概率性发送失败问题 */
    retVal |= J204BlockSysrefReqRetry(TX, clearedMapId, &(pPara->sysrefCfg));
    
    j204ExLog(J204_BLOCK,"%s BspHalAdaptSysrefRequest Tx finished ret=0x%#x\n", __func__, retVal);

    return retVal;
}

/*****************************************************************************
 * 函数名称: J204BlockPostSysrefRequest
 * 功能描述: 向IC侧RX发送sysref信号 
 * 输入参数: grpId - Group ID(也就是IC的J204 Block Id)
 * 输出参数: 无
 * 返 回 值: BSP_OK/BSP_ERROR
 * 其它说明: 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10248577@2021-08-20, 创建
 *----------------------------------------------------------------------------
 */
UINT32 J204BlockPostSysrefRequest(UINT32 index, UINT32 grpMask, T_J204LinkCfg* pPara)
{
    UINT32 retVal = BSP_OK;

    INPUT_POINTER_CHECK(pPara);

    /* 给IC侧RX/FB发送Sysref信号前，清除RX/FB的Sysref状态 */
    if(FULL_GROUP_MASK == grpMask || BspJ204GetGroupMask() == grpMask)
    {
        retVal |= BspJ204ClrSysRefStatus(RX);
        retVal |= BspJ204ClrSysRefStatus(PRX);
    }
    BspSysMsDelay(100);

    /* 此处使用单板下配置的默认sysref发送参数 */
    retVal |= BspHalAdaptSysrefRequest(&(pPara->sysrefCfg));
    CHECK_RETVAL_PRN(BspHalAdaptSysrefRequest,retVal);
    BspSysMsDelay(100);

    /* 规避IC4.3芯片，Sysref概率性发送失败问题 只检测Rx的sysref有效标志即可 */
    retVal |= J204BlockSysrefReqRetry(RX, 0, &(pPara->sysrefCfg));

    j204ExLog(J204_BLOCK,"%s BspHalAdaptSysrefRequest RxFb finished ret=0x%#x\n", __func__, retVal);

    return retVal;
}

/*****************************************************************************
 * 函数名称: J204BlockCloseSysref
 * 功能描述: 关闭Sysref信号 
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值: BSP_OK/BSP_ERROR
 * 其它说明: 待建链调试ok后，需要在此处关闭sysref，防止产生干扰
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10248577@2021-08-20, 创建
 *----------------------------------------------------------------------------
 */
UINT32 J204BlockCloseSysref(UINT32 index, UINT32 grpMask, T_J204LinkCfg* pPara)
{
    UINT32 retVal = BSP_OK;
    UINT32 en = 0;
    T_BspHalAdaptSysrefCfg *pSysRef = NULL;

    INPUT_POINTER_CHECK(pPara);
    
    pSysRef = &(pPara->sysrefCfg);
    retVal = BspJ204SysrefRequest(en, pSysRef->mode, pSysRef->sysrefNum, pSysRef->tsEnable);
    j204ExLog(J204_BLOCK,"%s BspJ204SysrefRequest close sysref finished! ret=0x%#x\n", __func__, retVal);
    return retVal;
}

UINT32 J204BlockCfgJitOutWin(UINT32 index, UINT32 grpMask, T_J204LinkCfg *pPara)
{
    UINT32 dirLoop = 0;
    UINT32 retVal = BSP_OK;

    /* Tx、Rx、Fb的 JitOutWin 配置*/
    for(dirLoop = RX; dirLoop <= PRX; dirLoop++)
    {
        retVal |= BspHalAdaptJ204JitOutWinCfg(dirLoop, 0);
        BspSysMsDelay(11);
        retVal |= BspHalAdaptJ204JitOutWinCfg(dirLoop, 2);

        j204ExLog(J204_BLOCK,"%s: BspHalAdaptJ204JitOutWinCfg ret=%d, dir = %d\n", __FUNCTION__, retVal, dirLoop);
    }

    return retVal;
}
/*****************************************************************************
 * 函数名称: BspJ204GetSysRefStatus
 * 功能描述: 查询sysref状态 
 * 输入参数: grpId - Group ID(也就是IC的J204 Block Id)
 * 输出参数: 无
 * 返 回 值: BSP_OK/BSP_ERROR
 * 其它说明: 
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10248577@2021-08-20, 创建
 *----------------------------------------------------------------------------
 */
UINT32 BspJ204GetSysRefStatus(UINT32 dir)
{
    return BspHalAdaptGetSysrefStatus(dir, 0x1);
}

/*****************************************************************************
 * 函数名称: BspJ204ClrSysRefStatus
 * 功能描述: 清除Sysref状态 
 * 输入参数: grpId - Group ID(也就是IC的J204 Block Id)
 * 输出参数: 无
 * 返 回 值: BSP_OK/BSP_ERROR
 * 其它说明: 
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10248577@2021-08-20, 创建
 *----------------------------------------------------------------------------
 */
UINT32 BspJ204ClrSysRefStatus(UINT32 dir)
{
    return BspHalAdaptClrSysrefStatus(dir, 0x1);
}

/*****************************************************************************
 * 函数名称: BspJ204GetLinkState
 * 功能描述: 查询J204c Rx和Fb Lane的建链同步状态 
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值: BSP_OK/BSP_ERROR
 * 其它说明: 
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10248577@2021-08-20, 创建
 *----------------------------------------------------------------------------
 */
UINT32 BspJ204GetLinkState(UINT32 dir, UINT32 laneId, UINT32 *state, UINT32 *regVal)
{   
    return BspHalAdaptGetJ204State(dir, laneId, state, regVal);
}

/*****************************************************************************
 * 函数名称: BspJ204GetLinkStatus
 * 功能描述: 获取上行、反馈Lane的同步状态
 * 输入参数: 无
 * 输出参数: pSta:建链状态，每lane1个bit，
             bit0-3:Rx lane0-3; bit4-7 Fb Lane0-3 
 * 返 回 值: 上行、反馈Lane的同步状态，Rx 4bit + fb 4bit
 * 其它说明: 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10248577@2021-08-20, 创建
 *----------------------------------------------------------------------------
 */
UINT32 BspJ204GetLinkStatus(UINT32 *pSta)
{
    UINT32 ulLaneIdx = 0;
    UINT32 ulIcRegVal = 0;
    UINT32 uLLinkStat = 0;
    UINT32 ulLinkStatusRet = 0;
    UINT32 loop = 0;
    UINT32 laneMask = 0;
    UINT32 dir = 0;

    INPUT_POINTER_CHECK(pSta);

    for(loop = 0; loop < J204_LANE_MAX_NUM; loop++)
    {
        dir = GetDirByLane(loop);
        laneMask = BspJ204GetLaneMask(dir);
        ulLaneIdx = loop%4;
        if(!BIT_VAL(laneMask,ulLaneIdx))
        {
            continue;
        }
        if(BSP_OK == BspHalAdaptGetJ204State(dir, ulLaneIdx, &uLLinkStat, &ulIcRegVal))
        {
            if(BSP_HALADAPT_J204_LINK_OK_REGVAL != ulIcRegVal)
            {
                ulLinkStatusRet |= BIT_SET(loop);
            }
        }
        else
        {
            return BSP_ERROR;
        }
        dbgInfoEx("%s>>%s Lane'%d RegVal'0x%X: Ret= 0x%04X\n", __FUNCTION__,
                  dirStr[dir], ulLaneIdx, ulIcRegVal, ulLinkStatusRet);        
    }
    *pSta = ulLinkStatusRet;    

    return BSP_OK;
}

/*****************************************************************************
 * 函数名称: BspJ204GetCrcErrStat(*)
 * 功能描述: 获取上行Lane的CRC误码状态
 * 输入参数: 无
 * 输出参数: pSta:CRC误码状态，每lane1个bit，
             bit0-3:Rx lane0-3; bit4-7 Fb Lane0-3 
 * 返 回 值: BSP_OK- 正常
 *           BSP_ERROR- 异常
 * 其它说明: 误码率高4bit不变化时，认为状态正常
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10248577@2021-08-20, 创建
 *----------------------------------------------------------------------------
 */
UINT32 BspJ204GetCrcErrStat(UINT32 *pSta)
{
    UINT32 tempValue[J204_LANE_MAX_NUM] = {0};
    UINT32 tempHighBit[J204_LANE_MAX_NUM] = {0};
    UINT32 flagBit = 0;
    UINT32 loop = 0;
    UINT32 laneMask = 0;
    UINT32 dir = 0;

    INPUT_POINTER_CHECK(pSta);
   
    for(loop = 0; loop < J204_LANE_MAX_NUM; loop++)
    {
        dir = GetDirByLane(loop);
        laneMask = BspJ204GetLaneMask(dir);
        if(!BIT_VAL(laneMask,loop%4))
        {
            continue;
        }
        if(BSP_OK == BspHalAdaptGetJ204CrcErrCnt(dir, loop%4, tempValue+loop))
        {
            tempHighBit[loop] = tempValue[loop] >> ((UINT32)12) & 0x0f;
            dbgInfoEx("%s>>%s Lane'%d CrcErrVal'0x%#X: curHighBit'0x%#X\n", __FUNCTION__,
                  dirStr[dir], loop%4, tempValue[loop], tempHighBit[loop]);
        }
        else
        {
            return BSP_ERROR;
        }
    }
    for(loop = 0; loop < J204_LANE_MAX_NUM; loop++)
    {
        dbgInfoEx("%s>>Lane'%d lastHighBit'0x%#X: curHighBit'0x%#X\n", __FUNCTION__,
                  loop, s_ulCrcHighBit[loop], tempHighBit[loop]);      
        if (s_ulCrcHighBit[loop] != tempHighBit[loop])
        {
            flagBit |= (UINT32)1 << loop;
            s_ulCrcHighBit[loop] = tempHighBit[loop];          
        }
    }

    *pSta = flagBit;
    
    dbgInfoEx("%s >> return flagBit=%#x\n", __FUNCTION__, flagBit);
    
    return BSP_OK;
}

/*****************************************************************************
 * 函数名称: BspJ204GetRwAddrDifStatus
 * 功能描述: 获取上行、反馈Lane的读写地址差冲突
 * 输入参数: 无
 * 输出参数: pSta:读写地址差冲突状态，每lane1个bit，
             bit0-3:Rx lane0-3; bit4-7 Fb Lane0-3
 * 返 回 值: 上行、反馈Lane的读写地址差冲突，Rx 4bit + fb 4bit,1代表有冲突，0代表无冲突
 * 其它说明:
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10248577@2021-08-20, 创建
 *----------------------------------------------------------------------------
 */
UINT32 BspJ204GetRwAddrDifStatus(UINT32 *pSta)
{
    UINT32 ulLaneIdx = 0;
    UINT32 uLRwAddrDifStat = 0;
    UINT32 ulRwAddrDifRet = 0;
    UINT32 ulIcRegVal = 0;
    UINT32 loop = 0;
    UINT32 laneMask = 0;
    UINT32 dir = 0;

    INPUT_POINTER_CHECK(pSta);

    for(loop = 0; loop < J204_LANE_MAX_NUM; loop++)
    {
        dir = GetDirByLane(loop);
        laneMask = BspJ204GetLaneMask(dir);
        ulLaneIdx = loop%4;
        if(!BIT_VAL(laneMask,ulLaneIdx))
        {
            continue;
        }
        if(BSP_OK == BspHalAdaptGetJ204RwAddrDifState(dir, ulLaneIdx, &uLRwAddrDifStat, &ulIcRegVal))
        {
            if(DPDIC_J204_RWADDR_ERROR == uLRwAddrDifStat)
            {
                ulRwAddrDifRet |= BIT_SET(loop);
            }
        }
        else
        {
            return BSP_ERROR;
        }
        dbgInfoEx("%s>>%s Lane'%d RegVal'0x%X: ulRwAddrDifRet= 0x%04X\n", __FUNCTION__,
                  dirStr[dir], ulLaneIdx, ulIcRegVal, ulRwAddrDifRet);
    }
    *pSta = ulRwAddrDifRet;

    return BSP_OK;
}

/*****************************************************************************
 * 函数名称: BspJ204LemcOffsetRecover
 * 功能描述: 读写地址差冲突处理，修改LEMCOFFSET
 * 输入参数: dir:方向
 * 输出参数: 无
 * 返 回 值:BSP_OK- 正常
 *           BSP_ERROR- 异常
 * 其它说明:
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10248577@2021-08-20, 创建
 *----------------------------------------------------------------------------
 */
UINT32 BspJ204LemcOffsetRecover(UINT32 dir, UINT32 ulValue)
{
    UINT32 retVal = BSP_OK;
    UINT32 curLemcOffset = 0;
    retVal = BspHalAdaptSetJ204LemcOffset(dir, ulValue);
    retVal |= BspHalAdaptGetJ204LemcOffset(dir, &curLemcOffset);
    if(dir <= PRX)
    {
        BspLog(LOG_LEVEL_0,"J204 %s change curLemcOffset to [%#x]\n", dirStr[dir], curLemcOffset);
    }
    return retVal;
}

/* Started by AICoder, pid:vcf558319820d9614cb90b3ce059bb10b37200aa */
UINT32 BspJ204SetAutoCfg(UINT32 enFlag)
{ 
    s_J204autoCfgDisableFlg = (enFlag == 1);
    BspLog(LOG_LEVEL_0,"%s >> s_J204autoCfgDisableFlg = %d\n",__FUNCTION__,s_J204autoCfgDisableFlg);
    return BSP_OK;
}

UINT32 BspJ204GetAutoCfg()
{
    return s_J204autoCfgDisableFlg;
}
/* Ended by AICoder, pid:vcf558319820d9614cb90b3ce059bb10b37200aa */

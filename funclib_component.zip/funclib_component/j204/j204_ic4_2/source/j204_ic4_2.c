/*****************************************************************************
 * 版权所有(C) 2020, ZTE Corp. ZXSDR-RRU Platform BSP
 *----------------------------------------------------------------------------
 * 模 块 名 : BSP
 * 文件名称 : chnmap_a.h
 * 文件标识 : {[N/A]}
 * 内容摘要 : 本文件主要提供rru的J204模块的实现
 * 注意事项 : 无
 * 作    者 : wangtao 10248577
 * 创建日期 : 2020-12-10
 * 当前版本 : Ver1.0
 *----------------------------------------------------------------------------
 * 变更记录 :
 *
 * $记录1
 * 变 更 单:
 * 责 任 人:
 * 修改日戳:
 * 变更说明:

 *----------------------------------------------------------------------------
 */
#include "j204_ic4_2.h"
#include "j204_common.h"
#include "j204_serdes.h"
#include "j204_block.h"
#include "j204_crm.h"
#include "j204_trx.h"
#include "ichaladapt_j204_ic4_2.h"
#include "ichaladapt_crm_ic4_2.h"
#include "ichaladaptbspapi_comm.h"

/**************************************************************************
 *                                  宏定义
 **************************************************************************/

#define J204_STEP_DEF(func,delay)  \
        {func,              #func,        delay},

#define J204_STEP_NULL  \
        {NULL,              "",        0},

#define SYSREF_PERIOD_VALUE (960)  //960K
#define J204_REBUILD_MAX_TIMES (3)
#define J204_LEMC_OFFSET_RECOVER_VAL (3)
/**************************************************************************
 *                               数据类型定义
 **************************************************************************/
typedef struct tag_J204LinkStep 
{
    pJ204LinkStepFunc pFunc;
    const CHAR *pFuncName;
    UINT32 delayMs;
    UINT32 result;
}T_J204LinkStep;

typedef struct tag_J204LinkInitStep 
{
    T_J204LinkStep initStep[J204_INIT_STEP_MAX];
}T_J204LinkInitStep;

typedef struct tag_J204LinkPreStep 
{
    T_J204LinkStep preStep[J204_PRE_STEP_MAX];
}T_J204LinkPreStep;

typedef struct tag_J204LinkPostStep 
{
    T_J204LinkStep postStep[J204_POST_STEP_MAX];
}T_J204LinkPostStep;

typedef struct tag_J204LaneInfo 
{
    UINT32 dir;
    UINT32 id;
}T_J204LaneInfo;

/**************************************************************************
*                         全局变量定义                                          *
**************************************************************************/

/* 初始化动作流程定义 */
static T_J204LinkInitStep s_j204LinkInitStep[J204_LINK_MODE_MAX] =
{
    //J204_LINK_MODE_DEFAULT的默认动作实现
    {
        {
            J204_STEP_DEF(J204CrmRelaseGlobalApb,    0)
            J204_STEP_DEF(J204SerdesLoadFirmware,    0)
            J204_STEP_DEF(J204SerdesAllPowerDown,    0)
            J204_STEP_DEF(J204SerdesSetTxEq,         0)
            J204_STEP_DEF(J204CrmResetAll,           0)
            J204_STEP_DEF(J204CrmRelaseAllApb,       0)
            J204_STEP_DEF(J204BlockParaInit,         0)
            J204_STEP_DEF(J204BlockSysrefGenerate,   0)
        },
    },
    //其他流程定义
    {
    }
};

/* 建链PRESTEP动作流程定义 */
static T_J204LinkPreStep s_j204LinkPreStep[J204_LINK_MODE_MAX] =
{
    //J204_LINK_MODE_DEFAULT的默认动作实现
    {
        {
            J204_STEP_DEF(J204SerdesTxInit,          0)
            J204_STEP_DEF(J204CrmResetTxMap,         0)
            J204_STEP_DEF(J204CrmReleaseTxLogic,     2)
            J204_STEP_DEF(J204CrmReleaseTxSysref,    0)
            J204_STEP_DEF(J204BlockPreSysrefRequest, 1)
            J204_STEP_DEF(J204CrmReleaseTxWorkMap,   0)
            J204_STEP_DEF(J204CrmReleaseTxWorkLane,  0)
            J204_STEP_NULL
        },
    },
    //其他流程定义
    {
    }
};

/* 建链POSTSTEP动作流程定义 */
static T_J204LinkPostStep s_j204LinkPostStep[J204_LINK_MODE_MAX] =
{
    //J204_LINK_MODE_DEFAULT的默认动作实现
    {
        {
            J204_STEP_NULL
            J204_STEP_DEF(J204TrxSysrefCheck,        0)
            J204_STEP_DEF(J204CrmResetRxFbMap,       0)
            J204_STEP_DEF(J204SerdesRxInit,          0)
            J204_STEP_DEF(J204CrmReleaseRxFbWorkLane,0)
            J204_STEP_DEF(J204CrmReleaseRxFbCtrl,    0)
            J204_STEP_DEF(J204BlockPostSysrefRequest,0)
            J204_STEP_DEF(J204CrmReleaseRxFbWorkMap, 0)
            J204_STEP_DEF(J204CrmReleaseRxFbLogic,   0)
            J204_STEP_DEF(J204CrmReleaseRxRfTrans,   0)
            J204_STEP_DEF(J204BlockCloseSysref,      0)
            J204_STEP_DEF(J204BlockCfgJitOutWin,     0)
            J204_STEP_NULL
        },
    },
    //其他流程定义
    {
    }    
};

/* 打印开关 */
UINT32 j204PrnFlag = 0x7;

static T_J204LinkCfg s_J204LinkCfg = {0};
static T_J204TransLinkMapRecord s_pLinkMap  = {0};
static UINT32 s_J204Mode = (UINT32)J204_LINK_MODE_DEFAULT;
static UINT32 s_rfLaneMask[J204_LANE_GRP_NUM][J204_LANE_DIR_NUM] = {0};  /* 射频硬件使用的LaneMask */

/* 维测接口 */
static pJ204LinkStepDbgFunc pJ204InitStepDbgFunc = NULL;
static pJ204LinkStepDbgFunc pJ204PreStepDbgFunc = NULL;
static pJ204LinkStepDbgFunc pJ204PostStepDbgFunc = NULL;

/* Transceiver侧接口 */
static pJ204GetTrxLinkStatusFunc pGetTrxLinkStatFunc = NULL;
static pJ204PrnTrxLinkStatusFunc pPrnTrxLinkStatFunc = NULL;

/* 时间统计 */
UINT32 g_j204CalTime = 0; 
static struct timeval  g_J204StartTime;
static struct timeval  g_J204EndTime;

const CHAR dirStr[3][4] = {"RX","TX","PRX"};

UINT32 s_j204StepMax[J204_LINK_STEP_MAX] = 
{
    J204_INIT_STEP_MAX,
    J204_PRE_STEP_MAX,
    J204_POST_STEP_MAX
};

UINT32 s_j204DirLaneMax[J204_LANE_DIR_NUM] = 
{
    DPDIC_J204_RX_LANE_MAX_SUM,
    DPDIC_J204_TX_LANE_MAX_SUM,
    DPDIC_J204_FB_LANE_MAX_SUM
};

static UINT32 s_ulJ204LemcOffSetRecoverVal[PRX+1] = {J204_LEMC_OFFSET_RECOVER_VAL,J204_LEMC_OFFSET_RECOVER_VAL,J204_LEMC_OFFSET_RECOVER_VAL};
/*
                            lane的对应关系
204inf0: |                      block0                       |
phy      |          phy0           |          phy1           |
phy      | lane0 lane1 lane2 lane3 | lane0 lane1 lane2 lane3 |
serdes   | lane0 lane1 lane2 lane3   lane4 lane5 lane6 lane7 |
j204c    |  tx0   tx1   tx2   tx3  |  tx4   tx5   tx6   tx7  |   *204 lane
j204c    |  rx0   rx1   rx2   rx3  |  fb0   fb1   fb2   fb3  |   *204 lane
射频       |  tx0   tx1   tx2   tx3  |  tx4   tx5   tx6   tx7  |   *rf lane
射频       |  fb0   fb1   rx0   rx1  |  fb2   fb3   rx2   rx3  |   *rf lane

*/
static T_J204LaneInfo s_RxLaneRfTo204[DPDIC_J204_RX_LANE_MAX_SUM] = 
{
    {RX,2},{RX,3},{PRX,2},{PRX,3}
};

static T_J204LaneInfo s_FbLaneRfTo204[DPDIC_J204_RX_LANE_MAX_SUM] = 
{
    {RX,0},{RX,1},{PRX,0},{PRX,1}
};

/*****************************************************************************
*                                                                            *
*                              内部函数实现                                        *
*                                                                            *
*****************************************************************************/

static VOID DbgJ204CalTimeStart(VOID)
{
    gettimeofday(&g_J204StartTime,NULL);
}

static UINT32 DbgJ204CalTimeEnd(VOID)
{
    gettimeofday(&g_J204EndTime,NULL); 
    g_j204CalTime = (((g_J204EndTime.tv_sec - g_J204StartTime.tv_sec)*1000000L + g_J204EndTime.tv_usec) - g_J204StartTime.tv_usec);
    g_j204CalTime = g_j204CalTime / 1000;
    //dbgInfo("%s calTime=%d(ms)\n", __FUNCTION__, g_j204CalTime);
    return g_j204CalTime;
}

static UINT32 GetGroupMaskOfCurLinkCfg(VOID)
{
    UINT32 grp = 0;
    UINT32 dir = 0;
    UINT32 grpMask = 0;
    for(grp=0; grp<J204_LANE_GRP_NUM; grp++)
    {
        for(dir=0; dir<J204_LANE_DIR_NUM; dir++)
        {
            if(s_J204LinkCfg.laneCfg[grp][dir].laneIdMask)
            {
                grpMask |= (BIT_SET(grp));
                break;
            }
        }
    }
    return grpMask;
}

UINT32 BspInitJ204LemcOffSetRecoverVal(UINT32 dir, UINT32 val)
{
    if(dir > PRX)
    {
        return BSP_ERROR;
    }
    s_ulJ204LemcOffSetRecoverVal[dir] = val;

    return BSP_OK;
}

UINT32 BspGetJ204LemcOffSetRecoverVal(UINT32 dir, UINT32 *pVal)
{
    if(dir > PRX)
    {
        return BSP_ERROR;
    }
    INPUT_POINTER_CHECK(pVal);
    *pVal = s_ulJ204LemcOffSetRecoverVal[dir];

    return BSP_OK;
}

static UINT32 BspJ204InitStep(UINT32 grpMask, T_J204LinkCfg *pJ204LinkCfg)
{
    UINT32 stepLoop = 0;
    pJ204LinkStepFunc pInitStepFunc = NULL;
    UINT32 retVal = BSP_OK;
    UINT32 calTimeMs = 0;
    UINT32 retTotal = BSP_OK;
    T_J204LinkStep *pInitStep = NULL;

    if(s_J204Mode >= J204_LINK_MODE_MAX)
    {
        return BSP_ERROR;
    }

    DbgJ204CalTimeStart();
    
    for(stepLoop=0; stepLoop<J204_INIT_STEP_MAX;stepLoop++)
    {
        pInitStep = &(s_j204LinkInitStep[s_J204Mode].initStep[stepLoop]);
        pInitStepFunc = pInitStep->pFunc;
        //如果当前模式下未定义动作，则调用默认动作
        if(NULL == pInitStepFunc)
        {
            pInitStepFunc = s_j204LinkInitStep[J204_LINK_MODE_DEFAULT].initStep[stepLoop].pFunc;
        }
        if(NULL == pInitStepFunc)
        {
            dbgInfoEx("%s [stepLoop=%d] pInitStepFunc is NULL, continue next step\n",__func__, stepLoop);
            continue;
        }

        retVal = (*pInitStepFunc)(J204_LINK_INIT_STEP_IDX(stepLoop), grpMask, pJ204LinkCfg);
        retTotal |= retVal;
        pInitStep->result = retVal;
        if(BSP_OK != retVal)
        {
            dbgErr("%s [stepLoop=%d] pInitStepFunc failed!\n",__func__, stepLoop);
        }
        
        /* 动作间延时 */
        if(pInitStep->delayMs)
        {
            BspSysMsDelay(pInitStep->delayMs);
        }

        //维测
        if(NULL != pJ204InitStepDbgFunc)
        {
            (*pJ204InitStepDbgFunc)(J204_LINK_INIT_STEP_IDX(stepLoop), grpMask, pJ204LinkCfg);
        }
    }

    calTimeMs = DbgJ204CalTimeEnd();
    dbgInfo("%s consumed time = %d(ms)\n", __FUNCTION__, calTimeMs);
    
    return retTotal;    
}

static UINT32 BspJ204PreStep(UINT32 grpMask, T_J204LinkCfg *pJ204LinkCfg)
{
    UINT32 stepLoop = 0;
    pJ204LinkStepFunc pPreStepFunc = NULL;
    UINT32 retVal = BSP_OK;
    UINT32 calTimeMs = 0;
    UINT32 retTotal = BSP_OK;
    T_J204LinkStep *pPreStep = NULL;

    if(s_J204Mode >= J204_LINK_MODE_MAX)
    {
        return BSP_ERROR;
    }

    DbgJ204CalTimeStart();
    
    for(stepLoop=0; stepLoop<J204_PRE_STEP_MAX;stepLoop++)
    {
        pPreStep = &(s_j204LinkPreStep[s_J204Mode].preStep[stepLoop]);
        pPreStepFunc = pPreStep->pFunc;
        //如果当前模式下未定义动作，则调用默认动作
        if(NULL == pPreStepFunc)
        {
            pPreStepFunc = s_j204LinkPreStep[J204_LINK_MODE_DEFAULT].preStep[stepLoop].pFunc;
        }
        if(NULL == pPreStepFunc)
        {
            dbgInfoEx("%s [stepLoop=%d] pPreStepFunc is NULL, continue next step\n",__func__, stepLoop);
            continue;
        }
        
        retVal = (*pPreStepFunc)(J204_LINK_PRE_STEP_IDX(stepLoop), grpMask, pJ204LinkCfg);
        retTotal |= retVal;
        pPreStep->result = retVal;
        if(BSP_OK != retVal)
        {
            dbgErr("%s [stepLoop=%d] pPreStepFunc failed!\n",__func__, stepLoop);
        }
        
        /* 动作间延时 */
        if(pPreStep->delayMs)
        {
            BspSysMsDelay(pPreStep->delayMs);
        }
        
        //维测
        if(NULL != pJ204PreStepDbgFunc)
        {
            (*pJ204PreStepDbgFunc)(J204_LINK_PRE_STEP_IDX(stepLoop), grpMask, pJ204LinkCfg);
        }
    }

    calTimeMs = DbgJ204CalTimeEnd();
    dbgInfo("%s consumed time = %d(ms)\n", __FUNCTION__, calTimeMs);
    
    return BSP_OK;    
}

static UINT32 BspJ204PostStep(UINT32 grpMask, T_J204LinkCfg *pJ204LinkCfg)
{
    UINT32 stepLoop = 0;
    pJ204LinkStepFunc pPostStepFunc = NULL;
    UINT32 retVal = BSP_OK;
    UINT32 calTimeMs = 0;
    UINT32 retTotal = BSP_OK;
    T_J204LinkStep *pPostStep = NULL;

    if(s_J204Mode >= J204_LINK_MODE_MAX)
    {
        return BSP_ERROR;
    }

    DbgJ204CalTimeStart();
    
    for(stepLoop=0; stepLoop<J204_POST_STEP_MAX;stepLoop++)
    {
        pPostStep = &(s_j204LinkPostStep[s_J204Mode].postStep[stepLoop]);
        pPostStepFunc = pPostStep->pFunc;
        //如果当前模式下未定义动作，则调用默认动作
        if(NULL == pPostStepFunc)
        {
            pPostStepFunc = s_j204LinkPostStep[J204_LINK_MODE_DEFAULT].postStep[stepLoop].pFunc;
        }
        if(NULL == pPostStepFunc)
        {
            dbgInfoEx("%s [stepLoop=%d] pPostStepFunc is NULL, continue next step\n",__func__,stepLoop);
            continue;
        }
         
        retVal = (*pPostStepFunc)(J204_LINK_POST_STEP_IDX(stepLoop), grpMask, pJ204LinkCfg);
        retTotal |= retVal;
        pPostStep->result = retVal;
        if(BSP_OK != retVal)
        {
            dbgErr("%s [stepLoop=%d] pPostStepFunc failed!\n",__func__,stepLoop);
        }

        /* 动作间延时 */
        if(pPostStep->delayMs)
        {
            BspSysMsDelay(pPostStep->delayMs);
        }

        //维测
        if(NULL != pJ204PostStepDbgFunc)
        {
            (*pJ204PostStepDbgFunc)(J204_LINK_POST_STEP_IDX(stepLoop), grpMask, pJ204LinkCfg);
        }

    }    

    calTimeMs = DbgJ204CalTimeEnd();
    dbgInfo("%s consumed time = %d(ms)\n", __FUNCTION__, calTimeMs);
    
    return BSP_OK;        
}

static VOID ChangeRfLaneMaskTo204(T_J204LinkCfg *pJ204LinkCfg)
{
    UINT32 grp = 0;
    UINT32 dir = 0;
    UINT32 lane = 0;
    UINT32 laneMask[J204_LANE_GRP_NUM][J204_LANE_DIR_NUM] = {0};

    /* 根据射频硬件使用的laneMask转换得到204 LaneMask */
    for(grp=0; grp<J204_LANE_GRP_NUM; grp++)
    {
        /* TX */
        laneMask[grp][TX] = s_rfLaneMask[grp][TX];

        /* RX */
        for(lane=0; lane<DPDIC_J204_RX_LANE_MAX_SUM; lane++)
        {
            if(BIT_VAL(s_rfLaneMask[grp][RX],lane))
            {
                laneMask[grp][s_RxLaneRfTo204[lane].dir] |= (0x1 << s_RxLaneRfTo204[lane].id);
            }
        }
        
        /* PRX */
        for(lane=0; lane<DPDIC_J204_FB_LANE_MAX_SUM; lane++)
        {
            if(BIT_VAL(s_rfLaneMask[grp][PRX],lane))
            {
                laneMask[grp][s_FbLaneRfTo204[lane].dir] |= (0x1 << s_FbLaneRfTo204[lane].id);
            }
        }

    } 

    /* 更新内部使用laneMask为204 LaneMask */
    for(grp=0; grp<J204_LANE_GRP_NUM; grp++)
    {
        for(dir=0; dir<J204_LANE_DIR_NUM; dir++)
        {
            pJ204LinkCfg->laneCfg[grp][dir].laneIdMask = laneMask[grp][dir];
        }
    }
    return;
}

/*****************************************************************************
*                                                                            *
*                              维测函数实现                                        *
*                                                                            *
*****************************************************************************/
/* 打印J204建链流程的动作步骤，及执行结果 */
VOID showj204step(VOID)
{
    UINT32 loop = 0;
   
    dbgInfo("J204 Step Status:\n");

    dbgInfo("IDX INIT_STEP,                       result\n");
    for(loop=0; loop<J204_INIT_STEP_MAX; loop++)
    {
        dbgInfo("%03d %-32s, %s\n",loop, 
            s_j204LinkInitStep[s_J204Mode].initStep[loop].pFuncName,
            RESULT_TO_STR(s_j204LinkInitStep[s_J204Mode].initStep[loop].result));
    }

    dbgInfo("\nIDX PRE_STEP,                        result\n");
    for(loop=0; loop<J204_PRE_STEP_MAX; loop++)
    {
        dbgInfo("%03d %-32s, %s\n", loop,
            s_j204LinkPreStep[s_J204Mode].preStep[loop].pFuncName,
            RESULT_TO_STR(s_j204LinkPreStep[s_J204Mode].preStep[loop].result));
    }

    dbgInfo("\nIDX POST_STEP,                       result\n");
    for(loop=0; loop<J204_POST_STEP_MAX; loop++)
    {
        dbgInfo("%03d %-32s, %s\n", loop,
            s_j204LinkPostStep[s_J204Mode].postStep[loop].pFuncName,
            RESULT_TO_STR(s_j204LinkPostStep[s_J204Mode].postStep[loop].result));
    }
    return;
}

/* 打印J204建链的配置参数 */
VOID showj204linkpara(VOID)
{
    UINT32 loopDir = 0;
    UINT32 loopGrp = 0;
    T_J204LaneCfg *pLaneCfg = NULL;
        
    dbgInfo("J204 [mode=%d] LANE INFO is :\n",s_J204Mode);
    dbgInfo("dir grp laneMask laneMask mapMask dateRate linkinfo-addr-regval linksize mapinfo-addr-regval mapSize\n");
    for(loopDir=RX;loopDir<=PRX;loopDir++)
    {
        for(loopGrp=0;loopGrp<J204_LANE_GRP_NUM;loopGrp++)
        {
            pLaneCfg = &(s_J204LinkCfg.laneCfg[loopGrp][loopDir]);;
            dbgInfo("%3s %3d %08x %08x %07x %8d 0x%07x-0x%08x %8d 0x%06x-0x%08x %7d\n",dirStr[loopDir],loopGrp,
            s_rfLaneMask[loopGrp][loopDir],
            pLaneCfg->laneIdMask,
            pLaneCfg->mapMask,
            pLaneCfg->dateRate,
            (pLaneCfg->pLinkInfo==NULL)?0:(*(pLaneCfg->pLinkInfo)),
            (pLaneCfg->pLinkInfo==NULL)?0:(*(pLaneCfg->pLinkInfo+1)),
            pLaneCfg->linkSize,
            (pLaneCfg->pMapInfo==NULL)?0:(*(pLaneCfg->pMapInfo)),
            (pLaneCfg->pMapInfo==NULL)?0:(*(pLaneCfg->pMapInfo+1)),
            pLaneCfg->mapSize);
        }
    }
    return;

}

/* 打印Sysref配置参数 */
VOID showj204sysrefcfg(VOID)
{
    T_BspHalAdaptSysrefCfg *pSysrefCfg;
    
    pSysrefCfg = &(s_J204LinkCfg.sysrefCfg);

    dbgInfo("J204 SYSREF INFO is :\n");
    dbgInfo("sysrefEn=%d\n", pSysrefCfg->sysrefEn); 
    dbgInfo("mode=%d\n",pSysrefCfg->mode); 
    dbgInfo("period=%d\n", pSysrefCfg->period);
    dbgInfo("width=%d\n", pSysrefCfg->width);
    dbgInfo("sysrefNum=%d\n",pSysrefCfg->sysrefNum); 
    dbgInfo("tsEnable=%#x\n", pSysrefCfg->tsEnable); 
    dbgInfo("sysrefFrDelay=%d\n",pSysrefCfg->sysrefFrDelay); 
    dbgInfo("localcntSyncEn=%d\n",pSysrefCfg->localcntSyncEn);
    dbgInfo("sysPha=%d\n",pSysrefCfg->sysPha);
    dbgInfo("isExtSysref=%d\n",pSysrefCfg->isExtSysref);
            
    return;    
}

/* 打印link寄存器的寄存器值 */
VOID showj204linkreg(UINT32 dir)
{
    T_J204LaneCfg *pLaneCfg = NULL;
    UINT32 *pLinkInfo = NULL;
    UINT32 linkSize = 0;
    UINT32 *pRegAddr = 0;
    UINT32 index = 0;
    UINT32 headAddr = 0;
    UINT32 regData = 0;
    UINT32 regAddr = 0;

    if(dir >=J204_LANE_DIR_NUM)
    {
        return;
    }
    pLaneCfg = &(s_J204LinkCfg.laneCfg[0][dir]);
    pLinkInfo = pLaneCfg->pLinkInfo;
    linkSize = pLaneCfg->linkSize;
    pRegAddr = (UINT32*)pLinkInfo;
    headAddr = BspHalAdaptGetJ204RegHeadAddr(0);

    if(NULL == pLinkInfo || 0 == linkSize)
    {
        return;
    }
    dbgInfo("J204 grp%d link reg print\n", 0);
    for(index=0; index<linkSize; index++)
    {
        regAddr = headAddr + (*pRegAddr); 
        BspHalAdaptDpdicRegRd(0, regAddr, 0, &regData);
        dbgInfo("regAddr=%#x, val=%#x\n", regAddr, regData);
        pRegAddr+=2;
    }

    return;

}

/* 打印cmd寄存器的寄存器值 */
VOID showj204cmdreg(UINT32 dir)
{
    T_J204LaneCfg *pLaneCfg = NULL;
    UINT32 *pCmdInfo = NULL;
    UINT32 cmdSize = 0;
    UINT32 *pRegAddr = 0;
    UINT32 index = 0;
    UINT32 headAddr = 0;
    UINT32 regData = 0;
    UINT32 regAddr = 0;

    if(dir >=J204_LANE_DIR_NUM)
    {
        return;
    }  
    pLaneCfg = &(s_J204LinkCfg.laneCfg[0][dir]);
    pCmdInfo = pLaneCfg->pCmdInfo;
    cmdSize = pLaneCfg->cmdSize;

    if(NULL == pCmdInfo || 0 == cmdSize)
    {
        return;
    }    
    pRegAddr = (UINT32*)pCmdInfo;
    headAddr = BspHalAdaptGetJ204RegHeadAddr(0);

    dbgInfo("J204 grp%d cmd reg print\n", 0);
    for(index=0; index<cmdSize; index++)
    {
        //coverity[cert_int30_c_violation:SUPPRESS]
        regAddr = headAddr + (*pRegAddr); 
        BspHalAdaptDpdicRegRd(0, regAddr, 0, &regData);
        dbgInfo("regAddr=%#x, val=%#x\n", regAddr, regData);
        pRegAddr+=2;
    }

    return;

}

/* 打印开关控制 */
UINT32 j204setprnsw(UINT32 flag)
{
    j204PrnFlag = flag;
    return j204PrnFlag; 
}
    
/* 调试执行单步动作 */
VOID j204stepdebug(UINT32 linkStep, UINT32 stepIdx)
{
    T_J204LinkStep *pStep = NULL;
    pJ204LinkStepFunc pStepFunc = NULL;
    UINT32 grpMask = 0;
    UINT32 retVal = BSP_OK;

    if(linkStep >= J204_LINK_STEP_MAX || stepIdx >= s_j204StepMax[linkStep])
    {
        dbgErr(" input para error!\n");
        return;
    }

    if(J204_LINK_INIT_STEP == linkStep)
    {
        pStep = &(s_j204LinkInitStep[s_J204Mode].initStep[stepIdx]);
    }
    else if(J204_LINK_PRE_STEP == linkStep)
    {
        pStep = &(s_j204LinkPreStep[s_J204Mode].preStep[stepIdx]);
    }
    else 
    {
        pStep = &(s_j204LinkPostStep[s_J204Mode].postStep[stepIdx]);
    }

    grpMask = GetGroupMaskOfCurLinkCfg();
    pStepFunc = pStep->pFunc;
    if(NULL == pStepFunc)
    {
        dbgErr(" step[%d][%d] error!\n", linkStep, stepIdx);
        return;
    }
    retVal = (*pStepFunc)(stepIdx, grpMask, &s_J204LinkCfg);
    if(BSP_OK != retVal)
    {
        dbgErr(" step[%d][%d] error!\n", linkStep, stepIdx);
    }
    dbgErr(" step[%d][%d] finished!\n", linkStep, stepIdx);
    return;
}


/*****************************************************************************
*                                                                            *
*                              对外接口实现                                        *
*                                                                            *
*****************************************************************************/

/*****************************************************************************
 * 函数名称: BspJ204LinkParaInit
 * 功能描述: 配置单板下的J204建链参数到J204模块中
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值: BSP_OK/BSP_ERROR
 * 其它说明: 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10248577@2021-08-20, 创建
 *----------------------------------------------------------------------------
 */
UINT32 BspJ204LinkParaInit(T_J204LinkPara *pJ204LinkPara)
{
    UINT32 srcSize = 0;
    UINT32 destSize = 0;
    UINT32 dir  =0;
    UINT32 grp = 0;
    UINT32 retVal = BSP_OK;

    INPUT_POINTER_CHECK(pJ204LinkPara);

    s_J204Mode = pJ204LinkPara->j204Mode;
    destSize = sizeof(s_J204LinkCfg.laneCfg);
    srcSize = sizeof(pJ204LinkPara->laneCfg);
    memcpy_s(s_J204LinkCfg.laneCfg, destSize, pJ204LinkPara->laneCfg, srcSize);

    /* 备份射频硬件使用的laneMask，用于维测打印 */
    for(grp=0; grp<J204_LANE_GRP_NUM; grp++)
    {
        for(dir=0; dir<J204_LANE_DIR_NUM; dir++)
        {
            s_rfLaneMask[grp][dir] = s_J204LinkCfg.laneCfg[grp][dir].laneIdMask;
        }
    }

#ifdef USE_INPUT_RF_LANEMASK
    /* 将射频硬件使用的laneMask转换为内部使用的204 Lane Mask */
    ChangeRfLaneMaskTo204(&s_J204LinkCfg);
#endif

    return retVal;
}

/*****************************************************************************
 * 函数名称: BspJ204SysrefParaInit
 * 功能描述: 配置单板下的Sysref参数到J204模块中
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值: BSP_OK/BSP_ERROR
 * 其它说明: 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10248577@2021-08-20, 创建
 *----------------------------------------------------------------------------
 */
UINT32 BspJ204SysrefParaInit(T_BspHalAdaptSysrefCfg *pSysref)
{
    UINT32 sysrefClk;
    UINT32 srcSize = 0;
    UINT32 destSize = 0;
    
    INPUT_POINTER_CHECK(pSysref);

    destSize = sizeof(T_BspHalAdaptSysrefCfg);
    srcSize = sizeof(T_BspHalAdaptSysrefCfg);    
    memcpy_s(&(s_J204LinkCfg.sysrefCfg), destSize, pSysref, srcSize);

    /* 根据CRM中的Dl_logic3调整sysref周期配置 */
    if(BspHalAdaptGetJ204SysrefClk(&sysrefClk) == BSP_OK)
    {
        s_J204LinkCfg.sysrefCfg.period = (sysrefClk/(SYSREF_PERIOD_VALUE));
        s_J204LinkCfg.sysrefCfg.width = (s_J204LinkCfg.sysrefCfg.period/2);
        dbgInfo("%s J204 Sysref auto change period[0x%#x],width[0x%#x]\n", __func__, 
                s_J204LinkCfg.sysrefCfg.period, s_J204LinkCfg.sysrefCfg.width);
    }

    return BSP_OK;

}
/*****************************************************************************
 * 函数名称: BspJ204SerdesTxEqInit
 * 功能描述: 配置单板下的J204 Serdes预加重参数到J204模块中
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值: BSP_OK/BSP_ERROR
 * 其它说明: 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10248577@2021-08-20, 创建
 *----------------------------------------------------------------------------
 */
UINT32 BspJ204SerdesTxEqParaInit(T_J204SerdesTxEqPara *pPara, UINT32 laneNum)
{
    INPUT_POINTER_CHECK(pPara);

    s_J204LinkCfg.serdesTxEq.pEqPara = pPara;
    s_J204LinkCfg.serdesTxEq.laneNum = laneNum;

    return BSP_OK;
}

/*****************************************************************************
 * 函数名称: BspJ204LinkInitStep
 * 功能描述: J204模块初始化(包括serdes固件加载、上电等动作)
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值: BSP_OK/BSP_ERROR
 * 其它说明: 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10248577@2021-08-20, 创建
 *----------------------------------------------------------------------------
 */
UINT32 BspJ204LinkInitStep(VOID)
{
    UINT32 grpMask = GetGroupMaskOfCurLinkCfg();
    return BspJ204InitStep(grpMask, &s_J204LinkCfg);
}

/*****************************************************************************
 * 函数名称: BspJ204LinkGrpInitStep
 * 功能描述: J204模块单Gropu初始化(包括serdes固件加载、上电等动作)
 * 输入参数: grpId - Group ID(也就是IC的J204 Block Id)
 * 输出参数: 无
 * 返 回 值: BSP_OK/BSP_ERROR
 * 其它说明: 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10248577@2021-08-20, 创建
 *----------------------------------------------------------------------------
 */
UINT32 BspJ204LinkGrpInitStep(UINT32 grpId)
{
    UINT32 grpMask = 0;

    if(grpId >= J204_LANE_GRP_NUM)
    {
        return BSP_ERROR;
    }
    grpMask = BIT_SET(grpId);
    return BspJ204InitStep(grpMask, &s_J204LinkCfg);
}

/*****************************************************************************
 * 函数名称: BspJ204LinkPreStep
 * 功能描述: J204建链Transceiver初始化前IC侧的动作(整片IC所有lane一起操作)
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值: BSP_OK/BSP_ERROR
 * 其它说明: 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10248577@2021-08-20, 创建
 *----------------------------------------------------------------------------
 */
UINT32 BspJ204LinkPreStep(VOID)
{
    UINT32 grpMask = GetGroupMaskOfCurLinkCfg();
    return BspJ204PreStep(grpMask, &s_J204LinkCfg);
}
/*****************************************************************************
 * 函数名称: BspJ204LinkPostStep
 * 功能描述: J204建链Transceiver初始化后IC侧的动作(整片IC所有lane一起操作)
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值: BSP_OK/BSP_ERROR
 * 其它说明: 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10248577@2021-08-20, 创建
 *----------------------------------------------------------------------------
 */
UINT32 BspJ204LinkPostStep(VOID)
{
    UINT32 grpMask = GetGroupMaskOfCurLinkCfg();
    return BspJ204PostStep(grpMask, &s_J204LinkCfg);
}

/*****************************************************************************
 * 函数名称: BspJ204GrpLinkPreStep
 * 功能描述: J204建链Transceiver初始化前IC侧的动作(单Grp的lane一起操作)
 * 输入参数: grpId - Group ID(也就是IC的J204 Block Id)
 * 输出参数: 无
 * 返 回 值: BSP_OK/BSP_ERROR
 * 其它说明: 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10248577@2021-08-20, 创建
 *----------------------------------------------------------------------------
 */
UINT32 BspJ204LinkGrpPreStep(UINT32 grpId)
{
    UINT32 grpMask = 0;

    if(grpId >= J204_LANE_GRP_NUM)
    {
        return BSP_ERROR;
    }
    grpMask = BIT_SET(grpId);
    return BspJ204PreStep(grpMask, &s_J204LinkCfg);
}

/*****************************************************************************
 * 函数名称: BspJ204GrpLinkPostStep
 * 功能描述: J204建链Transceiver初始化后IC侧的动作(单Grp的lane一起操作)
 * 输入参数: grpId - Group ID(也就是IC的J204 Block Id)
 * 输出参数: 无
 * 返 回 值: BSP_OK/BSP_ERROR
 * 其它说明: 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10248577@2021-08-20, 创建
 *----------------------------------------------------------------------------
 */
UINT32 BspJ204LinkGrpPostStep(UINT32 grpId)
{
    UINT32 grpMask = 0;

    if(grpId >= J204_LANE_GRP_NUM)
    {
        return BSP_ERROR;
    }
    grpMask = BIT_SET(grpId);
    return BspJ204PostStep(grpMask, &s_J204LinkCfg);
}


/*****************************************************************************
 * 函数名称: BspJ204SetDbgFunc
 * 功能描述: 注册维测接口
 * 输入参数: grpId - Group ID(也就是IC的J204 Block Id)
 * 输出参数: 无
 * 返 回 值: BSP_OK/BSP_ERROR
 * 其它说明: 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10248577@2021-08-20, 创建
 *----------------------------------------------------------------------------
 */
UINT32 BspJ204SetDbgFunc(E_J204_LINK_STEP_DEF step, pJ204LinkStepDbgFunc pFunc)
{
    if(J204_LINK_INIT_STEP == step)
    {
        pJ204InitStepDbgFunc = pFunc;
    }
    else if(J204_LINK_PRE_STEP == step)
    {
        pJ204PreStepDbgFunc = pFunc;
    }
    else
    {
        pJ204PostStepDbgFunc = pFunc;
    }
    
    return BSP_OK; 
}

/*****************************************************************************
 * 函数名称: BspJ204SetGetTrxLinkStatFunc
 * 功能描述: 注册查询Transceiver侧同步状态的接口
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值: BSP_OK/BSP_ERROR
 * 其它说明: 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10248577@2021-08-20, 创建
 *----------------------------------------------------------------------------
 */
UINT32 BspJ204SetGetTrxLinkStatFunc(pJ204GetTrxLinkStatusFunc pFunc)
{
    pGetTrxLinkStatFunc = pFunc;
    return BSP_OK; 
}

/*****************************************************************************
 * 函数名称: BspJ204SetPrnTrxLinkStatFunc
 * 功能描述: 注册打印Transceiver侧同步状态的接口
 * 输入参数: grpId - Group ID(也就是IC的J204 Block Id)
 * 输出参数: 无
 * 返 回 值: BSP_OK/BSP_ERROR
 * 其它说明: 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10248577@2021-08-20, 创建
 *----------------------------------------------------------------------------
 */
UINT32 BspJ204SetPrnTrxLinkStatFunc(pJ204PrnTrxLinkStatusFunc pFunc)
{
    pPrnTrxLinkStatFunc = pFunc;
    return BSP_OK; 
}


/*****************************************************************************
 * 函数名称: BspJ204GetTrxLinkStat
 * 功能描述: 获取Trx侧J204的同步状态
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值: BSP_OK/BSP_ERROR
 * 其它说明: 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10248577@2021-08-20, 创建
 *----------------------------------------------------------------------------
 */
UINT32 BspJ204GetTrxLinkStat(UINT32 trxMask)
{
    UINT32 retVal = BSP_OK;
    
    //如果注册了获取Trx J204同步状态的回调接口，则调用
    if(NULL != pGetTrxLinkStatFunc)
    {
        retVal = (*pGetTrxLinkStatFunc)(trxMask);
    }
    else 
    {
        dbgErr("%s, Callback Function is not registered, retVal is meaningless!\n", __func__);
        retVal = BSP_OK;
    }

    return retVal;
}

/*****************************************************************************
 * 函数名称: BspJ204PrnTrxLinkStat
 * 功能描述: 打印Trx侧J204的同步状态
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值: BSP_OK/BSP_ERROR
 * 其它说明: 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10248577@2021-08-20, 创建
 *----------------------------------------------------------------------------
 */
UINT32 BspJ204PrnTrxLinkStat(UINT32 trxMask)
{
    UINT32 retVal = BSP_OK;
    
    //如果注册了获取Trx J204同步状态的回调接口，则调用
    if(NULL != pPrnTrxLinkStatFunc)
    {
        retVal = (*pPrnTrxLinkStatFunc)(trxMask);
    }
    else 
    {
        dbgErr("%s, Callback Function is not registered, retVal is meaningless!\n", __func__);
        retVal = BSP_OK;
    }    

    return retVal;
}

/*****************************************************************************
 * 函数名称: BspJ204PrnTrxLinkStat
 * 功能描述: 注册Pre建链阶段的各步骤动作接口
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值: BSP_OK/BSP_ERROR
 * 其它说明: 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10248577@2021-08-20, 创建
 *----------------------------------------------------------------------------
 */
UINT32 BspJ204SetPreStepFunc(UINT32 step, pJ204LinkStepFunc pFunc, const CHAR *pFuncName, UINT32 delayMs)
{
    if(step >= J204_PRE_STEP_MAX)
    {
        return BSP_ERROR;
    }
    s_j204LinkPreStep[s_J204Mode].preStep[step].pFunc = pFunc;
    s_j204LinkPreStep[s_J204Mode].preStep[step].pFuncName = pFuncName;
    s_j204LinkPreStep[s_J204Mode].preStep[step].delayMs = delayMs;
    return BSP_OK; 
}

/*****************************************************************************
 * 函数名称: BspJ204PrnTrxLinkStat
 * 功能描述: 注册Post建链阶段的各步骤动作接口
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值: BSP_OK/BSP_ERROR
 * 其它说明: 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10248577@2021-08-20, 创建
 *----------------------------------------------------------------------------
 */
UINT32 BspJ204SetPostStepFunc(UINT32 step, pJ204LinkStepFunc pFunc, const CHAR *pFuncName, UINT32 delayMs)
{
    if(step >= J204_POST_STEP_MAX)
    {
        return BSP_ERROR;
    }
    s_j204LinkPostStep[s_J204Mode].postStep[step].pFunc = pFunc;
    s_j204LinkPostStep[s_J204Mode].postStep[step].pFuncName = pFuncName;
    s_j204LinkPostStep[s_J204Mode].postStep[step].delayMs = delayMs;    
    return BSP_OK; 
}

/*****************************************************************************
 * 函数名称: BspJ204GetLaneMask
 * 功能描述: 查询上下行反馈Lane的使用状态
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值: BSP_OK/BSP_ERROR
 * 其它说明: 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10248577@2021-08-20, 创建
 *----------------------------------------------------------------------------
 */
UINT32 BspJ204GetLaneMask(UINT32 dir)
{
    UINT32 laneMask = 0;
    UINT32 loop = 0;

    if(dir >= J204_LANE_DIR_NUM)
    {
        return laneMask;
    }

    for(loop=0; loop<J204_LANE_GRP_NUM; loop++)
    {
        laneMask |= s_J204LinkCfg.laneCfg[loop][dir].laneIdMask;
    }

    return laneMask;
}

/*****************************************************************************
 * 函数名称: BspJ204GetGroupMask
 * 功能描述: 查询当前使用了几个Group
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值: GROUP掩码
 * 其它说明: 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10248577@2021-08-20, 创建
 *----------------------------------------------------------------------------
 */
UINT32 BspJ204GetGroupMask(VOID)
{
    return GetGroupMaskOfCurLinkCfg();
}

UINT32 BspJ204LinkLaneMapInit(T_J204TransLinkMapPara *pPara,UINT32 num)
{
    if(pPara == NULL)
    {
       return BSP_ERROR;
    }
    s_pLinkMap.num = num;
    s_pLinkMap.pLinkMap = pPara;

    return BSP_OK;
}

UINT32 BspJ204GetLinkLaneMask(UINT32 dir,UINT32 type,UINT32 chip)
{
    UINT32 loop = 0;
    UINT32 laneMask = 0;

    for(loop = 0; loop < s_pLinkMap.num; loop++ )
    {
        if(s_pLinkMap.pLinkMap[loop].dir == dir)
        {
            if(type == 1)
            {
                if(s_pLinkMap.pLinkMap[loop].mtsChipId == chip)  /*存在一片IC 对应多片*/
                {
                	laneMask |= s_pLinkMap.pLinkMap[loop].mtsLaneMask;
                }
            }
            else
            {
            	laneMask |= s_pLinkMap.pLinkMap[loop].icLaneMask;  /*IC侧lane掩码*/
            }
        }
    }

    return laneMask;
}

/*****************************************************************************
 * 函数名称: BspJ204LinkRebuild
 * 功能描述: J204c重建链
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值: BSP_OK/BSP_ERROR
 * 其它说明: 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10248577@2021-08-20, 创建
 *----------------------------------------------------------------------------
 */
UINT32 BspJ204LinkRebuild(VOID)
{
    UINT32 ulRetVal = BSP_OK;

    dbgInfoEx("%s  Start!\n", __FUNCTION__);

    /* 触发DPDIC Tx重新建链流程 */
    ulRetVal |= BspJ204LinkInitStep();
    ulRetVal |= BspJ204LinkPreStep();
    BspSysMsDelay(1000); /* 方案要求延迟3秒 */
    /* 触发Transceiver重新建链流程 */
    ulRetVal |= J204TrxLinkRebuild();
    /* 触发DPDIC Rx重新建链流程 */
    ulRetVal |= BspJ204LinkPostStep();
    BspSysMsDelay(1000); /* 方案要求延迟4秒 */
    dbgInfoEx("%s  End!\n", __FUNCTION__);

    return ulRetVal;
}

/*****************************************************************************
 * 函数名称: BspJ204LinkCheckAndRetry
 * 功能描述: J204c建链状态检查和重试
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值: BSP_OK/BSP_ERROR
 * 其它说明: 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10248577@2021-08-20, 创建
 *----------------------------------------------------------------------------
 */
UINT32 BspJ204LinkCheckAndRetry(VOID)
{
    UINT32 retVal = BSP_OK;
    UINT32 totalRetVal = BSP_OK;
    UINT32 linkStat= 0;
    UINT32 trxStat = 0;
    UINT32 rwAddrDiffStat= 0;
    UINT32 icLaneStat = 0;
    UINT32 retry = 0;

    do
    {
        icLaneStat = 0;
        linkStat = 0;
        rwAddrDiffStat = 0;
        trxStat = 0;
        retVal = BspJ204GetLinkStatus(&linkStat);
        totalRetVal |= retVal;
        if(BSP_OK == retVal)
        {
            icLaneStat |= linkStat;
        }
        retVal = BspJ204GetRwAddrDifStatus(&rwAddrDiffStat);
        totalRetVal |= retVal;
        if(BSP_OK == retVal)
        {
            icLaneStat |= rwAddrDiffStat;
        }
        trxStat = J204TrxGetJesdBringUpResult();
        if(BSP_OK != icLaneStat || BSP_OK != trxStat)
        {
            BspLog(LOG_LEVEL_0, "Need J204 rebuild for linkStat[%#x] rwAddrDiffStat[%#x] trxStat[%#x]\n",
                            linkStat, rwAddrDiffStat, trxStat);
            retVal = BspJ204LinkRebuild();
            totalRetVal |= retVal;
            BspLog(LOG_LEVEL_0, "J204 rebuild finished![retry=%d] [ret=%#x]\n", retry+1, retVal);
            retry++;
        }
        else
        {
            break;
        }
    }while(retry<J204_REBUILD_MAX_TIMES);
    if(BSP_OK != rwAddrDiffStat && J204_REBUILD_MAX_TIMES == retry)
    {
        if(rwAddrDiffStat&0xF)
        {
            BspLog(LOG_LEVEL_0, "J204 Set Rx LemcOffset rwAddrDiffStat[%#x] Rec[%#x] !\n", rwAddrDiffStat,s_ulJ204LemcOffSetRecoverVal[RX]);
            retVal = BspJ204LemcOffsetRecover(RX, s_ulJ204LemcOffSetRecoverVal[RX]);
            totalRetVal |= retVal;
        }
        if(rwAddrDiffStat&0xF0)
        {
            BspLog(LOG_LEVEL_0, "J204 Set Prx LemcOffset rwAddrDiffStat[%#x] Rec[%#x]!\n", rwAddrDiffStat, s_ulJ204LemcOffSetRecoverVal[PRX]);
            retVal = BspJ204LemcOffsetRecover(PRX, s_ulJ204LemcOffSetRecoverVal[PRX]);
            totalRetVal |= retVal;
        }
    }

    return totalRetVal;
}



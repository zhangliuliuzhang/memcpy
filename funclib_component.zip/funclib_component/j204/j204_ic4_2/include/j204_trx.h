/*****************************************************************************
 * 版权所有(C) 2020, ZTE Corp. ZXSDR-RRU Platform BSP
 *----------------------------------------------------------------------------
 * 模 块 名 : BSP
 * 文件名称 : j204_trx.h
 * 文件标识 : {[N/A]}
 * 内容摘要 : 本文件主要提供J204模块相关定义
 * 注意事项 : 无
 * 作    者 : wangtao 10248577
 * 创建日期 : 2020-12-10 
 * 当前版本 : Ver1.0
 *----------------------------------------------------------------------------
 * 变更记录 :
 *
 * $记录1
 * 变 更 单:
 * 责 任 人:
 * 修改日戳:
 * 变更说明:

 *----------------------------------------------------------------------------
 */
#ifndef FUNCLIB_J204_TRX_H_INCLUDED
#define FUNCLIB_J204_TRX_H_INCLUDED

#ifdef __cplusplus
extern "C" {
#endif

#include "bsppub.h"
#include "j204_ic4_2.h"

/**************************************************************************
 *                        数据声明
 **************************************************************************/

/*
    param chip           芯片号
    param sysrefFlag     sysref有效标志 1：代表收到  0：代表没收到
*/
typedef INT32 (*FUNC_TRX_CHECK_SYSREF)(INT32 chip, UINT32 *sysrefFlag);
typedef INT32 (*FUNC_TRX_CHECK_J204LINK)(UINT32 chip);
typedef INT32 (*FUNC_TRX_SEND_SYSREF)(INT32 chip);

typedef struct tag_J204TrxCallBackCfg 
{
    UINT32                  deviceType;           /* 设备类型，定义在rruinfo.h中，DEVICE_MTS、DEVICE_MTS2PRE */
    FUNC_TRX_CHECK_SYSREF   pTrxCheckSysrefFunc;  /* 检查Transcever是否收到sysref的接口 */
    FUNC_TRX_CHECK_J204LINK pTrxCheck204LinkFunc; /* 检查Transcever侧204建链状态的接口 */
    FUNC_TRX_SEND_SYSREF    pTrxSendSysrefFunc;   /* 向Transcever发送sysref信号的接口 */  
}T_J204TrxCallBackCfg;

/**************************************************************************
 *                        函数声明
 **************************************************************************/
UINT32 BspJ204TrxCallBackCfg(T_J204TrxCallBackCfg* pTrxFuncCfg, UINT32 trxTypeNum);
UINT32 J204TrxSysrefCheck(UINT32 index, UINT32 grpMask, T_J204LinkCfg* pPara);
UINT32 J204TrxLinkRebuild(VOID);
UINT32 J204TrxGetJesdBringUpResult(VOID);

#ifdef __cplusplus
}
#endif
#endif //FUNCLIB_J204_TRX_H_INCLUDED



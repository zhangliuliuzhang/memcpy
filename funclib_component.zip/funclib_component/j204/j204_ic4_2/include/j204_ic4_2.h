/*****************************************************************************
 * 版权所有(C) 2020, ZTE Corp. ZXSDR-RRU Platform BSP
 *----------------------------------------------------------------------------
 * 模 块 名 : BSP
 * 文件名称 : chnmap_a.h
 * 文件标识 : {[N/A]}
 * 内容摘要 : 本文件主要提供rru的J204模块的实现
 * 注意事项 : 无
 * 作    者 : wangtao 10248577
 * 创建日期 : 2020-12-10
 * 当前版本 : Ver1.0
 *----------------------------------------------------------------------------
 * 变更记录 :
 *
 * $记录1
 * 变 更 单:
 * 责 任 人:
 * 修改日戳:
 * 变更说明:

 *----------------------------------------------------------------------------
 */
#ifndef FUNCLIB_J204_IC4_2_H_INCLUDED
#define FUNCLIB_J204_IC4_2_H_INCLUDED

#ifdef __cplusplus
extern "C" {
#endif

#include "bsppub.h"
#include "bspcomm.h"
#include "ichaladaptbspapi_j204.h"
#include "ichaladaptbspapi_trx.h"

/**************************************************************************
 *                               宏定义                                      *
 **************************************************************************/
/* 单板下打表，使用射频硬件的laneMask还是204  内部laneMask */
#define USE_INPUT_RF_LANEMASK 

#define J204_LANE_GRP_NUM (2)
#define J204_LANE_DIR_NUM (PRX+1)

#define J204_GROUP0 (0)
#define J204_GROUP1 (1)
#define ONE_GROUP_MASK (0x1)
#define FULL_MAP_MASK (0x3)
#define FULL_GROUP_MASK (0x3)

/* J204建链同步状态 */
#define J204_LINK_OK        (0)
#define J204_LINK_ERR       (1)

/* Sysref信号发送模式 */
enum E_SYSREF_MODE
{
    E_SYSREF_MODE_PULSE= 0, /* 脉冲 */
    E_SYSREF_MODE_CONT,     /* 常发 */
    E_SYSREF_MODE_MAX
};

/* 最大支持2片Transicver */
#define TX_EN_MASK_MAX (0x3)

/* J204建链3个阶段定义 */
typedef enum ENUM_J204_LINK_STEP_DEF
{
    J204_LINK_INIT_STEP = 0,        /* 初始化 */
    J204_LINK_PRE_STEP = 1,         /* PreStep */
    J204_LINK_POST_STEP = 2,        /* PostStep */
    J204_LINK_STEP_MAX
}E_J204_LINK_STEP_DEF;

/* J204建链模式种类定义 */
typedef enum ENUM_J204_LINK_MODE
{
    J204_LINK_MODE_DEFAULT = 0,     /* ONECHIP模式 */
    J204_LINK_MODE_MS_M = 1,        /* 主从模式中的主片 */
    J204_LINK_MODE_MS_S = 2,        /* 主从模式中的从片 */
    J204_LINK_MODE_FPGA_SYSREF = 3, /* FPGA发送sysre */
    J204_LINK_MODE_MAX
}E_J204_LINK_MODE;

/* J204初始化步骤定义 */
typedef enum ENUM_J204_INIT_STEP
{
    J204_INIT_RELEASE_GLB_APB=0,    /* 释放全局apb复位 */
    J204_INIT_SERDES_LOAD_FW,       /* serdes固件加载 */
    J204_INIT_SERDES_POW_DOWN,      /* serdes power down */
    J204_INIT_SERDES_TX_EQ,         /* serdes Tx Lane预加重参数配置 */
    J204_INIT_RESET_ALL,            /* 全部复位 */
    J204_INIT_RELEASE_APB,          /* J204 UL、DL、FB的ABP复位释放 */
    J204_INIT_LINK_MAP,             /* link map参数配置 */
    J204_INIT_SYSREF_GEN,           /* 产生Sysref信号 */
    J204_INIT_STEP_MAX
}E_J204_INIT_STEP;

/* J204 PRE建链步骤定义 */
typedef enum ENUM_J204_PRE_STEP
{
    J204_PRE_SERDES_TX_INIT=0,      /* serdes Tx侧的初始化 */
    J204_PRE_RESET_TX,              /* J204模块的TX复位 */
    J204_PRE_RELEASE_TX_LOGIC,      /* J204 DL的LOGIC复位释放 */
    J204_PRE_RELEASE_TX_SYSREF,     /* J204 DL的SYSREF复位释放 */
    J204_PRE_SYSREF_REQUEST,        /* Sysref信号发送 */
    J204_PRE_RELEASE_TX_WORKMAP,    /* J204 DL的WORKMAP复位释放 */
    J204_PRE_RELEASE_TX_WORKLANE,   /* J204 DL的WORKLANE复位释放 */
    J204_PRE_CHIP_CONSIST,          /* 片间同步动作 */
    J204_PRE_STEP_MAX
}E_J204_PRE_STEP;

/* J204 POST建链步骤定义 */
typedef enum ENUM_J204_POST_STEP
{
    J204_POST_CHIP_CONSIST,         /* 片间同步动作 */
    J204_POST_TRX_SYSREF_CHECK,     /* Transceiver sysref检查 */
    J204_POST_RESET_RXFB,           /* J204模块的RX,FB复位 */
    J204_POST_SERDES_RX_INIT,       /* serdes Rx侧的初始化 */
    J204_POST_RELEASE_RXFB_WORKLANE,/* UL、FB的WORKLANE复位释放 */
    J204_POST_RELEASE_RXFB_CTRL,    /* UL、FB的CTRL复位释放 */
    J204_POST_SYSREF_REQUEST,       /* Sysref信号发送 */
    J204_POST_RELEASE_RXFB_WORKMAP, /* UL、FB的WORKMAP复位释放 */
    J204_POST_RELEASE_RXFB_LOGIC,   /* UL、FB的LOGIC复位释放 */
    J204_POST_RELEASE_RF_TRANS,     /* 射频信息传输复位释放 */
    J204_POST_CLOSE_SYSREF,         /* 关闭sysref */
    J204_POST_JIT_OUT_WIN_CFG,      /* 配置JitOutWin */
    J204_POST_CHIP_CONSIST_STATUS_CLR, /* 片间同步清除 */
    J204_POST_STEP_MAX
}E_J204_POST_STEP;

#define J204_LINK_INIT_STEP_IDX(idx) (J204_LINK_INIT_STEP*1000+idx)
#define J204_LINK_PRE_STEP_IDX(idx) (J204_LINK_PRE_STEP*1000+idx)
#define J204_LINK_POST_STEP_IDX(idx) (J204_LINK_POST_STEP*1000+idx)

/**************************************************************************
 *                             数据类型定义                                     *
 **************************************************************************/

/* 预加重参数定义 */
typedef struct tag_J204SerdesTxEqPara 
{
    UINT32 laneId;  /* J204 Serdes Tx Lane Id (0~7) */
    UINT32 eqPre;
    UINT32 eqPost;
    UINT32 eqMain; 
}T_J204SerdesTxEqPara;

/* Trx 预加重参数定义 */
typedef struct tag_TrxJ204SerdesTxEqPara
{
    UINT32 chipId;  /* trx chipid*/
    UINT32 laneId;  /* Trx J204 Serdes Tx Lane Id*/
    UINT32 eqPre;
    UINT32 eqPost;
    UINT32 eqMain;
}T_TrxJ204SerdesTxEqPara;

typedef struct tag_J204SerdesTxEqInfo 
{
    UINT32 laneNum;
    T_J204SerdesTxEqPara *pEqPara;
}T_J204SerdesTxEqInfo;

/* J204 Lane信息定义 */
typedef struct tag_J204LaneCfg 
{
    UINT32  laneIdMask;  /* J204 lane掩码 */
    UINT32  mapMask;     /* J204 map掩码 */
    UINT32  dateRate;    /* serdes 线速率 */
    UINT32  *pLinkInfo;  /* link参数数组首地址 */
    UINT32  linkSize;    /* link参数数量 */
    UINT32  *pMapInfo;   /* map参数数组首地址 */
    UINT32  mapSize;     /* map参数数量 */
    UINT32  *pCmdInfo;   /* cmd参数数组首地址 */
    UINT32  cmdSize;     /* cmd参数数量 */
}T_J204LaneCfg;

/* J204建链信息整体定义 */
typedef struct tag_J204LinkCfg 
{
    T_J204LaneCfg laneCfg[J204_LANE_GRP_NUM][J204_LANE_DIR_NUM];
    T_J204SerdesTxEqInfo serdesTxEq;
    T_BspHalAdaptSysrefCfg sysrefCfg;
}T_J204LinkCfg;

/* J204建链Lann参数信息 */
typedef struct tag_J204LinkPara 
{
    UINT32 j204Mode;
    T_J204LaneCfg laneCfg[J204_LANE_GRP_NUM][J204_LANE_DIR_NUM];
}T_J204LinkPara;

typedef struct tag_J204TransLinkPara
{
    UINT32 dir;
    UINT32  icLaneMask;
    UINT32  mtsLaneMask;
    UINT32  mtsChipId;
}T_J204TransLinkMapPara;

typedef struct tag_J204TransLinkRecord
{
    UINT32 num;
    T_J204TransLinkMapPara *pLinkMap;
}T_J204TransLinkMapRecord;

/* 建链各步骤接口形式定义 */
typedef UINT32 (*pJ204LinkStepFunc)(UINT32 index, UINT32 grpMask, T_J204LinkCfg* pPara);
/* 维测接口形式定义 */
typedef VOID (*pJ204LinkStepDbgFunc)(UINT32 index, UINT32 grpMask, T_J204LinkCfg* pPara);

/* Transceiver查询同步状态的接口形式定义 */
typedef UINT32 (*pJ204GetTrxLinkStatusFunc)(UINT32 trxMask);

/* Transceiver打印同步状态的接口形式定义 */
typedef UINT32 (*pJ204PrnTrxLinkStatusFunc)(UINT32 trxMask);


/**************************************************************************
 *                          功能接口声明
 **************************************************************************/
 
/* 以下函数用于J204的初始化，在单板初始化流程中调用 */
UINT32 BspJ204LinkParaInit(T_J204LinkPara *pJ204LinkPara);
UINT32 BspJ204SysrefParaInit(T_BspHalAdaptSysrefCfg *pSysref);
UINT32 BspJ204SerdesTxEqParaInit(T_J204SerdesTxEqPara *pPara, UINT32 laneNum);

/* 以下接口用于在J204c建链流程中调用 */
UINT32 BspJ204LinkInitStep(VOID);
UINT32 BspJ204LinkPreStep(VOID);
UINT32 BspJ204LinkPostStep(VOID);
UINT32 BspJ204LinkGrpPreStep(UINT32 grpId);
UINT32 BspJ204LinkGrpPostStep(UINT32 grpId);

/* J204c重建链流程 */
UINT32 BspJ204LinkRebuild(VOID);
/* J204c建链状态检查和重试 */
UINT32 BspJ204LinkCheckAndRetry(VOID);

/* 发送Sysref信号 */
UINT32 BspJ204SysrefRequest(UINT32 en, UINT32 mode, UINT32 sysrefNum, UINT32 txEnMask);

/* 查询上下行反馈Lane的使用状态 */
UINT32 BspJ204GetLaneMask(UINT32 dir);

/* 查询和清除Sysref状态 */
UINT32 BspJ204GetSysRefStatus(UINT32 dir);
UINT32 BspJ204ClrSysRefStatus(UINT32 dir);

/* 查询上行和反馈Lane的Crc误码状态 */
UINT32 BspJ204GetCrcErrStat(UINT32 *pSta);
/* 查询上行和反馈Lane的建链状态 */
UINT32 BspJ204GetLinkStatus(UINT32 *pSta); 
/* 获取上行、反馈Lane的读写地址差冲突 */
UINT32 BspJ204GetRwAddrDifStatus(UINT32 *pSta);
/* 读写地址差冲突处理，修改LEMCOFFSET */
UINT32 BspJ204LemcOffsetRecover(UINT32 dir, UINT32 ulValue);

/* 查询DPDIC侧 J204 Rx和Fb lane的建链状态 */
UINT32 BspJ204GetLinkState(UINT32 dir, UINT32 laneId, UINT32 *state, UINT32 *regVal);

/* 获取Transceiver侧的Rx lane同步状态 */
UINT32 BspJ204GetTrxLinkStat(UINT32 trxMask);

/* 打印Transceiver侧的Rx lane同步状态 */
UINT32 BspJ204PrnTrxLinkStat(UINT32 trxMask);

/* 注册每个动作后执行的维测接口 */
UINT32 BspJ204SetDbgFunc(E_J204_LINK_STEP_DEF step, pJ204LinkStepDbgFunc pFunc);

/* 查询当前使用了几个Group */
UINT32 BspJ204GetGroupMask(VOID);
UINT32 BspJ204LinkLaneMapInit(T_J204TransLinkMapPara *pPara,UINT32 num);
UINT32 BspJ204GetLinkLaneMask(UINT32 dir,UINT32 type,UINT32 chip);
/**************************************************************************
 *                        回调注册
 **************************************************************************/
/* 用于注册替换建链动作的函数实现 */
UINT32 BspJ204SetPreStepFunc(UINT32 step, pJ204LinkStepFunc pFunc, const CHAR *pFuncName, UINT32 delayMs);
UINT32 BspJ204SetPostStepFunc(UINT32 step, pJ204LinkStepFunc pFunc, const CHAR *pFuncName, UINT32 delayMs);

/* 注册获取的打印Transceiver侧的同步状态的回调函数 */
UINT32 BspJ204SetGetTrxLinkStatFunc(pJ204GetTrxLinkStatusFunc pFunc);
UINT32 BspJ204SetPrnTrxLinkStatFunc(pJ204PrnTrxLinkStatusFunc pFunc);
    
UINT32 BspJ204SysrefRequest(UINT32 en, UINT32 mode, UINT32 sysrefNum, UINT32 txEnMask);
UINT32 BspInitJ204LemcOffSetRecoverVal(UINT32 dir, UINT32 val);
UINT32 BspGetJ204LemcOffSetRecoverVal(UINT32 dir, UINT32 *pVal);
VOID show204link(VOID);
#ifdef __cplusplus
}
#endif
#endif //FUNCLIB_J204_2_H_INCLUDED



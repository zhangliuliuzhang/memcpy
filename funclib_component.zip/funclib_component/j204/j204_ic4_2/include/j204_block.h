/*****************************************************************************
 * 版权所有(C) 2020, ZTE Corp. ZXSDR-RRU Platform BSP
 *----------------------------------------------------------------------------
 * 模 块 名 : BSP
 * 文件名称 : j204_block.h
 * 文件标识 : {[N/A]}
 * 内容摘要 : 本文件主要提供J204模块相关定义
 * 注意事项 : 无
 * 作    者 : wangtao 10248577
 * 创建日期 : 2020-12-10 
 * 当前版本 : Ver1.0
 *----------------------------------------------------------------------------
 * 变更记录 :
 *
 * $记录1
 * 变 更 单:
 * 责 任 人:
 * 修改日戳:
 * 变更说明:

 *----------------------------------------------------------------------------
 */
#ifndef FUNCLIB_J204_BLOCK_H_INCLUDED
#define FUNCLIB_J204_BLOCK_H_INCLUDED

#ifdef __cplusplus
extern "C" {
#endif

#include "bsppub.h"
#include "j204_ic4_2.h"

/**************************************************************************
 *                        函数声明
 **************************************************************************/
UINT32 J204BlockParaInit(UINT32 index, UINT32 grpMask, T_J204LinkCfg* pPara);
UINT32 J204BlockSysrefGenerate(UINT32 index, UINT32 grpMask, T_J204LinkCfg* pPara);
UINT32 J204BlockPreSysrefRequest(UINT32 index, UINT32 grpMask, T_J204LinkCfg* pPara);
UINT32 J204BlockPostSysrefRequest(UINT32 index, UINT32 grpMask, T_J204LinkCfg* pPara);
UINT32 J204BlockCloseSysref(UINT32 index, UINT32 grpMask, T_J204LinkCfg* pPara);
UINT32 J204BlockCfgJitOutWin(UINT32 index, UINT32 grpMask, T_J204LinkCfg *pPara);
UINT32 J204BlockSysrefReqRetry(UINT32 dir, UINT32 mapId, T_BspHalAdaptSysrefCfg *pSysrefCfg);
UINT32 BspJ204SetAutoCfg(UINT32 enFlag);
UINT32 BspJ204GetAutoCfg();
UINT32 J204BlockLinkParaInit(UINT32 dir, UINT32 laneIdMask, T_J204LaneCfg* pLaneCfg);
#ifdef __cplusplus
}
#endif
#endif //FUNCLIB_J204_BLOCK_H_INCLUDED



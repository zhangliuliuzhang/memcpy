/*****************************************************************************
 * 版权所有(C) 2020, ZTE Corp. ZXSDR-RRU Platform BSP
 *----------------------------------------------------------------------------
 * 模 块 名 : BSP
 * 文件名称 : j204_common.h
 * 文件标识 : {[N/A]}
 * 内容摘要 : 本文件主要提供J204模块公共定义
 * 注意事项 : 无
 * 作    者 : wangtao 10248577
 * 创建日期 : 2020-12-10
 * 当前版本 : Ver1.0
 *----------------------------------------------------------------------------
 * 变更记录 :
 *
 * $记录1
 * 变 更 单:
 * 责 任 人:
 * 修改日戳:
 * 变更说明:

 *----------------------------------------------------------------------------
 */
#ifndef FUNCLIB_J204_COMMON_H_INCLUDED
#define FUNCLIB_J204_COMMON_H_INCLUDED

#ifdef __cplusplus
extern "C" {
#endif

#include "bsppub.h"
#include "bspcomm.h"
#include "funccommon_log.h"
#include "exprn.h"

/**************************************************************************
 *                               宏定义
 **************************************************************************/
#define CHECK_NULL_POINTER(ppointer)  if(NULL == ppointer) { dbgErr("%s %s is NULL!\n", __func__, #ppointer); return BSP_ERROR;}
#define CHECK_SKIP_CFG(plink,pmap)  if(NULL==plink || NULL==pmap) {continue; }
#define CHECK_LOADFW_RETVAL(str,mask,tx,rx,retVal)  \
        if(BSP_OK != retVal)                            \
        {                                               \
            dbgErr("%s %s mask=%#x tx=%d rx=%d err!\n", __func__, #str, mask, tx, rx); \
        }
#define CHECK_SERDES_RETVAL(str,mask,dir,rate,retVal)  \
        if(BSP_OK != retVal)                      \
        {                                         \
            dbgErr("%s %s mask=%#x dir=%d rate=%d err!\n", __func__, #str, mask, dir, rate); \
        }

#define RESULT_TO_STR(result)  ((result)==0?"OK":((result)==0xff?"SKIP":"ERR"))

/* 打印控制 */
extern UINT32 j204PrnFlag;
#define j204ExLog(flag,fmt,...) if (j204PrnFlag & flag) dbgInfo(fmt, ##__VA_ARGS__)
    
/* 打印开关 */
#define J204_SERDES (0x1)
#define J204_BLOCK (0x2)
#define J204_CRM (0x4)
#define J204_OTHERS (0x8)

#ifdef __cplusplus
}
#endif
#endif //FUNCLIB_J204_COMMON_H_INCLUDED



#ifndef _FUNCLIB_J204COMMON_H_
#define _FUNCLIB_J204COMMON_H_



#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif
#endif



/*****************************************************************************
* 版权所有(C) 2017, ZTE Corp. ZXSDR-RRU Platform BSP
*----------------------------------------------------------------------------
* 模  块  名 : papt_mts2pre
* 文件名称 : papt_mts2pre.c
* 文件标识 : {[N/A]}
* 内容摘要 : 本文件提供了PAPT公共模块的函数声明
* 注意事项 : 无
* 作       者 : 10248577
* 创建日期 : 2022-03-10
* 当前版本 : Ver1.0
*---------------------------------------------------------------------------*/
#include "bsppub.h"
#include "bspcomm.h"
#include "papt_mts2pre.h"
#include "rruinfo.h"
#include "mts2_common.h"
#include "mts2_paprotect.h"
#include "mts2_jesd204.h"
#include "exprn.h"
#include "funccommon_log.h"
#include "papt_private.h"
/**************************************************************************
 *                        宏定义
 **************************************************************************/



/**************************************************************************
 *                        全局变量
 **************************************************************************/

/**************************************************************************
*                         函数声明
**************************************************************************/



/**************************************************************************
*                         函数定义
**************************************************************************/


/* ---------------------------------------------------------------------------- */
/* -------------------------------- 告警检测 ---------------------------------- */
/* ---------------------------------------------------------------------------- */
/*****************************************************************************
 * 函数名称: Mts2GetPastMcuPllAlmStatus(*)
 * 功能描述: 获取Mts历史告警状态
 * 输入参数: lChipId          - MTS chip id
 *           ulBitsMask   - 获取的告警BitsMask, 默认0xFFFFFFFF;
 * 输出参数: pulEventBits - 告警事件MASK值
 * 返 回 值: 0 - 正常, 其它值 - 异常
 * 其它说明: 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10288704@2021-08-26, 创建
 *----------------------------------------------------------------------------
 */
INT32 Mts2GetPastMcuPllAlmStatus(INT32 lChipId, UINT32 ulBitsMask, UINT32 *pulEventBits)
{
    UINT32 ulEventStatus = 0;
    INT32  lGetPaAlmFlag = 0;
    INT32  lFunRet = 0;

    MTS2_CHECK_CHIP(lChipId);
    MTS2_CHECK_POINTER(pulEventBits);

    lGetPaAlmFlag = MTS2_PllProtect(lChipId);
    /* MTS子接口获取异常, 按照无告警处理, 父函数返回失败 */
    if (lGetPaAlmFlag < 0)
    {
        lGetPaAlmFlag = 0;
        lFunRet = -1;
        dbgErr("%s>>Chip'%d AlmFlag Get Error!\n", __FUNCTION__, lChipId);
    }
    ulEventStatus = lGetPaAlmFlag & ulBitsMask;
    dbgInfoEx("[%s] ulBitsMask:0x%08X lGetPaAlmFlag:%d ulEventStatus:%d\n",__FUNCTION__,ulBitsMask,lGetPaAlmFlag,ulEventStatus);

    BspSetTransPaProAlmFlagByChip(lChipId, TRANS_MCU_PLL_PAPRO_ALMTYPE, lGetPaAlmFlag);

    if (NULL != pulEventBits)
    {
        *pulEventBits = ulEventStatus;
    }

    dbgInfoEx("%s>>Chip'%d: Alm= Chnl'0x%08X  Mask'0x%08X\n", __FUNCTION__,
              lChipId, ulEventStatus, ulBitsMask);
    return lFunRet;

}

/*****************************************************************************
 * 函数名称: Mts2GetPastJ204bcAlmStatus(*)
 * 功能描述: 获取Mts历史告警状态
 * 输入参数: lChipId          - MTS chip id
 *           ulBitsMask   - 获取的告警BitsMask, 默认0xFFFFFFFF;
 * 输出参数: pulEventBits - 告警事件MASK值
 * 返 回 值: 0 - 正常, 其它值 - 异常
 * 其它说明: 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10288704@2021-08-26, 创建
 *----------------------------------------------------------------------------
 */
INT32 Mts2GetPastJ204bcAlmStatus(INT32 lChipId, UINT32 ulBitsMask, UINT32 *pulEventBits)
{
    UINT32 ulEventStatus = 0;
    INT32  lGetPaAlmFlag = 0;
    INT32  lFunRet = 0;

    MTS2_CHECK_CHIP(lChipId);
    MTS2_CHECK_POINTER(pulEventBits);

    lGetPaAlmFlag = MTS2_204RampProtect(lChipId);

    /* MTS子接口获取异常, 按照无告警处理, 父函数返回失败 */
    if (lGetPaAlmFlag < 0)
    {
        lGetPaAlmFlag = 0;
        lFunRet = -1;
        dbgErr("%s>>Chip'%d AlmFlag Get Error!\n", __FUNCTION__, lChipId);
    }

    ulEventStatus = lGetPaAlmFlag & ulBitsMask;
    dbgInfoEx("[%s] ulBitsMask:0x%08X lGetPaAlmFlag:%d ulEventStatus:%d\n",__FUNCTION__,ulBitsMask,lGetPaAlmFlag,ulEventStatus);

    BspSetTransPaProAlmFlagByChip(lChipId, TRANS_J204BC_PAPRO_ALMTYPE, lGetPaAlmFlag);

    if (NULL != pulEventBits)
    {
        *pulEventBits = ulEventStatus;
    }

    dbgInfoEx("%s>>Chip'%d: Alm= Chnl'0x%08X  Mask'0x%08X\n", __FUNCTION__,
              lChipId, ulEventStatus, ulBitsMask);
    return lFunRet;
}

/*****************************************************************************
 * 函数名称: Mts2GetPastSerdesAlmStatus(*)
 * 功能描述: 获取Mts历史告警状态
 * 输入参数: lChipId     - MTS chip id
 *           ulBitsMask  - 获取的告警BitsMask, 默认0xFFFFFFFF;
 * 输出参数: pulEventBits - 告警事件MASK值
 * 返 回 值: 0- 正常, 其它值- 异常
 * 其它说明: Serdes告警与TX_ERR进行关联的有SerdesPll失锁
 *           查询告警分类, 该分类下不动作; 无后处理
 *           0x20031910[0]- Serdes Pll Unlock
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10288704@2021-08-26, 创建
 *----------------------------------------------------------------------------
 */
INT32 Mts2GetPastSerdesAlmStatus(INT32 lChipId, UINT32 ulBitsMask, UINT32 *pulEventBits)
{
    UINT32 ulEventStatus = 0;
    INT32  lGetPaAlmFlag = 0;
    INT32  lFunRet = 0;

    MTS2_CHECK_CHIP(lChipId);
    MTS2_CHECK_POINTER(pulEventBits);

    lGetPaAlmFlag = MTS2_SerdesRampProtect(lChipId);

    /* MTS子接口获取异常, 按照无告警处理, 父函数返回失败 */
    if (lGetPaAlmFlag < 0)
    {
        lGetPaAlmFlag = 0;
        lFunRet = -1;
        dbgErr("%s>>Chip'%d AlmFlag Get Error!\n", __FUNCTION__, lChipId);
    }
   
    ulEventStatus = lGetPaAlmFlag & ulBitsMask;
    dbgInfoEx("[%s] ulBitsMask:0x%08X lGetPaAlmFlag:%d ulEventStatus:%d\n",__FUNCTION__,ulBitsMask,lGetPaAlmFlag,ulEventStatus);

    BspSetTransPaProAlmFlagByChip(lChipId, TRANS_SERDES_PAPRO_ALMTYPE, lGetPaAlmFlag);

    if (NULL != pulEventBits)
    {
        *pulEventBits = ulEventStatus;
    }
    
    dbgInfoEx("%s>>Chip'%d: Alm= Chnl'0x%08X  Mask'0x%08X\n", __FUNCTION__,
              lChipId, ulEventStatus, ulBitsMask);
    return lFunRet;
}

/*****************************************************************************
 * 函数名称: Mts2GetPastOutBufAlmStatus(*)
 * 功能描述: 获取Mts历史告警状态
 * 输入参数: lChipId     - MTS chip id
 *           ulBitsMask  - 获取的告警BitsMask, 默认0xFFFFFFFF;
 * 输出参数: pulEventBits - 告警事件MASK值
 * 返 回 值: 0- 正常, 其它值- 异常
 * 其它说明: TX链路时钟域转换出窗包括: 204xToDlp、DlpToDcp、DcpToDac
 *           单点、均值、宽谱、时域转换超门限告警后会触发MTS内部RAMP关断来保护, 功率异常
 *           时不与Tx_Err管脚关联, 不借外部保护, 单需软件定时查询MTS保护状态来恢复;
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10288704@2021-08-26, 创建
 *----------------------------------------------------------------------------
 */
INT32 Mts2GetPastOutBufAlmStatus(INT32 lChipId, UINT32 ulBitsMask, UINT32 *pulEventBits)
{
    UINT32 ulEventStatus = 0;
    INT32  lGetPaAlmFlag = 0;
    INT32  lFunRet = 0;

    MTS2_CHECK_CHIP(lChipId);
    MTS2_CHECK_POINTER(pulEventBits);

    /* 出窗告警不与Tx_Err管脚关联 */
    lGetPaAlmFlag = MTS2_OutBufRampProtect(lChipId);

    /* MTS子接口获取异常, 按照无告警处理, 父函数返回失败 */
    if (lGetPaAlmFlag < 0)
    {
        lGetPaAlmFlag = 0;
        lFunRet = -1;
        dbgErr("%s>>Chip'%d AlmFlag Get Error!\n", __FUNCTION__, lChipId);
    }

    ulEventStatus = lGetPaAlmFlag & ulBitsMask;
    dbgInfoEx("[%s] ulBitsMask:0x%08X lGetPaAlmFlag:%d ulEventStatus:%d\n",__FUNCTION__,ulBitsMask,lGetPaAlmFlag,ulEventStatus);

    BspSetTransPaProAlmFlagByChip(lChipId, TRANS_OUTBUF_PAPRO_ALMTYPE, lGetPaAlmFlag);

    if (NULL != pulEventBits)
    {
        *pulEventBits = ulEventStatus;
    }

    dbgInfoEx("%s>>Chip'%d: Alm= Chnl'0x%08X  Mask'0x%08X\n", __FUNCTION__,
              lChipId, ulEventStatus, ulBitsMask);
    return lFunRet;
}


/*****************************************************************************
 * 函数名称: Mts2GetPastPwrErrAlmStatus(*)
 * 功能描述: 获取Mts历史告警状态
 * 输入参数: lChipId     - MTS chip id
 *           ulBitsMask  - 获取的告警BitsMask, 默认0xFFFFFFFF;
 * 输出参数: pulEventBits - 告警事件MASK值
 * 返 回 值: 0- 正常, 其它值- 异常
 * 其它说明: TX链路数据检测异常包括: 单点功率检测, 宽谱功率检测;
 *           单点修改门限接口: MtsCfgSglPwrThresh
 *           宽谱修改门限接口: MtsCfgWbPwrThresh, MTS0.3芯片不支持;
 *           单点、均值、宽谱、时域转换超门限告警后会触发MTS内部RAMP关断来保护, 功率异常
 *           时不与Tx_Err管脚关联, 不借外部保护, 单需软件定时查询MTS保护状态来恢复;
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10288704@2021-08-26, 创建
 *----------------------------------------------------------------------------
 */
INT32 Mts2GetPastPwrErrAlmStatus(INT32 lChipId, UINT32 ulBitsMask, UINT32 *pulEventBits)
{
    INT32  lTmpAlmFlag = 0;
    UINT32 ulMtsChnlIdx = 0;
    UINT32 ulMtsErrCnts = 0;
    UINT32 ulGetAlmFlag = 0;
    UINT32 ulChnlBitAlm = 0;
    UINT32 ulEventStatus = 0;
    INT32  lFunRet = 0;

    MTS2_CHECK_CHIP(lChipId);
    MTS2_CHECK_POINTER(pulEventBits);

    /* 功率异常时不与Tx_Err管脚关联 */
    for (ulMtsChnlIdx = 0; ulMtsChnlIdx < 8; ulMtsChnlIdx++)
    {
        if(BSP_OK != BspPaptIsTransceiverChnlUsed(lChipId, ulMtsChnlIdx))
        {
            continue;
        }
        lTmpAlmFlag = MTS2_SglWbRampProtect(lChipId, ulMtsChnlIdx);
        if (lTmpAlmFlag < 0)
        {
            lTmpAlmFlag = 0; /* MTS子接口通道获取异常, 按照无告警处理 */
            ulMtsErrCnts++;
            dbgErr("%s>>Chip'%d MtsChnl'%d AlmFlag Get Error!\n",
                   __FUNCTION__, lChipId, ulMtsChnlIdx);
        }

        /* 有告警且对应的Bit配置有效, 再配置上报APP告警保护标志 */
        ulChnlBitAlm = (!!lTmpAlmFlag);     
        dbgInfoEx("[%s] ulBitsMask:0x%08X lTmpAlmFlag:%d ulChnlBitAlm:%d\n",__FUNCTION__,ulBitsMask,lTmpAlmFlag,ulChnlBitAlm);
        
        BspSetTransPaProAlmFlagByChn(lChipId, ulMtsChnlIdx, TRANS_PWRERR_PAPRO_ALMTYPE, ulChnlBitAlm);

        /* 单片MTS上每个TX通道占8Bits, 不合理的话再优化 */
        ulGetAlmFlag |= lTmpAlmFlag;

    }
    /* MTS子接口芯片上所有通道获取异常, 按照无告警处理, 父函数返回失败 */
    if (ulMtsErrCnts >= 8)
    {
        lFunRet = -1;
        dbgErr("%s>>Chip'%d AlmFlag Get Error!\n", __FUNCTION__, lChipId);
    }

    ulEventStatus = ulGetAlmFlag & ulBitsMask;
    if (NULL != pulEventBits)
    {
        *pulEventBits = ulEventStatus;
    }

    dbgInfoEx("%s>>Chip'%d: Alm= Chnl'0x%08X  Mask'0x%08X\n", __FUNCTION__,
              lChipId, ulEventStatus, ulBitsMask);
    return lFunRet;
}
/*****************************************************************************
 * 函数名称: Mts2GetPastArmErrAlmStatus(*)
 * 功能描述: 获取Mts历史告警状态
 * 输入参数: lChipId     - MTS chip id
 *           ulBitsMask  - 获取的告警BitsMask, 默认0xFFFFFFFF;
 * 输出参数: pulEventBits - 告警事件MASK值
 * 返 回 值: 0- 正常, 其它值- 异常
 * 其它说明: arm类告警;
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10288704@2021-08-26, 创建
 *----------------------------------------------------------------------------
 */
INT32 Mts2GetPastArmErrAlmStatus(INT32 lChipId, UINT32 ulBitsMask, UINT32 *pulEventBits)
{
    UINT32 ulEventStatus = 0;
    INT32  lGetPaAlmFlag = 0;
    INT32  lFunRet = 0;

    MTS2_CHECK_CHIP(lChipId);
    MTS2_CHECK_POINTER(pulEventBits);

    lGetPaAlmFlag = MTS2_WtdProtect(lChipId);
    /* MTS子接口获取异常, 按照无告警处理, 父函数返回失败 */
    if (lGetPaAlmFlag < 0)
    {
        lGetPaAlmFlag = 0;
        lFunRet = -1;
        dbgErr("%s>>Chip'%d AlmFlag Get Error!\n", __FUNCTION__, lChipId);
    }
    ulEventStatus = lGetPaAlmFlag & ulBitsMask;
    dbgInfoEx("[%s] ulBitsMask:0x%08X lGetPaAlmFlag:%d ulEventStatus:%d\n",__FUNCTION__,ulBitsMask,lGetPaAlmFlag,ulEventStatus);

    BspSetTransPaProAlmFlagByChip(lChipId, TRANS_MCU_PLL_PAPRO_ALMTYPE, lGetPaAlmFlag);

    if (NULL != pulEventBits)
    {
        *pulEventBits = ulEventStatus;
    }

    dbgInfoEx("%s>>Chip'%d: Alm= Chnl'0x%08X  Mask'0x%08X\n", __FUNCTION__,
              lChipId, ulEventStatus, ulBitsMask);
    return lFunRet;

}
/* ---------------------------------------------------------------------------- */
/* -------------------------------- 告警后处理 -------------------------------- */
/* ---------------------------------------------------------------------------- */

/*****************************************************************************
 * 函数名称: Mts2McuPllAlmRecover(*)
 * 功能描述: McuPllAlm异常后处理
 * 输入参数: lChipId       - MTS chip id
 *           ulAlmBitsMask - 告警事件MASK值
 * 输出参数: 无
 * 返 回 值: 0- 正常或无后处理操作正常, 负值- 后处理操作异常, 正值- 表示有后处理操作
 * 其它说明: 连续ulAlmBitsMask有3次告警, 才允许后处理
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10119095@2020-07-08, 创建
 *----------------------------------------------------------------------------
 */
INT32 Mts2McuPllAlmRecover(INT32 lChipId, UINT64 u64AlmBitsMask)
{
    /*
        MTS内部自动关数据，并送给DPDIC告警信号，DPDIC关PA。
        本告警无恢复处理，高层检测三次异常后触发立即复位或凌晨复位, 
    */
    return 0;
}

/*****************************************************************************
 * 函数名称: Mts2J204bcAlmRecover(*)
 * 功能描述: J204bc异常后处理
 * 输入参数: lChipId       - MTS chip id
 *           ulAlmBitsMask - 告警事件MASK值
 * 输出参数: 无
 * 返 回 值: 0- 正常或无后处理操作正常, 负值- 后处理操作异常, 正值- 表示有后处理操作
 * 其它说明: 连续ulAlmBitsMask有3次告警, 才允许后处理
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10119095@2020-07-08, 创建
 *----------------------------------------------------------------------------
 */
INT32 Mts2J204bcAlmRecover(INT32 lChipId, UINT64 u64AlmBitsMask)
{
    INT32 lRetVal = 0;

    if (0 == u64AlmBitsMask)
    {
        dbgInfoEx("%s>>Chip'%d AlmMask'0x%llX: return!\n",
                  __FUNCTION__, lChipId, u64AlmBitsMask);
        return 0; // 表示无后处理操作
    }
    
    lRetVal = BspPaptJ204LinkRebuildWithRetry(lChipId);
    return lRetVal;
}

/*****************************************************************************
 * 函数名称: Mts2SerdesAlmRecover(*)
 * 功能描述: serdes异常后处理
 * 输入参数: lChipId       - MTS chip id
 *           ulAlmBitsMask - 告警事件MASK值
 * 输出参数: 无
 * 返 回 值: 0- 正常或无后处理操作正常, 负值- 后处理操作异常, 正值- 表示有后处理操作
 * 其它说明: 连续ulAlmBitsMask有3次告警, 才允许后处理
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10119095@2020-07-08, 创建
 *----------------------------------------------------------------------------
 */
INT32 Mts2SerdesAlmRecover(INT32 lChipId, UINT64 u64AlmBitsMask)
{
    /*
        MTS内部自动关数据，并送给DPDIC告警信号，DPDIC关PA。
        本告警无恢复处理，高层检测三次异常后触发立即复位或凌晨复位, 
    */
    return 0;
}

/*****************************************************************************
 * 函数名称: Mts2OutBufAlmRecover(*)
 * 功能描述: 出窗告警异常后处理
 * 输入参数: lChipId       - MTS chip id
 *           ulAlmBitsMask - 告警事件MASK值
 * 输出参数: 无
 * 返 回 值: 0- 正常或无后处理操作正常, 负值- 后处理操作异常, 正值- 表示有后处理操作
 * 其它说明: 连续ulAlmBitsMask有3次告警, 才允许后处理
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10119095@2020-07-08, 创建
 *----------------------------------------------------------------------------
 */
INT32 Mts2OutBufAlmRecover(INT32 lChipId, UINT64 u64AlmBitsMask)
{
    /*
        MTS内部自动关数据，不会送给DPDIC告警信号，无法关PA(todo                     和万亮亮确认中)。
        本告警无恢复处理，高层检测三次异常后触发立即复位或凌晨复位, 
    */
    return 0;
}

/*****************************************************************************
 * 函数名称: Mts2PwrErrAlmRecover(*)
 * 功能描述: 链路功率异常后处理
 * 输入参数: lChipId       - MTS chip id
 *           ulAlmBitsMask - 告警事件MASK值
 * 输出参数: 无
 * 返 回 值: 0- 正常或无后处理操作正常, 负值- 后处理操作异常, 正值- 表示有后处理操作
 * 其它说明: 连续ulAlmBitsMask有3次告警, 才允许后处理
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10119095@2020-07-08, 创建
 *----------------------------------------------------------------------------
 */
INT32 Mts2PwrErrAlmRecover(INT32 lChipId, UINT64 u64AlmBitsMask)
{
    /*
        MTS内部自动关数据，不会送给DPDIC告警信号，无法关PA(todo                     和万亮亮确认中)。
        本告警无恢复处理，高层检测三次异常后触发立即复位或凌晨复位, 
    */
    return 0;
}

/*****************************************************************************
 * 函数名称: Mts2ArmErrAlmRecover(*)
 * 功能描述: ARM告警异常后处理
 * 输入参数: lChipId       - MTS chip id
 *           ulAlmBitsMask - 告警事件MASK值
 * 输出参数: 无
 * 返 回 值: 0- 正常或无后处理操作正常, 负值- 后处理操作异常, 正值- 表示有后处理操作
 * 其它说明: 连续ulAlmBitsMask有3次告警, 才允许后处理
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10119095@2020-07-08, 创建
 *----------------------------------------------------------------------------
 */
INT32 Mts2ArmErrAlmRecover(INT32 lChipId, UINT64 u64AlmBitsMask)
{
    /*
        MTS内部自动关数据，并送给DPDIC告警信号，DPDIC关PA。
        本告警无恢复处理，高层检测三次异常后触发立即复位或凌晨复位, 
    */
    return 0;
}


/*****************************************************************************
 * 函数名称: Mts2J204Rebuild(*)
 * 功能描述: mts2 j204重新建链
 * 输入参数: lChipId       - MTS chip id
 *           ulAlmBitsMask - 告警事件MASK值
 * 输出参数: 无
 * 返 回 值: 0- 正常或无后处理操作正常, 负值- 后处理操作异常, 正值- 表示有后处理操作
 * 其它说明: 连续ulAlmBitsMask有3次告警, 才允许后处理
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10119095@2020-07-08, 创建
 *----------------------------------------------------------------------------
 */
INT32 Mts2J204Rebuild(UINT32 lChipId)
{
    dbgInfoEx("%s lChipId=%d\n", __func__, lChipId);
    return MTS2_RestRlsrest204Serdes(lChipId);    
}


/* ---------------------------------------------------------------------------- */
/* ---------------------------------- 对外接口 -------------------------------- */
/* ---------------------------------------------------------------------------- */
/*****************************************************************************
 * 函数名称: Mts2GetPastPaProAlm(*)
 * 功能描述: Mts2功放保护告警检测
 * 输入参数: lChipId       - MTS chip id
 *           ulAlmType - 告警类型
 *           pu64EventBits - 告警掩码
 * 输出参数: 无
 * 返 回 值: BSP_OK- 成功; 负值- 失败
 * 其它说明: 连续pu64EventBits有3次告警, 才允许后处理
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10119095@2020-07-08, 创建
 *----------------------------------------------------------------------------
 */
INT32 Mts2GetPastPaProAlm(UINT32 chipId, E_TRANS_PAPRO_ALM_TYPE ulAlmType, UINT64 *pu64EventBits)
{
    INT32 lChipId = (INT32)chipId;
    INT32 lRetVal = 0;
    UINT32 ulMtsAlmBits = 0;
    UINT32 ulLastMtsAlmBits = 0;

    /* 分类检测告警 */
    switch (ulAlmType)
    {
    case TRANS_MCU_PLL_PAPRO_ALMTYPE:
        lRetVal = Mts2GetPastMcuPllAlmStatus(lChipId, 0xFFFFFFFF, &ulMtsAlmBits);
        break;
    case TRANS_J204BC_PAPRO_ALMTYPE:
        lRetVal = Mts2GetPastJ204bcAlmStatus(lChipId, 0xFFFFFFFF, &ulMtsAlmBits);
        break;
    case TRANS_SERDES_PAPRO_ALMTYPE:
        lRetVal = Mts2GetPastSerdesAlmStatus(lChipId, 0xFFFFFFFF, &ulMtsAlmBits);
        break;
    case TRANS_OUTBUF_PAPRO_ALMTYPE:
        lRetVal = Mts2GetPastOutBufAlmStatus(lChipId, 0xFFFFFFFF, &ulMtsAlmBits);
        break;
    case TRANS_PWRERR_PAPRO_ALMTYPE:
        lRetVal = Mts2GetPastPwrErrAlmStatus(lChipId, 0xFFFFFFFF, &ulMtsAlmBits);
        break;
    case TRANS_OTHERS_PAPRO_ALMTYPE:
        lRetVal = Mts2GetPastArmErrAlmStatus(lChipId, 0xFFFFFFFF, &ulMtsAlmBits);
        break;
    default:
        lRetVal = PAPT_NOT_SUPPORT_ALM;
        break;
    }

    if(ulLastMtsAlmBits != ulMtsAlmBits)
    {
        ulLastMtsAlmBits = ulMtsAlmBits;
        BspLog(LOG_LEVEL_0,"papt: %s: ePaProType[%d], ulMtsAlmBits[%d], ulLastEventBits[%d]\n",__FUNCTION__,ulAlmType, ulMtsAlmBits, ulLastMtsAlmBits);
    }

    if (NULL != pu64EventBits)
    {
        *pu64EventBits = (UINT64)ulMtsAlmBits;
    }

    return lRetVal;
}

/*****************************************************************************
 * 函数名称: Mts2ClrPastPaProAlm(*)
 * 功能描述: Mts2功放保护告警清除
 * 输入参数: lChipId       - MTS chip id
 *           ulAlmType - 告警类型
 * 输出参数: 无
 * 返 回 值: BSP_OK- 成功; 负值- 失败
 * 其它说明: 
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10119095@2020-07-08, 创建
 *----------------------------------------------------------------------------
 */
INT32 Mts2ClrPastPaProAlm(UINT32 chipId, E_TRANS_PAPRO_ALM_TYPE ulAlmType)
{
    INT32 lRetVal = 0;    
    /* 
        MTS告警为读清模式，不需要单独的清告警动作 
    */
    return lRetVal;
}

/*****************************************************************************
 * 函数名称: Mts2PaProAlmRecover(*)
 * 功能描述: Mts2功放保护告警后处理
 * 输入参数: lChipId       - MTS chip id
 *           ulAlmType - 告警类型
 *           u64AlmBitsMask - 告警掩码
 * 输出参数: 无
 * 返 回 值: 0- 正常或无后处理操作正常, 负值- 后处理操作异常, 正值- 表示有后处理操作
 * 其它说明: 连续pu64EventBits有3次告警, 才允许后处理
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10119095@2020-07-08, 创建
 *----------------------------------------------------------------------------
 */
INT32 Mts2PaProAlmRecover(UINT32 chipId, E_TRANS_PAPRO_ALM_TYPE ulAlmType, UINT64 u64AlmBitsMask)
{
    INT32 lChipId = (INT32)chipId;
    INT32 lTmpRet = 0;
    INT32 lRetVal = 0;
    UINT64 u64EventAlm = 0;

    switch (ulAlmType)
    {
    case TRANS_MCU_PLL_PAPRO_ALMTYPE:
        lRetVal = Mts2McuPllAlmRecover(lChipId, u64AlmBitsMask);
        break;
    case TRANS_J204BC_PAPRO_ALMTYPE:
        lRetVal = Mts2J204bcAlmRecover(lChipId, u64AlmBitsMask);
        break;
    case TRANS_SERDES_PAPRO_ALMTYPE:
        lRetVal = Mts2SerdesAlmRecover(lChipId, u64AlmBitsMask);
        break;
    case TRANS_OUTBUF_PAPRO_ALMTYPE:
        lRetVal = Mts2OutBufAlmRecover(lChipId, u64AlmBitsMask);
        break;
    case TRANS_PWRERR_PAPRO_ALMTYPE:
        lRetVal = Mts2PwrErrAlmRecover(lChipId, u64AlmBitsMask);
        break;
    case TRANS_OTHERS_PAPRO_ALMTYPE:
        lRetVal = Mts2ArmErrAlmRecover(lChipId, u64AlmBitsMask);
        break;   
    default: // E_PA_PRO_TYPE_INVALID_DEFINE
        lRetVal = PAPT_NOT_SUPPORT_ALM;
        break;
    }

    if ((UINT64)0 != u64AlmBitsMask)
    {
        /* MTS告警清除就是获取一次告警状态 */
        lTmpRet = Mts2GetPastPaProAlm(chipId, ulAlmType, &u64EventAlm);
        dbgInfoEx("%s>>PaProType'%d Ret'%d: AlmStatus= 0x%llX\n",
                  __FUNCTION__, ulAlmType, lTmpRet, u64EventAlm);
    }

    return lRetVal;
}

/*****************************************************************************
 * 函数名称: Mts2ClrAlmAfterInit(*)
 * 功能描述: 清除trancsceiver上所有告警
 * 输入参数: lChipId       - MTS chip id
 * 输出参数: 无
 * 返 回 值: 0- 正常或无后处理操作正常, 负值- 后处理操作异常, 正值- 表示有后处理操作
 * 其它说明: 初始化完成后，清除trancsceiver上所有告警
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10119095@2020-07-08, 创建
 *----------------------------------------------------------------------------
 */
INT32 Mts2ClrAlmAfterInit(UINT32 chipId)
{    
    return MTS2_ClearHistoryRampStatus(chipId);
}


/*****************************************************************************
 * 函数名称: Mts2ClrAlmAfterInit(*)
 * 功能描述: 清除trancsceiver上所有告警
 * 输入参数: lChipId       - MTS chip id
 * 输出参数: 无
 * 返 回 值: 0- 正常或无后处理操作正常, 负值- 后处理操作异常, 正值- 表示有后处理操作
 * 其它说明: 初始化完成后，清除trancsceiver上所有告警
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10119095@2020-07-08, 创建
 *----------------------------------------------------------------------------
 */
INT32 Mts2IcLaneAlmRecover(E_PaProType ePaProType, UINT64 u64AlmBitsMask)
{
    INT32 lRetVal = 0;
  
    if(E_PA_PRO_TYPE_IC_LANE_STATUS == ePaProType)
    {
        /*
            暂时按照对整片IC和全部Transceiver全部重新建链来实现，
            后续可以利用以下结构体中的信息：
                T_J204OnePairEnds -> dpdicLaneMask 和 transIdMask
            根据u64AlmBitsMask和dpdicLaneMask对比，
            判断DPDIC的哪个Grp及哪些片Transceiver需要重新建链
        */
        lRetVal = Mts2J204bcAlmRecover(PAPT_TRANS_FULL_MASK, u64AlmBitsMask); // 255表示所有MTS芯片
    }
    else 
    {
        lRetVal = PAPT_NOT_SUPPORT_ALM;
    }

    return lRetVal;
}
/**************************************************************************
*                                  维测接口
**************************************************************************/
VOID exprnaddmts2prepapt(VOID)
{
    exprnadd("Mts2J204bcAlmRecover");
    exprnadd("Mts2GetPastMcuPllAlmStatus");
    exprnadd("Mts2GetPastJ204bcAlmStatus");
    exprnadd("Mts2GetPastSerdesAlmStatus");
    exprnadd("Mts2GetPastOutBufAlmStatus");
    exprnadd("Mts2GetPastPwrErrAlmStatus");
    exprnadd("Mts2J204bcAlmRecover");
    exprnadd("Mts2J204Rebuild");
    return;
}

INT32 DbgMts2J204bcAlmRecover(UINT32 chip)
{
    return Mts2J204bcAlmRecover(chip, 0xff);
}

/**************************************************************************
                             回调挂接
 **************************************************************************/
static __attribute((constructor)) void SetMts2prePaptFunc() 
{
    (VOID)BspSetTransGetPaProAlmFunc(DEVICE_MTS2PRE,Mts2GetPastPaProAlm);
    (VOID)BspSetTransClrPaProAlmFunc(DEVICE_MTS2PRE,Mts2ClrPastPaProAlm);
    (VOID)BspSetTransPaProAlmRecoverFunc(DEVICE_MTS2PRE,Mts2PaProAlmRecover);
    (VOID)BspSetTransClrAlmAfterInitFunc(DEVICE_MTS2PRE,Mts2ClrAlmAfterInit);
    (VOID)BspSetTransJ204RebuildFunc(DEVICE_MTS2PRE,Mts2J204Rebuild);
    (VOID)BspSetPaProAlmRecoverFunc(E_PA_PRO_TYPE_IC_LANE_STATUS, Mts2IcLaneAlmRecover);
}



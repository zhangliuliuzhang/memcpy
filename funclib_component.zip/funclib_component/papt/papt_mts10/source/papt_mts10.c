/*****************************************************************************
* 版权所有(C) 2017, ZTE Corp. ZXSDR-RRU Platform BSP
*----------------------------------------------------------------------------
* 模  块  名 : papt_mts10
* 文件名称 : papt_mts10.c
* 文件标识 : {[N/A]}
* 内容摘要 : 本文件提供了PAPT公共模块的函数声明
* 注意事项 : 无
* 作       者 : 10248577
* 创建日期 : 2022-03-10
* 当前版本 : Ver1.0
*---------------------------------------------------------------------------*/
#include "bsppub.h"
#include "bspcomm.h"
#include "papt_mts10.h"
#include "rruinfo.h"
#include "mts_common.h"
#include "mts_paprotect.h"
#include "mts_jesd204.h"
#include "exprn.h"
#include "funccommon_log.h"
#include "papt_private.h"
/**************************************************************************
 *                        宏定义
 **************************************************************************/



/**************************************************************************
 *                        全局变量
 **************************************************************************/

/**************************************************************************
*                         函数声明
**************************************************************************/



/**************************************************************************
*                         函数定义
**************************************************************************/

/* ---------------------------------------------------------------------------- */
/* -------------------------------- 告警检测 ---------------------------------- */
/* ---------------------------------------------------------------------------- */
/*****************************************************************************
 * 函数名称: MtsGetPastMcuPllAlmStatus(*)
 * 功能描述: 获取Mts历史告警状态
 * 输入参数: lChipId          - MTS chip id
 *           ulBitsMask   - 获取的告警BitsMask, 默认0xFFFFFFFF;
 * 输出参数: pulEventBits - 告警事件MASK值
 * 返 回 值: 0 - 正常, 其它值 - 异常
 * 其它说明: 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10288704@2021-08-26, 创建
 *----------------------------------------------------------------------------
 */
INT32 MtsGetPastMcuPllAlmStatus(INT32 lChipId, UINT32 ulBitsMask, UINT32 *pulEventBits)
{
    UINT32 ulEventStatus = 0;
    INT32  lGetPaAlmFlag = 0;
    INT32  lFunRet = 0;

    MTS_CHECK_CHIP(lChipId);
    MTS_CHECK_POINTER(pulEventBits);

    lGetPaAlmFlag = MTS_PllRampProtect(lChipId);
    /* MTS子接口获取异常, 按照无告警处理, 父函数返回失败 */
    if (lGetPaAlmFlag < 0)
    {
        lGetPaAlmFlag = 0;
        lFunRet = -1;
        dbgErr("%s>>Chip'%d AlmFlag Get Error!\n", __FUNCTION__, lChipId);
    }
    ulEventStatus = lGetPaAlmFlag & ulBitsMask;
    dbgInfoEx("[%s] ulBitsMask:0x%08X lGetPaAlmFlag:%d ulEventStatus:%d\n",__FUNCTION__,ulBitsMask,lGetPaAlmFlag,ulEventStatus);

    BspSetTransPaProAlmFlagByChip(lChipId, TRANS_MCU_PLL_PAPRO_ALMTYPE, lGetPaAlmFlag);

    if (NULL != pulEventBits)
    {
        *pulEventBits = ulEventStatus;
    }

    dbgInfoEx("%s>>Chip'%d: Alm= Chnl'0x%08X  Mask'0x%08X\n", __FUNCTION__,
              lChipId, ulEventStatus, ulBitsMask);
    return lFunRet;

}

/*****************************************************************************
 * 函数名称: MtsGetPastJ204bcAlmStatus(*)
 * 功能描述: 获取Mts历史告警状态
 * 输入参数: lChipId          - MTS chip id
 *           ulBitsMask   - 获取的告警BitsMask, 默认0xFFFFFFFF;
 * 输出参数: pulEventBits - 告警事件MASK值
 * 返 回 值: 0 - 正常, 其它值 - 异常
 * 其它说明: 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10288704@2021-08-26, 创建
 *----------------------------------------------------------------------------
 */
INT32 MtsGetPastJ204bcAlmStatus(INT32 lChipId, UINT32 ulBitsMask, UINT32 *pulEventBits)
{
    UINT32 ulEventStatus = 0;
    INT32  lGetPaAlmFlag = 0;
    INT32  lFunRet = 0;

    MTS_CHECK_CHIP(lChipId);
    MTS_CHECK_POINTER(pulEventBits);

    lGetPaAlmFlag = MTS_204RampProtect(lChipId);

    /* MTS子接口获取异常, 按照无告警处理, 父函数返回失败 */
    if (lGetPaAlmFlag < 0)
    {
        lGetPaAlmFlag = 0;
        lFunRet = -1;
        dbgErr("%s>>Chip'%d AlmFlag Get Error!\n", __FUNCTION__, lChipId);
    }

    ulEventStatus = lGetPaAlmFlag & ulBitsMask;
    dbgInfoEx("[%s] ulBitsMask:0x%08X lGetPaAlmFlag:%d ulEventStatus:%d\n",__FUNCTION__,ulBitsMask,lGetPaAlmFlag,ulEventStatus);

    BspSetTransPaProAlmFlagByChip(lChipId, TRANS_J204BC_PAPRO_ALMTYPE, lGetPaAlmFlag);

    if (NULL != pulEventBits)
    {
        *pulEventBits = ulEventStatus;
    }

    dbgInfoEx("%s>>Chip'%d: Alm= Chnl'0x%08X  Mask'0x%08X\n", __FUNCTION__,
              lChipId, ulEventStatus, ulBitsMask);
    return lFunRet;
}

/*****************************************************************************
 * 函数名称: MtsGetPastSerdesAlmStatus(*)
 * 功能描述: 获取Mts历史告警状态
 * 输入参数: lChipId     - MTS chip id
 *           ulBitsMask  - 获取的告警BitsMask, 默认0xFFFFFFFF;
 * 输出参数: pulEventBits - 告警事件MASK值
 * 返 回 值: 0- 正常, 其它值- 异常
 * 其它说明: Serdes告警与TX_ERR进行关联的有SerdesPll失锁
 *           查询告警分类, 该分类下不动作; 无后处理
 *           0x20031910[0]- Serdes Pll Unlock
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10288704@2021-08-26, 创建
 *----------------------------------------------------------------------------
 */
INT32 MtsGetPastSerdesAlmStatus(INT32 lChipId, UINT32 ulBitsMask, UINT32 *pulEventBits)
{
    UINT32 ulEventStatus = 0;
    INT32  lGetPaAlmFlag = 0;
    INT32  lFunRet = 0;

    MTS_CHECK_CHIP(lChipId);
    MTS_CHECK_POINTER(pulEventBits);

    lGetPaAlmFlag = MTS_SerdesRampProtect(lChipId);

    /* MTS子接口获取异常, 按照无告警处理, 父函数返回失败 */
    if (lGetPaAlmFlag < 0)
    {
        lGetPaAlmFlag = 0;
        lFunRet = -1;
        dbgErr("%s>>Chip'%d AlmFlag Get Error!\n", __FUNCTION__, lChipId);
    }
   
    ulEventStatus = lGetPaAlmFlag & ulBitsMask;
    dbgInfoEx("[%s] ulBitsMask:0x%08X lGetPaAlmFlag:%d ulEventStatus:%d\n",__FUNCTION__,ulBitsMask,lGetPaAlmFlag,ulEventStatus);

    BspSetTransPaProAlmFlagByChip(lChipId, TRANS_SERDES_PAPRO_ALMTYPE, lGetPaAlmFlag);

    if (NULL != pulEventBits)
    {
        *pulEventBits = ulEventStatus;
    }
    
    dbgInfoEx("%s>>Chip'%d: Alm= Chnl'0x%08X  Mask'0x%08X\n", __FUNCTION__,
              lChipId, ulEventStatus, ulBitsMask);
    return lFunRet;
}

/*****************************************************************************
 * 函数名称: MtsGetPastOutBufAlmStatus(*)
 * 功能描述: 获取Mts历史告警状态
 * 输入参数: lChipId     - MTS chip id
 *           ulBitsMask  - 获取的告警BitsMask, 默认0xFFFFFFFF;
 * 输出参数: pulEventBits - 告警事件MASK值
 * 返 回 值: 0- 正常, 其它值- 异常
 * 其它说明: TX链路时钟域转换出窗包括: 204xToDlp、DlpToDcp、DcpToDac
 *           单点、均值、宽谱、时域转换超门限告警后会触发MTS内部RAMP关断来保护, 功率异常
 *           时不与Tx_Err管脚关联, 不借外部保护, 单需软件定时查询MTS保护状态来恢复;
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10288704@2021-08-26, 创建
 *----------------------------------------------------------------------------
 */
INT32 MtsGetPastOutBufAlmStatus(INT32 lChipId, UINT32 ulBitsMask, UINT32 *pulEventBits)
{
    UINT32 ulEventStatus = 0;
    INT32  lGetPaAlmFlag = 0;
    INT32  lFunRet = 0;

    MTS_CHECK_CHIP(lChipId);
    MTS_CHECK_POINTER(pulEventBits);

    /* 出窗告警不与Tx_Err管脚关联 */
    lGetPaAlmFlag = MTS_OutBufRampProtect(lChipId);

    /* MTS子接口获取异常, 按照无告警处理, 父函数返回失败 */
    if (lGetPaAlmFlag < 0)
    {
        lGetPaAlmFlag = 0;
        lFunRet = -1;
        dbgErr("%s>>Chip'%d AlmFlag Get Error!\n", __FUNCTION__, lChipId);
    }

    ulEventStatus = lGetPaAlmFlag & ulBitsMask;
    dbgInfoEx("[%s] ulBitsMask:0x%08X lGetPaAlmFlag:%d ulEventStatus:%d\n",__FUNCTION__,ulBitsMask,lGetPaAlmFlag,ulEventStatus);

    BspSetTransPaProAlmFlagByChip(lChipId, TRANS_OUTBUF_PAPRO_ALMTYPE, lGetPaAlmFlag);

    if (NULL != pulEventBits)
    {
        *pulEventBits = ulEventStatus;
    }

    dbgInfoEx("%s>>Chip'%d: Alm= Chnl'0x%08X  Mask'0x%08X\n", __FUNCTION__,
              lChipId, ulEventStatus, ulBitsMask);
    return lFunRet;
}


/*****************************************************************************
 * 函数名称: MtsGetPastPwrErrAlmStatus(*)
 * 功能描述: 获取Mts历史告警状态
 * 输入参数: lChipId     - MTS chip id
 *           ulBitsMask  - 获取的告警BitsMask, 默认0xFFFFFFFF;
 * 输出参数: pulEventBits - 告警事件MASK值
 * 返 回 值: 0- 正常, 其它值- 异常
 * 其它说明: TX链路数据检测异常包括: 单点功率检测, 宽谱功率检测;
 *           单点修改门限接口: MtsCfgSglPwrThresh
 *           宽谱修改门限接口: MtsCfgWbPwrThresh, MTS0.3芯片不支持;
 *           单点、均值、宽谱、时域转换超门限告警后会触发MTS内部RAMP关断来保护, 功率异常
 *           时不与Tx_Err管脚关联, 不借外部保护, 单需软件定时查询MTS保护状态来恢复;
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10288704@2021-08-26, 创建
 *----------------------------------------------------------------------------
 */
INT32 MtsGetPastPwrErrAlmStatus(INT32 lChipId, UINT32 ulBitsMask, UINT32 *pulEventBits)
{
    INT32  lTmpAlmFlag = 0;
    UINT32 ulMtsChnlIdx = 0;
    UINT32 ulMtsErrCnts = 0;
    UINT32 ulGetAlmFlag = 0;
    UINT32 ulChnlBitAlm = 0;
    UINT32 ulEventStatus = 0;
    INT32  lFunRet = 0;

    MTS_CHECK_CHIP(lChipId);
    MTS_CHECK_POINTER(pulEventBits);

    /* 功率异常时不与Tx_Err管脚关联 */
    for (ulMtsChnlIdx = 0; ulMtsChnlIdx < 4; ulMtsChnlIdx++)
    {
        if(BSP_OK != BspPaptIsTransceiverChnlUsed(lChipId, ulMtsChnlIdx))
        {
            continue;
        }
        lTmpAlmFlag = MTS_SglWbRampProtect(lChipId, ulMtsChnlIdx);
        if (lTmpAlmFlag < 0)
        {
            lTmpAlmFlag = 0; /* MTS子接口通道获取异常, 按照无告警处理 */
            ulMtsErrCnts++;
            dbgErr("%s>>Chip'%d MtsChnl'%d AlmFlag Get Error!\n",
                   __FUNCTION__, lChipId, ulMtsChnlIdx);
        }

        /* 有告警且对应的Bit配置有效, 再配置上报APP告警保护标志 */
        ulChnlBitAlm = (!!lTmpAlmFlag);     
        dbgInfoEx("[%s] ulBitsMask:0x%08X lTmpAlmFlag:%d ulChnlBitAlm:%d\n",__FUNCTION__,ulBitsMask,lTmpAlmFlag,ulChnlBitAlm);
        
        BspSetTransPaProAlmFlagByChn(lChipId, ulMtsChnlIdx, TRANS_PWRERR_PAPRO_ALMTYPE, ulChnlBitAlm);

        /* 单片MTS上每个TX通道占8Bits, 不合理的话再优化 */
        ulGetAlmFlag |= lTmpAlmFlag;

    }
    /* MTS子接口芯片上所有通道获取异常, 按照无告警处理, 父函数返回失败 */
    if (ulMtsErrCnts >= 8)
    {
        lFunRet = -1;
        dbgErr("%s>>Chip'%d AlmFlag Get Error!\n", __FUNCTION__, lChipId);
    }

    ulEventStatus = ulGetAlmFlag & ulBitsMask;
    if (NULL != pulEventBits)
    {
        *pulEventBits = ulEventStatus;
    }

    dbgInfoEx("%s>>Chip'%d: Alm= Chnl'0x%08X  Mask'0x%08X\n", __FUNCTION__,
              lChipId, ulEventStatus, ulBitsMask);
    return lFunRet;
}

/* ---------------------------------------------------------------------------- */
/* -------------------------------- 告警后处理 -------------------------------- */
/* ---------------------------------------------------------------------------- */

/*****************************************************************************
 * 函数名称: MtsMcuPllAlmRecover(*)
 * 功能描述: McuPllAlm异常后处理
 * 输入参数: lChipId       - MTS chip id
 *           ulAlmBitsMask - 告警事件MASK值
 * 输出参数: 无
 * 返 回 值: 0- 正常或无后处理操作正常, 负值- 后处理操作异常, 正值- 表示有后处理操作
 * 其它说明: 连续ulAlmBitsMask有3次告警, 才允许后处理
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10119095@2020-07-08, 创建
 *----------------------------------------------------------------------------
 */
INT32 MtsMcuPllAlmRecover(INT32 lChipId, UINT64 u64AlmBitsMask)
{
    /*
        MTS内部自动关数据，并送给DPDIC告警信号，DPDIC关PA。
        本告警无恢复处理，高层检测三次异常后触发立即复位或凌晨复位, 
    */
    return 0;
}

/*****************************************************************************
 * 函数名称: MtsJ204bcAlmRecover(*)
 * 功能描述: J204bc异常后处理
 * 输入参数: lChipId       - MTS chip id
 *           ulAlmBitsMask - 告警事件MASK值
 * 输出参数: 无
 * 返 回 值: 0- 正常或无后处理操作正常, 负值- 后处理操作异常, 正值- 表示有后处理操作
 * 其它说明: 连续ulAlmBitsMask有3次告警, 才允许后处理
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10119095@2020-07-08, 创建
 *----------------------------------------------------------------------------
 */
INT32 MtsJ204bcAlmRecover(INT32 lChipId, UINT64 u64AlmBitsMask)
{
    INT32 lRetVal = 0;

    if (0 == u64AlmBitsMask)
    {
        dbgInfoEx("%s>>Chip'%d AlmMask'0x%llX: return!\n",
                  __FUNCTION__, lChipId, u64AlmBitsMask);
        return 0; // 表示无后处理操作
    }
    
    lRetVal = BspPaptJ204LinkRebuildWithRetry(lChipId);
    return lRetVal;
}

/*****************************************************************************
 * 函数名称: MtsSerdesAlmRecover(*)
 * 功能描述: serdes异常后处理
 * 输入参数: lChipId       - MTS chip id
 *           ulAlmBitsMask - 告警事件MASK值
 * 输出参数: 无
 * 返 回 值: 0- 正常或无后处理操作正常, 负值- 后处理操作异常, 正值- 表示有后处理操作
 * 其它说明: 连续ulAlmBitsMask有3次告警, 才允许后处理
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10119095@2020-07-08, 创建
 *----------------------------------------------------------------------------
 */
INT32 MtsSerdesAlmRecover(INT32 lChipId, UINT64 u64AlmBitsMask)
{
    /*
        MTS内部自动关数据，并送给DPDIC告警信号，DPDIC关PA。
        本告警无恢复处理，高层检测三次异常后触发立即复位或凌晨复位, 
    */
    return 0;
}

/*****************************************************************************
 * 函数名称: MtsOutBufAlmRecover(*)
 * 功能描述: 出窗告警异常后处理
 * 输入参数: lChipId       - MTS chip id
 *           ulAlmBitsMask - 告警事件MASK值
 * 输出参数: 无
 * 返 回 值: 0- 正常或无后处理操作正常, 负值- 后处理操作异常, 正值- 表示有后处理操作
 * 其它说明: 连续ulAlmBitsMask有3次告警, 才允许后处理
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10119095@2020-07-08, 创建
 *----------------------------------------------------------------------------
 */
INT32 MtsOutBufAlmRecover(INT32 lChipId, UINT64 u64AlmBitsMask)
{
    /*
        MTS内部自动关数据，不会送给DPDIC告警信号，无法关PA(todo                     和万亮亮确认中)。
        本告警无恢复处理，高层检测三次异常后触发立即复位或凌晨复位, 
    */
    return 0;
}

/*****************************************************************************
 * 函数名称: MtsPwrErrAlmRecover(*)
 * 功能描述: 链路功率异常后处理
 * 输入参数: lChipId       - MTS chip id
 *           ulAlmBitsMask - 告警事件MASK值
 * 输出参数: 无
 * 返 回 值: 0- 正常或无后处理操作正常, 负值- 后处理操作异常, 正值- 表示有后处理操作
 * 其它说明: 连续ulAlmBitsMask有3次告警, 才允许后处理
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10119095@2020-07-08, 创建
 *----------------------------------------------------------------------------
 */
INT32 MtsPwrErrAlmRecover(INT32 lChipId, UINT64 u64AlmBitsMask)
{
    /*
        MTS内部自动关数据，不会送给DPDIC告警信号，无法关PA(todo                     和万亮亮确认中)。
        本告警无恢复处理，高层检测三次异常后触发立即复位或凌晨复位, 
    */
    return 0;
}

/*****************************************************************************
 * 函数名称: MtsArmErrAlmRecover(*)
 * 功能描述: ARM告警异常后处理
 * 输入参数: lChipId       - MTS chip id
 *           ulAlmBitsMask - 告警事件MASK值
 * 输出参数: 无
 * 返 回 值: 0- 正常或无后处理操作正常, 负值- 后处理操作异常, 正值- 表示有后处理操作
 * 其它说明: 连续ulAlmBitsMask有3次告警, 才允许后处理
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10119095@2020-07-08, 创建
 *----------------------------------------------------------------------------
 */
INT32 MtsArmErrAlmRecover(INT32 lChipId, UINT64 u64AlmBitsMask)
{
    /*
        MTS内部自动关数据，并送给DPDIC告警信号，DPDIC关PA。
        本告警无恢复处理，高层检测三次异常后触发立即复位或凌晨复位, 
    */
    return 0;
}

/*****************************************************************************
 * 函数名称: MtsJ204Rebuild(*)
 * 功能描述: mts j204重新建链
 * 输入参数: lChipId       - MTS chip id
 *           ulAlmBitsMask - 告警事件MASK值
 * 输出参数: 无
 * 返 回 值: 0- 正常或无后处理操作正常, 负值- 后处理操作异常, 正值- 表示有后处理操作
 * 其它说明: 连续ulAlmBitsMask有3次告警, 才允许后处理
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10119095@2020-07-08, 创建
 *----------------------------------------------------------------------------
 */
INT32 MtsJ204Rebuild(UINT32 lChipId)
{
    dbgInfoEx("%s lChipId=%d\n", __func__, lChipId);
    return MTS_RestRlsrest204Serdes(lChipId);    
}

/* ---------------------------------------------------------------------------- */
/* ---------------------------------- 对外接口 -------------------------------- */
/* ---------------------------------------------------------------------------- */
/*****************************************************************************
 * 函数名称: MtsGetPastPaProAlm(*)
 * 功能描述: Mts功放保护告警检测
 * 输入参数: lChipId       - MTS chip id
 *           ulAlmType - 告警类型
 *           pu64EventBits - 告警掩码
 * 输出参数: 无
 * 返 回 值: BSP_OK- 成功; 负值- 失败
 * 其它说明: 连续pu64EventBits有3次告警, 才允许后处理
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10119095@2020-07-08, 创建
 *----------------------------------------------------------------------------
 */
INT32 MtsGetPastPaProAlm(UINT32 chipId, E_TRANS_PAPRO_ALM_TYPE ulAlmType, UINT64 *pu64EventBits)
{
    INT32 lChipId = (INT32)chipId;
    INT32 lRetVal = 0;
    UINT32 ulMtsAlmBits = 0;
    UINT32 ulLastMtsAlmBits = 0;

    /* 分类检测告警 */
    switch (ulAlmType)
    {
    case TRANS_MCU_PLL_PAPRO_ALMTYPE:
        lRetVal = MtsGetPastMcuPllAlmStatus(lChipId, 0xFFFFFFFF, &ulMtsAlmBits);
        break;
    case TRANS_J204BC_PAPRO_ALMTYPE:
        lRetVal = MtsGetPastJ204bcAlmStatus(lChipId, 0xFFFFFFFF, &ulMtsAlmBits);
        break;
    case TRANS_SERDES_PAPRO_ALMTYPE:
        lRetVal = MtsGetPastSerdesAlmStatus(lChipId, 0xFFFFFFFF, &ulMtsAlmBits);
        break;
    case TRANS_OUTBUF_PAPRO_ALMTYPE:
        lRetVal = MtsGetPastOutBufAlmStatus(lChipId, 0xFFFFFFFF, &ulMtsAlmBits);
        break;
    case TRANS_PWRERR_PAPRO_ALMTYPE:
        lRetVal = MtsGetPastPwrErrAlmStatus(lChipId, 0xFFFFFFFF, &ulMtsAlmBits);
        break;
    default:
        lRetVal = PAPT_NOT_SUPPORT_ALM;
        break;
    }

    if(ulLastMtsAlmBits != ulMtsAlmBits)
    {
        ulLastMtsAlmBits = ulMtsAlmBits;
        BspLog(LOG_LEVEL_0,"papt: %s: ePaProType[%d], ulMtsAlmBits[%d], ulLastEventBits[%d]\n",__FUNCTION__,ulAlmType, ulMtsAlmBits, ulLastMtsAlmBits);
    }

    if (NULL != pu64EventBits)
    {
        *pu64EventBits = (UINT64)ulMtsAlmBits;
    }

    return lRetVal;
}

/*****************************************************************************
 * 函数名称: MtsClrPastPaProAlm(*)
 * 功能描述: Mts功放保护告警清除
 * 输入参数: lChipId       - MTS chip id
 *           ulAlmType - 告警类型
 * 输出参数: 无
 * 返 回 值: BSP_OK- 成功; 负值- 失败
 * 其它说明: 
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10119095@2020-07-08, 创建
 *----------------------------------------------------------------------------
 */
INT32 MtsClrPastPaProAlm(UINT32 chipId, E_TRANS_PAPRO_ALM_TYPE ulAlmType)
{
    INT32 lRetVal = 0;    
    /* 
        MTS告警为读清模式，不需要单独的清告警动作 
    */
    return lRetVal;
}

/*****************************************************************************
 * 函数名称: MtsPaProAlmRecover(*)
 * 功能描述: Mts功放保护告警后处理
 * 输入参数: lChipId       - MTS chip id
 *           ulAlmType - 告警类型
 *           u64AlmBitsMask - 告警掩码
 * 输出参数: 无
 * 返 回 值: 0- 正常或无后处理操作正常, 负值- 后处理操作异常, 正值- 表示有后处理操作
 * 其它说明: 连续pu64EventBits有3次告警, 才允许后处理
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10119095@2020-07-08, 创建
 *----------------------------------------------------------------------------
 */
INT32 MtsPaProAlmRecover(UINT32 chipId, E_TRANS_PAPRO_ALM_TYPE ulAlmType, UINT64 u64AlmBitsMask)
{
    INT32 lChipId = (INT32)chipId;
    INT32 lTmpRet = 0;
    INT32 lRetVal = 0;
    UINT64 u64EventAlm = 0;

    switch (ulAlmType)
    {
    case TRANS_MCU_PLL_PAPRO_ALMTYPE:
        lRetVal = MtsMcuPllAlmRecover(lChipId, u64AlmBitsMask);
        break;
    case TRANS_J204BC_PAPRO_ALMTYPE:
        lRetVal = MtsJ204bcAlmRecover(lChipId, u64AlmBitsMask);
        break;
    case TRANS_SERDES_PAPRO_ALMTYPE:
        lRetVal = MtsSerdesAlmRecover(lChipId, u64AlmBitsMask);
        break;
    case TRANS_OUTBUF_PAPRO_ALMTYPE:
        lRetVal = MtsOutBufAlmRecover(lChipId, u64AlmBitsMask);
        break;
    case TRANS_PWRERR_PAPRO_ALMTYPE:
        lRetVal = MtsPwrErrAlmRecover(lChipId, u64AlmBitsMask);
        break;
    case TRANS_OTHERS_PAPRO_ALMTYPE:
        lRetVal = MtsArmErrAlmRecover(lChipId, u64AlmBitsMask);
        break;   
    default: // E_PA_PRO_TYPE_INVALID_DEFINE
        lRetVal = PAPT_NOT_SUPPORT_ALM;
        break;
    }

    if ((UINT64)0 != u64AlmBitsMask)
    {
        /* MTS告警清除就是获取一次告警状态 */
        lTmpRet = MtsGetPastPaProAlm(chipId, ulAlmType, &u64EventAlm);
        dbgInfoEx("%s>>PaProType'%d Ret'%d: AlmStatus= 0x%llX\n",
                  __FUNCTION__, ulAlmType, lTmpRet, u64EventAlm);
    }

    return lRetVal;
}

/*****************************************************************************
 * 函数名称: MtsClrAlmAfterInit(*)
 * 功能描述: 清除trancsceiver上所有告警
 * 输入参数: lChipId       - MTS chip id
 * 输出参数: 无
 * 返 回 值: 0- 正常或无后处理操作正常, 负值- 后处理操作异常, 正值- 表示有后处理操作
 * 其它说明: 初始化完成后，清除trancsceiver上所有告警
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10119095@2020-07-08, 创建
 *----------------------------------------------------------------------------
 */
INT32 MtsClrAlmAfterInit(UINT32 chipId)
{
    INT32 lRetVal = 0;  

    /* mts10无清告警动作，待和万亮亮确认 */
    return lRetVal;
}

/*****************************************************************************
 * 函数名称: MtsClrAlmAfterInit(*)
 * 功能描述: 清除trancsceiver上所有告警
 * 输入参数: lChipId       - MTS chip id
 * 输出参数: 无
 * 返 回 值: 0- 正常或无后处理操作正常, 负值- 后处理操作异常, 正值- 表示有后处理操作
 * 其它说明: 初始化完成后，清除trancsceiver上所有告警
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10119095@2020-07-08, 创建
 *----------------------------------------------------------------------------
 */
INT32 MtsIcLaneAlmRecover(E_PaProType ePaProType, UINT64 u64AlmBitsMask)
{
    INT32 lRetVal = 0;
  
    if(E_PA_PRO_TYPE_IC_LANE_STATUS == ePaProType)
    {
        /*
            暂时按照对整片IC和全部Transceiver全部重新建链来实现，
            后续可以利用以下结构体中的信息：
                T_J204OnePairEnds -> dpdicLaneMask 和 transIdMask
            根据u64AlmBitsMask和dpdicLaneMask对比，
            判断DPDIC的哪个Grp及哪些片Transceiver需要重新建链
        */
        lRetVal = MtsJ204bcAlmRecover(PAPT_TRANS_FULL_MASK, u64AlmBitsMask); // 255表示所有MTS芯片
    }
    else 
    {
        lRetVal = PAPT_NOT_SUPPORT_ALM;
    }

    return lRetVal;
}
/**************************************************************************
*                                  维测接口
**************************************************************************/
VOID exprnaddmtspapt(VOID)
{
    exprnadd("MtsJ204bcAlmRecover");
    exprnadd("MtsGetPastMcuPllAlmStatus");
    exprnadd("MtsGetPastJ204bcAlmStatus");
    exprnadd("MtsGetPastSerdesAlmStatus");
    exprnadd("MtsGetPastOutBufAlmStatus");
    exprnadd("MtsGetPastPwrErrAlmStatus");
    exprnadd("MtsJ204bcAlmRecover");
    exprnadd("MtsJ204Rebuild");
    return;
}

INT32 DbgMtsJ204bcAlmRecover(UINT32 chip)
{
    return MtsJ204bcAlmRecover(chip, 0xff);
}

/**************************************************************************
                             回调挂接
 **************************************************************************/
static __attribute((constructor)) void SetMtsPaptFunc() 
{
    (VOID)BspSetTransGetPaProAlmFunc(DEVICE_MTS,MtsGetPastPaProAlm);
    (VOID)BspSetTransClrPaProAlmFunc(DEVICE_MTS,MtsClrPastPaProAlm);
    (VOID)BspSetTransPaProAlmRecoverFunc(DEVICE_MTS,MtsPaProAlmRecover);
    (VOID)BspSetTransClrAlmAfterInitFunc(DEVICE_MTS,MtsClrAlmAfterInit);
    (VOID)BspSetTransJ204RebuildFunc(DEVICE_MTS,MtsJ204Rebuild);
    (VOID)BspSetPaProAlmRecoverFunc(E_PA_PRO_TYPE_IC_LANE_STATUS, MtsIcLaneAlmRecover);
}



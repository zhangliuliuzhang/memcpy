
/*****************************************************************************
* 版权所有(C) 2023, ZTE Corp. ZXSDR-RRU Platform BSP
*----------------------------------------------------------------------------
* 模 块 名 : BSP
* 文件名称 : adi_init.c
* 文件标识 : {[N/A]}
* 内容摘要 : 本文件提供了ADI的攻防保护接口
* 注意事项 : 无
* 作    者 : 332561
* 创建日期 : 2023-8-2 14:45:34
* 当前版本 : Ver1.0
*----------------------------------------------------------------------------*/

#include "devdrv_transceiver.h"
#include "ad903x.h"
#include "boardinit.h"
#include "papt_common.h" 
#include "adi_adrv903x_gpio_types.h"
#include "chnmapcommon.h"
// #include "digtrxlinkwrapper.h"
#include "exprn.h"
#include "j204_ic4_2.h"
#include "bsppub.h"
#include "papt_private.h"
#include "funccommon_log.h"

#define AD903X_J204C_TX_LINK_OK  0x00003
#define AD903X_REC_ALM_EVENT_MAX_SUM       ((UINT32)TRANS_PAPRO_ALM_TYPE_MAX)
typedef struct _T_AD903X_PAPT_RECORD
{
    // mcpClkAlm  j204bcAlm  serdesAlm  outbufAlm  pwrErrAlm armErrAlm
    UINT64 au64RecPaAlm[AD903X_REC_ALM_EVENT_MAX_SUM];
    UINT64 au32AlmEvent[AD903X_REC_ALM_EVENT_MAX_SUM];
}T_AD903X_PAPT_RECORD;

static UINT32 s_ulAd903xJ204cRecoverFlag = 0;
static UINT32 s_aulAd903xJ204cRecoverEvent[AD903X_DEV_NUM] = {0, };
static UINT32 s_aulTestSetPaProAlmFlag[AD903X_DEV_NUM] = {0,0,0,0,0,0,0,0}; // 模拟告警
//static T_AD903X_PAPT_RECORD s_atAd903xPaptRecordEvent[AD903X_DEV_NUM] = {{{0, 0, }}, {{0, 0, }}};

#define AD903X_FUNC_RETURN_CHK(FunRet)                   \
{                                                        \
    if (BSP_OK != (FunRet))                              \
    {                                                    \
        dbgInfoEx("%s>>Func Call Error! Ret= 0x%04X\n",  \
                  __FUNCTION__, (FunRet));               \
    }                                                    \
} 

#define AD903X_SERDES_REINIT_ERROR_REPORT(funcRet, retVal, funcinfo)  \
{                                                                     \
    if (BSP_OK != (funcRet))                                          \
    {                                                                 \
        (retVal) = -1;                                                \
        dbgErr("%s>> %s Return Error!\n", __FUNCTION__, (funcinfo));  \
    }                                                                 \
}

static UINT32 GetTransceiverChipNum()
{
    TRruDeviceDescription *pDev = NULL;
    UINT32 loop;
    static UINT32 trsvChipNum = 0;

    if (trsvChipNum != 0)
    {
    	return trsvChipNum;
    }
    for (loop = 0; loop < BspGetTxBspChanNum(); loop++)
    {
        if (0 == BspChipInfoPtrGetByRfPathDef(loop,TX,DEVICE_TYPE_TRANSCEIVER,&pDev))
        {
            if (pDev->ulDeviceCfg != INVALID_VALUE)
            {
                trsvChipNum++;
            }
        }
    }
    return trsvChipNum;
}

/******************************************************************************
 *                                                                            *
 *                            功放保护相关接口实现                            *
 *                                                                            *
 ******************************************************************************/
/* ///////////////////////////////////// note /////////////////////////////////////////////////////////////
(1)请参考A9631a_s的fpgafunc.c中的以下函数进行实现
    Ad9025GetPastPaProAlm
    Ad9025ClrPastPaProAlm
    Ad9025PaProAlmRecover

(2)使用BspSetTransPaProAlmFlagByChip替换以下操作
   s_ulMtsMcuPllPaProAlmFlag = BIT_FIELD_MASK_CFG(s_ulMtsMcuPllPaProAlmFlag, ulSetBitsAlm, lChipId * 4, 4);

(3)使用BspSetTransPaProAlmFlagByChn替换以下操作
   s_ulMtsPwrErrPaProAlmFlag = BIT_FIELD_MASK_CFG(s_ulMtsPwrErrPaProAlmFlag, ulSetBitsAlm, ulBitsOffset, 1);

另外，64bit状态标志中使用4*8个bit保存告警，4代表4片Transceiver，8代表Transceiver的8个通道
///////////////////////////////////////////////////////////////////////////////////////////////////////// */

/*  =======================================================================================================
    Ad903xSetPaProAlmFlag 模拟告警调试命令, 配置代码参考:
    ulType : 0x01-McuClk, 0x02-J204BC & Serdes, 0x04-PwrErr, 0x08-ArmErr, 0xFF-All
    ulIndex: Ad903x芯片索引,  ulAlmStatus: 模拟告警码
    ///////////////////////// McuClk 模拟告警, 用于打桩测试 ///////////////////////////////////
    UINT32 ulTestIdx    = 0;
    UINT32 ulTestFlg    = 0;

    ulTestIdx = ulChipId % AD903X_DEV_NUM;
    ulTestFlg = (s_aulTestSetPaProAlmFlag[ulTestIdx] >> 16) & 0xFFFF;
    if (0 != (ulTestFlg & BSP_BIT_SET(0)))
    {
        ulTmpRet = BSP_OK;
        tAdiGpIntMask.upperMask |= ((UINT64)(s_aulTestSetPaProAlmFlag[ulTestIdx] & 0xFFFF)) << 26;
        dbgInfo("%s>>ChipId'0x%d TestFlag'0x%04X ClkAlm: DbgPaProAlm= 0x%04X\n", __FUNCTION__,
                 ulTestIdx, ulTestFlg, s_aulTestSetPaProAlmFlag[ulTestIdx] & 0xFFFF);
    }
    ///////////////////////////////////////////////////////////////////////////////////////////
    ////////////////////////////// Serdes J204C 模拟告警, 用于打桩测试 ////////////////////////
    UINT32 ulTestIdx  = 0;
    UINT32 ulTestFlg  = 0;
    
    ulTestIdx = ulChipId % AD903X_DEV_NUM;
    ulTestFlg = (s_aulTestSetPaProAlmFlag[ulTestIdx] >> 16) & 0xFFFF;
    if (0 != (ulTestFlg & BSP_BIT_SET(1)))
    {
        tDeframerStatus0.linkState = (s_aulTestSetPaProAlmFlag[ulTestIdx] >> 0) & 0x00FF;
    //  tDeframerStatus1.linkState = (s_aulTestSetPaProAlmFlag[ulTestIdx] >> 8) & 0x00FF;
        dbgInfo("%s>>ChipId'0x%d TestFlag'0x%04X Serdes: DbgPaProAlm= 0x%04X\n", __FUNCTION__,
                ulTestIdx, ulTestFlg, s_aulTestSetPaProAlmFlag[ulTestIdx] & 0xFFFF);
    }
    ///////////////////////////////////////////////////////////////////////////////////////////
    ////////////////////////////// PwrErr 模拟告警, 用于打桩测试 //////////////////////////////
    UINT32 ulTestIdx    = 0;
    UINT32 ulTestFlg    = 0;
    
    ulTestIdx = ulChipId % AD903X_DEV_NUM;
    ulTestFlg = (s_aulTestSetPaProAlmFlag[ulTestIdx] >> 16) & 0xFFFF;
    if (0 != (ulTestFlg & BSP_BIT_SET(2)))
    {
        u64PwrAlmFlg = s_aulTestSetPaProAlmFlag[ulTestIdx] & 0xFFFF;
        dbgInfo("%s>>ChipId'0x%d TestFlag'0x%04X PwrChk: DbgPaProAlm= 0x%04X\n", __FUNCTION__,
                 ulTestIdx, ulTestFlg, s_aulTestSetPaProAlmFlag[ulTestIdx] & 0xFFFF);
    }
    ///////////////////////////////////////////////////////////////////////////////////////////
    ////////////////////////////// ArmErr 模拟告警, 用于打桩测试 //////////////////////////////
    UINT32 ulTestIdx    = 0;
    UINT32 ulTestFlg    = 0;
    
    ulTestIdx = ulChipId % AD903X_DEV_NUM;
    ulTestFlg = (s_aulTestSetPaProAlmFlag[ulTestIdx] >> 16) & 0xFFFF;
    if (0 != (ulTestFlg & BSP_BIT_SET(3)))
    {
        u64AlmErrFlg = s_aulTestSetPaProAlmFlag[ulTestIdx] & 0x00FF;
        u64StreamFlg = s_aulTestSetPaProAlmFlag[ulTestIdx] & 0xFF00;
        dbgInfo("%s>>ChipId'0x%d TestFlag'0x%04X ArmErr: DbgPaProAlm= 0x%04X\n", __FUNCTION__,
                 ulTestIdx, ulTestFlg, s_aulTestSetPaProAlmFlag[ulTestIdx] & 0xFFFF);
    }
    /////////////////////////////////////////////////////////////////////////////////////////// 
    ===========================================================================================  */
UINT32 Ad903xSetPaProAlmFlag(UINT32 ulType, UINT32 ulIndex, UINT32 ulAlmStatus)
{
    if (ulIndex >= AD903X_DEV_NUM)
    {
        dbgErr("%s>>Error!Param Over; ChipId(0~%d)= %d\n", __FUNCTION__,
               AD903X_DEV_NUM - 1, ulIndex);
        return BSP_ERROR;
    }

    if (0 == ulAlmStatus)
    {
        s_aulTestSetPaProAlmFlag[ulIndex] = 0;
    }
    else
    {
        s_aulTestSetPaProAlmFlag[ulIndex]  = ulType << 16;
        s_aulTestSetPaProAlmFlag[ulIndex] |= ulAlmStatus & 0xFFFF;
    }
    
    dbgInfo("%s>>Chip'%d: DbgAlmStatus= 0x%08X\n", __FUNCTION__, ulIndex, ulAlmStatus);
    return BSP_OK;
}

/* 时钟状态     ：BspTestAd903xPllStatusGet ChipIndex
   正常返回值0x0B: bit0= CLKPLL LockStatus; bit1= RF0PLL LockStatus ; bit2= RF1PLL LockStatus; bit3= SerdesPLL LockStatus  
   本振失锁     : BspTestAd903xRegWrite ChipIndex,0x47300004,0x5c,0xffffffff
                  GpintStatus=0x1b....
   恢复正常     : BspTestAd903xLoFrequencySet 0,0,0x9ab5b680,0,0
   CLKPLL失锁   : BspTestAd903xRegWrite ChipIndex,0x48090004,0xff,0xffffffff
                  GpintStatus=0xd8....
   恢复正常     : BspTestAd903xRegWrite ChipIndex,0x48090004,0x40,0xffffffff
   SerdesPLL失锁: BspTestAd903xRegWrite ChipIndex,0x48060004,0xff,0xffffffff
                  GpintStatus=0x94....以及loss sync header告警
   恢复正常     : BspTestAd903xRegWrite ChipIndex,0x48060004,0x42,0xffffffff  */
// ulAlmClrFlag: 0- 只获取告警不允许清除不配置功放保护标志, 1- 获取告警后清除, 配置功放保护标志
static INT32 BspGetAd903xMcuClkAlm(UINT32 ulAlmClrFlag, UINT32 ulChipId, UINT64 *pu64EventBits)
{
    INT32  lRetVal      = 0;
    UINT32 ulChipSum    = 0;
    UINT64 u64PastClkSta = 0;
    UINT64 u64PastRf0Sta = 0;
    UINT64 u64PastRf1Sta = 0;
    UINT64 u64PastSerdes = 0;
    UINT32 u64PllAlmMask = 0;
    UINT32 ulCurrPllSta  = 0;
    UINT32 ulPllsAlmClr  = 0;
    UINT32 ulSetBitsAlm  = 0;
    UINT32 ulTrsvAlmFlg  = 0;
    UINT32 ulTmpRet      = BSP_OK;
    adi_adrv_GpIntMask_t tAdiGpIntMask = {0, };

    if ((UINT64 *)NULL == pu64EventBits)
    {
        dbgErr("%s>>Param Error! pEventBits NULL;\n", __FUNCTION__);
        return (INT32)-1; //索引超出范围,不应上报告警
    }

    ulChipSum = GetTransceiverChipNum();
    if (ulChipId >= ulChipSum)
    {
        *pu64EventBits = 0;
        dbgErr("%s>>Error!Param Over; ChipId(0~%d)= %d\n",
               __FUNCTION__, ulChipSum - 1, ulChipId);
        return (INT32)BSP_OK; // 索引超出范围,不应上报告警
    }

    // 1) 软件查询历史告警: BspTestAd903xGpIntStatusGet--> BspAd903xGpIntStatusGet
    ulTmpRet = BspAd903xGpIntStatusGet(ulChipId, &tAdiGpIntMask);
    /*           历史告警             -->     实时告警
       Clock  PLL Unlock: UpperBit[30]--> CLK    PLL 状态:  Bit0
       RF0    PLL Unlock: UpperBit[32]--> RF0    PLL 状态:  Bit1
       RF1    PLL Unlock: UpperBit[31]--> RF1    PLL 状态:  Bit2  -- 未使用, 不做对比
       SERDES PLL Unlock: UpperBit[26]--> SERDES PLL 状态:  Bit3
       CurrAlm[3~0]: SerdesPll、Rf1Pll、Rf0Pll、ClkPll; 正常值为0x0B, 对应Bit值1表示正常; */
    if (BSP_OK == ulTmpRet)
    {
        u64PastClkSta = (tAdiGpIntMask.upperMask >> 30) & 0x01;
        u64PastRf0Sta = (tAdiGpIntMask.upperMask >> 32) & 0x01;
    //  u64PastRf1Sta = (tAdiGpIntMask.upperMask >> 31) & 0x01;
        u64PastSerdes = (tAdiGpIntMask.upperMask >> 26) & 0x01;
    }
    else
    {
        lRetVal += (INT32)-1;
    }

    u64PllAlmMask |= u64PastClkSta << 0;
    u64PllAlmMask |= u64PastRf0Sta << 1;
    u64PllAlmMask |= u64PastRf1Sta << 2;
    u64PllAlmMask |= u64PastSerdes << 3;
    *pu64EventBits = u64PllAlmMask;

    if (ulAlmClrFlag > 0)
    {
        // 2) 查看实时告警, 若实时告警状态正常(已恢复), 则清除历史告警, 软件记录+1
        //    查看实时告警, 若实时告警状态异常(未恢复), 不清除历史告警, 软件记录
        // BspTestAd903xPllStatusGet--> BspAd903xGetPllStatus
        ulTmpRet = BspAd903xGetPllStatus(ulChipId, &ulCurrPllSta);
        if (BSP_OK == ulTmpRet)
        {
            // CurrPllSta[3~0]: SerdesPll、Rf1Pll、Rf0Pll、ClkPll; 对应Bit值为1 表示正常;
            // 实时告警正常值为0x0B; 历史和实时告警与操作后对应Bit为 1 允许告警清除; 否则不清除告警;
            ulPllsAlmClr = ulCurrPllSta & u64PllAlmMask;
            if ((UINT32)0 != ulPllsAlmClr)
            {
                // BspTestAd903xGpIntStatusClear 1,0xFFFFFFFF,0xFFFF,0xFFFFFFFF,0xFFFF
                // BspTestAd903xGpIntStatusClear--> BspAd903xGpIntStatusClear
                tAdiGpIntMask.lowerMask  = ((UINT64)0x00000000);
                // tAdiGpIntMask.upperMask  = ((UINT64)0x00000051) << 26;
                tAdiGpIntMask.upperMask  = ((UINT64)((ulPllsAlmClr >> 0) & 0x01)) << 30; // ClkPllUnlock
                tAdiGpIntMask.upperMask |= ((UINT64)((ulPllsAlmClr >> 1) & 0x01)) << 32; // Rf0PllUnlock
                tAdiGpIntMask.upperMask |= ((UINT64)((ulPllsAlmClr >> 2) & 0x01)) << 31; // Rf1PllUnlock
                tAdiGpIntMask.upperMask |= ((UINT64)((ulPllsAlmClr >> 3) & 0x01)) << 26; // SerdesPllSta
                ulTmpRet = BspAd903xGpIntStatusClear(ulChipId, &tAdiGpIntMask);
                ulTmpRet = BspAd903xGpIntStatusClear(ulChipId, &tAdiGpIntMask);
                AD903X_FUNC_RETURN_CHK(ulTmpRet);
            }
        }
        else
        {
            lRetVal += (INT32)-1;
        }
    
        ulTrsvAlmFlg = TRANS_MCU_PLL_PAPRO_ALMTYPE;
        ulSetBitsAlm = ((UINT64)0 != *pu64EventBits) ? 0xFF : 0x00;
        BspSetTransPaProAlmFlagByChip(ulChipId, ulTrsvAlmFlg, ulSetBitsAlm);
    }

    dbgInfoEx("%s>>Ad903x'%d ClrFlag'%d: ClrBits= 0x%04X, CurrAlm= 0x%04X; AlmStatus= 0x%llX\n",
              __FUNCTION__, ulChipId, ulAlmClrFlag, ulPllsAlmClr, ulCurrPllSta, *pu64EventBits);
    return lRetVal;
}

// ulAlmClrFlag: 0- 只获取告警不允许清除不配置功放保护标志, 1- 获取告警后清除, 配置功放保护标志
// TxSerdes 获取的是实时告警, 无需清除, ulAlmClrFlag 参数暂无用
static INT32 Ad903xGetTxSerdesAlm(UINT32 ulAlmClrFlag, UINT32 ulChipId, UINT64 *pu64EventBits)
{
    INT32  lRetVal    = 0;
    UINT32 ulChipSum  = 0;
//  UINT32 ulLoopCnt  = 0;
//  UINT32 ulLaneIdx  = 0;
//  UINT32 ulLaneAddr = 0;
//  UINT32 ulLaneSta  = 0;
    UINT32 ulTmpRet   = BSP_OK;
    UINT64 u64J204cLinkSta = 0;
//  UINT64 u64TxLaneStatus = 0;
    adi_adrv_DeframerStatus_v2_t tDeframerStatus0 = {0,};
//  adi_adrv_DeframerStatus_v2_t tDeframerStatus1 = {0,};

    if ((UINT64 *)NULL == pu64EventBits)
    {
        dbgErr("%s>>Param Error! pEventBits NULL;\n", __FUNCTION__);
        return (INT32)-1;
    }

    ulChipSum = GetTransceiverChipNum();
    if (ulChipId >= ulChipSum)
    {
        *pu64EventBits = 0;
        dbgErr("%s>>Error!Param Over; ChipId(0~%d)= %d\n",
               __FUNCTION__, ulChipSum - 1, ulChipId);
        return (INT32)BSP_OK; // 索引超出范围,不应上报告警
    }

    // BspTestAd903xDeframerStatusGet_v2 chipIndex, 0x01 -->BspAd903xDeframerStatusGet_v2
    // 通过建链状态寄存器获取; 查看实时寄存器状态3次, 如果出现异常, 触发建链流程(APP负责???)
    // A9651A只使用DEFRAMER_0, 所以状态只查询DEFRAMER_0; 回读值只关注LinkState是否为0x03, 
    // LinkState==0x03表示所有使用的Lane均建链正常, laneStatus[]和Ad903x寄存器0x48000539不再关注;
    ulTmpRet  = BspAd903xDeframerStatusGet_v2(ulChipId, ADI_ADRV903X_DEFRAMER_0, &tDeframerStatus0);
//  ulTmpRet |= BspAd903xDeframerStatusGet_v2(ulChipId, ADI_ADRV903X_DEFRAMER_1, &tDeframerStatus1);
    if (BSP_OK == ulTmpRet)
    {
        if ((uint8_t)AD903X_J204C_TX_LINK_OK != tDeframerStatus0.linkState) 
        {
            u64J204cLinkSta |= (UINT64)0x01 << 0;
        }

    //  if ((uint8_t)AD903X_J204C_TX_LINK_OK != tDeframerStatus1.linkState)
    //  {
    //      u64J204cLinkSta |= (UINT64)0x01 << 4;
    //  }
    }
    else
    {
        lRetVal = (INT32)-1;
    }
    *pu64EventBits = u64J204cLinkSta;

#if (0)
    // ====== TxJ204cStatus: 不关心Lane和Tx通道的对应关系 ======
    ulLaneAddr = 0x48000539; // 只读取Lane: 0x48000539 ~ 0x48000545
    // 0x48000529 0x052D 0x0531 0x0535, 0x48000539 0x053D 0x0541 0x0545
    // 检测建链状态Lane0~7, 返回值为0xC0且不跳动, 说明下行建链稳定
    for (ulLoopCnt = 0; ulLoopCnt < 3; ulLoopCnt++)
    {
        for (ulLaneIdx = 0; ulLaneIdx < 4; ulLaneIdx++)
        {
            // LinkState= 0x08表示Lane建立稳定
            if ((uint8_t)0x08 != tDeframerStatus0.laneStatus[ulLaneIdx])
            {
                u64TxLaneStatus |= (UINT64)0x01 << (8 + ulLaneIdx);
            }
            if ((uint8_t)0x08 != tDeframerStatus1.laneStatus[ulLaneIdx])
            {
                u64TxLaneStatus |= (UINT64)0x01 << (16 + ulLaneIdx);
            }

            // BspTestAd903xRegRead--> BspAd903xRegRead
            BspAd903xRegRead(ulChipId, ulLaneAddr + ulLaneIdx * 4, &ulLaneSta, 0xFF);
            if (DPDIC_TO_AD903X_TX_OK != ulLaneSta)
            {
                u64TxLaneStatus |= (UINT64)0x01 << (24 + ulLaneIdx);
            }
        }
        BspSysMsDelay(10);
    }
    *pu64EventBits |= u64TxLaneStatus;
#endif

    dbgInfoEx("%s>>Ad903x'%d ClrFlag'%d: AlmStatus= 0x%llX\n", __FUNCTION__, ulChipId, ulAlmClrFlag, *pu64EventBits);
    return lRetVal;
}

// ulAlmClrFlag: 0- 只获取告警不允许清除不配置功放保护标志, 1- 获取告警后清除, 配置功放保护标志
// RxSerdes 获取的是实时告警, 无需清除, ulAlmClrFlag 参数暂无用
static INT32 Ad903xGetRxSerdesAlm(UINT32 ulAlmClrFlag, UINT32 ulChipId, UINT64 *pu64EventBits)
{
    INT32 lRetVal = 0;
#if (0) // 此函数的实现在 BspGetIcJ204LaneStatus 函数中已经完成
    UINT32 ulLoop    = 0;
    UINT32 ulRxData  = 0;
    UINT32 ulOrxData = 0;

    for (ulLoop = 0; ulLoop < 4; ulLoop++)
    {
        IcHalRdReg(0, CPU_J204_UL_CHECK_ERR_LANE, ulLoop * 4, &ulRxData); // 上行 LOCAL_SAMPLE_J204C_LANE0_IDLE
        if (AD903X_TO_IC_SERDES_OK != ulRxData)
        {
            *pu64EventBits |= 0x01 << (ulLoop * 2 + 32);
        }
    }

    for (ulLoop = 0; ulLoop < 4; ulLoop++)
    {
        IcHalRdReg(0, CPU_J204_FB_CHECK_ERR_LANE, ulLoop * 4, &ulOrxData); // 反馈 LOCAL_SAMPLE_J204C_LANE4_IDLE
        if (AD903X_TO_IC_SERDES_OK != ulOrxData)
        {
            *pu64EventBits |= 0x01 << (ulLoop * 2 + 40);
        }
    }

    dbgInfoEx("%s>>Ad903x'%d ClrFlag'%d: AlmStatus= 0x%llX\n", __FUNCTION__, ulChipId, ulAlmClrFlag, *pu64EventBits);
#endif
    return lRetVal;
}

// ulType:  0- J204c, 1- Serdes
// ulAlmClrFlag: 0- 只获取告警不允许清除不配置功放保护标志, 1- 获取告警后清除, 配置功放保护标志
static INT32 Ad903xGetTrxJ204cSerdesAlm(UINT32 ulType, UINT32 ulAlmClrFlag, UINT32 ulChipId, UINT64 *pu64EventBits)
{
    INT32  lRetVal      = 0;
    UINT32 ulChipSum    = 0;
    UINT32 ulTrsvAlmFlg = 0;
    UINT32 ulSetBitsAlm = 0;
    UINT64 u64TxSerdesAlm = 0;
    UINT64 u64RxSerdesAlm = 0;

    if ((UINT64 *)NULL == pu64EventBits)
    {
        dbgErr("%s>>Param Error! pEventBits NULL;\n", __FUNCTION__);
        return (INT32)-1;
    }

    ulChipSum = GetTransceiverChipNum();
    if (ulChipId >= ulChipSum)
    {
        *pu64EventBits = 0;
        dbgErr("%s>>Error!Param Over; ChipId(0~%d)= %d\n",
               __FUNCTION__, ulChipSum - 1, ulChipId);
        return (INT32)BSP_OK; // 索引超出范围,不应上报告警
    }

    if (0 == ulType)
    {
        ulTrsvAlmFlg = TRANS_J204BC_PAPRO_ALMTYPE;
    }
    else
    {
    #if (0) // 0: 表示不允许检测Serdes告警状态, 1: 表示允许;
        ulTrsvAlmFlg = TRANS_SERDES_PAPRO_ALMTYPE;
    #else
        *pu64EventBits = 0; // Ad903x不区分Serdes和J204C, Serdes不检查只上报无告警;
        dbgInfoEx("%s>>Ad903x'%d Type(0:J204C 1:Serdes)'%d ClrFlag'%d: Not Check!\n",
                  __FUNCTION__, ulChipId, ulType, ulAlmClrFlag);
        return (INT32)BSP_OK;
    #endif
    }

    lRetVal |= Ad903xGetTxSerdesAlm(ulAlmClrFlag, ulChipId, &u64TxSerdesAlm); // BspGetAd9025TxSerdesAlm
    lRetVal |= Ad903xGetRxSerdesAlm(ulAlmClrFlag, ulChipId, &u64RxSerdesAlm); // BspGetAd9025RxSerdesAlm
    *pu64EventBits = u64TxSerdesAlm | u64RxSerdesAlm;

    if (ulAlmClrFlag > 0)
    {
        // LaneIdx和Trans通道是否有对应关系? 如果有, 需要按通道设置ulSetBitsAlm;
        // 按通道配置接口: BspSetTransPaProAlmFlagByChn();
        ulSetBitsAlm = ((UINT64)0 != *pu64EventBits) ? 0xFF : 0x00;
        BspSetTransPaProAlmFlagByChip(ulChipId, ulTrsvAlmFlg, ulSetBitsAlm);
    }

    dbgInfoEx("%s>>Ad903x'%d Type(0:J204C 1:Serdes)'%d ClrFlag'%d: AlmStatus= 0x%llX\n",
              __FUNCTION__, ulChipId, ulType, ulAlmClrFlag, *pu64EventBits);
    return lRetVal;
}

// 创造J204C告警命令: IcHalApiAdjustJ204SerdesTxEq 0x01,0,23,0
// ulAlmClrFlag: 0- 只获取告警不允许清除不配置功放保护标志, 1- 获取告警后清除, 配置功放保护标志
static INT32 BspGetAd903xJ204bcAlm(UINT32 ulAlmClrFlag, UINT32 ulChipId, UINT64 *pu64EventBits)
{
    INT32 lRetVal = 0;

    // Ad903x不区分Serdes和J204C, 告警上报只保留J204C;
    lRetVal = Ad903xGetTrxJ204cSerdesAlm(0, ulAlmClrFlag, ulChipId, pu64EventBits);
    return lRetVal;
}

// ulAlmClrFlag: 0- 只获取告警不允许清除不配置功放保护标志, 1- 获取告警后清除, 配置功放保护标志
static INT32 BspGetAd903xSerdesAlm(UINT32 ulAlmClrFlag, UINT32 ulChipId, UINT64 *pu64EventBits)
{
    INT32 lRetVal = 0;

    lRetVal = Ad903xGetTrxJ204cSerdesAlm(1, ulAlmClrFlag, ulChipId, pu64EventBits);
    return lRetVal;
}

// ulAlmClrFlag: 0- 只获取告警不允许清除不配置功放保护标志, 1- 获取告警后清除, 配置功放保护标志
static INT32 BspGetAd903xPwrErrAlm(UINT32 ulAlmClrFlag, UINT32 ulChipId, UINT64 *pu64EventBits)
{
    INT32  lRetVal      = 0;
//  uint8_t  ucEventAlm   = 0;
    UINT32 ulChnlIdx    = 0;
    UINT32 ulChipSum    = 0;
    UINT32 ulTrsvAlmFlg = 0;
    UINT32 ulSetBitsAlm = 0;
//  UINT32 ulTrxChnlIdx = 0;
    UINT64 u64PwrAlmFlg = 0;
    UINT64 u64TmpPwrAlm = 0;
//  UINT64 u64PwrErrFlg = 0;
//  UINT64 u64TmpPwrErr = 0;
    UINT32 ulFunRet     = BSP_OK;
    UINT32 ulTmpRet     = BSP_OK;
//  adi_adrv_TxChannels_e eTxChnlNo = 0;
    adi_adrv_GpIntMask_t tAdiGpIntMask = {0, };

    ulTrsvAlmFlg = TRANS_PWRERR_PAPRO_ALMTYPE;

    if ((UINT64 *)NULL == pu64EventBits)
    {
        dbgErr("%s>>Param Error! pEventBits NULL;\n", __FUNCTION__);
        return (INT32)-1;
    }

    ulChipSum = GetTransceiverChipNum();
    if (ulChipId >= ulChipSum)
    {
        *pu64EventBits = 0;
        dbgErr("%s>>Error!Param Over; ChipId(0~%d)= %d\n",
               __FUNCTION__, ulChipSum - 1, ulChipId);
        return (INT32)BSP_OK; //索引超出范围,不应上报告警
    }

    ulTmpRet = BspAd903xGpIntStatusGet(ulChipId, &tAdiGpIntMask); // BspAd9025GpIntStatusGet
    if (BSP_OK == ulTmpRet)
    {
        u64PwrAlmFlg = (tAdiGpIntMask.upperMask >> 10) & 0xFFFF;
        if (ulAlmClrFlag > 0)
        {
            // BspTestAd903xGpIntStatusClear 1,0xFFFFFFFF,0xFFFF,0xFFFFFFFF,0xFFFF
            // BspTestAd903xGpIntStatusClear--> BspAd903xGpIntStatusClear
            tAdiGpIntMask.lowerMask  = ((UINT64)0x00000000);
            tAdiGpIntMask.upperMask  = ((UINT64)0x0000FFFF) << 10;
            ulTmpRet = BspAd903xGpIntStatusClear(ulChipId, &tAdiGpIntMask);       
            AD903X_FUNC_RETURN_CHK(ulTmpRet);
        }
    }
    else
    {
        u64PwrAlmFlg = (int64_t)0;
        ulFunRet |= BSP_BIT_SET(0);
    }
    *pu64EventBits = u64PwrAlmFlg;

    // Curr EventAlm: ucEventAlm[0]- Pa Protection Average Power Error
    // Curr EventAlm: ucEventAlm[1]- Pa Protection Peak    Power Error
    // BspTestAd903xTxProtectionErrorGet  --> BspAd903xTxProtectionErrorGet
    for (ulChnlIdx = 0; ulChnlIdx < 8; ulChnlIdx++)
    {
        u64TmpPwrAlm = u64PwrAlmFlg & (((UINT64)0x03) << ( ulChnlIdx * 2));
    #if (0)
        eTxChnlNo = (adi_adrv_TxChannels_e)(ADI_ADRV903X_TX0 << ulChnlIdx); // ADI_ADRV903X_TX0
        ulTmpRet = BspAd903xTxProtectionErrorGet(ulChipId, eTxChnlNo, &ucEventAlm);
        if (BSP_OK == ulTmpRet)
        {
            // 测试发现告警清除异常打印: ad903x#0 Ad903xHalTxProtectionErrorClear error,retVal=-1 ??????
            u64TmpPwrErr = ((UINT64)(ucEventAlm & 0x03)) << (32 + ulChnlIdx * 2);
            if ((UINT64)0 != u64TmpPwrErr) // // 测试发现告警清除异常, 清除加个判断; 确定后去掉???
            {
                ulTmpRet = BspAd903xTxProtectionErrorClear(ulChipId, eTxChnlNo, ucEventAlm & 0x03);
                AD903X_FUNC_RETURN_CHK(ulTmpRet);
            }
        }
        else
        {
            u64TmpPwrErr = (int64_t)0;
            ulFunRet |= BSP_BIT_SET(8 + ulChnlIdx);
        }
        u64PwrErrFlg |= u64TmpPwrErr;
    #endif
        if (ulAlmClrFlag > 0)
        {
            ulSetBitsAlm = !!(u64TmpPwrAlm); // ulSetBitsAlm = !!(u64TmpPwrAlm | u64TmpPwrErr);
            BspSetTransPaProAlmFlagByChn(ulChipId, ulChnlIdx, ulTrsvAlmFlg, ulSetBitsAlm);
        }
    }
//  *pu64EventBits |= u64PwrErrFlg;

    if (BSP_OK != ulFunRet)
    {
        lRetVal = (INT32)-1;
    }
    dbgInfoEx("%s>>Ad903x'%d ClrFlag'%d Ret'0x%04X: AlmStatus= 0x%llX\n", __FUNCTION__, 
              ulChipId, ulAlmClrFlag, ulFunRet, *pu64EventBits);

    return lRetVal;
}

// ulAlmClrFlag: 0- 只获取告警不允许清除不配置功放保护标志, 1- 获取告警后清除, 配置功放保护标志
static INT32 BspGetAd903xArmErrAlm(UINT32 ulAlmClrFlag, UINT32 ulChipId, UINT64 *pu64EventBits)
{
    INT32  lRetVal      = 0;
    UINT32 ulChnlIdx    = 0;
    UINT32 ulChipSum    = 0;
    UINT32 ulTrsvAlmFlg = 0;
    UINT32 ulSetBitsAlm = 0;
    UINT32 ulBitAlmBack = 0;
    UINT64 u64AlmErrFlg = 0;
    UINT64 u64StreamFlg = 0;
    UINT32 ulTmpRet     = BSP_OK;
    adi_adrv_GpIntMask_t tAdiGpIntMask = {0, };

    if ((UINT64 *)NULL == pu64EventBits)
    {
        dbgErr("%s>>Param Error! pEventBits NULL;\n", __FUNCTION__);
        return (INT32)-1;
    }

    ulChipSum = GetTransceiverChipNum();
    if (ulChipId >= ulChipSum)
    {
        *pu64EventBits = 0;
        dbgErr("%s>>Error!Param Over; ChipId(0~%d)= %d\n",
               __FUNCTION__, ulChipSum - 1, ulChipId);
        return (INT32)BSP_OK; //索引超出范围,不应上报告警
    }

    ulTmpRet = BspAd903xGpIntStatusGet(ulChipId, &tAdiGpIntMask); // BspAd9025GpIntStatusGet
    if (BSP_OK == ulTmpRet)
    {
        // 把StreamProcessor部分异常放到u64AlmErrFlg标志上, 不区分通道设置ulSetBitsAlm
        // ARM告警屏蔽GpIntPinMask-->UpperMask[D0和D5] bit 位
        u64AlmErrFlg |= tAdiGpIntMask.upperMask & (((UINT64)0x03DE) <<  0); // Arm 异常

        u64AlmErrFlg |= tAdiGpIntMask.lowerMask & (((UINT64)0x0001) << 40); // Core StreamProcessor异常
        u64AlmErrFlg |= tAdiGpIntMask.lowerMask & (((UINT64)0x0001) << 39); // ORx1 StreamProcessor异常
        u64AlmErrFlg |= tAdiGpIntMask.lowerMask & (((UINT64)0x0001) << 38); // ORx0 StreamProcessor异常

        u64StreamFlg |= tAdiGpIntMask.lowerMask & (((UINT64)0xFFFF) << 22); // Trx  StreamProcessor异常 

        /* @张丹宁 Arm告警和radio确认过了, 改成不清历史告警Gpint, 清了那就和没保护一个样;
           Arm没有实时检测手段; 不做后处理动作, 如果天线降秩通道过多也会凌晨自救的; */
    #if (0)
        if (ulAlmClrFlag > 0)
        {
            // BspTestAd903xGpIntStatusClear 1,0xFFFFFFFF,0xFFFF,0xFFFFFFFF,0xFFFF
            // BspTestAd903xGpIntStatusClear--> BspAd903xGpIntStatusClear
            tAdiGpIntMask.lowerMask = ((UINT64)0x07FFFF) << 22;
            tAdiGpIntMask.upperMask = ((UINT64)0x0003FF) <<  0;
            ulTmpRet = BspAd903xGpIntStatusClear(ulChipId, &tAdiGpIntMask);
            AD903X_FUNC_RETURN_CHK(ulTmpRet);
        }
    #endif
    }
    else
    {
        lRetVal = (INT32)(-1);
    }
    *pu64EventBits = u64AlmErrFlg | u64StreamFlg;
    /* Started by AICoder, pid:of020sc9f3o2f73147ea0a3640b36407e9c6449c */
    if(0 != (*pu64EventBits))
    {
       BspLog(LOG_LEVEL_0,"%s>>gpIntStatus.lowerMask = 0x%llx.\n", __FUNCTION__, tAdiGpIntMask.lowerMask);
       BspLog(LOG_LEVEL_0,"%s>>gpIntStatus.upperMask = 0x%llx.\n", __FUNCTION__, tAdiGpIntMask.upperMask);

    }
    /* Ended by AICoder, pid:of020sc9f3o2f73147ea0a3640b36407e9c6449c */

    if (ulAlmClrFlag > 0)
    {
        ulTrsvAlmFlg = TRANS_OTHERS_PAPRO_ALMTYPE;
        ulBitAlmBack = ((UINT64)0 != u64AlmErrFlg) ? 0xFF : 0x00;
    
        for (ulChnlIdx = 0; ulChnlIdx < 8; ulChnlIdx++)
        {
            ulSetBitsAlm  = 0;
            ulSetBitsAlm |= !!(ulBitAlmBack & BSP_BIT_SET(ulChnlIdx));                 // Arm 异常
            ulSetBitsAlm |= !!(u64StreamFlg & (((UINT64)0x01) << (22 + ulChnlIdx))); // Rx StreamProcessor异常
            ulSetBitsAlm |= !!(u64StreamFlg & (((UINT64)0x01) << (30 + ulChnlIdx))); // Tx StreamProcessor异常
            BspSetTransPaProAlmFlagByChn(ulChipId, ulChnlIdx, ulTrsvAlmFlg, ulSetBitsAlm);
        }

        /* Started by AICoder, pid:67459ye05ecb63814e51080bb0e2fc02f6577b18 */
        // BspTestAd903xGpIntStatusClear 1,0xFFFFFFFF,0xFFFF,0xFFFFFFFF,0xFFFF
        // BspTestAd903xGpIntStatusClear--> BspAd903xGpIntStatusClear
        tAdiGpIntMask.lowerMask  = ((UINT64)0xFFFF << 32) | (UINT64)0xFFFFFFFF;
        tAdiGpIntMask.upperMask  = ((UINT64)0xFFFF << 32) | (UINT64)0xFFFFFFFF;
        ulTmpRet = BspAd903xGpIntStatusClear(ulChipId, &tAdiGpIntMask);
        AD903X_FUNC_RETURN_CHK(ulTmpRet);
        dbgInfoEx("%s>>BspAd903xGpIntStatusClear!!!\n", __FUNCTION__);
        /* Ended by AICoder, pid:67459ye05ecb63814e51080bb0e2fc02f6577b18 */

    }

    dbgInfoEx("%s>>Ad903x'%d ClrFlag'%d: AlmStatus= 0x%llX\n", __FUNCTION__, ulChipId, ulAlmClrFlag, *pu64EventBits);
    return lRetVal;
}

// static VOID Ad903xRecordPaptAlmEvent(E_PaProType ulAlmType, UINT64 *pu64EventBits)
// {
//     UINT32 ulChipId   = 0;
//     UINT32 ulChipSum  = 0;
//     UINT32 ulEventIdx = 0;
//     UINT32 ulAlmEvent = 0;

// #if defined(BSP_MAKE_VER) || defined(_BSP_WITH_WFS)
//     UINT32 transNum = GetTransceiverChipNum();
// #else
//     UINT32 transNum = GetTransceiverChipNum();
// #endif

//     if ((UINT64 *)NULL == pu64EventBits)
//     {
//         dbgErr("%s>>Param Error! pEventBits NULL;\n", __FUNCTION__);
//         return;
//     }

//     switch(ulAlmType)
//     {
//         case E_PA_PRO_TYPE_TRSV_MCUPLL0:  //时钟失锁告警和本振失锁告警
//         {
//             ulEventIdx = TRANS_MCU_PLL_PAPRO_ALMTYPE;
//             ulChipId   = ulAlmType - E_PA_PRO_TYPE_TRSV_MCUPLL0;
//             break;
//         }
//         case E_PA_PRO_TYPE_TRSV_J204BC0:  //204B/204C异常保护告警
//         {
//             ulEventIdx = TRANS_J204BC_PAPRO_ALMTYPE;
//             ulChipId   = ulAlmType - E_PA_PRO_TYPE_TRSV_J204BC0;
//             break;
//         }
//         case E_PA_PRO_TYPE_TRSV_SERDES0:
//         {
//             ulEventIdx = TRANS_SERDES_PAPRO_ALMTYPE;
//             ulChipId   = ulAlmType - E_PA_PRO_TYPE_TRSV_SERDES0;
//             break;
//         }
//         case E_PA_PRO_TYPE_TRSV_PWRERR0: //单点和均值功率告警
//         {
//             ulEventIdx = TRANS_PWRERR_PAPRO_ALMTYPE;
//             ulChipId   = ulAlmType - E_PA_PRO_TYPE_TRSV_PWRERR0;
//             break;
//         }
//         case E_PA_PRO_TYPE_TRSV_OTHERS0: //ARM或Stream Processor异常保护与监测
//         {
//             ulEventIdx = TRANS_OTHERS_PAPRO_ALMTYPE;
//             ulChipId   = ulAlmType - E_PA_PRO_TYPE_TRSV_OTHERS0;
//             break;
//         }
//         default:
//             return;
//     }

//     if (ulChipId >= ulChipSum) // AD903X_DEV_NUM
//     {
//         dbgErr("%s>>Error! ChipId Over;\n", __FUNCTION__);
//         return;
//     }

//     s_atAd903xPaptRecordEvent[ulChipId].au64RecPaAlm[ulEventIdx % AD903X_REC_ALM_EVENT_MAX_SUM] = *pu64EventBits; // s_ad9025PaptRecordEvent

//     ulAlmEvent = s_atAd903xPaptRecordEvent[ulChipId].au32AlmEvent[ulEventIdx % AD903X_REC_ALM_EVENT_MAX_SUM];
//     if (*pu64EventBits > (UINT64)0)
//     {
//         if (ulAlmEvent < (UINT32)0xFFFFFFFF)
//         {
//             ulAlmEvent++;
//         }
//         else
//         {
//             ulAlmEvent = 1;
//         }
//     }
//     s_atAd903xPaptRecordEvent[ulChipId].au32AlmEvent[ulEventIdx % AD903X_REC_ALM_EVENT_MAX_SUM] = ulAlmEvent;
//     dbgInfoEx("%s>>AlmType'%d Ad903x'%d EventIdx'%d: AlmEventCnt= %d, AlmStatus= 0x%llX\n",
//               __FUNCTION__, ulAlmType, ulChipId, ulEventIdx, ulAlmEvent, *pu64EventBits);
// }

/*****************************************************************************
 * 函数名称: Ad903xGetPastPaProAlm(*)
 * 功能描述: Ad903x功放告警上报
 * 输入参数: ulAlmType    - PaPro Alarm Type
 * 输出参数: pulEventBits - 正值代表有告警
 * 返 回 值: 0- 正常, 负值- 获取告警异常
 * 其它说明: Ad9025对应接口:  Ad9025GetPastPaProAlm  MtsGetPastPaProAlm
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *----------------------------------------------------------------------------
 */
INT32 Ad903xGetPastPaProAlm(UINT32 chipId, E_TRANS_PAPRO_ALM_TYPE ulAlmType, UINT64 *pu64EventBits)
{
    INT32  lRetVal  = 0;
    UINT32 ulChipId = 0;

    switch(ulAlmType)
    {
        case TRANS_MCU_PLL_PAPRO_ALMTYPE: //时钟失锁告警和本振失锁告警
        {
            lRetVal = BspGetAd903xMcuClkAlm(1, ulChipId, pu64EventBits);
            break;
        }
        case TRANS_J204BC_PAPRO_ALMTYPE:// 204B/204C异常保护告警
        {
            lRetVal = BspGetAd903xJ204bcAlm(1, ulChipId, pu64EventBits);
            break;
        }
        case TRANS_SERDES_PAPRO_ALMTYPE:
        {
            lRetVal = BspGetAd903xSerdesAlm(1, ulChipId, pu64EventBits);
            break;
        }

        case TRANS_PWRERR_PAPRO_ALMTYPE:// 单点和均值功率告警
        {
            lRetVal = BspGetAd903xPwrErrAlm(1, ulChipId, pu64EventBits);
            break;
        }
        case TRANS_OTHERS_PAPRO_ALMTYPE: // ARM或Stream Processor异常保护与监测
        {
            lRetVal = BspGetAd903xArmErrAlm(1, ulChipId, pu64EventBits);
            break;
        }
        default:
            lRetVal = PAPT_NOT_SUPPORT_ALM;
            break;
    }
    return lRetVal;
}

INT32 Ad903xClrPastPaProAlm(UINT32 chipId, E_TRANS_PAPRO_ALM_TYPE eTransAlmType)
{
    INT32  lRetVal   = 0;

    // Ad903x异常状态清除跟随在状态获取之后处理, 此处不再单独调用清除函数
    return lRetVal;
}

INT32 Ad903xJ204bcAlmRecover(UINT32 ulChipId, UINT64 u64AlmBitsMask)
{
    int32_t  lRetVal   = 0;
    uint32_t ulLoopIdx = 0;
    uint32_t ulChipSum = 0;
    uint32_t ulChipMin = 0;
    uint32_t ulChipMax = 0;
    uint32_t ulTmpRet  = BSP_OK;
    adi_adrv_GpIntMask_t tAdiGpIntMask = {0, };

    // if (0 == u64AlmBitsMask)
    // {
    //     dbgErr("%s>>Error! BitMask'0x%llx Not Enable;\n", __FUNCTION__, u64AlmBitsMask);
    //     return (int32_t)-1;
    // }

//  恢复流程不支持单片操作, 固定, 单片DPDIC下所有的Ad903x都操作
    ulChipSum = GetTransceiverChipNum();
#if (1)
    ulChipMin = 0;
    ulChipMax = ulChipSum;
#else
    if (ulChipId < ulChipSum)
    {
        ulChipMin = ulChipId;
        ulChipMax = ulChipId + 1;
    }
    else
    {
        ulChipMin = 0;
        ulChipMax = ulChipSum;
    }
#endif
    ////////////////////////// 防止重入频繁操作 ///////////////////////////
    for (ulLoopIdx = ulChipMin; ulLoopIdx < ulChipMax; ulLoopIdx++)
    {
        if (0 != (s_ulAd903xJ204cRecoverFlag & BSP_BIT_SET(ulLoopIdx)))
        {
        //  dbgInfoEx("%s>>Chip'%d AlmMask'0x%llX: J204cRecover......\n",
        //            __FUNCTION__, ulChipIdx, u64AlmBitsMask);
            break; // 表示后处理操作进行中
        }
    }
    if (ulLoopIdx < ulChipMax)
    {
        dbgInfo("%s>>Chip'%d AlmMask'0x%llX: J204cRecover......\n",
                __FUNCTION__, ulLoopIdx, u64AlmBitsMask);
        return (int32_t)255;
    }
    for (ulLoopIdx = ulChipMin; ulLoopIdx < ulChipMax; ulLoopIdx++)
    {
        s_ulAd903xJ204cRecoverFlag |= (uint32_t)BSP_BIT_SET(ulLoopIdx);
    }
    ///////////////////////////////////////////////////////////////////////

    for (ulLoopIdx = ulChipMin; ulLoopIdx < ulChipMax; ulLoopIdx++)
    {
        ulTmpRet = BspAd903xDisableTrackingCals(ulLoopIdx, 0x08, 0xFF);
        AD903X_SERDES_REINIT_ERROR_REPORT(ulTmpRet, lRetVal, "BspAd903xDisableTrackingCals");
    }

    lRetVal = BspPaptJ204LinkRebuildWithRetry(ulChipId);
    
    for (ulLoopIdx = ulChipMin; ulLoopIdx < ulChipMax; ulLoopIdx++)
    {
    //  Ad9025对应接口: BspAd9025EnableTrackingCals();
        ulTmpRet = BspAd903xEnableTrackingCals(ulLoopIdx, 0x08, 0xFF);
        AD903X_SERDES_REINIT_ERROR_REPORT(ulTmpRet, lRetVal, "BspAd903xEnableTrackingCals");
    }

    // Ad903xJesdBringUp之后清除一下告警
    // BspTestAd903xGpIntStatusClear 1,0xFFFFFFFF,0xFFFF,0xFFFFFFFF,0xFFFF
    // BspTestAd903xGpIntStatusClear--> BspAd903xGpIntStatusClear
    // Ad9025对应接口: BspAd9025GPIntClearStatusRegister
    for (ulLoopIdx = ulChipMin; ulLoopIdx < ulChipMax; ulLoopIdx++)
    {
        tAdiGpIntMask.lowerMask  = ((uint64_t)0xFFFF << 32) | (uint64_t)0xFFFFFFFF;
        tAdiGpIntMask.upperMask  = ((uint64_t)0xFFFF << 32) | (uint64_t)0xFFFFFFFF;
        ulTmpRet = BspAd903xGpIntStatusClear(ulLoopIdx, &tAdiGpIntMask);
        AD903X_SERDES_REINIT_ERROR_REPORT(ulTmpRet, lRetVal, "BspAd903xGpIntStatusClear");

        if (s_aulAd903xJ204cRecoverEvent[ulLoopIdx] < (uint32_t)0xFFFFFFFF)
        {
            s_aulAd903xJ204cRecoverEvent[ulLoopIdx]++;
        }
        else
        {
            s_aulAd903xJ204cRecoverEvent[ulLoopIdx] = 0;
        }

        s_ulAd903xJ204cRecoverFlag &= (uint32_t)BSP_BIT_REV(ulLoopIdx);
    }

    dbgInfoEx("%s>>Chip'%d AlmMask'0x%llX: J204cRecover End!\n",
              __FUNCTION__, ulChipId, u64AlmBitsMask);
    return lRetVal;
}


/*****************************************************************************
 * 函数名称: Ad903xPaProAlmRecover(*)
 * 功能描述: Ad903x功放告警修复
 * 输入参数: ulAlmType      - 告警类型
 *           u64AlmBitsMask - 告警BitsMask
 * 输出参数: 无
 * 返 回 值: 0- 正常或无后处理操作, 负值- 后处理操作异常, 正值- 表示有后处理操作
 * 其它说明: 修复优先级: 时钟本振类>> Serdes类>> 204类>> 功率异常类>> ARM类
 *           A9631AS26对应接口: Ad9025PaProAlmRecover
 *           A9641AS26对应接口: MtsPaProAlmRecover
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10332561, 创建
 *----------------------------------------------------------------------------
 */
INT32 Ad903xPaProAlmRecover(UINT32 ulChipId,E_TRANS_PAPRO_ALM_TYPE ulAlmType, UINT64 u64AlmBitsMask)
{
    INT32  lRetVal  = 0;
    INT32  lChipId = (INT32)ulChipId;

    switch(ulAlmType)
    {
        case TRANS_MCU_PLL_PAPRO_ALMTYPE:  // 时钟失锁告警和本振失锁告警
        case TRANS_PWRERR_PAPRO_ALMTYPE: // 单点和均值功率告警
        case TRANS_OTHERS_PAPRO_ALMTYPE:  // ARM或Stream Processor异常保护与监测
        case TRANS_SERDES_PAPRO_ALMTYPE:
        case TRANS_OUTBUF_PAPRO_ALMTYPE:
            break;
        case TRANS_J204BC_PAPRO_ALMTYPE: // 204B/204C异常保护告警
            lRetVal = Ad903xJ204bcAlmRecover(lChipId, u64AlmBitsMask); // Ad903x接口
            break;
        default:
            lRetVal = PAPT_NOT_SUPPORT_ALM;
            break;
    }

    return lRetVal;
}

adi_adrv_GpIntMask_t g_GpIntMask = 
{
    .lowerMask = ((UINT64)0xFE00 << 32) | (UINT64)0x003FFFFF,
    .upperMask = ((UINT64)0xFFFE << 32) | (UINT64)0x93FFFC21,
};

UINT32 BspModifyAd903xGpIntMask(adi_adrv_GpIntMask_t *pGpIntMask)
{
    UINT32 retVal = BSP_OK;
    if(NULL == pGpIntMask)
    {
        return BSP_ERROR;
    }
    
    memcpy_s(&g_GpIntMask,sizeof(adi_adrv_GpIntMask_t),pGpIntMask,sizeof(adi_adrv_GpIntMask_t));
    return retVal;
}

UINT32 BspGetAd903xGpIntMask(VOID)
{
    UINT32 retVal = BSP_OK;
    dbgInfo("%s>>line'%d lowerMask'0x%lX: upperMask'0x%lX'!\n",__FUNCTION__, __LINE__, g_GpIntMask.lowerMask,  g_GpIntMask.upperMask);
    return retVal;
}

INT32 Ad903xClrAlmAfterInit(UINT32 chipIndex)
{
    UINT32 ulChipIdx = 0;
    UINT32 ulChipSum = 0;    
    UINT32 ulTmpRet  = BSP_OK;
    UINT32 ulRetVal  = BSP_OK;
    adi_adrv_GpIntMask_t tAdiGpIntClearMask = {0, };
    adi_adrv_GpIntMask_t tGpIntStickyBitMask = {0, };
    adi_adrv_GpIntPinMaskCfg_t tAdiPinMaskCfg = {0, };

    ulChipSum = GetTransceiverChipNum();
    /* BspTestAd903xGpIntPinMaskCfgSet只关注ADI_ADRV903X_GPINT0, gpInt1Mask默认全部配置为1,
       (1表示不启用, 即不关联Alm管脚); ARM告警屏蔽GpIntPinMask  upper mask  D0和D5bit位。修改指令：
       1) BspTestAd903xGpIntPinMaskCfgSet  ChipIndex,0,0x003f7fff,0xfe00,0x93fffc21,0xfffe
       2) BspTestAd903xGpIntStickyBitMaskSet ChipIndex,0x003f7fff,0xfe00,0x93fffc21,0xfffe */
    tAdiPinMaskCfg.gpInt0Mask.lowerMask = g_GpIntMask.lowerMask,
    tAdiPinMaskCfg.gpInt0Mask.upperMask = g_GpIntMask.upperMask,
    tAdiPinMaskCfg.gpInt1Mask.lowerMask = ((UINT64)0xFFFF << 32) | (UINT64)0xFFFFFFFF;
    tAdiPinMaskCfg.gpInt1Mask.upperMask = ((UINT64)0xFFFF << 32) | (UINT64)0xFFFFFFFF;

    tGpIntStickyBitMask.lowerMask = g_GpIntMask.lowerMask;
    tGpIntStickyBitMask.upperMask = g_GpIntMask.upperMask;

    tAdiGpIntClearMask.lowerMask = ((UINT64)0xFFFF << 32) | (UINT64)0xFFFFFFFF;
    tAdiGpIntClearMask.upperMask = ((UINT64)0xFFFF << 32) | (UINT64)0xFFFFFFFF;

    for (ulChipIdx = 0; ulChipIdx < ulChipSum; ulChipIdx++)
    {
        ulTmpRet = BspAd903xGpIntPinMaskCfgSet(ulChipIdx, ADI_ADRV903X_GPINT0, &tAdiPinMaskCfg);
        AD903X_FUNC_RETURN_CHK(ulTmpRet);
        ulRetVal |= ulTmpRet;

        ulTmpRet = BspAd903xGpIntStickyBitMaskSet(ulChipIdx, &tGpIntStickyBitMask);
        AD903X_FUNC_RETURN_CHK(ulTmpRet);
        ulRetVal |= ulTmpRet;

        ulTmpRet = BspAd903xGpIntStatusClear(ulChipIdx, &tAdiGpIntClearMask);
        AD903X_FUNC_RETURN_CHK(ulTmpRet);
        ulRetVal |= ulTmpRet;
    }
    
    return ulRetVal;
}

/*****************************************************************************
 * 函数名称: Ad903x2J204Rebuild(*)
 * 功能描述: ADI j204重新建链
 * 输入参数: lChipId       - ADI chip id
 *           ulAlmBitsMask - 告警事件MASK值
 * 输出参数: 无
 * 返 回 值: 0- 正常或无后处理操作正常, 负值- 后处理操作异常, 正值- 表示有后处理操作
 * 其它说明: 连续ulAlmBitsMask有3次告警, 才允许后处理
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10332561@2023-08-03, 创建
 *----------------------------------------------------------------------------
 */
INT32 Ad903xJ204Rebuild(UINT32 ulChipId)
{
    UINT32 ulChipSum = 0;
    UINT32 ulTmpRet  = BSP_OK;
    INT32 lRetVal = 0;
    UINT32 ulChipMin = 0;
    UINT32 ulChipMax = 0;
    UINT32 ulLoopIdx = 0;

    ulChipSum = GetTransceiverChipNum();
    ulChipMax = ulChipSum;

    for(ulLoopIdx = ulChipMin; ulLoopIdx < ulChipMax; ulLoopIdx++)
    {
        ulTmpRet = BspAd903xJesdBringUp(ulLoopIdx); // Ad9025对应接口: BspAd9025JesdBringup();
        AD903X_SERDES_REINIT_ERROR_REPORT(ulTmpRet, lRetVal, "BspAd903xJesdBringUp");
    }
    return (UINT32)lRetVal;
}

/*****************************************************************************
 * 函数名称: Mts2ClrAlmAfterInit(*)
 * 功能描述: 清除trancsceiver上所有告警
 * 输入参数: lChipId       - MTS chip id
 * 输出参数: 无
 * 返 回 值: 0- 正常或无后处理操作正常, 负值- 后处理操作异常, 正值- 表示有后处理操作
 * 其它说明: 初始化完成后，清除trancsceiver上所有告警
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10119095@2020-07-08, 创建
 *----------------------------------------------------------------------------
 */
INT32 Ad903xIcLaneAlmRecover(E_PaProType ePaProType, UINT64 u64AlmBitsMask)
{
    INT32 lRetVal = 0;
  
    if(E_PA_PRO_TYPE_IC_LANE_STATUS == ePaProType)
    {
        /*
            暂时按照对整片IC和全部Transceiver全部重新建链来实现，
            后续可以利用以下结构体中的信息：
                T_J204OnePairEnds -> dpdicLaneMask 和 transIdMask
            根据u64AlmBitsMask和dpdicLaneMask对比，
            判断DPDIC的哪个Grp及哪些片Transceiver需要重新建链
        */
        lRetVal = Ad903xJ204bcAlmRecover(PAPT_TRANS_FULL_MASK, u64AlmBitsMask); // 255表示所有MTS芯片
    }
    else 
    {
        lRetVal = PAPT_NOT_SUPPORT_ALM;
    }

    return lRetVal;
}

/**************************************************************************
                             回调挂接
 **************************************************************************/
static __attribute((constructor)) void SetADIPaptFunc() 
{

    (VOID)BspSetTransGetPaProAlmFunc(DEVICE_AD903X,Ad903xGetPastPaProAlm);
    (VOID)BspSetTransClrPaProAlmFunc(DEVICE_AD903X,Ad903xClrPastPaProAlm);
    (VOID)BspSetTransPaProAlmRecoverFunc(DEVICE_AD903X,Ad903xPaProAlmRecover);
    (VOID)BspSetTransClrAlmAfterInitFunc(DEVICE_AD903X,Ad903xClrAlmAfterInit); 
    (VOID)BspSetTransJ204RebuildFunc(DEVICE_AD903X,Ad903xJ204Rebuild);
    (VOID)BspSetPaProAlmRecoverFunc(E_PA_PRO_TYPE_IC_LANE_STATUS, Ad903xIcLaneAlmRecover);
}

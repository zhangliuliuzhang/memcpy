/*****************************************************************************
* 版权所有(C) 2017, ZTE Corp. ZXSDR-RRU Platform BSP
*----------------------------------------------------------------------------
* 模  块  名 : papt_mts10
* 文件名称 : papt_mts10.h
* 文件标识 : {[N/A]}
* 内容摘要 : 本文件提供了PAPT公共模块的函数实现
* 注意事项 : 无
* 作       者 : 332561
* 创建日期 : 2023-08-02
* 当前版本 : Ver1.0
*---------------------------------------------------------------------------*/
#ifndef _FUNCLIB_PAPT_ADI_H_
#define _FUNCLIB_PAPT_ADI_H_

#ifdef __cplusplus
extern "C" {
#endif

#include "bsppub.h"
#include "bspcomm.h"
#include "papt_common.h"

/**************************************************************************
 *                        宏
 **************************************************************************/


/**************************************************************************
 *                         数据类型
 **************************************************************************/


/**************************************************************************
*                         函数声明
**************************************************************************/
INT32 Ad903xGetPastPaProAlm(UINT32 chipId, E_TRANS_PAPRO_ALM_TYPE ulAlmType, UINT64 *pu64EventBits);
INT32 Ad903xClrPastPaProAlm(UINT32 chipId, E_TRANS_PAPRO_ALM_TYPE eTransAlmType);
INT32 Ad903xPaProAlmRecover(UINT32 chipId, E_TRANS_PAPRO_ALM_TYPE ulAlmType, UINT64 u64AlmBitsMask);
INT32 Ad903xClrAlmAfterInit(UINT32 chipIndex);
INT32 Ad903xIcLaneAlmRecover(E_PaProType ePaProType, UINT64 u64AlmBitsMask);
UINT32 BspModifyAd903xGpIntMask(adi_adrv_GpIntMask_t *pGpIntMask);

#ifdef __cplusplus
}
#endif

#endif

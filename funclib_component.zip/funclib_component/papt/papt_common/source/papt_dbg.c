/*****************************************************************************
* 版权所有(C) 2017, ZTE Corp. ZXSDR-RRU Platform BSP
*----------------------------------------------------------------------------
* 模  块  名 : papt_common
* 文件名称 : papt_dbg.c
* 文件标识 : {[N/A]}
* 内容摘要 : 本文件提供了PAPT模块维测接口实现
* 注意事项 : 无
* 作       者 : 10248577
* 创建日期 : 2022-03-10
* 当前版本 : Ver1.0
*---------------------------------------------------------------------------*/
#include "papt_dbg.h"
#include "papt_common.h"
#include "exprn.h"

/**************************************************************************
*                                  维测接口
**************************************************************************/

static void showpaptalarmlist(UINT32 startAlm)
{
    UINT32 loop= 0;
    const CHAR   *pcTypeNameStr = NULL;

    for(loop=(startAlm?startAlm:E_PA_PRO_TYPE_RFFPGA_PSYNC); loop<E_PA_PRO_TYPE_INVALID_DEFINE; loop++)
    {
        PA_PRO_ALM_TYPE_NAME_STR(loop, pcTypeNameStr);
        dbgInfo("almType=%02d almdscp=%s\n", loop, pcTypeNameStr);
    }
    return;
}

VOID DbgGetPaProPastAlm(UINT32 ulPaProTypeIdx)
{
    UINT32 retVal = BSP_OK;
    const CHAR   *pcTypeNameStr = NULL;
    T_PaProInputParam tPaProInputPara = {0};
    T_PaProFlagOutput tPaProAlmOutput = {0};

    PA_PRO_ALM_TYPE_NAME_STR(ulPaProTypeIdx, pcTypeNameStr);

    tPaProInputPara.ulPaProType = ulPaProTypeIdx;
    tPaProInputPara.ulPaProMask = 0xFFFFFFFF;
    memset(&tPaProAlmOutput, 0, sizeof(T_PaProFlagOutput));

    dbgInfo("input ulPaProTypeIdx=%d,%s\n", ulPaProTypeIdx,pcTypeNameStr);

    retVal = BspGetPaProPastAlm(&tPaProInputPara, &tPaProAlmOutput);
    if (BSP_OK != retVal)
    {
        dbgInfo("BspGetPaProPastAlm error\n");
        return;
    }
    dbgInfo("BspGetPaProPastAlm succ!\n");
    dbgInfo("PaProAlmOutput.MainMixedFlag=%#x\n", tPaProAlmOutput.ulMainMixedFlag);
    dbgInfo("PaProAlmOutput.SlaveMaskFlag=0x%llx\n", tPaProAlmOutput.ulSlaveMaskFlag);
    return;
}

VOID DbgPaProAlmRecover(UINT32 ulPaProTypeIdx)
{
    INT32 retVal = BSP_OK;
    const CHAR   *pcTypeNameStr = NULL;
    UINT64 u64EventAlmMask = 0xffffffff;

    PA_PRO_ALM_TYPE_NAME_STR(ulPaProTypeIdx, pcTypeNameStr);

    dbgInfo("input ulPaProTypeIdx=%d,%s almmask=0x%llx\n", ulPaProTypeIdx,pcTypeNameStr,u64EventAlmMask);

    retVal = BspPaProAlmRecover(ulPaProTypeIdx, u64EventAlmMask);
    if ((INT32)BSP_OK != retVal)
    {
        dbgInfo("BspPaProAlmRecover error\n");
    }
    dbgInfo("BspPaProAlmRecover succ!\n");
    return;
}

VOID DbgPaGetPaProtectAlmFlag(UINT32 ulBspChnl)
{
    UINT32 retVal = BSP_OK;
    UINT32 ulPaProFlag = 0;

    retVal = BspGetPaProtectAlmFlag(ulBspChnl, &ulPaProFlag);
    if (BSP_OK != retVal)
    {
        dbgInfo("BspGetPaProtectAlmFlag error\n");
    }
    dbgInfo("BspGetPaProtectAlmFlag succ!\n");
    dbgInfo("PaProFlag=%#x\n", ulPaProFlag);
    return;
}

UINT32 DbgPaptCheckRecoverInit(UINT32 trxMask, UINT32 grpMask, UINT32 laneMask)
{
    UINT32 retVal = 0;
    T_J204PairEndsInfo pairInfo = {0};
    pairInfo.onePairEnds[0].transIdMask = 0x3;
    pairInfo.onePairEnds[0].dpdicGrpMask = 0x3;
    pairInfo.onePairEnds[0].dpdicLaneMask = 0xFF;
    retVal = BspPaptCheckRecoverInit(&pairInfo);

    return retVal;
}

static VOID exprnaddcommonpapt(VOID)
{
    exprnadd("BspGetPaProPastAlm");
    exprnadd("BspGetPaProtectAlmFlag");
    exprnadd("BspPaProAlmRecover");
    exprnadd("BspPerTransGetPastPaProAlm");
    exprnadd("BspPerTransClrPaProPastAlm");
    exprnadd("BspPerTransPaProAlmRecover");
    exprnadd("BspPerTransClrAlmAfterInit");
    exprnadd("BspTransceiverGetPastPaProAlm");
    exprnadd("BspSetTransPaProAlmFlagByChip");
    exprnadd("BspSetTransPaProAlmFlagByChn");
    exprnadd("BspSetDpdicPaProAlmFlag");
    exprnadd("BspSetDpdicPaProAlmAllChn");
    exprnadd("BspPaptTransJ204Rebuild");
    exprnadd("BspGetPaProFlag");

    return;
}

static VOID prnpaptcommonfuncname(VOID)
{
    dbgInfo("BspGetPaProPastAlm\n");
    dbgInfo("BspGetPaProtectAlmFlag\n");
    dbgInfo("BspPaProAlmRecover\n");
    dbgInfo("BspPerTransGetPastPaProAlm\n");
    dbgInfo("BspPerTransClrPaProPastAlm\n");
    dbgInfo("BspPerTransPaProAlmRecover\n");
    dbgInfo("BspPerTransClrAlmAfterInit\n");
    dbgInfo("BspTransceiverGetPastPaProAlm\n");
    dbgInfo("BspSetTransPaProAlmFlagByChip\n");
    dbgInfo("BspSetTransPaProAlmFlagByChn\n");
    dbgInfo("BspSetDpdicPaProAlmFlag\n");
    dbgInfo("BspPaptTransJ204Rebuild\n");
    dbgInfo("BspGetPaProFlag\n");

    return;
}

/*****************************************************************************
*                                                                            *
*                                                                            *
*                            功放保护HELP接口实现                                    *
*                                                                            *
*                                                                            *
*****************************************************************************/
static VOID papthelp(VOID)
{
    dbgInfo("showpaptalarmlist\n");
    dbgInfo("showicalarmflag\n");
    dbgInfo("showtransalarmflag\n");
    dbgInfo("showhalpaptdata\n");
    dbgInfo("showcrmpaptdata\n");
    dbgInfo("showapppaptdata\n");
    dbgInfo("paprtprn bspChan,isClr\n");
    dbgInfo("papts chanMask,isClr\n");
    dbgInfo("paprtclr\n");
    dbgInfo("crmpaprtprn isClr\n");      
    dbgInfo("DbgGetPaProPastAlm PaProTypeIdx\n");
    dbgInfo("DbgPaProAlmRecover PaProTypeIdx\n");
    dbgInfo("DbgPaGetPaProtectAlmFlag ulBspChnl\n");
    dbgInfo("exprnaddcommonpapt\n");
    dbgInfo("prnpaptcommonfuncname\n");
    dbgInfo("exprnaddmts2prepapt\n");
    dbgInfo("exprnaddmtspapt\n");
    dbgInfo("exprnadddpdicpapt\n");
    dbgInfo("openpaptalm\n");
    dbgInfo("closepaptalm\n");
    dbgInfo("s_closePaptAlmReport\n");
    dbgInfo("MTS2_RampHelp\n");
    dbgInfo("DbgPaptCheckRecoverInit trxMask,grpMask,laneMask\n");
    return;
}

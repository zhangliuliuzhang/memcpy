/*****************************************************************************
* 版权所有(C) 2017, ZTE Corp. ZXSDR-RRU Platform BSP
*----------------------------------------------------------------------------
* 模  块  名 : papt_common
* 文件名称 : papt_common.c
* 文件标识 : {[N/A]}
* 内容摘要 : 本文件提供了PAPT公共模块的函数声明
* 注意事项 : 无
* 作       者 : 10248577
* 创建日期 : 2022-03-10
* 当前版本 : Ver1.0
*---------------------------------------------------------------------------*/
#include "bsppub.h"
#include "bspcomm.h"
#include "ru_basedef.h"
#include "ichaladapt_ic4_2.h"
#include "papt_common.h"
#include "rruinfo.h"
#include "vxadp.h"
#include "chnmapcommon.h"
#include "devdrv_transceiver.h"
#include "funccommon_log.h"
#include "funccommon.h"
#include "chnmap_a.h"
#include "papt_private.h"
#include "powerctrl_ic4_2.h"
/**************************************************************************
*                              宏定义
**************************************************************************/
#define APP_ALM_TYPE_MAX (E_PA_PRO_TYPE_INVALID_DEFINE)

#define PAPT_SUPPORT_CHN_MAX (64)
#define PAPT_SUPPORT_TRANS_MAX (8)
#define PAPT_J204_REBUILD_MAX (3)
#define PAPT_ALM_FLAG_MAX   (7)
/**************************************************************************
*                         函数声明
**************************************************************************/
INT32 BspTransceiverPaProAlmRecover(E_PaProType ePaProAlmType, UINT64 u64AlmBitsMask);
UINT32 BspSlaveGetPastPaProAlm(E_PaProType ePaProType, UINT64 *pu64EventBits);
INT32 BspSlavePaProAlmRecover(E_PaProType ePaProAlmType, UINT64 u64AlmBitsMask);
/**************************************************************************
*                         数据类型
**************************************************************************/
/* 维测用,保存与APP接口之间的交互数据 */
typedef struct _T_DbgPaptAppData
{
    UINT64  curSlaveMaskFlag;         /* 最近一次上报给高层的告警 */
    UINT64  lastValidSlaveMaskFlag;   /* 最近一次上报给高层的有效告警 */
    UINT64  recoverEventAlmMask;      /* 最近一次高层进行后处理的告警 */
}T_DbgPaptAppData;

/* 各类型Transceiver挂接的papt回调接口 */
typedef struct tagT_TransPaProAlmPara
{ 
    FUNC_TRANS_GET_PAST_PRO_ALM pFuncTransGetPastPrmAlm;
    FUNC_TRANS_CLR_PAST_PRO_ALM pFuncTransClrPastPrmAlm;
    FUNC_TRANS_PAST_PRO_ALM_RECOVER pFuncTransPastPrmAlmRecover;
    FUNC_TRANS_CLR_ALM_AFTER_INIT pFuncTransClrAlmAfterInit;
    FUNC_TRANS_CLR_ALM_AFTER_INIT pFuncTransJ204Rebuild;
}T_TransPaProAlmPara;

/* 缓存当前使用的Transceiver的各种信息(包含回调接口、有效通道掩码、devicetype等) */
typedef struct tagT_BufOfTransPaProAlmPara
{ 
    FUNC_TRANS_GET_PAST_PRO_ALM pFuncTransGetPastPrmAlm;
    FUNC_TRANS_CLR_PAST_PRO_ALM pFuncTransClrPastPrmAlm;
    FUNC_TRANS_PAST_PRO_ALM_RECOVER pFuncTransPastPrmAlmRecover;
    FUNC_TRANS_CLR_ALM_AFTER_INIT pFuncTransClrAlmAfterInit;
    UINT32 transUsedChnMask;
    UINT32 deviceType;
}T_BufOfTransPaProAlmPara;

/* 缓存各通道的Transceiver信息 */
typedef struct tagT_BufOfTransInfoByBspChn
{ 
    UINT32 ulRfTrsvType;
    UINT32 ulTrsvChipId;
    UINT32 ulChnlOfChip;
}T_BufOfTransInfoByBspChn;


/* 子端告警挂接的papt回调接口 */
typedef struct tagT_SlavePaProAlmPara
{
    FUNC_SLAVE_GET_PAST_PRO_ALM pFuncSlaveGetPastPrmAlm;
    FUNC_SLAVE_PAST_PRO_ALM_RECOVER pFuncSlavePastPrmAlmRecover;
}T_SlavePaProAlmPara;

static FUNC_UPDATE_PAPT_POW_INFO s_pFuncUpdatePaptInfo = NULL;
/**************************************************************************
 *                        全局变量
 **************************************************************************/

/* 功放保护告警对应的告警检测、后处理接口列表 */
static T_PaProAlmPara s_PaProAlmPara[APP_ALM_TYPE_MAX] = 
{
    [E_PA_PRO_TYPE_RFFPGA_PSYNC]    = {NULL , NULL},
    [E_PA_PRO_TYPE_TRSV_MCUPLL0] = {BspTransceiverGetPastPaProAlm,BspTransceiverPaProAlmRecover},
    [E_PA_PRO_TYPE_TRSV_MCUPLL1] = {BspTransceiverGetPastPaProAlm,BspTransceiverPaProAlmRecover},
    [E_PA_PRO_TYPE_TRSV_MCUPLL2] = {BspTransceiverGetPastPaProAlm,BspTransceiverPaProAlmRecover},
    [E_PA_PRO_TYPE_TRSV_MCUPLL3] = {BspTransceiverGetPastPaProAlm,BspTransceiverPaProAlmRecover},
    [E_PA_PRO_TYPE_TRSV_MCUPLL4] = {BspTransceiverGetPastPaProAlm,BspTransceiverPaProAlmRecover},
    [E_PA_PRO_TYPE_TRSV_MCUPLL5] = {BspTransceiverGetPastPaProAlm,BspTransceiverPaProAlmRecover},
    [E_PA_PRO_TYPE_TRSV_MCUPLL6] = {BspTransceiverGetPastPaProAlm,BspTransceiverPaProAlmRecover},
    [E_PA_PRO_TYPE_TRSV_MCUPLL7] = {BspTransceiverGetPastPaProAlm,BspTransceiverPaProAlmRecover},    
    [E_PA_PRO_TYPE_TRSV_J204BC0] = {BspTransceiverGetPastPaProAlm,BspTransceiverPaProAlmRecover},
    [E_PA_PRO_TYPE_TRSV_J204BC1] = {BspTransceiverGetPastPaProAlm,BspTransceiverPaProAlmRecover},
    [E_PA_PRO_TYPE_TRSV_J204BC2] = {BspTransceiverGetPastPaProAlm,BspTransceiverPaProAlmRecover},
    [E_PA_PRO_TYPE_TRSV_J204BC3] = {BspTransceiverGetPastPaProAlm,BspTransceiverPaProAlmRecover},
    [E_PA_PRO_TYPE_TRSV_J204BC4] = {BspTransceiverGetPastPaProAlm,BspTransceiverPaProAlmRecover},
    [E_PA_PRO_TYPE_TRSV_J204BC5] = {BspTransceiverGetPastPaProAlm,BspTransceiverPaProAlmRecover},
    [E_PA_PRO_TYPE_TRSV_J204BC6] = {BspTransceiverGetPastPaProAlm,BspTransceiverPaProAlmRecover},
    [E_PA_PRO_TYPE_TRSV_J204BC7] = {BspTransceiverGetPastPaProAlm,BspTransceiverPaProAlmRecover},    
    [E_PA_PRO_TYPE_TRSV_SERDES0] = {BspTransceiverGetPastPaProAlm,BspTransceiverPaProAlmRecover},
    [E_PA_PRO_TYPE_TRSV_SERDES1] = {BspTransceiverGetPastPaProAlm,BspTransceiverPaProAlmRecover},
    [E_PA_PRO_TYPE_TRSV_SERDES2] = {BspTransceiverGetPastPaProAlm,BspTransceiverPaProAlmRecover},
    [E_PA_PRO_TYPE_TRSV_SERDES3] = {BspTransceiverGetPastPaProAlm,BspTransceiverPaProAlmRecover},
    [E_PA_PRO_TYPE_TRSV_SERDES4] = {BspTransceiverGetPastPaProAlm,BspTransceiverPaProAlmRecover},
    [E_PA_PRO_TYPE_TRSV_SERDES5] = {BspTransceiverGetPastPaProAlm,BspTransceiverPaProAlmRecover},
    [E_PA_PRO_TYPE_TRSV_SERDES6] = {BspTransceiverGetPastPaProAlm,BspTransceiverPaProAlmRecover},
    [E_PA_PRO_TYPE_TRSV_SERDES7] = {BspTransceiverGetPastPaProAlm,BspTransceiverPaProAlmRecover},    
    [E_PA_PRO_TYPE_TRSV_OUTBUF0] = {BspTransceiverGetPastPaProAlm,BspTransceiverPaProAlmRecover},
    [E_PA_PRO_TYPE_TRSV_OUTBUF1] = {BspTransceiverGetPastPaProAlm,BspTransceiverPaProAlmRecover},
    [E_PA_PRO_TYPE_TRSV_OUTBUF2] = {BspTransceiverGetPastPaProAlm,BspTransceiverPaProAlmRecover},
    [E_PA_PRO_TYPE_TRSV_OUTBUF3] = {BspTransceiverGetPastPaProAlm,BspTransceiverPaProAlmRecover},
    [E_PA_PRO_TYPE_TRSV_OUTBUF4] = {BspTransceiverGetPastPaProAlm,BspTransceiverPaProAlmRecover},
    [E_PA_PRO_TYPE_TRSV_OUTBUF5] = {BspTransceiverGetPastPaProAlm,BspTransceiverPaProAlmRecover},
    [E_PA_PRO_TYPE_TRSV_OUTBUF6] = {BspTransceiverGetPastPaProAlm,BspTransceiverPaProAlmRecover},
    [E_PA_PRO_TYPE_TRSV_OUTBUF7] = {BspTransceiverGetPastPaProAlm,BspTransceiverPaProAlmRecover},    
    [E_PA_PRO_TYPE_TRSV_PWRERR0] = {BspTransceiverGetPastPaProAlm,BspTransceiverPaProAlmRecover},
    [E_PA_PRO_TYPE_TRSV_PWRERR1] = {BspTransceiverGetPastPaProAlm,BspTransceiverPaProAlmRecover},
    [E_PA_PRO_TYPE_TRSV_PWRERR2] = {BspTransceiverGetPastPaProAlm,BspTransceiverPaProAlmRecover},
    [E_PA_PRO_TYPE_TRSV_PWRERR3] = {BspTransceiverGetPastPaProAlm,BspTransceiverPaProAlmRecover},
    [E_PA_PRO_TYPE_TRSV_PWRERR4] = {BspTransceiverGetPastPaProAlm,BspTransceiverPaProAlmRecover},
    [E_PA_PRO_TYPE_TRSV_PWRERR5] = {BspTransceiverGetPastPaProAlm,BspTransceiverPaProAlmRecover},
    [E_PA_PRO_TYPE_TRSV_PWRERR6] = {BspTransceiverGetPastPaProAlm,BspTransceiverPaProAlmRecover},
    [E_PA_PRO_TYPE_TRSV_PWRERR7] = {BspTransceiverGetPastPaProAlm,BspTransceiverPaProAlmRecover},    
    [E_PA_PRO_TYPE_TRSV_OTHERS0] = {BspTransceiverGetPastPaProAlm,BspTransceiverPaProAlmRecover},
    [E_PA_PRO_TYPE_TRSV_OTHERS1] = {BspTransceiverGetPastPaProAlm,BspTransceiverPaProAlmRecover},
    [E_PA_PRO_TYPE_TRSV_OTHERS2] = {BspTransceiverGetPastPaProAlm,BspTransceiverPaProAlmRecover},
    [E_PA_PRO_TYPE_TRSV_OTHERS3] = {BspTransceiverGetPastPaProAlm,BspTransceiverPaProAlmRecover},    
    [E_PA_PRO_TYPE_TRSV_OTHERS4] = {BspTransceiverGetPastPaProAlm,BspTransceiverPaProAlmRecover},
    [E_PA_PRO_TYPE_TRSV_OTHERS5] = {BspTransceiverGetPastPaProAlm,BspTransceiverPaProAlmRecover},
    [E_PA_PRO_TYPE_TRSV_OTHERS6] = {BspTransceiverGetPastPaProAlm,BspTransceiverPaProAlmRecover},
    [E_PA_PRO_TYPE_TRSV_OTHERS7] = {BspTransceiverGetPastPaProAlm,BspTransceiverPaProAlmRecover},
    [E_PA_PRO_TYPE_SLAVE0_SYSPLL] = {BspSlaveGetPastPaProAlm,BspSlavePaProAlmRecover},
    [E_PA_PRO_TYPE_SLAVE1_SYSPLL] = {BspSlaveGetPastPaProAlm,BspSlavePaProAlmRecover},
    [E_PA_PRO_TYPE_SLAVE2_SYSPLL] = {BspSlaveGetPastPaProAlm,BspSlavePaProAlmRecover},
    [E_PA_PRO_TYPE_SLAVE0_BRDPWR_12V] = {BspSlaveGetPastPaProAlm,BspSlavePaProAlmRecover},
    [E_PA_PRO_TYPE_SLAVE1_BRDPWR_12V] = {BspSlaveGetPastPaProAlm,BspSlavePaProAlmRecover},
    [E_PA_PRO_TYPE_SLAVE2_BRDPWR_12V] = {BspSlaveGetPastPaProAlm,BspSlavePaProAlmRecover},
    [E_PA_PRO_TYPE_SLAVE0_FRAME] = {BspSlaveGetPastPaProAlm,BspSlavePaProAlmRecover},
    [E_PA_PRO_TYPE_SLAVE1_FRAME] = {BspSlaveGetPastPaProAlm,BspSlavePaProAlmRecover},
    [E_PA_PRO_TYPE_SLAVE2_FRAME] = {BspSlaveGetPastPaProAlm,BspSlavePaProAlmRecover},
};

/* Transceiver告警上报、告警清除、自救接口列表 */
static T_TransPaProAlmPara s_TransPaProAlmPara[DEVICE_NUM] = { 0 }; 

/* 维测用,保存与APP接口之间的交互数据 */
static T_DbgPaptAppData s_dbgPaptAppData[APP_ALM_TYPE_MAX] = {0};

/* Transceiver告警状态记录 */
static UINT64 s_ulTransPaProAlmFlag[TRANS_PAPRO_ALM_TYPE_MAX] = {0};

/* DPDIC告警状态记录 */
static UINT64 s_aulDpdicPastPaProAlmFlag[DPDIC_PAPRO_ALM_TYPE_MAX] = {0};

/* J204建链分组信息 */
T_J204PairEndsInfo s_204PairEndsInfo = {0};

/* J204断链告警恢复处理函数挂接 */
static FUNC_PAPT_J204_LINK_BUILD pFuncJ204LinkPreStep = NULL;
static FUNC_PAPT_J204_LINK_BUILD pFuncJ204LinkPostStep = NULL;
static FUNC_PAPT_J204_SYSREF_SEND pFuncJ204LinkSendSysref = NULL; 
static FUNC_PAPT_J204_RWADDRDIF_CHECK pFuncJ204RwAddrDifCheck = NULL;
static FUNC_PAPT_J204_RWADDRDIF_RECOVER pFuncJ204RwAddrDifRecover = NULL;

/* 缓存Transceiver信息,提高访问性能 */
T_BufOfTransPaProAlmPara s_BufTransPaProAlmPara[PAPT_SUPPORT_TRANS_MAX] = {0};
static T_BufOfTransInfoByBspChn s_BufOfPaptTransInfo[BSP_MAX_CHAN_NUM] = {0};

/* 开关接口 */
static UINT32 s_closePaptAlmReport = 1; /* 默认关闭，单板调用初始化接口后才打开 */

/* 光口告警、非光口告警区分, 默认掩码为0，需根据应用场景进行配置 */
static UINT64 s_optPaptAlmPosEnMask = 0;
/* 削峰前的均值功率保护告警, 默认掩码为0，需根据应用场景进行配置 */
static UINT64 s_cfrPaptAlmPosEnMask = 0;
/* DPD后的单点保护告警, 默认掩码为0，需根据应用场景进行配置 */
static UINT64 s_dpdPaptAlmPosEnMask = 0;

/* 重建链中标志 */
static UINT32 s_aulJ204bcRecoverFlag = 0;


/* 子端告警告警上报、告警清除、自救接口列表 */
static T_SlavePaProAlmPara s_SlavePaProAlmPara = { 0 };
static UINT64 s_ulSlavePaProAlmFlag[SLAVE_PAPRO_ALM_TYPE_MAX] = {0};
/**************************************************************************
*                         函数定义
**************************************************************************/
static UINT32 GetChipMaskByNum(UINT32 num)
{
    UINT32 loop = 0;
    UINT32 mask = 0;
    for(loop=0; loop<num; loop++)
    {
        mask |= BIT_SET(loop);
    }
    return mask;
}

static UINT32 PaptTransceiverInfoAnalyse(VOID)
{
    UINT32 loop = 0;    
    UINT32 ulTrsvNameId = 0;
    UINT32 ulTrsvChipId = 0;
    UINT32 ulTrsvChn = 0;
    UINT32 ulRetVal = BSP_OK;
    
    for (loop = 0; loop < BspGetTxBspChanNum(); loop++)
    {
        ulRetVal = BspGetTransceiverInfoByBspChnl(loop, &ulTrsvNameId, &ulTrsvChipId, &ulTrsvChn);
        if (BSP_OK != ulRetVal)
        {
            dbgInfoEx("%s>>TransceiverInfo Get Error! [bspChn=%d]\n", __FUNCTION__, loop);
            return BSP_ERROR;
        }

        if(ulTrsvChipId >= PAPT_SUPPORT_TRANS_MAX || ulTrsvChn >= PAPT_TRANS_CHN_MAX_NUM)
        {
            dbgErr("%s Transceiver info err ulTrsvChipId=%d, ulTrsvChn=%d\n",
                __func__, ulTrsvChipId, ulTrsvChn);
            return BSP_ERROR;
        }

        s_BufOfPaptTransInfo[loop].ulRfTrsvType = ulTrsvNameId;
        s_BufOfPaptTransInfo[loop].ulTrsvChipId = ulTrsvChipId;
        s_BufOfPaptTransInfo[loop].ulChnlOfChip = ulTrsvChn;
        s_BufTransPaProAlmPara[ulTrsvChipId].deviceType = ulTrsvNameId;
        s_BufTransPaProAlmPara[ulTrsvChipId].transUsedChnMask |= (BIT_SET(ulTrsvChn));        
    }    
    return BSP_OK;
}

static echiptype GetTransDevTypeByChipId(UINT32 chipId)
{
    if(chipId < PAPT_SUPPORT_TRANS_MAX && s_BufTransPaProAlmPara[chipId].deviceType)
    {
        return s_BufTransPaProAlmPara[chipId].deviceType;
    }

    return DEVICE_NUM;
}

static UINT32 GetTransInfoByBspChan(UINT32 bspChn, UINT32 *pulDevName, UINT32 *pulDevIdx, UINT32 *pulInterChnl)
{
    if(bspChn < BSP_MAX_CHAN_NUM && s_BufOfPaptTransInfo[bspChn].ulRfTrsvType)
    {
        *pulDevName = s_BufOfPaptTransInfo[bspChn].ulRfTrsvType;
        *pulDevIdx = s_BufOfPaptTransInfo[bspChn].ulTrsvChipId;
        *pulInterChnl = s_BufOfPaptTransInfo[bspChn].ulChnlOfChip;
        return BSP_OK;
    }
    return BSP_ERROR;
}

static UINT32 GetTransceiverChipNum()
{
    TRruDeviceDescription *pDev = NULL;
    UINT32 loop;
    static UINT32 trsvChipNum = 0;

    if (trsvChipNum != 0)
    {
    	return trsvChipNum;
    }
    for (loop = 0; loop < BspGetTxBspChanNum(); loop++)
    {
        if (0 == BspChipInfoPtrGetByRfPathDef(loop,TX,DEVICE_TYPE_TRANSCEIVER,&pDev))
        {
            if (pDev->ulDeviceCfg != INVALID_VALUE)
            {
                trsvChipNum++;
            }
        }
    }
    return trsvChipNum;
}

/*****************************************************************************
 * 函数名称: BspPaptIsTransceiverChnlUsed(*)
 * 功能描述: 查询Transceiver的指定通道是否使用
 * 输入参数: chipId：芯片片号
 * 输入参数: transChn：芯片内部通道号
 * 输出参数: 无
 * 返 回 值: BSP_OK- 正常
 *           BSP_ERROR- 异常
 * 其它说明: 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10248577@2021-08-20, 创建
 *----------------------------------------------------------------------------
 */
UINT32 BspPaptIsTransceiverChnlUsed(UINT32 chipId, UINT32 transChn)
{
    if(chipId >= PAPT_SUPPORT_TRANS_MAX || transChn >= PAPT_TRANS_CHN_MAX_NUM)
    {
        return BSP_ERROR;
    }
    
    if(BIT_VAL((s_BufTransPaProAlmPara[chipId].transUsedChnMask), transChn))
    {
        return BSP_OK;
    }

    return BSP_ERROR;
}

/*****************************************************************************
 * 函数名称: BspSetPaptJ204PairEndsInfo(*)
 * 功能描述: J204建链分组信息设置
 * 输入参数: T_J204PairEndsInfo - J204建链分组信息
 * 输出参数: 无
 * 返 回 值: BSP_OK- 正常
 *           BSP_ERROR- 异常
 * 其它说明: 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10248577@2021-08-20, 创建
 *----------------------------------------------------------------------------
 */
UINT32 BspPaptSetJ204PairEndsInfo(T_J204PairEndsInfo *pInfo)
{
    memcpy_s(&s_204PairEndsInfo, sizeof(T_J204PairEndsInfo), pInfo, sizeof(T_J204PairEndsInfo));
    return BSP_OK;
}

/*****************************************************************************
 * 函数名称: BspGetPaptJ204PairEndsInfo(*)
 * 功能描述: 获取J204建链分组信息
 * 输入参数: 无
 * 输出参数: J204建链分组信息
 * 返 回 值: BSP_OK- 正常
 *           BSP_ERROR- 异常
 * 其它说明: 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10248577@2021-08-20, 创建
 *----------------------------------------------------------------------------
 */
T_J204PairEndsInfo* BspPaptGetJ204PairEndsInfo(VOID)
{
    return &s_204PairEndsInfo;
}

/*****************************************************************************
 * 函数名称: BspPaptGetJ204TransEndsInfo(*)
 * 功能描述: 获取指定transceiver片号对应的分组Transceiver片号掩码
 * 输入参数: 无
 * 输出参数: J204建链分组信息
 * 返 回 值: BSP_OK- 正常
 *           BSP_ERROR- 异常
 * 其它说明: 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10248577@2021-08-20, 创建
 *----------------------------------------------------------------------------
 */
UINT32 BspPaptGetJ204TransEndsInfo(UINT32 chipIdMask)
{
    UINT32 loop = 0;
    for(loop=0; loop<J204_PAIRS_NUM_MAX; loop++)
    {
        if(chipIdMask & s_204PairEndsInfo.onePairEnds[loop].transIdMask)
        {
            return s_204PairEndsInfo.onePairEnds[loop].transIdMask;
        }
    }
    return 0;    
}

/*****************************************************************************
 * 函数名称: BspPaptGetJ204TransEndsInfo(*)
 * 功能描述: 获取指定transceiver片号掩码对应的分组Transceiver片号掩码
 * 输入参数: 无
 * 输出参数: J204建链分组信息
 * 返 回 值: BSP_OK- 正常
 *           BSP_ERROR- 异常
 * 其它说明: 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10248577@2021-08-20, 创建
 *----------------------------------------------------------------------------
 */
UINT32 BspPaptGetJ204DpdicEndsInfo(UINT32 chipIdMask)
{
    UINT32 loop = 0;
    for(loop=0; loop<J204_PAIRS_NUM_MAX; loop++)
    {
        if(chipIdMask & s_204PairEndsInfo.onePairEnds[loop].transIdMask)
        {
            return s_204PairEndsInfo.onePairEnds[loop].dpdicGrpMask;
        }
    }
    return 0;
}

/*****************************************************************************
 * 函数名称: BspPaptJ204LinkPreStep(*)
 * 功能描述: J204告警恢复处理接口
 * 输入参数: chipIdMask - transceiver片号掩码
 * 输出参数: 无
 * 返 回 值: BSP_OK- 正常
 *           BSP_ERROR- 异常
 * 其它说明: 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10248577@2021-08-20, 创建
 *----------------------------------------------------------------------------
 */
UINT32 BspPaptJ204LinkPreStep(UINT32 chipIdMask)
{
    if(NULL == pFuncJ204LinkPreStep)
    {
        return BSP_ERROR;
    }
    return (*pFuncJ204LinkPreStep)(chipIdMask);
}

/*****************************************************************************
 * 函数名称: BspPaptJ204LinkPostStep(*)
 * 功能描述: J204告警恢复处理接口
 * 输入参数: chipIdMask - transceiver片号掩码
 * 输出参数: 无
 * 返 回 值: BSP_OK- 正常
 *           BSP_ERROR- 异常
 * 其它说明: 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10248577@2021-08-20, 创建
 *----------------------------------------------------------------------------
 */
UINT32 BspPaptJ204LinkPostStep(UINT32 chipIdMask)
{
    if(NULL == pFuncJ204LinkPostStep)
    {
        return BSP_ERROR;
    }
    return (*pFuncJ204LinkPostStep)(chipIdMask);    
}

/*****************************************************************************
 * 函数名称: BspPaptJ204SendSysref(*)
 * 功能描述: J204 Sysref信号发送接口
 * 输入参数: chipIdMask - transceiver片号掩码
 * 输出参数: 无
 * 返 回 值: BSP_OK- 正常
 *           BSP_ERROR- 异常
 * 其它说明: 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10248577@2021-08-20, 创建
 *----------------------------------------------------------------------------
 */
UINT32 BspPaptJ204SendSysref(UINT32 chipIdMask, UINT32 num)
{
    if(NULL == pFuncJ204LinkSendSysref)
    {
        return BSP_ERROR;
    }
    return (*pFuncJ204LinkSendSysref)(chipIdMask, num);     
}

/*****************************************************************************
 * 函数名称: BspPaptSetJ204LinkPreFunc(*)
 * 功能描述: 挂接J204告警恢复处理接口
 * 输入参数: pFunc - 函数名
 * 输出参数: 无
 * 返 回 值: BSP_OK- 正常
 *           BSP_ERROR- 异常
 * 其它说明: 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10248577@2021-08-20, 创建
 *----------------------------------------------------------------------------
 */
UINT32 BspPaptSetJ204LinkPreFunc(FUNC_PAPT_J204_LINK_BUILD pFunc)
{
    if(NULL == pFunc)
    {
        return BSP_ERROR;
    }
    pFuncJ204LinkPreStep = pFunc;
    return BSP_OK;
}

/*****************************************************************************
 * 函数名称: BspPaptSetJ204LinkPostFunc(*)
 * 功能描述: 挂接J204告警恢复处理接口
 * 输入参数: pFunc - 函数名
 * 输出参数: 无
 * 返 回 值: BSP_OK- 正常
 *           BSP_ERROR- 异常
 * 其它说明: 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10248577@2021-08-20, 创建
 *----------------------------------------------------------------------------
 */
UINT32 BspPaptSetJ204LinkPostFunc(FUNC_PAPT_J204_LINK_BUILD pFunc)
{
    if(NULL == pFunc)
    {
        return BSP_ERROR;
    }
    pFuncJ204LinkPostStep = pFunc;
    return BSP_OK;
}

/*****************************************************************************
 * 函数名称: BspPaptSetJ204SendSysrefFunc(*)
 * 功能描述: 挂接J204 sysref信号发送接口
 * 输入参数: pFunc - 函数名
 * 输出参数: 无
 * 返 回 值: BSP_OK- 正常
 *           BSP_ERROR- 异常
 * 其它说明: 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10248577@2021-08-20, 创建
 *----------------------------------------------------------------------------
 */
UINT32 BspPaptSetJ204SendSysrefFunc(FUNC_PAPT_J204_SYSREF_SEND pFunc)
{
    if(NULL == pFunc)
    {
        return BSP_ERROR;
    }
    pFuncJ204LinkSendSysref = pFunc;
    return BSP_OK;
}

/*****************************************************************************
 * 函数名称: BspPaptSetJ204RwAddrDifCheckFunc(*)
 * 功能描述: 挂接J204读写地址冲突检查接口
 * 输入参数: pFunc - 函数名
 * 输出参数: 无
 * 返 回 值: BSP_OK- 正常
 *           BSP_ERROR- 异常
 * 其它说明: 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10248577@2021-08-20, 创建
 *----------------------------------------------------------------------------
 */
UINT32 BspPaptSetJ204RwAddrDifCheckFunc(FUNC_PAPT_J204_RWADDRDIF_CHECK pFunc)
{
    if(NULL == pFunc)
    {
        return BSP_ERROR;
    }
    pFuncJ204RwAddrDifCheck = pFunc;
    return BSP_OK;
}

/*****************************************************************************
 * 函数名称: BspPaptSetJ204RwAddrDifRecoverFunc(*)
 * 功能描述: 挂接J204读写地址冲突恢复接口
 * 输入参数: pFunc - 函数名
 * 输出参数: 无
 * 返 回 值: BSP_OK- 正常
 *           BSP_ERROR- 异常
 * 其它说明: 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10248577@2021-08-20, 创建
 *----------------------------------------------------------------------------
 */
UINT32 BspPaptSetJ204RwAddrDifRecoverFunc(FUNC_PAPT_J204_RWADDRDIF_RECOVER pFunc)
{
    if(NULL == pFunc)
    {
        return BSP_ERROR;
    }
    pFuncJ204RwAddrDifRecover = pFunc;
    return BSP_OK;
}

/*****************************************************************************
 * 函数名称: BspPaptGetTransChipNums(*)
 * 功能描述: 获取transceiver片数
 * 输入参数: 无
 * 输出参数: transceiver片数
 * 返 回 值: BSP_OK- 正常
 *           BSP_ERROR- 异常
 * 其它说明: 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10248577@2021-08-20, 创建
 *----------------------------------------------------------------------------
 */
UINT32 BspPaptGetTransChipNums(VOID)
{
    return GetTransceiverChipNum();
}

/*****************************************************************************
 * 函数名称: BspSetGetPaProAlmFunc(*)
 * 功能描述: 挂接Transceiver告警上报具体实现接口
 * 输入参数: pFunc - 函数名
 * 输出参数: 无
 * 返 回 值: BSP_OK- 正常
 *           BSP_ERROR- 异常
 * 其它说明: 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10248577@2021-08-20, 创建
 *----------------------------------------------------------------------------
 */
UINT32 BspSetGetPaProAlmFunc(E_PaProType ePaProType, FUNC_GET_PAST_PRO_ALM pFunc)
{
    if(NULL == pFunc)
    {
        return BSP_ERROR;
    }
    s_PaProAlmPara[ePaProType].pFuncGetPastProAlm = pFunc;
    return BSP_OK;
}

/*****************************************************************************
 * 函数名称: BspSetGetPaProAlmFunc(*)
 * 功能描述: 挂接Transceiver告警上报具体实现接口
 * 输入参数: pFunc - 函数名
 * 输出参数: 无
 * 返 回 值: BSP_OK- 正常
 *           BSP_ERROR- 异常
 * 其它说明: 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10248577@2021-08-20, 创建
 *----------------------------------------------------------------------------
 */
UINT32 BspSetPaProAlmRecoverFunc(E_PaProType ePaProType, FUNC_PA_PRO_ALM_RECOVER pFunc)
{
    if(NULL == pFunc)
    {
        return BSP_ERROR;
    }
    s_PaProAlmPara[ePaProType].pFuncPaProAlmRecover = pFunc;
    return BSP_OK;
}

/*****************************************************************************
 * 函数名称: BspSetTransGetPaProAlmFunc(*)
 * 功能描述: 挂接Transceiver告警上报具体实现接口
 * 输入参数: pFunc - 函数名
 * 输出参数: 无
 * 返 回 值: BSP_OK- 正常
 *           BSP_ERROR- 异常
 * 其它说明: 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10248577@2021-08-20, 创建
 *----------------------------------------------------------------------------
 */
UINT32 BspSetTransGetPaProAlmFunc(UINT32 deviceType, FUNC_TRANS_GET_PAST_PRO_ALM pFunc)
{
    if(NULL == pFunc)
    {
        return BSP_ERROR;
    }
    s_TransPaProAlmPara[deviceType].pFuncTransGetPastPrmAlm = pFunc;
    return BSP_OK;
}

/*****************************************************************************
 * 函数名称: BspSetTransClrPaProAlmFunc(*)
 * 功能描述: 挂接Transceiver告警清除具体实现接口
 * 输入参数: pFunc - 函数名
 * 输出参数: 无
 * 返 回 值: BSP_OK- 正常
 *           BSP_ERROR- 异常
 * 其它说明: 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10248577@2021-08-20, 创建
 *----------------------------------------------------------------------------
 */
UINT32 BspSetTransClrPaProAlmFunc(UINT32 deviceType, FUNC_TRANS_CLR_PAST_PRO_ALM pFunc)
{
    if(NULL == pFunc)
    {
        return BSP_ERROR;
    }
    s_TransPaProAlmPara[deviceType].pFuncTransClrPastPrmAlm = pFunc;
    return BSP_OK;
}

/*****************************************************************************
 * 函数名称: BspSetTransClrPaProAlmFunc(*)
 * 功能描述: 挂接Transceiver告警自救具体实现接口
 * 输入参数: pFunc - 函数名
 * 输出参数: 无
 * 返 回 值: BSP_OK- 正常
 *           BSP_ERROR- 异常
 * 其它说明: 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10248577@2021-08-20, 创建
 *----------------------------------------------------------------------------
 */
UINT32 BspSetTransPaProAlmRecoverFunc(UINT32 deviceType, FUNC_TRANS_PAST_PRO_ALM_RECOVER pFunc)
{
    if(NULL == pFunc)
    {
        return BSP_ERROR;
    }
    s_TransPaProAlmPara[deviceType].pFuncTransPastPrmAlmRecover = pFunc;
    return BSP_OK;
}

/*****************************************************************************
 * 函数名称: BspSetTransClrAlmAfterInitFunc(*)
 * 功能描述: 挂接Transceiver初始化后清除告警的具体实现接口
 * 输入参数: pFunc - 函数名
 * 输出参数: 无
 * 返 回 值: BSP_OK- 正常
 *           BSP_ERROR- 异常
 * 其它说明: 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10248577@2021-08-20, 创建
 *----------------------------------------------------------------------------
 */
UINT32 BspSetTransClrAlmAfterInitFunc(UINT32 deviceType, FUNC_TRANS_CLR_ALM_AFTER_INIT pFunc)
{
    if(NULL == pFunc)
    {
        return BSP_ERROR;
    }
    s_TransPaProAlmPara[deviceType].pFuncTransClrAlmAfterInit = pFunc;
    return BSP_OK;
}

/*****************************************************************************
 * 函数名称: BspSetDpdicPaptAlmClassifyMask(*)
 * 功能描述: 设置DPDIC功放保护告警分类的掩码(含光口、CFR、DPD等3个分类)
 * 输入参数: pClassifyMask - 告警分类掩码
 * 输出参数: 无
 * 返 回 值: BSP_OK- 正常
 *           BSP_ERROR- 异常
 * 其它说明: 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10248577@2024-02-23, 创建
 *----------------------------------------------------------------------------
 */
UINT32 BspSetDpdicPaptAlmClassifyMask(T_PaptAlmClassifyMask *pClassifyMask)
{
    INPUT_POINTER_CHECK(pClassifyMask);

    s_optPaptAlmPosEnMask = pClassifyMask->optPaptAlmPosEnMask;
    s_cfrPaptAlmPosEnMask = pClassifyMask->cfrPaptAlmPosEnMask;
    s_dpdPaptAlmPosEnMask = pClassifyMask->dpdPaptAlmPosEnMask;

    return BSP_OK;
}

/*****************************************************************************
 * 函数名称: BspSetTransJ204RebuildFunc(*)
 * 功能描述: 挂接Transceiver J204重新建链的具体实现接口
 * 输入参数: pFunc - 函数名
 * 输出参数: 无
 * 返 回 值: BSP_OK- 正常
 *           BSP_ERROR- 异常
 * 其它说明: 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10248577@2021-08-20, 创建
 *----------------------------------------------------------------------------
 */
UINT32 BspSetTransJ204RebuildFunc(UINT32 deviceType, FUNC_TRANS_J204_REBUILD pFunc)
{
    if(NULL == pFunc)
    {
        return BSP_ERROR;
    }
    s_TransPaProAlmPara[deviceType].pFuncTransJ204Rebuild = pFunc;
    return BSP_OK;    
}

/*****************************************************************************
 * 函数名称: BspSetSlaveGetPaProAlmFunc(*)
 * 功能描述: 挂接子端告警上报具体实现接口
 * 输入参数: pFunc - 函数名
 * 输出参数: 无
 * 返 回 值: BSP_OK- 正常
 *           BSP_ERROR- 异常
 * 其它说明: 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10248577@2021-08-20, 创建
 *----------------------------------------------------------------------------
 */
UINT32 BspSetSlaveGetPaProAlmFunc(FUNC_SLAVE_GET_PAST_PRO_ALM pFunc)
{
    if(NULL == pFunc)
    {
        return BSP_ERROR;
    }
    s_SlavePaProAlmPara.pFuncSlaveGetPastPrmAlm = pFunc;
    return BSP_OK;
}

/*****************************************************************************
 * 函数名称: BspSetTransPaProAlmRecoverFunc(*)
 * 功能描述: 挂接子端告警自救具体实现接口
 * 输入参数: pFunc - 函数名
 * 输出参数: 无
 * 返 回 值: BSP_OK- 正常
 *           BSP_ERROR- 异常
 * 其它说明: 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10248577@2021-08-20, 创建
 *----------------------------------------------------------------------------
 */
UINT32 BspSetSlavePaProAlmRecoverFunc(FUNC_SLAVE_PAST_PRO_ALM_RECOVER pFunc)
{
    if(NULL == pFunc)
    {
        return BSP_ERROR;
    }
    s_SlavePaProAlmPara.pFuncSlavePastPrmAlmRecover = pFunc;
    return BSP_OK;
}

/*****************************************************************************
 * 函数名称: BspPaptTransJ204Rebuild(*)
 * 功能描述: 对指定的Transceiver进行重新建链
 * 输入参数: chipId：片号
 * 输出参数: 无
 * 返 回 值: BSP_OK- 正常
 *           BSP_ERROR- 异常
 * 其它说明: 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10248577@2021-08-20, 创建
 *----------------------------------------------------------------------------
 */
UINT32 BspPaptTransJ204Rebuild(UINT32 chipId)
{
    UINT32 ulRetVal = BSP_OK;
    INT32 lRetVal = 0;

    echiptype deviceType = DEVICE_NUM; 
    FUNC_TRANS_J204_REBUILD pFunc = NULL;
    
    deviceType = GetTransDevTypeByChipId(chipId);
    if(DEVICE_NUM == deviceType)
    {
        dbgErr("%s>> deviceType error\n",__FUNCTION__);
        return BSP_ERROR;
    }
    
    pFunc = s_TransPaProAlmPara[deviceType].pFuncTransJ204Rebuild;
    if(NULL == pFunc)
    {
        dbgErr("%s>> pFunc is NULL\n",__FUNCTION__);
        return BSP_ERROR;
    }

    lRetVal = (*pFunc)(chipId);
    ulRetVal = ((0 == lRetVal)?BSP_OK:BSP_ERROR);

    dbgInfoEx("%s>> finished! chipId=%d \n", __FUNCTION__, chipId);

    return ulRetVal;
}

/*****************************************************************************
 * 函数名称: BspPerTransGetPastPaProAlm(*)
 * 功能描述: 获取Transceiver功放保护历史告警
 * 输入参数: ulAlmType    - 功放保护告警枚举类型
 * 输出参数: pu64EventBits - 功放保护告警子码
 * 返 回 值: 0- 正常, 其它值- 异常
 * 其它说明: 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10119095@2020-07-08, 创建
 *----------------------------------------------------------------------------
 */
UINT32 BspPerTransGetPastPaProAlm(UINT32 chipId, E_TRANS_PAPRO_ALM_TYPE ulAlmType, UINT64 *pu64EventBits)
{
    UINT32 ulRetVal = BSP_OK;
    INT32 lRetVal = 0;
    FUNC_TRANS_GET_PAST_PRO_ALM pFunc = NULL;
    echiptype deviceType = DEVICE_NUM; 

    if(chipId >= PAPT_SUPPORT_TRANS_MAX)
    {
        return BSP_ERROR;
    }

    if(NULL == s_BufTransPaProAlmPara[chipId].pFuncTransGetPastPrmAlm)
    {
        deviceType = GetTransDevTypeByChipId(chipId);
        if(DEVICE_NUM == deviceType)
        {
            dbgErr("%s>> deviceType error\n",__FUNCTION__);
            return BSP_ERROR;
        }
        s_BufTransPaProAlmPara[chipId].pFuncTransGetPastPrmAlm = s_TransPaProAlmPara[deviceType].pFuncTransGetPastPrmAlm;
    }
    pFunc = s_BufTransPaProAlmPara[chipId].pFuncTransGetPastPrmAlm;
    if(NULL == pFunc)
    {
        dbgInfoEx("%s>> pFunc is NULL\n",__FUNCTION__);
        return BSP_ERROR;
    }

    lRetVal = (*pFunc)(chipId, ulAlmType, pu64EventBits);
    ulRetVal = ((0 == lRetVal)?BSP_OK:BSP_ERROR);

    dbgInfoEx("%s>> finished! chipId=%d ulAlmType=%d eventBits=0x%llx\n", __FUNCTION__, chipId, ulAlmType, *pu64EventBits);

    return ulRetVal;
}

/*****************************************************************************
 * 函数名称: BspPerTransClrPaProPastAlm(*)
 * 功能描述: Transceiver功放保护历史告警清除
 * 输入参数: ePaAlmType - 功放保护告警枚举类型
 * 输出参数: 无
 * 返 回 值: 0- 正常, 其它值- 异常
 * 其它说明: 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10119095@2020-07-08, 创建
 *----------------------------------------------------------------------------
 */
UINT32 BspPerTransClrPaProPastAlm(UINT32 chipId, E_TRANS_PAPRO_ALM_TYPE ulAlmType)
{
    UINT32 ulRetVal = BSP_OK;
    INT32 lRetVal = 0;
    FUNC_TRANS_CLR_PAST_PRO_ALM pFunc = NULL;
    echiptype deviceType = DEVICE_NUM;

    if(chipId >= PAPT_SUPPORT_TRANS_MAX)
    {
        return BSP_ERROR;
    }

    if(NULL == s_BufTransPaProAlmPara[chipId].pFuncTransClrPastPrmAlm)
    {
        deviceType = GetTransDevTypeByChipId(chipId);
        if(DEVICE_NUM == deviceType)
        {
            dbgErr("%s>> deviceType error\n",__FUNCTION__);
            return BSP_ERROR;
        }
        s_BufTransPaProAlmPara[chipId].pFuncTransClrPastPrmAlm = s_TransPaProAlmPara[deviceType].pFuncTransClrPastPrmAlm;
    }
    pFunc = s_BufTransPaProAlmPara[chipId].pFuncTransClrPastPrmAlm;
    if(NULL == pFunc)
    {
        dbgInfoEx("%s>> pFunc is NULL\n",__FUNCTION__);
        return BSP_ERROR;
    }

    lRetVal = (*pFunc)(chipId, ulAlmType);
    ulRetVal = ((0 == lRetVal)?BSP_OK:BSP_ERROR);

    dbgInfoEx("%s>> finished! chipId=%d ulAlmType=%d\n", __FUNCTION__, chipId, ulAlmType);

    return ulRetVal;
}

/*****************************************************************************
 * 函数名称: BspPerTransPaProAlmRecover(*)
 * 功能描述: Transceiver功放保护告警后处理
 * 输入参数: ePaProAlmType  - PA告警保护类型;
 *           u64AlmBitsMask - 告警EventBitsMask
 * 输出参数: 无
 * 返 回 值: 0- 正常或无后处理操作正常, 负值- 后处理操作异常, 正值- 表示有后处理操作
 * 其它说明: 修复优先级：ARM/PLL时钟类>> 204类>> serdes类>> Tx链路类
 *           优先级高的告警处理完毕无告警后, 再处理下一级
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10119095@2020-07-14, 创建
 *----------------------------------------------------------------------------
 */
INT32 BspPerTransPaProAlmRecover(UINT32 chipId, E_TRANS_PAPRO_ALM_TYPE ulAlmType, UINT64 u64AlmBitsMask)
{
    //UINT32 ulRetVal = BSP_OK;
    INT32 lRetVal = 0;
    FUNC_TRANS_PAST_PRO_ALM_RECOVER pFunc = NULL;
    echiptype deviceType = DEVICE_NUM;

    if(chipId >= PAPT_SUPPORT_TRANS_MAX)
    {
        return PAPT_RECOVER_ERR;
    }

    if(NULL == s_BufTransPaProAlmPara[chipId].pFuncTransPastPrmAlmRecover)
    {
        deviceType = GetTransDevTypeByChipId(chipId);
        if(DEVICE_NUM == deviceType)
        {
            dbgErr("%s>> deviceType error\n",__FUNCTION__);
            return PAPT_RECOVER_ERR;
        }
        s_BufTransPaProAlmPara[chipId].pFuncTransPastPrmAlmRecover = s_TransPaProAlmPara[deviceType].pFuncTransPastPrmAlmRecover;
    }
    pFunc = s_BufTransPaProAlmPara[chipId].pFuncTransPastPrmAlmRecover;
    if(NULL == pFunc)
    {
        dbgInfoEx("%s>> pFunc is NULL\n",__FUNCTION__);
        return PAPT_RECOVER_ERR;
    }

    lRetVal = (*pFunc)(chipId, ulAlmType, u64AlmBitsMask);
    //ulRetVal = ((0 == lRetVal)?BSP_OK:BSP_ERROR);

    dbgInfoEx("%s>> finished! chipId=%d ulAlmType=%d u64AlmBitsMask=0x%llx ret=%d\n", 
            __FUNCTION__, chipId, ulAlmType,u64AlmBitsMask,lRetVal);

    return lRetVal;
}

/*****************************************************************************
 * 函数名称: BspPerTransClrAlmAfterInit(*)
 * 功能描述: Transceiver功放保护告警后处理
 * 输入参数: ePaProAlmType  - PA告警保护类型;
 *           u64AlmBitsMask - 告警EventBitsMask
 * 输出参数: 无
 * 返 回 值: 0- 正常或无后处理操作正常, 负值- 后处理操作异常, 正值- 表示有后处理操作
 * 其它说明: 修复优先级：ARM/PLL时钟类>> 204类>> serdes类>> Tx链路类
 *           优先级高的告警处理完毕无告警后, 再处理下一级
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10119095@2020-07-14, 创建
 *----------------------------------------------------------------------------
 */
UINT32 BspPerTransClrAlmAfterInit(UINT32 chipId)
{
    UINT32 ulRetVal = BSP_OK;
    INT32 lRetVal = 0;
    FUNC_TRANS_CLR_ALM_AFTER_INIT pFunc = NULL;
    echiptype deviceType = DEVICE_NUM; 

    if(chipId >= PAPT_SUPPORT_TRANS_MAX)
    {
        return BSP_ERROR;
    }

    if(NULL == s_BufTransPaProAlmPara[chipId].pFuncTransClrAlmAfterInit)
    {
        deviceType = GetTransDevTypeByChipId(chipId);
        if(DEVICE_NUM == deviceType)
        {
            dbgErr("%s>> deviceType error\n",__FUNCTION__);
            return BSP_ERROR;
        }
        s_BufTransPaProAlmPara[chipId].pFuncTransClrAlmAfterInit = s_TransPaProAlmPara[deviceType].pFuncTransClrAlmAfterInit;
    }
    pFunc = s_BufTransPaProAlmPara[chipId].pFuncTransClrAlmAfterInit;
    if(NULL == pFunc)
    {
        dbgErr("%s>> pFunc is NULL\n",__FUNCTION__);
        return BSP_ERROR;
    }

    lRetVal = (*pFunc)(chipId);
    ulRetVal = ((0 == lRetVal)?BSP_OK:BSP_ERROR);

    dbgInfoEx("%s>> finished! chipId=%d\n", __FUNCTION__, chipId);

    return ulRetVal;

}

static UINT32 GetTransAlmTypeAndChipId(E_PaProType ePaProType, UINT32 *pChipId, E_TRANS_PAPRO_ALM_TYPE *pAlmType)
{
    E_TRANS_PAPRO_ALM_TYPE alarmType = 0;
    UINT32 ulChipId = 0;
    UINT32 ulRetVal = BSP_OK;
    
    switch (ePaProType)
    {
        case E_PA_PRO_TYPE_TRSV_MCUPLL0:
        case E_PA_PRO_TYPE_TRSV_MCUPLL1:
        case E_PA_PRO_TYPE_TRSV_MCUPLL2:
        case E_PA_PRO_TYPE_TRSV_MCUPLL3:
        case E_PA_PRO_TYPE_TRSV_MCUPLL4:
        case E_PA_PRO_TYPE_TRSV_MCUPLL5:
        case E_PA_PRO_TYPE_TRSV_MCUPLL6:
        case E_PA_PRO_TYPE_TRSV_MCUPLL7:            
            ulChipId = ePaProType - E_PA_PRO_TYPE_TRSV_MCUPLL0;
            alarmType = TRANS_MCU_PLL_PAPRO_ALMTYPE;
            break;
        case E_PA_PRO_TYPE_TRSV_J204BC0:
        case E_PA_PRO_TYPE_TRSV_J204BC1:
        case E_PA_PRO_TYPE_TRSV_J204BC2:
        case E_PA_PRO_TYPE_TRSV_J204BC3:
        case E_PA_PRO_TYPE_TRSV_J204BC4:
        case E_PA_PRO_TYPE_TRSV_J204BC5:
        case E_PA_PRO_TYPE_TRSV_J204BC6:
        case E_PA_PRO_TYPE_TRSV_J204BC7:            
            ulChipId = ePaProType - E_PA_PRO_TYPE_TRSV_J204BC0;
            alarmType = TRANS_J204BC_PAPRO_ALMTYPE;;
            break;
        case E_PA_PRO_TYPE_TRSV_SERDES0:
        case E_PA_PRO_TYPE_TRSV_SERDES1:
        case E_PA_PRO_TYPE_TRSV_SERDES2:
        case E_PA_PRO_TYPE_TRSV_SERDES3:
        case E_PA_PRO_TYPE_TRSV_SERDES4:
        case E_PA_PRO_TYPE_TRSV_SERDES5:
        case E_PA_PRO_TYPE_TRSV_SERDES6:
        case E_PA_PRO_TYPE_TRSV_SERDES7:            
            ulChipId = ePaProType - E_PA_PRO_TYPE_TRSV_SERDES0;
            alarmType = TRANS_SERDES_PAPRO_ALMTYPE;
            break;
        case E_PA_PRO_TYPE_TRSV_OUTBUF0:
        case E_PA_PRO_TYPE_TRSV_OUTBUF1:
        case E_PA_PRO_TYPE_TRSV_OUTBUF2:
        case E_PA_PRO_TYPE_TRSV_OUTBUF3:
        case E_PA_PRO_TYPE_TRSV_OUTBUF4:
        case E_PA_PRO_TYPE_TRSV_OUTBUF5:
        case E_PA_PRO_TYPE_TRSV_OUTBUF6:
        case E_PA_PRO_TYPE_TRSV_OUTBUF7:            
            ulChipId = ePaProType - E_PA_PRO_TYPE_TRSV_OUTBUF0;
            alarmType = TRANS_OUTBUF_PAPRO_ALMTYPE;
            break;
        case E_PA_PRO_TYPE_TRSV_PWRERR0:
        case E_PA_PRO_TYPE_TRSV_PWRERR1:
        case E_PA_PRO_TYPE_TRSV_PWRERR2:
        case E_PA_PRO_TYPE_TRSV_PWRERR3:
        case E_PA_PRO_TYPE_TRSV_PWRERR4:
        case E_PA_PRO_TYPE_TRSV_PWRERR5:
        case E_PA_PRO_TYPE_TRSV_PWRERR6:
        case E_PA_PRO_TYPE_TRSV_PWRERR7:            
            ulChipId = ePaProType - E_PA_PRO_TYPE_TRSV_PWRERR0;
            alarmType = TRANS_PWRERR_PAPRO_ALMTYPE;
            break;
        case E_PA_PRO_TYPE_TRSV_OTHERS0:
        case E_PA_PRO_TYPE_TRSV_OTHERS1:
        case E_PA_PRO_TYPE_TRSV_OTHERS2:
        case E_PA_PRO_TYPE_TRSV_OTHERS3:
        case E_PA_PRO_TYPE_TRSV_OTHERS4:
        case E_PA_PRO_TYPE_TRSV_OTHERS5:
        case E_PA_PRO_TYPE_TRSV_OTHERS6:
        case E_PA_PRO_TYPE_TRSV_OTHERS7:            
            ulChipId = ePaProType - E_PA_PRO_TYPE_TRSV_OTHERS0;
            alarmType = TRANS_OTHERS_PAPRO_ALMTYPE;
            break;
        default:
            ulRetVal = BSP_ERROR;
            break;
    }    

    *pChipId = ulChipId;
    *pAlmType = alarmType;

    return ulRetVal;
}

/*****************************************************************************
 * 函数名称: BspTransceiverGetPastPaProAlm(*)
 * 功能描述: 获取Transceiver功放保护历史告警
 * 输入参数: ePaAlmType    - 功放保护告警枚举类型
 * 输出参数: pu64EventBits - 功放保护告警子码
 * 返 回 值: 0- 正常, 其它值- 异常
 * 其它说明: 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10119095@2020-07-08, 创建
 *----------------------------------------------------------------------------
 */
UINT32 BspTransceiverGetPastPaProAlm(E_PaProType ePaProType, UINT64 *pu64EventBits)
{
    UINT32 chipId = 0;
    UINT32 ulRetVal = 0;
    E_TRANS_PAPRO_ALM_TYPE almType = 0;
    unsigned long long tick1,tick2,tick3,tick4 = 0;
    
    ulRetVal = GetTransAlmTypeAndChipId(ePaProType, &chipId, &almType);
    if(BSP_OK != ulRetVal)
    {
        return BSP_ERROR;
    }

    /* 对于超出片号范围的告警，直接返回不支持 */
    if(chipId >= BspPaptGetTransChipNums())
    {
        return PAPT_NOT_SUPPORT_ALM;
    }

    tick1 = tick64Get();
    ulRetVal = BspPerTransGetPastPaProAlm(chipId, almType, pu64EventBits);

    tick2 = tick64Get();
    dbgInfoEx("[%s] :BspTransceiverGetPastPaProAlm %llu * 10ms \r\n", __FUNCTION__,(tick2-tick1));
    tick3 = tick64Get();
    dbgInfoEx("[%s] :dbginfo kill time %llu * 10ms \r\n", __FUNCTION__,(tick3-tick2));
    BspPerTransClrPaProPastAlm(chipId, almType); /* 读后清除 ??? */
    tick4 = tick64Get();
    dbgInfoEx("[%s] :BspTransceiverClrPaProPastAlm %llu * 10ms, PaProType : %d  \r\n", __FUNCTION__, (tick4-tick3),ePaProType);

    return ulRetVal;
}

/*****************************************************************************
 * 函数名称: BspTransceiverPaProAlmRecover(*)
 * 功能描述: 获取Transceiver功放保护历史告警
 * 输入参数: ePaProType    - 功放保护告警枚举类型
 * 输出参数: pu64EventBits - 功放保护告警子码
 * 返 回 值: 0- 正常或无后处理操作正常, 负值- 后处理操作异常, 正值- 表示有后处理操作进行中
 * 其它说明: 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10119095@2020-07-08, 创建
 *----------------------------------------------------------------------------
 */
INT32 BspTransceiverPaProAlmRecover(E_PaProType ePaProType, UINT64 u64AlmBitsMask)
{
    UINT32 chipId = 0;
    INT32 lRetVal = 0;
    E_TRANS_PAPRO_ALM_TYPE almType = 0; 

    if(BSP_OK != GetTransAlmTypeAndChipId(ePaProType, &chipId, &almType))
    {
        return PAPT_RECOVER_ERR;
    }

    /* 对于超出片号范围的告警，直接返回不支持 */
    if(chipId >= BspPaptGetTransChipNums())
    {
        return PAPT_NOT_SUPPORT_ALM;
    }

    lRetVal = BspPerTransPaProAlmRecover(chipId, almType, u64AlmBitsMask);
    return lRetVal;
}

/*****************************************************************************
 * 函数名称: BspTransceiverClrAlmAfterInit(*)
 * 功能描述: 获取Transceiver功放保护历史告警
 * 输入参数: ePaAlmType    - 功放保护告警枚举类型
 * 输出参数: pu64EventBits - 功放保护告警子码
 * 返 回 值: 0- 正常, 其它值- 异常
 * 其它说明: 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10119095@2020-07-08, 创建
 *----------------------------------------------------------------------------
 */
UINT32 BspTransceiverClrAlmAfterInit(VOID)
{
    UINT32 chip = 0;
    static UINT32 chipNum = 0;
    UINT32 retVal = BSP_OK;

    if(0 == chipNum)
    {
        chipNum = GetTransceiverChipNum();
    }

    for(chip=0; chip<chipNum; chip++)
    {
        retVal |= BspPerTransClrAlmAfterInit(chip);
    }

    return retVal;
}

/*****************************************************************************
 * 函数名称: BspSetTransPaProAlmFlagByChip(*)
 * 功能描述: 提供给各Transceiver告警上报接口使用，更新告警记录用
 * 输入参数: chipId - Transceiver芯片号
 *           ulAlmType  - 告警类型，见E_J204_TRANS_PAPT_ALM_FLAG定义
 *           ulAlmFlag - 1:有告警/0:无告警
 * 输出参数: 无
 * 返 回 值: BSP_OK- 正常
 *           BSP_ERROR- 异常
 * 其它说明: 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10248577@2021-08-20, 创建
 *----------------------------------------------------------------------------
 */
UINT32 BspSetTransPaProAlmFlagByChip(UINT32 chipId, UINT32 ulAlmType, UINT32 ulAlmFlag)
{
    UINT32 ulBitsOff = 0;

    if ((chipId     >= (UINT32)PAPT_SUPPORT_TRANS_MAX)      ||
        (ulAlmType  >= (UINT32)TRANS_PAPRO_ALM_TYPE_MAX))
    {
        dbgErr("%s>>Error! ParamOver; ChipId= %d, AlmType= %d\n",
               __FUNCTION__, chipId, ulAlmType);
        return BSP_ERROR;
    }

    ulBitsOff = (UINT32)(chipId * (UINT32)PAPT_TRANS_CHN_MAX_NUM);
    if (ulAlmFlag > (UINT32)0)
    {
        s_ulTransPaProAlmFlag[ulAlmType] |= (UINT64)0xFF << ulBitsOff;
    }
    else
    {
        s_ulTransPaProAlmFlag[ulAlmType] &= ~((UINT64)0xFF << ulBitsOff);
    }

    dbgInfoEx("%s>>Trans'%d AlmIdx'%d TrsvChnl'%d BitOff'%2d: SetAlmFlag= 0x%08llX\n", __FUNCTION__,
              chipId, ulAlmType, 255, ulBitsOff, s_ulTransPaProAlmFlag[ulAlmType]);
    return BSP_OK;
}

/*****************************************************************************
 * 函数名称: BspSetTransPaProAlmFlagByChn(*)
 * 功能描述: 提供给各Transceiver告警上报接口使用，更新告警记录用
 * 输入参数: chipId - Transceiver芯片号
 *           ulTransChn  - Transceiver内部通道号
 *           ulAlmType  - 告警类型，见E_J204_TRANS_PAPT_ALM_FLAG定义
 *           ulAlmFlag - 1:有告警/0:无告警
 * 输出参数: 无
 * 返 回 值: BSP_OK- 正常
 *           BSP_ERROR- 异常
 * 其它说明: 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10248577@2021-08-20, 创建
 *----------------------------------------------------------------------------
 */
UINT32 BspSetTransPaProAlmFlagByChn(UINT32 chipId, UINT32 ulTransChn, UINT32 ulAlmType, UINT32 ulAlmFlag)
{
    UINT32 ulBitsOff = 0;

    if ((chipId     >= (UINT32)PAPT_SUPPORT_TRANS_MAX)      ||
        (ulTransChn >= (UINT32)PAPT_TRANS_CHN_MAX_NUM)        ||
        (ulAlmType  >= (UINT32)TRANS_PAPRO_ALM_TYPE_MAX))
    {
        dbgErr("%s>>Error! ParamOver; ChipId= %d, TransChn= %d, AlmType= %d\n",
               __FUNCTION__, chipId, ulTransChn, ulAlmType);
        return BSP_ERROR;
    }

    ulBitsOff = (UINT32)(chipId * (UINT32)PAPT_TRANS_CHN_MAX_NUM + ulTransChn);
    if (ulAlmFlag > (UINT32)0)
    {
        s_ulTransPaProAlmFlag[ulAlmType] |= ((UINT64)0x1<<ulBitsOff);
    }
    else
    {
        s_ulTransPaProAlmFlag[ulAlmType] &= (~((UINT64)0x1<<ulBitsOff));
    }
    dbgInfoEx("%s>>Trans'%d AlmIdx'%d TrsvChnl'%d BitOff'%2d: SetAlmFlag= 0x%08llX\n", __FUNCTION__,
              chipId, ulAlmType, ulTransChn, ulBitsOff, s_ulTransPaProAlmFlag[ulAlmType]);
    return BSP_OK;
}


/*****************************************************************************
 * 函数名称: BspSetDpdicPaProAlmFlag(*)
 * 功能描述: 提供给各Transceiver告警上报接口使用，更新告警记录用
 * 输入参数: chipId - Transceiver芯片号
 *           ulTransChn  - Transceiver内部通道号
 *           ulAlmType  - 告警类型，见E_J204_TRANS_PAPT_ALM_FLAG定义
 *           ulAlmFlag - 1:有告警/0:无告警
 * 输出参数: 无
 * 返 回 值: BSP_OK- 正常
 *           BSP_ERROR- 异常
 * 其它说明: 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10248577@2021-08-20, 创建
 *----------------------------------------------------------------------------
 */
UINT32 BspSetDpdicPaProAlmFlag(UINT32 ulAlmType, UINT32 bspChn, UINT32 ulAlmFlag)
{
    if ((bspChn     >= (UINT32)PAPT_SUPPORT_CHN_MAX)      ||
        (ulAlmType  >= (UINT32)DPDIC_PAPRO_ALM_TYPE_MAX))
    {
        dbgErr("%s>>Error! ParamOver; BspChn= %d, ulAlmType= %d\n",
               __FUNCTION__, bspChn, ulAlmType);
        return BSP_ERROR;
    }

    if (ulAlmFlag > (UINT32)0)
    {
        s_aulDpdicPastPaProAlmFlag[ulAlmType] |= ((UINT64)0x1<<bspChn);
    }
    else
    {
        s_aulDpdicPastPaProAlmFlag[ulAlmType] &= (~((UINT64)0x1<<bspChn));
    }
    dbgInfoEx("%s>>AlmIdx'%d BspChn'%d SetAlmFlag= 0x%08llX\n", __FUNCTION__,
              ulAlmType, bspChn, s_aulDpdicPastPaProAlmFlag[ulAlmType]);
    if(0 != ulAlmFlag)
    {
         BspLog(LOG_LEVEL_0, "%s>>AlmIdx'%d BspChn'%d SetAlmFlag= 0x%08llX\n", __FUNCTION__,
                  ulAlmType, bspChn, s_aulDpdicPastPaProAlmFlag[ulAlmType]);
    }

    return BSP_OK;
}

/*****************************************************************************
 * 函数名称: BspSetDpdicPaProAlmAllChn(*)
 * 功能描述: 提供给各DPDIC告警上报接口使用，更新告警记录用
 * 输入参数: ulAlmType  - DPDIC告警类型，不超过DPDIC_PAPRO_ALM_TYPE_MAX
 *           ulAlmEventBits - 所有通道的告警集合
 * 输出参数: 无
 * 返 回 值: BSP_OK- 正常
 *           BSP_ERROR- 异常
 * 其它说明: 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10248577@2021-08-20, 创建
 *----------------------------------------------------------------------------
 */
UINT32 BspSetDpdicPaProAlmAllChn(UINT32 ulAlmType, UINT64 ulAlmEventBits)
{
    if (ulAlmType  >= (UINT32)DPDIC_PAPRO_ALM_TYPE_MAX)
    {
        dbgErr("%s>>Error! ParamOver; ulAlmType= %d\n",
               __FUNCTION__, ulAlmType);
        return BSP_ERROR;
    }

    s_aulDpdicPastPaProAlmFlag[ulAlmType] = ulAlmEventBits;

    dbgInfoEx("%s>>AlmIdx'%d SetAlmFlag= 0x%08llX\n", __FUNCTION__,
              ulAlmType, s_aulDpdicPastPaProAlmFlag[ulAlmType]);
    return BSP_OK;
}

/*****************************************************************************
 * 函数名称: BspGetDpdicPaProAlmFlag(*)
 * 功能描述: 读取保存的DPDIC告警状态
 * 输入参数: ulAlmType  - 告警类型
 *           pUlAlmEventBits  - 保存的告警状态
 * 输出参数: 无
 * 返 回 值: BSP_OK- 正常
 *           BSP_ERROR- 异常
 * 其它说明: 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10248577@2021-08-20, 创建
 *----------------------------------------------------------------------------
 */
UINT32 BspGetDpdicPaProAlmFlag(UINT32 ulAlmType, UINT64 *pUlAlmEventBits)
{
    if (ulAlmType  >= (UINT32)DPDIC_PAPRO_ALM_TYPE_MAX)
    {
        dbgErr("%s>>Error! ParamOver; ulAlmType= %d\n",
               __FUNCTION__, ulAlmType);
        return BSP_ERROR;
    }

    *pUlAlmEventBits = s_aulDpdicPastPaProAlmFlag[ulAlmType];
    
    dbgInfoEx("%s>>AlmIdx'%d SetAlmFlag= 0x%08llX\n", __FUNCTION__,
              ulAlmType, *pUlAlmEventBits);
    return BSP_OK;    
}

/*****************************************************************************
 * 函数名称: BspSetSlavePaProAlmFlagByPortId(*)
 * 功能描述: 提供给各子端告警上报接口使用，更新告警记录用
 * 输入参数: portId - 子端编号
 *           ulAlmType  - 告警类型，见SLAVE_PAPRO_ALM_TYPE_MAX定义
 *           ulAlmFlag - 1:有告警/0:无告警
 * 输出参数: 无
 * 返 回 值: BSP_OK- 正常
 *           BSP_ERROR- 异常
 * 其它说明: 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10248577@2021-08-20, 创建
 *----------------------------------------------------------------------------
 */
UINT32 BspSetSlavePaProAlmFlagByPortId(UINT32 portId, UINT32 ulAlmType, UINT32 ulAlmFlag)
{
    if ((portId     >= (UINT32)MAX_SLAVE_PORT_NUM)      ||
        (ulAlmType  >= (UINT32)SLAVE_PAPRO_ALM_TYPE_MAX))
    {
        dbgErr("%s>>Error! ParamOver; portId= %d, AlmType= %d\n",
               __FUNCTION__, portId, ulAlmType);
        return BSP_ERROR;
    }

    if (ulAlmFlag > (UINT32)0)
    {
        s_ulSlavePaProAlmFlag[ulAlmType] |= (UINT64)0x1 << portId;   /*同一类告警每个子端占1bit*/
    }
    else
    {
        s_ulSlavePaProAlmFlag[ulAlmType] &= ~((UINT64)0x1 << portId);
    }

    dbgInfoEx("%s>>Trans'%d AlmIdx'%d TrsvChnl'%d : SetAlmFlag= 0x%08llX\n", __FUNCTION__,
        portId, ulAlmType, 255, s_ulSlavePaProAlmFlag[ulAlmType]);
    return BSP_OK;
}
/*****************************************************************************
 * 函数名称: BspGetPaProPastAlm(*)
 * 功能描述: 获取功放保护历史告警状态
 * 输入参数: ptPaProParam:
 *               ->ulPaProType - PA告警保护类型;
 *                   E_PA_PRO_TYPE_RFFPGA0_HARD: RfFpga硬件告警类型
 *                   E_PA_PRO_TYPE_TRSV_MCUPLL0: Transceiver芯片MCUPLL告警类型
 *               ->ulPaProMask - 获取告警状态的Mask标志,
 *                   0xFFFFFFFF: 获取所有标志的告警状态
 * 输出参数: ptPaProOutput:
 *               ->ulMainMixedFlag - 所有AlmMask位的或状态,
 *               ->ulSlaveMaskFlag - 各个功放保护的Mask告警状态,
 * 返 回 值: BSP_OK- 成功; 其他- 失败
 * 其它说明: 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10119095@2020-07-14, 创建
 *----------------------------------------------------------------------------
 */
UINT32 BspGetPaProPastAlm(T_PaProInputParam *ptPaProParam, T_PaProFlagOutput *ptPaProOutput) 
{
    UINT64 u64EventBit = 0;
    UINT32 ulTmpRet = BSP_OK;
    UINT32 ulRetVal = BSP_OK;
    E_PaProType ePaProType = 0;
    UINT32 ulDbgAlmIdx = 0;

    PARAM_POINTER_NULL_CHK_WITH_RET(BIT_SET(0), tPaProInputParam, ptPaProParam);
    PARAM_POINTER_NULL_CHK_WITH_RET(BIT_SET(1), tPaProFlagOutput, ptPaProOutput);

    /* 因为高层已调用该接口，未避免影响库上版本，待自测后再放开 */
    if(s_closePaptAlmReport)
    {
        ptPaProOutput->ulMainMixedFlag = 0;
        ptPaProOutput->ulSlaveMaskFlag = 0;
        return ulRetVal;
    }
    
    ePaProType = ptPaProParam->ulPaProType;
    if(ePaProType < APP_ALM_TYPE_MAX)
    {
        if(NULL != s_PaProAlmPara[(UINT32)ePaProType].pFuncGetPastProAlm)
        {
            ulTmpRet = s_PaProAlmPara[(UINT32)ePaProType].pFuncGetPastProAlm(ePaProType, &u64EventBit);
        }
        else 
        {
            ulTmpRet = BSP_ERROR; 
        }
    }
    else 
    {
        ulTmpRet = BSP_ERROR;   
    }

    if (BSP_OK == ulTmpRet)
    {
        ulRetVal = BSP_OK;
        ptPaProOutput->ulMainMixedFlag = !(!(u64EventBit));
        ptPaProOutput->ulSlaveMaskFlag = u64EventBit;
        /* 维测 */
        ulDbgAlmIdx = (ePaProType % APP_ALM_TYPE_MAX);
        if(ulDbgAlmIdx < APP_ALM_TYPE_MAX)
        {
            s_dbgPaptAppData[ulDbgAlmIdx].curSlaveMaskFlag = u64EventBit;
            if(u64EventBit)
            {
                s_dbgPaptAppData[ulDbgAlmIdx].lastValidSlaveMaskFlag = u64EventBit;
            }
        }
    }
    else
    {
        ulRetVal |= BIT_SET(2);
        /* 维测 */
        ulDbgAlmIdx = (ePaProType % APP_ALM_TYPE_MAX);
        if(ulDbgAlmIdx < APP_ALM_TYPE_MAX)
        {
            s_dbgPaptAppData[ulDbgAlmIdx].curSlaveMaskFlag = PAPT_INVALID_DATA_64;
        }
    }
    dbgInfoEx("%s>>PaProType'%d: AlmStatus= 0x%llX\n", __FUNCTION__, ePaProType, u64EventBit);
    if(0 != u64EventBit)
    {
       BspLog(LOG_LEVEL_0,"%s>>PaProType'%d: AlmStatus= 0x%llX\n", __FUNCTION__, ePaProType, u64EventBit);
    }
    return ulRetVal;
}


/*****************************************************************************
 * 函数名称: BspPaProAlmRecover(*)
 * 功能描述: Transceiver功放保护告警后处理
 * 输入参数: ulPaProAlmType  - PA告警保护类型;
 *           u64EventAlmMask - 告警EventBitsMask, 由BspGetPaProPastAlm输出传递
 * 输出参数: 无
 * 返 回 值: 0- 正常或无后处理操作正常, 负值- 后处理操作异常, 正值- 表示有后处理操作进行中
 * 其它说明: 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10119095@2020-07-14, 创建
 *----------------------------------------------------------------------------
 */
INT32 BspPaProAlmRecover(UINT32 ulPaProAlmType, UINT64 u64EventAlmMask)
{
    INT32  lFunRet = 0;
    E_PaProType ePaProAlmType = 0;
    UINT64 recordMask = u64EventAlmMask;

    /* 因为高层已调用该接口，未避免影响库上版本，待自测后再放开 */
    if(s_closePaptAlmReport)
    {
        return BSP_OK;;
    }

    ePaProAlmType = ulPaProAlmType;
    if(ePaProAlmType < APP_ALM_TYPE_MAX)
    {
        if(NULL != s_PaProAlmPara[(UINT32)ePaProAlmType].pFuncPaProAlmRecover)
        {
            lFunRet = s_PaProAlmPara[(UINT32)ePaProAlmType].pFuncPaProAlmRecover(ePaProAlmType, u64EventAlmMask);
        }
        else 
        {
            lFunRet = PAPT_NOT_SUPPORT_ALM; 
        }
    }
    else 
    {
        lFunRet = PAPT_NOT_SUPPORT_ALM;   
    }

    /* 维测 */
    if(ePaProAlmType < APP_ALM_TYPE_MAX)
    {
        s_dbgPaptAppData[(UINT32)ePaProAlmType].recoverEventAlmMask = recordMask;
    }
    
    return lFunRet;    
}

/*****************************************************************************
 * 函数名称: BspGetPaProtectAlmFlag(*)
 * 功能描述: BSP上报功放保护标志
 * 输入参数: ulBspChnl - BSP 通道号
 * 输出参数: pulPaProFlag - 功放保护标志: 0- 正常, 其它值- 功放保护
 * 返 回 值: 0x0 - 无功放保护告警，正常
 *           0x1 (bit0) - 光口类、时钟类功放保护告警
 *           0x2 (bit1) - 削峰前的均值功率保护告警
 *           0x4 (bit2) - DPD后的单点功率保护告警
 *           0x8 (bit3) - 其他类型功放保护，比如transceiver触发的保护、掉电告警保护等
 *           0x10(bit4) - 其他中频数据功放类（带外、DPD后均值）告警
 * 其它说明: 主控侧、DPDIC、MTS/AD9025等所有功放保护告警保护标志都通过此接口上报;
 *           用于高层APP功率检测、驻波检测、数模功率差告警、闭环功控等处理时检测
 *           调用; 目前只有MTS上报, 其它待补充;
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10119095@2020-07-08, 创建
 *----------------------------------------------------------------------------
 */
UINT32 BspGetPaProtectAlmFlag(UINT32 ulBspChnl, UINT32 *pulPaProFlag)
{
    INPUT_POINTER_CHECK(pulPaProFlag);

#if (defined (BSP_MAKE_VER) || defined (_BSP_WITH_WFS))
    *pulPaProFlag = 0;
    dbgInfo("%s>>Ver(Bsp Wfs) Not Support; return OK!\n", __FUNCTION__);

    return BSP_OK; /* 小版本和工装版本不支持 */
#else
    UINT32 ulLoopCnt = 0;
    UINT32 ulBspChnlSum = 0;
    UINT32 ulRfTrsvType = 0;
    UINT32 ulTrsvChipId = 0;
    UINT32 ulChnlOfChip = 0;
    UINT32 ulBitsOffset = 0;
    UINT64 ulPaProAlm = 0;

    UINT32 ulTmpRet = BSP_OK;
    UINT32 ulRetAlmStatus = BSP_OK;
    UINT32 ulLoopAlmType = 0;

    UINT64 ulOptPaProAlmFlag = 0;
    UINT64 ulOthersPaProAlmFlag = 0;
    UINT64 ulCfrPaProAlmFlag = 0;
    UINT64 ulDpdPaProAlmFlag = 0;
    UINT64 ulTransPaProAlmFlag = 0;
    UINT64 ulSlavePaProAlmFlag = 0;
    UINT64 ulSlavePowVaildFlag = 0;
    UINT32 retVal[PAPT_ALM_FLAG_MAX] = {0};
    UINT32 portId = 0;

    if(s_closePaptAlmReport)
    {
        *pulPaProFlag = 0;
        return BSP_OK;
    }

    ulBspChnlSum = BspGetTxChannel();
    if (ulBspChnl >= ulBspChnlSum)
    {
        *pulPaProFlag = 0;
        dbgErr("%s>>Error! Param Over; BspChnl(0~%d)= %d\n",
               __FUNCTION__, ulBspChnlSum - 1, ulBspChnl);
        return BSP_ERROR;
    }

    /* ================== DPDIC 功放保护告警标志 =================== */
    for (ulLoopCnt = 0; ulLoopCnt < DPDIC_PAPRO_ALM_TYPE_MAX; ulLoopCnt++)
    {
        ulPaProAlm = (s_aulDpdicPastPaProAlmFlag[ulLoopCnt] & BIT_SET(ulBspChnl));

        if(BIT_VAL(s_optPaptAlmPosEnMask,ulLoopCnt))            //21 23 24 光口告警
        {
            ulOptPaProAlmFlag |= ulPaProAlm;
        }
        else if(BIT_VAL(s_cfrPaptAlmPosEnMask,ulLoopCnt))       //13 削峰前功率告警
        {
            ulCfrPaProAlmFlag |= ulPaProAlm;
        }
        else if(BIT_VAL(s_dpdPaptAlmPosEnMask,ulLoopCnt))       //11 dpd后单点功率告警 10dpd后均值保护
        {
            ulDpdPaProAlmFlag |= ulPaProAlm;
        }
        else                                                    //其他的类型告警
        {
            if(DSP_POW_CALC_ALARM_SAVE_IDX == ulLoopCnt)
            {
                ulSlavePowVaildFlag |= ulPaProAlm;   /*9124 子端功率是否正常的标志*/
            }
            else
            {
                ulOthersPaProAlmFlag |= ulPaProAlm;
            }
        }
    }
    /* ============================================================= */

    /* ================= Transceiver功放保护告警标志 =============== */
    /* 获取BSP通道和 Transceiver芯片号芯片内通道的对应关系 */
    ulTmpRet = GetTransInfoByBspChan(ulBspChnl, &ulRfTrsvType, &ulTrsvChipId, &ulChnlOfChip);
    if (BSP_OK == ulTmpRet)
    {
        ulBitsOffset = ulTrsvChipId * PAPT_TRANS_CHN_MAX_NUM + ulChnlOfChip;
        for(ulLoopAlmType=0; ulLoopAlmType<TRANS_PAPRO_ALM_TYPE_MAX; ulLoopAlmType++)
        {
            ulTransPaProAlmFlag |= (s_ulTransPaProAlmFlag[ulLoopAlmType] & BIT_SET(ulBitsOffset));
        }
        dbgInfoEx("%s>>Chnl(Bsp'%2d) Trsv(Type'%3d Id'%d Chnl'%d): AlmFlag= 0x%08llX\n",
                  __FUNCTION__, ulBspChnl, ulRfTrsvType, ulTrsvChipId, ulChnlOfChip, ulTransPaProAlmFlag);
    }
    else
    {
     /* Trsv芯片识别异常, 不上报Trsv芯片告警保护标志;
        此处不直接返回BSP_OK, RFpga和IC告警继续上报 */
    //  return BSP_OK;
        dbgInfoEx("%s>>BspChnl'%2d TransceiverInfo Get Error!\n",
                  __FUNCTION__, ulBspChnl);
    }
    /* ============================================================= */
    if(LINK_REMOTE == BspIsRemoteSlaveChan(ulBspChnl, 1))   /*拉远通道才检测*/
    {
        BspGetPortIdByBspChn(ulBspChnl, TX, &portId);
        for(ulLoopCnt = 0; ulLoopCnt < SLAVE_PAPRO_ALM_TYPE_MAX; ulLoopCnt++)
        {
            ulSlavePaProAlmFlag |= (s_ulSlavePaProAlmFlag[ulLoopCnt]&BIT_SET(portId));
        }
    }

    retVal[0] = (ulOptPaProAlmFlag?1:0);
    retVal[1] = (ulCfrPaProAlmFlag?1:0);
    retVal[2] = (ulDpdPaProAlmFlag?1:0);
    retVal[3] = (ulTransPaProAlmFlag?1:0);
    retVal[4] = (ulOthersPaProAlmFlag?1:0);
    retVal[5] = (ulSlavePaProAlmFlag?1:0);
    retVal[6] = (ulSlavePowVaildFlag?1:0);
    for(ulLoopCnt=0; ulLoopCnt < PAPT_ALM_FLAG_MAX; ulLoopCnt++)
    {
        ulRetAlmStatus |= retVal[ulLoopCnt] << ulLoopCnt;
    }

    *pulPaProFlag = ulRetAlmStatus;
    dbgInfoEx("%s>>BspChnl'%2d: PaProFlag= %#x\n", __FUNCTION__,
              ulBspChnl, *pulPaProFlag);

    return BSP_OK;
#endif
}

/*****************************************************************************
 * 函数名称: BspGetPaProFlag(*)
 * 功能描述: 获取功放保护标志(通过掩码区分光口告警和非光口告警)
 * 输入参数: chipId - transceiver片号
 * 输出参数: 无
 * 返 回 值: 0- 无功放保护告警
 *           0x1 - 光口类功放保护告警
 *           0x2 - 非光口类功放保护告警
 *           0x3 - 光口类功放保护告警 + 非光口类功放保护告警
 * 其它说明: FDD机型使用
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10248577@2021-08-20, 创建
 *----------------------------------------------------------------------------
 */
UINT32 BspGetPaProFlag(UINT32 ulBspChnl)
{
#if (defined (BSP_MAKE_VER) || defined (_BSP_WITH_WFS))
    dbgInfoEx("%s>>Ver(Bsp Wfs) Not Support; return OK!\n", __FUNCTION__);

    return 0; /* 小版本和工装版本不支持 */
#else
    UINT32 ulLoopCnt = 0;
    UINT32 ulBspChnlSum = 0;
    UINT32 ulRfTrsvType = 0;
    UINT32 ulTrsvChipId = 0;
    UINT32 ulChnlOfChip = 0;
    UINT32 ulBitsOffset = 0;
    UINT64 ulOptPaProAlmFlag = 0;
    UINT64 ulOthersPaProAlmFlag = 0;
    UINT32 ulTmpRet = BSP_OK;
    UINT32 ulRetAlmStatus = NONE_PAPT;
    UINT32 ulLoopAlmType = 0;

    if(s_closePaptAlmReport)
    {
        return 0;
    }

    ulBspChnlSum = BspGetTxChannel();
    if (ulBspChnl >= ulBspChnlSum)
    {
        dbgErr("%s>>Error! Param Over; BspChnl(0~%d)= %d\n",
               __FUNCTION__, ulBspChnlSum - 1, ulBspChnl);
        return 0;
    }

    /* ================== DPDIC 功放保护告警标志 =================== */
    for (ulLoopCnt = 0; ulLoopCnt < DPDIC_PAPRO_ALM_TYPE_MAX; ulLoopCnt++)
    {
        if(BIT_VAL(s_optPaptAlmPosEnMask,ulLoopCnt))
        {
            ulOptPaProAlmFlag |= (s_aulDpdicPastPaProAlmFlag[ulLoopCnt] & BIT_SET(ulBspChnl));
        }
        else 
        {
            ulOthersPaProAlmFlag |= (s_aulDpdicPastPaProAlmFlag[ulLoopCnt] & BIT_SET(ulBspChnl));
        }
    }
    /* ============================================================= */

    /* ================= Transceiver功放保护告警标志 =============== */
    /* 获取BSP通道和 Transceiver芯片号芯片内通道的对应关系 */
    ulTmpRet = GetTransInfoByBspChan(ulBspChnl, &ulRfTrsvType, &ulTrsvChipId, &ulChnlOfChip);
    if (BSP_OK == ulTmpRet)
    {
        ulBitsOffset = ulTrsvChipId * PAPT_TRANS_CHN_MAX_NUM + ulChnlOfChip;
        for(ulLoopAlmType=0; ulLoopAlmType<TRANS_PAPRO_ALM_TYPE_MAX; ulLoopAlmType++)
        {
            ulOthersPaProAlmFlag |= (s_ulTransPaProAlmFlag[ulLoopAlmType] & BIT_SET(ulBitsOffset));
        }
        dbgInfoEx("%s>>Chnl(Bsp'%2d) Trsv(Type'%3d Id'%d Chnl'%d): AlmFlag= 0x%08llX\n",
                  __FUNCTION__, ulBspChnl, ulRfTrsvType, ulTrsvChipId, ulChnlOfChip, ulOthersPaProAlmFlag);
    }
    else
    {
     /* Trsv芯片识别异常, 不上报Trsv芯片告警保护标志;
        此处不直接返回BSP_OK, RFpga和IC告警继续上报 */
    //  return BSP_OK;
        dbgInfoEx("%s>>BspChnl'%2d TransceiverInfo Get Error!\n",
                  __FUNCTION__, ulBspChnl);
    }
    /* ============================================================= */
    if(ulOptPaProAlmFlag)
    {
        ulRetAlmStatus |= OPT_TYPE_PAPT;
    }
    if(ulOthersPaProAlmFlag)
    {
        ulRetAlmStatus |= OTHER_TYPE_PAPT;
    }
    dbgInfoEx("%s>>BspChnl'%2d: PaProFlag= %#x\n", __FUNCTION__,
              ulBspChnl, ulRetAlmStatus);

    return ulRetAlmStatus;
#endif    
}

/*****************************************************************************
 * 函数名称: BspPaptCheckRecoverInit(*)
 * 功能描述: 提供给各Transceiver告警上报接口使用，更新告警记录用
 * 输入参数: pInfo:J204建链分组信息
 * 输出参数: 无
 * 返 回 值: BSP_OK- 正常
 *           BSP_ERROR- 异常
 * 其它说明: 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10248577@2021-08-20, 创建
 *----------------------------------------------------------------------------
 */
UINT32 BspPaptCheckRecoverInit(T_J204PairEndsInfo *pInfo)
{
    UINT32 retVal = BSP_OK;

    INPUT_POINTER_CHECK(pInfo);

    retVal = PaptTransceiverInfoAnalyse();
    if(BSP_OK == retVal)
    {
        s_closePaptAlmReport = 0;
        BspLog(LOG_LEVEL_0, "papt check and recover open\n");
    }
    else
    {
        dbgErr("%s PaptTransceiverInfoAnalyse err\n",__func__);
        BspLog(LOG_LEVEL_0, "papt check and recover close for trx analyse fail\n");
        s_closePaptAlmReport = 1;
        return retVal;
    }

    retVal = BspPaptSetJ204PairEndsInfo(pInfo);
    if(BSP_OK != retVal)
    {
        dbgErr("%s BspPaptSetJ204PairEndsInfo err\n",__func__);
        return retVal;
    }

    retVal = BspTransceiverClrAlmAfterInit();
    if(BSP_OK != retVal)
    {
        dbgErr("%s BspTransceiverClrAlmAfterInit err\n",__func__);
        return retVal;
    }  

    return retVal;
}

/*****************************************************************************
 * 函数名称: BspPaptJ204LinkRebuild(*)
 * 功能描述: J204重建链流程
 * 输入参数: chipIdMask: 需要重建链的Transceiver片号掩码
 *        ulTrxChipSum: Transceiver总片数
 * 输出参数: 无
 * 返 回 值: BSP_OK- 重建链成功, BSP_ERROR- 重建链失败
 * 其它说明:
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10119095@2020-07-08, 创建
 *----------------------------------------------------------------------------
 */
UINT32 BspPaptJ204LinkRebuild(UINT32 chipIdMask, UINT32 ulTrxChipSum)
{
    UINT32 ulTrsvIdx = 0;
    UINT32 ulRetVal = BSP_OK;

    dbgInfoEx("%s>>ChipIdMask'%#x ulTrxChipSum'%d J204cRebuild Start!\n",
              __FUNCTION__, chipIdMask, ulTrxChipSum);

    /* 触发重新建链流程 */
    ulRetVal |= BspPaptJ204LinkPreStep(chipIdMask);
    BspSysMsDelay(1000); /* 方案要求延迟3秒 */
    for (ulTrsvIdx = 0; ulTrsvIdx < ulTrxChipSum; ulTrsvIdx++)
    {
        if(BIT_VAL(chipIdMask,ulTrsvIdx))
        {
            ulRetVal |= BspPaptTransJ204Rebuild(ulTrsvIdx);
            dbgInfoEx("%s>>Chip'%d Transceiver J204 rebuild!\n",__FUNCTION__, ulTrsvIdx);
        }
    }

    BspSysMsDelay(1000); /* 方案要求延迟2秒 */

    /* 在所有MTS接口MTS_RestRlsrest204Serdes调用之后,
       给MTS 发送一次 sysref; 配置一次是会向所有MTS 都发送sysref 脉冲 */
    /* todo 判断为MTS或者MTS2时才发送sysref */
    //coverity[cert_int31_c_violation:SUPPRESS]
    ulRetVal |= BspPaptJ204SendSysref(chipIdMask, 4);
    dbgInfoEx("%s>>Send Sysref To Transceiver chipIdMask=%#x\n", __FUNCTION__, chipIdMask);
    BspSysMsDelay(1000); /* 方案要求延迟2秒 */

    ulRetVal |= BspPaptJ204LinkPostStep(chipIdMask);
    BspSysMsDelay(1000); /* 方案要求延迟4秒 */

    dbgInfoEx("%s>>ChipIdMask'%#x J204cRebuild End!\n",
              __FUNCTION__, chipIdMask);

    return ulRetVal;
}

/*****************************************************************************
 * 函数名称: BspPaptJ204LinkRebuildWithRetry(*)
 * 功能描述: J204重建链流程(包含重试)
 * 输入参数: lChipId       -  chip id，0XFF表示全部Transceiver
 * 输出参数: 无
 * 返 回 值: 0- 重建链成功, 负值- 重建链失败
 * 其它说明:
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10119095@2020-07-08, 创建
 *----------------------------------------------------------------------------
 */
INT32 BspPaptJ204LinkRebuildWithRetry(INT32 lChipId)
{
    INT32 lRetVal = 0;
    UINT32 ulRetVal = BSP_OK;
    UINT32 ulTmpRet = BSP_OK;
    UINT32 ulTrxChipSum = 0;
    UINT32 chipIdMask = 0;
    UINT32 ulChipId = (UINT32)lChipId;
    UINT32 ulRwAddrDif = 0;
    UINT32 retry = 0;

    /* 建链信息获取 */
    ulTrxChipSum  = BspPaptGetTransChipNums();
    if(ulChipId > PAPT_TRANS_FULL_MASK)
    {
        return PAPT_RECOVER_ERR;
    }
    else if(PAPT_TRANS_FULL_MASK == ulChipId)
    {
        chipIdMask = GetChipMaskByNum(ulTrxChipSum);
    }
    else
    {
        chipIdMask = 0x1<<ulChipId;
        chipIdMask = BspPaptGetJ204TransEndsInfo(chipIdMask);
    }

    if (0 != s_aulJ204bcRecoverFlag)
    {
        dbgInfoEx("%s>>Chip'%d J204cRecover......\n",
                  __FUNCTION__, ulChipId);
        return PAPT_RECOVER_BUSY; // 表示后处理操作进行中
    }

    s_aulJ204bcRecoverFlag = 0x0F;
    do
    {
        ulRwAddrDif = 0;
        ulTmpRet = BspPaptJ204LinkRebuild(chipIdMask, ulTrxChipSum);
        ulRetVal |= ulTmpRet;
        BspLog(LOG_LEVEL_0, "Papt J204 rebuild finished![retry=%d] [ret=%#x]\n", retry+1, ulTmpRet);
        if(NULL != pFuncJ204RwAddrDifCheck)
        {
            ulTmpRet = (*pFuncJ204RwAddrDifCheck)(chipIdMask, &ulRwAddrDif);
            ulRetVal |= ulTmpRet;
            if(BSP_OK == ulTmpRet)
            {
                if(BSP_OK == ulRwAddrDif)
                {
                    dbgInfoEx("%s ulRwAddrDif[%#x] is ok\n", __FUNCTION__, ulRwAddrDif);
                    break;
                }
                else
                {
                    dbgInfoEx("%s ulRwAddrDif[%#x] is error\n", __FUNCTION__, ulRwAddrDif);
                    BspLog(LOG_LEVEL_0, "Papt J204 rwAddrDif[%#x] is error\n", ulRwAddrDif);
                }
            }
        }
        retry++;
    }while(retry<PAPT_J204_REBUILD_MAX);
    /* 重建链3次之后，依然有读写地址冲突，则修改lemsoffset */
    if(BSP_OK != ulRwAddrDif && PAPT_J204_REBUILD_MAX == retry)
    {
        if(NULL != pFuncJ204RwAddrDifRecover)
        {
            BspLog(LOG_LEVEL_0, "Papt J204 Set LemcOffset for RwAddrDiff[%#x]!\n", ulRwAddrDif);
            (*pFuncJ204RwAddrDifRecover)(chipIdMask);
        }
    }
    s_aulJ204bcRecoverFlag = 0;

    if (BSP_OK != ulRetVal)
    {
        lRetVal = PAPT_RECOVER_ERR;
    }
    return lRetVal;
}


/*对照BspTransceiverGetPastPaProAlm 修改 上报子端告警并清除为下次读取做准备*/
UINT32 BspSlaveGetPastPaProAlm(E_PaProType ePaProType, UINT64 *pu64EventBits)
{
    INT32 lRetVal = 0;

    INPUT_POINTER_CHECK(pu64EventBits);
    if(NULL == s_SlavePaProAlmPara.pFuncSlaveGetPastPrmAlm)
    {
        dbgInfoEx("%s>> pFunc is NULL\n",__FUNCTION__);
        return BSP_ERROR;
    }
    lRetVal = s_SlavePaProAlmPara.pFuncSlaveGetPastPrmAlm(ePaProType, pu64EventBits);
    return lRetVal;
}

/*一拖三机型 子端告警恢复*/
INT32 BspSlavePaProAlmRecover(E_PaProType ePaProAlmType, UINT64 u64AlmBitsMask)
{
    INT32 lRetVal = 0;

    if(NULL == s_SlavePaProAlmPara.pFuncSlavePastPrmAlmRecover)
    {
        dbgInfoEx("%s>> pFunc is NULL\n",__FUNCTION__);
        return BSP_ERROR;
    }
    lRetVal = s_SlavePaProAlmPara.pFuncSlavePastPrmAlmRecover(ePaProAlmType, u64AlmBitsMask);
    return lRetVal;
}
/**************************************************************************
*                                  维测接口
**************************************************************************/
static VOID showapppaptdata(UINT32 startAlm)
{
    UINT32 loop=0;
    const CHAR   *pcTypeNameStr = NULL;

    dbgInfo("almtype  almtypename  curSlaveMaskFlag  lastValidSlaveMaskFlag  recoverEventAlmMask \n");
    for(loop=(startAlm?startAlm:E_PA_PRO_TYPE_RFFPGA_PSYNC); loop<APP_ALM_TYPE_MAX; loop++)
    {
        PA_PRO_ALM_TYPE_NAME_STR(loop, pcTypeNameStr);
        dbgInfo("%7d  %40s  0x%llx  0x%llx  0x%llx\n", loop, pcTypeNameStr,
            s_dbgPaptAppData[loop].curSlaveMaskFlag, s_dbgPaptAppData[loop].lastValidSlaveMaskFlag,
            s_dbgPaptAppData[loop].recoverEventAlmMask);
    }
    dbgInfo(" ------------------------------------------------------------------\n");
    dbgInfo("dpdic4.0 support 17 kinds of papt alarm.\n");

    return;
}

static VOID showicalarmflag(VOID)
{
    UINT32 ulLoopCnt = 0;

    for (ulLoopCnt = 0; ulLoopCnt < DPDIC_PAPRO_ALM_TYPE_MAX; ulLoopCnt++)
    {
        dbgInfo(">>Idx'%2d  Dpdic'0x%08llX\n",
                ulLoopCnt, s_aulDpdicPastPaProAlmFlag[ulLoopCnt]);
    }
    return;
}

static VOID showtransalarmflag(VOID)
{
    UINT32 ulAlmTypeIdx  = 0;
//  UINT32 ulTrsvChipSum = 0;
    E_PaProType ePaProType = 0;
    const CHAR *pcTypeNameStr = NULL;

//  ulTrsvChipSum = BspGetTransceiverChipNum();
//  A9651A规格有4片Transceiver, ePaProType 配置为最大值
    for (ulAlmTypeIdx = 0; ulAlmTypeIdx < TRANS_PAPRO_ALM_TYPE_MAX; ulAlmTypeIdx++)
    {
        switch(ulAlmTypeIdx)
        {
        case TRANS_MCU_PLL_PAPRO_ALMTYPE:
        //  ePaProType = E_PA_PRO_TYPE_TRSV_MCUPLL0;
            ePaProType = E_PA_PRO_TYPE_TRSV_MCUPLL7;
            break;
        case TRANS_J204BC_PAPRO_ALMTYPE:
            ePaProType = E_PA_PRO_TYPE_TRSV_J204BC7;
            break;
        case TRANS_SERDES_PAPRO_ALMTYPE:
            ePaProType = E_PA_PRO_TYPE_TRSV_SERDES7;
            break;
        case TRANS_OUTBUF_PAPRO_ALMTYPE:
            ePaProType = E_PA_PRO_TYPE_TRSV_OUTBUF7;
            break;
        case TRANS_PWRERR_PAPRO_ALMTYPE:
            ePaProType = E_PA_PRO_TYPE_TRSV_PWRERR7;
            break;
        case TRANS_OTHERS_PAPRO_ALMTYPE:
        default:
            ePaProType = E_PA_PRO_TYPE_TRSV_OTHERS7;
            break;
        }
  
    //  ePaProType = ePaProType + ulTrsvChipSum - 1;
        PA_PRO_ALM_TYPE_NAME_STR(ePaProType, pcTypeNameStr);
        dbgInfo("%s>>TrsvAlmTpyeId'%2d PaProType'%2d [%-28s~ 0]: PaProFlag= 0x%08llX\n", __FUNCTION__,
                ulAlmTypeIdx, ePaProType, pcTypeNameStr, s_ulTransPaProAlmFlag[ulAlmTypeIdx]);
    }
    return;
}

static VOID openpaptalm(VOID)
{
    s_closePaptAlmReport = 0;
    return;
}

static VOID closepaptalm(VOID)
{
    s_closePaptAlmReport = 1;
    return;
}

UINT32 BspSetPaptAlmReport(UINT32 paptAlmReport)
{
    s_closePaptAlmReport = paptAlmReport;
    return BSP_OK;
}

UINT32 BspSetUpdatePaptInfoCallBack(FUNC_UPDATE_PAPT_POW_INFO pFunc)
{
    s_pFuncUpdatePaptInfo = pFunc;
    return BSP_OK;
}

/* 功放保护dpd均值门限更新 */
UINT32 BspSetDpdAvgPaProThr(UINT32 bspChan, INT32 thr)
{
    UINT32 retVal = BSP_OK;

    BspLog(LOG_LEVEL_0, "%s bspChan %d thr %d\n", __FUNCTION__, bspChan, thr);
    if(NULL != s_pFuncUpdatePaptInfo)
    {
        retVal = s_pFuncUpdatePaptInfo(bspChan,0, E_PA_PRO_TYPE_LOCAL_FREQ_DPD_AVG_PWR, thr);
    }

    return retVal;
}

/* 功放保护cfr长时均值门限更新 */
UINT32 BspSetCfrAvgPaProThr(UINT32 bspChan, INT32 thr)
{
    UINT32 retVal = BSP_OK;

    BspLog(LOG_LEVEL_0, "%s bspChan %d thr %d\n", __FUNCTION__, bspChan, thr);
    if(NULL != s_pFuncUpdatePaptInfo)
    {
        retVal = s_pFuncUpdatePaptInfo(bspChan,0, E_PA_PRO_TYPE_LOCAL_FREQ_LONG_AVG_PWR, thr);
    }

    return retVal;
}

/* 功放保护cfr长时平均掩码更新 */
UINT32 BspSetCfrAvgPaProMask(UINT32 bspChan, INT32 maskEn)
{
    UINT32 retVal = BSP_OK;

    BspLog(LOG_LEVEL_0, "%s bspChan %d enMask %d\n", __FUNCTION__, bspChan, maskEn);
    if(NULL != s_pFuncUpdatePaptInfo)
    {
        retVal = s_pFuncUpdatePaptInfo(bspChan,1, E_PA_PRO_TYPE_LOCAL_FREQ_LONG_AVG_PWR, maskEn);
    }

    return retVal;
}

/*dpd均值保护时降低进入dpd的功率*/
UINT32 BspSetDpdAvgPaProPow(UINT32 bspChan, INT32 delta)
{
    UINT32 retVal = BSP_OK;

    BspLog(LOG_LEVEL_0, "%s bspChan %d thr %d\n", __FUNCTION__, bspChan, delta);
    if(NULL != s_pFuncUpdatePaptInfo)
    {
        retVal = s_pFuncUpdatePaptInfo(bspChan,2, 0, delta);
    }

    return retVal;
}

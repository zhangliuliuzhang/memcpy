/*****************************************************************************
* 版权所有(C) 2017, ZTE Corp. ZXSDR-RRU Platform BSP
*----------------------------------------------------------------------------
* 模  块  名 : papt_common
* 文件名称 : papt_private.h
* 文件标识 : {[N/A]}
* 内容摘要 : 本文件提供了PAPT模块内部使用的函数实现
* 注意事项 : 无
* 作       者 : 10248577
* 创建日期 : 2022-03-10
* 当前版本 : Ver1.0
*---------------------------------------------------------------------------*/
#ifndef _FUNCLIB_PAPT_COMMON_PRIVATE_H_
#define _FUNCLIB_PAPT_COMMON_PRIVATE_H_

#ifdef __cplusplus
extern "C" {
#endif

#include "papt_common.h"

/* PAPT内部J204告警恢复处理用内部接口 */
UINT32 BspPaptJ204LinkPreStep(UINT32 chipIdMask);
UINT32 BspPaptJ204LinkPostStep(UINT32 chipIdMask);
UINT32 BspPaptJ204SendSysref(UINT32 chipIdMask, UINT32 num);

UINT32 BspPaptSetJ204PairEndsInfo(T_J204PairEndsInfo *pInfo);
UINT32 BspPaptGetJ204TransEndsInfo(UINT32 chipIdMask);
UINT32 BspPaptGetJ204DpdicEndsInfo(UINT32 chipIdMask);
UINT32 BspPaptGetTransChipNums(VOID);
UINT32 BspPaptIsTransceiverChnlUsed(UINT32 chipId, UINT32 transChn);

UINT32 BspPaptTransJ204Rebuild(UINT32 chipId);
UINT32 BspPaptJ204LinkRebuild(UINT32 chipIdMask, UINT32 ulTrxChipSum);
INT32 BspPaptJ204LinkRebuildWithRetry(INT32 lChipId);
UINT32 BspSetPaptAlmReport(UINT32 paptAlmReport);

#ifdef __cplusplus
}
#endif

#endif

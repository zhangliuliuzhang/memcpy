/*****************************************************************************
* 版权所有(C) 2017, ZTE Corp. ZXSDR-RRU Platform BSP
*----------------------------------------------------------------------------
* 模  块  名 : papt_common
* 文件名称 : papt_common.h
* 文件标识 : {[N/A]}
* 内容摘要 : 本文件提供了PAPT公共模块的函数实现
* 注意事项 : 无
* 作       者 : 10248577
* 创建日期 : 2022-03-10
* 当前版本 : Ver1.0
*---------------------------------------------------------------------------*/
#ifndef _FUNCLIB_PAPT_COMMON_H_
#define _FUNCLIB_PAPT_COMMON_H_

#ifdef __cplusplus
extern "C" {
#endif

#include "bsppub.h"
#include "bspcomm.h"

/**************************************************************************
 *                        宏
 **************************************************************************/
typedef enum _E_TRANS_PAPRO_ALM_TYPE
{
    TRANS_MCU_PLL_PAPRO_ALMTYPE = 0,  /* 时钟失锁告警和本振失锁告警 */
    TRANS_J204BC_PAPRO_ALMTYPE  = 1,  /* 204B/204C异常保护告警 */
    TRANS_SERDES_PAPRO_ALMTYPE  = 2,  /* Serdes异常告警 */
    TRANS_OUTBUF_PAPRO_ALMTYPE  = 3,  /* 出窗告警 */
    TRANS_PWRERR_PAPRO_ALMTYPE  = 4,  /* 单点和均值功率告警 */
    TRANS_OTHERS_PAPRO_ALMTYPE  = 5,  /* ARM或Stream Processor异常保护与监测 */
    TRANS_PAPRO_ALM_TYPE_MAX
}E_TRANS_PAPRO_ALM_TYPE;

typedef enum _E_SLAVE_PAPRO_ALM_TYPE
{
    SLAVE_SYSPLL_PAPRO_ALMTYPE = 0,  /* 时钟失锁告警 */
    SLAVE_BRDPWR_12V_PAPRO_ALMTYPE,  /*12V欠压 */
    SLAVE_FRAME_PAPRO_ALMTYPE,  /* 同步帧头丢失 */
    SLAVE_RFPLL_PAPRO_ALMTYPE,  /*影响子端所以归类在这里*/
    SLAVE_PAPRO_ALM_TYPE_MAX
}E_SLAVE_PAPRO_ALM_TYPE;

#define DPDIC_PAPRO_ALM_TYPE_MAX (30)

#define J204_PAIRS_NUM_MAX (16)

#define PAPT_TRANS_CHN_MAX_NUM (8)

#define OPT_PAPT_ALM_POS_NUM (10)
#define NONE_PAPT               ((UINT32)0)
#define OPT_TYPE_PAPT           ((UINT32)1)
#define OTHER_TYPE_PAPT         ((UINT32)2)

#define PAPT_RECOVER_ERR        (-1)
#define PAPT_NOT_SUPPORT_ALM    (-1)
#define PAPT_RECOVER_BUSY       (0xFF)

#define PAPT_INVALID_DATA_64 (0x5a5a5a5a5a5a5a5a)
#define PAPT_INVALID_DATA_32 (0x5a5a5a5a)

#define PAPT_TRANS_FULL_MASK    (0xFF) /* 表示全部Transceiver */

/**************************************************************************
 *                         数据类型
 **************************************************************************/
typedef UINT32 (*FUNC_GET_PAST_PRO_ALM)(E_PaProType ePaProType, UINT64 *pu64EventBits);
typedef INT32 (*FUNC_PA_PRO_ALM_RECOVER)(E_PaProType ePaProType, UINT64 u64AlmBitsMask);


typedef INT32 (*FUNC_TRANS_GET_PAST_PRO_ALM)(UINT32 chipId, E_TRANS_PAPRO_ALM_TYPE eTransAlmType, UINT64 *pu64EventBits);
typedef INT32 (*FUNC_TRANS_CLR_PAST_PRO_ALM)(UINT32 chipId, E_TRANS_PAPRO_ALM_TYPE eTransAlmType);
typedef INT32 (*FUNC_TRANS_PAST_PRO_ALM_RECOVER)(UINT32 chipId, E_TRANS_PAPRO_ALM_TYPE eTransAlmType, UINT64 u64AlmBitsMask);
typedef INT32 (*FUNC_TRANS_CLR_ALM_AFTER_INIT)(UINT32 chipId);
typedef INT32 (*FUNC_TRANS_J204_REBUILD)(UINT32 chipId);


typedef UINT32 (*FUNC_PAPT_J204_LINK_BUILD)(UINT32 chipIdMask);
typedef UINT32 (*FUNC_PAPT_J204_SYSREF_SEND)(UINT32 chipIdMask, UINT32 num);
typedef UINT32 (*FUNC_PAPT_J204_RWADDRDIF_CHECK)(UINT32 chipIdMask, UINT32 *state);
typedef UINT32 (*FUNC_PAPT_J204_RWADDRDIF_RECOVER)(UINT32 chipIdMask);


typedef INT32 (*FUNC_SLAVE_GET_PAST_PRO_ALM)(E_PaProType ePaProType, UINT64 *pu64EventBits);
typedef INT32 (*FUNC_SLAVE_PAST_PRO_ALM_RECOVER)(UINT32 ulPaProAlmType, UINT64 u64EventAlmMask);
typedef UINT32 (*FUNC_UPDATE_PAPT_POW_INFO)(UINT32 bspChan, UINT32 cfgType, UINT32 paptType, INT32 para);

typedef struct tagT_PaProAlmPara
{ 
    FUNC_GET_PAST_PRO_ALM   pFuncGetPastProAlm;
    FUNC_PA_PRO_ALM_RECOVER pFuncPaProAlmRecover;
}T_PaProAlmPara;

typedef struct tagT_J204OnePairEnds
{
    UINT32 dpdicLaneMask;
    UINT32 dpdicGrpMask;
    UINT32 transIdMask;
}T_J204OnePairEnds;

typedef struct tag_J204PairEndsInfo
{
    T_J204OnePairEnds onePairEnds[J204_PAIRS_NUM_MAX];
}T_J204PairEndsInfo;

typedef struct tag_PaptAlmClassifyMask
{
    UINT64 optPaptAlmPosEnMask;
    UINT64 cfrPaptAlmPosEnMask;
    UINT64 dpdPaptAlmPosEnMask;
}T_PaptAlmClassifyMask;

/**************************************************************************
*                         函数声明
**************************************************************************/
/* 供单板调用的初始化接口 */
UINT32 BspPaptCheckRecoverInit(T_J204PairEndsInfo *pInfo);

/* 供单板调用的Transceiver初始化后告警清除接口 */
UINT32 BspTransceiverClrAlmAfterInit(VOID);

/* FDD机型获取功放保护标志的接口 */
UINT32 BspGetPaProFlag(UINT32 ulBspChnl);

/* 供其他模块注册功放保护告警检测、后处理能力的接口 */
UINT32 BspSetGetPaProAlmFunc(E_PaProType ePaProType, FUNC_GET_PAST_PRO_ALM pFunc);
UINT32 BspSetPaProAlmRecoverFunc(E_PaProType ePaProType, FUNC_PA_PRO_ALM_RECOVER pFunc);

/* 供其他模块注册Transceiver功放保护告警检测、清除、后处理、初始化清除、重建链能力的接口 */
UINT32 BspSetTransGetPaProAlmFunc(UINT32 deviceType, FUNC_TRANS_GET_PAST_PRO_ALM pFunc);
UINT32 BspSetTransClrPaProAlmFunc(UINT32 deviceType, FUNC_TRANS_CLR_PAST_PRO_ALM pFunc);
UINT32 BspSetTransPaProAlmRecoverFunc(UINT32 deviceType, FUNC_TRANS_PAST_PRO_ALM_RECOVER pFunc);
UINT32 BspSetTransClrAlmAfterInitFunc(UINT32 deviceType, FUNC_TRANS_CLR_ALM_AFTER_INIT pFunc);
UINT32 BspSetTransJ204RebuildFunc(UINT32 deviceType, FUNC_TRANS_J204_REBUILD pFunc);

/* 供其他模块更新Transceiver功放保护告警标志的接口 */
UINT32 BspSetTransPaProAlmFlagByChn(UINT32 chipId, UINT32 ulTransChn, UINT32 ulAlmType, UINT32 ulAlmFlag);
UINT32 BspSetTransPaProAlmFlagByChip(UINT32 chipId, UINT32 ulAlmType, UINT32 ulAlmFlag);

/* 供其他模块更新、查询DPDIC功放保护告警标志的接口 */
UINT32 BspSetDpdicPaProAlmFlag(UINT32 ulAlmType, UINT32 bspChn, UINT32 ulAlmFlag);
UINT32 BspSetDpdicPaProAlmAllChn(UINT32 ulAlmType, UINT64 ulAlmEventBits);
UINT32 BspGetDpdicPaProAlmFlag(UINT32 ulAlmType, UINT64 *pUlAlmEventBits);

/* 供其他模块注入DPDIC功放保护告警分类掩码的接口 */
UINT32 BspSetDpdicPaptAlmClassifyMask(T_PaptAlmClassifyMask *pClassifyMask);

/* 供其他模块注册J204告警后处理能力的接口 */
UINT32 BspPaptSetJ204LinkPreFunc(FUNC_PAPT_J204_LINK_BUILD pFunc);
UINT32 BspPaptSetJ204LinkPostFunc(FUNC_PAPT_J204_LINK_BUILD pFunc);
UINT32 BspPaptSetJ204SendSysrefFunc(FUNC_PAPT_J204_SYSREF_SEND pFunc);
UINT32 BspPaptSetJ204RwAddrDifCheckFunc(FUNC_PAPT_J204_RWADDRDIF_CHECK pFunc);
UINT32 BspPaptSetJ204RwAddrDifRecoverFunc(FUNC_PAPT_J204_RWADDRDIF_RECOVER pFunc);

/* 供其他模块注册Slave功放保护告警检测、后处理能力的接口 */
UINT32 BspSetSlaveGetPaProAlmFunc(FUNC_SLAVE_GET_PAST_PRO_ALM pFunc);
UINT32 BspSetSlavePaProAlmRecoverFunc(FUNC_SLAVE_PAST_PRO_ALM_RECOVER pFunc);

/* 供其他模块更新、查询Slave功放保护告警标志的接口 */
UINT32 BspSetSlavePaProAlmFlagByPortId(UINT32 portId, UINT32 ulAlmType, UINT32 ulAlmFlag);

/*更新各种保护门限*/
UINT32 BspSetUpdatePaptInfoCallBack(FUNC_UPDATE_PAPT_POW_INFO pFunc);

UINT32 BspTransceiverGetPastPaProAlm(E_PaProType ePaProType, UINT64 *pu64EventBits);
#ifdef __cplusplus
}
#endif

#endif

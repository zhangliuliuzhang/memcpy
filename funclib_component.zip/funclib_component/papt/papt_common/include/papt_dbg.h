/*****************************************************************************
* 版权所有(C) 2017, ZTE Corp. ZXSDR-RRU Platform BSP
*----------------------------------------------------------------------------
* 模  块  名 : papt_common
* 文件名称 : papt_dbg.h
* 文件标识 : {[N/A]}
* 内容摘要 : 本文件提供了PAPT模块维测功能对外接口
* 注意事项 : 无
* 作       者 : 10248577
* 创建日期 : 2022-03-10
* 当前版本 : Ver1.0
*---------------------------------------------------------------------------*/
#ifndef _FUNCLIB_PAPT_COMMON_DBG_H_
#define _FUNCLIB_PAPT_COMMON_DBG_H_

#ifdef __cplusplus
extern "C" {
#endif

#include "bsppub.h"

VOID DbgGetPaProPastAlm(UINT32 ulPaProTypeIdx);
VOID DbgPaProAlmRecover(UINT32 ulPaProTypeIdx);
VOID DbgPaGetPaProtectAlmFlag(UINT32 ulBspChnl);
UINT32 DbgPaptCheckRecoverInit(UINT32 trxMask, UINT32 grpMask, UINT32 laneMask);

#ifdef __cplusplus
}
#endif

#endif

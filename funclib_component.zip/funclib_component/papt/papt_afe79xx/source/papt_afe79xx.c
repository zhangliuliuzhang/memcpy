/*****************************************************************************
* 版权所有(C) 2023, ZTE Corp. ZXSDR-RRU Platform BSP
*----------------------------------------------------------------------------
* 模 块 名 : BSP
* 文件名称 : papt_afe79xx.c
* 文件标识 : {[N/A]}
* 内容摘要 : 本文件提供了AFE79XX的功放保护接口
* 注意事项 : 无
* 作   者 :
* 创建日期 :
* 当前版本 : Ver1.0
*----------------------------------------------------------------------------*/

#include "devdrv_transceiver.h"
#include "afe79xx.h"
#include "papt_common.h" 
#include "chnmapcommon.h"
#include "exprn.h"
#include "bsppub.h"
#include "j204_ic4_2.h"
#include "papt_private.h"
/******************************************************************************
 *                                                                            *
 *                            宏定义                                           *
 *                                                                            *
 ******************************************************************************/
#define AFE_FUNC_RETURN_CHK(FunRet)                   \
{                                                        \
    if (BSP_OK != (FunRet))                              \
    {                                                    \
        dbgInfoEx("%s>>Func Call Error! Ret= 0x%04X\n",  \
                  __FUNCTION__, (FunRet));               \
    }                                                    \
} 

#define AFE_ERROR_REPORT(funcRet, retVal, funcinfo)  \
{                                                                     \
    if (BSP_OK != (funcRet))                                          \
    {                                                                 \
        (retVal) = -1;                                                \
        dbgErr("%s>> %s Return Error!\n", __FUNCTION__, (funcinfo));  \
    }                                                                 \
}

#define AFE_CHIP_CHECK(chipId,retVal)                                 \
{                                                                     \
    if (chipId >= GetTransceiverChipNum())                            \
    {                                                                 \
        dbgInfoEx("%s>>Afe79xx device ID out of bounds,chipId:%d\r\n",__FUNCTION__,chipId);   \
        return retVal;                                                \
    }                                                                 \
}

/******************************************************************************
 *                                                                             *
 *                            全局变量                                         *
 *                                                                            *
 ******************************************************************************/
static UINT32 GetTransceiverChipNum()
{
    TRruDeviceDescription *pDev = NULL;
    UINT32 ulLoop = 0;
    static UINT32 ulTrsvChipNum = 0;

    if (ulTrsvChipNum != 0)
    {
        return ulTrsvChipNum;
    }
    for (ulLoop = 0; ulLoop < BspGetTxBspChanNum(); ulLoop++)
    {
        if (0 == BspChipInfoPtrGetByRfPathDef(ulLoop, TX,DEVICE_TYPE_TRANSCEIVER, &pDev))
        {
            if (pDev->ulDeviceCfg != INVALID_VALUE)
            {
                ulTrsvChipNum++;
            }
        }
    }
    return ulTrsvChipNum;
}

/******************************************************************************
 *                                                                            *
 *                            功放保护相关接口实现                            *
 *                                                                            *
 ******************************************************************************/
/********************* PLL告警  与原来的接口保持一致**************************/
UINT32 BspAfe79xxPllCheckAlarmStatus(UINT32 chipId)
{
    UINT32 retVal = BSP_OK;

    AFE_CHIP_CHECK(chipId, BSP_OK); //索引超出范围,不应上报告警 避免影响高层流程
    retVal = afe79xxPllCheck(chipId);
    dbgInfoEx("\n[%s]  status: %d\n",__FUNCTION__,retVal);

    return retVal;
}
/*****************************************************************************
 * 函数名称: Afe79xxGetPastPaProAlm(*)    ---BspTransceiverGetPastPaProAlm
 * 功能描述: 获取Afe79xx历史告警状态
 * 输入参数: ulAlmType     - 告警类型,用于查询 AFE7989 chip id
 * 输出参数: pulEventBits - 告警事件真值 0/1    并记录映射到了BSPCHAN,底层维测使用查看全部告警
 * 返 回 值: 0- 正常, 其它值- 异常
 * 其它说明: SerdesPll失锁/Serdes告警
 *          数据类告警暂不支持:该分类下不动作; 无后处理
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10268066@2020-09-08, 创建
 *----------------------------------------------------------------------------
 */
INT32 Afe79xxGetPastPaProAlm(UINT32 ulChipId, E_TRANS_PAPRO_ALM_TYPE ulAlmType, UINT64 *pulEventBits)
{
    INT32 lRetVal = 0;

    INPUT_POINTER_CHECK(pulEventBits);
    switch(ulAlmType)
    {
        case TRANS_MCU_PLL_PAPRO_ALMTYPE:
        {
            lRetVal = BspAfe79xxPllCheckAlarmStatus(ulChipId);
            *pulEventBits = lRetVal;
            if(lRetVal != 0)
            {
                lRetVal = 0;
                BspSetTransPaProAlmFlagByChip(ulChipId,TRANS_MCU_PLL_PAPRO_ALMTYPE,1);
            }
            else
            {
                BspSetTransPaProAlmFlagByChip(ulChipId,TRANS_MCU_PLL_PAPRO_ALMTYPE,0);
            }
            break;
        }
        case TRANS_J204BC_PAPRO_ALMTYPE:
        {
            lRetVal = BspAfe79xxGetJ204BringUpStatus(ulChipId);
            *pulEventBits = lRetVal;
            if(lRetVal != 0)
            {
                lRetVal = 0;
                BspSetTransPaProAlmFlagByChip(ulChipId,TRANS_J204BC_PAPRO_ALMTYPE,1);
            }
            else
            {
                BspSetTransPaProAlmFlagByChip(ulChipId,TRANS_J204BC_PAPRO_ALMTYPE,0);
            }
            break;
        }
        default:
        {
            lRetVal = PAPT_NOT_SUPPORT_ALM;//不检测项返回
            break;
        }
    }

    dbgInfoEx("%s>>chipId'%2d: ulAlmType:0x%04x  *pulEventBits: 0x%04llx\n",    \
                  __FUNCTION__,ulChipId, ulAlmType, *pulEventBits);

    return lRetVal;
}

/*****************************************************************************
 * 函数名称: Afe79xxClrPastPaProAlm --- (原AfeClrPastPaProAlm ---BspTransceiverClrPaProPastAlm(*)）
 * 功能描述: 功放保护历史告警清除
 * 输入参数: ePaAlmType - 功放保护告警枚举类型
 * 输出参数: 无
 * 返 回 值: 0- 正常, 其它值- 异常
 * 其它说明: 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10119095@2020-07-08, 创建
 *----------------------------------------------------------------------------
 */
INT32 Afe79xxClrPastPaProAlm(UINT32 ulChipId, E_TRANS_PAPRO_ALM_TYPE ulAlmType)
{
    INT32 lRetVal  = BSP_OK;

    switch (ulAlmType)
    {
        case TRANS_MCU_PLL_PAPRO_ALMTYPE:
             lRetVal = BspAfe79xxAlmClear(ulChipId);
             break;
        case TRANS_J204BC_PAPRO_ALMTYPE:
             lRetVal = BspAfe79xxAlmClear(ulChipId);
             break;
        default:
            break;
    }
    return lRetVal;
}


/*清除所有trancesiver上的告警*/
static UINT32 Afe79xxClrAllTrvAlarm(VOID)
{
    UINT32 retVal = BSP_OK;
    UINT32 ulChipNum = 0;
    UINT32 ulLoop = 0;

    ulChipNum = BspGetTransceiverChipNum();
    /**清告警**/
    for(ulLoop = 0; ulLoop < ulChipNum; ulLoop++)
    {
         retVal |= BspAfe79xxAlmClear(ulLoop);
    }

    return retVal;
}

/*****************************************************************************
 * 函数名称: Afe79xxPaProAlmRecover(*)    ----BspTransceiverPaProAlmRecover
 * 功能描述: Afe79xx功放告警修复
 * 输入参数: lChipId   - Afe79xx chip id
 * 输出参数: 无
 * 返 回 值: 0- 正常或无后处理操作正常, 负值- 后处理操作异常, 正值- 表示有后处理操作
 * 其它说明: BSP负责处理的话, 此函数需要周期性执行
 *           修复优先级: 时钟本振类>> Serdes类>> 204类>> 功率异常类>> ARM类
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10119095@2020-07-08, 创建
 *----------------------------------------------------------------------------
 */
INT32 Afe79xxPaProAlmRecover(UINT32 ulchipId, E_TRANS_PAPRO_ALM_TYPE ulAlmType, UINT64 u64AlmBitsMask)
{
    INT32 lRetVal = 0;

    if (0 == u64AlmBitsMask)
    {
        dbgInfoEx("%s>>Chip'%d AlmMask'0x%llX: return!\n",
                  __FUNCTION__, ulchipId, u64AlmBitsMask);
        return 0; // 表示无后处理操作
    }
    BspJ204LinkInitStep();
    lRetVal = BspPaptJ204LinkRebuildWithRetry(ulchipId);
    Afe79xxClrAllTrvAlarm();
    BspSysMsDelay(1000);
    dbgInfoEx("%s>>chipId'%2d: lRetVal:0x%04x  u64AlmBitsMask: 0x%04llx\n", \
                  __FUNCTION__, ulchipId, lRetVal, u64AlmBitsMask);

    return lRetVal;
}

/*初始化过程调用  清除告警 BspPerTransClrAlmAfterInit -BspTransceiverClrAlmAfterInit -BspPaptCheckRecoverInit-BspPaptReportRecoverInit */
INT32 Afe79xxClrAlmAfterInit(UINT32 ulChipId)
{
    INT32 retVal  = BSP_OK;
    retVal = BspAfe79xxAlmClear(ulChipId);
    return retVal;
}

/*按平台设计Afe79xxJ204Rebuild 是Afe79xxPaProAlmRecover中204异常恢复时trx侧的动作，ic的动作不包含在内*/
INT32 Afe79xxJ204Rebuild(UINT32 ulChipId)
{
    INT32 retVal  = BSP_OK;
    retVal = BspAfe79xx204ReBuild(ulChipId);
    return retVal;
}

INT32 Afe79xxJ204bcAlmRecover(UINT32 ulChipId, UINT64 u64AlmBitsMask)
{
    INT32 retVal  = BSP_OK;

    retVal = BspJ204LinkInitStep();
    retVal |= BspPaptJ204LinkRebuildWithRetry(ulChipId);     /*preinit/7989 sync-sysref/postinit */
    retVal |= Afe79xxClrAllTrvAlarm();
    return retVal;
}

INT32 Afe79xxIcLaneAlmRecover(E_PaProType ePaProType, UINT64 u64AlmBitsMask)
{
    INT32 lRetVal = 0;

    if(E_PA_PRO_TYPE_IC_LANE_STATUS == ePaProType)
    {
        lRetVal = Afe79xxJ204bcAlmRecover(PAPT_TRANS_FULL_MASK, u64AlmBitsMask); // 255表示所有芯片
    }
    else
    {
        lRetVal = PAPT_NOT_SUPPORT_ALM;
    }

    return lRetVal;
}
/**************************************************************************
                             回调挂接
 **************************************************************************/
static __attribute((constructor)) void SetAfe79xxPaptFunc()
{
    (VOID)BspSetTransGetPaProAlmFunc(DEVICE_AFE7989,Afe79xxGetPastPaProAlm);
    (VOID)BspSetTransClrPaProAlmFunc(DEVICE_AFE7989,Afe79xxClrPastPaProAlm);
    (VOID)BspSetTransPaProAlmRecoverFunc(DEVICE_AFE7989,Afe79xxPaProAlmRecover);
    (VOID)BspSetTransClrAlmAfterInitFunc(DEVICE_AFE7989,Afe79xxClrAlmAfterInit);   /*初始化流程调用*/
    (VOID)BspSetTransJ204RebuildFunc(DEVICE_AFE7989,Afe79xxJ204Rebuild);           /*Afe79xxPaProAlmRecover 中trx侧的动作*/
    (VOID)BspSetPaProAlmRecoverFunc(E_PA_PRO_TYPE_IC_LANE_STATUS, Afe79xxIcLaneAlmRecover);
}

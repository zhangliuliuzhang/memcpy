/*****************************************************************************
* 版权所有(C) 2017, ZTE Corp. ZXSDR-RRU Platform BSP
*----------------------------------------------------------------------------
* 模  块  名 : papt_dpdic42
* 文件名称 : papt_dpdic42_crm.c
* 文件标识 : {[N/A]}
* 内容摘要 : 本文件提供了PAPT公共模块的函数声明
* 注意事项 : 无
* 作       者 : 10248577
* 创建日期 : 2022-03-10
* 当前版本 : Ver1.0
*---------------------------------------------------------------------------*/
#include "papt_dpdic42_crm.h"
#include "ichaladapt_ic4_2.h"
#include "funccommon_log.h"

/**************************************************************************
 *                        宏定义
 **************************************************************************/
#define ALL_CHAN_PAPT_ALARM_VAL (0xFF)    /* 8个通道全部出现告警(适用于CRM告警) */

/**************************************************************************
 *                        数据类型定义
 **************************************************************************/



/**************************************************************************
 *                        全局变量
 **************************************************************************/
/* CRM告警状态记录 */
UINT32  curCrmAlmTypeMask;             /* 最近一次从CRM读取的告警类型掩码              */
UINT32  lastValidCrmAlmTypeMask;       /* 最近一次从CRM读取的告警类型掩码              */
UINT32  curCrmOrgAlmMask;              /* 最近一次从CRM读取的原始告警掩码              */
UINT32  lastValidCrmOrgAlmMask;        /* 最近一次从CRM读取的原始告警掩码              */

/**************************************************************************
*                         函数声明
**************************************************************************/



/**************************************************************************
*                         函数定义
**************************************************************************/
/* 记录单板欠压告警状态变化 */
static void RecordBoardPwrAlarmStatus(UINT32 pastAlm, UINT32 realAlm)
{
    static UINT32 lastRecordPast = 0;
    static UINT32 lastRecordReal = 0;

    if ( (lastRecordPast != pastAlm) || (lastRecordReal != realAlm) )
    {
        BspLog(LOG_LEVEL_0, "12V alarm. past:%#x, real:%#x\n", pastAlm, realAlm);
        lastRecordPast = pastAlm;
        lastRecordReal = realAlm;
    }
}

/*****************************************************************************
 * 函数名称: GetDpdicCrmDetailAlarmType
 * 功能描述: 查询具体的CRM告警种类（PLL告警、复位告警）
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值:
 * 其它说明: 单板欠压告警已通过其他接口获取
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10248577@2021-08-20, 创建
 *----------------------------------------------------------------------------
 */
UINT32 GetDpdicCrmDetailAlarmType(E_PaProType ePaAlmType, UINT32 *pAlmStatus)
{
   UINT32 retVal = BSP_OK;
   UINT32 orgAlarmMask = 0;
   UINT32 alarmTypeMask = 0;

    if(E_PA_PRO_TYPE_CRM_SEND_RESET_UNUS == ePaAlmType ||
       E_PA_PRO_TYPE_CRM_SEND_CLK_UNUS == ePaAlmType ||
       E_PA_PRO_TYPE_BOARD_PWR_ALARM == ePaAlmType)
    {

        retVal = BspHalAdaptGetCrmAlarmType(&orgAlarmMask, &alarmTypeMask);
        if(BSP_OK != retVal)
        {
            *pAlmStatus = 0;
            return BSP_ERROR;
        }
    }
    else
    {
        *pAlmStatus = 0;
        return BSP_ERROR;
    }

    /* 先清,根据具体告警重新赋值 */
    *pAlmStatus = 0;

    /* 判断是否有复位告警 */
    if(E_PA_PRO_TYPE_CRM_SEND_RESET_UNUS == ePaAlmType)
    {
        if(BIT_VAL(alarmTypeMask, CRM_PAPT_ALM_RESET))
        {
            *pAlmStatus = ALL_CHAN_PAPT_ALARM_VAL;
        }
    }
    /* 判断是否有时钟异常告警 */
    else if(E_PA_PRO_TYPE_CRM_SEND_CLK_UNUS == ePaAlmType)
    {
        if(BIT_VAL(alarmTypeMask, CRM_PAPT_ALM_PLL_ERR))
        {
            *pAlmStatus = ALL_CHAN_PAPT_ALARM_VAL;
        }
    }
    /* 判断是否有时钟异常告警 */
    else
    {
        if(BIT_VAL(alarmTypeMask, CRM_PAPT_ALM_BOARD_PWR_OFF))
        {
            *pAlmStatus = ALL_CHAN_PAPT_ALARM_VAL;
        }
    }

    /* 维测 */
    curCrmAlmTypeMask = alarmTypeMask;
    curCrmOrgAlmMask = orgAlarmMask;
    if(alarmTypeMask)
    {
        lastValidCrmAlmTypeMask = alarmTypeMask;
    }
    if(orgAlarmMask)
    {
        lastValidCrmOrgAlmMask = orgAlarmMask;
    }

    return BSP_OK;
}

/*****************************************************************************
 * 函数名称: ClrDpdicCrmDetailAlarm
 * 功能描述: 清除具体的CRM告警种类（PLL告警、复位告警）
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值:
 * 其它说明: 单板欠压告警已通过其他接口清除、另按照方案，crm告警不清除，故本接口暂未使用
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10248577@2021-08-20, 创建
 *----------------------------------------------------------------------------
 */
UINT32 ClrDpdicCrmDetailAlarm(E_PaProType ePaAlmType)
{
    UINT32 retVal = BSP_OK;

    /* 判断是否有复位告警 */
    if(E_PA_PRO_TYPE_CRM_SEND_RESET_UNUS == ePaAlmType)
    {
        retVal = BspHalAdaptClrCrmAlarmType(CRM_PAPT_ALM_RESET);
    }
    /* 判断是否有时钟异常告警 */
    else if(E_PA_PRO_TYPE_CRM_SEND_CLK_UNUS == ePaAlmType)
    {
        retVal = BspHalAdaptClrCrmAlarmType(CRM_PAPT_ALM_PLL_ERR);
    }
    /* 判断是否有单板欠压告警 */
    else if(E_PA_PRO_TYPE_BOARD_PWR_ALARM == ePaAlmType)
    {
        retVal = BspHalAdaptClrCrmAlarmType(CRM_PAPT_ALM_BOARD_PWR_OFF);
    }
    else
    {
        return BSP_ERROR;
    }

    return retVal;
}

/*****************************************************************************
 * 函数名称: GetBoardPwrReportAlarm
 * 功能描述: 查询单板-12欠压告警
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值:
 * 其它说明: 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10248577@2021-08-20, 创建
 *----------------------------------------------------------------------------
 */
UINT32 GetBoardPwrReportAlarm(void)
{
    UINT32 pastAlm = BspHalAdaptGetCrmPastAlarm(CRM_PAPT_ALM_BOARD_PWR_OFF);
    UINT32 realAlm = BspHalAdaptGetCrmRealAlarm(CRM_PAPT_ALM_BOARD_PWR_OFF);

    RecordBoardPwrAlarmStatus(pastAlm, realAlm);

    if ( (pastAlm != BSP_OK) && (realAlm == BSP_OK) )
    {
        return BSP_ERROR;
    }

    return BSP_OK;
}

/*****************************************************************************
 * 函数名称: ClearBoardPwrAlarm
 * 功能描述: 清除单板欠压告警
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值:
 * 其它说明: 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10248577@2021-08-20, 创建
 *----------------------------------------------------------------------------
 */
void ClearBoardPwrAlarm(void)
{
    BspHalAdaptClrCrmAlarmType(CRM_PAPT_ALM_BOARD_PWR_OFF);
    BspHalAdaptClrCrmPaAlm(CRM_PAPT_ALM_BOARD_PWR_OFF);
    BspHalAdaptClrCrmDataAlm(CRM_PAPT_ALM_BOARD_PWR_OFF);

    return ;
}

/**************************************************************************
*                                  维测接口
**************************************************************************/

static UINT8 s_dpdicCrmAlmNameStr[IC_CRM_PAPT_ALARM_MAX_NUM][48] =
{
    "cfg_pdcfm0_1_rst_reg     ",
    "cfg_pdcfm0_0_rst_reg     ",
    "rst_glb_wd_ext_n_pulse_pa",
    "cfg_a53_cpu_po_rst_reg_3 ",
    "cfg_a53_cpu_po_rst_reg_2 ",
    "cfg_a53_cpu_po_rst_reg_1 ",
    "cfg_a53_cpu_po_rst_reg_0 ",
    "cfg_a53_core_rst_reg_3",
    "cfg_a53_core_rst_reg_2",
    "cfg_a53_core_rst_reg_1",
    "cfg_a53_core_rst_reg_0",
    "cfg_soc_glb_rst_reg   ",
    "cfg_lmsm0_rst_reg     ",
    "48V                   ",
    "5.5V_12V              ",
    "VINDOWN               ",
    "pll7                  ",
    "pll6                  ",
    "pll4                  ",
    "pll3                  ",
    "pll2                  ",
    "pll1                  ",
    "pll0                  ",
    "clk_j204_crm_ref0     ",
    "clk_opt_ref           ",
    "clk_roe_ref           "
};

static VOID CrmAlmEventPrn(UINT32 isClr)
{
    UINT32 loop = 0;
    UINT32 enMask=0,almMask=0,almTypeMask=0;
    UINT32 enVal=0,almVal=0;
    UINT32 crmAlmIdx = 0;

    (VOID)BspHalAdaptGetCrmAlarmType(&almMask, &almTypeMask);
    enMask = BspHalAdaptGetCrmPaptAlarmEnMask();

    dbgInfo("En Mask:       [%#x]\n",enMask);
    dbgInfo("Alm Mask:      [%#x]\n",almMask);
    dbgInfo("Alm Type Mask: [%#x]\n",almTypeMask);
    dbgInfo("------------------------------------------------------------------------\n");
    dbgInfo("%-4s %-32s %-9s %-8s\n",
            "type", "descript", "enable", "alarm");
    for (loop = 0; loop < IC_CRM_PAPT_ALARM_MAX_NUM; loop++)
    {
        enVal = !!(enMask & BSP_BIT_SET(loop));
        almVal = !!(almMask & BSP_BIT_SET(loop));
        crmAlmIdx = IC_CRM_PAPT_ALARM_MAX_NUM - loop - 1;
        dbgInfo("%-4x %-32s %-9s %-8s\n", loop, s_dpdicCrmAlmNameStr[crmAlmIdx], enVal?"Enable":"Disable", almVal?"Alarm":"OK");
    }
    dbgInfo("------------------------------------------------------------------------\n");

    if (isClr)
    {
        (VOID)BspHalAdaptClrAllCrmAlarm();
    }
}


static void crmpaprtprn(UINT32 isClr)
{
    CrmAlmEventPrn(isClr);
}

static VOID showcrmpaptdata(VOID)
{
    dbgInfo(" ------------------------------------------------------------------\n");
    dbgInfo("crm alarm:\n");
    dbgInfo("curCrmAlmTypeMask =       %#x\n", curCrmAlmTypeMask);
    dbgInfo("curCrmOrgAlmMask =        %#x\n", curCrmOrgAlmMask);
    dbgInfo("lastValidCrmAlmTypeMask = %#x\n", lastValidCrmAlmTypeMask);
    dbgInfo("lastValidCrmOrgAlmMask =  %#x\n", lastValidCrmOrgAlmMask);
    dbgInfo("dpdic4.0 crm module support 21 kinks of papt alarm.\n");
    dbgInfo(" ------------------------------------------------------------------\n");
    return;
}

/**************************************************************************
                             回调挂接
 **************************************************************************/
static __attribute((constructor)) void SetDpdic42CrmPaptFunc()
{

}


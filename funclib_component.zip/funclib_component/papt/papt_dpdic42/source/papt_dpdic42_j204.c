/*****************************************************************************
* 版权所有(C) 2017, ZTE Corp. ZXSDR-RRU Platform BSP
*----------------------------------------------------------------------------
* 模  块  名 : papt_dpdic42
* 文件名称 : papt_dpdic42_j204.c
* 文件标识 : {[N/A]}
* 内容摘要 : 本文件提供了PAPT公共模块的函数声明
* 注意事项 : 无
* 作       者 : 10248577
* 创建日期 : 2022-03-10
* 当前版本 : Ver1.0
*---------------------------------------------------------------------------*/
#include "papt_dpdic42_j204.h"
#include "ichaladapt_ic4_2.h"
#include "papt_common.h"
#include "j204_ic4_2.h"
#include "papt_private.h"
/**************************************************************************
 *                        宏定义
 **************************************************************************/


/**************************************************************************
 *                        数据类型定义
 **************************************************************************/



/**************************************************************************
 *                        全局变量
 **************************************************************************/


/**************************************************************************
*                         函数声明
**************************************************************************/



/**************************************************************************
*                         函数定义
**************************************************************************/
/*****************************************************************************
 * 函数名称: BspPaptJ204LinkPreStep(*)
 * 功能描述: J204告警恢复处理接口
 * 输入参数: chipIdMask - transceiver片号掩码
 * 输出参数: 无
 * 返 回 值: BSP_OK- 正常
 *           BSP_ERROR- 异常
 * 其它说明: 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10248577@2021-08-20, 创建
 *----------------------------------------------------------------------------
 */
static UINT32 BspPaptJ204LinkPreStep_IC42(UINT32 chipIdMask)
{
    /*
        目前在DPDIC4.2的机型中，DPDIC侧暂不支持部分204重建链，
        后面扩展支持按DPDIC的MAP为单位重建链（BspJ204LinkGrpPreStep），
        可以在此函数内增加Transceiver 片号和DPDIC的grp间的对应关系处理
        chipIdMask为0xFF时，代表需要DPDIC侧所有lane都需要重新建链
    */
    UINT32 retVal = BSP_OK;
    retVal |= BspJ204LinkInitStep();
    retVal |= BspJ204LinkPreStep();
    return retVal;
}

/*****************************************************************************
 * 函数名称: BspPaptJ204LinkPostStep(*)
 * 功能描述: J204告警恢复处理接口
 * 输入参数: chipId - transceiver片号
 * 输出参数: 无
 * 返 回 值: BSP_OK- 正常
 *           BSP_ERROR- 异常
 * 其它说明: 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10248577@2021-08-20, 创建
 *----------------------------------------------------------------------------
 */
static UINT32 BspPaptJ204LinkPostStep_IC42(UINT32 chipIdMask)
{
    /*
        目前在DPDIC4.2的机型中，DPDIC侧暂不支持部分204重建链，
        后面扩展支持按DPDIC的MAP为单位重建链（BspJ204LinkGrpPostStep），
        可以在此函数内增加Transceiver 片号和DPDIC的grp间的对应关系处理
        chipIdMask为0xFF时，代表需要DPDIC侧所有lane都需要重新建链
    */
    return BspJ204LinkPostStep();
}

/*****************************************************************************
 * 函数名称: BspPaptJ204LinkPostStep(*)
 * 功能描述: J204 SysRef信号发送接口
 * 输入参数: chipId - transceiver片号
 * 输出参数: 无
 * 返 回 值: BSP_OK- 正常
 *           BSP_ERROR- 异常
 * 其它说明: 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10248577@2021-08-20, 创建
 *----------------------------------------------------------------------------
 */
static UINT32 BspPaptJ204SendSysref_IC42(UINT32 chipIdMask, UINT32 num)
{
    /*
       DPDIC4.2给Sysref固定按照脉冲方式发送
    */
    return BspJ204SysrefRequest(1, E_SYSREF_MODE_PULSE, num, chipIdMask);
}

static UINT32 BspPaptJ204RwAddrDiffCheck_IC42(UINT32 chipIdMask, UINT32 *state)
{
    /*
        目前在DPDIC4.2的机型中，DPDIC侧暂不支持部分204重建链，
        后面扩展支持按DPDIC的MAP为单位重建链，可以在此函数内增加Transceiver 片号和DPDIC的grp间的对应关系处理
        根据对应的Grp，进一步确定判断哪些lane处于读写地址冲突检测范围，
        下面对范围内的lane进行检查，暂时按照对全部lane进行检查处理
    */
    UINT32 retVal = BSP_OK;
    UINT32 rwAddrDifstat = 0;

    retVal = BspJ204GetRwAddrDifStatus(&rwAddrDifstat);
    if(BSP_OK == retVal)
    {
        *state = rwAddrDifstat;
    }
    return retVal;
}
static UINT32 BspPaptJ204RwAddrDiffRecover_IC42(UINT32 chipIdMask)
{
    /*
        目前在DPDIC4.2的机型中，DPDIC侧暂不支持部分204重建链，
        后面扩展支持按DPDIC的MAP为单位重建链，可以在此函数内增加Transceiver 片号和DPDIC的grp间的对应关系处理
        根据对应的Grp，进一步确定判断哪些lane处于读写地址冲突恢复的范围，
        下面对范围内的lane进行恢复，暂时按照对全部lane进行恢复处理
    */
    UINT32 retVal = BSP_OK;
    UINT32 rwAddrDifstat = 0;
    UINT32 recVal = 0x3;

    retVal = BspJ204GetRwAddrDifStatus(&rwAddrDifstat);
    if(BSP_OK == retVal)
    {
        if(rwAddrDifstat & 0xF)
        {
            BspGetJ204LemcOffSetRecoverVal(RX, &recVal);
            retVal |= BspJ204LemcOffsetRecover(RX, recVal);
        }
        if(rwAddrDifstat & 0xF0)
        {
            BspGetJ204LemcOffSetRecoverVal(PRX, &recVal);
            retVal |= BspJ204LemcOffsetRecover(PRX, recVal);
        }
    }
    return retVal;
}

/*****************************************************************************
 * 函数名称: BspGetIcJ204LaneStatus
 * 功能描述: 获取上行、反馈Lane的状态
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值: lane的状态(上行、反馈Lane同步状态+上行Lane的CRC误码状态)
 * 其它说明: 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10248577@2021-08-20, 创建
 *----------------------------------------------------------------------------
 */
UINT32 BspGetIcJ204LaneStatus(VOID)
{
    UINT32 uLLinkStat = 0;
    UINT32 ulCrcStat = 0;
    UINT32 laneState = 0;

    //Rx、Fb的的建链状态
    if(BSP_OK != BspJ204GetLinkStatus(&uLLinkStat))
    {
        uLLinkStat = 0;
        dbgErr("%s>> BspJ204GetLinkStatus error.\n", __FUNCTION__);
    }
    laneState |= uLLinkStat;

    //Rx、Fb的CRC校验结果
    if(BSP_OK != BspJ204GetCrcErrStat(&ulCrcStat))
    {
        ulCrcStat = 0;
        dbgErr("%s>> BspGetIcRxCrcErrCode error.\n",__FUNCTION__);
    }
    laneState |= ulCrcStat;

    dbgInfoEx("%s >> laneState=%#x\n", __FUNCTION__, laneState);

    return laneState;
}


/**************************************************************************
                             回调挂接
 **************************************************************************/
static __attribute((constructor)) void SetDpdic42J204PaptFunc()
{
    /* J204告警恢复处理接口注册 */
    (void)BspPaptSetJ204LinkPreFunc(BspPaptJ204LinkPreStep_IC42);
    (void)BspPaptSetJ204LinkPostFunc(BspPaptJ204LinkPostStep_IC42);
    (void)BspPaptSetJ204SendSysrefFunc(BspPaptJ204SendSysref_IC42);
    (void)BspPaptSetJ204RwAddrDifCheckFunc(BspPaptJ204RwAddrDiffCheck_IC42);
    (void)BspPaptSetJ204RwAddrDifRecoverFunc(BspPaptJ204RwAddrDiffRecover_IC42);
}


/*****************************************************************************
* 版权所有(C) 2017, ZTE Corp. ZXSDR-RRU Platform BSP
*----------------------------------------------------------------------------
* 模  块  名 : papt_dpdic42
* 文件名称 : papt_dpdic42.c
* 文件标识 : {[N/A]}
* 内容摘要 : 本文件提供了PAPT公共模块的函数声明
* 注意事项 : 无
* 作       者 : 10248577
* 创建日期 : 2022-03-10
* 当前版本 : Ver1.0
*---------------------------------------------------------------------------*/
#include "papt_dpdic42.h"
#include "ru_basedef.h"
#include "ichaladapt_ic4_2.h"
#include "papt_common.h"
#include "chnmap_a.h"
#include "papt_maintain.h"
#include "funccommon_log.h"
#include "papt_dpdic42_crm.h"
#include "papt_dpdic42_j204.h"

/**************************************************************************
 *                        宏定义
 **************************************************************************/
#define DGB_CHAN_MAX_NUM (8)

/*
    CRM PLL和RESET告警都会保存在s_aulDpdicPastPaProAlmFlag的20号位置
    会出现相互覆盖的情况，故将CRM PLL告警移动到24号位置
*/
#define CRM_PLL_ALARM_SAVE_IDX  (24)

/**************************************************************************
 *                        数据类型定义
 **************************************************************************/
typedef struct _T_DbgPaptHalData
 {
     UINT32  almEnFlag;                /* 最近一次从HAL层读取的告警使能              */
     UINT32  curAlmStatus;             /* 最近一次从HAL层读取的告警状态              */
     UINT32  lastValidAlmStatus;       /* 最近一次从HAL层读取的有效告警状态              */
     UINT32  clrAlmIdx;                /* 最近一次清除的告警          */
 }T_DbgPaptHalData;


/**************************************************************************
 *                        全局变量
 **************************************************************************/
static T_DbgPaptHalData s_dbgPaptHalData[DGB_CHAN_MAX_NUM] = {0};

/* 功放保护告警分类的掩码(含光口、CFR、DPD等3个分类) */
static T_PaptAlmClassifyMask s_paptClassifyMask =
{
    .optPaptAlmPosEnMask = 0x1A00000, /* 21, 23, 24 */
    .cfrPaptAlmPosEnMask = 0x2000,    /* 13 */
    .dpdPaptAlmPosEnMask = 0xC00      /*10 11 */
};

/**************************************************************************
*                         函数声明
**************************************************************************/



/**************************************************************************
*                         函数定义
**************************************************************************/

/* 根据向高层上报的告警类型获得对应在DPDIC4.2中的功放保护告警的bit位序号 */
UINT32 GetDpdicAlmIdxByAlmType(E_PaProType ePaAlmType)
{
    UINT32 ulInfoOffsetRet = 0;

    switch (ePaAlmType)
    {
        case E_PA_PRO_TYPE_LOCAL_FREQ_OUT_BAND_PWR:
            ulInfoOffsetRet = 9;
            break;
        case E_PA_PRO_TYPE_LOCAL_FREQ_LONG_AVG_PWR:
            ulInfoOffsetRet = 13;
            break;
        case E_PA_PRO_TYPE_LOCAL_FREQ_ONE_SIG_PWR:
            ulInfoOffsetRet = 11;
            break;
        case E_PA_PRO_TYPE_CRM_SEND_RESET_UNUS:
            ulInfoOffsetRet = 20;
            break;
        case E_PA_PRO_TYPE_LOCAL_OSC_CLK_UNLOCK:
            ulInfoOffsetRet = 23;
            break;
        case E_PA_PRO_TYPE_CRM_SEND_CLK_UNUS:
            ulInfoOffsetRet = 20;
            break;
        case E_PA_PRO_TYPE_OPT_DATA_OFF_UNUS:
            ulInfoOffsetRet = 21;
            break;
        case E_PA_PRO_TYPE_OPT_PA_OFF_UNUS:
            ulInfoOffsetRet = 21;
            break;
        case E_PA_PRO_TYPE_LOCAL_FREQ_DPD_AVG_PWR:
            ulInfoOffsetRet = 10;
            break;
        case E_PA_PRO_TYPE_LOCAL_FREQ_MC_SYNC_RW:
            ulInfoOffsetRet = 7;
            break;
        case E_PA_PRO_TYPE_BOARD_PWR_ALARM:
            ulInfoOffsetRet = 20;
            break; 
        default:
            ulInfoOffsetRet = DPDIC_PAPRO_ALM_TYPE_MAX_IDX;
            break;
    }

    return ulInfoOffsetRet;
}

/* 根据功放保护告警的bit位序号，获取该种告警是否处于使能状态 */
UINT32 GetDpdicAlmEnFlag(UINT32 bspChan, UINT32 almIdx, UINT32 *pAlmEnFlag)
{
    UINT32 chipId = 0;
    UINT32 difChan = 0;
    UINT32 retVal = 0;
    UINT32 mask = 0;
    T_BspFuRuSupportAvgPaptInfo tmp = {0};
    UINT32 tmpVal = 0;

    INPUT_POINTER_CHECK(pAlmEnFlag);
    retVal = BspGetDifInfoByBspChn(bspChan, TX, &chipId, &difChan);
    if (BSP_OK != retVal)
    {
        dbgErr("[%s] bspChan[%d] Get difChan[%d] Error!\n",
               __FUNCTION__, bspChan, difChan);

        /* 维测 */
        if(bspChan < DGB_CHAN_MAX_NUM) s_dbgPaptHalData[bspChan].almEnFlag = PAPT_INVALID_DATA_32;

        return retVal;
    }

    retVal = BspHalAdaptGetPaptDaOffMask(difChan, &mask);
    if (BSP_OK != retVal)
    {
        dbgErr("[%s] BspHalAdaptGetPaptDaOffMask Error, difChan[%d]\n",
               __FUNCTION__, difChan);

        /* 维测 */
        if(bspChan < DGB_CHAN_MAX_NUM) s_dbgPaptHalData[bspChan].almEnFlag = PAPT_INVALID_DATA_32;

        return retVal;
    }

    *pAlmEnFlag = (mask & (0x01<<almIdx))?1:0;
    tmpVal = BspGetRruSpecialAbility(BSP_FU_RU_SPE_AVG_PAPT, &tmp, sizeof(T_BspFuRuSupportAvgPaptInfo));
    if((BSP_OK == tmpVal)&&(almIdx == GetDpdicAlmIdxByAlmType(E_PA_PRO_TYPE_LOCAL_FREQ_LONG_AVG_PWR)))
    {
        dbgInfoEx("1-bspChan %d, almIdx %d, *pAlmEnFlag %d\n", bspChan, almIdx, *pAlmEnFlag);
        if((1 == tmp.usSupportAvgPaptFlag)&&(0 != (tmp.ulChanMask&(1<<bspChan))))
        {
            *pAlmEnFlag = 1;   /*特殊策略 关数据功放的掩码不配置但是告警还是要上报*/
        }
        dbgInfoEx("2-bspChan %d, almIdx %d , *pAlmEnFlag %d\n", bspChan, almIdx, *pAlmEnFlag);
    }
    /* 维测 */
    if(bspChan < DGB_CHAN_MAX_NUM)
    {
        s_dbgPaptHalData[bspChan].almEnFlag = mask;
    }

    return retVal;
}

/* 根据功放保护告警的bit位序号，获取该种告警是否处于告警状态 */
UINT32 GetDpdicAlmStatus(UINT32 bspChan, UINT32 almIdx, UINT32 *pAlmStatus)
{
    UINT32 chipId = 0;
    UINT32 difChan = 0;
    UINT32 retVal = 0;
    UINT32 rcd = 0;

    INPUT_POINTER_CHECK(pAlmStatus);
    retVal = BspGetDifInfoByBspChn(bspChan, TX, &chipId, &difChan);
    if (BSP_OK != retVal)
    {
        dbgErr("[%s] bspChan[%d] Get difChan[%d] Error!\n",
               __FUNCTION__, bspChan, difChan);
        /* 维测 */
        if(bspChan < DGB_CHAN_MAX_NUM) s_dbgPaptHalData[bspChan].curAlmStatus = PAPT_INVALID_DATA_32;
        return retVal;
    }

    retVal = BspHalAdaptGetPaptMonitorRpt(difChan, &rcd);
    if (BSP_OK != retVal)
    {
        dbgErr("[%s] BspHalAdaptGetPaptMonitorRpt Error, difChan[%d]\n",
               __FUNCTION__, difChan);
        /* 维测 */
        if(bspChan < DGB_CHAN_MAX_NUM) s_dbgPaptHalData[bspChan].curAlmStatus = PAPT_INVALID_DATA_32;
        return retVal;
    }

    *pAlmStatus = (rcd & (0x01<<almIdx))?1:0;

    /* 维测 */
    if(bspChan < DGB_CHAN_MAX_NUM)
    {
        s_dbgPaptHalData[bspChan].curAlmStatus = rcd;
        if(rcd)
        {
            s_dbgPaptHalData[bspChan].lastValidAlmStatus = rcd;
        }
    }

    return retVal;
}

/* 根据功放保护告警的bit位序号，清除对应的告警 */
UINT32 ClrDpdicAlmStatus(UINT32 bspChan, UINT32 almIdx)
{
    UINT32 chipId = 0;
    UINT32 difChan = 0;
    UINT32 retVal = 0;

    retVal = BspGetDifInfoByBspChn(bspChan, TX, &chipId, &difChan);
    if (BSP_OK != retVal)
    {
        dbgErr("[%s] bspChan[%d] Get difChan[%d] Error!\n",
               __FUNCTION__, bspChan, difChan);
        /* 维测 */
        if(bspChan < DGB_CHAN_MAX_NUM) s_dbgPaptHalData[bspChan].clrAlmIdx = PAPT_INVALID_DATA_32;
        return retVal;
    }

    retVal = BspHalAdaptClrPaptMonitorRpt(difChan, 0x01 << almIdx);
    if (BSP_OK != retVal)
    {
        dbgErr("[%s] BspHalAdaptClrPaptMonitorRpt Error, difChan[%d]\n",
               __FUNCTION__, difChan);
        /* 维测 */
        if(bspChan < DGB_CHAN_MAX_NUM) s_dbgPaptHalData[bspChan].clrAlmIdx = PAPT_INVALID_DATA_32;
        return retVal;
    }

    /* 维测 */
    if(bspChan < DGB_CHAN_MAX_NUM)
    {
        s_dbgPaptHalData[bspChan].clrAlmIdx = almIdx;
    }

    return retVal;
}

/*****************************************************************************
 * 函数名称: DpdicGetPaProAlmEnFlag(*)
 * 功能描述: FPGA 历史告警清除
 * 输入参数: ulChipIdx  - FPGA chip id
 *           ulBitsMask - 清除BitsMask
 * 输出参数: 无
 * 返 回 值: 0- 正常, 其它值- 异常
 * 其它说明: 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10248577@2020-07-08, 创建
 *----------------------------------------------------------------------------
 */
UINT32 DpdicGetPaProAlmEnFlag(UINT32 ulNormMode, UINT32 ulChipIdx, E_PaProType ePaAlmType)
{
    UINT32 ulChnlIdx = 0;
    UINT32 ulAlmEnFlag = 0;
    UINT32 ulBspChnlSum = 0;
    UINT32 ulAlmInfoIdx = 0;
    UINT32 ulValBuffIdx = 0;
    UINT32 ulRetAlmEnBits = 0;

    ulBspChnlSum = BspGetTxChannel();
    ulAlmInfoIdx = GetDpdicAlmIdxByAlmType(ePaAlmType);
    if (ulAlmInfoIdx >= DPDIC_PAPRO_ALM_TYPE_MAX_IDX)
    {
        dbgErr("%s>>Error! InfoIdx Over; InfoIdx(0~%d)= %d\n", __FUNCTION__,
               DPDIC_PAPRO_ALM_TYPE_MAX_IDX - 1, ulAlmInfoIdx);
        return BSP_OK; /* 异常情况下, 返回BSP_OK, 不使能 */
    }

    ulValBuffIdx = ulAlmInfoIdx % DPDIC_PAPRO_ALM_TYPE_MAX_IDX;

    /* 寄存器定义: 0-屏蔽, 1-使能; enRev定义为0 */
    for (ulChnlIdx = 0; ulChnlIdx < ulBspChnlSum; ulChnlIdx++)
    {
        ulAlmEnFlag = 0;
        if (BSP_OK == GetDpdicAlmEnFlag(ulChnlIdx, ulAlmInfoIdx, &ulAlmEnFlag))
        {
            ulRetAlmEnBits |= ulAlmEnFlag << ulChnlIdx;
        }
        if (0 == (ulNormMode | ulAlmEnFlag))
        {   /* 不使能的告警, 当前通道对应的上报APP告警标志BIT清零 */
            if(E_PA_PRO_TYPE_CRM_SEND_CLK_UNUS == ePaAlmType)
            {
                BspSetDpdicPaProAlmFlag(CRM_PLL_ALARM_SAVE_IDX,ulChnlIdx,0);
            }
            else 
            {
                BspSetDpdicPaProAlmFlag(ulValBuffIdx,ulChnlIdx,0);
            }
        }
    }

    dbgInfoEx("%s>>Fpga'%d AlmType'%d: AlmEnFlag= 0x%08X\n", __FUNCTION__,
              ulChipIdx, ePaAlmType, ulRetAlmEnBits);
    return ulRetAlmEnBits;
}

/*****************************************************************************
 * 函数名称: DpdicGetPastPaProAlmStatus(*)
 * 功能描述: FPGA 历史告警清除
 * 输入参数: ulChipIdx  - FPGA chip id
 *           ulBitsMask - 清除BitsMask
 * 输出参数: 无
 * 返 回 值: 0- 正常, 其它值- 异常
 * 其它说明: 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10248577@2020-07-08, 创建
 *----------------------------------------------------------------------------
 */
UINT32 DpdicGetPastPaProAlmStatus(UINT32 ulChipIdx, UINT32 ulBitsMask,
                         E_PaProType ePaAlmType, UINT32 *pulEventBits)
{
    UINT32 ulChnlIdx = 0;
//  UINT32 ulTestFlg = 0;
    UINT32 ulRdPaAlmVal = 0;
    UINT32 ulRetAlmBits = 0;
    UINT32 ulBspChnlSum = 0;
    UINT32 ulAlmInfoIdx = 0;
    UINT32 ulValBuffIdx = 0;

    ulBspChnlSum = BspGetTxChannel();
    ulAlmInfoIdx = GetDpdicAlmIdxByAlmType(ePaAlmType);
    if (ulAlmInfoIdx >= DPDIC_PAPRO_ALM_TYPE_MAX_IDX)
    {
        dbgErr("%s>>Error! InfoIdx Over; InfoIdx(0~%d)= %d\n", __FUNCTION__,
               DPDIC_PAPRO_ALM_TYPE_MAX_IDX - 1, ulAlmInfoIdx);
        return BSP_OK; /* 异常情况下, 返回BSP_OK, 不使能 */
    }

    ulValBuffIdx = ulAlmInfoIdx % DPDIC_PAPRO_ALM_TYPE_MAX_IDX;

    for (ulChnlIdx = 0; ulChnlIdx < ulBspChnlSum; ulChnlIdx++)
    {
        ulRdPaAlmVal = 0;

        if (BSP_OK == GetDpdicAlmStatus(ulChnlIdx, ulAlmInfoIdx, &ulRdPaAlmVal))
        {
            ulRetAlmBits |= (!!(ulRdPaAlmVal)) << ulChnlIdx;
        }
    }

    /* 如果是CRM告警，则需要继续区分详细告警种类 */
    if(ulRetAlmBits && IC_CRM_PAPT_BIT_INDEX == ulAlmInfoIdx)
    {
        (VOID)GetDpdicCrmDetailAlarmType(ePaAlmType, &ulRetAlmBits);
    }

    ulRetAlmBits &= ulBitsMask;

    /*///////////////// 模拟告警, 用于打桩测试 //////////////////////////
    ulTestFlg = (s_aulDbgSetPaProAlmFlag[ulValBuffIdx] >> 24) & 0xFF;
    if (PAPRO_ALM_DPDIC_DBG_FLAG == ulTestFlg)
    {
        ulRetAlmBits = s_aulDbgSetPaProAlmFlag[ulValBuffIdx] & 0x00FFFFFF;
    }
    ////////////////////////////////////////////////////////////////////*/

    if (NULL != pulEventBits)
    {
        *pulEventBits = ulRetAlmBits;
    }

    if(E_PA_PRO_TYPE_CRM_SEND_CLK_UNUS == ePaAlmType)
    {
        BspSetDpdicPaProAlmAllChn(CRM_PLL_ALARM_SAVE_IDX,(UINT64)ulRetAlmBits);
    }
    else 
    {
        BspSetDpdicPaProAlmAllChn(ulValBuffIdx,(UINT64)ulRetAlmBits);
    }
    
    dbgInfoEx("%s>>Dpdic'%d: ePaAlmType %d BitMask=0x%08X AlarmStatus=0x%08X\n", __FUNCTION__, ulChipIdx, ePaAlmType, ulBitsMask, ulRetAlmBits);
    if(0 != ulRetAlmBits)
    {
     BspLog(LOG_LEVEL_0,"%s>>Dpdic'%d: ePaAlmType %d BitMask=0x%08X AlarmStatus=0x%08X\n", __FUNCTION__, ulChipIdx, ePaAlmType, ulBitsMask, ulRetAlmBits);
    }
    return BSP_OK;
}

/*****************************************************************************
 * 函数名称: DpdicClrPastPaProAlmStatus(*)
 * 功能描述: FPGA 历史告警清除
 * 输入参数: ulChipIdx  - FPGA chip id
 *           ulBitsMask - 清除BitsMask
 * 输出参数: 无
 * 返 回 值: 0- 正常, 其它值- 异常
 * 其它说明: 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10248577@2020-07-08, 创建
 *----------------------------------------------------------------------------
 */
UINT32 DpdicClrPastPaProAlmStatus(UINT32 ulChipIdx, UINT32 ulBitsMask, E_PaProType ePaAlmType)
{
    UINT32 ulChnlIdx = 0;
    UINT32 ulBspChnlSum = 0;
    UINT32 ulAlmInfoIdx = 0;

    ulBspChnlSum = BspGetTxChannel();
    ulAlmInfoIdx = GetDpdicAlmIdxByAlmType(ePaAlmType);
    if (ulAlmInfoIdx >= DPDIC_PAPRO_ALM_TYPE_MAX_IDX)
    {
        dbgErr("%s>>Error! InfoIdx Over; InfoIdx(0~%d)= %d\n", __FUNCTION__,
               DPDIC_PAPRO_ALM_TYPE_MAX_IDX - 1, ulAlmInfoIdx);
        return BSP_OK; /* 异常情况下, 返回BSP_OK, 不使能 */
    }

    for (ulChnlIdx = 0; ulChnlIdx < ulBspChnlSum; ulChnlIdx++)
    {
        if (0 == (ulBitsMask & BIT_SET(ulChnlIdx)))
        {
            continue;
        }
        if (BSP_OK != ClrDpdicAlmStatus(ulChnlIdx, ulAlmInfoIdx))
        {
            dbgErr("%s ClrDpdicAlmStatus error, Chn=%d, AlmIdx=%d\n",
                __FUNCTION__, ulChnlIdx, ulAlmInfoIdx);
        }

        dbgInfoEx("%s>>Chnl'%2d: AlmIdx[%d] is cleared\n", __FUNCTION__, ulChnlIdx, ulAlmInfoIdx);

    }

    /* 如果是CRM告警，需要继续清除CRM内的告警 */
    if(IC_CRM_PAPT_BIT_INDEX == ulAlmInfoIdx)
    {
    #if 0 /* CRM类告警一旦发生，DPDIC会锁存，为保证软件上报和硬件锁存状态一致，CRM类告警不清除(闫峰建议) 20220126 */
        if (BSP_OK != ClrDpdicCrmDetailAlarm(ePaAlmType))
        {
            dbgErr("%s ClrDpdicCrmDetailAlarm error, ePaAlmType=%d\n", 
                __FUNCTION__, ePaAlmType);
        }
    #endif
    }

    return BSP_OK;
}

/*****************************************************************************
 * 函数名称: DpdicClrPastPaProAlmStatus(*)
 * 功能描述: FPGA 历史告警清除
 * 输入参数: ulChipIdx  - FPGA chip id
 *           ulBitsMask - 清除BitsMask
 * 输出参数: 无
 * 返 回 值: 0- 正常, 其它值- 异常
 * 其它说明: 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10248577@2020-07-08, 创建
 *----------------------------------------------------------------------------
 */
UINT32 BspDpdicGetPastPaProAlm(E_PaProType ePaProType, UINT64 *pu64EventBits)
{
    UINT32 ulAlmEnFlag = 0;
    UINT32 ulRetVal = BSP_OK;
    UINT32 ulEventBits = 0;
    UINT32 ulLastEventBits = 0;

    switch (ePaProType)
    {
        case E_PA_PRO_TYPE_LOCAL_FREQ_OUT_BAND_PWR:
        case E_PA_PRO_TYPE_LOCAL_FREQ_LONG_AVG_PWR:
        case E_PA_PRO_TYPE_LOCAL_FREQ_ONE_SIG_PWR:
        case E_PA_PRO_TYPE_CRM_SEND_RESET_UNUS:
        case E_PA_PRO_TYPE_LOCAL_OSC_CLK_UNLOCK:
        case E_PA_PRO_TYPE_CRM_SEND_CLK_UNUS:
        case E_PA_PRO_TYPE_OPT_DATA_OFF_UNUS:
        case E_PA_PRO_TYPE_OPT_PA_OFF_UNUS:
        case E_PA_PRO_TYPE_LOCAL_FREQ_DPD_AVG_PWR:
        case E_PA_PRO_TYPE_LOCAL_FREQ_MC_SYNC_RW:
            /* 获取使能标志, 只处理使能的告警 */
            ulAlmEnFlag = DpdicGetPaProAlmEnFlag(0, 0, ePaProType);
            ulRetVal    = DpdicGetPastPaProAlmStatus(0, ulAlmEnFlag, ePaProType, &ulEventBits);
            DpdicClrPastPaProAlmStatus(0, ulAlmEnFlag, ePaProType);
            break;
        case E_PA_PRO_TYPE_BOARD_PWR_ALARM:
            ulEventBits = (UINT64)GetBoardPwrReportAlarm();
            break;
        case E_PA_PRO_TYPE_IC_LANE_STATUS:
            ulEventBits = (UINT64)BspGetIcJ204LaneStatus();
            break;
        default:
            ulRetVal = BSP_ERROR;
            break;
    }

    if(ulLastEventBits != ulEventBits)
    {
        ulLastEventBits = ulEventBits;
        BspLog(LOG_LEVEL_0,"papt: %s: ePaProType[%d], ulEventBits[%d], ulLastEventBits[%d]\n",__FUNCTION__,ePaProType, ulEventBits, ulLastEventBits);
    }
    *pu64EventBits = (UINT64)ulEventBits;
    return ulRetVal; 
}

/*****************************************************************************
 * 函数名称: BspDpdicPaProAlmRecover(*)
 * 功能描述: DPDIC功放保护告警后处理
 * 输入参数: ulPaProAlmType - 告警类型
 *           u64AlmBitsMask - 告警掩码
 * 输出参数: 无
 * 返 回 值: 0- 正常或无后处理操作正常, 负值- 后处理操作异常, 正值- 表示有后处理操作
 * 其它说明: 连续pu64EventBits有3次告警, 才允许后处理
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10119095@2020-07-08, 创建
 *----------------------------------------------------------------------------
 */
INT32 BspDpdicPaProAlmRecover(E_PaProType ePaProType, UINT64 u64EventAlmMask)
{
    INT32  lFunRet = 0;
    
    switch (ePaProType)
    {
        case E_PA_PRO_TYPE_BOARD_PWR_ALARM:
            ClearBoardPwrAlarm();
            break;
        default:
            lFunRet = -1;
            break;
    }

    return lFunRet;    
}

/**************************************************************************
*                                  维测接口
**************************************************************************/

static VOID exprnadddpdicpapt(VOID)
{
    exprnadd("BspDpdicGetPastPaProAlm");
    exprnadd("BspGetIcJ204LaneStatus");
    exprnadd("DpdicGetPaProAlmEnFlag");
    exprnadd("DpdicGetPastPaProAlmStatus");
    exprnadd("DpdicClrPastPaProAlmStatus");
    exprnadd("BspHalAdaptGetCrmAlarmType");
    exprnadd("BspHalAdaptClrCrmAlarmType");    
    return;
}

static VOID showhalpaptdata(VOID)
{
    UINT32 loop=0;

    dbgInfo("chan  almEnFlag  curAlmStatus  lastValidAlmStatus  clrAlmIdx\n");
    for(loop=0; loop<DGB_CHAN_MAX_NUM; loop++)
    {
        dbgInfo("%4d  %9x  %12x  %18x  %9x\n", loop,
            s_dbgPaptHalData[loop].almEnFlag, s_dbgPaptHalData[loop].curAlmStatus,
            s_dbgPaptHalData[loop].lastValidAlmStatus, s_dbgPaptHalData[loop].clrAlmIdx);
    }
    dbgInfo("dpdic4.2 papt module support 24 kinds of papt alarm.\n");
    return;
}

/**************************************************************************
                             回调挂接
 **************************************************************************/
static __attribute((constructor)) void SetDpdic42PaptFunc() 
{
    /* 告警检测 */
    (VOID)BspSetGetPaProAlmFunc(E_PA_PRO_TYPE_LOCAL_FREQ_OUT_BAND_PWR,BspDpdicGetPastPaProAlm);
    (VOID)BspSetGetPaProAlmFunc(E_PA_PRO_TYPE_LOCAL_FREQ_LONG_AVG_PWR,BspDpdicGetPastPaProAlm);
    (VOID)BspSetGetPaProAlmFunc(E_PA_PRO_TYPE_LOCAL_FREQ_ONE_SIG_PWR,BspDpdicGetPastPaProAlm);
    (VOID)BspSetGetPaProAlmFunc(E_PA_PRO_TYPE_CRM_SEND_RESET_UNUS,BspDpdicGetPastPaProAlm);
    (VOID)BspSetGetPaProAlmFunc(E_PA_PRO_TYPE_LOCAL_OSC_CLK_UNLOCK,BspDpdicGetPastPaProAlm);
    (VOID)BspSetGetPaProAlmFunc(E_PA_PRO_TYPE_CRM_SEND_CLK_UNUS,BspDpdicGetPastPaProAlm);
    (VOID)BspSetGetPaProAlmFunc(E_PA_PRO_TYPE_OPT_DATA_OFF_UNUS,BspDpdicGetPastPaProAlm);
    (VOID)BspSetGetPaProAlmFunc(E_PA_PRO_TYPE_OPT_PA_OFF_UNUS,BspDpdicGetPastPaProAlm);
    (VOID)BspSetGetPaProAlmFunc(E_PA_PRO_TYPE_LOCAL_FREQ_DPD_AVG_PWR,BspDpdicGetPastPaProAlm);
    (VOID)BspSetGetPaProAlmFunc(E_PA_PRO_TYPE_LOCAL_FREQ_MC_SYNC_RW,BspDpdicGetPastPaProAlm);
    (VOID)BspSetGetPaProAlmFunc(E_PA_PRO_TYPE_LOCAL_FREQ_MC_SYNC_RW,BspDpdicGetPastPaProAlm);
    (VOID)BspSetGetPaProAlmFunc(E_PA_PRO_TYPE_BOARD_PWR_ALARM,BspDpdicGetPastPaProAlm);
    (VOID)BspSetGetPaProAlmFunc(E_PA_PRO_TYPE_IC_LANE_STATUS,BspDpdicGetPastPaProAlm);

    /* 告警恢复 */
    (VOID)BspSetPaProAlmRecoverFunc(E_PA_PRO_TYPE_BOARD_PWR_ALARM,BspDpdicPaProAlmRecover);

    /* 设置功放保护告警分类的掩码(含光口、CFR、DPD等3个分类) */
    BspSetDpdicPaptAlmClassifyMask(&s_paptClassifyMask);
}


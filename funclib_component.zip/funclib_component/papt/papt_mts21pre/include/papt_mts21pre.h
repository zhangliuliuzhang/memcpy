/*****************************************************************************
* 版权所有(C) 2017, ZTE Corp. ZXSDR-RRU Platform BSP
*----------------------------------------------------------------------------
* 模  块  名 : papt_mts21pre
* 文件名称 : papt_mts21pre.h
* 文件标识 : {[N/A]}
* 内容摘要 : 本文件提供了PAPT公共模块的函数实现
* 注意事项 : 无
* 作       者 : 10248577
* 创建日期 : 2022-03-10
* 当前版本 : Ver1.0
*---------------------------------------------------------------------------*/
#ifndef _FUNCLIB_PAPT_MTS21PRE_H_
#define _FUNCLIB_PAPT_MTS21PRE_H_

#ifdef __cplusplus
extern "C" {
#endif

#include "bsppub.h"
#include "bspcomm.h"
#include "papt_common.h"

/**************************************************************************
 *                        宏
 **************************************************************************/


/**************************************************************************
 *                         数据类型
 **************************************************************************/


/**************************************************************************
*                         函数声明
**************************************************************************/
INT32 Mts21GetPastPaProAlm(UINT32 chipId, E_TRANS_PAPRO_ALM_TYPE ulAlmType, UINT64 *pu64EventBits);
INT32 Mts21ClrPastPaProAlm(UINT32 chipId, E_TRANS_PAPRO_ALM_TYPE ulAlmType);
INT32 Mts21PaProAlmRecover(UINT32 chipId, E_TRANS_PAPRO_ALM_TYPE ulAlmType, UINT64 u64AlmBitsMask);
INT32 Mts21ClrAlmAfterInit(UINT32 chipId);
INT32 Mts21IcLaneAlmRecover(E_PaProType ePaProType, UINT64 u64AlmBitsMask);


#ifdef __cplusplus
}
#endif

#endif

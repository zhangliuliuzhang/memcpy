/*****************************************************************************
* 版权所有(C) 2017, ZTE Corp. ZXSDR-RRU Platform BSP
*----------------------------------------------------------------------------
* 模 块 名 : bsp
* 文件名称 : paptapi.h
* 文件标识 : {[N/A]}
* 内容摘要 : 本文件提供了PAPT模块对APP接口声明
* 注意事项 : 无
* 作    者 :   10248577
* 创建日期 : 2024-03-21
* 当前版本 : Ver1.0
*----------------------------------------------------------------------------
*/

#ifndef _FUNCLIB_PAPTAPI_H_
#define _FUNCLIB_PAPTAPI_H_

#ifdef __cplusplus
extern "C" {
#endif

#include "bsppub.h"

UINT32 BspGetPaProPastAlm(T_PaProInputParam *ptPaProParam, T_PaProFlagOutput *ptPaProOutput);
INT32 BspPaProAlmRecover(UINT32 ulPaProAlmType, UINT64 u64EventAlmMask);
UINT32 BspGetPaProtectAlmFlag(UINT32 ulBspChnl, UINT32 *pulPaProFlag);

#ifdef __cplusplus
}
#endif
#endif 


##@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
# arm_eabi_gcc4.8.2_glibc_2.18.0_fp.mak - ZTE RRU BSP LINUX����ϵͳ XILINX MPSOC �� CPU ͨ�ñ��뻷������
#
# Copyright 1985-2017 ZTE Corporation, RRU Platform
#
# �޸ļ�¼
# ------------------------------------------------------------------------------
#   ��־ǿ@2017-1-22 11:43:35 �����ļ�
#
# ��������
#   �ṩͨ�õĹ��߼�����ѡ������
#
# ʹ�÷���
#   ��makeconfig.mak����
#
################################################################################

##******************************************************************************
## �����趨(�����ϵͳ·��, �ƺ�������Ҳ���Ա���ͨ��, �����?)
##++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
TOOLS_CHAINS=arm/arm_eabi_gcc4.8.2_glibc2.18.0_fp
KIDE_TOOL_BASE = $(subst \,/,$(LINUX_BASE))

ifeq (,$(findstring $(TOOLS_CHAINS), $(KIDE_TOOL_BASE)))
	LINUX_BASE   :=$(subst \,/,$(LINUX_BASE)/$(TOOLS_CHAINS))
endif

GCC_BIN_PREFIX   = $(call CONVERT_SLASH,$(LINUX_BASE)/bin/arm-unknown-linux-gnueabi-)

SYS_INC_PATH     = -I$(LINUX_BASE)/arm-unknown-linux-gnueabi/include \
                   -I$(LINUX_BASE)/arm-unknown-linux-gnueabi/include/c++/4.8.2 \
                   -I$(LINUX_BASE)/arm-unknown-linux-gnueabi/include/c++/4.8.2/arm-unknown-linux-gnueabi \
                   -I$(LINUX_BASE)/lib/gcc/arm-unknown-linux-gnueabi/4.8.2/include

CC_ARCH_SPEC     = -march=armv8-a #-mtune=cortex-a53

CFLAGS          += $(_C_DEBUG) $(CC_ARCH_SPEC) -DRW_MULTI_THREAD \
                   -D_REENTRANT -fno-builtin \
                   -DVOS_LINUX -D_GNU_SOURCE -D_BYTE_ORDER=_BIG_ENDIAN -D_ARM_CPU_
CXXFLAGS        += $(_C_DEBUG) $(CC_ARCH_SPEC) -DRW_MULTI_THREAD \
                   -D_REENTRANT  -msoft-float 
CFLAGS_AS       += $(_AS_DEBUG) $(CC_ARCH_SPEC) -fno-builtin \
                   -P -x assembler-with-cpp 
DEPCFLAGS       += -MM $(CC_ARCH_SPEC) $(BATCH_INCLUDE) $(_COMMON_FLAGS)
DEPCFLAGS_AS    += $(DEPCFLAGS) -x assembler-with-cpp
LDFLAGS         += 
LD_PARTIAL_FLAGS+= -r
LD_LOW_FLAGS    += -Ttext $(RAM_LOW_ADRS)
LD_HIGH_FLAGS   += -Ttext $(RAM_HIGH_ADRS)

##******************************************************************************
## ִ�������趨
##++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
AR               = $(GCC_BIN_PREFIX)ar$(EXE_SUFFIX)
AS               = $(GCC_BIN_PREFIX)gcc$(EXE_SUFFIX)
CC               = @$(GCC_BIN_PREFIX)gcc$(EXE_SUFFIX)
LD               = $(GCC_BIN_PREFIX)ld$(EXE_SUFFIX) $(_LD_DEBUG)
NM               = $(GCC_BIN_PREFIX)nm$(EXE_SUFFIX)
SIZE             = $(GCC_BIN_PREFIX)size$(EXE_SUFFIX)
OBJCPY           = $(GCC_BIN_PREFIX)objcopy$(EXE_SUFFIX)
STRIP            = $(GCC_BIN_PREFIX)strip$(EXE_SUFFIX)
##==============================================================================
## �ļ�����
##------------------------------------------------------------------------------


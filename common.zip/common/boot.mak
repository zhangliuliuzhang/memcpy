##@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
# Modules.mak - ZTE RRU BSP ģ����� makefile �����ļ�, �������������ģ��Ŀ��
#
# Copyright 1985-2010 ZTE Corporation, RRU Platform
#
# �޸ļ�¼
# ------------------------------------------------------------------------------
#   ������@2010-5-16 19:33:43 �����ļ�
#
# ��������
#   �ṩͨ��ģ��������
#
# ʹ��˵��
#   ��������ģ�����, ��Ҫ�ϼ��ṩ���±���
#
#       _BSP_BOOT_SRC_PATH
#       _BSP_BOOT_TGT_PATH
#       _BSP_BOOT_OBJ_PATH
#       _BSP_BOOT_DEP_PATH
#
################################################################################

_SRC_P  = $(_BSP_BOOT_SRC_PATH)/$(_B_NAME)
_DEP_P  = $(_BSP_BOOT_DEP_PATH)/$(_B_NAME)
_OBJ_P  = $(_BSP_BOOT_OBJ_PATH)/$(_B_NAME)
_TGT_P  = $(_BSP_BOOT_TGT_PATH)
#add by renkang
_LOB_P  = $(_BSP_BOOT_LOB_PATH)/$(_B_NAME)
_LINT_P = $(_BSP_BOOT_LINT_PATH)/$(_B_NAME)
##******************************************************************************
## ���������ģ��Ŀ¼������Ҫ��Դ����(ͨ��ѡȡ�����ļ�)
##++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
_SRCS ?= $(wildcard $(_SRC_P)/source/*.c)

ifeq (loadversion,$(_B_NAME))
ifeq (DRA62X,$(SYSTEM))
  _SRCS += $(wildcard $(_BSP_BOOT_SRC_PATH)/cpu/dra62xboot/*.c)
endif
ifeq (ZX2114XX,$(SYSTEM))   
  _SRCS += $(wildcard $(_BSP_BOOT_SRC_PATH)/cpu/zx211410boot/*.c)  
  ifneq (Y, $(_BSP_KEXEC_BOOT_TYPE))
    BOOT_FILTER_OUT_SRCS = halboot.c
  endif
endif
ifeq (ZX2112XX,$(SYSTEM))   
  _SRCS += $(wildcard $(_BSP_BOOT_SRC_PATH)/cpu/zx211201boot/*.c)  
  ifneq (Y, $(_BSP_KEXEC_BOOT_TYPE))
    BOOT_FILTER_OUT_SRCS = halboot.c
  endif
endif
ifeq (ZYNQMPSOC,$(SYSTEM))
	_SRCS += $(wildcard $(_BSP_BOOT_SRC_PATH)/cpu/zynqmpsocboot/*.c) 
endif
ifeq (AM572X,$(SYSTEM))
   _SRCS += $(wildcard $(_BSP_BOOT_SRC_PATH)/cpu/am572xboot/*.c)
endif
ifeq (LS10X3A,$(SYSTEM))
  _SRCS += $(wildcard $(_BSP_BOOT_SRC_PATH)/cpu/ls10x3aboot/*.c)
endif
endif


_SRCS_NO_DIR := $(notdir $(_SRCS))
_SRCS_NO_DIR := $(filter-out $(BOOT_FILTER_OUT_SRCS),$(_SRCS_NO_DIR))
_SRCS := $(foreach EACH_SRC,$(_SRCS_NO_DIR),$(addprefix $(_SRC_P)/source/,$(EACH_SRC)))

##******************************************************************************
## ����ͨ�������ļ�
##++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
include $(_BSP_SOURCE_PATH)/common/makeconfig.mak

##******************************************************************************
## �����ļ�����·������(�û�·������, �������ܸ���ȱʡ����)
##++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
##vpath %.c  $(_SRC_P)/Source:$(_BSP_COMMON_SRC_PATH)
##vpath %.h  $(_SRC_P)/Include:$(_BSP_COMMON_SRC_PATH)
##vpath %.o  $(_OBJ_P)

##******************************************************************************
## ȷ�������ļ���Ŀ���ļ�
##++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
_OBJS   = $(addprefix $(_OBJ_P)/,$(notdir $(_SRCS:.c=.o)))
_DEPS   = $(addprefix $(_DEP_P)/,$(notdir $(_SRCS:.c=.d)))
#add by renkang
_LOBS   = $(addprefix $(_LOB_P)/,$(notdir $(_SRCS:.c=.lob)))

# ���Ƿ� 2011��09��05��
_LINT_ERRS = $(addprefix $(_LINT_P)/,$(notdir $(_SRCS:.c=.txt)))
##******************************************************************************
## αĿ�궨��(����������������Ƿ�Ŀ���Ѿ�����, ���Ӧ�Ĺ���ǿ��ִ��)
##++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
.PHONY: CheckDirReady

################################################################################
## ���������Ŀ���(ִ��֮ǰ�����·������)
##<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
default: $(_TGT_P)/lib$(_B_NAME).o
$(_TGT_P)/lib$(_B_NAME).o: $(_OBJS)
	$(ECHO) -n Making $(subst \\,/,$@) ...... 
	$(MKDIR) $(_TGT_P)
	$(LD) -r -o $@ $(filter-out CheckDirReady, $+)
	$(ECHO) ^ Done!
	$(ECHO) $(subst 8,..........,88888888)
	$(ECHO) . Boot $@ has been completed!
	$(ECHO) $(subst 8,..........,88888888)

##******************************************************************************
## �����ļ����ɹ���
##++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
$(_DEP_P)/%.d: $(_SRC_P)/source/%.c 
	$(MKDIR) $(_DEP_P)
	$(ECHO) -n Making $(subst /,\,$@)  ...... 
	$(CC) -MM $(CFLAGS) $(INCL_PATH) -c $< | sed \
      "s/$*\.o[ :]*/$(subst /,\/,$(_OBJ_P))\/$*.o $(subst /,\/,$(_DEP_P))\/$*.d \: /g" > $@
	$(ECHO) ^ Done!  

ifeq (loadversion,$(_B_NAME))
ifeq (DRA62X,$(SYSTEM))	
$(_DEP_P)/%.d: $(_BSP_BOOT_SRC_PATH)/cpu/dra62xboot/%.c
	$(MKDIR) $(_DEP_P)
	$(ECHO) -n Making $(subst /,\,$@)  ...... 
	$(CC) -MM $(CFLAGS) $(INCL_PATH) -c $< | sed \
      "s/$*\.o[ :]*/$(subst /,\/,$(_OBJ_P))\/$*.o $(subst /,\/,$(_DEP_P))\/$*.d \: /g" > $@
	$(ECHO) ^ Done!  
endif
ifeq (ZX2114XX,$(SYSTEM)) 
$(_DEP_P)/%.d: $(_BSP_BOOT_SRC_PATH)/cpu/zx211410boot/%.c
	$(MKDIR) $(_DEP_P)
	$(ECHO) -n Making $(subst /,\,$@)  ...... 
	$(CC) -MM $(CFLAGS) $(INCL_PATH) -c $< | sed \
      "s/$*\.o[ :]*/$(subst /,\/,$(_OBJ_P))\/$*.o $(subst /,\/,$(_DEP_P))\/$*.d \: /g" > $@
	$(ECHO) ^ Done! 
endif
ifeq (ZX2112XX,$(SYSTEM)) 
$(_DEP_P)/%.d: $(_BSP_BOOT_SRC_PATH)/cpu/zx211201boot/%.c
	$(MKDIR) $(_DEP_P)
	$(ECHO) -n Making $(subst /,\,$@)  ...... 
	$(CC) -MM $(CFLAGS) $(INCL_PATH) -c $< | sed \
      "s/$*\.o[ :]*/$(subst /,\/,$(_OBJ_P))\/$*.o $(subst /,\/,$(_DEP_P))\/$*.d \: /g" > $@
	$(ECHO) ^ Done! 
endif
ifeq (ZYNQMPSOC,$(SYSTEM)) 
$(_DEP_P)/%.d: $(_BSP_BOOT_SRC_PATH)/cpu/zynqmpsocboot/%.c
	$(MKDIR) $(_DEP_P)
	$(ECHO) -n Making $(subst /,\,$@)  ...... 
	$(CC) -MM $(CFLAGS) $(INCL_PATH) -c $< | sed \
      "s/$*\.o[ :]*/$(subst /,\/,$(_OBJ_P))\/$*.o $(subst /,\/,$(_DEP_P))\/$*.d \: /g" > $@
	$(ECHO) ^ Done! 
endif
ifeq (AM572X,$(SYSTEM))
$(_DEP_P)/%.d: $(_BSP_BOOT_SRC_PATH)/cpu/am572xboot/%.c
	$(MKDIR) $(_DEP_P)
	$(ECHO) -n Making $(subst /,\,$@)  ...... 
	$(CC) -MM $(CFLAGS) $(INCL_PATH) -c $< | sed \
      "s/$*\.o[ :]*/$(subst /,\/,$(_OBJ_P))\/$*.o $(subst /,\/,$(_DEP_P))\/$*.d \: /g" > $@
	$(ECHO) ^ Done! 
endif
ifeq (LS10X3A,$(SYSTEM))
$(_DEP_P)/%.d: $(_BSP_BOOT_SRC_PATH)/cpu/ls10x3aboot/%.c
	$(MKDIR) $(_DEP_P)
	$(ECHO) -n Making $(subst /,\,$@)  ...... 
	$(CC) -MM $(CFLAGS) $(INCL_PATH) -c $< | sed \
      "s/$*\.o[ :]*/$(subst /,\/,$(_OBJ_P))\/$*.o $(subst /,\/,$(_DEP_P))\/$*.d \: /g" > $@
	$(ECHO) ^ Done! 
endif
endif

$(_DEP_P)/%.d: $(_SRC_P)/test/%.c 
	$(MKDIR) $(_DEP_P)
	$(ECHO) -n Making $(subst /,\,$@)  ...... 
	$(CC) -MM $(CFLAGS) $(INCL_PATH) -c $< | sed \
      "s/$*\.o[ :]*/$(subst /,\/,$(_OBJ_P))\/$*.o $(subst /,\/,$(_DEP_P))\/$*.d \: /g" > $@
	$(ECHO) ^ Done!  
	
##******************************************************************************
## �����Ŀ���ļ����ɹ���
##++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
$(_OBJ_P)/%.o: $(_SRC_P)/source/%.c
	$(MKDIR) $(_OBJ_P)
	$(ECHO) -n Making $(subst /,\,$@) ...... 
	$(CC) $(CFLAGS) $(INCL_PATH) -c $< -o $@
	$(ECHO) ^ Done!
	

ifeq (loadversion,$(_B_NAME))
ifeq (DRA62X,$(SYSTEM))		
$(_OBJ_P)/%.o: $(_BSP_BOOT_SRC_PATH)/cpu/dra62xboot/%.c
	$(MKDIR) $(_OBJ_P)
	$(ECHO) -n Making $(subst /,\,$@) ...... 
	$(CC) $(CFLAGS) $(INCL_PATH) -c $< -o $@
	$(ECHO) ^ Done!
endif
ifeq (ZX2114XX,$(SYSTEM)) 
$(_OBJ_P)/%.o: $(_BSP_BOOT_SRC_PATH)/cpu/zx211410boot/%.c
	$(MKDIR) $(_OBJ_P)
	$(ECHO) -n Making $(subst /,\,$@) ...... 
	$(CC) $(CFLAGS) $(INCL_PATH) -c $< -o $@
	$(ECHO) ^ Done!
endif
ifeq (ZX2112XX,$(SYSTEM)) 
$(_OBJ_P)/%.o: $(_BSP_BOOT_SRC_PATH)/cpu/zx211201boot/%.c
	$(MKDIR) $(_OBJ_P)
	$(ECHO) -n Making $(subst /,\,$@) ...... 
	$(CC) $(CFLAGS) $(INCL_PATH) -c $< -o $@
	$(ECHO) ^ Done!
endif
ifeq (ZYNQMPSOC,$(SYSTEM))
$(_OBJ_P)/%.o: $(_BSP_BOOT_SRC_PATH)/cpu/zynqmpsocboot/%.c
	$(MKDIR) $(_OBJ_P)
	$(ECHO) -n Making $(subst /,\,$@) ...... 
	$(CC) $(CFLAGS) $(INCL_PATH) -c $< -o $@
	$(ECHO) ^ Done!
endif
ifeq (AM572X,$(SYSTEM))
$(_OBJ_P)/%.o: $(_BSP_BOOT_SRC_PATH)/cpu/am572xboot/%.c
	$(MKDIR) $(_OBJ_P)
	$(ECHO) -n Making $(subst /,\,$@) ...... 
	$(CC) $(CFLAGS) $(INCL_PATH) -c $< -o $@
	$(ECHO) ^ Done!
endif
ifeq (LS10X3A,$(SYSTEM))
$(_OBJ_P)/%.o: $(_BSP_BOOT_SRC_PATH)/cpu/ls10x3aboot/%.c
	$(MKDIR) $(_OBJ_P)
	$(ECHO) -n Making $(subst /,\,$@) ...... 
	$(CC) $(CFLAGS) $(INCL_PATH) -c $< -o $@
	$(ECHO) ^ Done!
endif
endif


$(_OBJ_P)/%.o: $(_SRC_P)/test/%.c
	 $(MKDIR) $(_OBJ_P)
	$(ECHO) -n Making $(subst /,\,$@) ...... 
	$(CC) $(CFLAGS) $(INCL_PATH) -c $< -o $@
	$(ECHO) ^ Done!
##**************************************************
RruPlatBspModuleLint: $(_LOBS)
	@echo ------------------------------------
	cmd /c "type $(subst /,\,$(_LINT_ERRS)) > $(_BSP_BOOT_LINT_PATH)/$(_B_NAME).txt"
	cmd /c "$(LINT_TOOL)  \
	-i$(subst /,\,$(LINT_DIR)) \
	-u$(subst /,\, $(LINT_OPTTION_FILE)  -e126  $(BSP_PCLINT_FLAGS)) $< \
	-oo($(_BSP_BOOT_LOB_PATH)/$(_B_NAME).lob) >> $(_BSP_BOOT_LINT_PATH)/$(_B_NAME).txt"
	@echo  make $(_BSP_BOOT_LOB_PATH)/$(_B_NAME).lob done!


$(_LOB_P)/%.lob:$(_SRC_P)/source/%.c
	$(MKDIR) $(_LOB_P)
	$(MKDIR) $(_LINT_P)
	cmd /c "$(LINT_TOOL)  +ffn  +macros -zero -b -v \
	-i$(subst /,\,$(LINT_DIR)) \
	-u$(subst /,\, $(LINT_OPTTION_FILE)  -e126  $(BSP_PCLINT_FLAGS)) $< \
	-oo($@) >$(addprefix $(_LINT_P)/,$(notdir $(subst .lob,.txt,$@)))"
	@echo Making $@ done!

##******************************************************************************
## ���������ڵ������ļ�(�����������, һ����û��, �򲻰���)
##++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
ifeq (, $(_PLAT_DISABLE_DEPEND))
    -include $(_DEPS)
endif

##==============================================================================
## �ļ�����
##------------------------------------------------------------------------------

##@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
# Mpc860Cfg.mak - ZTE RRU BSP LINUX����ϵͳ MPC860 �� CPU ͨ�ñ��뻷������
#
# Copyright 1985-2010 ZTE Corporation, RRU Platform
#
# �޸ļ�¼
# ------------------------------------------------------------------------------
#   ������@2010-5-15 11:43:35 �����ļ�
#
# ��������
#   �ṩͨ�õĹ��߼�����ѡ������
#
# ʹ�÷���
#   ��BspMakeCfg.mak����
#
################################################################################

##******************************************************************************
## �����趨(�����ϵͳ·��, �ƺ�������Ҳ���Ա���ͨ��, �����?)
##++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
TOOLS_CHAINS=arm/arm_eabi_gcc4.5.2_glibc2.13.0_fp
KIDE_TOOL_BASE = $(subst \,/,$(LINUX_BASE))
ifeq (,$(findstring $(TOOLS_CHAINS), $(KIDE_TOOL_BASE)))
	LINUX_BASE   :=$(subst \,/,$(LINUX_BASE)/$(TOOLS_CHAINS))
endif

GCC_BIN_PREFIX   = $(call CONVERT_SLASH,$(LINUX_BASE)/bin/arm-unknown-linux-gnueabi-)


SYS_INC_PATH     = -I$(LINUX_BASE)/arm-unknown-linux-gnueabi/include \
                   -I$(LINUX_BASE)/arm-unknown-linux-gnueab/include/c++/4.5.2 \
                   -I$(LINUX_BASE)/arm-unknown-linux-gnueab/include\c++/4.5.2/arm-unknown-linux-gnueabi \
                   -I$(LINUX_BASE)\lib\gcc\arm-unknown-linux-gnueabi/4.5.2/include

CC_ARCH_SPEC     = 

CFLAGS          += $(_C_DEBUG) -DRW_MULTI_THREAD \
                   -D_REENTRANT -fno-builtin \
                   -DVOS_LINUX -D_GNU_SOURCE -D_BYTE_ORDER=_LITTLE_ENDIAN  -D_ARM_CPU_
CXXFLAGS        += $(_C_DEBUG) $(CC_ARCH_SPEC) -DRW_MULTI_THREAD \
                   -D_REENTRANT -fno-builtin -mhard-float 
CFLAGS_AS       += $(_AS_DEBUG) $(CC_ARCH_SPEC) -fno-builtin \
                   -fno-for-scope -P -x assembler-with-cpp 
DEPCFLAGS       += -MM $(CC_ARCH_SPEC) $(BATCH_INCLUDE) $(_COMMON_FLAGS)
DEPCFLAGS_AS    += $(DEPCFLAGS) -x assembler-with-cpp
LDFLAGS         += 
LD_PARTIAL_FLAGS+= -r
LD_LOW_FLAGS    += -Ttext $(RAM_LOW_ADRS)
LD_HIGH_FLAGS   += -Ttext $(RAM_HIGH_ADRS)

##******************************************************************************
## ִ�������趨
##++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#POST_BUILD_RULE  = @rem
#AR               = @$(GCC_BIN_PREFIX)ar.exe
#AS               = $(GCC_BIN_PREFIX)gcc.exe
#CC               = @$(GCC_BIN_PREFIX)gcc.exe
#LD               = $(GCC_BIN_PREFIX)ld.exe $(_LD_DEBUG)
#NM               = $(GCC_BIN_PREFIX)nm.exe
#SIZE             = $(GCC_BIN_PREFIX)size.exe
#COMPILE_LEGEND   = $(CC) -c -fdollars-in-identifiers $(CFLAGS)
#LD_PARTIAL       = $(CC) -r -Wl,-X
#LDOUT_CONV       = @rem
#BINXSYM          = @elfXsyms

AR               = $(GCC_BIN_PREFIX)ar$(EXE_SUFFIX)
AS               = $(GCC_BIN_PREFIX)gcc$(EXE_SUFFIX)
CC               = $(GCC_BIN_PREFIX)gcc$(EXE_SUFFIX)
LD               = $(GCC_BIN_PREFIX)ld$(EXE_SUFFIX) $(_LD_DEBUG)
NM               = $(GCC_BIN_PREFIX)nm$(EXE_SUFFIX)
SIZE             = $(GCC_BIN_PREFIX)size$(EXE_SUFFIX)
OBJCPY           = $(GCC_BIN_PREFIX)objcopy$(EXE_SUFFIX)
STRIP            = $(GCC_BIN_PREFIX)strip$(EXE_SUFFIX)
##==============================================================================
## �ļ�����
##------------------------------------------------------------------------------


##@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
# MakeConfig.mak - ZTE RRU BSP ��ϵͳ��������
#
# Copyright 1985-2010 ZTE Corporation, RRU Platform
#
# �޸ļ�¼
# ------------------------------------------------------------------------------
#   ������@2010-5-15 11:20:16 �����ļ�
#
# ��������
#   �ṩͨ�õĹ��߼�����ѡ������
#
# ʹ�÷���
#   ��BSP������Ŀ¼�����makefile����*.mak�ļ�����
#
################################################################################

##******************************************************************************
## ͨ�������
##++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++


## Linux Env compile BBU 2013.09.26
RM	             = -@rm -f -r
MOVE             = -@move
ECHO             = -@echo
CP               = -@copy

_NOT_EXIST       = @if not exist
_EXIST_DIR       = @if exist

END_POS          =
ifeq (_LINUX,$(COMPILE_ENV_OS))
IF_EXIST_FILE    = @if [ -f $1 ]; then $2; fi
IF_NOTEXIST_FILE = @if [ ! -f $1 ]; then $2; fi
IF_EXIST_DIR     = @if [ -d $1 ]; then $2; fi
IF_NOTEXIST_DIR  = @if [ ! -d $1 ]; then $2; fi
CONVERT_SLASH    = $1

RMDIR            = rm -rf
MKDIR            = mkdir -p
PWD              = pwd
EXE_SUFFIX       =
SHELL_SUFFIX     =.sh
TRANS_SYMBOL     =\ $(END_POS)
CR		           = 
else
	ifeq (,$(BSP_MAKE_VER))
		IF_EXIST_FILE    = @if exist $(subst /,\,$1) $(subst /,\,$2)
		IF_NOTEXIST_FILE = @if not exist $(subst /,\,$1) $(subst /,\,$2)
		IF_EXIST_DIR     = @if exist $(subst /,\,$1) $(subst /,\,$2)
		IF_NOTEXIST_DIR  = @if not exist $(subst /,\,$1) $(subst /,\,$2)
		CONVERT_SLASH    = $(subst /,\,$1)
	else
		IF_EXIST_FILE    = @if [ -f $1 ]; then $2; fi
		IF_NOTEXIST_FILE = @if [ ! -f $1 ]; then $2; fi
		IF_EXIST_DIR     = @if [ -d $1 ]; then $2; fi
		IF_NOTEXIST_DIR  = @if [ ! -d $1 ]; then $2; fi
		CONVERT_SLASH    = $1
	endif
RMDIR            = @rmdir
MKDIR            = @mkdir.exe -p
PWD              = cd
EXE_SUFFIX       =.exe
SHELL_SUFFIX     =.bat
TRANS_SYMBOL     = ^ $(END_POS)
CR		           =;
endif


##******************************************************************************
## ͨ�������(_ADDED_XX_FLAGS����Ҫִ�б����ģ�����ж���)
##++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
_COMMON_FLAGS  = -g
_COMMON_FLAGS += -DCPU=$(CPU) -D_CPU_TYPE=$(_CPU_TYPE) 
_COMMON_FLAGS += -D_PHY_BOARD=$(_PHY_BOARD) -D_LOGIC_BOARD=$(_LOGIC_BOARD)
_COMMON_FLAGS += -DBSP_$(_BSP_VER_STEM)_VERSION=1
ifneq (,$(BSP_MAKE_VER))
    _COMMON_FLAGS += -DBSP_MAKE_VER
endif

ifeq (YES,$(BSP_MAKE_MTE))
    _COMMON_FLAGS += -DBSP_MAKE_MTE
endif

ifeq ($(_LOGIC_BOARD), _LOGIC_R8862)
	_COMMON_FLAGS += -D_MAKE_R8862
endif


ifeq ($(BSP_WITH_FPGA), 1)
	_COMMON_FLAGS += -DBSP_WITH_FPGA
endif

ifeq (_BSP_SOLO_RELEASE,$(_VERSION_TYPE))
    _COMMON_FLAGS += -D_BSP_DEBUG
endif

ifeq ($(_BSP_WITH_WFS), 1)
	_COMMON_FLAGS += -D_BSP_WITH_WFS
endif

ifeq ($(_BSP_WITH_WFSFT), 1)
	_COMMON_FLAGS += -D_BSP_WITH_WFS -D_BSP_WITH_WFSFT
endif

##******************************************************************************
## �ڴ�������壨��Ϊ�ڴ�Խ��-kmt_slop���ڴ�й¶-kmt_leak��
##++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
ifeq (YES,$(_MEM_CHECK_SURPORT))
_COMMON_FLAGS += -kmt_slop -DMEM_CHECK_SURPORT
endif

ifeq (YES,$(_MEM_LEAK_SURPORT))
_COMMON_FLAGS += -kmt_leak -DMEM_LEAK_SURPORT
endif

_C_DEBUG    = $(_COMMON_FLAGS) $(_ADDED_C_FLAGS)
_AS_DEBUG   = $(_COMMON_FLAGS) $(_ADDED_AS_FLAGS) 
_LD_DEBUG   =                  $(_ADDED_LD_FLAGS)

##******************************************************************************
## ����·��
##++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
# ���Ƿ� 2011��09��05��
LINT_DIR = $(_BSP_SOURCE_PATH)/tools/lint
LINT = $(LINT_DIR)/lint-nt
_LINT_OUTPUT = $(VER_ROOT)/platform/tool/lint/linterror.txt
LINT_TOOL = $(LINT_DIR)/lint-nt.exe
LINT_OPTTION_FILE=$(LINT_DIR)/optionbsp.lnt
##******************************************************************************
## ���ݲ�ͬ��CPU����ѡ�ò�ͬ������ģ��
##++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

ifeq ($(CPU),DRA62X)
   include $(VER_ROOT)/platform/bsp/common/dra62xlxcfg.mak
endif

ifeq ($(CPU),CORTEXA9)
   include $(VER_ROOT)/platform/bsp/common/cortexa9lxcfg.mak
endif


ifeq ($(CPU),XILINX_MPSOC_A53_32BIT)
    include $(VER_ROOT)/platform/bsp/common/arm_eabi_gcc4.8.2_glibc2.18.0_fp.mak    
endif
ifeq ($(CPU),CORTEXA53)
    include $(VER_ROOT)/platform/bsp/common/cortexa53lxcfg.mak    
endif

ifeq ($(CPU),CORTEXA15)
    include $(VER_ROOT)/platform/bsp/common/cortexa15lxcfg.mak    
endif

ifeq (,$(CC_PREFIX))
	CC:=@$(CC)
else
	CC:=@$(CC_PREFIX) $(subst @,,$(CC))
endif


##################################################
CCFLAGS_TEMP =$(CFLAGS)
CCFLAGS_TEMP +=$(OS_INCLUDE)
CCFLAGS_TEMP +=$(INCL_PATH)
BSP_PCLINT_FLAGS        = $(subst /,\,$(filter -I%,$(CCFLAGS_TEMP)))
BSP_PCLINT_FLAGS       += $(subst /,\,$(filter -i%,$(CCFLAGS_TEMP)))
BSP_PCLINT_FLAGS       += $(subst /,\,$(filter -D%,$(CCFLAGS_TEMP)))
BSP_PCLINT_FLAGS       += $(subst /,\,$(filter -d%,$(CCFLAGS_TEMP)))
################################################################################
### �ļ�����
################################################################################

/*****************************************************************************
* 版权所有(C) 2017, ZTE Corp. ZXSDR-RRU Platform BSP
*----------------------------------------------------------------------------
* 模 块 名 : BSP
* 文件名称 : power.c
* 文件标识 : {[N/A]}
* 内容摘要 : 本文件提供了领域CI维测接口
* 注意事项 : 无
* 作    者 :
* 创建日期 : 2022-3-28 14:45:34
* 当前版本 : Ver1.0
*----------------------------------------------------------------------------
* 变更记录 :
*
* $记录1
* 变 更 单: $0000000(N/A)
* 责 任 人:
* 修改日戳: 2022-3-28 14:45:34
* 变更说明: 创建文件

*----------------------------------------------------------------------------
*/
#include "rruinfo.h"
#include "bspcomm.h"
#include "regdrv_access.h"
#include "regdrv_comm.h"
#include "secure_func.h"
#include "clk_common.h"
#include "devdrv_clk.h"
#include "sfp.h"

static UINT32 RruPropertyFileInit(VOID)
{
    UINT32 txNum  = 0;
    UINT32 rxNum  = 0;
    UINT32 prxNum = 0;

    txNum = BspGetTxChannel();
    rxNum = BspGetRxChannel();
    prxNum = BspGetPrxChannel();
    if((txNum != 0) && (rxNum != 0) && (prxNum != 0))
    {
        dbgInfo("Rru Property File Init Success!\n");
        return BSP_OK;
    }
    else
    {
        dbgInfo("Rru Property File Init Failed!\n");
        return BSP_ERROR;
    }
}

static UINT32 RruRegisterMeterInit(VOID)
{
    T_Reg_Drv_Access *localBus = NULL;
    T_Reg_Drv_Access *localBus_8bit = NULL;
    T_Reg_Drv_Access *localBus_32bit = NULL;

    localBus = BspGetRegAccess(DEV_REG_ACCESS_LOCAL_BUS);
    localBus_8bit = BspGetRegAccess(DEV_REG_ACCESS_LOCAL_BUS_8BIT);
    localBus_32bit = BspGetRegAccess(DEV_REG_ACCESS_LOCAL_BUS_32BIT);
    if((localBus != NULL) && (localBus_8bit != NULL) && (localBus_32bit != NULL))
    {
        dbgInfo("Rru Register Meter Init Success!\n");
        return BSP_OK;
    }
    else
    {
        dbgInfo("Rru Register Meter Init Failed!\n");
        return BSP_ERROR;
    }
}

static UINT32 RruClkPllLdLockStatus(VOID)
{
    UINT32 retVal = BSP_OK;
    UINT32 id     = 0;

    id = BspDevNameToId("Pllsys");
    retVal = BspGetClkPllSysLd(id);
    return retVal;
}

static UINT32 RruClkPllLd2LockStatus(VOID)
{
    UINT32 retVal = BSP_OK;
    UINT32 id     = 0;

    id = BspDevNameToId("Pllsys");
    retVal = BspGetClkPllSysLd2(id);
    return retVal;
}

static UINT32 RruClkInit(VOID)
{
    UINT32 devId = 0;
    INT32  lSnpRet = 0;
    CHAR   acBufName[64] ={0};
    UINT32 devNo = 0;
    T_ClkPllCfgPriv *clkCfg = NULL;

    lSnpRet = snprintf_s(acBufName, sizeof(acBufName), "PllSys");
    SNPRINTF_S_CHECK(lSnpRet, sizeof(acBufName));
    devId = BspDevNameToId(&acBufName[0]);
    devNo = BspClkDevIdToDevNo(devId);
    clkCfg = BspGetClkPllCfgPriv(devNo);
    if(clkCfg != NULL)
    {
        dbgInfo("Rru Clk Init Success!\n");
        return BSP_OK;
    }
    else
    {
        dbgInfo("Rru Clk Init Failed!\n");
        return BSP_ERROR;
    }
}

static VOID RruGetPaVolt(VOID)
{
    UINT32 paNum  = 0;
    UINT32 loop   = 0;
    INT32  paVolt = 0;

    paNum = BspGetPaNum();
    for(loop = 0;loop < paNum;loop++)
    {
        paVolt = BspGetPaVolt(loop);
        dbgInfo("Pa %d Volt=%d\n",loop,paVolt);
    }
}

static UINT32 RruOptAlarm(UINT32 optId)
{
    UINT32 retVal = 0;
    UINT32 val    = 0;

    retVal = BspGetOptStatus(optId);
    if((retVal & BSP_CPRI_ERR_LOS) == BSP_CPRI_ERR_LOS)
    {
        val |= BSP_CPRI_ERR_LOS;
    }
    if((retVal & BSP_OPT_ERR_LOF) == BSP_OPT_ERR_LOF)
    {
        val |= BSP_OPT_ERR_LOF;
    }
    if((retVal & BSP_OPT_ERR_LOP) == BSP_OPT_ERR_LOP)
    {
        val |= BSP_OPT_ERR_LOP;
    }

    return val;
}

static UINT32 RruSfpExistStatus(UINT32 optId)
{
    UINT32 retVal = 0;
    UINT32 val    = 0;

    retVal = BspGetOptStatus(optId);
    if((retVal & BSP_OPT_ERR_NO_EXIST) == BSP_OPT_ERR_NO_EXIST)
    {
        val |= BSP_OPT_ERR_NO_EXIST;
    }

    return val;
}

static UINT32 RruGetDpdStatus(VOID)
{
    UINT32 retVal  = BSP_OK;
    UINT32 status  = 0;
    UINT32 chanNum  = 0;
    UINT32 loop    = 0;

    chanNum = BspGetTxChanNum();
    for(loop = 0;loop < chanNum;loop++)
    {
        retVal |= BspGetDpdStatus(loop,&status);
        if(status == BIT_SET(7))
        {
            dbgInfo("Chan %d Dsp Dog Error!\n",loop);
        }
    }
    return retVal;
}

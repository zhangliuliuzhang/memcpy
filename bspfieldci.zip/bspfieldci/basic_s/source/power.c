/*****************************************************************************
* 版权所有(C) 2017, ZTE Corp. ZXSDR-RRU Platform BSP
*----------------------------------------------------------------------------
* 模 块 名 : BSP
* 文件名称 : power.c
* 文件标识 : {[N/A]}
* 内容摘要 : 本文件提供了领域CI维测接口
* 注意事项 : 无
* 作    者 :
* 创建日期 : 2022-3-28 14:45:34
* 当前版本 : Ver1.0
*----------------------------------------------------------------------------
* 变更记录 :
*
* $记录1
* 变 更 单: $0000000(N/A)
* 责 任 人:
* 修改日戳: 2022-3-28 14:45:34
* 变更说明: 创建文件

*----------------------------------------------------------------------------
*/
#include "cfrcommon.h"

static UINT32 RruGetCfrCpgCoef(UINT32 cfrBw)
{
    UINT32 retVal  = BSP_OK;
    T_CfrCpgPara cpgPara = {0};
    UINT32 coefLen = 0;
    UINT32 loop    = 0;

    retVal = BspGetCfrCpgCoef(cfrBw,&cpgPara);
    if(retVal != BSP_OK)
    {
        dbgInfo("%s:Get Cfr Cpg Coef Failed!\n",__FUNCTION__);
        return BSP_ERROR;
    }
    coefLen = cpgPara.coefLen;
    for(loop = 0;loop < coefLen;loop++)
    {
        dbgInfo("Cfr Cpg Bw=%d,CoefPara[%d]=%d,CoefLen=%d\n",cpgPara.cfrBw,loop,cpgPara.pCoefPara[loop],coefLen);
    }
    return retVal;
}

static UINT32 RruGetCfrGatePara(VOID)
{
    UINT32 retVal     = BSP_OK;
    UINT32 num        = 0;
    UINT32 cfrGate[E_CFR_THR_NUM] = {0,0,0};
    UINT32 loop       = 0;
    UINT32 dir        = TX;
    UINT32 bspChn     = 0;
    UINT32 difChn     = 0;
    UINT32 difChipId  = 0;

    num = BspGetTxChannel();
    for(loop = 0;loop < num;loop++)
    {
        retVal |= BspGetBspChnByRfChn(loop,dir,&bspChn);
        retVal |= BspGetDifInfoByBspChn(bspChn, dir, &difChipId, &difChn);
        retVal |= BspGetCfrGatePara(difChn,cfrGate);
        dbgInfo("Chan %d Cfr Gate 1st=%d,2nd=%d,3rd=%d\n",loop,cfrGate[E_CFR_THR_1ST],cfrGate[E_CFR_THR_2ND],cfrGate[E_CFR_THR_3RD]);
    }
    return retVal;
}

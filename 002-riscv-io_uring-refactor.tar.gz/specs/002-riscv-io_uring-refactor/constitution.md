# 项目宪法 / Constitution: RISC-V + io_uring Memcached 重构

## 项目概述 / Project Overview

**项目名称**: RISC-V + io_uring Memcached 重构
**功能编号**: 002
**核心约束**: 按规格重构 — 允许修改核心代码以实现性能优化

## 技术约束 / Technical Constraints

### TC-1: 代码修改范围

- **规则**: 仅修改规格中明确的需求（19 项"做"的需求）
- **禁止**: 修改 Out of Scope 中列出的功能（协议扩展、持久化、分布式等）
- **允许**: 新建文件、修改现有代码逻辑、添加编译条件

### TC-2: 目标平台

- **主平台**: RISC-V 64-bit + Linux 6.0+
- **扩展要求**: V (Vector) + B (Bitmanip) + A (Atomic) + Zicbom + Zihintpause
- **玄铁兼容**: 同时支持标准 Zbb 和玄铁 XTheadBb 厂商扩展

### TC-3: 回退策略

| 前置条件 | 要求 | 降级策略 |
|---------|------|---------|
| RISC-V 扩展缺失 | 检测 `__riscv_*` 宏 | 回退到 C 标准库实现 |
| Linux 内核 < 6.0 | 运行时检测 | 回退到 libevent/epoll |
| liburing 缺失 | 编译期检测 | 回退到 libevent |
| 大页不足 | 启动时检测 | 启动失败，提示用户 |
| NUMA 单节点 | 运行时检测 | 使用全局内存池 |

### TC-4: 构建系统

- **构建工具**: GNU Autotools（autoconf / automake / libtool）
- **新增依赖**: liburing >= 2.4（可选）、libnuma（可选）
- **编译验证**: `./autogen.sh && ./configure && make`

### TC-5: Phase 依赖

```
Phase 1 → Phase 2 → Phase 4 → Phase 4.5 → Phase 3 → Phase 2.5
                              ↑              ↑
                              └──────────────┘
                              F4.5.1 必须先于 F3.3 完成
```

**关键约束**: Phase 4.5（refcount 改 uint32）必须在 Phase 3（PBUF_RING）之前完成

## 质量标准 / Quality Standards

### QS-1: 性能目标

| 指标 | 基线 | 目标 |
|------|------|------|
| 吞吐量 (QPS) | 记录基线 | 提升 3-5 倍 |
| P99 延迟 | 记录基线 | 降低 50%+ |
| P999 延迟 | 记录基线 | 降低 60%+ |

### QS-2: 兼容性

- 协议兼容：ASCII/Binary 协议完全兼容
- 客户端兼容：现有客户端无需修改
- 配置兼容：现有配置参数语义保持

### QS-3: 可维护性

- 每个 Phase 独立可测试、可回退
- RISC-V 特定代码使用 `#ifdef __riscv` 条件编译
- 添加代码注释说明优化点

## 依赖项 / Dependencies

| 依赖 | 用途 | 来源 |
|------|------|------|
| GCC >= 14.0 或 LLVM >= 18.0 | RISC-V 扩展支持 | Docker `rust-c-dev:latest` |
| liburing >= 2.4 | io_uring 异步 I/O | 系统包或源码编译 |
| libnuma | NUMA 亲和（可选） | 系统包 |
| ThreadSanitizer | 并发验证（F4.3） | GCC 内置 |

## 风险控制 / Risk Control

| 风险 | 缓解措施 |
|------|----------|
| F4.5.1 sizeof 变化破坏 PBUF_RING | 强制 Phase 4.5 先于 Phase 3 |
| F4.3 内存屏障精简导致并发错误 | ThreadSanitizer + 压力测试 |
| 玄铁扩展宏未定义 | 编译器需 `-march=...xtheadbb` |
| io_uring 内核版本不足 | 运行时探测，降级 epoll |

## 验收标准 / Acceptance Criteria

1. 编译验证通过（`./configure && make`）
2. 非 RISC-V / 非 Linux 6.0 环境自动降级
3. 吞吐量提升 >= 3 倍
4. P99 延迟降低 >= 50%
5. 协议兼容性测试通过
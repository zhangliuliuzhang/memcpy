# Tasks: RISC-V + io_uring Memcached 重构

**Generated**: 2026-07-08
**Source**: spec.md, plan.md

## Implementation Strategy

**执行策略**：严格串行执行（每 Phase 完成并测试后进入下一 Phase）

**关键依赖**：
- Phase 4.5（T008-T012）必须在 Phase 3（T013-T014）之前完成
- T008（F4.5.1 refcount 改 uint32）完成后 sizeof(item) 锁定，后续任务才能继续
- Phase 1/2/4 可并行开发，但需按顺序测试验证

**MVP 范围**：Phase 1（内存基底）完成即可验证基本编译和运行

---

## Phases Overview

- Phase 1: 内存基底与指令对齐（4 tasks）
- Phase 2: 计算热点矢量化（1 task）
- Phase 4: 尾延迟优化（2 tasks）
- Phase 4.5: RV64A 原子操作（5 tasks）⚠️ 关键依赖
- Phase 3: io_uring 异步网络引擎（2 tasks）
- Phase 2.5: TTL 预分类（1 task）

---

## Phase 1: 内存基底与指令对齐

**Goal**: 完成 item 结构体对齐验证、2MB 大页分配、intrinsics 头文件、NUMA 条件编译
**Independent Test**: 编译成功 + 启动 memcached 验证大页分配

### T001: F1.1 item 字段自然对齐静态断言

- [ ] T001 [F1.1] 在 `memcached.h` item 结构体定义后添加静态断言验证字段对齐

**文件**: `memcached.h:730`（结构体定义后）

**实现**:
```c
_Static_assert(offsetof(item, next) % 8 == 0, "next pointer not 8-byte aligned");
_Static_assert(offsetof(item, prev) % 8 == 0, "prev pointer not 8-byte aligned");
_Static_assert(offsetof(item, h_next) % 8 == 0, "h_next pointer not 8-byte aligned");
_Static_assert(offsetof(item, time) % 4 == 0, "time field not 4-byte aligned");
```

**验收**: 编译成功，断言无报错

---

### T002: F1.2 slab_page_size=2MB + 大页管理

- [ ] T002 [F1.2] 修改 slab 页尺寸为 2MB 并实现强制大页分配

**文件**:
- `memcached.c:264`
- `slabs.c:memory_allocate()`
- `slabs.c:slabs_init()`

**实现要点**:
1. `memcached.c:264`: `settings.slab_page_size = 2 * 1024 * 1024`
2. `slabs.c`: `memory_allocate()` 使用 `mmap(MAP_HUGETLB)`，失败则 `exit(1)`
3. `slabs.c:slabs_init()`: 启动时检测 `/proc/sys/vm/nr_hugepages` 并警告不足

**验收**: 编译成功，启动时打印大页检测信息，大页不足时退出

---

### T003: F1.4 RISC-V intrinsics 头文件

- [ ] T003 [P] [F1.4] 新建 `riscv_intrinsics.h` 头文件封装 RISC-V 指令

**文件**: `riscv_intrinsics.h`（新建）

**实现要点**:
- Zihintpause: `riscv_pause()`
- Zicboz: `riscv_cbo_zero()`（条件编译）
- Zbb/XTheadBb: `riscv_ctz()`, `riscv_clz()`（编译期宏切换）
- RV64A: `riscv_amomax_w_rl()`, `riscv_amoswap_w_aq()`, `riscv_lr_d()`, `riscv_sc_d_rl()`

**验收**: 文件创建成功，非 RISC-V 环境 `#ifdef __riscv` 条件编译生效

---

### T004: F1.5 NUMA 亲和条件编译

- [ ] T004 [F1.5] 实现 NUMA 条件性内存池分配

**文件**:
- `slabs.c`
- `configure.ac`

**实现要点**:
1. `configure.ac`: 添加 `--enable-numa` 参数检测 libnuma
2. `slabs.c`: `HAVE_NUMA` 条件编译，>=2 节点时 per-node 池，单节点时全局池

**验收**: 编译成功，启动时打印 NUMA 状态（启用/禁用）

---

## Phase 2: 计算热点矢量化

**Goal**: ASCII 协议 `\r\n` 扫描向量化
**Independent Test**: ASCII 协议解析吞吐 > 1GB/s

### T005: F2.2 ASCII \r\n 向量化

- [ ] T005 [F2.2] 实现 RVV 向量化 `\r\n` 扫描替换 memchr

**文件**:
- `riscv_intrinsics.h`
- `proto_text.c:273,386`

**实现要点**:
1. `riscv_intrinsics.h`: 添加 `riscv_memchr_crlf()` 内联函数（RVV 向量加载比较）
2. `proto_text.c`: 两处 `memchr(c->rcurr, '\n', c->rbytes)` 替换为条件编译调用

**验收**: 编译成功，RISC-V V 扩展环境启用向量化，非 V 环境回退 memchr

---

## Phase 4: 尾延迟优化

**Goal**: MADV_COLLAPSE 大页聚合 + 内存屏障审计
**Independent Test**: THP 聚合成功率 > 80%，ThreadSanitizer 无 data race

### T006: F4.2 MADV_COLLAPSE

- [ ] T006 [F4.2] 实现定时 MADV_COLLAPSE 后台线程

**文件**:
- `memcached.c`（启动参数）
- `slabs.c` 或 `items.c`（后台线程）

**实现要点**:
1. 新增启动参数 `--madv-collapse-interval=N`（默认 60 秒）
2. 后台线程遍历 COLD_LRU 尾部页面调用 `madvise(MADV_COLLAPSE)`

**验收**: 编译成功，启动参数生效，后台线程定期执行

---

### T007: F4.3 精简内存屏障

- [ ] T007 [F4.3] 全局内存屏障审计 + ThreadSanitizer 验证

**文件**: 全局审计（`__sync_synchronize`, `pthread_mutex` 边界）

**实现要点**:
1. 运行 `make CFLAGS="-fsanitize=thread -g" test`
2. 审计热点路径屏障，精简不必要的 fence 指令
3. 确保无 data race 报告

**验收**: ThreadSanitizer 验证通过，无并发错误

---

## Phase 4.5: RV64A 原子操作

⚠️ **关键依赖**: 必须在 Phase 3 之前完成

**Goal**: sizeof(item) 锁定 + 原子操作优化
**Independent Test**: sizeof(item) 变化验证（+2B），并发压力测试通过

### T008: F4.5.1 refcount 改 uint32

- [ ] T008 [F4.5.1] 将 item.refcount 从 uint16 改为 uint32

**文件**: `memcached.h:716`

**实现要点**:
- `unsigned short refcount` → `uint32_t refcount`
- sizeof(item) 增加 2 字节，验证所有依赖 sizeof 的计算

**验收**: 编译成功，打印 sizeof(item) 确认变化

---

### T009: F4.5.2 引用计数 RV64A 优化

- [ ] T009 [F4.5.2] 用 C11 stdatomic 替换 refcount 操作宏

**文件**: `memcached.h:1190-1191`

**实现要点**:
```c
#include <stdatomic.h>

#define refcount_incr(it) \
    atomic_fetch_add_explicit((atomic_uint *)&(it)->refcount, 1, memory_order_relaxed)

#define refcount_decr(it) \
    (atomic_fetch_add_explicit((atomic_uint *)&(it)->refcount, -1, memory_order_acq_rel) == 1)
```

**验收**: 编译成功，原子操作语义正确

---

### T010: F4.5.3 LRU 时间戳 amomax

- [ ] T010 [F4.5.3] 用 riscv_amomax_w_rl 替换 time 字段赋值

**文件**:
- `items.c:521,589,596,603,1078`

**实现要点**:
- 5 处 `it->time = current_time` 替换为 `riscv_amomax_w_rl(&it->time, current_time)`

**验收**: 编译成功，RISC-V 环境启用内联汇编

---

### T011: F4.5.4 LRU 自旋锁重构

- [ ] T011 [F4.5.4] 用 RISC-V amoswap 自旋锁替换 pthread_mutex

**文件**:
- `thread.c:100`
- `riscv_intrinsics.h`
- 全局搜索 `lru_locks` 调用点

**实现要点**:
1. 定义 `riscv_spinlock_t` 类型
2. `riscv_intrinsics.h`: 添加 `riscv_spinlock_lock/unlock()` 函数（含 pause）
3. 替换 `pthread_mutex_t lru_locks[POWER_LARGEST]` 为自旋锁数组
4. 全局替换 mutex_lock/unlock 调用

**验收**: 编译成功，自旋锁功能验证

---

### T012: F4.5.5 Bump Queue 无锁化

- [ ] T012 [F4.5.5] 用 lr.d/sc.d 实现 Bump Queue 无锁入队

**文件**: `items.c:112-131`

**实现要点**:
1. 重构 `lru_bump_buf` 结构体，入队目标改为 `atomic_uint64_t head`
2. `lru_bump_async()` 用 lr.d/sc.d 无锁入队循环
3. 出队保持 mutex 保护

**验收**: 编译成功，并发测试无 ABA 问题

---

## Phase 3: io_uring 异步网络引擎

⚠️ **前置依赖**: Phase 4.5 完成（sizeof(item) 稳定）

**Goal**: io_uring 引擎替换 libevent + PBUF_RING 零拷贝
**Independent Test**: io_uring 编译成功，网络连接正常收发

### T013: io_uring 引擎基础

- [ ] T013 [F3.1+F3.2+F3.4] 实现 io_uring 引擎替换 libevent

**文件**:
- `configure.ac`
- `io_uring_engine.c/h`（新建）
- `thread.c`

**实现要点**:
1. `configure.ac`: `--enable-io_uring` 参数检测 liburing
2. 新建 `io_uring_engine.c/h`: SQ/CQ 深度 256，Multi-Shot 内核探测降级
3. `thread.c`: 每 worker 独立 io_uring 实例，替换 `event_base_loop`

**验收**: 编译成功，io_uring 环境启用新引擎，非 io_uring 回退 libevent

---

### T014: PBUF_RING 零拷贝

- [ ] T014 [F3.3] 实现 PBUF_RING 注册和 16MB 独立缓冲区

**文件**: `io_uring_engine.c`

**实现要点**:
1. mmap 16MB 独立缓冲区（8 个 2MB 大页）
2. 注册 `io_uring_buf_ring`，DMA 写入缓冲区
3. 解析后 memcpy 到 Slab（一次拷贝方案）

**验收**: 编译成功，PBUF_RING 注册成功，DMA 写入验证

---

## Phase 2.5: TTL 预分类

**Goal**: 短命/长命对象隔离 + 整页秒级回收
**Independent Test**: 过期清理 CPU 开销降低 80%+

### T015: F2.5.6 TTL 预分类 + 整页回收

- [ ] T015 [F2.5.6] 按 TTL 区间路由分配 + 整页过期回收

**文件**:
- `items.c:do_item_alloc()`
- `items.c` 或 `slabs.c`（lru_maintainer 线程）

**实现要点**:
1. `do_item_alloc()`: 60 秒阈值，`id |= SHORT_TTL_PAGE / LONG_TTL_PAGE`
2. lru_maintainer 线程: 添加 `ttl_page_recycle()` 整页回收逻辑

**验收**: 编译成功，短命 Page 整体过期可秒级回收

---

## Dependencies

```
Phase 1 (T001-T004) ─────────────────────────────┐
                                                 │
Phase 2 (T005) ──────────────────────────────────┤ 可并行开发
                                                 │
Phase 4 (T006-T007) ─────────────────────────────┘
                                                 │
Phase 4.5 (T008-T012) ───────────────────────────┼── ⚠️ 关键依赖：必须在 Phase 3 之前
                                                 │
Phase 3 (T013-T014) ─────────────────────────────┤ PBUF_RING 依赖 sizeof(item) 稳定
                                                 │
Phase 2.5 (T015) ────────────────────────────────┘
```

**关键约束**:
- T008（F4.5.1）完成后 sizeof(item) 锁定
- T014（PBUF_RING）必须等待 T008 完成

---

## Parallel Execution Examples

**Phase 1 内部并行**:
- T003（intrinsics.h）与 T001/T002/T004 可并行（不同文件）

**Phase 1/2/4 并行开发**:
- T001-T004（内存）|| T005（向量化）|| T006-T007（尾延迟）
- 测试时按顺序：Phase 1 → Phase 2 → Phase 4

**Phase 4.5 内部串行**:
- T008 → T009 → T010 → T011 → T012（sizeof 变化影响后续）

---

## Verification Strategy

### 每 Phase 测试

1. 编译验证: `./autogen.sh && ./configure && make -j$(nproc)`
2. 单元测试: `make test` 或 `./testapp`
3. 功能验证: 启动 memcached，运行基本 GET/SET 操作

### Phase 4.3 特殊验证

```bash
make clean
make CFLAGS="-fsanitize=thread -g" test
# 无 data race 报告
```

### Phase 4.5 特殊验证

- T008 完成后验证 `sizeof(item)` 变化
- T009-T012 并发压力测试验证原子操作正确性

### Phase 3 特殊验证

- io_uring 编译成功（liburing 链接）
- 内核版本探测正确
- 网络连接正常收发
# Specification Quality Checklist: RISC-V + io_uring Memcached 重构

**Purpose**: Validate specification completeness and quality before proceeding to planning
**Created**: 2026-07-06
**Updated**: 2026-07-07 (after item-by-item decision session)
**Feature**: [spec.md](../spec.md)

## Content Quality

- [x] No implementation details (languages, frameworks, APIs)
- [x] Focused on user value and business needs
- [x] Written for non-technical stakeholders
- [x] All mandatory sections completed

## Requirement Completeness

- [x] No [NEEDS CLARIFICATION] markers remain
- [x] Requirements are testable and unambiguous
- [x] Success criteria are measurable
- [x] Success criteria are technology-agnostic (no implementation details)
- [x] All acceptance scenarios are defined
- [x] Edge cases are identified
- [x] Scope is clearly bounded
- [x] Dependencies and assumptions identified

## Feature Readiness

- [x] All functional requirements have clear acceptance criteria
- [x] User scenarios cover primary flows
- [x] Feature meets measurable outcomes defined in Success Criteria
- [x] No implementation details leak into specification

## Item-by-Item Decisions (2026-07-07)

### Phase 1: 内存基底与指令对齐

| ID | 决策 | 备注 |
|---|------|------|
| F1.1 | ✅ 做（弱化） | 仅自然对齐，不强加 64B padding |
| F1.2 | ✅ 做 | slab_page_size=2MB + 显式大页 |
| F1.3 | 👤 交给用户 | memset/memcpy/memmove/memchr 用户自行替换 |
| F1.4 | ✅ 做（双路） | 标准 Zbb + 玄铁 XTheadBb，编译期宏判定 |
| F1.5 | ✅ 做（条件性） | NUMA 检测到则优化，否则全局池 |

### Phase 2: 计算热点矢量化

| ID | 决策 | 备注 |
|---|------|------|
| F2.1 | ❌ 不做 | 哈希算法不优化，保持现有 MurmurHash3/XXH3 |
| F2.2 | ✅ 做（仅 ASCII） | `\r\n` 扫描向量化，Binary 保持原逻辑 |
| F2.3 | ❌ 不做 | 架构为 free list，无位图扫描 |
| F2.4 | ❌ 不做 | 随 F2.2 自动启用 |

### Phase 2.5: Slab 机制深度优化

| ID | 决策 | 备注 |
|---|------|------|
| F2.5.1 | ❌ 不做 | 效用函数驱动重平衡 |
| F2.5.2 | ❌ 不做 | 页压缩与条目迁移（Defrag） |
| F2.5.3 | ❌ 不做 | 运行时自适应 Slab Class 创建 |
| F2.5.4 | ❌ 不做 | 相邻 Slab Class 空间借调 |
| F2.5.5 | ❌ 不做 | 跨 Slab 全局借道置换 |
| F2.5.6 | ✅ 做 | TTL 预分类 + 整页回收 |

### Phase 3: 异步网络引擎重写

| ID | 决策 | 备注 |
|---|------|------|
| F3.1 | ✅ 做 | io_uring 替换 libevent/epoll |
| F3.2 | ✅ 做 | IORING_OP_RECV Multi-Shot |
| F3.3 | ✅ 做 | PBUF_RING 零拷贝（依赖 Phase 4.5 先完成） |
| F3.4 | ✅ 做 | 每 worker 独立 io_uring 实例 |

### Phase 4: 内核高级协同与尾延迟优化

| ID | 决策 | 备注 |
|---|------|------|
| F4.1 | ✅ 做 | Zihintpause 指令 |
| F4.2 | ✅ 做 | madvise(MADV_COLLAPSE) |
| F4.3 | ✅ 做（高风险） | 精简内存屏障，需充分并发测试 |

### Phase 4.5: RV64A 原子操作深度优化

| ID | 决策 | 备注 |
|---|------|------|
| F4.5.1 | ✅ 做 | refcount 改 uint32（必须在 Phase 3 之前完成） |
| F4.5.2 | ✅ 做 | 引用计数 RV64A 优化 |
| F4.5.3 | ✅ 做 | LRU 时间戳 amomax 优化 |
| F4.5.4 | ✅ 做 | LRU 自旋锁重构 |
| F4.5.5 | ✅ 做 | Bump Queue 无锁化 |

## Critical Phase Ordering Change

**原顺序**：Phase 1 → 2 → 3 → 2.5 → 4 → 4.5

**新顺序**：

```
Phase 1 → Phase 2 (并行) → Phase 4 (并行)
    ↓
Phase 4.5 (RV64A，sizeof(item) 锁定)
    ↓
Phase 3 (io_uring，PBUF_RING 依赖稳定 sizeof)
    ↓
Phase 2.5 (仅 TTL 预分类)
```

**关键约束**：F4.5.1 改 refcount 为 uint32，sizeof(item) 变化 2 字节。F3.3 PBUF_RING 注册需稳定的 sizeof(item) 计算 DMA 目标地址，否则 DMA 写入错位。

## Phase Coverage Summary (After Decisions)

| Phase | 核心内容 | 做的数量 | 不做数量 | 交给用户 |
|-------|---------|---------|---------|---------|
| Phase 1 | 内存基底 + NUMA + 大页 + intrinsics | 4 | 0 | 1（F1.3） |
| Phase 2 | 计算热点矢量化 | 1 | 3 | 0 |
| Phase 2.5 | Slab 机制优化（仅 TTL 预分类） | 1 | 5 | 0 |
| Phase 3 | io_uring 异步网络 | 4 | 0 | 0 |
| Phase 4 | 尾延迟优化 | 3 | 0 | 0 |
| Phase 4.5 | RV64A 原子操作 | 5 | 0 | 0 |
| **总计** | | **18** | **8** | **1** |

## Notes

- 规格已根据逐项决策完整调整，删除"不做"的需求，保留决策记录
- **关键 Phase 顺序调整**：Phase 4.5 必须先于 Phase 3 完成（sizeof(item) 稳定）
- F1.4 同时支持标准 Zbb 和玄铁 XTheadBb，编译期宏判定
- F1.5 NUMA 亲和为条件性实现（两路方案）
- F4.3 精简内存屏障标记为高风险，需充分并发测试
- F1.3 memset 系列完全交给用户，规格不涉及
- **F2.1 哈希算法不优化**，保持现有实现
- **规格已就绪，可进入 `/speckit-implement` 阶段**

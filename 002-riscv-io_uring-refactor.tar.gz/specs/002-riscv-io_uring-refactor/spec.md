# Specification: RISC-V + io_uring Memcached 重构

## Overview

将 Memcached 1.6.42 针对 RISC-V 架构和 Linux 6.0 的 io_uring 进行深度性能优化重构，融合 RISC-V 指令集扩展（V/B/A/Zicbom/Zihintpause）、io_uring 异步网络引擎与内核协同技术，目标是吞吐量提升 3-5 倍，P99 延迟降低 50% 以上。

## Clarifications

### Session 2026-07-06

- Q: CXL 分层内存是否纳入本次规格？ → A: 不纳入，作为后续独立功能规划。
- Q: 8 项 Slab 优化 + 混合分配模式如何纳入？ → A: 第 1-8 项全部纳入（混合分配不纳入）。第 8 项（显式大页管理）强化原 F1.2。
- Q: 混合分配模式（Slab + Log-Structured）是否纳入本次？ → A: 不纳入，作为后续独立规格，本次聚焦 RISC-V + io_uring 主线。

### Session 2026-07-07（逐项决策）

逐项确认结果，详见下方 [Decision Summary](#decision-summary) 章节。关键调整：

- **F1.1**：仅保留必要字段自然对齐校验，**不强加 64B padding**（取消原"cache line 对齐"目标）
- **F1.3**：memset/memcpy/memmove/memchr **完全交给用户**，规格中不再涉及
- **F1.4**：intrinsics 头文件同时支持标准 Zbb 和玄铁 XTheadBb 扩展，**编译期宏判定**（不做运行时 hwprobe）
- **F1.5**：NUMA 亲和实现**条件性两路方案**（NUMA 检测到则优化，否则全局池）
- **F2.1**：路径 B - 换算法（向量化哈希）
- **F2.2**：仅 ASCII 协议的 `\r\n` 扫描向量化
- **F2.3 / F2.4 / F2.5.1-5**：全部不做
- **F2.5.6**：TTL 预分类 + 整页回收，做
- **F3.1-4**：Phase 3 全做
- **F4.1-3**：Phase 4 全做（F4.3 精简屏障需充分并发测试）
- **F4.5.1-5**：Phase 4.5 全做
- **Phase 顺序调整**：由于 F4.5.1 改变 sizeof(item)，必须**先于 F3.3 PBUF_RING 完成**

## Problem Statement

原生 Memcached 设计于 x86 架构和传统 epoll 时代，存在以下性能瓶颈：

1. **内存布局未对齐**：item 结构体字段未按 8 字节自然对齐，无法适配 RV64A 的 lr.d/sc.d 双字原子操作
2. **Slab 页尺寸不匹配**：默认 1MB 无法利用 RISC-V Sv39/Sv48 的 2MB Mega-page 巨页优化
3. **计算热点未向量化**：哈希计算、协议解析等热点未利用 RISC-V V 扩展和 B 扩展（含玄铁 XTheadBb 厂商扩展）
4. **网络 I/O 开销大**：libevent/epoll 模型存在频繁系统调用、用户态-内核态数据拷贝、事件重注册开销
5. **锁竞争与尾延迟**：高并发下全局锁竞争激烈，缺乏 RISC-V Zihintpause 指令优化自旋等待
6. **TTL 混合污染**：短命与长命对象混在同一 Page，无法实现整页秒级回收
7. **原子操作低效**：refcount/time 字段更新依赖传统锁机制或 CAS 循环，无法利用 RV64A 原子指令的硬件优势

## User Stories

### 作为基础设施运维工程师

1. 我希望在 RISC-V 服务器上部署高性能 Memcached，以便支撑高并发缓存服务
2. 我希望在不修改应用代码的前提下获得 3-5 倍吞吐提升，以便降低硬件成本
3. 我希望看到详细的性能基准报告，以便验证优化效果并向上级汇报

### 作为性能工程师

4. 我希望网络 I/O 延迟尽可能低，以便提升系统整体吞吐量
5. 我希望哈希计算和协议解析占用的 CPU 时间更少，以便释放更多资源给业务处理
6. 我希望看到分阶段的性能对比数据，以便评估每个优化阶段的 ROI

### 作为系统开发者

7. 我希望代码保持可读性和可维护性，以便后续迭代和调试
8. 我希望重构分阶段进行，以便在出现问题时能快速定位回退
9. 我希望热点路径的并发控制开销最小化，以便消除高并发下的总线争用

## Dependencies

### Phase 依赖关系图（已调整）

```
Phase 1（内存基底 + NUMA + 大页 + intrinsics）
    ↓ 提供 2MB 大页 + NUMA 亲和 + item 自然对齐
Phase 2（计算向量化：哈希 + ASCII 解析）  ── 可与 Phase 1 并行
    ↓
Phase 4（尾延迟优化：pause + MADV_COLLAPSE + 精简屏障） ── 可与 Phase 1/2 并行
    ↓
Phase 4.5（RV64A 原子操作：refcount 改 uint32，item 布局稳定）  ← 必须在 Phase 3 之前
    ↓ item 结构体 sizeof 锁定
Phase 3（io_uring 异步网络引擎：PBUF_RING 注册依赖稳定的 sizeof(item)）
    ↓ 提供零拷贝 DMA + SQE/CQE 派发
Phase 2.5（Slab 优化：仅 TTL 预分类 + 整页回收）
```

### 关键依赖说明

| Phase | 依赖项 | 依赖原因 |
|-------|--------|---------|
| **Phase 3 → Phase 4.5** | **Phase 4.5 必须先完成** | F3.3 PBUF_RING 注册时，DMA 目标地址基于 sizeof(item) 计算。F4.5.1 将 refcount 从 uint16 改为 uint32，sizeof 变化 2 字节。若 F4.5.1 在 PBUF_RING 注册后执行，DMA 写入会错位。 |
| Phase 4.5 → Phase 1 | F1.1（item 字段 8B 对齐）完成 | RV64A lr.d/sc.d 要求 8 字节对齐 |
| Phase 3 → Phase 1 | F1.2（2MB 大页）完成 | PBUF_RING 要求缓冲区物理连续且对齐 2MB |
| Phase 4 → Phase 1 | F1.4（intrinsics.h）完成 | F4.1 pause 指令需通过 intrinsics 头文件调用 |

### 并行执行建议

- **Phase 1、Phase 2、Phase 4** 可并行开发（无相互依赖）
- **Phase 4.5** 必须等待 Phase 1 完成，但可与 Phase 2/4 并行
- **Phase 3** 必须等待 Phase 4.5 完成（sizeof(item) 锁定）
- **Phase 2.5**（仅 TTL 预分类）必须在 Phase 3 之后

## Functional Requirements

### Phase 1: 内存基底与指令对齐

| ID | 需求 | 决策 | 验收标准 |
|----|------|------|----------|
| F1.1 | item 结构体字段**自然对齐** | ✅ 做 | `next/prev/refcount/time` 均 8 字节自然对齐（适配 lr.d/sc.d）。**不强加 64B cache line padding**，保持 sizeof(item) 最小化 |
| F1.2 | Slab 页尺寸 2MB + 显式大页 | ✅ 做 | `settings.slab_page_size == 2MB`；通过 `mmap(MAP_HUGETLB)` 显式申请大页。THP 内核停顿率 < 1% |
| F1.3 | ~~内存清零使用 Zicboz `cbo.zero`~~ | 👤 交给用户 | 用户自行替换 memset/memcpy/memmove/memchr，规格不涉及 |
| F1.4 | RISC-V 内联汇编封装头文件 | ✅ 做 | `riscv_intrinsics.h` 包含：cbo.zero/ctz/clz/pause/amomax.w/amoswap.w/lr.d/sc.d。**同时支持标准 Zbb 和玄铁 XTheadBb**，**编译期宏判定**（如 `#ifdef __riscv_xtheadbb`），不做运行时 hwprobe |
| F1.5 | NUMA 亲和性 Slab 分配 | ✅ 做（条件性） | **两路方案**：运行时检测 NUMA 节点数。>= 2 节点时按节点拆分空闲页池，跨节点访问率 < 5%；单节点时使用全局内存池（跳过 NUMA 优化） |

### Phase 2: 计算热点矢量化

| ID | 需求 | 决策 | 验收标准 |
|----|------|------|----------|
| F2.1 | ~~哈希算法替换为向量化版本~~ | ❌ 不做 | （用户决定不优化哈希算法） |
| F2.2 | ASCII 协议 `\r\n` 扫描向量化 | ✅ 做（仅 ASCII） | ASCII 协议解析吞吐 > 1GB/s；Binary 协议保持原逻辑 |
| F2.3 | ~~Slab 空闲块扫描使用 B 扩展~~ | ❌ 不做 | （原架构为 free list，无位图扫描需求） |
| F2.4 | ~~编译选项包含 RVV 和 B 扩展~~ | ❌ 不做 | （随 F2.2 自动启用，无独立需求） |

### Phase 2.5: Slab 机制深度优化（仅 TTL 预分类）

> **前置依赖**：Phase 3 必须完成并稳定。

| ID | 需求 | 决策 | 验收标准 |
|----|------|------|----------|
| F2.5.1 | ~~效用函数驱动重平衡~~ | ❌ 不做 | |
| F2.5.2 | ~~页压缩与条目迁移（Defrag）~~ | ❌ 不做 | |
| F2.5.3 | ~~运行时自适应 Slab Class 创建~~ | ❌ 不做 | |
| F2.5.4 | ~~相邻 Slab Class 空间借调~~ | ❌ 不做 | |
| F2.5.5 | ~~跨 Slab 全局借道置换~~ | ❌ 不做 | |
| F2.5.6 | 基于 TTL 预分类 + 整页回收 | ✅ 做 | 分配时按 TTL 区间路由到不同 Page（短命/长命隔离）。短命 Page 在相近时间整体过期，后台线程整页擦除。过期清理 CPU 开销降低 80%+ |

### Phase 3: 异步网络引擎重写

> **前置依赖**：Phase 4.5 必须完成（sizeof(item) 稳定）。

| ID | 需求 | 决策 | 验收标准 |
|----|------|------|----------|
| F3.1 | 用 io_uring 替换 libevent/epoll | ✅ 做 | 所有网络 I/O 通过 io_uring SQE/CQE 派发。非 Linux 6.0+ 环境回退 epoll |
| F3.2 | 启用 IORING_OP_RECV Multi-Shot | ✅ 做 | 内核持续推送套接字事件，无用户态 Re-arm。Linux < 5.19 自动降级为单发 RECV |
| F3.3 | 注册 PBUF_RING 实现零拷贝 | ✅ 做 | 网卡 DMA 直接写入 Slab，无用户态拷贝（通过 perf/eBPF 验证）。**必须在 Phase 4.5 完成后注册** |
| F3.4 | 每个 worker 线程独立 io_uring 实例 | ✅ 做 | 无跨线程 ring 访问，锁竞争最小化 |

### Phase 4: 内核高级协同与尾延迟优化

| ID | 需求 | 决策 | 验收标准 |
|----|------|------|----------|
| F4.1 | 自旋锁使用 Zihintpause 指令 | ✅ 做 | 自旋期间 CPU 功耗降低 15%+（通过 `perf stat -e power/energy-pkg/` 测量） |
| F4.2 | 冷 Slab 调用 madvise(MADV_COLLAPSE) | ✅ 做 | THP 聚合成功率 > 80% |
| F4.3 | 精简不必要的内存屏障 | ✅ 做（高风险） | fence 指令数量从 N 条减少到 M 条（通过 objdump 反汇编统计，基线 N 由 Phase 1 测量），**无正确性问题**（需充分并发压力测试验证） |

### Phase 4.5: RV64A 原子操作深度优化

> **前置依赖**：Phase 1 的 F1.1（item 字段 8 字节对齐）必须完成。
> **后续依赖**：Phase 3 的 F3.3（PBUF_RING）必须等待本 Phase 完成（sizeof(item) 锁定）。

| ID | 需求 | 决策 | 验收标准 |
|----|------|------|----------|
| F4.5.1 | 引用计数字段类型变更 | ✅ 做 | `refcount` 从 `unsigned short`（uint16）改为 `uint32_t`，以适配 `amoadd.w`（32 位原子加）。item 结构体 sizeof 增加 2 字节，对齐目标不变 |
| F4.5.2 | 引用计数 RV64A 优化 | ✅ 做 | `incr_refcount` 用 `amoadd.w`（Relaxed）；`decr_refcount` 用 `amoadd.w.aqrl`（Acq-Rel），仅在计数归零时同步释放 |
| F4.5.3 | LRU 时间戳 amomax 优化 | ✅ 做 | `time` 字段用 `amomax.w.rl` 单指令完成"比较并写入"，热点 Key 写冲突在硬件层退化为并发读 |
| F4.5.4 | LRU 自旋锁重构 | ✅ 做 | `amoswap.w.aq` + `pause` 自旋，替代 `pthread_mutex`，自旋开销降低 60%+ |
| F4.5.5 | Bump Queue 无锁化 | ✅ 做 | `lr.d`/`sc.d` 独占预约实现无 ABA 问题的无锁入队，无需版本号计数器 |

## Decision Summary

### 统计

| Phase | 总数 | 做 | 不做 | 交给用户 |
|-------|------|----|------|---------|
| Phase 1 | 5 | 4 | 0 | 1（F1.3） |
| Phase 2 | 4 | 1 | 3 | 0 |
| Phase 2.5 | 6 | 1 | 5 | 0 |
| Phase 3 | 4 | 4 | 0 | 0 |
| Phase 4 | 3 | 3 | 0 | 0 |
| Phase 4.5 | 5 | 5 | 0 | 0 |
| **总计** | **27** | **18** | **8** | **1** |

### 关键约束

1. **F1.1 弱化**：仅自然对齐，不强加 64B padding → sizeof(item) 不变（仅 F4.5.1 改 refcount 时增加 2 字节）
2. **F1.3 隔离**：memset 系列完全交给用户 → 规格不涉及
3. **F1.4 双路**：标准 Zbb + 玄铁 XTheadBb 编译期切换 → 通过 `__riscv_zbb` / `__riscv_xtheadbb` 宏
4. **F1.5 条件性**：NUMA 检测到则优化，否则全局池 → 两路实现
5. **Phase 顺序调整**：Phase 4.5 必须先于 Phase 3 → 确保 sizeof(item) 在 PBUF_RING 注册时稳定
6. **F4.3 高风险**：精简内存屏障需充分并发压力测试
7. **F2.1 不做**：哈希算法不优化 → 保持现有 MurmurHash3/XXH3

## Non-Functional Requirements

### 性能指标

| 指标 | 基线目标 | 优化目标 |
|------|----------|----------|
| 吞吐量（GET/SET QPS） | 记录基线 | 提升 3-5 倍 |
| P99 延迟 | 记录基线 | 降低 50%+ |
| P999 延迟 | 记录基线 | 降低 60%+ |
| CPU Cache Miss 率 | 记录基线 | 降低 40%+ |
| 内存带宽利用率 | 记录基线 | 提升 2x+ |
| 过期对象回收 CPU 开销 | 记录基线 | 降低 80%+ |
| 原子操作延迟 | 记录基线 | 降低 60%+ |

### 兼容性

- 保持 Memcached ASCII/Binary 协议完全兼容
- 保持现有配置参数语义（新增参数可选）
- 支持在非 RISC-V / 非 Linux 6.0 环境回退到传统实现
- **同时支持标准 RISC-V Zbb 和玄铁 XTheadBb 扩展**（编译期切换）

### 可维护性

- 每个阶段独立可测试、可回退
- 代码注释说明 RISC-V 特定优化点
- 性能基准脚本可重复执行

## Success Criteria

### 量化指标

1. **吞吐量提升**：在相同硬件配置下，GET/SET 混合负载 QPS 达到基线的 3-5 倍
2. **延迟改善**：P99 延迟降低 50% 以上，P999 延迟降低 60% 以上
3. **资源效率**：相同 QPS 下 CPU 占用降低 30% 以上
4. **零拷贝达成**：网络 I/O 路径无用户态-内核态数据拷贝（通过 perf/eBPF 验证）
5. **TTL 整页回收**：过期清理 CPU 开销降低 80%+
6. **原子操作优化**：热点路径原子操作延迟降低 60%+，无总线争用告警

### 质性指标

7. **协议兼容**：现有 Memcached 客户端无需修改即可使用
8. **渐进交付**：每个 Phase 完成后可独立部署验证
9. **可观测性**：提供详细的性能计数器输出（io_uring 深度、向量指令利用率、原子操作统计、NUMA 命中等）
10. **玄铁兼容**：在玄铁 CPU 上自动启用 XTheadBb 扩展，无需修改代码

## Prerequisites

### 硬件环境

| 前置条件 | 要求 | 降级策略 |
|---------|------|---------|
| RISC-V 64-bit | 支持 V/B/A/Zicbom/Zihintpause 扩展（标准 Zbb 或玄铁 XTheadBb） | 检测缺失扩展时禁用对应优化，回退到 C 标准库实现 |
| Linux 内核 | >= 6.0（io_uring Multi-Shot/PBUF_RING） | < 6.0 时禁用 io_uring，回退到 epoll；< 5.19 时禁用 Multi-Shot |
| NUMA 拓扑 | >= 2 个节点 | 单节点时禁用 NUMA 亲和性优化，使用全局内存池 |
| 大页预留 | `vm.nr_hugepages >= N`（N 由内存容量计算） | 大页不足时回退到 4KB 页，性能降级 15-20% |

### 编译环境

| 前置条件 | 要求 | 降级策略 |
|---------|------|---------|
| GCC | >= 14.0 或 LLVM >= 18.0 | 低版本时禁用 RISC-V intrinsics，回退到 C 标准库 |
| io_uring 库 | liburing >= 2.4 | 缺失时回退到 libevent/epoll |

### 编译期宏判定（玄铁扩展）

- `__riscv_zbb`：标准 Zbb 扩展（ctz/clz/andn 等）
- `__riscv_xtheadbb` 或 `__xtheadbb__`：玄铁 XTheadBb 厂商扩展（th.ff1/th.ff0/th.rev 等）
- 编译时通过 GCC/Clang 预定义宏切换实现，不做运行时 hwprobe

### 工作负载假设

- 以中小对象（< 1KB）为主的高并发读写场景（Memcached 典型用例）
- 使用 mutilate 或 memtier_benchmark 进行压测，perf 进行性能剖析

## Out of Scope

1. **Memcached 协议扩展**：不新增自定义命令或协议字段
2. **持久化功能**：不涉及外部存储（extstore）或重启恢复优化
3. **分布式特性**：不涉及集群、分片、复制等分布式功能
4. **安全功能**：不涉及 SASL、TLS 性能优化（保持现有实现）
5. **Proxy 模式**：不涉及 Memcached proxy 模式优化
6. **非 RISC-V 架构优化**：x86/ARM 特定优化不在本次重构范围
7. **Windows/FreeBSD 支持**：仅针对 Linux 6.0+ 平台
8. **CXL 分层内存**：冷数据分层路由作为后续独立功能规划
9. **混合分配模式（Slab + Log-Structured）**：作为后续独立规格规划
10. **动态 Slab Class 数量突破 64**：保持 `slabs_clsid` 为 uint8
11. **memset/memcpy/memmove/memchr 优化**：用户自行替换，规格不涉及（F1.3 决策）
12. **Slab 重平衡 / Defrag / 自适应 Class / 借调 / 全局置换**：F2.5.1-5 不做
13. **位图扫描向量化**：F2.3 不做（架构为 free list，无位图）
14. **运行时 hwprobe 检测玄铁扩展**：仅编译期宏判定（F1.4 决策）

## Risk Analysis

### 跨 Phase 并发风险

| 风险场景 | 涉及 Phase | 缓解措施 |
|---------|-----------|---------|
| **PBUF_RING 注册时 sizeof(item) 不稳定** | **Phase 4.5 + Phase 3** | **强制 Phase 4.5 在 Phase 3 之前完成**；F4.5.1 改 refcount 后，sizeof(item) 锁定，再注册 PBUF_RING |
| TTL 预分类与现有 LRU 队列冲突 | Phase 2.5 + Phase 4.5 | 短命 Page 不进入 HOT/WARM 队列，直接进入 TEMP 队列，过期时整页回收 |
| 精简内存屏障引发并发错误 | Phase 4（F4.3） | 必须通过 ThreadSanitizer + 高压并发压力测试验证 |

### 前置条件不满足风险

| 风险场景 | 缓解措施 |
|---------|---------|
| 大页预留不足 | 启动时检测大页可用量，不足时打印警告并回退到 4KB 页 |
| NUMA 节点数为 1 | 编译时检测 `libnuma`，运行时检测节点数，单节点时跳过 NUMA 亲和性初始化 |
| RISC-V 扩展缺失 | 编译期宏判定，缺失时回退到 C 标准库实现 |
| 玄铁 CPU 未定义 XTheadBb 宏 | 编译器需添加 `-march=...xtheadbb` 参数，否则回退到标准 Zbb |
| io_uring 内核版本不足 | 运行时检测内核版本，回退到 libevent/epoll |

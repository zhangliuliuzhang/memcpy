# Implementation Plan: RISC-V + io_uring Memcached 重构

## Overview

将 Memcached 1.6.42 针对 RISC-V 架构和 Linux 6.0 的 io_uring 进行深度性能优化重构。本计划基于规格文档 [spec.md](spec.md) 和逐项确认的技术决策。

## Constitution Check

> 参见 [constitution.md](constitution.md) - 本功能的独立宪法

| 约束类型 | 规则 | 状态 |
|---------|------|------|
| **代码修改** | 按规格修改，允许重构核心模块 | ✅ 允许 |
| **构建系统** | Autotools + Docker `rust-c-dev:latest` | ✅ 保持 |
| **目标平台** | RISC-V 64-bit + Linux 6.0+ | ✅ 新增 |
| **回退策略** | 非 RISC-V / 非 Linux 6.0 环境自动降级 | ✅ 必须 |

---

## Phase Execution Order

```
严格串行执行（每 Phase 完成并测试后进入下一 Phase）：

Phase 1: 内存基底与指令对齐
    ↓
Phase 2: 计算热点矢量化
    ↓
Phase 4: 尾延迟优化（pause + COLLAPSE + 屏障审计）
    ↓
Phase 4.5: RV64A 原子操作（sizeof(item) 锁定）
    ↓ ⚠️ 关键依赖：Phase 3 必须等待 Phase 4.5 完成
Phase 3: io_uring 异步网络引擎
    ↓
Phase 2.5: TTL 预分类 + 整页回收
```

---

## Phase 1: 内存基底与指令对齐

### F1.1 item 字段自然对齐

**决策**：静态断言验证（编译期报错）

**实现**：
```c
// memcached.h（在 item 结构体定义后添加）
_Static_assert(offsetof(item, next) % 8 == 0, "next pointer not 8-byte aligned");
_Static_assert(offsetof(item, prev) % 8 == 0, "prev pointer not 8-byte aligned");
_Static_assert(offsetof(item, h_next) % 8 == 0, "h_next pointer not 8-byte aligned");
_Static_assert(offsetof(item, time) % 4 == 0, "time field not 4-byte aligned");
```

**文件**：`memcached.h:730`（结构体定义后）

---

### F1.2 slab_page_size=2MB + 大页管理

**决策**：
- 全局默认 2MB（修改 `settings.slab_page_size`）
- 强制大页，失败退出（不回退 4KB 页）
- 使用 `mmap(MAP_HUGETLB)` 显式申请大页

**实现**：

1. **修改默认值**：
```c
// memcached.c:264
settings.slab_page_size = 2 * 1024 * 1024;  // 改为 2MB
```

2. **大页分配函数**：
```c
// slabs.c:memory_allocate()
static void *memory_allocate(size_t size) {
    void *ret = mmap(NULL, size, PROT_READ | PROT_WRITE,
                     MAP_PRIVATE | MAP_ANONYMOUS | MAP_HUGETLB,
                     -1, 0);
    if (ret == MAP_FAILED) {
        fprintf(stderr, "ERROR: Failed to allocate huge pages (size=%zu). "
                        "Please increase vm.nr_hugepages.\n", size);
        exit(1);
    }
    return ret;
}
```

3. **启动时大页检测**：
```c
// slabs.c:slabs_init() 开头
void slabs_init(...) {
    // 检测大页可用量
    FILE *f = fopen("/proc/sys/vm/nr_hugepages", "r");
    unsigned long nr_hugepages;
    fscanf(f, "%lu", &nr_hugepages);
    fclose(f);
    size_t required_pages = mem_limit / (2 * 1024 * 1024);
    if (nr_hugepages < required_pages) {
        fprintf(stderr, "WARNING: Only %lu huge pages available, "
                        "need %zu for full allocation.\n",
                nr_hugepages, required_pages);
    }
    // ... 继续原有逻辑
}
```

**文件**：
- `memcached.c:264`
- `slabs.c:memory_allocate()`
- `slabs.c:slabs_init()`

---

### F1.4 RISC-V intrinsics 头文件

**决策**：
- 单独头文件 `riscv_intrinsics.h`
- GCC/Clang 预定义宏检测玄铁扩展（`__riscv_xtheadbb` / `__xtheadbb__`）
- 同时支持标准 Zbb 和玄铁 XTheadBb

**实现**：

```c
// riscv_intrinsics.h（新建）
#ifndef RISCV_INTRINSICS_H
#define RISCV_INTRINSICS_H

#ifdef __riscv

// ===== Zihintpause =====
static inline void riscv_pause(void) {
    asm volatile("pause" ::: "memory");
}

// ===== Zicboz (cbo.zero) =====
#ifdef __riscv_zicboz
static inline void riscv_cbo_zero(void *addr) {
    asm volatile("cbo.zero %0" : : "r"(addr) : "memory");
}
#endif

// ===== Zbb / XTheadBb (ctz/clz) =====
#if defined(__riscv_zbb) || defined(__riscv_xtheadbb) || defined(__xtheadbb__)
static inline unsigned int riscv_ctz(unsigned int x) {
#if defined(__riscv_xtheadbb) || defined(__xtheadbb__)
    unsigned int result;
    asm volatile("th.ff0 %0, %1" : "=r"(result) : "r"(x));
    return result;
#else  // 标准 Zbb
    unsigned int result;
    asm volatile("ctz %0, %1" : "=r"(result) : "r"(x));
    return result;
#endif
}

static inline unsigned int riscv_clz(unsigned int x) {
#if defined(__riscv_xtheadbb) || defined(__xtheadbb__)
    unsigned int result;
    asm volatile("th.ff1 %0, %1" : "=r"(result) : "r"(x));
    return result;
#else  // 标准 Zbb
    unsigned int result;
    asm volatile("clz %0, %1" : "=r"(result) : "r"(x));
    return result;
#endif
}
#endif

// ===== RV64A Atomic Operations =====
// amomax.w.rl for time update
static inline void riscv_amomax_w_rl(uint32_t *addr, uint32_t val) {
    asm volatile("amomax.w.rl zero, %0, (%1)"
                 : : "r"(val), "r"(addr) : "memory");
}

// amoswap.w.aq for spinlock acquire
static inline uint32_t riscv_amoswap_w_aq(uint32_t *lock, uint32_t val) {
    uint32_t result;
    asm volatile("amoswap.w.aq %0, %1, (%2)"
                 : "=r"(result) : "r"(val), "r"(lock) : "memory");
    return result;
}

// lr.d/sc.d for lock-free queue
static inline uint64_t riscv_lr_d(uint64_t *addr) {
    uint64_t result;
    asm volatile("lr.d %0, (%1)" : "=r"(result) : "r"(addr) : "memory");
    return result;
}

static inline long riscv_sc_d_rl(uint64_t *addr, uint64_t val) {
    long result;
    asm volatile("sc.d.rl %0, %1, (%2)"
                 : "=r"(result) : "r"(val), "r"(addr) : "memory");
    return result;
}

#endif  // __riscv

#endif  // RISCV_INTRINSICS_H
```

**文件**：`riscv_intrinsics.h`（新建）

---

### F1.5 NUMA 亲和（条件性）

**决策**：编译期条件编译（`./configure --enable-numa`）

**实现**：

```c
// slabs.c
#ifdef HAVE_NUMA
#include <numa.h>

// Per-node memory pools
static void *mem_base_numa[MAX_NUMA_NODES];
static size_t mem_avail_numa[MAX_NUMA_NODES];
static int numa_node_count;

static int detect_numa_nodes(void) {
    if (numa_available() < 0) return 0;
    numa_node_count = numa_num_configured_nodes();
    return numa_node_count;
}
#endif

// slabs_init()
void slabs_init(...) {
#ifdef HAVE_NUMA
    int nodes = detect_numa_nodes();
    if (nodes >= 2) {
        // Per-node allocation
        for (int i = 0; i < nodes; i++) {
            mem_base_numa[i] = memory_allocate(mem_limit / nodes);
            mem_avail_numa[i] = mem_limit / nodes;
        }
        fprintf(stderr, "NUMA affinity enabled: %d nodes detected\n", nodes);
    } else {
        // Single node: use global pool
        mem_base = memory_allocate(mem_limit);
        mem_current = mem_base;
        mem_avail = mem_limit;
        fprintf(stderr, "NUMA affinity disabled: single node detected\n");
    }
#else
    // No libnuma: use global pool
    mem_base = memory_allocate(mem_limit);
    mem_current = mem_base;
    mem_avail = mem_limit;
#endif
}
```

**configure.ac 添加**：
```autoconf
AC_ARG_ENABLE([numa],
  [AS_HELP_STRING([--enable-numa], [Enable NUMA-aware memory allocation])])
if test "x$enable_numa" = "xyes"; then
  AC_CHECK_LIB([numa], [numa_available], [have_numa=yes], [have_numa=no])
  if test "x$have_numa" = "xyes"; then
    AC_DEFINE([HAVE_NUMA], [1], [Define if libnuma is available])
    LIBS="-lnuma $LIBS"
  else
    AC_MSG_WARN([libnuma not found, NUMA support disabled])
  fi
fi
```

**文件**：
- `slabs.c`
- `configure.ac`

---

## Phase 2: 计算热点矢量化

### F2.1 哈希算法

**决策**：不优化（用户决定）

**说明**：保持现有 MurmurHash3/XXH3 实现，不进行 RVV 向量化改造。

---

### F2.2 ASCII \r\n 向量化

**决策**：新建内联函数替换 memchr

**实现**：

```c
// riscv_intrinsics.h 添加
#ifdef __riscv_vector
static inline const char *riscv_memchr_crlf(const char *s, size_t n) {
    // RVV 向量化扫描 \r\n 序列
    // 简化版：先找 \r，再检查后一个字符是否 \n
    size_t vl;
    const char *result = NULL;

    // 使用 RVV 向量加载和比较
    while (n > 0) {
        vl = __riscv_vsetvl_e8m1(n);
        vint8m1_t vdata = __riscv_vle8_v_i8m1(s, vl);
        vint8m1_t vcr = __riscv_vmseq_vx_i8m1(vdata, '\r', vl);
        // ... 向量查找逻辑 ...
        // 如果找到 \r 且下一个是 \n，返回位置
        // 详见完整实现
    }
    return result;
}
#endif
```

```c
// proto_text.c:273 替换
#ifdef __riscv_vector
el = riscv_memchr_crlf(c->rcurr, c->rbytes);
#else
el = memchr(c->rcurr, '\n', c->rbytes);
#endif
```

**文件**：
- `riscv_intrinsics.h`
- `proto_text.c:273,386`

---

## Phase 4: 尾延迟优化

### F4.1 Zihintpause 指令

**决策**：在自旋锁循环中插入 pause 指令（F4.5.4 实现后调用）

**实现**：
```c
// riscv_intrinsics.h（已在 F1.4 定义）
static inline void riscv_pause(void) {
    asm volatile("pause" ::: "memory");
}

// 自旋锁使用（F4.5.4 中）
void riscv_spinlock_lock(riscv_spinlock_t *lock) {
    while (riscv_amoswap_w_aq(lock, 1) != 0) {
        riscv_pause();  // 自旋等待
    }
}
```

---

### F4.2 MADV_COLLAPSE

**决策**：
- 定时触发（启动参数 `--madv-collapse-interval=N`）
- 仅 COLD LRU 页面

**实现**：

```c
// 新增启动参数
settings.madv_collapse_interval = 60;  // 默认 60 秒

// 新增后台线程（或复用 lru_maintainer）
static void *madv_collapse_thread(void *arg) {
    while (1) {
        sleep(settings.madv_collapse_interval);
        for (int i = 0; i < MAX_NUMBER_OF_SLAB_CLASSES; i++) {
            // 检查 COLD_LRU 尾部页面
            item *tail = tails[i | COLD_LRU];
            if (tail && ITEM_is_cold_page(tail)) {
                void *page_addr = item_to_page_addr(tail);
                madvise(page_addr, settings.slab_page_size, MADV_COLLAPSE);
            }
        }
    }
}
```

**文件**：
- `memcached.c`（启动参数）
- `slabs.c` 或 `items.c`（后台线程）

---

### F4.3 精简内存屏障

**决策**：全部审计 + ThreadSanitizer 验证

**实现**：
1. 运行 `make CFLAGS="-fsanitize=thread" test`
2. 审计所有 `__sync_synchronize`、`pthread_mutex` 边界
3. 针对性精简热点路径的屏障

**验证要求**：ThreadSanitizer 无 data race 报告

---

## Phase 4.5: RV64A 原子操作

⚠️ **关键前置**：必须在 Phase 3 之前完成

### F4.5.1 refcount 改 uint32

**决策**：仅修改 `item.refcount`，`item_chunk.refcount` 保持 uint16

**实现**：
```c
// memcached.h:716
typedef struct _stritem {
    // ...
    uint32_t        refcount;   // 改为 uint32_t
    // ...
} item;
```

**影响**：sizeof(item) 增加 2 字节，需更新所有依赖 sizeof(item) 的计算

---

### F4.5.2 引用计数 RV64A 优化

**决策**：C11 stdatomic

**实现**：
```c
// memcached.h:1190-1191 替换
#include <stdatomic.h>

#define refcount_incr(it) \
    atomic_fetch_add_explicit((atomic_uint *)&(it)->refcount, 1, memory_order_relaxed)

#define refcount_decr(it) \
    (atomic_fetch_add_explicit((atomic_uint *)&(it)->refcount, -1, memory_order_acq_rel) == 1)
```

**注意**：`refcount_decr` 返回值为"是否归零"，归零时需同步释放

---

### F4.5.3 LRU 时间戳 amomax

**决策**：内联汇编（C11 无 atomic_fetch_max）

**实现**：
```c
// items.c:521,589,596,603,1078 替换为
riscv_amomax_w_rl(&it->time, current_time);
```

---

### F4.5.4 LRU 自旋锁重构

**决策**：
- 仅替换 `lru_locks[256]`
- 简单 amoswap 自旋锁（无公平性保证）

**实现**：
```c
// thread.c:100 替换
typedef volatile uint32_t riscv_spinlock_t;
extern riscv_spinlock_t lru_locks[POWER_LARGEST];

// riscv_intrinsics.h 添加
static inline void riscv_spinlock_lock(riscv_spinlock_t *lock) {
    while (riscv_amoswap_w_aq(lock, 1) != 0) {
        riscv_pause();
    }
}

static inline void riscv_spinlock_unlock(riscv_spinlock_t *lock) {
    asm volatile("amoswap.w.rl zero, zero, (%0)" : : "r"(lock) : "memory");
}

// 替换所有 mutex_lock(&lru_locks[id]) 为 riscv_spinlock_lock(&lru_locks[id])
```

---

### F4.5.5 Bump Queue 无锁化

**决策**：入队无锁（lr.d/sc.d），出队保持 mutex

**实现**：
```c
// items.c:112-131
typedef struct _lru_bump_buf {
    struct _lru_bump_buf *prev;
    struct _lru_bump_buf *next;
    pthread_mutex_t dequeue_mutex;  // 仅出队保护
    atomic_uint64_t head;           // 无锁入队目标
    bipbuf_t *buf;
    uint64_t dropped;
} lru_bump_buf;

static bool lru_bump_async(lru_bump_buf *b, item *it, uint32_t hv) {
    // lr.d/sc.d 无锁入队
    uint64_t old_head, success;
    do {
        old_head = riscv_lr_d(&b->head);
        success = riscv_sc_d_rl(&b->head, (uint64_t)new_entry);
    } while (success != 0);
    // ...
}
```

---

## Phase 3: io_uring 异步网络引擎

⚠️ **前置依赖**：Phase 4.5 完成（sizeof(item) 稳定）

### F3.1 io_uring 替换 libevent

**决策**：
- 编译期条件编译（`./configure --enable-io_uring`）
- SQ/CQ 深度默认 256，启动参数 `--io-uring-depth=N` 可调

**实现**：

```c
// configure.ac
AC_ARG_ENABLE([io_uring],
  [AS_HELP_STRING([--enable-io_uring], [Enable io_uring async I/O])])
if test "x$enable_io_uring" = "xyes"; then
  AC_CHECK_LIB([uring], [io_uring_queue_init], [have_uring=yes], [have_uring=no])
  if test "x$have_uring" = "xyes"; then
    AC_DEFINE([HAVE_IO_URING], [1], [Define if liburing is available])
    LIBS="-luring $LIBS"
  fi
fi
```

```c
// io_uring_engine.h（新建）
#ifdef HAVE_IO_URING
#include <liburing.h>

typedef struct {
    struct io_uring ring;
    int depth;
} io_uring_ctx_t;

int io_uring_engine_init(io_uring_ctx_t *ctx, int depth);
void io_uring_engine_loop(io_uring_ctx_t *ctx);
#endif
```

```c
// thread.c 替换
#ifdef HAVE_IO_URING
io_uring_engine_init(&me->ring_ctx, settings.io_uring_depth);
io_uring_engine_loop(&me->ring_ctx);
#else
event_base_loop(me->base, EVLOOP_ONCE);
#endif
```

**文件**：
- `configure.ac`
- `io_uring_engine.c/h`（新建）
- `thread.c`

---

### F3.2 RECV Multi-Shot

**决策**：运行时自动探测内核版本，<5.19 降级单发

**实现**：
```c
// io_uring_engine.c
static bool kernel_supports_multishot(void) {
    struct utsname buf;
    uname(&buf);
    int major, minor;
    sscanf(buf.release, "%d.%d", &major, &minor);
    return (major >= 5 && minor >= 19) || (major >= 6);
}

void io_uring_recv_setup(io_uring_ctx_t *ctx, int fd) {
    if (kernel_supports_multishot()) {
        struct io_uring_sqe *sqe = io_uring_get_sqe(&ctx->ring);
        io_uring_prep_recv(sqe, fd, NULL, 0, IORING_RECV_MULTISHOT);
        // ...
    } else {
        // 单发模式
        // ...
    }
}
```

---

### F3.3 PBUF_RING 零拷贝

**决策**：
- 独立缓冲区（一次拷贝方案）
- 每 worker 16MB（8 个 2MB 页）
- DMA 写入缓冲区，解析后 memcpy 到 Slab

**实现**：
```c
// io_uring_engine.c
typedef struct {
    void *buf_ring;
    size_t buf_ring_size;  // 16MB
    int registered_bgid;
} pbuf_ring_ctx_t;

int pbuf_ring_register(io_uring_ctx_t *ctx, pbuf_ring_ctx_t *pbuf) {
    // mmap 16MB 独立缓冲区
    pbuf->buf_ring = mmap(NULL, 16 * 1024 * 1024,
                          PROT_READ | PROT_WRITE,
                          MAP_PRIVATE | MAP_ANONYMOUS | MAP_HUGETLB,
                          -1, 0);

    // 注册 PBUF_RING
    struct io_uring_buf_ring *br = io_uring_setup_buf_ring(&ctx->ring, 8, pbuf->registered_bgid, 0);
    // 填充缓冲区地址
    // ...
}
```

---

### F3.4 每 worker 独立 ring

**决策**：每 worker 独立 io_uring 实例

**实现**：
```c
// thread.c
typedef struct {
    // ...
#ifdef HAVE_IO_URING
    io_uring_ctx_t ring_ctx;
#endif
} LIBEVENT_THREAD;

static void *worker_thread(void *arg) {
    LIBEVENT_THREAD *me = arg;
#ifdef HAVE_IO_URING
    io_uring_engine_init(&me->ring_ctx, settings.io_uring_depth);
    io_uring_engine_loop(&me->ring_ctx);
#else
    event_base_loop(me->base, EVLOOP_ONCE);
#endif
}
```

---

## Phase 2.5: TTL 预分类

### F2.5.6 TTL 预分类 + 整页回收

**决策**：
- 60 秒阈值（对齐 `settings.temporary_ttl`）
- 复用 `lru_maintainer` 后台线程

**实现**：

```c
// items.c:do_item_alloc()
// 在分配时按 TTL 路由到不同 Page
if (exptime <= current_time + 60) {
    // 短命对象：路由到短命 Page
    id |= SHORT_TTL_PAGE;
} else {
    // 长命对象：路由到长命 Page
    id |= LONG_TTL_PAGE;
}

// lru_maintainer 中添加整页回收逻辑
static void ttl_page_recycle(void) {
    for (int i = 0; i < MAX_NUMBER_OF_SLAB_CLASSES; i++) {
        // 检查短命 Page 是否全部过期
        if (is_short_ttl_page(i) && page_all_expired(i)) {
            // 整页回收
            slabs_free_page(i);
        }
    }
}
```

---

## Critical Files Summary

| Phase | 文件 | 操作 |
|-------|------|------|
| F1.1 | `memcached.h` | 添加静态断言 |
| F1.2 | `memcached.c`, `slabs.c` | slab_page_size=2MB, 大页分配 |
| F1.4 | `riscv_intrinsics.h` | 新建 |
| F1.5 | `slabs.c`, `configure.ac` | NUMA 条件编译 |
| F2.1 | `hash.c` | 不优化，保持现有实现 |
| F2.2 | `riscv_intrinsics.h`, `proto_text.c` | 向量化 \r\n 扫描 |
| F4.1 | `riscv_intrinsics.h` | pause 指令 |
| F4.2 | `slabs.c` | MADV_COLLAPSE 线程 |
| F4.3 | 全局 | ThreadSanitizer 审计 |
| F4.5.1 | `memcached.h` | refcount 改 uint32 |
| F4.5.2 | `memcached.h` | stdatomic refcount |
| F4.5.3 | `items.c`, `riscv_intrinsics.h` | amomax 时间戳 |
| F4.5.4 | `thread.c`, `riscv_intrinsics.h` | 自旋锁替换 |
| F4.5.5 | `items.c` | 无锁 Bump Queue |
| F3.1-4 | `io_uring_engine.c/h`, `thread.c`, `configure.ac` | io_uring 引擎 |
| F2.5.6 | `items.c`, `slabs.c` | TTL 预分类 |

---

## Verification Strategy

### 每 Phase 测试

1. 编译验证：`./autogen.sh && ./configure && make -j$(nproc)`
2. 单元测试：`make test` 或 `./testapp`
3. 功能验证：启动 memcached，运行基本 GET/SET 操作

### Phase 4.3 特殊验证

```bash
make clean
make CFLAGS="-fsanitize=thread -g" test
# 无 data race 报告
```

### Phase 4.5 特殊验证

- refcount 改 uint32 后验证 `sizeof(item)` 变化
- 并发压力测试验证原子操作正确性

### Phase 3 特殊验证

- io_uring 编译成功（liburing 链接）
- 内核版本探测正确
- 网络连接正常收发

---

## Risk Mitigation

| 风险 | 缓解措施 |
|------|----------|
| F4.5.1 sizeof 变化破坏 PBUF_RING | **强制 Phase 4.5 先于 Phase 3** |
| F4.3 内存屏障精简导致并发错误 | ThreadSanitizer + 高压压力测试 |
| 大页不足启动失败 | 启动时检测并提示用户增加 nr_hugepages |
| io_uring 内核版本不足 | 编译期条件编译，无 liburing 时回退 libevent |
| 玄铁扩展宏未定义 | 编译器需 `-march=...xtheadbb`，否则回退 Zbb |

---

## Generated Artifacts

- [plan.md](plan.md) - 本文件
- [constitution.md](constitution.md) - 002 功能独立宪法
/*****************************************************************************
* 版权所有(C) 2017, ZTE Corp. ZXSDR-RRU Platform BSP
*----------------------------------------------------------------------------
* 模 块 名 : BSP
* 文件名称 : bsp_service_private_api.h
* 文件标识 : {[N/A]}
* 内容摘要 : 供BSP内部注册接口使用的框架接口声明 
* 注意事项 : 无
* 作    者 : 10248577
* 创建日期 : 2024-12-14 10:54:35
* 当前版本 : Ver1.0
*----------------------------------------------------------------------------
* 变更记录 :
*
* $记录1
* 变 更 单: $0000000(N/A)
* 责 任 人:
* 修改日戳:
* 变更说明: 创建文件

*----------------------------------------------------------------------------
*/

#ifndef BSP_SERVICE_PRVATE_API_H
#define BSP_SERVICE_PRVATE_API_H

#ifdef __cplusplus
extern "C" {
#endif

#include "bsp_service.h"

/** @brief 仅有输入参数的统一接口适配代码模板 */
#define BSP_SERVICE_SET_DEF_S(cmd) \
static UINT32 BspService_##cmd(VOID* inputPtr, UINT32 inputLen, VOID* outputPtr, UINT32 outputLen)   \
{                                                                                                    \
    T_##cmd##_IN_PARA inPara = {0};                                                                  \
    if(NULL == inputPtr || sizeof(T_##cmd##_IN_PARA) != inputLen)                                    \
    {                                                                                                \
        return BSP_ERROR;                                                                            \
    }                                                                                                \
    memcpy_s(&inPara, sizeof(T_##cmd##_IN_PARA), inputPtr, inputLen);

#define BSP_SERVICE_SET_DEF_E(cmd) }

/** @brief 有输入、输出参数的统一接口适配代码模板 */
#define BSP_SERVICE_SGET_DEF_S(cmd) \
static UINT32 BspService_##cmd(VOID* inputPtr, UINT32 inputLen, VOID* outputPtr, UINT32 outputLen)   \
{                                                                                                    \
    UINT32 retVal = BSP_OK;                                                                          \
    T_##cmd##_IN_PARA inPara = {0};                                                                  \
    T_##cmd##_OUT_PARA outPara = {0};                                                                \
    if(NULL == inputPtr || sizeof(T_##cmd##_IN_PARA) != inputLen)                                    \
    {                                                                                                \
        return BSP_ERROR;                                                                            \
    }                                                                                                \
    if(NULL == outputPtr || sizeof(T_##cmd##_OUT_PARA) != outputLen)                                 \
    {                                                                                                \
        return BSP_ERROR;                                                                            \
    }                                                                                                \
    memcpy_s(&inPara, sizeof(T_##cmd##_IN_PARA), inputPtr, inputLen);  

#define BSP_SERVICE_SGET_DEF_E(cmd) \
    if(BSP_OK == retVal)                                                                             \
    {                                                                                                \
        memcpy_s(outputPtr, outputLen, &outPara, sizeof(T_##cmd##_OUT_PARA));                        \
    }                                                                                                \
    return retVal;                                                                                   \
}

/** @brief 仅有输出参数的统一接口适配代码模板 */
#define BSP_SERVICE_GET_DEF_S(cmd) \
static UINT32 BspService_##cmd(VOID* inputPtr, UINT32 inputLen, VOID* outputPtr, UINT32 outputLen)   \
{                                                                                                    \
    UINT32 retVal = BSP_OK;                                                                          \
    T_##cmd##_OUT_PARA outPara = {0};                                                                \
    if(NULL == outputPtr || sizeof(T_##cmd##_OUT_PARA) != outputLen)                                 \
    {                                                                                                \
        return BSP_ERROR;                                                                            \
    }

#define BSP_SERVICE_GET_DEF_E(cmd) \
    if(BSP_OK == retVal)                                                                             \
    {                                                                                                \
        memcpy_s(outputPtr, outputLen, &outPara, sizeof(T_##cmd##_OUT_PARA));                        \
    }                                                                                                \
    return retVal;                                                                                   \
}

/** @brief 无输入和输出参数的统一接口适配代码模板 */
#define BSP_SERVICE_NSGET_DEF_S(cmd) \
static UINT32 BspService_##cmd(VOID* inputPtr, UINT32 inputLen, VOID* outputPtr, UINT32 outputLen)    \
{
    
#define BSP_SERVICE_NSGET_DEF_E(cmd) }

/** @brief 接口注册代码模板 */
#define BSP_SERVICE_REGIST_DEF(cmd) BspRegistService(cmd,BspService_##cmd)

#ifdef __cplusplus
}
#endif

#endif

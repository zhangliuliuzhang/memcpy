/*****************************************************************************
* 版权所有(C) 2017, ZTE Corp. ZXSDR-RRU Platform BSP
*----------------------------------------------------------------------------
* 模 块 名 : BSP
* 文件名称 : bsp_service.h
* 文件标识 : {[N/A]}
* 内容摘要 : 框架使用基本数据类型定义
* 注意事项 : 无
* 作    者 : 10248577
* 创建日期 : 2024-12-14 10:55:13
* 当前版本 : Ver1.0
*----------------------------------------------------------------------------
* 变更记录 :
*
* $记录1
* 变 更 单: $0000000(N/A)
* 责 任 人:
* 修改日戳:
* 变更说明: 创建文件

*----------------------------------------------------------------------------
*/

#ifndef BSP_SERVICE_H
#define BSP_SERVICE_H

#ifdef __cplusplus
extern "C" {
#endif

#include <stdint.h>
#include "bsp_service_errcode.h"
/**************************************************************************
 *                         Data Type定义                                    *
 **************************************************************************/
typedef uint32_t (*BspServiceFuncVarArgs)(void * inputData, uint32_t inputLen, void * outputData, uint32_t outputLen);

BspServiceFuncVarArgs BspGetService(uint32_t cmd);
uint32_t BspRegistService(uint32_t cmd, BspServiceFuncVarArgs serviceFunc);
uint32_t BspUnregistService(uint32_t cmd);

#ifdef __cplusplus
}
#endif

#endif

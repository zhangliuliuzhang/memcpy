/*****************************************************************************
* 版权所有(C) 2017, ZTE Corp. ZXSDR-RRU Platform BSP
*----------------------------------------------------------------------------
* 模 块 名 : BSP
* 文件名称 : bsp_service_public_def.h
* 文件标识 : {[N/A]}
* 内容摘要 : 供APP使用的BSP统一接口返回值声明
* 注意事项 : 无
* 作    者 : 10248577
* 创建日期 : 2024-12-14 10:53:36
* 当前版本 : Ver1.0
*----------------------------------------------------------------------------
* 变更记录 :
*
* $记录1
* 变 更 单: $0000000(N/A)
* 责 任 人:
* 修改日戳:
* 变更说明: 创建文件

*----------------------------------------------------------------------------
*/

#ifndef BSP_SERVICE_ERRCODE_H
#define BSP_SERVICE_ERRCODE_H

#ifdef __cplusplus
extern "C" {
#endif

#include <stdint.h>

/* Started by AICoder, pid:p1b45j58dbcbe9714c4c0824d011e8122eb79db2 */
/** @brief BSP统一接口万用错误码定义 */
#define BSP_SERVICE_OK                            (0)
#define BSP_SERVICE_ERROR                         ((uint32_t)(-1))

/** @brief BSP统一接口通用错误码定义(0xff000000开始) */
#define BSP_SERVICE_ERR_INVALID_PARA              ((uint32_t)0xff000001)
#define BSP_SERVICE_ERR_NULL_POINTER              ((uint32_t)0xff000002)
#define BSP_SERVICE_ERR_OUT_OF_RANGE              ((uint32_t)0xff000003)
#define BSP_SERVICE_ERR_FUNC_NOT_SUPPORT          ((uint32_t)0xff000004)
#define BSP_SERVICE_ERR_MEM_MALLOC                ((uint32_t)0xff000005)
#define BSP_SERVICE_ERR_OUT_OF_TIME               ((uint32_t)0xff000006)
#define BSP_SERVICE_ERR_CRC                       ((uint32_t)0xff000007)
#define BSP_SERVICE_ERR_DEVICE_NOT_READY          ((uint32_t)0xff000008)
#define BSP_SERVICE_ERR_DEVICE_NOT_EXIST          ((uint32_t)0xff000009)
#define BSP_SERVICE_ERR_FILE_NOT_FOUND            ((uint32_t)0xff00000A)
#define BSP_SERVICE_ERR_BUF_TOO_SMALL             ((uint32_t)0xff00000B)
#define BSP_SERVICE_ERR_NETWORK_ERROR             ((uint32_t)0xff00000C)
/* Ended by AICoder, pid:p1b45j58dbcbe9714c4c0824d011e8122eb79db2 */

#ifdef __cplusplus
}
#endif

#endif

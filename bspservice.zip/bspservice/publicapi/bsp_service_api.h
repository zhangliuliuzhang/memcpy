/*****************************************************************************
* 版权所有(C) 2017, ZTE Corp. ZXSDR-RRU Platform BSP
*----------------------------------------------------------------------------
* 模 块 名 : BSP
* 文件名称 : bsp_service_public_api.h
* 文件标识 : {[N/A]}
* 内容摘要 : 供APP使用的BSP统一接口声明
* 注意事项 : 无
* 作    者 : 10248577
* 创建日期 : 2024-12-14 10:53:36
* 当前版本 : Ver1.0
*----------------------------------------------------------------------------
* 变更记录 :
*
* $记录1
* 变 更 单: $0000000(N/A)
* 责 任 人:
* 修改日戳:
* 变更说明: 创建文件

*----------------------------------------------------------------------------
*/

#ifndef BSP_SERVICE_PUBLIC_API_H
#define BSP_SERVICE_PUBLIC_API_H


#ifdef __cplusplus
extern "C" {
#endif

/* Started by AICoder, pid:97672ocd33s8ed4149740aea0156332f3fd3654f */
#include <stdint.h>

/** 
 * @brief BSP统一接口输入参数标准定义 
 * @param[in] cmd 
 * @code
 * 原接口输入参数为：UINT32 chan, INT32 gain
 * 如果对应的cmd为BSP_CMD_SET_KD_GAIN，则入参可定义为
 * BSP_PARA_IN_DEF_S(BSP_CMD_SET_KD_GAIN)
 * {
 *     UINT32 chan;
 *     INT32 gain;
 * } BSP_PARA_IN_DEF_E(BSP_CMD_SET_KD_GAIN);
 * @endcode
 */
#define BSP_PARA_IN_DEF_S(cmd) typedef struct tag_##cmd##_IN_PARA 
#define BSP_PARA_IN_DEF_E(cmd) T_##cmd##_IN_PARA

/** 
 * @brief BSP统一接口输出参数标准定义 
 * @param[in] cmd 
 * @code
 * 原接口输出参数为：INT32 *gain;
 * 如果对应的cmd为BSP_CMD_GET_KD_GAIN，则出参定义为
 * BSP_PARA_OUT_DEF_S(BSP_CMD_GET_KD_GAIN)
 * {
 *     INT32 gain;
 * } BSP_PARA_OUT_DEF_E(BSP_CMD_GET_KD_GAIN);
 * @endcode
 */
#define BSP_PARA_OUT_DEF_S(cmd) typedef struct tag_##cmd##_OUT_PARA 
#define BSP_PARA_OUT_DEF_E(cmd) T_##cmd##_OUT_PARA

/** 
 * @brief 复用已有结构体的输入参数标准定义 
 * @param[in] tag 复用的结构体的typedef名称 
 * @param[in] cmd 
 * @code
 * 复用的结构体及typedef声明：
 * struct tagT_ChanGain
 * {
 *     UINT32 chan;
 *     INT32 gain;
 * };
 * typedef struct tagT_ChanGain T_ChanGain;
 * 输出参数标准定义：
 * BSP_PARA_IN_TYPEDEF(T_ChanGain, BSP_CMD_SET_TX_GAIN);
 * @endcode
 */
#define BSP_PARA_IN_TYPEDEF(tag,cmd) typedef tag T_##cmd##_IN_PARA 

/** 
 * @brief 复用已有结构体的输出参数标准定义 
 * @param[in] tag 复用的结构体的typedef名称 
 * @param[in] cmd 
 * @code
 * 复用的结构体及typedef声明：
 * struct tagT_Gain
 * {
 *     INT32 gain;
 * };
 * typedef struct tagT_Gain T_Gain;
 * 输出参数标准定义：
 * BSP_PARA_OUT_TYPEDEF(T_Gain, BSP_CMD_GET_KD_GAIN);
 * @endcode
 */
#define BSP_PARA_OUT_TYPEDEF(tag,cmd) typedef tag T_##cmd##_OUT_PARA 

/** 
 * @brief APP侧统一接口输入参数定义 
 * @param[in] cmd 
 * @code
 * BSP侧输入参数定义：
 * BSP_PARA_IN_DEF_S(BSP_CMD_SET_KD_GAIN)
 * {
 *     UINT32 chan;
 *     INT32 gain;
 * } BSP_PARA_IN_DEF_E(BSP_CMD_SET_KD_GAIN);
 * APP侧使用示例：
 * BSP_PARA_IN(BSP_CMD_SET_KD_GAIN) in = {0};
 * ret = BspCallService(BSP_CMD_SET_KD_GAIN, &in, sizeof(in), NULL, 0);
 * 其他处理
 * @endcode
 */
#define BSP_PARA_IN(cmd) T_##cmd##_IN_PARA

/** 
 * @brief APP侧统一接口输出参数定义 
 * @param[in] cmd 
 * @code
 * BSP侧
 * 输入参数定义：
 * BSP_PARA_IN_DEF_S(BSP_CMD_GET_KD_GAIN)
 * {
 *     UINT32 chan;
 * } BSP_PARA_IN_DEF_E(BSP_CMD_GET_KD_GAIN);
 * 输出参数定义：
 * BSP_PARA_OUT_DEF_S(BSP_CMD_GET_KD_GAIN)
 * {
 *     INT32 gain;
 * } BSP_PARA_OUT_DEF_E(BSP_CMD_GET_KD_GAIN);
 * APP侧
 * 使用示例：
 * BSP_PARA_IN(BSP_CMD_GET_KD_GAIN) in = {0};
 * BSP_PARA_OUT(BSP_CMD_GET_KD_GAIN) out = {0};
 * ret = BspCallService(BSP_CMD_GET_KD_GAIN, &in, sizeof(in), &out, sizeof(out));
 * 其他处理
 * @endcode
 */
#define BSP_PARA_OUT(cmd) T_##cmd##_OUT_PARA

/**
 * @brief       BSP统一接口
 * @param[in]   cmd:用于标识功能类别和接口
 * @param[in]   inputPtr:存放入参数据的buf地址
 * @param[in]   inputLen:入参数据buf的长度，避免访问越界
 * @param[out]  outputPtr:存放出参数据的buf地址
 * @param[in]   outputLen:存放输出参数的buf的长度，避免访问越界
 * @return
 *   =0   成功 \n
 *   其它 失败，详见bsp_service_errcode.h中的错误码定义 \n
*/
uint32_t BspCallService(uint32_t cmd, void * inputPtr, uint32_t inputLen, void * outputPtr, uint32_t outputLen);
/* Ended by AICoder, pid:97672ocd33s8ed4149740aea0156332f3fd3654f */

#ifdef __cplusplus
}
#endif

#endif

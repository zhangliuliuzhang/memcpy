/*****************************************************************************
* 版权所有(C) 2017, ZTE Corp. ZXSDR-RRU Platform BSP
*----------------------------------------------------------------------------
* 模 块 名 : BSP
* 文件名称 : bsp_service.c
* 文件标识 : {[N/A]}
* 内容摘要 : BSP统一接口实现
* 注意事项 : 无
* 作    者 : 10248577
* 创建日期 : 2025-07-01 10:55:54
* 当前版本 : Ver1.0
*----------------------------------------------------------------------------
* 变更记录 :
*
* $记录1
* 变 更 单: $0000000(N/A)
* 责 任 人:
* 修改日戳:
* 变更说明: 创建文件

*----------------------------------------------------------------------------
*/
/* Started by AICoder, pid:2309fv224ah61a2147b40a3aa1f2e2961f289eea */
// LCOV_EXCL_START
// LCOV_EXCL_BR_START
#include <stdint.h>
#include <stdlib.h>
#include "bsp_service.h"

#define HASH_SIZE (1024)  // 哈希表大小，建议为质数

/* 哈希表节点结构 */
typedef struct ServiceNode {
    uint32_t cmd;
    BspServiceFuncVarArgs serviceFunc;
    struct ServiceNode* next;
} ServiceNode;

/* 哈希表结构 */
typedef struct {
    ServiceNode* buckets[HASH_SIZE];
} ServiceHashTable;

/* 
    哈希函数 
    cmd取值范围为0x00XX00YY,其中XX为功能类型、YY为接口号
    hash表大小为1024，为保证cmd平均分布在1024范围内，
    根据cmd的取值特征，hash函数选择为：(0xXX%20)*50 + 0xYY%50
*/
static uint32_t hash_function(uint32_t key) 
{   
    uint32_t XX = (key >> 16) & 0xFF;
    uint32_t YY = key & 0xFF;
    return ((XX % 20) * 50 + (YY % 50))% HASH_SIZE;
}

/* 初始化哈希表 */
static int init_hash_table(ServiceHashTable* table) 
{
    for (int i = 0; i < HASH_SIZE; i++) {
        table->buckets[i] = NULL;
    }
    return BSP_SERVICE_OK;
}

/* 插入服务到哈希表 */
static int insert_service(ServiceHashTable* table, uint32_t cmd, BspServiceFuncVarArgs func) 
{
    if (!func) return BSP_SERVICE_ERROR;

    uint32_t index = hash_function(cmd);
    ServiceNode* newNode = (ServiceNode*)malloc(sizeof(ServiceNode));
    if (!newNode) return BSP_SERVICE_ERROR;

    newNode->cmd = cmd;
    newNode->serviceFunc = func;
    newNode->next = table->buckets[index];
    table->buckets[index] = newNode;
    return BSP_SERVICE_OK;
}

/* 删除服务 */
static int remove_service(ServiceHashTable* table, uint32_t cmd) 
{
    uint32_t index = hash_function(cmd);
    ServiceNode* current = table->buckets[index];
    ServiceNode* prev = NULL;

    while (current) {
        if (current->cmd == cmd) {
            if (prev) {
                prev->next = current->next;
            } else {
                table->buckets[index] = current->next;
            }
            free(current);
            return BSP_SERVICE_OK;
        }
        prev = current;
        current = current->next;
    }
    return BSP_SERVICE_ERROR;
}

/* 查找服务 */
static BspServiceFuncVarArgs find_service(ServiceHashTable* table, uint32_t cmd) 
{
    uint32_t index = hash_function(cmd);
    ServiceNode* current = table->buckets[index];

    while (current) {
        if (current->cmd == cmd) {
            return current->serviceFunc;
        }
        current = current->next;
    }
    return NULL;
}

/* 销毁哈希表 */
static void destroy_hash_table(ServiceHashTable* table) 
{
    for (int i = 0; i < HASH_SIZE; i++) {
        ServiceNode* current = table->buckets[i];
        while (current) {
            ServiceNode* temp = current;
            current = current->next;
            free(temp);
        }
    }
}

/* 全局服务表实例 */
static ServiceHashTable g_serviceTable;
static int s_initialized = 0;

/*****************************************************************************
 *  函数名称   : BspRegistService
 *  功能描述   : 注册cmd对应的服务
 *  输入参数   : cmd 服务命令字；serviceFunc 保存服务的函数指针
 *  输出参数   : 无
 *  返 回 值   : 无
 *  其它说明   : 
 *  工装使用申明:
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *  $0000000(N/A), , 创建
 *----------------------------------------------------------------------------
 */
uint32_t BspRegistService(uint32_t cmd, BspServiceFuncVarArgs serviceFunc) 
{
    if (!s_initialized) {
        init_hash_table(&g_serviceTable);
        s_initialized = 1;
    }
    
    if (find_service(&g_serviceTable, cmd)) {
        //printf("cmd %u exist, will be rewrite!\n", cmd);
    }
    
    return insert_service(&g_serviceTable, cmd, serviceFunc);
}

/*****************************************************************************
 *  函数名称   : BspUnregistService
 *  功能描述   : 注销cmd对应的服务
 *  输入参数   : cmd 服务命令字；
 *  输出参数   : 无
 *  返 回 值   : 无
 *  其它说明   : 
 *  工装使用申明:
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *  $0000000(N/A), , 创建
 *----------------------------------------------------------------------------
 */
uint32_t BspUnregistService(uint32_t cmd) 
{
    if (!s_initialized) return BSP_SERVICE_ERROR;
    return remove_service(&g_serviceTable, cmd);
}

/*****************************************************************************
 *  函数名称   : BspGetService
 *  功能描述   : 获取cmd对应的服务
 *  输入参数   : cmd 服务命令字；
 *  输出参数   : 无
 *  返 回 值   :-BspServiceFuncVarArgs类型的指针
 *             -失败：NULL
 *             -成功：保存服务的函数指针
 *  其它说明   : 
 *  工装使用申明:
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *  $0000000(N/A), , 创建
 *----------------------------------------------------------------------------
 */
BspServiceFuncVarArgs BspGetService(uint32_t cmd) 
{
    if (!s_initialized) return NULL;
    return find_service(&g_serviceTable, cmd);
}

/*****************************************************************************
 *  函数名称   : BspCleanupServices
 *  功能描述   : 清理服务
 *  输入参数   : 无
 *  输出参数   : 无
 *  返 回 值   : 无
 *  其它说明   : 
 *  工装使用申明:
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *  $0000000(N/A), , 创建
 *----------------------------------------------------------------------------
 */
void BspCleanupServices() 
{
    if (s_initialized) {
        destroy_hash_table(&g_serviceTable);
        s_initialized = 0;
    }
}
// LCOV_EXCL_BR_STOP
// LCOV_EXCL_STOP
/* Ended by AICoder, pid:2309fv224ah61a2147b40a3aa1f2e2961f289eea */

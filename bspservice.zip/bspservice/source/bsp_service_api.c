/*****************************************************************************
* 版权所有(C) 2017, ZTE Corp. ZXSDR-RRU Platform BSP
*----------------------------------------------------------------------------
* 模 块 名 : BSP
* 文件名称 : bsp_service_api.cpp
* 文件标识 : {[N/A]}
* 内容摘要 : BSP统一接口实现
* 注意事项 : 无
* 作    者 : 10248577
* 创建日期 : 2024-03-27 10:55:54
* 当前版本 : Ver1.0
*----------------------------------------------------------------------------
* 变更记录 :
*
* $记录1
* 变 更 单: $0000000(N/A)
* 责 任 人:
* 修改日戳:
* 变更说明: 创建文件

*----------------------------------------------------------------------------
*/


#include <stdio.h>
#include <stdlib.h>
#include "bsp_service_api.h"
#include "bsp_service_errcode.h"
#include "bsp_service.h"

// LCOV_EXCL_START
// LCOV_EXCL_BR_START
/*****************************************************************************
 *  函数名称   : BspCallService
 *  功能描述   : 服务获取
 *  输入参数   : cmd 服务命令字；... 可变参列表
 *  输出参数   : 无
 *  返 回 值   : BSP_SERVICE_OK/BSP_SERVICE_ERROR
 *  其它说明   : 
 *  工装使用申明:
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *  $0000000(N/A), , 创建
 *----------------------------------------------------------------------------
 */
uint32_t BspCallService(uint32_t cmd, void * inputPtr, uint32_t inputLen, void * outputPtr, uint32_t outputLen)
{
    uint32_t ret = BSP_SERVICE_ERROR;

    BspServiceFuncVarArgs pfunc = BspGetService(cmd);
    if(NULL != pfunc)
    {
        ret = pfunc(inputPtr, inputLen, outputPtr, outputLen);
    }

    return ret;
}
// LCOV_EXCL_BR_STOP
// LCOV_EXCL_STOP


/***************************************************************************** 
* 版权所有(C) 2014, ZTE Corp. ZXSDR-RRU Platform BSP
*----------------------------------------------------------------------------
* 模 块 名 : bsp
* 文件名称 : bootapp.h
* 文件标识 : {[N/A]}
* 内容摘要 : 
* 注意事项 : 无
* 作    者 : 耿佳佳
* 创建日期 : 2014-05-12
* 当前版本 : Ver2.0
*----------------------------------------------------------------------------
* 变更记录 :
*
* $记录1
* 变 更 单: $0000000(N/A)
* 责 任 人: 耿佳佳
* 修改日戳: 2014-05-12 10:20:16
* 变更说明: 创建文件
*----------------------------------------------------------------------------
*/

#ifndef _BOOTAPP_H_
#define _BOOTAPP_H_

#ifdef __cplusplus
extern "C" {
#endif

#include <bsppub.h>

#include <netpacket/packet.h>
#include <netinet/if_ether.h>
#include <net/if.h> 
#include <netinet/in.h>

#include <vxadp.h>

#if defined(CONFIG_DRA62X)	
#include "dra62xboot.h"
#elif defined(CONFIG_ZX211410_EXT)
#include "zx211410boot.h"
#elif defined(CONFIG_LS10X3A)
#include "ls10x3aboot.h"
#elif defined(CONFIG_ZYNQMPSOC)
#include "zynqmpsocboot.h"
#elif defined(CONFIG_AM572X)
#include "am572xboot.h"
#elif defined(CONFIG_ZX2112XX)
#include "zx211411a1boot.h"
#elif defined(CONFIG_ZXW11200)
#include "zxw11200boot.h"
#elif defined(CONFIG_ZX211412)
#include "zx211412boot.h"
#elif defined(CONFIG_ZX211413)
#include "zx211413boot.h"
#endif

typedef struct
{
    unsigned char  ucCpuType;
    unsigned char  ucReserved;
    unsigned short usReserved;
    char *pcCpuDesc;  
}T_CPUTypeDesc;

#if 0
char *gachVerTypeDesc[] = 
{
    "CPU",
    "FPGA",
    "DSP",
    "BOOT",
    "EPLD",
    "MICROCODE",
    "UNKNOWN"
};

T_CPUTypeDesc gatCpuTypeDesc[] = 
{
    {32,0,0,"MPC8360E"},
    {33,0,0,"MPC8313"},
    {34,0,0,"MPC8541"},
    {35,0,0,"MPC8548"},
    {36,0,0,"MPC8347"},
    {37,0,0,"MPC852"},
	{57,0,0,"LS1043A"},
    { 0,0,0,"UNKOWN"}
};
#endif

/**************************************************************************
                            软件版本信息相关定义
***************************************************************************/
#define SW_MAX_NUMBER                       10    /* 限制下载软件中文件的个数 */


#define PACK_STORE_IN_FILE  0
#define PACK_STORE_IN_MEM   1
#define PACK_DESC_IS_USED   1
#define PACK_DESC_NOT_USED  0
#define MAX_PACK_DESC                       10    /* 最多同时打开的包数 */
#define INVALID_PACK_DESC                   0xFFFFFFFF
#define BSP_CFG_FLASH_BASE  0x0

#define  VERION_CPU                     (0)
#define  VERION_LINUX                    (0xa)
#define PROTECT_ZONE_SIZE_INIT				(ULONG)(12 * 1024 * 1024UL) /*保护区大小*/
#define PROTECT_ZONE_ADDRESS_INIT			(0xa00000) 		/*保护区起始地址*/
#define PROTECT_FLASH_ERASE_SECTOR_SIZE ((ULONG)(128*1024))   /*Flash 擦除块大小*/
#define BSP_ID_MAX                                  (0x10000) 
#define BSP_DEVICE_ID_BASE                   		(0x00000000)
#define BSP_DEVICE_ID_CPU0                   		(BSP_DEVICE_ID_BASE + 0x0000)
#define BSP_DEVICE_ID_BOARD0                 		(BSP_DEVICE_ID_BASE + 0x0002)
#define BLANK         "\033[m"
#define RED           "\033[0;32;31m"
#define LIGHT_RED     "\033[1;31m"
#define GREEN         "\033[0;32;32m"
#define LIGHT_GREEN   "\033[1;32m"
#define BLUE          "\033[0;32;34m"
#define LIGHT_BLUE    "\033[1;34m"
#define DARY_GRAY     "\033[1;30m"
#define CYAN          "\033[0;36m"
#define LIGHT_CYAN    "\033[1;36m"
#define PURPLE        "\033[0;35m"
#define LIGHT_PURPLE  "\033[1;35m"
#define BROWN         "\033[0;33m"
#define YELLOW        "\033[1;33m"
#define LIGHT_GRAY    "\033[0;37m"
#define WHITE         "\033[1;37m"

/************************************flash 定义*******************************/

#define FLASH_SIZE_128M             (128*1024*1024)
#define FLASH_SIZE_64M              (64*1024*1024)
#ifdef CONFIG_SECURITY
#define FLASH_SECTOR_SIZE           (64*1024) /*SPI Flash 的擦除块大小不同--与硬件强相关*/
#define FLASH_PARTITION_NUM         (4)    /*boot、保护区、SEC、文件系统*/
#define BOOT     0
#define RESVERD  1
#define SEC      2
#else
#define FLASH_SECTOR_SIZE           (256*1024) /*SPI Flash 的擦除块大小不同--与硬件强相关*/
#define FLASH_PARTITION_NUM         (3)    /*boot、保护区、文件系统*/
#define BOOT     0
#define RESVERD  1
#endif
/*********************************保护区定义 *******************************/
#define BOOT_MTD0_SIZE           0x800000
/*****************************************************************************/
/*********************************内存定义 *******************************/
#define DRAM_4M                  (0x0400000)

#define DRAM_32M                 (0x02000000)
#define DRAM_64M                 (0x04000000)
#define DRAM_128M                (0x08000000)
#define DRAM_256M                (0x10000000)
/**********************************上电计时*************************************/
/*add by 10242265 2019-1-17*/
#define MAXNAMELEN 12
#define KEBOOT_MAGICNAME "KEBOOTMAGIC" 
#define MAX_ENDNAME      "MAX_FINI"
#define RECORD_TIME_NODE_SIZE      (0x400)//1K 
#define RECORD_TIME_NODE_ADDR      (BSP_MEM_ADDR + 0x8000)//0x8000 = 32K
/*node_name 注意和 NameBuffer同步*/
enum node_id
{
	FILESYSTEM_START,
	FILESYSTEM_END,
	VER_START,  /*开始加载版本*/
	CUR_END,    /*cur.swv加载结束*/
    DOWNLOAD_END,/*download流程结束*/
	PROCT_END,  /*加载保护区结束*/
	TMP_END,    /*加载tmp.swv结束*/
	KEXEC_END,  /*执行kexec命令结束*/
	END,
};
struct TimeNode
{
	char cName[MAXNAMELEN];
	unsigned int dwRecTime;  /*1=10ms*/
};

/*is ubifs readonly filesystem? 
0:  rw
1:  ro
2:  filesystem mount error
-1:  error*/
#define FS_FILESYSTEM_NOTMOUNT  2
#define FS_FILESYSTEM_READONLY  1
#define FS_FILESYSTEM_RW        0

/*****************************************************************************/
void TimeNode(enum node_id name);
VOID BootSysMsDelay(ULONG ulDelay);
int check_protect_version();
VOID fs_recover(unsigned int dwIndex);
STATUS checkProtectVersion();
int checkFilesystemVersion(const char *pchBootFile);
int ldLinuxBakVer(const char *pchBootFile);
T_VerProtectHead* BootGetProtectHeadFromFlash(ULONG ulProZoneAddrOffset);
ULONG BootGetVerProtectLen(VOID);
ULONG BootGetFlashVerProtectAddr(VOID);

#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif

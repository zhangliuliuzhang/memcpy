/***************************************************************************** 
* 版权所有(C) 2014, ZTE Corp. ZXSDR-RRU Platform BSP
*----------------------------------------------------------------------------
* 模 块 名 : bsp
* 文件名称 : bootadp.h
* 文件标识 : {[N/A]}
* 内容摘要 : 
* 注意事项 : 无
* 作    者 : 耿佳佳
* 创建日期 : 2014-05-12
* 当前版本 : Ver2.0
*----------------------------------------------------------------------------
* 变更记录 :
*
* $记录1
* 变 更 单: $0000000(N/A)
* 责 任 人: 耿佳佳
* 修改日戳: 2014-05-12 10:20:16
* 变更说明: 创建文件
*----------------------------------------------------------------------------
*/

#ifndef _BOOTADP_H_
#define _BOOTADP_H_

#ifdef __cplusplus
extern "C" {
#endif

#include <bsppub.h>

#define CPU_VER_ERR_ADRS  (CHAR *)(BspGetReservedMemAddr(BSP_HIGH_RESERVED_MEM_BSP) + 0x51B0)       /* CPU版本加载错误码，16字节,UCHG00156197,zhangaiq,20090421 */
#define FPGA_VER_ERR_ADRS (CHAR *)(BspGetReservedMemAddr(BSP_HIGH_RESERVED_MEM_BSP) + 0x51C0)       /* FPGA版本加载错误码，16字节,UCHG00156197,zhangaiq,20090421 */
/* Started by AICoder, pid:ebd2585c0bl3f98142f809728082621e75a2e8ad */
#define BOOTK_VER_ADRS    (CHAR *)(BspGetReservedMemAddr(BSP_HIGH_RESERVED_MEM_BSP) + 0x5000) /* BOOT版本号地址，44字节 */
/* Ended by AICoder, pid:ebd2585c0bl3f98142f809728082621e75a2e8ad */
#define CPU_VER_ADRS      (CHAR *)(BspGetReservedMemAddr(BSP_HIGH_RESERVED_MEM_BSP) + 0x5030)       /* CPU版本号，44字节 */
#define FPGA_VER_ADRS     (CHAR *)(BspGetReservedMemAddr(BSP_HIGH_RESERVED_MEM_BSP) + 0x5060)       /* FPGA版本号，44字节 */
#define DSP_VER_ADRS      (UCHAR *)(BspGetReservedMemAddr(BSP_HIGH_RESERVED_MEM_BSP) + 0x5090)       /* DSP版本号，44字节 */
#define DPLL_VER_ADRS     (UCHAR *)(BspGetReservedMemAddr(BSP_HIGH_RESERVED_MEM_BSP) + 0x5250)       /*dpll file header ver, 44byte*/
#define M0_VER_ADRS       (CHAR *)(BspGetReservedMemAddr(BSP_HIGH_RESERVED_MEM_BSP) + 0x5280)       /* BOOT版本号，44字节 */
#define SPL_VER_ADRS      (CHAR *)(BspGetReservedMemAddr(BSP_HIGH_RESERVED_MEM_BSP) + 0x5290)       /* BOOT版本号，44字节 */
#define UBOOT_VER_ADRS    (CHAR *)(BspGetReservedMemAddr(BSP_HIGH_RESERVED_MEM_BSP) + 0x52a0)       /* BOOT版本号，44字节 */

#define CPU_CA_VER_ERR_ADRS (CHAR *)(BspGetReservedMemAddr(BSP_HIGH_RESERVED_MEM_BSP) + 0x57B0)       /* CA扩展带安全头文件版本加载错误码，16字节*/
#define CA_CAFILE_VERIFY_ERROR  0x1
#define CA_LD_PARSE_CUR27_ERROR  0x2
#define CA_IMAGE_HASH_ERROR    0x3
#define CA_SIGNATURE_ERROR   0x4

#define  MASTER_BOOT_OK  0x11
#define  MASTER_KUBOOT_OK  0x22
#define  SLAVE_BOOT_OK  0x33
#define  SLAVE_KUBOOT_OK  0x44


#define  MASTER_UBOOT_SPL_OK  0x11  /*主uboot spl加载成功标志*/
#define  MASTER_UBOOT_OK  	  0x22  /*主uboot加载成功标志*/
#define  SLAVE_UBOOT_SPL_OK   0x33  /*从uboot spl加载成功标志*/
#define  SLAVE_UBOOT_OK       0x44  /*从uboot 加载成功标志*/

#define BLOCK_NAME_LEN                  (64)
#define BSP_KEXECBOOT_RESET             (0x38)   /*KEXECBOOT复位*/
#define BSP_FILESYSTEM_RESET           (0x3a)   /*文件系统异常复位*/

typedef struct tagT_RruProZoneInit
{
    ULONG aulParam[5];      /*初始化入参*/
    UCHAR *pucData;          /*数据缓冲区*/
    ULONG  ulLenth;           /*缓存区数据长度*/	
    VOID   (*pIntCallBackHandler1) (UCHAR *pucParam); /*回调函数1*/
    VOID   (*pIntCallBackHandler2) (UCHAR *pucParam); /*回调函数2*/			
}T_RruProZoneInit;
#if 0
typedef struct tagPartitionMap
{
	char  acPartitionName[BLOCK_NAME_LEN];     /* 分区名 */
	ULONG ulPartitionOffset;                   /* 起始偏移地址 */
	ULONG ulPartitionSize;                     /* 分区大小 */
    ULONG ulPartitionType;                     /* 每个分区的类型(char 或者block)*/
}T_PartitionMap;

typedef struct T_FlashInfo
{
    ULONG       ulFlashSize;      /* flash芯片大小 */
    ULONG       ulSectorSize;     /* sector size */
	ULONG       ulPartitionNum;   /* FLASH包含的分区数量 */
	T_PartitionMap atPartitionMap[MAX_BLOCK_NUM];    /* 每个分区对应地址映射表 */
}T_FlashInfo;
#endif
typedef INT (*BSP_SYSTEM_CALLBACK)(const CHAR *);
UINT32 BspClrCaErrReason(VOID);
UINT32 BspSetCaErrReason(UCHAR ucRunVer, UCHAR ucErrReason);
UINT32 BspClrCpuVerErrReason(VOID);
#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif

/******************************************************************************
* 版权所有 (C)2007, 深圳市中兴通讯股份有限公司。
*
* 文件名称： BootApp.c
* 文件标识：
* 内容摘要： 软基站平台BootApp.c。用于BOOT模块入口。
* 其它说明： 无
* 当前版本： V1.0
* 作    者： 耿佳佳
* 完成日期： 2015-9-22
*
* 修改记录1：
*    修改日期：
*    版 本 号：
*    修 改 人：
*    变 更 号：
*    关 键 字：
*    修改内容：
*
******************************************************************************/
/* =====================#include（依次为标准库头文件、非标准库头文件）====== */
#include <vxadp.h>
#include <bootapp.h>
#include <bsppub.h>
#include <bootadp.h>
#include <bspcomm.h>
#include <loadversion.h>
#ifdef CONFIG_ZXW11200_NTN
#include <repairversion.h>
#endif

/* system函数指针，默认为C库提供的system函数 */
static BSP_SYSTEM_CALLBACK s_pfSystem = (BSP_SYSTEM_CALLBACK)system;
extern ULONG g_ulRamReservedAddr;
/* =====================常量定义==================================*/

/*****************************************************************************
* 函数名称   : SysMemTop
* 功能描述   : 适配函数
* 读全局变量 : 无
* 写全局变量 : 无
* 输入参数   : 无
* 输出参数   : 无
* 返 回 值   : 成功或者失败
* 其它说明   :
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 崔文会@2011-01-19 08:33:43, 拷贝并平台规范化
*----------------------------------------------------------------------------
*/
CHAR * SysMemTop(void)
{
    return NULL;
}

/*****************************************************************************
* 函数名称   : BspGetReservedMemAddr(*)
* 功能描述   : 返回某个模块需要的内存保留区地址
* 读全局变量 : 无
* 写全局变量 : 无
* 输入参数   : ucModuleId - 0:BSP 1:OSS 6:User-define
* 输出参数   :
* 返 回 值   : 某个模块许可使用的保留区内存地址，如果模块号不存在，则返回
*               sysPhysMemTop();
* 其它说明   :
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), chenjinsong@2010-9-15 11:15:46
*----------------------------------------------------------------------------
*/
unsigned long BspGetReservedMemAddr(UCHAR ucModuleId)
{
    unsigned long ulAddr;
    switch (ucModuleId)
    {
        case BSP_HIGH_RESERVED_MEM_BSP: /* BSP */
        {
            ulAddr = g_ulRamReservedAddr + SYS_MEM_TOP + BSP_VER_PROTECT_SIZE + APP_RESERVED_SIZE + OSS_MEM_SIZE;
            break;
        }

        case BSP_HIGH_RESERVED_MEM_MGR: /* OSS */
        {
            ulAddr = g_ulRamReservedAddr + SYS_MEM_TOP + BSP_VER_PROTECT_SIZE + APP_RESERVED_SIZE;
            break;
        }

        case BSP_HIGH_RESERVED_MEM_APP1: /* 产品高层，使用保留区 */
        {
            ulAddr = g_ulRamReservedAddr + SYS_MEM_TOP + BSP_VER_PROTECT_SIZE;
            break;
        }

        case BSP_HIGH_RESERVED_MEM_L3: /* 产品高层 */
        {
            ulAddr = g_ulRamReservedAddr + SYS_MEM_TOP + BSP_VER_PROTECT_SIZE
                    + APP_RESERVED_SIZE - BSP_HIGH_RESERVED_MEM_APP3;
            break;
        }

        case BSP_HIGH_RESERVED_MEM_APP3: /* 产品高层*/
        {
            ulAddr = g_ulRamReservedAddr + SYS_MEM_TOP + BSP_VER_PROTECT_SIZE
                    + APP1_RESERVED_SIZE + APP2_RESERVED_SIZE;
            break;
        }

        case BSP_HIGH_RESERVED_MEM_APP2: /* 产品高层*/
        {
            ulAddr = g_ulRamReservedAddr + SYS_MEM_TOP + BSP_VER_PROTECT_SIZE + APP1_RESERVED_SIZE;
            break;
        }

        case BSP_HIGH_RESERVED_MEM_USER_DEFINE: /* 版本保护区 */
        {
            ulAddr = g_ulRamReservedAddr + SYS_MEM_TOP;
            break;
        }

        default:
        {
            dbgErr("Error input %d\n", ucModuleId);
            ulAddr = (ULONG)SysMemTop();
        }
    }

    return ulAddr;
}
/**********************************************************************
* 函数名称：BspSystem
* 功能描述：通过system函数执行命令
* 输入参数：命令行
* 输出参数：无
* 返 回 值：BSP_OK - 成功
*           其它   - 失败
* 其它说明：无
* 修改日期       版本号             修改人    修改内容
* -----------------------------------------------
* 2012/04/11     ZXSDRV1020001B02   叶青林    创建
***********************************************************************/
INT BspSystem(const CHAR *pcCommand)
{
    return s_pfSystem(pcCommand);
}
#if 0
/*===========================================================
函数名      :  CheckCrc16
功能        :  CRC16检查
输入参数说明:
               *ucBuffer     -- 待检查的buffer
               ulBufferLength-- buffer长度
               ulTarCrcValue -- 预期CRC
返回值说明  :  0 -- CRC正确
               1 -- CRC长度不正确
               2 -- CRC错误
引用全局变量:
附加说明    :
修改说明    :
  修改日期          版本号      修改人      修改内容
  -----------------------------------------------
  2008年1月25日      1.0       wood        创建
===========================================================*/
unsigned long CheckCrc16(unsigned char *ucBuffer,
                         unsigned long  ulBufferLength,
                         unsigned short ulTarCrcValue)
{
    unsigned short ulCrcValue;
    if (ulBufferLength == 0)
    {
        return 1;
    }

    /* 最终决策修改初始值为 全1 */
    ulCrcValue = BspCountCrc16(0xFFFF,ucBuffer,ulBufferLength);

    if (ulCrcValue != ulTarCrcValue)
    {
        zte_printf_s("target crc %#8x != calced crc %#8x\n",ulTarCrcValue,ulCrcValue);
        return 2;
    }

    return 0;
}
#endif
/**********************************************************************
* 函数名称：BspClrCaErrReason
* 功能描述：清除CA带扩展安全头版本加载失败原因
* 输入参数：ulErrReason：版本加载失败原因
* 输出参数：无
* 返 回 值：BSP_OK
* 其它说明：无
* 修改日期      版本号  修改人      修改内容
* ---------------------------------------------------------------------
* 2010-11-25    V1.0    张雷         创建
************************************************************************/
UINT32 BspClrCaErrReason(VOID)
{
    zte_memset_s((CHAR *)CPU_CA_VER_ERR_ADRS, sizeof(T_CtrlVerErrReason), 0, sizeof(T_CtrlVerErrReason));
    return BSP_OK;
}

/*****************************************************************************
* 函数名称   : BspSetCaErrReason(*)
* 功能描述   :
* 读全局变量 :
* 写全局变量 :
* 输入参数   : ptCpuErrReason：cpu版本加载错误结构体
* 输出参数   :
* 返 回 值   : BSP_OK: 烧录成功；
* 其它说明   : 设置cpu当前运行版本及加载错误码对外接口(BOOT提供标志位的地址)
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*----------------------------------------------------------------------------
*/
UINT32 BspSetCaErrReason(UCHAR ucRunVer, UCHAR ucErrReason)
{
    /*需BOOT提供地址*/
    T_CtrlVerErrReason tCpuErrReason;

    zte_memcpy_s(&tCpuErrReason, sizeof(T_CtrlVerErrReason), (CHAR *)CPU_CA_VER_ERR_ADRS, sizeof(T_CtrlVerErrReason));
    /*设置特征值，以区分新旧BOOT*/
    tCpuErrReason.ulMarkVal = BSP_CPU_LOAD_REASON_MARKVAL;
    tCpuErrReason.ucRunVer = ucRunVer;

    if (BSP_RUN_VERSION == ucRunVer) /*高区版本*/
    {
        tCpuErrReason.ucMasterVerErr = ucErrReason;
    }
    if (BSP_BAK_VERSION == ucRunVer) /*低区版本*/
    {
        tCpuErrReason.ucSlaveVerErr = ucErrReason;
    }

    zte_memcpy_s((CHAR *)CPU_CA_VER_ERR_ADRS, sizeof(T_CtrlVerErrReason), &tCpuErrReason, sizeof(T_CtrlVerErrReason));

    return BSP_OK;
}

UINT32 BspGetCpuVerErrReason(T_CtrlVerErrReason *ptCpuErrReason)
{
    zte_memcpy_s(ptCpuErrReason, sizeof(T_CtrlVerErrReason), (CHAR *)CPU_VER_ERR_ADRS, sizeof(T_CtrlVerErrReason));

    return BSP_OK;
}
/*****************************************************************************
* 函数名称   : BspSetCpuVerErrReason(*)
* 功能描述   :
* 读全局变量 :
* 写全局变量 :
* 输入参数   : ptCpuErrReason：cpu版本加载错误结构体
* 输出参数   :
* 返 回 值   : BSP_OK: 烧录成功；
* 其它说明   : 设置cpu当前运行版本及加载错误码对外接口(BOOT提供标志位的地址)
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A),  张  雷@2010-11-15 17:15:58, 创建
*----------------------------------------------------------------------------
*/
UINT32 BspSetCpuVerErrReason(UCHAR ucRunVer, UCHAR ucErrReason)
{
    /*需BOOT提供地址*/
    T_CtrlVerErrReason tCpuErrReason;

    zte_memcpy_s(&tCpuErrReason, sizeof(T_CtrlVerErrReason), (CHAR *)CPU_VER_ERR_ADRS, sizeof(T_CtrlVerErrReason));
    /*设置特征值，以区分新旧BOOT*/
    tCpuErrReason.ulMarkVal = BSP_CPU_LOAD_REASON_MARKVAL;

    tCpuErrReason.ucRunVer = ucRunVer;
    switch(ucRunVer)
    {
        case BSP_RUN_VERSION:
            tCpuErrReason.ucMasterVerErr = ucErrReason;
            break;
        case BSP_BAK_VERSION:
            tCpuErrReason.ucSlaveVerErr = ucErrReason;
            break;
        case BSP_BIN_DEF_VERSION:
            tCpuErrReason.ucBinDefaultVerErr = ucErrReason;
            break;
        case BSP_BAK_DEF_VERSION:
            tCpuErrReason.ucBakDefaultVerErr = ucErrReason;
            break;
        case BSP_ACK_VERSION:
            tCpuErrReason.ucAckVerErr = ucErrReason;
            break;
        case BSP_PROVERSION:
            tCpuErrReason.ucProtectVerErr = ucErrReason;
            break;
        #ifdef CONFIG_ZXW11200_NTN
        case BSP_BAK_FSVERSION:
            tCpuErrReason.ucReserve[0] = ucErrReason;
            break;
        case BSP_BAK_REPAIR_VERSION:
            tCpuErrReason.ucReserve[1] = ucErrReason;
            break;
        #endif
        default:
            printf("Unknown RunVer\n");
            break;
    }

    zte_memcpy_s((CHAR *)CPU_VER_ERR_ADRS, sizeof(T_CtrlVerErrReason), &tCpuErrReason, sizeof(T_CtrlVerErrReason));

    return BSP_OK;
}

/*****************************************************************************
* 函数名称   : BspSetCpuSoftVersion(*)
* 功能描述   :
* 读全局变量 : 无
* 写全局变量 : 无
* 输入参数   : pcCpuSoftVer  - 存储版本信息指针
*             : ucSizeofBytes - 版本信息长度
* 输出参数   :
* 返 回 值   : BSP_OK->无错,否则返回对应的错误码
* 其它说明   : RRU通用适配接口函数
*---------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 宋志强@2011-04-21 15:22:00  创建
*----------------------------------------------------------------------------
*/
UINT32 BspSetCpuSoftVersion(CHAR *pcCpuSoftVer, UCHAR ucSizeofBytes)
{
    if (pcCpuSoftVer == NULL)
    {
        return BSP_ERROR_NULL_POINTER;
    }
    zte_memset_s((CHAR*)CPU_VER_ADRS, VERNO_LEN, 0, VERNO_LEN); /* 先清空 */
    zte_memcpy_s((CHAR *)CPU_VER_ADRS, VERNO_LEN, pcCpuSoftVer, ucSizeofBytes);

    return BSP_OK;
}
/**********************************************************************
* 函数名称：BspClrCpuVerErrReason
* 功能描述：清除CPU版本加载失败原因
* 输入参数：ulErrReason：版本加载失败原因
* 输出参数：无
* 返 回 值：BSP_OK
* 其它说明：无
* 修改日期      版本号  修改人      修改内容
* ---------------------------------------------------------------------
* 2010-11-25    V1.0    张雷         创建
************************************************************************/
UINT32 BspClrCpuVerErrReason(VOID)
{
    zte_memset_s((CHAR *)CPU_VER_ERR_ADRS, sizeof(T_CtrlVerErrReason), 0, sizeof(T_CtrlVerErrReason));
    return BSP_OK;
}

UINT64 BspGetProcBasePhyAddr(void)
{
    return 0;
}

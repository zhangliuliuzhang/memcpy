/************************************************************************
* 版权所有 (C)2016, 深圳市中兴通讯股份有限公司。
*
* 文件名称： bootdpll.c
* 文件标识： UTCA
* 内容摘要： boot:  解析时钟芯片配置表并配置下去
* 其它说明：
* 当前版本：
* 作    者：niuyanru
* 完成日期： 2016-12-20
*----------------------------------------------------------------------------
* 变更记录 :
*
* $记录1
* 变 更 单:
* 责 任 人:
* 修改日戳:
* 变更说明:
*----------------------------------------------------------------------------
*******************************************************************   */
#if (defined(CONFIG_ZX2112XX))||(defined(CONFIG_LS10X3A))
#include<sys/socket.h>
#include<sys/ioctl.h>
#include<unistd.h>
#include<sys/types.h>
#include<sys/stat.h>
#include<fcntl.h>
#include<errno.h>
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<netinet/in.h>
#include<netdb.h>
#include<linux/errno.h>
#include<time.h>
#include<sys/time.h>
#include <linux/if.h>
#include <bsppub.h>
#include <bootadp.h>
#if defined(CONFIG_ZX2112XX)
#include "zteic3spi.h"
#endif

#define MAX_LINE_SIZE 4096
#define BOOT_DPLL_CFG_FILE "/dpllcfg"
#define BOOT_DPLL_CFG_M_FILE "/ata/dpllcfg.bin"

#if defined(CONFIG_LS10X3A)
#define BOOT_DPLL_CFG_S_ADD    (0x1100000)  /*protect file addr*/
#endif
#if defined(CONFIG_ZX2112XX)
#define BOOT_DPLL_CFG_S_ADD    (0x1180000)
#endif

#define BOOT_DPLL_CFG_S_MLEN  0x40000  /*max length*/
#define BOOT_DPLL_CFG_HEAD_LEN  0x80

#if defined(CONFIG_LS10X3A)
#define KXSPI_DPLL_DEV   "/dev/KernSpiDpll"
int g_spidpllFd = -1;

#define CPSW_DPLL_MAJOR           (10)
#define CPSW_DPLL_MINOR           (240)

#define SPI_DPLL_CFG_MODE         0x11
#define SPI_DPLL_SHOW_INFO        0x22
#define SPI_DPLL_SET_ADDR         0x33
#define DPLL_MAX_ADD_LEN          0x8

typedef struct T_dplladdr
{
    unsigned int addrlen;
    char add_u8[DPLL_MAX_ADD_LEN];
};

struct T_dplladdr g_spiaddcfg;
#endif

#if defined(CONFIG_ZX2112XX)
#define SPI_BUS_ID_HW_DEVCTRL 133
/*SPI DIRVER*/
static SEM_ID g_tHwSpiBusSemId;
static T_ZTE_HW_SPI_PARA s_atHwSpiPriv[] =
{
    [ZTE_SPI_BUS_0] =
    {
        .ulBusId = ZTE_SPI_BUS_0,
        .ulMax_hz = 50000000,    /* 该速率待确认 */
        .ulMode = SPI_MODE_0,
        .ulCs = 0,
    },
    [ZTE_SPI_BUS_1] =
    {
        .ulBusId = ZTE_SPI_BUS_1,
        .ulMax_hz = 50000000,    /* 该速率待确认 */
        .ulMode = SPI_MODE_0,
        .ulCs = 0,
    },
    [ZTE_SPI_BUS_2] =
    {
        .ulBusId = ZTE_SPI_BUS_2,
        .ulMax_hz = 1562500,    /* 该速率待确认 */
        .ulMode = SPI_MODE_0,
        .ulCs = 0,
    },
};
static T_SPI_DRV s_atHwSpiBusDrv =
{
    .ulSpiDrvId   = SPI_BUS_ID_HW_DEVCTRL,
    .ulDrvType    = SPI_DRV_TYPE_ZTE_HW,
    .pPrivateData = &(s_atHwSpiPriv[ZTE_SPI_BUS_2]),
    .ptPrev       = NULL,
    .ptNext       = NULL,
};
extern void BootSetDpllCs(unsigned char ucEn);
extern void BootSetDpllRst(void);
#endif

static void printhex(void *hex, int len, char *tag)
{
    int i;
    unsigned char *p = (unsigned char *)hex;

    if(len < 1)
    {
    return;
    }
    if(len > MAX_LINE_SIZE)
    {
        return;
    }


    for(i = 0; i < len; i++)
    {
        if(*p < 0x10)
        {
            zte_printf_s("0%x%s", *p++, tag);
        }
        else
        {
            zte_printf_s("%2x%s", *p++, tag);
        }
    }

    if(*p < 0x10)
    {
        zte_printf_s("0%x\n", *p++);
    }
    else
    {
        zte_printf_s("%2x\n", *p++);
    }
}

#if defined(CONFIG_ZX2112XX)
/******************************************************************************
* 函数名称   : BspSpiDpllInit(*)
* 功能描述   : 初始化 spi dpll 处理模块
* 读全局变量 : 无
* 写全局变量 : 无
* 输入参数   : 无
* 输出参数   : 无
* 返 回 值   : BSP_OK :成功
               其他   :错误码
* 其它说明   : 对外接口
* ----------------------------------------------------------------------------*
* 历史记录(变更单, 责任人 @修改日期,      操作说明)
* $0000000(N/A),   牛彦茹                 创建
******************************************************************************/
int BspSpiDpllInit(void)
{
    int ulTmpRet = 0;
    T_SPI_DRV *ptSpiBusDrv = &s_atHwSpiBusDrv;

    g_tHwSpiBusSemId = semBCreate(SEM_Q_FIFO, SEM_FULL);
    if (NULL == g_tHwSpiBusSemId)
    {
        zte_printf_s("%s: line%d. Error!HwSpiBus'%d Sem Create Fail\n",
        __FUNCTION__, __LINE__, ZTE_SPI_BUS_2);
        return -1;
    }

    ulTmpRet = _BspZteHwSpiInit(ptSpiBusDrv);
    if (0 != ulTmpRet)
    {
        zte_printf_s("%s: line%d. DevIndex'%d SpiBusDrv init Error!ErrRet= 0x%x\n",
        __FUNCTION__, __LINE__, ZTE_SPI_BUS_2, ulTmpRet);
    }

    return ulTmpRet;
}
#else
/******************************************************************************
* 函数名称   : BspSpiDpllInit(*)
* 功能描述   : 初始化 spi dpll 处理模块
* 读全局变量 : 无
* 写全局变量 : 无
* 输入参数   : 无
* 输出参数   : 无
* 返 回 值   : BSP_OK :成功
               其他   :错误码
* 其它说明   : 对外接口
* ----------------------------------------------------------------------------*
* 历史记录(变更单, 责任人 @修改日期,      操作说明)
* $0000000(N/A),   牛彦茹                 创建
******************************************************************************/
int BspSpiDpllInit(void)
{
    if (access(KXSPI_DPLL_DEV,F_OK))
    {
        /* if we're creating a named pipe, the final parameter is ignored */
        if (mknod(KXSPI_DPLL_DEV, 0x2666, makedev(CPSW_DPLL_MAJOR, CPSW_DPLL_MINOR)))
        {
            zte_printf_s("mknod failed: %s\n", (char *)strerror(errno));
            return -1;
        }
    }

    if (g_spidpllFd < 0)
    {
        g_spidpllFd = open(KXSPI_DPLL_DEV,O_RDWR | O_SYNC);
        zte_printf_s("open %s dev \n ",KXSPI_DPLL_DEV);
    }

    if(g_spidpllFd < 0)
    {
        zte_printf_s("Open %s error \n",KXSPI_DPLL_DEV);
        return -1;
    }

    return 0;

}
#endif
static unsigned char picknum(char *inBuf, unsigned int Lindex)
{
    unsigned char data;

    if(Lindex>=MAX_LINE_SIZE)
    {
        zte_printf_s("[%s]data out of range! Lindex:%x\n",__FUNCTION__,Lindex);
        return -1;
    }

    data=0;
    if(inBuf[Lindex]>='0'&&inBuf[Lindex]<='9')
    {
        data+=((inBuf[Lindex]-'0')<<4);
    }
    else if(inBuf[Lindex]>='A'&&inBuf[Lindex]<='F')
    {
        data+=((inBuf[Lindex]-'A'+10)<<4);
    }
    else if(inBuf[Lindex]>='a'&&inBuf[Lindex]<='f')
    {
        data+=((inBuf[Lindex]-'a'+10)<<4);
    }
    else
    {
        zte_printf_s("[%s]data out of range %c! Lindex:%x\n",__FUNCTION__,inBuf[Lindex],Lindex);
        return -1;
    }

    if(inBuf[Lindex+1]>='0'&&inBuf[Lindex+1]<='9')
    {
        data+=(inBuf[Lindex+1]-'0');
    }
    else if(inBuf[Lindex+1]>='A'&&inBuf[Lindex+1]<='F')
    {
        data+=(inBuf[Lindex+1]-'A'+10);
    }
    else if(inBuf[Lindex+1]>='a'&&inBuf[Lindex+1]<='f')
    {
        data+=(inBuf[Lindex+1]-'a'+10);
    }
    else
    {
        zte_printf_s("[%s]data out of range %c! Lindex:%d\n",__FUNCTION__,inBuf[Lindex+1],Lindex+1);
        return -1;
    }
    return data;
}
#if defined(CONFIG_ZX2112XX)
/******************************************************************************
* 函数名称   : GetSpiCfg(*)
* 功能描述   : get spi cfg from dpllcfg.bin
* 读全局变量 : 无
* 写全局变量 : 无
* 输入参数   : 无
* 输出参数   : 无
* 返 回 值   : BSP_OK :成功
               其他   :错误码
* 其它说明   : 对外接口
* ----------------------------------------------------------------------------*
* 历史记录(变更单, 责任人 @修改日期,      操作说明)
* $0000000(N/A),   牛彦茹                 创建
******************************************************************************/
int GetSpiCfg(void)
{
    char tmpReadline[MAX_LINE_SIZE] = {0};
    char acStr1[MAX_LINE_SIZE],acStr2[MAX_LINE_SIZE];
    rsize_t size_array1[2] = {MAX_LINE_SIZE, 0};
    rsize_t size_array2[3] = {MAX_LINE_SIZE, MAX_LINE_SIZE, 0};
    unsigned int readNum=0, iRet = 0;
    FILE * fid=NULL;
    #if defined(CONFIG_ZX2112XX)
    T_SPI_DRV *ptSpiBusDrv = &s_atHwSpiBusDrv;
    T_ZTE_HW_SPI_PARA *ptZteHwSpiPara = &s_atHwSpiPriv;
    #endif

    fid = fopen(BOOT_DPLL_CFG_FILE, "r+b");
    if(NULL == fid)
    {
        zte_printf_s("[ReadDpllFile]: open and creat %s  failed!\n",BOOT_DPLL_CFG_FILE);
        return -1;
    }

    while (NULL != fgets(tmpReadline, 256, fid))
    {
        zte_sscanf_s(tmpReadline ,"%s", size_array1, acStr1);
        //zte_printf_s("read str = %s\n",acStr1);
        if((0 == strncmp("[V]", acStr1, MAX_LINE_SIZE))
            ||(0 == strncmp("[DATE]", acStr1, MAX_LINE_SIZE)))
        {
            zte_sscanf_s(tmpReadline ,"%s %s", size_array2, acStr1, acStr2);
            zte_printf_s("%s %s\n",acStr1,acStr2);
        }

        if(0 == strncmp("[SpiDrvId]", acStr1, MAX_LINE_SIZE))
        {
            zte_sscanf_s(tmpReadline ,"%s %x", size_array1, acStr1, &readNum);
            ptSpiBusDrv->ulSpiDrvId = readNum;
            zte_printf_s("%s is %x\n",acStr1,readNum);
        }
        if(0 == strncmp("[DrvType]", acStr1, MAX_LINE_SIZE))
        {
            zte_sscanf_s(tmpReadline ,"%s %x", size_array1, acStr1, &readNum);
            ptSpiBusDrv->ulDrvType = readNum;
            zte_printf_s("%s is %x\n",acStr1,readNum);
        }
        if(0 == strncmp("[BusId]", acStr1, MAX_LINE_SIZE))
        {
            zte_sscanf_s(tmpReadline ,"%s %x", size_array1, acStr1, &readNum);
            ptZteHwSpiPara->ulBusId= readNum;
            zte_printf_s("%s is %x\n",acStr1,readNum);
        }
        if(0 == strncmp("[Max_hz]", acStr1, MAX_LINE_SIZE))
        {
            zte_sscanf_s(tmpReadline ,"%s %x", size_array1, acStr1, &readNum);
            ptZteHwSpiPara->ulMax_hz = readNum;
            zte_printf_s("%s is %x\n",acStr1,readNum);
        }
        if(0 == strncmp("[Mode]", acStr1, MAX_LINE_SIZE))
        {
            zte_sscanf_s(tmpReadline ,"%s %x", size_array1, acStr1, &readNum);
            ptZteHwSpiPara->ulMode = readNum;
            zte_printf_s("%s is %x\n",acStr1,readNum);
        }
        if(0 == strncmp("[Cs]", acStr1, MAX_LINE_SIZE))
        {
            zte_sscanf_s(tmpReadline ,"%s %x", size_array1, acStr1, &readNum);
            ptZteHwSpiPara->ulCs = readNum;
            zte_printf_s("%s is %x\n",acStr1,readNum);
            break;
        }
    }
    if(NULL != fid)
    {
        /* Started by AICoder, pid:kbf5bab86f6459c1476d08b980269425755749d8 */
        zte_fclose_s(fid);
        /* Started by AICoder, pid:kbf5bab86f6459c1476d08b980269425755749d8 */
    }
    return iRet;
}
#endif
/******************************************************************************
* 函数名称   : ParseFile(*)
* 功能描述   : 解析时钟配置文件
* 读全局变量 : 无
* 写全局变量 : 无
* 输入参数   : 无
* 输出参数   : 无
* 返 回 值   : BSP_OK :成功
               其他   :错误码
* 其它说明   : 对外接口
* ----------------------------------------------------------------------------*
* 历史记录(变更单, 责任人 @修改日期,      操作说明)
* $0000000(N/A),   牛彦茹                 创建
******************************************************************************/
int ParseFile(void)
{
    char tmpReadline[MAX_LINE_SIZE] = {0};
    char acStr1[MAX_LINE_SIZE],acStr2[MAX_LINE_SIZE];
    rsize_t size_array1[2] = {MAX_LINE_SIZE, 0};
    rsize_t size_array2[3] = {MAX_LINE_SIZE, MAX_LINE_SIZE, 0};
    unsigned char dataBuf[MAX_LINE_SIZE] = {0};
    unsigned char recvbuf[MAX_LINE_SIZE] = {0};
    unsigned int maxdevnum = 0, idindex = 0, idlen = 0, cfgline = 0;
    unsigned int nextline = 0, curline = 0, goFlag = 0, lineindex = 0;
    unsigned int i=0, readNum=0, iRet = 0;
    unsigned int rwFlag=0, datacount=0, delay =0, lockFlag =0, ms10Flag = 0;
    FILE * fid=NULL;
    #if defined(CONFIG_ZX2112XX)
    T_SPI_DRV *ptSpiBusDrv = &s_atHwSpiBusDrv;
    #endif

    fid = fopen(BOOT_DPLL_CFG_FILE, "r+b");
    if(NULL == fid)
    {
        zte_printf_s("[ReadDpllFile]: open and creat %s  failed!\n",BOOT_DPLL_CFG_FILE);
        return -1;
    }

    while (NULL != fgets(tmpReadline, 256, fid))
    {
        curline++;

        if((goFlag!=0)&&(curline<nextline))
        {
            continue;
        }
        if(curline == nextline)
        {
            goFlag = 0;
        }
        zte_sscanf_s(tmpReadline ,"%s", size_array1, acStr1);
        //zte_printf_s("read str = %s\n",acStr1);
        if((0 == strncmp("[V]", acStr1, MAX_LINE_SIZE))
            ||(0 == strncmp("[DATE]", acStr1, MAX_LINE_SIZE))
            ||(0 == strncmp("[devIndex]", acStr1, MAX_LINE_SIZE))
            ||(0 == strncmp("[manufacturer]", acStr1, MAX_LINE_SIZE))
            ||(0 == strncmp("[SupportId]", acStr1, MAX_LINE_SIZE))
            ||(0 == strncmp("[DevSpiMode]", acStr1, MAX_LINE_SIZE)))
        {
            zte_sscanf_s(tmpReadline ,"%s %s", size_array2, acStr1, acStr2);
            zte_printf_s("%s %s\n",acStr1,acStr2);
        }
        if(0 == strncmp("[delay]", acStr1, MAX_LINE_SIZE))
        {
            zte_sscanf_s(tmpReadline ,"%s %s", size_array2, acStr1, acStr2);
            ms10Flag = 1;
            zte_printf_s("%s %s\n",acStr1,acStr2);
        }
        if(0 == strncmp("[MaxNum]", acStr1, MAX_LINE_SIZE))
        {
            zte_sscanf_s(tmpReadline ,"%s %x", size_array1, acStr1, &readNum);
            maxdevnum = readNum;
            zte_printf_s("%s is %x\n",acStr1,maxdevnum);
        }
        if(0 == strncmp("[IDindex]", acStr1, MAX_LINE_SIZE))
        {
            zte_sscanf_s(tmpReadline ,"%s %x", size_array1, acStr1, &readNum);
            idindex = readNum;
            zte_printf_s("%s is %x\n",acStr1,idindex);
        }
        if(0 == strncmp("[IDlen]", acStr1, MAX_LINE_SIZE))
        {
            zte_sscanf_s(tmpReadline ,"%s %x", size_array1, acStr1, &readNum);
            idlen = readNum;
            zte_printf_s("%s is %x\n",acStr1,idlen);
        }
        if(0 == strncmp("[CFGline]", acStr1, MAX_LINE_SIZE))
        {
            zte_sscanf_s(tmpReadline ,"%s %x", size_array1, acStr1, &readNum);
            cfgline = readNum;
            zte_printf_s("%s is %d\n",acStr1,cfgline);
        }
        if(0 == strncmp("[LOCK]", acStr1, MAX_LINE_SIZE))
        {
            lockFlag = 1;
            zte_printf_s("%s is probe\n",acStr1);
        }
        if(0 == strncmp("[DEVEND]", acStr1, MAX_LINE_SIZE))
        {
            if(2 == lockFlag)
            {
                zte_printf_s("config done! dev is locked\n");
                iRet = 0;
            }
            else
            {
                zte_printf_s("config done! dev is not locked\n");
                iRet = 1;
            }
            break;
        }
        if((idindex == maxdevnum)&&(goFlag == 0)&&(0 == strncmp("[devIndex]", acStr1, MAX_LINE_SIZE)))
        {
            zte_printf_s("not find support id!\n");
            iRet = -1;
            break;
        }
        /*parse data*/
        if(0 == strncmp("<DATA>", acStr1, MAX_LINE_SIZE))
        {
            while (NULL != fgets(tmpReadline, MAX_LINE_SIZE, fid))
            {
                curline++;
                zte_sscanf_s(tmpReadline ,"%s", size_array1, acStr1);
                //zte_printf_s("%s %d\n", acStr1, curline);
                if(0 == strncmp("<DATAEND>", acStr1, MAX_LINE_SIZE))
                {
                    break;
                }

                rwFlag=0, datacount=0, delay =0;
                zte_sscanf_s(tmpReadline ,"%x %x %x %n", NULL, &rwFlag, &datacount, &delay, &lineindex);
                //zte_printf_s("data is %d %d %d %d \n",rwFlag,datacount,delay,lineindex);
                if(delay>0)
                {
                    if(0!=ms10Flag) taskDelay(delay);
                    else sleep(delay);
                }
                if(0 == rwFlag)/*spi write*/
                {
                    for(i=0;i<datacount;i++)
                    {
                        dataBuf[i] = picknum(tmpReadline,lineindex);
                        lineindex += 3;
                    }
                    #ifdef DPLL_DEBUG /*debug*/
                    zte_printf_s("SPI WRITE DATA:%d--",datacount);
                    printhex(dataBuf,datacount," ");
                    #endif

                    #if defined(CONFIG_LS10X3A)
                    iRet = write(g_spidpllFd, dataBuf, datacount);
                    #else
                    usleep(300);
                    BootSetDpllCs(1);
                    if(ptSpiBusDrv->pSpiSend)
                    {
                        iRet = ptSpiBusDrv->pSpiSend(ptSpiBusDrv, dataBuf, datacount);
                    }
                    BootSetDpllCs(0);
                    #endif
                    #ifdef DPLL_DEBUG
                    zte_printf_s("spi dpll write byte = %d  ret = 0x%x\n",datacount, iRet);
                    #endif
                }
                else if(1 == rwFlag)/*spi read*/
                {
                    for(i=0;i<datacount*2;i++)
                    {
                        dataBuf[i] = picknum(tmpReadline,lineindex);
                        lineindex += 3;
                    }
                    #ifdef DPLL_DEBUG /*debug*/
                    zte_printf_s("SPI READ DATA:%d--",datacount);
                    printhex(dataBuf,datacount*2," ");
                    #endif
                    #if defined(CONFIG_LS10X3A)
                    read(g_spidpllFd, recvbuf, datacount);
                    #else
                    usleep(300);
                    BootSetDpllCs(1);
                    if(ptSpiBusDrv->pSpiRecv)
                    {
                        iRet = ptSpiBusDrv->pSpiRecv(ptSpiBusDrv, recvbuf, datacount);
                    }
                    BootSetDpllCs(0);
                    #endif

                    for(i=0;i<datacount;++i)/*find the devid || check data*/
                    {
                        if(dataBuf[i] != (recvbuf[i]&dataBuf[i+datacount]))
                        {
                            printhex(dataBuf,datacount*2," ");
                            printhex(recvbuf,datacount," ");
                            break;
                        }
                    }
                    if(i==datacount)
                    {
                        if(lockFlag != 1)
                        {
                            goFlag = 1;
                            nextline = cfgline;
                            zte_printf_s("NOW GO TO CFGLINE:%d now in line:%d\n",cfgline,curline);
                            break;
                        }
                        else
                        {
                            lockFlag = 2;
                            zte_printf_s("check LOCK is locked\n");
                            break;
                        }
                    }
                }

                else if(2 == rwFlag)/*cfg addr*/
                {
                    #if defined(CONFIG_LS10X3A)
                    for(i=0;i<datacount;i++)
                    {
                        dataBuf[i] = picknum(tmpReadline,lineindex);
                        g_spiaddcfg.add_u8[i] = dataBuf[i];
                        lineindex += 3;
                    }
                    zte_printf_s("SPI CFG ADDR:0x%x--",datacount);
                    printhex(dataBuf,datacount," ");
                    g_spiaddcfg.addrlen = datacount;

                    ioctl(g_spidpllFd, SPI_DPLL_SET_ADDR, &g_spiaddcfg);
                    #else
                    for(i=0;i<datacount;i++)
                    {
                        dataBuf[i] = picknum(tmpReadline,lineindex);
                        lineindex += 3;
                    }
                    zte_printf_s("SPI CFG ADDR:0x%x--",datacount);
                    printhex(dataBuf,datacount," ");
                    usleep(300);
                    BootSetDpllCs(1);
                    if(ptSpiBusDrv->pSpiSend)
                    {
                        iRet = ptSpiBusDrv->pSpiSend(ptSpiBusDrv, dataBuf, datacount);
                    }
                    #endif
                }
                else
                {
                    zte_printf_s("rwFlag is error %x \n",rwFlag);
                }
            }
        }
    }

    if(NULL != fid)
    {
        /* Started by AICoder, pid:sb97a7206ap7d8214212086510ae012c91a74cad */
        zte_fclose_s(fid);
        /* Ended by AICoder, pid:sb97a7206ap7d8214212086510ae012c91a74cad */
    }
    return iRet;
}
static unsigned char dpllver[VERNO_LEN]= {0};
void dpll_showver(void)
{
    zte_printf_s("Dpll Version: %s\n", dpllver);
    return;
}
/******************************************************************************
* 函数名称   : ReadDpllFile(*)
* 功能描述   : get and check cfg file
* 读全局变量 : 无
* 写全局变量 : 无
* 输入参数   : 无
* 输出参数   : output file to "dpllcfg"
* 返 回 值   : BSP_OK :成功
               其他   :错误码
* 其它说明   : 对外接口
* ----------------------------------------------------------------------------*
* 历史记录(变更单, 责任人 @修改日期,      操作说明)
* $0000000(N/A),   牛彦茹                 创建
******************************************************************************/
static int CheckDpllFile(unsigned char     *inputBuf)
{
    int iRetVal=ERROR;
    FILE * fd_cfg=NULL;
    unsigned char ucCpuType = 0;
    unsigned char *pucRdVerFileBuff = NULL;
    ULONG ulCalCRCResult = 0;
    ULONG ulFileCRC = 0;
    ULONG ulFileSize=0;
    T_VerFileHeader *ptVerFileHeader = NULL;

    /* check input para*/
    if(NULL == inputBuf)
    {
        zte_printf_s("[CheckDpllFile]: inputBuf is NULL!\n");
        return iRetVal;
    }
    else
    {
        pucRdVerFileBuff = inputBuf;
    }

    ptVerFileHeader = (T_VerFileHeader *)pucRdVerFileBuff;
    BspGetCpuType(&ucCpuType);
    if(ucCpuType != ptVerFileHeader->ucCpuType)
    {
        zte_printf_s("[CheckDpllFile]: Cpu type in VerFileHeader is %d\n",ptVerFileHeader->ucCpuType);
        zte_printf_s("CPU type isn't Match\n");
        return iRetVal;
    }
    ulFileCRC = ntohl(ptVerFileHeader->ulCRC32);
    ulFileSize = ntohl(ptVerFileHeader->ulOriginalSize);
    /* Started by AICoder, pid:i52e48c490ncfb01496809601090c20d0b45ada8 */
    if (ulFileSize > (BOOT_DPLL_CFG_S_MLEN - sizeof(T_VerFileHeader)))
    {
        zte_printf_s("[CheckDpllFile]: ulFileSize=0x%x > 0x%x!\n", ulFileSize, BOOT_DPLL_CFG_S_MLEN - sizeof(T_VerFileHeader));
        return iRetVal;
    }
    /* Ended by AICoder, pid:i52e48c490ncfb01496809601090c20d0b45ada8 */

    zte_printf_s("CalculateCRC ......");
    ulCalCRCResult = CalculateCRC16(CRC_MASK,(unsigned char *)pucRdVerFileBuff+sizeof(ptVerFileHeader->ulCRC32), \
                                 ulFileSize+ sizeof(T_VerFileHeader)-sizeof(ptVerFileHeader->ulCRC32));

    /*crc error*/
    if(ulFileCRC != ulCalCRCResult)
    {
        zte_printf_s("\n CRC calculated in Boot is 0x%lx,but in file header is 0x%lx!!\n",ulCalCRCResult,ulFileCRC);
        zte_printf_s(" Version File CRC error !!!!\n");
        return iRetVal;
    }
    else if(0 == ulCalCRCResult) /*check if file is all zero*/
    {
        if (BSP_OK == CheckBufAllZero(pucRdVerFileBuff +sizeof(ptVerFileHeader->ulCRC32),   \
                               ulFileSize+ sizeof(T_VerFileHeader)-sizeof(ptVerFileHeader->ulCRC32)))
        {
            zte_printf_s("Version CRC error!! File all zero!!\n");
            return BSP_ERROR;
        }
    }
    zte_printf_s("ok.\n");
    /*get dpll ver */
    memset(dpllver,0,sizeof(dpllver));
    strncpy(dpllver,ptVerFileHeader->ucVerNo,VERNO_LEN-1);
    dpllver[VERNO_LEN - 1] = 0;
    /*creat real dpll cfg file*/
    fd_cfg = fopen(BOOT_DPLL_CFG_FILE, "w+b");
    if(NULL == fd_cfg)
    {
        zte_printf_s("[ReadDpllFile]: open and creat %s  failed!\n",BOOT_DPLL_CFG_FILE);
        return iRetVal;
    }
    iRetVal = fwrite(pucRdVerFileBuff+sizeof(T_VerFileHeader), 1, ulFileSize, fd_cfg);
    if(iRetVal != ulFileSize)
    {
        zte_printf_s("[ReadDpllFile]: fwrite %s error!\n",BOOT_DPLL_CFG_FILE);
        zte_fclose_s(fd_cfg);
        return iRetVal;
    }
    else
    {
        iRetVal = BSP_OK;
    }
    /* Started by AICoder, pid:ta608g7b1046ef8145230b9c90a986279ad7a26f */
    zte_fclose_s(fd_cfg);
    /* Ended by AICoder, pid:ta608g7b1046ef8145230b9c90a986279ad7a26f */
    return iRetVal;

}

/******************************************************************************
* 函数名称   : ReadDpllFile(*)
* 功能描述   : get and check cfg file
* 读全局变量 : 无
* 写全局变量 : 无
* 输入参数   : 无
* 输出参数   : output file to "dpllcfg"
* 返 回 值   : BSP_OK :成功
               其他   :错误码
* 其它说明   : 对外接口
* ----------------------------------------------------------------------------*
* 历史记录(变更单, 责任人 @修改日期,      操作说明)
* $0000000(N/A),   牛彦茹                 创建
******************************************************************************/
int ReadDpllFile(void)
{
    int iFD = 0, iRetVal=0;
    unsigned char *pucRdVerFileBuff = NULL;
    ULONG ulFileSize=0;
    struct stat tStat;
    T_VerFileHeader *ptVerFileHeader = NULL;

    /* malloc bootdpll cfg file mem*/
    pucRdVerFileBuff = (unsigned char *)malloc(BOOT_DPLL_CFG_S_MLEN);
    if(NULL == pucRdVerFileBuff)
    {
        zte_printf_s("[ReadDpllFile]: malloc read version file buffer failed!\n");
        return ERROR;
    }

    /*first read cfgfile from filesystem*/
    iFD = open(BOOT_DPLL_CFG_M_FILE,O_RDONLY,0666);
    if(iFD <= 0)
    {
        zte_printf_s("[ReadDpllFile]: Can not open master file!------%s\n",BOOT_DPLL_CFG_M_FILE);
        iRetVal = 0x5a;
        goto backver;
    }

    /*get file size*/
    if (ERROR == fstat(iFD, &tStat))
    {
        zte_printf_s("[ReadDpllFile]: Can not open version file!\n");
        iRetVal = 0x5a;
        goto backver;
    }

    /*check file size*/
    ulFileSize = tStat.st_size;
    if(ulFileSize > BOOT_DPLL_CFG_S_MLEN)
    {
        zte_printf_s("[ReadDpllFile]: version file size %ld  is longer than 0x%x\n", ulFileSize, BOOT_DPLL_CFG_S_MLEN);
        iRetVal = 0x5a;
        goto backver;
    }

    iRetVal = read(iFD, pucRdVerFileBuff, ulFileSize);
    zte_printf_s("1111111111111first ulFileSize is 0x%lx, pucRdVerFileBuff is 0x%p\n", ulFileSize, pucRdVerFileBuff);
    if((ULONG)iRetVal != ulFileSize)
    {
        zte_printf_s("[ReadDpllFile]: Version file read error\n");
        memset(pucRdVerFileBuff, 0, BOOT_DPLL_CFG_S_MLEN);
        iRetVal = 0x5a;
        goto backver;
    }

    /*check file header*/
    iRetVal = CheckDpllFile(pucRdVerFileBuff);
    if(BSP_OK != iRetVal)
    {
        memset(pucRdVerFileBuff, 0, BOOT_DPLL_CFG_S_MLEN);
        iRetVal = 0x5a;
    }
backver:
    if(0x5a == iRetVal)/*use back dpllcfg from norflash*/
    {
        zte_printf_s("read dpllcfg.bin from backver\n");
        iRetVal = BspFlashRead(BOOT_DPLL_CFG_S_ADD, pucRdVerFileBuff, BOOT_DPLL_CFG_HEAD_LEN);
        if(0 != iRetVal)
        {
            zte_printf_s("[ReadDpllFile]: read file verheader from flash error=0x%d\n",iRetVal);
            memset(pucRdVerFileBuff, 0, BOOT_DPLL_CFG_HEAD_LEN);
        }
        else
            ptVerFileHeader = (T_VerFileHeader *)pucRdVerFileBuff;

        if((ptVerFileHeader)&&(ptVerFileHeader->ulOriginalSize <= (BOOT_DPLL_CFG_S_MLEN-BOOT_DPLL_CFG_HEAD_LEN)))
        {
            iRetVal = BspFlashRead(BOOT_DPLL_CFG_S_ADD, pucRdVerFileBuff, \
                                            ntohl(ptVerFileHeader->ulOriginalSize)+BOOT_DPLL_CFG_HEAD_LEN);
        }
        else
        {
            zte_printf_s("[ReadDpllFile]: file length error\n");
            free(pucRdVerFileBuff);
            if(iFD > 0)    close(iFD);
            return iRetVal;
        }
        if (0 != iRetVal)
        {
            zte_printf_s("[ReadDpllFile]: read file from flash error=0x%d\n",iRetVal);
            free(pucRdVerFileBuff);
            if(iFD > 0)    close(iFD);
            return iRetVal;
        }
        else
        {
            iRetVal = CheckDpllFile(pucRdVerFileBuff);
            if(BSP_OK != iRetVal)
            {
                free(pucRdVerFileBuff);
                if(iFD > 0)    close(iFD);
                return iRetVal;
            }
        }
    }

    free(pucRdVerFileBuff);
    if(iFD > 0)
    {
        close(iFD);
    }
    return iRetVal;
}
/*INIT SPI BUS ADN dpll chip*/
int dpll_init(void)
{
    int iRet = -1;

    /*reset chip*/
    BootSetDpllRst();

    memset((char *)DPLL_VER_ADRS, 0, VERNO_LEN); /*first clear*/

    /*get dpll cfg file from filesystem or norflash*/
    iRet = ReadDpllFile();
    if(iRet)
    {
        zte_printf_s("ReadDpllFile ret:0x%x\n",iRet);
        return iRet;
    }
    #if defined(CONFIG_ZX2112XX)
    /*get spi cfg para form right cfg file*/
    iRet = GetSpiCfg();
    zte_printf_s("GetSpiCfg ret:0x%x\n",iRet);
    #endif

    /*init spi bus*/
    iRet = BspSpiDpllInit();
    if(iRet)
    {
        zte_printf_s("init spi dpll ret:0x%x\n",iRet);
        return iRet;
    }
    /*set cs not available*/
    BootSetDpllCs(0);

    /*parse the cfg file and cfg dpll chip*/
    iRet = ParseFile();
    zte_printf_s("ParseFile ret:0x%x\n",iRet);

    strncpy((char *)DPLL_VER_ADRS,dpllver,VERNO_LEN-1);

    return iRet;
}
#if 0
/*test func add by niuyanru*/
int dpll_test(int ulTest, int ulCase)
{
    int iRet = -1;
    unsigned char regaddr[2];
    unsigned char recvbuf[MAX_LINE_SIZE] = {0}; // for revevied packet
    /* Started by AICoder, pid:p5818qb5404063f14dae0827d04e260efba8feb4 */
    unsigned char sendbuf[MAX_LINE_SIZE]={0};// for sended packet
    sendbuf[0]=0x7C;
    sendbuf[1]=0x0;
    sendbuf[2]=0xC0;
    sendbuf[3]=0x10;
    sendbuf[4]=0x20;
    /* Ended by AICoder, pid:p5818qb5404063f14dae0827d04e260efba8feb4 */
    long ulDataLen=5;
    FILE * fid=NULL;
    #if defined(CONFIG_ZX2112XX)
    T_SPI_DRV *ptSpiBusDrv = &s_atHwSpiBusDrv;
    #endif

    zte_printf_s("ulTest = %x;  ulCase = %x \n",ulTest,ulCase);

    if(16 == ulTest)  /*for release version*/
    {
        /*get dpll cfg file from filesystem or norflash*/
        iRet = ReadDpllFile();
        zte_printf_s("ReadDpllFile ret:0x%x",iRet);

        #if defined(CONFIG_ZX2112XX)
        /*get spi cfg para form right cfg file*/
        iRet = GetSpiCfg();
        zte_printf_s("GetSpiCfg ret:0x%x",iRet);
        #endif
        /*init spi bus*/
        iRet = BspSpiDpllInit();
        zte_printf_s("init spi dpll ret:0x%x",iRet);
        /*set cs not available*/
        BootSetDpllCs(0);

        /*parse the cfg file and cfg dpll chip*/
        iRet = ParseFile();
        zte_printf_s("ParseFile ret:0x%x",iRet);
    }

    if(3 == ulTest)
    {
        ParseFile();
    }
    #if defined(CONFIG_LS10X3A)
    if(0 == ulTest)/*write*/
    {
        iRet = write(g_spidpllFd, sendbuf, ulDataLen);
        zte_printf_s("spi dpll write byte = %d\n",iRet);
    }
    if(1 == ulTest)/*read*/
    {
        ulDataLen = read(g_spidpllFd, recvbuf, 12);
        zte_printf_s("spi dpll read byte = %d\n",ulDataLen);
        if (0 <= ulDataLen)
        {
            sleep(1);
            printhex(recvbuf,ulDataLen," ");
        }
    }
    if(2 == ulTest)/*ioctl*/
    {
        ioctl(g_spidpllFd, ulCase, 0);
    }


    if(4 == ulTest) /*read id*/
    {
        sendbuf[0]=0x7c; sendbuf[1]=0; sendbuf[2]=0xc0; sendbuf[3]=0x10; sendbuf[4]=0x20;
        iRet = write(g_spidpllFd, sendbuf, 5);
        zte_printf_s("spi dpll write byte = %d\n",iRet);

        g_spiaddcfg.addrlen = 1;
        g_spiaddcfg.add_u8[0] = 0xb2;
        ioctl(g_spidpllFd, SPI_DPLL_SET_ADDR, &g_spiaddcfg);

        ulDataLen = read(g_spidpllFd, recvbuf, 2);
        zte_printf_s("spi dpll read byte = %d\n",ulDataLen);
        if (0 <= ulDataLen)
        {
            sleep(1);
            printhex(recvbuf,ulDataLen," ");
        }
    }
    if(5 == ulTest) /*read locked*/
    {
        sendbuf[0]=0x7c; sendbuf[1]=0; sendbuf[2]=0xc0; sendbuf[3]=0x10; sendbuf[4]=0x20;
        iRet = write(g_spidpllFd, sendbuf, 5);
        zte_printf_s("spi dpll write byte = %d\n",iRet);

        g_spiaddcfg.addrlen = 1;
        g_spiaddcfg.add_u8[0] = 0xd4;
        ioctl(g_spidpllFd, SPI_DPLL_SET_ADDR, &g_spiaddcfg);

        ulDataLen = read(g_spidpllFd, recvbuf, 2);
        zte_printf_s("spi dpll read byte = %d\n",ulDataLen);
        if (0 <= ulDataLen)
        {
            sleep(1);
            printhex(recvbuf,ulDataLen," ");
        }
    }
    if(6 == ulTest) /*read reg*/
    {
        regaddr[1] = ulCase & 0x7f;
        if(ulCase & 0x80) sendbuf[1]=0x80;
        else sendbuf[1] = 0;

        regaddr[0] = (ulCase>>8) & 0xff;
        sendbuf[0]=0x7c; sendbuf[2]=regaddr[0]; sendbuf[3]=0x10; sendbuf[4]=0x20;
        iRet = write(g_spidpllFd, sendbuf, 5);
        zte_printf_s("spi dpll write byte = %d\n",iRet);

        g_spiaddcfg.addrlen = 1;
        g_spiaddcfg.add_u8[0] = 0x80|regaddr[1];
        ioctl(g_spidpllFd, SPI_DPLL_SET_ADDR, &g_spiaddcfg);

        ulDataLen = read(g_spidpllFd, recvbuf, 2);
        zte_printf_s("spi dpll read byte = %d\n",ulDataLen);
        if (0 <= ulDataLen)
        {
            sleep(1);
            printhex(recvbuf,ulDataLen," ");
        }
    }
    zte_printf_s("g_spidpllFd = %d\n",g_spidpllFd);
    if(g_spidpllFd>0)
    {
        close(g_spidpllFd);
    }
    #else
    if(6 == ulTest) /*read reg*/
    {
        regaddr[1] = ulCase & 0x7f;
        if(ulCase & 0x80)
        {
            sendbuf[1]=0x80;
        }
        else sendbuf[1] = 0;

        regaddr[0] = (ulCase>>8) & 0xff;
        sendbuf[0]=0x7c; sendbuf[2]=regaddr[0]; sendbuf[3]=0x10; sendbuf[4]=0x20;

        BootSetDpllCs(1);
        if(ptSpiBusDrv->pSpiSend)
        {
            iRet = ptSpiBusDrv->pSpiSend(ptSpiBusDrv, sendbuf, 5);
        }
        BootSetDpllCs(0);
        zte_printf_s("spi dpll write byte = %d\n",iRet);

        sendbuf[0] = 0x80|regaddr[1];
        BootSetDpllCs(1);
        if(ptSpiBusDrv->pSpiSend)
        {
            iRet = ptSpiBusDrv->pSpiSend(ptSpiBusDrv, sendbuf, 1);
        }
        if(ptSpiBusDrv->pSpiRecv)
        {
            iRet = ptSpiBusDrv->pSpiRecv(ptSpiBusDrv, recvbuf, 2);
        }
        BootSetDpllCs(0);

        zte_printf_s("spi dpll read byte = %d\n",iRet);
        sleep(1);
        printhex(recvbuf,2," ");
    }
    if(4 == ulTest) /*read id*/
    {
        sendbuf[0]=0x7c; sendbuf[1]=0; sendbuf[2]=0xc0; sendbuf[3]=0x10; sendbuf[4]=0x20;
        BootSetDpllCs(1);
        if(ptSpiBusDrv->pSpiSend)
        {
            iRet = ptSpiBusDrv->pSpiSend(ptSpiBusDrv, sendbuf, 5);
        }
        BootSetDpllCs(0);
        zte_printf_s("spi dpll write byte = %d\n",iRet);

        sendbuf[0]=0xb2;
        BootSetDpllCs(1);
        if(ptSpiBusDrv->pSpiSend)
        {
            iRet = ptSpiBusDrv->pSpiSend(ptSpiBusDrv, sendbuf, 1);
        }
        if(ptSpiBusDrv->pSpiRecv)
        {
            iRet = ptSpiBusDrv->pSpiRecv(ptSpiBusDrv, recvbuf, 2);
        }
        BootSetDpllCs(0);

        zte_printf_s("spi dpll read byte = %d\n",iRet);
        sleep(1);
        printhex(recvbuf,2," ");
    }
    #endif
    if(fid)
    {
        (void)fclose(fid);
    }
    return 0;
}
#endif
#endif

/******************************************************************************
* 版权所有 (C)2007, 深圳市中兴通讯股份有限公司。
*
* 文件名称： BootApp.c
* 文件标识：
* 内容摘要： 软基站平台BootApp.c。用于BOOT模块入口。
* 其它说明： 无
* 当前版本： V1.0
* 作    者： 耿佳佳
* 完成日期： 2015-9-22
*
* 修改记录1：
*    修改日期：
*    版 本 号：
*    修 改 人：
*    变 更 号：
*    关 键 字：
*    修改内容：
*
******************************************************************************/
/* =====================#include（依次为标准库头文件、非标准库头文件）====== */
#include "secure_func.h"
#include <vxadp.h>
#include <bootapp.h>
#include <bsppub.h>
#include <loadversion.h>
#include <bootadp.h>
#include <bspcomm.h>
#include <linux/sysctl.h>
#include <math.h>
#include <sys/stat.h>
//#include <fsapp.h>
#include <flash.h>
/* Started by AICoder, pid:l75e4z8177jfdd014ee509a19066880b6ca268c8 */
#include <crc.h>
/* Ended by AICoder, pid:l75e4z8177jfdd014ee509a19066880b6ca268c8 */
#if defined(CONFIG_ZXW11200_NTN)
#include "protocol.h"
#include <repairversion.h>
/* Started by AICoder, pid:wbfacjd32b901d514c0b08bf40e2aa0fcee2b92e */
#include <loadversion_plus.h>
/* Ended by AICoder, pid:wbfacjd32b901d514c0b08bf40e2aa0fcee2b92e */
#endif
#include <ubifs.h>

/* =====================文件内部使用的宏 #define========================== */
#define USE_DDR_ADDR_TEMP 0x06900000
#define CFG_VER_RAM_LEN (16 * 1024 * 1024) /* reserved for download cur.swv 20110225*/
#define BOOT_BR_FEED_PER_SEC ((WORD32)10)
#define ETH_PROMISC_MODE 1
#define ETH_NOPROMISC_MODE 0

#define SIOCGIFINDEX 0x8933 /* name -> if_index mapping */
#define WRITE_FLASH_SUCCESS 0x55
#define WRITE_FLASH_FAILED 0xAA

/*BOMID8 BOMID16 功能宏由cmake决定*/
#if(defined(CONFIG_BOMID16) || defined(CONFIG_BOMID8))
#define BOMID_MAGIC_NUM 0xA5C3 /*因小端存储，低位存储在低位，高位存储在高位*/
#define BOMID_CRC16_ADDR_OFFSET 12
#define BOMID_MAGIC_NUM_ADDR_OFFSET 14
enum bomid_type
{
    ModuleGroupId,
    BoardGroupId,
    BoardTypeId,
    HardChangeId,
    HardCustomIdA,
    HardCustomIdB
};

typedef struct
{
    UCHAR ucBomIdInfo[12];
    USHORT usCRC16;
    USHORT usMagicNum;
} tBomIDInfoStruct;
#endif
/* =====================全局变量 global=================================== */
int iSocket = 0;
UCHAR gucRecBuf[4096] = {0};
unsigned char aMacIpSetFlag[2] =
{
    0x5A, 0xFA
}; /*定义配置包的特定信息标志*/
unsigned char LFecIpAddr[4];
unsigned char aBSPPIIIIpAddr[4];
unsigned char aEnvironment[4];
unsigned char BSPBOARDID;
unsigned char LFecEnetAddr[6] =
{
    0x40, 0x00, 0x00, 0x64, 0x64, 0x01
};

typedef struct /*定义主控发来的MAC_IP配置包的结构*/
{
    unsigned char aDestMac[6]; /* MAC包的目地址*/
    unsigned char aSrcMac[6]; /* MAC包的源地址*/
    unsigned short wDataLength; /* 0-23 */
    unsigned short wMacIpSetFlag; /*配置包的特定信息标志  0x5AFA? */
    unsigned char aIpAddr[4];
    unsigned char aPIIIIpAddr[4]; /*PIII的IP*/
    unsigned char aEnvironment[4]; /*环境号*/
    unsigned char byBoardID; /*单板号*/
    unsigned char aPast[10];
    unsigned char byCheckSun;
} tMACGetStruc;

unsigned char *gpucmacMsg;
unsigned char *gpucmacRetMsg;
unsigned char *gpucsave;
int icnt;
unsigned char gucRet;
unsigned char gaucmacRet[40] = {0};
unsigned char gaucmac[40] = {0};
ULONG g_ulProZoneAddrOffset = PROTECT_ZONE_ADDRESS_INIT;
ULONG g_ulProZoneSize = PROTECT_ZONE_SIZE_INIT;

ULONG g_ulResetTrue = 1;
int part_info_ctl[4] = {CTL_FS, FS_JFFS2, JFFS2_PART2, PART2_INFO};
int part_gc_ctl[4] = {CTL_FS, FS_JFFS2, JFFS2_PART2, PART2_START_GC};
struct sockaddr_ll addr;

char * const pathlist[1] = {"/sbin/format"};
rsize_t pathlist_size = 1;
/* =====================本地变量（即静态全局变量）local==================== */
static unsigned int s_uitobootflag = 1;
static unsigned char s_ucGetMacIpSetFlag = 0; /*重新配置完成标识*/
/* 增加保护区版本标志完善INI异常处理，By Zengx,2012.02.23 */

static T_FlashInfo boot_tFlashInfo;
/* =====================局部函数原型====================================== */
ULONG FlushRuSwToProtect();
/* =====================外部函数申明====================================== */
extern ULONG _GetPHYLinkStatus();
extern ULONG loadlinux(VOID);
extern STATUS CheckBufAllZero(UCHAR *pucData, ULONG ulLen);

#if defined(CONFIG_LS10X3A)&&!defined(CONFIG_A9606_BOARD)
extern ULONG cpld_read(ULONG ulOffSet, unsigned char *pucReg);
extern ULONG cpld_write(ULONG ulOffSet, unsigned char ucReg);
#endif

#if defined(CONFIG_DRA62X)
extern int dra62x_is_config(enum e_dra624_module_cfg_t dra624_module);
#endif

#if defined(CONFIG_ZYNQMPSOC)
extern unsigned char zynqmpsoc_get_appid();
#endif

extern UCHAR g_ucRunVer;
extern BOOL s_bProzoneFlag; /* 保护区版本标志 */
extern BOOL s_bBackFlag; /*回退版本标志*/
extern BOOL s_bRunFlag; /*回退版本标志*/
extern int AddrArray[2];

extern T_FileSystemInfo s_at_FileSystemInfo[];
extern int max_filesystem_num;


/*****************************************************************************
* 函数名称   : BootSysMsDelay(*)
* 功能描述   : 系统延时函数
* 读全局变量 : 无
* 写全局变量 : 无
* 输入参数   : ulDelay  - 延时长度(ms)
* 输出参数   : 无
* 返 回 值   :
* 其它说明   : 系统保留接口函数
*工装使用申明: 工装使用接口，请注意波及
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 宋志强2014-05-12 18:55:24, 从r15trx 移植到dpdic 单板
*----------------------------------------------------------------------------
*/
VOID BootSysMsDelay(ULONG ulDelay)
{
    if (ulDelay < 10)
    {
        taskDelay(1); /* 1ms */
    }
    else
    {
        taskDelay(ulDelay / 10);
    }
}
/*****************************************************************************
* 函数名称   : BootRruProZoneModInit(*)
* 功能描述   : 保护区模块初始化
* 读全局变量 : 无
* 写全局变量 : 无
* 输入参数   : 模块初始化结构体指针
* 输出参数   : 无
* 返 回 值   : BSP_OK 成功，其他失败
* 其它说明   :
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 姜建奎@2012-03-01 10:14:27 创建
* $0000001(N/A), 姜建奎@2012-12-11 10:14:27 其他需要的参数初始化
*----------------------------------------------------------------------------
*/
ULONG BootRruProZoneModInit(T_RruProZoneInit *ptRruProZoneInit)
{
    if (NULL == ptRruProZoneInit)
    {
        zte_printf_s("BspRruProZoneMod Init Fail \n");
        return BSP_ERROR;
    }

    g_ulProZoneAddrOffset = ptRruProZoneInit->aulParam[0]; /*传递保护区的偏移地址*/
    g_ulProZoneSize = ptRruProZoneInit->aulParam[1]; /*保护区的长度*/

    return BSP_OK;
}
/*****************************************************************************
* 函数名称   : BootSoftModInit(*)
* 功能描述   : 初始化各个软件模块
* 读全局变量 : 无
* 写全局变量 : 无
* 输入参数   : 无
* 输出参数   : 无
* 返 回 值   : BSP_OK 成功,BSP_ERROR 出错
* 其它说明   :
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 姜建奎@2012-03-02 11:14:27 创建
* $0000001(N/A), 姜建奎@2012-12-11 11:14:27 根据r15trx 需要修改
*----------------------------------------------------------------------------
*/
ULONG BootSoftModInit(void)
{
    ULONG ulRet = 0;
    INT fd = 0;
    ULONG ulmtdSize = 0;
    ULONG ulBootMtdSize = 0;
    T_RruProZoneInit tRruProZoneInit;
    zte_memset_s((void *)&tRruProZoneInit, sizeof(tRruProZoneInit), 0, sizeof(tRruProZoneInit));
    fd = open("/dev/mtd0", O_RDWR);
    if (fd < 0)
    {
        zte_printf_s("open /dev/mtd0 error \n");
        return BSP_ERROR;
    }

    if (0 != lseek(fd, 0, SEEK_SET))
    {
        zte_printf_s("lseek /dev/mtd0 to begin error \n");
        close(fd);
        return BSP_ERROR;
    }
    ulBootMtdSize = lseek(fd, 0, SEEK_END);
    if (0 == ulBootMtdSize)
    {
        zte_printf_s("lseek /dev/mtd0 to end error \n");
        close(fd);
        return BSP_ERROR;
    }
    close(fd);

    fd = open("/dev/mtd1", O_RDWR);
    if (fd < 0)
    {
        zte_printf_s("open /dev/mtd1 error \n");
        return BSP_ERROR;
    }
    if (0 != lseek(fd, 0, SEEK_SET))
    {
        zte_printf_s("lseek /dev/mtd1 to begin error \n");
        close(fd);
        return BSP_ERROR;
    }
    ulmtdSize = lseek(fd, 0, SEEK_END);
    if (0 == ulmtdSize)
    {
        zte_printf_s("lseek /dev/mtd1 to end error \n");
        close(fd);
        return BSP_ERROR;
    }
    close(fd);

    // tRruProZoneInit.aulParam[0] = DRAM_256M; /*获取单板DRAM 大小*/
    // tRruProZoneInit.aulParam[1] = FLASH_SECTOR_SIZE; /*单板Flash 擦除块的大小*/
    tRruProZoneInit.aulParam[0] = ulBootMtdSize + PROTECT_ZONE_OFFSET_MTD1; /*单板保护区的偏移地址*/
    #if defined(CONFIG_ZX211412)
    tRruProZoneInit.aulParam[1] = ulmtdSize - PROTECT_ZONE_OFFSET_MTD1 - PROTECT_ZONE_SAFE_AREA;
    #else
    tRruProZoneInit.aulParam[1] = ulmtdSize - PROTECT_ZONE_OFFSET_MTD1; /*保护区的长度*/
    #endif
    ulRet = BootRruProZoneModInit(&tRruProZoneInit);
    return ulRet;
}

/**********************************************************************
* 函数名称:mii
* 功能描述:通过GMII寄存器读PHY  .  针对以太网口GMAC0
* 输入参数: *     - udCsrClockRange：CSR 时钟区域
*     - udGR： GMII寄存器
*     - udPA： PHY设备物理层地址
*     - pudData：需要读出的数据的地址
* 输出参数:
* 返 回 值:
* 其它说明:
* 修改日期        版本号     修改人          修改内容
* -----------------------------------------------
* 2014-5-28       V1.0       yam             创建
* $0000000(N/A), 00086970 19:33:10 trm78E
***********************************************************************/
ULONG mii(CHAR *pcAct, ULONG ulAddr, ULONG ulReg, ULONG ulData)
{
    ULONG pulData = 0;
    #define MII_CLK_150_250MHZ  0x4 /*0b0100*/
    ULONG ulRet;

    if (NULL == pcAct)
    {
        zte_printf_s("%s:Input Pointer is NULL!\n", __FUNCTION__);
        zte_printf_s("mii \"read\",Addr,Reg - read  MII PHY <addr> register <reg>\n");
        zte_printf_s("mii \"write\",Addr,Reg,data -write <data> to MII PHY <addr> register <reg>\n");
        return ERROR_NULL_POINTER;
    }

    if (strcmp(pcAct, "write") == 0)
    {
        ulRet = BootDebugMiiWrite(MII_CLK_150_250MHZ, ulReg, ulAddr, ulData);
        if (0 != ulRet)
        {
            zte_printf_s("Error writing to the PHY addr=%02x reg=%02x\n", ulAddr, ulReg);
        }
    }
    else if (strcmp(pcAct, "read") == 0)
    {
        ulRet = BootDebugMiiRead(MII_CLK_150_250MHZ, ulReg, ulAddr, &pulData);
        if (0 != ulRet)
        {
            zte_printf_s("Error reading the PHY addr=0x%02x reg=0x%02x\n", ulAddr, ulReg);
        }
        else
        {
            zte_printf_s("addr=%02x reg=%02x data=", ulAddr, ulReg);
            zte_printf_s("%04x\n", pulData);
        }
    }
    else
    {
        zte_printf_s("para error!\n");
        zte_printf_s("mii \"read\",Addr,Reg - read  MII PHY <addr> register <reg>\n");
        zte_printf_s("mii \"write\",Addr,Reg,data -write <data> to MII PHY <addr> register <reg>\n");
        ulRet = BSP_ERROR;
    }
    return ulRet;
}
/**************************************************************************
* 函数名称： bs
* 功能描述：
* 输入参数： void
* 输出参数： 无
* 返 回 值：
* ------------------------------------------------------
* 其它说明：
* 修改日期     版本号     修改人      修改内容
* 2014/5/29         V1.0              00086970                        创建
**************************************************************************/
VOID bs(VOID)
{
    s_uitobootflag = 0;
}
/**************************************************************************
* 函数名称： goboot
* 功能描述：
* 输入参数： void
* 输出参数： 无
* 返 回 值：
* ------------------------------------------------------
* 其它说明：
* 修改日期     版本号     修改人      修改内容
* 2014/5/29         V1.0              00086970                        创建
**************************************************************************/
VOID goboot(VOID)
{
    s_uitobootflag = 2;
}
/**************************************************************************
* 函数名称： nf
* 功能描述：
* 输入参数： void
* 输出参数： 无
* 返 回 值：
* ------------------------------------------------------
* 其它说明：
* 修改日期     版本号     修改人      修改内容
* 2014/5/29         V1.0              00086970                        创建
**************************************************************************/
VOID nf(VOID)
{
    s_uitobootflag = 3;
}

#if defined(CONFIG_RECORD_TIME)
/*********************上电计时节点名称,和bootapp.h中保持位置一致*************************************/
static const char NameBuffer[END][MAXNAMELEN] =
{
    "FILE_ST",
    "FILE_END",
    "VER_ST",
    "CUR_END",
    "DOWLD_END",
    "PROCT_END",
    "TMP_END",
    "KEXEC_END",
};
/**************************************************************************
* 函数名称：WriteNextNode
* 功能描述：写BOOTAPP阶段的计时节点到高端内存
* 输入参数：计时节点高端内存基址、计时节点
* 输出参数：
* 返 回 值：
* ------------------------------------------------------
* 其它说明：
* 修改日期     版本号     修改人      修改内容
* 2019/1/17   V1.0      10242265                     创建
**************************************************************************/
char WriteNextNode(void * BaseAddr, struct TimeNode *data)
{
    struct TimeNode* EndPtr = (struct TimeNode*)BaseAddr;
    struct TimeNode* HeadPtr = (struct TimeNode*)BaseAddr;
    if (NULL == EndPtr || NULL == data)
    {
        zte_printf_s("ERROR NULL ptr!!!\n");
        return -1;
    }
    /*check header 设置每个节点名字的结束符，防止strlen 没有结束符 */
    HeadPtr->cName[MAXNAMELEN - 1] = '\0';
    if (0 != strncmp(HeadPtr->cName, KEBOOT_MAGICNAME, MAXNAMELEN))
    {
        zte_printf_s("ERROR BOOTAPP HEADER!!!\n");
        return -1;
    }
    /* Started by AICoder, pid:x2222ue826n4b11149510980401197056a5548ab */
    while (zte_strnlen_s(EndPtr->cName, MAXNAMELEN) > 0 &&
       ((char *)EndPtr + sizeof(struct TimeNode)) < ((char *)BaseAddr + RECORD_TIME_NODE_SIZE))
    /* Ended by AICoder, pid:x2222ue826n4b11149510980401197056a5548ab */
    {
        if (0 == strncmp(EndPtr->cName, MAX_ENDNAME, strlen(MAX_ENDNAME)))
        {
            zte_printf_s("waring: TIME NODE MEM SPACE FULL!!\n");
            EndPtr--;
            break;
        }
        else
        {
            EndPtr++;
        }
        EndPtr->cName[MAXNAMELEN - 1] = '\0';
    }
    /*这里的计时函数得到的就是系统上电以来的时间，不用进行累加*/
    data->cName[MAXNAMELEN - 1] = '\0';
    zte_printf_s("Time Node [%s] dwRecTime:%d ms\n", data->cName, data->dwRecTime * 10);
    zte_memcpy_s(EndPtr, sizeof(struct TimeNode), data, sizeof(struct TimeNode));
    return 0;
}
/**************************************************************************
* 函数名称：TimeNode
* 功能描述：记录计时节点api
* 输入参数：计时节点名称
* 输出参数：
* 返 回 值：
* ------------------------------------------------------
* 其它说明：
* 修改日期     版本号     修改人      修改内容
* 2019/1/17   V1.0      10242265         创建
**************************************************************************/
void TimeNode(enum node_id name)
{
    struct timespec *ts = (struct timespec *)malloc(sizeof(struct timespec));
    struct TimeNode *tn = (struct TimeNode *)malloc(sizeof(struct TimeNode));
    struct TimeNode *HeadAddr = NULL;
    void *mem_vir = (void *)BootGetMemVir(); /*获取对应cpu上电计时基址*/
    if (NULL == ts || NULL == tn || NULL == mem_vir)
    {
        zte_printf_s("ERROR TImeNode Ptr!!!\n");
        goto error;
    }
    HeadAddr = (struct TimeNode *)(mem_vir);
    HeadAddr->cName[MAXNAMELEN - 1] = '\0';
    // zte_printf_s("mem_vir:0x%lx.phy_addr:0x%lx  data:%s\n",mem_vir,DRAM_BASE_ADDR+ ((unsigned long)BootGetDdrSize() << 20)-OSS_MEM_SIZE+0x8000,HeadAddr->cName);
    clock_gettime(CLOCK_MONOTONIC, ts);
    if (zte_strncpy_s(tn->cName, MAXNAMELEN, NameBuffer[name], MAXNAMELEN - 1) < 0)
    {
        dbgErr("%s %d zte_strncpy_s error!!\n", __func__, __LINE__);
        goto error;
    }
    tn->dwRecTime = (unsigned int)(ts->tv_sec * 1000 + ts->tv_nsec / 1000000) / 10;
    WriteNextNode(mem_vir, tn);
error:
    if (NULL != ts)
    {
        free(ts);
    }
    if (NULL != tn)
    {
        free(tn);
    }
    ts = NULL;
    tn = NULL;
}
#endif
/**************************************************************************
* 函数名称： sf_write
* 功能描述：
* 输入参数： void
* 输出参数： 无
* 返 回 值：
* ------------------------------------------------------
* 其它说明：
* 修改日期     版本号     修改人      修改内容
* 2014/5/29         V1.0              00086970                        创建
**************************************************************************/
ULONG sf_write(ULONG ucName, ULONG ulOffset, ULONG ulLen)
{
    FILE *pf = NULL;
    CHAR *cDatafile = (CHAR *)ucName;
    struct stat tStat;
    ULONG ulFileSize = 0;
    /* Started by AICoder, pid:m97b4y22b8j069d14327098150229c053431ca77 */
    UCHAR *pucRdVerFileBuff = NULL; // 初始化读取版本文件的缓冲区指针
    /* Ended by AICoder, pid:m97b4y22b8j069d14327098150229c053431ca77 */
    ULONG iRetVal = BSP_OK;
    ULONG ulBuffLen = 0;
    LONG ulSize = ulLen;
    ULONG ulFlashOffset = ulOffset;
    ULONG iReadLen = 0;
    /*
    if ( ulLen > pow(2,25))
    {
    zte_printf_s("len must be smaller than 32M\n");
    return BSP_ERROR;
    }
    */

    if (0 == ulLen)
    {
        zte_printf_s("Lenth can not be 0\n");
        return BSP_ERROR;
    }

    ulBuffLen = 1024 * 1024;
    /* Started by AICoder, pid:p8e55ne879n1b221445a0b2f80004b0f1f06baf2 */
    pucRdVerFileBuff = malloc(ulBuffLen);
    if (pucRdVerFileBuff == NULL)
    {
        dbgErr("malloc buffer failed!");
        return BSP_ERROR_MEM_MALLOC;
    }
    /* Ended by AICoder, pid:p8e55ne879n1b221445a0b2f80004b0f1f06baf2 */

    pf = fopen(cDatafile, "rb");
    if (NULL == pf)
    {
        dbgErr("open %s fail!\n", cDatafile);
        free(pucRdVerFileBuff);
        pucRdVerFileBuff = NULL;
        return BSP_ERROR;
    }
    /* Started by AICoder, pid:z0fcbsd507n030014fc40853d095d507d7882c4f */
    if (fstat(fileno(pf), &tStat) == -1)
    {
        dbgErr("stat file %s Failed!\n", cDatafile);
        free(pucRdVerFileBuff);
        pucRdVerFileBuff = NULL;
        zte_fclose_s(pf);
        return BSP_ERROR;
    }
    /* Ended by AICoder, pid:z0fcbsd507n030014fc40853d095d507d7882c4f */
    ulFileSize = tStat.st_size;
    if (ulLen > ulFileSize)
    {
        dbgErr("len beyond the file length !\n");
        free(pucRdVerFileBuff);
        pucRdVerFileBuff = NULL;
        zte_fclose_s(pf);
        return BSP_ERROR;
    }

    while (ulSize >= ulBuffLen)
    {
        /* 读取源文件内容 */
        zte_memset_s(pucRdVerFileBuff, ulBuffLen, 0, ulBuffLen);
        iReadLen = fread(pucRdVerFileBuff, 1, ulBuffLen, pf);
        if (iReadLen != ulBuffLen)
        {
            dbgErr("read file <%s> failed!, reason: %d is not equal to %d\n", cDatafile, iReadLen, ulBuffLen);
            iRetVal = BSP_ERROR;
            zte_fclose_s(pf);
            free(pucRdVerFileBuff);
            pucRdVerFileBuff = NULL;
            return iRetVal;
        }
        /* 延时200ms */
        // BspSysMsDelay(20);
        /* 将读取到的内容写入flash */
        /* Started by AICoder, pid:pcc82y041dk3d651406d0a2c1076030d0e8130b7 */
        iRetVal = BspFlashWrite(ulFlashOffset, pucRdVerFileBuff, ulBuffLen);
        /* Ended by AICoder, pid:pcc82y041dk3d651406d0a2c1076030d0e8130b7 */
        if (BSP_OK != iRetVal)
        {
            dbgErr("write flash failed!offset:0x%x,len:0x%x\n", ulFlashOffset, ulBuffLen);
            zte_fclose_s(pf);
            free(pucRdVerFileBuff);
            pucRdVerFileBuff = NULL;
            return iRetVal;
        }

        //  BspSysMsDelay(200);
        ulSize -= ulBuffLen;
        ulFlashOffset += ulBuffLen;
    }
    if ((BSP_OK == iRetVal) && (ulSize > 0))
    {
        /* 读源文件内容 */
        zte_memset_s(pucRdVerFileBuff, ulBuffLen, 0, ulBuffLen);
        iReadLen = fread(pucRdVerFileBuff, 1, ulSize, pf);
        if (iReadLen != ulSize)
        {
            dbgErr("read file <%s> failed!, reason: %d is not equal to %d\n", cDatafile, iReadLen, ulSize);
            iRetVal = BSP_ERROR;
        }
        else
        {
            /* Started by AICoder, pid:bed97mbf01wee3914592097c60de2c0bc1c2de26 */
            // 将版本文件缓冲区写入闪存
            iRetVal = BspFlashWrite(ulFlashOffset, pucRdVerFileBuff, ulSize);
            /* Ended by AICoder, pid:bed97mbf01wee3914592097c60de2c0bc1c2de26 */
            if (BSP_OK != iRetVal)
            {
                dbgErr("write flash failed!offset:0x%x,len:0x%x\n", ulFlashOffset, ulSize);
            }
        }
    }

    zte_fclose_s(pf);
    free(pucRdVerFileBuff);
    pucRdVerFileBuff = NULL;
    return iRetVal;
}
/**************************************************************************
* 函数名称： sf_read
* 功能描述：
* 输入参数： void
* 输出参数： 无
* 返 回 值：
* ------------------------------------------------------
* 其它说明：
* 修改日期     版本号     修改人         修改内容
* 2014/5/29         V1.0              00086970                        创建
**************************************************************************/
ULONG sf_read(ULONG ucName, ULONG ulOffset, ULONG ulLen)
{
    INT32 fd = 0;
    CHAR *cDatafile = (CHAR *)ucName;
    /* Started by AICoder, pid:m917c1f911q0597148ca087e109fa40c435272b8 */
    // 初始化读取版本文件的缓冲区指针
    UCHAR *pucRdVerFileBuff = NULL;
    /* Ended by AICoder, pid:m917c1f911q0597148ca087e109fa40c435272b8 */
    ULONG iRetVal = BSP_OK;
    ULONG ulWriteLen = 0;
    /*
    if ( ulLen > pow(2,25))
    {
    zte_printf_s("len must be smaller than 32M\n");
    return BSP_ERROR;
    }
    */
    if (0 == ulLen)
    {
        zte_printf_s("Lenth can not be 0\n");
        return BSP_ERROR;
    }
    fd = open(cDatafile, (O_CREAT | O_RDWR), 0644);
    if (fd < 0)
    {
        zte_printf_s("open file %s Error!\n", cDatafile);
        return BSP_ERROR;
    }
    zte_printf_s("### fopen %s wb\n", cDatafile);
    /* Started by AICoder, pid:x841ea6a77i130014ec70857e0be5e0ac0f77a7a */
    pucRdVerFileBuff = malloc(ulLen);
    if (pucRdVerFileBuff == NULL)
    {
        zte_printf_s("malloc read version file buffer failed!\n");
        close(fd);
        return BSP_ERROR;
    }
    /* Ended by AICoder, pid:x841ea6a77i130014ec70857e0be5e0ac0f77a7a */
    zte_printf_s("Offset 0x%x Lenth 0x%x  will be read!!!\n", ulOffset, ulLen);
    /* Started by AICoder, pid:hac8b6510d5dbc81428a0a7c60aaac043ea2285a */
    // 从闪存读取数据到版本文件缓冲区
    iRetVal = BspFlashRead(ulOffset, pucRdVerFileBuff, ulLen);
    /* Ended by AICoder, pid:hac8b6510d5dbc81428a0a7c60aaac043ea2285a */
    if (BSP_OK != iRetVal)
    {
        zte_printf_s("read flash failed!\n");
        free(pucRdVerFileBuff);
        pucRdVerFileBuff = NULL;
        close(fd);
        return BSP_ERROR;
    }
    ulWriteLen = write(fd, (char *)pucRdVerFileBuff, ulLen);
    if (ulWriteLen != ulLen)
    {
        free(pucRdVerFileBuff);
        pucRdVerFileBuff = NULL;
        close(fd);
        return BSP_ERROR;
    }

    free(pucRdVerFileBuff);
    pucRdVerFileBuff = NULL;
    close(fd);
    return iRetVal;
}
/**************************************************************************
* 函数名称： sf_erase
* 功能描述：
* 输入参数： void
* 输出参数： 无
* 返 回 值：
* ------------------------------------------------------
* 其它说明：
* 修改日期     版本号     修改人          修改内容
* 2014/5/29         V1.0              00086970                        创建
**************************************************************************/
ULONG sf_erase(ULONG ulOffset, ULONG ulLen)
{
    ULONG iRetVal = BSP_OK;
    ULONG ulSectorsize = 1024 * 1024;
    LONG ulSize = ulLen;
    ULONG ulFlashOffset = ulOffset;
    /*if ( ulLen > pow(2,25))
    {
    zte_printf_s("len must be smaller than 32M\n");
    return BSP_ERROR;
    }*/

    if (0 == ulLen)
    {
        zte_printf_s("Lenth can not be 0\n");
        return BSP_ERROR;
    }
    zte_printf_s("Offset 0x%x Lenth 0x%x  will be erased!!!\n", ulOffset, ulLen);

    while ((ulSize >= ulSectorsize) && (iRetVal == BSP_OK))
    {
        iRetVal = BspFlashErase(ulFlashOffset, ulSectorsize);
        ulSize -= ulSectorsize;
        ulFlashOffset += ulSectorsize;
    }
    if ((BSP_OK == iRetVal) && (ulSize > 0))
    {
        iRetVal = BspFlashErase(ulFlashOffset, ulSize);
    }

    return iRetVal;
}
/**************************************************************************
* 函数名称： sf
* 功能描述：
* 输入参数： void
* 输出参数： 无
* 返 回 值：
* ------------------------------------------------------
* 其它说明：
* 修改日期     版本号     修改人      修改内容
* 2014/5/29         V1.0              00086970                        创建
**************************************************************************/
VOID sf(void)
{
    zte_printf_s("sf help:\n");
    zte_printf_s("sf_read \"filename\",offset,len - read len bytes starting at offset to file\n");
    zte_printf_s("sf_write \"filename\",offset,len - write len bytes from file to flash at offset\n");
    zte_printf_s("sf_erase offset,len - erase len bytes from offset\n");
}
/**************************************************************************
* 函数名称： GetFtBsValue
* 功能描述：
* 输入参数： void
* 输出参数： 无
* 返 回 值：
* ------------------------------------------------------
* 其它说明：
* 修改日期     版本号     修改人      修改内容
* 2014/5/29         V1.0              00086970                        创建
**************************************************************************/
BOOL GetFtBsValue()
{
    int fd = 0;
    CHAR buf[4] = {0};
    int iRet = 0;
    fd = open("/bscfg", O_RDONLY, 0666);
    if (fd < 0)
    {
        // zte_printf_s("open ft bs cfg file error,please check noteftp's bs cmd\n");
        return s_uitobootflag;
    }

    iRet = zte_read_s(fd, buf, sizeof(buf), 4);
    if (4 != iRet)
    {
        zte_printf_s("read bs cfg file error.\n");
        close(fd);
        return s_uitobootflag;
    }
    if ((buf[0] == 'b') && (buf[1] == 's'))
    {
        if (buf[3] == '1')
        {
            s_uitobootflag = 0;
            /*cce1 bs之前启用了看门狗，为保证看门狗喂狗任务不停止*/
            // g_bStopFeedDog = FALSE;
        }
        else if (buf[3] == '2')
        {
            s_uitobootflag = 3;
            /*cce1 bs之前启用了看门狗，为保证看门狗喂狗任务不停止*/
            // g_bStopFeedDog = FALSE;
        }
    }
    close(fd);
    return s_uitobootflag;
}

#if defined(CONFIG_BOMID8)
/**************************************************************************
* 函数名称： SetHwInfo
* 功能描述： BomId 设置
*
* 输入参数： void
* 输出参数： 无
* 返 回 值： 模块组号
*
* -----------------------------------------------------------------------
* 其它说明：
*
* 修改日期     版本号     修改人      修改内容
* 2014/5/30         V1.0             00086970                        创建
**************************************************************************/
ULONG SetHwInfo(UCHAR ucMGId, UCHAR ucBGId, UCHAR ucBTId, UCHAR ucHCId)
{
    ULONG ulRet = BSP_ERROR;
    tBomIDInfoStruct bomid;
    UCHAR *addr;

    zte_memset_s(bomid.ucBomIdInfo, sizeof(bomid.ucBomIdInfo), 0, sizeof(bomid.ucBomIdInfo));
    bomid.ucBomIdInfo[0] = ucMGId;
    bomid.ucBomIdInfo[1] = ucBGId;
    bomid.ucBomIdInfo[2] = ucBTId;
    bomid.ucBomIdInfo[3] = ucHCId;

    /* Started by AICoder, pid:n9eberc57dh560b1422408bc70c3ec1c1b98be7c */
    #if defined(MASTER_MODULEID_ADDR) && defined(SLAVE_MODULEID_ADDR)
    if (CHIP_MASTER_TYPE == BootGetChipMsFlag())
    {
        addr = MASTER_MODULEID_ADDR;
    }
    else
    {
        addr = SLAVE_MODULEID_ADDR;
    }
    #else
    addr = MODULEID_ADDR;
    #endif
    ulRet = BspFlashWrite(addr, (UCHAR *)&bomid, sizeof(tBomIDInfoStruct));
    /* Ended by AICoder, pid:n9eberc57dh560b1422408bc70c3ec1c1b98be7c */
    zte_printf_s("Write Flash BomId area Success!\n");

    return ulRet;
}
#endif

/*该部分bomid组件因无论bomid8还是bomid16,康讯工装固定使用8bit，故均需提供*/
#if(defined(CONFIG_BOMID8) || defined(CONFIG_BOMID16))
/*****************************************************************************
* 函数名称   : BspGetModuleGroupId
* 功能描述   : 获取模组ID
* 读全局变量 : 无
* 写全局变量 : 无
* 输入参数   : 无
* 输出参数   : 无
* 返 回 值   : 硬件信息
* 其它说明   :
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 崔文会@2014-05-19 08:33:43, 拷贝并平台规范化
*----------------------------------------------------------------------------
*/
UCHAR BootGetModuleGroupId(VOID)
{
    ULONG ulRet2 = BSP_OK;
    UCHAR ucValue = 0;
    UCHAR ucValue2 = 0;

    #if(defined(MASTER_MODULEID_ADDR) && defined(SLAVE_MODULEID_ADDR))
    if (CHIP_MASTER_TYPE == BootGetChipMsFlag())
    {
        ulRet2 = BspFlashRead((MASTER_MODULEID_ADDR), &ucValue2, 1);
    }
    else
    {
        ulRet2 = BspFlashRead((SLAVE_MODULEID_ADDR), &ucValue2, 1);
    }
    #else
    ulRet2 = BspFlashRead((MODULEID_ADDR), &ucValue2, 1);
    #endif

    if ((BSP_OK != ulRet2) || (0xff == ucValue2))
    {
        dbgErr("%s>> GetModuleGroupId error!\n", __FUNCTION__);
        ucValue = 0;
    }
    else
    {
        ucValue = ucValue2;
    }
    return ucValue;
}
/*****************************************************************************
* 函数名称   : BspGetBoardGroupId
* 功能描述   : 获取单板组ID
* 读全局变量 : 无
* 写全局变量 : 无
* 输入参数   : 无
* 输出参数   : 无
* 返 回 值   : 硬件信息
* 其它说明   :
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 崔文会@2014-05-19 08:33:43, 拷贝并平台规范化
*----------------------------------------------------------------------------
*/
UCHAR BootGetBoardGroupId(VOID)
{
    ULONG ulRet2 = BSP_OK;
    UCHAR ucValue = 0;
    UCHAR ucValue2 = 0;
    #if(defined(MASTER_MODULEID_ADDR) && defined(SLAVE_MODULEID_ADDR))
    if (CHIP_MASTER_TYPE == BootGetChipMsFlag())
    {
        ulRet2 = BspFlashRead((MASTER_MODULEID_ADDR + 1), &ucValue2, 1);
    }
    else
    {
        ulRet2 = BspFlashRead((SLAVE_MODULEID_ADDR + 1), &ucValue2, 1);
    }
    #else
    ulRet2 = BspFlashRead((MODULEID_ADDR + 1), &ucValue2, 1);
    #endif
    if ((BSP_OK != ulRet2) || (0xff == ucValue2))
    {
        dbgErr("%s>> GetBoardGroupId error!\n", __FUNCTION__);
        ucValue = 0;
    }
    else
    {
        ucValue = ucValue2;
    }
    return ucValue;
}

/*****************************************************************************
* 函数名称   : BspGetBoardTypeId
* 功能描述   : 获取单板类型
* 读全局变量 : 无
* 写全局变量 : 无
* 输入参数   : 无
* 输出参数   : 无
* 返 回 值   : 硬件信息
* 其它说明   :
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 崔文会@2014-05-19 08:33:43, 拷贝并平台规范化
*----------------------------------------------------------------------------
*/
UCHAR BootGetBoardId(VOID)
{
    ULONG ulRet2 = BSP_OK;
    UCHAR ucValue = 0;
    UCHAR ucValue2 = 0;
    #if(defined(MASTER_MODULEID_ADDR) && defined(SLAVE_MODULEID_ADDR))
    if (CHIP_MASTER_TYPE == BootGetChipMsFlag())
    {
        ulRet2 = BspFlashRead((MASTER_MODULEID_ADDR + 2), &ucValue2, 1);
    }
    else
    {
        ulRet2 = BspFlashRead((SLAVE_MODULEID_ADDR + 2), &ucValue2, 1);
    }
    #else
    ulRet2 = BspFlashRead((MODULEID_ADDR + 2), &ucValue2, 1);
    #endif
    if ((BSP_OK != ulRet2) || (0xff == ucValue2))
    {
        dbgErr("%s>> GetBoardTypeId error!\n", __FUNCTION__);
        ucValue = 0;
    }
    else
    {
        ucValue = ucValue2;
    }
    return ucValue;
}
/*****************************************************************************
* 函数名称   : BspGetHardwareChangeId
* 功能描述   : 获取硬件变更ID
* 读全局变量 : 无
* 写全局变量 : 无
* 输入参数   : 无
* 输出参数   : 无
* 返 回 值   : 硬件信息
* 其它说明   :
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 崔文会@2014-05-19 08:33:43, 拷贝并平台规范化
*----------------------------------------------------------------------------
*/
UCHAR BootGetHardwareChangeId(VOID)
{
    ULONG ulRet2 = BSP_OK;
    UCHAR ucValue = 0;
    UCHAR ucValue2 = 0;
    #if(defined(MASTER_MODULEID_ADDR) && defined(SLAVE_MODULEID_ADDR))
    if (CHIP_MASTER_TYPE == BootGetChipMsFlag())
    {
        ulRet2 = BspFlashRead((MASTER_MODULEID_ADDR + 3), &ucValue2, 1);
    }
    else
    {
        ulRet2 = BspFlashRead((SLAVE_MODULEID_ADDR + 3), &ucValue2, 1);
    }
    #else
    ulRet2 = BspFlashRead((MODULEID_ADDR + 3), &ucValue2, 1);
    #endif
    if ((BSP_OK != ulRet2) || (0xff == ucValue2))
    {
        dbgErr("%s>> GetHardwareChaneId error!\n", __FUNCTION__);
        ucValue = 0;
    }
    else
    {
        ucValue = ucValue2;
    }
    return ucValue;
}
/**********************************************************************
* 函数名称:ULONG BoopGetModuleId()
* 功能描述:Boot获得模组号
* 输入参数:无
* 输出参数:
* 返 回 值:
* 其它说明:
* 修改日期        版本号     修改人          修改内容
* -----------------------------------------------
* 2015-10-22       V1.0       00086970             创建
***********************************************************************/
UCHAR BootGetModuleId(VOID)
{
    UCHAR ulModuleGroupId = 0;
    ulModuleGroupId = BootGetModuleGroupId();
    zte_printf_s(">>>ModuleGroupId is 0x%x\n", ulModuleGroupId);

    return ulModuleGroupId;
}
/**********************************************************************
* 函数名称:ULONG BootGetGroupId()
* 功能描述:Boot获得单板组号
* 输入参数:无
* 输出参数:
* 返 回 值:
* 其它说明:
* 修改日期        版本号     修改人          修改内容
* -----------------------------------------------
* 2015-10-22       V1.0       00086970             创建
***********************************************************************/
UCHAR BootGetGroupId(VOID)
{
    UCHAR ulBoardGroupId = 0;
    ulBoardGroupId = BootGetBoardGroupId();
    zte_printf_s(">>>BoardGroupId is 0x%x\n", ulBoardGroupId);

    return ulBoardGroupId;
}
/**********************************************************************
* 函数名称:ULONG BootGetBoardTypeId()
* 功能描述:Boot获得单板类号
* 输入参数:无
* 输出参数:
* 返 回 值:
* 其它说明:
* 修改日期        版本号     修改人          修改内容
* -----------------------------------------------
* 2015-10-22       V1.0       00086970             创建
***********************************************************************/
UCHAR BootGetBoardTypeId(VOID)
{
    UCHAR ulBoardTypeId = 0;
    ulBoardTypeId = BootGetBoardId();
    zte_printf_s(">>>ucBoardTypeId is 0x%x\n", ulBoardTypeId);

    return ulBoardTypeId;
}
/**********************************************************************
* 函数名称:ULONG BootGetHardChangeId()
* 功能描述:Boot获得单板类号
* 输入参数:无
* 输出参数:
* 返 回 值:
* 其它说明:
* 修改日期        版本号     修改人          修改内容
* -----------------------------------------------
* 2015-10-22       V1.0       00086970             创建
***********************************************************************/
UCHAR BootGetHardChangeId(VOID)
{
    UCHAR ulHardChangeId = 0;
    ulHardChangeId = BootGetHardwareChangeId();
    zte_printf_s(">>>HardChangeId is 0x%x\n", ulHardChangeId);

    return ulHardChangeId;
}
#endif

#if defined(CONFIG_BOMID8)
static VOID PrnHwInfo8(VOID)
{
    BootGetModuleId();
    BootGetGroupId();
    BootGetBoardTypeId();
    BootGetHardChangeId();
}
#endif
/*16bit id 兼容,数据规划
*      00h                 01h                 02h                 03h                04h                 05h
*module Group ID     Board Group ID      Boaed Type ID       Board Change ID     Hard Custom ID A   Hard Custom ID B
*    low 8bit            low 8bits           low 8bits           low 8bits           low 8bits           low 8bits
*
*      06h                 07h                 08h                 09h                0ah                 0bh
*module Group ID     Board Group ID      Boaed Type ID       Board Change ID     Hard Custom ID A   Hard Custom ID B
*    high 8bit           high 8bits          high 8bits          high 8bits          high 8bits          high 8bits
*
*      0ch                 0dh                 0eh                 0fh
*     CRC16               CRC16             Magic Number       Magic Number
*   high 8bit           low 8bits           high 8bits          low 8bits
*/
/*LS10X3A 编入８bits 16bits 接口
*从V4 4C/IC4起的新CPU只编入16bits接口
*/
#if defined(CONFIG_BOMID16)
static ULONG BootGetSingleHwInfo16(USHORT usIndex)
{
    ULONG ulRet = BSP_OK;
    UCHAR ucValLow = 0;
    UCHAR ucValHigh = 0;
    USHORT usVal = 0;
    if (usIndex > 5)
    {
        dbgErr("%s>> wrong Index error!\n", __FUNCTION__);
        return BSP_ERROR;
    }
    #if(defined(MASTER_MODULEID_ADDR) && defined(SLAVE_MODULEID_ADDR))
    if (CHIP_MASTER_TYPE == BootGetChipMsFlag())
    {
        ulRet |= BspFlashRead((MASTER_MODULEID_ADDR + usIndex), &ucValLow, 1);
        ulRet |= BspFlashRead((MASTER_MODULEID_ADDR + usIndex + 6), &ucValHigh, 1);
    }
    else
    {
        ulRet |= BspFlashRead((SLAVE_MODULEID_ADDR + usIndex), &ucValLow, 1);
        ulRet |= BspFlashRead((SLAVE_MODULEID_ADDR + usIndex + 6), &ucValHigh, 1);
    }
    #else
    ulRet |= BspFlashRead((MODULEID_ADDR + usIndex), &ucValLow, 1);
    ulRet |= BspFlashRead((MODULEID_ADDR + usIndex + 6), &ucValHigh, 1);
    #endif
    usVal = ucValLow | (ucValHigh << 8);

    if ((BSP_OK != ulRet) || (0xffff == usVal))
    {
        return BSP_ERROR;
    }

    return (ULONG)usVal;
}

static ULONG BootGetModuleGroupId16(void)
{
    ULONG ulRet = BSP_OK;

    ulRet = BootGetSingleHwInfo16(ModuleGroupId);
    if ((BSP_ERROR == ulRet))
    {
        dbgErr("%s>> GetModuleGroupId error!\n", __FUNCTION__);
    }

    return ulRet;
}

static ULONG BootGetBoardGroupId16(void)
{
    ULONG ulRet = BSP_OK;

    ulRet = BootGetSingleHwInfo16(BoardGroupId);
    if ((BSP_ERROR == ulRet))
    {
        dbgErr("%s>> GetBoardGroupId error!\n", __FUNCTION__);
    }

    return ulRet;
}

static ULONG BootGetBoardId16(void)
{
    ULONG ulRet = BSP_OK;

    ulRet = BootGetSingleHwInfo16(BoardTypeId);
    if ((BSP_ERROR == ulRet))
    {
        dbgErr("%s>> GetBoardTypeId error!\n", __FUNCTION__);
    }

    return ulRet;
}

static ULONG BootGetHardwareChangeId16(void)
{
    ULONG ulRet = BSP_OK;

    ulRet = BootGetSingleHwInfo16(HardChangeId);
    if ((BSP_ERROR == ulRet))
    {
        dbgErr("%s>> GetHardwareChaneId error!\n", __FUNCTION__);
    }

    return ulRet;
}

static ULONG BootGetHardwareCustomIdA(void)
{
    ULONG ulRet = BSP_OK;

    ulRet = BootGetSingleHwInfo16(HardCustomIdA);
    if ((BSP_ERROR == ulRet))
    {
        dbgErr("%s>> GetHardwareCustomIdA error!\n", __FUNCTION__);
    }

    return ulRet;
}

static ULONG BootGetHardwareCustomIdB(void)
{
    ULONG ulRet = BSP_OK;

    ulRet = BootGetSingleHwInfo16(HardCustomIdB);
    if ((BSP_ERROR == ulRet))
    {
        dbgErr("%s>> GetHardwareCustomIdB error!\n", __FUNCTION__);
    }

    return ulRet;
}

static ULONG BootGetModuleId16(void)
{
    ULONG ulModuleGroupId = 0;
    ulModuleGroupId = BootGetModuleGroupId16();
    zte_printf_s(">>>ModuleGroupId is 0x%x\n", ulModuleGroupId);

    return ulModuleGroupId;
}

static ULONG BootGetGroupId16(void)
{
    ULONG ulBoardGroupId = 0;
    ulBoardGroupId = BootGetBoardGroupId16();
    zte_printf_s(">>>BoardGroupId is 0x%x\n", ulBoardGroupId);

    return ulBoardGroupId;
}

static ULONG BootGetBoardTypeId16(void)
{
    ULONG ulBoardTypeId = 0;
    ulBoardTypeId = BootGetBoardId16();
    zte_printf_s(">>>ucBoardTypeId is 0x%x\n", ulBoardTypeId);

    return ulBoardTypeId;
}

static ULONG BootGetHardChangeId16(void)
{
    ULONG ulHardChangeId = 0;
    ulHardChangeId = BootGetHardwareChangeId16();
    zte_printf_s(">>>HardChangeId is 0x%x\n", ulHardChangeId);

    return ulHardChangeId;
}

static ULONG BootGetHardCustomIdA(void)
{
    ULONG ulHardCustomIdA = 0;
    ulHardCustomIdA = BootGetHardwareCustomIdA();
    zte_printf_s(">>>HardCustomIdA is 0x%x\n", ulHardCustomIdA);

    return ulHardCustomIdA;
}

static ULONG BootGetHardCustomIdB(void)
{
    ULONG ulHardCustomIdB = 0;
    ulHardCustomIdB = BootGetHardwareCustomIdB();
    zte_printf_s(">>>HardCustomIdB is 0x%x\n", ulHardCustomIdB);

    return ulHardCustomIdB;
}

static ULONG BootGetBomIdCRC(void)
{
    ULONG ulRet = BSP_OK;
    USHORT usVal = 0;

    #if(defined(MASTER_MODULEID_ADDR) && defined(SLAVE_MODULEID_ADDR))
    if (CHIP_MASTER_TYPE == BootGetChipMsFlag())
    {
        ulRet |= BspFlashRead((MASTER_MODULEID_ADDR + BOMID_CRC16_ADDR_OFFSET), (UCHAR *)&usVal, 2);
    }
    else
    {
        ulRet |= BspFlashRead((SLAVE_MODULEID_ADDR + BOMID_CRC16_ADDR_OFFSET), (UCHAR *)&usVal, 2);
    }
    #else
    ulRet |= BspFlashRead((MODULEID_ADDR + BOMID_CRC16_ADDR_OFFSET), (UCHAR *)&usVal, 2);
    #endif

    if (BSP_OK != ulRet)
    {
        return BSP_ERROR;
    }

    return (ULONG)usVal;
}

static ULONG BootGetBomIdMagicNum(void)
{
    ULONG ulRet = BSP_OK;
    USHORT usVal = 0;

    #if(defined(MASTER_MODULEID_ADDR) && defined(SLAVE_MODULEID_ADDR))
    if (CHIP_MASTER_TYPE == BootGetChipMsFlag())
    {
        ulRet |= BspFlashRead((MASTER_MODULEID_ADDR + BOMID_MAGIC_NUM_ADDR_OFFSET), (UCHAR *)&usVal, 2);
    }
    else
    {
        ulRet |= BspFlashRead((SLAVE_MODULEID_ADDR + BOMID_MAGIC_NUM_ADDR_OFFSET), (UCHAR *)&usVal, 2);
    }
    #else
    ulRet |= BspFlashRead((MODULEID_ADDR + BOMID_MAGIC_NUM_ADDR_OFFSET), (UCHAR *)&usVal, 2);
    #endif

    if (BSP_OK != ulRet)
    {
        return BSP_ERROR;
    }

    return (ULONG)usVal;
}

static ULONG BootGetBomId(tBomIDInfoStruct *bomid)
{
    ULONG ulRet = BSP_OK;

    #if(defined(MASTER_MODULEID_ADDR) && defined(SLAVE_MODULEID_ADDR))
    if (CHIP_MASTER_TYPE == BootGetChipMsFlag())
    {
        ulRet |= BspFlashRead(MASTER_MODULEID_ADDR, (UCHAR *)bomid, sizeof(tBomIDInfoStruct));
    }
    else
    {
        ulRet |= BspFlashRead(SLAVE_MODULEID_ADDR, (UCHAR *)bomid, sizeof(tBomIDInfoStruct));
    }
    #else
    ulRet |= BspFlashRead(MODULEID_ADDR, (UCHAR *)bomid, sizeof(tBomIDInfoStruct));
    #endif

    return ulRet;
}

static VOID PrnHwInfo16(VOID)
{
    BootGetModuleId16();
    BootGetGroupId16();
    BootGetBoardTypeId16();
    BootGetHardChangeId16();
    BootGetHardCustomIdA();
    BootGetHardCustomIdB();
}

ULONG SetSingleHwInfo16(USHORT usId, USHORT usIndex)
{
    ULONG ulRet = BSP_OK;
    if (usIndex > 5)
    {
        zte_printf_s("wrong ID Index\n");
        return BSP_ERROR;
    }
    if (BootGetBomIdMagicNum() == BOMID_MAGIC_NUM)
    {
        tBomIDInfoStruct bomid;
        bomid.usCRC16 = 0;
        BootGetBomId(&bomid);
        bomid.ucBomIdInfo[usIndex] = (usId & 0xff);
        bomid.ucBomIdInfo[usIndex + 6] = (usId >> 8);
        bomid.usCRC16 = CalculateCRC16(CRC_MASK, bomid.ucBomIdInfo, sizeof(bomid.ucBomIdInfo));
        bomid.usCRC16 = CRC_BIG_LITTLE_SWAP_USHORT(bomid.usCRC16); /*对齐BOMID16方案中的CRC高位放在flash低地址，转换后烧写*/
        bomid.usMagicNum = BOMID_MAGIC_NUM;

        #if(defined(MASTER_MODULEID_ADDR) && defined(SLAVE_MODULEID_ADDR))
        if (CHIP_MASTER_TYPE == BootGetChipMsFlag())
        {
            ulRet |= BspFlashWrite((MASTER_MODULEID_ADDR), (UCHAR *)&bomid, sizeof(tBomIDInfoStruct));
        }
        else
        {
            ulRet |= BspFlashWrite((SLAVE_MODULEID_ADDR), (UCHAR *)&bomid, sizeof(tBomIDInfoStruct));
        }
        #else
        ulRet |= BspFlashWrite((MODULEID_ADDR), (UCHAR *)&bomid, sizeof(tBomIDInfoStruct));
        #endif
    }
    else
    {
        zte_printf_s("MagicNum Error! Only Support change 16bits ID.\n");
        return BSP_ERROR;
    }

    return ulRet;
}

ULONG SetHwInfo16(USHORT usMGId, USHORT usBGId, USHORT usBTId, USHORT usHCId, USHORT usHCIda, USHORT usHCIdb)
{
    ULONG ulRet = BSP_ERROR;
    tBomIDInfoStruct bomid;

    bomid.ucBomIdInfo[ModuleGroupId] = (UCHAR)usMGId;
    bomid.ucBomIdInfo[ModuleGroupId + 6] = (UCHAR)(usMGId >> 8);
    bomid.ucBomIdInfo[BoardGroupId] = (UCHAR)usBGId;
    bomid.ucBomIdInfo[BoardGroupId + 6] = (UCHAR)(usBGId >> 8);
    bomid.ucBomIdInfo[BoardTypeId] = (UCHAR)usBTId;
    bomid.ucBomIdInfo[BoardTypeId + 6] = (UCHAR)(usBTId >> 8);
    bomid.ucBomIdInfo[HardChangeId] = (UCHAR)usHCId;
    bomid.ucBomIdInfo[HardChangeId + 6] = (UCHAR)(usHCId >> 8);
    bomid.ucBomIdInfo[HardCustomIdA] = (UCHAR)usHCIda;
    bomid.ucBomIdInfo[HardCustomIdA + 6] = (UCHAR)(usHCIda >> 8);
    bomid.ucBomIdInfo[HardCustomIdB] = (UCHAR)usHCIdb;
    bomid.ucBomIdInfo[HardCustomIdB + 6] = (UCHAR)(usHCIdb >> 8);

    bomid.usCRC16 = CalculateCRC16(CRC_MASK, bomid.ucBomIdInfo, sizeof(bomid.ucBomIdInfo));
    bomid.usCRC16 = CRC_BIG_LITTLE_SWAP_USHORT(bomid.usCRC16); /*对齐BOMID16方案中的CRC高位放在flash低地址，转换后烧写*/
    bomid.usMagicNum = BOMID_MAGIC_NUM;

    #if(defined(MASTER_MODULEID_ADDR) && defined(SLAVE_MODULEID_ADDR))
    if (CHIP_MASTER_TYPE == BootGetChipMsFlag())
    {
        ulRet = BspFlashWrite(MASTER_MODULEID_ADDR, (UCHAR*)&bomid, sizeof(tBomIDInfoStruct));
    }
    else
    {
        ulRet = BspFlashWrite(SLAVE_MODULEID_ADDR, (UCHAR*)&bomid, sizeof(tBomIDInfoStruct));
    }
    #else
    ulRet = BspFlashWrite(MODULEID_ADDR, (UCHAR*)&bomid, sizeof(tBomIDInfoStruct));
    #endif

    if (BSP_OK == ulRet)
    {
        zte_printf_s("Write Flash BomId area Success!\n");
    }
    else
    {
        zte_printf_s("Write Flash BomId area Failed!\n");
    }

    return ulRet;
}
#endif
/**************************************************************************
* 函数名称： PrnHwInfo
* 功能描述： BomId 打印
*
* 输入参数： void
* 输出参数： 无
* 返 回 值： 模块组号
*
* -----------------------------------------------------------------------
* 其它说明：
*
* 修改日期     版本号     修改人         修改内容
* 2014/5/26         V1.0              yam                        创建
**************************************************************************/
#if(defined(CONFIG_BOMID8) && defined(CONFIG_BOMID16)) /*LS10X3A 机型既有８bits　接口使用，又有16bits　接口使用，根据MagicNum做分支处理*/
VOID PrnHwInfo(VOID)
{
    if (BootGetBomIdMagicNum() == BOMID_MAGIC_NUM)
    {
        tBomIDInfoStruct bomid;
        USHORT valcrc16 = 0;
        BootGetBomId(&bomid);
        valcrc16 = CalculateCRC16(CRC_MASK, bomid.ucBomIdInfo, sizeof(bomid.ucBomIdInfo));
        valcrc16 = CRC_BIG_LITTLE_SWAP_USHORT(valcrc16); /*对齐BOMID16方案中的CRC高位放在flash低地址，转换后再与读取的值比较*/
        if (bomid.usCRC16 != valcrc16)
        {
            zte_printf_s("CRC ERROR!crc in flash is %#x,the calculated is %#x", bomid.usCRC16, valcrc16);
        }
        PrnHwInfo16();
    }
    else
    {
        PrnHwInfo8();
    }
}
#elif defined(CONFIG_BOMID16) /*从V4 4C/IC4起的新CPU只编入16bits接口*/
VOID PrnHwInfo(VOID)
{
    tBomIDInfoStruct bomid;
    USHORT valcrc16 = 0;
    BootGetBomId(&bomid);
    valcrc16 = CalculateCRC16(CRC_MASK, bomid.ucBomIdInfo, sizeof(bomid.ucBomIdInfo));
    valcrc16 = CRC_BIG_LITTLE_SWAP_USHORT(valcrc16); /*对齐BOMID16方案中的CRC高位放在flash低地址，转换后再与读取的值比较*/
    if (bomid.usCRC16 != valcrc16)
    {
        zte_printf_s("CRC ERROR!crc in flash is %#x,the calculated is %#x", bomid.usCRC16, valcrc16);
    }
    PrnHwInfo16();
}
#else
VOID PrnHwInfo(VOID) /*老CPU（除LS10X3A外）只使用８bits接口*/
{
    PrnHwInfo8();
}
#endif
/**************************************************************************
* 函数名称： LOCAL STATUS WaitUserInput(ULONG ulTimeout)
* 功能描述： 等待一段时间提示用户在此时间内可以输入
* 输入参数： ulTimeout: 超时设置
* 输出参数：
* 返 回 值： FALSE: 自动运行
*            TRUE: 停住，进行菜单选择
* 其它说明： 加载成功不会返回
* 修改日期    版本号     修改人         修改内容
* -----------------------------------------------
* 2007-12-26   V1.0      张爱卿          创建
**************************************************************************/
/* Started by AICoder, pid:xd9e2hca12paee614a9f08177036cc3706e8cbc5 */
static STATUS WaitUserInputForNormal(ULONG ulTimeout)
{
    unsigned long long ulBstopTime;
    ULONG ulTimeLeft;
    unsigned long long ulTimeMarker;

    ulBstopTime = tick64Get() + (unsigned long long)sysClkRateGet() * ulTimeout;
    ulTimeMarker = tick64Get() + (unsigned long long)sysClkRateGet();
    ulTimeLeft = ulTimeout;

    zte_printf_s("\r%d  ", ulTimeLeft);
    #ifdef VOS_LINUX /* #ifndef VOS_LINUX */
    fflush(stdout);
    #endif /* #ifndef VOS_LINUX */
    while ((tick64Get() < ulBstopTime) && (1 == s_uitobootflag) && (1 == GetFtBsValue()))
    {
        if ((tick64Get() > (ulTimeMarker - 100)) && (tick64Get() < (ulTimeMarker + 100)))
        {
            ulTimeMarker = tick64Get() + (unsigned long long)sysClkRateGet();
            zte_printf_s("\r%d  ", --ulTimeLeft);
            #ifdef VOS_LINUX /* #ifdef VOS_LINUX */
            fflush(stdout);
            #endif /* #ifdef VOS_LINUX */
        }
        taskDelay(sysClkRateGet());
    }
    if (1 == s_uitobootflag)
    {
        zte_printf_s("\r%d  : %llu", 0, ulTimeLeft);
        #ifdef VOS_LINUX /* #ifndef VOS_LINUX */
        fflush(stdout);
        #endif /* #ifndef VOS_LINUX */
    }
    return s_uitobootflag;
}
/* Ended by AICoder, pid:xd9e2hca12paee614a9f08177036cc3706e8cbc5 */
/**********************************************************************
* 函数名称：Bsp_system
* 功能描述：通过shell执行参数中的shell 命令
* 输入参数：待执行的命令行字符串
* 输出参数：无
* 返 回 值：子进程退出码
* 其它说明：该函数主要为是为了解决Linux下C库自带的system的几个问题(其它系统下直
            接转发给system函数):用户进程不可能抓到任务0的退出

1、内核的overcommit_memory检测导致system->fork失败
2、system创建的子进程导致产品进程监控不准确
3、子进程监控CatchChildExit->waitpid导致system->waitpid失败
4、bpn在config.h定义了#define system  Bsp_System  替换system

* 修改日期   修改人        修改内容
* ---------------------------------------------------------------------
* 2011/02/23        liwf                        创建
************************************************************************/
/*lint -e{725,614,506}*/
int Bsp_System(const char *command)
{
    const char * const SHELL_PATH = "/bin/sh"; /* Path of the shell.  */
    const char * const SHELL_NAME = "sh";      /* Name to give it.  */
    pid_t forked_pid;
    int status = 0;
    int myerrno = 0; /*当子进程正确返回时，该值无意义*/

    static pthread_mutex_t system_lock = PTHREAD_MUTEX_INITIALIZER;

    if (!command)
    {
        return -1;
    }
    /*由于线程可以通过pthread_cancel杀死，所以这里注册对互斥锁的释放。
    这里没有使用Vos_CreateProcessSem是为了减少对Vos系统初始化的依赖，
    从而可以供BSP使用。*/
    // pthread_cleanup_push((void (*)(void *)) pthread_mutex_unlock, (void *) &system_lock);
    if ((status = pthread_mutex_lock(&system_lock)) != 0)
    {
        dbgErr("%s %d: pthread_mutex_lock error, status:%d\n", __FUNCTION__, __LINE__, status);
        return status;
    }

    /* 内核中的overcommit_memory 策略可能导致占用了大量内存的MGR fork失败，所以
    这里通过vfork绕过此检测就不会在fork时进行页表拷贝以及影响到父进程vma的属
    性,用vfork后，父子进程还是共享虚拟内存空间，在子进程执行execv后，会给子
    进程重新映射vma，这时它之前与父进程共享的vma不再生效了*/
    if ((pid_t)0 == (forked_pid = vfork()))
    {
        /* Child side.  */
        const char *new_argv[4] =
        {
            SHELL_NAME,
            "-c",
            command,
            NULL,
        };
        /*这个值应该在CatchChildExit中使用, 一方面是提高 "产品进程" 退出监控的
        准确性另一方面保证这里可以通过waitpid接收到子进程的退出状态,不使用数
        组的原因是为了减少多线程可能引起的竞争
        由于我们创建的是子进程，所以使用pid(不是tid，尽管两个在数值上是相等的)*/
        /* pid_t systemed_child = getpid();*/
        /* zte_printf_s("%s systemed_child %d \n",__FUNCTION__,systemed_child);*/

        /* 由于/bin/sh是始终存在的，这里就不检测返回值了 */
        (void)execve(SHELL_PATH, (char *const *)new_argv, __environ);
        exit(127); /*C库用的是_exit，但是我觉得exit更合理?*/
    }
    else if (forked_pid < (pid_t)0)
    {
        /* The fork failed.  */
        status = -1;
        myerrno = errno;

        /* perror("In Func""fored -1 ");*/
    }
    else
        /* Parent side.  */
    if (waitpid(forked_pid, &status, 0) != forked_pid)
    {
        status = -1;
        myerrno = errno;
        /* perror("In Func"  "waitpid");*/
    }

    pthread_mutex_unlock(&system_lock);

    errno = myerrno;

    return status;
}

/* Started by AICoder, pid:617c2qc0203cfb5144c10b9210581213b6c44210 */
void ChangeMacAddr(void)
{
    CHAR cmdBuf[256];
    zte_memset_s(cmdBuf, sizeof(cmdBuf), 0, sizeof(cmdBuf));
    system("ifconfig eth0 down");
    zte_snprintf_s(cmdBuf, sizeof(cmdBuf), "ifconfig eth0 hw ether %02x:%02x:%02x:%02x:%02x:%02x",
                   LFecEnetAddr[0], LFecEnetAddr[1], LFecEnetAddr[2],
                   LFecEnetAddr[3], LFecEnetAddr[4], LFecEnetAddr[5]);
    system(cmdBuf);
    zte_snprintf_s(cmdBuf, sizeof(cmdBuf), "ifconfig eth0 %d.%d.%d.%d",
                   LFecIpAddr[0], LFecIpAddr[1], LFecIpAddr[2], LFecIpAddr[3]);
    system(cmdBuf);
    system("ifconfig eth0 up");
}
/* Ended by AICoder, pid:617c2qc0203cfb5144c10b9210581213b6c44210 */

ULONG BspEthSend(volatile void *packet, int length)
{
    int iRetVal = 0;
    iRetVal = send(iSocket, (VOID *)packet, length, 0);
    return iRetVal;
}

VOID BspRecvPktFromPCTask()
{
    int iRetVal = 0;
    int i = 0;
    UCHAR byCheckSum = 0;
    UCHAR *pbyMsg = NULL;
    while (0 == s_ucGetMacIpSetFlag)
    {
        iRetVal = recv(iSocket, (VOID *)gucRecBuf, 4096, 0);
        if (iRetVal > 0)
        {
            pbyMsg = gucRecBuf;
            /*zte_printf_s("pbyMsg = 0x%x - 0x%x -0x%x - 0x%x -0x%x - 0x%x - 0x%x  -0x%x  -0x%x  -0x%x  - \n", \
                    pbyMsg[0], pbyMsg[1],pbyMsg[2], pbyMsg[3],pbyMsg[4], pbyMsg[5], pbyMsg[14], pbyMsg[15], pbyMsg[16], pbyMsg[17]);*/
            if (memcmp(aMacIpSetFlag, (gucRecBuf + 14), 2) == 0)
            {
                zte_printf_s("\n str Compare1 OK");
                if (s_ucGetMacIpSetFlag == 0)
                /*检查重新配置完成标识*/
                {
                    zte_printf_s("\nstrCompare2 OK");
                    byCheckSum = 0;
                    for (i = 0; i < 39; i++)
                    {
                        /*计算CheckSun*/
                        byCheckSum = byCheckSum + *pbyMsg++;
                    }
                    pbyMsg = gucRecBuf;
                    zte_printf_s("\nbyCheckSum is 0x%x\n", byCheckSum);
                    if (byCheckSum == pbyMsg[39])
                    {
                        /*CheckSum ok ;是主控板发来的配置本板的MAC及IP地址的配置信息*/
                        zte_memcpy_s((&LFecEnetAddr[0]), sizeof(LFecEnetAddr), gucRecBuf, 6);          /*获取新MAC*/
                        zte_memcpy_s((&LFecIpAddr[0]), sizeof(LFecIpAddr), gucRecBuf + 16, 4);         /*获取新IP*/
                        zte_memcpy_s((&aBSPPIIIIpAddr[0]), sizeof(aBSPPIIIIpAddr), gucRecBuf + 20, 4); /*获取主控 IP*/
                        zte_memcpy_s((&aEnvironment[0]), sizeof(aEnvironment), gucRecBuf + 24, 4);     /*获取环境号*/
                        zte_memcpy_s((&BSPBOARDID), sizeof(BSPBOARDID), gucRecBuf + 28, 1);            /*获取BOARD ID*/
                        zte_printf_s("\nSuccess Get MAC and Ip Set\n");
                        SetEthProMode(0);
                        ChangeMacAddr(); /*根据新的MAC、IP从新定配置IP地址*/
                        gpucmacMsg = gucRecBuf; /*保存收到的MAC包*/
                        s_ucGetMacIpSetFlag = 1;
                    }
                    else
                    {
                        /*CheckSun ERROR*/
                        zte_printf_s("\nCrc ERROR byCheckSum=0x%x,gucRecBuf[39]=0x%x OK", byCheckSum, gucRecBuf[39]);
                    }
                }
            }
        }
    }
}

int get_iface_index(int fd, const char *interface_name)
{
    struct ifreq ifr;
    zte_memset_s(&ifr, sizeof(ifr), 0, sizeof(ifr));
    zte_strncpy_s(ifr.ifr_name, sizeof(ifr.ifr_name), interface_name, strlen(interface_name));
    if (ioctl(fd, SIOCGIFINDEX, &ifr) == -1)
    {
        return (-1);
    }
    return ifr.ifr_ifindex;
}
ULONG BootTestVersionDownLoadInit()
{
    /*lint -e{641}*/
    if ((iSocket = socket(PF_PACKET, SOCK_RAW, htons(ETH_P_ALL))) < 0)
    {
        zte_printf_s("create raw socket error\n");
        return BSP_ERROR;
    }
    zte_memset_s(&addr, sizeof(addr), 0, sizeof(addr));
    addr.sll_family = AF_PACKET;
    addr.sll_ifindex = get_iface_index(iSocket, "eth0"); /*很重要; */
    addr.sll_protocol = htons(ETH_P_ALL);
    if (bind(iSocket, (struct sockaddr*)&addr, sizeof(addr)) < 0)
    {
        zte_printf_s("raw socket bind err\n");
        return BSP_ERROR;
    }
    taskSpawn("tRecvPktFromPC", 111, 0, 10000,
              (FUNCPTR)BspRecvPktFromPCTask, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
    return BSP_OK;
}
/******************************************************************************
函数名  ：int CreatRruCfgIniFile(void)
功能    ：在中试版本加载前,先判断如果没有RRUCFG.INI文件
         就创建一个并写定CPU_FLAG为0
引用全局变量：
输入参数说明：
返回值说明  ：
附加说明    ：
****************************************************************/
int CreatRruCfgIniFile(void)
{
    INT32 fd = 0;
    UINT len = 0;
    unsigned char ucCnt = 0;
    /* Started by AICoder, pid:fa5cfy8b11d899114cde098060d1000df4d6be59 */
    T_OamCfgParam tLoadCfgParam = {
        .acName = {0},
        .cFlag = 0,
        .cValue = 0,
        .cEnd = 0
    };
    /* Ended by AICoder, pid:fa5cfy8b11d899114cde098060d1000df4d6be59 */
    fd = open(RTRDOWNCFGFILE, O_RDWR);
    if (fd < 0)
    {
        /*如果打开文件失败或读文件失败在指定路径创建文件*/
        fd = open(RTRDOWNCFGFILE, (O_CREAT | O_RDWR), 0644);
        zte_printf_s("### fopen RTRDOWNCFGFILE wb\n");
        if (fd < 0)
        {
            zte_printf_s("Create RTRDOWNCFGFILE Error!\n");
            return 2;
        }
        /*初始化数据,注意名字长度*/
        for (ucCnt = 0; ucCnt < 30; ucCnt++)
        {
            tLoadCfgParam.acName[ucCnt] = 0;
        }
        zte_strncpy_s((char *)tLoadCfgParam.acName, sizeof(tLoadCfgParam.acName), (const char *)FLAG_RTRVER, strlen(FLAG_RTRVER));
        tLoadCfgParam.cFlag = '=';
        tLoadCfgParam.cValue = '0';
        tLoadCfgParam.cEnd = '\n'; /*由'\0' 改为'\n'换行符, By Zengx, 2011.07.22 */
        zte_printf_s("###  TLoadCfgParam chValue=%x\n", tLoadCfgParam.cValue);
        if (0 != lseek(fd, 0, SEEK_SET)) /* 0530 yc */
        {
            zte_printf_s("lseek RRUCFG.INI SEEK_SET ERR！");
            close(fd);
            return BSP_ERROR;
        }
        len = write(fd, (char *)(&tLoadCfgParam), FLAG_CPUVER_LEN);
        if (len < FLAG_CPUVER_LEN)
        {
            zte_printf_s("write only %d bytes to file RTRDOWNCFGFILE,break...\n", len);
            close(fd);
            return 3;
        }
        close(fd);
    }
    else
    {
        zte_printf_s("RRUCFG.INI exist!\n");
        close(fd);
        return 1;
    }

    return 0;
}

#ifdef CONFIG_ZXW11200_NTN
/* Started by AICoder, pid:8272c0d4698d4093a75daef1a2ce7ad2 */
#define MTD_INFO_LEN 256

static int BootGetMtdInfo(T_FlashInfo *flash_info)
{
    FILE *fp = fopen("/proc/mtd", "r");
    if (fp == NULL) 
    {
        printf("Failed to open /proc/mtd\n");
        return -1;
    }

    char buffer[MTD_INFO_LEN];
    int mtd_num = 0;
    int ret = 0;
    while (fgets(buffer, MTD_INFO_LEN, fp)) 
    {
        if (sscanf(buffer, "mtd%*d: %x", &flash_info->atPartitionMap[mtd_num].ulPartitionSize) == 1) 
        {
            flash_info->ulFlashSize += flash_info->atPartitionMap[mtd_num].ulPartitionSize;
            ret = sprintf_s(flash_info->atPartitionMap[mtd_num].acPartitionName, BLOCK_NAME_LEN, "/dev/mtd%d", mtd_num);
            if(ret < 0)
            {
                zte_printf_s("sprintf_s ret'%d max'%d!", ret, BLOCK_NAME_LEN);
                fclose(fp);
                return BSP_ERROR;
            }
            flash_info->atPartitionMap[mtd_num].ulPartitionOffset = (mtd_num == 0) ? 0 : (flash_info->atPartitionMap[mtd_num-1].ulPartitionOffset + flash_info->atPartitionMap[mtd_num-1].ulPartitionSize);
            mtd_num++;
            if (mtd_num >= MAX_BLOCK_NUM) 
            {
                zte_printf_s("Flash mtd num error!\n");
                break;
            }
        }
    }

    flash_info->ulSectorSize = FLASH_SECTOR_SIZE;
    fclose(fp);
    flash_info->ulPartitionNum = mtd_num;
    return mtd_num;
}
/* Ended by AICoder, pid:8272c0d4698d4093a75daef1a2ce7ad2 */

ULONG BootFlashInit(VOID)
{
    ULONG retCode = BSP_OK;
    T_FlashInfo tFlashCfg;
   
    zte_memcpy_s(&tFlashCfg, sizeof(T_FlashInfo), 0, sizeof(T_FlashInfo));
    BootGetMtdInfo(&tFlashCfg);
    /*lint +e785*/
    retCode = BspFlashModuleInit(&tFlashCfg);
    zte_memcpy_s(&boot_tFlashInfo, sizeof(T_FlashInfo), &tFlashCfg, sizeof(T_FlashInfo));
    BspFlashShowCfg();

    return retCode;
}
#else
/*****************************************************************************
* 函数名称   : BootFlashInit(*)
* 功能描述   : flash初始化
* 读全局变量 : 无
* 写全局变量 : 无
* 输入参数   : 无
* 输出参数   : 无
* 返 回 值   : BSP_OK或者错误码
* 其它说明   : 无
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), zhaoyun@2014-5-27 14:07:25 创建
*----------------------------------------------------------------------------
*/

ULONG BootFlashInit(VOID)
{
    INT fd;
    ULONG retCode = BSP_OK;
    ULONG ulFlashSize = 0;

    #ifdef CONFIG_SECURITY
    ULONG ulmtdOffset[FLASH_PARTITION_NUM] = {0, 0, 0, 0};
    ULONG ulmtdSize[FLASH_PARTITION_NUM] = {0, 0, 0, 0};
    CHAR* p_acPartitionName[FLASH_PARTITION_NUM] = {"/dev/mtd0", "/dev/mtd1", "/dev/mtd2", "/dev/mtd3"};
    #else
    ULONG ulmtdOffset[FLASH_PARTITION_NUM] = {0, 0, 0};
    ULONG ulmtdSize[FLASH_PARTITION_NUM] = {0, 0, 0};
    CHAR* p_acPartitionName[FLASH_PARTITION_NUM] = {"/dev/mtd0", "/dev/mtd1", "/dev/mtd2"};
    #endif
    UCHAR i = 0;

    for (i = 0; i < FLASH_PARTITION_NUM; i++)
    {
        fd = open(p_acPartitionName[i], O_RDWR);
        if (fd < 0)
        {
            if (FILESYSTEM == i)
            {
                zte_printf_s("board maybe without mtd%d for filesystem,just break\n", i);
                break;
            }
            zte_printf_s("open %s error \n", p_acPartitionName[i]);
            return BSP_ERROR;
        }
        else
        {
        // zte_printf_s("open %s  OK! fd=%d \n",p_acPartitionName[i],fd);
        }

        if (0 != lseek(fd, 0, SEEK_SET))
        {
            zte_printf_s("lseek /dev/mtd%d to begin error \n", i);
            close(fd);
            return BSP_ERROR;
        }
        ulmtdSize[i] = lseek(fd, 0, SEEK_END);
        if (0 == ulmtdSize[i])
        {
            zte_printf_s("lseek /dev/mtd%d to end error \n", i);
            close(fd);
            return BSP_ERROR;
        }
        close(fd);
    }
    ulmtdOffset[BOOT] = 0;
    ulmtdOffset[RESVERD] = ulmtdOffset[BOOT] + ulmtdSize[BOOT];

    #ifdef CONFIG_SECURITY
    ulmtdOffset[SEC] = ulmtdOffset[RESVERD] + ulmtdSize[RESVERD];
    ulmtdOffset[FILESYSTEM] = ulmtdOffset[SEC] + ulmtdSize[SEC];
    #else
    ulmtdOffset[FILESYSTEM] = ulmtdOffset[RESVERD] + ulmtdSize[RESVERD];
    #endif

    ulFlashSize = ulmtdOffset[FILESYSTEM] + ulmtdSize[FILESYSTEM];
    // zte_printf_s("ulFlashSize% = 0x%x\n",ulFlashSize);
    if (ulFlashSize < ulmtdOffset[FILESYSTEM])
    {
        zte_printf_s("Flash partition error!\n");
        zte_printf_s("dev          offset        size\n");
        for (i = 0; i < FLASH_PARTITION_NUM; i++)
        {
            zte_printf_s("%s    %8.8x    %8.8x\n", p_acPartitionName[i], ulmtdOffset[i], ulmtdSize[i]);
        }
        return BSP_ERROR;
    }

    /*lint -e785*/
    T_FlashInfo tFlashCfg =
    {
        ulFlashSize,
        FLASH_SECTOR_SIZE, /* sector size 256K */
        // FLASH_PARTITION_NUM,      /* FLASH包含的分区数量 */
        i,
        {
            {"/dev/mtd0", ulmtdOffset[BOOT], ulmtdSize[BOOT]},
            {"/dev/mtd1", ulmtdOffset[RESVERD], ulmtdSize[RESVERD]},

            #ifdef CONFIG_SECURITY
            {"/dev/mtd2", ulmtdOffset[SEC], ulmtdSize[SEC]},
            {"/dev/mtd3", ulmtdOffset[FILESYSTEM], ulmtdSize[FILESYSTEM]},
            #else
            {"/dev/mtd2", ulmtdOffset[FILESYSTEM], ulmtdSize[FILESYSTEM]},
            #endif

        }
    };
    /*lint +e785*/
    retCode = BspFlashModuleInit(&tFlashCfg);
    zte_memcpy_s(&boot_tFlashInfo, sizeof(T_FlashInfo), &tFlashCfg, sizeof(T_FlashInfo));
    BspFlashShowCfg();

    return retCode;
}
#endif

int BootSelectWork(void)
{
    FUNCPTR entry = 0;
    int iRetVal;
    const char *pchBootFile = "/ata/BSP/cur.swv";
    zte_printf_s("Start to load  %s\n", pchBootFile);

    /*down load version*/
    iRetVal = ldCertainFile(pchBootFile, &entry);

    if (ERROR == iRetVal)
    {
        zte_printf_s("Load /ata/BSP/cur.swv failed!!\n");
        return ERROR;
    }
    return BSP_OK;
}

/* ******************************************************************************
* 函数名称： VOID BootDownLoadVersion(VOID)
* 功能描述：
* 输入参数： 无
* 输出参数： 无
* 返 回 值： ERROR: 加载失败
*            OK: 加载成功
* 其它说明：
* 修改日期    版本号     修改人         修改内容
* -----------------------------------------------
* 2007-12-26   V1.0      张爱卿          创建
********************************************************************************* */
static INT BootDownLoadVersion(VOID)
{

    INT iRetVal = 0;
    /*GetBootLineCheckValue();*/
    /* Started by AICoder, pid:m984e89f9ake3bc14d6009ab50675708d385de40 */
    unsigned char acCheckInfo[20] = {0xf2, 0xf2, 0xf5, 0};
    unsigned char acCheckValue[20] = {0xf2, 0xf2, 0xf5, 0};
    /* Ended by AICoder, pid:m984e89f9ake3bc14d6009ab50675708d385de40 */
    /*添加模块组号和单板组号20110721 yc*/
    SHORT sMoudleId = 0;
    SHORT sGroupId = 0;
    CHAR acModuleId[10] = {0}; /*模块组号*/
    CHAR acGroupId[10] = {0}; /*单板识别号*/
    UCHAR cmdBuf[256] = {0};
    int retsystem = 0;
    int fd = 0;
    int i = 0;
    struct stat tStat;
    ULONG ulFileSize;
    UCHAR *pucRdVerFileBuff = NULL;
    /* Started by AICoder, pid:jbf3792b0f5508a1446609f35027bd4346575a94 */
    for (i = 0; i < sizeof(acCheckInfo); i++)
    {
        acCheckInfo[i] &= 0x7f;
    }

    for (i = 0; i < sizeof(acCheckValue); i++)
    {
        acCheckValue[i] &= 0x7f;
    }

    sMoudleId = BootGetModuleId();
    sGroupId = BootGetGroupId();

    zte_printf_s("MoudleId and GroupId  %02x/%02x\n", sMoudleId, sGroupId);

    zte_snprintf_s(acModuleId, sizeof(acModuleId), "%02x", sMoudleId);
    zte_snprintf_s(acGroupId, sizeof(acGroupId), "%02x", sGroupId);

    zte_strncat_s((CHAR *)acCheckInfo, sizeof(acCheckInfo), acModuleId, zte_strnlen_s(acModuleId, sizeof(acModuleId)));
    zte_strncat_s((CHAR *)acCheckInfo, sizeof(acCheckInfo), acGroupId, zte_strnlen_s(acGroupId, sizeof(acGroupId)));

    zte_strncat_s((CHAR *)acCheckValue, sizeof(acCheckValue), acModuleId, zte_strnlen_s(acModuleId, sizeof(acModuleId)));
    zte_strncat_s((CHAR *)acCheckValue, sizeof(acCheckValue), acGroupId, zte_strnlen_s(acGroupId, sizeof(acGroupId)));

    zte_printf_s("ftp %s/%s\n", (UCHAR *)acCheckInfo, (UCHAR *)acCheckValue);

    system("echo 3 > /proc/sys/net/ipv4/tcp_syn_retries");

    #if defined(CONFIG_ZX2112XX) || defined(CONFIG_ZX211412)
    if (BootGetDownloadFlag() == 0)
    {
        zte_snprintf_s((char *)cmdBuf, sizeof(cmdBuf), "ftpget -u %s -p %s 199.33.33.1 cur.swv cur.swv", (UCHAR *)acCheckInfo, (UCHAR *)acCheckValue);
    }
    else
    {
        zte_snprintf_s((char *)cmdBuf, sizeof(cmdBuf), "ftpget -u %s -p %s 198.33.33.100 cur.swv cur.swv", (UCHAR *)acCheckInfo, (UCHAR *)acCheckValue);
    }
    #else
    zte_snprintf_s((char *)cmdBuf, sizeof(cmdBuf), "ftpget -u %s -p %s 199.33.33.1 cur.swv cur.swv", (UCHAR *)acCheckInfo, (UCHAR *)acCheckValue);
    #endif

    retsystem = system((char *)cmdBuf);

    zte_printf_s("cmdBuf =%s\n", cmdBuf);
    zte_printf_s("retsystem=%d, errno=%d\n", retsystem, errno);

    system("echo 6 > /proc/sys/net/ipv4/tcp_syn_retries");
    /* Ended by AICoder, pid:jbf3792b0f5508a1446609f35027bd4346575a94 */
    #if 1
    if (0 != retsystem)
    {
        zte_printf_s("ftpget err in %s\n", __FUNCTION__);
        #if(defined(CONFIG_ZX2112XX))
        BootWatchDogInit(); /*WatchDogTime set at max value which is 42s for ZX2112XX*/
        #endif
        return ERROR;
    }
    // system("tftp -gr cur.swv 192.254.1.1");
    #endif
    /* 读取版本文件内容 */
    fd = open("cur.swv", O_RDONLY, 0666);
    if (ERROR == fd)
    {
        zte_printf_s("Can not open version file!\n");
        /*设置版本文件打开失败错误,UCHG00156197,zhangaiq,20090421*/
        BspSetCpuVerErrReason(g_ucRunVer, BSP_VER_OPEN_ERROR);
        return ERROR;
    }
    /*获取文件长度*/
    if (ERROR == fstat(fd, &tStat))
    {
        zte_printf_s("Can not open version file!\n");
        close(fd);
        return ERROR;
    }

    ulFileSize = tStat.st_size;

    /* 申请读版本文件缓存 */
    /* Started by AICoder, pid:l6bf2lb3dc3d61a145ce0a5e30b262172001f53d */
    pucRdVerFileBuff = (UCHAR *)malloc(ulFileSize);
    if (pucRdVerFileBuff == NULL)
    {
        zte_printf_s("version file size %u\n", ulFileSize);
        zte_printf_s("malloc read version file buffer failed!\n");
        close(fd);
        return ERROR;
    }

    iRetVal = zte_read_s(fd, pucRdVerFileBuff, ulFileSize, ulFileSize);
    zte_printf_s("ulFileSize is 0x%x, pucRdVerFileBuff is 0x%p\n", ulFileSize, pucRdVerFileBuff);
    /* Ended by AICoder, pid:l6bf2lb3dc3d61a145ce0a5e30b262172001f53d */
    if ((ULONG)iRetVal != ulFileSize)
    {
        zte_printf_s("Version file read error\n");
        close(fd);
        free(pucRdVerFileBuff);
        pucRdVerFileBuff = NULL;
        /*设置版本文件读取失败错误,UCHG00156197,zhangaiq,20090421*/
        BspSetCpuVerErrReason(g_ucRunVer, BSP_VER_READ_ERROR);
        return ERROR;
    }
    close(fd);

    iRetVal = ldFileFromRam(pucRdVerFileBuff, ulFileSize);
    if (BSP_OK != iRetVal)
    {
        /* 版本解压缩失败,告警灯闪6下,1hz*/
        // BootFtpChkLed(6);
        free(pucRdVerFileBuff);
        pucRdVerFileBuff = NULL;
        /*设置版本解压缩失败错误,UCHG00156197,zhangaiq,20090421*/
        BspSetCpuVerErrReason(g_ucRunVer, BSP_VER_UNCMP_ERROR);
        return ERROR;
    }
    free(pucRdVerFileBuff);
    pucRdVerFileBuff = NULL;

    return OK;
}
#if (defined(CONFIG_ZYNQMPSOC) || defined(CONFIG_ZX2112XX) || defined(CONFIG_ZX211412)|| defined(CONFIG_ZX211413)|| defined(CONFIG_ZXW11200))
/* ******************************************************************************
* 函数名称： LOCAL STATUS ldFileDownload()
* 功能描述：下载cpu版本并加载版本
* 访问的表：
* 修改的表：
* 输入参数：
* 输出参数：
* 返 回 值： ERROR: 加载失败
*            OK: 加载成功
* 其它说明： flash保护区加载版本文件
* 修改日期    版本号     修改人         修改内容
* -----------------------------------------------
* 2017-03-17         V1.0              00086970            创建
**********************************************************************************/
STATUS ldFileDownload()
{
    INT iRetVal = 0;
    /*GetBootLineCheckValue();*/
    UCHAR cmdBuf[256] = {0};
    int retsystem = 0;
    int fd = 0;
    int i = 0;
    struct stat tStat;
    ULONG ulFileSize;
    UCHAR *pucRdVerFileBuff = NULL;
    /* Started by AICoder, pid:j59b5a258by179414f130965e011a6049365f629 */
    unsigned char acCheckInfo[20] = {0xfa, 0xf4, 0xe5, 0}; /*0x80|value*/
    unsigned char acCheckValue[20] = {0xfa, 0xf4, 0xe5, 0};   /*0x80|value*/
    /*zte&zte*/
    for (i = 0; i < sizeof(acCheckInfo); i++)
    {
        acCheckInfo[i] = acCheckInfo[i] & 0x7f;
    }
    for (i = 0; i < sizeof(acCheckValue); i++)
    {
        acCheckValue[i] = acCheckValue[i] & 0x7f;
    }
    /* Ended by AICoder, pid:j59b5a258by179414f130965e011a6049365f629 */
    /*设置保护区启动标志*/
    zte_printf_s("\n*************************************************\n");
    zte_printf_s("\n*******download version......********\n");
    zte_printf_s("\n*************************************************\n");

    g_ucRunVer = BSP_PROVERSION;
    BspSetCpuVerErrReason(g_ucRunVer, 0);

    /* Started by AICoder, pid:37796h33dbkc8d1140330947a092f71ab7f84e35 */
    #if defined(CONFIG_ZYNQMPSOC)
    if (zynqmpsoc_get_appid() == 0x3)
    {
        zte_snprintf_s((char *)cmdBuf, sizeof(cmdBuf), "ftpget -u %s -p %s 198.33.33.100 cpu.swv /tmp/cpu.swv", (CHAR *)acCheckInfo, (CHAR *)acCheckValue);
    }
    else
    {
        zte_snprintf_s((char *)cmdBuf, sizeof(cmdBuf), "tftp -gr cpu.swv 198.33.33.100");
    }
    #elif defined(CONFIG_ZX2112XX)
    zte_snprintf_s((char *)cmdBuf, sizeof(cmdBuf), "tftp -gr cpu.swv 198.33.33.100 -b 16318");
    #elif defined(CONFIG_ZXW11200)
    if (ms_flag() == SLAVE_GPIO_FLAG)
    {
        retsystem = zte_snprintf_s((char *)cmdBuf, sizeof(cmdBuf), "tftp -gr cur7.swv 198.33.33.102 -b 16318 -l cpu.swv");
        SNPRINTF_S_CHECK(retsystem, sizeof(cmdBuf));
    }
    #endif
    /* Ended by AICoder, pid:37796h33dbkc8d1140330947a092f71ab7f84e35 */

    /* Started by AICoder, pid:7bd31fcf24j2e68142830a9f20dea50594c180ce */
    retsystem = BspSystem((char *)cmdBuf);
    /* Ended by AICoder, pid:7bd31fcf24j2e68142830a9f20dea50594c180ce */
    zte_printf_s("cmdBuf =%s\n", cmdBuf);
    zte_printf_s("retsystem=%d, errno=%d\n", retsystem, errno);
    #if 1
    if (0 != retsystem)
    {
        zte_printf_s("tftp/ftp err in %s\n", __FUNCTION__);
        BspSetCpuVerErrReason(g_ucRunVer, BSP_FLASH_PROTECTVER_DOWNLOAD_ERROR);
        return ERROR;
    }
    #endif

    zte_printf_s("\n*************************************************\n");
    zte_printf_s("\n*******load file from ram......********\n");
    zte_printf_s("\n*************************************************\n");

    /* 读取版本文件内容 */
    fd = open("cpu.swv", O_RDONLY, 0666);
    if (ERROR == fd)
    {
        zte_printf_s("Can not open version file!\n");
        /*设置版本文件打开失败错误,UCHG00156197,zhangaiq,20090421*/
        BspSetCpuVerErrReason(g_ucRunVer, BSP_VER_OPEN_ERROR);
        return ERROR;
    }
    /*获取文件长度*/
    if (ERROR == fstat(fd, &tStat))
    {
        zte_printf_s("Can not open version file!\n");
        BspSetCpuVerErrReason(g_ucRunVer, BSP_VER_READ_ERROR);
        close(fd);
        return ERROR;
    }

    ulFileSize = tStat.st_size;
    /*if (ulFileSize > MAX_CPU_VERSION_SIZE)
    {
        zte_printf_s("cpu version file size %ld exceed in 16M\n",ulFileSize);
        BspSetCpuVerErrReason(g_ucRunVer,BSP_VER_READ_ERROR);
        close(fd);
        return BSP_ERROR;
    }*/

    /* 申请读版本文件缓存 */
    /* Started by AICoder, pid:1a5a5pdf40m855a14dc6090bb0af87075c287137 */
    pucRdVerFileBuff = (UCHAR *)malloc(ulFileSize);
    if (pucRdVerFileBuff == NULL)
    {
        zte_printf_s("version file size %u\n", ulFileSize);
        zte_printf_s("malloc read version file buffer failed!\n");
        close(fd);
        return ERROR;
    }
    /* Ended by AICoder, pid:1a5a5pdf40m855a14dc6090bb0af87075c287137 */

    iRetVal = zte_read_s(fd, pucRdVerFileBuff, ulFileSize, ulFileSize);

    if ((ULONG)iRetVal != ulFileSize)
    {
        zte_printf_s("Version file read error\n");
        close(fd);
        free(pucRdVerFileBuff);
        pucRdVerFileBuff = NULL;
        /*设置版本文件读取失败错误,UCHG00156197,zhangaiq,20090421*/
        BspSetCpuVerErrReason(g_ucRunVer, BSP_VER_READ_ERROR);
        return ERROR;
    }
    close(fd);

    iRetVal = ldFileFromRam(pucRdVerFileBuff, ulFileSize);
    if (BSP_OK != iRetVal)
    {
        /* 版本解压缩失败,告警灯闪6下,1hz*/
        //BootFtpChkLed(6);
        free(pucRdVerFileBuff);
        pucRdVerFileBuff = NULL;
        /*设置版本解压缩失败错误,UCHG00156197,zhangaiq,20090421*/
        BspSetCpuVerErrReason(g_ucRunVer, BSP_VER_UNCMP_ERROR);
        return ERROR;
    }
    free(pucRdVerFileBuff);
    pucRdVerFileBuff = NULL;

    return OK;
}
#endif

/*****************************************************************************
* 函数名称   : BootGetFlashVerProtectAddr(*)
* 功能描述   :
* 读全局变量 :
* 写全局变量 :
* 输入参数   :
* 输出参数   :
* 返 回 值   :
*
* 其它说明   : 获取Flash保护区偏移地址地址(对外接口)
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A),  张  雷@2010-11-15 17:15:58, 创建
*----------------------------------------------------------------------------
*/
ULONG BootGetFlashVerProtectAddr(VOID)
{
    return g_ulProZoneAddrOffset;
}

/*****************************************************************************
* 函数名称   : BspGetVerProtectLen(*)
* 功能描述   :
* 读全局变量 :
* 写全局变量 :
* 输入参数   :
* 输出参数   :
* 返 回 值   : 保护区长度
*
* 其它说明   : 获取Flash 保护区的长度(对外接口)
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A),  张  雷@2010-11-15 17:15:58, 创建
*----------------------------------------------------------------------------
*/
ULONG BootGetVerProtectLen(VOID)
{
    return g_ulProZoneSize;
}

T_VerProtectHead* BootGetProtectHeadFromFlash(ULONG ulProZoneAddrOffset)
{
    ULONG ulProtectHeadLen;
    T_VerProtectHead *ptVerProtectHead = NULL;
    ULONG ulRet = BSP_OK;

    ulProtectHeadLen = sizeof(T_VerProtectHead);
    ptVerProtectHead = (T_VerProtectHead *)malloc(ulProtectHeadLen);
    zte_printf_s("ptVerProtextHead = 0x%x \n", (ULONG)ptVerProtectHead);
    if (NULL == ptVerProtectHead)
    {
        zte_printf_s("malloc error!!\n");
        return NULL;
    }

    zte_memset_s(ptVerProtectHead, ulProtectHeadLen, 0, ulProtectHeadLen);
    ulRet = BspFlashRead(ulProZoneAddrOffset, (UCHAR *)ptVerProtectHead, ulProtectHeadLen);
    if (ulRet != BSP_OK)
    {
        zte_printf_s(" T_VerProtectHead INFO READ wrong!!\n");
        free((void*)ptVerProtectHead);
        ptVerProtectHead = NULL;
        return NULL;
    }

    return ptVerProtectHead;
}

STATUS checkProtectVersion()
{
    T_VerProtectHead *ptVerProtectHead = NULL;
    T_ProtectVerInfo *ptVerInfo = NULL;
    ULONG ulVerSize = 0;
    ULONG ulVerOffSet = 0;
    INT iRetVal = OK;
    ULONG ulProZoneAddrOffset;
    ULONG ulRet = BSP_OK;
    CHAR *pcImgBuf;
    /*设置保护区启动标志*/
    zte_printf_s("\n*************************************************\n");
    zte_printf_s("\n*******load file from flash protect......********\n");
    zte_printf_s("\n*************************************************\n");

    ulProZoneAddrOffset = BootGetFlashVerProtectAddr(); /*拿到保护区偏移地址*/
    ptVerProtectHead = BootGetProtectHeadFromFlash(ulProZoneAddrOffset);
    if(!ptVerProtectHead)
    {
        return ERROR;
    }
    /*  等待确认保护区版本头头信息 */
    zte_printf_s("\nsuccess!\n");

    #ifndef CONFIG_CRC_CPU_ONLY
    /* Started by AICoder, pid:we14d2961fqa09f14e2d09ab70c9f70444e20816 */
    ULONG ulCalCRCResult = 0;
    T_ProtectVerInfoHead *ptVerInfoHead = NULL;
    ptVerInfoHead = &(ptVerProtectHead->tVerInfoFileHead);
    /* Ended by AICoder, pid:we14d2961fqa09f14e2d09ab70c9f70444e20816 */
    zte_printf_s("Calculate ProtectVerInfoHead CRC ......\n");

    /*校验 版本头*/
    ulCalCRCResult = CalculateCRC16(CRC_MASK, (UCHAR *)ptVerProtectHead + sizeof(T_ProtectVerInfoHead), (sizeof(T_VerProtectHead) - sizeof(T_ProtectVerInfoHead)));
    if (ptVerInfoHead->ulCRC != ulCalCRCResult)
    {
        zte_printf_s("Ver Protect Head CRC error!!!!\n");
        free(ptVerProtectHead);
        ptVerProtectHead = NULL;
        /*设置CRC校验出错错误*/
        BspSetCpuVerErrReason(g_ucRunVer, BSP_FLASH_PROTECT_HEAD_CRC_ERROR);
        return ERROR;
    }
    else if (0 == ulCalCRCResult)
    {
        /* CRC为0的时候再校验一下数据是否全0，全0也认为CRC错误 */
        /* Started by AICoder, pid:rb9efvfed72c11214f200986d0e67605186145ec */
        if (BSP_OK == CheckBufAllZero((UCHAR *)(ptVerProtectHead->tVerInfo), sizeof(T_VerProtectHead) - sizeof(T_ProtectVerInfoHead)))
        /* Ended by AICoder, pid:rb9efvfed72c11214f200986d0e67605186145ec */
        {
            zte_printf_s("Ver Protect Head CRC error!! File all zero!!\n");
            free(ptVerProtectHead);
            ptVerProtectHead = NULL;
            /*设置CRC校验出错错误*/
            BspSetCpuVerErrReason(g_ucRunVer, BSP_FLASH_PROTECT_HEAD_CRC_ERROR);
            return ERROR;
        }
    }
    #endif
    /*根据版本信息，获取保护区版本长度和偏移地址*/
    #if defined(CONFIG_SECURITY)
    ptVerInfo = &(ptVerProtectHead->tVerInfo[1]);
    #else
    ptVerInfo = &(ptVerProtectHead->tVerInfo[0]);
    #endif
    /*ulVerSize:cur.swv 的长度，注意 大小端转换*/
    ulVerSize = ptVerInfo->tVerInfoFile.ulSWLength;

    /*ulVerOffSet : 保护区版本头占用的大小256KB，注意 大小端转换*/
    ulVerOffSet = ptVerInfo->ulVerOffSet;

    /*ulVerOffSet应该是flash擦除单元的整数倍,现在的FLASH为256KB，需调整*/
    if (0 != (ulVerOffSet % FLASH_ERASE_SIZE))
    {
        zte_printf_s("CPU version offset error, ulVerOffSet = 0x%x, ", ulVerOffSet);
        zte_printf_s("FLASH_ERASE_SIZE =0x%x\n", FLASH_ERASE_SIZE);
        free(ptVerProtectHead);
        ptVerProtectHead = NULL;
        /*设置CRC校验出错错误*/
        BspSetCpuVerErrReason(g_ucRunVer, BSP_FLASH_PROTECT_READ_ERROR);
        return ERROR;
    }

    if (ulVerSize > BootGetVerProtectLen())
    {
        zte_printf_s("CPU version length is 0x%x is oversize\n", ulVerSize);
        free(ptVerProtectHead);
        ptVerProtectHead = NULL;
        BspSetCpuVerErrReason(g_ucRunVer, BSP_FLASH_PROTECT_READ_ERROR);
        return ERROR;
    }
    pcImgBuf = (CHAR*)malloc(ulVerSize);
    if (NULL == pcImgBuf)
    {
        free(ptVerProtectHead);
        ptVerProtectHead = NULL;
        BspSetCpuVerErrReason(g_ucRunVer, BSP_FLASH_PROTECT_READ_ERROR);
        return BSP_VER_UNCMP_ERROR;
    }

    ulRet = BspFlashRead(ulProZoneAddrOffset + ulVerOffSet, (UCHAR *)pcImgBuf, ulVerSize);
    if (ulRet != BSP_OK)
    {
        zte_printf_s(" pcImgBuf INFO READ wrong!!\n");
        free(ptVerProtectHead);
        ptVerProtectHead = NULL;
        free((void*)pcImgBuf);
        pcImgBuf = NULL;
        BspSetCpuVerErrReason(g_ucRunVer, BSP_FLASH_PROTECT_READ_ERROR);
        return ERROR;
    }

    zte_printf_s("\n read ok!!\n");
    /* Started by AICoder, pid:bdc4a5dd338cce5143700ace401245079161d782 */
    iRetVal = ldFileFromRam((UCHAR *)pcImgBuf, ulVerSize);
    /* Ended by AICoder, pid:bdc4a5dd338cce5143700ace401245079161d782 */
    if (BSP_OK != iRetVal)
    {
        /* 版本解压缩失败,告警灯闪6下,1hz*/
        //BootFtpChkLed(6);
        free(ptVerProtectHead); /*通过固定内存存版本，所以不需要free*/
        ptVerProtectHead = NULL;
        free(pcImgBuf);
        pcImgBuf = NULL;
        /*设置版本解压缩失败错误, 在ldFileFromRam里设置即可*/

        return ERROR;
    }
    free(ptVerProtectHead);
    ptVerProtectHead = NULL;
    free(pcImgBuf);
    pcImgBuf = NULL;

    return BSP_OK;
}

/* ******************************************************************************
* 函数名称： LOCAL STATUS ldFileFromFlashProtect()
* 功能描述： 从Flash保护区加载版本
* 访问的表：
* 修改的表：
* 输入参数：
* 输出参数：
* 返 回 值： ERROR: 加载失败
*            OK: 加载成功
* 其它说明： flash保护区加载版本文件
* 修改日期    版本号     修改人         修改内容
* -----------------------------------------------
* 2010-03-27         V1.0              rongfang             创建
**********************************************************************************/
STATUS ldFileFromFlashProtect()
{
    /*当前正在版本保护区版本*/
    g_ucRunVer = BSP_PROVERSION;
    BspSetCpuVerErrReason(g_ucRunVer, 0);

    #ifdef CONFIG_LOADVERSION_PLUS
    return checkProtectVersionPlus();
    #else
    return checkProtectVersion();
    #endif
}

static UCHAR getRunVerCode(const char *pchBootFile)
{
    if(!strncmp(pchBootFile,RTR_VX_OLD,sizeof(RTR_VX_OLD)))
        return BSP_RUN_VERSION;
    else if(!strncmp(pchBootFile,RTR_VX_NEW,sizeof(RTR_VX_NEW)))
        return BSP_BAK_VERSION;
    #ifdef CONFIG_ZXW11200_NTN
    else if(!strncmp(pchBootFile,RTR1_VX_OLD,sizeof(RTR1_VX_OLD)))
        return BSP_BAK_FSVERSION;
    #endif
    else
     return -1;
}

int checkFilesystemVersion(const char *pchBootFile)
{
    UCHAR ucCnt;
    INT32 fd = 0;
    INT iRetVal = ERROR;
    FUNCPTR entry = 0;

    for (ucCnt = 0; ucCnt < 2; ucCnt++)
    /*尝试下载 2次*/
    {
        /*判断压缩文件是否存在*/
        zte_printf_s("Retry Time(=%d)\n", ucCnt);

        fd = open(pchBootFile, O_RDONLY, 0);
        if (-1 == fd)
        {
            if (0 < ucCnt)
            {
                zte_printf_s("open %s fail!\n", pchBootFile);
                /*添加高端内存错误指示:版本文件不存在yc20110616*/
                BspSetCpuVerErrReason(g_ucRunVer, BSP_VER_OPEN_ERROR);

                return -1;
            }
            continue;
        }
        close(fd);
        zte_printf_s("Loading File: %s ......", pchBootFile);
        zte_printf_s("Start linux image  package unpressing...\n");
        iRetVal = ldCertainFile(pchBootFile, &entry);
        zte_printf_s("load linux pack ,retVal  =  %d!\n", iRetVal);
        if (BSP_OK != iRetVal)
        /* 如果解压错误，即原CRC 或解压后CRC 错误，则重启*/
        {
            /*解压错误重启动! */
            zte_printf_s("ERROR! FAIL TO DECOMPRESS  FILE %s  _zxb\n", pchBootFile);

            return -1;
        }
        else
        {
            return OK;
        }
    }

    return -1;
}

/*===========================================================
函数名      ：ldLinuxBakVer
功能        ：加载备用版本 tmp.swv
输入参数说明：   pchBootFile -- 要加载的文件名
返回值说明  ：
引用全局变量：
附加说明    ：
===========================================================*/
int ldLinuxBakVer(const char *pchBootFile)
{
    g_ucRunVer = getRunVerCode(pchBootFile);
    BspSetCpuVerErrReason(g_ucRunVer, 0);

    return checkFilesystemVersion(pchBootFile);
}

static void HandleBeforeKexecReboot()
{
    
    #ifdef CONFIG_ZXW11200_NTN
    /* Started by AICoder, pid:afd8di8a25m998714abc098dd0af3e0e98a1b621 */
    struct stat st;
    /* Ended by AICoder, pid:afd8di8a25m998714abc098dd0af3e0e98a1b621 */
    if(NTN_BOARD_2ND == get_ntn_board_type() && stat(FORMAT_LOG_FILE, &st) == -1)
    {
        if(BSP_RUN_VERSION == g_ucRunVer || BSP_PROVERSION == g_ucRunVer) 
        {
            fs_recover(1);
            fs_recover(2);
        }
        else if(BSP_BAK_FSVERSION == g_ucRunVer || BSP_BAK_REPAIR_VERSION == g_ucRunVer)
        {
            fs_recover(2);
        }
    }
    #endif

    #if defined(CONFIG_DRA62X)
    if (1 == dra62x_is_config(SWITCH_RESET))
    {
        dbgInfo("Pre-disable dma irq for Dra62x eth1 & eth0.\n");
        /* yam inform:
        *   Disable irq and interrupt of eth0 & eth1, to avoid of
        *   jumping error during kexec soft reset
        */
        if ((BSP_OK != BspNetIrqIntDisable("eth1")) ||
            (BSP_OK != BspNetIrqIntDisable("eth0")))
        {
            dbgInfo("Try BspNetIrqIntDisable Failed!\n");
        }
        BootSysMsDelay(1000);
    }
    #endif

    /* 关闭各串网口、中断，避免二次内核跳转期间异常 */
    /* For better, down eth1 at first, then eth0. */
    #if(defined(CONFIG_LS10X3A) || defined(CONFIG_ZXW11200) || defined(CONFIG_ZX211410_EXT))
    #else
    BspNetDeviceClose("eth1");
    #endif

    BspNetDeviceClose("eth0");
    /*add by lyq 10242265 2018-12-22*/
    #if defined(CONFIG_RECORD_TIME)
    TimeNode(KEXEC_END);
    #endif
}

/*****************************************************************************
* 函 数 名: BootBoardSetReset
* 功能描述: boot统一复位入口函数
* 输入参数: ULONG ulMode : 复位模式，0-gracefulreboot/1-kexecreboot
            ULONG ulWtd  : 看门狗使能标志，0-关闭/1-使能
* 输出参数: 无
* 返 回 值: 无
* 其他说明: 不考虑返回处理
* 修改日期　　　　版本号　　修改人　　修改内容
* --------------------------------------------
* 2015年12月11日　　V1.0　　　10029949　　　新建
*
*****************************************************************************/
ULONG BootBoardSetReset(ULONG ulMode, ULONG ulWtd)
{
    UCHAR buffer[20];
    int iRetVal = ERROR;

    /*在复位接口中统一保存一把boot下的cur/bak的log*/
    #ifdef CONFIG_RECORDLOG
    SaveKebootCurLog();
    #endif
    #if defined(CONFIG_ZXW11200_NTN)
    T_CtrlVerErrReason tCpuErrReason;
    BspGetCpuVerErrReason(&tCpuErrReason);
    if((NTN_BOARD_2ND == get_ntn_board_type()) && (g_ucRunVer == BSP_BAK_REPAIR_VERSION) && (0 != tCpuErrReason.ucReserve[1]))
    {
        boot_report(REPAIR_VERSION_FAILED);
    }
    else
    {
        boot_report(RUN_IN_KEBOOT);
    }
    #endif
    if (1 == ulMode)
    {
        HandleBeforeKexecReboot();
        /* softreset by kexec, never return for normal */
        iRetVal = KexecRebootCmd(BSP_KEXECBOOT_RESET, ulWtd);
        if (OK != iRetVal)
        {
            dbgErr("KEXEC REBOOT: Kexec Cmd Error[%d]!\n", iRetVal);
        }
        else
        {
            dbgInfo("!!! JUST WAIT FOR REBOOT !!! by BootBoardSetReset\n");
            /* In case of wtd invalid, only wait for 100s, then go to gracefulreboot */
            BootSysMsDelay(100000);
        }

        dbgErr("!!!!!! KEXEC REBOOT ERROR !!!!!!\n");
        /* go on gracefulreboot */
    }
    #if (defined(CONFIG_ZXW11200_NTN) && defined(CONFIG_MULTI_FILESYSTEM))
    if(NTN_BOARD_2ND == get_ntn_board_type())
    {
        for(int i = 1;i < max_filesystem_num;i++)
        {
            BootGetFsRecoverFlag_Multi(i);
        }
    }
    #endif
    /* exception or not kexecreboot, do gracefulreboot for reset */

    /* Started by AICoder, pid:efeed8eca0ba246142840a8920fc1c0762037862 */
    zte_memset_s(buffer, sizeof(buffer), 0, sizeof(buffer));
    zte_snprintf_s((char *)buffer, sizeof(buffer), "reboot %d", BSP_LOCAL_SOFTEXCP_RESET);
    BspSystem((char *)buffer);
    /* Ended by AICoder, pid:efeed8eca0ba246142840a8920fc1c0762037862 */
    return BSP_OK;
}
/*****************************************************************************
*  函数名称   : BspResetDevice(*)
*  功能描述   : 复位单板上的器件
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : ulDevId     - 器件识别号
*             : ulResetType - 复位类型, 1-软复位 0 -硬复位
*             : ulCause     - 复位原因
*  输出参数   : 无
*  返 回 值   : 成功时返回BSP_OK, 否则返回BSP_ERROR
*  其它说明   : RRU公共接口函数
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A), 宋志强2014-05-12 10:30:31, 创建
*----------------------------------------------------------------------------
*/
ULONG BootResetDevice(ULONG ulDevId, ULONG ulResetType, ULONG ulCause)
{

    ULONG ulDevIdVal = ulDevId;
    if (BSP_ID_MAX < ulDevId)
    {
        ulDevIdVal = BSP_DEVICE_ID_BOARD0;
    }

    /*
    1、单板复位，主片复位，使用内置看门狗。主片运行后，通过操作扩展FPGA复位从片
    2、主片CPU核复位，如何操作?
    3、主从片DSP核复位，尤坤补充
    4、从片复位，通过扩展FPGA复位从片
    5、是否要考虑IC内部组件复位?组件需要参加设备ID编址，以及扩展复位类型宏定义。
    6、扩展FPGA复位，通过GPIO实现；
    7、其他外设器件复位，由赵云补充；
    */

    switch (ulDevIdVal)
    {
        case BSP_DEVICE_ID_BOARD0: /* 单板复位，使用内置看门狗复位，  */
        {
            dbgPrn(GREEN "[Bsp Reset] Cause: " RED "%x\n" BLANK, ulCause);
            /* 暂时关闭，编译问题 */
            // BspInitGain();/*增益衰减最大，即关闭*/
            sleep(1);

            if (g_ulResetTrue == 0)
            {
                break;
            }
            /* 操作看门狗复位，待补充 */
            BootBoardSetReset(ulCause, 1);

            break;
        }
    }

    return BSP_OK;
}
/*****************************************************************************
*  函数名称   : BspBoardReset
*  功能描述   : 适配函数
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : 无
*  输出参数   : 无
*  返 回 值   : 成功或者失败
*  其它说明   :
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A), 崔文会@2011-01-19 08:33:43, 拷贝并平台规范化
*----------------------------------------------------------------------------
*/
void BootBoardReset(void)
{
    // BspSetResetType(BSP_LOCAL_SOFTEXCP_RESET);
    BootResetDevice((ULONG) "Board0", BSP_RESET_TYPE_SOFT, BSP_APP_SOFT_RESET);
}
/**************************************************************************
* 函数名称: void LoadMsgFile(void)
* 功能描述: 单核linux版本加载
* 输入参数: 无
* 输出参数: 无
* 返 回 值: 无
* 其它说明: 正常情况下该函数不返回,暂不支持dtb，需要增加dtb时需加入宏
*
* 修改日期:    版本号     修改人        修改内容
* -----------------------------------------------
* 2015-10-22            V1.0             00086970          创建
**************************************************************************/
ULONG LoadMacMsgFile(UCHAR *ucDataBuf, ULONG ullength)
{
    CHAR acuFileName[20] = "/MacMsg.txt";
    int iFD = 0;
    CHAR aucShellCmd[180];
    ULONG ulWriteLen = 0;
    ULONG ulRetVal = BSP_OK;

    iFD = open(acuFileName, O_CREAT | O_WRONLY, 0644);
    if (iFD < 0)
    {
        zte_printf_s("open %s error \n", acuFileName);
        return BSP_ERROR;
    }
    zte_snprintf_s((char *)aucShellCmd, sizeof(aucShellCmd), "cat /dev/null > %s ", acuFileName);
    system((char *)aucShellCmd);
    zte_printf_s("load MacMsg to /MacMsg.txt...");

    ulWriteLen = write(iFD, (char *)ucDataBuf, ullength);
    if (ulWriteLen != ullength)
    {
        zte_printf_s("error!\n");
        close(iFD);
        return BSP_ERROR;
    }
    fsync(iFD);
    close(iFD);
    zte_printf_s("ok!\n");
    return ulRetVal;
}

static ULONG WaitForMacAndIp()
{
    int iflag = 0;
    int iLoop;
    int iSendRet = 0;

    zte_printf_s("WAIT GET MAC AND IP  ADDR ...\n");
    /*等待3s后如果收到配置报，如果没有收到配置包，继续往下*/
    while (iflag < 300)
    {
        BootSysMsDelay(10); // 10000 * 300
        iflag++;
        if (1 == s_ucGetMacIpSetFlag)
        {
            iflag = 300;
            zte_printf_s("Get new MAC and IP addr \n");
            /* 去掉8306的setenv ipaddr/ethaddr */
            for (icnt = 0; icnt < 40; icnt++)
            {
                /**避免混杂模式下接收数据过多时,本次配置数据尚未完全接收完
                就被后到的其他数据覆盖的可能,将接收实现从NormalBoot()移动到
                netGetMacIP()内,这里仅打印出接收到的配置信息内容,move from 8306*/
                gaucmac[icnt] = *(gpucmacMsg + icnt);
                gaucmacRet[icnt] = *(gpucmacMsg + icnt);
                zte_printf_s("%x ", gaucmac[icnt]);
                zte_printf_s(" ");
            }
            zte_printf_s("\n");
            /*交换MAC 地址*/
            gaucmacRet[0] = gaucmac[6];
            gaucmacRet[1] = gaucmac[7];
            gaucmacRet[2] = gaucmac[8];
            gaucmacRet[3] = gaucmac[9];
            gaucmacRet[4] = gaucmac[10];
            gaucmacRet[5] = gaucmac[11];
            gaucmacRet[6] = gaucmac[0];
            gaucmacRet[7] = gaucmac[1];
            gaucmacRet[8] = gaucmac[2];
            gaucmacRet[9] = gaucmac[3];
            gaucmacRet[10] = gaucmac[4];
            gaucmacRet[11] = gaucmac[5];
            BootSysMsDelay(5000);
            for (iLoop = 0; iLoop < 10; iLoop++)
            {
                iSendRet = send(iSocket, gaucmacRet, 40, 0);
                if (iSendRet == 40)
                {
                    break;
                }
            }
            if (iLoop == 10)
            {
                zte_printf_s("Send Mac Data failed\n");
            }
            else
            {
                zte_printf_s("Send Mac Data End\n");
            }
            zte_printf_s("FT Mode!! \n");
            #if defined(CONFIG_ZXW11200)
            /*解决外接DB15还回头时偶发的加载工装版本异常，不关外狗，联动的，将调试串口留在uart0；
            但关闭内狗。如此，并行下载约有8分钟时间*/
            BootInnerWatchDogDisable();
            #else
            BootWatchDogDisable();
            #endif
            #if (defined(CONFIG_ZX211413) || defined(CONFIG_ZX211412))
            BootSetM0MoniA53();
            #endif
            for (icnt = 0; icnt < 40; icnt++)
            {
                zte_printf_s("%x ", gaucmacRet[icnt]);
                zte_printf_s("*");
            }
            zte_printf_s("\n");
            LoadMacMsgFile(gaucmacRet, 40);
            return 0;
            /*这里需要加入什么流程*/
        }
    }
    zte_printf_s("Not get new MAC and IP addr \n");
    return -1;
}

/**************************************************************************
* 函数名称: UCHAR NormalBoot(void)
* 功能描述: 内核镜像 uImage 和 RAMDISK 镜像加载入口
* 输入参数: 无
* 输出参数:
* 返 回 值: BSP_OK: -- 表示版本加载正常
其他： -- 表示加载失败时的错误码
* 其它说明: RTR2 中这两个镜像合并成一个。
但是这里不加载逻辑镜像，逻辑镜像在内核启动后加载
*
* 修改日期:    版本号     修改人        修改内容
* -----------------------------------------------
* 2010-05-25     V1.0      xxx        Created
**************************************************************************/
UCHAR NormalBoot(void)
{
    int iRetVal = OK;
    /*ULONG         ulProtectStartFlag = 0;*/
    BOOL bFromFlashProtect = FALSE;
    unsigned int uiRet = ERROR;
    /*intfBspWatchDogEnable(); */

    if (0 == BootGetPhyLinkStatus()) /*debug网口正常连通*/
    {
        /********混杂模式start*****/
        s_ucGetMacIpSetFlag = 0;
        SetEthProMode(1); /*对进入的帧的目的地址不进行检查*/
        BootTestVersionDownLoadInit();
        zte_printf_s("Enter Promiscuous mode \n");
        if(0 == WaitForMacAndIp())
        {
            return -1;
        }

        SetEthProMode(0); /* 网卡进入到正常模式 */
    }

    /********混杂模式end*****/
    #ifdef CONFIG_RECORD_FSLOG
    BspSaveUbifsRoLog();
    #endif
    #ifdef CONFIG_RECORDLOG
    SaveKebootBakLog();
    #endif

    iRetVal = BootSelectWork(); /*运行中试版本*/
    if (OK == iRetVal)
    {
        CreatRruCfgIniFile();
        BootLedRun(0);
        zte_printf_s("FT Mode!! \n");
        #if defined(CONFIG_ZXW11200)
        BootBoardSetReset(1, 1); /*解决外接DB15还回头时偶发的加载工装版本异常，不关狗，联动的，将调试串口留在uart0*/
        #else
        BootWatchDogDisable();
        BootBoardSetReset(1, 0);
        #endif
    }
    else
    {
        zte_printf_s("load ft Image from fileSystem fail!\n");
    }

    /*add by lyq 10242265 2018-12-22*/
    #if defined(CONFIG_RECORD_TIME)
    TimeNode(VER_START);
    #endif

    iRetVal = ldFileFromFlash();

    if (OK == iRetVal)
    {
        BootLedRun(0);
        zte_printf_s("normal boot ok!\n");
        BootBoardSetReset(1, 1);
    }
    else
    {
         /* s_bProzoneFlag INI文件异常时按保护区分支启动,By Zengx,2012.02.23 */
        if(s_bRunFlag || s_bBackFlag || s_bProzoneFlag)
        {
            bFromFlashProtect = TRUE;
        }
        else
        {
            /*加载失败后立即复位，modify by luojian 2010-1-11*/
            zte_printf_s("###run release Image from FileSystem  fail!\n");
            // BootBoardReset();
            BootBoardSetReset(0, 1);
            return iRetVal;
        }

        /*开始加载保护区*/
        if (bFromFlashProtect)
        {
            #if 0
            /*8101NR分支，共五处，搜BootGetDownloadFlag*/
            if (0x3==zynqmpsoc_get_appid())
            {
                BootWatchDogDisable();
                do
                {
                    uiRet = ldFileDownload();
                    BootSysMsDelay(1000);
                }
                while(OK != uiRet);
            }
            else
            {
                uiRet = ldFileDownload();
            }
            #else
            if (1 == BootGetDownloadFlag())
            {
                zte_printf_s("download version!\n");
                #if defined(CONFIG_ZYNQMPSOC)
                if (0x3 == zynqmpsoc_get_appid())
                {
                    BootWatchDogDisable();
                    do
                    {
                        uiRet = ldFileDownload();
                        BootSysMsDelay(1000);

                    } while (OK != uiRet);
                }
                else
                {

                    uiRet = ldFileDownload();
                }
                #elif (defined(CONFIG_ZX2112XX) || defined(CONFIG_ZXW11200))
                BootWatchDogDisable();
                do
                {
                    uiRet = ldFileDownload();
                    BootSysMsDelay(1000);

                } while (OK != uiRet);
                #endif
                /*add by lyq 10242265 2018-12-22*/
                #if defined(CONFIG_RECORD_TIME)
                TimeNode(DOWNLOAD_END);
                #endif
            }
            else
            {
                zte_printf_s("load protect version!\n");
                uiRet = ldFileFromFlashProtect();
                /*add by lyq 10242265 2018-12-22*/
                #if defined(CONFIG_RECORD_TIME)
                TimeNode(PROCT_END);
                #endif
            }
            #endif
            if (OK != uiRet)
            {
                #ifdef CONFIG_ZXW11200_NTN
                if(NTN_BOARD_2ND == get_ntn_board_type())
                {
                    if(OK != ubifs_init(1) || OK != ldLinuxBakVer(RTR1_VX_OLD))
                    {
                        if(-1 == ldFileFromRepairVersion())
                        {
                            BootBoardSetReset(0, 1);
                        }
                    }
                }
                else{
                #endif

                    /*1，保护区加载失败后*/
                    zte_printf_s("load tmp.swv bakver!\n");
                    if (OK != ldLinuxBakVer(RTR_VX_NEW))
                    {
                        /*2，加载备用版本也失败后直接复位*/
                        // BootBoardReset();
                        BootBoardSetReset(0, 1);
                    }
                #ifdef CONFIG_ZXW11200_NTN
                }
                #endif
                /*add by lyq 10242265 2018-12-22*/
                #if defined(CONFIG_RECORD_TIME)
                TimeNode(TMP_END);
                #endif
                
            }
            /*********************************************************************/
            /* 在启动版本之前关闭看门狗任务，启动硬件喂狗*/
            /*********************************************************************/
            /*BootWatchDogDisable();*/
            BootLedRun(0);
            BootBoardSetReset(1, 1);
        }
    }
    return ERROR;
}

int GetFlashInfo(ULONG *p_ulBlkSize)
{

    FILE *fd = NULL;
    char *pcAddr = NULL;
    char cTmp = 0;
    #define MTD_INFO_FILE "/proc/mtd"
    char cFlashInfo[256] = {0};
    // ULONG ulBlocksize = 0x40000;

    *p_ulBlkSize = 0x40000;
    fd = fopen(MTD_INFO_FILE, "r+b");
    if (NULL == fd)
    {
        zte_printf_s("Can not open /proc/mtd\n");
        return 1;
    }
    fseek(fd, 0L, SEEK_SET);
    zte_memset_s(cFlashInfo, sizeof(cFlashInfo), 0, sizeof(cFlashInfo));
    cTmp = fread(cFlashInfo, 1, sizeof(cFlashInfo), fd);
    if (0 >= cTmp)
    {
        zte_printf_s("read /proc/mtd error\n");
        zte_fclose_s(fd);
        return 2;
    }
    zte_printf_s("cFlashInfo = %s\n", cFlashInfo);

    pcAddr = strstr(cFlashInfo, "JFFS2");
    if (NULL == pcAddr)
    {
        pcAddr = strstr(cFlashInfo, "Filesystem");
        if (NULL == pcAddr)
        {
            zte_printf_s("/proc/mtd Filesystem and JFFS2 key words error\n");
            zte_fclose_s(fd);
            return 3;
        }
    }

    *p_ulBlkSize = (ULONG)strtol(pcAddr - 10, NULL, 16);

    zte_fclose_s(fd);
    return 0;
}
/*****************************************************************************
*  函数名称   : BootFSScan(*)
*  功能描述   : 扫描检测文件系统格式
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : 无
*  输出参数   : 无
*  返 回 值   : 0表示为JFFS2格式; 1表示UBIFS格式;BSP_ERROR表示未扫描出文件系统格式
*  其它说明   : 无
*  函数属性   : 基础接口
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000001(N/A), 曾鑫@2011-12-19 14:39:02 创建
*  $0000002(N/A), 00086970@2016-8-12 14:39:02 移植到keboot
*----------------------------------------------------------------------------
*/
ULONG BootFSScan(void)
{
    INT fd;
    ULONG retCode = BSP_OK;
    ULONG ulmtdOffset[FLASH_PARTITION_NUM] = {0, 0, 0};
    ULONG ulmtdSize[FLASH_PARTITION_NUM] = {0, 0, 0};
    CHAR* p_acPartitionName[FLASH_PARTITION_NUM] = {"/dev/mtd0", "/dev/mtd1", "/dev/mtd2"};
    UCHAR i = 0;
    ULONG ulBlockSize = 0x40000;
    ULONG ulLoop = 0;
    USHORT usTmpVal = 0;
    ULONG ulSecCount = 0;

    for (i = 0; i < FLASH_PARTITION_NUM; i++)
    {
        fd = open(p_acPartitionName[i], O_RDWR);
        if (fd < 0)
        {

            zte_printf_s("open %s error \n", p_acPartitionName[i]);
            return BSP_ERROR;
        }
        else
        {
            // zte_printf_s("open %s  OK! fd=%d \n",p_acPartitionName[i],fd);
        }
        if (0 != lseek(fd, 0, SEEK_SET))
        {
            zte_printf_s("lseek /dev/mtd%d to begin error \n", i);
            close(fd);
            return BSP_ERROR;
        }
        ulmtdSize[i] = lseek(fd, 0, SEEK_END);
        if (ulmtdSize[i] == 0)
        {
            zte_printf_s("lseek /dev/mtd%d to end error \n", i);
            close(fd);
            return BSP_ERROR;
        }
        close(fd);
    }
    ulmtdOffset[BOOT] = 0;
    ulmtdOffset[RESVERD] = ulmtdOffset[BOOT] + ulmtdSize[BOOT];
    ulmtdOffset[FILESYSTEM] = ulmtdOffset[RESVERD] + ulmtdSize[RESVERD];

    if ((0 != GetFlashInfo(&ulBlockSize)) || (0 == ulBlockSize))
    {
        ulBlockSize = 0x40000;
        zte_printf_s("read block size error,use default.\n");
    }
    ulSecCount = ulmtdSize[FILESYSTEM] / ulBlockSize;
    for (ulLoop = 0; ulLoop < ulSecCount; ulLoop++)
    {
        retCode = BspFlashRead(ulmtdOffset[FILESYSTEM] + ulLoop * ulBlockSize, (UCHAR *)&usTmpVal, 2);
        if (BSP_OK == retCode)
        {
            if (0x1985 == usTmpVal)
            {
                zte_printf_s("CleanMarker[%d]= 0x%x\n", ulLoop, usTmpVal);
                zte_printf_s("\nThis is JFFS2\n");
                return 0;
            }
            else if (0x4255 == usTmpVal)
            {
                zte_printf_s("CleanMarker[%d]= 0x%x\n", ulLoop, usTmpVal);
                zte_printf_s("\nThis is UBIFS\n");
                return 1;
            }
            else
            {
                continue;
            }
        }
        else
        {
            continue;
        }
    }
    zte_printf_s("FsScan:This is neither JFFS2 nor UBIFS\n");
    return BSP_ERROR;
}

int check_protect_version()
{   
    int iRet = ERROR;
    if (1 == BootGetDownloadFlag())
    {
        #if(defined(CONFIG_ZYNQMPSOC) || defined(CONFIG_ZX2112XX) || defined(CONFIG_ZX211412) || defined(CONFIG_ZX211413))
        zte_printf_s("download version!\n");
        iRet = ldFileDownload();
        #endif
    }
    else
    {
        zte_printf_s("load protect version!\n");
        iRet = ldFileFromFlashProtect();
    }

    return iRet;
}

static int fs_isformatdone(void)
{
    FILE *fd = NULL;
    char tmpReadBuf[256];
    char acStr1[100], acStr2[100];
    rsize_t size_array[3] = {100, 100, 0};
    int ret = -1;

    fd = fopen(FORMAT_LOG_FILE, "r");
    if (NULL == fd)
    {
        zte_printf_s("Can not open %s\n",FORMAT_LOG_FILE);
        return -1;
    }
    /* 循环读取每行 */
    while (0 == zte_fgets_s(tmpReadBuf, sizeof(tmpReadBuf), 100, fd))
    {
        /*umount /mnt/filesystem
        UbifsFlashFormat: umount success!
        ubidetach -m 2
        UbifsFlashFormat: ubidetach success!
        ubiformat: format success!
        ubiformat: ubiattach success!
        ubiformat: ubimkvol success!
        ubiformat: mount ubifs success!
        umount /mnt/filesystem
        UbifsFlashFormat: umount success!*/
        zte_sscanf_s(tmpReadBuf, "%s %s", size_array, acStr1, acStr2);
        // zte_printf_s("read str = %s %s \n",acStr1, acStr2);
        if (0 == strncmp("mount", acStr2, 5))
        {
            ret = 0;
            break;
        }
    }

    zte_fclose_s(fd);
    return ret;
}

static int do_format(unsigned int dwIndex, unsigned long ulDelay)
{
    ULONG ulDelayPass = 0;
    const char* path = "/sbin/format";
    char reset_type[4] = {0};
    char fs_index[4] = {0};
    char* const argv[6] = {"format", "1", reset_type,"1", fs_index, NULL};
    rsize_t argc = 6;
    zte_snprintf_s(reset_type, sizeof(reset_type), "%d", BSP_FILESYSTEM_RESET);
    zte_snprintf_s(fs_index, sizeof(fs_index), "%d", dwIndex);
    /*
        #if(defined(CONFIG_ZX2112XX))
        BootWatchDogDisable();
        #endif
        */
    zte_system_s(path, argv, argc, pathlist, pathlist_size);

    for (ulDelayPass = 0; ulDelayPass < ulDelay; ulDelayPass++)
    {
        if (0 != fs_isformatdone())
        {
            taskDelay(sysClkRateGet());
            #if(defined(CONFIG_ZX2112XX))
            BootSetWatchDogTime(21);
            #endif
            #if(defined(CONFIG_ZXW11200_NTN))
            BootSetWatchDogTime(60);
            #endif
        }
        else
        {
            return OK;
        }
    }

    return ERROR;
}

#if (defined(CONFIG_ZXW11200_NTN) && defined(CONFIG_MULTI_FILESYSTEM))

/* Started by AICoder, pid:vb2598ae4fffdb1141730aac60d29815ec396725 */
static int set_format_flag(unsigned int dwIndex, int ret)
{
    zte_memset_s((CHAR*)FS_FORMAT_FLAG, sizeof(UINT32), 0, sizeof(UINT32)); /* 清空 */

    UINT32 format_flag = FILESYSTEM_FORMAT_FLAG | (dwIndex << 12);

    if (!ret)
    {
        format_flag |= FORMAT_SUCCESS;
    }
    else
    {
        format_flag |= FORMAT_ERROR;
    }

    *(UINT32 *)FS_FORMAT_FLAG = format_flag;

    return OK;
}
/* Ended by AICoder, pid:vb2598ae4fffdb1141730aac60d29815ec396725 */

static int fs_format(unsigned int dwIndex, unsigned long ulDelay)
{
    int ret = ERROR;
    set_format_flag(dwIndex, ret);
    if(NTN_BOARD_2ND == get_ntn_board_type())
    {
        ret = OK;
    }
    else
    {
        ret = check_protect_version();
    }

    if (OK == ret)
    {
        if(NTN_BOARD_2ND == get_ntn_board_type())
        {
            for(int i = dwIndex+1;i < max_filesystem_num;i++)
            {
                BootGetFsRecoverFlag_Multi(i);//清除标志
            }
        }
        ret = do_format(dwIndex, ulDelay);
        if(OK == ret)
        {
            set_format_flag(dwIndex, ret);
        }
    }

    return ret;
}
#else
static int fs_format(unsigned int dwIndex, unsigned long ulDelay)
{
    int ret = ERROR;
    
    ret = check_protect_version();

    if (OK == ret)
    {
        ret = do_format(dwIndex, ulDelay);
    }

    return ret;
}
#endif

VOID fs_recover(unsigned int dwIndex)
{
    ULONG ulDelay = 15;
    ULONG ulRet = -1;
    int ret = -1;

    if(dwIndex >= max_filesystem_num)
    {
        zte_printf_s("error index\n");
        return;
    }

    if (should_recover_fs(dwIndex)) /*filesystem mount error*/
    {
        ulRet = get_filesystem_mtd_size(dwIndex);
        if(-1 == ulRet)
        {
            zte_printf_s("get_filesystem_mtd_size error\n");
            return;
        }
        
        #if(defined(CONFIG_ZXW11200_NTN))
        ulDelay = 16*60;
        #else
        if (ulRet >= 128 * 1024 * 1024)
        {
            /*认为mtd2大于等于128M为nandflash，延时使用公式换算，配合设置看门狗喂狗时间(dra62x,8998主片)*/
            ulRet = ulRet / (64 * 1024 * 1024);
            ulDelay = ulRet * 10;
            zte_printf_s("fs_recover get fs delay = %d \n", ulDelay);
            #ifndef CONFIG_ZX2112XX
            BootWatchDogDisable();
            BootSetWatchDogTime(ulRet * 10 * 2 + 50); /*2倍ulDelay的看门狗裕量*/
            BootWatchDogEnable();
            #endif
            zte_printf_s("!!! file system mount error, start from protect zone...\n");
            zte_printf_s("!!! reset watch dog time %d \n", ulRet * 10 * 2 + 50);
        }
        else
        {
            /*认为mtd2小于128M为norflash，延时固定5分钟(实测4分钟)。
            8101qspi降频，format实测需要4分半，delay6分钟9601高层8分钟心跳有风险，继续5分钟。
            8101nr硬件看门狗输出会复位flash，9601料单升级又支持看门狗，此处也需要设置看门狗*/
            #if(defined(CONFIG_LS10X3A) || defined(CONFIG_ZX2112XX) || defined(CONFIG_ZX211410_EXT) || \
                defined(CONFIG_ZXW11200) || defined(CONFIG_ZX211412) || defined(CONFIG_ZX211413))
            ulDelay = 480;
            #else
            ulDelay = 300;
            #endif
            zte_printf_s("nor flash,fs_recover get fs delay = %d \n", ulDelay);
            #ifndef CONFIG_ZX2112XX
            BootWatchDogDisable();
            BootSetWatchDogTime(480); /*8分钟看门狗裕量*/
            BootWatchDogEnable();
            #endif
            zte_printf_s("!!! file system mount error, start from download...\n");
            zte_printf_s("!!! reset watch dog time %d \n", 480);
        }
        #endif

        /*判断保护区版本是否正常*/
        #if 0
        /*8101NR分支，共五处，搜BootGetDownloadFlag*/
        zte_printf_s("download version!\n");
        ret = ldFileDownload();
        #endif

        ret = fs_format(dwIndex, ulDelay);
        
        if(ERROR == ret)
        {
            zte_printf_s("fs_recover error = %x\n", ret);
        }
    }
}

ULONG jffs2_init(VOID)
{

    UCHAR ucBufCmd[256] = "mount -t jffs2 /dev/mtdblock2 /mnt/jffs";

    int nRetVal = BSP_OK;

    zte_printf_s("Jffs2 ,cmd :%s\n", ucBufCmd);
    /* Started by AICoder, pid:d3306q0730mf961145bd0b500096f30693011252 */
    system((char *)ucBufCmd);
    /* Ended by AICoder, pid:d3306q0730mf961145bd0b500096f30693011252 */

    system("ln -s /mnt/jffs /ata");

    system("mkdir -p /ata/rru");

    system("mkdir -p /ata/rru/fpga");

    system("mkdir -p /ata/rru/dsp");

    return nRetVal;
}
/**************************************************************************
* 函数名称： normal
* 功能描述：
* 输入参数： void
* 输出参数： 无
* 返 回 值：
* ------------------------------------------------------
* 其它说明：
* 修改日期     版本号     修改人         修改内容
* 2014/5/29         V1.0              00086970                      创建
* 2018/8/31
2019/8/1                               jc@10256052   增加ZX2112XX WatchDogTime
**************************************************************************/
ULONG normal(VOID)
{
    ULONG ulRet = BSP_OK;
    #if(defined(CONFIG_ZX2112XX))
    BootWatchDogInit();  /*WatchDogTime set at max value which is 42s for ZX2112XX*/
    BootFpgaWdtEnable(); /*Enable Fpga Watch Dog*/
    #else
    BootWatchDogEnable();
    BootSetWatchDogTime(240); /*此时到内核启动完成大约需要25s，留有余量设置为50s*/
    #endif
    ulRet = NormalBoot();

    return ulRet;
}

ULONG isflashVerOk(CHAR *pchVerFile)
{
    INT32 fd = 0;
    INT iRetVal;
    UCHAR *pucRdVerFileBuff = NULL;
    ULONG ulFileSize;
    struct stat tStat;
    T_VerFileHeader *ptVerFileHeader = NULL;
    ULONG ulCalCRCResult = 0;
    ULONG ulFileCRC = 0;

    fd = open(pchVerFile, O_RDONLY, 0);
    if (-1 == fd)
    {
        zte_printf_s("open %s failed! \n", pchVerFile);
        return BSP_ERROR;
    }

    /*获取文件长度*/
    if (fstat(fd, &tStat) < 0)
    {
        zte_printf_s("Can not fstat version file!\n");
        close(fd);
        return BSP_ERROR;
    }
    ulFileSize = tStat.st_size;

    /* 申请读版本文件缓存 */
    /* Started by AICoder, pid:46225m9f9111b2714ce60b1b30a9640dbf586e1c */
    pucRdVerFileBuff = (UCHAR *)malloc(ulFileSize);
    if (pucRdVerFileBuff == NULL)
    {
        zte_printf_s("version file size %u\n", ulFileSize);
        zte_printf_s("malloc read version file buffer failed!\n");
        close(fd);
        return BSP_ERROR;
    }
    /* Ended by AICoder, pid:46225m9f9111b2714ce60b1b30a9640dbf586e1c */

    zte_printf_s("reading file %s......", pchVerFile);
    iRetVal = zte_read_s(fd, pucRdVerFileBuff, ulFileSize, ulFileSize);
    if ((ULONG)iRetVal != ulFileSize)
    {
        zte_printf_s("Version file read error\n");
        close(fd);
        free(pucRdVerFileBuff);
        pucRdVerFileBuff = NULL;
        return BSP_ERROR;
    }
    close(fd);
    zte_printf_s("ok\n");

    ptVerFileHeader = (T_VerFileHeader *)pucRdVerFileBuff;
    ulFileCRC = ntohl(ptVerFileHeader->ulCRC32);

    zte_printf_s("CalculateCRC ......");

    ulCalCRCResult = CalculateCRC16(CRC_MASK, (UCHAR *)pucRdVerFileBuff + sizeof(ptVerFileHeader->ulCRC32), ulFileSize - sizeof(ptVerFileHeader->ulCRC32));

    /* 如果版本文件的CRC校验出错 */
    /* Started by AICoder, pid:s47e0jba02v11d0143940a7c7026d0002927a4d6 */
    if (ulFileCRC != ulCalCRCResult)
    {
        zte_printf_s("\n CRC calculated in Boot is 0x%x, but in file header is 0x%x!!\n", ulCalCRCResult, ulFileCRC);
        zte_printf_s("%s Version File CRC error !!!!\n", pchVerFile);
        free(pucRdVerFileBuff);
        return BSP_ERROR;
    }
    /* Ended by AICoder, pid:s47e0jba02v11d0143940a7c7026d0002927a4d6 */
    /* 如果版本文件的CRC校验出错 */
    else if (0 == ulCalCRCResult)
    {
        /* CRC为0的时候再校验一下数据是否全0，全0也认为CRC错误 */
        if (BSP_OK == CheckBufAllZero((UCHAR *)(pucRdVerFileBuff + sizeof(ptVerFileHeader->ulCRC32)), (ulFileSize - sizeof(ptVerFileHeader->ulCRC32))))
        {
            zte_printf_s("Version CRC error!! File all zero!!\n");
            free(pucRdVerFileBuff);
            return BSP_ERROR;
        }
    }
    zte_printf_s("ok.\n");
    free(pucRdVerFileBuff);
    return BSP_OK;
}

/**************************************************************************
* 函数名称: int BootAppStart(void)
* 功能描述: 工装 应用程序入口
* 输入参数: 无
* 输出参数:
* 返 回 值: 无
* 其它说明:
*
* 修改日期:    版本号     修改人        修改内容
* -----------------------------------------------
* 2010-05-25     V1.0      xxx        Created
**************************************************************************/
INT32 BootAppStart(void)
{
    int iLoopTime = 0;
    unsigned char ucdata = 0;
    #if defined(CONFIG_DRA62X)
    ULONG ulRet = BSP_ERROR;
    #endif
    
    BootLedRun(1);

    if (0 == BootGetPhyLinkStatus()) /*debug网口正常连通*/
    {
        zte_printf_s(" input 'bs' to stop auto boot in 10s\n");
        iLoopTime = 10;
    }
    #if(defined(CONFIG_LS10X3A) || defined(CONFIG_ZXW11200))
    /* GPS UART attach input data */
    else if (BSP_OK == BootAttachUartCom())
    {
        zte_printf_s(" input 'bs' to stop auto boot in 15s\n");
        iLoopTime = 15;
    }
    #endif
    else
    {
        zte_printf_s(" input 'bs' to stop auto boot in 5s\n");
        iLoopTime = 5;
    }
    /*refer to the explanation about autobootflag where it is defined*/
    WaitUserInputForNormal(iLoopTime);

    if ((1 == s_uitobootflag) || (2 == s_uitobootflag)) /* release or go */
    {
        #if defined(CONFIG_DRA62X)
        ulRet = BootFSScan();
        if (0 == ulRet)
        {
            jffs2_init();
        }
        else if (1 == ulRet)
        {
            ubifs_init(0);
            fs_recover(0);
        }
        else
        {
            zte_printf_s("No filesystem.Just go on...\n");
        }
        #elif (defined(CONFIG_ZX2112XX)) // dpdic3 mount the filesystem in the rcS
        #else
        #if defined(CONFIG_LS10X3A)
        if (1 == ls10x3a_is_config(BOARD_NR30_NETMUX)) // gps uart可复用为串口
        {
            if (STATUS_GPS_UART == BootGetUartCom())
            {
                BootSwitchUartCom(STATUS_DBG_UART); // restory defaule uart
            }
        }
        #endif
        #if defined(CONFIG_ZXW11200)
        if (STATUS_GPS_UART == BootGetUartCom())
        {
            BootSwitchUartCom(STATUS_DBG_UART); // restory defaule uart
        }
        #endif
        #if defined(CONFIG_RECORD_TIME)
        TimeNode(FILESYSTEM_START);
        #endif
        ubifs_init(0);
        fs_recover(0);
        #ifdef CONFIG_ZXW11200_NTN
        if(NTN_BOARD_2ND == get_ntn_board_type())
        {
            ubifs_init(2);
        }
        #endif
        #if defined(CONFIG_RECORD_TIME)
        TimeNode(FILESYSTEM_END);
        #endif
        #if defined(CONFIG_LS10X3A) && !defined(CONFIG_A9606_BOARD) /* A9606烧录板无CPLD */
        BootCheckFile();
        #endif
        #endif

        ucdata = NormalBoot();

        zte_printf_s("ucdata = %d \n", ucdata);
    }
    else if ((0 == s_uitobootflag) || (3 == s_uitobootflag)) /* bs */
    {
        BootWatchDogDisable();
        #if (defined(CONFIG_ZX211413) || defined(CONFIG_ZX211412))
        BootSetM0MoniA53();
        #endif
        #if defined(CONFIG_ZX2112XX)
        BootFpgaWdtDisable(); /*Disable Fpga Watch Dog*/
        #endif
        if (0 == s_uitobootflag)
        {
            #if defined(CONFIG_DRA62X)
            ulRet = BootFSScan();
            if (0 == ulRet)
            {
                jffs2_init();
            }
            else if (1 == ulRet)
            {
                ubifs_init(0);
            }
            else
            {
                zte_printf_s("No file system.Pls format to JFFS2 or UBIFS first.0:JFFS2,1:UBIFS\n");
            }
            #elif(defined(CONFIG_ZX2112XX)) // dpdic3 mount the filesystem in the rcS
            ;
            #else
            #if defined(CONFIG_RECORD_TIME)
            TimeNode(FILESYSTEM_START);
            #endif
            ubifs_init(0);
            #ifdef CONFIG_ZXW11200_NTN
            if(NTN_BOARD_2ND == get_ntn_board_type())
            {
                ubifs_init(2);
            }
            #endif
            #if defined(CONFIG_RECORD_TIME)
            TimeNode(FILESYSTEM_END);
            #endif
            #endif
        }

        // zte_printf_s("%s ",CFG_PROMPT);
    }

    return OK;
}

VOID MainLoop(VOID)
{
    /*NXP 新双boot流程中主备boot分别位于两片flash中*/
    #ifndef CONFIG_LS10X3A
    boot_flag_set();
    #endif

    #if(defined(CONFIG_ZYNQMPSOC))
    #if 0
    /*8101NR分支，共五处，搜BootGetDownloadFlag，固定不走康讯工装*/
    #else
    if ((0 == BootGetDownloadFlag()) && (0 == BootGetPhyLinkStatus())) /*debug网口正常连通*/
    {
        /*OSSchedLock();*/
        if (0 == BootDownLoadVersion())
        {
            /*zte_printf_s("bootm ......\n");*/
            /*OSSchedUnlock();*/
            /*BootLedStatusSet(0); */ /*4,跳入oss之前常亮 */
            BootWatchDogDisable();
            BootBoardSetReset(1, 0);
        }
        else
        {
            /*OSSchedUnlock();*/
            zte_printf_s("load Image from ftpserver fail 800811 \n");
        }
    }
    #endif
    #else
    /*加速器寄存器初始化*/
    #if(defined(CONFIG_ZX2112XX) || defined(CONFIG_ZX211412) || defined(CONFIG_ZX211413))
    BootCfgPllAndL2ss();
    #endif
    if (0 == BootGetPhyLinkStatus()) /*debug网口正常连通*/
    {
        /*OSSchedLock();*/
        if (0 == BootDownLoadVersion())
        {
            /*zte_printf_s("bootm ......\n");*/
            /*OSSchedUnlock();*/
            /*BootLedStatusSet(0); */ /*4,跳入oss之前常亮 */
            #if defined(CONFIG_ZXW11200)
            BootBoardSetReset(1, 1); /*解决外接DB15还回头时偶发的加载工装版本异常，不关狗，联动的，将调试串口留在uart0*/
            #else
            BootWatchDogDisable();
            BootBoardSetReset(1, 0);
            #endif
        }
        else
        {
            /*OSSchedUnlock();*/
            zte_printf_s("load Image from ftpserver fail 800811 \n");
        }
    }
    #endif

    if (-1 == BootAppStart())
    {
        zte_printf_s("app error\n");
    }
}

/*****************************************************************************
* 函数名称   : Bsp_GetVerHeader(*)
* 功能描述   : 获取规格包的版本头
* 读全局变量 :
* 写全局变量 :
* 输入参数   : pcFileName 规格包文件名
* 输出参数   : ptVerFileHeader 版本头结构体

* 返 回 值   : BSP_OK       -- 成功
*               其他         -- 异常失败
* 其它说明   :
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A),  宋志强@2012-12-20 12:15:58, 创建
*----------------------------------------------------------------------------
*/
ULONG BootGetVerHeader(const char *pcFileName, T_VerFileHeader *ptVerFileHeader)
{
    FILE *pf = NULL;
    int iReadLen;

    if ((NULL == pcFileName) || (NULL == ptVerFileHeader))
    {
        dbgInfo("[BSP] Input para null.");
        return BSP_ERROR_INVALID_PARA;
    }

    /* 读取版本文件内容 */
    pf = fopen(pcFileName, "rb");
    if (NULL == pf)
    {
        dbgInfo("[BSP] Open %s failed!", pcFileName);
        return BSP_ERROR;
    }

    zte_memset_s((UCHAR *)ptVerFileHeader, sizeof(T_VerFileHeader), 0, sizeof(T_VerFileHeader));
    iReadLen = fread(ptVerFileHeader, 1, sizeof(T_VerFileHeader), pf);
    if (sizeof(T_VerFileHeader) != iReadLen)
    {
        dbgErr("[BSP] Read VerFileHead in %s failed!", pcFileName);
        zte_fclose_s(pf);
        return BSP_ERROR;
    }

    zte_fclose_s(pf);

    ptVerFileHeader->ulCRC32          = ntohl(ptVerFileHeader->ulCRC32);
    ptVerFileHeader->usVerType        = ntohs(ptVerFileHeader->usVerType);
    ptVerFileHeader->ulCompressedSize = ntohl(ptVerFileHeader->ulCompressedSize);
    ptVerFileHeader->ulCompressedCRC  = ntohl(ptVerFileHeader->ulCompressedCRC);
    ptVerFileHeader->ulOriginalSize   = ntohl(ptVerFileHeader->ulOriginalSize);
    ptVerFileHeader->ulOriginalCRC    = ntohl(ptVerFileHeader->ulOriginalCRC);
    ptVerFileHeader->ulSoftType       = ntohl(ptVerFileHeader->ulSoftType);
    ptVerFileHeader->ulCreateTime     = ntohl(ptVerFileHeader->ulCreateTime);

    return BSP_OK;
}

ULONG BspGetFlashBlkSize(ULONG ulFlashAddr, ULONG ulSrcFileLen, ULONG *ulBuffLen)
{
    UINT32 count;
    ULONG ulRetVal = BSP_ERROR;
    for (count = 0; count < boot_tFlashInfo.ulPartitionNum - 1; count++)
    {
        if (ulFlashAddr >= boot_tFlashInfo.atPartitionMap[count].ulPartitionOffset)
        {
            if ((ulFlashAddr + ulSrcFileLen) <= (boot_tFlashInfo.atPartitionMap[count].ulPartitionOffset + boot_tFlashInfo.atPartitionMap[count].ulPartitionSize))
            {
                ulRetVal = BspGetFlashMtdSectorSize(count, ulBuffLen);
                if (ulRetVal)
                {
                    dbgErr("Get flash mtd sector size failed, reason %d!\n", ulRetVal);
                    return BSP_ERROR;
                }
                break;
            }
        }
    }
    return ulRetVal;
}

/*****************************************************************************
* 函数名称   : Bsp_SlowCopyFileToFlash(*)
* 功能描述   : 拷贝数据到Flash
* 读全局变量 :
* 写全局变量 :
* 输入参数   : pucSrcFile 源数据
                ulFlashAddr Flash 地址
* 输出参数   :

* 返 回 值   : BSP_OK       -- 成功
*              其他         -- 异常失败
* 其它说明   :
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A),  宋志强@2012-12-20 12:15:58, 创建
*----------------------------------------------------------------------------
*/
ULONG BootSlowCopyFileToFlash(CHAR *pucSrcFile, ULONG ulFlashAddr)
{
    ULONG ulRetVal = BSP_OK;
    ULONG ulSrcFileLen = 0;
    UCHAR *pucVerBuff = NULL;
    ULONG ulBuffLen = 0;
    struct stat tStatInfo;
    FILE *pf = NULL;
    int iReadLen;
    /* Started by AICoder, pid:0dd5ce9e0f705d8149fb0abb30f2a31819480887 */
    INT32 fd = 0;

    INPUT_POINTER_CHECK(pucSrcFile);

    fd = open(pucSrcFile, O_RDONLY);
    if (fd == -1) {
        zte_printf_s("open %s failed! \n", pucSrcFile);
        return BSP_ERROR;
    }

    /* 获取运行版本文件长度 */
    if (fstat(fd, &tStatInfo) < 0) {
        zte_printf_s("Can not fstat version file!\n");
        close(fd);
        return BSP_ERROR;
    }

    close(fd);
    /* Ended by AICoder, pid:0dd5ce9e0f705d8149fb0abb30f2a31819480887 */

    ulSrcFileLen = tStatInfo.st_size;

    /*获取mtd分区块大小*/
    ulRetVal = BspGetFlashBlkSize(ulFlashAddr, ulSrcFileLen, &ulBuffLen);
    if (ulRetVal || (0 == ulBuffLen) || (ulBuffLen > 0x100000))
    {
        dbgErr("ERROR: plsese chech file size & flashAddr, ulRetVal: 0x%x, ulBuffLen: 0x%x!", ulRetVal, ulBuffLen);
        return BSP_ERROR;
    }
    /* 以只读方式打开源文件 */
    pf = fopen(pucSrcFile, "rb");
    if (NULL == pf)
    {
        dbgErr("open file <%s> failed!n", pucSrcFile);
        return BSP_ERROR;
    }
    /* 申请内存 */
    /* Started by AICoder, pid:oe4b9n1d2bh6651143680926706f6b05e3e7e99f */
    pucVerBuff = malloc(ulBuffLen);
    if (pucVerBuff  == NULL)
    {
        dbgErr("malloc buffer failed!");
        /* 关闭源文件 */
        zte_fclose_s(pf);
        return BSP_ERROR_MEM_MALLOC;
    }
    /* Ended by AICoder, pid:oe4b9n1d2bh6651143680926706f6b05e3e7e99f */

    while (ulSrcFileLen >= ulBuffLen)
    {
        /* 读取源文件内容 */
        zte_memset_s(pucVerBuff, ulBuffLen, 0, ulBuffLen);
        iReadLen = fread(pucVerBuff, 1, ulBuffLen, pf);
        if (iReadLen != ulBuffLen)
        {
            dbgErr("read file <%s> failed!, iReadLen : 0x%x!\n", pucSrcFile, iReadLen);
            ulRetVal = BSP_ERROR;
            goto err;
        }
        /* 延时10ms */
        BootSysMsDelay(10);

        /* 将读取到的内容写入flash */
        /* Started by AICoder, pid:zf28aocdc7q0a8e147ff0b00b0783b06cdf692fb */
        ulRetVal = BspFlashWrite(ulFlashAddr, pucVerBuff, ulBuffLen);
        if (ulRetVal != BSP_OK)
        {
            dbgErr("write flash failed!\n");
            goto err;
        }
        /* Ended by AICoder, pid:zf28aocdc7q0a8e147ff0b00b0783b06cdf692fb */

        BootSysMsDelay(10);
        ulSrcFileLen = ulSrcFileLen - ulBuffLen;
        ulFlashAddr = ulFlashAddr + ulBuffLen;
    }
    if (BSP_OK == ulRetVal)
    {
        if (ulSrcFileLen > 0)
        {
            /* 读源文件内容 */
            zte_memset_s(pucVerBuff, ulBuffLen, 0, ulBuffLen);
            iReadLen = fread(pucVerBuff, 1, ulSrcFileLen, pf);
            if (iReadLen != ulSrcFileLen)
            {
                dbgErr("read file <%s> failed!, iReadLen : 0x%x!!\n", pucSrcFile, iReadLen);
                ulRetVal = BSP_ERROR;
                goto err;
            }

            /* 延时10ms */
            BootSysMsDelay(10);

            /* 将读取的内容写入flash */
            /* Started by AICoder, pid:ze44er40cbaf0ee1469f08930015e50a40b5e8f8 */
            ulRetVal = (ULONG)BspFlashWrite(ulFlashAddr, pucVerBuff, ulSrcFileLen);
            if (ulRetVal != BSP_OK)
            {
                dbgErr("write flash failed!!");
            }
            /* Ended by AICoder, pid:ze44er40cbaf0ee1469f08930015e50a40b5e8f8 */
            /*延时10ms*/
            BootSysMsDelay(10);
        }
    }
err:
    /* 关闭源文件 */
    zte_fclose_s(pf);
    free(pucVerBuff);
    pucVerBuff = NULL;
    return ulRetVal;
}
/*****************************************************************************
* 函数名称   : Bsp_CalculateFlashVerCrc(*)
* 功能描述   : 计算保护区版本的CRC值
* 读全局变量 :
* 写全局变量 :
* 输入参数   : ulFlashAddr flash 地址
                ulVerLen 版本长度
* 输出参数   : pulCrc CRC值

* 返 回 值   : BSP_OK       -- 成功
*               其他         -- 异常失败
* 其它说明   :
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A),  宋志强@2012-12-20 12:15:58, 创建
*----------------------------------------------------------------------------
*/
ULONG BootCalculateFlashVerCrc(ULONG ulFlashAddr, ULONG ulVerLen, ULONG *pulCrc)
{
    ULONG ulRetVal   = BSP_OK;
    ULONG ulBuffLen  = 0;
    ULONG ulCalCRC   = 0xffff;
    UCHAR *pucBuffer = NULL;

    INPUT_POINTER_CHECK(pulCrc);
    ulBuffLen = BspGetFlashEraseSectorSize();

    /* 申请内存用于CRC校验 */
    pucBuffer = (UCHAR *)malloc(ulBuffLen);
    if (NULL == pucBuffer)
    {
        dbgErr("malloc buffer for crc calculte failed!\n");
        return BSP_ERROR;
    }

    while (ulVerLen >= ulBuffLen)
    {
        /* 读取flash值到内存中 */
        if (BSP_OK != BspFlashRead(ulFlashAddr, (UCHAR *)pucBuffer, ulBuffLen))
        {
            ulRetVal = BSP_ERROR;
            break;
        }

        ulCalCRC    = BspCountCrc16((USHORT)ulCalCRC, (UCHAR *)pucBuffer, ulBuffLen);
        ulFlashAddr = ulFlashAddr + ulBuffLen;
        ulVerLen    = ulVerLen - ulBuffLen;
        BootSysMsDelay(30);
    }
    if (BSP_OK == ulRetVal)
    {
        if (ulVerLen > 0)
        {
            if (BSP_OK != BspFlashRead(ulFlashAddr, (UCHAR *)pucBuffer, ulVerLen))
            {
                ulRetVal = BSP_ERROR;
            }
            else
            {
                ulCalCRC = BspCountCrc16((USHORT)ulCalCRC, (UCHAR *)pucBuffer, ulVerLen);
            }
        }
    }

    free(pucBuffer);
    pucBuffer = NULL;
    *pulCrc = ulCalCRC;

    return ulRetVal;
}

/*****************************************************************************
* 函数名称   : CopyRunVerToFlash(*)
* 功能描述   : 刷新RunVer 到保护区
* 读全局变量 :
* 写全局变量 :
* 输入参数   : ulIndex 规格类型 0- CPU版本， 1- FPGA 版本
* 输出参数   : ptProtectHead  版本头结构体

* 返 回 值   : BSP_OK       -- 成功
*               其他         -- 异常失败
* 其它说明   :
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A),  宋志强@2012-12-20 12:15:58, 创建
*----------------------------------------------------------------------------
*/
ULONG BootCopyRunVerToFlash(ULONG ulIndex, T_VerProtectHead *ptProtectHead)
{
    ULONG ulRetVal                      = BSP_OK;
    ULONG ulSrcFileLen                  = 0;
    ULONG ulProtectAddr                 = 0;
    ULONG ulProtectLen                  = 0;
    ULONG ulProtectHeadFlashLen         = 0;
    ULONG ulCpuOffset                   = 0;
    ULONG ulCpuFileLen                  = 0;
    ULONG ulFlashSection                = 0;
    BYTE ucLoop                         = 0;
    time_t ulWriteFlashTime             = 0;
    T_ProtectVerInfoHead *ptVerInfoHead = NULL;
    T_ProtectVerInfo *ptVerInfo         = NULL;
    T_VerFileHeader tSwFileHead;
    const CHAR* acSrcFileName;
    ULONG ulProtectVerCrc               = 0;
    ULONG ulCalCrc                      = 0;
    struct stat tStatInfo;
    /* Started by AICoder, pid:xfeb45f747h435f1485c08ab30e25c2a8fd8617a */
    INT32 fd = 0;
    INPUT_POINTER_CHECK(ptProtectHead);

    ulFlashSection = BspGetFlashEraseSectorSize();

    if (0 == ulIndex)
    {
        acSrcFileName = "/ata/rru/cur.swv";
    }
    else
    {
        acSrcFileName = "/ata/rru/fpga/cur.swv";
    }

    fd = open(acSrcFileName, O_RDONLY, 0);
    if (fd == -1)
    {
        zte_printf_s("open %s failed! \n", acSrcFileName);
        return BSP_ERROR;
    }
    /* 获取运行版本文件长度 */
    if (fstat(fd, &tStatInfo) < 0)
    {
        zte_printf_s("Can not fstat version file!\n");
        close(fd);
        return BSP_ERROR;
    }
    close(fd);
    /* Ended by AICoder, pid:xfeb45f747h435f1485c08ab30e25c2a8fd8617a */
    ulSrcFileLen = tStatInfo.st_size;
    /* 读取运行版本文件头 */
    zte_memset_s(&tSwFileHead, sizeof(T_VerFileHeader), 0, sizeof(T_VerFileHeader));
    ulRetVal = BootGetVerHeader(acSrcFileName, &tSwFileHead);
    if (BSP_OK != ulRetVal)
    {
        dbgInfo("Get file <%s> head failed!, reason: %d", acSrcFileName, ulRetVal);
        return BSP_ERROR;
    }

    /* 获取写flash时间 */
    time(&ulWriteFlashTime);

    ptVerInfoHead = (T_ProtectVerInfoHead *)ptProtectHead;
    ptVerInfo     = (T_ProtectVerInfo *)(ptVerInfoHead + 1);

    /* 获取保护区头信息 */
    ulProtectLen          = BootGetVerProtectLen();
    ulProtectAddr         = BootGetFlashVerProtectAddr();
    ulProtectHeadFlashLen = (1 + sizeof(T_VerProtectHead) / ulFlashSection) * ulFlashSection;

    /* CPU版本是保护区第一个版本、FPGA是第二个版本 */
    if (0 == ulIndex)
    {
        ptVerInfo->ulVerOffSet = ulProtectHeadFlashLen;
    }
    else
    {
        /* 获取CPU版本的偏移和文件长度 */
        ulCpuOffset = ptVerInfo->ulVerOffSet;
        ulCpuFileLen = ptVerInfo->tVerInfoFile.ulSWLength;
        /* fpga版本信息为第二个 */
        ptVerInfo++;
        ptVerInfo->ulVerOffSet = (1 + (ulCpuOffset + ulCpuFileLen) / ulFlashSection) * ulFlashSection;
    }
    ptVerInfo->tVerInfoFile.ulSWLength               = ulSrcFileLen;
    ptVerInfo->tVerInfoFile.ulCreateTime             = ulWriteFlashTime;
    ptVerInfo->tVerInfoFile.ulCRC32                  = tSwFileHead.ulCRC32;
    ptVerInfo->tVerInfoFile.tFILESWINF.ulSoftType    = tSwFileHead.ulSoftType;
    ptVerInfo->tVerInfoFile.tFILESWINF.ucCpuType     = tSwFileHead.ucCpuType;
    ptVerInfo->tVerInfoFile.tFILESWINF.ucVersionKind = (UCHAR)ulIndex;
    zte_memcpy_s(ptVerInfo->tVerInfoFile.tFILESWINF.acVersionNo, VERNO_LEN, tSwFileHead.ucVerNo, VERNO_LEN);
    ptVerInfoHead->ulCRC = BspCountCrc16(0xFFFF, (UCHAR *)ptProtectHead + sizeof(T_ProtectVerInfoHead), sizeof(T_VerProtectHead) - sizeof(T_ProtectVerInfoHead));

    dbgInfo("ulProtectAddr : %x, ulVerOffSet: 0x%x, ulSWLength : %d, ulCRC32 : 0x%x,ulWriteFlashTime: %d, ucSwClass: %d, acVersionNo: %s\n",
        ulProtectAddr, ptVerInfo->ulVerOffSet, ptVerInfo->tVerInfoFile.ulSWLength,
        ptVerInfo->tVerInfoFile.ulCRC32, ptVerInfo->tVerInfoFile.ulCreateTime,
        ptVerInfo->tVerInfoFile.tFILESWINF.ucVersionKind, ptVerInfo->tVerInfoFile.tFILESWINF.acVersionNo);

    /* 偏移加上文件长度不能超过保护区长度 */
    if ((ptVerInfo->ulVerOffSet + ulSrcFileLen) > ulProtectLen)
    {
        dbgErr("error!file <%s> length <%d> append offset <%d> is larger the and protect length <%d>!\n",
            acSrcFileName, ulSrcFileLen, ptVerInfo->ulVerOffSet, ulProtectLen);
        return BSP_ERROR;
    }

    /* 写版本文件 */
    for (ucLoop = 0; ucLoop < 3; ucLoop++)
    {
        ulRetVal = BootSlowCopyFileToFlash((CHAR *)acSrcFileName, (ulProtectAddr + ptVerInfo->ulVerOffSet));
        if (BSP_OK != ulRetVal)
        {
            dbgInfo("copy file <%s> to flash times %d failed! reason: %d\n", acSrcFileName, ucLoop, ulRetVal);
            continue;
        }

        /* 写flash完毕再对flash中的版本进行CRC校验 */
        if (BSP_OK != BspFlashRead((ulProtectAddr + ptVerInfo->ulVerOffSet), (UCHAR *)&ulProtectVerCrc, sizeof(ULONG)))
        {
            dbgErr("BspFlashRead Failed! time: %d\n", ucLoop);
            continue;
        }

        BootSysMsDelay(1000);
        if (BSP_OK != BootCalculateFlashVerCrc((ulProtectAddr + ptVerInfo->ulVerOffSet + sizeof(ULONG)), (ulSrcFileLen - sizeof(ULONG)), &ulCalCrc))
        {
            dbgInfo("Check Flash Crc Failed! time: %d\n", ucLoop);
            continue;
        }

        ulProtectVerCrc = ntohl(ulProtectVerCrc);

        if (ulProtectVerCrc != ulCalCrc)
        {
            dbgInfo("Crc check Failed!, Head: %d, Calculate: %d!\n", ulProtectVerCrc, ulCalCrc);
            continue;
        }
        else
        {
            break;
        }
    }

    if (3 == ucLoop)
    {
        dbgErr("copy file <%s> to flash failed!\n", acSrcFileName);
        return BSP_ERROR;
    }

    return ulRetVal;
}
/*****************************************************************************
* 函数名称   : FlushRuSwToProtect(*)
* 功能描述   : 刷新RunVer 到保护区，只刷新CPU,FPGA版本到保护区
* 读全局变量 :
* 写全局变量 :
* 输入参数   :
* 输出参数  :

* 返 回 值   : BSP_OK       -- 成功
*               其他         -- 异常失败
* 其它说明   :
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A),  宋志强@2012-12-20 12:15:58, 创建
*----------------------------------------------------------------------------
*/
ULONG FlushRuSwToProtect()
{
    T_VerProtectHead* ptProtectHead;
    ULONG ulProtectAddr, ulFlashSection;

    ulProtectAddr = BootGetFlashVerProtectAddr();
    ulFlashSection = BspGetFlashEraseSectorSize();

    ptProtectHead = (T_VerProtectHead*)malloc(sizeof(T_VerProtectHead));
    if (NULL == ptProtectHead)
    {
        return BSP_ERROR;
    }
    zte_memset_s((UCHAR *)ptProtectHead, sizeof(T_VerProtectHead), 0, sizeof(T_VerProtectHead));
    if (BSP_OK != BootCopyRunVerToFlash(0, ptProtectHead))
    {
        free(ptProtectHead);
        return BSP_ERROR;
    }
    if (BSP_OK != BootCopyRunVerToFlash(1, ptProtectHead))
    {
        free(ptProtectHead);
        return BSP_ERROR;
    }

    /* 每次刷新保护区头之前先擦出保护区头 */
    if (BSP_OK != BspFlashErase(ulProtectAddr, ulFlashSection))
    {
        dbgErr("Erease flash protect head failed!");
        free(ptProtectHead);
        return FALSE;
    }
    dbgInfo("copy done ,will flush protect head\n");
    /* 刷新完版本之后需要将版本信息及重新计算后的版本头CRC写到保护区头中 */
    dbgInfo("ulProtectHead : %x, ulCRC32 : 0x%x\n", ulProtectAddr, ptProtectHead->tVerInfoFileHead.ulCRC);
    if (BSP_OK != BspFlashWrite(ulProtectAddr, (UCHAR *)ptProtectHead, sizeof(T_VerProtectHead)))
    {
        dbgErr("write protect head flash error!");
        free(ptProtectHead);
        return FALSE;
    }
    free(ptProtectHead);
    dbgInfo("Flush Run Software to Flash succeed!\n");
    return BSP_OK;
}

/****************************************************************************
* 函数名称   : BspBuildAucmacRet(*)
* 功能描述   : 对gaucmacRet数组重写入刷保护区结果,并写入校验值
* 读全局变量 : 无
* 写全局变量 : 无
* 输入参数   : ucFailOrSucc: 0x55 表示刷flash成功,0xAA表示刷flash失败
* 输出参数   : 无
* 返 回 值   : 0 成功, else 入参异常
* 其它说明   :
*---------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), wyj @2013-03-28  12:15:58, creat
*************************************************************************/
ULONG BspBuildAucmacRet(UCHAR ucFailOrSucc)
{
    ULONG ulLoop = 0;
    UCHAR ucValue = 0;

    if ((0xAA != ucFailOrSucc) && (0x55 != ucFailOrSucc))
    {
        zte_printf_s("Input param [0x%x] error!\n", ucFailOrSucc);
        return -1;
    }

    gaucmacRet[24] = ucFailOrSucc;

    for (ulLoop = 0; ulLoop < 39; ulLoop++)
    {
        ucValue += gaucmacRet[ulLoop];
    }
    gaucmacRet[39] = ucValue;
    return 0;
}
/*****************************************************************************
* 函数名称   : wrflashprotect(*)
* 功能描述   : 刷新RunVer 到保护区，只刷新CPU,FPGA版本到保护区(封装为原kuboot命令)
* 读全局变量 :
* 写全局变量 :
* 输入参数   :
* 输出参数  :

* 返 回 值   : BSP_OK       -- 成功
*               其他         -- 异常失败
* 其它说明   :
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A),  00086970  20151120   创建
*----------------------------------------------------------------------------
*/
ULONG wrflashprotect(VOID)
{
    ULONG ulRet = BSP_ERROR;
    ULONG ulSocketLen = BSP_ERROR;
    ulRet = FlushRuSwToProtect();
    if (ulRet == BSP_OK)
    {
        BspBuildAucmacRet(WRITE_FLASH_SUCCESS); /*标示刷flash成功*/
    }
    else
    {
        BspBuildAucmacRet(WRITE_FLASH_FAILED); /*标示刷flash失败*/
    }

    ulSocketLen = BspEthSend(gaucmacRet, 40);
    return ulSocketLen;
}
/*****************************************************************************
* 函数名称   : testFlashWrite(*)
* 功能描述   : 刷新RunVer 到保护区，只刷新CPU,FPGA版本到保护区(封装为原kuboot命令)
* 读全局变量 :
* 写全局变量 :
* 输入参数   :
* 输出参数  :

* 返 回 值   : BSP_OK       -- 成功
*               其他         -- 异常失败
* 其它说明   :
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A),  00086970  20151120   创建
*----------------------------------------------------------------------------
*/
ULONG testCharFlashWrite(ULONG ulOffset, UCHAR ulDate)
{
    return BspFlashWrite(ulOffset, &ulDate, 1);
}
/*****************************************************************************
* 函数名称   : BspGetBootSoftVersion(*)
* 功能描述   :
* 读全局变量 : 无
* 写全局变量 : 无
* 输入参数   : pcCpuSoftVer  - 存储版本信息指针
*           : ucSizeofBytes - 版本信息长度
* 输出参数   :
* 返 回 值   : BSP_OK->无错,否则返回对应的错误码
* 其它说明   : RRU通用适配接口函数
*---------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 00086970@2016-05-27 15:22:00  创建
*----------------------------------------------------------------------------
*/
ULONG BspGetBootSoftVersion(CHAR *pcBootSoftVer, UCHAR ucSizeofBytes)
{
    if (pcBootSoftVer == NULL)
    {
        return BSP_ERROR_NULL_POINTER;
    }
    zte_memcpy_s(pcBootSoftVer, 150, (CHAR *)BOOTK_VER_ADRS, ucSizeofBytes);
    pcBootSoftVer[ucSizeofBytes - 1] = 0;
    return BSP_OK;
}

VOID BootVer(ULONG model)
{
    CHAR ver[150] = {0};
    #if(defined(CONFIG_LS10X3A) || defined(CONFIG_ZX2112XX) || defined(CONFIG_ZXW11200) || defined(CONFIG_ZX211412) || defined(CONFIG_ZX211413)) || defined(CONFIG_ZYNQMPSOC)
    if (1 == model)
    {
        zte_printf_s("First ");
        BootGetVersion(ver, 0);
    }
    else if (2 == model)
    {
        zte_printf_s("Second ");
        BootGetVersion(ver, 1);
    }
    #if(defined(CONFIG_ZXW11200) || defined(CONFIG_ZX211413))
    else if (3 == model)
    {
        zte_printf_s("Third ");
        BootGetVersion(ver, 2);
    }
    #endif
    else
    {
        BspGetBootSoftVersion(ver, 44);
    }
    #else
    BspGetBootSoftVersion(ver, 44);
    #endif
    dbgPrn("Boot Version: %s\n", ver);
    return;
}


/* Started by AICoder, pid:l33f9c9273b64d314aac09071029b811cc04d00b */
#ifdef RENAME_FUNC_UTFT
INT UTFT_BootDownLoadVersion(VOID)
{
    return BootDownLoadVersion();
}
#endif
/* Ended by AICoder, pid:l33f9c9273b64d314aac09071029b811cc04d00b */

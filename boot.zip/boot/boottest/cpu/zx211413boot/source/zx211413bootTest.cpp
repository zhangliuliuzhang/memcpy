
/* Started by AICoder, pid:s2d77r5fbbde348141920b8530c7dd05aa18a751 */
#include "gtest/gtest.h"
#include <mockcpp/mokc.h>
#include "zx211413boottest.h"


TEST(BootGetSfpPhyLinkSpeedTest, Handles10M) {
    UINT32 speed = 0x8; // (0x8 & 0xc) >> 2 == 2
    EXPECT_EQ(100, BootGetSfpPhyLinkSpeed(speed));
}

TEST(BootGetSfpPhyLinkSpeedTest, Handles100M) {
    UINT32 speed = 0x4; // (0x4 & 0xc) >> 2 == 1
    EXPECT_EQ(100, BootGetSfpPhyLinkSpeed(speed));
}

TEST(BootGetSfpPhyLinkSpeedTest, Handles1000M) {
    UINT32 speed = 0x0; // (0x0 & 0xc) >> 2 == 0
    EXPECT_EQ(1000, BootGetSfpPhyLinkSpeed(speed));
}

TEST(BootGetSfpPhyLinkSpeedTest, HandlesInvalidSpeed) {
    UINT32 speed = 0xFF; // (0x1 & 0xc) >> 2 == 0x0, but not matching any case
    UINT32 uiRet = BootGetSfpPhyLinkSpeed(speed);
    EXPECT_EQ(BSP_ERROR, uiRet);
}




TEST(BootGetPhyLinkStatusTest, QCellBoardTypeLinkOk) {
    g_qcell_type = QCELL_BOARDTYPE;
    UINT32 ulValue = NET_STATE_LINKOK;
    MOCKER(BspGetPhyStatus).stubs().with(any(), outBoundP(&ulValue), any()).will(returnValue(BSP_OK));
    UINT32 retVal = BootGetPhyLinkStatus();
    EXPECT_EQ(retVal, 0);
    GlobalMockObject::verify();
}

TEST(BootGetPhyLinkStatusTest, QCellBoardTypeLinkDown) {
    g_qcell_type = QCELL_BOARDTYPE;
    UINT32 ulValue = 0;
    MOCKER(BspGetPhyStatus).stubs().with(any(), outBoundP(&ulValue), any()).will(returnValue(BSP_OK));
    UINT32 retVal = BootGetPhyLinkStatus();
    EXPECT_EQ(retVal, 1);
    GlobalMockObject::verify();
}

TEST(BootGetPhyLinkStatusTest, QCellBoardTypeBspGetPhyStatusError) {
    g_qcell_type = QCELL_BOARDTYPE;
    MOCKER(BspGetPhyStatus).stubs().with(any(), any(), any()).will(returnValue(BSP_ERROR));
    UINT32 retVal = BootGetPhyLinkStatus();
    EXPECT_EQ(retVal, BSP_ERROR);
    GlobalMockObject::verify();
}

TEST(BootGetPhyLinkStatusTest, NonQCellBoardTypeIIC1LinkOk) {
    g_qcell_type = 0;
    UINT32 ulOptflag = IIC1_SUPPORT_COOPER;
    UINT32 ulValue = NET_STATE_LINKOK;
    MOCKER(BootGetCooperIndex).stubs().will(returnValue(ulOptflag));//如果原接口需要传入的是是指针类型，就需要用outBoundP，否则就用eq
    MOCKER(BootGetSfpPhyStatus).stubs().with(eq(ulOptflag), outBoundP(&ulValue)).will(returnValue(BSP_OK));
    UINT32 retVal = BootGetPhyLinkStatus();
    EXPECT_EQ(retVal, PHY_LINK_UP);
    GlobalMockObject::verify();
}

TEST(BootGetPhyLinkStatusTest, NonQCellBoardTypeIIC1LinkDown) {
    g_qcell_type = 0;
    UINT32 ulOptflag = IIC1_SUPPORT_COOPER;
    UINT32 ulValue = 0;
    MOCKER(BootGetCooperIndex).stubs().will(returnValue(ulOptflag));
    MOCKER(BootGetSfpPhyStatus).stubs().with(eq(ulOptflag), outBoundP(&ulValue)).will(returnValue(BSP_OK));
    UINT32 retVal = BootGetPhyLinkStatus();
    EXPECT_EQ(retVal, PHY_LINK_DOWN);
    GlobalMockObject::verify();
}

TEST(BootGetPhyLinkStatusTest, NonQCellBoardTypeIIC1BootGetSfpPhyStatusError) {
    g_qcell_type = 0;
    UINT32 ulOptflag = IIC1_SUPPORT_COOPER;
    MOCKER(BootGetCooperIndex).stubs().will(returnValue(ulOptflag));
    MOCKER(BootGetSfpPhyStatus).stubs().with(eq(ulOptflag), any()).will(returnValue(BSP_ERROR));
    UINT32 retVal = BootGetPhyLinkStatus();
    EXPECT_EQ(retVal, BSP_ERROR);
    GlobalMockObject::verify();
}

TEST(BootGetPhyLinkStatusTest, NonQCellBoardTypeIIC2LinkOk) {
    g_qcell_type = 0;
    UINT32 ulOptflag = IIC2_SUPPORT_COOPER;
    UINT32 ulValue = NET_STATE_LINKOK;
    MOCKER(BootGetCooperIndex).stubs().will(returnValue(ulOptflag));
    MOCKER(BootGetSfpPhyStatus).stubs().with(eq(ulOptflag), outBoundP(&ulValue)).will(returnValue(BSP_OK));
    UINT32 retVal = BootGetPhyLinkStatus();
    EXPECT_EQ(retVal, PHY_LINK_UP);
    GlobalMockObject::verify();
}

TEST(BootGetPhyLinkStatusTest, NonQCellBoardTypeNoSupport) {
    g_qcell_type = 0;
    UINT32 ulOptflag = IIC_NO_SUPPORT_COOPER;
    MOCKER(BootGetCooperIndex).stubs().will(returnValue(ulOptflag));
    UINT32 retVal = BootGetPhyLinkStatus();
    EXPECT_EQ(retVal, 1);
    GlobalMockObject::verify();
}

/* Ended by AICoder, pid:s2d77r5fbbde348141920b8530c7dd05aa18a751 */
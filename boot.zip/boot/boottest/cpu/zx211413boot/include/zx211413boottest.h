/* Started by AICoder, pid:rb1793ca158bca414c010978900b172bbd80c2ea */
#include "bootapp.h"
#include "phy.h"

extern "C"
{
    UINT32 BootGetSfpPhyLinkSpeed(UINT32 speed);
    UINT32 BspGetPhyStatus(UINT32 ulDevNum, UINT32 *pulStat, UINT32 ulMode);
    UINT32 BootGetPhyLinkStatus(VOID);
    UINT32 BootGetCooperIndex(VOID);
    UINT32 BootGetSfpPhyStatus(UINT32 ulOptIndex, UINT32 *pulStat);
}
/* Ended by AICoder, pid:rb1793ca158bca414c010978900b172bbd80c2ea */
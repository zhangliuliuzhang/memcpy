/* Started by AICoder, pid:c1f3e642f40610f14f830be930571c2060505753 */
#include "bootadp.h"
#include "zx211412boot.h"

extern "C" {
    UINT8 BootGetKBootMSFlag();
    UINT32 BspFlashRead(UINT32 ulOffset, UCHAR *pucBufAddr, UINT32 ulDataLen);
    UINT32 BootGetVersion(char *headPtr,char model);
}
/* Ended by AICoder, pid:c1f3e642f40610f14f830be930571c2060505753 */
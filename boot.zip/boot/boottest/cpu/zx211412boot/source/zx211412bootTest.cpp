/* Started by AICoder, pid:4a9e1pd1dan2ecc1496b09f541cb9c02d0f292a6 */
#include "gtest/gtest.h"
#include <mockcpp/mokc.h>
#include "zx211412boottest.h"


TEST(BootGetVersionTest, NullPointer) {
    CHAR* headPtr = nullptr;
    UINT32 retVal = BootGetVersion(headPtr, 0);
    EXPECT_EQ(retVal, BSP_ERROR);
}

TEST(BootGetVersionTest, ModelZeroSuccess) {
    CHAR headPtr[BOOT_VER_STR_MAX_LEN] = {0};
    MOCKER(BootGetKBootMSFlag).stubs().will(returnValue(MASTER_KUBOOT_OK));//打桩：模拟BootGetKBootMSFlag接口返回MASTER_KUBOOT_OK
    MOCKER(BspFlashRead).stubs().with(any(), any(), any()).will(returnValue(BSP_OK));//打桩：模拟BspFlashRead接口返回BSP_OK
    UINT32 retVal = BootGetVersion(headPtr, 0);
    EXPECT_EQ(retVal, BSP_OK);
    EXPECT_TRUE(strlen(headPtr) > 0);
    GlobalMockObject::verify();
}

TEST(BootGetVersionTest, ModelOneSuccess) {
    CHAR headPtr[BOOT_VER_STR_MAX_LEN] = {0};
    MOCKER(BootGetKBootMSFlag).stubs().will(returnValue(MASTER_KUBOOT_OK));
    MOCKER(BspFlashRead).stubs().with(any(), any(), any()).will(returnValue(BSP_OK));
    UINT32 retVal = BootGetVersion(headPtr, 1);
    EXPECT_EQ(retVal, BSP_OK);
    EXPECT_TRUE(strlen(headPtr) > 0);
    GlobalMockObject::verify();
}

TEST(BootGetVersionTest, InvalidCheckFlag) {
    CHAR headPtr[BOOT_VER_STR_MAX_LEN] = {0};
    MOCKER(BootGetKBootMSFlag).stubs().will(returnValue(0));
    UINT32 retVal = BootGetVersion(headPtr, 0);
    EXPECT_EQ(retVal, BSP_ERROR);
    GlobalMockObject::verify();
}

TEST(BootGetVersionTest, FlashReadErrorModelZero) {
    CHAR headPtr[BOOT_VER_STR_MAX_LEN] = {0};
    MOCKER(BootGetKBootMSFlag).stubs().will(returnValue(MASTER_KUBOOT_OK));
    MOCKER(BspFlashRead).stubs().with(any(), any(), any()).will(returnValue(BSP_ERROR));
    UINT32 retVal = BootGetVersion(headPtr, 0);
    EXPECT_EQ(retVal, BSP_ERROR);
    GlobalMockObject::verify();
}

TEST(BootGetVersionTest, FlashReadErrorModelOne) {
    CHAR headPtr[BOOT_VER_STR_MAX_LEN] = {0};
    MOCKER(BootGetKBootMSFlag).stubs().will(returnValue(MASTER_KUBOOT_OK));
    MOCKER(BspFlashRead).stubs().with(any(), any(), any()).will(returnValue(BSP_ERROR));
    UINT32 retVal = BootGetVersion(headPtr, 1);
    EXPECT_EQ(retVal, BSP_ERROR);
    GlobalMockObject::verify();
}


TEST(BootGetVersionTest, SlaveKuBootOk) {
    CHAR headPtr[BOOT_VER_STR_MAX_LEN] = {0};
    MOCKER(BootGetKBootMSFlag).stubs().will(returnValue(SLAVE_KUBOOT_OK));
    MOCKER(BspFlashRead).stubs().with(any(), any(), any()).will(returnValue(BSP_OK));
    UINT32 retVal = BootGetVersion(headPtr, 0);
    EXPECT_EQ(retVal, BSP_OK);
    EXPECT_TRUE(strlen(headPtr) > 0);
    GlobalMockObject::verify();
}

TEST(BootGetVersionTest, SlaveKuBootOkModelOne) {
    CHAR headPtr[BOOT_VER_STR_MAX_LEN] = {0};
    MOCKER(BootGetKBootMSFlag).stubs().will(returnValue(SLAVE_KUBOOT_OK));
    MOCKER(BspFlashRead).stubs().with(any(), any(), any()).will(returnValue(BSP_OK));
    UINT32 retVal = BootGetVersion(headPtr, 1);
    EXPECT_EQ(retVal, BSP_OK);
    EXPECT_TRUE(strlen(headPtr) > 0);
    GlobalMockObject::verify();
}
/* Ended by AICoder, pid:4a9e1pd1dan2ecc1496b09f541cb9c02d0f292a6 */


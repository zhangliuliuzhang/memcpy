/* Started by AICoder, pid:k6033da7c6g73cc142d8087340ab1724c200ba5e */
#include "bootapp.h"
#include <mtd/mtd-abi.h>
extern "C"
{
    unsigned int get_mtd_size(int mtd_num);
}
/* Ended by AICoder, pid:k6033da7c6g73cc142d8087340ab1724c200ba5e */
/* Started by AICoder, pid:7a9ceuf07fg2bcd141230b51d0ca4a122d44832c */

#include "gtest/gtest.h"
#include <mockcpp/mokc.h>
#include "bootapptest.h"


int main(int argc, char *argv[]) {
    testing::InitGoogleTest(&argc, argv);
    return RUN_ALL_TESTS();
}
/* Ended by AICoder, pid:7a9ceuf07fg2bcd141230b51d0ca4a122d44832c */
/* Started by AICoder, pid:9afe2o5800rc733141e80aa330be512087702d52 */
#include "bootapp.h"

extern "C"
{
    STATUS ldFileDownload();
    INT UTFT_BootDownLoadVersion(VOID);
    INT BspSystem(const CHAR *pcCommand);
    ULONG ldFileFromRam(UCHAR *pucVerbuf, ULONG ulFileSize);
    UINT32 BootGetDownloadFlag(VOID);
    UCHAR BootGetModuleId(VOID);
    UCHAR BootGetGroupId(VOID);
    int UTFT_main(int argc, char *argv[]);
}
/* Ended by AICoder, pid:9afe2o5800rc733141e80aa330be512087702d52 */
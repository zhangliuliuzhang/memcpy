/******************************************************************************
* 版权所有 (C)2007, 深圳市中兴通讯股份有限公司。
*
* 文件名称： loadversion.c
* 文件标识：
* 内容摘要： 软基站平台 loadversion.c。用于加载flash上的cpu版本。(为方便kexec软复位
            只编译到boot流程中加载flash中cpu版本的部分，将该部分从bootapp中提出来，
            编译boot.out时同样编译).
* 其它说明： 无
* 当前版本： V1.0
* 作    者： 耿佳佳
* 完成日期： 2015-9-22
*
* 修改记录1：
*    修改日期：
*    版 本 号：
*    修 改 人：
*    变 更 号：
*    关 键 字：
*    修改内容：
*
******************************************************************************/
#include <vxadp.h>
#include <bsppub.h>
#include <bspcomm.h>
#include <loadversion.h>
#include "surezip.h"
#include "crc.h"
#ifdef CONFIG_ZXW11200_NTN
#include <repairversion.h>
#endif

#if defined(CONFIG_DRA62X)
#include "dra62xboot.h"
#elif defined(CONFIG_ZX211410_EXT)
#include "zx211410boot.h"
#elif defined(CONFIG_LS10X3A)
#include "ls10x3aboot.h"
#elif defined(CONFIG_ZYNQMPSOC)
#include "zynqmpsocboot.h"
#elif defined(CONFIG_AM572X)
#include "am572xboot.h"
#elif defined(CONFIG_ZX2112XX)
#include "zx211411a1boot.h"
#elif defined(CONFIG_ZXW11200)
#include "zxw11200boot.h"
/* Started by AICoder, pid:a0897i6ab9ic1d21459709d7d09fa10ace0156de */
#include "flash.h"
/* Ended by AICoder, pid:a0897i6ab9ic1d21459709d7d09fa10ace0156de */
#elif defined(CONFIG_ZX211412)
#include "zx211412boot.h"
#elif defined(CONFIG_ZX211413)
#include "zx211413boot.h"
/* Started by AICoder, pid:b6e2a6824b8df38142360b72805508095511b59c */
#include "flash.h"
/* Ended by AICoder, pid:b6e2a6824b8df38142360b72805508095511b59c */
#endif

#ifdef CONFIG_SECURITY
#include <zte_validate.h>
#endif

#if defined(COMPILE_FOR_KEXEC_BOOT)
#include <bootadp.h>
#include <bootapp.h>
#else
#ifndef _4C_VDE_TEST_
#include <fpgaload.h>
#endif
#endif
/* =====================常量定义========================================= */

/* =====================文件内部使用的宏 #define========================== */
#define DEBUG_INTER_NAME_LEN 64
/* =====================全局变量 global=================================== */
UCHAR g_ucRunVer = BSP_RUN_VERSION;
BOOL s_bProzoneFlag = FALSE; /* 保护区版本标志 */
BOOL s_bBackFlag = FALSE; /*回退版本标志*/
BOOL s_bRunFlag = FALSE; /*回退版本标志*/
UCHAR g_ucCmdLine[256] = {0};

/* =====================本地变量（即静态全局变量）local==================== */

static UCHAR gucDebugInterfaceName[DEBUG_INTER_NAME_LEN] = {"eth0"};
/* =====================局部函数原型====================================== */

/* =====================外部函数申明====================================== */
extern int AddrArray[2];
/* ============================函数实现====================================== */

UCHAR* GetDebugInterfaceName(void)
{
    return gucDebugInterfaceName;
}

STATUS SetDebugInterfaceName(UCHAR *ucNewName)
{
    if (NULL == ucNewName)
    {
        dbgErr("%s new name is NULL!", __FUNCTION__);
        return ERROR;
    }
    /* Started by AICoder, pid:52532n32f56f21414251088fc0f89703799896ea */
    if ((DEBUG_INTER_NAME_LEN - 1) <= strlen((const char *)ucNewName))
    /* Ended by AICoder, pid:52532n32f56f21414251088fc0f89703799896ea */
    {
        dbgErr("%s new name is too long!", __FUNCTION__);
        return ERROR;
    }

    zte_memset_s(gucDebugInterfaceName, DEBUG_INTER_NAME_LEN, 0, DEBUG_INTER_NAME_LEN);

    /*strcpy(gucDebugInterfaceName,ucNewName);*/
    /*CERT EXP37-C 类不要用错误的参数数目或类型来调用函数的告警*/
    // coverity[cert_exp37_c_violation:SUPPRESS]
    /* Started by AICoder, pid:tce0a1db4cb6b1d149230a8b907ccf08aa9196ea */
    zte_strncpy_s((char *)gucDebugInterfaceName, DEBUG_INTER_NAME_LEN, (const char *)ucNewName, DEBUG_INTER_NAME_LEN - 1);
    /* Ended by AICoder, pid:tce0a1db4cb6b1d149230a8b907ccf08aa9196ea */
    gucDebugInterfaceName[DEBUG_INTER_NAME_LEN - 1] = 0;

    return OK;
}
/**************************************************************************
* 函数名称: void loadlinux(void)
* 功能描述: 单核linux版本加载
* 输入参数: 无
* 输出参数: 无
* 返 回 值: 无
* 其它说明: 正常情况下该函数不返回,暂不支持dtb，需要增加dtb时需加入宏
*
* 修改日期:    版本号     修改人        修改内容
* -----------------------------------------------
* 2015-10-22            V1.0             00086970          创建
**************************************************************************/
ULONG loadlinux(ULONG ulIndex, UCHAR *ucDataBuf, ULONG ullength)
{
    CHAR acuImageName[20] = "/uImage";
    CHAR acramdiskName[20] = "/ramdisk.bin";
    CHAR acdtbName[20] = "/system.dtb";
    int iFD = 0;
    CHAR aucShellCmd[180];
    ULONG ulWriteLen = 0;
    ULONG ulRetVal = BSP_OK;
    INT32 snpRet = 0;

    if (ulIndex == UIMAGE)
    {
        /* 创建根目录下uImage文件 */
        iFD = open(acuImageName, O_CREAT | O_WRONLY, 0644);

        if (iFD < 0)
        {
            dbgErr("open /uImage failed!\n");
            return BSP_ERROR;
        }
        /*CERT ERR33-c 类返回值非指针类的告警*/
        // coverity[cert_err33_c_violation:SUPPRESS]
        /* Started by AICoder, pid:a49a2a6b60u86021453708a3e0f6bd0cd8221d7c */
        snpRet = zte_snprintf_s((char *)aucShellCmd, sizeof(aucShellCmd), "cat /dev/null > %s", acuImageName);
        SNPRINTF_S_CHECK(snpRet, sizeof(aucShellCmd));
        /* Ended by AICoder, pid:a49a2a6b60u86021453708a3e0f6bd0cd8221d7c */
        BspSystem((char *)aucShellCmd);
        dbgErr("load uImage to /...");
    }
    else if (ulIndex == RAMDISK)
    {
        iFD = open(acramdiskName, O_CREAT | O_WRONLY, 0644);
        if (iFD < 0)
        {
            dbgErr("open /ramdisk.bin failed!\n");
            return BSP_ERROR;
        }
        /*CERT ERR33-c 类返回值非指针类的告警*/
        //coverity[cert_err33_c_violation:SUPPRESS]
        //coverity[cert_fio47_c_violation:SUPPRESS]
        snpRet = zte_snprintf_s((char *)aucShellCmd, sizeof(aucShellCmd), "cat /dev/null > %s ", acramdiskName);
        SNPRINTF_S_CHECK(snpRet, sizeof(aucShellCmd));
        BspSystem((char *)aucShellCmd);
        dbgErr("load ramdisk.bin to /...");
    }
    else if (ulIndex == DTB)
    {
        /*CERT FIO32-C 类不要在设备上执行只适用于文件的操作的告警*/
        //coverity[cert_fio32_c_violation:SUPPRESS]
        iFD = open(acdtbName, O_CREAT | O_WRONLY, 0644);
        if (iFD < 0)
        {
            dbgErr("open /system.dtb failed!\n");
            return BSP_ERROR;
        }
        /*CERT ERR33-c 类返回值非指针类的告警*/
        // coverity[cert_err33_c_violation:SUPPRESS]
        snpRet = zte_snprintf_s((char *)aucShellCmd, sizeof(aucShellCmd), "cat /dev/null > %s ", acdtbName);
        SNPRINTF_S_CHECK(snpRet,sizeof(aucShellCmd));
        BspSystem((char *)aucShellCmd);
        dbgErr("load system.dtb to /...");
    }
    else
    {
        dbgErr("Index error!\n");
        return BSP_ERROR;
    }
    /* write uimage to file. */
    ulWriteLen = write(iFD, (char *)ucDataBuf, ullength);
    if (ulWriteLen != ullength)
    {
        dbgErr("error!\n");
        close(iFD);
        return BSP_ERROR;
    }
    fsync(iFD);
    close(iFD);
    dbgErr("ok!\n");
    return ulRetVal;
}
/*===========================================================
函数名      :  PackVerHeaderShow
功能        :  打印版本头部信息
输入参数说明:
               *ptVerHeader -- 版本头指针
返回值说明  :
引用全局变量:
附加说明    :
修改说明    :
修改日期          版本号      修改人      修改内容
-----------------------------------------------
2008年3月20日      1.0       wood        创建
===========================================================*/
void PackVerHeaderShow(T_VerFileHeader *ptVerHeader)
{
    /*char  acTimeChar[100];*/
    dbgErr("===========version header info============\n");
    #if (defined(CONFIG_ZX211410_EXT))
    dbgErr("Whole file crc      : %-#8x\n", (ptVerHeader->ulCRC32));
    dbgErr("VerHeader Version   : %-#8x\n", (ptVerHeader->ulHeaderVersion));
    // dbgErr("Version type        : %-4d (%s)\n",ptVerHeader->usVerType,GetVerTypeStr(ptVerHeader->usVerType));
    // dbgErr("CPU     type        : %-4d (%s)\n",ptVerHeader->ucCpuType,GetCPUTypeStr(ptVerHeader->ucCpuType));
    dbgErr("Compressed File Size: %-d\n", (ptVerHeader->ulCompressedSize));
    dbgErr("Compressed File CRC : %-#8x\n", (ptVerHeader->ulCompressedCRC));
    dbgErr("Original   File Size: %-d\n", (ptVerHeader->ulOriginalSize));
    dbgErr("Original   File CRC : %-#8x\n", (ptVerHeader->ulOriginalCRC));
    dbgErr("Soft type           : %-d\n", (ptVerHeader->ulSoftType));
    #elif defined(CONFIG_ZX2112XX)
    #else
    dbgErr("Whole file crc      : %-#8x\n", CRC_BIG_LITTLE_SWAP_LONG(ptVerHeader->ulCRC32));
    dbgErr("VerHeader Version   : %-#8x\n", CRC_BIG_LITTLE_SWAP_LONG(ptVerHeader->ulHeaderVersion));
    // dbgErr("Version type        : %-4d (%s)\n",ptVerHeader->usVerType,GetVerTypeStr(ptVerHeader->usVerType));
    // dbgErr("CPU     type        : %-4d (%s)\n",ptVerHeader->ucCpuType,GetCPUTypeStr(ptVerHeader->ucCpuType));
    dbgErr("Compressed File Size: %-d\n", CRC_BIG_LITTLE_SWAP_LONG(ptVerHeader->ulCompressedSize));
    dbgErr("Compressed File CRC : %-#8x\n", CRC_BIG_LITTLE_SWAP_LONG(ptVerHeader->ulCompressedCRC));
    dbgErr("Original   File Size: %-d\n", CRC_BIG_LITTLE_SWAP_LONG(ptVerHeader->ulOriginalSize));
    dbgErr("Original   File CRC : %-#8x\n", CRC_BIG_LITTLE_SWAP_LONG(ptVerHeader->ulOriginalCRC));
    dbgErr("Soft type           : %-d\n", CRC_BIG_LITTLE_SWAP_LONG(ptVerHeader->ulSoftType));
    #endif
    /* dbgErr("Version             : %s\n",ptVerHeader->ucVerNo);*/
    /* GetLocalTime(ptVerHeader->ulCreateTime,acTimeChar);
    dbgErr("ulCreateTime        : %s\n",acTimeChar);*/
}
/*===========================================================
函数名      :  PackVerHeaderShow
功能        :  打印FPGA，DSP等合并版本头信息
输入参数说明:
               *ptVerHeader --
返回值说明  :
引用全局变量:
附加说明    :
修改说明    :
修改日期          版本号      修改人      修改内容
-----------------------------------------------
2008年3月20日      1.0       wood        创建
===========================================================*/
void PackUnionHeaderShow(TSwPackage *ptSwHeader)
{
    unsigned char ucCnt;

    if (ptSwHeader->ucSwNum == 0)
    {
        dbgErr("No image is found in Union.\n");
        return;
    }

    for (ucCnt = 0; ucCnt < ptSwHeader->ucSwNum; ucCnt++)
    {
        dbgErr("-----------------\n");
        dbgErr("Image  %d:\n", ucCnt);

        dbgErr("Image     Id: %-d\n", ptSwHeader->atSwIdInfo[ucCnt].ucSwId);
        dbgErr("Image Length: 0x%lx\n", ptSwHeader->atSwIdInfo[ucCnt].ulSwLen);
    }
}

/*===========================================================
函数名      :  GetDivFromUnion
功能        :  从合并包里获取单个软件的地址以及长度
输入参数说明:
               *pucUnion -- 输入合并包的缓冲区地址
                ucNum -- 输入要提取的软件序号(从0开始)
               **pucDivAddr -- 输出要提取软件的缓冲区地址
               *pulLength -- 输出要提取软件的大小
返回值说明  :  UNPRESS_EC_NULL_BUFFER
               UNPRESS_EC_DIV_NUM_ERROR
               UNPRESS_OK

引用全局变量:
附加说明    :
修改说明    :
修改日期          版本号      修改人      修改内容
-----------------------------------------------
2008年2月19日      1.0       wood        创建
===========================================================*/
unsigned long GetCpuDivFromUnion(unsigned char *pucUnion,
                                 unsigned char ucNum,
                                 unsigned char **pucDivAddr,
                                 unsigned long *pulLength)
{
    TSwPackage *ptUnionAddr;
    unsigned long ulUnionHeaderLen;
    unsigned char ucLoop;

    if (NULL == pucUnion || NULL == pucDivAddr)
    {
        return UNPRESS_EC_NULL_BUFFER;
    }

    ptUnionAddr = (TSwPackage *)pucUnion;

    if (ucNum > ptUnionAddr->ucSwNum)
    {
        dbgErr("Max division number of union must be less than %d\n", ptUnionAddr->ucSwNum);
        return UNPRESS_EC_DIV_NUM_ERROR;
    }

    ulUnionHeaderLen = sizeof(unsigned char) + ptUnionAddr->ucSwNum * sizeof(TSwIdInfo);

    *pucDivAddr = pucUnion + ulUnionHeaderLen;

    for (ucLoop = 0; ucLoop < ucNum; ucLoop++)
    {
        #if (defined(CONFIG_ZX211410_EXT))
        *pucDivAddr += (ptUnionAddr->atSwIdInfo[ucLoop].ulSwLen);
        #elif defined(CONFIG_ZX2112XX)
        #else
        *pucDivAddr += CRC_BIG_LITTLE_SWAP_LONG(ptUnionAddr->atSwIdInfo[ucLoop].ulSwLen);
        #endif
    }

    #if (defined(CONFIG_ZX211410_EXT))
    *pulLength = (ptUnionAddr->atSwIdInfo[ucNum].ulSwLen); /*每个软件包的长度*/
    #elif defined(CONFIG_ZX2112XX)
    #else
    *pulLength = CRC_BIG_LITTLE_SWAP_LONG(ptUnionAddr->atSwIdInfo[ucNum].ulSwLen); /*每个软件包的长度*/
    #endif

    /*dbgErr("\n   *pulLength=0x%x \n", *pulLength );*/
    return BSP_OK;
}

/*===========================================================
函数名      :  PackSoftNumGet
功能        :  获得合并包里软件的数量
输入参数说明:
               ulPD -- 压缩包描述符
返回值说明  :  INVALID_PACK_DESC(0xFFFFFFFF) -- 错误的描述符
               其他为合并包内软件的数量
引用全局变量:
附加说明    :
修改说明    :
修改日期          版本号      修改人      修改内容
-----------------------------------------------
2008年6月18日      1.0       wood        创建
===========================================================*/
unsigned long PackSoftNumGet(UCHAR *ptPd)
{
    TSwPackage *ptSwHeader;

    ptSwHeader = (TSwPackage *)ptPd;

    /*dbgErr("\nPackSoftNumGet:ptSwHeader->ucSwNum=%d\n",ptSwHeader->ucSwNum);*/ /*返回合并包的个数*/
    /* CERT EXP39-C 类不要通过不兼容类型的指针访问变量的告警*/
    //coverity[cert_exp39_c_violation:SUPPRESS]
    return ptSwHeader->ucSwNum;
}

/*===========================================================
函数名      :  PackAnalyze
功能        :  合并包解析，返回软件在缓存中的地址和长度
输入参数说明:
               ulPD -- 压缩包描述符
               ulSoftNum -- 软件序号
               **pucSoftAddr -- 镜像在缓存中的地址(output)
               *pulSoftLength -- 镜像的长度(output)
返回值说明  :
引用全局变量:
附加说明    :  非打包类型UNPRESS_EC_NOT_UNION_TYPE,
                   返回整个解压包的地址和长度
               正确解包返回 UNPRESS_OK
修改说明    :
修改日期          版本号      修改人      修改内容
-----------------------------------------------
2008年4月28日      1.1       wood        增加由于合并头不存在或者非法引起的越界判决
2008年3月17日      1.0       wood        创建
===========================================================*/
unsigned long PackAnalyze(unsigned char *ucPackbuf,
                          unsigned long ulSoftNum,
                          unsigned char **pucSoftAddr,
                          unsigned long *pulSoftLength)
{

    unsigned long ulRetCode;

    if (NULL == pulSoftLength || pucSoftAddr == NULL)
    {

        dbgErr("Null ptr!\n");
        return UNPRESS_EC_NULL_BUFFER;
    }

    ulRetCode = GetCpuDivFromUnion(ucPackbuf,
                                ulSoftNum,
                                pucSoftAddr,
                                pulSoftLength);
    #if 0
    dbgErr("2.ucPackbuf[0x%x], ulSoftNum[0x%x], pucSoftAddr[0x%x], pulSoftLength[0x%x],ulRetCode[0x%x]\n",
        ucPackbuf, ulSoftNum, **pucSoftAddr, *pulSoftLength, ulRetCode);
    dbgErr("3.*pucSoftAddr[0x%x], ptPd->pucUnpackBuf[0x%x], (*pucSoftAddr + *pulSoftLength)[0x%x], (ptPd->pucUnpackBuf + (( ptVerHeader->ulOriginalSize)))[0x%x]\n",
        (ULONG )*pucSoftAddr, (ULONG)ptPd->pucUnpackBuf, (ULONG )(*pucSoftAddr + *pulSoftLength), (ULONG)(ptPd->pucUnpackBuf + (( ptVerHeader->ulOriginalSize))));
        dbgErr("It's not a union type that you want to analyze too\n");
        PackVerHeaderShow(ptVerHeader);
        PackUnionHeaderShow(ptSwHeader);

    dbgErr("version file region--start at %#8x,length %d\n",(ULONG )*pucSoftAddr,*pulSoftLength);
    /* 越界, 起始/结束地址不在解压镜像的范围之内  */

    /*dbgErr("PackAnalyze: ptPd->pucUnpackBuf=0x%x\n",ptPd->pucUnpackBuf);
    dbgErr("PackAnalyze: ptVerHeader->ulOriginalSize=0x%x\n", ptVerHeader->ulOriginalSize);
    dbgErr("PackAnalyze: ptVerHeader->ulOriginalSize=0x%x\n",  (CRC_BIG_LITTLE_SWAP_LONG( ptVerHeader->ulOriginalSize)));*//*   add  hong*/
    #if defined(CONFIG_DRA62X)
    if ((ULONG )*pucSoftAddr <  (ULONG)*ucPackbuf
       || (ULONG )(*pucSoftAddr + *pulSoftLength) > (ULONG)(*ucPackbuf + (CRC_BIG_LITTLE_SWAP_LONG( ptVerHeader->ulOriginalSize))))/*    add hong*/
    #elif defined(CONFIG_ZX211410_EXT)
    if ((ULONG )*pucSoftAddr <  (ULONG)*ucPackbuf
       || (ULONG )(*pucSoftAddr + *pulSoftLength) > (ULONG)(*ucPackbuf + (( ptVerHeader->ulOriginalSize))))/*    add hong*/
    #endif
    {
        dbgErr("It's not a union type that you want to analyze too\n");
        PackVerHeaderShow(ptVerHeader);
        PackUnionHeaderShow(ptSwHeader);

        dbgErr("version file region--start at %#8x,length %d\n",(ULONG )*pucSoftAddr,*pulSoftLength);
        *pucSoftAddr   = ptPd->pucUnpackBuf;
        *pulSoftLength =  ptVerHeader->ulOriginalSize;
        ulRetCode = UNPRESS_EC_NOT_UNION_TYPE;
    }
    #endif
    return ulRetCode;
}

/*===========================================================
函数名      :  PackUpress
功能        :  解压V4版本包
输入参数说明:
               *ucInFile  -- 压缩文件地址
                ulFileLen  -- 压缩文件的长度(带版本头)
               *ucOutFile -- 解压文件地址
返回值说明  :
引用全局变量:
附加说明    :
修改说明    :
修改日期          版本号      修改人      修改内容
-----------------------------------------------
2008年2月19日      1.0       wood        创建
===========================================================*/
unsigned long PackUpress(unsigned char *ucInFile,
                         unsigned long ulFileLen,
                         unsigned char *ucOutFile)
{

    T_VerFileHeader *ptHeader = NULL;

    if (NULL == ucInFile || NULL == ucOutFile)
    {
        dbgErr("null input pointer at unpress routine.\n");
        return UNPRESS_EC_NULL_BUFFER;
    }

    ptHeader = (T_VerFileHeader *)ucInFile;

    #if (defined(CONFIG_ZX211410_EXT))
    if ((ulFileLen - sizeof(T_VerFileHeader)) != (ptHeader->ulCompressedSize))
    #elif defined(CONFIG_ZX2112XX)
    #else
    if ((ulFileLen - sizeof(T_VerFileHeader)) != CRC_BIG_LITTLE_SWAP_LONG(ptHeader->ulCompressedSize))
    #endif
    {
        dbgErr("File length is not matched.\n");
        return UNPRESS_EC_WHOLE_FILE_LEN_ERROR;
    }
    #if 0
    /* crc package context */
    #if defined(CONFIG_DRA62X)
    if (0 != CheckCrc16(ucInFile+sizeof(T_VerFileHeader),
                    ulFileLen - sizeof(T_VerFileHeader),
                    CRC_BIG_LITTLE_SWAP_LONG(ptHeader->ulCompressedCRC)))
    #elif defined(CONFIG_ZX211410_EXT)
    if (0 != CheckCrc16(ucInFile+sizeof(T_VerFileHeader),
                    ulFileLen - sizeof(T_VerFileHeader),
                    (ptHeader->ulCompressedCRC)))
    #endif
    {
        dbgErr("packed file crc error.\n");
        return UNPRESS_EC_PACKED_FILE_CRC_ERROR;
    }
    #endif

    #if (defined(CONFIG_ZX211410_EXT) || defined(CONFIG_ZX2112XX))

    if (VER_TYPE_FPGA != (ptHeader->usVerType)
        && VER_TYPE_DSP != (ptHeader->usVerType)
        && VER_TYPE_CPU != (ptHeader->usVerType))
    #else
    if (VER_TYPE_FPGA != CRC_BIG_LITTLE_SWAP_USHORT(ptHeader->usVerType)
        && VER_TYPE_DSP != CRC_BIG_LITTLE_SWAP_USHORT(ptHeader->usVerType)
        && VER_TYPE_CPU != CRC_BIG_LITTLE_SWAP_USHORT(ptHeader->usVerType))

    #endif
    {
        /* 这些软件类型未经压缩， 直接拷贝即可 */
        #if (defined(CONFIG_ZX211410_EXT) || defined(CONFIG_ZX2112XX))
        zte_memcpy_s(ucOutFile, ((ptHeader->ulOriginalSize)), ucInFile, ((ptHeader->ulOriginalSize)));
        #else
        zte_memcpy_s(ucOutFile, (CRC_BIG_LITTLE_SWAP_LONG(ptHeader->ulOriginalSize)), ucInFile, (CRC_BIG_LITTLE_SWAP_LONG(ptHeader->ulOriginalSize)));
        #endif
    }
    else
    {

        if (OK != vx_inflate((ucInFile + sizeof(T_VerFileHeader)), ucOutFile, (ulFileLen - sizeof(T_VerFileHeader)), (unsigned long *)&(ptHeader->ulOriginalSize)))
        {
            dbgErr("fail to inflate data\n");
            return UNPRESS_EC_UNPACK_ERROR;
        }
    }

    return BSP_OK;
} /* UnpressV4() */

/**********************************************************************
* 函数名称:LoadLinuxCompress
* 功能描述:解压缩cpu版本到根目录，原文件使用RRU filter工具，参数为0，非压缩格式
          L3头+合并头+sw1+sw2
* 输入参数:pcVerBuf:版本文件指针
* 输出参数:
* 返 回 值:BSP_OK:成功;错误码:失败
* 其它说明:暂不支持dtb文件
          非压缩版本在单板makefile中定义VERSION_UNCOMPRESS宏。
* 修改日期        版本号     修改人          修改内容
* -----------------------------------------------
* 2015-10-22       V1.0       00086970             创建
***********************************************************************/
ULONG LoadLinuxUnCompress(UCHAR *pucDataBuf, ULONG ulLength)
{
    TSwPackage *ptSwHeader = NULL;
    UCHAR *uluImageaddr = NULL;
    UCHAR *ulramdiskaddr = NULL;
    UCHAR *ulramdiskend = NULL;
    UCHAR ucVerNum = 0;
    ULONG ulRet = BSP_OK;
    #if defined(CONFIG_DTB)
    UCHAR *uldtbaddr = NULL;
    UCHAR *uldtbend = NULL;
    #endif
    if (NULL == pucDataBuf)
    {
        return BSP_ERROR;
    }

    ptSwHeader = (TSwPackage *)(VOID *)pucDataBuf;
    ucVerNum = ptSwHeader->ucSwNum;

    if (0 == ucVerNum || (UCHAR)(-1) == ucVerNum)
    {
        dbgErr("Invalid linux package number.\n");
        return BSP_ERROR;
    }

    #if defined(CONFIG_DTB)
    if (3 != ucVerNum)
    {
        dbgErr("Invalid linux package number.\n");
        return BSP_ERROR;
    }
    #else
    if (2 != ucVerNum)
    {
        dbgErr("Invalid linux package number.\n");
        return BSP_ERROR;
    }
    #endif
    uluImageaddr = pucDataBuf + (sizeof(unsigned char) + sizeof(TSwIdInfo) * ucVerNum);
    /*增加uImage特征字段校验*/
    /*校验非压缩格式是否正确*/
    /*uImage 第32字节起linux-2.6.32.60-EMBSYS-CGEL-4.02*/
    #if (defined(CONFIG_ZX211410_EXT) || defined(CONFIG_DRA62X))
    UCHAR ucStr[] = "Linux";
    /* Started by AICoder, pid:5b1452e3b501e6a144360949206f2a029b94fcb0 */
    if (strncmp((char *)uluImageaddr + 32, (char *)ucStr, 5) != 0)
    /* Ended by AICoder, pid:5b1452e3b501e6a144360949206f2a029b94fcb0 */
    {
        dbgErr("uImage ERROR!!\n");
        return BSP_ERROR;
    }
    #endif
    ulRet = loadlinux(UIMAGE, uluImageaddr, ntohl(ptSwHeader->atSwIdInfo[UIMAGE].ulSwLen));
    if (ulRet != BSP_OK)
    {
        return BSP_ERROR;
    }

    ulramdiskaddr = uluImageaddr + ntohl(ptSwHeader->atSwIdInfo[UIMAGE].ulSwLen);
    ulramdiskend = ulramdiskaddr + ntohl(ptSwHeader->atSwIdInfo[RAMDISK].ulSwLen);
    if (ulramdiskend > pucDataBuf + ulLength)
    {
        dbgErr("It's not a union type that you want to analyze too\n");
        return BSP_ERROR;
    }

    ulRet = loadlinux(RAMDISK, ulramdiskaddr, ntohl(ptSwHeader->atSwIdInfo[RAMDISK].ulSwLen));
    if (ulRet != BSP_OK)
    {
        return BSP_ERROR;
    }

    #if defined(CONFIG_DTB)
    uldtbaddr = ulramdiskaddr + ntohl(ptSwHeader->atSwIdInfo[RAMDISK].ulSwLen);
    uldtbend = uldtbaddr + ntohl(ptSwHeader->atSwIdInfo[DTB].ulSwLen);
    if (uldtbend > pucDataBuf + ulLength)
    {
        dbgErr("It's not a union type that you want to analyze too\n");
        return BSP_ERROR;
    }

    ulRet = loadlinux(DTB, uldtbaddr, ntohl(ptSwHeader->atSwIdInfo[DTB].ulSwLen));
    if (ulRet != BSP_OK)
    {
        return BSP_ERROR;
    }
    #endif
    return BSP_OK;
}

/***********************************************************************
* 函数名称:LoadLinuxCompress
* 功能描述:解压缩cpu版本到根目录，原文件使用RRU filter工具，参数为1，压缩格式
           L3头+合并头+L3头+sw1+L3头+sw2
* 输入参数:pcVerBuf:版本文件指针
* 输出参数:
* 返 回 值:BSP_OK:成功;错误码:失败
* 其它说明:
           暂不支持dtb文件
* 修改日期        版本号     修改人          修改内容
* -----------------------------------------------
* 2015-10-22       V1.0       00086970             创建
***********************************************************************/
ULONG LoadLinuxCompress(UCHAR *pcVerBuf, ULONG ulLength)
{
    int SoftNum;
    int Ret;
    int cnt;
    unsigned char *pucPackBuf;
    unsigned long ulPackLength;
    unsigned char *pucUncompressBuf = NULL;
    T_VerFileHeader *ptHeader = NULL;
    /*dbgErr("%s,%d ,0x%x,0x%x,0x%x\n",__FILE__,__LINE__,*pcVerBuf,pcVerBuf, ptVerHeader->ulCompressedSize);*/

    SoftNum = PackSoftNumGet(pcVerBuf);

    if (0 == SoftNum)
    {
        dbgErr("Invalid linux package number.\n");
        return -1;
    }
    #if (defined(CONFIG_ZX211410_EXT) || defined(CONFIG_DRA62X))
    if (2 != SoftNum)
    {
        dbgErr("Invalid linux package number.\n");
        return BSP_ERROR;
    }
    #elif defined(CONFIG_ZX2112XX)
    #else
    if (3 != SoftNum)
    {
        dbgErr("Invalid linux package number.\n");
        return BSP_ERROR;
    }
    #endif
    /* 合并包的前两个为uimage 和ramdisk文件 */

    for (cnt = 0; cnt < SoftNum; cnt++)
    {
        dbgErr("Uncompress..... soft %d\n", cnt);
        /* 获得合并文件的地址和长度 */
        Ret = PackAnalyze(pcVerBuf, cnt, &pucPackBuf, &ulPackLength);
        if (0 != Ret)
        {
            dbgErr(" error!");
            dbgErr("Fail to analyze soft:%d", cnt);
            return -2;
        }

        if (pucPackBuf < pcVerBuf
        || (pucPackBuf + ulPackLength) > (pcVerBuf + ulLength)) /*    add hong*/
        {
            dbgErr("It's not a union type that you want to analyze too\n");
            dbgErr("version file region--start at %#8x,length 0x%lx\n", (ULONG)*pucPackBuf, ulPackLength);
            pucPackBuf = pcVerBuf;
            ulPackLength = ulLength;
            return -5;
        }

        /* 暂时不检查单个小包的crc*/
        ptHeader = (T_VerFileHeader *)pucPackBuf;

        pucUncompressBuf = (UCHAR *)malloc(ptHeader->ulOriginalSize);
        if (NULL == pucUncompressBuf)
        {
            dbgErr(" malloc error!\n");
            return -6;
        }
        zte_memset_s(pucUncompressBuf, ptHeader->ulOriginalSize, 0, ptHeader->ulOriginalSize);

        Ret = PackUpress(pucPackBuf, ulPackLength, pucUncompressBuf);
        if (0 != Ret)
        {
            dbgErr(" error!");
            free(pucUncompressBuf);
            pucUncompressBuf = NULL;
            dbgErr("Fail to unpress soft:%d", cnt);
            return -3;
        }
        dbgErr(" ok!");

        Ret = loadlinux(cnt, pucUncompressBuf, ptHeader->ulOriginalSize);
        if (0 != Ret)
        {
            free(pucUncompressBuf);
            pucUncompressBuf = NULL;
            dbgErr("Fail to load linux:%d", cnt);
            return -4;
        }

        free(pucUncompressBuf);
        pucUncompressBuf = NULL;
    }
    return 0;
}
#ifdef CONFIG_SECURITY
/*
* this function load json file, check cputype& CRC.
* then get signature for cpu.swv
*/
static const char *pcJsonFileName = NULL;

/*flash_size -1M + 128K*/
/*modify by gengjiajia to support nor flash single D42*/
#define CA_CSF_HEAD_ADDR_L (GetMtd2EndAddr() - 1024 * 1024 + 128 * 1024)
#define CA_CSF_HEAD_ADDR_H (GetMtd2EndAddr() - 1024 * 1024 + 148 * 1024)
#define CA_CSF_HEAD_MAXSIZE (20 * 1024)

static unsigned int GetMtd2EndAddr(void)
{
    int fd = 0;
    /* Started by AICoder, pid:e566dgd093m738014171090570fae40c5a61794d */
    CHAR aucMtdName[16] = {0};
    /* Ended by AICoder, pid:e566dgd093m738014171090570fae40c5a61794d */
    unsigned int ulBootMtdSize[3] = {0};
    unsigned int i;

    for (i = 0; i < 3; i++)
    {
        if (zte_snprintf_s(aucMtdName, sizeof(aucMtdName), "/dev/mtd%d", i) < 0)
        {
            dbgErr("%s>>snprintf error !\n", __FUNCTION__);
            return BSP_ERROR;
        }

        fd = open(aucMtdName, O_RDWR);
        if (fd < 0)
        {
            dbgErr("%s>>open %s error \n", __FUNCTION__, aucMtdName);
            return BSP_ERROR;
        }

        if (0 != lseek(fd, 0, SEEK_SET))
        {
            dbgErr("%s>>lseek %s to begin error \n", __FUNCTION__, aucMtdName);
            close(fd);
            return BSP_ERROR;
        }
        ulBootMtdSize[i] = lseek(fd, 0, SEEK_END);
        if (0 == ulBootMtdSize[i])
        {
            dbgErr("%s>>lseek %s to end error \n", __FUNCTION__, aucMtdName);
            close(fd);
            return BSP_ERROR;
        }
        close(fd);
    }

    return (ulBootMtdSize[0] + ulBootMtdSize[1] + ulBootMtdSize[2]);
}

VOID printcsf(VOID)
{
    zte_printf_s("%s>>CA_CSF_HEAD_ADDR_L=0x%x \n", __FUNCTION__, CA_CSF_HEAD_ADDR_L);
    zte_printf_s("%s>>CA_CSF_HEAD_ADDR_H=0x%x \n", __FUNCTION__, CA_CSF_HEAD_ADDR_H);
    return;
}

unsigned int ldParseJsonFile(const char *pcFilename, unsigned int uiVerLen, unsigned int uiVerCrc, char *pcsign_data, unsigned int *psignLen)
{
    int fd = 0;
    struct stat tStat;
    unsigned int ulFileSize = 0;
    unsigned char *pucRdVerFileBuff = NULL;
    T_VerFileHeader *ptVerFileHeader = NULL;
    unsigned int uiret = 0;
    int iRetVal = 0;
    uint ulFileCRC = 0, ulCalCRCResult = 0;
    /* Started by AICoder, pid:h4a33pc8cdm180414338084ad0ebd00c4e21e0ee */
    unsigned char *ptVerProtectHead = NULL;
    /* Ended by AICoder, pid:h4a33pc8cdm180414338084ad0ebd00c4e21e0ee */
    T_ProtectVerInfoHead *ptVerInfoHead = NULL;
    T_ProtectVerInfo *ptVerInfo = NULL;
    unsigned int ulVerOffSet = 0;
    unsigned int ulProZoneAddrOffset;
    unsigned int ulProtectHeadLen;
    unsigned int ulRet = BSP_OK;

    if (g_ucRunVer == BSP_PROVERSION) /*load json from protect zone*/
    {
        ulProZoneAddrOffset = BootGetFlashVerProtectAddr();
        ulProtectHeadLen = sizeof(T_VerProtectHead);

        /* Started by AICoder, pid:hb13fe8e9252751144bb0b84f0c1cb08ae61a82a */
        ptVerProtectHead = malloc(ulProtectHeadLen);
        /* Ended by AICoder, pid:hb13fe8e9252751144bb0b84f0c1cb08ae61a82a */
        dbgErr("ptVerProtextHead = 0x%x \n", (ULONG)ptVerProtectHead);
        if (NULL == ptVerProtectHead)
        {
            dbgErr("malloc error!!\n");
            uiret = BSP_ERROR;
            goto ret1;
        }

        zte_memset_s(ptVerProtectHead, ulProtectHeadLen, 0, ulProtectHeadLen);
        ulRet = BspFlashRead(ulProZoneAddrOffset, (UCHAR *)ptVerProtectHead, ulProtectHeadLen);
        if (ulRet != BSP_OK)
        {
            dbgErr(" T_VerProtectHead INFO READ wrong!!\n");
            uiret = BSP_ERROR;
            goto ret1;
        }

        ptVerInfoHead = (T_ProtectVerInfoHead *)ptVerProtectHead;
        ptVerInfo = (T_ProtectVerInfo *)(ptVerInfoHead + 1);
        ulFileSize = ptVerInfo->tVerInfoFile.ulSWLength;
        ulVerOffSet = ptVerInfo->ulVerOffSet;

        if (0 == ulFileSize)
        {
            goto ret1;
        }
        /* Started by AICoder, pid:v8abb80d486ae4514e740be080d0630355f12003 */
        pucRdVerFileBuff = malloc(ulFileSize);
        /* Ended by AICoder, pid:v8abb80d486ae4514e740be080d0630355f12003 */
        if (NULL == pucRdVerFileBuff)
        {
            uiret = BSP_ERROR;
            goto ret1;
        }

        /* Started by AICoder, pid:3180el4eb6l4c101437709ab404c9e0b46c19ff5 */
        ulRet = BspFlashRead(ulProZoneAddrOffset + ulVerOffSet, pucRdVerFileBuff, ulFileSize);
        /* Ended by AICoder, pid:3180el4eb6l4c101437709ab404c9e0b46c19ff5 */
        if (ulRet != BSP_OK)
        {
            dbgErr(" pucRdVerFileBuff INFO READ wrong!!\n");
            uiret = BSP_ERROR;
            goto ret1;
        }
    }
    else
    {
        if (NULL == pcFilename)
        {
            dbgErr("Input para null.\n");
            uiret = BSP_ERROR;
            goto ret1;
        }
        fd = open(pcFilename, O_RDONLY, 0666);
        if (0 > fd)
        {
            dbgErr("Can not open version file!\n");
            uiret = BSP_ERROR;
            goto ret1;
        }

        if (fstat(fd, &tStat) < 0)
        {
            dbgErr("Can not fstat version file!\n");
            close(fd);
            uiret = BSP_ERROR;
            goto ret1;
        }
        ulFileSize = tStat.st_size;
        pucRdVerFileBuff = (unsigned char *)malloc(ulFileSize);
        if (NULL == pucRdVerFileBuff)
        {
            dbgErr("version file size %u\n", ulFileSize);
            dbgErr("malloc read version file buffer failed!\n");
            close(fd);
            uiret = BSP_ERROR;
            goto ret1;
        }
        zte_memset_s(pucRdVerFileBuff, ulFileSize, 0, ulFileSize);
        iRetVal = zte_read_s(fd, pucRdVerFileBuff, ulFileSize, ulFileSize);
        if ((ULONG)iRetVal != ulFileSize)
        {
            dbgErr("Version file read error\n");
            close(fd);
            uiret = BSP_ERROR;
            goto ret1;
        }
        close(fd);
    }

    ptVerFileHeader = (T_VerFileHeader *)pucRdVerFileBuff;

    ulFileCRC = ntohl(ptVerFileHeader->ulCRC32);
    dbgErr("CalculateCRC ......");
    if (ulFileSize < sizeof(ptVerFileHeader))
    {
        dbgErr("ulFileSize %d  is too small ......\n", ulFileSize);
        goto ret1;
    }

    ulCalCRCResult = CalculateCRC16(CRC_MASK, (UCHAR *)pucRdVerFileBuff + sizeof(ptVerFileHeader->ulCRC32), ulFileSize - sizeof(ptVerFileHeader->ulCRC32));
    if (ulFileCRC != ulCalCRCResult)
    {
        dbgErr("\n CRC calculated in Boot is 0x%x,but in file header is 0x%x!!\n", ulCalCRCResult, ulFileCRC);
        dbgErr(" Version File CRC error !!!!\n");
        uiret = BSP_ERROR;
        goto ret1;
    }
    else if (0 == ulCalCRCResult)
    {
        if (ulFileSize < sizeof(T_VerFileHeader)) /*Coverity fix*/
        {
            dbgErr("ulFileSize 0x%x error!!\n", ulFileSize);
            uiret = BSP_ERROR;
            goto ret1;
        }
        if (BSP_OK == CheckBufAllZero((UCHAR *)(pucRdVerFileBuff + sizeof(ptVerFileHeader->ulCRC32)), (ulFileSize - sizeof(ptVerFileHeader->ulCRC32))))
        {
            dbgErr("Version CRC error!! File all zero!!\n");
            uiret = BSP_ERROR;
            goto ret1;
        }
    }
    dbgErr("ok.\n");

    /* Started by AICoder, pid:48411h7db7884b314bec08abc0eca40d81516097 */
    uiret = BspGetVersionSign(pucRdVerFileBuff + sizeof(T_VerFileHeader), uiVerLen, uiVerCrc, (unsigned char *)pcsign_data, psignLen);
    /* Ended by AICoder, pid:48411h7db7884b314bec08abc0eca40d81516097 */    if (uiret)
    {
        dbgErr("get sign file from json.swv failed, uiret=0x%x\n", uiret);
        goto ret1;
    };
ret1:
    if (ptVerProtectHead)
    {
        free(ptVerProtectHead);
        ptVerProtectHead = NULL;
    }
    if (pucRdVerFileBuff)
    {
        free(pucRdVerFileBuff);
        pucRdVerFileBuff = NULL;
    }
    return uiret;
}
/*
 * ldCaExCsfFile : load CA and verify
 * input : uiCaVerAddr: address of ca extra csf header
 * output: pub_key
 *         pub_key_len
 */
int ldCaExCsfFile(uint uiCaVerAddr, char *pub_key, uint *pub_key_len)
{
    uchar *pucRdVerFileBuff = NULL;
    T_VerFileHeader *ptVerFileHeader = NULL;
    T_VerFileHeader *ptTmpFileHeader = NULL;
    uint ulVerSize = 0;
    uint ulCalCRCResult = 0;
    uint ulFileCRC = 0;
    uint ulVerappAddr = uiCaVerAddr;
    int iret = 0;

    ptTmpFileHeader = malloc(sizeof(T_VerFileHeader));
    if (NULL == ptTmpFileHeader)
    {
        dbgErr("malloc error!!\n");
        iret = -1;
        goto return1;
    }
    zte_memset_s(ptTmpFileHeader, sizeof(T_VerFileHeader), 0, sizeof(T_VerFileHeader));
    iret = BspFlashRead(ulVerappAddr, (uchar *)ptTmpFileHeader, sizeof(T_VerFileHeader));
    if (0 != iret)
    {
        goto return2;
    }
    /*get version size*/
    ulVerSize = ntohl(ptTmpFileHeader->ulCompressedSize) +
                sizeof(T_VerFileHeader);
    if (ulVerSize > CA_CSF_HEAD_MAXSIZE)
    {
        dbgErr("Ca_ext ver SIZE error !! = 0x%x\n", ulVerSize);
        iret = -2;
        goto return2;
    }

    pucRdVerFileBuff = (uchar *)malloc(ulVerSize);
    if (NULL == pucRdVerFileBuff)
    {
        dbgErr("malloc error!!\n");
        iret = -4;
        goto return2;
    }

    iret = BspFlashRead(ulVerappAddr, pucRdVerFileBuff, ulVerSize);
    if (0 != iret)
    {
        goto return2;
    }

    ptVerFileHeader = (T_VerFileHeader *)pucRdVerFileBuff;

    ulFileCRC = ntohl(ptVerFileHeader->ulCRC32);

    ulCalCRCResult = CalculateCRC16(0xffff, (uchar *)pucRdVerFileBuff + sizeof(ptVerFileHeader->ulCRC32), (ulVerSize - sizeof(ptVerFileHeader->ulCRC32)));

    /* CRC check for jason file*/
    if (ulFileCRC != ulCalCRCResult)
    {
        dbgErr("CRC calculated in Boot is 0x%x,but in VerInfo is 0x%x!!\n",
               ulCalCRCResult, ulFileCRC);
        dbgErr("Ca_ext: Version CRC error!!\n");
        iret = -5;
        goto return2;
    }
    else if (0 == ulCalCRCResult)
    {
        /*CRC check if jason file is all zero */
        if (0 == CheckBufAllZero((uchar *)(pucRdVerFileBuff + sizeof(
           ptVerFileHeader->ulCRC32)), (ulVerSize - sizeof(ptVerFileHeader->ulCRC32))))
        {
            dbgErr("Ca_ext:Version CRC error!! File all zero!!\n");
            iret = -6;
            goto return2;
        }
    }
    dbgErr("CRC ok.\n");

    /*VERIFY CERT FILE*/
    iret = zte_secure_validate((uintptr_t)(pucRdVerFileBuff + sizeof(T_VerFileHeader)));
    if (0 != iret)
    {
        dbgErr("verify CA certfile in FAILED!!\n");
        goto return2;
    }
    /*get ver pub key*/
    iret = ldPkeyFromCAheader((uintptr_t)(pucRdVerFileBuff + sizeof(T_VerFileHeader)), pub_key, pub_key_len);
    if (iret != 0)
    {
        dbgErr("ldPkeyFromCAheader get pub key error!\n");
        goto return2;
    }
    dbgErr("verify CA certfile is PASSED!! \n");

return2:
    if (pucRdVerFileBuff != NULL)
    {
        free(pucRdVerFileBuff);
        pucRdVerFileBuff = NULL;
    }

    if (ptTmpFileHeader != NULL)
    {
        free(ptTmpFileHeader);
        ptTmpFileHeader = NULL;
    }
return1:
    return iret;
}

/*
* CPU VERSIOIN SECURE ON
*
*/
#define CPU_VERSION_NV_COUNT_OFFSET 88
unsigned int VerifyCpuVersion(unsigned char *pucVerbuf, unsigned int ulFileCRC, unsigned int ulFileSize)
{
    char ver_sign_data[RSA_4K_KEY_SZ_BYTES] = {0};
    char ver_pkey_data[RSA_4K_KEY_SZ_BYTES*2] = {0};
    char calc_hash[SHA256_BYTES] = {0};
    int uiExCsfHeader_flag=0;
    /* Started by AICoder, pid:72337y05f1nfde014ede084e60d9dd0d3ab224c6 */
    unsigned int sign_len;
    unsigned int key_len;
    /* Ended by AICoder, pid:72337y05f1nfde014ede084e60d9dd0d3ab224c6 */
    T_VerFileHeader *ptVerFileHeader = (T_VerFileHeader *)pucVerbuf;
    unsigned int uiret=0, uiNvRead=0, uiNvEnable=0;
    int iret=0;
    /*clear ca file error log mem*/
    BspClrCaErrReason();

    /*GET sign data*/
    uiret = ldParseJsonFile(pcJsonFileName, ulFileSize, ulFileCRC, ver_sign_data, &sign_len);
    if(uiret != 0)
    {
        dbgErr("get sign data from json file error! uiret = 0x%x\n", uiret);
        BspSetCpuVerErrReason(g_ucRunVer,BSP_JASON_FILE_READ_ERROR);
        BspSetCaErrReason(BSP_RUN_VERSION, CA_LD_PARSE_CUR27_ERROR);
        return BSP_ERROR;
    }

    /*get pubkey*/
    uiret = ldCaExCsfFile(CA_CSF_HEAD_ADDR_H, ver_pkey_data, &key_len);
    if(uiret == 0) {
        uiExCsfHeader_flag = 1;
    }else{
        dbgErr("load and verify high caExCsfFile failed\n");
        BspSetCaErrReason(BSP_RUN_VERSION, CA_CAFILE_VERIFY_ERROR);
        uiret = ldCaExCsfFile(CA_CSF_HEAD_ADDR_L, ver_pkey_data, &key_len);
        uiExCsfHeader_flag = 2;
    }
    if(uiret != 0)
    {
        dbgErr("load and verify high&low caExCsfFile failed\n");
        BspSetCpuVerErrReason(g_ucRunVer,BSP_CA_EXTRA_FILE_VERIFY_ERROR+(uiExCsfHeader_flag-1)*0x80);
        BspSetCaErrReason(BSP_BAK_VERSION, CA_CAFILE_VERIFY_ERROR);
        return BSP_ERROR;
    }

    /*calc version hash*/
    iret = calc_data_hash((char *)pucVerbuf, ulFileSize, calc_hash, CSF_CPUKEY_NUM);
    if(iret != 0)
    {
        BspSetCpuVerErrReason(g_ucRunVer, BSP_VER_HASH_ERROR+(uiExCsfHeader_flag-1)*0x80);
        BspSetCaErrReason(uiExCsfHeader_flag-1, CA_IMAGE_HASH_ERROR);
        dbgErr("cala hash of version failed\n");
        return BSP_ERROR;
    }

    /* verify image*/
    iret = rsa_auth_signature(calc_hash, ver_pkey_data, key_len, ver_sign_data, sign_len);
    if(iret != 0)
    {
        if(1 == uiExCsfHeader_flag)
        {
            BspSetCaErrReason(BSP_RUN_VERSION, CA_SIGNATURE_ERROR);
            uiret = ldCaExCsfFile(CA_CSF_HEAD_ADDR_L, ver_pkey_data, &key_len);
            uiExCsfHeader_flag = 2;
            if(uiret != 0)
            {
                dbgErr("load and verify low caExCsfFile failed\n");
                BspSetCpuVerErrReason(g_ucRunVer, BSP_CA_EXTRA_FILE_VERIFY_ERROR+(uiExCsfHeader_flag-1)*0x80);
                BspSetCaErrReason(uiExCsfHeader_flag-1, CA_CAFILE_VERIFY_ERROR);
                return BSP_ERROR;
            }
            else
            {
                iret = rsa_auth_signature(calc_hash, ver_pkey_data, key_len, ver_sign_data, sign_len);
                if(iret != 0)
                {
                    dbgErr("rsa_auth_signature verify cpu swv error!\n");
                    BspSetCpuVerErrReason(g_ucRunVer, BSP_VER_VERIFY_ERROR + (uiExCsfHeader_flag-1)*0x80);
                    BspSetCaErrReason(uiExCsfHeader_flag-1, CA_SIGNATURE_ERROR);
                    return BSP_ERROR;
                }
            }
        }
        else
        {
            dbgErr("rsa_auth_signature verify cpu swv error!\n");
            BspSetCpuVerErrReason(g_ucRunVer, BSP_VER_VERIFY_ERROR+(uiExCsfHeader_flag-1)*0x80);
            BspSetCaErrReason(uiExCsfHeader_flag-1, CA_SIGNATURE_ERROR);
            return BSP_ERROR;
        }
    }

    dbgErr("rsa_auth_signature verify cpu swv PASSED!!!\n");
    BspSetCaErrReason(uiExCsfHeader_flag-1, 0);
    if(uiExCsfHeader_flag==1)
        dbgErr("use high CA file\n");
    else
        dbgErr("use low CA file\n");

    /*bsp ptVerFileHeader have not uiAntiRollback*/
    /*rollback verify*/

    uiret = BspGetNvModeSwitch(&uiNvEnable);
    if(uiret != 0)
    {
        dbgErr("zte_auth_nvctr get BspGetNvModeSwitch failed, goon...\n");
        return BSP_OK;
    }

    if(uiNvEnable)
    {
        uiret = BspUserNvValRead(&uiNvRead);
        if(uiret != 0)
        {
            dbgErr("BspUserNvValRead ret error!\n");
            BspSetCpuVerErrReason(g_ucRunVer, BSP_VER_NV_VERIFY_ERROR + (uiExCsfHeader_flag-1)*0x80);
            return BSP_ERROR;
        }
        else if(uiNvRead > *(unsigned int *)((char *)ptVerFileHeader+CPU_VERSION_NV_COUNT_OFFSET))
        {
            dbgErr("zte_auth_nvctr verify cpu swv error!\n");
            BspSetCpuVerErrReason(g_ucRunVer, BSP_VER_NV_VERIFY_ERROR + (uiExCsfHeader_flag-1)*0x80);
            return BSP_ERROR;
        }
        dbgErr("zte_auth_nvctr verify cpu swv PASSED!!!\n");
    }

    return BSP_OK;
}
#endif
/* ******************************************************************************
* 函数名称： STATUS  ldFileFromRam(CHAR *pcFileName, FUNCPTR *pEntry)
* 功能描述： 从内存加载指定的文件
* 输入参数： pucVerbuf: 版本缓存指针
* 输出参数：
* 返 回 值： ERROR: 加载失败
*            OK: 加载成功
* 其它说明：
* 修改日期    版本号     修改人         修改内容
* -----------------------------------------------
* 2015-10-26   V1.0      00086970        创建
********************************************************************************* */
ULONG ldFileFromRam(UCHAR *pucVerbuf, ULONG ulFileSize)
{
    INT iRetVal;
    UCHAR *pucRealVerFileBuff = NULL;
    UCHAR *pucRealVerBuf = NULL;
    UCHAR ucCpuType = 0;
    ULONG ulCalCRCResult = 0;
    ULONG ulFileCRC = 0;
    ULONG ulRealFileSize;
    T_VerFileHeader *ptVerFileHeader = NULL;
    ULONG cpuVercheckflag = TRUE;

    if (NULL == pucVerbuf)
    {
        dbgErr("Input para null.\n");
        return BSP_ERROR;
    }

    /* 读取版本文件内容 */

    pucRealVerBuf = pucVerbuf;
    ptVerFileHeader = (T_VerFileHeader *)pucRealVerBuf;

    #if (defined(COMPILE_FOR_KEXEC_BOOT) && defined(CONFIG_ZXW11200))
    {
        if(SLAVE_GPIO_FLAG == ms_flag())
        {
            cpuVercheckflag = FALSE;    /*4C做从不检查cpu版本*/
        }
    }
    #endif

    if(cpuVercheckflag == TRUE)
    {
        /*校验软件类型是否是CPU软件*/
        if (VERSION_CPU != ntohs(ptVerFileHeader->usVerType))
        {
            dbgErr("Ver Type is %d\n", ntohs(ptVerFileHeader->usVerType));
            dbgErr("Version type isn't CPU\n");
            /*设置软件类型不匹配错误,UCHG00156197,zhangaiq,20090421*/
            #ifndef _4C_VDE_TEST_
            BspSetCpuVerErrReason(g_ucRunVer, BSP_VER_SWCLASS_ERROR);
            #endif
            return BSP_ERROR;
        }
    }

    BspGetCpuType(&ucCpuType);
    if (ucCpuType != ptVerFileHeader->ucCpuType)
    {
        dbgErr("Cpu type in VerFileHeader is %d\n", ptVerFileHeader->ucCpuType);
        dbgErr("CPU type isn't Match\n");
        /*设置CPU类型不匹配错误,UCHG00156197,zhangaiq,20090421*/
        #ifndef _4C_VDE_TEST_
        BspSetCpuVerErrReason(g_ucRunVer, BSP_VER_CPUTYPE_ERROR);
        #endif
        return BSP_ERROR;
    }
    #ifndef _4C_VDE_TEST_
    BspSetCpuSoftVersion(ptVerFileHeader->ucVerNo, VERNO_LEN);
    #endif

    /*modify by zengweixin 2009-12-03*/
    /* SetCpuVersionInfo();将加载的CPU版本号记录下来*/
    /* 计算版本文件的CRC校验值 */

    ulFileCRC = ntohl(ptVerFileHeader->ulCRC32);
    #ifdef CONFIG_SECURITY
    /* Started by AICoder, pid:eca297c77cgf02014eec0837b0a4800e45a98d62 */
    UINT uiBootSecureMode = 0;
    unsigned int uiret = 0;
    /* Ended by AICoder, pid:eca297c77cgf02014eec0837b0a4800e45a98d62 */
    uiret = BspGetSafeBootCheckSwitch(&uiBootSecureMode);
    /*secure mode smc call error , goto run realese version*/
    if ((0 == uiret) && (1 == uiBootSecureMode))
    {
        uiret = VerifyCpuVersion(pucRealVerBuf, ulFileCRC, ulFileSize);
        if (uiret != 0)
        {
            dbgErr("secure on: verify cpu error\n");
            return BSP_ERROR;
        }
        else
        {
            dbgErr("secure on: verify cpu pass!!\n");
        }
    }
    else
    #endif
    {
        dbgErr("CalculateCRC ......");
        ulCalCRCResult = CalculateCRC16(CRC_MASK, (UCHAR *)pucRealVerBuf + sizeof(ptVerFileHeader->ulCRC32),
                                        (UINT32)ulFileSize - sizeof(ptVerFileHeader->ulCRC32));

        /* 如果版本文件的CRC校验出错 */
        if (ulFileCRC != ulCalCRCResult)
        {
            dbgErr("\n CRC calculated in Boot is 0x%x,but in file header is 0x%x!!\n", ulCalCRCResult, ulFileCRC);
            dbgErr(" Version File CRC error !!!!\n");
            /*设置CRC校验出错错误,UCHG00156197,zhangaiq,20090421*/
            #ifndef _4C_VDE_TEST_
            BspSetCpuVerErrReason(g_ucRunVer, BSP_VER_CRC_ERROR);
            #endif
            return BSP_ERROR;
        } /* 如果版本文件的CRC校验出错 */
        else if (0 == ulCalCRCResult)
        {
            /* CRC为0的时候再校验一下数据是否全0，全0也认为CRC错误 */
            if (BSP_OK == CheckBufAllZero((UCHAR *)(pucRealVerBuf + sizeof(ptVerFileHeader->ulCRC32)),
                                          (UINT32)(ulFileSize - sizeof(ptVerFileHeader->ulCRC32))))
            {
                dbgErr("Version CRC error!! File all zero!!\n");
                #ifndef _4C_VDE_TEST_
                BspSetCpuVerErrReason(g_ucRunVer, BSP_VER_CRC_ERROR);
                #endif
                return BSP_ERROR;
            }
        }
        dbgErr("ok.\n");
    }

    pucRealVerFileBuff = pucRealVerBuf + sizeof(T_VerFileHeader);
    ulRealFileSize = ulFileSize - sizeof(T_VerFileHeader);

    /*打包文件先拆包,多核版本主核永远是第一个版本*/
    dbgErr("fileSize---%u, pucRealVerFileBuff --- 0x%x\n", ulRealFileSize, (ULONG)pucRealVerFileBuff);
    dbgErr("ok.\n");

    /*
    ramdisk 压缩比率, 实际为a.bin-->b.in的压缩的反过程,
    考虑到各单板压缩算法不同,由各单板各自指定.
    */

    #if defined(VERSION_UNCOMPRESS) /*非压缩格式*/ /*增加长度入参校验用*/
    iRetVal = LoadLinuxUnCompress(pucRealVerFileBuff, ntohl(ptVerFileHeader->ulOriginalSize));
    #else
    /*压缩格式*/
    /*字节序放这里*/
    iRetVal = LoadLinuxCompress(pucRealVerFileBuff, ntohl(ptVerFileHeader->ulOriginalSize));
    #endif

    if (BSP_OK != iRetVal)
    {

        /*设置版本解压缩失败错误,UCHG00156197,zhangaiq,20090421*/
        #ifndef _4C_VDE_TEST_
        BspSetCpuVerErrReason(g_ucRunVer, BSP_VER_UNCMP_ERROR);
        #endif
        return BSP_ERROR;
    }

    return BSP_OK;
}

/* ******************************************************************************
* 函数名称： STATUS  ldCertainFile(CHAR *pcFileName, FUNCPTR *pEntry)
* 功能描述： 从母板的Flash文件系统加载指定的文件
* 输入参数： pcFileName: 文件名,包含路径。
* 输出参数： pEntry: 存放下载映象的起始地址
* 返 回 值： ERROR: 加载失败
*            OK: 加载成功
* 其它说明：
* 修改日期    版本号     修改人         修改内容
* -----------------------------------------------
* 2007-12-26   V1.0      张爱卿          创建
********************************************************************************* */
ULONG ldCertainFile(const char *pcFileName, FUNCPTR *pEntry)
{

    INT iRetVal;
    INT fd = 0;
    UCHAR *pucRdVerFileBuff = NULL;
    ULONG ulFileSize;
    struct stat tStat;
    
    

    if ((NULL == pcFileName) || (NULL == pEntry))
    {
        dbgErr("Input para null.\n");
        return BSP_ERROR;
    }
    dbgErr("fileName --- %s \n", pcFileName);
    #ifdef CONFIG_SECURITY
    /* Started by AICoder, pid:lca290c77ckf02014eec0837b0a4800e45a78d62 */
    UINT32 uiBootSecureMode = 0;
    UINT32 uiret = 0;
    /* Ended by AICoder, pid:lca290c77ckf02014eec0837b0a4800e45a78d62 */
    /*add file verify*/
    uiret = BspGetSafeBootCheckSwitch(&uiBootSecureMode);
    /*secure mode smc call error , goto run realese version*/
    if ((0 == uiret) && (1 == uiBootSecureMode))
    {
        if (0 == strcmp(pcFileName, RTR_VX_OLD))
        {
            pcJsonFileName = RTR_VX_JSON_OLD;
        }
        else if (0 == strcmp(pcFileName, RTR_VX_NEW))
        {
            pcJsonFileName = RTR_VX_JSON_NEW;
        }
        else if (0 == strcmp(pcFileName, RTR_VX_DBG))
        {
            pcJsonFileName = RTR_VX_JSON_DBG;
        }
    }
    #endif
    /* 读取版本文件内容 */
    fd = open(pcFileName, O_RDONLY, 0666);
    if (0 > fd)
    {
        dbgErr("Can not open version file!\n");
        /*设置版本文件打开失败错误,UCHG00156197,zhangaiq,20090421*/
        #ifndef _4C_VDE_TEST_
        BspSetCpuVerErrReason(g_ucRunVer, BSP_VER_OPEN_ERROR);
        #endif
        return BSP_ERROR;
    }

    /*获取文件长度*/
    if (fstat(fd, &tStat) < 0)
    {
        dbgErr("Can not fstat version file!\n");
        #ifndef _4C_VDE_TEST_
        BspSetCpuVerErrReason(g_ucRunVer, BSP_VER_READ_ERROR);
        #endif
        close(fd);
        return BSP_ERROR;
    }
    ulFileSize = tStat.st_size;

    /* if (ulFileSize > MAX_CPU_VERSION_SIZE)
    {
        dbgErr("cpu version file size %ld exceed in 16M\n",ulFileSize);
        BspSetCpuVerErrReason(g_ucRunVer,BSP_VER_READ_ERROR);
        close(fd);
        return BSP_ERROR;
    }*/

    /* 申请读版本文件缓存 */
    pucRdVerFileBuff = (UCHAR *)malloc(ulFileSize);
    if (NULL == pucRdVerFileBuff)
    {
        dbgErr("version file size %u\n", ulFileSize);
        dbgErr("malloc read version file buffer failed!\n");
        #ifndef _4C_VDE_TEST_
        BspSetCpuVerErrReason(g_ucRunVer, BSP_VER_READ_ERROR);
        #endif
        close(fd);
        return BSP_ERROR;
    }
    zte_memset_s(pucRdVerFileBuff, ulFileSize, 0, ulFileSize);
    iRetVal = zte_read_s(fd, pucRdVerFileBuff, ulFileSize, ulFileSize);
    if ((ULONG)iRetVal != ulFileSize)
    {
        dbgErr("Version file read error\n");
        close(fd);
        free(pucRdVerFileBuff);
        pucRdVerFileBuff = NULL;
        /*设置版本文件读取失败错误,UCHG00156197,zhangaiq,20090421*/
        #ifndef _4C_VDE_TEST_
        BspSetCpuVerErrReason(g_ucRunVer, BSP_VER_READ_ERROR);
        #endif
        return BSP_ERROR;
    }
    close(fd);

    iRetVal = ldFileFromRam(pucRdVerFileBuff, ulFileSize);

    if (BSP_OK != iRetVal)
    {
        free(pucRdVerFileBuff);
        pucRdVerFileBuff = NULL;
        /* CPU版本错误码由调用函数内部填写 */
        return BSP_ERROR;
    }

    free(pucRdVerFileBuff);
    pucRdVerFileBuff = NULL;
    return BSP_OK;
}

/* ******************************************************************************
* 函数名称： STATUS  ldFileFromFlash(CHAR *pcFileSysDiskName, FUNCPTR *pEntry)
* 功能描述： 从母板的Flash文件系统加载版本文件
* 输入参数： pcFileSysDiskName: Flash文件系统的盘符。如DOC文件系统为"/ROOT/"
* 输出参数： pEntry: 存放下载映象的起始地址
* 返 回 值： ERROR: 加载失败
*            OK: 加载成功
* 其它说明： 文件系统加载版本文件
* 修改日期    版本号     修改人         修改内容
* -----------------------------------------------
* 2012-02-23   V1.1      曾     鑫          完善RRUCFG.INI异常时的保护区分支处理
* 2007-12-26   V1.0      张爱卿          创建
********************************************************************************* */
STATUS ldFileFromFlash(void)
{
    INT32 fd = 0;
    UINT len = 0;
    UCHAR ucCnt;
    INT32 iRetVal;
    CHAR pchBootFile[64]; /*加载的文件名*/
    T_OamCfgParam tLoadCfgParam = {{0}, 0};
    FUNCPTR entry = 0;
    UINT retVal = 0;

    /*UCHAR *cmdBuf = "bootm 0x600000 0xa00000";*/
    T_CtrlVerErrReason tCpuErrReason;

    /* 在boot中使用看门狗,创建喂狗任务 */
    /*  intfBspWatchDogEnable();
    ucBootWDTaskID = kubootTaskCreate(WDTaskEntry, (void*)0, &WatchDogMainStack[WATCHDOG_STK_SIZE -1], WATCHDOG_MAIN_PRI);*/

    /*先对CPU版本加载错误记录清零,保留激活版本回退的错误码,UCHG00156197,zhangaiq,20090421*/
    #ifndef _4C_VDE_TEST_
    zte_memcpy_s(&tCpuErrReason, sizeof(T_CtrlVerErrReason), (CHAR *)CPU_VER_ERR_ADRS, sizeof(T_CtrlVerErrReason));

    if (tCpuErrReason.ulMarkVal == BSP_CPU_LOAD_REASON_MARKVAL)
    {
        BspClrCpuVerErrReason();
        if ((tCpuErrReason.ucRunVer == BSP_ACK_VERSION) && (tCpuErrReason.ucAckVerErr != 0))
        {
            BspSetCpuVerErrReason(BSP_ACK_VERSION, tCpuErrReason.ucAckVerErr);
        }
    }
    else
    {
        BspClrCpuVerErrReason();
    }
    /* EC614001691568,设置好默认启动版本和CERR特征码,By Zengx,11.09.20 */
    g_ucRunVer = BSP_RUN_VERSION;
    BspSetCpuVerErrReason(g_ucRunVer, 0);
    #endif
    fd = open(RTRDOWNCFGFILE, O_RDONLY, 0);

    if (fd < 0)
    {
        /*如果打开文件失败或读文件失败在指定路径创建文件*/
        fd = open(RTRDOWNCFGFILE, (O_CREAT | O_RDWR), 0644);
        dbgErr("Create RTRDOWNCFGFILE wb\n");
        if (fd < 0)
        {
            dbgErr("Create RTRDOWNCFGFILE Error!\n");
            #ifndef _4C_VDE_TEST_
            /*添加高端内存错误指示:打开配置文件失败yc20110616*/
            BspSetCpuVerErrReason(g_ucRunVer, BSP_BOOTINI_OPEN_ERROR);
            /* 记录错误码后按保护区分支启动,By Zengx,2012.02.23 */
            #endif
            s_bProzoneFlag = TRUE;
            return 2;
        }
        /*初始化数据,注意名字长度*/
        for (ucCnt = 0; ucCnt < 30; ucCnt++)
        {
            tLoadCfgParam.acName[ucCnt] = 0;
        }
        /*strcpy((char*)tLoadCfgParam.acName, (const char*)FLAG_RTRVER);用strncpy代替*/
        zte_strncpy_s((char *)tLoadCfgParam.acName, 30, (const char *)FLAG_RTRVER, 30);
        tLoadCfgParam.acName[29] = '\0';
        tLoadCfgParam.cFlag = '=';
        tLoadCfgParam.cValue = '0';
        tLoadCfgParam.cEnd = '\n'; /*由'\0' 改为'\n'换行符, By Zengx, 2011.07.22 */
        dbgErr("\n****TLoadCfgParam chValue=%x****\n", tLoadCfgParam.cValue);

        retVal = lseek(fd, 0, SEEK_SET); /* 0530 yc */
        if (-1 == retVal)
        {
            close(fd);
            return BSP_ERROR;
        }
        len = write(fd, (char *)(&tLoadCfgParam), FLAG_CPUVER_LEN);
        if (len < FLAG_CPUVER_LEN)
        {
            dbgErr("write only %d bytes to file RTRDOWNCFGFILE,break...\n", len);
            /*添加高端内存错误指示:写配置文件失败yc20110616*/
            #ifndef _4C_VDE_TEST_
            BspSetCpuVerErrReason(g_ucRunVer, BSP_BOOTINI_WRITE_ERROR);
            #endif
            close(fd);
            /* 记录错误码后按保护区分支启动,By Zengx,2012.02.23 */
            s_bProzoneFlag = TRUE;
            return 3;
        }
        close(fd);
    }
    else
    {
        len = zte_read_s(fd, (char *)(&tLoadCfgParam), FLAG_CPUVER_LEN, FLAG_CPUVER_LEN);
        if (len != FLAG_CPUVER_LEN)
        {
            dbgErr("file %s read not enough content, break...\n", RTRDOWNCFGFILE);
            /*添加高端内存错误指示:配置文件长度不正确yc20110616*/
            #ifndef _4C_VDE_TEST_
            BspSetCpuVerErrReason(g_ucRunVer, BSP_BOOTINI_LEN_ERROR);
            #endif
            close(fd);
            /* 记录错误码后按保护区分支启动,By Zengx,2012.02.23 */
            s_bProzoneFlag = TRUE;
            return 4;
        }
        /* 增加验证CPU_VER_FLAG标志,By Zengx,2012.02.23 */
        if (0 != strncmp((const char *)tLoadCfgParam.acName, (const char *)FLAG_RTRVER, strlen(FLAG_RTRVER) + 1))
        {
            dbgErr("file %s read not correct content, break...\n", RTRDOWNCFGFILE);
            /* 将读取内容错误视为CRC错误码,By Zengx,2012.02.23 */
            #ifndef _4C_VDE_TEST_
            BspSetCpuVerErrReason(g_ucRunVer, BSP_BOOTINI_CRC_ERROR);
            #endif
            close(fd);
            /* 记录错误码后按保护区分支启动,By Zengx,2012.02.23 */
            s_bProzoneFlag = TRUE;
            return 5;
        }
        close(fd);
    }
    // coverity[cert_int31_c_violation:SUPPRESS]
    zte_strncpy_s(pchBootFile, sizeof(pchBootFile), RTR_VX_OLD, zte_strnlen_s(RTR_VX_OLD, 100) + 1);
    pchBootFile[63] = '\0';
    #ifndef _4C_VDE_TEST_
    /*向文件写入数据*/
    switch (tLoadCfgParam.cValue)
    {
        case NORMAL_BOOT:
        {
            dbgErr("RRU:Normal boot ...... \n");
            g_ucRunVer = BSP_RUN_VERSION;
            BspSetCpuVerErrReason(g_ucRunVer, 0);
            s_bRunFlag = TRUE;
            break;
        }

        case ACTIVE_BOOT:
        {
            /*设置新文件为当前启动文件供后面程序调入内存*/
            g_ucRunVer = BSP_ACK_VERSION;
            BspSetCpuVerErrReason(g_ucRunVer, 0);
            // coverity[cert_int31_c_violation:SUPPRESS]
            zte_strncpy_s(pchBootFile, sizeof(pchBootFile), RTR_VX_NEW, zte_strnlen_s(RTR_VX_NEW, 100) + 1);
            pchBootFile[63] = '\0';
            dbgErr("RRU:Upgrading......\n");
            /*更新软件板本指示标志*/
            dbgErr("RRU:Old [%s] = %c.\n", FLAG_RTRVER, tLoadCfgParam.cValue);
            tLoadCfgParam.cValue = UPGRADE_BOOT; /*标记进入升级状态*/
            /* 614003807741, start */
            fd = open(RTRDOWNCFGFILE, O_RDWR);
            dbgErr("### fopen %s wb fd=%d\n", RTRDOWNCFGFILE, fd);
            if (fd < 0)
            {
                dbgErr("RRU:Open file \"%s\" fail...\n", RTRDOWNCFGFILE);
                BspSetCpuVerErrReason(g_ucRunVer, BSP_BOOTINI_OPEN_ERROR);
                break;
            }
            if (0 != lseek(fd, 0, SEEK_SET))
            {
                dbgErr("RRU:Update %s fail,lseek fail...\n", RTRDOWNCFGFILE);
                BspSetCpuVerErrReason(g_ucRunVer, BSP_BOOTINI_READ_ERROR);
            }
            len = write(fd, (char *)(&tLoadCfgParam), FLAG_CPUVER_LEN);
            dbgErr("### fwrite %s wb len=%d\n", RTRDOWNCFGFILE, FLAG_CPUVER_LEN);
            if (len < FLAG_CPUVER_LEN)
            {
                dbgErr("RRU:Update %s fail,write only %d bytes to file %s,break...\n", RTRDOWNCFGFILE, len, RTRDOWNCFGFILE);
                /*添加高端内存错误指示:写配置文件失败yc20110616*/
                BspSetCpuVerErrReason(g_ucRunVer, BSP_BOOTINI_WRITE_ERROR);
                close(fd);
                break;
            }
            /* 614003807741, end */
            close(fd);
            dbgErr("RRU:Update %s success.\n", RTRDOWNCFGFILE);
            dbgErr("RRU:New [%s] = %c.\n", FLAG_RTRVER, tLoadCfgParam.cValue);
            break;
        }

        case UPGRADE_BOOT:
        {
            dbgErr("RRU:Previous upgrading failure detected, recovering......\n");
            /*更新软件板本指示标志*/
            s_bBackFlag = TRUE;
            dbgErr("RRU:Old [%s] = %c.\n", FLAG_RTRVER, tLoadCfgParam.cValue);
            tLoadCfgParam.cValue = FAILURE_BOOT;
            fd = open(RTRDOWNCFGFILE, O_RDWR);
            if (fd < 0)
            {
                dbgErr("RRU:Open file \"%s\" fail...\n", RTRDOWNCFGFILE);
                BspSetCpuVerErrReason(g_ucRunVer, BSP_BOOTINI_OPEN_ERROR);
                break;
            }
            dbgErr("### fopen %s wb fd=%d\n", RTRDOWNCFGFILE, fd);
            /* 614003807741, start */
            if (0 != lseek(fd, 0, SEEK_SET))
            {
                dbgErr("RRU:Update %s fail,lseek fail...\n", RTRDOWNCFGFILE);
                BspSetCpuVerErrReason(g_ucRunVer, BSP_BOOTINI_READ_ERROR);
            }
            len = write(fd, (char *)(&tLoadCfgParam), FLAG_CPUVER_LEN);
            dbgErr("### fwrite %s wb len=%d\n", RTRDOWNCFGFILE, FLAG_CPUVER_LEN);
            if (len < FLAG_CPUVER_LEN)
            {
                dbgErr("RRU:Update %s fail,write only %d bytes to file %s,break...\n", RTRDOWNCFGFILE, len, RTRDOWNCFGFILE);
                /*添加高端内存错误指示:写配置文件失败yc20110616*/
                BspSetCpuVerErrReason(g_ucRunVer, BSP_BOOTINI_WRITE_ERROR);
                close(fd);
                break;
            }
            /* 614003807741, end */
            close(fd);
            dbgErr("RRU:Update %s success.\n", RTRDOWNCFGFILE);
            dbgErr("RRU:New [%s] = %c.\n", FLAG_RTRVER, tLoadCfgParam.cValue);
            break;
        }

        case FAILURE_BOOT:
        {
            /*上次的升级错误未被上报*/
            dbgErr("RRU:There are upgrading errors without report\n");
            s_bRunFlag = TRUE; /*相当于加载 cur.swv*/
            break;
        }

        default:
        {
            /*异常状态*/
            dbgErr("RRU:Abnormal boot indicator status ! \n");
            break;
        }
    }
    #endif
    /*开始加载*/
    for (ucCnt = 0; ucCnt < 2; ucCnt++)
    /*尝试下载 2次*/
    {
        /*判断压缩文件是否存在*/
        dbgErr("Retry Time(=%d)\n", ucCnt);

        fd = open(pchBootFile, O_RDONLY, 0);
        if (-1 == fd)
        {
            if (0 < ucCnt)
            {
                dbgErr("open %s fail!\n", pchBootFile);
                /*添加高端内存错误指示:版本文件不存在yc20110616*/
                #ifndef _4C_VDE_TEST_
                BspSetCpuVerErrReason(g_ucRunVer, BSP_VER_OPEN_ERROR);
                #endif
                /*add by lyq 10242265 2018-12-22 即使加载错误也记录节点*/
                #if defined(CONFIG_RECORD_TIME)
                if (0 == strcmp(pchBootFile, RTR_VX_OLD))
                {
                    TimeNode(CUR_END);
                }
                else if (0 == strcmp(pchBootFile, RTR_VX_NEW))
                {
                    TimeNode(TMP_END);
                }
                else
                    ;
                #endif
                return -1;
            }
            continue;
        }
        close(fd);
        dbgErr("Loading File: %s ......", pchBootFile);
        dbgErr("Start linux image  package unpressing...\n");
        iRetVal = ldCertainFile(pchBootFile, &entry);
        dbgErr("load linux pack ,retVal  =  %d!\n", iRetVal);
        /*add by lyq 10242265 2018-12-22*/
        #if defined(CONFIG_RECORD_TIME)
        if (0 == strcmp(pchBootFile, RTR_VX_OLD))
        {
            TimeNode(CUR_END);
        }
        else if (0 == strcmp(pchBootFile, RTR_VX_NEW))
        {
            TimeNode(TMP_END);
        }
        else
            ;
        #endif
        /* Started by AICoder, pid:ob44cecc2eiab5b1459308b1a076c71fcf99bf77 */
        if (BSP_OK == iRetVal)
        /* 如果解压无误，则跳转至程序入口*/
        {
            /*释放分配的内存*/
            /*dbgErr("RRU:Free memory.\n");*/
            // run_command(CONFIG_BOOTMCMD, 0);
            return BSP_OK;
            /*跳转到内核启动入口*/

            /*run_command(cmdBuf, 0); */
        }
        else
        /* 如果解压错误，即原CRC 或解压后CRC 错误，则重启*/
        {
            /*解压错误重启动! */
            dbgErr("ERROR! FAIL TO DECOMPRESS  FILE %s  _zxb\n", pchBootFile);
            /* CPU版本错误码由调用函数内部填写 */
            return -1;
        }
        /* Ended by AICoder, pid:ob44cecc2eiab5b1459308b1a076c71fcf99bf77 */
    }
    /* Started by AICoder, pid:40c01zf46bzb0ff14a370afd908f160a01f15152 */
    return BSP_OK;
    /* Ended by AICoder, pid:40c01zf46bzb0ff14a370afd908f160a01f15152 */
}
/*****************************************************************************
* 函数名称   : GetCmdline
* 功能描述   : 将一级boot传下来的命令行装载到全局数组
* 读全局变量 : 无
* 写全局变量 : 无
* 输入参数   : 无
* 输出参数   : 无
* 返 回 值   : 硬件信息
* 其它说明   : 用于1。kexecboot给正式版本内核传参，2。kexecboot通过mem=获取
*               cpu使用的内存大小(不是ddr的物理大小)
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 00086970@2016-03-31      创建
*----------------------------------------------------------------------------
*/

ULONG GetCmdline(VOID)
{

    LONG lRetVal = BSP_OK;
    INT fd = 0;

    fd = open("/proc/cmdline", O_RDONLY, 0x666);
    if (0 > fd)
    {
        dbgErr("Can not open /proc/cmdline\n");
        return BSP_ERROR;
    }

    lRetVal = zte_read_s(fd, g_ucCmdLine, sizeof(g_ucCmdLine), sizeof(g_ucCmdLine));

    if (0 >= lRetVal)
    {
        dbgErr("read /proc/cmdline error\n");
        close(fd);
        return BSP_ERROR;
    }

    /* 因读取/proc/cmdline时内核在尾部加了个'\n'，需相应去掉 */
    g_ucCmdLine[lRetVal - 1] = 0;
    dbgErr("cmdline: %s", g_ucCmdLine);

    close(fd);

    return (ULONG)lRetVal;
}
/*****************************************************************************
* 函 数 名: KexecCmdBuild
* 功能描述: kexec参数行构造函数
* 输入参数: UCHAR *pucParamBuf : 参数行buf指针
* 输入参数: UCHAR ucBufSize    : 参数行buf大小，字节单位
* 输出参数: 无
* 返 回 值: 正确为OK，否则为错误码
* 其他说明: 适配各CPU平台内核引导行
* 修改日期　　　　版本号　　修改人　　修改内容
* --------------------------------------------
* 2015年11月2日　　V1.0　　　10029949　　　新建
*
*****************************************************************************/
STATUS KexecCmdBuild(UCHAR *pucParamBuf, size_t ucBufSize)
{
    /* UCHAR ulLen1,ulLen2; */
    /* 字符串内部对\和"都需增加\转义处理，以便保留子字符串 */
    char ucBufCmd[256] = {0};
    UINT32 retVal = 0;

    #if defined(CONFIG_DTB)
    #if (defined(CONFIG_LS10X3A) || defined(CONFIG_ZXW11200) || defined(CONFIG_ZX211412) || defined(CONFIG_ZX211413))
    retVal = zte_snprintf_s(ucBufCmd, sizeof(ucBufCmd), "kexec -l /uImage --initrd=/ramdisk.bin --dtb=/system.dtb --reuse-cmdline");
    #else
    retVal = zte_snprintf_s(ucBufCmd, sizeof(ucBufCmd), "kexec -l /uImage --initrd=/ramdisk.bin --dtb=/system.dtb");
    #endif

    #else
    // coverity[cert_exp37_c_violation:SUPPRESS]
    /* Started by AICoder, pid:yec8f0b8deq9593145940a2470193b0f75a512ba */
    if (0 == zte_strnlen_s((const char *)g_ucCmdLine, sizeof(g_ucCmdLine)))
    /* Ended by AICoder, pid:yec8f0b8deq9593145940a2470193b0f75a512ba */
    {
        if (BSP_ERROR == GetCmdline())
        {
            SetDefaultCmdline();
        }
    }
    /*目前strlen(ucBufCmd)已经149，ucBufSize 150,命令行再增加字符需注意越界*/
    /*sprintf(ucBufCmd, "kexec -l /uImage --initrd=/ramdisk.bin  --append=\\\"%s\\\"", g_ucCmdLine);*/
    retVal = zte_snprintf_s(ucBufCmd, sizeof(ucBufCmd), "kexec -l /uImage --initrd=/ramdisk.bin  --append=\\\"%s\\\"", g_ucCmdLine);
    #endif

    /*COV 58597*/
    if (retVal != zte_strnlen_s(ucBufCmd, sizeof(ucBufCmd)))
    {
        dbgErr("%s %d sprintf error!!\n", __func__, __LINE__);
        return BSP_ERROR;
    }
    /* Started by AICoder, pid:49e7fj781crd76e14543098c80d2ee0c5515a628 */
    zte_strncpy_s((char *)pucParamBuf, ucBufSize, ucBufCmd, ucBufSize);
    /* Ended by AICoder, pid:49e7fj781crd76e14543098c80d2ee0c5515a628 */
    return OK;
}

/*****************************************************************************
* 函 数 名: KexecRebootCmd
* 功能描述: kexec命令执行函数
* 输入参数: ULONG ulCause : 软复位原因宏值
*           ULONG ulWtd   : 看门狗重置标志，0-不重置看门狗喂狗时间/1-重置看门狗喂狗时间
* 输出参数: 无
* 返 回 值: 正常返回OK，错误则返回错误码
* 其他说明:
* 修改日期　　　　版本号　　修改人　　修改内容
* --------------------------------------------
* 2015年11月2日　　V1.0　　　10029949　　　新建
*
*****************************************************************************/
STATUS KexecRebootCmd(ULONG ulCause, ULONG ulWtd)
{
    UCHAR ucKexecBuf[180] = {0};
    UCHAR ucParamBuf[150] = {0};
    STATUS iRetVal = ERROR;
    INT32 retVal = 0;

    zte_memset_s(ucParamBuf, sizeof(ucParamBuf), 0, sizeof(ucParamBuf));
    iRetVal = KexecCmdBuild(ucParamBuf, sizeof(ucParamBuf));
    if (BSP_ERROR == iRetVal)
    {
        dbgErr("KEXEC REBOOT: KexecCmdBuild Error!\n");
        return BSP_ERROR;
    }
    /* 需对kexec参数字符串前后增加\"转义处理，方可整体用作一个字符串入参 */
    /*CERT ERR33-c 类返回值非指针类的告警*/
    // coverity[cert_err33_c_violation:SUPPRESS]
    /* Started by AICoder, pid:w5c20tfae6p4ffb14acc0a3bc043d8090c61bdb4 */
    retVal = zte_snprintf_s((char *)ucKexecBuf, sizeof(ucKexecBuf), "kexec_reboot \"%s\" %d %d", ucParamBuf, ulCause, ulWtd);
    /* Ended by AICoder, pid:w5c20tfae6p4ffb14acc0a3bc043d8090c61bdb4 */
    SNPRINTF_S_CHECK(retVal,sizeof(ucKexecBuf));
    // dbgErr("%s\n", ucParamBuf);
    // dbgErr("%s\n", ucKexecBuf);
    /* Started by AICoder, pid:8e35csdc5ffd57c14f5a0a6ce0a6d70ada11b0a3 */
    iRetVal = BspSystem((char *)ucKexecBuf);
    /* Ended by AICoder, pid:8e35csdc5ffd57c14f5a0a6ce0a6d70ada11b0a3 */
    /* 这里是对应着Vos_System的返回值做判断，ERROR/-1才为错误，其他则都视为正确， */
    /* 即将Vos_System中waitpid(pid)的正常返回也按正确返回处理 */
    if (ERROR == iRetVal)
    {
        dbgErr("KEXEC REBOOT: BspSystem Error!\n");
        return ERROR;
    }

    return OK;
}

unsigned int GetFreeMem()
{
    struct sysinfo s_info;
    int error;
    error = sysinfo(&s_info);
    if (error < 0)
    {
        /*若获取失败，为了不改变原流程，此处按最大数值返回*/
        return 0xFFFFFFFF;
    }
    return s_info.freeram;
}
int IsMemOkForKeReboot()
{
    int fd = -1;
    unsigned int len = 0;
    unsigned int freeMem = 0;
    struct stat tStat;
    if ((fd = open(RTR_VX_OLD, O_RDONLY)) < 0)
    {
        if ((fd = open(RTR_VX_NEW, O_RDONLY)) < 0)
        {
            dbgErr("Can not open cur.swv & tmp.swv version file!\n");
            return BSP_OK;
        }
    }

    if (fstat(fd, &tStat) < 0)
    {
        dbgErr("Can not fstat version file!\n");
        close(fd);
        return BSP_OK;
    }
    len = tStat.st_size;
    close(fd);

    freeMem = GetFreeMem();
    /*预留3M，防止OOM*/
    if ((len * 2 + 3 * 1024 * 1024) > freeMem)
    {
        /*只有该场景明确需要转为graceful_reboot,其余场景按原流程走*/
        dbgErr("file len %dB, free mem %dB!\n", len, freeMem);
        return BSP_ERROR;
    }
    return BSP_OK;
}

/*****************************************************************************
* 函 数 名: KexecRebootEntry
* 功能描述: kexec软复位入口函数
* 输入参数: ULONG ulCause : 软复位原因宏值
* 输出参数: 无
* 返 回 值: 正常返回OK，错误则返回错误码
* 其他说明:
* 修改日期　　　　版本号　　修改人　　修改内容
* --------------------------------------------
* 2015年11月2日　　V1.0　　　10029949　　　新建
*
*****************************************************************************/
#ifdef CONFIG_KDA_MUL_PROCESS
const char *kda_name = "/dev/KernDrvAgt";
#else
const char *kda_name = "/dev/misc/KernDrvAgt";
#endif

STATUS KexecRebootEntry(ULONG ulCause)
{
    STATUS iRetVal = ERROR;
    UCHAR buffer[20] = {0};
    kda_ioctl_t devIo = {0};
    const char *str = NULL;
    int fd = -1;
    const char *oprator = "c";
    const char *majornew = "10";
    const char *minornew = "244";
    int len = -1;
    if (BSP_OK != IsMemOkForKeReboot())
    {
        str = "Free mem may not enough for ke_reboot,change to graceful_reboot!";
        BspMknod(kda_name, oprator, majornew, minornew);
        if ((fd = open(kda_name, O_RDWR | O_SYNC)) < 0)
        {
            dbgErr("open %s failed!", kda_name);
        }
        else
        {
            len = zte_strnlen_s(str, (sizeof(devIo.dx) - 1));
            zte_memcpy_s(devIo.dx, (sizeof(devIo.dx) - 1), str, len);
            if (ioctl(fd, KDA_PRINT_IN_OS, &devIo))
            {
                dbgErr("ioctl KDA_PRINT_IN_OS failed\n");
            }
            close(fd);
        }
        dbgErr("%s\n", str);
        /* Started by AICoder, pid:g1fade50d3z84dd146460a9a701db20714010276 */
        iRetVal = zte_snprintf_s((char *)buffer, sizeof(buffer), "reboot %u", (unsigned int)ulCause);
        /* Ended by AICoder, pid:g1fade50d3z84dd146460a9a701db20714010276 */
        /* Started by AICoder, pid:f0b84l9594s1a4214d8308307095201ca981be02 */
        if (iRetVal != zte_strnlen_s((char *)buffer, sizeof(buffer)))
        /* Ended by AICoder, pid:f0b84l9594s1a4214d8308307095201ca981be02 */
        {
            dbgErr("%s %d zte_strnlen_s error!!\n", __func__, __LINE__);
            return iRetVal;
        }
        /* Started by AICoder, pid:b3b80pebbcq52be1492c08c4207bf717c197919d */
        BspSystem((char *)buffer);
        /* Ended by AICoder, pid:b3b80pebbcq52be1492c08c4207bf717c197919d */
    }
    else
    {
        iRetVal = ldFileFromFlash();
        if (OK != iRetVal)
        {
            dbgErr("KEXEC REBOOT: Split uImage&ramdisk From SWV Error[%d]!\n",
                   iRetVal);
            return iRetVal;
        }
        iRetVal = KexecRebootCmd(ulCause, 1);
        if (OK != iRetVal)
        {
            dbgErr("KEXEC REBOOT: Kexec Cmd Error[%d]!\n", iRetVal);
            return iRetVal;
        }
    }
    return OK;
}
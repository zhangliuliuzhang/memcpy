/**************************************************************************
 * 版权所有 (C)2001, 深圳市中兴通讯股份有限公司
 *
 * 文件名称: loadversion.h
 * 文件标识:
 * 内容摘要:
 * 其它说明:
 * 当前版本: ZXSDR BBUV120B01
 * 作    者: 
 * 完成日期:
 *
 * 修改记录1:
 *    修改日期: 2012年06月21日
 *    版 本 号: ZXSDR BBUV120B01
 *    修 改 人: 耿佳佳
 *    修改内容: 创建
 * 修改记录2:
 **************************************************************************/
#ifndef _LOADVERSION_H_
#define _LOADVERSION_H_

#ifdef __cplusplus
extern "C" {
#endif


#include <sys/stat.h>
/*公共宏定义*/
#define UIMAGE  0
#define RAMDISK 1
#define DTB     2
#define MAX_VERSION_DESC     3    /* 最多同时打开的包数 */
#define SW_MAX_NUMBER                       10    /* 限制下载软件中文件的个数 */
#define UNPRESS_EC_NULL_BUFFER              (UNPRESS_EC_BASE + 1)
#define UNPRESS_EC_WHOLE_FILE_CRC_ERROR     (UNPRESS_EC_BASE + 2)
#define UNPRESS_EC_WHOLE_FILE_LEN_ERROR     (UNPRESS_EC_BASE + 3)
#define UNPRESS_EC_PACKED_FILE_CRC_ERROR    (UNPRESS_EC_BASE + 4)
#define UNPRESS_EC_UNPACK_ERROR             (UNPRESS_EC_BASE + 5)
#define UNPRESS_EC_UNPACKED_FILE_CRC_ERROR  (UNPRESS_EC_BASE + 6)
#define UNPRESS_EC_DIV_NUM_ERROR            (UNPRESS_EC_BASE + 7)
#define UNPRESS_EC_ERROR_PARAMS             (UNPRESS_EC_BASE + 8)
#define UNPRESS_EC_PACKED_FILE_NOT_EXIST    (UNPRESS_EC_BASE + 9)
#define UNPRESS_EC_APPLY_PD_ERROR           (UNPRESS_EC_BASE + 10)
#define UNPRESS_EC_ZERO_FILE_LENGTH         (UNPRESS_EC_BASE + 11)
#define UNPRESS_EC_MALLOC_FAIL              (UNPRESS_EC_BASE + 12)
#define UNPRESS_EC_READ_FILE_ERROR          (UNPRESS_EC_BASE + 13)
#define UNPRESS_EC_NOT_UNION_TYPE           (UNPRESS_EC_BASE + 14)
#define UNPRESS_EC_BASE                     0x20000000
#define VER_TYPE_CPU                        0
#define VER_TYPE_FPGA                       1
#define VER_TYPE_BOOT                       2
#define VER_TYPE_EPLD                       6
#define VER_TYPE_DSP                        8
#define VER_TYPE_MICROCODE                  9
#define VER_TYPE_HOTPATCH                   12

#define VER_OS_TYPE_VXWORKS                 0
#define VER_OS_TYPE_LINUX                   1

#define NORMAL_BOOT '0'
#define ACTIVE_BOOT '1'
#define UPGRADE_BOOT '2'
#define FAILURE_BOOT '3'

#define RTRDOWNCFGFILE  "/ata/RRUCFG.INI"
#define FLAG_RTRVER     "CPU_VER_FLAG"
#define FLAG_CPUVER_LEN 33
#define BSP_CPU_VER_ERR_ADRS_TMP  (0x87F851B0)  /*0x80000000+128M-512K+0X51B0*/
#define RTR_VX_OLD      "/ata/rru/cur.swv"
#define RTR1_VX_OLD      "/ata1/rru/cur.swv"
#define RTR_VX_NEW      "/ata/rru/tmp.swv"
#define RTR_VX_DBG      "/ata/BSP/cur.swv"
#define RTR_VX_JSON_OLD      "/ata/rru/cur27.swv"
#define RTR_VX_JSON_NEW      "/ata/rru/tmp27.swv"
#define RTR_VX_JSON_DBG      "/ata/BSP/cur27.swv"

#define FLASH_ERASE_SIZE (0x10000)
/*#define MAX_CPU_VERSION_SIZE  0x1000000*/

#define  BSP_FlASH_PROTECT_VERSION         (0x05)     /* Flash版本保护区的版本 */
/* Started by AICoder, pid:o9639db12e863f81486208e9e0aa930eb9b3a26c */
#if defined(COMPILE_FOR_KEXEC_BOOT)
#define  BSP_CPU_LOAD_REASON_MARKVAL       (0x43455252)     /* CPU版本加载原因特征值"CERR" */
#endif
/* Ended by AICoder, pid:o9639db12e863f81486208e9e0aa930eb9b3a26c */
#define  BSP_FLASH_PROTECT_HEAD_CRC_ERROR  (0x13)    /*flash保护区头CRC错误*/
#define  BSP_FLASH_PROTECT_READ_ERROR    (0x12)    /*flash保护区读取失败*/
#define  BSP_VER_SWCLASS_ERROR       (0x0c)     /* 版本软件类型不匹配错误 */     
#define  BSP_VER_CPUTYPE_ERROR       (0x0d)     /* 版本CPU类型不匹配错误 */    
#define  BSP_VER_CRC_ERROR           (0x0e)     /* 版本CRC错误 */ 
#define  BSP_FLASH_PROTECTVER_DOWNLOAD_ERROR  (0x14)    /*保护区版本下在失败错误*/
/*secure on err*/
#define  BSP_JASON_FILE_READ_ERROR       (0x20)  /*JASION FILE READ OR PARSE ERROR*/
#define  BSP_CA_EXTRA_FILE_READ_ERROR    (0x21)  /*read CA_EXT FILE ERROR OR CRC ERROR*/
#define  BSP_CA_EXTRA_FILE_VERIFY_ERROR  (0x22)  /*VERIFY CA EXTRA FILE ERROR*/
#define  BSP_GET_VER_PUBKEY_ERROR        (0x23)  /*get pubkey of version error*/
#define  BSP_VER_HASH_ERROR              (0x24)  /*calc hash of version error*/
#define  BSP_VER_VERIFY_ERROR            (0x25)  /*verify version error*/
#define  BSP_VER_NV_VERIFY_ERROR         (0x26)  /*version rollback verify error*/

typedef struct  tagT_OamCfgParam/* 加载配置文件*/
{
    CHAR acName[30];
    CHAR cFlag;
    CHAR cValue;
    CHAR cEnd;
} T_OamCfgParam;

#pragma pack(1)

typedef struct TagSwIdInfo      /* 软件包头中每个软件的ID和大小信息 */
{
    unsigned char    ucSwId                      ;   /* 软件包中的软件ID */
    unsigned long    ulSwLen                     ;   /* 软件包中的软件大小 */
}TSwIdInfo, *PTSwIdInfo;

typedef struct TagSwPackage     /* 软件包的文件头结构 */
{
    unsigned char    ucSwNum                     ;   /* 软件包中的软件个数 */
    TSwIdInfo        atSwIdInfo[SW_MAX_NUMBER]   ;   /* 每个软件的ID和大小 */
   // unsigned long    ulSwHeaderLen               ;   /* 软件包头的大小：sizeof(unsigned char)+sizeof(TSwIdInfo)*ucSwNum */
}TSwPackage, *PTSwPackage;
typedef struct
{
    unsigned long  ulIsUsed;
    unsigned long  ulPackStoreType;
    unsigned char *pucPackBuf;
    unsigned char *pucUnpackBuf;
    
}T_PackDesc;

#pragma pack()
STATUS KexecRebootEntry(ULONG ulCause);
static unsigned int GetMtd2EndAddr(void);
ULONG ldCertainFile(const char *pcFileName, FUNCPTR *pEntry);
ULONG ldFileFromRam(UCHAR *pucVerbuf, ULONG ulFileSize);
STATUS KexecRebootCmd(ULONG ulCause, ULONG ulWtd);
STATUS ldFileFromFlash(void);
/* Started by AICoder, pid:s2571gc5287d1791468d096e80ecf6049214b9f7 */
ULONG SetDefaultCmdline();
ULONG BspMknod(const char * filepath, const char *oprator, const char *majornew, const char* minornew);
/* Ended by AICoder, pid:s2571gc5287d1791468d096e80ecf6049214b9f7 */
/* Started by AICoder, pid:c4383k4441a6a1b1460009b03047d00c46015f2d */
ULONG GetCmdline(VOID);
/* Ended by AICoder, pid:c4383k4441a6a1b1460009b03047d00c46015f2d */
#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif


#ifndef PROTOCOL_H
#define PROTOCOL_H

#include <stdint.h>

#define FRAME_START_END_FLAG 0x7E

//dest_addr or src_addr for A01
#define MCU 0x01
#define LT 0x02
#define CPU_4C 0x03
#define GLL 0x04
#define CPU_D4 0x05

//dest_addr or src_addr for B01/C01
#define BBU_MCU 0x01
#define BBU_4C 0x02
#define LT_2ND 0x03
#define RRU_MCU 0x04
#define RRU_4C 0x05

#define ALL 0xFF

//frame_type
#define NORMAL_LINK_DATA_FRAME  0x0
#define LINK_DETECTION_FRAME_SEND    0x1
#define LINK_DETECTION_FRAME_REPLIED    0x2
#define NO_SENSE    0x3
#define REQUEST_FRAME_REGISTER_PROCESS  0x4
#define REQUEST_FRAME_REGISTER_LOGICAL_ADDRESS  0x5

//checksum_type
#define CRC 0x0
#define NO_CRC 0x1
#define ACCUMULATION_VERIFICATION 0x2
#define NO_ACCUMULATION_VERIFICATION 0x3

//message_id used by A01
#define TELEMETRY_REQUEST_FRAME_FORMAT  0x0030
#define TELEMETRY_RESPONSE_FRAME_FORMAT  0x0031

//message_id used by 2ND
#define RU_QUICK_CHANGE_MESSAGE     0x0600

//cpu2_run_status
#define RUN_IN_BL2  0x20
#define RUN_IN_UBOOT    0x30
#define RUN_IN_KEBOOT  0x40
#define REPAIR_VERSION_FAILED  0x41

#pragma pack(1)
// 链路层报文头部结构体
typedef struct {
    uint8_t dest_addr;      // 链路层目的地址
    uint8_t src_addr;       // 链路层源地址
    uint8_t frame_type;     // 帧类型控制字
    uint8_t checksum_type;       // 校验和控制字
    uint16_t length;        // 链路层长度
} LinkLayerHeader;

// PID格式结构体
typedef struct {
    uint32_t process_id;        // 进程号
    uint32_t device_id;         // 设备ID
    uint16_t mp_number;         // MP编号
    uint16_t board_number;      // 单板号
    uint8_t processor_number;   // 单板上的处理器号
    uint8_t subsystem_number;   // 子系统号
    uint8_t routing_type;       // 路由类型
    uint8_t reserve;            // 保留字段
} PIDFormat;

// 应用消息体结构体,搭载试验载荷速变遥测轮询周期1秒，共50个字节
typedef struct {
    uint8_t unit_id;                    // 单板内单元ID
    uint8_t power_monitoring;           // 二级+三级电源PG监控
    uint8_t critical_device_info;       // 关键器件信息
    uint8_t mcu_run_status;             // 一级域MCU运行状态
    uint8_t cpu2_run_status;            // 二级域CPU运行状态
    uint8_t cpu3_run_status;            // 三级域CPU运行状态
    uint8_t mcu_test_status;            // 一级域MCU测试状态
    uint8_t cpu2_test_status;           // 二级域CPU测试状态
    uint8_t cpu3_test_status;           // 三级域CPU测试状态
    uint8_t reserve2[11];               // 保留字段2
    uint8_t custom_message_id;          // ZTE速变自定义消息号
    uint8_t custom_message_length;      // ZTE速变自定义消息长度
    uint8_t custom_message[28];         // ZTE速变自定义消息内容
} ApplicationMessage;

// 应用消息体结构体,搭载试验载荷速变遥测轮询周期1秒，共50个字节
typedef struct {
    /* Started by AICoder, pid:8c8f2y4c76mb33f140d70a5670cd09210df247d4 */
    uint8_t payload_type_id;
    uint8_t used[12];
    uint8_t reserved[7];
    uint8_t bbu_reserved[5];
    uint8_t used2;
    uint8_t reserved2[2];
    uint8_t used3[3];
    uint8_t rf_4c_self_report_status;
    uint8_t ru_reserved[18];
/* Ended by AICoder, pid:8c8f2y4c76mb33f140d70a5670cd09210df247d4 */
} ApplicationMessage2ND;

// 传输层报文结构体
typedef struct {
    PIDFormat src_process;    // 源进程PID
    PIDFormat dst_process;      // 目的进程PID
    uint16_t message_id;      // 消息号
    uint16_t message_length;    // 消息体长度
    uint32_t reserve1;          // 保留字段1
    uint32_t reserve2;          // 保留字段2
    ApplicationMessage app_message;    // 应用层消息体
} TransportLayerPacket;

// 传输层报文结构体2ND
typedef struct {
    uint16_t message_id;      // 消息号
    uint16_t message_length;    // 消息体长度
    ApplicationMessage2ND app_message;    // 应用层消息体
} TransportLayerPacket2ND;

// 链路层报Payload结构体
typedef struct {
    TransportLayerPacket transport_layer_packet;
    uint16_t checksum;
} LinkLayerPayload;

// 链路层报Payload结构体2ND
typedef struct {
    TransportLayerPacket2ND transport_layer_packet;
    uint16_t checksum;
} LinkLayerPayload2ND;

// 链路层报文结构体
typedef struct {
    uint8_t frame_start_flag;
    LinkLayerHeader link_layer_header;
    LinkLayerPayload link_layer_payload;
    uint8_t frame_end_flag;
} LinkLayerPacket;

// 链路层报文结构体2ND
typedef struct {
    uint8_t frame_start_flag;
    LinkLayerHeader link_layer_header;
    LinkLayerPayload2ND link_layer_payload;
    uint8_t frame_end_flag;
} LinkLayerPacket2ND;
#pragma pack()

int boot_report_1st(uint8_t status);
int boot_report_2nd(uint8_t status);
#endif
#include <stdio.h>
#include <crc.h>
#include <bsppub.h>
#include "protocol.h"
#include "tty_utils.h"

#define MESSAGE_UART "/dev/ttyS1"

static int message_init(LinkLayerPacket* packet, uint8_t status) 
{    
    //预填充全0处理
    memset_s(packet, sizeof(LinkLayerPacket), 0x0, sizeof(LinkLayerPacket));
    memset_s(&(packet->link_layer_payload.transport_layer_packet.app_message), sizeof(ApplicationMessage), 0xAA, sizeof(ApplicationMessage));

    packet->frame_start_flag = FRAME_START_END_FLAG;

    // 填充链路层报文头部字段
    packet->link_layer_header.dest_addr = MCU;
    packet->link_layer_header.src_addr = CPU_4C;
    packet->link_layer_header.frame_type = NORMAL_LINK_DATA_FRAME;
    packet->link_layer_header.checksum_type = CRC;
    packet->link_layer_header.length = htons(sizeof(LinkLayerHeader) + sizeof(LinkLayerPayload)); //长度字段表示链路层报文内容长度

    // 填充链路层报文有效载荷字段
    packet->link_layer_payload.transport_layer_packet.message_id = htons(TELEMETRY_RESPONSE_FRAME_FORMAT);
    packet->link_layer_payload.transport_layer_packet.message_length = htons(sizeof(ApplicationMessage));

    // 速变遥测应答帧有效字段填充
    packet->link_layer_payload.transport_layer_packet.app_message.unit_id = CPU_4C;
    packet->link_layer_payload.transport_layer_packet.app_message.cpu2_run_status = status;

    // 计算链路层报文校验和
    packet->link_layer_payload.checksum = htons(CalculateCRC16(CRC_MASK, (const unsigned char *)&(packet->link_layer_header), 
    sizeof(LinkLayerHeader) + sizeof(LinkLayerPayload) - sizeof(packet->link_layer_payload.checksum)));

    // 置帧尾标志
    packet->frame_end_flag = FRAME_START_END_FLAG;

    return 0;
}

static int message_2nd_init(LinkLayerPacket2ND* packet, uint8_t status) 
{    
    //预填充全0处理
    memset_s(packet, sizeof(LinkLayerPacket2ND), 0x0, sizeof(LinkLayerPacket2ND));
    memset_s(&(packet->link_layer_payload.transport_layer_packet.app_message), sizeof(ApplicationMessage2ND), 0xAA, sizeof(ApplicationMessage2ND));

    packet->frame_start_flag = FRAME_START_END_FLAG;

    // 填充链路层报文头部字段
    packet->link_layer_header.dest_addr = RRU_MCU;
    packet->link_layer_header.src_addr = RRU_4C;
    packet->link_layer_header.frame_type = NORMAL_LINK_DATA_FRAME;
    packet->link_layer_header.checksum_type = CRC;
    packet->link_layer_header.length = htons(sizeof(LinkLayerHeader) + sizeof(LinkLayerPayload2ND)); //长度字段表示链路层报文内容长度

    // 填充链路层报文有效载荷字段
    packet->link_layer_payload.transport_layer_packet.message_id = htons(RU_QUICK_CHANGE_MESSAGE);
    packet->link_layer_payload.transport_layer_packet.message_length = htons(sizeof(ApplicationMessage2ND));

    // 速变遥测应答帧有效字段填充
    packet->link_layer_payload.transport_layer_packet.app_message.rf_4c_self_report_status = status;

    // 计算链路层报文校验和
    packet->link_layer_payload.checksum = htons(CalculateCRC16(CRC_MASK, (const unsigned char *)&(packet->link_layer_header), 
    sizeof(LinkLayerHeader) + sizeof(LinkLayerPayload2ND) - sizeof(packet->link_layer_payload.checksum)));

    // 置帧尾标志
    packet->frame_end_flag = FRAME_START_END_FLAG;

    return 0;
}

static void messsage_print(const char* packet, int len)
{
    for(int i = 0; i < len; i++)
    {
        printf("0x%x ",*((char*)packet + i));
    }
}

static void messsage_send(int fd, const char* packet, int len)
{
    char split_character[3] = {0x7D,0x5E,0x5D};
    char *data = (char *)packet;

    write(fd, &data[0], 1);

    for(int i = 1; i < (len - 1); i++)
    {
        if(data[i] == FRAME_START_END_FLAG)
        {
            write(fd, &split_character[0], 1);
            write(fd, &split_character[1], 1);
        }
        else if(data[i] == split_character[0])
        {
            write(fd, &split_character[0], 1);
            write(fd, &split_character[2], 1);
        }
        else{
            write(fd, &data[i], 1);
        }
    }
    
    write(fd, &data[len - 1], 1);
    return;
}

int boot_report_1st(uint8_t status)
{
    LinkLayerPacket packet;

    message_init(&packet, status);

    int fd = set_tty_settings(MESSAGE_UART, B115200, 8, 1, 0);
    if (fd == -1) {
        fprintf(stderr, "Failed to set tty settings\n");
        return -1;
    }

    messsage_send(fd, (const char*)&packet,sizeof(LinkLayerPacket));
    close(fd);

    return 0;
}

int boot_report_2nd(uint8_t status)
{
    LinkLayerPacket2ND packet;

    message_2nd_init(&packet, status);

    int fd = set_tty_settings(MESSAGE_UART, B115200, 8, 1, 0);
    if (fd == -1) {
        fprintf(stderr, "Failed to set tty settings\n");
        return -1;
    }

    messsage_send(fd, (const char*)&packet,sizeof(LinkLayerPacket2ND));
    close(fd);

    return 0;
}
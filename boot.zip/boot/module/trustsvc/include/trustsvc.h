/*****************************************************************************
 * 版权所有(C) 2014, ZTE Corp. ZXSDR-RRU Platform BSP
 *----------------------------------------------------------------------------
 * 模 块 名 : BSP
 * 文件名称 : trustsvc.h
 * 文件标识 : {[N/A]}
 * 内容摘要 : 本文件主要提供安全服务相关的代码实现
 * 注意事项 : 无
 * 作     者 : 00283311
 * 创建日期 : 2021-06-08 
 * 当前版本 : Ver1.0
 *----------------------------------------------------------------------------
 * 变更记录 :
 *
 * $记录1
 * 变 更 单:
 * 责 任 人:
 * 修改日戳:
 * 变更说明:

 *----------------------------------------------------------------------------
 */
#ifndef _TRUSTSVC_H_
#define _TRUSTSVC_H_

#ifdef __cplusplus
extern "C" {
#endif

#include "bsppub.h"
#include "bspcomm.h"

/**************************************************************************
 *                        宏定义
 **************************************************************************/
#define EFUSE_SMC_CMD_BASE         0x82000000 /*smc statand:0x80000000 fase call+0x02000000 Sip service Calls+ function number:0x0~0xFFFF*/
#define _EFUSE_SMC_CMD(magic,num)  (EFUSE_SMC_CMD_BASE + num)
#define EFUSE_NV_VAL_MAX           (UINT32)32


/**************************************************************************
*                         全局变量定义                                   *
**************************************************************************/

/**************************************************************************
*                         数据类型                                       *
**************************************************************************/
typedef struct Tag_efuse_data {
    unsigned int dev_id; /* efuse_func_type */
    unsigned int rs;     /* Operation Return Status */
    unsigned int rv;     /* Operation Return Value*/
    unsigned int d0;     /*  */
    unsigned int d1;
    unsigned int d2;
    unsigned int d3;
    unsigned int dx[17];
}T_Efuse_Date;

enum smc_cmd_table
{
    /*SMC EFUSE FUNC*/
    SMC_EFUSE_HASH_WRITE      = _EFUSE_SMC_CMD(EFUSE_SMC_CMD_BASE, 1),
    SMC_EFUSE_HASH_CMP,
    SMC_EFUSE_SET_SEC_BIT,
    SMC_EFUSE_GET_SEC_BIT,
    SMC_EFUSE_SET_NV_BIT,
    SMC_EFUSE_GET_NV_BIT,
    SMC_EFUSE_BOOT_NV_VAL_WRITE,
    SMC_EFUSE_BOOT_NV_VAL_READ,
    SMC_EFUSE_USER_NV_VAL_WRITE,
    SMC_EFUSE_USER_NV_VAL_READ,
    SMC_EFUSE_SET_ICE_BIT,
    SMC_EFUSE_GET_ICE_BIT,
    SMC_EFUSE_GET_SEC_MODE,
    SMC_EFUSE_GET_NV_MODE,
};

/**************************************************************************
*                         函数声明
**************************************************************************/
UINT32 BspHashWrite(UINT32 *pHsah, UINT32 ulLen);
UINT32 BspHashCmp(UINT32 *pHsah, UINT32 ulLen);
UINT32 BspSetSecBit(VOID);
UINT32 BspGetSecBit(UINT32 *pRdval);
UINT32 BspSetNvBit(VOID);
UINT32 BspGetNvBit(UINT32 *pRdval);
UINT32 BspBootNvValWrite(UINT32 ulWrVal);
UINT32 BspBootNvValRead(UINT32 *pRdval);
UINT32 BspUserNvValWrite(UINT32 ulWrVal);
UINT32 BspUserNvValRead(UINT32 *pRdval);
UINT32 BspSetIceBit(VOID);
UINT32 BspGetIceBit(UINT32 *pRdval);
UINT32 BspGetSafeBootCheckSwitch(UINT32 *pRdval);
UINT32 BspGetNvModeSwitch(UINT32 *pRdVal);


#ifdef __cplusplus
}
#endif
#endif /* _TRUSTSVC_H_ */



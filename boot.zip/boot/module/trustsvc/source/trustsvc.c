/*****************************************************************************
* 版权所有(C) 2021, ZTE Corp. ZXSDR-RRU Platform BSP
*----------------------------------------------------------------------------
* 模 块 名 : BSP
* 文件名称 : trustsvc.c
* 文件标识 : {[N/A]}
* 内容摘要 : 本文件主要提供安全服务相关的代码实现
* 注意事项 : 无
* 作     者 : 00283311
* 创建日期 : 2021-06-08
* 当前版本 : Ver1.0
*----------------------------------------------------------------------------
* 变更记录 :
*
* $记录1
* 变 更 单:
* 责 任 人:
* 修改日戳:
* 变更说明:

*----------------------------------------------------------------------------
*/

#include <unistd.h>
#include <stdio.h>
#include <sys/types.h>
#include <linux/ioctl.h>
#include <sys/sysmacros.h>
#include <sys/stat.h>
#include <sys/ioctl.h>
#include <fcntl.h>
#include <string.h>
#include <stddef.h>
#include <sys/mman.h>
#include <stdlib.h>

//#include "exprn.h"
#include "trustsvc.h"

/**************************************************************************
 *                        常量                                            *
 **************************************************************************/

/**************************************************************************
 *                        宏                                              *
 **************************************************************************/

#define WRITE_NV_VAL_CHECK(val)                                 \
{                                                               \
    if ((val) > EFUSE_NV_VAL_MAX)                               \
    {                                                           \
        dbgErr("efuse roll-back val= 0x%x over range!\n", val); \
        return BSP_ERROR_INVALID_PARA;                          \
    }                                                           \
}

/**************************************************************************
 *                         全局变量定义                                   *
 **************************************************************************/

/**************************************************************************
 *                         局部函数声明                                   *
 **************************************************************************/

/**************************************************************************
 *                         局部函数实现                                   *
 **************************************************************************/

/**************************************************************************
* 函数名称: BspHashWrite
* 功能描述: 哈希值烧写
* 输入参数: pHsah: 哈希值
            ulLen: 哈希长度
* 输出参数: 无
* 返 回 值: BSP_OK 执行成功
*           其它   执行失败
* 其它说明:
* 修改日期       版本号           修改人    修改内容
* ------------------------------------------------------------------------
* 2021年06月25日        00283311      创建
**************************************************************************/
UINT32 BspHashWrite(UINT32 *pHsah, UINT32 ulLen)
{
    INT32 fd = 0;
    UINT32 ulRet = BSP_OK;
    T_Efuse_Date EfuseData;
    INPUT_POINTER_CHECK(pHsah);
    if (access("/dev/tsm", 0))
    {
        dbgErr("%s>>accesss tsm error\n", __FUNCTION__);
        return BSP_ERROR;
    }
    fd = open("/dev/tsm", O_RDWR | O_SYNC);
    if (fd < 0)
    {
        dbgErr("%s>>open /dev/tsm error\n", __FUNCTION__);
        return BSP_ERROR;
    }
    zte_memcpy_s(&EfuseData.dx, ulLen * 4, pHsah, ulLen * 4);
    ulRet = ioctl(fd, SMC_EFUSE_HASH_WRITE, &EfuseData);
    if (0 != ulRet)
    {
        dbgErr("%s>>ioctl SMC_EFUSE_HASH_WRITE err\n", __FUNCTION__);
        close(fd);
        return BSP_ERROR;
    }

    dbgInfo("%s>>hash write %s!\n", __FUNCTION__, (0 == EfuseData.rs) ? "succ" : "fail");
    close(fd);
    return EfuseData.rs;
}

/**************************************************************************
* 函数名称: BspHashCmp
* 功能描述: 哈希值比对
* 输入参数: pHsah: 哈希值
            ulLen: 哈希长度
* 输出参数: 无
* 返 回 值: BSP_OK 执行成功
*           其它   执行失败
* 其它说明:
* 修改日期       版本号           修改人    修改内容
* ------------------------------------------------------------------------
* 2021年06月25日        00283311      创建
**************************************************************************/
#define SHA256_BYTES (256 / 8)
UINT32 BspHashCmp(UINT32 *pHsah, UINT32 ulLen)
{
    INT32 fd = 0;
    UINT32 ulRet = BSP_OK;
    T_Efuse_Date EfuseData;
    INPUT_POINTER_CHECK(pHsah);
    if (ulLen != SHA256_BYTES / 4)
    {
        dbgErr("%s>>ulLen=%d input error\n", __FUNCTION__, ulLen);
        return BSP_ERROR;
    }

    if (access("/dev/tsm", 0))
    {
        dbgErr("%s>>accesss tsm error\n", __FUNCTION__);
        return BSP_ERROR;
    }
    fd = open("/dev/tsm", O_RDWR | O_SYNC);
    if (fd < 0)
    {
        dbgErr("%s>>open /dev/tsm error\n", __FUNCTION__);
        return BSP_ERROR;
    }

    zte_memcpy_s(&EfuseData.dx, ulLen * 4, pHsah, ulLen * 4);
    ulRet = ioctl(fd, SMC_EFUSE_HASH_CMP, &EfuseData);
    if (0 != ulRet)
    {
        dbgErr("%s>>ioctl SMC_EFUSE_HASH_CMP err\n", __FUNCTION__);
        close(fd);
        return BSP_ERROR;
    }
    if (0 != EfuseData.rs)
    {
        dbgErr("%s>>ioctl SMC_EFUSE_HASH_CMP smcret err\n", __FUNCTION__);
        close(fd);
        return BSP_ERROR;
    }

    dbgInfo("%s>>hash compare %s!\n", __FUNCTION__, (0 == EfuseData.rv) ? "same" : "differ");
    close(fd);
    return EfuseData.rv;
}

/**************************************************************************
* 函数名称: BspSetSecBit
* 功能描述: 置位安全模式使能位
* 输入参数: 无
* 输出参数: 无
* 返 回 值: BSP_OK 执行成功
*           其它   执行失败
* 其它说明:
* 修改日期       版本号           修改人    修改内容
* ------------------------------------------------------------------------
* 2021年06月25日        00283311      创建
**************************************************************************/
UINT32 BspSetSecBit(VOID)
{
    INT32 fd = 0;
    UINT32 ulRet = BSP_OK;
    T_Efuse_Date EfuseData;

    if (access("/dev/tsm", 0))
    {
        dbgErr("%s>>accesss tsm error\n", __FUNCTION__);
        return BSP_ERROR;
    }
    fd = open("/dev/tsm", O_RDWR | O_SYNC);
    if (fd < 0)
    {
        dbgInfo("%s>>open /dev/tsm error\n", __FUNCTION__);
        return BSP_ERROR;
    }

    ulRet = ioctl(fd, SMC_EFUSE_SET_SEC_BIT, &EfuseData);
    if (0 != ulRet)
    {
        dbgErr("%s>>ioctl SMC_EFUSE_SET_SEC_BIT err\n", __FUNCTION__);
        close(fd);
        return BSP_ERROR;
    }

    dbgInfo("%s>>set sec bit %s!\n", __FUNCTION__, (0 == EfuseData.rs) ? "succ" : "fail");
    close(fd);
    return EfuseData.rs;
}

/**************************************************************************
* 函数名称: BspGetSecBit
* 功能描述: 读取安全模式使能位
* 输入参数: 无
* 输出参数: pRdVal: 读取的安全模式使能位状态
* 返 回 值: BSP_OK 执行成功
*           其它   执行失败
* 其它说明:
* 修改日期       版本号           修改人    修改内容
* ------------------------------------------------------------------------
* 2021年06月25日        00283311      创建
**************************************************************************/
UINT32 BspGetSecBit(UINT32 *pRdVal)
{
    INT32 fd = 0;
    UINT32 ulRet = BSP_OK;
    T_Efuse_Date EfuseData;
    INPUT_POINTER_CHECK(pRdVal);

    if (access("/dev/tsm", 0))
    {
        dbgErr("%s>accesss tsm error\n", __FUNCTION__);
        return BSP_ERROR;
    }
    fd = open("/dev/tsm", O_RDWR | O_SYNC);
    if (fd < 0)
    {
        dbgErr("%s>>open /dev/tsm error\n", __FUNCTION__);
        return BSP_ERROR;
    }

    ulRet = ioctl(fd, SMC_EFUSE_GET_SEC_BIT, &EfuseData);
    if (0 != ulRet)
    {
        dbgErr("%s>>ioctl SMC_EFUSE_GET_SEC_BIT err\n", __FUNCTION__);
        close(fd);
        return BSP_ERROR;
    }

    *pRdVal = EfuseData.rv;
    dbgInfo("%s>>read set bit %s, Rdval=0x%x\n", __FUNCTION__, (0 == EfuseData.rs) ? "succ" : "fail", *pRdVal);
    close(fd);
    return EfuseData.rs;
}

/**************************************************************************
* 函数名称: BspSetNvBit
* 功能描述: 置位防回滚使能位
* 输入参数: 无
* 输出参数: 无
* 返 回 值: BSP_OK 执行成功
*           其它   执行失败
* 其它说明:
* 修改日期       版本号           修改人    修改内容
* ------------------------------------------------------------------------
* 2021年06月25日        00283311      创建
**************************************************************************/
UINT32 BspSetNvBit(VOID)
{
    INT32 fd = 0;
    UINT32 ulRet = BSP_OK;
    T_Efuse_Date EfuseData;

    if (access("/dev/tsm", 0))
    {
        dbgErr("%s>>accesss tsm error\n", __FUNCTION__);
        return BSP_ERROR;
    }
    fd = open("/dev/tsm", O_RDWR | O_SYNC);
    if (fd < 0)
    {
        dbgErr("%s>>open /dev/tsm error\n", __FUNCTION__);
        return BSP_ERROR;
    }

    ulRet = ioctl(fd, SMC_EFUSE_SET_NV_BIT, &EfuseData);
    if (0 != ulRet)
    {
        dbgErr("%s>>ioctl SMC_EFUSE_SET_NV_BIT err\n", __FUNCTION__);
        close(fd);
        return BSP_ERROR;
    }

    dbgInfo("%s>>set roll-back bit %s!\n", __FUNCTION__, (0 == EfuseData.rs) ? "succ" : "fail");
    close(fd);
    return EfuseData.rs;
}

/**************************************************************************
* 函数名称: BspGetNvBit
* 功能描述: 读取防回滚使能位
* 输入参数: 无
* 输出参数: pRdVal: 读取防回滚使能位状态
* 返 回 值: BSP_OK 执行成功
*           其它   执行失败
* 其它说明:
* 修改日期       版本号           修改人    修改内容
* ------------------------------------------------------------------------
* 2021年06月25日        00283311      创建
**************************************************************************/
UINT32 BspGetNvBit(UINT32 *pRdVal)
{
    INT32 fd = 0;
    UINT32 ulRet = BSP_OK;
    T_Efuse_Date EfuseData;
    INPUT_POINTER_CHECK(pRdVal);

    if (access("/dev/tsm", 0))
    {
        dbgErr("%s>>accesss tsm error\n", __FUNCTION__);
        return BSP_ERROR;
    }
    fd = open("/dev/tsm", O_RDWR | O_SYNC);
    if (fd < 0)
    {
        dbgErr("%s>>open /dev/tsm error\n", __FUNCTION__);
        return BSP_ERROR;
    }

    ulRet = ioctl(fd, SMC_EFUSE_GET_NV_BIT, &EfuseData);
    if (0 != ulRet)
    {
        dbgErr("%s>>ioctl SMC_EFUSE_GET_NV_BIT err\n", __FUNCTION__);
        close(fd);
        return BSP_ERROR;
    }

    *pRdVal = EfuseData.rv;
    dbgInfo("%s>>read roll-back bit %s, Rdval=0x%x\n", __FUNCTION__, (0 == EfuseData.rs) ? "succ" : "fail", *pRdVal);
    close(fd);
    return EfuseData.rs;
}

/**************************************************************************
* 函数名称: BspBootNvValWrite
* 功能描述: 烧写固件版本防回滚计数值
* 输入参数: ulWrVal:固件版本防回滚计数值
* 输出参数: 无
* 返 回 值: BSP_OK 执行成功
*           其它   执行失败
* 其它说明:
* 修改日期       版本号           修改人    修改内容
* ------------------------------------------------------------------------
* 2021年06月25日        00283311      创建
**************************************************************************/
UINT32 BspBootNvValWrite(UINT32 ulWrVal)
{
    INT32 fd = 0;
    UINT32 ulRet = BSP_OK;
    T_Efuse_Date EfuseData;
    WRITE_NV_VAL_CHECK(ulWrVal);

    if (access("/dev/tsm", 0))
    {
        dbgErr("%s>>accesss tsm error\n", __FUNCTION__);
        return BSP_ERROR;
    }
    fd = open("/dev/tsm", O_RDWR | O_SYNC);
    if (fd < 0)
    {
        dbgErr("%s>>open /dev/tsm error\n", __FUNCTION__);
        return BSP_ERROR;
    }

    EfuseData.d0 = ulWrVal;
    ulRet = ioctl(fd, SMC_EFUSE_BOOT_NV_VAL_WRITE, &EfuseData);
    if (0 != ulRet)
    {
        dbgErr("%s>>ioctl SMC_EFUSE_GET_NV_BIT err\n", __FUNCTION__);
        close(fd);
        return BSP_ERROR;
    }

    dbgInfo("%s>>Write boot-roll back bit %s, WrVal=0x%x\n", __FUNCTION__, (0 == EfuseData.rs) ? "succ" : "fail", ulWrVal);
    close(fd);
    return EfuseData.rs;
}

/**************************************************************************
* 函数名称: BspBootNvValRead
* 功能描述: 读取固件版本防回滚计数值
* 输入参数: 无
* 输出参数: pRdVal: 读取的防回滚计数值
* 返 回 值: BSP_OK 执行成功
*           其它   执行失败
* 其它说明:
* 修改日期       版本号           修改人    修改内容
* ------------------------------------------------------------------------
* 2021年06月25日        00283311      创建
**************************************************************************/
UINT32 BspBootNvValRead(UINT32 *pRdVal)
{
    INT32 fd = 0;
    UINT32 ulRet = BSP_OK;
    T_Efuse_Date EfuseData;
    INPUT_POINTER_CHECK(pRdVal);

    if (access("/dev/tsm", 0))
    {
        dbgErr("%s>>accesss tsm error\n", __FUNCTION__);
        return BSP_ERROR;
    }
    fd = open("/dev/tsm", O_RDWR | O_SYNC);
    if (fd < 0)
    {
        dbgErr("%s>>open /dev/tsm error\n", __FUNCTION__);
        return BSP_ERROR;
    }

    ulRet = ioctl(fd, SMC_EFUSE_BOOT_NV_VAL_READ, &EfuseData);
    if (0 != ulRet)
    {
        dbgErr("%s>>ioctl SMC_EFUSE_BOOT_NV_VAL_READ err\n", __FUNCTION__);
        close(fd);
        return BSP_ERROR;
    }

    *pRdVal = EfuseData.rv;
    dbgInfo("%s>>read boot roll-back bit %s, Rdval=0x%x\n", __FUNCTION__, (0 == EfuseData.rs) ? "succ" : "fail", *pRdVal);
    close(fd);
    return EfuseData.rs;
}

/**************************************************************************
* 函数名称: BspUserNvValWrite
* 功能描述: 烧写应用版本防回滚计数值
* 输入参数: ulWrVal: 应用版本防回滚计数值
* 输出参数: 无
* 返 回 值: BSP_OK 执行成功
*           其它   执行失败
* 其它说明:
* 修改日期       版本号           修改人    修改内容
* ------------------------------------------------------------------------
* 2021年06月25日        00283311      创建
**************************************************************************/
UINT32 BspUserNvValWrite(UINT32 ulWrVal)
{
    INT32 fd = 0;
    UINT32 ulRet = BSP_OK;
    T_Efuse_Date EfuseData;
    WRITE_NV_VAL_CHECK(ulWrVal);

    if (access("/dev/tsm", 0))
    {
        dbgErr("%s>>accesss tsm error\n", __FUNCTION__);
        return BSP_ERROR;
    }
    fd = open("/dev/tsm", O_RDWR | O_SYNC);
    if (fd < 0)
    {
        dbgErr("%s>>open /dev/tsm error\n", __FUNCTION__);
        return BSP_ERROR;
    }

    EfuseData.d0 = ulWrVal;
    ulRet = ioctl(fd, SMC_EFUSE_USER_NV_VAL_WRITE, &EfuseData);
    if (0 != ulRet)
    {
        dbgErr("%s>>ioctl SMC_EFUSE_USER_NV_VAL_WRITE err\n", __FUNCTION__);
        close(fd);
        return BSP_ERROR;
    }

    dbgInfo("%s>>write user roll-back bit %s, WrVal=0x%x\n", __FUNCTION__, (0 == EfuseData.rs) ? "succ" : "fail", ulWrVal);
    close(fd);
    return EfuseData.rs;
}

/**************************************************************************
* 函数名称: BspUserNvValRead
* 功能描述: 读取应用版本防回滚计数值
* 输入参数: 无
* 输出参数: pRdVal: 读取的应用版本防回滚计数值
* 返 回 值: BSP_OK 执行成功
*           其它   执行失败
* 其它说明:
* 修改日期       版本号           修改人    修改内容
* ------------------------------------------------------------------------
* 2021年06月25日        00283311      创建
**************************************************************************/
UINT32 BspUserNvValRead(UINT32 *pRdVal)
{
    INT32 fd = 0;
    UINT32 ulRet = BSP_OK;
    T_Efuse_Date EfuseData;
    INPUT_POINTER_CHECK(pRdVal);

    if (access("/dev/tsm", 0))
    {
        dbgErr("%s>>accesss tsm error\n", __FUNCTION__);
        return BSP_ERROR;
    }
    fd = open("/dev/tsm", O_RDWR | O_SYNC);
    if (fd < 0)
    {
        dbgErr("%s>>open /dev/tsm error\n", __FUNCTION__);
        return BSP_ERROR;
    }

    ulRet = ioctl(fd, SMC_EFUSE_USER_NV_VAL_READ, &EfuseData);
    if (0 != ulRet)
    {
        dbgErr("%s>>ioctl SMC_EFUSE_USER_NV_VAL_READ err\n", __FUNCTION__);
        close(fd);
        return BSP_ERROR;
    }

    *pRdVal = EfuseData.rv;
    dbgInfo("%s>>read user roll-back bit %s, Rdval=0x%x\n", __FUNCTION__, (0 == EfuseData.rs) ? "succ" : "fail", *pRdVal);
    close(fd);
    return EfuseData.rs;
}

/**************************************************************************
* 函数名称: BspSetIceBit
* 功能描述: 置位ICE使能位
* 输入参数: 无
* 输出参数: 无
* 返 回 值: BSP_OK 执行成功
*           其它   执行失败
* 其它说明:
* 修改日期       版本号           修改人    修改内容
* ------------------------------------------------------------------------
* 2021年06月25日        00283311      创建
**************************************************************************/
UINT32 BspSetIceBit(VOID)
{
    INT32 fd = 0;
    UINT32 ulRet = BSP_OK;
    T_Efuse_Date EfuseData;

    if (access("/dev/tsm", 0))
    {
        dbgErr("%s>>accesss tsm error\n", __FUNCTION__);
        return BSP_ERROR;
    }
    fd = open("/dev/tsm", O_RDWR | O_SYNC);
    if (fd < 0)
    {
        dbgErr("%s>>open /dev/tsm error\n", __FUNCTION__);
        return BSP_ERROR;
    }

    ulRet = ioctl(fd, SMC_EFUSE_SET_ICE_BIT, &EfuseData);
    if (0 != ulRet)
    {
        dbgErr("%s>>ioctl SMC_EFUSE_SET_ICE_BIT err\n", __FUNCTION__);
        close(fd);
        return BSP_ERROR;
    }

    dbgInfo("%s>>set user ice bit %s!\n", __FUNCTION__, (0 == EfuseData.rs) ? "succ" : "fail");
    close(fd);
    return EfuseData.rs;
}

/**************************************************************************
* 函数名称: BspGetIceBit
* 功能描述: 获取ICE使能位状态
* 输入参数: 无
* 输出参数: pRdVal: 读取的ICE使能位状态
* 返 回 值: BSP_OK 执行成功
*           其它   执行失败
* 其它说明:
* 修改日期       版本号           修改人    修改内容
* ------------------------------------------------------------------------
* 2021年06月25日        00283311      创建
**************************************************************************/
UINT32 BspGetIceBit(UINT32 *pRdVal)
{
    INT32 fd = 0;
    UINT32 ulRet = BSP_OK;
    T_Efuse_Date EfuseData;
    INPUT_POINTER_CHECK(pRdVal);

    if (access("/dev/tsm", 0))
    {
        dbgErr("%s>>accesss tsm error\n", __FUNCTION__);
        return BSP_ERROR;
    }
    fd = open("/dev/tsm", O_RDWR | O_SYNC);
    if (fd < 0)
    {
        dbgErr("%s>>open /dev/tsm error\n", __FUNCTION__);
        return BSP_ERROR;
    }

    ulRet = ioctl(fd, SMC_EFUSE_GET_ICE_BIT, &EfuseData);
    if (0 != ulRet)
    {
        dbgErr("%s>>ioctl SMC_EFUSE_GET_ICE_BIT err\n", __FUNCTION__);
        close(fd);
        return BSP_ERROR;
    }

    *pRdVal = EfuseData.rv;
    dbgInfo("%s>>read ice bit %s, Rdval=0x%x\n", __FUNCTION__, (0 == EfuseData.rs) ? "succ" : "fail", *pRdVal);
    close(fd);
    return EfuseData.rs;
}

/**************************************************************************
* 函数名称: BspGetSafeBootCheckSwitch
* 功能描述: 获取安全Boot开关状态
* 输入参数: 无
* 输出参数: pRdVal: 0-安全关闭;1-安全打开
* 返 回 值: BSP_OK 执行成功
*           其它   执行失败
* 其它说明:
* 修改日期       版本号           修改人    修改内容
* ------------------------------------------------------------------------
* 2021年06月25日        00283311      创建
**************************************************************************/
UINT32 BspGetSafeBootCheckSwitch(UINT32 *pRdVal)
{

    INT32 fd = 0;
    UINT32 ulRet = BSP_OK;
    T_Efuse_Date EfuseData;
    INPUT_POINTER_CHECK(pRdVal);

    if (access("/dev/tsm", 0))
    {
        dbgErr("%s>>accesss tsm error\n", __FUNCTION__);
        return BSP_ERROR;
    }
    fd = open("/dev/tsm", O_RDWR | O_SYNC);
    if (fd < 0)
    {
        dbgErr("%s>>open /dev/tsm error\n", __FUNCTION__);
        return BSP_ERROR;
    }

    ulRet = ioctl(fd, SMC_EFUSE_GET_SEC_MODE, &EfuseData);
    if (0 != ulRet)
    {
        dbgErr("%s>>ioctl SMC_EFUSE_GET_SEC_MODE err\n", __FUNCTION__);
        close(fd);
        return BSP_ERROR;
    }
    #ifdef FOR_TEST_SECURE
    EfuseData.rv = 1;
    EfuseData.rs = 0;
    #endif

    *pRdVal = EfuseData.rv;
    dbgInfo("%s>>read safe boot mode switch %s, Rdval=0x%x(0-close, 1-open)\n", __FUNCTION__, (0 == EfuseData.rs) ? "succ" : "fail", *pRdVal);
    close(fd);
    return EfuseData.rs;
}

/**************************************************************************
* 函数名称: BspGetNvModeSwitch
* 功能描述: 获取防回滚值开关状态
* 输入参数: 无
* 输出参数: pRdVal: 0-防回滚开关关闭;1-防回滚开关打开
* 返 回 值: BSP_OK 执行成功
*           其它   执行失败
* 其它说明:
* 修改日期       版本号           修改人    修改内容
* ------------------------------------------------------------------------
* 2021年07月06日        00283311      创建
**************************************************************************/
UINT32 BspGetNvModeSwitch(UINT32 *pRdVal)
{
    INT32 fd = 0;
    UINT32 ulRet = BSP_OK;
    T_Efuse_Date EfuseData;
    INPUT_POINTER_CHECK(pRdVal);

    if (access("/dev/tsm", 0))
    {
        dbgErr("%s>>accesss tsm error\n", __FUNCTION__);
        return BSP_ERROR;
    }
    fd = open("/dev/tsm", O_RDWR | O_SYNC);
    if (fd < 0)
    {
        dbgErr("%s>>open /dev/tsm error\n", __FUNCTION__);
        return BSP_ERROR;
    }

    ulRet = ioctl(fd, SMC_EFUSE_GET_NV_MODE, &EfuseData);
    if (0 != ulRet)
    {
        dbgErr("%s>>ioctl SMC_EFUSE_GET_NV_MODE err\n", __FUNCTION__);
        close(fd);
        return BSP_ERROR;
    }

    *pRdVal = EfuseData.rv;
    dbgInfo("%s>>read Nv mode switch %s, Rdval=0x%x(0-close, 1-open)\n", __FUNCTION__, (0 == EfuseData.rs) ? "succ" : "fail", *pRdVal);
    close(fd);
    return EfuseData.rs;
}

#include "ubifs.h"
#include "exprn.h"
#include "zte_slibc.h"
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/sysmacros.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <string.h>
#include <dirent.h>
#include <sys/mount.h>
#include <sys/statvfs.h>
#include <bsppub.h>
#include <bspcomm.h>
#include <sys/ioctl.h>
#include <mtd/mtd-abi.h>

extern int taskDelay(int ticks);
extern ULONG BootGetFsRecoverFlag(VOID);

T_FileSystemInfo s_at_FileSystemInfo[] = {
	//约定pcLabel pcMntDir ucUbiNo 存在对应关系，即FilesystemX /mnt/filesystemX ubiX
    {"Filesystem", "/mnt/filesystem",  "/ata", "/ata/rru", "/ata/rru/fpga", "/ata/rru/dsp", 0xFF, 0x0, {0xFF, 0xFF}},
#if defined(CONFIG_MULTI_FILESYSTEM)
    {"Filesystem1", "/mnt/filesystem1", "/ata1", "/ata1/rru", NULL, NULL, 0xFF, 0x1, {0xFF, 0xFF}},
    {"Filesystem2", "/mnt/filesystem2", "/ata2", NULL, NULL, NULL, 0xFF, 0x2, {0xFF, 0xFF}},
#endif
};

int max_filesystem_num = sizeof(s_at_FileSystemInfo) / sizeof(T_FileSystemInfo);

char * const open_dirlist[1] = {"/"};
rsize_t open_dirlist_size = 1;

/* Started by AICoder, pid:4c7f62bfaf834d4c8176bb3aac7b6a90 */
/* Started by VerifyCI-CodeReview, pid:4c7f62bfaf834d4c8176bb3aac7b6a90 */
#include <unistd.h>
#include <sys/wait.h>
#include <stdio.h>
#include <stdlib.h>

int mySystem(const char* command) 
{
    pid_t pid = fork();
    if (pid == -1) {
        perror("fork failed");
        return -1;
    } else if (pid == 0) {
        execl("/bin/sh", "sh", "-c", command, (char *)NULL);
        perror("exec failed");
        exit(EXIT_FAILURE);
    } else {
        int status;
        if (waitpid(pid, &status, 0) == -1) {
            perror("waitpid failed");
            return -1;
        }
        if (WIFEXITED(status)) {
            int exitStatus = WEXITSTATUS(status);
            if (exitStatus == 0) {
                return 0;
            } else {
                zte_printf_s("Command %s failed with exit status: %d\n", command, exitStatus);
                return -1;
            }
        } else if (WIFSIGNALED(status)) {
            int signalNumber = WTERMSIG(status);
            zte_printf_s("Command terminated by signal: %d\n", signalNumber);
            return -1;
        } else {
            zte_printf_s("Unknown error occurred\n");
            return -1;
        }
    }
}
/* Ended by VerifyCI-CodeReview, pid:4c7f62bfaf834d4c8176bb3aac7b6a90 */
/* Ended by AICoder, pid:4c7f62bfaf834d4c8176bb3aac7b6a90 */


/**
 * read_data - read data from a file.
 * @file: the file to read from
 * @buf: the buffer to read to
 * @buf_len: buffer length
 *
 * This function returns number of read bytes in case of success and %-1 in
 * case of failure. Note, if the file contains more then @buf_len bytes of
 * date, this function fails with %EINVAL error code.
 */
static int read_data(const char *file, void *buf, int buf_len)
{
	int fd, rd, tmp1;
	char tmp;

	fd = open(file, O_RDONLY);
	if (fd == -1)
		return -1;

	rd = zte_read_s(fd, buf, buf_len, buf_len);
	if (rd == -1) {
		zte_printf_s("cannot read \"%s\"", file);
		goto out_error;
	}

	if (rd == buf_len) {
		zte_printf_s("contents of \"%s\" is too long", file);
		errno = EINVAL;
		goto out_error;
	}

	((char *)buf)[rd] = '\0';

	/* Make sure all data is read */
	tmp1 = zte_read_s(fd, &tmp, 1, 1);
	if (tmp1 < 0) {
		zte_printf_s("cannot read \"%s\"", file);
		goto out_error;
	}
	if (tmp1 > 0) {
		zte_printf_s("file \"%s\" contains too much data (> %d bytes)",
		       file, buf_len);
		errno = EINVAL;
		goto out_error;
	}

	if (close(fd))
		return zte_printf_s("close failed on \"%s\"", file);

	return rd;

out_error:
	close(fd);
	return -1;
}

/**
 * read_major - read major and minor numbers from a file.
 * @file: name of the file to read from
 * @major: major number is returned here
 * @minor: minor number is returned here
 *
 * This function returns % in case of succes, and %-1 in case of failure.
 */
static int read_major(const char *file, int *major, int *minor)
{
	int ret;
	char buf[BUFLEN];

	ret = read_data(file, buf, BUFLEN);
	if (ret < 0)
		return ret;

	ret = zte_sscanf_s(buf, "%d:%d\n", NULL, major, minor);
	if (ret != 2) {
		errno = EINVAL;
		return zte_printf_s("\"%s\" does not have major:minor format", file);
	}

	if (*major < 0 || *minor < 0) {
		errno = EINVAL;
		return zte_printf_s("bad major:minor %d:%d in \"%s\"",
			      *major, *minor, file);
	}

	return 0;
}

static int ubi_ctrl_get_major(int *major, int *minor)
{
   return read_major(SYSFS_UBI_CTRL_DEV, major, minor);
}

static int ubi_dev_get_major(int dev_num, int *major, int *minor)
{
    char file[zte_strnlen_s(SYSFS_UBI_DEV, MAX_PATH_LEN) + 50];
    int ret = 0;

    ret = zte_snprintf_s(file, sizeof(file), SYSFS_UBI_DEV, dev_num);
    SNPRINTF_S_CHECK(ret, sizeof(file));

    return read_major(file, major, minor);
}

/* Started by AICoder, pid:df7fc88da4cd409bab97802365db46a2 */
/* Started by VerifyCI-CodeReview, pid:df7fc88da4cd409bab97802365db46a2 */
static int ubi_attach(unsigned char ucMtdNo, unsigned char ucUbiNo) 
{
    // Attach mtd to ubi
    char ubiAttachCmd[BUFLEN];
    int ret;

    ret = zte_snprintf_s(ubiAttachCmd, BUFLEN, "ubiattach %s -m %d -d %d", UBI_CTRL_DEV, ucMtdNo, ucUbiNo);
    if (ret < 0 || ret >= BUFLEN) {
        perror("Failed to construct ubiattach command");
        return -1;
    }

    ret = mySystem(ubiAttachCmd);
    if (ret < 0) {
        zte_printf_s("Failed to ubiattach mtd");
        return -1;
    }

    return 0;
}
/* Ended by VerifyCI-CodeReview, pid:df7fc88da4cd409bab97802365db46a2 */
/* Ended by AICoder, pid:df7fc88da4cd409bab97802365db46a2 */

static int ubi_mkvol(unsigned char ucUbiNo) {
    // Create ubi volume
    char ubiMkvolCmd[BUFLEN];
    int ret;

    ret = zte_snprintf_s(ubiMkvolCmd, sizeof(ubiMkvolCmd), "ubimkvol /dev/ubi%d -m -N ubifs%d", ucUbiNo, ucUbiNo);
    SNPRINTF_S_CHECK(ret, sizeof(ubiMkvolCmd));
    
    ret = mySystem(ubiMkvolCmd);
    if (ret < 0) {
        zte_printf_s("Failed to create ubi volume");
        return -1;
    }

    return 0;
}

/* Started by AICoder, pid:748839f76b445981442308914047663f48b978e3 */
static int get_mtd_from_name(const char* mtd_name) 
{
    DIR* dir = NULL;
    struct dirent* entry;
    char path[MAX_PATH_LEN];
    int index = -1;
    int ret = 0;
    char* const dirlist[1] = {"/sys/class/mtd"};
    rsize_t dirlist_size = 1;

    ret = zte_opendir_s(&dir, "/sys/class/mtd", dirlist, dirlist_size);
    if (ret) {
        perror("Failed to open directory");
        return -1;
    }

    while ((entry = readdir(dir)) != NULL) {
        if (strncmp(entry->d_name, "mtd", 3) == 0) {
            ret = zte_snprintf_s(path, sizeof(path), "/sys/class/mtd/%s/name", entry->d_name);
            SNPRINTF_S_CHECK(ret, sizeof(path));
            FILE* file = NULL;
            ret = zte_fopen_s(&file, path, "r", open_dirlist , open_dirlist_size);

            if (ret < 0 && file == NULL) {
                continue;
            }

            char name[MAX_PATH_LEN];
            if (zte_fgets_s(name, sizeof(name), sizeof(name), file) == 0) {
                name[strcspn(name, "\n")] = '\0'; // Remove newline character
                if (strcmp(name, mtd_name) == 0) {
                    index = BspAtoi(entry->d_name + 3, 0);
                    ret = zte_fclose_s(file);
                    FCLOSE_CHECK(ret);
                    break;
                }
            }
            /* Started by AICoder, pid:t8e51e841fkcbea14b6709ff2040e12ccf072f13 */
            ret = zte_fclose_s(file);
            /* Ended by AICoder, pid:t8e51e841fkcbea14b6709ff2040e12ccf072f13 */
            FCLOSE_CHECK(ret);
        }
    }

    ret = zte_closedir_s(dir);
    DIRCLOSE_CHECK(ret);

    return index;
}
/* Ended by AICoder, pid:748839f76b445981442308914047663f48b978e3 */

/* Started by AICoder, pid:58dbc60e0b854a1c89ee4cd5785cb144 */
/* Started by VerifyCI-CodeReview, pid:58dbc60e0b854a1c89ee4cd5785cb144 */
static int filesystem_info_init(unsigned int dwIndex) 
{
    T_FileSystemInfo *fsInfo = &s_at_FileSystemInfo[dwIndex];
    int mtdIndex = 0;

    if (fsInfo->pcLabel == NULL) {
        zte_printf_s("文件系统标签为空\n");
        return -1;
    }

    mtdIndex = get_mtd_from_name(fsInfo->pcLabel);
    if(-1 == mtdIndex)
    {
        zte_printf_s("获取MTD设备号失败\n");
        return mtdIndex;
    }
    else{
        fsInfo->ucMtdNo = mtdIndex;
    }
    
    return 0;
}
/* Ended by VerifyCI-CodeReview, pid:58dbc60e0b854a1c89ee4cd5785cb144 */
/* Ended by AICoder, pid:58dbc60e0b854a1c89ee4cd5785cb144 */

/* Started by AICoder, pid:a636d6608c8043398745480425e9cd0a */
/* Started by VerifyCI-CodeReview, pid:a636d6608c8043398745480425e9cd0a */
static int create_directory(const char* path) 
{
    char* path_copy = strdup(path);
    int fprtRet = 0;
    int ret = 0;
    if (path_copy == NULL) {
        fprtRet = fprintf(stderr, "Failed to allocate memory for path_copy\n");
        FPRINTF_CHECK(fprtRet);
        return -1;
    }

    rsize_t strmax = zte_strnlen_s(path_copy, MAX_PATH_LEN);
    char * save = NULL;
    char* token = zte_strtok_s(path_copy, &strmax, "/", &save);
    char* current_path = NULL;
    char* new_path = NULL;
    
    while (token != NULL) {
        if (current_path == NULL) {
            int path_len = zte_strnlen_s(token, MAX_PATH_LEN) + 2;
            current_path = (char*)malloc(path_len);
            if (current_path == NULL) {
                fprtRet = fprintf(stderr, "Failed to allocate memory for current_path\n");
                FPRINTF_CHECK(fprtRet);
                free(path_copy);
                return -1;
            }
            ret = zte_snprintf_s(current_path, path_len, "/%s", token);
            if ( ret < 0 || ret > path_len) {
                fprtRet = fprintf(stderr, "Failed to format current_path\n");
                FPRINTF_CHECK(fprtRet);
                free(current_path);
                free(path_copy);
                return -1;
            }
        } else {
            int new_path_len = zte_strnlen_s(current_path, MAX_PATH_LEN) + zte_strnlen_s(token, MAX_PATH_LEN) + 2;
            new_path = (char*)malloc(new_path_len);
            if (new_path == NULL) {
                fprtRet = fprintf(stderr, "Failed to allocate memory for new_path\n");
                FPRINTF_CHECK(fprtRet);
                free(current_path);
                free(path_copy);
                return -1;
            }
            ret = zte_snprintf_s(new_path, new_path_len, "%s/%s", current_path, token);
            if ( ret < 0 || ret > new_path_len) {
                fprtRet = fprintf(stderr, "Failed to format new_path\n");
                FPRINTF_CHECK(fprtRet);
                free(new_path);
                free(current_path);
                free(path_copy);
                return -1;
            }
            free(current_path);
            current_path = new_path;
        }

        DIR* dir = NULL;
        char * const dirlist[1] = {current_path};
        rsize_t dirlist_size = 1;
        ret = zte_opendir_s(&dir, current_path, dirlist, dirlist_size);
        if(ret < 0 && NULL == dir)
        {
            if(mkdir(current_path, 0755) == -1) 
            {
                fprtRet = fprintf(stderr, "Failed to create directory: %s\n", current_path);
                FPRINTF_CHECK(fprtRet);
                free(current_path);
                free(path_copy);
                return -1;
            }
        }
        else 
        {
            ret = zte_closedir_s(dir);
            DIRCLOSE_CHECK(ret);
        }

        token = zte_strtok_s(NULL, &strmax, "/", &save);
    }
    
    free(current_path);
    free(path_copy);
    return 0;
}
/* Ended by VerifyCI-CodeReview, pid:a636d6608c8043398745480425e9cd0a */
/* Ended by AICoder, pid:a636d6608c8043398745480425e9cd0a */

/* Started by AICoder, pid:f6c4e52419b9a0214a690b8fe17a90563b4487ea */
static int ubifs_mknod(const char *path, mode_t mode, dev_t dev)
{
    int ret = 0;
    FILE *fp = NULL;
    ret = zte_fopen_s(&fp, path, "r", open_dirlist , open_dirlist_size);

    if (ret < 0 && NULL == fp) 
    {
        ret = mknod(path, mode, dev);
        if (ret != 0) {
            zte_printf_s("Failed to create device node %s\n", path);
            return -1;
        }
    }
    else 
    {
        /* Started by AICoder, pid:cda75g75c157a6414c870adde05ff71cf0567cb3 */
        ret = zte_fclose_s(fp);
        /* Ended by AICoder, pid:cda75g75c157a6414c870adde05ff71cf0567cb3 */
        FCLOSE_CHECK(ret);
    }

    return 0;
}

static int do_mount(const char *source, const char *target, const char *filesystemtype, unsigned long mountflags, const void *data)
{
    int ret = 0;
    FILE *fp = NULL;
    
    ret = zte_fopen_s(&fp, target, "r", open_dirlist, open_dirlist_size);

    if (ret < 0 && NULL == fp) 
    {
        ret = mkdir(target, 0755);
        if (ret != 0) {
            zte_printf_s("Failed to create directory %s\n", target);
            return -1;
        }
    }
    else
    {
        /* Started by AICoder, pid:05ab8vedd6q3759140560be9f0edf20b3105a703 */
        ret = zte_fclose_s(fp);
        /* Ended by AICoder, pid:05ab8vedd6q3759140560be9f0edf20b3105a703 */
        FCLOSE_CHECK(ret);
    }

    ret = mount(source, target, filesystemtype, mountflags, data);
    if (ret != 0) 
    {
        zte_printf_s("Failed to mount %s to %s\n", source, target);
        return -1;
    }

    return 0;
}

static int ubifs_mount(int ubiNo,const char* target)
{
    char source[64];
    int ret = 0;

    ret = zte_snprintf_s(source,sizeof(source), "ubi%d_0",ubiNo);
    SNPRINTF_S_CHECK(ret, sizeof(source));

    return do_mount(source, target, "ubifs", MS_SYNCHRONOUS, NULL);
}

/* Started by AICoder, pid:kadb9z3c50kbbfb14a0509d020a1e0291a3437ff */
static int do_symlink(const char *target, const char *linkpath)
{
    struct stat st;
    int ret = 0;

    // 使用 lstat 检查 linkpath 是否存在
    if (lstat(linkpath, &st) != 0) {
        // 如果 lstat 返回 -1，表示文件不存在或发生其他错误
        if (errno == ENOENT) {
            // 文件不存在，创建符号链接
            ret = symlink(target, linkpath);
            if (ret != 0) {
                zte_printf_s("Failed to create symlink %s\n", linkpath);
                return -1;
            }
        } else {
            // 其他错误
            zte_printf_s("Error checking file status for %s: %s\n", linkpath, zte_strerror_s(errno));
            return -1;
        }
    }

    return 0;
}
/* Ended by AICoder, pid:kadb9z3c50kbbfb14a0509d020a1e0291a3437ff */

static int ubifs_init_device(int dev_num)
{
    int major, minor;
    char dev_path[zte_strnlen_s(UBI_DEV, MAX_PATH_LEN)+10];

    int ret = ubi_dev_get_major(dev_num, &major, &minor);
    if (ret != 0) {
        zte_printf_s("Failed to get major and minor numbers for UBI device %d\n", dev_num);
        return -1;
    }

    ret = zte_snprintf_s(dev_path, sizeof(dev_path), UBI_DEV, dev_num);
    SNPRINTF_S_CHECK(ret, sizeof(dev_path));

    ret = ubifs_mknod(dev_path, S_IFCHR | 0600, makedev(major, minor));
    if (ret != 0) {
        zte_printf_s("Failed to create device node %s\n", dev_path);
        return -1;
    }

    return 0;
}

static int ubifs_init_ctrl_device()
{
    int major, minor;
    int ret = ubi_ctrl_get_major(&major, &minor);
    if (ret != 0) {
        zte_printf_s("Failed to get major and minor numbers for UBI control device\n");
        return -1;
    }
    ret = ubifs_mknod(UBI_CTRL_DEV, S_IFCHR | 0600, makedev(major, minor));
    if (ret != 0) {
        zte_printf_s("Failed to create device node %s\n", UBI_CTRL_DEV);
        return -1;
    }
    return 0;
}

/* Started by AICoder, pid:87f7691eb8hf6fe14d2f0bbb20687615f45434a6 */
unsigned long fs_isro(const char* filePath) {
    struct statfs fs;
    int result = statfs(filePath, &fs);
    
    if (result == -1) {
        return FS_FILESYSTEM_NOTMOUNT;
    }

    if(fs.f_type != UBIFS_SUPER_MAGIC)
    {
        return FS_FILESYSTEM_NOTMOUNT;
    }
    
    if (fs.f_flags & ST_RDONLY) {
        return FS_FILESYSTEM_READONLY;
    }
    
    return FS_FILESYSTEM_RW;
}
/* Ended by AICoder, pid:87f7691eb8hf6fe14d2f0bbb20687615f45434a6 */

/* Started by AICoder, pid:87fed26542a718d142ee0a2a8008d2248a38882e */
unsigned int get_mtd_size(int mtd_num) {
    char mtd_path[20];
    int fd;
    struct mtd_info_user mtd_info;
    int ret = 0;

    // 构造mtd设备路径
    ret = zte_snprintf_s(mtd_path, sizeof(mtd_path), "/dev/mtd%d", mtd_num);
    SNPRINTF_S_CHECK(ret, sizeof(mtd_path));

    // 打开mtd设备
    fd = open(mtd_path, O_RDONLY);
    if (fd < 0) {
        perror("Failed to open mtd device");
        return -1;
    }

    // 获取mtd信息
    if (ioctl(fd, MEMGETINFO, &mtd_info) < 0) {
        perror("Failed to get mtd info");
        close(fd);
        return -1;
    }

    // 关闭mtd设备
    close(fd);
    // 返回mtd大小
    return mtd_info.size;
}
/* Ended by AICoder, pid:87fed26542a718d142ee0a2a8008d2248a38882e */

/* Started by AICoder, pid:076ef5317es8c921443b092cd0083e1e4925fc24 */
unsigned int get_filesystem_mtd_size(unsigned int index) 
{
    int mtd_index = 0;
    char mtd_name[20];
    int ret = 0;

    if(0 == index)
    {
        zte_memcpy_s(mtd_name, sizeof(mtd_name), FILESYSTEM_MTD_NAME, sizeof(FILESYSTEM_MTD_NAME));
    }
    else
    {
        ret = zte_snprintf_s(mtd_name, sizeof(mtd_name), FILESYSTEM_MTD_NAME"%d", index);
        SNPRINTF_S_CHECK(ret, sizeof(mtd_name));
    }

    mtd_index = get_mtd_from_name(mtd_name);
    if(-1 == mtd_index)
        return -1;

    return get_mtd_size(mtd_index);
}
/* Ended by AICoder, pid:076ef5317es8c921443b092cd0083e1e4925fc24 */

#if(defined(CONFIG_ZX211412) || defined(CONFIG_ZXW11200) || defined(CONFIG_ZX211413))
/* Started by AICoder, pid:m9f27e726at1d9b14e2808574113ef359912bee1 */
static int ubifs_early_init(T_FileSystemInfo *fsInfo)
{
    int ret = 0;
    FILE *fp = NULL;
    
    if(NULL == fsInfo)
    {
        return -1;
    }
    
    ret = zte_fopen_s(&fp, fsInfo->pcMntDir, "r", open_dirlist, open_dirlist_size);

    if (ret < 0 && NULL == fp) 
    {
        ret = mkdir(fsInfo->pcMntDir, 0755);
        if (ret != 0) {
            zte_printf_s("Failed to create directory %s\n", fsInfo->pcMntDir);
            return -1;
        }
    }
    else
    {
        /* Started by AICoder, pid:h0d98q9109xf1871400c0897b0268503a5951c3e */
        ret = zte_fclose_s(fp);
        /* Ended by AICoder, pid:h0d98q9109xf1871400c0897b0268503a5951c3e */
        FCLOSE_CHECK(ret);
    }

    return do_symlink(fsInfo->pcMntDir, fsInfo->pcLnRootDir);
}

/* Started by AICoder, pid:s7822c4883s98b3146050943604f1d54d4f343fe */
ULONG ubifs_dev_init(T_FileSystemInfo *fsInfo)
{
    int ret = 0;
    struct stat st;

    if (NULL == fsInfo)
    {
        return -1;
    }

    // Check if /dev/ubi_ctrl device exists
    if (lstat(UBI_CTRL_DEV, &st) != 0) {
        if (errno == ENOENT) {
            if (0 != ubifs_init_ctrl_device()) {
                return -1;
            }
        } else {
            // Handle other errors
            perror("Error checking UBI control device");
            return -1;
        }
    }

    if (0 != ubi_attach(fsInfo->ucMtdNo, fsInfo->ucUbiNo)) {
        return -1;
    }

    taskDelay(sysClkRateGet()); /* wait for ubifs attach */

    // Check if /dev/ubiX device exists
    char dev_path[MAX_PATH_LEN];
    ret = zte_snprintf_s(dev_path, sizeof(dev_path), UBI_DEV, fsInfo->ucUbiNo);
    SNPRINTF_S_CHECK(ret, sizeof(dev_path));

    if (lstat(dev_path, &st) != 0) {
        if (errno == ENOENT) {
            if (0 != ubifs_init_device(fsInfo->ucUbiNo)) {
                return -1;
            }
        } else {
            // Handle other errors
            perror("Error checking UBI device");
            return -1;
        }
    }

    // Mount UBIFS
    if (0 != ubifs_mount(fsInfo->ucUbiNo, fsInfo->pcMntDir)) {
        return -1;
    }

    return 0;
}
/* Ended by AICoder, pid:s7822c4883s98b3146050943604f1d54d4f343fe */

static int ubifs_post_init(T_FileSystemInfo *fsInfo)
{
    if(NULL == fsInfo)
    {
        return -1;
    }
    // Create subdirectories
    if (fsInfo->pcLnSubDir1 != NULL) {
        create_directory(fsInfo->pcLnSubDir1);
    }
    if (fsInfo->pcLnSubDir2 != NULL) {
        create_directory(fsInfo->pcLnSubDir2);
    }
    if (fsInfo->pcLnSubDir3 != NULL) {
        create_directory(fsInfo->pcLnSubDir3);
    }

    return 0;
}

ULONG ubifs_init(unsigned int dwIndex)
{
    if (dwIndex >= max_filesystem_num) {
        zte_printf_s("Invalid filesystem index\n");
        return -1;
    }

    T_FileSystemInfo *fsInfo = &s_at_FileSystemInfo[dwIndex];

    if(filesystem_info_init(dwIndex) == -1)
    {
        return -1;
    }
    ///mnt/filesystemX ataX 创建
    ubifs_early_init(fsInfo);
    //文件系统挂载
    ubifs_dev_init(fsInfo);
    //rru fpga dsp子目录创建
    ubifs_post_init(fsInfo);

    return 0;
}
/* Ended by AICoder, pid:m9f27e726at1d9b14e2808574113ef359912bee1 */

/* Ended by AICoder, pid:f6c4e52419b9a0214a690b8fe17a90563b4487ea */
#elif (defined(CONFIG_LS10X3A) || defined(CONFIG_ZX2112XX) || defined(CONFIG_ZX211410_EXT))
/* Started by AICoder, pid:ebe9chd71b9657014a780a674175e0634f54acef */
int get_ubifs_dev_no(VOID)
{
    FILE *fd = NULL;
    char *pReadBuf = NULL;
    char acStr1[100], acStr2[100];
    rsize_t size_array[3] = {100, 100, 0};
    int iReadlen = 0, iReadlen1 = 0;
    int iCmdCnt = 0;

    BspSystem("ubinfo > /test");

    fd = fopen("/test", "r");
    if (NULL == fd)
    {
        zte_printf_s("Can not open /test\n");
        BspSystem("rm -f /test");
        return -1;
    }
    pReadBuf = (char *)malloc(0x100);
    if (NULL == pReadBuf)
    {
        BspSystem("rm -f /test");
        zte_printf_s("Can't malloc buf\n");
        zte_fclose_s(fd);
        return -2;
    }
    /*find&match str*/
    while (0 == zte_fgets_s(pReadBuf, 0x100, 100, fd))
    {
        /*UBI version:                    1
        Count of UBI devices:           1
        UBI control device major/minor: 10:56
        Present UBI devices:            ubi0*/
        iCmdCnt = zte_sscanf_s(pReadBuf, "%*s %*s %s %s %d:%d", size_array, acStr1, acStr2, &iReadlen, &iReadlen1);
        // zte_printf_s("read str = %s %s %d %d\n",acStr1, acStr2, iReadlen, iReadlen1);
        if (0 == strncmp("major/minor:", acStr2, sizeof(acStr2)))
        {
            free(pReadBuf);
            zte_fclose_s(fd);
            BspSystem("rm -f /test");
            return iReadlen1;
        }
    }
    zte_printf_s("not find ubifs dev no!\n");
    free(pReadBuf);
    zte_fclose_s(fd);
    BspSystem("rm -f /test");
    return -3;
}

int get_ubi0_dev_no(VOID)
{
    FILE *fd = NULL;
    char *pReadBuf = NULL;
    int iReadlen = 0, iReadlen1 = 0;
    int iCmdCnt = 0;

    fd = fopen("/sys/class/ubi/ubi0/dev", "r");
    if (NULL == fd)
    {
        zte_printf_s("Can not open /sys/class/ubi/ubi0/dev\n");
        return -1;
    }
    pReadBuf = (char *)malloc(0x100);
    if (NULL == pReadBuf)
    {
        zte_fclose_s(fd);
        zte_printf_s("Can't malloc buf\n");
        return -2;
    }
    /*find&match str*/
    while (0 == zte_fgets_s(pReadBuf, 0x100, 100, fd))
    {
        /*246:0*/
        iCmdCnt = zte_sscanf_s(pReadBuf, "%d:%d", NULL, &iReadlen, &iReadlen1);
        // zte_printf_s("read %d %d\n", iReadlen, iReadlen1);
        if (0 == iReadlen1)
        {
            free(pReadBuf);
            zte_fclose_s(fd);
            return iReadlen;
        }
    }
    zte_printf_s("not find ubi0 dev NO!\n");
    free(pReadBuf);
    zte_fclose_s(fd);
    return -3;
}

ULONG ubifs_init(unsigned int dwIndex)
{
    UCHAR ucBufCmd[256];
    int nRetVal = BSP_OK, ubidevNo = 0, ubi0No = 0;

    BspSystem("mkdir -p /mnt/filesystem");
    ubidevNo = get_ubifs_dev_no();
    if (ubidevNo > 0)
    {
        zte_snprintf_s(ucBufCmd, sizeof(ucBufCmd), "mknod /dev/ubi_ctrl c 10 %d", ubidevNo);
        BspSystem(ucBufCmd);
    }
    else
    {
        zte_printf_s("can not get ubifs dev NO, use defautlt NO\n");
        BspSystem("mknod /dev/ubi_ctrl c 10 56");
    }

    zte_snprintf_s(ucBufCmd, sizeof(ucBufCmd), "ubiattach /dev/ubi_ctrl -m %d", FILESYSTEM);
    BspSystem(ucBufCmd);

    taskDelay(sysClkRateGet()); /*wait for ubifs attach*/
    ubi0No = get_ubi0_dev_no();
    if (ubi0No > 0)
    {
        zte_snprintf_s(ucBufCmd, sizeof(ucBufCmd), "mknod /dev/ubi0 c %d 0", ubi0No);
        BspSystem(ucBufCmd);
    }
    else
    {
        zte_printf_s("can not get ubi0 dev NO, use defautlt NO\n");
    }

    /*mount增加-o sync，每次写入writebuffer即刻同步到flash*/
    BspSystem("mount -t ubifs ubi0_0 /mnt/filesystem -o sync");

    BspSystem("ln -s /mnt/filesystem /ata");

    BspSystem("mkdir -p /ata/rru");

    BspSystem("mkdir -p /ata/rru/fpga");

    BspSystem("mkdir -p /ata/rru/dsp");

    return nRetVal;
}
/* Ended by AICoder, pid:ebe9chd71b9657014a780a674175e0634f54acef */

#else
ULONG ubifs_init(unsigned int dwIndex)
{
    UCHAR ucBufCmd[256];
    int nRetVal = BSP_OK;
    zte_snprintf_s(ucBufCmd, sizeof(ucBufCmd), "ubiattach /dev/ubi_ctrl -m %d", FILESYSTEM);
    system(ucBufCmd);
    /*mount增加-o sync，每次写入writebuffer即刻同步到flash*/
    system("mount -t ubifs ubi0_0 /mnt/filesystem -o sync");

    system("ln -s /mnt/filesystem /ata");

    system("mkdir -p /ata/rru");

    system("mkdir -p /ata/rru/fpga");

    system("mkdir -p /ata/rru/dsp");

    return nRetVal;
}
#endif

/* Started by AICoder, pid:y1c38y6d02z79c21435a0855919f4b369e817209 */
#if (defined(CONFIG_MULTI_FILESYSTEM))
static bool should_recover_multifs(unsigned int dwIndex)
{
    ULONG ulUbifsFormat_mask = 0;
    
    if(dwIndex >= max_filesystem_num)
    {
        zte_printf_s("error index in %s\n",__FUNCTION__);
        return false;
    }

    ulUbifsFormat_mask = BootGetFsRecoverFlag_Multi(dwIndex);
    
    return (FS_ABNORMAL_MAGIC_NUM == ulUbifsFormat_mask);
}
#endif

static bool should_recover_singlefs(unsigned int dwIndex)
{
    ULONG ulUbifsFormat_mask = 0;
    T_FileSystemInfo *fsInfo = NULL;
    ULONG ubimntflag = 0;

    if(dwIndex >= max_filesystem_num)
    {
        zte_printf_s("error index in %s\n",__FUNCTION__);
        return false;
    }

    fsInfo = &s_at_FileSystemInfo[dwIndex];

    ubimntflag = fs_isro(fsInfo->pcMntDir);
    ulUbifsFormat_mask = BootGetFsRecoverFlag();

    return ((FS_FILESYSTEM_RW != ubimntflag) || (FS_ABNORMAL_MAGIC_NUM == ulUbifsFormat_mask));
}

static bool should_recover_singlefs_new()
{
    ULONG ulUbifsFormat_mask = 0;

    ulUbifsFormat_mask = BootGetFsRecoverFlag();
    
    return (FS_ABNORMAL_MAGIC_NUM == ulUbifsFormat_mask);
}

#if defined(CONFIG_ZXW11200_NTN)
bool should_recover_fs(unsigned int dwIndex)
{
    if(NTN_BOARD_2ND == get_ntn_board_type())
    {
        return should_recover_multifs(dwIndex);
    }
    else{
        return should_recover_singlefs(dwIndex);
    }
}
#elif (defined(CONFIG_ZX211412) || defined(CONFIG_ZX211413) || defined(CONFIG_ZXW11200))
bool should_recover_fs(unsigned int dwIndex)
{
    return should_recover_singlefs_new();
}
#else
bool should_recover_fs(unsigned int dwIndex)
{
    return should_recover_singlefs(dwIndex);
}
#endif
/* Ended by AICoder, pid:y1c38y6d02z79c21435a0855919f4b369e817209 */


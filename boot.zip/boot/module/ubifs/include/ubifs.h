/* Started by AICoder, pid:358a9s77580655d1441209ede02e5e2da4f13f34 */
#ifndef UBIFS_H
#define UBIFS_H

#include <stdbool.h>
#include "secure_func.h"
#include "bspcomm.h"
#if defined(CONFIG_ZXW11200)
#include "zxw11200boot.h"
#endif

typedef struct {
    const char *pcLabel;    // mtd name
    const char *pcMntDir;   // 挂载目录名
    const char *pcLnRootDir;    // 软链接目录
    const char *pcLnSubDir1;    // 子目录
    const char *pcLnSubDir2;    // 子目录
    const char *pcLnSubDir3;    // 子目录
    unsigned char ucMtdNo;  // mtd序号
    unsigned char ucUbiNo;  // ubi设备序号
    unsigned char ucRsv[2];     //占位，预留
} T_FileSystemInfo;

#define FS_FILESYSTEM_NOTMOUNT         2
#define FS_FILESYSTEM_READONLY         1
#define FS_FILESYSTEM_RW               0

#define UBI_DEV "/dev/ubi%d"
#define UBI_CTRL_DEV "/dev/ubi_ctrl"
#define SYSFS_UBI_CTRL_DEV "/sys/class/misc/ubi_ctrl/dev"
#define SYSFS_UBI_DEV "/sys/class/ubi/ubi%d/dev"
#define FILESYSTEM_PATH "/mnt/filesystem"
#define FILESYSTEM_MTD_NAME "Filesystem"
#define FORMAT_LOG_FILE "/format.txt"
#define MAX_PATH_LEN 512
#define MAX_LOG_LEN 128
#define BUFLEN 50
#ifdef CONFIG_SECURITY
#define FILESYSTEM    3
#else
#define FILESYSTEM    2
#endif

#define FS_ABNORMAL_MAGIC_NUM   0xdeadbeaf

#define UBIFS_SUPER_MAGIC   0x24051905

#define DIRCLOSE_CHECK(_dirclsRet) \
    CHECK_RET_WARNING(((_dirclsRet) != (INT32)0), "dirclose ret'%d!", (_dirclsRet))

unsigned int get_filesystem_mtd_size(unsigned int index);
ULONG ubifs_init(unsigned int dwIndex);
unsigned long fs_isro(const char* filePath);
bool should_recover_fs(unsigned int dwIndex);

#endif
/* Ended by AICoder, pid:358a9s77580655d1441209ede02e5e2da4f13f34 */
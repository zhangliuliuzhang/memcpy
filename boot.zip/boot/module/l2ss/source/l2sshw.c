
/*********************************************************************
* 版权所有 (C)2002, 中兴通讯股份有限公司。
*
* 文件名称： ntl_l2ss_api.c
* 文件标识：
* 其它说明：
* 当前版本：
* 作    者： 姚自强
* 完成日期： 2015/09/09
* 修改记录1：
*    修改日期：
*    版 本 号：
*    修 改 人：
*    修改内容：
**********************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "bsppub.h"
#include "bspcomm.h"
#ifdef CONFIG_ZX211412
#include "zx211412boot.h"
#elif CONFIG_ZX211413
#include "zx211413boot.h"
#endif
#include "l2sshw.h"

#define L2SS_REG_BASE_ADDR (0xc0000000)

UINT8 g_acVidToVlanIdx[512] = {0}; /*VLAN ID到VLAN特性表索引的映射*/

static UINT32 g_l2ssRegVirAddr = 0;
UINT32 BootCfgL2ssBaseAddr(UINT32 vir_addr)
{
    g_l2ssRegVirAddr = vir_addr;
    return 0;
}

UINT32 L2SS_READREG(UINT32 offset)
{
    UINT32 virAddr;
    UINT32 viroffset;

    viroffset = (offset + BOOT_L2SS_BASE_ADDR) - L2SS_MAP_ADDR;
    virAddr = (UINT32)g_l2ssRegVirAddr + viroffset;

    return (UINT32)(*(volatile UINT32 *)(virAddr));
}

UINT32 L2SS_READBIT(UINT32 offset, UINT32 mask)
{
    UINT32 val;

    val = L2SS_READREG(offset);
    return (val & mask);
}

UINT32 L2SS_WRITEREG(UINT32 offset, UINT32 val)
{
    UINT32 virAddr;
    UINT32 viroffset;

    viroffset = (offset + BOOT_L2SS_BASE_ADDR) - L2SS_MAP_ADDR;
    virAddr = (UINT32)g_l2ssRegVirAddr + viroffset;

    *(volatile UINT32 *)(virAddr) = val;

    return 0;
}

UINT32 L2SS_SETBITS(UINT32 offset, UINT32 bit)
{
    UINT32 val;

    val = L2SS_READREG(offset);
    val |= bit;
    L2SS_WRITEREG(offset, val);
    return 0;
}

UINT32 L2SS_CLRBITS(UINT32 offset, UINT32 bit)
{
    UINT32 val;

    val = L2SS_READREG(offset);
    val &= (~bit);
    L2SS_WRITEREG(offset, val);
    return 0;
}

void l2ssDelay(UINT64 dwTimeOut)
{
    BspSysMsDelay_Sys(dwTimeOut);
}

/**********************************************************************
* 函数名称：L2ssDebugEnable
* 功能描述：配置L2SS进入Debug模式
* 输入参数：
* 输出参数：
* 返 回 值：
* 其他说明：
* 修改日期        版本号       修改人            修改内容
* ----------------------------------------------------------------------
************************************************************************/
UINT32 L2ssDebugEnable(void)
{
    L2SS_WRITEREG(L2SS_CFGI_GLOBAL_DEBUG_EN, L_DEBUG_ENABLE_VALUE);

    return (UINT32)BSP_OK;
}

/**********************************************************************
* 函数名称：L2ssDebugDisable
* 功能描述：配置L2SS退出Debug模式
* 输入参数：
* 输出参数：
* 返 回 值：
* 其他说明：
* 修改日期        版本号       修改人            修改内容
* ----------------------------------------------------------------------
************************************************************************/
UINT32 L2ssDebugDisable(void)
{
    L2SS_WRITEREG(L2SS_CFGI_GLOBAL_DEBUG_EN, 0x00000000u);

    return (UINT32)BSP_OK;
}

UINT32 L2ssDebugIsEnable(VOID)
{
    UINT32 ret = 0;
    if (L_DEBUG_ENABLE_VALUE == L2SS_READREG(L2SS_CFGI_GLOBAL_DEBUG_EN))
    {
        ret = 1;
    }

    return ret;
}

/**********************************************************************
* 函数名称：L2ssCfgModuDebugEnable
* 功能描述：配置L2SS模块进入debug模式
* 输入参数：
* 输出参数：
* 返 回 值：
* 其他说明：
* 修改日期        版本号       修改人            修改内容
* ----------------------------------------------------------------------
************************************************************************/
UINT32 L2ssCfgModuDebugEnable(e_L2ssModu modu, UINT32 en)
{
    if (!L2ssDebugIsEnable())
    {
        zte_printf_s("Ntl l2ss debug is disable !!!\n");
        return (UINT32)BSP_ERROR;
    }

    if (1 == en)
    {
        L2SS_SETBITS(L2SS_CFGI_PARS_DEBUG_CMD + (modu * L2SS_CFGI_CMD_SPAN), BIT0); // 进入调试模式
    }
    else
    {
        L2SS_CLRBITS(L2SS_CFGI_PARS_DEBUG_CMD + (modu * L2SS_CFGI_CMD_SPAN), BIT0); // 退出调试模式
    }

    return (UINT32)BSP_OK;
}

/**********************************************************************
* 函数名称：L2ssModuDebugIsEnable
* 功能描述：
* 输入参数：
* 输出参数：
* 返 回 值：
* 其他说明：
* 修改日期        版本号       修改人            修改内容
************************************************************************/
UINT32 L2ssModuDebugIsEnable(e_L2ssModu modu)
{
    UINT32 ret = 0;
    UINT32 val = 0;

    val = L2SS_READREG(L2SS_CFGI_PARS_DEBUG_CMD + (modu * L2SS_CFGI_CMD_SPAN));
    if (BIT0 & val)
    {
        ret = 1;
    }

    return ret;
}

/**********************************************************************
* 函数名称：L2ssCfgiStopModuEnable
* 功能描述：配置模块停止、启动
* 输入参数：eModuId 不能是e_QMAN_ID，是否有对qman做特殊处理有待验证
* 输出参数：
* 返 回 值：
* 其他说明：
* 修改日期        版本号       修改人            修改内容
************************************************************************/
UINT32 L2ssCfgiStopModuEnable(e_L2ssModu modu, UINT32 en) /*L2ssCfgiStopModu*/
{
    if ((!L2ssDebugIsEnable()) || (!L2ssModuDebugIsEnable(modu)))
    {
        zte_printf_s("%d debug is disable !!!\n", modu);
        return (UINT32)BSP_ERROR;
    }

    if (1 == en)
    {
        L2SS_SETBITS(L2SS_CFGI_PARS_DEBUG_CMD + (modu * L2SS_CFGI_CMD_SPAN), BIT1); // 停止
    }
    else
    {
        L2SS_CLRBITS(L2SS_CFGI_PARS_DEBUG_CMD + (modu * L2SS_CFGI_CMD_SPAN), BIT1); // 启动
    }

    return (UINT32)BSP_OK;
}

/**********************************************************************
* 函数名称：L2ssCheckQmanNorSelfInitDone
* 功能描述：查看QMAN NOR模块的自检完成
* 输入参数：
* 输出参数：
* 返 回 值：
* 其他说明：
* 修改日期        版本号       修改人            修改内容
* ----------------------------------------------------------------------
************************************************************************/
UINT32 L2ssCheckQmanNorSelfInitDone(UINT32 engId)
{
    UINT32 sta;
    UINT32 cnt = 0;
    sta = L2SS_READREG(L2SS_QMAN_NOR_SELF_INIT_DONE(engId));
    while ((0x01 != (sta & 0x01)) && (cnt < 10))
    {
        cnt++;
        l2ssDelay(100);
        sta = L2SS_READREG(L2SS_QMAN_NOR_SELF_INIT_DONE(engId));
    }
    if (1 == (sta & 0x01))
    {
        zte_printf_s("%s done\n", __FUNCTION__);
    }
    else
    {
        zte_printf_s("%s failed\n", __FUNCTION__);
    }
    return (cnt >= 10) ? -1 : 0;
}

/**********************************************************************
* 函数名称：L2ssSetEngMode
* 功能描述：配置引擎的工作模式
* 输入参数：
* 输出参数：
* 返 回 值：
* 其他说明：
* 修改日期        版本号       修改人            修改内容
* ----------------------------------------------------------------------
************************************************************************/
UINT32 L2ssSetEngMode(UINT32 ctrl)
{

    L2SS_WRITEREG(L2SS_CFGI_ENG_ENABLE_MODE, ctrl);
    return (UINT32)BSP_OK;
}

/**********************************************************************
* 函数名称：L2ssSetQmanCfgiInnerPortGroup
* 功能描述：配置内端口的起始编号
* 输入参数：
* 输出参数：
* 返 回 值：
* 其他说明：
* 修改日期        版本号       修改人            修改内容
* ----------------------------------------------------------------------
************************************************************************/
UINT32 L2ssSetQmanCfgiInnerPortGroup(UINT32 value)
{
    return L2SS_WRITEREG(L2SS_CFGI_IPORT_GROUP_ID, value);
}

/**********************************************************************
* 函数名称：L2ssWaitRegBitSet
* 功能描述：
* 输入参数：udDelayTime 最长等待时间(ms)
* 输出参数：
* 返 回 值：
* 其他说明：
* 修改日期        版本号       修改人            修改内容
* ----------------------------------------------------------------------
************************************************************************/
UINT32 L2ssWaitRegBitSet(UINT32 udRegAddr, UINT32 udBitMap, UINT32 udDelayTime)
{
    UINT32 udRegVal = 0;
    UINT32 udTimeOut = 0;
    UINT32 udPrecision = 100;

    udDelayTime = (udDelayTime / 1000) * udPrecision;
    do
    {
        l2ssDelay(1);
        udRegVal = L2SS_READREG(udRegAddr);
        udTimeOut++;
        if (0 == (udTimeOut % udPrecision)) /*  cpu时钟轮询precision次后就打印告警信号 */
        {
            zte_printf_s("udRegAddr = 0x%08x\n", udRegAddr);
            zte_printf_s("udRegVal  = 0x%08x\n", udRegVal);
            zte_printf_s("waiting for 0x%08x set....%d seconds \n", udBitMap, udTimeOut / udPrecision);
        }
        if (udTimeOut > udDelayTime) /*当时间超过最大udPrecision的告警次数就会超时，udDelayTime/udPrecision*/
        {
            zte_printf_s("Time out!\n");
            return BSP_ERROR;
        }

    } while (!(udRegVal & udBitMap));

    return (UINT32)BSP_OK;
}

/**********************************************************************
* 函数名称：L2ssLkupCfgDtblEnable
* 功能描述：直接表配置使能
* 输入参数：
* 输出参数：
* 返 回 值：
* 其他说明：
* 修改日期        版本号       修改人            修改内容
* ----------------------------------------------------------------------
************************************************************************/
UINT32 L2ssLkupCfgDtblEnable(void)
{
    UINT32 udResult = BSP_OK;

    // LKUP的直接表的SRAM 配置开关打开。
    L2SS_SETBITS(L2SS_LKUP_SRAM_CONFIG_EN, BIT0);

    // DTBL的SRAM-CPU访问申请寄存器
    L2SS_SETBITS(L2SS_LKUP_DTBL_CPU_RDWR_REQ, BIT0);

    udResult = L2ssWaitRegBitSet(L2SS_LKUP_DTBL_CPU_RDWR_RDY, BIT0, 5000); // 5s

    return udResult;
}

/**********************************************************************
* 函数名称：L2ssLkupCfgDtblDisable
* 功能描述：直接表配置去使能
* 输入参数：
* 输出参数：
* 返 回 值：
* 其他说明：
* 修改日期        版本号       修改人            修改内容
* ----------------------------------------------------------------------
************************************************************************/
UINT32 L2ssLkupCfgDtblDisable(void)
{
    //DTBL的SRAM-CPU访问申请寄存器
    L2SS_CLRBITS(L2SS_LKUP_DTBL_CPU_RDWR_REQ, BIT0);

    //LKUP的直接表的SRAM 配置开关关闭。
    L2SS_CLRBITS(L2SS_LKUP_SRAM_CONFIG_EN, BIT0);

    return (UINT32)BSP_OK;
}

UINT32 lvlemSw2Hw(T_L2ssLvlem *ptLvlem, T_L2ssLvlem_hw *ptLvlem_hw, UINT32 hw2sw)
{
    if (!hw2sw)
    {
        ptLvlem_hw->udPortBitmap1 = ptLvlem->udPortBitmap >> 59; /*5bit*/
        ptLvlem_hw->udPortBitmap2 = ptLvlem->udPortBitmap >> 27 & 0xffffffff; /*32bit*/
        ptLvlem_hw->udPortBitmap3 = ptLvlem->udPortBitmap & 0x07ffffff; /*27bit*/

        ptLvlem_hw->udStPortBitmap1 = ptLvlem->udStPortBitmap >> 59;
        ptLvlem_hw->udStPortBitmap2 = ptLvlem->udStPortBitmap >> 27 & 0xffffffff;
        ptLvlem_hw->udStPortBitmap3 = ptLvlem->udStPortBitmap & 0x07ffffff;

        ptLvlem_hw->udStgId = ptLvlem->udStgId;
    }
    else
    {
        ptLvlem->udPortBitmap = ((UINT64)(ptLvlem_hw->udPortBitmap1)) << 59 | ((UINT64)(ptLvlem_hw->udPortBitmap2)) << 27 | (ptLvlem_hw->udPortBitmap3);
        ptLvlem->udStPortBitmap = ((UINT64)(ptLvlem_hw->udStPortBitmap1)) << 59 | ((UINT64)(ptLvlem_hw->udStPortBitmap2)) << 27 | (ptLvlem_hw->udStPortBitmap3);
        ptLvlem->udStgId = ptLvlem_hw->udStgId;
    }
    return 0;
}

/**********************************************************************
* 函数名称： L2ssLkupCfgLmcmcTable
* 功能描述： 配置组播表ID=0~31的组播端口bitmap。查表失败按照组播表广播
* 输入参数： udDtblNum:0-127 表id ，udValue:目的端口映射bitmap
* 输出参数：
* 返 回 值：
* 其他说明：
* 修改日期        版本号     修改人           修改内容
* ----------------------------------------------------------------------
************************************************************************/
UINT32 L2ssLkupCfgLmcmcTable(UINT32 udDtblNum, UINT64 uddBitMap)
{
    UINT32 udAddrIndex = 0;

    UINT32 udRegTmpH = 0;
    UINT32 udRegTmpL = 0;

    UINT32 udBitMapH;
    UINT32 udBitMapL;

    udBitMapH = uddBitMap >> 32;
    udBitMapL = uddBitMap & 0xffffffff;

    L2ssLkupCfgDtblEnable();

    udAddrIndex = (udDtblNum / 2) * 8; /*直接表寄存器索引，因为每个2表占8个32位寄存器(256bit)，bitmap映射的地址顺序:31-0;63-32*/
    if (0 == udDtblNum % 2) /*写入的时候要按照128位宽(16字节)，先写地址1-3，再写地址0才能保证拼接成功*/ /*每32字节存2个表*/
    {
        udRegTmpL = L2SS_READREG(L2SS_LKUP_LK_MC_L2MC_ADDR(udAddrIndex + 2));
        udRegTmpH = L2SS_READREG(L2SS_LKUP_LK_MC_L2MC_ADDR(udAddrIndex + 3));
        L2SS_WRITEREG(L2SS_LKUP_LK_MC_L2MC_ADDR(udAddrIndex + 1), udBitMapH);
        L2SS_WRITEREG(L2SS_LKUP_LK_MC_L2MC_ADDR(udAddrIndex + 2), udRegTmpL);
        L2SS_WRITEREG(L2SS_LKUP_LK_MC_L2MC_ADDR(udAddrIndex + 3), udRegTmpH);
        L2SS_WRITEREG(L2SS_LKUP_LK_MC_L2MC_ADDR(udAddrIndex    ), udBitMapL);
    }
    else
    {
        udRegTmpL = L2SS_READREG(L2SS_LKUP_LK_MC_L2MC_ADDR(udAddrIndex));
        udRegTmpH = L2SS_READREG(L2SS_LKUP_LK_MC_L2MC_ADDR(udAddrIndex + 1));
        L2SS_WRITEREG(L2SS_LKUP_LK_MC_L2MC_ADDR(udAddrIndex + 1), udRegTmpH);
        L2SS_WRITEREG(L2SS_LKUP_LK_MC_L2MC_ADDR(udAddrIndex + 2), udBitMapL);
        L2SS_WRITEREG(L2SS_LKUP_LK_MC_L2MC_ADDR(udAddrIndex + 3), udBitMapH);
        L2SS_WRITEREG(L2SS_LKUP_LK_MC_L2MC_ADDR(udAddrIndex    ), udRegTmpL);
    }

    L2ssLkupCfgDtblDisable();

    return (UINT32)BSP_OK;
}

/**********************************************************************
* 函数名称：L2ssLkupCfgLvlemTable
* 功能描述：利用表号配置Lvlem表 LK_VLAN_EGR_PKTM 是个直接表,进行报文处理，如果
            报文的目的端口和该VLAN的udPortBitmap不匹配，则将报文过滤。如果报文的目的
            端口和该VLAN的udStPortBitmap匹配，则剥离外层标签。
* 输入参数：
* 输出参数：
* 返 回 值：
* 其他说明：
* 修改日期        版本号       修改人            修改内容
* ----------------------------------------------------------------------
************************************************************************/
UINT32 L2ssLkupCfgLvlemTable(UINT32 udClassId, T_L2ssLvlem *ptLvlem)
{
    UINT32 *pudValue;
    UINT32 udRegId;
    T_L2ssLvlem_hw tlvlemhw;

    lvlemSw2Hw(ptLvlem, &tlvlemhw, 0);
    pudValue = (UINT32 *)&tlvlemhw;
    udRegId = udClassId * 8; /*8个4字节寄存器，也即每个表占256bit，位宽133bit*/

    L2ssLkupCfgDtblEnable();

    L2SS_WRITEREG(L2SS_LKUP_LK_VLAN_EGR_PKTM_ADDR(udRegId + 4), pudValue[0]);
    L2SS_WRITEREG(L2SS_LKUP_LK_VLAN_EGR_PKTM_ADDR(udRegId + 3), pudValue[1]);
    L2SS_WRITEREG(L2SS_LKUP_LK_VLAN_EGR_PKTM_ADDR(udRegId + 2), pudValue[2]);
    L2SS_WRITEREG(L2SS_LKUP_LK_VLAN_EGR_PKTM_ADDR(udRegId + 1), pudValue[3]);
    L2SS_WRITEREG(L2SS_LKUP_LK_VLAN_EGR_PKTM_ADDR(udRegId    ), pudValue[4]);

    L2ssLkupCfgDtblDisable();

    return (UINT32)BSP_OK;
}

/**********************************************************************
* 函数名称：L2ssQmanCfgDlp2Qlp
* 功能描述：DLP到QLP的映射  ,还有一个映射是 QLP到VPP的映射关系 见LP2vPP表,既可以实现
DLPx 映射到 QLPy
* 输入参数：
* 输出参数：
* 返 回 值：
* 其他说明：
* 修改日期        版本号       修改人            修改内容
* ----------------------------------------------------------------------
************************************************************************/
UINT32 L2ssQmanCfgDlp2Qlp(UINT32 dlpNo, UINT32 qlpNo) /*dlpNo填实际端口号*/
{
    UINT32 udValue = 0;
    UINT32 mask = 0;

    L2ssDebugEnable();
    udValue = L2SS_READREG(L2SS_QMAN_DLP2QLP_MAP_CFG(dlpNo / 4));
    mask = ~(0x3f << ((dlpNo % 4) * 8));
    udValue &= mask;
    udValue |= (qlpNo << ((dlpNo % 4) * 8));
    L2SS_WRITEREG(L2SS_QMAN_DLP2QLP_MAP_CFG(dlpNo / 4), udValue);
    L2ssDebugDisable();

    return (UINT32)BSP_OK;
}

/**********************************************************************
* 函数名称：L2ssPktmCfgDpp2Dvpp
* 功能描述：PKTM DPP 到 DVPP 映射配置
* 输入参数：udSlave:1为备用状态配置  0 默认为主用配置
* 其他说明：
* 修改日期        版本号       修改人            修改内容
* ----------------------------------------------------------------------
************************************************************************/
UINT32 L2ssPktmCfgDpp2Dvpp(UINT32 udDpp, UINT32 udDvpp, UINT32 udSlave)
{
    UINT32 udRegId = 0;
    UINT32 udRegPos = 0;
    UINT32 udBitMap = 0;

    udRegId = udDpp / 4; /*64个端口映射到16个寄存器*/
    udRegPos = (udDpp % 4) * 8; /*每个寄存器4个dvpp,8bit对齐，dvpp序号从低bit到高bit增长*/

    if (udSlave)
    {
        udBitMap = L2SS_READREG(L2SS_PKTM_DPP_2DVPP_SLAVE_MAP(udRegId));
    }
    else
    {
        udBitMap = L2SS_READREG(L2SS_PKTM_DPP_2DVPP_MAST_MAP(udRegId));
    }
    udBitMap &= ~(0x3f << udRegPos); /*每个dpp端口的值6bit*/
    udBitMap |= (udDvpp << udRegPos);

    if (udSlave)
    {
        L2SS_WRITEREG(L2SS_PKTM_DPP_2DVPP_SLAVE_MAP(udRegId), udBitMap);
    }
    else
    {
        L2SS_WRITEREG(L2SS_PKTM_DPP_2DVPP_MAST_MAP(udRegId), udBitMap);
    }
    return (UINT32)BSP_OK;
}

#if 0
UINT32 NtlL2ssPortMapTestInit()
{
    L2ssQmanCfgDlp2Qlp(32,15); /*agent 0*/
    L2ssQmanCfgDlp2Qlp(44,14); /*agent 1*/
    L2ssQmanCfgDlp2Qlp(45,13); /*agent 2*/
    L2ssQmanCfgDlp2Qlp(46,12); /*agent 3*/
    L2ssQmanCfgDlp2Qlp(33,1);  /*xc*/
    L2ssQmanCfgDlp2Qlp(34,2);  /*roe0*/
    L2ssQmanCfgDlp2Qlp(35,3);  /*roe1*/

    L2ssPktmCfgDpp2Dvpp(32,15,0);
    L2ssPktmCfgDpp2Dvpp(44,14,0);
    L2ssPktmCfgDpp2Dvpp(45,13,0);
    L2ssPktmCfgDpp2Dvpp(46,12,0);
    L2ssPktmCfgDpp2Dvpp(33,1,0);
    L2ssPktmCfgDpp2Dvpp(34,2,0);
    L2ssPktmCfgDpp2Dvpp(35,3,0);
    return BSP_OK;
}
#endif

/**********************************************************************
* 函数名称：L2ssPrepCfgPktErrCtrl
* 功能描述：配置头校验错误是否丢弃
* 输入参数：
* 输出参数：
* 返 回 值：
* 其他说明：
* 修改日期        版本号       修改人            修改内容
************************************************************************/
UINT32 L2ssPrepCfgPktErrCtrl(UINT32 udErrDropEn)
{
    UINT32 udRegTmp = 0;
    UINT32 udCnt = 0;

    for (udCnt = 0; udCnt < e_L2SS_ENG_NUM; udCnt += 2)
    {
        udRegTmp = L2SS_READREG(L2SS_PREP_PARS_PKT_ERR_CTRL(udCnt)) & (~BIT0);
        udRegTmp |= udErrDropEn & BIT0;
        L2SS_WRITEREG(L2SS_PREP_PARS_PKT_ERR_CTRL(udCnt), udRegTmp);
    }

    return (UINT32)0;
}

/**********************************************************************
* 函数名称：L2ssParsCfglpSelParseNUm
* 功能描述：逻辑端口的解析单元的选择
* 输入参数：
* 输出参数：
* 返 回 值：
* 其他说明：
* 修改日期        版本号       修改人            修改内容
* ----------------------------------------------------------------------
************************************************************************/
UINT32 L2ssParsCfglpSelParseNUm(UINT32 udLPNum, UINT32 udParseNum)
{
    UINT32 udAddrBase = 0;
    UINT32 udAddrOffset = 0;
    UINT32 udRegTmp = 0;

    udAddrBase = (udLPNum / 16) * 0x4;
    udAddrOffset = (udLPNum % 16) * 2;

    udRegTmp = L2SS_READREG((L2SS_PARS_PORT_0_15_PARSER_SEL + udAddrBase));
    udRegTmp &= ~(BW2 << udAddrOffset);
    udRegTmp |= udParseNum << udAddrOffset;
    L2SS_WRITEREG((L2SS_PARS_PORT_0_15_PARSER_SEL + udAddrBase), udRegTmp);

    return (UINT32)0;
}

/**********************************************************************
* 函数名称：L2ssParsCfgPktAnalyLevel
* 功能描述：PARS的报文解析层次配置
* 输入参数：E_TrxpId ePortNum 端口号
            UINT32 udLevel 解析层次 2-5
* 输出参数：
* 返 回 值：
* 其他说明：
* 修改日期        版本号       修改人            修改内容
************************************************************************/
UINT32 L2ssParsCfgPktAnalyLevel(E_TrxpId ePortNum, UINT32 udLevel)
{
    UINT32 udAddrBase   = 0;
    UINT32 udAddrOffset = 0;
    UINT32 udValue      = 0;
    UINT32 udRegTmp     = 0;

    udAddrBase = (ePortNum / 6) * 0x4;
    udAddrOffset = ePortNum % 6 * 5;
    switch (udLevel)
    {
        case 5:
        {
            udValue |= 0x04;
            break;
        }

        case 4:
        {
            udValue |= 0x02;
            break;
        }

        case 3:
        {
            udValue |= 0x01;
            break;
        }

        case 2:
        {
            udValue = 0x00;
            break;
        }

        default:
        {
            udValue = 0x01;
            break;
        }
    }

    if (udAddrBase == 0 || udAddrBase == 4)
    {
        udRegTmp = L2SS_READREG((L2SS_PARS_CTRL_REG0 + udAddrBase));
        udRegTmp &= ~(0x1f << udAddrOffset);
        udRegTmp |= udValue << udAddrOffset;
        L2SS_WRITEREG((L2SS_PARS_CTRL_REG0 + udAddrBase), udRegTmp);
    }
    else
    {
        udRegTmp = L2SS_READREG((L2SS_PARS_CTRL_REG2 + udAddrBase - 0x8));
        udRegTmp &= ~(0x1f << udAddrOffset);
        udRegTmp |= udValue << udAddrOffset;
        L2SS_WRITEREG((L2SS_PARS_CTRL_REG2 + udAddrBase - 0x8), udRegTmp);
    }
    return (UINT32)0;
}

/**********************************************************************
* 函数名称：L2ssLkupCfgHashCpuAdd
* 功能描述：配置CPU添加表项匹配是否修改
* 输入参数：udModifyEn 1，对匹配项进行修改；0，不修改，返回表项匹配结果
* 输出参数：
* 返 回 值：
* 其他说明：
* 修改日期        版本号       修改人            修改内容
* ----------------------------------------------------------------------
************************************************************************/
UINT32 L2ssLkupCfgHashCpuAdd(UINT32 udModifyEn)
{
    L2SS_WRITEREG(L2SS_LKUP_HASH_CPU_ADD_CFG, udModifyEn);

    return (UINT32)BSP_OK;
}

/**********************************************************************
* 函数名称：L2ssLkupGetLslppTable
* 功能描述：
* 输入参数：
* 输出参数：
* 返 回 值：
* 其他说明：
* 修改日期        版本号       修改人            修改内容
* ----------------------------------------------------------------------
************************************************************************/
UINT32 L2ssLkupGetLslppTable(E_TrxpId ePortNum, T_L2ssLslpp *ptLslpp)
{
    UINT32 *pudValue = NULL;

    pudValue = (UINT32 *)ptLslpp;

    L2ssLkupCfgDtblEnable();
    pudValue[1] = L2SS_READREG(L2SS_LKUP_LK_SRC_LPORTL_PREP_ADDR(ePortNum));
    pudValue[0] = L2SS_READREG(L2SS_LKUP_LK_SRC_LPORTH_PREP_ADDR(ePortNum));
    L2ssLkupCfgDtblDisable();

    return (UINT32)BSP_OK;
}

/**********************************************************************
* 函数名称： L2ssLkupCfgLslppTable
* 功能描述： 配置预处理的7个源逻辑端口，LK_SRC_LPORT_PREP
* 输入参数：
* 输出参数：
* 返 回 值：
* 其他说明：
* 修改日期        版本号     修改人           修改内容
* ----------------------------------------------------------------------
************************************************************************/
UINT32 L2ssLkupCfgLslppTable(E_TrxpId ePortNum, T_L2ssLslpp *ptLslpp)
{
    UINT32 udValueH = 0;
    UINT32 udValueL = 0;
    UINT32 *pudlLslpp = 0;

    pudlLslpp = (UINT32*)ptLslpp;
    udValueH = pudlLslpp[0];
    udValueL = pudlLslpp[1];

    L2ssLkupCfgDtblEnable();

    L2SS_WRITEREG(L2SS_LKUP_LK_SRC_LPORTL_PREP_ADDR(ePortNum), udValueL);
    L2SS_WRITEREG(L2SS_LKUP_LK_SRC_LPORTH_PREP_ADDR(ePortNum), udValueH);

    L2ssLkupCfgDtblDisable();

    return (UINT32)BSP_OK;
}

/**********************************************************************
* 函数名称：NtlL2ssVlanMapModeSet
* 功能描述：配置VLAN映射的方式及优先级
* 输入参数：ePortNum 端口
           udMapMode 映射方式 EXT IP MAC
           BIT0 SMAC BIT1 DMAC BIT2 SIP BIT3 DIP BIT4 EXTA BIT5 EXB
           udMapPri 映射优先级 EXT IP MAC Precedence
           BIT8-6 EXTB_KEY的选择 BIT5 (PKT_EXT_KEY)D/S(1/0) BIT4 D/S BIT3 D/S BIT2-0 000-111
* 输出参数：
* 返 回 值：
* 其他说明：
* 修改日期        版本号       修改人            修改内容
* ----------------------------------------------------------------------
* 2016/03/18       V1.0      Yaoziqiang            创建
************************************************************************/
UINT32 L2ssVlanMapModeSet(E_TrxpId ePortNum, UINT32 udMapMode, UINT32 udMapPri)
{
    T_L2ssLslpp tLslpp;

    zte_memset_s(&tLslpp, sizeof(T_L2ssLslpp), 0, sizeof(T_L2ssLslpp));
    L2ssLkupGetLslppTable(ePortNum, &tLslpp);
    tLslpp.ulDmacBasedVidEnable = (udMapMode & BIT1) >> 1;
    tLslpp.ulSmacBasedVidEnable = (udMapMode & BIT0);
    tLslpp.ulDipBasedVidEnable = (udMapMode & BIT3) >> 3;
    tLslpp.ulSipBasedVidEnable = (udMapMode & BIT2) >> 2;
    tLslpp.ulPktExtaBasedVidEnable = (udMapMode & BIT4) >> 4;
    tLslpp.ulPktExtbBasedVidEnable = (udMapMode & BIT5) >> 5;

    tLslpp.ulVlanDmacPrecedence = (udMapPri & BIT3) >> 3;
    tLslpp.ulVlanDipPrecedence = (udMapPri & BIT4) >> 4;
    tLslpp.ulVlanPrecedence = (udMapPri & 0x7);
    tLslpp.ulV4Len = 0x1;
    tLslpp.ulV6Len = 0x3;
    /*使用EXTx做VLAN映射时，L4端口号是选择目的还是源 1:DPORT  0：SPORT*/
    tLslpp.ulPktExtKey = (udMapPri & BIT5) >> 5;
    tLslpp.uExtB_KT = (udMapPri >> 6) & BW3; /*ExtB_kt[0:2]决定了Ext_key[31:0]的关系
                                             Ext_kt = 000: Ext_Key = L5_4B
                                             Ext_kt = 001: Ext_Key = L5_4B
                                             Ext_kt = 010: 如果是UDP, Ext_Key = L5_4B,否则 Ext_Key = {1'b0,SLP_Type[2:0],DIP_KEY[27:0]}
                                             Ext_kt = 011: 如果是UDP, Ext_Key = L5_4B,否则 Ext_Key = {1'b0,SLP_Type[2:0],SIP_KEY[27:0]}
                                             Ext_kt = 100: 如果是分片报文,Ext_Key = {1'b0,SLP_Type[2:0],SIP_KEY[27:0]},否则Ext_Key = L5_4B
                                             Ext_kt = 110: Ext_Key = {1'b0,SLP_Type[2:0],DIP_KEY[27:0]}
                                             Ext_kt = 111: Ext_Key = {1'b0,SLP_Type[2:0],SIP_KEY[27:0]}*/

    L2ssLkupCfgLslppTable(ePortNum, &tLslpp);

    return (UINT32)0;
}

/**********************************************************************
* 函数名称： L2ssLkupCfgLvtapTable
* 功能描述：
* 输入参数：
* 输出参数：
* 返 回 值：
* 其他说明：L2ssVlanApplyLvtapTableId 申请地址资源
* 修改日期        版本号     修改人           修改内容
* ----------------------------------------------------------------------
************************************************************************/
UINT32 L2ssLkupCfgLvtapTable(UINT32 udClassId, T_L2ssLvtap *ptLvtap)
{
    UINT16 usValue = 0;
    UINT32 udAddrBase = 0;
    UINT32 udAddrOffset = 0;
    UINT32 udRegTmp0 = 0;
    UINT32 udRegTmp1 = 0;

    usValue = *(UINT16 *)ptLvtap; /*标签表的是以16bit进行操作的，大小端结构体按照16bit进行操作*/
    udAddrBase = udClassId / 2;
    udAddrOffset = udClassId % 2 * 16;

    L2ssDebugEnable();
    L2ssLkupCfgDtblEnable();

    udRegTmp0 = L2SS_READREG(L2SS_LKUP_LK_VLAN_TAG_ACT_PREP_ADDR(udAddrBase));
    udRegTmp0 &= ~(0xffff << udAddrOffset);
    udRegTmp0 |= usValue << udAddrOffset;
    if (0 == udAddrBase % 2)
    {
        udRegTmp1 = L2SS_READREG(L2SS_LKUP_LK_VLAN_TAG_ACT_PREP_ADDR(udAddrBase + 1));
        L2SS_WRITEREG(L2SS_LKUP_LK_VLAN_TAG_ACT_PREP_ADDR(udAddrBase), udRegTmp0);
        L2SS_WRITEREG(L2SS_LKUP_LK_VLAN_TAG_ACT_PREP_ADDR(udAddrBase + 1), udRegTmp1);
    }
    else
    {
        udRegTmp1 = L2SS_READREG(L2SS_LKUP_LK_VLAN_TAG_ACT_PREP_ADDR(udAddrBase - 1));
        L2SS_WRITEREG(L2SS_LKUP_LK_VLAN_TAG_ACT_PREP_ADDR(udAddrBase - 1), udRegTmp1);
        L2SS_WRITEREG(L2SS_LKUP_LK_VLAN_TAG_ACT_PREP_ADDR(udAddrBase), udRegTmp0);
    }

    L2ssLkupCfgDtblDisable();
    L2ssDebugDisable();
    return (UINT32)BSP_OK;
}

/**********************************************************************
* 函数名称：NtlL2ssPortVlanSet
* 功能描述：
* 输入参数：
* 输出参数：
* 返 回 值：
* 其他说明：
* 修改日期        版本号       修改人            修改内容
* ----------------------------------------------------------------------
************************************************************************/
UINT32 L2ssPortVlanSet(E_TrxpId ePortNum, UINT32 udVlanId, UINT32 udVtagSlpMap)
{
    UINT32 udTableBaseAddr = 0;

    UINT32 udTagActProf = 0;

    T_L2ssLslpp tLslpp;
    T_L2ssLvtap tLvtap;

    zte_memset_s(&tLslpp, sizeof(T_L2ssLslpp), 0, sizeof(T_L2ssLslpp));
    L2ssLkupGetLslppTable(ePortNum, &tLslpp);

    udTagActProf = tLslpp.ulTagActProf0 | (tLslpp.ulTagActProf1 << 4);

    if ((0 == tLslpp.ulTagActProf0) && (0 == tLslpp.ulTagActProf1))
    {
        udTagActProf = L2ssLkupApplyLvtapTableId();
        tLslpp.ulTagActProf0 = udTagActProf & BW4;
        tLslpp.ulTagActProf1 = udTagActProf >> 4;
    }

    tLslpp.ulVtagSlpMap = udVtagSlpMap;
    tLslpp.ulOvid = udVlanId;
    L2ssLkupCfgLslppTable(ePortNum, &tLslpp);

    zte_memset_s(&tLvtap, sizeof(T_L2ssLvtap), 0, sizeof(T_L2ssLvtap));
    tLvtap.usSotOdeiAct = 2;
    tLvtap.usSotOpriAct = 2;
    tLvtap.usSotOtagAct = 2;
    tLvtap.usSotPotagAct = 2;
    tLvtap.usUtOdeiAct = 2;
    tLvtap.usUtOpriAct = 2;
    tLvtap.usUtOtagAct = 2;

    udTableBaseAddr = tLslpp.ulTagActProf0 | (tLslpp.ulTagActProf1 << 4);
    L2ssLkupCfgLvtapTable(udTableBaseAddr, &tLvtap);

    return (UINT32)BSP_OK;
}

/**********************************************************************
* 函数名称：L2ssPortVlanGet
* 功能描述：
* 输入参数：
* 输出参数：
* 返 回 值：
* 其他说明：
* 修改日期        版本号       修改人            修改内容
* ----------------------------------------------------------------------
************************************************************************/
UINT32 L2ssPortVlanGet(E_TrxpId ePortNum)
{
    UINT32 vlanId;
    T_L2ssLslpp tLslpp;

    zte_memset_s(&tLslpp, sizeof(T_L2ssLslpp), 0, sizeof(T_L2ssLslpp));
    L2ssLkupGetLslppTable(ePortNum, &tLslpp);
    vlanId = tLslpp.ulOvid;

    #if 0
    /* Started by AICoder, pid:0622760931i4c7b14c370bce00bf2b0dc5e837fd */
    UINT32 udTableBaseAddr = 0;
    UINT32 udTagActProf = 0;
    T_L2ssLvtap tLvtap;
    /* Ended by AICoder, pid:0622760931i4c7b14c370bce00bf2b0dc5e837fd */
    udTagActProf = tLslpp.ulTagActProf0 | (tLslpp.ulTagActProf1 << 4);

    if ((0 == tLslpp.ulTagActProf0) && (0 == tLslpp.ulTagActProf1))
    {
        udTagActProf = L2ssLkupApplyLvtapTableId();
        tLslpp.ulTagActProf0 = udTagActProf & BW4;
        tLslpp.ulTagActProf1 = udTagActProf >> 4;
    }

    tLslpp.ulVtagSlpMap = udVtagSlpMap;
    tLslpp.ulOvid = udVlanId;
    L2ssLkupCfgLslppTable(ePortNum, &tLslpp);

    zte_memset_s(&tLvtap, sizeof(T_L2ssLvtap), 0, sizeof(T_L2ssLvtap));
    tLvtap.usSotOdeiAct = 2;
    tLvtap.usSotOpriAct = 2;
    tLvtap.usSotOtagAct = 2;
    tLvtap.usSotPotagAct = 2;
    tLvtap.usUtOdeiAct = 2;
    tLvtap.usUtOpriAct = 2;
    tLvtap.usUtOtagAct = 2;

    udTableBaseAddr = tLslpp.ulTagActProf0 | (tLslpp.ulTagActProf1 << 4);
    L2ssLkupCfgLvtapTable(udTableBaseAddr, &tLvtap);
    #endif
    return (UINT32)vlanId;
}

UINT32 L2ssLkuplviprepToLvlip(T_L2ssLvIngPrep *ptL2sslviprep, T_L2ssLvIdPrep *ptL2ssLvIdPrep, T_L2ssLvlip *ptL2ssLvlip)
{
    UINT64 bitmap;

    ptL2ssLvlip->ulLagMaskType     = ptL2sslviprep->ulLagMaskType;
    ptL2ssLvlip->ulLagKeyType1     = (ptL2sslviprep->ulLagMaskType >> 1) & BW3;
    ptL2ssLvlip->ulLagKeyType0     = (ptL2sslviprep->ulLagMaskType & BW1);

    ptL2ssLvlip->ulUmcIdx          = (ptL2sslviprep->ulUmcIdx1 << 6) | (ptL2sslviprep->ulUmcIdx0);
    ptL2ssLvlip->ulUucIdx          = ptL2sslviprep->ulUucIdx;
    ptL2ssLvlip->ulBcIdx           = ptL2sslviprep->ulBcIdx;

    ptL2ssLvlip->ulFidId1          = (ptL2sslviprep->ulFidId >> 2) & BW10;
    ptL2ssLvlip->ulFidId0          = ptL2sslviprep->ulFidId & BW2;

    ptL2ssLvlip->ulVlanClassId     = ptL2sslviprep->ulVlanClassId;
    ptL2ssLvlip->ulL2mcMissDrop    = ptL2sslviprep->ulL2mcMissDrop;
    ptL2ssLvlip->ulL2mcMissTocpu   = ptL2sslviprep->ulL2mcMissTocpu;
    ptL2ssLvlip->ulL2ucMissDrop    = ptL2sslviprep->ulL2ucMissDrop;
    ptL2ssLvlip->ulL2ucMissTocpu   = ptL2sslviprep->ulL2ucMissTocpu;
    ptL2ssLvlip->ulLearnDrop       = ptL2sslviprep->ulLearnDrop;
    ptL2ssLvlip->ulLearnDisable    = ptL2sslviprep->ulLearnDisable;
    ptL2ssLvlip->ulCmlFlagsValid   = ptL2sslviprep->ulCmlFlagsValid;
    ptL2ssLvlip->ulCmlFlagsMove    = ptL2sslviprep->ulCmlFlagsMove;
    ptL2ssLvlip->ulCmlFlagsNew     = ptL2sslviprep->ulCmlFlagsNew;

    ptL2ssLvlip->ulStaticMoveDrop  = ptL2sslviprep->ulStaticMoveDrop;
    ptL2ssLvlip->ulStaticMoveTocpu = ptL2sslviprep->ulStaticMoveTocpu;

    ptL2ssLvlip->ulStgId1          = (ptL2sslviprep->ulStgId >> 1) & BW4;
    ptL2ssLvlip->ulStgId0          = ptL2sslviprep->ulStgId & BW1;

    bitmap = ((UINT64)ptL2sslviprep->ulPortBitmap2 << 63) | ((UINT64)ptL2sslviprep->ulPortBitmap1 << 31) | ((UINT64)ptL2sslviprep->ulPortBitmap0 & BW31);

    ptL2ssLvlip->ulPortBitmap2     = (bitmap >> 33) & BW31; // bit[63:39] 25    1
    ptL2ssLvlip->ulPortBitmap1     = (bitmap >> 1) & BW32;  // bit[38:7]  32   32
    ptL2ssLvlip->ulPortBitmap0     = bitmap & BW1;          // bit[6:0]   7    31

    ptL2ssLvlip->ulMirrorEn        = ptL2sslviprep->ulMirrorEn;

    ptL2ssLvlip->ulVlanIdL         = ptL2ssLvIdPrep->ulVlanIdL;
    ptL2ssLvlip->ulValid           = ptL2ssLvIdPrep->ulValid;
    ptL2ssLvlip->ulRsv1            = ptL2ssLvIdPrep->ulRsv1;
    ptL2ssLvlip->ulKey             = ptL2ssLvIdPrep->ulKey; /*hyt:此处应该加ulValnIdx1、0*/
    ptL2ssLvlip->ulKeyType         = ptL2ssLvIdPrep->ulKeyType;

    ptL2ssLvlip->ulValnIdx0        = ptL2ssLvIdPrep->ulValnIdx0;
    ptL2ssLvlip->ulValnIdx1        = ptL2ssLvIdPrep->ulValnIdx1;

    return (UINT32)BSP_OK;
}

/**********************************************************************
* 函数名称： L2ssLkupCpuHashaOp
* 功能描述： 查表的类型：00，普通查找；01，表项插入；10，表项删除；11，表项修改
             表类型:00: 为转发表，FID+MAC_ADDR查找；
                    01: 为MAC VLAN映射，MAC查找
                    10: 为VLAN索引表，VID查找
* 输入参数：
* 输出参数：
* 返 回 值：
* 其他说明：
* 修改日期        版本号     修改人           修改内容
* ----------------------------------------------------------------------
************************************************************************/
UINT32 L2ssLkupCpuHashaOp(UINT32 udOptype, UINT32 udHashKeyType, void *ptHashTable, void *ptHashTableResp)
{
    UINT32 udResult = BSP_OK;
    UINT32 udCpuHashResp = 0;
    UINT32 udCpuHashReq = 0;
    UINT32 audHashKey[7] = {0};
    UINT32 audTempTable[2] = {0};
    UINT32 *pudHashKey = NULL;
    UINT32 *pudHashKeyResp = NULL;

    UINT32 *pudHashKeyTempResp = NULL;

    T_L2ssLvIdPrep *ptL2ssLvIdPre = NULL;
    T_L2ssLvIngPrep tL2sslviprep;
    zte_memset_s(&tL2sslviprep, sizeof(tL2sslviprep), 0, sizeof(tL2sslviprep));

    if ((udHashKeyType == e_L2ssHashFmType) || (udHashKeyType == e_L2ssHashMacType))
    {
        udCpuHashReq = ((udOptype << 4) | 0x01) & (~BIT1); /*配置申请访问hash表的类型a*/

        pudHashKey = (UINT32 *)ptHashTable;
        audHashKey[0] = pudHashKey[3];
        audHashKey[1] = pudHashKey[2];
        audHashKey[2] = pudHashKey[1];
        audHashKey[3] = pudHashKey[0];
    }
    else if (udHashKeyType == e_L2ssHashVlanType)
    {

        udCpuHashReq = ((udOptype << 4) | 0x01) | BIT1; /*配置申请访问hash表的类型b*/
        pudHashKey = (UINT32 *)ptHashTable;
        audHashKey[0] = pudHashKey[6];
        audHashKey[1] = pudHashKey[5];
        audHashKey[2] = pudHashKey[4];
        audHashKey[3] = pudHashKey[3];
        audHashKey[4] = pudHashKey[2];
        audHashKey[5] = pudHashKey[1];
        audHashKey[6] = pudHashKey[0];
    }
    else
    {
        udCpuHashReq = ((udOptype << 4) | 0x01) | BIT1; /*配置申请访问hash表的类型b*/
        pudHashKey = (UINT32 *)ptHashTable;
        audHashKey[0] = pudHashKey[1];
        audHashKey[1] = pudHashKey[0];
    }

    if ((udOptype == L2SS_HASH_ADD) && ((udHashKeyType == e_L2ssHashVlanType) /*hashb表添加打开匹配修改使能*/
                                     || (udHashKeyType == e_L2ssHashTsnType)))
    {
        L2ssLkupCfgHashCpuAdd(1);
    }

    L2SS_WRITEREG(L2SS_LKUP_CPU_HASH_KEY(0), audHashKey[0]); /*CPU发起的Hash查表键值寄存器0，对应键值的bit[31:0] */
    L2SS_WRITEREG(L2SS_LKUP_CPU_HASH_KEY(1), audHashKey[1]); /*CPU发起的Hash查表键值寄存器1，对应键值的bit[63:32] */
    L2SS_WRITEREG(L2SS_LKUP_CPU_HASH_KEY(2), audHashKey[2]); /*CPU发起的Hash查表键值寄存器2，对应键值的bit[95:64]*/
    L2SS_WRITEREG(L2SS_LKUP_CPU_HASH_KEY(3), audHashKey[3]); /*CPU发起的Hash查表键值寄存器3，对应键值的bit[127:96]*/
    L2SS_WRITEREG(L2SS_LKUP_CPU_HASH_KEY(4), audHashKey[4]); /*CPU发起的Hash查表键值寄存器4，对应键值的bit[159:127]*/
    L2SS_WRITEREG(L2SS_LKUP_CPU_HASH_KEY(5), audHashKey[5]); /*CPU发起的Hash查表键值寄存器5，对应键值的bit[191:160]*/
    L2SS_WRITEREG(L2SS_LKUP_CPU_HASH_KEY(6), audHashKey[6]); /*CPU发起的Hash查表键值寄存器6，对应键值的bit[191:160]*/

    /*CPU写请求寄存器,硬件响应操作hash表项的操作*/
    L2SS_WRITEREG(L2SS_LKUP_CPU_HASH_REQ, udCpuHashReq);

    udResult = L2ssWaitRegBitSet(L2SS_LKUP_CPU_HASH_RESP, BIT8, 100000); // 5s  /*ads2dbg下改为100000，实际使用过程中为5000*/
    if (BSP_OK != udResult)
    {

        zte_printf_s("L2ss Waite Error\n");
        return (UINT32)BSP_ERROR;
    }

    udCpuHashResp = L2SS_READREG(L2SS_LKUP_CPU_HASH_RESP);
    udCpuHashResp &= BIT4;
    if (((L2SS_HASH_ADD == udOptype) && (BIT4 == udCpuHashResp) && (udHashKeyType != e_L2ssHashVlanType) && (udHashKeyType != e_L2ssHashTsnType)) /*hashb表可以不判断此项*/
        || ((L2SS_HASH_ADD != udOptype) && (BIT4 != udCpuHashResp)))
    {
        zte_printf_s("error,the udCpuHashResp is 0x%x\n", udCpuHashResp);
        return (UINT32)BSP_ERROR;
    }

    if (NULL != ptHashTableResp)
    {
        pudHashKeyResp = (UINT32 *)ptHashTableResp;
        switch (udHashKeyType)
        {
            case e_L2ssHashFmType:
            case e_L2ssHashMacType:
            {
                pudHashKeyResp[0] = L2SS_READREG(L2SS_LKUP_CPU_HASH_RESP_RSLT(3)); /*最高bit位,最低地址*/
                pudHashKeyResp[1] = L2SS_READREG(L2SS_LKUP_CPU_HASH_RESP_RSLT(2));
                pudHashKeyResp[2] = L2SS_READREG(L2SS_LKUP_CPU_HASH_RESP_RSLT(1));
                pudHashKeyResp[3] = L2SS_READREG(L2SS_LKUP_CPU_HASH_RESP_RSLT(0)); /*最低bit位,最高地址*/
                break;
            }
            case e_L2ssHashVlanType:
            {
                /* 获取Vlan特性表中表 */
                pudHashKeyTempResp = (UINT32 *)&tL2sslviprep;
                pudHashKeyTempResp[0] = L2SS_READREG(L2SS_LKUP_CPU_HASH_RESP_RSLT(4)); /*vlan索引表时，响应结果是vlan特性直接表的内容*/
                pudHashKeyTempResp[1] = L2SS_READREG(L2SS_LKUP_CPU_HASH_RESP_RSLT(3)); /*vlan索引表时，响应结果是vlan特性直接表的内容*/
                pudHashKeyTempResp[2] = L2SS_READREG(L2SS_LKUP_CPU_HASH_RESP_RSLT(2));
                pudHashKeyTempResp[3] = L2SS_READREG(L2SS_LKUP_CPU_HASH_RESP_RSLT(1));
                pudHashKeyTempResp[4] = L2SS_READREG(L2SS_LKUP_CPU_HASH_RESP_RSLT(0));

                /* hyt:获取Vlan索引表小表 */
                audTempTable[0] = audHashKey[1];
                audTempTable[1] = audHashKey[0];
                ptL2ssLvIdPre = (T_L2ssLvIdPrep *)&audTempTable[0];

                /* 产生vlan特性表+vlan索引表大表 */
                if (BSP_OK != L2ssLkuplviprepToLvlip(&tL2sslviprep, ptL2ssLvIdPre, (T_L2ssLvlip *)ptHashTableResp))
                {
                    return BSP_ERROR;
                }

                break;
            }
            case e_L2ssHashTsnType:
            {
                pudHashKeyResp[0] = L2SS_READREG(L2SS_LKUP_CPU_HASH_RESP_RSLT(1));
                pudHashKeyResp[1] = L2SS_READREG(L2SS_LKUP_CPU_HASH_RESP_RSLT(0));

                break;
            }
            default:
            {
                zte_printf_s("response hash table error!");
                return (UINT32)BSP_ERROR;
            }
        }
    }

    if ((udOptype == L2SS_HASH_ADD) && ((udHashKeyType == e_L2ssHashVlanType) /*hashb表添加关闭匹配修改使能*/
                                     || (udHashKeyType == e_L2ssHashTsnType)))
    {
        L2ssLkupCfgHashCpuAdd(0);
    }

    return (UINT32)BSP_OK;
}

/**********************************************************************
* 函数名称：L2ssLkupCpuLpmSearch
* 功能描述：CPU对LpM表查找操作
* 输入参数：
* 输出参数：
* 返 回 值：
* 其他说明：要求在配置前查找时，audLpmKey与其掩码BIT需要对应，其他为0
            避免误匹配
* 修改日期        版本号       修改人            修改内容
* ----------------------------------------------------------------------
************************************************************************/
UINT32 L2ssLkupCpuLpmSearch(UINT32 udKeytype, UINT32 audLpmKey[], void *pudLpmResp)
{
    UINT32 udCpuLpmReq = 0;
    UINT32 udLpmResp = 0;
    UINT32 udLpmKeyTemp[4] = {0};
    UINT32 *pudHashKey = NULL;

    UINT32 udResult = 0xffffffff;

    switch (udKeytype)
    {
        case e_LpmKeyIpv4L16:
        case e_LpmKeyIpv6L16:
        {
            udLpmKeyTemp[0] = audLpmKey[0];
            udLpmKeyTemp[1] = audLpmKey[1];
            udLpmKeyTemp[2] = audLpmKey[2];
            udLpmKeyTemp[3] = audLpmKey[3];
            break;
        }
        case e_LpmKeyIpv4L32:
        case e_LpmKeyExta:
        case e_LpmKeyIpv6L32:
        {
            udLpmKeyTemp[0] = audLpmKey[0];
            udLpmKeyTemp[1] = audLpmKey[1];
            udLpmKeyTemp[2] = audLpmKey[2];
            udLpmKeyTemp[3] = audLpmKey[3];
            break;
        }
        case e_LpmKeyExtb64:
        case e_LpmKeyIpv6L64:
        case e_LpmKeyExtbL64E:
        {
            udLpmKeyTemp[0] = audLpmKey[1];
            udLpmKeyTemp[1] = audLpmKey[0];
            udLpmKeyTemp[2] = audLpmKey[2];
            udLpmKeyTemp[3] = audLpmKey[3];
            break;
        }
        case e_LpmKeyIpv6L128:
        case e_LpmKeyExtbL128:
        case e_LpmKeyExtbL128E:
        {
            udLpmKeyTemp[0] = audLpmKey[3];
            udLpmKeyTemp[1] = audLpmKey[2];
            udLpmKeyTemp[2] = audLpmKey[1];
            udLpmKeyTemp[3] = audLpmKey[0];
            break;
        }
        default:
        {
            return (UINT32)-1;
            break;
        }
    }

    // 配置为添加指令
    udCpuLpmReq = (udKeytype << 4) | 0x01;

    /* hyt:告诉CPU需要需要查表的键值 */
    L2SS_WRITEREG(L2SS_LKUP_CPU_LPM_KEY(0), udLpmKeyTemp[0]); /*数组的低地址代表者键值的高位*/
    L2SS_WRITEREG(L2SS_LKUP_CPU_LPM_KEY(1), udLpmKeyTemp[1]);
    L2SS_WRITEREG(L2SS_LKUP_CPU_LPM_KEY(2), udLpmKeyTemp[2]);
    L2SS_WRITEREG(L2SS_LKUP_CPU_LPM_KEY(3), udLpmKeyTemp[3]);

    // CPU写请求寄存器
    L2SS_WRITEREG(L2SS_LKUP_CPU_LPM_REQ, udCpuLpmReq);

    udResult = L2ssWaitRegBitSet(L2SS_LKUP_CPU_LPM_RESP, BIT8, 5000); // 5s
    udLpmResp = L2SS_READREG(L2SS_LKUP_CPU_LPM_RESP);

    //if (g_udNtlSysTestFlag == 1)
    //{
    //zte_printf_s("the response is 0x%x\n", udLpmResp);
    //}

    if (0 != udResult)
    {
        return 0xffffffff;
    }
    if (0 == (udLpmResp & BIT4))
    {
        return 0xffffffff;
    }

    udResult = (udLpmResp >> 16) & 0xffff;
    if (NULL != pudLpmResp)
    {
        pudHashKey = (UINT32 *)pudLpmResp;
        pudHashKey[0] = L2SS_READREG(L2SS_LKUP_CPU_LPM_RESP_RSLT_1);
        pudHashKey[1] = L2SS_READREG(L2SS_LKUP_CPU_LPM_RESP_RSLT_0);
    }

    return udResult;
}

/**********************************************************************
* 函数名称：L2ssLkupCfgLpmEnable
* 功能描述：LPM表配置使能
* 输入参数：
* 输出参数：
* 返 回 值：
* 其他说明：
* 修改日期        版本号       修改人            修改内容
* ----------------------------------------------------------------------
************************************************************************/
UINT32 L2ssLkupCfgLpmEnable(VOID)
{
    UINT32 udResult = 0;

    // LKUP的直接表的SRAM 配置开关打开。
    L2SS_SETBITS(L2SS_LKUP_SRAM_CONFIG_EN, BIT0);
    // CPU申请访问LPM的SRAM
    L2SS_SETBITS(L2SS_LKUP_LPM_CPU_RDWR_REQ, BIT0);

    udResult = L2ssWaitRegBitSet(L2SS_LKUP_LPM_CPU_RDWR_RDY, BIT0, 5000); // 5s

    return udResult;
}

/**********************************************************************
* 函数名称：L2ssLkupCfgLpmDisable
* 功能描述：LPM表配置去使能
* 输入参数：
* 输出参数：
* 返 回 值：
* 其他说明：
* 修改日期        版本号       修改人            修改内容
************************************************************************/
UINT32 L2ssLkupCfgLpmDisable(VOID)
{
    // DTBL的SRAM-CPU访问申请寄存器
    L2SS_CLRBITS(L2SS_LKUP_LPM_CPU_RDWR_REQ, BIT0);
    // LKUP的直接表的SRAM 配置开关关闭。
    L2SS_CLRBITS(L2SS_LKUP_SRAM_CONFIG_EN, BIT0);

    return (UINT32)0;
}

/**********************************************************************
* 函数名称： L2ssLkupCfgLipapTable
* 功能描述：
* 输入参数：
* 输出参数：
* 返 回 值：
* 其他说明：
* 修改日期        版本号     修改人           修改内容
************************************************************************/
UINT32 L2ssLkupCfgLipapTable(UINT32 udBaseAddr, T_L2ssLpmIpAddr *ptLpmValue)
{
    UINT32 udKeyType     = 0;
    UINT32 udCfgTmp      = 0;
    UINT32 udTabLen      = 0;
    UINT32 udLoop        = 0;
    UINT32 *pudKey       = 0;
    UINT32 *pudMask      = 0;
    UINT32 audKeyMask[8] = {0};
    UINT32 *pudValue     = NULL;

    pudValue  = (UINT32 *)&(ptLpmValue->tLipapValue); /*sram表的数据，获取IP表的地址*/

    pudKey    = &(ptLpmValue->audKey[0]);
    pudMask   = &(ptLpmValue->audMask[0]);
    udKeyType = ptLpmValue->udKeyType;
    udCfgTmp  = (udKeyType << 4) | BIT0; /*LPM表的数据*/
    switch (udKeyType)
    {
        case e_LpmKeyIpv4L16:
        case e_LpmKeyIpv6L16:
        {
            udTabLen = 1; /* 一张表 键值为16bit    */
            break;
        }
        case e_LpmKeyIpv4L32:
        case e_LpmKeyExta:
        case e_LpmKeyIpv6L32:
        {
            udTabLen = 2; /* 两张表 键值为32bit    */
            break;
        }
        case e_LpmKeyExtb64:
        case e_LpmKeyIpv6L64:
        case e_LpmKeyExtbL64E:
        {
            udTabLen = 4;
            break;
        }
        case e_LpmKeyIpv6L128:
        case e_LpmKeyExtbL128:
        case e_LpmKeyExtbL128E:
        {
            udTabLen = 8;
            break;
        }
        default:
        {
            return -1;
            break;
        }
    }

    for (udLoop = 0; udLoop < udTabLen; udLoop++)
    {
        if ((0 == udLoop % 2) && (1 != udTabLen))
        {
            audKeyMask[udLoop] = (pudKey[udLoop / 2] & (0xffff << 16)) >> 16;
            audKeyMask[udLoop] |= pudMask[udLoop / 2] & (0xffff << 16);
        }
        else
        {
            audKeyMask[udLoop] = pudKey[udLoop / 2] & 0xffff;
            audKeyMask[udLoop] |= (pudMask[udLoop / 2] & 0xffff) << 16; /*udTabLen =1 时，只有一种情况，键值和掩码存在低16bit*/
        }
    }

    L2ssLkupCfgLpmEnable();
    L2SS_WRITEREG(L2SS_LKUP_LPM_SRAML_BASE_ADDR(udBaseAddr), pudValue[1]);
    L2SS_WRITEREG(L2SS_LKUP_LPM_SRAMH_BASE_ADDR(udBaseAddr), pudValue[0]);

    for (udLoop = 0; udLoop < udTabLen; udLoop++)
    {
        L2SS_WRITEREG(L2SS_LKUP_LPM_TCAML_BASE_ADDR(udBaseAddr + udLoop), audKeyMask[udLoop]);
        L2SS_WRITEREG(L2SS_LKUP_LPM_TCAMH_BASE_ADDR(udBaseAddr + udLoop), udCfgTmp); /*udBaseAddr为udTabLen字节对齐*/
    }

    L2ssLkupCfgLpmDisable();

    return (UINT32)0;
}

/**********************************************************************
* 函数名称：NtlL2ssLpmVlanSet
* 功能描述：
* 输入参数：此函数需要修改，IC4.0，看下是否启用 PKT_SEG_ID_VLD字段
* 输出参数：
* 返 回 值：
* 其他说明：
* 修改日期        版本号       修改人            修改内容
* ----------------------------------------------------------------------
* 2016/03/04       V1.0      Yaoziqiang            创建
************************************************************************/
UINT32 L2ssLpmVlanSet(T_L2ssLpmStruct *pLpmInfo, UINT32 udVlanId, UINT32 udTagActIdx, UINT32 udMapMode)
{
    UINT32 udLoop = 0;
    UINT32 udLpmTableId = 0;
    UINT32 udTagActProf = 0;
    UINT32 hashValid = 0;
 
    T_L2ssLpmIpAddr tLpmValue;
    T_L2ssLipap tLipapValue;
    T_L2ssLvtap tLvtap;

    zte_memset_s(&tLipapValue, sizeof(T_L2ssLipap), 0, sizeof(T_L2ssLipap));
    zte_memset_s(&tLpmValue, sizeof(T_L2ssLpmIpAddr), 0, sizeof(T_L2ssLpmIpAddr));
    zte_memset_s(&tLvtap, sizeof(T_L2ssLvtap), 0, sizeof(T_L2ssLvtap));
    tLvtap.usSotOdeiAct = 2;
    tLvtap.usSotOpriAct = 2;
    tLvtap.usSotOtagAct = 2;
    tLvtap.usSotPotagAct = 2;
    tLvtap.usUtOdeiAct = 2;
    tLvtap.usUtOpriAct = 2;
    tLvtap.usUtOtagAct = 2;

    /*如果标签行为表的指针是0，则需要重新申请，因为0为vid=0情况下的标签行为指针，两者为映射关系*/
    if (0 == udTagActIdx)
    {
        return (UINT32)-1;
    }

    udTagActProf = udTagActIdx;

    /* hyt:查LK_IP_ADDR_PREP表，获取直接表号 */
    udLpmTableId = L2ssLkupCpuLpmSearch(pLpmInfo->udKeyType, &(pLpmInfo->audKey[0]), (UINT32 *)&tLipapValue);
    /* Started by AICoder, pid:w15eawb56cl5f2a140310b7fb0a8e606c6240797 */
    if (0xffffffff != udLpmTableId) /*返回值不是0xffffffff,查到了LPM表了，不需要申请*/
    {
        zte_memcpy_s(&tLpmValue.tLipapValue, sizeof(T_L2ssLipap), &tLipapValue, sizeof(T_L2ssLipap));
    }
    /* Ended by AICoder, pid:w15eawb56cl5f2a140310b7fb0a8e606c6240797 */
    else
    {
        /* hyt:申请LPM指针 */
        udLpmTableId = L2ssLkupApplyLpmTableId(pLpmInfo->udKeyType); /*没有查到返回的udLpmTableId是0xffffffff,需要申请*/
        if (0xffffffff == udLpmTableId)
        {
            L2ssLkupReleaseLvtapTableId(udTagActProf);
            return (UINT32)-1;
        }
    }

    tLpmValue.tLipapValue.udTagActProf = udTagActProf;
    /* TAG_ACT */
    // L2ssLkupCfgLvtapTable(udTagActProf, &tLvtap);

    tLpmValue.udKeyType = pLpmInfo->udKeyType;
    for (udLoop = 0; udLoop < 4; udLoop++)
    {
        tLpmValue.audKey[udLoop] = pLpmInfo->audKey[udLoop];
        tLpmValue.audMask[udLoop] = pLpmInfo->audMask[udLoop];
    }
    tLpmValue.tLipapValue.udSipVlanValid = udMapMode & 0x1;
    tLpmValue.tLipapValue.udDipVlanValid = (udMapMode >> 1) & 0x1;
    tLpmValue.tLipapValue.udOvid = udVlanId;

    tLpmValue.tLipapValue.SEG_ID_VLD = 0;
    /*
        * Started by AICoder, pid:6a806t7e1b13f2114cb8084b70fc6b279f1454b4
        UINT32 segValid = 0;
        UINT32 segVal = 0;
        * Ended by AICoder, pid:6a806t7e1b13f2114cb8084b70fc6b279f1454b4
        if (1 == segValid)
        {
            //seg_vaild 有效的情况下，ExtA/B查表时，得到是SEG_ID addr_class_id
            tLpmValue.tLipapValue.ADDR_CLASS_ID = segVal;
        }
    */
    tLpmValue.tLipapValue.LAG_HASH_VALID = hashValid;
    /*
        * Started by AICoder, pid:a34700a191a1e4914df50846a05bfe14201144b8
        UINT32 hashIdx = 0;
        * Ended by AICoder, pid:a34700a191a1e4914df50846a05bfe14201144b8
        if (1 == hashValid) //if hashValid = 1，LAG_HASH[15] = 1, 则选择LAG_HASH[0:3]作为LAG_IDX
        {
            //seg_vaild 有效的情况下，ExtA/B查表时，得到是SEG_ID addr_class_id
            tLpmValue.tLipapValue.LAG_HASH_IDX = hashIdx;   //LAG_IDX 选择 LPTOVPP MAP表中的offset的位置
        }
    */
    /* hyt:建立直接表与LMP表的关系 */
    L2ssLkupCfgLipapTable(udLpmTableId, &tLpmValue); /*配置sram表，即LK_IP_ADDR_PREP表，LPM表和sram的表索引表是映射关系，查找到LPM表索引后自动映射到sram表索引*/
    return (UINT32)udLpmTableId;
}

UINT32 L2ssLvTapTblSet(UINT32 *pTblIdx)
{
    UINT32 udTagActProf = 0;
    T_L2ssLvtap tLvtap;

    zte_memset_s(&tLvtap, sizeof(T_L2ssLvtap), 0, sizeof(T_L2ssLvtap));
    tLvtap.usSotOdeiAct = 2;
    tLvtap.usSotOpriAct = 2;
    tLvtap.usSotOtagAct = 2;
    tLvtap.usSotPotagAct = 2;
    tLvtap.usUtOdeiAct = 2;
    tLvtap.usUtOpriAct = 2;
    tLvtap.usUtOtagAct = 2;

    udTagActProf = L2ssLkupApplyLvtapTableId();
    if (0 == udTagActProf)
    {
        return (UINT32)-1;
    }

    if (0 == L2ssLkupCfgLvtapTable(udTagActProf, &tLvtap))
    {
        *pTblIdx = udTagActProf;
        return 0;
    }

    return (UINT32)-1;
}

/**********************************************************************
* 函数名称：NtlL2ssCreatVlan
* 功能描述：创建VLAN特性表(包括输入输出特性)
* 输入参数：
* 输出参数：
* 返 回 值：
* 其他说明：
* 修改日期        版本号       修改人            修改内容
* ----------------------------------------------------------------------
************************************************************************/
UINT32 L2ssCreatVlan(UINT32 udVlanId, UINT32 udFid, UINT64 uddPortMap, UINT64 uddStPortMap)
{
    UINT32 udMcIdx       = 0;
    UINT32 udVcIdx       = 0;
    UINT32 udResult      = BSP_OK;
    UINT32 udVlanIdL     = 0;
    UINT32 udoffset      = 0;
    UINT32 udlagKeyType  = 0;
    UINT32 udLagMaskType = 0;

    T_L2ssLvlip tLvlip;
    T_L2ssLvlem tLvlem;

    /* hyt:获取要组播的基地址 */
    udMcIdx = L2ssLkupApplyLmcmcTableId();
    if (0 == udMcIdx)
    {
        zte_printf_s("failed,L2MC table apply overflow\n");
        return BSP_ERROR;
    }
    L2ssLkupCfgLmcmcTable(udMcIdx, uddPortMap); /*配置组播表项*/

    /* hyt:获取输出特性表的基地址 */
    udVcIdx = L2ssLkupApplyLvlemTableId();
    if (0 == udVcIdx)
    {
        L2ssLkupReleaseLmcmcTableId(udMcIdx);
        zte_printf_s("failed, Lvlem table apply overflow\n");
        return BSP_ERROR;
    }
    zte_memset_s(&tLvlem, sizeof(T_L2ssLvlem), 0, sizeof(T_L2ssLvlem));
    tLvlem.udPortBitmap = uddPortMap;
    tLvlem.udStPortBitmap = uddStPortMap;
    /*tLvlem.udStgLkEn = 0;*/
    tLvlem.udStgId = 0; /*todo:生成树组id*/
    L2ssLkupCfgLvlemTable(udVcIdx, &tLvlem);

    if (udVlanId >= 512)
    {
        zte_printf_s("failed,[%s]udVlanId'%d is over max 512 \n", __FUNCTION__, udVlanId);
        return BSP_ERROR;
    }
    g_acVidToVlanIdx[udVlanId] = L2ssLkupApplyLvIpTableId();
    udVlanIdL = udVlanId & BW2;
    zte_memset_s(&tLvlip, sizeof(T_L2ssLvlip), 0, sizeof(T_L2ssLvlip));

    tLvlip.ulKeyType = e_L2ssHashVlanType;
    tLvlip.ulKey = udVlanId >> 2;
    tLvlip.ulValid = 1;

    udoffset = udVlanIdL % 4;
    if ((udVlanId - udoffset) >= (512 - 3))
    {
        zte_printf_s("[%s]udVlanId - udoffset = %d over max vlanIdx 512 -3 \n", __FUNCTION__, udVlanId - udoffset);
        return BSP_ERROR;
    }
    tLvlip.ulValnIdx0 = g_acVidToVlanIdx[udVlanId - udoffset] | (g_acVidToVlanIdx[udVlanId + 1 - udoffset] << 9) | ((g_acVidToVlanIdx[udVlanId + 2 - udoffset] & BW2) << 18);
    tLvlip.ulValnIdx1 = (g_acVidToVlanIdx[udVlanId + 2 - udoffset] >> 2) | (g_acVidToVlanIdx[udVlanId + 3 - udoffset] << 7);

    tLvlip.ulVlanIdL = udVlanIdL;

    tLvlip.ulFidId0 = udFid & BW2;
    tLvlip.ulFidId1 = (udFid >> 2) & BW10;

    tLvlip.ulPortBitmap2 = (uddPortMap >> 33) & BW31; // bit[63:39] 25
    tLvlip.ulPortBitmap1 = (uddPortMap >> 1) & BW32;  // bit[38:7]  32
    tLvlip.ulPortBitmap0 = uddPortMap & BW1;          // bit[6:0]   7

    tLvlip.ulVlanClassId = udVcIdx;
    tLvlip.ulBcIdx = udMcIdx;
    tLvlip.ulUmcIdx = udMcIdx;
    tLvlip.ulUucIdx = udMcIdx;

    tLvlip.ulLagMaskType = udLagMaskType;

    tLvlip.ulLagKeyType1 = (udlagKeyType >> 1) & BW3;
    tLvlip.ulLagKeyType0 = udlagKeyType & BW1;

    udResult = L2ssLkupCpuHashaOp(L2SS_HASH_ADD, e_L2ssHashVlanType, (void *)&tLvlip, NULL);
    return udResult;
}

VOID l2ss_hw_cntp_en()
{
    UINT32 loop;
    for (loop = e_L2SS_ENG0; loop < e_L2SS_ENG_NUM; loop += 2)
    {
        L2SS_SETBITS(L2SS_PREP_CNT_START_EN(loop), BIT0);
        L2SS_SETBITS(L2SS_PREP_CNT_CTRL(loop), BIT0);
    }
    /*L2FM计数器使能的打开，bit6~bit8计数器使能比特位*/
    L2SS_SETBITS(L2SS_L2FM_CTRL, 0x1c0);

    /*L2MC计数器使能的打开 */
    L2SS_SETBITS(L2SS_L2MC_CNT_ENABLE, BW8);
    #if 0
    /*QMAN CNT 计数器使能,cnt的用法可以，后续再chekc下*/
    L2SS_WRITEREG(L2SS_QMAN_CNT_EN_CFG_C(1), BW32);
    L2SS_WRITEREG(L2SS_QMAN_CNT_EN_CFG_C(2), BW32);
    L2SS_WRITEREG(L2SS_QMAN_CNT_EN_CFG_C(3), BW32);

    L2SS_WRITEREG(L2SS_QMAN_NOR_CNT1_EN_CFG(0), BW32);
    L2SS_WRITEREG(L2SS_QMAN_NOR_CNT1_EN_CFG(2), BW32);

    L2SS_WRITEREG(L2SS_QMAN_TSN_CNT1_EN_CFG(0), BW32);
    L2SS_WRITEREG(L2SS_QMAN_TSN_CNT1_EN_CFG(1), BW32);

    L2SS_SETBITS(L2SS_QMAN_INCNT_FULL_STOP, BIT0);
    #endif
    /*PKTM的计数器使能*/
    L2SS_SETBITS(L2SS_PKTM_CNT_CTRL, BW2);

    /*BMAN的计数器使能*/
    L2SS_WRITEREG(L2SS_BMAN_CNT_EN, BW32);

    /*PARSE的计数器使能*/
    L2SS_WRITEREG(L2SS_PARS_CNT_EN, BW32);

    /*LKUP的计数器使能*/
    L2SS_SETBITS(L2SS_LKUP_CNT_START_EN, BW2);
}

UINT32 isL2ssPortHwValid(UINT32 port)
{
    /*1. l2ss硬件支持范围判断*/
    UINT64 uddPortMatch = (((UINT64)1) << port) & L2SS_VALID_PORT_MAP;
    if (!uddPortMatch)
    {
        return 0;
    }
    if (port >= L2SS_OUT_PORT_MIN && port <= L2SS_OUT_PORT_MAX) /*外端口*/
    {
        return 1;
    }
    if (port >= L2SS_INNER_PORT_MIN && port <= L2SS_INNER_PORT_MAX) /*内端口*/
    {
        return 1;
    }
    return 0;
}

UINT32 l2ssGetTrpgPortAddr(UINT32 port)
{
    UINT32 addr = 0;

    if (port < L2SS_TRXP32)
    {
        addr = L2SS_EPORT_BLOCK_ADDR + (port % L2SS_TRXP32) * L2SS_PORT_SPAN;
    }
    else
    {
        if (port < L2SS_TRXP44)
        {
            addr = L2SS_IPORT_BLOCK_ADDR + (port - L2SS_TRXP32) / 12 * L2SS_PORT_BLOCK_SPAN + ((port - L2SS_TRXP32) % 12) * L2SS_PORT_SPAN;
        }
        else
        {
            addr = L2SS_IPORT_BLOCK_ADDR + 0x60000 + (port - L2SS_TRXP44) * L2SS_PORT_SPAN;
        }
    }

    return addr;
}

void L2ssPortEnable(UINT32 port)
{
    UINT32 addr;

    addr = l2ssGetTrpgPortAddr(port);
    L2SS_SETBITS((addr + L2SS_PORT_LIMIT_EN), BIT1);
    L2SS_WRITEREG((addr + L2SS_PORT_CTRL), 0x13);

    zte_printf_s("%s port[%d] succ\n", __FUNCTION__, port);
}

void L2ssPortDisable(UINT32 port)
{
    UINT32 addr;
    UINT32 event;

    addr = l2ssGetTrpgPortAddr(port);

    L2SS_CLRBITS((addr + L2SS_PORT_LIMIT_EN), BIT1);
    L2SS_CLRBITS((addr + L2SS_PORT_CTRL), BW2);

    l2ssDelay(200);

    event = L2SS_READREG((addr + L2SS_PORT_ALARM_EVENT));
    if ((0 == (event & BIT6)) && (0 == (event & BIT4)) &&
        (0 == (event & BIT2)))
    {
        zte_printf_s("%s l2ss port[%d] failed\n", __FUNCTION__, port);
        return;
    }

    zte_printf_s("%s l2ss port[%d] succ\n", __FUNCTION__, port);
}

void L2ssPortLoop(UINT32 port, UINT32 loop)
{
    UINT32 addr;

    addr = l2ssGetTrpgPortAddr(port);

    if (0 == loop)
    {
        L2SS_CLRBITS((addr + L2SS_PORT_DEBUG), BIT4);
        L2SS_CLRBITS((addr + L2SS_PORT_DEBUG), BIT7);
    }
    else
    {
        L2SS_SETBITS((addr + L2SS_PORT_DEBUG), BIT4 | BIT7);
    }
    l2ssDelay(200);

    zte_printf_s("%s l2ss port[%d] succ\n", __FUNCTION__, port);
}

UINT32 L2ssGetXmacPortaddr(UINT32 port) /*l2ss基地址*/
{
    UINT32 xmacOffset = 0x40000; /*第一个xmac相对l2ss偏移地址0x40000,*/
    UINT32 xmacStep   = 0x1000;    /* 每个端口相差0x1000 */
    UINT32 addr;

    if (port >= L2SS_MAX_EPORT_ID)
    {
        return 0;
    }
    addr = L2SS_B1_ADDR_OFFSET + (port / 4) * xmacOffset + (port % 4) * xmacStep;

    return addr;
}

UINT32 L2ssXmacEnable(UINT32 port)
{
    UINT32 addr;

    addr = L2ssGetXmacPortaddr(port);
    if (!addr)
    {
        return BSP_ERROR;
    }
    addr += XMAC_MAC_CTRL;

    L2SS_SETBITS(addr, XMAC_MAC_TX_EN_CFG_MASK);
    L2SS_SETBITS(addr, XMAC_MAC_RCV_EN_CFG_MASK);
    L2SS_SETBITS(addr, XMAC_MAC_STATIC_EN_CFG_MASK);

    zte_printf_s("%s xmac[%d] succ\n", __FUNCTION__, port);
    return BSP_OK;
}

UINT32 L2ssXmacDisable(UINT32 port)
{
    UINT32 addr;

    addr = L2ssGetXmacPortaddr(port);
    if (!addr)
    {
        return BSP_ERROR;
    }
    addr += XMAC_MAC_CTRL;

    L2SS_CLRBITS(addr, XMAC_MAC_TX_EN_CFG_MASK);
    L2SS_CLRBITS(addr, XMAC_MAC_RCV_EN_CFG_MASK);
    zte_printf_s("%s xmac[%d] succ\n", __FUNCTION__, port);

    return BSP_OK;
}

UINT32 L2ssXmacDisableAllPort()
{
    UINT32 port;

    for (port = 0; port < L2SS_MAX_EPORT_ID; port++)
    {
        if (!isL2ssPortHwValid(port))
        {
            continue;
        }
        L2ssXmacDisable(port);
    }

    return BSP_OK;
}

UINT32 L2ssMacRxPathDelay(UINT32 port, UINT32 val)
{
    UINT32 addr = 0;

    addr = L2ssGetXmacPortaddr(port);
    if (!addr)
    {
        return BSP_ERROR;
    }
    addr += XMAC_PCS_RPD;

    L2SS_SETBITS(addr, val);

    return BSP_OK;
}

UINT32 L2ssMacTxPathDelay(UINT32 port, UINT32 val)
{
    UINT32 addr = 0;

    addr = L2ssGetXmacPortaddr(port);
    if (!addr)
    {
        return BSP_ERROR;
    }
    addr += XMAC_PCS_TPD;

    L2SS_SETBITS(addr, val);

    return BSP_OK;
}


UINT32 L2ssmacCfgTxIpg(UINT32 port,UINT32 udCfgVal)
{
    UINT32 addr;

    addr = L2ssGetXmacPortaddr(port);
    if (!addr)
    {
        return BSP_ERROR;
    }
    addr += XMAC_TX_IPG_LEN;
    
    L2SS_WRITEREG(addr, udCfgVal);
    return BSP_OK;
}

UINT32 L2ssXmacSetSpeed(UINT32 port, UINT32 speed)
{
    UINT32 addr;
    UINT32 val;

    addr = L2ssGetXmacPortaddr(port);
    if (!addr)
    {
        return BSP_ERROR;
    }
    addr += XMAC_MAC_CFG;

    val = L2SS_READREG(addr);
    val = BIT_FIELD_MASK_CFG(val, speed, XMAC_MAC_SPEED_CFG_POS, XMAC_MAC_SPEED_CFG_LEN);

    L2SS_WRITEREG(addr, val);
    switch (speed)
    {
        case e_XMAC_SPEED_5G:
        {
            L2ssMacRxPathDelay(port, NTL_PATH_DELAY_10GE_RX_NO_FEC);
            L2ssMacTxPathDelay(port, NTL_PATH_DELAY_10GE_TX_NO_FEC);
            break;
        }

        case e_XMAC_SPEED_50G:
        {
            L2ssMacRxPathDelay(port, NTL_PATH_DELAY_2_5G_RX);
            L2ssMacTxPathDelay(port, NTL_PATH_DELAY_2_5G_TX);
            break;
        }

        case e_XMAC_SPEED_25G:
        {
            L2ssMacRxPathDelay(port, NTL_PATH_DELAY_1000M_RX);
            L2ssMacTxPathDelay(port, NTL_PATH_DELAY_1000M_TX);
            break;
        }

        case e_XMAC_SPEED_10G:
        {
            L2ssMacRxPathDelay(port, NTL_PATH_DELAY_10GE_RX_NO_FEC);
            L2ssMacTxPathDelay(port, NTL_PATH_DELAY_10GE_TX_NO_FEC);
            break;
        }

        case e_XMAC_SPEED_2_5G:
        {
            L2ssMacRxPathDelay(port, NTL_PATH_DELAY_2_5G_RX);
            L2ssMacTxPathDelay(port, NTL_PATH_DELAY_2_5G_TX);
            break;
        }

        case e_XMAC_SPEED_1G:
        {
            L2ssMacRxPathDelay(port, NTL_PATH_DELAY_1000M_RX);
            L2ssMacTxPathDelay(port, NTL_PATH_DELAY_1000M_TX);
            break;
        }

        case e_XMAC_SPEED_100M:
        {
            L2ssMacRxPathDelay(port, NTL_PATH_DELAY_100M_RX);
            L2ssMacTxPathDelay(port, NTL_PATH_DELAY_100M_TX);
            break;
        }

        case e_XMAC_SPEED_10M:
        {
            L2ssMacRxPathDelay(port, NTL_PATH_DELAY_10M_RX);
            L2ssMacTxPathDelay(port, NTL_PATH_DELAY_10M_TX);
            break;
        }

        default:
        {
            L2ssMacRxPathDelay(port, NTL_PATH_DELAY_1000M_RX);
            L2ssMacTxPathDelay(port, NTL_PATH_DELAY_1000M_TX);
        }
    }

    zte_printf_s("mac_cfg_Speed speed %d\n ", speed);

    return BSP_OK;
}

UINT32 L2ssMacCfgMru(UINT32 port, UINT32 udCfgVal)
{
    UINT32 addr = 0;

    addr = L2ssGetXmacPortaddr(port);
    if (!addr)
    {
        return BSP_ERROR;
    }
    addr += XMAC_MAX_FRM_LEN;

    L2SS_CLRBITS(addr, XMAC_MAC_MRU_CFG_MASK);
    L2SS_SETBITS(addr, udCfgVal << XMAC_MAC_MRU_CFG_POS);

    return BSP_OK;
}

UINT32 L2ssMacCfgMtu(UINT32 port, UINT32 udCfgVal)
{
    UINT32 addr = 0;

    addr = L2ssGetXmacPortaddr(port);
    if (!addr)
    {
        return BSP_ERROR;
    }
    addr += XMAC_MAX_FRM_LEN;

    L2SS_CLRBITS(addr, XMAC_MAC_MTU_CFG_MASK);
    L2SS_SETBITS(addr, udCfgVal << XMAC_MAC_MTU_CFG_POS);

    return BSP_OK;
}

UINT32 L2ssMacTxFlowCtrl(UINT32 port, UINT32 val)
{
    UINT32 addr = 0;

    addr = L2ssGetXmacPortaddr(port);
    if (!addr)
    {
        return BSP_ERROR;
    }
    addr += XMAC_MAC_CFG;

    L2SS_CLRBITS(addr, XMAC_MAC_TX_FLOW_EN_MASK);
    L2SS_SETBITS(addr, val << XMAC_MAC_TX_FLOW_EN_POS);

    return BSP_OK;
}

UINT32 L2ssMacRxFlowCtrl(UINT32 port, UINT32 val)
{
    UINT32 addr = 0;

    addr = L2ssGetXmacPortaddr(port);
    if (!addr)
    {
        return BSP_ERROR;
    }
    addr += XMAC_MAC_CFG;

    L2SS_CLRBITS(addr, XMAC_MAC_RCV_FLOW_EN_MASK);
    L2SS_SETBITS(addr, val << XMAC_MAC_RCV_FLOW_EN_POS);

    return BSP_OK;
}

UINT32 L2ssMacTxFcsCtrl(UINT32 port, UINT32 val)
{
    UINT32 addr;

    addr = L2ssGetXmacPortaddr(port);
    if (!addr)
    {
        return BSP_ERROR;
    }
    addr += XMAC_MAC_CFG;

    L2SS_CLRBITS(addr, XMAC_MAC_ADD_FCS_EN_FOR_TX_MASK);
    L2SS_SETBITS(addr, val << XMAC_MAC_ADD_FCS_EN_FOR_TX_POS);

    return BSP_OK;
}

UINT32 L2ssMacRxFcsCtrl(UINT32 port, UINT32 val)
{
    UINT32 addr = 0;

    addr = L2ssGetXmacPortaddr(port);
    if (!addr)
    {
        return BSP_ERROR;
    }
    addr += XMAC_MAC_CFG;

    L2SS_CLRBITS(addr, XMAC_MAC_FORWARD_FCS_EN_FOR_RCV_MASK);
    L2SS_SETBITS(addr, val << XMAC_MAC_FORWARD_FCS_EN_FOR_RCV_POS);

    return BSP_OK;
}

UINT32 L2ssMacPadCtrl(UINT32 port, UINT32 val)
{
    UINT32 addr = 0;

    addr = L2ssGetXmacPortaddr(port);
    if (!addr)
    {
        return BSP_ERROR;
    }
    addr += XMAC_MAC_CFG;
    L2SS_CLRBITS(addr, XMAC_MAC_ADD_PAD_EN_FOR_TX_MASK);
    L2SS_SETBITS(addr, val << XMAC_MAC_ADD_PAD_EN_FOR_TX_POS);

    return BSP_OK;
}

UINT32 L2ssMacCntpCtrl(UINT32 port, UINT32 val)
{
    UINT32 addr = 0;

    addr = L2ssGetXmacPortaddr(port);
    if (!addr)
    {
        return BSP_ERROR;
    }
    addr += XMAC_MAC_CTRL;

    L2SS_CLRBITS(addr, XMAC_MAC_STATIC_EN_CFG_MASK);
    L2SS_SETBITS(addr, val << XMAC_MAC_STATIC_EN_CFG_POS);

    return BSP_OK;
}

UINT32 L2sssMacSetInterfaceMode(UINT32 eport, UINT32 speed)
{
    UINT32 macspeed;

    switch (speed)
    {
        case SPEED_10:
        case SPEED_100:
        {
            macspeed = e_XMAC_SPEED_100M;
            break;
        }
        case SPEED_1000:
        {
            macspeed = e_XMAC_SPEED_1G;
            break;
        }
        default:
        {
            macspeed = e_XMAC_SPEED_1G;
            break;
        }
    }

    L2ssXmacSetSpeed(eport, macspeed);
    return BSP_OK;
}





UINT32 L2ssMacInit(UINT32 eport)
{
    UINT32 port = 0;

    for (port = 0; port < L2SS_MAX_EPORT_ID; port++)
    {
        if (1 != ((eport >> port) & 0x01))
        {
            continue;
        }
        L2ssMacTxFcsCtrl(port, 1);
        L2ssMacRxFcsCtrl(port, 0);

        L2ssMacTxFlowCtrl(port, 1);
        L2ssMacRxFlowCtrl(port, 1);

        L2ssMacCfgMru(port, MAX_RXBUF_LEN);
        L2ssMacCfgMtu(port, MAX_RXBUF_LEN);

        L2ssMacPadCtrl(port, 1);
        L2ssMacCntpCtrl(port, 1);

        L2sssMacSetInterfaceMode(port, SPEED_100);
        zte_printf_s("xmacInit Mac[%d]End! \n", port);
    }

    return BSP_OK;
}



UINT32 L2ssCpuAgentGetPortAddr(UINT32 port)
{
    UINT32 addr;

    if (port <= L2SS_TRXP32)
    {
        addr = L2SS_CFGI_ID_B3A_ADDR + CFGI_AGENCY_OFFSET;
    }
    else if ((port >= L2SS_TRXP42) && (port <= L2SS_TRXP46))
    {
        addr = L2SS_B3B_ADDR_OFFSET + 0x00010000 + (port - L2SS_TRXP42) * 0x4000;
    }
    else /*预留地址扩展*/
    {
        addr = L2SS_CFGI_ID_B3A_ADDR;
    }

    return addr;
}

/*释放复位*/
UINT32 L2ssCpuAgentRlsPort(UINT32 port)
{
    UINT32 addr;

    addr = L2ssCpuAgentGetPortAddr(port);

    L2SS_WRITEREG(addr + L2SS_CTRL_TRXP_RST, 0);
    return BSP_OK;
}

/*复位*/
UINT32 L2ssCpuAgentRstPort(UINT32 port)
{
    UINT32 addr;

    addr = L2ssCpuAgentGetPortAddr(port);

    L2SS_WRITEREG(addr + L2SS_CTRL_TRXP_RST, 1);
    return BSP_OK;
}

UINT32 L2ssCpuAgentByteOrder(UINT32 port, UINT32 byte_order)
{
    UINT32 rd_order_addr;
    UINT32 wr_order_addr;

    if (port <= L2SS_AGENT_PORT0)
    {
        rd_order_addr = L2SS_TRXP_R_ORDER;
        wr_order_addr = L2SS_TRXP_W_ORDER;
    }
    else if ((port >= L2SS_AGENT_PORT1) && (port < MAX_AGENT_PORT_IDX))
    {
        rd_order_addr = L2SS_TRXP_R_ORDER + (port - L2SS_AGENT_PORT1 + 2) * 256;
        wr_order_addr = L2SS_TRXP_W_ORDER + (port - L2SS_AGENT_PORT1 + 2) * 256;
    }
    else /*预留地址扩展*/
    {
        zte_printf_s("l2ss_set_agentport_axim_bus_order failed port[%d]\n", port);
        return -1;
    }

    /*
    zte_printf_s("%s rd addr[0x%08x]\n",__FUNCTION__,rd_order_addr);
    zte_printf_s("%s wr addr[0x%08x]\n",__FUNCTION__,wr_order_addr);
    */

    L2SS_WRITEREG(rd_order_addr, byte_order);
    L2SS_WRITEREG(wr_order_addr, byte_order);
    return 0;
}

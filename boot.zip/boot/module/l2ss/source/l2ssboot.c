/*****************************************************************************
* 版权所有(C) 2010, ZTE Corp. RRU Bsp Platform
*----------------------------------------------------------------------------
* 模 块 名 : BSP
* 文件名称 : dpdichal.c
* 文件标识 : {[N/A]}
* 内容摘要 : 实现dpdic的加速器配置
* 注意事项 : 无
* 作    者 : 郭勇
* 创建日期 : 2019-04-08
* 当前版本 : Ver1.0
*----------------------------------------------------------------------------
* 变更记录 :
*
* $记录1
* 变 更 单: $0000000(N/A)
* 责 任 人: 耿佳佳
* 修改日戳: 2015-10-22 08:28:34
* 变更说明: 创建文件
*
*----------------------------------------------------------------------------
*/

/* 标准库头文件 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "bsppub.h"
#include "bspcomm.h"
#include "l2ssboot.h"
#include "l2sshw.h"
#ifdef CONFIG_ZX211412
#include "zx211412boot.h"
#elif CONFIG_ZX211413
#include "zx211413boot.h"
#endif
extern UINT8 g_icChipId;

/* Started by AICoder, pid:if9b75acd8m422714a030820a0cd04379de53ae6 */
T_BspHalAdaptSerdesRxCfg s_sboardAdaptSerdesRxCfg[] = {
     { -24, 24, 0, 4 },
     { -24, 24, 0, 4 },
     { -24, 24, 0, 4 },
     { -24, 24, 0, 4 },
};

static T_BspHalAdaptPcsCfg s_sboardEcpriPcsCfg[] = {

     { 0, OPTPCS_ETH,  OPTPCS_BIND_MODE_4T1X, OPTPCS_PORT_MODE_1X, OPTPCS_ETH_1G_2P5G_10B, OPTPCS_FEC_TYPE_BYPASS, OPTPCS_PCS_GEAR_WIDTH_32B ,0, 0, 0},
     { 1, OPTPCS_ETH,  OPTPCS_BIND_MODE_4T1X, OPTPCS_PORT_MODE_1X, OPTPCS_ETH_1G_2P5G_10B, OPTPCS_FEC_TYPE_BYPASS, OPTPCS_PCS_GEAR_WIDTH_32B ,0, 0, 0},
     { 2, OPTPCS_ETH,  OPTPCS_BIND_MODE_4T1X, OPTPCS_PORT_MODE_1X, OPTPCS_ETH_1G_2P5G_10B, OPTPCS_FEC_TYPE_BYPASS, OPTPCS_PCS_GEAR_WIDTH_32B ,0, 0, 0},
     { 3, OPTPCS_ETH,  OPTPCS_BIND_MODE_4T1X, OPTPCS_PORT_MODE_1X, OPTPCS_ETH_1G_2P5G_10B, OPTPCS_FEC_TYPE_BYPASS, OPTPCS_PCS_GEAR_WIDTH_32B ,0, 0, 0},
};

static T_SERDES_PARAM s_serdesPara_1G[] =
{
    {SERDES_ID_0, SERDES_LANE_0, SERDES_RATE_1G25, 5.04,  1, 0, 0, 0, 0, 0},
    {SERDES_ID_0, SERDES_LANE_1, SERDES_RATE_1G25, 25,  1, 0, 0, 0, 0, 0},
    {SERDES_ID_0, SERDES_LANE_2, SERDES_RATE_1G25, 5.04,  1, 0, 0, 0, 0, 0},
    {SERDES_ID_0, SERDES_LANE_3, SERDES_RATE_1G25, 25,  1, 0, 0, 0, 0, 0},
};

T_BspHalAdaptNtlPortCfg  g_atBoardXmacPortCfg[] =
{
    {e_NTL_XMAC_PORT_0, e_NTL_FRONT_BOARD,  e_NTL_SPEED_1000M,e_NTL_XMAC_FEC_BYPASS},
    {e_NTL_XMAC_PORT_1, e_NTL_FRONT_BOARD,  e_NTL_SPEED_1000M,e_NTL_XMAC_FEC_BYPASS},
    {e_NTL_XMAC_PORT_2, e_NTL_FRONT_BOARD,  e_NTL_SPEED_1000M,e_NTL_XMAC_FEC_BYPASS},
    {e_NTL_XMAC_PORT_3, e_NTL_FRONT_BOARD,  e_NTL_SPEED_1000M,e_NTL_XMAC_FEC_BYPASS},
};

T_BspHalAdaptNtlTrxpCfg g_atBoardTrxpModeCfg[] =
{
    {e_TRXP_PORT_1X,e_TRXP_PORT_1X,e_TRXP_PORT_1X,e_TRXP_PORT_1X},
    {e_TRXP_PORT_1X,e_TRXP_PORT_1X,e_TRXP_PORT_1X,e_TRXP_PORT_1X},
};
/* Ended by AICoder, pid:if9b75acd8m422714a030820a0cd04379de53ae6 */

#if 0
T_NTLDrvParam gtBootNtlDrviParam = {0};

T_NtlPortCfg g_atBootXmacPortCfg[] =
{
    #ifdef _DPDIC3_ADS
    {e_XMAC_PORT_8, e_NTL_FRONT_BOARD,  e_XMAC_SPEED_1G},
    #else
    {e_XMAC_PORT_10, e_NTL_FRONT_BOARD,  e_XMAC_SPEED_1G},/*PCS10-11端口是速率是5G以下，连接的GMII通道*/
    {e_XMAC_PORT_11, e_NTL_FRONT_BOARD,  e_XMAC_SPEED_1G},
    #endif

};


/* TRPG 端口组全局配置，20个外端口，5组TRPG */
T_TRPG_GROUP_MODE_CFG g_atBootTrxpModeCfg[MAX_TRPG_MODE_NUM] =
{
    {e_TRXP_PORT_1X,e_TRXP_PORT_1X,e_TRXP_PORT_1X,e_TRXP_PORT_1X},
    {e_TRXP_PORT_1X,e_TRXP_PORT_1X,e_TRXP_PORT_1X,e_TRXP_PORT_1X},
    {e_TRXP_PORT_1X,e_TRXP_PORT_1X,e_TRXP_PORT_1X,e_TRXP_PORT_1X},
    {e_TRXP_PORT_1X,e_TRXP_PORT_1X,e_TRXP_PORT_1X,e_TRXP_PORT_1X},
    {e_TRXP_PORT_1X,e_TRXP_PORT_1X,e_TRXP_PORT_1X,e_TRXP_PORT_1X},
};


/**************************************************************************
函数名称:  NaccXmacConfigInit(*)
功能描述:  单板下BTTL XMAC 参数初始化
输入参数:  无
输出参数:  无
返 回 值:  BSP_OK /  RETURN_ERROR
其它说明：
修改日期      版本号      修改人          修改内容
-----------------------------------------------------------------------
2013-12-9      V1.0                     创建
**************************************************************************/
UINT32 BootXmacConfigInit(T_XmacParamStruct *pXmacDrvParamArry)
{
    UINT8 macAddr[6] ={0x40,0x00,0xc0,0xfe,0x01,0x5}; /*暂时先写死*/
    UINT32 idx = 0;
    UINT32 macMaxNum = 0;
    UINT32 macId = 0;
    T_XmacDrvParam *pXmacDrvParam = NULL;

    INPUT_POINTER_CHECK(pXmacDrvParamArry);
    #if 0
    BspGetCtrlNetMac(aucMacAddr);
    for(idx = 0; idx < 6; idx++)
    {
        aucMacAddr[idx] = aucMacAddrTemp[5-idx];
    }
    #endif
    macMaxNum = sizeof(g_atBootXmacPortCfg)/sizeof(g_atBootXmacPortCfg[0]);

    for(idx=0; idx<macMaxNum; idx++)
    {
        if (!isXmacPortHwValid(idx))
        {
            continue;
        }
        macId = g_atBootXmacPortCfg[idx].udPortId;
        pXmacDrvParam = &(pXmacDrvParamArry->atXmacDrvParam[macId]);
        pXmacDrvParam->bEnable = 1;
        pXmacDrvParam->bReplaceSrcMac = 0;
        pXmacDrvParam->bTxAddPadEn = 1;
        pXmacDrvParam->eMacId = macId;
        pXmacDrvParam->ePortSpeed = g_atBootXmacPortCfg[idx].eSpeed;
        pXmacDrvParam->udMruVlaue = NTL_XMAC_MRU;
        pXmacDrvParam->udMtuVlaue = NTL_XMAC_TX_MAX_LEN;
        pXmacDrvParam->b1588RcvCtl = 0; /*暂时先关闭1588的功能*/
        pXmacDrvParam->b1588TxCtl = 0;  /*暂时先关闭1588的功能*/

        switch(pXmacDrvParam->ePortSpeed)
        {
            case e_XMAC_SPEED_10G:
            {
                pXmacDrvParam->udPcsRcvPathDelay = NTL_PATH_DELAY_10GE_RX_NO_FEC;
                pXmacDrvParam->udPcsTxPathDelay =  NTL_PATH_DELAY_10GE_TX_NO_FEC;
                break;
            }
            case e_XMAC_SPEED_2_5G:
            {
                pXmacDrvParam->udPcsRcvPathDelay = NTL_PATH_DELAY_2_5G_RX;
                pXmacDrvParam->udPcsTxPathDelay =  NTL_PATH_DELAY_2_5G_TX;
                break;
            }
            case e_XMAC_SPEED_1G:
            {
                pXmacDrvParam->udPcsRcvPathDelay = NTL_PATH_DELAY_1000M_RX;
                pXmacDrvParam->udPcsTxPathDelay =  NTL_PATH_DELAY_1000M_TX;
                break;
            }
            case e_XMAC_SPEED_100M:
            {
                pXmacDrvParam->udPcsRcvPathDelay = NTL_PATH_DELAY_100M_RX;
                pXmacDrvParam->udPcsTxPathDelay =  NTL_PATH_DELAY_100M_TX;
                break;
            }
            case e_XMAC_SPEED_10M:
            {
                pXmacDrvParam->udPcsRcvPathDelay = NTL_PATH_DELAY_10M_RX;
                pXmacDrvParam->udPcsTxPathDelay =  NTL_PATH_DELAY_10M_TX;
                break;
            }
            default:
            {
                pXmacDrvParam->udPcsRcvPathDelay = NTL_PATH_DELAY_10GE_RX_NO_FEC;
                pXmacDrvParam->udPcsTxPathDelay =  NTL_PATH_DELAY_10GE_RX_NO_FEC;
            }
        }

        zte_memcpy_s(pXmacDrvParam->aucMacAddr, 6, macAddr, 6);
    }

    return BSP_OK;
}




/**********************************************************************
* 函数名称： L2ssConfigInit
* 功能描述：
* 输入参数：
* 输出参数：
* 返 回 值：
* 其他说明：
* 修改日期        版本号     修改人           修改内容
* ----------------------------------------------------------------------
************************************************************************/
UINT32 BootL2ssConfigInit(T_L2ssDrvParam *ptL2ssDrvParam)
{
    INPUT_POINTER_CHECK(ptL2ssDrvParam);

    ptL2ssDrvParam->bIsStart = 1;

    /*L2SS的parse相关配置*/
    ptL2ssDrvParam->tParseBaseDrvParam.udParseEngId            = e_L2SS_ENG0;  //ads阶段parse引擎的设置都是进入ENG0
    ptL2ssDrvParam->tParseBaseDrvParam.udAnalyLevel            = 5;
    ptL2ssDrvParam->tParseBaseDrvParam.udGp0Thrd               = 0x500;  /*需要确认配置*/
    ptL2ssDrvParam->tParseBaseDrvParam.udParseCpuEthType       = 0xaa53;
    ptL2ssDrvParam->udPktmCpuEthType                           = 0xaa54;
    ptL2ssDrvParam->udTrxpPauseEn                              = BW3;
    ptL2ssDrvParam->uddPortEnableBitmap                        = (UINT64)L2SS_VALID_PORT_MAP;

    /* trxp端口模式配置表 */
    ptL2ssDrvParam->ptL2ssTrpgModeParam                        = (T_TRPG_GROUP_MODE_CFG *)&g_atBootTrxpModeCfg;


    /*L2SS的qman流控和门限的相关配置*/
    ptL2ssDrvParam->tFlowBaseDrvParam.udQmanOcMacTime          = L2SS_OC_MAC_TIME;
    ptL2ssDrvParam->tFlowBaseDrvParam.udQmanLpMacTime          = L2SS_LP_MAC_TIME;
    ptL2ssDrvParam->tFlowBaseDrvParam.udQmanShareThrd          = 4096;
    ptL2ssDrvParam->tFlowBaseDrvParam.udQmanMinLimit           = 0x1f;
    ptL2ssDrvParam->tFlowBaseDrvParam.udQmanThrdEn             = L2SS_QMAN_DLP_QE_THRD_EN;
    ptL2ssDrvParam->tFlowBaseDrvParam.udQmanKLevel             = 3;
    ptL2ssDrvParam->tFlowBaseDrvParam.eSpeedType               = e_L2ssSpeed_50G;

    /*分流配置,ads调试阶段分流配置为默认关闭，正式版本使用时打开分流配置*/
    // ptL2ssDrvParam->tL2ssPktShuntDrvParam.bIsStart          = 1;
    #if 0
    ptL2ssDrvParam->tL2ssPktShuntDrvParam.bIsStart             = FALSE;           //TRUE;
    ptL2ssDrvParam->tL2ssPktShuntDrvParam.udPktShuntType       = e_NTL_SHUNT_IP;
    ptL2ssDrvParam->tL2ssPktShuntDrvParam.uddBroadPortMap      = 0x00000ffe003f0000;   //广播端口
    ptL2ssDrvParam->tL2ssPktShuntDrvParam.uddPktmOutputPortMap = 0x00000ffe003f0000;   //PKTM输出端口
    ptL2ssDrvParam->tL2ssPktShuntDrvParam.udMapMode            = 0;      //初始化时映射模式使能是0
    ptL2ssDrvParam->tL2ssPktShuntDrvParam.udMapPri             = 0;       //端口映射的优先级为0
    ptL2ssDrvParam->tL2ssPktShuntDrvParam.udVtagSlpMap         = 0;   /*使用本表中的OVID字段作为映射结果*/
    #endif
    //  BspGetCtrlNetMac(ptL2ssDrvParam->tL2ssPktShuntDrvParam.aucMac);


    /* trxp端口打开配置，ads阶段的端口的打开配置用全局变量控制*/
    ptL2ssDrvParam->uddPortEnableBitmap = 0x0;
    /* l2ss配置使能 */
    ptL2ssDrvParam->bIsStart = TRUE;

    return BSP_OK;
    // NtlL2ssInit(&tL2ssDrvParam);
}


/**************************************************************************
函数名称:  NtlCfgParaInit
功能描述:  Ntl各个子系统模块参数的初始化
输入参数:
输出参数:  无
返 回 值:  BSP_OK /  RETURN_ERROR
其它说明：

修改日期      版本号      修改人          修改内容
-----------------------------------------------------------------------
**************************************************************************/
UINT32 BootNtlCfgParaInit(T_NTLDrvParam *ptNtlDrviParam)
{
    UINT32 ret = 0;

    INPUT_POINTER_CHECK(ptNtlDrviParam);

    ret = BootXmacConfigInit(&(ptNtlDrviParam->xmacDrvParam));
    if (BSP_OK != ret)
    {
        dbgErr("NaccXmacConfigInit failed! \n");
        return BSP_ERROR;
    }

    ret = BootL2ssConfigInit(&(ptNtlDrviParam->l2ssDrvParam));
    if (BSP_OK != ret)
    {
        dbgErr("L2ssConfigInit failed! \n");
        return BSP_ERROR;
    }

    /*单板传进来的其他参数，比如mac，等可以放到下面继续初始化*/

    return BSP_OK;

}

/**************************************************************************
函数名称:  NtlL2ssRegMap
功能描述:  NTL寄存器空间映射
输入参数:  ptNtlDrvParam 参见T_NTLDrvParam
输出参数:  无
返 回 值:  BSP_OK /  RETURN_ERROR
其它说明：
修改日期      版本号      修改人          修改内容
-----------------------------------------------------------------------
2017-11-22      V1.0     shejingui          创建
**************************************************************************/
UINT32 BootL2ssRegMap(T_NTLDrvParam *ptNtlDrvParam,UINT32 phyL2ssAddr,UINT32 phyl2ssAddrSize)
{
    UINT32   virAddr = 0;
    UINT32   ulSpaceProt = PROT_READ | PROT_WRITE;
    INT32 ifile = -1;
    #if 1
    if ((ifile = open("/dev/mem", O_RDWR | O_SYNC)) < 0)
    {
        dbgErr("open /dev/mem failed\n");
        return BSP_ERROR;
    }

    virAddr = mmap((VOID *)NULL, phyl2ssAddrSize, ulSpaceProt, MAP_SHARED, ifile, phyL2ssAddr);
    if (0 == virAddr)
    {
        dbgErr("%s mmap error\n",__FUNCTION__);
        return BSP_ERROR;
    }
    dbgInfo("%s mmap ok,viraddr[0x%08x]\n",__FUNCTION__,virAddr);
    close(ifile);
    #endif
    //DpdIcHalGetAddrPhyToVir(0,phyL2ssAddr,&virAddr);
    dbgInfo("%s mmap ok,viraddr[0x%08x]\n",__FUNCTION__,virAddr);

    ptNtlDrvParam->l2ssDrvParam.regVirAddr = virAddr;
    ptNtlDrvParam->xmacDrvParam.regVirAddr = virAddr;
    ptNtlDrvParam->tPtpDrvParam.regVirAddr = virAddr;

    zte_printf_s("%s:l2ss reg baseaddr = 0x%08x\n",__FUNCTION__,virAddr);

    return BSP_OK;
}

UINT32 BootInitL2ss(T_L2ssDrvParam *pl2ssDrvParam)
{
    INPUT_POINTER_CHECK(pl2ssDrvParam);

    NtlL2ssCfgBaseAddr(pl2ssDrvParam->regVirAddr);
    if (BSP_OK !=  NtlL2ssInit(pl2ssDrvParam))
    {
        dbgErr("%s failed\n",__FUNCTION__);
        return BSP_ERROR;
    }

   /*设置本地Debug ETH的初始化 */
    if (BSP_OK !=  NtlL2ssSetDebugEthIpVlan(L2SS_DEBUG_ETH_IP_VLAN))
    {
        dbgErr("%s failed\n",__FUNCTION__);
        return BSP_ERROR;
    }

    dbgInfo("%s init succ\n",__FUNCTION__);
    return BSP_OK;
}

UINT32 BootInitXmac(T_XmacParamStruct *pXmacDrvParam)
{
    UINT32 ret = -1;
    UINT32 idx = 0;

    INPUT_POINTER_CHECK(pXmacDrvParam);

    NtlXMacCfgBaseAddr(pXmacDrvParam->regVirAddr);
    for(idx = 0;idx < NACC_XMAC_NUM;idx ++)
    {
        if (!isXmacPortHwValid(idx))
        {
            continue;
        }

        if (pXmacDrvParam->atXmacDrvParam[idx].bEnable)
        {
            ret = NaccXmacInit(&(pXmacDrvParam->atXmacDrvParam[idx]));
            if (BSP_OK != ret)
            {
                dbgErr("%s NaccXmacInit %d failed\n",__FUNCTION__,idx);
                return BSP_ERROR;
            }
        }
    }

    dbgInfo("%s init succ!\n",__FUNCTION__);
    return BSP_OK;
}
#endif
UINT32 BootSetEth0DebugIpMacAddr()
{
    UINT8 mac[6] = {0x5a, 0x54, 0x45, 0xff, 0xff, 0xff};
    UINT8 ip[4] = {199, 33, 33, 33};
    UINT8 mask[4] = {0xff, 0xff, 0xff, 0};
    UINT8 netif[8] = "eth0";
    char cmd[128] = {0};

    BspGetCpuType(&mac[3]);

    zte_snprintf_s(cmd, sizeof(cmd), "ifconfig %s down", netif);
    zte_printf_s("%s\n", cmd);
    BspSystem(cmd);

    zte_snprintf_s(cmd, sizeof(cmd), "ifconfig %s hw ether %02X:%02X:%02X:%02X:%02X:%02X", netif,
                   mac[0], mac[1], mac[2], mac[3], mac[4], mac[5]);
    zte_printf_s("%s\n", cmd);
    BspSystem(cmd);

    zte_snprintf_s(cmd, sizeof(cmd), "ifconfig %s %d.%d.%d.%d netmask %d.%d.%d.%d", netif, ip[0], ip[1], ip[2], ip[3],
                   mask[0], mask[1], mask[2], mask[3]);
    zte_printf_s("%s\n", cmd);
    BspSystem(cmd);

    zte_printf_s("%s done\n", __FUNCTION__);

    return BSP_OK;
}

/*200网段，光网口*/
UINT32 BootSetEth1DebugIpMacAddr()
{
    UINT8 mac[6] = {0x40, 0x00, 0xC8, 0x21, 0x21, 0x21};
    UINT8 ip[4] = {200, 33, 33, 33};
    UINT8 mask[4] = {0xff, 0xff, 0xff, 0};
    UINT8 netif[8] = "eth1";

    char cmd[128] = {0};

    zte_snprintf_s(cmd, sizeof(cmd), "ifconfig %s down", netif);
    zte_printf_s("%s\n", cmd);
    BspSystem(cmd);

    zte_snprintf_s(cmd, sizeof(cmd), "ifconfig %s hw ether %02X:%02X:%02X:%02X:%02X:%02X", netif,
                   mac[0], mac[1], mac[2], mac[3], mac[4], mac[5]);
    zte_printf_s("%s\n", cmd);
    BspSystem(cmd);

    zte_snprintf_s(cmd, sizeof(cmd), "ifconfig %s %d.%d.%d.%d netmask %d.%d.%d.%d", netif, ip[0], ip[1], ip[2], ip[3],
                   mask[0], mask[1], mask[2], mask[3]);
    zte_printf_s("%s\n", cmd);
    BspSystem(cmd);

    return BSP_OK;
}

/*198网段*/
UINT32 BootSetslavechipIpMacAddr()
{
    UINT8 mac[6] = {0x40, 0x00, 0xC6, 0x21, 0x21, 0x05};
    UINT8 ip[4] = {198, 33, 33, 2};
    UINT8 mask[4] = {0xff, 0xff, 0xff, 0};
    UINT8 netif[8] = "eth0";
    char cmd[128] = {0};
    UINT32 uchipid = 0;

    uchipid = g_icChipId;
    uchipid = (uchipid & 0xf) >> 0x1;
    mac[5] = uchipid + 2;
    ip[3] = uchipid + 2;

    zte_snprintf_s(cmd, sizeof(cmd), "ifconfig %s down", netif);
    zte_printf_s("%s\n", cmd);
    BspSystem(cmd);

    zte_snprintf_s(cmd, sizeof(cmd), "ifconfig %s hw ether %02X:%02X:%02X:%02X:%02X:%02X", netif,
                   mac[0], mac[1], mac[2], mac[3], mac[4], mac[5]);
    zte_printf_s("%s\n", cmd);
    BspSystem(cmd);

    zte_snprintf_s(cmd, sizeof(cmd), "ifconfig %s %d.%d.%d.%d netmask %d.%d.%d.%d", netif, ip[0], ip[1], ip[2], ip[3],
                   mask[0], mask[1], mask[2], mask[3]);
    zte_printf_s("%s\n", cmd);
    BspSystem(cmd);

    return BSP_OK;
}

/*调用后，dirve the kernel to implement open function*/
UINT32 BootSetEth0Up()
{
    UINT8 netif[8] = "eth0";
    char cmd[128] = {0};
    zte_snprintf_s(cmd, sizeof(cmd), "ifconfig %s up", netif);
    zte_printf_s("%s\n", cmd);
    system(cmd);
    return BSP_OK;
}

UINT32 BootSetEth0Down()
{
    UINT8 netif[8] = "eth0";
    char cmd[128] = {0};
    zte_snprintf_s(cmd, sizeof(cmd), "ifconfig %s down", netif);
    zte_printf_s("%s\n", cmd);
    system(cmd);
    return BSP_OK;
}

static T_SERDES_PARAM *s_pSerdesCfg = NULL;
static UINT32 s_serdesLaneNum = 0;
#ifdef CONFIG_ZX211413
static T_BspHalAdaptSerdesRxCfg *s_pSerdesRxCfg = NULL;
#endif
static UINT32 s_optSserdesInitStatus[E_OPT_SERDES_INIT_MAX][OPT_SERDES_LANE_MAX_NUM] = {0};
static T_DifCfgSave s_tDifCfgSave[E_DIF_CFG_TYPE_MAX] = {0};
static UINT32 s_PreAllocCpriType = E_OPT_ECPRI;
static UINT32 s_uCpriType = E_OPT_ECPRI;

#ifdef CONFIG_ZX211412

UINT32 IcHalGetIcChipId(UINT32 *pChipIdx)
{
    UINT32 uRet = BSP_OK;
    uRet = IcHalBitRdReg(0, UBAR_SRC_CHIP_ID, 0, pChipIdx, 0, 1);
    return uRet;
}
#endif

UINT32 IcHalSetPreAllocType(UINT32 uBearType)
{
    UINT32 uRet = BSP_OK;
    s_PreAllocCpriType = uBearType;
    return uRet;
}
UINT32 IcHalTdmBifSetCpriType(UINT32 uCpriType)
{
    s_uCpriType = uCpriType;
    return BSP_OK;
}

static VOID SaveDifCfg(UINT32 type, VOID *pAddr, UINT32 linkunm, UINT32 difChNum)
{
    if (type < E_DIF_CFG_TYPE_MAX)
    {
        s_tDifCfgSave[type].pAddr = pAddr;
        s_tDifCfgSave[type].linkunm = linkunm;
        s_tDifCfgSave[type].difChNum = difChNum;
    }
    return;
}

/* Started by AICoder, pid:kda32c2eb7rbb0e14e570991b03908040678301a */
VOID SaveOptSerdesInitRes(UINT32 initStep, UINT32 laneId, UINT32 result)
{
    if (initStep < E_OPT_SERDES_INIT_MAX && laneId < OPT_SERDES_LANE_MAX_NUM)
    {
        s_optSserdesInitStatus[initStep][laneId] = result;
    }
    return;
}
/* Ended by AICoder, pid:kda32c2eb7rbb0e14e570991b03908040678301a */

UINT32 BspHalAdaptSetSerdesTxEq(T_SERDES_PARAM *serdesCfg, UINT32 laneNum)
{
    UINT32 loop = 0;
    UINT32 retVal = BSP_OK;
    UINT32 serdesId = 0;
    UINT32 laneId = 0;
    UINT32 txEqEn = 0;
    INT32 eoh0 = 0;
    INT32 eoh1 = 0;
    INT32 eoh2 = 0;
    INT32 eoh3 = 0;
    UINT32 retTotal = BSP_OK;

    INPUT_POINTER_CHECK(serdesCfg);

    for (loop = 0; loop < laneNum; loop++)
    {
        serdesId = serdesCfg[loop].serdesId;
        laneId = serdesCfg[loop].laneId;
        txEqEn = serdesCfg[loop].txEqEn;
        eoh0 = serdesCfg[loop].eoh0;
        eoh1 = serdesCfg[loop].eoh1;
        eoh2 = serdesCfg[loop].eoh2;
        eoh3 = serdesCfg[loop].eoh3;

        if (!txEqEn)
        {
            dbgInfo("%s serdesId[%d] laneId[%d] txEqEn[%d] continue\n", __func__, serdesId, laneId, txEqEn);
            continue;
        }

            /* Started by AICoder, pid:6fc1d9ebbc316fc149a609088096530f6bc2b5f9 */
            dbgInfo("%s serdesId[%d] laneId[%d] txEqEn[%d] eoh0=%d eoh1=%d eoh2=%d eoh3=%d\n",
                    __func__, serdesId, laneId, txEqEn, eoh0, eoh1, eoh2, eoh3);
            /* Ended by AICoder, pid:6fc1d9ebbc316fc149a609088096530f6bc2b5f9 */

        // coverity[cert_int31_c_violation:SUPPRESS]
        retVal = IcHalApiLycaSetTxFirCoff(serdesId, laneId, eoh0, eoh1, eoh2, eoh3);
        if (BSP_OK != retVal)
        {
            dbgErr("%s IcHalApiLycaSetTxFirCoff lane[%d][%d] eoh0=%d eoh1=%d eoh2=%d eoh3=%d err\n",
                   __func__, serdesId, laneId, eoh0, eoh1, eoh2, eoh3);
        }
        SaveOptSerdesInitRes(E_OPT_SERDES_TXEQ, loop, retVal);
        retTotal |= retVal;
    }

    return retTotal;
}
UINT32 BspHalAdaptPcsInit(T_BspHalAdaptPcsCfg *pcsCfg, UINT32 laneNum)
{
    UINT32 retVal = BSP_OK;
    UINT32 retTotal = BSP_OK;

    INPUT_POINTER_CHECK(pcsCfg);

    retVal = IcHalApiInitPcs(pcsCfg, laneNum);
    retTotal |= retVal;
    CHECK_RETVAL_PRN(IcHalApiInitPcs, retVal);

    retVal = IcHalApiSetFlowTokenEn(pcsCfg, laneNum);
    retTotal |= retVal;
    CHECK_RETVAL_PRN(IcHalApiSetFlowTokenEn, retVal);

    SaveOptSerdesInitRes(E_OPT_SERDES_PCS, 0, retTotal);

    return retTotal;
}

/*
    lane0-lane3 <-> pcs0
    lane4-lane7 <-> pcs1
*/
UINT32 BspHalAdaptCrmPcsSetReset(UINT32 laneMask, UINT32 rstFlag)
{
    UINT32 chip = 0;
    UINT32 retVal = BSP_OK;

    if (laneMask & 0xF)
    {
        retVal = IcHalApiCrmPcsSetReset(chip, E_IC_CRM_PCS_0_RESET, rstFlag);
        CHECK_RETVAL(IcHalApiCrmPcsSetReset, retVal);
    }
    #ifdef CONFIG_ZX211412

    if (laneMask & 0xF0)
    {
        retVal = IcHalApiCrmPcsSetReset(chip, E_IC_CRM_PCS_1_RESET, rstFlag);
        CHECK_RETVAL(IcHalApiCrmPcsSetReset, retVal);
    }
    #endif
    return BSP_OK;
}

UINT32 BspHalAdaptCrmNtlXmacSetReset(UINT32 dir, UINT32 laneMask, UINT32 rstFlag)
{
    if (RX == dir)
    {
        return IcHalApiCrmNtlRxXmacSetReset(0, laneMask, rstFlag);
    }
    else if (TX == dir)
    {
        return IcHalApiCrmNtlTxXmacSetReset(0, laneMask, rstFlag);
    }
    else
    {
        return BSP_ERROR;
    }
}

UINT32 BspHalAdaptPcsPreInit(T_BspHalAdaptPcsCfg *pcsCfg, UINT32 laneNum)
{
    UINT32 retVal = BSP_OK;

    INPUT_POINTER_CHECK(pcsCfg);

    retVal = IcHalApiPreInitPcs(pcsCfg, laneNum);
    SaveOptSerdesInitRes(E_OPT_SERDES_PREPCS, 0, retVal);
    CHECK_RETVAL(IcHalApiPreInitPcs, retVal);

    return BSP_OK;
}
#ifdef CONFIG_ZX211412
UINT32 BspHalAdaptSerdesTxInit(T_SERDES_PARAM *serdesCfg, UINT32 laneNum)
{
    UINT32 loop = 0;
    UINT32 retVal = BSP_OK;
    UINT32 serdesId = 0;
    UINT32 laneId = 0;
    UINT32 rate = 0;
    E_LYCA_CLK_CFG clkMode;
    DOUBLE chlen = 0.0;
    UINT32 retTotal = BSP_OK;

    INPUT_POINTER_CHECK(serdesCfg);

    SaveDifCfg(E_OPT_SERDES_PARA, (VOID*)serdesCfg, 1, laneNum);

    for (loop = 0; loop < laneNum; loop++)
    {
        serdesId = serdesCfg[loop].serdesId;
        laneId = serdesCfg[loop].laneId;
        rate = serdesCfg[loop].rate;
        clkMode = serdesCfg[loop].mode;
        chlen = serdesCfg[loop].chlen;

        retVal = IcHalApiLycaInitTx(serdesId, laneId, rate, clkMode, chlen);
        if (BSP_OK != retVal)
        {
            dbgErr("%s IcHalApiLycaInitTx lane[%d][%d] rate=%d clkMode=%d chlen=%f err\n",
                __func__, serdesId, laneId, rate, clkMode, chlen);
        }

        SaveOptSerdesInitRes(E_OPT_SERDES_TXINIT, loop, retVal);
        retTotal |= retVal;
    }

    return retTotal;
}

#elif CONFIG_ZX211413
/* Started by AICoder, pid:g334c3f498d2e7014a98088bb0a2f13a2ae87a9b */
UINT32 BspHalAdaptSerdesTxInit(T_SERDES_PARAM *serdesCfg, UINT32 laneNum)
{
    UINT32 loop = 0;
    UINT32 retVal = BSP_OK;
    UINT32 serdesId = 0;
    UINT32 laneId = 0;
    UINT32 rate = 0;
    E_LYCA_CLK_CFG clkMode;
    DOUBLE chlen = 0.0;
    UINT32 retTotal = BSP_OK;

    INPUT_POINTER_CHECK(serdesCfg);

    SaveDifCfg(E_OPT_SERDES_PARA, (VOID *)serdesCfg, 1, laneNum);

    for (loop = 0; loop < laneNum; loop++)
    {
        serdesId = serdesCfg[loop].serdesId;
        laneId = serdesCfg[loop].laneId;
        rate = serdesCfg[loop].rate;
        clkMode = serdesCfg[loop].mode;
        chlen = serdesCfg[loop].chlen;

        /* TX初始化（发送PRBS） */
        retVal = IcHalApiLycaInitTx(serdesId, laneId, rate, chlen);
        if (BSP_OK != retVal)
        {
            dbgErr("%s IcHalApiLycaInitTx lane[%d][%d] rate=%d clkMode=%d chlen=%f err\n",
                __func__, serdesId, laneId, rate, clkMode, chlen);
        }
        /* 保存serdesTX初始化结果 */
        //coverity[cert_int30_c_violation:SUPPRESS]
        SaveOptSerdesInitRes(E_OPT_SERDES_TXINIT, serdesId * 4 + laneId, retVal);
        retTotal |= retVal;
    }

    return retTotal;
}
/* Ended by AICoder, pid:g334c3f498d2e7014a98088bb0a2f13a2ae87a9b */
#endif

UINT32 BspHalAdaptSerdesLoadFw(T_SERDES_PARAM *serdesCfg, UINT32 laneNum)
{
    UINT32 loop = 0;
    UINT32 retVal = BSP_OK;
    UINT32 retTotal = BSP_OK;

    INPUT_POINTER_CHECK(serdesCfg);

    for (loop = 0; loop < laneNum; loop++)
    {
        retVal = IcHalApiLycaLoadFw(serdesCfg[loop].serdesId, serdesCfg[loop].laneId);
        if (BSP_OK != retVal)
        {
            dbgErr("%s IcHalApiLycaLoadFw lane[%d][%d] err\n", __func__, serdesCfg[loop].serdesId, serdesCfg[loop].laneId);
        }

        SaveOptSerdesInitRes(E_OPT_SERDES_LOADFW, loop, retVal);
        retTotal |= retVal;
    }

    return retTotal;
}

UINT32 BootOptPcsPreInit(UINT32 portmap)
{
    UINT32 retVal = BSP_OK;
    UINT32 port = 0;
    for (port = 0; port < L2SS_PORT_MAX; port++)
    {
        if (1 != ((portmap >> port) & 0x01))
        {
            continue;
        }

        retVal = BspHalAdaptPcsPreInit(&s_sboardEcpriPcsCfg[port], 1);
        CHECK_RETVAL(BspHalAdaptPcsPreInit, retVal);
    }
    return BSP_OK;
}
UINT32 BootOptSerdesLoadFirmware(VOID)
{
    UINT32 retVal = BSP_OK;

    retVal = BspHalAdaptSerdesLoadFw(s_pSerdesCfg, s_serdesLaneNum);
    CHECK_RETVAL(BspHalAdaptSerdesLoadFw, retVal);

    return BSP_OK;
}
UINT32 BootOptSerdesTxInit(VOID)
{
    UINT32 retVal = BSP_OK;

    retVal = BspHalAdaptSerdesTxInit(s_pSerdesCfg, s_serdesLaneNum);
    CHECK_RETVAL(BspHalAdaptSerdesTxInit, retVal);

    return BSP_OK;
}

UINT32 BootOptSerdesSetTxEq(VOID)
{
    UINT32 retVal = BSP_OK;

    retVal = BspHalAdaptSetSerdesTxEq(s_pSerdesCfg, s_serdesLaneNum);
    CHECK_RETVAL(BspHalAdaptSetSerdesTxEq, retVal);

    return BSP_OK;
}

/* Started by AICoder, pid:7d9det7688d83b014e6508eed019af2ab9391fb6 */
#if 0
UINT32 BootHalAdaptSerdesRxInit(T_SERDES_PARAM *serdesCfg, UINT32 laneNum)
{
    UINT32 loop = 0;
    UINT32 retVal = BSP_OK;
    UINT32 serdesId = 0;
    UINT32 laneId = 0;
    UINT32 retTotal = BSP_OK;

    INPUT_POINTER_CHECK(serdesCfg);

    for (loop = 0; loop < laneNum; loop++)
    {
        serdesId = serdesCfg[loop].serdesId;
        laneId = serdesCfg[loop].laneId;

        retVal = IcHalApiLycaInitRx(serdesId, laneId);
        if (BSP_OK != retVal)
        {
            dbgErr("%s IcHalApiLycaInitRx lane[%d][%d] err\n", __func__, serdesId, laneId);
        }

        SaveOptSerdesInitRes(E_OPT_SERDES_RXINIT, loop, retVal);
        retTotal |= retVal;
    }

    return retTotal;
}
#endif
/* Ended by AICoder, pid:7d9det7688d83b014e6508eed019af2ab9391fb6 */

UINT32 BootHalAdaptSerdesChgNormal(T_SERDES_PARAM *serdesCfg, UINT32 laneNum)
{
    UINT32 loop = 0;
    UINT32 retVal = BSP_OK;
    UINT32 serdesId = 0;
    UINT32 laneId = 0;
    UINT32 retTotal = BSP_OK;

    INPUT_POINTER_CHECK(serdesCfg);

    for (loop = 0; loop < laneNum; loop++)
    {
        serdesId = serdesCfg[loop].serdesId;
        laneId = serdesCfg[loop].laneId;

        retVal = IcHalApiLycaTccSwitch(serdesId, laneId);
        if (BSP_OK != retVal)
        {
            dbgErr("%s IcHalApiLycaTccSwitch lane[%d][%d] err\n", __func__, serdesId, laneId);
        }

        SaveOptSerdesInitRes(E_OPT_SERDES_NORMAL, loop, retVal);
        retTotal |= retVal;
    }

    return retTotal;
}

#ifdef CONFIG_ZX211412
UINT32 BspHalAdaptSerdesRxInit(T_SERDES_PARAM *serdesCfg, UINT32 laneNum)
{
    UINT32 loop = 0;
    UINT32 retVal = BSP_OK;
    UINT32 serdesId = 0;
    UINT32 laneId = 0;
    UINT32 retTotal = BSP_OK;

    INPUT_POINTER_CHECK(serdesCfg);

    for (loop = 0; loop < laneNum; loop++)
    {
        serdesId = serdesCfg[loop].serdesId;
        laneId = serdesCfg[loop].laneId;

        retVal = IcHalApiLycaInitRx(serdesId, laneId);
        if (BSP_OK != retVal)
        {
            dbgErr("%s IcHalApiLycaInitRx lane[%d][%d] err\n", __func__, serdesId, laneId);
        }

        SaveOptSerdesInitRes(E_OPT_SERDES_RXINIT, loop, retVal);
        retTotal |= retVal;
    }

    return retTotal;
}
#elif CONFIG_ZX211413
UINT32 BspHalAdaptSerdesRxInit(T_SERDES_PARAM *serdesCfg, T_BspHalAdaptSerdesRxCfg *serdesRxCfg, UINT32 laneNum)
{
    UINT32 loop = 0;
    UINT32 retVal = BSP_OK;
    UINT32 serdesId = 0;
    UINT32 laneId = 0;
    UINT32 retTotal = BSP_OK;

    INPUT_POINTER_CHECK(serdesCfg);
    INPUT_POINTER_CHECK(serdesRxCfg);

    for (loop = 0; loop < laneNum; loop++)
    {
        serdesId = serdesCfg[loop].serdesId;
        laneId = serdesCfg[loop].laneId;
        serdesRxCfg = &serdesRxCfg[loop];
        /* RX初始化 */
        retVal = IcHalApiLycaInitRx(serdesId, laneId, serdesRxCfg);
        if (BSP_OK != retVal)
        {
            dbgErr("%s IcHalApiLycaInitRx lane[%d][%d] err\n", __func__, serdesId, laneId);
        }
        /* 保存serdesRX初始化结果 */
        // coverity[cert_int30_c_violation:SUPPRESS]
        SaveOptSerdesInitRes(E_OPT_SERDES_RXINIT, serdesId * 4 + laneId, retVal);
        retTotal |= retVal;
    }

    return retTotal;
}
#endif

UINT32 BspHalAdaptSerdesChgNormal(T_SERDES_PARAM *serdesCfg, UINT32 laneNum)
{
    UINT32 loop = 0;
    UINT32 retVal = BSP_OK;
    UINT32 serdesId = 0;
    UINT32 laneId = 0;
    UINT32 retTotal = BSP_OK;

    INPUT_POINTER_CHECK(serdesCfg);

    for (loop = 0; loop < laneNum; loop++)
    {
        serdesId = serdesCfg[loop].serdesId;
        laneId = serdesCfg[loop].laneId;

        retVal = IcHalApiLycaTccSwitch(serdesId, laneId);
        if (BSP_OK != retVal)
        {
            dbgErr("%s IcHalApiLycaTccSwitch lane[%d][%d] err\n", __func__, serdesId, laneId);
        }

        SaveOptSerdesInitRes(E_OPT_SERDES_NORMAL, loop, retVal);
        retTotal |= retVal;
    }

    return retTotal;
}

#ifdef CONFIG_ZX211412
UINT32 BootOptSerdesRxInit(VOID)
{
    UINT32 retVal = BSP_OK;

    retVal = BspHalAdaptSerdesRxInit(s_pSerdesCfg, s_serdesLaneNum);
    CHECK_RETVAL(BspHalAdaptSerdesRxInit, retVal);

    return BSP_OK;
}
#elif CONFIG_ZX211413

static UINT32 BootOptSerdesRxInit(VOID)
{
    UINT32 retVal = BSP_OK;

    retVal = BspHalAdaptSerdesRxInit(s_pSerdesCfg, s_pSerdesRxCfg, s_serdesLaneNum);
    CHECK_RETVAL(BspHalAdaptSerdesRxInit, retVal);

    return BSP_OK;
}
#endif

UINT32 BootOptSerdesChgNormal(VOID)
{
    UINT32 retVal = BSP_OK;

    retVal = BspHalAdaptSerdesChgNormal(s_pSerdesCfg, s_serdesLaneNum);
    CHECK_RETVAL(BspHalAdaptSerdesChgNormal, retVal);

    return BSP_OK;
}

VOID BootHalAdaptOptSerdesInitStatusClr(VOID)
{
    UINT32 i = 0, j = 0;
    for (i = 0; i < E_OPT_SERDES_INIT_MAX; i++)
    {
        for (j = 0; j < OPT_SERDES_LANE_MAX_NUM; j++)
        {
            s_optSserdesInitStatus[i][j] = 0xff;
        }
    }
    return;
}

#ifdef CONFIG_ZX211412
UINT32 BootOptSerdesInit(UINT32 portmap)
{
    UINT32 retTotal = BSP_OK;
    UINT32 retVal = BSP_OK;
    UINT32 port = 0;
    for (port = 0; port < L2SS_PORT_MAX; port++)
    {
        if (1 != ((portmap >> port) & 0x01))
        {
            continue;
        }
        s_pSerdesCfg = &s_serdesPara_1G[port];
        s_serdesLaneNum = 1;

        retVal = BootOptSerdesLoadFirmware();
        retTotal |= retVal;
        CHECK_RETVAL_PRN(BootOptSerdesLoadFirmware, retVal);

        retVal = BootOptSerdesTxInit();
        retTotal |= retVal;
        CHECK_RETVAL_PRN(BootOptSerdesTxInit, retVal);

        retVal = BootOptSerdesSetTxEq();
        retTotal |= retVal;
        CHECK_RETVAL_PRN(BootOptSerdesSetTxEq, retVal);

        retVal = BootOptSerdesRxInit();
        retTotal |= retVal;
        CHECK_RETVAL_PRN(BootOptSerdesRxInit, retVal);

        #if 0
        if (BSP_OK == retVal)
        {
            s_serdesRxInitedFlag = 1;
        }
        #endif

        retVal = BootOptSerdesChgNormal();
        retTotal |= retVal;
        CHECK_RETVAL_PRN(BspOptSerdesChgNormal, retVal);
    }

    return retTotal;
}

#elif CONFIG_ZX211413

UINT32 BootOptSerdesInit(UINT32 portmap, UINT32 optIndex)
{
    UINT32 retTotal = BSP_OK;
    UINT32 retVal = BSP_OK;
    UINT32 port = 0;

    for (port = 0; port < L2SS_MAX_EPORT_ID; port++)
    {
        if (1 != ((portmap >> port) & 0x01))
        {
            continue;
        }
        s_pSerdesRxCfg = &s_sboardAdaptSerdesRxCfg[port];
        s_pSerdesCfg = &s_serdesPara_1G[port];
        s_serdesLaneNum = 1;

        retVal = BootOptSerdesLoadFirmware();
        retTotal |= retVal;
        CHECK_RETVAL_PRN(BootOptSerdesLoadFirmware, retVal);

        retVal = BootOptSerdesTxInit();
        retTotal |= retVal;
        CHECK_RETVAL_PRN(BootOptSerdesTxInit, retVal);

        retVal = BootOptSerdesSetTxEq();
        retTotal |= retVal;
        CHECK_RETVAL_PRN(BootOptSerdesSetTxEq, retVal);

        if (0xff == optIndex)
        {
            retVal = BspInitPhy(0);
            retTotal |= retVal;
            CHECK_RETVAL_PRN(BspInitPhy, retVal);
        }
        else
        {
            retVal = BootInitSfpPhy(optIndex);
            retTotal |= retVal;
            CHECK_RETVAL_PRN(BootInitSfpPhy, retVal);
        }

        BspSysMsDelay_Sys(1000);

        retVal = BootOptSerdesRxInit();
        retTotal |= retVal;
        CHECK_RETVAL_PRN(BootOptSerdesRxInit, retVal);

        #if 0
        if (BSP_OK == retVal)
        {
            s_serdesRxInitedFlag = 1;
        }
        #endif

        retVal = BootOptSerdesChgNormal();
        retTotal |= retVal;
        CHECK_RETVAL_PRN(BspOptSerdesChgNormal, retVal);
    }

    return retTotal;
}
#endif
UINT32 BootOptPcsInit(UINT32 portmap)
{
    UINT32 retVal = BSP_OK;
    UINT32 retTotal = BSP_OK;

    UINT32 port = 0;
    for (port = 0; port < L2SS_PORT_MAX; port++)
    {
        if (1 != ((portmap >> port) & 0x01))
        {
            continue;
        }
        retVal = BspHalAdaptPcsInit(&s_sboardEcpriPcsCfg[port], 1);
        retTotal |= retVal;
        CHECK_RETVAL_PRN(BspHalAdaptPcsInit, retVal);
    }

    return retTotal;
}

UINT32 BootOptNtlCrmInit(UINT32 laneMask, UINT32 rstFlag)
{
    UINT32 retVal = BSP_OK;
    UINT32 retTotal = BSP_OK;

    retVal = BspHalAdaptCrmNtlXmacSetReset(TX, laneMask, rstFlag);
    retTotal |= retVal;
    CHECK_RETVAL_PRN(BspHalAdaptCrmNtlXmacSetReset, retVal);
    retVal = BspHalAdaptCrmNtlXmacSetReset(RX, laneMask, rstFlag);
    retTotal |= retVal;
    CHECK_RETVAL_PRN(BspHalAdaptCrmNtlXmacSetReset, retVal);

    return retTotal;
}

#ifdef CONFIG_ZX211412
UINT32 BootOptDebugNetInit(UINT32 portmap)
{
    UINT32 retTotal = BSP_OK;
    UINT32 retVal = BSP_OK;
    UINT32 laneMask = portmap;

    BootHalAdaptOptSerdesInitStatusClr();

    retVal = BootOptNtlCrmInit(laneMask, 0);
    retTotal |= retVal;
    CHECK_RETVAL_PRN(BootOptNtlCrmInit, retVal);

    retVal = BspHalAdaptCrmPcsSetReset(laneMask, 1);
    retTotal |= retVal;
    CHECK_RETVAL_PRN(BspHalAdaptCrmPcsSetReset, retVal);

    retVal = BootOptPcsPreInit(laneMask);
    retTotal |= retVal;
    CHECK_RETVAL_PRN(BootOptPcsPreInit, retVal);

    retVal = BootOptSerdesInit(laneMask);
    retTotal |= retVal;
    CHECK_RETVAL_PRN(BootOptSerdesInit, retVal);

    retVal = BootOptPcsInit(laneMask);
    retTotal |= retVal;
    CHECK_RETVAL_PRN(BootOptPcsInit, retVal);

    #if 1
    retVal = BootOptNtlCrmInit(laneMask, 1);
    retTotal |= retVal;
    CHECK_RETVAL_PRN(BootOptNtlCrmInit, retVal);
    #else
    retVal = BootOptEcpriParaInit();
    retTotal |= retVal;
    CHECK_RETVAL_PRN(BootOptEcpriParaInit, retVal);
    #endif

    L2ssMacInit(laneMask);

    return retTotal;
}
#else

UINT32 BootSerdesInit(UINT32 portmap, UINT32 optIndex)
{

    UINT32 retTotal = BSP_OK;
    UINT32 retVal = BSP_OK;
    UINT32 laneMask = portmap;

    BootHalAdaptOptSerdesInitStatusClr();

    retVal = BootOptNtlCrmInit(laneMask, 0);
    retTotal |= retVal;
    CHECK_RETVAL_PRN(BootOptNtlCrmInit, retVal);

    retVal = BspHalAdaptCrmPcsSetReset(laneMask, 1);
    retTotal |= retVal;
    CHECK_RETVAL_PRN(BspHalAdaptCrmPcsSetReset, retVal);

    retVal = BootOptPcsPreInit(laneMask);
    retTotal |= retVal;
    CHECK_RETVAL_PRN(BootOptPcsPreInit, retVal);

    retVal = BootOptSerdesInit(laneMask, optIndex);
    retTotal |= retVal;
    CHECK_RETVAL_PRN(BootOptSerdesInit, retVal);

    retVal = BootOptPcsInit(laneMask);
    retTotal |= retVal;
    CHECK_RETVAL_PRN(BootOptPcsInit, retVal);

    return retTotal;
}
#endif

UINT32 BootXmacInit(UINT32 portmap)
{

    UINT32 retTotal = BSP_OK;
    UINT32 retVal = BSP_OK;
    UINT32 laneMask = portmap;

/*ADS case*/

    retVal = BootOptNtlCrmInit(laneMask, 1);
    retTotal |= retVal;
    CHECK_RETVAL_PRN(BootOptNtlCrmInit, retVal);

    retVal = L2ssMacInit(laneMask);
    return retVal;
}



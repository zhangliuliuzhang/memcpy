
/*********************************************************************
* 版权所有 (C)2002, 中兴通讯股份有限公司。
*
* 文件名称： ntl_l2ss_proc.c
* 文件标识：
* 其它说明：
* 当前版本：
* 作    者： 姚自强
* 完成日期： 2015/09/09
* 修改记录1：
*    修改日期：
*    版 本 号：
*    修 改 人：
*    修改内容：
**********************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "bsppub.h"
#include "l2sshw.h"

#define L2SS_TABLE_NUM           8
#define LPM_SIZE8_NUM            8

#define L2SS_TABLE_START_ID      16
#define L2SS_LPM_SIZE8_START_ID  16

static UINT32 g_vlanIdTable[L2SS_TABLE_NUM] = {0};
static UINT32 g_vlanIdPoint = 0;
static UINT32 g_audLvIpTable[L2SS_TABLE_NUM] = {0};
static UINT32 g_udLvIpTablePoint = 0;
static UINT32 g_audLvtapTable[L2SS_TABLE_NUM] = {0};
static UINT32 g_udLvtapTablePoint = 0;
static UINT32 g_audLvlemTable[L2SS_TABLE_NUM] = {0};
static UINT32 g_udLvlemTablePoint = 0;
static UINT32 g_audLmcmcTable[L2SS_TABLE_NUM] = {0};
static UINT32 g_udLmcmcTablePoint = 0;


static UINT32 g_audLpmSize8[LPM_SIZE8_NUM] = {0};
static UINT32 g_audLpmSize4[2*LPM_SIZE8_NUM] = {0};
static UINT32 g_audLpmSize2[4*LPM_SIZE8_NUM] = {0};
static UINT32 g_audLpmSize1[8*LPM_SIZE8_NUM] = {0};

static UINT32 g_audLpmSize8Point = 0;
static UINT32 g_audLpmSize4Point = 0;
static UINT32 g_audLpmSize2Point = 0;
static UINT32 g_audLpmSize1Point = 0;



/**********************************************************************
* 函数名称：L2ssLkupInitLvIpTableId
* 功能描述：初始化vlan特性表的基地址资源池
* 输入参数：
* 输出参数：
* 返 回 值：
* 其他说明：0号基址不参与分配
* 修改日期        版本号       修改人            修改内容
* ----------------------------------------------------------------------
* 2016/02/29       V1.0      Yaoziqiang            创建
************************************************************************/
UINT32 L2ssLkupInitVlanId(void)
{
    UINT32 udLoop = 0;

    for (udLoop = 0; udLoop < L2SS_TABLE_NUM; udLoop++)
    {
        g_vlanIdTable[udLoop] = L2SS_TABLE_START_ID + udLoop;
    }

    g_vlanIdPoint = 0;

    return (UINT32)BSP_OK;
}

/**********************************************************************
* 函数名称：L2ssLkupApplyLvIpTableId
* 功能描述：获取要写入vlan特性表的基地址
* 输入参数：
* 输出参数：
* 返 回 值：0, 无效 1-255,有效地址
* 其他说明：0号基址不参与分配
* 修改日期        版本号       修改人            修改内容
* ----------------------------------------------------------------------
* 2016/02/29       V1.0      Yaoziqiang            创建
************************************************************************/
UINT32 L2ssLkupApplyVlanId(void)
{
    UINT32 udResult = 0;

    if (L2SS_TABLE_NUM > g_vlanIdPoint)
    {
        udResult = g_vlanIdTable[g_vlanIdPoint];
        g_vlanIdPoint++;
    }

    return udResult;
}


/**********************************************************************
* 函数名称：L2ssLkupInitLvIpTableId
* 功能描述：初始化vlan特性表的基地址资源池
* 输入参数：
* 输出参数：
* 返 回 值：
* 其他说明：0号基址不参与分配
* 修改日期        版本号       修改人            修改内容
* ----------------------------------------------------------------------
* 2016/02/29       V1.0      Yaoziqiang            创建
************************************************************************/
UINT32 L2ssLkupInitLvIpTableId(void)
{
    UINT32 udLoop = 0;

    for (udLoop = 0; udLoop < L2SS_TABLE_NUM; udLoop++)
    {
        g_audLvIpTable[udLoop] = L2SS_TABLE_START_ID + udLoop;
    }

    g_udLvIpTablePoint = 0;

    return (UINT32)BSP_OK;
}


/**********************************************************************
* 函数名称：L2ssLkupApplyLvIpTableId
* 功能描述：获取要写入vlan特性表的基地址
* 输入参数：
* 输出参数：
* 返 回 值：0, 无效 1-255,有效地址
* 其他说明：0号基址不参与分配
* 修改日期        版本号       修改人            修改内容
* ----------------------------------------------------------------------
* 2016/02/29       V1.0      Yaoziqiang            创建
************************************************************************/
UINT32 L2ssLkupApplyLvIpTableId(void)
{
    UINT32 udResult = 0;

    if (L2SS_TABLE_NUM > g_udLvIpTablePoint)
    {
        udResult = g_audLvIpTable[g_udLvIpTablePoint];
        g_udLvIpTablePoint++;
    }

    return udResult;
}



/**********************************************************************
* 函数名称：L2ssLkupReleaseLvIpTableId
* 功能描述：回收vlan特性表的基地址
* 输入参数：
* 输出参数：
* 返 回 值：
* 其他说明：
* 修改日期        版本号       修改人            修改内容
* ----------------------------------------------------------------------
* 2016/02/29       V1.0      Yaoziqiang            创建
************************************************************************/
UINT32 L2ssLkupReleaseLvIpTableId(UINT32 udTableId)
{
    UINT32 udResult = BSP_ERROR;

    if ((0 < g_udLvIpTablePoint) && (0 != udTableId))
    {
        g_udLvIpTablePoint--;
        g_audLvIpTable[g_udLvIpTablePoint] = udTableId;

        udResult = BSP_OK;
    }

    return udResult;
}



/**********************************************************************
* 函数名称：L2ssLkupInitLvtapTableId
* 功能描述：初始化标签行为表的基地址资源池
* 输入参数：
* 输出参数：
* 返 回 值：
* 其他说明：0号基址不参与分配
* 修改日期        版本号       修改人            修改内容
* ----------------------------------------------------------------------
* 2016/02/29       V1.0      Yaoziqiang            创建
************************************************************************/
UINT32 L2ssLkupInitLvtapTableId(void)
{
    UINT32 udLoop = 0;

    for (udLoop = 0; udLoop < L2SS_TABLE_NUM; udLoop++)
    {
        g_audLvtapTable[udLoop] = L2SS_TABLE_START_ID + udLoop;
    }

    g_udLvtapTablePoint = 0;

    return (UINT32)BSP_OK;
}

/**********************************************************************
* 函数名称：L2ssLkupApplyLvtapTableId
* 功能描述：获取要写入标签行为表的基地址
* 输入参数：
* 输出参数：
* 返 回 值：0, 无效 1-63,有效地址
* 其他说明：0号基址不参与分配
* 修改日期        版本号       修改人            修改内容
* ----------------------------------------------------------------------
* 2016/02/29       V1.0      Yaoziqiang            创建
************************************************************************/
UINT32 L2ssLkupApplyLvtapTableId(void)
{
    UINT32 udResult = 0;

    if (L2SS_TABLE_NUM > g_udLvtapTablePoint)
    {
        udResult = g_audLvtapTable[g_udLvtapTablePoint];
        g_udLvtapTablePoint++;
    }

    return udResult;
}

/**********************************************************************
* 函数名称：L2ssLkupReleaseLvtapTableId
* 功能描述：回收标签行为表的基地址
* 输入参数：
* 输出参数：
* 返 回 值：
* 其他说明：
* 修改日期        版本号       修改人            修改内容
* ----------------------------------------------------------------------
* 2016/02/29       V1.0      Yaoziqiang            创建
************************************************************************/
UINT32 L2ssLkupReleaseLvtapTableId(UINT32 udTableId)
{
    UINT32 udResult = BSP_OK;

    if ((0 < g_udLvtapTablePoint) && (0 != udTableId))
    {
        g_udLvtapTablePoint--;
        g_audLvtapTable[g_udLvtapTablePoint] = udTableId;

        udResult = BSP_OK;
    }

    return udResult;
}

/**********************************************************************
* 函数名称：L2ssLkupInitLvlemTableId
* 功能描述：初始化VLAN输出特性表的基地址资源池
* 输入参数：
* 输出参数：
* 返 回 值：
* 其他说明：0号基址不参与分配
* 修改日期        版本号       修改人            修改内容
* ----------------------------------------------------------------------
* 2016/02/29       V1.0      Yaoziqiang            创建
************************************************************************/
UINT32 L2ssLkupInitLvlemTableId(void)
{
    UINT32 udLoop = 0;

    for (udLoop = 0; udLoop < L2SS_TABLE_NUM; udLoop++)
    {
        g_audLvlemTable[udLoop] = L2SS_TABLE_START_ID + udLoop;
    }

    g_udLvlemTablePoint = 0;

    return (UINT32)BSP_OK;
}

/**********************************************************************
* 函数名称：L2ssLkupApplyLvlemTableId
* 功能描述：获取要写入VLAN输出特性表的基地址
* 输入参数：
* 输出参数：
* 返 回 值：0, 无效 1-63,有效地址
* 其他说明：0号基址不参与分配
* 修改日期        版本号       修改人            修改内容
* ----------------------------------------------------------------------
* 2016/02/29       V1.0      Yaoziqiang            创建
************************************************************************/
UINT32 L2ssLkupApplyLvlemTableId(void)
{
    UINT32 udResult = 0;

    if (L2SS_TABLE_NUM > g_udLvlemTablePoint)
    {
        udResult = g_audLvlemTable[g_udLvlemTablePoint];
        g_udLvlemTablePoint++;
    }

    return udResult;
}

/**********************************************************************
* 函数名称：L2ssLkupReleaseLvlemTableId
* 功能描述：回收VLAN输出特性表的基地址
* 输入参数：
* 输出参数：
* 返 回 值：
* 其他说明：
* 修改日期        版本号       修改人            修改内容
* ----------------------------------------------------------------------
* 2016/02/29       V1.0      Yaoziqiang            创建
************************************************************************/
UINT32 L2ssLkupReleaseLvlemTableId(UINT32 udTableId)
{
    UINT32 udResult = BSP_OK;

    if ((0 < g_udLvlemTablePoint) && (0 != udTableId))
    {
        g_udLvlemTablePoint--;
        g_audLvlemTable[g_udLvlemTablePoint] = udTableId;

        udResult = BSP_OK;
    }

    return udResult;
}

/**********************************************************************
* 函数名称：L2ssLkupInitLmcmcTableId
* 功能描述：初始化组播表的基地址资源池
* 输入参数：
* 输出参数：
* 返 回 值：
* 其他说明：0号基址不参与分配
* 修改日期        版本号       修改人            修改内容
* ----------------------------------------------------------------------
* 2016/03/01       V1.0      Yaoziqiang            创建
************************************************************************/
UINT32 L2ssLkupInitLmcmcTableId(void)
{
    UINT32 udLoop = 0;

    for (udLoop = 0; udLoop < L2SS_TABLE_NUM; udLoop++)
    {
        g_audLmcmcTable[udLoop] = L2SS_TABLE_START_ID + udLoop;
    }

    g_udLmcmcTablePoint = 0;

    return (UINT32)BSP_OK;
}

/**********************************************************************
* 函数名称：L2ssLkupApplyLmcmcTableId
* 功能描述：获取要写入组播表的基地址
* 输入参数：
* 输出参数：
* 返 回 值：0, 无效 1-31,有效地址
* 其他说明：0号基址不参与分配
* 修改日期        版本号       修改人            修改内容
* ----------------------------------------------------------------------
* 2016/03/01       V1.0      Yaoziqiang            创建
************************************************************************/
UINT32 L2ssLkupApplyLmcmcTableId(void)
{
    UINT32 udResult = 0;

    if (L2SS_TABLE_NUM > g_udLmcmcTablePoint)
    {
        udResult = g_audLmcmcTable[g_udLmcmcTablePoint];
        g_udLmcmcTablePoint++;
    }

    return udResult;
}

/**********************************************************************
* 函数名称：L2ssLkupReleaseLmcmcTableId
* 功能描述：回收组播表的基地址
* 输入参数：
* 输出参数：
* 返 回 值：
* 其他说明：
* 修改日期        版本号       修改人            修改内容
* ----------------------------------------------------------------------
* 2016/03/01       V1.0      Yaoziqiang            创建
************************************************************************/
UINT32 L2ssLkupReleaseLmcmcTableId(UINT32 udTableId)
{
    UINT32 udResult = BSP_ERROR;

    if ((0 < g_udLmcmcTablePoint) && (0 != udTableId))
    {
        g_udLmcmcTablePoint--;
        g_audLmcmcTable[g_udLmcmcTablePoint] = udTableId;

        udResult = BSP_OK;
    }

    return udResult;
}

/**********************************************************************
* 函数名称：L2ssLkupInitLpmTableId
* 功能描述：lpm指针库初始化
* 输入参数：
* 输出参数：
* 返 回 值：
* 其他说明：0号基址参与分配
* 修改日期        版本号       修改人            修改内容
************************************************************************/
UINT32 L2ssLkupInitLpmTableId(VOID)
{
    UINT32 udLoop = 0;

    for (udLoop = 0; udLoop < LPM_SIZE8_NUM; udLoop++)         /*最多可以配置4096个表项，但实际使用过程中只使用了2048个*/
    {
        g_audLpmSize8[udLoop] = L2SS_LPM_SIZE8_START_ID + udLoop * 8;
    }

    zte_memset_s(&g_audLpmSize4[0],sizeof(g_audLpmSize4), 0,sizeof(g_audLpmSize4));
    zte_memset_s(&g_audLpmSize2[0],sizeof(g_audLpmSize2), 0,sizeof(g_audLpmSize2));
    zte_memset_s(&g_audLpmSize1[0],sizeof(g_audLpmSize1), 0,sizeof(g_audLpmSize1));

    g_audLpmSize8Point = LPM_SIZE8_NUM;
    g_audLpmSize4Point = 0;
    g_audLpmSize2Point = 0;
    g_audLpmSize1Point = 0;

    return (UINT32)0;
}


/**********************************************************************
* 函数名称：L2ssLkupLpmSize8DealTableId
* 功能描述：
* 输入参数：
* 输出参数：
* 返 回 值：
* 其他说明：
* 修改日期        版本号       修改人            修改内容
************************************************************************/
UINT32 L2ssLkupLpmSize8DealTableId(UINT32 udApplyTabLen)
{
    UINT32 udLpmSize = 8;
    UINT32 udResult = 0;

    g_audLpmSize8Point--;
    udResult = g_audLpmSize8[g_audLpmSize8Point];
    udLpmSize -= udApplyTabLen;
    if (0 != udLpmSize)
    {
        g_audLpmSize4[g_audLpmSize4Point] = udResult + 4;
        g_audLpmSize4Point++;
        udLpmSize -= 4;
        if (0 != udLpmSize)
        {
            g_audLpmSize2[g_audLpmSize2Point] = udResult + 2;
            g_audLpmSize2Point++;
            udLpmSize -= 2;
            if (0 != udLpmSize)
            {
                g_audLpmSize1[g_audLpmSize1Point] = udResult + 1;
                g_audLpmSize1Point++;
            }
        }
    }

    return udResult;
}

/**********************************************************************
* 函数名称：L2ssLkupLpmSize4DealTableId
* 功能描述：
* 输入参数：
* 输出参数：
* 返 回 值：
* 其他说明：
* 修改日期        版本号       修改人            修改内容
************************************************************************/
UINT32 L2ssLkupLpmSize4DealTableId(UINT32 udApplyTabLen)
{
    UINT32 udLpmSize = 4;
    UINT32 udResult = 0;

    g_audLpmSize4Point--;
    udResult = g_audLpmSize4[g_audLpmSize4Point];
    udLpmSize -= udApplyTabLen;
    if (0 != udLpmSize)
    {
        g_audLpmSize2[g_audLpmSize2Point] = udResult + 2;
        g_audLpmSize2Point++;
        udLpmSize -= 2;
        if (0 != udLpmSize)
        {
            g_audLpmSize1[g_audLpmSize1Point] = udResult + 1;
            g_audLpmSize1Point++;
        }
    }

    return udResult;
}

/**********************************************************************
* 函数名称：L2ssLkupLpmSize2DealTableId
* 功能描述：
* 输入参数：
* 输出参数：
* 返 回 值：
* 其他说明：
* 修改日期        版本号       修改人            修改内容
************************************************************************/
UINT32 L2ssLkupLpmSize2DealTableId(UINT32 udApplyTabLen)
{
    UINT32 udLpmSize = 2;
    UINT32 udResult = 0;

    g_audLpmSize2Point--;
    udResult = g_audLpmSize2[g_audLpmSize2Point];
    udLpmSize -= udApplyTabLen;
    if (0 != udLpmSize)
    {
        g_audLpmSize1[g_audLpmSize1Point] = udResult + 1;
        g_audLpmSize1Point++;
    }

    return udResult;
}

/**********************************************************************
* 函数名称：L2ssLkupLpmSize1DealTableId
* 功能描述：
* 输入参数：
* 输出参数：
* 返 回 值：
* 其他说明：
* 修改日期        版本号       修改人            修改内容
* ----------------------------------------------------------------------
************************************************************************/
UINT32 L2ssLkupLpmSize1DealTableId(VOID)
{
    UINT32 udResult = 0;

    g_audLpmSize1Point--;
    udResult = g_audLpmSize1[g_audLpmSize1Point];
    return udResult;
}

/**********************************************************************
* 函数名称：L2ssLkupApplyLpmTableId
* 功能描述：申请lpm指针
* 输入参数：
* 输出参数：
* 返 回 值：
* 其他说明：
* 修改日期        版本号       修改人            修改内容
* ----------------------------------------------------------------------
* 2016/03/01       V1.0      Yaoziqiang            创建
************************************************************************/
UINT32 L2ssLkupApplyLpmTableId(E_LpmKeyType eKeyType)
{
    UINT32 udTabLen = 0;
    UINT32 udResult = 0xFFFFFFFF;

    switch (eKeyType)
    {
        case e_LpmKeyIpv4L16:
        case e_LpmKeyIpv6L16:
        {
            udTabLen = 1;
            if (0 != g_audLpmSize1Point)
            {
                udResult = L2ssLkupLpmSize1DealTableId();
                break;
            }
        }
        case e_LpmKeyIpv4L32:
        case e_LpmKeyExta:
        case e_LpmKeyIpv6L32:
        {
            if (0 == udTabLen)
            {
                udTabLen = 2;
            }
            if (0 != g_audLpmSize2Point)
            {
                udResult = L2ssLkupLpmSize2DealTableId(udTabLen);
                break;
            }
        }
        case e_LpmKeyExtb64:
        case e_LpmKeyIpv6L64:
        case e_LpmKeyExtbL64E:
        {
            if (0 == udTabLen)
            {
                udTabLen = 4;
            }
            if (0 != g_audLpmSize4Point)
            {
                udResult = L2ssLkupLpmSize4DealTableId(udTabLen);
                break;
            }
        }
        case e_LpmKeyIpv6L128:
        case e_LpmKeyExtbL128:
        case e_LpmKeyExtbL128E:
        {
            if (0 == udTabLen)
            {
                udTabLen = 8;
            }
            if (0 != g_audLpmSize8Point)
            {
                udResult = L2ssLkupLpmSize8DealTableId(udTabLen);
                break;
            }
        }
        default:
        break;
    }

    return udResult;
}

/**********************************************************************
* 函数名称：L2ssLkupReleaseLpmTableId
* 功能描述：回收lpm指针
* 输入参数：
* 输出参数：
* 返 回 值：
* 其他说明：
* 修改日期        版本号       修改人            修改内容
************************************************************************/
UINT32 L2ssLkupReleaseLpmTableId(E_LpmKeyType eKeyType, UINT32 udTableId)
{
    UINT32 udResult = 0;

    switch (eKeyType)
    {
        case e_LpmKeyIpv4L16:
        case e_LpmKeyIpv6L16:
        {
            g_audLpmSize1[g_audLpmSize1Point] = udTableId;
            g_audLpmSize1Point++;
            break;
        }

        case e_LpmKeyIpv4L32:
        case e_LpmKeyExta:
        case e_LpmKeyIpv6L32:
        {
            g_audLpmSize2[g_audLpmSize2Point] = udTableId;
            g_audLpmSize2Point++;
            break;
        }
        case e_LpmKeyExtb64:
        case e_LpmKeyIpv6L64:
        case e_LpmKeyExtbL64E:
        {
            g_audLpmSize4[g_audLpmSize4Point] = udTableId;
            g_audLpmSize4Point++;
            break;
        }
        case e_LpmKeyIpv6L128:
        case e_LpmKeyExtbL128:
        case e_LpmKeyExtbL128E:
        {
            g_audLpmSize8[g_audLpmSize8Point] = udTableId;
            g_audLpmSize8Point++;
            break;
        }

        default:
        {
            udResult = (UINT32)-1;
            break;
        }

    }

    return udResult;
}

/**********************************************************************
* 函数名称：NtlL2ssLkupInit
* 功能描述：
* 输入参数：
* 输出参数：
* 返 回 值：
* 其他说明：
* 修改日期        版本号       修改人            修改内容
* ----------------------------------------------------------------------
* 2016/03/01       V1.0      Yaoziqiang            创建
************************************************************************/
UINT32 L2ssLkupInit(VOID)
{
    L2ssLkupInitVlanId();        /*初始化vlan id的资源*/
    L2ssLkupInitLvIpTableId();   /*初始化vlan特性表的索引*/
    L2ssLkupInitLvtapTableId();  /*初始化标签行为的索引*/
    L2ssLkupInitLvlemTableId();  /*初始化VLAN输出特性表的索引*/
    L2ssLkupInitLmcmcTableId();  /*初始化组播表的索引*/
    L2ssLkupInitLpmTableId();
    return (UINT32)BSP_OK;
}

/**********************************************************************
* 函数名称：NtlL2ssProcInit
* 功能描述：PROC相关初始化
* 输入参数：
* 输出参数：
* 返 回 值：
* 其他说明：
* 修改日期        版本号       修改人            修改内容
* ----------------------------------------------------------------------
* 2016/03/01       V1.0      Yaoziqiang            创建
************************************************************************/
UINT32 L2ssProcInit(VOID)
{
    L2ssLkupInit();/*主要初始化表资源管理*/

    return (UINT32)BSP_OK;
}


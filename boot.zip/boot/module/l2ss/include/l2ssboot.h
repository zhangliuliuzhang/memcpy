/**************************************************************************
 * 版权所有 (C)2001, 深圳市中兴通讯股份有限公司
 *
 * 文件名称: zx211410boot.h
 * 文件标识:
 * 内容摘要:
 * 其它说明:
 * 当前版本: 
 * 作    者:
 * 完成日期:
 *
 * 修改记录1:
 *    修改日期: 
 *    版 本 号: 
 *    修 改 人: 
 *    修改内容: 创建
 * 修改记录2:
 **************************************************************************/

#ifndef _L2SSBOOT_H_
#define _L2SSBOOT_H_

#include <netinet/in.h>
#include <arpa/inet.h>
#include "l2sshw.h"
#include "opt_pcs_api.h"
#include "lyca_dev_api.h"
#include "ichal_opt_api.h"
#include "crmntl.h"
#include "icopthalcomm.h"
#include "regtbl.h"
/* Started by AICoder, pid:f350978b24i64501490f09ca20f5850e84b13a59 */
#include "phy.h"
/* Ended by AICoder, pid:f350978b24i64501490f09ca20f5850e84b13a59 */
#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

#define L2SS_M0_PORT              L2SS_TRXP32
#define L2SS_MIRROR_SMP_PORT      L2SS_TRXP42
#define L2SS_CEVA_PORT            L2SS_TRXP43
#define L2SS_R8_PORT              L2SS_TRXP44
#define L2SS_A53_OPT_ETH_PORT     L2SS_TRXP45
#define L2SS_A53_DBG_ETH_PORT     L2SS_TRXP46

#define L2SS_OPT_ETH_PORT        L2SS_TRXP34


#define L2SS_DEBUG_OPT_ETH_PORT     	 L2SS_TRXP1

#define OPT_SERDES_LANE_MAX_NUM (8)



#define ICHAL_ADAPT_FUNC_DEF(func, ...)         \
    {                                           \
        UINT32 retVal = BSP_OK;                 \
        retVal = IcHalApi##func(__VA_ARGS__);   \
        return retVal;                          \
    } 

#ifdef CONFIG_ZX211413
typedef enum
{
    CPRI_EXCEPT_10G_MODE = 0,
    ETH_MODE,
    CPRI_10G_MODE,
    RESERVED_MODE
}E_LYCA_CLK_CFG;
#endif

typedef struct  T_SERDES_PARAM {
    UINT32 serdesId;
    UINT32 laneId;
    UINT32 rate;
    DOUBLE chlen;
    E_LYCA_CLK_CFG mode;
    INT32 txEqEn;
    INT32 eoh0;
    INT32 eoh1;
    INT32 eoh2;
    INT32 eoh3;
} T_SERDES_PARAM;

typedef enum
{
    SERDES_ID_0=0,
    SERDES_ID_1,
    SERDES_ID_MAX,
}SERDES_ID;


typedef enum E_SERDES_LANE_IDS {
    SERDES_LANE_0 = 0,
    SERDES_LANE_1,
    SERDES_LANE_2,
    SERDES_LANE_3,
    SERDES_LANE_ID_BUFF
} E_SERDES_LANE_IDS;

enum _E_OPT_SERDES_INIT_STAT
{
    E_OPT_SERDES_PREPCS = 0,
    E_OPT_SERDES_PCS,
    E_OPT_SERDES_LOADFW,
    E_OPT_SERDES_TXINIT,
    E_OPT_SERDES_TXEQ,
    E_OPT_SERDES_RXINIT,
    E_OPT_SERDES_NORMAL,
    E_OPT_SERDES_APPRXINIT,
    E_OPT_SERDES_APPNORMAL,    
    E_OPT_SERDES_INIT_MAX
};

enum _E_DIF_CFG_TYPE
{
    E_DIF_ROUTEMAP_RX = 0,
    E_DIF_ROUTEMAP_TX,
    E_DIF_ROUTEMAP_FB,
    E_DIF_ROUTEMAP_204,
    E_DIF_ROUTEPARA_TX,
    E_DIF_DIFPARA_INIT,
    E_DIF_DIFPARA_SAMRATE,
    E_DIF_DIFPARA_CLK,
    E_DIF_DIFPARA_RESALLOC,
    E_DIF_DIFPARA_CFR,
    E_DIF_DIFPARA_FR,
    E_OPT_SERDES_PARA,
    E_DIF_DIFPARA_DTX,
    E_DIF_DIFPARA_PAPT,
    E_DIF_DIFPARA_GATE,
    E_OPT_ROECW_CFG,
    E_DIF_CFG_TYPE_MAX
};

typedef struct _T_DifCfgSave
{
    VOID* pAddr;
    UINT32 linkunm;
    UINT32 difChNum;
}T_DifCfgSave;


typedef T_PCS_CONFIG_TBL T_BspHalAdaptPcsCfg;
typedef T_NtlPortCfg T_BspHalAdaptNtlPortCfg;
typedef T_TRPG_GROUP_MODE_CFG T_BspHalAdaptNtlTrxpCfg;

#ifndef STRUCT_SERDES_RXINIT_PARA
/*pma RX初始化参数配置表*/
typedef struct
{
    INT8   phaseMin;    /*minimum CDR opt phase (默认配-24)*/
    INT8   phaseMax;    /*maximum CDR opt phase (53G配4，其他配24)*/
    UINT32 uVga;        /*VGA cfg (默认配3)*/
    UINT32 uCmtermCtrl;  /*term ctrl(默认配5)*/
}T_OPT_SERDES_RX_INIT_PARA;   /*pcs通道配置表*/
#define STRUCT_SERDES_RXINIT_PARA
#endif

typedef T_OPT_SERDES_RX_INIT_PARA T_BspHalAdaptSerdesRxCfg;

#define SERDES_RATE_1G25  (1250000U)     

UINT32 BootNtlInit(void);
/* Started by AICoder, pid:la1c13b7f3c3ff114325098010a237123f351c21 */
UINT32 BootSetEth0DebugIpMacAddr();
UINT32 BootXmacInit(UINT32 portmap);
UINT32 BootSerdesInit(UINT32 portmap, UINT32 optIndex);
extern UINT32 IcHalApiLycaTccSwitch(UINT32 serdesId, UINT32 laneId);
extern UINT32 IcHalApiLycaLoadFw(UINT32 serdesId, UINT32 laneId);
extern UINT32 IcHalApiLycaSetTxFirCoff(UINT32 serdesId, UINT32 laneId, UINT32 eoh0, UINT32 eoh1, UINT32 eoh2, UINT32 eoh3);

#if  defined(CONFIG_ZX211413)
extern UINT32 IcHalApiLycaInitRx(UINT32 serdesId, UINT32 laneId, T_OPT_SERDES_RX_INIT_PARA *initPara);
extern UINT32 IcHalApiLycaInitTx(UINT32 serdesId, UINT32 laneId, UINT32 rate, DOUBLE ldb);
#elif  defined(CONFIG_ZX211412)
extern UINT32 IcHalApiLycaInitRx(UINT32 serdesId, UINT32 laneId);
extern UINT32 IcHalApiLycaInitTx(UINT32 serdesId, UINT32 laneId, UINT32 rate, E_LYCA_CLK_CFG clkMode, DOUBLE ldb);
UINT32 BootOptDebugNetInit(UINT32 portmap);
#endif
/* Ended by AICoder, pid:la1c13b7f3c3ff114325098010a237123f351c21 */
#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif


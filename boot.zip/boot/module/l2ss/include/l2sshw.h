/*
 * Copyright 2009-2011 Freescale Semiconductor, Inc.
 *
 * SPDX-License-Identifier:	GPL-2.0+
 */

#ifndef __L2SS_HW_H__
#define __L2SS_HW_H__

#ifdef  CONFIG_ZX211412
#include "zx211412boot.h"
#elif CONFIG_ZX211413
#include "zx211413boot.h"
#endif

/*public*/
/* 根据所在位域的偏移，计算出该位域对应的掩码 */
#define BIT_FIELD_MASK_GET(bitoff, bitfieldlen) \
(((0x01 << (bitfieldlen)) - 1) << (bitoff))

/* 从指定变量或数据中提取出指定位域的数据 */
#define BIT_FIELD_GET(val, bitoff, bitfieldlen) \
((val) & BIT_FIELD_MASK_GET(bitoff, bitfieldlen))

/* 修改指定数据中的位域值 */
#define BIT_FIELD_SET(var, val, bitoff, bitlen) \
((var) = (((var) & (~ BIT_FIELD_MASK_GET(bitoff, bitlen))) | ((val) << (bitoff))))


#define BIT0     		0x00000001u
#define BIT1     		0x00000002u
#define BIT2     		0x00000004u
#define BIT3     		0x00000008u
#define BIT4     		0x00000010u
#define BIT5     		0x00000020u
#define BIT6     		0x00000040u
#define BIT7     		0x00000080u
#define BIT8     		0x00000100u
#define BIT9     		0x00000200u
#define BIT10    		0x00000400u
#define BIT11    		0x00000800u
#define BIT12    		0x00001000u
#define BIT13    		0x00002000u
#define BIT14    		0x00004000u
#define BIT15    		0x00008000u
#define BIT16    		0x00010000u
#define BIT17    		0x00020000u
#define BIT18    		0x00040000u
#define BIT19    		0x00080000u
#define BIT20    		0x00100000u
#define BIT21    		0x00200000u
#define BIT22    		0x00400000u
#define BIT23    		0x00800000u
#define BIT24    		0x01000000u
#define BIT25    		0x02000000u
#define BIT26    		0x04000000u
#define BIT27    		0x08000000u
#define BIT28    		0x10000000u
#define BIT29    		0x20000000u
#define BIT30    		0x40000000u
#define BIT31    		0x80000000u

/*位宽常量定义 */
#define BW1          	((UINT32)0x00000001)
#define BW2          	((UINT32)0x00000003)
#define BW3          	((UINT32)0x00000007)
#define BW4          	((UINT32)0x0000000f)
#define BW5          	((UINT32)0x0000001f)
#define BW6          	((UINT32)0x0000003f)
#define BW7          	((UINT32)0x0000007f)
#define BW8          	((UINT32)0x000000ff)
#define BW9          	((UINT32)0x000001ff)
#define BW10         	((UINT32)0x000003ff)
#define BW11         	((UINT32)0x000007ff)
#define BW12         	((UINT32)0x00000fff)
#define BW13         	((UINT32)0x00001fff)
#define BW14         	((UINT32)0x00003fff)
#define BW15         	((UINT32)0x00007fff)
#define BW16         	((UINT32)0x0000ffff)
#define BW17         	((UINT32)0x0001ffff)
#define BW18         	((UINT32)0x0003ffff)
#define BW19         	((UINT32)0x0007ffff)
#define BW20         	((UINT32)0x000fffff)
#define BW21         	((UINT32)0x001fffff)
#define BW22         	((UINT32)0x003fffff)
#define BW23         	((UINT32)0x007fffff)
#define BW24         	((UINT32)0x00ffffff)
#define BW25         	((UINT32)0x01ffffff)
#define BW26         	((UINT32)0x03ffffff)
#define BW27         	((UINT32)0x07ffffff)
#define BW28         	((UINT32)0x0fffffff)
#define BW29         	((UINT32)0x1fffffff)
#define BW30         	((UINT32)0x3fffffff)
#define BW31         	((UINT32)0x7fffffff)
#define BW32            ((UINT32)0xffffffff)


#define L2SS_B0_ADDR_OFFSET 					0x03800000  //ntltro 外部端口，PMON/CNTP/CFGI/BLK
#define L2SS_B1_ADDR_OFFSET 					0x04C00000  //ntlmac0 CNTP CFGI BLK
#define L2SS_B2_ADDR_OFFSET 					0x04C00000  //保留，以确保与IC3.0模块号对应起来
#define L2SS_B3A_ADDR_OFFSET 					0x02800000 //ntltri_S0 内部端口 CNTP/CFGI/BLK
#define L2SS_B3B_ADDR_OFFSET 					0x02C00000  //ntltri_S1 代理端口CFGI
#define L2SS_B4_ADDR_OFFSET 					0x03000000  //ntlppb :包含PARSE,PKTM,BMAN PMON/CNTP/CFGI/BLK
#define L2SS_B5_ADDR_OFFSET 					0x05000000  //ntlplll :包含PREP,L2FM,L2MC,LOOKUP PMON/CNTP/CFGI/BLK
#define L2SS_B6_ADDR_OFFSET 					0x06000000  //QMAN PMON/CNTP/CFGI/BLK

#define L2SS_CFGI_ID_B0_ADDR 					(0x00100000 + L2SS_B0_ADDR_OFFSET)  /*troa0 外部端口  0-7*/
#define L2SS_CFGI_ID_B1_ADDR 					(0x00020000 + L2SS_B1_ADDR_OFFSET)  /*xmac0*/
#define L2SS_CFGI_ID_B2_ADDR 					(0x00020000 + L2SS_B2_ADDR_OFFSET)  /*未使用*/
#define L2SS_CFGI_ID_B3A_ADDR 					(0x000F0000 + L2SS_B3A_ADDR_OFFSET)  /*trir_axi0 内部端口 32-47*/
#define L2SS_CFGI_ID_B3B_ADDR 					(0x00000000 + L2SS_B3B_ADDR_OFFSET)  /*trir_axi1,新增5个代理口的*/
#define L2SS_CFGI_ID_B4_ADDR 					(0x00070000 + L2SS_B4_ADDR_OFFSET)  /*PARSE,PKTM,BMAN*/ /*PTP*/
#define L2SS_CFGI_ID_B5_ADDR 					(0x00000000 + L2SS_B5_ADDR_OFFSET)  /*PREP,L2FM,L2MC,LOOKUP*/
#define L2SS_CFGI_ID_B6_ADDR 					(0x00700000 + L2SS_B6_ADDR_OFFSET)  /*QMAN*/

#define CFGI_GLOBAL_OFFSET 						(0)
#define CFGI_INNER_OFFSET  						(0x4000)
#define CFGI_AGENCY_OFFSET 						(0x8000)

#define L2SS_BASE_LEN                        	(0x04)

/*CFGI*/
#define L2SS_CFGI_DEBUG_BASE                 	(L2SS_CFGI_ID_B6_ADDR + 0x00000000)
#define L2SS_CFGI_GLOBAL_DEBUG_EN            	(L2SS_CFGI_DEBUG_BASE + 0x00000400)
#define L2SS_CFGI_ENG_ENABLE_MODE               (L2SS_CFGI_ID_B6_ADDR + 0x000002D0)  /*引擎工作模式,QMAN,Plll,ppb三个模块*/
#define L2SS_CFGI_IPORT_GROUP_ID                (L2SS_CFGI_ID_B6_ADDR + 0x00000044)

/*PARS*/
#define L2SS_PARS_BASE_ADDRESS                  (L2SS_B4_ADDR_OFFSET + 0x00100000)            /*L2SS模块PARS全局寄存器组的基址*/            
#define L2SS_PARS_CNT_EN                        (L2SS_PARS_BASE_ADDRESS + 0x2028)      /**各个解析单元的各种计数器功能使能*/
#define L2SS_PARS_PORT_0_15_PARSER_SEL          (L2SS_PARS_BASE_ADDRESS + 0x1000)      /*0-15逻辑端口的解析单元的选择*/ 
#define L2SS_PARS_CTRL_REG0                  	(L2SS_PARS_BASE_ADDRESS + 0x2064)      /*0~5端口解析层次的配置*/
#define L2SS_PARS_CTRL_REG2                     (L2SS_PARS_BASE_ADDRESS + 0x245C)      /*12~17端口解析层次的配置*/

/*PREP*/
#define L2SS_PREP_BASE_ADDRESS         			(L2SS_B5_ADDR_OFFSET + 0x00100000)
#define L2SS_PREP_ENG_BASE(n)                   (L2SS_PREP_BASE_ADDRESS + 0x10000*(n)) /* 预处理模块有4套引擎，每套引擎地址相差0x10000 */
#define L2SS_PREP_IBUF_BASE_ADDR(n, m)          (L2SS_PREP_ENG_BASE(n) + 0x00004000 + ((m)*L2SS_BASE_LEN))   
#define L2SS_PREP_RXBUFA_INFO1(n)               (L2SS_PREP_ENG_BASE(n) + 0x00000200 + 0x00000000)
#define L2SS_PREP_RXBUFA_INFO2(n)               (L2SS_PREP_ENG_BASE(n) + 0x00000200 + 0x00000004)
#define L2SS_PREP_RXBUFA_INFO3(n)               (L2SS_PREP_ENG_BASE(n) + 0x00000200 + 0x00000008)
#define L2SS_PREP_CNT_START_EN(n)         		(L2SS_PREP_ENG_BASE(n) + 0x00002000u + 0x00000090u)
#define L2SS_PREP_CNT_CTRL(n)             		(L2SS_PREP_ENG_BASE(n) + 0x00002000u + 0x00000074u)
#define L2SS_PREP_PARS_PKT_ERR_CTRL(n)          (L2SS_PREP_ENG_BASE(n) + 0x00002000u + 0x00000000u)

/*L2fm*/
#define L2SS_L2FM_BASE_ADDRESS          		(L2SS_B5_ADDR_OFFSET + 0x00200000)
#define L2SS_L2FM_ENG_BASE(n)           		(L2SS_L2FM_BASE_ADDRESS+0x80000+0x20000*(n))
#define L2SS_L2FM_IBFIFO_OAM(n,m)         		(L2SS_L2FM_ENG_BASE(n) + 0x000002C4 + ((m-1)*L2SS_BASE_LEN))
#define L2SS_L2FM_IBUFFER_BASE_ADDR(n)  		(L2SS_L2FM_ENG_BASE(n) + 0x00001000)
#define L2SS_L2FM_CTRL                  		(L2SS_L2FM_BASE_ADDRESS + 0x00000414u)

/*l2mc*/
#define L2SS_L2MC_BASE_ADDRESS          		(L2SS_B5_ADDR_OFFSET + 0x00300000)
#define L2SS_L2MC_ENG_BASE(n)           		(L2SS_L2MC_BASE_ADDRESS + 0x80000 + 0x20000*(n))
#define L2SS_L2MC_IBFIFO_OAM(n,m)       		(L2SS_L2MC_ENG_BASE(n) + 0x00000200 + ((m-1)*L2SS_BASE_LEN))
#define L2SS_L2MC_PD_RAM(n,m)             		(L2SS_L2MC_ENG_BASE(n) + 0x00004000 + ((m)*L2SS_BASE_LEN))
#define L2SS_L2MC_CNT_ENABLE                    (L2SS_L2MC_BASE_ADDRESS + 0x00002014u)

/*QMAN*/
#define L2SS_QMAN_BASE_ADDRESS               	(L2SS_B6_ADDR_OFFSET 	   + 0x00000000)
#define L2SS_QMAN_NOR_ENG_BASE(n)            	(L2SS_QMAN_BASE_ADDRESS    + 0x00000000 + 0x100000*(n))
#define L2SS_QMAN_GLOBAL_BASE                	(L2SS_QMAN_BASE_ADDRESS    + 0x00600000)
#define L2SS_QMAN_DLP2QLP_MAP_CFG(n)         	(L2SS_QMAN_GLOBAL_BASE     + 0x00002b00 + ((n)*L2SS_BASE_LEN))
#define L2SS_QMAN_NOR_SELF_INIT_DONE(n)     	(L2SS_QMAN_NOR_ENG_BASE(0) + 0x00002024)

/*BMAN*/
#define L2SS_BMAN_BASE_ADDRESS                  (L2SS_B4_ADDR_OFFSET + 0x00400000u)
#define L2SS_BMAN_CNT_EN                        (L2SS_BMAN_BASE_ADDRESS + 0x000020D8u)

/*LKUP*/
#define L2SS_LKUP_BASE_ADDRESS               	(L2SS_B5_ADDR_OFFSET 	+ 0x00400000)
#define L2SS_LKUP_OAM_BASE                   	(L2SS_LKUP_BASE_ADDRESS + 0x00000400)
#define L2SS_LKUP_SRAM_BASE                  	(L2SS_LKUP_BASE_ADDRESS + 0x00020000)  
#define L2SS_LKUP_CONFIG_BASE                	(L2SS_LKUP_BASE_ADDRESS + 0x00002000)    

#define L2SS_LKUP_SRAM_CONFIG_EN             	(L2SS_LKUP_OAM_BASE     + 0x00000000)
#define L2SS_LKUP_DTBL_CPU_RDWR_REQ          	(L2SS_LKUP_OAM_BASE     + 0x00000044)
#define L2SS_LKUP_DTBL_CPU_RDWR_RDY          	(L2SS_LKUP_OAM_BASE     + 0x00000048)

#define L2SS_LKUP_HASH_BDEL_REQ              	(L2SS_LKUP_CONFIG_BASE  + 0x00000140)
#define L2SS_LKUP_HASH_BDEL_ACK              	(L2SS_LKUP_CONFIG_BASE  + 0x0000014c)
#define L2SS_LKUP_CPU_HASH_KEY(n)            	(L2SS_LKUP_CONFIG_BASE  + 0x00000088 + ((n)*L2SS_BASE_LEN))  
#define L2SS_LKUP_CPU_HASH_RESP_RSLT(n)      	(L2SS_LKUP_CONFIG_BASE  + 0x000000b0 + ((n)*L2SS_BASE_LEN))
#define L2SS_LKUP_CPU_HASH_REQ               	(L2SS_LKUP_CONFIG_BASE  + 0x00000080)      
#define L2SS_LKUP_CPU_HASH_RESP              	(L2SS_LKUP_CONFIG_BASE  + 0x00000084)     
#define L2SS_LKUP_HASH_CPU_ADD_CFG           	(L2SS_LKUP_CONFIG_BASE  + 0x00000100)

#define L2SS_LKUP_LK_VLAN_EGR_PKTM_ADDR(n)   	(L2SS_LKUP_SRAM_BASE 	+ 0x00010000 + ((n)*L2SS_BASE_LEN))
#define L2SS_LKUP_LK_MC_L2MC_ADDR(n)         	(L2SS_LKUP_SRAM_BASE 	+ 0x00014000 + ((n)*L2SS_BASE_LEN))
#define L2SS_LKUP_HASHB_DTL_BASE_ADDR(n)     	(L2SS_LKUP_SRAM_BASE 	+ 0x00038000 + ((n)*L2SS_BASE_LEN*8))
#define L2SS_LKUP_LK_SRC_LPORTL_PREP_ADDR(n) 	(L2SS_LKUP_SRAM_BASE 	+ 0x00015080 + ((n)*L2SS_BASE_LEN*2))
#define L2SS_LKUP_LK_SRC_LPORTH_PREP_ADDR(n) 	(L2SS_LKUP_SRAM_BASE 	+ 0x00015084 + ((n)*L2SS_BASE_LEN*2))
#define L2SS_LKUP_LK_VLAN_TAG_ACT_PREP_ADDR(n)  (L2SS_LKUP_SRAM_BASE 	+ 0x00015000 + ((n)*L2SS_BASE_LEN))
#define L2SS_LKUP_LPM_SRAML_BASE_ADDR(n)        (L2SS_LKUP_SRAM_BASE    + 0x00050000u + ((n)*L2SS_BASE_LEN*2))
#define L2SS_LKUP_LPM_SRAMH_BASE_ADDR(n)        (L2SS_LKUP_SRAM_BASE    + 0x00050004u + ((n)*L2SS_BASE_LEN*2))
#define L2SS_LKUP_LPM_TCAML_BASE_ADDR(n)        (L2SS_LKUP_SRAM_BASE    + 0x00040000u + ((n)*L2SS_BASE_LEN*2))
#define L2SS_LKUP_LPM_TCAMH_BASE_ADDR(n)        (L2SS_LKUP_SRAM_BASE    + 0x00040004u + ((n)*L2SS_BASE_LEN*2))

#define L2SS_LKUP_CNT_START_EN         			(L2SS_LKUP_CONFIG_BASE + 0x00000500u)
#define L2SS_LKUP_CPU_LPM_KEY(n)      		    (L2SS_LKUP_CONFIG_BASE + 0x00000008u + ((n)*L2SS_BASE_LEN))

#define L2SS_LKUP_CPU_LPM_REQ           		(L2SS_LKUP_CONFIG_BASE + 0x00000000u)
#define L2SS_LKUP_CPU_LPM_RESP         			(L2SS_LKUP_CONFIG_BASE + 0x00000004u)
#define L2SS_LKUP_CPU_LPM_RESP_RSLT_0  			(L2SS_LKUP_CONFIG_BASE + 0x00000030u)
#define L2SS_LKUP_CPU_LPM_RESP_RSLT_1   		(L2SS_LKUP_CONFIG_BASE + 0x00000034u)

#define L2SS_LKUP_LPM_CPU_RDWR_REQ      		(L2SS_LKUP_OAM_BASE + 0x00000014u)
#define L2SS_LKUP_LPM_CPU_RDWR_RDY      		(L2SS_LKUP_OAM_BASE + 0x00000018u)


/*PKTM*/
#define L2SS_PKTM_BASE_ADDRESS               	(L2SS_B4_ADDR_OFFSET 	+ 0x00300000)
#define L2SS_PKTM_DPP_2DVPP_SLAVE_MAP(n)     	(L2SS_PKTM_BASE_ADDRESS + 0x000003C0 + (n)*L2SS_BASE_LEN )
#define L2SS_PKTM_DPP_2DVPP_MAST_MAP(n)      	(L2SS_PKTM_BASE_ADDRESS + 0x00000340 + (n)*L2SS_BASE_LEN )  
#define L2SS_PKTM_CNT_CTRL             			(L2SS_PKTM_BASE_ADDRESS + 0x00000404u) /*统计使能*/

/*TRPG*/
#define L2SS_EPORT_BLOCK_ADDR   				(L2SS_B0_ADDR_OFFSET) 
#define L2SS_IPORT_BLOCK_ADDR      				(L2SS_B3A_ADDR_OFFSET)

#define L2SS_PORT_BLOCK_SPAN      				(0x60000)
#define L2SS_PORT_SPAN            				(0x8000)

#define L2SS_PORT_LIMIT_EN        				(0x00000450)
#define L2SS_PORT_CTRL            				(0x00000404)    /*接收、发送、主备、统计使能*/
#define L2SS_PORT_DEBUG            				(0x00000408)    /*接收、发送、主备、统计使能*/
#define L2SS_PORT_ALARM_EVENT     				(0x0000002C)


/*Agent*/
#define L2SS_DDR_BLOCK_SIZE       				(0x00000700)
#define L2SS_CTRL_TRXP_RST        				(0x00000100)

#define L2SS_RXFIFO_EMPTY         				(0x00000648)
#define L2SS_RXFIFO_NUMB          				(0x00000644)
#define L2SS_FREE_TXFIFO_EMPTY    				(0x00000688)
#define L2SS_FREE_TXFIFO_NUMB     				(0x00000684)

#define L2SS_TXFIFO_WR_DATA       				(0x00001200)
#define L2SS_RXFIFO_RD_DATA       				(0x00001240)
#define L2SS_FREE_RXFIFO_WR_DATA  				(0x000012C0)
#define L2SS_FREE_TXFIFO_RD_DATA  				(0x00001280)


#define L2SS_TXCFG_NUMB           				(0x00000500)
#define L2SS_TXPKT_NUMB           				(0x00000504)
#define L2SS_RXCFG_NUMB           				(0x00000508)
#define L2SS_RXPKT_NUMB           				(0x0000050C)

#define L2SS_TXFIFO_NUMB           				(0x00000604)
#define L2SS_TXFIFO_FULL           				(0x00000608)
#define L2SS_FREE_RXFIFO_NUMB      				(0x000006C4)
#define L2SS_FREE_RXFIFO_FULL      				(0x000006C8)

/*配置内部端口总倒换*/
#define L2SS_TRXP_R_ORDER	     				(L2SS_B3A_ADDR_OFFSET +  0x110000 + 0x00002060)
#define L2SS_TRXP_W_ORDER   	  				(L2SS_B3A_ADDR_OFFSET +  0x110000 + 0x00006060)


#define L_DEBUG_ENABLE_VALUE                  	0xA53CF0CAu

#define L2SS_HASH_LOOP              			0x00
#define L2SS_HASH_ADD               			0x01
#define L2SS_HASH_DELETE            			0x02
#define L2SS_HASH_MODIFY            			0x03

#define L2SS_HASH_FM                			0x00
#define L2SS_HASH_MAC               			0x01
#define L2SS_HASH_VLAN             				0x02

/*debug*/
#define L2SS_CFGI_CMD_SPAN					    0x08

#define L2SS_CFGI_PARS_DEBUG_REQ         (L2SS_CFGI_DEBUG_BASE + 0x00000500)
#define L2SS_CFGI_PARS_DEBUG_CMD         (L2SS_CFGI_DEBUG_BASE + 0x00000504)
#define L2SS_CFGI_PARS1_DEBUG_REQ        (L2SS_CFGI_DEBUG_BASE + 0x00000508)
#define L2SS_CFGI_PARS1_DEBUG_CMD        (L2SS_CFGI_DEBUG_BASE + 0x0000050C)
#define L2SS_CFGI_PARS2_DEBUG_REQ        (L2SS_CFGI_DEBUG_BASE + 0x00000510)
#define L2SS_CFGI_PARS2_DEBUG_CMD        (L2SS_CFGI_DEBUG_BASE + 0x00000514)
#define L2SS_CFGI_PARS3_DEBUG_REQ        (L2SS_CFGI_DEBUG_BASE + 0x00000518)
#define L2SS_CFGI_PARS3_DEBUG_CMD        (L2SS_CFGI_DEBUG_BASE + 0x0000051C)

#define L2SS_CFGI_BMAN_DEBUG_REQ         (L2SS_CFGI_DEBUG_BASE + 0x00000520)
#define L2SS_CFGI_BMAN_DEBUG_CMD         (L2SS_CFGI_DEBUG_BASE + 0x00000524)    

#define L2SS_CFGI_PKTM_DEBUG_REQ         (L2SS_CFGI_DEBUG_BASE + 0x00000528)
#define L2SS_CFGI_PKTM_DEBUG_CMD         (L2SS_CFGI_DEBUG_BASE + 0x0000052c)
#define L2SS_CFGI_PKTM1_DEBUG_REQ        (L2SS_CFGI_DEBUG_BASE + 0x00000530)
#define L2SS_CFGI_PKTM1_DEBUG_CMD        (L2SS_CFGI_DEBUG_BASE + 0x00000534)
#define L2SS_CFGI_PKTM2_DEBUG_REQ        (L2SS_CFGI_DEBUG_BASE + 0x00000538)
#define L2SS_CFGI_PKTM2_DEBUG_CMD        (L2SS_CFGI_DEBUG_BASE + 0x0000053c)
#define L2SS_CFGI_PKTM3_DEBUG_REQ        (L2SS_CFGI_DEBUG_BASE + 0x00000540)
#define L2SS_CFGI_PKTM3_DEBUG_CMD        (L2SS_CFGI_DEBUG_BASE + 0x00000544)


#define L2SS_CFGI_PREP_DEBUG_REQ         (L2SS_CFGI_DEBUG_BASE + 0x00000548)
#define L2SS_CFGI_PREP_DEBUG_CMD         (L2SS_CFGI_DEBUG_BASE + 0x0000054c)
#define L2SS_CFGI_PREP1_DEBUG_REQ        (L2SS_CFGI_DEBUG_BASE + 0x00000550)
#define L2SS_CFGI_PREP1_DEBUG_CMD        (L2SS_CFGI_DEBUG_BASE + 0x00000554)
#define L2SS_CFGI_PREP2_DEBUG_REQ        (L2SS_CFGI_DEBUG_BASE + 0x00000558)
#define L2SS_CFGI_PREP2_DEBUG_CMD        (L2SS_CFGI_DEBUG_BASE + 0x0000055c)
#define L2SS_CFGI_PREP3_DEBUG_REQ        (L2SS_CFGI_DEBUG_BASE + 0x00000560)
#define L2SS_CFGI_PREP3_DEBUG_CMD        (L2SS_CFGI_DEBUG_BASE + 0x00000564)


#define L2SS_CFGI_L2FM_DEBUG_REQ         (L2SS_CFGI_DEBUG_BASE + 0x00000568)
#define L2SS_CFGI_L2FM_DEBUG_CMD         (L2SS_CFGI_DEBUG_BASE + 0x0000056C)
#define L2SS_CFGI_L2FM1_DEBUG_REQ        (L2SS_CFGI_DEBUG_BASE + 0x00000570)
#define L2SS_CFGI_L2FM1_DEBUG_CMD        (L2SS_CFGI_DEBUG_BASE + 0x00000574)
#define L2SS_CFGI_L2FM2_DEBUG_REQ        (L2SS_CFGI_DEBUG_BASE + 0x00000578)
#define L2SS_CFGI_L2FM2_DEBUG_CMD        (L2SS_CFGI_DEBUG_BASE + 0x0000057C)
#define L2SS_CFGI_L2FM3_DEBUG_REQ        (L2SS_CFGI_DEBUG_BASE + 0x00000580)
#define L2SS_CFGI_L2FM3_DEBUG_CMD        (L2SS_CFGI_DEBUG_BASE + 0x00000584)


#define L2SS_CFGI_L2MC_DEBUG_REQ         (L2SS_CFGI_DEBUG_BASE + 0x00000588)
#define L2SS_CFGI_L2MC_DEBUG_CMD         (L2SS_CFGI_DEBUG_BASE + 0x0000058c)
#define L2SS_CFGI_L2MC1_DEBUG_REQ        (L2SS_CFGI_DEBUG_BASE + 0x00000590)
#define L2SS_CFGI_L2MC1_DEBUG_CMD        (L2SS_CFGI_DEBUG_BASE + 0x00000594)
#define L2SS_CFGI_L2MC2_DEBUG_REQ        (L2SS_CFGI_DEBUG_BASE + 0x00000598)
#define L2SS_CFGI_L2MC2_DEBUG_CMD        (L2SS_CFGI_DEBUG_BASE + 0x0000059c)
#define L2SS_CFGI_L2MC3_DEBUG_REQ        (L2SS_CFGI_DEBUG_BASE + 0x000005A0)
#define L2SS_CFGI_L2MC3_DEBUG_CMD        (L2SS_CFGI_DEBUG_BASE + 0x000005A4)

#define L2SS_CFGI_LKUP_HASHA_DEBUG_REQ        (L2SS_CFGI_DEBUG_BASE + 0x000005A8)
#define L2SS_CFGI_LKUP_HASHA_DEBUG_CMD        (L2SS_CFGI_DEBUG_BASE + 0x000005AC)
#define L2SS_CFGI_LKUP_HASHB_DEBUG_REQ        (L2SS_CFGI_DEBUG_BASE + 0x000005B0)
#define L2SS_CFGI_LKUP_HASHB_DEBUG_CMD        (L2SS_CFGI_DEBUG_BASE + 0x000005B4)
#define L2SS_CFGI_LKUP_LPM_DEBUG_REQ          (L2SS_CFGI_DEBUG_BASE + 0x000005B8)
#define L2SS_CFGI_LKUP_LPM_DEBUG_CMD          (L2SS_CFGI_DEBUG_BASE + 0x000005BC)
#define L2SS_CFGI_LKUP_DTBL_DEBUG_REQ         (L2SS_CFGI_DEBUG_BASE + 0x00000C0)
#define L2SS_CFGI_LKUP_DTBL_DEBUG_CMD         (L2SS_CFGI_DEBUG_BASE + 0x000005C4)

#define L2SS_CFGI_QMAN_DEBUG_REQ              (L2SS_CFGI_DEBUG_BASE + 0x000005C8)
#define L2SS_CFGI_QMAN_DEBUG_CMD              (L2SS_CFGI_DEBUG_BASE + 0x000005CC)
#define L2SS_CFGI_QMAN1_DEBUG_REQ             (L2SS_CFGI_DEBUG_BASE + 0x000005D0)
#define L2SS_CFGI_QMAN1_DEBUG_CMD             (L2SS_CFGI_DEBUG_BASE + 0x000005D4)
#define L2SS_CFGI_QMAN2_DEBUG_REQ             (L2SS_CFGI_DEBUG_BASE + 0x000005D8)
#define L2SS_CFGI_QMAN2_DEBUG_CMD             (L2SS_CFGI_DEBUG_BASE + 0x000005DC)
#define L2SS_CFGI_QMAN3_DEBUG_REQ             (L2SS_CFGI_DEBUG_BASE + 0x000005E0)
#define L2SS_CFGI_QMAN3_DEBUG_CMD             (L2SS_CFGI_DEBUG_BASE + 0x000005E4)

#define L2SS_CFGI_QMAN_TSN0_DEBUG_REQ         (L2SS_CFGI_DEBUG_BASE + 0x000005E8)
#define L2SS_CFGI_QMAN_TSN0_DEBUG_CMD         (L2SS_CFGI_DEBUG_BASE + 0x000005EC)
#define L2SS_CFGI_QMAN_TSN1_DEBUG_REQ         (L2SS_CFGI_DEBUG_BASE + 0x000005F0)
#define L2SS_CFGI_QMAN_TSN1_DEBUG_CMD         (L2SS_CFGI_DEBUG_BASE + 0x000005F4)




/*mac*/
#define XMAC_MAC_CFG               			 (0x40)                 /* XMAC配置寄存器 */
#define XMAC_MAC_CTRL              			 (0x44)                 /* XMAC控制寄存器 */
#define XMAC_PAUSE_TIME            			 (0x50)                 /* XMAC pasue帧时间寄存器 */
#define XMAC_MAX_FRM_LEN          			 (0x54)                 /* XMAC最大帧长配置寄存器 */
#define XMAC_TX_IPG_LEN            			 (0x58)                 /* XMAC IPG配置寄存器 */
#define XMAC_TX_PREAMBLE_LEN      		     (0x5C)                 /* XMAC 配置发送报文序文长度寄存器 */
#define XMAC_MAC_ADDR_HIGH        			 (0x60)                 /* XMAC 配置MAC地址高位16bit */
#define XMAC_MAC_ADDR_LOW         			 (0x64)                 /* XMAC 配置MAC地址低位32bit */
#define XMAC_PCS_RPD              			 (0xD0)                 /* XMAC RCV PATH DELAY */
#define XMAC_PCS_TPD               			 (0xD4)                 /* XMAC TX PATH DELAY */


#define XMAC_MAC_MTU_CFG_POS                 (0)
#define XMAC_MAC_MTU_CFG_MASK                (0x3fff << XMAC_MAC_MTU_CFG_POS)

#define XMAC_MAC_TX_EN_CFG_POS               (2)
#define XMAC_MAC_TX_EN_CFG_MASK              (1 << XMAC_MAC_TX_EN_CFG_POS)

#define XMAC_MAC_RCV_EN_CFG_POS              (3)
#define XMAC_MAC_RCV_EN_CFG_MASK             (1 << XMAC_MAC_RCV_EN_CFG_POS)

#define XMAC_MAC_STATIC_EN_CFG_POS           (4)
#define XMAC_MAC_STATIC_EN_CFG_MASK          (1 << XMAC_MAC_STATIC_EN_CFG_POS)

#define XMAC_MAC_RCV_FLOW_EN_POS             (5)
#define XMAC_MAC_RCV_FLOW_EN_MASK            (1 << XMAC_MAC_RCV_FLOW_EN_POS)

#define XMAC_MAC_TX_FLOW_EN_POS              (6)
#define XMAC_MAC_TX_FLOW_EN_MASK             (1 << XMAC_MAC_TX_FLOW_EN_POS)


#define XMAC_MAC_FORWARD_FCS_EN_FOR_RCV_POS  (7)
#define XMAC_MAC_FORWARD_FCS_EN_FOR_RCV_MASK (1 << XMAC_MAC_FORWARD_FCS_EN_FOR_RCV_POS)

#define XMAC_MAC_ADD_FCS_EN_FOR_TX_POS       (8)
#define XMAC_MAC_ADD_FCS_EN_FOR_TX_MASK      (1 << XMAC_MAC_ADD_FCS_EN_FOR_TX_POS)

#define XMAC_MAC_REPLACE_SRC_MAC_EN_POS      (9)
#define XMAC_MAC_REPLACE_SRC_MAC_EN_MASK     (BW1 << XMAC_MAC_REPLACE_SRC_MAC_EN_POS)

#define XMAC_MAC_ADD_PAD_EN_FOR_TX_POS       (10)
#define XMAC_MAC_ADD_PAD_EN_FOR_TX_MASK      (BW1 << XMAC_MAC_ADD_PAD_EN_FOR_TX_POS)

#define XMAC_MAC_LINK_FAULT_EN_FOR_POS       (11) 
#define XMAC_MAC_LINK_FAULT_EN_FOR_MASK      (BW1 << XMAC_MAC_LINK_FAULT_EN_FOR_POS)

#define XMAC_MAC_FAR_LOOPBACK_EN_POS         (12)  /*3.0变为远端环回*/
#define XMAC_MAC_FAR_LOOPBACK_EN_MASK        (BW1 << XMAC_MAC_FAR_LOOPBACK_EN_POS)

#define XMAC_MAC_MRU_CFG_POS                 (16)
#define XMAC_MAC_MRU_CFG_MASK                (0x3fff << XMAC_MAC_MRU_CFG_POS)

#define XMAC_MAC_SPEED_CFG_POS               (0)
#define XMAC_MAC_SPEED_CFG_LEN                3


#define L2SS_CPU_AGENT_LITTLE_ENDIAN              1
#define L2SS_CPU_AGENT_BIG_ENDIAN                 0

#define L2SS_VALID_PORT_MAP     0x000000000FC0730F

#define NTL_PATH_DELAY_10GE_TX_NO_FEC     72
#define NTL_PATH_DELAY_10GE_RX_NO_FEC     59
#define NTL_PATH_DELAY_10GE_TX_FEC        72
#define NTL_PATH_DELAY_10GE_RX_FEC        272
#define NTL_PATH_DELAY_1000M_TX           266
#define NTL_PATH_DELAY_1000M_RX           199
#define NTL_PATH_DELAY_2_5G_TX            106
#define NTL_PATH_DELAY_2_5G_RX            79
#define NTL_PATH_DELAY_100M_TX            2304
#define NTL_PATH_DELAY_100M_RX            1848
#define NTL_PATH_DELAY_10M_TX             22680
#define NTL_PATH_DELAY_10M_RX             18336

/* The forced speed, 10Mb, 100Mb, gigabit, 2.5Gb, 10GbE. */
#define SPEED_10		10
#define SPEED_100		100
#define SPEED_1000		1000
#define SPEED_2500		2500
#define SPEED_10000		10000

#define MAX_RXBUF_LEN 1536




typedef enum
{
    e_XMAC_SPEED_10M= 0, /* xmac 端口速率10M */
    e_XMAC_SPEED_100M,   /* xmac 端口速率100M */
    e_XMAC_SPEED_1G,     /* xmac 端口速率1G */
    e_XMAC_SPEED_2_5G,   /* xmac 端口速率2.5G */
    
    e_XMAC_SPEED_10G,    /* xmac 端口速率10G */   /*todo ,phy层对于10g的判断很特殊*/
    e_XMAC_SPEED_25G,     /* xmac 端口速率25G */
    e_XMAC_SPEED_50G,     /* xmac 端口速率50G */
    e_XMAC_SPEED_5G,     /* xmac 端口速率5G */
    e_XMAC_SPEED_NUM,    /* XMAC 最大值 8 */

    e_CMAC_SPEED_INDEX=0x10,
    e_CMAC_SPEED_40G= 0x10,   /* cmac 端口速率40G */
    e_CMAC_SPEED_100G,        /* cmac 端口速率100G */
    e_CMAC_SPEED_200G,        /* cmac 端口速率200G */
    e_CMAC_SPEED_NUM,         /* cmac最大值 */
    
}E_XMAC_SPEED_TYPE;


#define L2SS_OUT_PORT_MIN       L2SS_TRXP0
#define L2SS_OUT_PORT_MAX       (L2SS_MAX_EPORT_ID - 1)

#define L2SS_INNER_PORT_MIN     L2SS_TRXP32
#define L2SS_INNER_PORT_MAX     L2SS_TRXP46
#define L2SS_PORT_MAX           4


/*hash*/
typedef enum
{
    e_L2ssHashFmType = 0,  /*0*/
    e_L2ssHashMacType,     /*1*/
    e_L2ssHashVlanType,    /*2*/
    e_L2ssHashTsnType,     /*3*/
    e_L2ssHashTypeNum,
}E_L2ssHashKeyType;
	


/*table*/

/* LK_VLAN_ID_PREP +LK_VLAN_ING_PREP表  */
typedef struct
{
       
    UINT32 ulLagKeyType1:3;     /*4bit链路汇聚做Hash运算的键值类型*/
    UINT32 ulLagMaskType:1;    /*1bit链路汇聚做Hash运算的掩码类型*/
	UINT32 ulRsv0:28;           /*3bit保留位*/
	      
	UINT32 ulFidId1:10;         /*用于查LKFD_L2FM表。以支持SVL*/
	UINT32 ulBcIdx:7;          /*广播报文的泛洪索引。查LKMC_L2MC表*/
    UINT32 ulUucIdx:7;         /*未知单播包的泛洪索引。查LKMC_L2MC表*/
    UINT32 ulUmcIdx:7;         /*未知组播包的泛洪索引。查LKMC_L2MC表*/ 
    UINT32 ulLagKeyType0:1;     /*4bit链路汇聚做Hash运算的键值类型*/
        
    UINT32 ulStgId1:4;          /*生成树组ID*/
    UINT32 ulStaticMoveTocpu:1; /*静态MAC_SA移动了，是否送CPU判断。*/
    UINT32 ulStaticMoveDrop:1; /*静态MAC_SA移动了，是否丢弃判*/
    UINT32 ulCmlFlagsNew:4;    /*"新站点的学习控制。bit3：是否丢包bit2：是否送CPUbit1：HW设挂起bit0：HW学习。如果BIT0和BIT1同时有效，bit0有效"*/
	UINT32 ulCmlFlagsMove:4;   /*"站点搬移的学习控制bit3：是否丢包，bit2：是否送CPU，bit1：HW设挂起，bit0：HW搬移。如果BIT0和BIT1同时有效，bit0有效。"*/
    UINT32 ulCmlFlagsValid:1;  /*表示CMLFLAG是否有效。如果无效，则使用L2FM的逻辑端口表的CML特性。*/
    UINT32 ulLearnDisable:1;   /*不使能学习*/
    UINT32 ulLearnDrop:1;      /*完成学习后进行丢包*/
    UINT32 ulL2ucMissTocpu:1;  /*拷贝LKFD_L2FM查找失败的单播报文到CPU*/
    UINT32 ulL2ucMissDrop:1;   /*丢弃LKFD_L2FM查找失败的单播报文*/
    UINT32 ulL2mcMissTocpu:1;  /*拷贝LKFD_L2FM查找失败的组播报文到CPU*/
    UINT32 ulL2mcMissDrop:1;   /*丢弃LKFD_L2FM查找失败的组播报文*/
    UINT32 ulVlanClassId:9;    /*VLAN索引，即本VLAN在L2SS内的索引。传送给PKTM，使PKTM不用再查Hash表*/
    UINT32 ulFidId0:2;         /*用于查LKFD_L2FM表。以支持SVL*/
    
    UINT32 ulPortBitmap2:31;     /*"端口BitmapBitmap[63:39]，依次对应端口63…39"*/
    UINT32 ulStgId0:1;          /*生成树组ID*/

    UINT32 ulPortBitmap1:32;     /*"端口BitmapBitmap[38:7]，依次对应端口38…7"*/

    UINT32 ulValnIdx1:16;        /*{ VID[3]_IDX[7:0], VID[2]_IDX[7:0] , VID[1]_IDX[7:0] , VID[0]_IDX[7:0]  }*/  /* hyt:Vlan索引 */                              
    UINT32 ulRsv1:11;             /*保留位*/
    UINT32 ulValid:1;         /*表项LK_VLAN_ID_PREP的有效字段   */
    UINT32 ulVlanIdL:2;         /*VLAN_ID[1:0]   键值的bit[55:54]为VLAN_ID[1:0]，用于选择直接表VLAN特性表索引*/
    UINT32 ulMirrorEn:1;       /*镜像使能,键值的bit[56]开始为 hashb的直接表内容*/
    UINT32 ulPortBitmap0:1;     /*"端口BitmapBitmap[6:0]，依次对应端口6…0"*/
  
    UINT32 ulKeyType:2;        /*"hash表的类型澹00: 为转发表，FID+MAC_ADDR查找01: 为MAC VLAN映射，MAC查找10: 为VLAN索引表11: 为TSN_QID表"*/
    UINT32 ulKey:10;           /*Vlan ID[[11:2]*/
    UINT32 ulValnIdx0:20;        /*{ VID[3]_IDX[7:0], VID[2]_IDX[7:0] , VID[1]_IDX[7:0] , VID[0]_IDX[7:0]  }*/  
                               
}T_L2ssLvlip;



/* LK_VLAN_EGR_PKTM表 VLAN的输出特性表*/
typedef struct
{
    UINT64 udPortBitmap;   /*"输出端口的BITMAP，如果不匹配，则丢包
                                Bitmap[6:0]，依次对应端口6…0"*/
    UINT64 udStPortBitmap; /*"剥除一层标签的端口bitmap。
                                如果不匹配，按照内部的修改结果发送
                                如果匹配，将剥离一层标签。如果是有双层的话，会保留内层。"*/
                                
    UINT32 udStgId:5;        /*生成树组ID*/
    UINT32 udReserv:27;     
    /*UINT32 udStgLkEn:7;*/      /* 3.0已经废除 ---- "生成树查表使能。
                                    1，需要根据STG_ID查生成树，并根据生成树状态过滤报文。
                                    0，不需要查生成树，所有报文均可通过。"*/
}T_L2ssLvlem;


typedef struct
{
    UINT32 udPortBitmap1:5;
    UINT32 udReserv:27;
    
    UINT32 udPortBitmap2:32;
    
    UINT32 udStPortBitmap1:5; 
    UINT32 udPortBitmap3:27;
    
    UINT32 udStPortBitmap2:32;
    
    UINT32 udStgId:5;      
    UINT32 udStPortBitmap3:27;
}T_L2ssLvlem_hw;


/* LK_VLAN_ING_PREP 特性表  */
typedef struct
{      
    UINT32 ulUmcIdx1:1;         /*未知组播包的泛洪索引。查LKMC_L2MC表*/
    UINT32 ulLagKeyType:4;     /*4bit链路汇聚做Hash运算的键值类型*/
    UINT32 ulLagMaskType:1;    /*1bit链路汇聚做Hash运算的掩码类型*/
    UINT32 ulRsv0:26;           /*3bit保留位*/
    
    UINT32 ulFidId:12;         /*用于查LKFD_L2FM表。以支持SVL*/
    UINT32 ulBcIdx:7;          /*广播报文的泛洪索引。查LKMC_L2MC表*/
    UINT32 ulUucIdx:7;         /*未知单播包的泛洪索引。查LKMC_L2MC表*/
    UINT32 ulUmcIdx0:6;         /*未知组播包的泛洪索引。查LKMC_L2MC表*/

    UINT32 ulPortBitmap2:1;     /*"端口BitmapBitmap[63:0]，依次对应端口63…0"*/ 
    UINT32 ulStgId:5;          /*生成树组ID*/
    UINT32 ulStaticMoveTocpu:1;/*静态MAC_SA移动了，是否送CPU判断。*/
    UINT32 ulStaticMoveDrop:1; /*静态MAC_SA移动了，是否丢弃判断。*/
    UINT32 ulCmlFlagsNew:4;    /*"新站点的学习控制bit3：是否丢包，bit2：是否送CPU，bit1：HW设挂起，bit0：HW学习。*/
    UINT32 ulCmlFlagsMove:4;   /*"站点搬移的学习控制。bit3：是否丢包，bit2：是否送CPU，bit1：HW设挂起，bit0：HW搬移。*/
    UINT32 ulCmlFlagsValid:1;  /*表示CMLFLAG是否有效。如果无效，则使用L2FM的逻辑端口表的CML特性。*/
    UINT32 ulLearnDisable:1;   /*不使能学习*/
    UINT32 ulLearnDrop:1;      /*完成学习后进行丢包*/
    UINT32 ulL2ucMissTocpu:1;  /*拷贝LKFD_L2FM查找失败的单播报文到CPU*/ 
    UINT32 ulL2ucMissDrop:1;   /*丢弃LKFD_L2FM查找失败的单播报文*/
    UINT32 ulL2mcMissTocpu:1;  /*拷贝LKFD_L2FM查找失败的组播报文到CPU*/
    UINT32 ulL2mcMissDrop:1;   /*丢弃LKFD_L2FM查找失败的组播报文*/
    UINT32 ulVlanClassId:9;    /*VLAN索引，即本VLAN在L2SS内的索引。传送给PKTM，使PKTM不用再查Hash表*/

    UINT32 ulPortBitmap1:32;     /*"端口BitmapBitmap[63:0]，依次对应端口63…0"*/                             
                            
    UINT32 ulMirrorEn:1;       /*镜像使能,键值的bit[56]开始为 hashb的直接表内容*/ 
    UINT32 ulPortBitmap0:31;     /*"端口BitmapBitmap[63:0]，依次对应端口63…0"*/
   
}T_L2ssLvIngPrep;


/* LK_VLAN_ID_PREP 索引表  */
typedef struct
{
    UINT32 ulValnIdx1:16;        /*{ VID[3]_IDX[7:0], VID[2]_IDX[7:0] , VID[1]_IDX[7:0] , VID[0]_IDX[7:0]  }*/    
    UINT32 ulRsv1:11;             /*保留位*/
    UINT32 ulValid:1;         /*表项LK_VLAN_ID_PREP的有效字段   */
    UINT32 ulVlanIdL:2;         /*VLAN_ID[1:0]   键值的bit[55:54]为VLAN_ID[1:0]，用于选择直接表VLAN特性表索引*/
    UINT32 ulRsv0:2;         /*保留字段*/
                                
    UINT32 ulKeyType:2;        /*"hash表的类型澹00: 为转发表，FID+MAC_ADDR查找01: 为MAC VLAN映射，MAC查找10: 为VLAN索引表11: 为TSN_QID表"*/   
    UINT32 ulKey:10;           /*Vlan ID[[11:2]*/                                
    UINT32 ulValnIdx0:20;        /*{ VID[3]_IDX[7:0], VID[2]_IDX[7:0] , VID[1]_IDX[7:0] , VID[0]_IDX[7:0]  }*/   
    
}T_L2ssLvIdPrep; 


/* LK_SRC_LPORT_PREP表 逻辑端口表 */
typedef struct
{
    UINT32 ulTagActProf1:2;           /*"对输入的VLAN标签采取的行为指针。指针指向：LK_VLAN_TAG_ACT_PREP"*/
    UINT32 ulOvid:12;                /*默认基于端口的VID*/
    UINT32 ulOdei:1;                 /*默认基于端口的DEI*/
    UINT32 ulOpri:3;                 /*默认基于端口的PRI值*/
    UINT32 ulVlanMisToCpu:1;         /*"输入VLAN不匹配的报文送CPU。"*/
    UINT32 ulVlanFailToCpu:1;        /*"LK_VLAN_ING_PREP查表失败是否送CPU。*/
    UINT32 ulTpidUnmDis:1;           /*如果OTPID不匹配，则丢弃。如果不丢弃的话，则作为UNTAG报文处理。*/
    UINT32 ulTpidUnmToCpu:1;         /*"如果OTPID不匹配，则作为UNTAG报文处理，送CPU.*/
    UINT32 ulOuterTpidEn:4;          /*该端口所支持的外层TPID的值，4个中的哪几个，bitmap*/
    UINT32 ulVtagSlpMap:2;           /*"表示如何基于源逻辑端口的VID映射
                                     bi1:表示输入报文为UT/PT的映射方法，bit0:表示输入报文为PVT的映射方法
                                                           对应bit的值为0时表示使用本表中的OVID字段作为映射结果
                                                           对应bit的值为1时表示使用原报文的VID作为映射结果              */
    UINT32 uExtB_KT:3;               /*确定ExtB键值中的Ext_Key的选择。*/
    UINT32 ulRsv:1;



    UINT32 ulPktExtKey:1;             /*"表示使用EXTx做VLAN映射时，L4的端口号，选的是源端口还是目的端口*/
    UINT32 ulV6Key:12;                /*"IPV6不使用128BIT查表时，查表键值选择。*/
    UINT32 ulV6Len:2;                 /*"IPV6的查表长度00，16bit；01，32bit；10，64bit；11，128bit；"*/
    UINT32 ulV4Key:1;                 /*IPV4使用16bit查表时，查表键值选择，1，表示高16bit，0，表示低16bit*/
    UINT32 ulV4Len:1;                 /*IPV4的查表长度，1，表示32bit；0，表示16bit*/
    UINT32 ulVlanPrecedence:3;        /*"确定VLAN映射的优先级*/ 
    UINT32 ulVlanDipPrecedence:1;     /*IP到VLAN的映射，是DIP优先还是SIP优先。1，DIP*/
    UINT32 ulVlanDmacPrecedence:1;    /*MAC到VLAN的映射，是DMAC优先还是SMAC优先。1，DMAC*/
    UINT32 ulPktExtbBasedVidEnable:1; /*"使能基于报文扩展字段B（EXTB）的的VLAN映射，使用LPM表。"*/
    UINT32 ulPktExtaBasedVidEnable:1; /*"使能基于报文扩展字段A（EXTA）的的VLAN映射，使用LPM表"*/
    UINT32 ulSipBasedVidEnable:1;    /*使能基于源IP子网的VLAN映射*/
    UINT32 ulDipBasedVidEnable:1;    /*使能基于目的IP子网的VLAN映射*/
    UINT32 ulSmacBasedVidEnable:1;   /*使能基于源MAC的VLAN映射*/
    UINT32 ulDmacBasedVidEnable:1;   /*使能基于目的MAC的VLAN映射*/
    UINT32 ulTagActProf0:4;           /*"对输入的VLAN标签采取的行为指针。指针指向：LK_VLAN_TAG_ACT_PREP"*/

}T_L2ssLslpp;


/* LK_VLAN_TAG_ACT_PREP表 VLAN标签行为表 */
typedef struct
{
    UINT16 usUtOtagAct:2;   /*"无的外层VLAN标签。
                                2`b00：不修改；2`b01：不修改；2`b10：在原标签前插入；2`b11：不修改"*/
    UINT16 usUtOpriAct:2;   /*"无标签的外层PRI的操作。
                                2`b00：不修改；2`b01：不修改；2`b10：在原标签前插入；2`b11：不修改"*/
    UINT16 usUtOdeiAct:2;   /*"无标签的外层DEI的操作：
                                2`b00：不修改；2`b01：不修改；2`b10：在原标签前插入；2`b11：不修改；"*/
    UINT16 usSotPotagAct:2; /*"单外层的外层VLAN标签。VID=12'B0时，即只有优先级标签，对VID的修改。
                                2`b00：不修改；2`b01：填映射值；2`b10：在原标签前插入；2`b11：删除；"*/                            

    UINT16 usSotOtagAct:2;  /*"单外层的外层VLAN标签。VID!=12'B0。
                                2`b00：不修改；2`b01：填映射值；2`b10：在原标签前插入；2`b11：删除；"*/
    UINT16 usSotOpriAct:2;  /*"单外层标签的外层PRI的操作。包括VID=12'B0时，
                                2`b00：不修改；2`b01：填映射值；2`b10：在原标签前插入；2`b11：删除；"*/
    UINT16 usSotOdeiAct:2;  /*"单外层标签的外层DEI的操作。包括VID=12'B0时，
                                2`b00：不修改；2`b01：填映射值；2`b10：在原标签前插入；2`b11：删除；"*/                        
    UINT16 usRsv1:2;
    
  
}T_L2ssLvtap;

/* LK_IP_ADDR_PREP表 IP表 */
typedef struct
{
    UINT32 LAG_HASH_IDX:4;    /*表示链路汇聚的目的虚物理端口ID*/
    UINT32 LAG_HASH_VALID:1;  /*表示链路汇聚指定端口使能*/
    UINT32 ADDR_CLASS_ID:12;  /*1. 使用IP查表时，得到IP地址的ClassID。            2. ExtA/B查表时，得到是SEG_ID。*/
    UINT32 SEG_ID_VLD:1;      /*ExtA/B才使用（EXTB优先级高于ExtA）。PKT_SEGI_VID字段为0时才判断SEG_ID_VID是否有效，为1表示SEG_ID字段有效，为0表示SEG_ID字段无效*/
    UINT32 PKT_SEG_ID_VLD:1;   /*ExtA/B才使用(eXTa/B任何一个PKT_SEGI_VID有效，结构就有效)。为1表示报文的FLOWID[15:0]为SEG_OD字段，为0表示根据SEG_ID_VID字段获取SEG_ID*/
    UINT32 Reserved:13;       /*保留字段*/ 

    UINT32 udSipMirrorAndEn:1;/*源IP地址镜像使能，需要DIP_MIRROR_AND_EN也为1，才捕获报文。*/
    UINT32 udDipMirrorAndEn:1;/*目的IP地址镜像使能，需要SIP_MIRROR_AND_EN也为1，才捕获报文。*/
    UINT32 udSipMirrorOrEn:1; /*源IP地址镜像使能*/
    UINT32 udDipMirrorOrEn:1; /*"目的IP地址镜像使能如果是基于EXTx的查表，表示镜像使能是否有效。"*/
    UINT32 udTagActProf:6;    /*"对输入的VLAN标签采取的行为指针。指针指向：LK_VLAN_TAG_ACT_PREP"*/
    UINT32 udOvid:12;         /*默认基于端口的VID*/
    UINT32 udOdei:1;          /*外层VLAN标签默认PRI值*/ 
    UINT32 udOpri:3;          /*外层VLAN标签默认PRI值*/ 
    UINT32 udDipVlanValid:1;  /*"表示基于DIP的VLAN映射值是否有效。如果是基于EXTx的查表，表示映射值是否有效。"*/
    UINT32 udSipVlanValid:1;  /*表示基于SIP的VLAN映射是否有效。*/
    UINT32 udSipTocpuEn:1;    /*源IP地址送CPU使能。*/
    UINT32 udDipTocpuEn:1;    /*"目的IP地址送CPU使能。如果是基于EXTx的查表，表示从CPU使能是否有效。"*/
    UINT32 udSipDropEn:1;     /*源IP地址命中丢弃使能*/
    UINT32 udDipDropEn:1;     /*"目的IP地址命中丢弃使能 如果是基于EXTx的查表，表示丢弃使能是否有效。"*/
   
}T_L2ssLipap;

typedef struct
{
    UINT32 udKeyType;/* 键值类型 */
    UINT32 audKey[4];/* 键值组，用于支持128bit的表项 */
    UINT32 audMask[4];
    T_L2ssLipap tLipapValue;
    
}T_L2ssLpmIpAddr;

typedef struct
{
    UINT32 udKeyType;
    UINT32 audKey[4];
    UINT32 audMask[4];
}T_L2ssLpmStruct;

/*模块调试ID*/
typedef enum
{
    e_PARS_ID = 0, 
    e_PARS_ID1,
    e_PARS_ID2,
    e_PARS_ID3,
    e_BMAN_ID,
    e_PKTM_ID,
    e_PKTM_ID2,
    e_PKTM_ID3,
    e_PKTM_ID4,
    e_PREP_ID,    /* 9 */
    e_PREP_ID2,
    e_PREP_ID3,
    e_PREP_ID4, 
    e_L2FM_ID,
    e_L2FM_ID2,
    e_L2FM_ID3,
    e_L2FM_ID4,
    e_L2MC_ID,    /* 17 */
    e_L2MC2_ID,
    e_L2MC3_ID,
    e_L2MC4_ID,
    e_LKUP_HASHA_ID,
    e_LKUP_HASHB_ID,
    e_LKUP_LPM_ID,
    e_LKUP_DTBL_ID,
    e_QMAN_ID,      /* 25 */
    e_QMAN1_ID,
    e_QMAN2_ID,
    e_QMAN3_ID,
    e_QMAN_TSN0_ID,
    e_QMAN_TSN1_ID,   /* 30 */
    e_MODU_ID,        /* 31 */
}e_L2ssModu;

/*PKT_TYPE编码  报文类型编码，5bit*/
typedef enum
{
    e_IPV4 = 0,         /*0 PARS识别*/                                                            
    e_IPV6,         /*1 PARS识别*/                                                            
    e_NOT_IP,       /*2 其他非IP封装的以太网报文，PARS识别*/                                  
    e_MARK_RESP,    /*3 PKTM送给TRXP的报文。MARK resp帧*/                                     
    e_IPV4_UDP1588, /*4 ipv4 UDP封装的1588报文，PARS识别*/                                    
    e_IPV6_UDP1588, /*5 ipv6 UDP封装的1588报文，PARS识别*/                                    
    e_ETH_1588,     /*6 Ethernet封装的1588报文，PARS识别*/                                    
    e_SEC_1588,     /*7 CPU下发的IP SEC的1588报文。TRXP从SRC_BTTL识别，或L2FM从SRC_CPU识别。*/
    e_AH_OAM,       /*8 IEEE802.3ah OAM报文，需要在PREP识别，或L2FM识别*/                     
    e_BPDU,         /*9 BPDU报文，需要在PREP识别，或L2FM识别*/                                
    e_PRTC_PKT,     /*10 L2协议报文，需要在PREP识别，或L2FM识别*/                              
    e_SCTP,         /*11 SCTP报文，PREP识别*/                                                  
    e_LAG_MARK,     /*12 由QMAN生成该类型，PKTM生成报文。Mark Request帧*/                      
    e_AG_OAM,       /*13 CPU下发的IEEE802.1ag OAM 延迟测量报文。由CPU填写类型。CPU同时填写需要*/
    e_UDP,          /*14 UDP报文，PREP识别*/                                                   
    e_TCP,          /*15 TCP报文，PREP识别*/                                                   
    e_IPV4_FRAG,    /*16 IPV4分片报文，由PARS识别*/                                            
    e_IPV6_FRAG,    /*17 IPV6分片报文，由PARS识别*/ 
    e_ROE_IQ_PKT,   /*18 NTL3.0 ADD*/
    e_BB_NULL_PKT,  /*19 NTL3.0 ADD,不占BB资源的报文,通知trxp不需要释放BB资源*/
    //e_保留1,        /*其他未分配的编码*/                                                    
    //e_保留2,        /*在L2_ENTRY查表结果可以得到报文类型。以及其他在PARS微码预留的报文类型*/
    e_PKT_TYPE_NUM,
}e_PktType;

typedef enum
{
    e_L2SS_ENG0 = 0, 
    e_L2SS_ENG1,  
    e_L2SS_ENG2,     
    e_L2SS_ENG3,        
    e_L2SS_ENG_NUM,      
}e_L2SS_ENG;

/* Lpm Key Type */
typedef enum
{
    e_LpmKeyIpv4L16 = 0,    //000，IPV4 16BIT；
    e_LpmKeyIpv4L32,    //001，IPV4 32BIT
    e_LpmKeyExta,       //010，EXT_A 32BIT 3'b0+PKT_TYPE[4:0]+Protocol[7:0]+L4_PORT[15:0]
    e_LpmKeyExtb64,       //011，EXT_B 64BIT 3'b0+PKT_TYPE[4:0]+Protocol[7:0]+L4_PORT[15:0]+Ext_key[31:0]
    e_LpmKeyIpv6L16,    //100，IPV6 16BIT；
    e_LpmKeyIpv6L32,    //101，IPV6 32BIT
    e_LpmKeyIpv6L64,    //110，IPV6 64BIT；
    e_LpmKeyIpv6L128,   //111，IPV6 128BIT
    
    e_LpmKeyExtbL64E,    //1000  000+PKT_TYPE[4:0]+flow_id[7:0]+ Ext_48key [47:0]
    e_LpmKeyExtbL128,    //1001  Ext_Kt [2:0] + PKT_TYPE[4:0] + Protocol[7:0] + L4Port[15:0] + Ext_key[31:0] + Ext_64Key[63::0]
	e_LpmKeyExtbL128E,   //1010  SLP_Type[2:0] + PKT_TYPE[4:0] + Protocol[7:0]+ 16'b0 + L5_4B[31:0] + PARS_Rsv[63:0]
    e_LpmKeyTypeNum,
    
}E_LpmKeyType;

UINT32 L2ssXmacDisable(UINT32 port);
UINT32 L2ssXmacEnable(UINT32 port);
UINT32 L2ssXmacSetSpeed(UINT32 port,UINT32 speed);
UINT32 L2ssCpuAgentRlsPort(UINT32 port);
UINT32 L2ssCpuAgentRstPort(UINT32 port);
UINT32 L2ssCpuAgentByteOrder(UINT32 port,UINT32 byte_order);
UINT32 L2ssProcInit(VOID);
UINT32 L2ssLkupInit(VOID);
UINT32 L2ssCreatVlan(UINT32 udVlanId, UINT32 udFid, UINT64 uddPortMap, UINT64 uddStPortMap);
UINT32 L2ssVlanMapModeSet(E_TrxpId ePortNum, UINT32 udMapMode, UINT32 udMapPri);
UINT32 L2ssParsCfglpSelParseNUm(UINT32 udLPNum, UINT32 udParseNum);
UINT32 L2ssParsCfgPktAnalyLevel(E_TrxpId ePortNum, UINT32 udLevel);
UINT32 L2ssPortVlanGet(E_TrxpId ePortNum);
UINT32 L2ssPortVlanSet(E_TrxpId ePortNum, UINT32 udVlanId, UINT32 udVtagSlpMap);
UINT32 L2ssLvTapTblSet(UINT32 *pTblIdx);
void L2ssPortEnable(UINT32 port);
void L2ssPortDisable(UINT32 port);
UINT32 L2ssLkupApplyLvtapTableId(void);
UINT32 L2ssLkupApplyLpmTableId(E_LpmKeyType eKeyType);
UINT32 L2ssLkupApplyLmcmcTableId(void);
UINT32 L2ssLkupApplyLvlemTableId(void);
UINT32 L2ssLkupReleaseLvtapTableId(UINT32 udTableId);
UINT32 L2ssLkupReleaseLmcmcTableId(UINT32 udTableId);
UINT32 L2ssLkupApplyLvIpTableId(void);
UINT32 BootCfgL2ssBaseAddr(UINT32 vir_addr);
/* Started by AICoder, pid:a60a4acdfdb2f4f141030bdc8017541eb9305159 */
UINT32 L2ssLpmVlanSet(T_L2ssLpmStruct *pLpmInfo, UINT32 udVlanId, UINT32 udTagActIdx, UINT32 udMapMode);
UINT32 L2ssPrepCfgPktErrCtrl(UINT32 udErrDropEn);
VOID l2ss_hw_cntp_en();
UINT32 L2ssSetQmanCfgiInnerPortGroup(UINT32 value);
UINT32 L2ssSetEngMode(UINT32 ctrl);
UINT32 L2ssCheckQmanNorSelfInitDone(UINT32 engId);
UINT32 L2ssmacCfgTxIpg(UINT32 port,UINT32 udCfgVal);
UINT32 L2sssMacSetInterfaceMode(UINT32 eport, UINT32 speed);
UINT32 L2ssMacInit(UINT32 eport);
extern VOID BspSysMsDelay_Sys(UINT32 ulDelay);
/* Ended by AICoder, pid:a60a4acdfdb2f4f141030bdc8017541eb9305159 */
#endif /* __L2SS_H__ */

/*---------------------------------------------------------------------------------------------------------------------
 * 版权所有(C)2000-2011, 中兴通讯股份有限公司 
 * 
 * 文 件 名: uart.h  
 * 
 * 作    者: 10010370
 * 
 * 接口描述:
 *     Bootrom软件uart接口处理
 * 
 * 版    本: v1.0
 * 
 * ------------------------------------------------------------------------------------------------------------------ 
 * 
 *     修改日期         修改人            修改内容
 *     20111103         10010370          创建
 *     
 *-------------------------------------------------------------------------------------------------------------------*/

#ifndef _MII_H_
#define _MII_H_

#define IC_MDIO_VER_REG      (0x0)
#define IC_MDIO_DATA_W_REG   (0x4)
#define IC_MDIO_DATA_R_REG   (0x8)
#define IC_MDIO_EXT_ADDR_REG (0xC)
#define IC_MDIO_INT_REG      (0x10)
#define IC_MDIO_CTRL_REG     (0x14)

#define OP_WRITE   			 (1)
#define OP_READ   			 (2)


#define MDIO_CTL_WRITE		(OP_WRITE << 10)
#define MDIO_CTL_READ		(OP_READ << 10)

 
#define MDIO_CTL_INFO		((0<<16) | (0<<15))


UINT32 BootRdIcMiiReg(UINT32 ulAddr);
UINT32 BootWrIcMiiReg(UINT32 ulAddr, UINT32 ulData);
UINT32 BootCfgMiiBaseAddr(UINT32 vir_addr);

/* Started by AICoder, pid:o9b4cpe00f49484146450b19a012560b8912c34c */
UINT32 BootSetMiiWrReg(UINT32 phyAddr,UINT32 regAddr,UINT32 val);
UINT32 BootGetMiiWrReg(UINT32 phyAddr,UINT32 regAddr,UINT32 *pVal);
/* Ended by AICoder, pid:o9b4cpe00f49484146450b19a012560b8912c34c */
#endif  /* _UART_H_ */

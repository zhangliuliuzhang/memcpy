/**************************************************************************
* 版权所有 (C)2001, 深圳市中兴通讯股份有限公司
*
* 文件名称: M88E1322Api.c
* 文件标识:
* 内容摘要:
* 其它说明:
* 当前版本: V1.0
* 作    者: 罗乔发
* 完成日期:
*
* 修改记录1:
*    修改日期: 2010年04月09日
*    版 本 号: V1.0
*    修 改 人: 罗乔发
*    修改内容: 创建
* 修改记录2:
**************************************************************************/
//#include "hal.h"
#include "bsppub.h"
#include "mii.h"



static UINT32 g_miiVirAddr = 0 ;


UINT32 BootCfgMiiBaseAddr(UINT32 vir_addr)
{
    g_miiVirAddr = vir_addr;
    return 0;
}

/*读IC寄存器*/
UINT32 BootRdIcMiiReg(UINT32 ulAddr)
{
    UINT32 ulRegAddr = 0;

    ulRegAddr = ulAddr + g_miiVirAddr;

    return *((volatile UINT32 *)ulRegAddr);
}

/*写IC寄存器*/
UINT32 BootWrIcMiiReg(UINT32 ulAddr, UINT32 ulData)
{
    UINT32 ulRegAddr = 0;

    ulRegAddr = ulAddr + g_miiVirAddr;

    *((volatile UINT32 *)ulRegAddr) = ulData;

    return BSP_OK;
}



UINT32 BootGetMiiIntr()
{
    UINT32 val = 0;
    val = BootRdIcMiiReg(IC_MDIO_INT_REG);
    return val;
}

UINT32 BootClrMiiIntr()
{
    return BootWrIcMiiReg(IC_MDIO_INT_REG,0);
}


UINT32 BootGetMiiCtrlReg()
{
    UINT32 val = 0;
    val = BootRdIcMiiReg(IC_MDIO_CTRL_REG);

    return val;
}

UINT32 BootSetMiiCtrlReg(UINT32 val)
{
    return BootWrIcMiiReg(IC_MDIO_CTRL_REG,val);
}


UINT32 BootGetMiiVal()
{
    UINT32 val = 0;
    val = BootRdIcMiiReg(IC_MDIO_DATA_R_REG);

    return (val & 0xffff);
}

UINT32 BootSetMiiVal(UINT32 val)
{
    return BootWrIcMiiReg(IC_MDIO_DATA_W_REG,val);
}


UINT32 BootWaitMiiFinish()
{
    UINT32 flag = 0;
    UINT32 dlyCnt = 0;

    flag =  (BootGetMiiIntr() & 0x1);
    //zte_printf_s("flag1 = %d\n",flag);
    while(0 == flag)
    {
        dlyCnt++;
        if (dlyCnt >= 10000)
        {
            break;
        }
        flag =  (BootGetMiiIntr() & 0x1);
        //zte_printf_s("flag2 = %d\n",flag);

    }

    flag =  (BootGetMiiIntr() & 0x1);
    //zte_printf_s("flag3 = %d\n",flag);
    if (1 == flag)
    {
        return BSP_OK;
    }
    return BSP_ERROR;
}



UINT32 BootSetMiiWrReg(UINT32 phyAddr,UINT32 regAddr,UINT32 val)
{
    UINT32 reg = 0;

    //zte_printf_s("BootSetMiiWrReg phyAddr=%d regAddr=%d\n",phyAddr,regAddr);

    /*clr intr*/
    BootClrMiiIntr();

    /*wr val*/
    BootSetMiiVal(val & 0xffff);

    phyAddr = ((phyAddr & 0x1f) << 5);
    regAddr = (regAddr & 0x1f);
    //zte_printf_s("wr reg addr = %d\n",regAddr);

    reg = (MDIO_CTL_INFO | MDIO_CTL_WRITE | (1<<12) | phyAddr | regAddr);

    //zte_printf_s("BspSetMiiCtrlReg reg val = 0x%08x\n",reg);

    BootSetMiiCtrlReg(reg);

    /*start*/
    reg = BootGetMiiCtrlReg();
    reg |= (1 << 14);
    BootSetMiiCtrlReg(reg);

    //zte_printf_s("wr reg = 0x%08x\n",reg);
    if (BSP_OK == BootWaitMiiFinish())
    {
        return BSP_OK;
    }

    return BSP_ERROR;
}

UINT32 BootGetMiiWrReg(UINT32 phyAddr,UINT32 regAddr,UINT32 *pVal)
{
    UINT32 reg = 0;

    //zte_printf_s("BootGetMiiWrReg phyAddr=%d regAddr=%d\n",phyAddr,regAddr);

    /*clr intr*/
    BootClrMiiIntr();

    phyAddr = (phyAddr << 5);
    regAddr = (regAddr & 0x1f);

    reg = (MDIO_CTL_INFO | MDIO_CTL_READ | (1<<12) | phyAddr | regAddr);
    BootSetMiiCtrlReg(reg);

    /*start*/
    reg = BootGetMiiCtrlReg();
    reg |= (1 << 14);
    BootSetMiiCtrlReg(reg);

    if (BSP_OK == BootWaitMiiFinish())
    {
        /*rd val*/
        *pVal = BootGetMiiVal();
        return BSP_OK;
    }

    zte_printf_s("BootGetMiiWrReg failed\n");
    return BSP_ERROR;

}



UINT32 phyWr(UINT32 phyAddr,UINT32 addr, UINT32 reg)
{
    zte_printf_s("wr addr = %d\n",addr);
    BootSetMiiWrReg(phyAddr,addr,reg);
    return BSP_OK;
}

UINT32 phyRd(UINT32 phyAddr,UINT32 addr)
{
    UINT32 val = 0;
    BootGetMiiWrReg(phyAddr,addr,&val);
    zte_printf_s("val = 0x%08x\n",val);
    return BSP_OK;
}

#if 0
VOID phyClk()
{
    BootSetMiiClk();
}
#endif




/**
******************************************************************************
* Copyright (c) 2020 ZTE Corp. ZXSDR-RRU Platform BSP.
*
* @file        bspcommonstdlog.c
* @brief       实现串口日志保存接口
* @version     V1.0
* @author      施佳炜10262604
* @date        2022/08/01
******************************************************************************
*/
#include "secure_func.h"
#include "bspcommonstdlog.h"
#include "bootapp.h"
#include "bspcomm.h"
#include "vxadp.h"
#include "ubifs.h"
#if defined(CONFIG_ZXW11200)
#include "zxw11200boot.h"
#elif defined(CONFIG_ZX2112XX)
#include "zx211411a1boot.h"
#elif defined(CONFIG_ZX211410_EXT)
#include "zx211410boot.h"
#elif defined(CONFIG_ZX211412)
#include "zx211412boot.h"
#elif defined(CONFIG_ZX211413)
#include "zx211413boot.h"
#elif defined(CONFIG_LS10X3A)
#include "ls10x3aboot.h"
#endif

unsigned long s_AppLogPhysicAddr = 0;
static T_LOG_DESC* log_desc = NULL;

/**
************************************************************************
* @name      BspPhyAddrToKernel
* @brief     配置串口日志使用的物理地址给内核
* @param[in] unsigned long long logAddrBase 物理地址，单板层传入
*            UINT32 interruptNum 中断号，单板层传入
*            INT32 KdaDrvFd kda设备fd，单板层传入
* @warning
* @return    BSP_ERROR or BSP_OK
* @author      施佳炜10262604
* @date        2022/08/01
************************************************************************
*/
INT32 BootKdaInitComRecord(unsigned long long logAddrBase, UINT32 interruptNum, INT32 KdaDrvFd)
{
    kda_ioctl_t devIo = {0};

    devIo.d0 = (logAddrBase >> 32) & 0xffffffff;
    devIo.d1 = logAddrBase & 0xffffffff;
    devIo.d2 = interruptNum;
    devIo.d3 = 1;
    #if defined(CONFIG_ZX211410_EXT)
    /*传入串口log的单区大小 KB*/
    devIo.dx[0] = BUF_SIZE / 0x400;
    #endif

    if (ioctl(KdaDrvFd, KDA_SERIAL_RECORD_MEMORY, &devIo))
    {
        (VOID) zte_printf_s("ioctl KDA_SERIAL_RECORD_MEMORY failed\n");
        return ERROR;
    }

    return 0;
}

UINT32 BspPhyAddrToKernel(unsigned long long phyAddr, UINT32 interruptNum, INT32 KdaDrvFd)
{
    INT32 retVal;

    if (phyAddr == 0)
    {
        return BSP_ERROR;
    }

    retVal = BootKdaInitComRecord(phyAddr, interruptNum, KdaDrvFd);
    if (retVal != 0)
    {
        return BSP_ERROR;
    }
    s_AppLogPhysicAddr = phyAddr;

    return BSP_OK;
}

UINT32 GetFileHeadDesc(UINT64 buffLen, const CHAR *desc, CHAR *tmpBuf, UINT32 tmpBufLen)
{
    INT32 secRet;

    if (buffLen == 0)
    {
        secRet = zte_snprintf_s(tmpBuf, tmpBufLen - 1, "DESC:%s, tick=%lu, %s", desc, tickGet(),
                "ATTENTION !!!:No date Record\n");
        if (secRet <= 0)
        {
            dbgErr("%s, snprintf_s failed, buffer len:%d\n", __FUNCTION__, buffLen);
            return BSP_ERROR;
        }
    }
    else
    {
        secRet = zte_snprintf_s(tmpBuf, tmpBufLen - 1, "DESC:%s, tick=%lu, %s", desc, tickGet(),
                "The Com Print has been successfully recorded\n");
        if (secRet <= 0)
        {
            dbgErr("%s, snprintf_s failed, buffer len:%d\n", __FUNCTION__, buffLen);
            return BSP_ERROR;
        }
    }

    return BSP_OK;
}

/**
************************************************************************
* @name      AddRecordHead
* @brief     将头结构体写入日志文件
* @param[in] headBuf 头结构体
*            fp 文件指针
* @warning
* @return    VOID
* @author    施佳炜10262604
* @date      2022/08/01
************************************************************************
*/
VOID AddRecordHead(T_COM_RECORD_HEADER *headBuf, FILE *fp)
{
    CHAR headCharBuf[255] = {0};
    int len = 0;

    if (headBuf == NULL || fp == NULL)
    {
        return;
    }

    if (zte_snprintf_s(headCharBuf, sizeof(headCharBuf) - 1, "ullIndex=%lld, ullLenInByte=%lld, ullFlag=0x%llX, ullSlaveReadIndex=%lld\n",
        headBuf->ullIndex, headBuf->ullLenInByte, headBuf->ullFlag, headBuf->ullSlaveReadIndex) <= 0)
    {
        dbgErr("%s, snprintf_s failed\n", __FUNCTION__);
        return;
    }

    len = zte_strnlen_s(headCharBuf, sizeof(headCharBuf));
    if (len >= 0)
    {
        if (fwrite(headCharBuf, len, 1, fp) != 1)
        {
            dbgErr("%s, fwrite headBuf failed\n", __FUNCTION__);
        }
    }
    return;
}

/**
************************************************************************
* @name      Save2File
* @brief     配置串口日志使用的物理地址给内核
* @param[in] CHAR *buff写文件的内容。UINT64 buffLen写入长度。
*            const CHAR *fileName文件名。const CHAR *desc文件描述
* @warning
* @return    BSP_ERROR or BSP_OK
* @author    施佳炜10262604
* @date      2022/08/01
************************************************************************
*/
UINT32 Save2File(T_COM_RECORD *recordBuf, UINT64 buffLen, const CHAR *fileName, const CHAR *desc)
{
    FILE *fp = NULL;
    CHAR tmpBuf[128] = {0};
    INT32 secRet;
    UINT32 retVal = BSP_ERROR;
    size_t bufLen = buffLen & 0xffffffff;
    int len = 0;

    INPUT_POINTER_CHECK(recordBuf);
    INPUT_POINTER_CHECK(fileName);
    INPUT_POINTER_CHECK(desc);

    if (GetFileHeadDesc(buffLen, desc, tmpBuf, sizeof(tmpBuf)) != BSP_OK)
    {
        dbgErr("%s, GetFileHeadDesc failed, fileName: %s\n", __FUNCTION__, fileName);
        return BSP_ERROR;
    }

    fp = fopen(fileName, "a+");
    if (fp == NULL)
    {
        dbgErr("%s, open file failed, fileName: %s\n", __FUNCTION__, fileName);
        return BSP_ERROR;
    }

    len = zte_strnlen_s(tmpBuf, sizeof(tmpBuf));
    if (len >= 0)
    {
        if (fwrite(tmpBuf, len, 1, fp) != 1)
        {
            dbgErr("%s, fwrite head failed, fileName: %s\n", __FUNCTION__, fileName);
            secRet = zte_fclose_s(fp);
            CHECK_RET_WARNING(secRet != (INT32)0, "fclose ret'%d!", secRet);
            return retVal;
        }
    }

    // 如果写入长度为0,就不写buff内容
    if (buffLen == 0)
    {
        secRet = fsync(fileno(fp));
        CHECK_RET_WARNING(secRet != (INT32)0, "fsync failed");
        secRet = zte_fclose_s(fp);
        CHECK_RET_WARNING(secRet != (INT32)0, "fclose ret'%d!", secRet);
        return BSP_OK;
    }

    if (fwrite(recordBuf->acBuf, bufLen, 1, fp) != 1)
    {
        dbgErr("%s, fwrite buffer failed, fileName: %s\n", __FUNCTION__, fileName);
        secRet = zte_fclose_s(fp);
        CHECK_RET_WARNING(secRet != (INT32)0, "fclose ret'%d!", secRet);
        return retVal;
    }
    AddRecordHead(&(recordBuf->tHeader), fp);

    if (fsync(fileno(fp)) != 0)
    {
        dbgErr("%s, fsync failed, fileName: %s\n", __FUNCTION__, fileName);
        secRet = zte_fclose_s(fp);
        CHECK_RET_WARNING(secRet != (INT32)0, "fclose ret'%d!", secRet);
        return retVal;
    }
    retVal = BSP_OK;
    secRet = zte_fclose_s(fp);
    FCLOSE_CHECK(secRet);

    return retVal;
}

/**
************************************************************************
* @name      compress_log
* @brief     调用 gzip 压缩文件,-c表示将压缩后的结果输出到标准输出，不改变原文件
* @param[in] const CHAR *path压缩前文件名
*            const CHAR *bakPath压缩后文件名
*            zipLvl压缩速度，1最快，低压缩比。9最慢，高压缩比，缺省值是6
* @warning   压缩成功后会删除
* @return    BSP_ERROR or BSP_OK
* @author    施佳炜10262604
* @date      2022/08/01
************************************************************************
*/
UINT32 compress_log(const CHAR *path, const CHAR *bakPath, INT32 zipLvl)
{
    CHAR cmdBuf[128] = {0};
    INT32 retVal;

    INPUT_POINTER_CHECK(path);
    INPUT_POINTER_CHECK(bakPath);

    if (zipLvl < 1 || zipLvl > 9)
    {
        dbgErr("%s: invalid zipLvl: %d\n", __FUNCTION__, zipLvl);
        return BSP_ERROR;
    }

    retVal = zte_snprintf_s(cmdBuf, sizeof(cmdBuf) - 1, "/bin/gzip -%dc %s > %s", zipLvl, path, bakPath);
    if (retVal <= 0)
    {
        dbgErr("%s: snprintf_s failed, ret: %d\n", __FUNCTION__, retVal);
        return BSP_ERROR;
    }

    retVal = BspSystem(cmdBuf);
    if (retVal != 0)
    {
        dbgErr("%s: exe %s failed, ret: %d\n", __FUNCTION__, cmdBuf, retVal);
        return BSP_ERROR;
    }

    retVal = remove(path);
    if (retVal != 0)
    {
        dbgErr("%s: remove %s failed, ret: %d\n", __FUNCTION__, path, retVal);
        return BSP_ERROR;
    }
    return BSP_OK;
}

/**
************************************************************************
* @name      SaveCurFile2Backup
* @brief     将文件压缩成备份文件
* @param[in] const CHAR *tmpFile临时文件名
*            const CHAR *bakFile备份文件名
* @warning
* @return    BSP_ERROR or BSP_OK
* @author    施佳炜10262604
* @date      2022/08/01
************************************************************************
*/
UINT32 SaveCurFile2Backup(const CHAR *tmpFile, const CHAR *bakFile)
{
    return compress_log(tmpFile, bakFile, 9);
}

/**
************************************************************************
* @name      BspRenameLogFile
* @brief     BAK文件重命名，留出_01.gz。即*_03.gz->*04.gz，依次类推
* @param[in] const CHAR *dirPath路径
*            const CHAR *filePrefix文件前缀
*            UCHAR maxFileCount最多转储份数
* @warning
* @return    BSP_ERROR or BSP_OK
* @author    施佳炜10262604
* @date      2022/08/01
************************************************************************
*/
VOID BspRenameLogFile(const CHAR *file, UCHAR maxFileCount)
{
    CHAR srcFileName[255] = {0};
    CHAR dstFileName[255] = {0};
    UCHAR i;

    for (i = maxFileCount; i > 1; i--)
    {
        bzero(srcFileName, sizeof(srcFileName));
        bzero(dstFileName, sizeof(dstFileName));
        if (zte_snprintf_s(srcFileName, sizeof(srcFileName) - 1, file, i - 1) <= 0)
        {
            continue;
        }
        // 源文件不存在，跳过本次循环
        if (access(srcFileName, F_OK) != 0)
        {
            continue;
        }
        if (zte_snprintf_s(dstFileName, sizeof(dstFileName), file, i) <= 0)
        {
            continue;
        }
        // 目的文件如果存在，删除
        if (access(dstFileName, F_OK) == 0)
        {
            (VOID) remove(dstFileName);
        }
        (VOID) BspMoveFile(srcFileName, dstFileName);
    }
}

UINT8 findPosition(T_COM_RECORD *pRecord, UINT8 index)
{
    UINT8 i;
    unsigned long long flag;
    flag = 0 == index ? CUR_BUF_FLAG : BAK_BUF_FLAG;

    for (i = 0; i < RECORD_BUF_CNT; i++)
    {
        if (flag == pRecord[i].tHeader.ullFlag)
        {
            break;
        }
    }
    /*原则上讲，一定会找到，boot内核串口log初始化时会写入BOOT log的 CUR,BAK标志。
     若没找到有CUR或BAK标志的缓冲区，则指定第一个缓冲区作为的CUR或BAK */
    if (RECORD_BUF_CNT == i)
    {
        i = 0;
    }

    return i;
}

VOID CreateLogDir(VOID)
{
    struct stat statBuf = {0};
    CHAR cmdBuf[255] = {0};
    INT32 retVal = 0;

    if ((stat(log_desc->bk_log_path, &statBuf) == 0) && S_ISDIR(statBuf.st_mode))
    {
        dbgInfo("%s: dir: %s exist\n", __FUNCTION__, log_desc->bk_log_path);
        return;
    }

    if (zte_snprintf_s(cmdBuf, sizeof(cmdBuf) - 1, "/bin/mkdir -p %s", log_desc->bk_log_path) <= 0)
    {
        dbgErr("%s: snprintf_s failed\n", __FUNCTION__);
        return;
    }

    retVal = BspSystem(cmdBuf);
    if (retVal != 0)
    {
        dbgErr("%s: exe %s failed, ret: %d\n", __FUNCTION__, cmdBuf, retVal);
        return;
    }
}

/**
************************************************************************
* @name      AddResetInfo
* @brief     在文件开头增加上一把的复位信息
* @param[in] fileName - 文件名
* @warning
* @return    VOID
* @author    施佳炜10262604
* @date      2022/08/01
************************************************************************
*/
VOID AddResetInfo(const CHAR *fileName)
{
    FILE *fp = NULL;
    ResetInfo *info = NULL;
    CHAR Buf[100] = {0};
    INT32 retVal = 0;
    int len = 0;
    ULONG CurBootFlag = BootFlagGet();
    info = (ResetInfo* )BootGetBoardResetInfoAddr();
    UINT32 ResetType_HW = BootGetBoardHwResetType();
    UINT32 ResetType_SW = BootGetBoardSwResetType();

    retVal = zte_snprintf_s(Buf, sizeof(Buf) - 1, "CurBootFlag:0x%x PreBootFlag:0x%x ResetType HW:0x%x SW:0x%x ResetTime:%d-%02d-%02d %02d:%02d:%02d\n",
        CurBootFlag, info->boot_flag, ResetType_HW, ResetType_SW, info->tm_year + 1900, info->tm_mon + 1, info->tm_mday,
        info->tm_hour, info->tm_min, info->tm_sec);
    if (retVal <= 0)
    {
        dbgErr("%s, snprintf_s failed\n", __FUNCTION__);
        return;
    }

    CreateLogDir();
    fp = fopen(fileName, "w+");
    if (fp == NULL)
    {
        dbgErr("%s: open %s failed\n", __FUNCTION__, fileName);
        return;
    }

    len = zte_strnlen_s(Buf, sizeof(Buf));
    if (len >= 0)
    {
        if (fwrite(Buf, len, 1, fp) != 1)
        {
            dbgErr("%s: fwrite %s failed\n", __FUNCTION__, fileName);
            retVal = zte_fclose_s(fp);
            CHECK_RET_WARNING(retVal != (INT32)0, "fclose ret'%d!", retVal);
            return;
        }
    }

    if (fsync(fileno(fp)) != 0)
    {
        dbgErr("%s, fsync failed, fileName: %s\n", __FUNCTION__, fileName);
    }

    if (zte_fclose_s(fp) != 0)
    {
        dbgErr("%s: close %s failed\n", __FUNCTION__, fileName);
    }
}

/**
************************************************************************
* @name      MapComRecordMem
* @brief     将物理地址映射到虚拟地址空间
* @param[in] phyMemAddr  起始地址
*            size 映射长度
* @warning
* @return    映射后的虚拟内存地址
* @author    施佳炜10262604
* @date      2022/08/01
************************************************************************
*/
T_COM_RECORD * MapComRecordMem(unsigned long phyMemAddr, unsigned int size)
{
    INT32 fd = -1;
    VOID *vmAddr = NULL;
    T_COM_RECORD *comRecordAddr = NULL;
    size_t mapSize = size * 2;
    INT32 retVal = 0;

    if (phyMemAddr == 0)
    {
        return NULL;
    }

    fd = open("/dev/mem", O_RDWR | O_SYNC);
    if (fd == -1)
    {
        dbgErr("%s: open /dev/mem failed\n", __FUNCTION__);
        return NULL;
    }

    vmAddr = mmap(0, mapSize, PROT_READ | PROT_WRITE, MAP_SHARED, fd, phyMemAddr);
    if (vmAddr == MAP_FAILED)
    {
        dbgErr("%s: mmap failed, size:%ld, phyaddr:%x\n", __FUNCTION__, mapSize, phyMemAddr);
        retVal = close(fd);
        CHECK_RET_WARNING(retVal != (INT32)0, "%s, close %d failed\n", __FUNCTION__, fd);
        return NULL;
    }
    comRecordAddr = (T_COM_RECORD *)vmAddr;

    if (close(fd) != 0)
    {
        dbgErr("%s, close %d failed\n", __FUNCTION__, fd);
    }
    return comRecordAddr;
}

VOID UnMapComRecordMem(VOID *MemAddr, unsigned int size)
{
    size_t mapSize = size * 2;

    if (munmap(MemAddr, mapSize) != 0)
    {
        dbgErr("%s: munmap %p failed\n", __FUNCTION__, MemAddr);
    }
}

/**
************************************************************************
* @name      BspPrintComRecordHead
* @brief     调试函数，查询bak和cur区的头部信息
* @param[in] index - 0（cur区），1(bak区)
* @warning
* @return    BSP_ERROR or BSP_OK
* @author    施佳炜10262604
* @date      2022/08/01
************************************************************************
*/
UINT32 BspPrintComRecordHead(UINT8 index)
{
    T_COM_RECORD *recordPointer = NULL;
    T_COM_RECORD *pRecord = NULL;
    UINT8 pos = 0;

    if (index > 1)
    {
        return BSP_ERROR;
    }
    pRecord = MapComRecordMem(s_AppLogPhysicAddr, BUF_SIZE);
    INPUT_POINTER_CHECK(pRecord);
    pos = findPosition(pRecord, index);
    recordPointer = &(pRecord[pos]);

    dbgInfo("%s Record physic Address: 0x%x\n", (index == 0) ? "Cur" : "Bak", s_AppLogPhysicAddr + pos * BUF_SIZE);
    dbgInfo("%s Record Virtual Address: %p\n", (index == 0) ? "Cur" : "Bak", recordPointer);
    dbgInfo("ullIndex: %lld\n", recordPointer->tHeader.ullIndex);
    dbgInfo("ullLenInByte: %lld\n", recordPointer->tHeader.ullLenInByte);
    dbgInfo("ullFlag: 0x%llx\n", recordPointer->tHeader.ullFlag);
    dbgInfo("ullSlaveReadIndex: %lld\n", recordPointer->tHeader.ullSlaveReadIndex);
    UnMapComRecordMem(pRecord, BUF_SIZE);

    return BSP_OK;
}
#ifdef CONFIG_RECORD_FSLOG
/**
************************************************************************
* @name      BspSaveUbifsRoLog
* @brief     保存文件系统变只读后的出错块信息
* @warning
* @return    BSP_ERROR or BSP_OK
* @author    niuyanru
* @date      2023/05
************************************************************************
*/
UINT32 BspSaveUbifsRoLog()
{
    const char* tempFileName;
    const char* logFileName;
    T_fs_ro_record *pFsRoLog = NULL;
    FILE *fp = NULL;
    INT32 retVal = 0;
    size_t fwrite_len=0;
    CHAR fileNameBuf[255] = {0};

    if(BootLogDescInit())
    {
        return BSP_ERROR;
    }
    tempFileName = log_desc->boot_cur_fsro_temp_file_path;
    logFileName = log_desc->boot_cur_fsro_file_path;
    pFsRoLog = (T_fs_ro_record *)MapComRecordMem(getFsLogPhyAddr(), UBIFS_RO_LOG_LEN);
    INPUT_POINTER_CHECK(pFsRoLog);

    if (FS_RO_MAGIC != pFsRoLog->magic)
    {
        UnMapComRecordMem(pFsRoLog, UBIFS_RO_LOG_LEN);
        return BSP_OK;
    }
    else
    {
        /*清零模数-->如果再次挂载文件系统或存储有问题，可能会丢一次log
         *因为是维测log。接受这种丢失。*/
        pFsRoLog->magic = 0;
        /*如果发生过格式化后，文件系统重新挂载*/
        if (FS_FILESYSTEM_NOTMOUNT == fs_isro(log_desc->fs_path))
        {
            ubifs_init(log_desc->fs_index);
            taskDelay(sysClkRateGet());
        }
        CreateLogDir();
    }
    /*新建读写文件，如果文件不存在，那么一个新的文件会被创建*/
    fp = fopen(tempFileName, "w+");
    if (fp == NULL)
    {
        dbgErr("%s, open file failed, fileName: %s\n", __FUNCTION__, tempFileName);
        UnMapComRecordMem(pFsRoLog, UBIFS_RO_LOG_LEN);
        return BSP_ERROR;
    }
    fwrite_len = pFsRoLog->errinfo.err_log_pebsize + 4096;
    if(fwrite_len > UBIFS_RO_LOG_LEN)
    {
        dbgErr("%s, err_log_pebsize(0x%x) is oversize\n", __FUNCTION__, fwrite_len);
        /* Started by AICoder, pid:x29e8oc8ba0f31d14c4a082af05db42346370c39 */
        retVal = zte_fclose_s(fp);
        /* Ended by AICoder, pid:x29e8oc8ba0f31d14c4a082af05db42346370c39 */
        CHECK_RET_WARNING(retVal != (INT32)0, "fclose ret'%d!", retVal);
        UnMapComRecordMem(pFsRoLog, UBIFS_RO_LOG_LEN);
        return BSP_ERROR;
    }

    if (fwrite(pFsRoLog, fwrite_len, 1, fp) != 1)
    {
        dbgErr("%s, fwrite head failed, fileName: %s\n", __FUNCTION__, tempFileName);
        retVal = zte_fclose_s(fp);
        CHECK_RET_WARNING(retVal != (INT32)0, "fclose ret'%d!", retVal);
        UnMapComRecordMem(pFsRoLog, UBIFS_RO_LOG_LEN);
        return retVal;
    }

    if (fsync(fileno(fp)) != 0)
    {
        dbgErr("%s, fsync failed, fileName: %s\n", __FUNCTION__, tempFileName);
    }

    if (zte_fclose_s(fp) != 0)
    {
        dbgErr("%s: close %s failed\n", __FUNCTION__, tempFileName);
    }

    UnMapComRecordMem(pFsRoLog, UBIFS_RO_LOG_LEN);

    /*压缩文件到gz，最多存储4份*/
    if (zte_snprintf_s(fileNameBuf, sizeof(fileNameBuf) - 1, logFileName, 1) <= 0)
    {
        dbgErr("%s: snprintf_s failed\n", __FUNCTION__);
        return BSP_ERROR;
    }
    BspRenameLogFile(logFileName, 4);
    if (SaveCurFile2Backup(tempFileName, fileNameBuf) == BSP_OK)
    {
        dbgInfo("%s: save ubi Log successfully\n", __FUNCTION__);
        return BSP_OK;
    }
    return BSP_ERROR;
}
#endif
/**
************************************************************************
* @name      BspSaveBootAppLog
* @brief     保存BootAppLog
* @param[in] index - 0（cur区），1(bak区)
* @warning
* @return    BSP_ERROR or BSP_OK
* @author    施佳炜10262604
* @date      2022/08/01
************************************************************************
*/
UINT32 BspSaveBootAppLog(UINT8 index)
{
    unsigned long long bufferLen = 0;
    T_COM_RECORD *pComRecord = NULL;
    T_COM_RECORD *record = NULL;
    CHAR fileNameBuf[255] = {0};
    UINT8 pos = 0;
    const char* tempFileName;
    const char* logFileName;

    if(BootLogDescInit())
    {
        return BSP_ERROR;
    }
    tempFileName = (0 == index ? log_desc->boot_cur_app_temp_file_path : log_desc->boot_bak_app_temp_file_path);
    logFileName = (0 == index ? log_desc->boot_cur_app_file_path : log_desc->boot_bak_app_file_path);

    /*在文件头增加前一把的复位时间，复位原因，boot启动标志*/
    AddResetInfo(tempFileName);

    pComRecord = MapComRecordMem(s_AppLogPhysicAddr, BUF_SIZE);
    INPUT_POINTER_CHECK(pComRecord);
    pos = findPosition(pComRecord, index);
    record = &(pComRecord[pos]);

    bufferLen = record->tHeader.ullLenInByte;
    if (bufferLen == 0)
    {
        dbgInfo("%s: no cur log need to save, bufferLen:0x%llx\n", __FUNCTION__, bufferLen);
    }
    else
    {
        if (bufferLen >= RECORD_BUF_SIZE_IN_BYTE)
        {
            bufferLen = (UINT64)RECORD_BUF_SIZE_IN_BYTE - 1;
        }

        Save2File(record, bufferLen, tempFileName, "boot record");
    }
    UnMapComRecordMem(pComRecord, BUF_SIZE);
    if (zte_snprintf_s(fileNameBuf, sizeof(fileNameBuf) - 1, logFileName, 1) <= 0)
    {
        dbgErr("%s: snprintf_s failed\n", __FUNCTION__);
        return BSP_ERROR;
    }
    BspRenameLogFile(logFileName, RECORD_FILE_CNT);
    if (SaveCurFile2Backup(tempFileName, fileNameBuf) == BSP_OK)
    {
        dbgInfo("%s: save boot Log successfully, index:%d\n", __FUNCTION__, index);
        return BSP_OK;
    }
    return BSP_ERROR;
}

/**
************************************************************************
* @name      BspSaveBootKmsgLog
* @brief     保存boot kmsg日志
* @param[in] index - 0（cur区），1(bak区)
* @warning
* @return    BSP_ERROR or BSP_OK
* @author    施佳炜10262604
* @date      2022/08/01
************************************************************************
*/
UINT32 BspSaveBootKmsgLog(UINT8 index)
{
    CHAR fileNameBuf[255] = {0};
    CHAR cmdBuf[100] = {0};
    INT32 retVal;
    const char* tempFileName;
    const char* logFileName;

    if(BootLogDescInit())
    {
        return BSP_ERROR;
    }
    tempFileName = (0 == index ? log_desc->boot_cur_kmsg_temp_file_path : log_desc->boot_last_kmsg_temp_file_path);
    logFileName = (0 == index ? log_desc->boot_cur_kmsg_file_path : log_desc->boot_last_kmsg_file_path);

    /*在文件头增加前一把的复位时间，复位原因，boot启动标志*/
    AddResetInfo(tempFileName);
    if (0 == index)
    {
        if (zte_snprintf_s(cmdBuf, sizeof(cmdBuf) - 1, "/bin/dmesg >> %s", tempFileName) <= 0)
        {
            dbgErr("%s: snprintf_s cmdBuf failed\n", __FUNCTION__);
            return BSP_ERROR;
        }
    }
    if (1 == index)
    {
        if (zte_snprintf_s(cmdBuf, sizeof(cmdBuf) - 1, "cat /proc/last_kmsg >> %s", tempFileName) <= 0)
        {
            dbgErr("%s: snprintf_s cmdBuf failed\n", __FUNCTION__);
            return BSP_ERROR;
        }
    }

    retVal = BspSystem(cmdBuf);
    if (retVal != 0)
    {
        dbgErr("%s: exec %s failed, ret: %d\n", __FUNCTION__, cmdBuf, retVal);
        return BSP_ERROR;
    }

    if (zte_snprintf_s(fileNameBuf, sizeof(fileNameBuf) - 1, logFileName, 1) <= 0)
    {
        dbgErr("%s: snprintf_s failed\n", __FUNCTION__);
        return BSP_ERROR;
    }
    BspRenameLogFile(logFileName, RECORD_FILE_CNT);
    if (SaveCurFile2Backup(tempFileName, fileNameBuf) == BSP_OK)
    {
        dbgInfo("%s: save boot kmsg successfully, index:%d\n", __FUNCTION__, index);
        return BSP_OK;
    }
    return BSP_ERROR;
}

UINT32 ram_console_save(const char* fileName, RAM_CONSOLE_BUFFER *buffer, UINT8 index)
{
    FILE *fp = NULL;
    fp = fopen(fileName, "a+");
    int secRet = -1;
    if (fp == NULL)
    {
        dbgErr("%s, open file failed, fileName: %s\n", __FUNCTION__, fileName);
        return BSP_ERROR;
    }
    if (0 == index)
    {
        if (fwrite(&buffer->data[0], buffer->size, 1, fp) != 1)
        {
            dbgErr("%s, fwrite buffer failed, fileName: %s\n", __FUNCTION__, fileName);
            secRet = zte_fclose_s(fp);
            CHECK_RET_WARNING(secRet != (INT32)0, "fclose ret'%d!", secRet);
            return BSP_ERROR;
        }
    }
    if (1 == index)
    {
        if (fwrite(buffer, LAST_KMSG_SIZE, 1, fp) != 1)
        {
            dbgErr("%s, fwrite buffer failed, fileName: %s\n", __FUNCTION__, fileName);
            secRet = zte_fclose_s(fp);
            CHECK_RET_WARNING(secRet != (INT32)0, "fclose ret'%d!", secRet);
            return BSP_ERROR;
        }
    }

    if (fsync(fileno(fp)) != 0)
    {
        dbgErr("%s, fsync failed, fileName: %s\n", __FUNCTION__, fileName);
    }

    if (zte_fclose_s(fp) != 0)
    {
        dbgErr("%s: close %s failed\n", __FUNCTION__, fileName);
    }
    return BSP_OK;
}

/**
************************************************************************
* @name      BootGetLastCpuKmsgLog
* @brief     保存cpu kmsg日志
* @param[in]  index - 0（cur区），1(bak区)
* @warning
* @return    BSP_ERROR or BSP_OK
* @author    施佳炜10262604
* @date      2022/08/01
************************************************************************
*/
UINT32 BootGetLastCpuKmsgLog(UINT8 index)
{
    CHAR fileNameBuf[255] = {0};
    RAM_CONSOLE_BUFFER *logbuf = NULL;
    int ram_console_buffer_size = LAST_KMSG_SIZE - sizeof(RAM_CONSOLE_BUFFER);
    const char* tempFileName;
    const char* logFileName;
    
    if(BootLogDescInit())
    {
        return BSP_ERROR;
    }
    tempFileName = (index == 0 ? log_desc->cpu_cur_kmsg_temp_file_path : log_desc->cpu_last_kmsg_temp_file_path);
    logFileName = (index == 0 ? log_desc->cpu_cur_kmsg_file_path : log_desc->cpu_last_kmsg_file_path);

    /*在文件头增加前一把的复位时间，复位原因，boot启动标志*/
    AddResetInfo(tempFileName);
    /*对于LAST_KMSG，主区在低区，备区在高区*/
    logbuf = (RAM_CONSOLE_BUFFER *)MapComRecordMem(getLastKmsgAddr() + LAST_KMSG_SIZE * index, LAST_KMSG_SIZE);

    INPUT_POINTER_CHECK(logbuf);
    /*对于主区做合法性检查*/
    if (0 == index)
    {
        if (logbuf->magic == RAM_CONSOLE_MAGIC)
        {
            if (logbuf->size > ram_console_buffer_size || logbuf->start > logbuf->size)
            {
                dbgErr("ram_console: found existing invalid buffer, size %d, start %d\n",
                       logbuf->size, logbuf->start);
            }
            else
            {
                dbgErr("ram_console: found existing buffer, size %d, start %d\n",
                       logbuf->size, logbuf->start);
                ram_console_save(tempFileName, logbuf, index);
            }
        }
        else
        {
            dbgErr("ram_console: no valid data in buffer "
                   "(magic = 0x%08x)\n",
                   logbuf->magic);
        }
    }
    /*由于备区头固定被覆盖，对于cpu kmsg的备区直接按长度转储*/
    if (1 == index)
    {
        ram_console_save(tempFileName, logbuf, index);
    }
    UnMapComRecordMem(logbuf, LAST_KMSG_SIZE);
    if (zte_snprintf_s(fileNameBuf, sizeof(fileNameBuf) - 1, logFileName, 1) <= 0)
    {
        dbgErr("%s: snprintf_s failed\n", __FUNCTION__);
        return BSP_ERROR;
    }
    BspRenameLogFile(logFileName, RECORD_FILE_CNT);
    if (SaveCurFile2Backup(tempFileName, fileNameBuf) == BSP_OK)
    {
        dbgInfo("%s: save Last CPU kmsg successfully, index:%d\n", __FUNCTION__, index);
        return BSP_OK;
    }
    return BSP_ERROR;
}
/**
************************************************************************
* @name      BootGetLastCpuAppLog
* @brief     保存CPU AppLog
* @param[in] index - 0（cur区），1(bak区)
* @warning
* @return    BSP_ERROR or BSP_OK
* @author    施佳炜10262604
* @date      2022/08/01
************************************************************************
*/
UINT32 BootGetLastCpuAppLog(UINT8 index)
{
    unsigned long long bufferLen = 0;
    unsigned long long flag = 0;
    T_COM_RECORD *pComRecord = NULL;
    T_COM_RECORD *record = NULL;
    CHAR fileNameBuf[255] = {0};
    UINT8 pos = 0;
    const char* tempFileName;
    const char* logFileName;

    if(BootLogDescInit())
    {
        return BSP_ERROR;
    }
    flag = 0 == index ? CUR_BUF_FLAG : BAK_BUF_FLAG;
    tempFileName = (0 == index ? log_desc->cpu_cur_app_temp_file_path : log_desc->cpu_bak_app_temp_file_path);
    logFileName = (0 == index ? log_desc->cpu_cur_app_file_path : log_desc->cpu_bak_app_file_path);

    /*在文件头增加前一把的复位时间，复位原因，boot启动标志*/
    AddResetInfo(tempFileName);

    pComRecord = MapComRecordMem(getAppLogPhyAddr(), APP_LOG_SIZE);
    INPUT_POINTER_CHECK(pComRecord);

    pos = ((T_COM_RECORD *)(pComRecord + APP_LOG_SIZE / (BUF_SIZE)))->tHeader.ullFlag == flag ? 1 : 0;
    record = pComRecord + pos * APP_LOG_SIZE / (BUF_SIZE);

    bufferLen = record->tHeader.ullLenInByte;

    if (bufferLen == 0)
    {
        dbgInfo("%s: last cpu log need not to save, bufferLen:0x%llx\n", __FUNCTION__, bufferLen);
    }
    else
    {
        if (bufferLen >= (APP_LOG_SIZE - sizeof(T_COM_RECORD_HEADER)))
        {
            bufferLen = APP_LOG_SIZE - sizeof(T_COM_RECORD_HEADER) - 1;
        }

        Save2File(record, bufferLen, tempFileName, "Last CPU record");
    }
    UnMapComRecordMem(pComRecord, APP_LOG_SIZE);
    if (zte_snprintf_s(fileNameBuf, sizeof(fileNameBuf) - 1, logFileName, 1) <= 0)
    {
        dbgErr("%s: snprintf_s failed\n", __FUNCTION__);
        return BSP_ERROR;
    }
    BspRenameLogFile(logFileName, RECORD_FILE_CNT);
    if (SaveCurFile2Backup(tempFileName, fileNameBuf) == BSP_OK)
    {
        dbgInfo("%s: save last cpu log successfully, index:%d\n", __FUNCTION__, index);
        return BSP_OK;
    }
    return BSP_ERROR;
}

/**
************************************************************************
* @name      BootGetLastCpuLog
* @brief     一键提取前一把的CPU日志保存
* @param[in] index - 0（cur区），1(bak区)
* @warning
* @return    VOID
* @author    施佳炜10262604
* @date      2022/08/01
************************************************************************
*/
UINT32 BootGetLastCpuLog(UINT8 index)
{
    int ret = BSP_ERROR;
    if (0 == index || 1 == index)
    {
        ret = BootGetLastCpuAppLog(index);
        ret |= BootGetLastCpuKmsgLog(index);
    }

    return ret;
}

/**
 * mkpath - compose full path from 2 given components.
 * @path: the first component
 * @name: the second component
 *
 * This function returns the resulting path in case of success and %NULL in
 * case of failure.
 */
/* Started by AICoder, pid:63406afe56114b018669b94842ae6717 */
/* Started by VerifyCI-CodeReview, pid:63406afe56114b018669b94842ae6717 */
static char *mkpath(const char *path, const char *name)
{
    if (!path || !name) {
        printf("path or name is null\n");
        return NULL;
    }

    char *n;
    int len1 = zte_strnlen_s(path, MAX_PATH_LEN);
    int len2 = zte_strnlen_s(name, MAX_PATH_LEN);

    if (len2 == 0) {
        printf("name is empty\n");
        return NULL;
    }

    n = malloc(len1 + len2 + 2);
    if (!n) {
        printf("cannot allocate %d bytes\n", len1 + len2 + 2);
        return NULL;
    }

    zte_memcpy_s(n, len1 + len2 + 2, path, len1);
    if (n[len1 - 1] != '/')
        n[len1++] = '/';

    zte_memcpy_s(n + len1, len2 + 2, name, len2 + 1);
    return n;
}
/* Ended by VerifyCI-CodeReview, pid:63406afe56114b018669b94842ae6717 */
/* Ended by AICoder, pid:63406afe56114b018669b94842ae6717 */

void BootLogDescRelease()
{
    if(log_desc != NULL)
    {
        free(log_desc->bk_log_path);
        log_desc->bk_log_path = NULL;
        free(log_desc->boot_bak_app_temp_file_path);
        log_desc->boot_bak_app_temp_file_path = NULL;
        free(log_desc->boot_cur_app_temp_file_path);
        log_desc->boot_cur_app_temp_file_path = NULL;
        free(log_desc->boot_last_kmsg_temp_file_path);
        log_desc->boot_last_kmsg_temp_file_path = NULL;
        free(log_desc->boot_cur_kmsg_temp_file_path);
        log_desc->boot_cur_kmsg_temp_file_path = NULL;
        free(log_desc->boot_bak_app_file_path);
        log_desc->boot_bak_app_file_path = NULL;
        free(log_desc->boot_cur_app_file_path);
        log_desc->boot_cur_app_file_path = NULL;
        free(log_desc->boot_last_kmsg_file_path);
        log_desc->boot_last_kmsg_file_path = NULL;
        free(log_desc->boot_cur_kmsg_file_path);
        log_desc->boot_cur_kmsg_file_path = NULL;
        free(log_desc->boot_cur_fsro_temp_file_path);
        log_desc->boot_cur_fsro_temp_file_path = NULL;
        free(log_desc->boot_cur_fsro_file_path);
        log_desc->boot_cur_fsro_file_path = NULL;
        free(log_desc->cpu_bak_app_temp_file_path);
        log_desc->cpu_bak_app_temp_file_path = NULL;
        free(log_desc->cpu_cur_app_temp_file_path);
        log_desc->cpu_cur_app_temp_file_path = NULL;
        free(log_desc->cpu_last_kmsg_temp_file_path);
        log_desc->cpu_last_kmsg_temp_file_path = NULL;
        free(log_desc->cpu_cur_kmsg_temp_file_path);
        log_desc->cpu_cur_kmsg_temp_file_path = NULL;
        free(log_desc->cpu_bak_app_file_path);
        log_desc->cpu_bak_app_file_path = NULL;
        free(log_desc->cpu_cur_app_file_path);
        log_desc->cpu_cur_app_file_path = NULL;
        free(log_desc->cpu_last_kmsg_file_path);
        log_desc->cpu_last_kmsg_file_path = NULL;
        free(log_desc->cpu_cur_kmsg_file_path);
        log_desc->cpu_cur_kmsg_file_path = NULL;
        free(log_desc);
        log_desc = NULL;
    }
}

int BootLogDescInit()
{
    if(log_desc != NULL)
        return 0;
    log_desc = calloc(1, sizeof(T_LOG_DESC));
    if(!log_desc)
        return -1;
    #ifdef CONFIG_ZXW11200_NTN
    if(NTN_BOARD_2ND == get_ntn_board_type())
    {
        log_desc->fs_path = FS2_PATH;
        log_desc->fs_index = 2;
        log_desc->bk_log_path = mkpath(FS2_PATH,BK_LOG_PATH);
        if (!log_desc->bk_log_path)
            goto out_error;
    }
    else
    #endif
    {
        log_desc->fs_path = FS_PATH;
        log_desc->fs_index = 0;
        log_desc->bk_log_path = mkpath(FS_PATH,BK_LOG_PATH);
        if (!log_desc->bk_log_path)
            goto out_error;
    }

    log_desc->boot_bak_app_temp_file_path = mkpath(log_desc->bk_log_path,BOOT_BAK_LOG_TEMP_FILE_NAME);
    if (!log_desc->boot_bak_app_temp_file_path)
		goto out_error;

    log_desc->boot_cur_app_temp_file_path = mkpath(log_desc->bk_log_path,BOOT_CUR_LOG_TEMP_FILE_NAME);
    if (!log_desc->boot_cur_app_temp_file_path)
		goto out_error;

    log_desc->boot_last_kmsg_temp_file_path = mkpath(log_desc->bk_log_path,BOOT_LAST_KMSG_TEMP_FILE_NAME);
    if (!log_desc->boot_last_kmsg_temp_file_path)
		goto out_error;

    log_desc->boot_cur_kmsg_temp_file_path = mkpath(log_desc->bk_log_path,BOOT_CUR_KMSG_TEMP_FILE_NAME);
    if (!log_desc->boot_cur_kmsg_temp_file_path)
		goto out_error;

    log_desc->boot_bak_app_file_path = mkpath(log_desc->bk_log_path,BOOT_APP_LOG_BAK_FILE_NAME);
    if (!log_desc->boot_bak_app_file_path)
		goto out_error;

    log_desc->boot_cur_app_file_path = mkpath(log_desc->bk_log_path,BOOT_APP_LOG_CUR_FILE_NAME);
    if (!log_desc->boot_cur_app_file_path)
		goto out_error;

    log_desc->boot_last_kmsg_file_path = mkpath(log_desc->bk_log_path,BOOT_LAST_KMSG_FILE_NAME);
    if (!log_desc->boot_last_kmsg_file_path)
		goto out_error;

    log_desc->boot_cur_kmsg_file_path = mkpath(log_desc->bk_log_path,BOOT_CUR_KMSG_FILE_NAME);
    if (!log_desc->boot_cur_kmsg_file_path)
		goto out_error;

    log_desc->boot_cur_fsro_temp_file_path = mkpath(log_desc->bk_log_path,BOOT_CUR_FSRO_TEMP_FILE_NAME);
    if (!log_desc->boot_cur_fsro_temp_file_path)
		goto out_error;

    log_desc->boot_cur_fsro_file_path = mkpath(log_desc->bk_log_path,BOOT_CUR_FSRO_FILE_NAME);
    if (!log_desc->boot_cur_fsro_file_path)
		goto out_error;
    
    log_desc->cpu_bak_app_temp_file_path = mkpath(log_desc->bk_log_path,BAK_LOG_TEMP_FILE_NAME);
    if (!log_desc->cpu_bak_app_temp_file_path)
		goto out_error;

    log_desc->cpu_cur_app_temp_file_path = mkpath(log_desc->bk_log_path,CUR_LOG_TEMP_FILE_NAME);
    if (!log_desc->cpu_cur_app_temp_file_path)
		goto out_error;

    log_desc->cpu_last_kmsg_temp_file_path = mkpath(log_desc->bk_log_path,LAST_KMSG_TEMP_FILE_NAME);
    if (!log_desc->cpu_last_kmsg_temp_file_path)
		goto out_error;

    log_desc->cpu_cur_kmsg_temp_file_path = mkpath(log_desc->bk_log_path,CUR_KMSG_TEMP_FILE_NAME);
    if (!log_desc->cpu_cur_kmsg_temp_file_path)
		goto out_error;

    log_desc->cpu_bak_app_file_path = mkpath(log_desc->bk_log_path,APP_LOG_BAK_FILE_NAME);
    if (!log_desc->cpu_bak_app_file_path)
		goto out_error;

    log_desc->cpu_cur_app_file_path = mkpath(log_desc->bk_log_path,APP_LOG_CUR_FILE_NAME);
    if (!log_desc->cpu_cur_app_file_path)
		goto out_error;

    log_desc->cpu_last_kmsg_file_path = mkpath(log_desc->bk_log_path,LAST_KMSG_FILE_NAME);
    if (!log_desc->cpu_last_kmsg_file_path)
		goto out_error;

    log_desc->cpu_cur_kmsg_file_path = mkpath(log_desc->bk_log_path,CUR_KMSG_FILE_NAME);
    if (!log_desc->cpu_cur_kmsg_file_path)
		goto out_error;
    
    return 0;

    out_error:
	BootLogDescRelease(log_desc);
    return -1;
}
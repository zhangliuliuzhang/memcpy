/**
 ******************************************************************************
 * Copyright (c) 2020 ZTE Corp. ZXSDR-RRU Platform BSP.
 *
 * @file        bspcommonstdlog.h
 * @brief       串口日志保存头文件
 * @version     V1.0
 * @author      施佳炜10262604
 * @date        2022/08/01
 ******************************************************************************
*/
#ifndef _BSP_COM_STD_LOG_H_
#define _BSP_COM_STD_LOG_H_

#ifdef __cplusplus
extern "C" {
#endif

#include "bsppub.h"

#define FS_PATH "/mnt/filesystem"
#define FS2_PATH "/mnt/filesystem2"
#define BK_LOG_PATH ".log/b_k"
#define LAST_KMSG_ROOTFS_FILE_PATH "/proc/last_kmsg"

#define BOOT_BAK_LOG_TEMP_FILE_NAME "bootbaklogtempfile"
#define BOOT_APP_LOG_BAK_FILE_NAME "bspmasterbootapplog_%02d.gz"
#define BOOT_CUR_LOG_TEMP_FILE_NAME "bootcurlogtempfile"
#define BOOT_APP_LOG_CUR_FILE_NAME "bspmasterbootapplogcur_%02d.gz"
#define BOOT_LAST_KMSG_TEMP_FILE_NAME "bootlastkmsgtempfile"
#define BOOT_LAST_KMSG_FILE_NAME "bspmasterbootkmsg_%02d.gz"
#define BOOT_CUR_KMSG_TEMP_FILE_NAME "bootcurkmsgtempfile"
#define BOOT_CUR_KMSG_FILE_NAME "bspmasterbootcurkmsg_%02d.gz"

/*文件系统只读信息*/
#define BOOT_CUR_FSRO_TEMP_FILE_NAME "bspmasterfsisro"
#define BOOT_CUR_FSRO_FILE_NAME "bspmasterfsisro_%02d.gz"
#define BOOT_CUR_FSRO_FILE_PATH BK_LOG_PATH"/"BOOT_CUR_FSRO_FILE
#define UBIFS_RO_LOG_LEN  (256*1024 + 4096)

#define BAK_LOG_TEMP_FILE_NAME "baklogtempfile_b"
#define APP_LOG_BAK_FILE_NAME "bspmasterapplog_b_%02d.gz"
#define CUR_LOG_TEMP_FILE_NAME "curlogtempfile_b"
#define APP_LOG_CUR_FILE_NAME "bspmasterapplogcur_b_%02d.gz"
#define LAST_KMSG_TEMP_FILE_NAME "lastkmsgtempfile_b"
#define LAST_KMSG_FILE_NAME "bspmasterkmsg_b_%02d.gz"
#define CUR_KMSG_TEMP_FILE_NAME "curkmsgtempfile_b"
#define CUR_KMSG_FILE_NAME "bspmastercurkmsg_b_%02d.gz"

typedef struct
{
    unsigned int fs_index;
    const char* fs_path;
    char* bk_log_path;
    char* boot_bak_app_temp_file_path;
    char* boot_cur_app_temp_file_path;
    char* boot_last_kmsg_temp_file_path;
    char* boot_cur_kmsg_temp_file_path;
    char* boot_bak_app_file_path;
    char* boot_cur_app_file_path;
    char* boot_last_kmsg_file_path;
    char* boot_cur_kmsg_file_path;
    char* boot_cur_fsro_temp_file_path;
    char* boot_cur_fsro_file_path;
    char* cpu_bak_app_temp_file_path;
    char* cpu_cur_app_temp_file_path;
    char* cpu_last_kmsg_temp_file_path;
    char* cpu_cur_kmsg_temp_file_path;
    char* cpu_bak_app_file_path;
    char* cpu_cur_app_file_path;
    char* cpu_last_kmsg_file_path;
    char* cpu_cur_kmsg_file_path;
}T_LOG_DESC;

#define CUR_LOG_DELAY_S (0)
#define RECORD_BUF_CNT 2
#define CUR_BUF_FLAG (0x0000BEEF)   /* 当前BUF标志 */
#define BAK_BUF_FLAG (0xBBBBBEEF)   /* 备份BUF标志 */
#define CUR_LOG      0
#define BAK_LOG      1

#if (defined(CONFIG_ZXW11200) || defined(CONFIG_LS10X3A) || defined(CONFIG_ZX211410_EXT))
#define BUF_SIZE (0x10000)  /* 单个缓冲区数据容量: 64k*/

#elif (defined(CONFIG_ZX2112XX) || defined(CONFIG_ZX211412) || defined(CONFIG_ZX211413))
#define BUF_SIZE (0x20000)  /* 单个缓冲区数据容量: 128k*/
#endif

#define RECORD_FILE_CNT 8   /*保存log的份数*/

typedef struct
{
    unsigned long long ullIndex;
    unsigned long long ullLenInByte;
    unsigned long long ullFlag;
    unsigned long long ullSlaveReadIndex;
} T_COM_RECORD_HEADER;
#define RECORD_BUF_SIZE_IN_BYTE (BUF_SIZE - sizeof(T_COM_RECORD_HEADER))
typedef struct
{
    T_COM_RECORD_HEADER tHeader;
    unsigned char acBuf[RECORD_BUF_SIZE_IN_BYTE];
} T_COM_RECORD;

#define RAM_CONSOLE_MAGIC (0x52434d47)	/* RCMG */
typedef struct 
{
	unsigned int magic;
	unsigned int start;
	unsigned int size;
	unsigned char data[0];
}RAM_CONSOLE_BUFFER;

typedef struct
{
    int boot_flag;    /*对于存在双boot控制字的，前16位为双boot控制字，后16位为寄存器值*/
    char reserve0[4];
    int tm_sec;
    int tm_min;
    int tm_hour;
    int tm_mday;
    int tm_mon;
    int tm_year;
    char reserve1[36];
}ResetInfo;
/*文件系统只读信息记录*/
typedef struct ubi_errlog_info {
    int err_log_mtdnum;
    int err_log_lnum;
    int err_log_pnum;
    int err_log_pebsize;
    int err_log_offs;
    int err_log_errnum;
    char err_log_reason[8];
    char err_log_func[32];
}T_ubi_errlog_info;
/*高端内存分布：128B 结构体 256KB裸数据*/
typedef struct fs_ro_record {
    unsigned int magic;
    T_ubi_errlog_info errinfo;
}T_fs_ro_record;
#define FS_RO_MAGIC (0x46524d47) /*FRMG*/

UINT32 BspPhyAddrToKernel(unsigned long long phyAddr, UINT32 interruptNum, INT32 KdaDrvFd);
UINT32 BspSaveBootAppLog(UINT8 index);
UINT32 BspSaveBootKmsgLog(UINT8 index);
UINT32 BspPrintComRecordHead(UINT8 index);
UINT32 BootGetLastCpuLog(UINT8 index);
UINT32 BspSaveUbifsRoLog();
int BootLogDescInit();
#ifdef __cplusplus
}
#endif
#endif /* _BSP_COM_STD_LOG_H_ */

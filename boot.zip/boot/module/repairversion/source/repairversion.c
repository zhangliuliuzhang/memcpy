#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h>
#include <bsppub.h>
#include "bspcomm.h"
#include "flash.h"
#include <loadversion.h>
#include <repairversion.h>
#include "secure_func.h"
#include "bootapp.h"

extern UCHAR g_ucRunVer;
extern ULONG BootCalculateFlashVerCrc(ULONG ulFlashAddr, ULONG ulVerLen, ULONG *pulCrc);
extern ULONG BspGetFlashBlkSize(ULONG ulFlashAddr, ULONG ulSrcFileLen, ULONG *ulBuffLen);
#ifdef CONFIG_LOADVERSION_PLUS
extern ULONG BootGetVerProtectSwvLen(VOID);
#endif

/* area1 area2 area3 相同返回area1
    area1 area2  相同返回area1
    area2 area3 相同返回area2
    area1 area3 相同返回area3
    area1 area2 area3 都不相同返回NULL
*/
/* Started by AICoder, pid:5e237cf209074f6eb56aa48e3839b7ec */
/* Started by VerifyCI-CodeReview, pid:5e237cf209074f6eb56aa48e3839b7ec */
static unsigned char* three_area_compare(unsigned char* area1, unsigned char* area2, unsigned char* area3, uint len)
{
    if (NULL == area1 || NULL == area2 || NULL == area3)
    {
        return NULL;
    }

    if (len == 0)
    {
        return NULL;
    }

    if (area1 == area2 || area1 == area3 || area2 == area3)
    {
        return NULL;
    }

    if (0 != memcmp(area1, area2, len))
    {
        if (0 != memcmp(area1, area3, len))
        {
            if (0 != memcmp(area2, area3, len))
            {
                return NULL;
            }
            else
            {
                return area2;
            }
        }
        else
        {
            return area3;
        }
    }
    else
    {
        return area1;
    }
}
/* Ended by VerifyCI-CodeReview, pid:5e237cf209074f6eb56aa48e3839b7ec */
/* Ended by AICoder, pid:5e237cf209074f6eb56aa48e3839b7ec */


/* Started by AICoder, pid:2afdbtbd1cte84314b700826807115214313b813 */
static int getContentFromFilesystem(const char* filename, unsigned char* buffer, long offset, long len) 
{
    int fd = open(filename, O_RDONLY);
    if (fd == -1) {
        perror("Failed to open file");
        return -1;
    }
    
    if (lseek(fd, offset, SEEK_SET) == -1) {
        perror("Failed to seek file");
        close(fd);
        return -1;
    }
    
    ssize_t bytesRead = read(fd, buffer, len);
    if (bytesRead == -1) {
        perror("Failed to read file");
        close(fd);
        return -1;
    }
    
    close(fd);
    return bytesRead;
}
/* Ended by AICoder, pid:2afdbtbd1cte84314b700826807115214313b813 */

static int getContentFromProtect(unsigned int ulIndex, unsigned char* buffer, long offset, long len) 
{
    if (ulIndex > 1)
    {
        return -1;
    }

    ULONG ulProtectAddr, ulFlashSection;
    UINT32 ulVerOffSet = 0;

    ulFlashSection = BspGetFlashEraseSectorSize();
    ulProtectAddr = BootGetFlashVerProtectAddr();
    
    /* CPU版本是保护区第一个版本、FPGA是第二个版本 */
    /* 组件化cur27是保护区第一个版本、cur是第二个版本 */
    if (0 == ulIndex)
    {
        ulVerOffSet = 1 * ulFlashSection;
    }
    else
    {
        ulVerOffSet = 2 * ulFlashSection;
    }

    return BspFlashRead(ulProtectAddr + ulVerOffSet + offset, buffer, len);
}

static int getProtectVerInfo(T_ProtectVerInfo *ptVerInfo)
{
    T_VerProtectHead *ptVerProtectHead = NULL;
    unsigned int ulProZoneAddrOffset;
    unsigned int ulProtectHeadLen;
    unsigned int ulRet = BSP_OK;
    UINT32 uiret = BSP_OK;

    INPUT_POINTER_CHECK(ptVerInfo);

    ulProZoneAddrOffset = BootGetFlashVerProtectAddr();
    ulProtectHeadLen = sizeof(T_VerProtectHead);
    
    ptVerProtectHead = (T_VerProtectHead *)malloc(ulProtectHeadLen);
    dbgErr("ptVerProtextHead = 0x%x \n", (ULONG)ptVerProtectHead);
    if (NULL == ptVerProtectHead)
    {
        dbgErr("malloc error!!\n");
        return BSP_ERROR;
    }

    zte_memset_s(ptVerProtectHead, ulProtectHeadLen, 0, ulProtectHeadLen);
    ulRet = BspFlashRead(ulProZoneAddrOffset, (UCHAR *)ptVerProtectHead, ulProtectHeadLen);
    if (ulRet != BSP_OK)
    {
        dbgErr(" T_VerProtectHead INFO READ wrong!!\n");
        uiret = BSP_ERROR;
        goto ret1;
    }

    #if defined(CONFIG_SECURITY)
    memcpy(ptVerInfo,&ptVerProtectHead->tVerInfo[1],sizeof(T_ProtectVerInfo));
    #else
    memcpy(ptVerInfo,&ptVerProtectHead->tVerInfo[0],sizeof(T_ProtectVerInfo));
    #endif

    ret1:
    if (ptVerProtectHead)
    {
        free(ptVerProtectHead);
        ptVerProtectHead = NULL;
    }

    return uiret;
}

static int getRepairVerSize()
{
    T_ProtectVerInfo *ptVerInfo = NULL;
    struct stat tStatInfo;
    unsigned int *size = NULL;
    unsigned int protectVersize = 0, ataVersize = 0, ata1Versize = 0;

    ptVerInfo = calloc(sizeof(T_ProtectVerInfo),1);
    if (NULL == ptVerInfo)
    {
        dbgErr("calloc ptVerInfo failed!");
        return -1;
    }
    
    getProtectVerInfo(ptVerInfo);
    protectVersize = ptVerInfo->tVerInfoFile.ulSWLength;

    if (0 != stat(RTR_VX_OLD, &tStatInfo))
    {
        dbgErr("File:%s not exist!!\n", RTR_VX_OLD);
        free(ptVerInfo);
        ptVerInfo = NULL;
        return -1;
    }
    ataVersize = tStatInfo.st_size;

    if (0 != stat(RTR1_VX_OLD, &tStatInfo))
    {
        dbgErr("File:%s not exist!!\n", RTR1_VX_OLD);
        free(ptVerInfo);
        ptVerInfo = NULL;
        return -1;
    }
    ata1Versize = tStatInfo.st_size;

    free(ptVerInfo);
    ptVerInfo = NULL;

    printf("protectVersize:%d ataVersize:%d ata1Versize:%d\n",protectVersize, ataVersize, ata1Versize);
    size = (unsigned int*)three_area_compare((unsigned char*)&protectVersize, (unsigned char*)&ataVersize, (unsigned char*)&ata1Versize, sizeof(unsigned int));
    if(!size)
    {
        return -1;
    }
    
    return *size;
}

typedef struct version_flash_info
{
    int location;
    char filePath[128];
    char tempFilePath[128];
} version_info_t;

/* Started by AICoder, pid:ae05086ca6kaeb814e2509ca10258f141a854b25 */
static int getContentFromFlash(version_info_t* info, unsigned char* buffer, long offset, long len)
{
    if (IN_FILESYSTEM == info->location)
    {
        return getContentFromFilesystem(info->filePath, buffer, offset, len);
    }
    else if (IN_PROTECTION == info->location)
    {
        return getContentFromProtect(1, buffer, offset, len);
    }
    else
    {
        return UNKNOWN_LOCATION;
    }
}
/* Ended by AICoder, pid:ae05086ca6kaeb814e2509ca10258f141a854b25 */

static version_info_t versionInfo[] = {{IN_FILESYSTEM,RTR_VX_OLD,RTR_VX_REPAIR},
                                        {IN_FILESYSTEM,RTR1_VX_OLD,RTR1_VX_REPAIR},
                                        {IN_PROTECTION,"protection","protection"}};

/* Started by AICoder, pid:be05086ca63aeb814e2509ca10258f341a864b25 */
static int getRepairVersionWithSlideWindow(uint maxWindowLength, unsigned char* versionAddr, unsigned int versionSize, version_info_t* info)
{
    if (maxWindowLength <= 0 || versionAddr == NULL || versionSize <= 0 || info == NULL)
    {
        printf("input para error!\n");
        return -1;
    }
    
    long offset = 0;
    long len = maxWindowLength;

    printf("getting repair version,pls wait...\n");

    while (offset < versionSize)
    {
        if(len <= 0)
        {
            printf("get repair version failed at 0x%lx!\n",offset);
            return -1;
        }

        if(offset + len > versionSize)
        {
            len /= 2;
            continue;
        }

        unsigned char buffer1[maxWindowLength];
        unsigned char buffer2[maxWindowLength];
        unsigned char buffer3[maxWindowLength];

        getContentFromFlash(&info[0], buffer1, offset, len);
        getContentFromFlash(&info[1], buffer2, offset, len);
        getContentFromFlash(&info[2], buffer3, offset, len);
        
        unsigned char* result = three_area_compare(buffer1, buffer2, buffer3, len);

        if (result != NULL)
        {
            memcpy(versionAddr + offset, result, len);
            offset += len;
            len *= 2;
            if(len > maxWindowLength)
            {
                len = maxWindowLength;
            }
        }
        else
        {
            len /= 2;
        }
    }

    printf("get repair version succeed!waitting for check...\n");

    return ldFileFromRam(versionAddr, versionSize);
}
/* Ended by AICoder, pid:be05086ca63aeb814e2509ca10258f341a864b25 */

static UINT32 BootWriteSwToFile(UINT8 *pucSrcBuf, UINT32 ulBufLen, const char *pucOutName)
{
    FILE *fp = NULL;
    INT32 iWrLen = 0;
    INT32 lSnpRet = 0;
    UINT32 ulRetVal = BSP_OK;
    struct stat fileStat = {0};

    if (NULL == pucSrcBuf)
    {
        dbgErr("%s>>Param Error! SrcBuf is NULL\n", __FUNCTION__);
        return BSP_ERROR;
    }

    if (NULL == pucOutName)
    {
        dbgErr("%s>>Param Error! outputFilePath is NULL\n", __FUNCTION__);
        return BSP_ERROR;
    }
    /*检查是否存在*/
    if ((stat(pucOutName, &fileStat) != -1)&&(BSP_OK != BspDeleteFile(pucOutName)))
    {
        dbgErr("%s>>file %s can't delete !\n",__FUNCTION__,pucOutName);
        return BSP_ERROR;
    }
    fp = fopen(pucOutName, "w+");
    if (fp == NULL)
    {
        dbgErr("%s>>[%s] Open Error!\n", __FUNCTION__, pucOutName);
        return BSP_ERROR;
    }
    iWrLen = fwrite(pucSrcBuf, 1, ulBufLen, fp);
    if (iWrLen != (INT32)ulBufLen)
    {
        lSnpRet = fclose(fp);
        FCLOSE_CHECK(lSnpRet);

        ulRetVal = BspDeleteFile(pucOutName);
        if (BSP_OK != ulRetVal)
        {
            dbgErr("%s>>Fwrite Fail! File Delete Error!\n", __FUNCTION__);
            return BSP_ERROR - 2;
        }
        return BSP_ERROR - 1;
    }

    lSnpRet = fclose(fp);
    FCLOSE_CHECK(lSnpRet);
    return BSP_OK;
}

ULONG BootSlowCopyDataToFlash(UCHAR *data, ULONG dataLength, ULONG ulFlashAddr)
{
    ULONG ulRetVal = BSP_OK;
    ULONG ulBuffLen = 0;

    INPUT_POINTER_CHECK(data);

    /*获取mtd分区块大小*/
    ulRetVal = BspGetFlashBlkSize(ulFlashAddr, dataLength, &ulBuffLen);
    if (ulRetVal || (0 == ulBuffLen) || (ulBuffLen > 0x10000))
    {
        dbgErr("ERROR: plsese chech file size & flashAddr, ulRetVal: 0x%x, ulBuffLen: 0x%x!", ulRetVal, ulBuffLen);
        return BSP_ERROR;
    }

    while (dataLength >= ulBuffLen)
    {
        /* 将读取到的内容写入flash */
        ulRetVal = BspFlashWrite(ulFlashAddr, (UCHAR *)data, ulBuffLen);
        if (BSP_OK != ulRetVal)
        {
            dbgErr("write flash failed!\n");
            return BSP_ERROR;
        }

        BootSysMsDelay(10);
        dataLength -= ulBuffLen;
        data += ulBuffLen;
        ulFlashAddr += ulBuffLen;
    }

    if (BSP_OK == ulRetVal)
    {
        if (dataLength > 0)
        {
            /* 将读取的内容写入flash */
            ulRetVal = (ULONG)BspFlashWrite(ulFlashAddr, (UCHAR *)data, dataLength);
            if (BSP_OK != ulRetVal)
            {
                dbgErr("write flash failed!!");
                return BSP_ERROR;
            }
            /*延时10ms*/
            BootSysMsDelay(10);
        }
    }

    return ulRetVal;
}

static ULONG BootCopyRepairVerToFlash(ULONG ulIndex, UCHAR *data, UINT32 dataSize, T_VerProtectHead *ptProtectHead)
{
    ULONG ulRetVal                      = BSP_OK;
    ULONG ulProtectAddr                 = 0;
    ULONG ulProtectLen                  = 0;
    ULONG ulFlashSection                = 0;
    BYTE ucLoop                         = 0;
    T_ProtectVerInfo *ptVerInfo         = NULL;
    T_VerFileHeader *ptSwFileHead;
    ULONG ulProtectVerCrc               = 0;
    ULONG ulCalCrc                      = 0;

    INPUT_POINTER_CHECK(data);
    INPUT_POINTER_CHECK(ptProtectHead);

    ulFlashSection = BspGetFlashEraseSectorSize();

    ptSwFileHead = (T_VerFileHeader *)data;

    ptVerInfo = &(ptProtectHead->tVerInfo[ulIndex]);

    /* 获取保护区头信息 */
    #ifdef CONFIG_LOADVERSION_PLUS
    ulProtectLen          = BootGetVerProtectSwvLen();
    #else
    ulProtectLen          = BootGetVerProtectLen();
    #endif
    ulProtectAddr         = BootGetFlashVerProtectAddr();
    
    /* CPU版本是保护区第一个版本、FPGA是第二个版本 */
    /* 组件化cur27是保护区第一个版本、cur是第二个版本 */
    if (0 == ulIndex)
    {
        ptVerInfo->ulVerOffSet = 1 * ulFlashSection;
    }
    else
    {
        ptVerInfo->ulVerOffSet = 2 * ulFlashSection;
    }
    ptVerInfo->tVerInfoFile.ulSWLength               = dataSize;
    ptVerInfo->tVerInfoFile.ulCRC32                  = ptSwFileHead->ulCRC32;
    ptVerInfo->tVerInfoFile.tFILESWINF.ulSoftType    = ptSwFileHead->ulSoftType;
    ptVerInfo->tVerInfoFile.tFILESWINF.ucCpuType     = ptSwFileHead->ucCpuType;
    ptVerInfo->tVerInfoFile.tFILESWINF.ucVersionKind = (UCHAR)ulIndex;
    zte_memcpy_s(ptVerInfo->tVerInfoFile.tFILESWINF.acVersionNo, VERNO_LEN, ptSwFileHead->ucVerNo, VERNO_LEN);
    
    dbgInfo("ulProtectAddr : %x, ulVerOffSet: 0x%x, ulSWLength : %d, ulCRC32 : 0x%x, ucSwClass: %d, acVersionNo: %s\n",
        ulProtectAddr, ptVerInfo->ulVerOffSet, ptVerInfo->tVerInfoFile.ulSWLength,
        ptVerInfo->tVerInfoFile.ulCRC32, ptVerInfo->tVerInfoFile.tFILESWINF.ucVersionKind,
        ptVerInfo->tVerInfoFile.tFILESWINF.acVersionNo);

    /* 偏移加上文件长度不能超过保护区长度 */
    if ((ptVerInfo->ulVerOffSet + dataSize) > ulProtectLen)
    {
        dbgErr("error!data length <%d> append offset <%d> is larger the and protect length <%d>!\n",
             dataSize, ptVerInfo->ulVerOffSet, ulProtectLen);
        return BSP_ERROR;
    }

    /* 写版本文件 */
    for (ucLoop = 0; ucLoop < 3; ucLoop++)
    {
        if (BSP_OK != BootSlowCopyDataToFlash(data, dataSize, (ulProtectAddr + ptVerInfo->ulVerOffSet)))
        {
            dbgErr("write ver ro flash error!");
            continue;
        }

        /* 写flash完毕再对flash中的版本进行CRC校验 */
        if (BSP_OK != BspFlashRead((ulProtectAddr + ptVerInfo->ulVerOffSet), (UCHAR *)&ulProtectVerCrc, sizeof(ULONG)))
        {
            dbgErr("BspFlashRead Failed! time: %d\n", ucLoop);
            continue;
        }

        BootSysMsDelay(1000);
        if (BSP_OK != BootCalculateFlashVerCrc((ulProtectAddr + ptVerInfo->ulVerOffSet + sizeof(ULONG)), (dataSize - sizeof(ULONG)), &ulCalCrc))
        {
            dbgInfo("Check Flash Crc Failed! time: %d\n", ucLoop);
            continue;
        }

        ulProtectVerCrc = ntohl(ulProtectVerCrc);

        if (ulProtectVerCrc != ulCalCrc)
        {
            dbgInfo("Crc check Failed!, Head: %d, Calculate: %d!\n", ulProtectVerCrc, ulCalCrc);
            continue;
        }
        else
        {
            break;
        }
    }

    if (3 == ucLoop)
    {
        dbgErr("copy data to flash failed!\n");
        return BSP_ERROR;
    }

    return ulRetVal;
}

static ULONG flushRepairSwToProtect(UCHAR *data, UINT32 dataSize)
{
    T_VerProtectHead *ptVerProtectHead = NULL;
    ULONG ulProtectAddr, ulFlashSection;

    INPUT_POINTER_CHECK(data);

    ulProtectAddr = BootGetFlashVerProtectAddr();
    ulFlashSection = BspGetFlashEraseSectorSize();

    ptVerProtectHead = BootGetProtectHeadFromFlash(ulProtectAddr);
    if (!ptVerProtectHead)
    {
        return BSP_ERROR;
    }

    if (BSP_OK != BootCopyRepairVerToFlash(1, data, dataSize, ptVerProtectHead))
    {
        free(ptVerProtectHead);
        return BSP_ERROR;
    }

    /* 每次刷新保护区头之前先擦出保护区头 */
    if (BSP_OK != BspFlashErase(ulProtectAddr, ulFlashSection))
    {
        dbgErr("Erease flash protect head failed!");
        free(ptVerProtectHead);
        return FALSE;
    }
    dbgInfo("copy done ,will flush protect head\n");
    /* 刷新完版本之后需要将版本信息及重新计算后的版本头CRC写到保护区头中 */
    dbgInfo("ulProtectHead : %x, ulCRC32 : 0x%x\n", ulProtectAddr, ptVerProtectHead->tVerInfoFileHead.ulCRC);
    if (BSP_OK != BspFlashWrite(ulProtectAddr, (UCHAR *)ptVerProtectHead, sizeof(T_VerProtectHead)))
    {
        dbgErr("write protect head flash error!");
        free(ptVerProtectHead);
        return FALSE;
    }
    free(ptVerProtectHead);
    dbgInfo("Flush Run Software to Flash succeed!\n");
    return BSP_OK;
}

static int writeRepairVerToFlash(unsigned char* versionAddr, unsigned int versionSize, version_info_t* info)
{
    int ret = 0;

    if (IN_FILESYSTEM == info->location)
    {
        printf("write to %s,pls waitting...\n",info->filePath);
        ret = BootWriteSwToFile(versionAddr, versionSize, info->tempFilePath);
        if(ret)
        {
            return ret;
        }
        ret = checkFilesystemVersion(info->tempFilePath);
        if(ret)
        {
            return ret;
        }
        ret = BspMoveFile(info->tempFilePath, info->filePath);
        if(ret)
        {
            return ret;
        }
    }
    else if (IN_PROTECTION == info->location)
    {
        printf("write to %s,pls waitting...\n",info->filePath);
        ret = flushRepairSwToProtect(versionAddr, versionSize);
        if(ret)
        {
            return ret;
        }
        ret = checkProtectVersion();
        if(ret)
        {
            return ret;
        }
    }
    else
    {
        printf("unknown location\n\n");
        return UNKNOWN_LOCATION;
    }

    return BSP_OK;
}

static int repairFlashVersion(unsigned char *versionAddr, unsigned int versionSize)
{
    //按ata、ata1、protect顺序尝试回写校验
    int i = 0;
    for(i = 0; i < sizeof(versionInfo)/sizeof(version_info_t); i++)
    {
        int repair_count = 0;
        
        while(repair_count < 3)
        {
            BootSetWatchDogTime(120);
            if(0 == writeRepairVerToFlash(versionAddr, versionSize, &versionInfo[i]))   //回写校验成功
            {
                printf("%s repair success\n",versionInfo[i].filePath);
                return 0;
            }
            repair_count++;
        }
    }
    printf("%s repair failed\n",versionInfo[i - 1].filePath);
    
    return -1;
}

int ldFileFromRepairVersion()
{   
    unsigned int versionSize = 0;
    unsigned char *versionAddr = NULL;
    unsigned int maxWindowLength = 512;

    g_ucRunVer = BSP_BAK_REPAIR_VERSION;
    BspSetCpuVerErrReason(g_ucRunVer, 0);
    
    if(-1 == (versionSize = getRepairVerSize()))
    {
        return -1;
    }

    printf("get repair verision size = %d.\n",versionSize);

    versionAddr = calloc(versionSize,sizeof(char));
    if(!versionAddr)
        return -1;

    if(0 == getRepairVersionWithSlideWindow(maxWindowLength, versionAddr, versionSize, versionInfo)) //拼凑出一个完整校验通过的cur.swv,修复成功
    {
        repairFlashVersion(versionAddr, versionSize);

        if(ldFileFromRam(versionAddr, versionSize))
        {
            printf("ldFileFromRam failed!\n");
            free(versionAddr);
            return -1;
        }
        else{
            free(versionAddr);
            return 0;
        }
    }

    free(versionAddr);
    return -1;
}
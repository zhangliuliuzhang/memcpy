#ifndef _REPAIRVERSION_H_
#define _REPAIRVERSION_H_

#define RTR_VX_REPAIR   "/ata/rru/cur_repair.swv"
#define RTR1_VX_REPAIR   "/ata1/rru/cur_repair.swv"
#define BSP_BAK_FSVERSION (0x07) /* 多文件系统ata1下版本 */
#define BSP_BAK_REPAIR_VERSION (0x08) /* 三模修复生成版本 */
#define IN_FILESYSTEM   0
#define IN_PROTECTION   1
#define UNKNOWN_LOCATION    -1

int ldFileFromRepairVersion();
#endif
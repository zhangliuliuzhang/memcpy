/**************************************************************************
* 版权所有 (C)2001, 深圳市中兴通讯股份有限公司
*
* 文件名称: M88E1322Api.c
* 文件标识:
* 内容摘要:
* 其它说明:
* 当前版本: V1.0
* 作    者: 罗乔发
* 完成日期:
*
* 修改记录1:
*    修改日期: 2010年04月09日
*    版 本 号: V1.0
*    修 改 人: 罗乔发
*    修改内容: 创建
* 修改记录2:
**************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "bsppub.h"
#include "bspcomm.h"
#include "phy.h"
#include "meenyi.h"
/* Started by AICoder, pid:gdfb7f3d4fh5d2214ae3093800a22e03cf415eec */
#include "mii.h"
/* Ended by AICoder, pid:gdfb7f3d4fh5d2214ae3093800a22e03cf415eec */
static FUNC_RESET_PHY pResetPhy = NULL;

#define BIT(n) (1 << (n))

UINT32 BspPhyCtrl(T_BSP_DEV_PARA *ptPara);

static UINT32 g_ulPhyType = 0;
static UINT32 g_aulLastPage[M88E1512_MAX_PORT];

UINT32 PhyRegWrite(UINT32 ulDevNum, UINT32 phyAddr, UINT32 ulReg, UINT32 ulVal)
{
    return BootSetMiiWrReg(phyAddr, ulReg, ulVal);
}

UINT32 PhyRegRead(UINT32 ulDevNum, UINT32 phyAddr, UINT32 ulReg, UINT32 *pulVal)
{
    return BootGetMiiWrReg(phyAddr, ulReg, pulVal);
}

static UINT32 M88E1512PageSelect(UINT32 ulDevNum, UINT32 ulPage)
{
    UINT32 ulRetVal = BSP_OK;

    if (g_aulLastPage[ulDevNum] != ulPage)
    {
        ulRetVal = PhyRegWrite(ulDevNum, PHY_ADDR, M88E1512_PAGE_REG, ulPage);
        if (BSP_OK == ulRetVal)
        {
            g_aulLastPage[ulDevNum] = ulPage;
        }
    }

    return ulRetVal;
}

static UINT32 M88E1512AnyRegWrite(UINT32 ulDevNum, UINT32 ulReg, UINT32 ulPage, UINT32 ulVal)
{
    UINT32 ulRetVal = BSP_OK;

    if (M88E1512_PAGE_REG != ulReg)
    {
        M88E1512PageSelect(ulDevNum, ulPage);
    }

    ulRetVal = PhyRegWrite(ulDevNum, PHY_ADDR, ulReg, ulVal);

    return ulRetVal;
}

static UINT32 M88E1512AnyRegRead(UINT32 ulDevNum, UINT32 ulReg, UINT32 ulPage, UINT32 *pulVal)
{
    UINT32 ulRetVal = BSP_OK;

    if (M88E1512_PAGE_REG != ulReg)
    {
        // zte_printf_s("M88E1512AnyRegRead ulPage=%d\n",ulPage);
        M88E1512PageSelect(ulDevNum, ulPage);
    }

    ulRetVal = PhyRegRead(ulDevNum, PHY_ADDR, ulReg, pulVal);

    return ulRetVal;
}

UINT32 BspPhyRegRead(UINT32 ulDevNum, UINT32 ulReg, UINT32 ulPage, UINT32 *pulVal)
{
    T_BSP_DEV_PARA tPara;
    UINT32 ulRetVal = BSP_OK;

    zte_memset_s((void *)&tPara, sizeof(tPara), 0, sizeof(tPara));

    tPara.aulAddr[0] = ulDevNum;
    tPara.aulAddr[1] = ulReg;
    tPara.aulAddr[2] = ulPage;
    tPara.ulCmd = BSP_Q_ETHPHY_REG_GET;
    ulRetVal = BspPhyCtrl(&tPara);
    *pulVal = tPara.aulAddr[3];
    return ulRetVal;
}

UINT32 BspPhyRegWrite(UINT32 ulDevNum, UINT32 ulReg, UINT32 ulPage, UINT32 ulVal)
{
    T_BSP_DEV_PARA tPara;
    UINT32 ulRetVal = BSP_OK;

    zte_memset_s((void *)&tPara, sizeof(tPara), 0, sizeof(tPara));

    tPara.aulAddr[0] = ulDevNum;
    tPara.aulAddr[1] = ulReg;
    tPara.aulAddr[2] = ulPage;
    tPara.aulAddr[3] = ulVal;
    tPara.ulCmd = BSP_Q_ETHPHY_REG_SET;
    ulRetVal = BspPhyCtrl(&tPara);
    return ulRetVal;
}

static UINT32 M88E1512CopperStatusGet(UINT32 ulDevNum, UINT32 *pulStat)
{
    UINT32 ulRetVal = BSP_OK;
    UINT32 ulReg = 17;
    UINT32 ulPage = 0;
    UINT32 ulVal = 0;

    *pulStat = 0;
    ulRetVal = M88E1512AnyRegRead(ulDevNum, ulReg, ulPage, &ulVal);
    if (BSP_OK != ulRetVal)
    {
        return ulRetVal;
    }

    // zte_printf_s("M88E1512CopperStatusGet ulVal = %d\n",ulVal);

    *pulStat = 0;
    switch (BIT_FIELD_RIGHT_JUST_GET(ulVal, 14, 2))
    {
        case 2:
        {
            *pulStat |= NET_STATE_SPEED1000;
            break;
        }

        case 1:
        {
            *pulStat |= NET_STATE_SPEED100;
            break;
        }

        case 0:
        {
           *pulStat |= NET_STATE_SPEED10;
            break;
        }

        default:
        {
            break;
        }
    }

    if (BIT_FIELD_RIGHT_JUST_GET(ulVal, 13, 1))
    {
        *pulStat |= NET_STATE_DUPLEX;
    }

    /* copper energe detect status 位在link down时响应有点迟钝得多
     * 插上网线后响应很及时(active), 但拔除网线(link down)后, 通常要几秒钟该位才会置位(sleep),
     */
    if (!BIT_FIELD_RIGHT_JUST_GET(ulVal, 4, 1))
    {
        *pulStat |= NET_STATE_COPPER_INSERT;
    }

    if (BIT_FIELD_RIGHT_JUST_GET(ulVal, 10, 1))
    {
        *pulStat |= NET_STATE_COPPER_LINKOK | NET_STATE_LINKOK;
    }

    return ulRetVal;
}

static UINT32 M88E1512FiberStatusGet(UINT32 ulDevNum, UINT32 *pulStat)
{
    UINT32 ulRetVal = BSP_OK;
    UINT32 ulReg = 17;
    UINT32 ulPage = 1;
    UINT32 ulVal = 0;
    UCHAR ucSpd = 0;

    ulRetVal = M88E1512AnyRegRead(ulDevNum, ulReg, ulPage, &ulVal);
    if (BSP_OK != ulRetVal)
    {
        return ulRetVal;
    }
    *pulStat = 0;
    ucSpd = BIT_FIELD_RIGHT_JUST_GET(ulVal, 14, 2);
    switch (ucSpd)
    {
        case 2:
        {
            *pulStat |= NET_STATE_SPEED1000;
            break;
        }

        case 1:
        {
            *pulStat |= NET_STATE_SPEED100;
            break;
        }

        case 0:
        {
            *pulStat |= NET_STATE_SPEED10;
            break;
        }

        default:
        {
            break;
        }
    }

    if (BIT_FIELD_RIGHT_JUST_GET(ulVal, 13, 1))
    {
        *pulStat |= NET_STATE_DUPLEX;
    }

    if (BIT_FIELD_RIGHT_JUST_GET(ulVal, 5, 1))
    {
        *pulStat |= NET_STATE_FIBER_INSERT;
    }

    if (BIT_FIELD_RIGHT_JUST_GET(ulVal, 10, 1))
    {
        /* 只要光口linkup 则判定为光纤已插入。*/
        *pulStat |= NET_STATE_FIBER_LINKOK | NET_STATE_LINKOK | NET_STATE_FIBER_INSERT;
    }
    return ulRetVal;
}

static UINT32 M88E1512StatusGet(UINT32 ulDevNum, UINT32 *pulStat, UINT32 ulMedia)
{
    UINT32 ulRetVal = BSP_ERROR;

    if (BSP_PHY_MEDIA_COPPER == ulMedia)
    {
        ulRetVal = M88E1512CopperStatusGet(ulDevNum, pulStat);
    }
    else /* if (BSP_PHY_MEDIA_FIBER == ulMedia) */
    {
        ulRetVal = M88E1512FiberStatusGet(ulDevNum, pulStat);
    }
    return ulRetVal;
}

static UINT32 RTL8211PageSelect(UINT32 ulDevNum, UINT32 ulPage)
{
    UINT32 ulRetVal = BSP_OK;

    if (g_aulLastPage[ulDevNum] != ulPage)
    {
        ulRetVal = PhyRegWrite(ulDevNum, PHY_ADDR, RTL8211_PAGE_REG, ulPage);
        if (BSP_OK == ulRetVal)
        {
            g_aulLastPage[ulDevNum] = ulPage;
        }
    }
    return ulRetVal;
}

static UINT32 RTL8211AnyRegWrite(UINT32 ulDevNum, UINT32 ulReg, UINT32 ulPage, UINT32 ulVal)
{
    UINT32 ulRetVal = BSP_OK;

    if (RTL8211_PAGE_REG != ulReg)
    {
        RTL8211PageSelect(ulDevNum, ulPage);
    }

    ulRetVal = PhyRegWrite(ulDevNum, PHY_ADDR, ulReg, ulVal);

    return ulRetVal;
}

static UINT32 RTL8211AnyRegRead(UINT32 ulDevNum, UINT32 ulReg, UINT32 ulPage, UINT32 *pulVal)
{
    UINT32 ulRetVal = BSP_OK;

    if (RTL8211_PAGE_REG != ulReg)
    {
        RTL8211PageSelect(ulDevNum, ulPage);
    }

    ulRetVal = PhyRegRead(ulDevNum, PHY_ADDR, ulReg, pulVal);

    return ulRetVal;
}

static UINT32 RTL8211CopperStatusGet(UINT32 ulDevNum, UINT32 *pulStat)
{
    UINT32 ulRetVal = BSP_ERROR;
    UINT32 ulReg = 1;
    UINT32 ulPage = 0;
    UINT32 ulVal = 0;

    ulRetVal = BspPhyRegRead(ulDevNum, ulReg, ulPage, &ulVal);
    if (BSP_OK != ulRetVal)
    {
        return ulRetVal;
    }

    *pulStat = 0;
    if (BIT_FIELD_RIGHT_JUST_GET(ulVal, 5, 1))
    {
        *pulStat |= NET_STATE_NORM;

        ulRetVal = BspPhyRegRead(ulDevNum, RTL8211_STATUS_REG, 0xa43, &ulVal);
        if (BSP_OK != ulRetVal)
        {
            return ulRetVal;
        }
        switch (BIT_FIELD_RIGHT_JUST_GET(ulVal, 4, 2))
        {
            case 2:
            {
                *pulStat |= NET_STATE_SPEED1000;
                break;
            }

            case 1:
            {
                *pulStat |= NET_STATE_SPEED100;
                break;
            }

            case 0:
            {
               *pulStat |= NET_STATE_SPEED10;
                break;
            }

            default:
            {
                break;
            }
        }

        if (BIT_FIELD_RIGHT_JUST_GET(ulVal, 3, 1))
        {
            *pulStat |= NET_STATE_DUPLEX;
        }

        if (BIT_FIELD_RIGHT_JUST_GET(ulVal, 2, 1))
        {
            *pulStat |= NET_STATE_LINKOK;
        }
    }
    return ulRetVal;
}

static UINT32 RTL8211StatusGet(UINT32 ulDevNum, UINT32 *pulStat, UINT32 ulMedia)
{
    UINT32 ulRetVal = BSP_ERROR;

    if (BSP_PHY_MEDIA_COPPER == ulMedia)
    {
        ulRetVal = RTL8211CopperStatusGet(ulDevNum, pulStat);
    }
    return ulRetVal;
}

UINT32 BspRTL8211ChipInit(UINT32 ulDevNum)
{
    UINT32 ulRegValue;

/* Started by AICoder, pid:e6594m7a49na25714a900814902cb900a709b672 */
#if defined (CONFIG_ZX211413) || defined (CONFIG_ZX211412)
    /*page 0, reg 9  copper采用自协商1000Mbps，设置page 0, reg 9*/
    BspPhyRegRead(ulDevNum, 9, 0, &ulRegValue);
    ulRegValue |= (1 << 9); /* 1000BASE-T Full-Duplex advertised*/
    BspPhyRegWrite(ulDevNum, 9, 0, ulRegValue);
    BspSysMsDelay_Sys(10);
#else
    /*page 0, reg 9  copper采用自协商非1000Mbps，设置page 0, reg 9*/
    BspPhyRegRead(ulDevNum, 9, 0, &ulRegValue);
    ulRegValue &= ~(1 << 9); /* 1000BASE-T Full-Duplex Not advertised*/
    BspPhyRegWrite(ulDevNum, 9, 0, ulRegValue);
    BspSysMsDelay_Sys(10);
#endif
/* Ended by AICoder, pid:e6594m7a49na25714a900814902cb900a709b672 */

    /*close sgmii auto-negotiation*/
    BspPhyRegWrite(ulDevNum, 27, 0xa43, 0xdc84);
    BspPhyRegWrite(ulDevNum, 28, 0xa43, 0x7180);
    BspSysMsDelay_Sys(10);
    BspPhyRegWrite(ulDevNum, 27, 0xa43, 0xdc84);
    BspPhyRegRead(ulDevNum, 28, 0xa43, &ulRegValue);
    if (BIT(8) != (ulRegValue & BIT(8)))
    {
        zte_printf_s("ulRegValue = 0x%x\n", ulRegValue);
        return BSP_ERROR;
    }

    BspPhyRegWrite(ulDevNum, 27, 0xa43, 0xdcfa);
    BspPhyRegRead(ulDevNum, 28, 0xa43, &ulRegValue);
    zte_printf_s("0xdcfa ulRegValue1 = 0x%x\n", ulRegValue);
    BspPhyRegWrite(ulDevNum, 27, 0xa43, 0xdcfa);
    BspPhyRegRead(ulDevNum, 28, 0xa43, &ulRegValue);
    zte_printf_s("0xdcfa ulRegValue2 = 0x%x\n", ulRegValue);
    BspPhyRegWrite(ulDevNum, 27, 0xa43, 0xdcfc);
    BspPhyRegRead(ulDevNum, 28, 0xa43, &ulRegValue);
    zte_printf_s("0xdcfc ulRegValue1 = 0x%x\n", ulRegValue);
    BspPhyRegWrite(ulDevNum, 27, 0xa43, 0xdcfc);
    BspPhyRegRead(ulDevNum, 28, 0xa43, &ulRegValue);
    zte_printf_s("0xdcfc ulRegValue2 = 0x%x\n", ulRegValue);
    BspSysMsDelay_Sys(10);

    #if defined(CONFIG_ZX211413)
    /*close all phy broadcast*/
    BspPhyRegRead(ulDevNum, 24, 0xa43, &ulRegValue);
    ulRegValue &= ~(RTL8211_PHYADDR0_ENABLE);
    BspPhyRegWrite(ulDevNum, 24, 0xa43, ulRegValue);
    #endif

    /*close EEE*/
    BspPhyRegWrite(ulDevNum, 17, 0xa4b, 0x1110);
    BspPhyRegWrite(ulDevNum, 13, 0, 0x7);
    BspPhyRegWrite(ulDevNum, 14, 0, 0x3c);
    BspPhyRegWrite(ulDevNum, 13, 0, 0x4007);
    BspPhyRegWrite(ulDevNum, 14, 0, 0x0);

    return BSP_OK;
}

UINT32 BspPhyCtrl(T_BSP_DEV_PARA *ptPara)
{
    UINT32 ulRetVal = BSP_ERROR;

    UINT32 ulDevNum = 0;
    UINT32 *pulArg1 = NULL;
    UINT32 *pulArg2 = NULL;
    UINT32 *pulArg3 = NULL;

    ulDevNum = ptPara->aulAddr[0];
    pulArg1 = &ptPara->aulAddr[1];
    pulArg2 = &ptPara->aulAddr[2];
    pulArg3 = &ptPara->aulAddr[3];

    switch (ptPara->ulCmd)
    {
        case BSP_Q_ETHPHY_REG_GET:
        {
            if (M88E1512_TYPE == g_ulPhyType)
            {
                ulRetVal = M88E1512AnyRegRead(ulDevNum, *pulArg1, *pulArg2, pulArg3); /*ok*/
            }
            else if (RTL8211_TYPE == g_ulPhyType)
            {
                ulRetVal = RTL8211AnyRegRead(ulDevNum, *pulArg1, *pulArg2, pulArg3); /*ok*/
            }
            else if (TST0101_TYPE == g_ulPhyType)
            {
                ulRetVal = TST0101AnyRegRead(ulDevNum, *pulArg1, pulArg3); /*ok*/
            }
            break;
        }

        case BSP_Q_ETHPHY_REG_SET:
        {
            if (M88E1512_TYPE == g_ulPhyType)
            {
                ulRetVal = M88E1512AnyRegWrite(ulDevNum, *pulArg1, *pulArg2, *pulArg3); /*ok*/
            }
            else if (RTL8211_TYPE == g_ulPhyType)
            {
                ulRetVal = RTL8211AnyRegWrite(ulDevNum, *pulArg1, *pulArg2, *pulArg3); /*ok*/
            }
            else if (TST0101_TYPE == g_ulPhyType)
            {
                ulRetVal = TST0101AnyRegWrite(ulDevNum, *pulArg1, *pulArg3); /*ok*/
            }
            break;
        }

        case BSP_Q_ETHPHY_STATUS_GET:
        {
            if (M88E1512_TYPE == g_ulPhyType)
            {
                ulRetVal = M88E1512StatusGet(ulDevNum, pulArg1, *pulArg2); /*ok*/
            }
            else if (RTL8211_TYPE == g_ulPhyType)
            {
                ulRetVal = RTL8211StatusGet(ulDevNum, pulArg1, *pulArg2); /*ok*/
            }
            else if (TST0101_TYPE == g_ulPhyType)
            {
                ulRetVal = TST0101StatusGet(ulDevNum, pulArg1, *pulArg2); /*ok*/
            }
            break;
        }

        default:
        {
            ulRetVal = BSP_ERROR;
            break;
        }
    }

    return ulRetVal;
}

UINT32 BspPhyWait(const T_PHY_SWITCH_WAIT *ptPhySwitchWait)
{
    UINT32 ulTemp = 0;
    UINT32 ulWaitTimes = 0;
    UINT32 bitMask;
    UINT32 val;
    UINT32 waitT;

    if (NULL == ptPhySwitchWait)
    {
        return BSP_ERROR;
    }

    bitMask = ptPhySwitchWait->ulBitMask;
    val = ptPhySwitchWait->ulExpectVal;
    waitT = ptPhySwitchWait->ulWaitTime;

    BspPhyRegRead(ptPhySwitchWait->ulDevNum, ptPhySwitchWait->ulReg, ptPhySwitchWait->ulPage, &ulTemp);
    ulTemp &= (1 << bitMask);

    while ((ulTemp != val) && (ulWaitTimes < waitT))
    {
        BspSysMsDelay_Sys(1);
        BspPhyRegRead(ptPhySwitchWait->ulDevNum, ptPhySwitchWait->ulReg, ptPhySwitchWait->ulPage, &ulTemp);
        ulTemp &= (1 << bitMask);
        ulWaitTimes++;
    }

    if ((ulTemp == val) && (ulWaitTimes <= waitT))
    {
        return BSP_OK;
    }
    else
    {
        zte_printf_s("PhyWait error\n");
        return BSP_ERROR;
    }
}

UINT32 BspM88e1512ChipInit(UINT32 ulDevNum)
{

    UINT32 ulRegValue;
    T_PHY_SWITCH_WAIT tPhySwitchWait;

    /*page 18, reg 20  SGMII to cooper */
    BspPhyRegRead(ulDevNum, 20, 18, &ulRegValue);
    ulRegValue &= ~(0x7); /* 工作模式配置 */
    ulRegValue |= M88E1512_SGMII_COPPER;
    BspPhyRegWrite(ulDevNum, 20, 18, ulRegValue);
    ulRegValue |= 0x8000;
    BspPhyRegWrite(ulDevNum, 20, 18, ulRegValue);

    /* 等待复位操作完成 */
    tPhySwitchWait.ulBitMask   = 15;
    tPhySwitchWait.ulExpectVal = 0;
    tPhySwitchWait.ulDevNum    = ulDevNum;
    tPhySwitchWait.ulPage      = 18;
    tPhySwitchWait.ulReg       = 20;
    tPhySwitchWait.ulWaitTime  = 1000; /* 1000us */
    BspPhyWait(&tPhySwitchWait);
/* Started by AICoder, pid:bda9cre1cdh349514f1009b2e08eab06c1e9319b */
#if defined (CONFIG_ZX211413) || defined (CONFIG_ZX211412)
    /*page 0, reg 0  copper采用自协商1000Mbps，设置page 0, reg 9*/
    BspPhyRegRead(ulDevNum, 9, 0, &ulRegValue);
    ulRegValue |= (1 << 8); /* 1000BASE-T Half-Duplex advertised*/
    ulRegValue |= (1 << 9); /* 1000BASE-T Full-Duplex advertised*/
    BspPhyRegWrite(ulDevNum, 9, 0, ulRegValue);
    /*Software reset*/
    BspPhyRegRead(ulDevNum, 0, 0, &ulRegValue);
    ulRegValue |= 0x8000;
    BspPhyRegWrite(ulDevNum, 0, 0, ulRegValue);

    /* 等待复位操作完成 */
    tPhySwitchWait.ulBitMask   = 15;
    tPhySwitchWait.ulExpectVal = 0;
    tPhySwitchWait.ulDevNum    = ulDevNum;
    tPhySwitchWait.ulPage      = 0;
    tPhySwitchWait.ulReg       = 0;
    tPhySwitchWait.ulWaitTime  = 1000; /* 1000us */
    BspPhyWait(&tPhySwitchWait);
#else
    /*page 0, reg 0  copper采用自协商非1000Mbps，设置page 0, reg 9*/
    BspPhyRegRead(ulDevNum, 9, 0, &ulRegValue);
    ulRegValue &= ~(1 << 8); /* 1000BASE-T Half-Duplex Not advertised*/
    ulRegValue &= ~(1 << 9); /* 1000BASE-T Full-Duplex Not advertised*/
    BspPhyRegWrite(ulDevNum, 9, 0, ulRegValue);
    /*Software reset*/
    BspPhyRegRead(ulDevNum, 0, 0, &ulRegValue);
    ulRegValue |= 0x8000;
    BspPhyRegWrite(ulDevNum, 0, 0, ulRegValue);

    /* 等待复位操作完成 */
    tPhySwitchWait.ulBitMask   = 15;
    tPhySwitchWait.ulExpectVal = 0;
    tPhySwitchWait.ulDevNum    = ulDevNum;
    tPhySwitchWait.ulPage      = 0;
    tPhySwitchWait.ulReg       = 0;
    tPhySwitchWait.ulWaitTime  = 1000; /* 1000us */
    BspPhyWait(&tPhySwitchWait);
#endif
/* Ended by AICoder, pid:bda9cre1cdh349514f1009b2e08eab06c1e9319b */

    /*page 1, reg 0  fiber to 1000G SGMII full duplex*/
    BspPhyRegRead(ulDevNum, 0, 1, &ulRegValue);
    ulRegValue &= ~(1 << 12); /* disable AN */
    ulRegValue &= ~(1 << 6);  /* 1000G */
    ulRegValue |= (1 << 6);
    ulRegValue &= ~(1 << 8); /* full duplex */
    ulRegValue |= (1 << 8);
    BspPhyRegWrite(ulDevNum, 0, 1, ulRegValue);
    ulRegValue |= 0x8000;
    BspPhyRegWrite(ulDevNum, 0, 1, ulRegValue);

    /* 等待复位操作完成 */
    tPhySwitchWait.ulBitMask   = 15;
    tPhySwitchWait.ulExpectVal = 0;
    tPhySwitchWait.ulDevNum    = ulDevNum;
    tPhySwitchWait.ulPage      = 1;
    tPhySwitchWait.ulReg       = 0;
    tPhySwitchWait.ulWaitTime  = 1000; /* 1000us */
    BspPhyWait(&tPhySwitchWait);
    return BSP_OK; /*需要具体配置*/
}

ULONG BspInitM88e1512Init(UINT32 phyAddr)
{
    UINT32 ret = BSP_OK;

    zte_memset_s((void *)&g_aulLastPage[0], sizeof(g_aulLastPage), (UCHAR)(M88E1512_PAGE_INVALID), sizeof(g_aulLastPage));

    /* C88E1322 configurations */
    ret = BspM88e1512ChipInit(0);
    if (BSP_OK != ret)
    {
        zte_printf_s("M88E1512 chip initialize failed\n");
        return ret;
    }

    return BSP_OK;
}

ULONG BspInitRTL8211Init(UINT32 phyAddr)
{
    UINT32 ret = BSP_OK;

    /* C88E1322 configurations */
    ret = BspRTL8211ChipInit(0);
    if (BSP_OK != ret)
    {
        zte_printf_s("RTL8211 chip initialize failed\n");
        return ret;
    }

    return BSP_OK;
}

ULONG BspInitTST0101Init(UINT32 phyAddr)
{
    UINT32 ret = BSP_OK;

    /* MEENYI configurations */
    ret = BspTST0101ChipInit(0);
    if (BSP_OK != ret)
    {
        zte_printf_s("TST0101 chip initialize failed\n");
        return ret;
    }

    return BSP_OK;
}

UINT32 BspResetPhyCallBackInit(FUNC_RESET_PHY pReset)
{
    pResetPhy = pReset;
    return BSP_OK;
}

UINT32 BspResetPhy()
{
    if (pResetPhy)
    {
        return pResetPhy();
    }

    return BSP_OK;
}

UINT32 BspCheckPhyId(UINT32 phyAddr)
{
    UINT32 ret = BSP_OK;
    UINT32 ouiMsb = 0;
    UINT32 ulReg2 = 0, ouiLsb = 0, modelNo = 0;

    ret = BootGetMiiWrReg(phyAddr, PHY_ID_REG1, &ouiMsb);
    if (BSP_OK != ret)
    {
        zte_printf_s("read phy id error\n");
        return BSP_ERROR;
    }

    ret = BootGetMiiWrReg(phyAddr, PHY_ID_REG2, &ulReg2);
    if (BSP_OK != ret)
    {
        zte_printf_s("read phy id error\n");
        return BSP_ERROR;
    }
    ouiLsb = BIT_FIELD_RIGHT_JUST_GET(ulReg2, 10, 6);
    modelNo = BIT_FIELD_RIGHT_JUST_GET(ulReg2, 4, 6);

    if (M88E1512_OUI_MSB == ouiMsb && M88E1512_OUI_LSB == ouiLsb && M88E1512_MODEL_NO == modelNo)
    {
        zte_printf_s("phy type M88E1512\n");
        g_ulPhyType = M88E1512_TYPE;
    }
    else if (RTL8211_OUI_MSB == ouiMsb && RTL8211_OUI_LSB == ouiLsb && RTL8211_MODEL_NO == modelNo)
    {
        zte_printf_s("phy type RTL8211\n");
        g_ulPhyType = RTL8211_TYPE;
    }
    else if (TST0101_OUI_MSB == ouiMsb && TST0101_OUI_LSB == ouiLsb && TST0101_MODEL_NO == modelNo)
    {
        zte_printf_s("phy type TST0101\n");
        g_ulPhyType = TST0101_TYPE;
    }
    else
    {
        zte_printf_s("phy type unknow\n");
        ret = BSP_ERROR;
    }

    return ret;
}

/*在uboot下phy已经初始化了，这里决策：是否还需要重新再初始化一次，还是不需要初始化*/
UINT32 BspInitPhy(UINT32 phyAddr)
{
    UINT32 ret = BSP_OK;
    UINT32 idx;

    BspResetPhy();
    BspSysMsDelay_Sys(200);
    for (idx = 0; idx < 3; idx++)
    {
        ret = BspCheckPhyId(phyAddr);
        if (BSP_OK == ret)
        {
            break;
        }
        zte_printf_s("IdCheck error times:%d\n", idx);
    }

    if (BSP_OK == ret)
    {
        if (M88E1512_TYPE == g_ulPhyType)
        {
            ret = BspInitM88e1512Init(phyAddr);
        }
        else if (RTL8211_TYPE == g_ulPhyType)
        {
            ret = BspInitRTL8211Init(phyAddr);
        }
        else if (TST0101_TYPE == g_ulPhyType)
        {
            ret = BspInitTST0101Init(phyAddr);
        }
    }

    if (3 <= idx)
    {
        return BSP_ERROR;
    }
    return ret;
}

UINT32 BspGetPhyStatus(UINT32 ulDevNum, UINT32 *pulStat, UINT32 ulMode)
{
    T_BSP_DEV_PARA tPara;
    UINT32 ulRetVal = BSP_OK;

    zte_memset_s((void *)&tPara, sizeof(tPara), 0, sizeof(tPara));

    tPara.aulAddr[0] = ulDevNum;
    tPara.aulAddr[2] = ulMode;
    tPara.ulCmd = BSP_Q_ETHPHY_STATUS_GET;
    ulRetVal = BspPhyCtrl(&tPara);
    *pulStat = tPara.aulAddr[1];
    return ulRetVal;
}

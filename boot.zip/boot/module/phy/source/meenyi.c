#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "bsppub.h"
#include "phy.h"
#include "meenyi.h"

extern UINT32 PhyRegWrite(UINT32 ulDevNum, UINT32 phyAddr, UINT32 ulReg, UINT32 ulVal);
extern UINT32 PhyRegRead(UINT32 ulDevNum, UINT32 phyAddr, UINT32 ulReg, UINT32 *pulVal);

#define BIT(nr) (1UL << (nr))

UINT32 TST0101AnyRegWrite(UINT32 ulDevNum, UINT32 ulReg, UINT32 ulVal)
{
    UINT32 ulRetVal = BSP_OK;

    if (0x37 < ulReg)
    {
        ulRetVal |= PhyRegWrite(ulDevNum, PHY_ADDR, 0x1e, ulReg);

        ulRetVal |= PhyRegWrite(ulDevNum, PHY_ADDR, 0x1f, ulVal);
    }
    else
    {
        ulRetVal |= PhyRegWrite(ulDevNum, PHY_ADDR, ulReg, ulVal);
    }

    return ulRetVal;
}

UINT32 TST0101AnyRegRead(UINT32 ulDevNum, UINT32 ulReg, UINT32 *pulVal)
{
    UINT32 ulRetVal = BSP_OK;

    if (0x37 < ulReg)
    {
        ulRetVal |= PhyRegWrite(ulDevNum, PHY_ADDR, 0x1e, ulReg);

        ulRetVal |= PhyRegRead(ulDevNum, PHY_ADDR, 0x1f, pulVal);
    }
    else
    {
        ulRetVal |= PhyRegRead(ulDevNum, PHY_ADDR, ulReg, pulVal);
    }

    return ulRetVal;
}

static UINT32 TST0101CopperStatusGet(UINT32 ulDevNum, UINT32 *pulStat)
{
    UINT32 ulRetVal = BSP_ERROR;
    UINT32 ulVal = 0;
    UCHAR count  = 0;

    /*switch to UTP mode*/
    ulRetVal = TST0101AnyRegWrite(ulDevNum, REG_SMI_SDS_PHY, 0x0);
    if (BSP_OK != ulRetVal)
    {
        return ulRetVal;
    }

    *pulStat = 0;

    while (count < 6)
    {
        ulRetVal = TST0101AnyRegRead(ulDevNum, MII_BSR, &ulVal);
        if (BSP_OK != ulRetVal)
        {
            return ulRetVal;
        }
        if (BIT_FIELD_RIGHT_JUST_GET(ulVal, 5, 1))
        {
            break;
        }
        count++;
    }
    if (6 == count)
    {
        /* Started by AICoder, pid:e09ca99d02m0cb71492d0884503c5319562281b9 */
        zte_printf_s("%s MII_BSR = 0x%x\n",__FUNCTION__, ulVal);
        ulRetVal = TST0101AnyRegRead(ulDevNum, MII_SSR, &ulVal);
        zte_printf_s("%s MII_SSR = 0x%x\n",__FUNCTION__, ulVal);
        /* Ended by AICoder, pid:e09ca99d02m0cb71492d0884503c5319562281b9 */
        return ulRetVal;
    }
    count = 0;
    while (count < 100)
    {
        ulRetVal = TST0101AnyRegRead(ulDevNum, MII_SSR, &ulVal);
        if (BSP_OK != ulRetVal)
        {
            return ulRetVal;
        }

        *pulStat = 0;
        switch (BIT_FIELD_RIGHT_JUST_GET(ulVal, 14, 2))
        {
            case 2:
            {
                *pulStat |= NET_STATE_SPEED1000;
                break;
            }

            case 1:
            {
                *pulStat |= NET_STATE_SPEED100;
                break;
            }

            case 0:
            {
                *pulStat |= NET_STATE_SPEED10;
                break;
            }

            default:
            {
                break;
            }
        }

        if (BIT_FIELD_RIGHT_JUST_GET(ulVal, 13, 1))
        {
            *pulStat |= NET_STATE_DUPLEX;
        }

        /* copper energe detect status 位在link down时响应有点迟钝得多
        * 插上网线后响应很及时(active), 但拔除网线(link down)后, 通常要几秒钟该位才会置位(sleep),
        */
        if (!BIT_FIELD_RIGHT_JUST_GET(ulVal, 4, 1))
        {
            *pulStat |= NET_STATE_COPPER_INSERT;
        }

        if (BIT_FIELD_RIGHT_JUST_GET(ulVal, 10, 1))
        {
            *pulStat |= NET_STATE_COPPER_LINKOK | NET_STATE_LINKOK;
            break;
        }
        count++;
    }

    return ulRetVal;
}

static UINT32 TST0101FiberStatusGet(UINT32 ulDevNum, UINT32 *pulStat)
{
    UINT32 ulRetVal = BSP_OK;
    UINT32 ulVal = 0;
    UCHAR ucSpd = 0;

    /*switch to SDS mode*/
    ulRetVal = TST0101AnyRegWrite(ulDevNum, REG_SMI_SDS_PHY, 0x2);
    if (BSP_OK != ulRetVal)
    {
        return ulRetVal;
    }

    ulRetVal = TST0101AnyRegRead(ulDevNum, MII_SSR, &ulVal);
    if (BSP_OK != ulRetVal)
    {
        return ulRetVal;
    }
    *pulStat = 0;
    ucSpd = BIT_FIELD_RIGHT_JUST_GET(ulVal, 14, 2);
    switch (ucSpd)
    {
        case 2:
        {
            *pulStat |= NET_STATE_SPEED1000;
            break;
        }

        case 1:
        {
            *pulStat |= NET_STATE_SPEED100;
            break;
        }

        case 0:
        {
            *pulStat |= NET_STATE_SPEED10;
            break;
        }

        default:
        {
            break;
        }
    }

    if (BIT_FIELD_RIGHT_JUST_GET(ulVal, 13, 1))
    {
        *pulStat |= NET_STATE_DUPLEX;
    }

    if (BIT_FIELD_RIGHT_JUST_GET(ulVal, 5, 1))
    {
        *pulStat |= NET_STATE_FIBER_INSERT;
    }

    if (BIT_FIELD_RIGHT_JUST_GET(ulVal, 10, 1))
    {
        /* 只要光口linkup 则判定为光纤已插入。*/
        *pulStat |= NET_STATE_FIBER_LINKOK | NET_STATE_LINKOK | NET_STATE_FIBER_INSERT;
    }
    return ulRetVal;
}

UINT32 TST0101StatusGet(UINT32 ulDevNum, UINT32 *pulStat, UINT32 ulMedia)
{
    UINT32 ulRetVal = BSP_ERROR;

    if (BSP_PHY_MEDIA_COPPER == ulMedia)
    {
        ulRetVal = TST0101CopperStatusGet(ulDevNum, pulStat);
    }
    else /* if (BSP_PHY_MEDIA_FIBER == ulMedia) */
    {
        ulRetVal = TST0101FiberStatusGet(ulDevNum, pulStat);
    }
    return ulRetVal;
}

UINT32 TSTPhyWriteExt(UINT32 ulDevNum, UINT32 regnum, UINT32 val)
{
    UINT32 ret;

    ret = TST0101AnyRegWrite(ulDevNum, REG_DEBUG_ADDR_OFFSET, regnum);
    if (BSP_OK != ret)
    {
        return ret;
    }
    ret = TST0101AnyRegWrite(ulDevNum, REG_DEBUG_DATA, val);

    return ret;
}

UINT32 TSTPhyReadExt(UINT32 ulDevNum, UINT32 regnum, UINT32 *ulRegValue)
{
    UINT32 ret;
    UINT32 val;

    ret = TST0101AnyRegWrite(ulDevNum, REG_DEBUG_ADDR_OFFSET, regnum);
    if (BSP_OK != ret)
    {
        return ret;
    }
    val = TST0101AnyRegRead(ulDevNum, REG_DEBUG_DATA, ulRegValue);

    return val;
}

UINT32 TST0101CustomizeConfig(UINT32 ulDevNum)
{
    UINT32 ulRegValue;
    UINT32 ret = 0;

    /*Manufacturer's Suggestion*/
    TST0101AnyRegRead(ulDevNum, TSTPHY_UTP_AN_ADVERTISEMENT_REG, &ulRegValue);
    ulRegValue &= ~(PAUSE | ASYMMETRIC_PAUSE | EXTENDED_NEXT_PAGE);
    ret = TST0101AnyRegWrite(ulDevNum, TSTPHY_UTP_AN_ADVERTISEMENT_REG, ulRegValue);
    if (BSP_OK != ret)
    {
        return ret;
    }
    /*Switch to phy UTP page*/
    ret = TSTPhyWriteExt(ulDevNum, REG_SMI_SDS_PHY, 0);
    if (BSP_OK != ret)
    {
        return ret;
    }
    /*phy should give reference clock to ls1043a*/
    /*enable SyncE clock output and always output SyncE clock even when link is down*/
    TSTPhyReadExt(ulDevNum, TSTPHY_SYNCE_CFG_REG, &ulRegValue);
    ulRegValue |= (EN_SYNC_E_DURING_LNKDN | EN_SYNC_E);
    ret = TSTPhyWriteExt(ulDevNum, TSTPHY_SYNCE_CFG_REG, ulRegValue);
    if (BSP_OK != ret)
    {
        return ret;
    }
    /*PHY_INTERFACE_MODE_SGMII*/
    ret = TSTPhyWriteExt(ulDevNum, REG_SMI_SDS_PHY, 0x2);
    if (BSP_OK != ret)
    {
        return ret;
    }
    TST0101AnyRegRead(ulDevNum, REG_BASIC_CONTROL, &ulRegValue);
    /*close SDS auto-negotiation*/
    ulRegValue &= ~(AUTONEG_EN);
    /*set SDS in fixed 1000M*/
    ulRegValue &= ~(SPEED_LSB);
    ulRegValue |= SPEED_MSB;
    ulRegValue |= RESET;
    ret = TST0101AnyRegWrite(ulDevNum, REG_BASIC_CONTROL, ulRegValue);
    if (BSP_OK != ret)
    {
        return ret;
    }
    ret = TSTPhyWriteExt(ulDevNum, REG_SMI_SDS_PHY, 0X0);
    if (BSP_OK != ret)
    {
        return ret;
    }

    #if defined(CONFIG_ZX211413)
    /*close all phy broadcast*/
    TSTPhyReadExt(ulDevNum,TSTPHY_MDIO_CFG_REG,&ulRegValue);
    ulRegValue &= ~(PHYADDR_ENABLE);
    ret = TSTPhyWriteExt(ulDevNum, TSTPHY_MDIO_CFG_REG, ulRegValue);
    if (BSP_OK != ret)
    {
        return ret;
    }
    #endif

    return ret;
}

UINT32 BspTST0101ChipInit(UINT32 ulDevNum)
{
    UINT32 ulRegValue;
    UINT32 ret = BSP_ERROR;

    ret = TSTPhyWriteExt(ulDevNum, REG_SMI_SDS_PHY, 0);
    if (BSP_OK != ret)
    {
        return ret;
    }
    /*2ns delay & 1.8V & UTP_TO_SGMII*/
    ret = TSTPhyWriteExt(ulDevNum, TSTPHY_CHIP_CONFIG, 0x8163);
    if (BSP_OK != ret)
    {
        return ret;
    }
    /*page 0, reg 0x00  copper采用自协商，设置page 0, reg 0x00*/
    TST0101AnyRegRead(ulDevNum, MII_BMCR, &ulRegValue);
    ulRegValue |= (1 << 12);
    TST0101AnyRegWrite(ulDevNum, MII_BMCR, ulRegValue);
    BspSysMsDelay_Sys(10);

/* Started by AICoder, pid:m0f48u294ei6d8914e8b090450ecf30173d350a5 */
#if !defined(CONFIG_ZX211413) && !defined(CONFIG_ZX211412)
    /*page 0, reg 0x09  关闭千M自协商, 作为百M phy使用, 设置page 0, reg 0x09*/
    TST0101AnyRegRead(ulDevNum, MATER_SLAVE_CTRL_REG, &ulRegValue);
    ulRegValue &= ~(TST_1000BASE_T_FULL_REG);
    ret = TST0101AnyRegWrite(ulDevNum, MATER_SLAVE_CTRL_REG, ulRegValue);
    if (BSP_OK != ret)
    {
        return ret;
    }

    TST0101AnyRegRead(ulDevNum, REG_BASIC_CONTROL, &ulRegValue);
    ulRegValue |= RESET;
    ret = TST0101AnyRegWrite(ulDevNum, REG_BASIC_CONTROL, ulRegValue);
    if (BSP_OK != ret)
    {
        return ret;
    }
#endif
/* Ended by AICoder, pid:m0f48u294ei6d8914e8b090450ecf30173d350a5 */
    /* disable auto sleep */
    TSTPhyReadExt(ulDevNum, TST0101_EXTREG_SLEEP_CONTROL1, &ulRegValue);

    ulRegValue &= (~BIT(TST0101_EN_SLEEP_SW_BIT));

    ret = TSTPhyWriteExt(ulDevNum, TST0101_EXTREG_SLEEP_CONTROL1, ulRegValue);
    if (BSP_OK != ret)
    {
        return ret;
    }
    /* enable RXC clock when no wire plug */
    ret = TSTPhyWriteExt(ulDevNum, REG_SMI_SDS_PHY, 0);
    if (BSP_OK != ret)
    {
        return ret;
    }
    TSTPhyReadExt(ulDevNum, 0xc, &ulRegValue);
    ulRegValue &= ~(1 << 12);
    ret = TSTPhyWriteExt(ulDevNum, 0xc, ulRegValue);
    if (BSP_OK != ret)
    {
        return ret;
    }
    TST0101CustomizeConfig(ulDevNum);

    zte_printf_s("tst0101_config_init, 8521 init call out.\n");

    return BSP_OK;
}
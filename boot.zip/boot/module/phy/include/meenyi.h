#ifndef _MEENYI_H_
#define _MEENYI_H_

extern UINT32 TST0101AnyRegWrite(UINT32 ulDevNum, UINT32 ulReg, UINT32 ulVal);
extern UINT32 TST0101AnyRegRead(UINT32 ulDevNum, UINT32 ulReg, UINT32 *pulVal);
extern UINT32 TST0101StatusGet(UINT32 ulDevNum, UINT32 *pulStat, UINT32 ulMedia);
extern UINT32 TST0101IdCheck(UINT32 ulDevNum);
extern UINT32 BspTST0101ChipInit(UINT32 ulDevNum);

#define MII_BMCR		0x00	/* Basic mode control register */
#define TST0101_TYPE            101
#define TST0101_OUI_MSB        0x0
#define TST0101_OUI_LSB        0x0
#define TST0101_MODEL_NO       0x11
/* ((TST0101_OUI_MSB << 6) | (TST0101_OUI_LSB)) */
#define TST0101_OUI            0x0
#define REG_BASIC_CONTROL       0x0
#define RESET               BIT(15)
#define AUTONEG_EN          BIT(12)
#define SPEED_LSB           BIT(13)
#define AUTONEG_EN          BIT(12)
#define SPEED_MSB           BIT(6)
#define PHYADDR_ENABLE      BIT(6)

#define MII_BSR                 0x01   /*basic status register*/

#define MATER_SLAVE_CTRL_REG    0x09
#define TST_1000BASE_T_FULL_REG BIT(9)

#define MII_SSR                 0x11   /*specific status register*/

#define MDIO_DEVAD_NONE			(-1)
#define REG_DEBUG_ADDR_OFFSET   0x1e
#define REG_DEBUG_DATA			0x1f
#define REG_SMI_SDS_PHY         0xa000
#define TSTPHY_CHIP_CONFIG      0xa001
#define TST0101_EXTREG_SLEEP_CONTROL1	0x27
#define TST0101_EN_SLEEP_SW_BIT		15

#define TSTPHY_UTP_AN_ADVERTISEMENT_REG 0x4
#define PAUSE   BIT(10)
#define ASYMMETRIC_PAUSE   BIT(11)
#define EXTENDED_NEXT_PAGE   BIT(12)

#define TSTPHY_SYNCE_CFG_REG    0xa012
#define TSTPHY_MDIO_CFG_REG     0xa005
#define EN_SYNC_E_DURING_LNKDN  BIT(4)
#define EN_SYNC_E   BIT(5)

#endif
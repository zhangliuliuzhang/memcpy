/*---------------------------------------------------------------------------------------------------------------------
 * 版权所有(C)2000-2011, 中兴通讯股份有限公司 
 * 
 * 文 件 名: uart.h  
 * 
 * 作    者: 10010370
 * 
 * 接口描述:
 *     Bootrom软件uart接口处理
 * 
 * 版    本: v1.0
 * 
 * ------------------------------------------------------------------------------------------------------------------ 
 * 
 *     修改日期         修改人            修改内容
 *     20111103         10010370          创建
 *     
 *-------------------------------------------------------------------------------------------------------------------*/

#ifndef _PHY_H_
#define _PHY_H_

typedef unsigned char UCHAR;

#define BSP_Q_ETHPHY_REG_GET 0                               
#define BSP_Q_ETHPHY_REG_SET 1                               
#define BSP_Q_ETHPHY_STATUS_GET 2                               
#define BSP_Q_ETHPHY_MEDIA_LNKMD_GET 3                               
#define BSP_Q_ETHPHY_MEDIA_LNKMD_SET 4                               
#define BSP_Q_ETHPHY_MEDIA_PRFR_GET 5                               
#define BSP_Q_ETHPHY_MEDIA_PRFR_SET 6                               
#define BSP_Q_ETHPHY_MEDIA_PKT_RX_INIT 7                             
#define BSP_Q_ETHPHY_MEDIA_PKT_TX_INIT 8                             
#define BSP_Q_ETHPHY_MEDIA_PKT_RX 9                               
#define BSP_Q_ETHPHY_MEDIA_PKT_TX 10                               
#define BSP_Q_ETHPHY_CLK_MD_GET 11                               
#define BSP_Q_ETHPHY_CLK_MD_SET 12                               
#define BSP_Q_ETHPHY_LOOPBACK_MD_GET 13                              
#define BSP_Q_ETHPHY_LOOPBACK_MD_SET 14                              
#define BSP_Q_SYNCE_MODE_GET 15                               
#define BSP_Q_SYNCE_MODE_SET 16                               
#define BSP_Q_ETHPHY_ID_CHECK 17                               
#define BSP_Q_ETHPHY_REFCLK_GET 18                               
#define BSP_Q_ETHPHY_REFCLK_SET 19                               
#define BSP_Q_ETHPHY_RCVCRCLK_GET 20                               
#define BSP_Q_ETHPHY_RCVCRCLK_SET 21                               
#define BSP_Q_ETHPHY_LED_MOD_SET 22                               
#define BSP_Q_ETHPHY_UNIDIRTRANS_EN 23                               
#define BSP_Q_1000BASET_MS_MODE_GET 24

#define PHY_ADDR     (0)
#define BIT_FIELD_RIGHT_JUST_GET(val, bitoff, bitfieldlen) \
(((val) >> (bitoff)) & ((0x01 << (bitfieldlen)) - 1))

#define M88E1512_TYPE           1512
#define M88E1512_PAGE_REG       22
#define M88E1512_PAGE_NO_MAX    0XFF
#define M88E1512_PAGE_INVALID   0XFFFF

#define M88E1512_OUI_MSB        0x0141
#define M88E1512_OUI_LSB        0x0003
#define M88E1512_MODEL_NO       0x1d
/* ((M88E1512_OUI_MSB << 6) | (M88E1512_OUI_LSB)) */
#define M88E1512_OUI            0x5043

#define M88E1512_MAX_CHIP       1
#define M88E1512_PORTS_PER_CHIP 4
#define M88E1512_MAX_PORT       (M88E1512_MAX_CHIP * M88E1512_PORTS_PER_CHIP)

#define RTL8211_TYPE           8211
#define RTL8211_PAGE_REG       31
#define RTL8211_MODEL_NO       0x11
#define RTL8211_PAGE_INVALID   0XFFFF
#define RTL8211_OUI_MSB        0x001c
#define RTL8211_OUI_LSB        0x0032
#define RTL8211_STATUS_REG     26
#define RTL8211_PHYADDR0_ENABLE BIT(13)

#define M88E1111_MODEL_NO       0x0c
/* 88E1111 Extended PHY Specific Status Register */
#define MIIM_88E1111_PHY_EXT_SR		0x1b
#define MIIM_88E1111_HWCFG_MODE_MASK		0xf
#define MIIM_88E1111_HWCFG_MODE_COPPER_RGMII	0xb
#define MIIM_88E1111_HWCFG_MODE_FIBER_RGMII	0x3
#define MIIM_88E1111_HWCFG_MODE_SGMII_NO_CLK	0x4
#define MIIM_88E1111_HWCFG_MODE_COPPER_RTBI	0x9
#define MIIM_88E1111_HWCFG_FIBER_COPPER_AUTO	0x8000
#define MIIM_88E1111_HWCFG_FIBER_COPPER_RES	0x2000
#define MIIM_88E1111_1000BASE_HALF_DUPLEX    (1 << 8)
#define MIIM_88E1111_1000BASE_FULL_DUPLEX    (1 << 9)
#define MIIM_88E1111_POWER_DOWN    (1 << 11)
#define MIIM_88E1111_AUTO_NEGOTIATION    (1 << 12)
#define MIIM_88E1111_SPEED_SELECTION_MSB    (1 << 6)
#define MIIM_88E1111_SPEED_SELECTION_LSB    (1 << 13)
#define MIIM_88E1111_COPPER_DUPLEX_MODE    (1 << 8)
#define MIIM_88E1111_RESET    (1 << 15)
#define MIIM_88E1111_ASYMMETRIC_PAUSE    (1 << 11)
#define MIIM_88E1111_PAUSE    (1 << 10)
#define MIIM_88E1111_100BASE_TX_FULL_DUPLEX    (1 << 8)
#define MIIM_88E1111_100BASE_TX_HALF_DUPLEX    (1 << 7)
#define MIIM_88E1111_10BASE_TX_FULL_DUPLEX    (1 << 6)
#define MIIM_88E1111_10BASE_TX_HALF_DUPLEX    (1 << 5)
#define MIIM_88E1111_AUTO_NEGOTIATION_MODE_MASK		(0xf<<5)

#define M88E1111 1111

#define MIIM_88E1111_HWCFG_FIBER_COPPER_RES	0x2000

#define MIIM_88E1111_COPPER		0
#define MIIM_88E1111_FIBER		1

#define PHY_LINK_UP    0
#define PHY_LINK_DOWN    1

/* 88E1118 PHY defines */
#define MIIM_88E1118_PHY_PAGE		22
#define MIIM_88E1118_1000BASE_CTRL		9
#define MIIM_88E1118_AUTO_CTRL		4
#define MIIM_88E1118_CTRL		0
#define MIIM_88E1118_SR		17

#define PHY_ID_REG1           2
#define PHY_ID_REG2           3
#define NET_STATE_SPEED_MASK 0xffff
#define NET_STATE_NORM      0x1
#define NET_STATE_SPEED1000 0x2
#define NET_STATE_SPEED100  0x4
#define NET_STATE_SPEED10   0x8
#define NET_STATE_DUPLEX    0x10
#define NET_STATE_COPPER_INSERT 0x20
#define NET_STATE_COPPER_LINKOK 0x40
#define NET_STATE_LINKOK        0x80
#define NET_STATE_FIBER_INSERT  0x100
#define NET_STATE_FIBER_LINKOK  0x200

#define BSP_PHY_MEDIA_COPPER 0
#define BSP_PHY_MEDIA_FIBER 1

#define M88E1512_RGMII_COPPER      0
#define M88E1512_SGMII_COPPER      1
#define M88E1512_RGMII_1000BASEX   2
#define M88E1512_RGMII_1000BASEFX  3
#define M88E1512_RGMII_SGMII       4
#define M88E1512_RGMII_AMD_1       6   /*RGMII (System mode) to Auto Media Detect Copper/SGMII (Media mode)*/
#define M88E1512_RGMII_AMD_2       7   /*RGMII (System mode) to Auto Media Detect Copper/1000BASE-X/100BASE-FX*/

#define M88E1512_PACKET_ON_COPPER     2
#define M88E1512_PACKET_ON_SGMII      4
#define M88E1512_PACKET_ON_RGMII      6

typedef struct
{
    UINT32 ulDevNum;      /* 端口号 */
    UINT32 ulReg;         /* 寄存器地址 */
    UINT32 ulBitMask;     /* 待察看的寄存器对应的BIT位*/
    UINT32 ulPage;        /* PAGE */
    UINT32 ulExpectVal;   /* 期待值 */
    UINT32 ulWaitTime;    /* 等待时间 us*/
    UINT32 ulRsv[4];
}T_PHY_SWITCH_WAIT;

typedef ULONG (*FUNC_RESET_PHY)();

UINT32 BspInitPhy(UINT32 phyAddr);
UINT32 BspResetPhyCallBackInit(FUNC_RESET_PHY pReset);
/* Started by AICoder, pid:cab72vad7dp264b14b6e091440e6f206fa61ae90 */
extern VOID BspSysMsDelay_Sys(UINT32 ulDelay);
/* Ended by AICoder, pid:cab72vad7dp264b14b6e091440e6f206fa61ae90 */
#endif  /* _UART_H_ */

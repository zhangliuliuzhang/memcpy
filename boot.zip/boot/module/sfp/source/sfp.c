/**************************************************************************
* 版权所有 (C)2001, 深圳市中兴通讯股份有限公司
*
* 文件名称: Sfp.c
* 文件标识:
* 内容摘要: sfp phy芯片驱动
* 其它说明:
* 当前版本:B121N2
* 作    者: 耿佳佳
* 完成日期:
*
* 修改记录1:
*    修改日期: 2021年12月16日
*    版 本 号: B121N2
*    修 改 人: 耿佳佳
*    修改内容: 创建
* 修改记录2:
**************************************************************************/
#include "bsperrcode.h"
#include "bsp.h"
#include "bsppub.h"
#include "sfp.h"
#include "phy.h"

#include <errno.h>
#include <stddef.h>
#include <sys/ioctl.h>
#include <linux/types.h>

#ifndef I2C_USED_IN_KERNEL
#include "i2cbusapi.h"
#else
#include <linux/i2c.h>
#include <linux/i2c-dev.h>
#endif



#define MISSING_FUNC_FMT "Error: Adapter does not have %s capability\n"

/**************************************************************************
 *                        常量                                            *
 **************************************************************************/


/**************************************************************************
 *                        宏                                              *
 **************************************************************************/
#define SFP_DEV_INDEX_CHECK(index)          \
{                                           \
    if ((index) >= SFP_NUM_DEV)             \
    {                                       \
        return BSP_ERROR_INVALID_PARA;      \
    }                                       \
}


#define SFP_DEV_REG_CHECK(reg)              \
{                                           \
    if ((reg) > SFP_REG_CONF)               \
    {                                       \
        return BSP_ERROR_INVALID_PARA;      \
    }                                       \
}

#ifndef I2C_USED_IN_KERNEL
#define SFP_DEV_CRITICAL_ENTER(ii)              \
{                                               \
    SEM_ID ptSem = g_astSfp[ii].ptSemWrRd;      \
    if (ptSem != NULL)                          \
    {                                           \
        semTake(ptSem, WAIT_FOREVER);           \
    }                                           \
    else                                        \
    {                                           \
        return BSP_ERROR_NULL_POINTER;          \
    }                                           \
}

#define SFP_DEV_CRITICAL_EXIT(ii)               \
{                                               \
    SEM_ID ptSem = g_astSfp[ii].ptSemWrRd;      \
    if (ptSem != NULL)                          \
    {                                           \
        semGive(ptSem);                         \
    }                                           \
    else                                        \
    {                                           \
        return BSP_ERROR_NULL_POINTER;          \
    }                                           \
}
#endif
#define BIT_FIELD_RIGHT_JUST_GET(val, bitoff, bitfieldlen) \
(((val) >> (bitoff)) & ((0x01 << (bitfieldlen)) - 1))

/**************************************************************************
 *                         数据类型                                       *
 **************************************************************************/


/**************************************************************************
 *                         全局变量定义                                   *
 **************************************************************************/
#ifndef I2C_USED_IN_KERNEL
static T_SfpDev g_astSfp[SFP_NUM_DEV];
#endif
static UINT32 g_ulPhyType = 0;


/**************************************************************************
 *                         外部变量声明                                   *
 **************************************************************************/


/**************************************************************************
 *                         外部函数声明                                   *
 **************************************************************************/


/**************************************************************************
 *                         局部函数声明                                   *
 **************************************************************************/

#ifdef I2C_USED_IN_KERNEL
int open_i2c_dev(int i2cbus, char *filename, size_t size, int quiet)
{
    int file;

    zte_snprintf_s(filename, size, "/dev/i2c/%d", i2cbus);
    filename[size - 1] = '\0';
    file = open(filename, O_RDWR);

    if (file < 0 && (errno == ENOENT || errno == ENOTDIR))
    {
        zte_snprintf_s(filename, size,"/dev/i2c-%d", i2cbus);
        file = open(filename, O_RDWR);
    }

    if (file < 0 && !quiet)
    {
        if (errno == ENOENT)
        {
            FPRINTF(1, stderr, "Error: Could not open file "
                "`/dev/i2c-%d' or `/dev/i2c/%d': %s\n",
                i2cbus, i2cbus, zte_strerror_s(ENOENT));
        }
        else
        {
            FPRINTF(1, stderr, "Error: Could not open file "
                "`%s': %s\n", filename, zte_strerror_s(errno));
            if (errno == EACCES)
            {
                FPRINTF(1, stderr, "Run as root?\n");
            }
        }
    }

    return file;
}

static int check_funcs(int file, int size)
{
    unsigned long funcs;

    /* check adapter functionality */
    if (ioctl(file, I2C_FUNCS, &funcs) < 0)
    {
        FPRINTF(1, stderr, "Error: Could not get the adapter "
            "functionality matrix: %s\n", zte_strerror_s(errno));
        return -1;
    }

    switch (size)
    {
        case I2C_SMBUS_BYTE_DATA:
        {
            if (!(funcs & I2C_FUNC_SMBUS_READ_BYTE_DATA))
            {
                FPRINTF(1, stderr, MISSING_FUNC_FMT, "SMBus read byte");
                return -1;
            }
            if (!(funcs & I2C_FUNC_SMBUS_WRITE_BYTE_DATA))
            {
                FPRINTF(1, stderr, MISSING_FUNC_FMT, "SMBus write byte");
                return -1;
            }
            break;
        }

        case I2C_SMBUS_WORD_DATA:
        {
            if (!(funcs & I2C_FUNC_SMBUS_READ_WORD_DATA))
            {
                FPRINTF(1, stderr, MISSING_FUNC_FMT, "SMBus read word");
                return -1;
            }

            if (!(funcs & I2C_FUNC_SMBUS_WRITE_WORD_DATA))
            {
                FPRINTF(1, stderr, MISSING_FUNC_FMT, "SMBus write word");
                return -1;
            }
            break;
        }
        /* Started by AICoder, pid:s603f02521kf48614d670bcdf04af14cefa0c529 */
        default:
        {
            FPRINTF(1, stderr, "Unsupported data size\n");
            return -1;
        }
        /* Ended by AICoder, pid:s603f02521kf48614d670bcdf04af14cefa0c529 */
    }

    return 0;
}

int set_slave_addr(int file, int address, int force)
{
    /* With force, let the user read from/write to the registers
       even when a driver is also running */
    if (ioctl(file, force ? I2C_SLAVE_FORCE : I2C_SLAVE, address) < 0)
    {
        FPRINTF(1, stderr,
            "Error: Could not set address to 0x%02x: %s\n",
            address, zte_strerror_s(errno));
        return -errno;
    }

    return 0;
}

int i2c_smbus_access(int file, char read_write, __u8 command,
                int size, union i2c_smbus_data *data)
{
    struct i2c_smbus_ioctl_data args;
    int err;

    args.read_write = read_write;
    args.command = command;
    args.size = size;
    args.data = data;

    err = ioctl(file, I2C_SMBUS, &args);
    if (err == -1)
    {
        err = -errno;
    }
    return err;
}

int i2c_smbus_read_byte_data(int file, __u8 command)
{
    union i2c_smbus_data data;
    int err;

    err = i2c_smbus_access(file, I2C_SMBUS_READ, command,
                    I2C_SMBUS_BYTE_DATA, &data);
    if (err < 0)
    {
        return err;
    }
    return 0x0FF & data.byte;
}

int i2c_smbus_write_byte_data(int file, __u8 command, __u8 value)
{
    union i2c_smbus_data data;
    data.byte = value;
    return i2c_smbus_access(file, I2C_SMBUS_WRITE, command,
                            I2C_SMBUS_BYTE_DATA, &data);
}

int i2c_smbus_read_word_data(int file, __u8 command)
{
    union i2c_smbus_data data;
    int err;

    err = i2c_smbus_access(file, I2C_SMBUS_READ, command,
                           I2C_SMBUS_WORD_DATA, &data);
    if (err < 0)
    {
        return err;
    }
    return 0x0FFFF & data.word;
}

int i2c_smbus_write_word_data(int file, __u8 command, __u16 value)
{
    union i2c_smbus_data data;
    data.word = value;
    return i2c_smbus_access(file, I2C_SMBUS_WRITE, command,
                            I2C_SMBUS_WORD_DATA, &data);
}

int i2c_get(int i2cbus,int address, int daddress, int size)
{
    char filename[20];
    int res, file;
    int force = 0;

    file = open_i2c_dev(i2cbus, filename, sizeof(filename), 0);
    if (file < 0)
    {
        return -1;
    }
    if (check_funcs(file, size) || set_slave_addr(file, address, force))
    {
        close(file);
        return -1;
    }
    if (I2C_SMBUS_WORD_DATA == size)
    {
        res = i2c_smbus_read_word_data(file, daddress);
    }
    else /* I2C_SMBUS_BYTE_DATA */
    {
        res = i2c_smbus_read_byte_data(file, daddress);
    }
    close(file);

    if (res < 0)
    {
        FPRINTF(1, stderr, "Error: Read failed\n");
        return -2;
    }

    zte_printf_s("address: %#x, daddress: %#x, 0x%0*x\n", address, daddress, size == I2C_SMBUS_WORD_DATA ? 4 : 2, res);

    return res;
}

int i2c_set(int i2cbus,int address, int daddress, int value ,int size)
{
    char filename[20];
    int res, file;
    int force = 0;

    if (value < 0)
    {
        FPRINTF(1, stderr, "Error: Data value invalid!\n");
    }
    if ((size == I2C_SMBUS_BYTE_DATA && value > 0xff)
            || (size == I2C_SMBUS_WORD_DATA && value > 0xffff))
    {
        FPRINTF(1, stderr, "Error: Data value out of range!\n");
    }

    file = open_i2c_dev(i2cbus, filename, sizeof(filename), 0);
    if (file < 0)
    {
        return -1;
    }
    if (check_funcs(file, size) || set_slave_addr(file, address, force))
    {
        close(file);
        return -1;
    }
    if (I2C_SMBUS_WORD_DATA == size)
    {
        res = i2c_smbus_write_word_data(file, daddress, value);
    }
    else /* I2C_SMBUS_BYTE_DATA */
    {
        res = i2c_smbus_write_byte_data(file, daddress, value);
    }
    if (res < 0)
    {
        FPRINTF(1, stderr, "Error: Write failed\n");
        close(file);
        return -2;
    }

#ifdef READBACK
    if (I2C_SMBUS_WORD_DATA == size)
    {
        res = i2c_smbus_read_word_data(file, daddress);
    }
    else /* I2C_SMBUS_BYTE_DATA */
    {
        res = i2c_smbus_read_byte_data(file, daddress);
    }
    close(file);

    if (res < 0)
    {
        zte_printf_s("Warning - readback failed\n");
    }
    else if (res != value)
    {
        zte_printf_s("Warning - data mismatch - wrote "
                     "0x%0*x, read back 0x%0*x\n",
                     size == I2C_SMBUS_WORD_DATA ? 4 : 2, value,
                     size == I2C_SMBUS_WORD_DATA ? 4 : 2, res);
        }
    else
    {
        zte_printf_s("Value 0x%0*x written, readback matched\n",
                     size == I2C_SMBUS_WORD_DATA ? 4 : 2, value);
    }
    return 0;
#else
    close(file);
    return 0;
#endif
}

#endif

#ifdef I2C_USED_IN_KERNEL
UINT32 BootSfpRegRead(UINT32 ulIndex,UINT32 ulE2OrPhy, UINT32 ulReg, UINT32 *pulVal)
{
    int address;
    UINT32 ulRetVal = BSP_OK;

    if (SFP_EEPROM == ulE2OrPhy)
    {
        address = 0x50;
    }
    else if (SFP_PHY == ulE2OrPhy)
    {
        address = 0x56;
    }
    else
    {
        return -1;
    }

    if (ulReg > 0xff)
    {
        FPRINTF(1, stderr, "Error: Data address invalid!\n");
    }

    *pulVal = i2c_get(ulIndex,address, ulReg, I2C_SMBUS_BYTE_DATA);

    if ((int)*pulVal < 0)
    {
        ulRetVal = -1;
    }
    return ulRetVal;
}

UINT32 BootSfpRegWrite(UINT32 ulIndex, UINT32 ulE2OrPhy, UINT32 ulReg, UINT32 ulVal)
{
    int address;
    UINT32 ulRetVal = BSP_OK;

    if (SFP_EEPROM == ulE2OrPhy)
    {
        address = 0x50;
    }
    else if (SFP_PHY == ulE2OrPhy)
    {
        address = 0x56;
    }
    else
    {
        return -1;
    }
    if (ulReg > 0xff)
    {
        FPRINTF(1, stderr, "Error: Data address invalid!\n");
    }

    ulRetVal = i2c_set(ulIndex,address, ulReg, ulVal, I2C_SMBUS_BYTE_DATA);

    return ulRetVal;
}
#else
/**************************************************************************
 *                         全局函数实现                                   *
 **************************************************************************/


/**************************************************************************
* 函数名称: BootSfpDevInit
* 功能描述: Sfp设备初始化
* 输入参数: ptSfp设备结构体指针
* 输出参数: 错误码
* 返 回 值: BSP_OK 执行成功
*           其它   执行失败
* 其它说明:
* 修改日期       版本号           修改人    修改内容
* ------------------------------------------------------------------------
* 2021年12月26日 B121N1   耿佳佳    创建
**************************************************************************/
UINT32 BootSfpDevInit(T_SfpDev * ptSfp)
{
    UINT32 ulRetVal = BSP_OK;
    UINT32 ulSlaveAddr = 0;
    UINT32 ulLowAddr = 0;
    UINT32 ulHiAddr = 0xff;
    static UINT32 ulFirstRun = 1;
    T_SfpDev *ptDev = NULL;

    if (NULL == ptSfp)
    {
        return BSP_E_POINTER_NULL;
    }

    if (ptSfp->ulDevIndex >= SFP_NUM_DEV)
    {
        return BSP_E_INPUTPARA_ERROR;
    }

    ulSlaveAddr = ptSfp->tSlave.Addr;
    if ((ulSlaveAddr < ulLowAddr) || (ulSlaveAddr > ulHiAddr))
    {
        return BSP_E_INPUTPARA_ERROR;
    }

    /* 第一次运行时则清0驱动结构g_tEepromDevTbl  */

    zte_memset_s((void *)&g_astSfp[ptSfp->ulDevIndex], sizeof(T_SfpDev), 0, sizeof(T_SfpDev));

    ptDev = &g_astSfp[ptSfp->ulDevIndex];
    if (NULL != ptDev->ptSemWrRd)
    {
        return BSP_OK;
    }
    zte_memcpy_s((void *)ptDev, sizeof(*ptDev), (void *)ptSfp, sizeof(*ptDev));
    ptDev->tSlave.Mode = 0;
    ptDev->ptSemWrRd = semBCreate(SEM_Q_FIFO, SEM_FULL);
    if (NULL == ptDev->ptSemWrRd)
    {
        return BSP_ERROR;
    }

    return ulRetVal;
}


/**************************************************************************
* 函数名称: BootSfpRegRead
* 功能描述: Sfp phy寄存器读接口
* 输入参数: ulIndex：I2c索引号
           ulE2OrPhy：0 -EEPROM，1-PHY
           ulReg：寄存器
* 输出参数: pulVal：读出值
* 返 回 值: BSP_OK 执行成功
*           其它   执行失败
* 其它说明:
* 修改日期       版本号           修改人    修改内容
* ------------------------------------------------------------------------
* 2021年12月26日 B121N1   耿佳佳    创建
**************************************************************************/
UINT32 BootSfpRegRead(UINT32 ulIndex,UINT32 ulE2OrPhy, UINT32 ulReg, UINT32 *pulVal)
{
    UINT32 ulRetVal = BSP_OK;
    T_I2C_CLIENT_OWNER *ptOwner = NULL;
    UCHAR ucBuf[2] = {0, 0};
    T_I2C_MSG atI2CMsg[2] = {0};

    if (pulVal == NULL)
    {
        return BSP_ERROR_NULL_POINTER;
    }
    SFP_DEV_INDEX_CHECK(ulIndex);

    SFP_DEV_CRITICAL_ENTER(ulIndex);

    ucBuf[0] = ulReg;
    atI2CMsg[0].Flags = 0;
    atI2CMsg[0].Len = 1;
    atI2CMsg[0].pBuf = &ucBuf[0];

    atI2CMsg[1].Flags = I2C_M_RD;
    atI2CMsg[1].Len = 1;
    atI2CMsg[1].pBuf = &ucBuf[1];

    ptOwner = &g_astSfp[ulIndex].tSlave;
    if (SFP_EEPROM == ulE2OrPhy)
    {
        ptOwner->Addr = 0x50;
    }
    else if (SFP_PHY == ulE2OrPhy)
    {
        ptOwner->Addr = 0x56;
    }
    else
    {
        return -1;
    }

    ulRetVal = BspI2CBusTransfer(ptOwner, &atI2CMsg[0], 2);
    *pulVal = ucBuf[1];

    SFP_DEV_CRITICAL_EXIT(ulIndex);

    return ulRetVal;
}


/**************************************************************************
* 函数名称: BootSfpRegWrite
* 功能描述: Sfp寄存器写接口
* 输入参数: ulIndex：I2c索引号
           ulE2OrPhy：0 -EEPROM，1-PHY
           ulReg：寄存器
           ulVal：写入值
* 输出参数: 无
* 返 回 值: BSP_OK 执行成功
*           其它   执行失败
* 其它说明:
* 修改日期       版本号           修改人    修改内容
* ------------------------------------------------------------------------
* 2021年12月26日 B121N1   耿佳佳    创建
**************************************************************************/

UINT32 BootSfpRegWrite(UINT32 ulIndex, UINT32 ulE2OrPhy, UINT32 ulReg, UINT32 ulVal)
{
    UINT32 ulRetVal = BSP_OK;
    T_I2C_CLIENT_OWNER *ptOwner = NULL;
    UCHAR ucBuf[2] = {0, 0};
    T_I2C_MSG tI2CMsg = {0};

    if (ulIndex >= (UINT32)SFP_NUM_DEV)
    {
        return BSP_ERROR_INVALID_PARA;
    }
    SFP_DEV_CRITICAL_ENTER(ulIndex);

    ucBuf[0] = ulReg;
    ucBuf[1] = ulVal;
    tI2CMsg.Flags = 0;
    tI2CMsg.Len = 2;
    tI2CMsg.pBuf = &ucBuf[0];

    ptOwner = &g_astSfp[ulIndex].tSlave;

    if (SFP_EEPROM == ulE2OrPhy)
    {
        ptOwner->Addr = 0x50;
    }
    else if (SFP_PHY == ulE2OrPhy)
    {
        ptOwner->Addr = 0x56;
    }
    else
    {
        return -1;
    }
    ulRetVal = BspI2CBusTransfer(ptOwner, &tI2CMsg, 1);

    SFP_DEV_CRITICAL_EXIT(ulIndex);

    return ulRetVal;
}
#endif

UINT32 BootSfpPhyRegRead(UINT32 ulIndex, UINT32 ulReg, UINT32 *pulVal)
{
    UINT32 pVal[2] = {0,0};
    UINT32 ret = BSP_OK;

    ret |= BootSfpRegRead(ulIndex, SFP_PHY,ulReg, &pVal[0]);
    ret |= BootSfpRegRead(ulIndex, SFP_PHY,ulReg, &pVal[1]);
    *pulVal = (pVal[0] << 8) | pVal[1];
    return ret;
}

UINT32 BootSfpPhyRegWrite(UINT32 ulIndex, UINT32 ulReg, UINT32 ulVal)
{
    UINT32 pVal[2] = {0,0};
    UINT32 ret = BSP_OK;

    pVal[1] = ulVal & 0xff;
    pVal[0] = (ulVal >> 8) & 0xff;

    ret |= BootSfpRegWrite(ulIndex,SFP_PHY, ulReg,pVal[0]);
    ret |= BootSfpRegWrite(ulIndex,SFP_PHY, ulReg,pVal[1]);
    return ret;
}

UINT32 BootM88e1111ChipInit(UINT32 ulOptIndex)
{

    UINT32 ulRegValue;

    BootSfpPhyRegWrite(ulOptIndex, MIIM_88E1118_PHY_PAGE, 0);
    BootSfpPhyRegRead(ulOptIndex, MIIM_88E1118_CTRL, &ulRegValue);
    ulRegValue |= MIIM_88E1111_POWER_DOWN; /* power down */
    BootSfpPhyRegWrite(ulOptIndex, MIIM_88E1118_CTRL, ulRegValue);
    BspSysMsDelay_Sys(10);

    /*page 0, reg 27 write 0x9084, sgmii to copper*/
    BootSfpPhyRegRead(ulOptIndex, MIIM_88E1111_PHY_EXT_SR, &ulRegValue);
    ulRegValue &= ~(MIIM_88E1111_HWCFG_MODE_MASK);
    ulRegValue |= MIIM_88E1111_HWCFG_MODE_SGMII_NO_CLK;
    ulRegValue |= MIIM_88E1111_HWCFG_FIBER_COPPER_AUTO;
    BootSfpPhyRegWrite(ulOptIndex, MIIM_88E1111_PHY_EXT_SR, ulRegValue);
    BspSysMsDelay_Sys(10);

    /*page 0, reg 9 write 0xf00, Advertise 1000BASE-T Full/Half-Duplex*/
    BootSfpPhyRegRead(ulOptIndex, MIIM_88E1118_1000BASE_CTRL, &ulRegValue);
    ulRegValue |= MIIM_88E1111_1000BASE_HALF_DUPLEX; /* 1000BASE-T Half-Duplex advertised*/
    ulRegValue |= MIIM_88E1111_1000BASE_FULL_DUPLEX; /* 1000BASE-T Full-Duplex advertised*/
    BootSfpPhyRegWrite(ulOptIndex, MIIM_88E1118_1000BASE_CTRL, ulRegValue);
    BspSysMsDelay_Sys(10);

    /*page 0, reg 0 write 0x8140, Apply Software Reset, Disable Auto-Negotiation Process*/
    BootSfpPhyRegRead(ulOptIndex, MIIM_88E1118_CTRL, &ulRegValue);
    ulRegValue &= ~ MIIM_88E1111_AUTO_NEGOTIATION; /* disable AN */
    ulRegValue |= MIIM_88E1111_SPEED_SELECTION_MSB; /* 1000M */
    ulRegValue &= ~ MIIM_88E1111_SPEED_SELECTION_LSB;
    ulRegValue &= ~ MIIM_88E1111_COPPER_DUPLEX_MODE; /* full duplex */
    ulRegValue |= MIIM_88E1111_COPPER_DUPLEX_MODE;
    ulRegValue |= MIIM_88E1111_RESET;
    BootSfpPhyRegWrite(ulOptIndex, MIIM_88E1118_CTRL, ulRegValue);
    BspSysMsDelay_Sys(10);

    /*page 0, reg 4 write 0x0de1, Advertise 10/100BASE-T Full/Half-Duplex*/
    BootSfpPhyRegRead(ulOptIndex, MIIM_88E1118_AUTO_CTRL, &ulRegValue);
    ulRegValue &= ~ MIIM_88E1111_ASYMMETRIC_PAUSE;
    ulRegValue |= MIIM_88E1111_ASYMMETRIC_PAUSE;
    ulRegValue &= ~ MIIM_88E1111_PAUSE;
    ulRegValue |= MIIM_88E1111_PAUSE;
    ulRegValue &= ~ MIIM_88E1111_AUTO_NEGOTIATION_MODE_MASK;
    ulRegValue |= MIIM_88E1111_100BASE_TX_FULL_DUPLEX;
    ulRegValue |= MIIM_88E1111_100BASE_TX_HALF_DUPLEX;
    ulRegValue |= MIIM_88E1111_10BASE_TX_FULL_DUPLEX;
    ulRegValue |= MIIM_88E1111_10BASE_TX_HALF_DUPLEX;
    BootSfpPhyRegWrite(ulOptIndex, MIIM_88E1118_AUTO_CTRL, ulRegValue);
    BspSysMsDelay_Sys(10);

    /*close sgmii auto-negotiation*/
    BootSfpPhyRegWrite(ulOptIndex, MIIM_88E1118_PHY_PAGE, 1);
    BootSfpPhyRegRead(ulOptIndex, MIIM_88E1118_CTRL, &ulRegValue);
    ulRegValue &= ~ MIIM_88E1111_AUTO_NEGOTIATION; /* disable AN */
    ulRegValue &= ~ MIIM_88E1111_SPEED_SELECTION_MSB; /* 1000G */
    ulRegValue |= MIIM_88E1111_SPEED_SELECTION_MSB;
    ulRegValue &= ~ MIIM_88E1111_COPPER_DUPLEX_MODE; /* full duplex */
    ulRegValue |= MIIM_88E1111_COPPER_DUPLEX_MODE;
    ulRegValue |= MIIM_88E1111_RESET;
    BootSfpPhyRegWrite(ulOptIndex, MIIM_88E1118_CTRL, ulRegValue);
    BspSysMsDelay_Sys(10);

    /*page 0, reg 0 write 0x9140, Apply Software Reset, Enable Auto-Negotiation Process*/
    BootSfpPhyRegWrite(ulOptIndex, MIIM_88E1118_PHY_PAGE, 0);
    BootSfpPhyRegRead(ulOptIndex, MIIM_88E1118_CTRL, &ulRegValue);
    ulRegValue |= MIIM_88E1111_AUTO_NEGOTIATION; /* enable AN */
    ulRegValue |= MIIM_88E1111_SPEED_SELECTION_MSB; /* 1000M */
    ulRegValue &= ~ MIIM_88E1111_SPEED_SELECTION_LSB;
    ulRegValue &= ~ MIIM_88E1111_COPPER_DUPLEX_MODE; /* full duplex */
    ulRegValue |= MIIM_88E1111_COPPER_DUPLEX_MODE;
    ulRegValue |= MIIM_88E1111_RESET;
    BootSfpPhyRegWrite(ulOptIndex, MIIM_88E1118_CTRL, ulRegValue);

    return BSP_OK; /*需要具体配置*/
}


UINT32 BootInitM88e1111Init(UINT32 ulOptIndex)
{
    UINT32 ret = BSP_OK;


    /* C88E1322 configurations */
    ret = BootM88e1111ChipInit(ulOptIndex);
    if (BSP_OK != ret)
    {
        zte_printf_s("M88e1111 chip initialize failed\n");
        return ret;
    }

    return BSP_OK;
}
/**************************************************************************
* 函数名称: BootInitSfpPhy
* 功能描述: Sfp phy初始化入口函数
* 输入参数: ulOptIndex：光口索引号
* 输出参数: 无
* 返 回 值: BSP_OK 执行成功
*           其它   执行失败
* 其它说明:
* 修改日期       版本号           修改人    修改内容
* ------------------------------------------------------------------------
* 2021年12月26日 B121N1   耿佳佳    创建
**************************************************************************/
UINT32 BootInitSfpPhy(UINT32 ulOptIndex)
{
    UINT32 ret = BSP_OK;
    UINT32 idx;
    UINT32 pulVal=0;

    for(idx = 0; idx < 3; idx++)
    {
        ret = BootSfpPhyRegRead(ulOptIndex,PHY_ID_REG2,&pulVal);
        if ((BSP_OK == ret) && (BIT_FIELD_RIGHT_JUST_GET(pulVal, 4, 6) != 0))
        {
            break;
        }
        zte_printf_s("IdCheck error times:%d\n",idx);
    }

    if (3 <= idx)
    {
        return BSP_ERROR;
    }
    switch (BIT_FIELD_RIGHT_JUST_GET(pulVal, 4, 6))
    {
        case M88E1111_MODEL_NO:
        {
            zte_printf_s("opt phy type M88E1111\n");
            g_ulPhyType = 1111;
            ret=BootInitM88e1111Init(ulOptIndex);
            break;
        }
        default:
        {
            zte_printf_s("phy type unknow\n");
            ret = BSP_ERROR;
            break;
        }
    }

    return ret;
}

UINT32 M88E1111StatusGet(UINT32 ulOptIndex, UINT32 *pulStat)
{
    UINT32 ulRetVal = BSP_OK;
    UINT32 ulVal = 0;


    ulRetVal = BootSfpPhyRegRead(ulOptIndex, MIIM_88E1118_SR, &ulVal);
    if (BSP_OK != ulRetVal)
    {
        return ulRetVal;
    }

    zte_printf_s("M88E1111CopperStatusGet ulVal = 0x%x\n",ulVal);

    *pulStat = 0;
    switch (BIT_FIELD_RIGHT_JUST_GET(ulVal, 14, 2))
    {
        case 2:
        {
            *pulStat |= NET_STATE_SPEED1000;
            break;
        }

        case 1:
        {
            *pulStat |= NET_STATE_SPEED100;
            break;
        }

        case 0:
        {
            *pulStat |= NET_STATE_SPEED10;
            break;
        }

        default:
        {
            break;
        }
    }

    if (BIT_FIELD_RIGHT_JUST_GET(ulVal, 13, 1))
    {
        *pulStat |= NET_STATE_DUPLEX;
    }

    /* copper energe detect status 位在link down时响应有点迟钝得多
     * 插上网线后响应很及时(active), 但拔除网线(link down)后, 通常要几秒钟该位才会置位(sleep),
     */
    if (!BIT_FIELD_RIGHT_JUST_GET(ulVal, 4, 1))
    {
        *pulStat |= NET_STATE_COPPER_INSERT;
    }

    if (BIT_FIELD_RIGHT_JUST_GET(ulVal, 10, 1))
    {
        *pulStat |= NET_STATE_COPPER_LINKOK | NET_STATE_LINKOK;
    }

    return ulRetVal;
}

/**************************************************************************
* 函数名称: BootGetSfpPhyStatus
* 功能描述: Sfp phy获取网口链接状态
* 输入参数: ulOptIndex：光口索引号
* 输出参数: pulStat：链接状态表征值
* 返 回 值: BSP_OK 执行成功
*           其它   执行失败
* 其它说明:
* 修改日期       版本号           修改人    修改内容
* ------------------------------------------------------------------------
* 2021年12月26日 B121N1   耿佳佳    创建
**************************************************************************/

UINT32 BootGetSfpPhyStatus(UINT32 ulOptIndex, UINT32 *pulStat)
{

    UINT32 ulRetVal = BSP_OK;

    if (M88E1111== g_ulPhyType)
    {
        ulRetVal = M88E1111StatusGet(ulOptIndex, pulStat);     /*ok*/
    }
    return ulRetVal;

}



void sfpeepromrd(UINT32 ulIndex, UINT32 ulReg)
{
    UINT32 pulVal = 0;
    BootSfpRegRead(ulIndex,SFP_EEPROM, ulReg, &pulVal);
    zte_printf_s("sfprd reg %d = 0x%x\n",ulReg,pulVal);

    return;
}

void sfpeepromwr(UINT32 ulIndex, UINT32 ulReg, UINT32 ulVal)
{
    BootSfpRegWrite(ulIndex,SFP_EEPROM, ulReg, ulVal);
    return;
}



void sfpphyrd(UINT32 ulIndex, UINT32 ulReg)
{
    UINT32 pVal[2] = {0,0};
    UINT32 pulVal = 0;

    BootSfpRegRead(ulIndex, SFP_PHY,ulReg, &pVal[0]);
    BootSfpRegRead(ulIndex, SFP_PHY,ulReg, &pVal[1]);
    pulVal = (pVal[0] << 8) | pVal[1];
    zte_printf_s("sfprd reg %d = 0x%x\n",ulReg,pulVal);

    return;
}
void sfpphywr(UINT32 ulIndex, UINT32 ulReg, UINT32 ulVal)
{
    UCHAR pVal[2] = {0,0};

    pVal[1] = ulVal & 0xff;
    pVal[0] = (ulVal >> 8) & 0xff;

    BootSfpRegWrite(ulIndex,SFP_PHY, ulReg,pVal[0]);
    BootSfpRegWrite(ulIndex,SFP_PHY, ulReg,pVal[1]);

    return;
}


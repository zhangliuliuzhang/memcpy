/**************************************************************************
 * 版权所有 (C)2001, 深圳市中兴通讯股份有限公司
 *
 * 文件名称: SFP.h
 * 文件标识:
 * 内容摘要:
 * 其它说明:
 * 当前版本: ZXSDRV10109B01
 * 作    者: 罗乔发
 * 完成日期:
 *
 * 修改记录1:
 *    修改日期: 2011年10月13日
 *    版 本 号: ZXSDRV10109B01
 *    修 改 人: 罗乔发
 *    修改内容: 创建
 * 修改记录2:
 **************************************************************************/

#ifndef	_SFP_H_
#define	_SFP_H_
#ifndef I2C_USED_IN_KERNEL
#include "i2cbusapi.h"
#endif
/**************************************************************************
 *                        宏常量                                          *
 **************************************************************************/
#define SFP_NUM_DEV             8

#define SFP_I2C_ADDR_BASE       0x18
#define SFP_I2C_ADDR_PIN_NUM    3

#define SFP_NUM_REG             4
/* 芯片寄存器号定义 */
#define SFP_REG_INPUT           0 /* Input port register */
#define SFP_REG_OUTPUT          1 /* Output port register */
#define SFP_REG_POLARITY        2 /* Polarity inversion register */
#define SFP_REG_CONF            3 /* Configuration register */

#define SFP_EEPROM      0
#define SFP_PHY         1



/**************************************************************************
 *                        宏定义                                          *
 **************************************************************************/
/* Started by AICoder, pid:p11a4sf539k28f0141ae0a6d5028932720f4663b */
#define FPRINTF(flag, f, ...)             \
do {                                      \
   if (fprintf(f, __VA_ARGS__) < 0)       \
   {                                      \
      if ((f != stdout) && (f != stderr))                    \
      {                                   \
         if (flag == 1)                   \
         {                                \
            if (zte_fclose_s(f) == 0)           \
               zte_printf_s("fprintf error\n"); \
         }                                \
      }                                   \
   }                                      \
} while (0)
/* Ended by AICoder, pid:p11a4sf539k28f0141ae0a6d5028932720f4663b */
/**************************************************************************
 *                         数据类型                                       *
 **************************************************************************/
#ifndef I2C_USED_IN_KERNEL
typedef struct Tag_sfp_dev
{
   /* 设备编号，从0~10顺序编号 */
   ULONG ulDevIndex;
   /* 预留, 防止出现类似兼容芯片但有少量差异时使用 */
   ULONG ulDevType;
   /* I2C接口相关的从器件信息结构体 */
   T_I2C_CLIENT_OWNER tSlave;
   /*  */
   SEM_ID ptSemWrRd;
} T_SfpDev;
#endif

/**************************************************************************
 *                         全局变量声明                                   *
 **************************************************************************/


/**************************************************************************
 *                         全局函数声明                                   *
 **************************************************************************/
#ifndef I2C_USED_IN_KERNEL
ULONG BootSfpDevInit(T_SfpDev *ptSfp);
#endif
UINT32 BootSfpRegRead(UINT32 ulIndex,UINT32 ulE2OrPhy, UINT32 ulReg, UINT32 *pulVal);
UINT32 BootSfpRegWrite(UINT32 ulIndex,UINT32 ulE2OrPhy, UINT32 ulReg, UINT32 ulVal);
/* Started by AICoder, pid:60343r51c2s9e7b140c009754033640bbdc2a4db */
UINT32 BootInitSfpPhy(UINT32 ulOptIndex);
UINT32 BootGetSfpPhyStatus(UINT32 ulOptIndex, UINT32 *pulStat);
/* Ended by AICoder, pid:60343r51c2s9e7b140c009754033640bbdc2a4db */
#endif  /* _SFP_H_ */


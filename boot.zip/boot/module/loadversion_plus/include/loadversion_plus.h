#ifndef _LOADVERSION_PLUS_H_
#define _LOADVERSION_PLUS_H_

#ifdef __cplusplus
extern "C" {
#endif

#undef LOADVERSION_PLUS_DEBUG

#undef debug
#ifdef LOADVERSION_PLUS_DEBUG
#define debug(fmt, args...) zte_printf_s(fmt, ##args)
#else
#define debug(fmt, args...)
#endif

enum {
    E_BAKBLK_EMPTY = 0,
    E_BAKBLK_1STMAP,
    E_BAKBLK_2NDMAP,
    E_BAKBLK_INVALID
} E_BAKBLK;

enum {
    E_BAKBLK_RET_EMPTY = 0,
    E_BAKBLK_RET_1STMAP,
    E_BAKBLK_RET_2NDMAP,
    E_BAKBLK_RET_VALID,
    E_BAKBLK_RET_INVALID,
} E_BAKBLK_RET;

typedef struct tagT_BakBlk_MapInfo {
    unsigned int dwBakBlkStatus;   //备块状态枚举值变量
    unsigned int dwProzBlkAddr;    //源块保护区偏移地址
    unsigned int dwBakBlkAddr;     //备块映射区偏移地址
    unsigned int dwResv;           //预留+满足16字节对齐的ECC要求
} T_BakBlk_MapInfo;

typedef struct tagT_BakBlk_MapHead {
    unsigned int magic;    //0xBBADBBAD，判断高低16位任一正确即可
    unsigned int crc;      //从下面version字段开始，也包括映射信息数组的部分
    unsigned int version;  //映射信息的版本号，初始按0x01010101
    unsigned int dwResv;
} T_BakBlk_MapHead; //注意满足16字节对齐的ECC要求

#define macro_BAKBLK_MAGIC 0xBBADBBAD
#define macro_BAKBLK_MAGIC_H 0xBBAD
#define macro_BAKBLK_MAGIC_L 0xBBAD

#define PROTECT_ZONE_SWV_SIZE (100*1024*1024)
#define BAKBLK_SPACE_SIZE (10*1024*1024)
#define PROTECT_PLUS_TOTAL_SIZE (PROTECT_ZONE_SWV_SIZE + 2*BAKBLK_SPACE_SIZE)
#define VERSION_DATA 0
#define PROTECT_HEAD 1

#ifndef INPUT_POINTER_CHECK_RETURN_VAL
/* 指针非空检查宏，返回 BSP_ERROR_NULL_POINTER */
#define INPUT_POINTER_CHECK_RETURN_VAL(ppointer,val)                         \
    if (NULL == ppointer)                                     \
    {                                                         \
        dbgInfo("%s:Input Pointer is NULL!\n", __FUNCTION__); \
        return val;                            \
    }
#endif
/* Started by AICoder, pid:bef9ba0313nf93d14baf0a446013c3060f914059 */
STATUS checkProtectVersionPlus(void);
/* Ended by AICoder, pid:bef9ba0313nf93d14baf0a446013c3060f914059 */
#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif
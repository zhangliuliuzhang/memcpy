/* Started by AICoder, pid:z8e49da640f50301409208cac182e93c4fd011ca */
#include "bsppub.h"
#include "loadversion.h"
#include "loadversion_plus.h"
#include "bootapp.h"
#include "crc.h"
#include "flash.h"
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>

#ifdef LOADVERSION_PLUS_DEBUG   /* 测试用接口 */

extern ULONG BadBlockSimulation(UCHAR ucType, ULONG dwBadBlkAddr, T_BakBlk_MapInfo *ptSrcInfo, T_BakBlk_MapInfo *ptMyInfo, UCHAR *data);
extern ULONG WriteBakBlkMapHeadToFlash(T_BakBlk_MapInfo *ptSrcInfo);
extern ULONG BootGetProtectBlkSize(ULONG *ulProtectBlkSize);
extern ULONG LoadversionPlusTestInit(T_BakBlk_MapInfo **pptSrcInfo, T_BakBlk_MapInfo **pptMyInfo);
extern ULONG BootGetVerProtectSwvLen(void);
extern ULONG BootGetProtectBakBlkSpaceSize(void);
extern ULONG BootGetVerProtectBakBlkAddr(void);
extern ULONG BootGetFlashVerProtectAddr(void);
extern STATUS checkProtectVersionPlus(void);
extern UINT32 BootFlushMiniSetVerToProtect(void);

void commonLoadVersionTest(ULONG BakBlkSize, const ULONG (*badBlockSimulations)[2], size_t numSims, const char* funcName)
{
    T_BakBlk_MapInfo *ptSrcInfo = NULL;
    T_BakBlk_MapInfo *ptMyInfo = NULL;
    ULONG ulProZoneAddrOffset = 0;
    UCHAR* data = NULL;

    if (BSP_OK != BootFlushMiniSetVerToProtect())
    {
        printf("line%d %s failed\n", __LINE__, funcName);
        return;
    }

    ulProZoneAddrOffset = BootGetFlashVerProtectAddr();

    if (BSP_OK != LoadversionPlusTestInit(&ptSrcInfo, &ptMyInfo))
    {
        printf("line%d %s failed\n", __LINE__, funcName);
        goto cleanup;
    }

    BspFlashErase(BootGetVerProtectBakBlkAddr(), BootGetProtectBakBlkSpaceSize() * 2);
    data = calloc(BootGetVerProtectSwvLen(), sizeof(char));
    BspFlashRead(ulProZoneAddrOffset, data, BootGetVerProtectSwvLen());

    for (size_t i = 0; i < numSims; ++i)
    {
        BadBlockSimulation(badBlockSimulations[i][0], badBlockSimulations[i][1] + ulProZoneAddrOffset, ptSrcInfo, ptMyInfo, data);
    }

    WriteBakBlkMapHeadToFlash(ptSrcInfo);

cleanup:
    free(ptSrcInfo);
    free(ptMyInfo);
    free(data);
}

void LoadversionPlusTest_OnlyA()
{
    ULONG BakBlkSize = 0;
    if (BSP_OK != BootGetProtectBlkSize(&BakBlkSize))
    {
        printf("Failed to initialize BakBlkSize in %s\n", __FUNCTION__);
        return;
    }

    ULONG simulations[][2] = {
        {PROTECT_HEAD, 0},
        {VERSION_DATA, 2 * BakBlkSize},
        {VERSION_DATA, 70 * BakBlkSize},
        {VERSION_DATA, BootGetVerProtectSwvLen() - BakBlkSize}
    };
    commonLoadVersionTest(BakBlkSize, simulations, 4, __FUNCTION__);

    if (BSP_OK != checkProtectVersionPlus())
    {
        printf("%s failed\n", __FUNCTION__);
        return;
    }

    printf("%s succeed\n", __FUNCTION__);
}

void LoadversionPlusTest_AplusB()
{
    ULONG BakBlkSize = 0;
    if (BSP_OK != BootGetProtectBlkSize(&BakBlkSize))
    {
        printf("Failed to initialize BakBlkSize in %s\n", __FUNCTION__);
        return;
    }

    ULONG simulations[][2] = {
        {PROTECT_HEAD, 0},
        {VERSION_DATA, 2 * BakBlkSize},
        {VERSION_DATA, 70 * BakBlkSize},
        {VERSION_DATA, 70 * BakBlkSize} // Simulate A area failure
    };
    commonLoadVersionTest(BakBlkSize, simulations, 4, __FUNCTION__);

    if (BSP_OK != checkProtectVersionPlus())
    {
        printf("%s failed\n", __FUNCTION__);
        return;
    }

    printf("%s succeed\n", __FUNCTION__);
}

void LoadversionPlusTest_AplusBplusBHead()
{
    ULONG BakBlkSize = 0;
    if (BSP_OK != BootGetProtectBlkSize(&BakBlkSize))
    {
        printf("Failed to initialize BakBlkSize in %s\n", __FUNCTION__);
        return;
    }

    ULONG simulations[][2] = {
        {VERSION_DATA, 2 * BakBlkSize},
        {VERSION_DATA, 70 * BakBlkSize},
        {VERSION_DATA, 70 * BakBlkSize} // Simulate A area failure
    };
    commonLoadVersionTest(BakBlkSize, simulations, 3, __FUNCTION__);

    //擦除A区映射头
    if (BspFlashErase(BootGetVerProtectBakBlkAddr(), BakBlkSize) != BSP_OK)
    {
        printf("First BakBlk Head erase error\n");
        return;
    }

    if (BSP_OK != checkProtectVersionPlus())
    {
        printf("%s failed\n", __FUNCTION__);
        return;
    }

    printf("%s succeed\n", __FUNCTION__);
}

#endif
/* Ended by AICoder, pid:z8e49da640f50301409208cac182e93c4fd011ca */
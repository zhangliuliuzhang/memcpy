/* Started by AICoder, pid:mfff60e4a0745b41451908b997356772ef994323 */
#include "bsppub.h"
#include "bspcomm.h"
#include "loadversion.h"
#include "loadversion_plus.h"
#include "bootapp.h"
#include "crc.h"
#include "flash.h"
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>

extern UCHAR g_ucRunVer;
extern ULONG BspGetFlashBlkSize(ULONG ulFlashAddr, ULONG ulSrcFileLen, ULONG *ulBuffLen);

static ULONG s_ulBakBlkMaxNum = 0;
static ULONG s_ulProtectBlkSize = 0;

static void BakBlkMapHeadPrintf(T_BakBlk_MapHead *ptHead)
{
    INPUT_POINTER_CHECK_RETURN(ptHead);

    printf("BakBlkMapHead:\n");
    printf("magic:%08x\n", ptHead->magic);
    printf("crc:%08x\n", ptHead->crc);
    printf("version:%08x\n", ptHead->version);
    printf("dwResv:%08x\n", ptHead->dwResv);

    return;
}

static void BakBlkMapInfoPrintf(T_BakBlk_MapInfo *ptSrcInfo, UINT32 num)
{
    int i = 0;

    INPUT_POINTER_CHECK_RETURN(ptSrcInfo);

    for(i = 0; i < num; i++)
    {
        if(ptSrcInfo[i].dwBakBlkStatus != E_BAKBLK_1STMAP && ptSrcInfo[i].dwBakBlkStatus != E_BAKBLK_2NDMAP)
        {
            printf("total valid bakblk mapinfo num:%d\n",i);
            return;
        }

        printf("BakBlkMapInfo[%d]:\n",i);
        printf("dwBakBlkStatus:%#08x\n", ptSrcInfo[i].dwBakBlkStatus);
        printf("dwProzBlkAddr:%#08x\n", ptSrcInfo[i].dwProzBlkAddr);
        printf("dwBakBlkAddr:%#08x\n", ptSrcInfo[i].dwBakBlkAddr);
        printf("dwResv:%#08x\n", ptSrcInfo[i].dwResv);
    }

    printf("total valid bakblk mapinfo num:%d\n",num);
    return;
}

ULONG BootGetProtectBlkSize(ULONG *ulProtectBlkSize)
{
    INPUT_POINTER_CHECK_RETURN_VAL(ulProtectBlkSize, BSP_ERROR);
    ULONG ulProtectAddr = BootGetFlashVerProtectAddr();         // 获取保护区地址
    ULONG ulRetVal = 0;

    /* 获取mtd分区块大小 */
    ulRetVal = BspGetFlashBlkSize(ulProtectAddr, 0, ulProtectBlkSize);
    if (ulRetVal != BSP_OK || (0 == *ulProtectBlkSize) || (*ulProtectBlkSize > 0x100000))
    {
        printf("ERROR: please check flashAddr, ulRetVal: 0x%x, ulProtectBlkSize: 0x%x!", ulRetVal, *ulProtectBlkSize);
        return BSP_ERROR;
    }

    return BSP_OK;
}

__attribute__((weak)) ULONG BootGetVerProtectSwvLen(VOID)
{
    return BootGetVerProtectLen() < PROTECT_PLUS_TOTAL_SIZE ? BootGetVerProtectLen()*5/6 : PROTECT_ZONE_SWV_SIZE;
}

__attribute__((weak)) ULONG BootGetProtectBakBlkSpaceSize(void)
{
    return BootGetVerProtectLen() < PROTECT_PLUS_TOTAL_SIZE ? BootGetVerProtectLen()/12 : BAKBLK_SPACE_SIZE;
}

ULONG BootGetVerProtectBakBlkAddr(VOID)
{
    return BootGetFlashVerProtectAddr() + BootGetVerProtectLen() - BootGetProtectBakBlkSpaceSize()*2;
}

static ULONG BootGetBakBlkMaxNum(ULONG *ulBakBlkMaxNum)
{
    ULONG ulBakblkSpaceSize = BootGetProtectBakBlkSpaceSize();

    if (ulBakblkSpaceSize <= s_ulProtectBlkSize || s_ulProtectBlkSize == 0)
    {
        printf("ERROR: Invalid block size or backup block space size.");
        return BSP_ERROR;
    }

    *ulBakBlkMaxNum = ulBakblkSpaceSize/s_ulProtectBlkSize - 1;//减去映射头BLK占用

    return BSP_OK;
}

static ULONG LoadversionPlusInit()
{
    if(BootGetProtectBlkSize(&s_ulProtectBlkSize) == BSP_ERROR)
    {
        printf("line%d %s BootGetProtectBlkSize error\n",__LINE__,__FUNCTION__);
        return BSP_ERROR;
    }

    if(BootGetBakBlkMaxNum(&s_ulBakBlkMaxNum) == BSP_ERROR)
    {
        printf("line%d %s BootGetBakBlkMaxNum error!\n",__LINE__,__FUNCTION__);
        return BSP_ERROR;
    }

    debug("s_ulProtectBlkSize = %#x,s_ulBakBlkMaxNum = %#x\n",s_ulProtectBlkSize, s_ulBakBlkMaxNum);
    return BSP_OK;
}

static ULONG BakBlkMapInfoInit(T_BakBlk_MapHead **pptHead, T_BakBlk_MapInfo **pptMyInfo)
{
    INPUT_POINTER_CHECK_RETURN_VAL(pptHead, BSP_ERROR)
    INPUT_POINTER_CHECK_RETURN_VAL(pptMyInfo, BSP_ERROR)
    UINT32 len1 = sizeof(T_BakBlk_MapHead) + sizeof(T_BakBlk_MapInfo) * s_ulBakBlkMaxNum;
    UINT32 len2 = sizeof(T_BakBlk_MapInfo) * s_ulBakBlkMaxNum;

    if(*pptHead == NULL)
    {
        debug("line%d %s\n",__LINE__,__FUNCTION__);
        *pptHead =(T_BakBlk_MapHead *)calloc(1,len1);
        if(*pptHead == NULL)
        {
            printf("line%d %s,memory allocation error!\n",__LINE__,__FUNCTION__);
            return BSP_ERROR;
        }   
    }

    if(*pptMyInfo == NULL)
    {
        debug("line%d %s\n",__LINE__,__FUNCTION__);
        *pptMyInfo =(T_BakBlk_MapInfo *)calloc(1,len2);
        if(*pptMyInfo == NULL)
        {
            printf("line%d %s,memory allocation error!\n",__LINE__,__FUNCTION__);
            return BSP_ERROR;
        }
    }
    
    return BSP_OK;
}

static ULONG GetBakBlkMapInfoFromFlash(T_BakBlk_MapHead *ptHead, UINT32 BakBlkSpaceIndex)
{
    UINT32 uiFlashAddr = BootGetVerProtectBakBlkAddr() + BakBlkSpaceIndex*BootGetProtectBakBlkSpaceSize();
    UINT32 len = sizeof(T_BakBlk_MapHead) + sizeof(T_BakBlk_MapInfo) * s_ulBakBlkMaxNum;

    INPUT_POINTER_CHECK_RETURN_VAL(ptHead, BSP_ERROR)

    if (BspFlashRead(uiFlashAddr, (UCHAR *)ptHead, len) != BSP_OK)
    {
        printf("line%d %s,BspFlashRead error!\n",__LINE__,__FUNCTION__);
        return BSP_ERROR;
    }

    return BSP_OK;
}

static void BakBlkMapInfoRelease(T_BakBlk_MapHead **pptHead, T_BakBlk_MapInfo **pptMyInfo)
{
    INPUT_POINTER_CHECK_RETURN(pptHead)
    INPUT_POINTER_CHECK_RETURN(pptMyInfo)

    if(*pptHead != NULL)
    {
        free(*pptHead);
        *pptHead = NULL;
    }

    if(*pptMyInfo != NULL)
    {
        free(*pptMyInfo);
        *pptMyInfo = NULL;
    }
}

static ULONG FindMatchedBakBlk(ULONG dwStartAddr, ULONG dwEndAddr, T_BakBlk_MapInfo *ptSrcInfo, T_BakBlk_MapInfo *ptMyInfo, ULONG BakBlkIndexStart, ULONG BakBlkNum)
{
    ULONG ulRet = E_BAKBLK_RET_EMPTY;

    debug("line%d %s dwStartAddr=%#x dwEndAddr=%#x\n",__LINE__,__FUNCTION__,dwStartAddr,dwEndAddr);

    for(UINT32 SrcInfoIndex = BakBlkIndexStart,MyInfoIndex = 0; SrcInfoIndex < BakBlkIndexStart + BakBlkNum && SrcInfoIndex < s_ulBakBlkMaxNum; SrcInfoIndex++)
    {
        if(ptSrcInfo[SrcInfoIndex].dwBakBlkStatus != E_BAKBLK_EMPTY)
        {
            if(dwStartAddr <= ptSrcInfo[SrcInfoIndex].dwProzBlkAddr && dwEndAddr >= ptSrcInfo[SrcInfoIndex].dwProzBlkAddr)
            {
                if(ptSrcInfo[SrcInfoIndex].dwBakBlkStatus == E_BAKBLK_INVALID)
                {
                    return E_BAKBLK_RET_INVALID;
                }
                else{
                    zte_memcpy_s(&ptMyInfo[MyInfoIndex], sizeof(T_BakBlk_MapInfo), &ptSrcInfo[SrcInfoIndex], sizeof(T_BakBlk_MapInfo));
                    MyInfoIndex++;
                    ulRet = E_BAKBLK_RET_VALID;
                }
            }
        }
        else{
            return ulRet;
        }
    }

    return ulRet;
}

static ULONG GetBakBlks(UCHAR ucType, ULONG dwStartAddr, ULONG dwEndAddr, T_BakBlk_MapInfo *ptSrcInfo, T_BakBlk_MapInfo *ptMyInfo)
{
    ULONG ulRet = BSP_OK;

    INPUT_POINTER_CHECK_RETURN_VAL(ptSrcInfo, E_BAKBLK_RET_EMPTY)
    INPUT_POINTER_CHECK_RETURN_VAL(ptMyInfo, E_BAKBLK_RET_EMPTY)

    if(dwStartAddr < BootGetFlashVerProtectAddr() || dwEndAddr > BootGetFlashVerProtectAddr() + BootGetVerProtectSwvLen())
    {
        printf("line%d %s error!\n",__LINE__,__FUNCTION__);
        return E_BAKBLK_RET_INVALID;
    }

    if(ucType == PROTECT_HEAD)
    {
        ulRet = FindMatchedBakBlk(dwStartAddr, dwEndAddr, ptSrcInfo, ptMyInfo, 0, 1);
    }
    else
    {
        ulRet = FindMatchedBakBlk(dwStartAddr, dwEndAddr, ptSrcInfo, ptMyInfo, 1, s_ulBakBlkMaxNum - 1);
    }

    return ulRet;
}

static ULONG CheckBakBlkHead(T_BakBlk_MapHead *ptHead)
{
    ULONG ulCalCRCResult = 0;

    INPUT_POINTER_CHECK_RETURN_VAL(ptHead, BSP_ERROR)
    
    #ifdef LOADVERSION_PLUS_DEBUG
    printf("line%d %s\n",__LINE__,__FUNCTION__);
    BakBlkMapHeadPrintf(ptHead);
    #endif

    //验证魔数，判断高低16位任一正确即可
    if(((ptHead->magic & 0xffff) != macro_BAKBLK_MAGIC_H) && ((ptHead->magic >> 16) != macro_BAKBLK_MAGIC_L))
    {
        printf("line%d %s magic check error!\n",__LINE__,__FUNCTION__);
        return BSP_ERROR;
    }

    // 计算并验证CRC
    ulCalCRCResult = CalculateCRC16(CRC_MASK, (UCHAR *)ptHead + sizeof(ptHead->magic) + sizeof(ptHead->crc), 
                        sizeof(T_BakBlk_MapHead) - sizeof(ptHead->magic) - sizeof(ptHead->crc) + 
                        sizeof(T_BakBlk_MapInfo) * s_ulBakBlkMaxNum);
    if(ptHead->crc != ulCalCRCResult)
    {
        printf("line%d %s CalculateCRC16 error!\n",__LINE__,__FUNCTION__);
        return BSP_ERROR;
    }

    return BSP_OK;
}

static ULONG GetMyMapInfos(UCHAR ucType, ULONG dwStartAddr, ULONG dwEndAddr, T_BakBlk_MapHead *ptHead, T_BakBlk_MapInfo *ptMyInfo)
{
    ULONG ulRetVal = 0;
    
    INPUT_POINTER_CHECK_RETURN_VAL(ptHead, E_BAKBLK_RET_EMPTY)
    INPUT_POINTER_CHECK_RETURN_VAL(ptMyInfo, E_BAKBLK_RET_EMPTY)

    if(BSP_OK != GetBakBlkMapInfoFromFlash(ptHead, 0) || BSP_OK != CheckBakBlkHead(ptHead))
    {
        if(BSP_OK != GetBakBlkMapInfoFromFlash(ptHead, 1) || BSP_OK != CheckBakBlkHead(ptHead))
        {
            printf("line%d %s CheckBakBlkHead 1+1 failed\n",__LINE__,__FUNCTION__);
            return E_BAKBLK_RET_EMPTY;
        }
    }

    #ifdef LOADVERSION_PLUS_DEBUG
    printf("line%d %s,before found\n",__LINE__,__FUNCTION__);
    printf("protect_head:\n");
    BakBlkMapInfoPrintf((T_BakBlk_MapInfo*)(ptHead+1), 1);
    printf("protect_ver:\n");
    BakBlkMapInfoPrintf(((T_BakBlk_MapInfo*)(ptHead+1)+1), s_ulBakBlkMaxNum - 1);
    #endif

    ulRetVal = GetBakBlks(ucType, dwStartAddr, dwEndAddr, (T_BakBlk_MapInfo *)(ptHead + 1), ptMyInfo);

    return ulRetVal;
}

static ULONG BootCheckBakblkAddr(UCHAR ucType, T_BakBlk_MapInfo *ptMyInfo)
{
    if(PROTECT_HEAD == ucType)
    {
        if( ptMyInfo->dwBakBlkAddr != BootGetVerProtectBakBlkAddr() + s_ulProtectBlkSize && 
            ptMyInfo->dwBakBlkAddr != BootGetVerProtectBakBlkAddr() + BootGetProtectBakBlkSpaceSize() + s_ulProtectBlkSize )
        {
            return BSP_ERROR;
        }
    }
    else{
        if( (ptMyInfo->dwBakBlkAddr < BootGetVerProtectBakBlkAddr() + 2*s_ulProtectBlkSize || 
            ptMyInfo->dwBakBlkAddr >= BootGetVerProtectBakBlkAddr() + BootGetProtectBakBlkSpaceSize()) &&
            (ptMyInfo->dwBakBlkAddr < BootGetVerProtectBakBlkAddr() + BootGetProtectBakBlkSpaceSize() + 2*s_ulProtectBlkSize || 
            ptMyInfo->dwBakBlkAddr >= BootGetVerProtectBakBlkAddr() + 2*BootGetProtectBakBlkSpaceSize()) )
        {
            return BSP_ERROR;
        }
    }

    return BSP_OK;
}

static ULONG BootGetCompleteDataWithBakBlk(UCHAR ucType, UCHAR *data, ULONG dwDataLen, T_BakBlk_MapInfo *ptMyInfo, ULONG dwStartAddr)
{
    UCHAR *buffer = NULL;
    ULONG ulRet = 0;
    ULONG ulBufferSize = 0;

    INPUT_POINTER_CHECK_RETURN_VAL(data, BSP_ERROR)
    INPUT_POINTER_CHECK_RETURN_VAL(ptMyInfo, BSP_ERROR)

    ulBufferSize = dwDataLen > s_ulProtectBlkSize ? s_ulProtectBlkSize : dwDataLen;
    buffer = malloc(ulBufferSize);
    if (!buffer) 
    {
        printf("line%d %s buffer malloc error!\n",__LINE__,__FUNCTION__);
        return BSP_ERROR;
    }

    for(UINT32 BakBlkIndex = 0; BakBlkIndex < s_ulBakBlkMaxNum; BakBlkIndex++)
    {
        if(E_BAKBLK_RET_EMPTY == ptMyInfo[BakBlkIndex].dwBakBlkStatus)
        {
            debug("line%d %s\n",__LINE__,__FUNCTION__);
            return BSP_OK;
        }

        if(BSP_OK != BootCheckBakblkAddr(ucType, &ptMyInfo[BakBlkIndex]))
        {
            #ifdef LOADVERSION_PLUS_DEBUG
            printf("line%d %s BootCheckBakblkAddr failed!\n",__LINE__,__FUNCTION__);
            #endif
            return BSP_ERROR;
        }

        ulRet = BspFlashRead(ptMyInfo[BakBlkIndex].dwBakBlkAddr, buffer, ulBufferSize);
        if (ulRet != BSP_OK)
        {
            printf("line%d %s BspFlashRead failed!\n",__LINE__,__FUNCTION__);
            return BSP_ERROR;
        }

        zte_memcpy_s((data + (ptMyInfo[BakBlkIndex].dwProzBlkAddr - dwStartAddr)), dwDataLen, buffer, ulBufferSize);
    }

    free(buffer);
    return BSP_OK;
}

static int BspReadFromFlashWithBakBlk(UCHAR ucType, ULONG dwStartAddr, UCHAR *data, ULONG dwDataLen)
{
    T_BakBlk_MapHead *ptHead = NULL;
    T_BakBlk_MapInfo *ptMyInfo = NULL;
    ULONG ulRet = BSP_OK;
    ULONG ulBakRet = E_BAKBLK_RET_EMPTY;

    ulRet = BakBlkMapInfoInit(&ptHead, &ptMyInfo);
    if(ulRet != BSP_OK)
    {
        printf("line%d %s bakblk_mapinfo_init failed!\n",__LINE__,__FUNCTION__);
        BakBlkMapInfoRelease(&ptHead, &ptMyInfo);
        return BSP_ERROR;
    }
    
    ulBakRet = GetMyMapInfos(ucType, dwStartAddr, (dwStartAddr + dwDataLen), ptHead, ptMyInfo);
    if(E_BAKBLK_RET_INVALID == ulBakRet)
    {
        printf("line%d %s GetMyMapInfos failed!\n",__LINE__,__FUNCTION__);
        BakBlkMapInfoRelease(&ptHead, &ptMyInfo);
        return BSP_ERROR;
    }

    #ifdef LOADVERSION_PLUS_DEBUG
    debug("line%d %s,after found\n",__LINE__,__FUNCTION__);
    BakBlkMapInfoPrintf(ptMyInfo, s_ulBakBlkMaxNum);
    #endif

    ulRet = BspFlashRead(dwStartAddr, data, dwDataLen);
    if (ulRet != BSP_OK)
    {
        zte_printf_s(" pcImgBuf INFO READ wrong!!\n");
        BakBlkMapInfoRelease(&ptHead, &ptMyInfo);
        return BSP_ERROR;
    }

    debug("line%d %s,ulBakRet = %d\n",__LINE__,__FUNCTION__,ulBakRet);

    if(E_BAKBLK_RET_VALID == ulBakRet)
    {
        ulRet = BootGetCompleteDataWithBakBlk(ucType, data, dwDataLen, ptMyInfo, dwStartAddr);
        if(ulRet != BSP_OK)
        {
            printf("line%d %s BootGetCompleteDataWithBakBlk failed!\n",__LINE__,__FUNCTION__);
            BakBlkMapInfoRelease(&ptHead, &ptMyInfo);
            return BSP_ERROR;
        }
    }

    BakBlkMapInfoRelease(&ptHead, &ptMyInfo);
    return BSP_OK;
}

static T_VerProtectHead* BootGetProtectPlusHeadFromFlash(ULONG ulProZoneAddrOffset)
{
    ULONG ulProtectHeadLen = sizeof(T_VerProtectHead);
    T_VerProtectHead *ptVerProtectHead = NULL;

    ptVerProtectHead = (T_VerProtectHead *)malloc(ulProtectHeadLen);
    zte_printf_s("ptVerProtextHead = 0x%x \n", (ULONG)ptVerProtectHead);
    if (NULL == ptVerProtectHead)
    {
        zte_printf_s("malloc error!!\n");
        return NULL;
    }

    zte_memset_s(ptVerProtectHead, ulProtectHeadLen, 0, ulProtectHeadLen);

    if (BspReadFromFlashWithBakBlk(PROTECT_HEAD, ulProZoneAddrOffset, (UCHAR *)ptVerProtectHead, ulProtectHeadLen) != BSP_OK)
    {
        zte_printf_s(" T_VerProtectHead INFO READ wrong!!\n");
        free((void*)ptVerProtectHead);
        ptVerProtectHead = NULL;
        return NULL;
    }

    return ptVerProtectHead;
}

static CHAR* BootGetProtectPlusVerFromFlash(ULONG ulProZoneAddrOffset, T_VerProtectHead* ptVerProtectHead)
{
    CHAR *pcImgBuf = NULL;
    T_ProtectVerInfo *ptVerInfo = NULL;
    ULONG ulVerSize = 0;
    ULONG ulVerOffSet = 0;

    if(NULL == ptVerProtectHead)
    {
        printf("line%d %s\n",__LINE__,__FUNCTION__);
        return NULL;
    }
    /*根据版本信息，获取保护区版本长度和偏移地址*/
    #if defined(CONFIG_SECURITY)
    ptVerInfo = &(ptVerProtectHead->tVerInfo[1]);
    #else
    ptVerInfo = &(ptVerProtectHead->tVerInfo[0]);
    #endif
    /*ulVerSize:cur.swv 的长度，注意 大小端转换*/
    ulVerSize = ptVerInfo->tVerInfoFile.ulSWLength;

    /*ulVerOffSet : 保护区版本头占用的大小256KB，注意 大小端转换*/
    ulVerOffSet = ptVerInfo->ulVerOffSet;

    if (0 != (ulVerOffSet % s_ulProtectBlkSize))
    {
        zte_printf_s("CPU version offset error, ulVerOffSet = 0x%x, ", ulVerOffSet);
        zte_printf_s("FLASH_ERASE_SIZE =0x%x\n", s_ulProtectBlkSize);
        /*设置CRC校验出错错误*/
        BspSetCpuVerErrReason(g_ucRunVer, BSP_FLASH_PROTECT_READ_ERROR);
        return NULL;
    }

    if (ulVerSize > BootGetVerProtectSwvLen())
    {
        zte_printf_s("CPU version length is 0x%x is oversize\n", ulVerSize);
        BspSetCpuVerErrReason(g_ucRunVer, BSP_FLASH_PROTECT_READ_ERROR);
        return NULL;
    }

    pcImgBuf = (CHAR*)malloc(ulVerSize);
    if (NULL == pcImgBuf)
    {
        printf("line%d %s malloc pcImgBuf failed!\n",__LINE__,__FUNCTION__);
        return NULL;
    }

    if (BspReadFromFlashWithBakBlk(VERSION_DATA, ulProZoneAddrOffset + ulVerOffSet, (UCHAR*)pcImgBuf, ulVerSize) != BSP_OK)
    {
        zte_printf_s(" pcImgBuf INFO READ wrong!!\n");
        free((void*)pcImgBuf);
        pcImgBuf = NULL;
        BspSetCpuVerErrReason(g_ucRunVer, BSP_FLASH_PROTECT_READ_ERROR);
        return NULL;
    }

    return pcImgBuf;
}

STATUS checkProtectVersionPlus(void)
{
    T_VerProtectHead *ptVerProtectHead = NULL;
    T_ProtectVerInfo *ptVerInfo = NULL;
    ULONG ulVerSize = 0;
    #ifndef CONFIG_CRC_CPU_ONLY
    ULONG ulCalCRCResult = 0;
    T_ProtectVerInfoHead *ptVerInfoHead = NULL;
    #endif
    INT iRetVal = BSP_OK;
    ULONG ulProZoneAddrOffset;
    CHAR *pcImgBuf;

    /*设置保护区启动标志*/
    zte_printf_s("\n*************************************************\n");
    zte_printf_s("\n*******load file from flash protect......********\n");
    zte_printf_s("\n*************************************************\n");

    LoadversionPlusInit();

    ulProZoneAddrOffset = BootGetFlashVerProtectAddr(); /*拿到保护区偏移地址*/

    ptVerProtectHead = BootGetProtectPlusHeadFromFlash(ulProZoneAddrOffset);
    if(!ptVerProtectHead)
    {
        return BSP_ERROR;
    }
    /*  等待确认保护区版本头头信息 */
    zte_printf_s("\nsuccess!\n");

    #ifndef CONFIG_CRC_CPU_ONLY
    ptVerInfoHead = &(ptVerProtectHead->tVerInfoFileHead);
    zte_printf_s("Calculate ProtectVerInfoHead CRC ......\n");

    /*校验 版本头*/
    ulCalCRCResult = CalculateCRC16(CRC_MASK, (UCHAR *)ptVerProtectHead + sizeof(T_ProtectVerInfoHead), (sizeof(T_VerProtectHead) - sizeof(T_ProtectVerInfoHead)));
    if (ptVerInfoHead->ulCRC != ulCalCRCResult)
    {
        zte_printf_s("Ver Protect Head CRC error!!!!\n");
        /*设置CRC校验出错错误*/
        BspSetCpuVerErrReason(g_ucRunVer, BSP_FLASH_PROTECT_HEAD_CRC_ERROR);
        iRetVal = BSP_ERROR;
        goto return1;
    }
    else if (0 == ulCalCRCResult)
    {
        /* CRC为0的时候再校验一下数据是否全0，全0也认为CRC错误 */
        if (BSP_OK == CheckBufAllZero(&(ptVerProtectHead->tVerInfo[0]), (sizeof(T_VerProtectHead) - sizeof(T_ProtectVerInfoHead))))
        {
            zte_printf_s("Ver Protect Head CRC error!! File all zero!!\n");
            /*设置CRC校验出错错误*/
            BspSetCpuVerErrReason(g_ucRunVer, BSP_FLASH_PROTECT_HEAD_CRC_ERROR);
            iRetVal = BSP_ERROR;
            goto return1;
        }
    }
    #endif
    
    pcImgBuf = BootGetProtectPlusVerFromFlash(ulProZoneAddrOffset, ptVerProtectHead);
    if(!pcImgBuf)
    {
        iRetVal = BSP_ERROR;
        goto return1;
    }
    zte_printf_s("\n read ok!!\n");

    /*根据版本信息，获取保护区版本长度和偏移地址*/
    #if defined(CONFIG_SECURITY)
    ptVerInfo = &(ptVerProtectHead->tVerInfo[1]);
    #else
    ptVerInfo = &(ptVerProtectHead->tVerInfo[0]);
    #endif
    /*ulVerSize:cur.swv 的长度，注意 大小端转换*/
    ulVerSize = ptVerInfo->tVerInfoFile.ulSWLength;

    iRetVal = ldFileFromRam((UCHAR*)pcImgBuf, ulVerSize);
    if (BSP_OK != iRetVal)
    {
        iRetVal = BSP_ERROR;
        goto return2;
    }

return2:
    free(pcImgBuf);
    pcImgBuf = NULL;
return1:
    free(ptVerProtectHead);
    ptVerProtectHead = NULL;
    
    return iRetVal;
}

#ifdef LOADVERSION_PLUS_DEBUG   /* 测试用接口 */
extern ULONG BootGetVerHeader(const char *pcFileName, T_VerFileHeader *ptVerFileHeader);
extern ULONG BootSlowCopyFileToFlash(CHAR *pucSrcFile, ULONG ulFlashAddr);
extern ULONG BootCalculateFlashVerCrc(ULONG ulFlashAddr, ULONG ulVerLen, ULONG *pulCrc);

static ULONG UpdateBakBlkMapInfo(ULONG dwBadBlkAddr, T_BakBlk_MapInfo *ptSrcInfo, T_BakBlk_MapInfo *ptMyInfo, ULONG BakBlkIndexStart, ULONG BakBlkNum)
{
    INPUT_POINTER_CHECK_RETURN_VAL(ptSrcInfo, E_BAKBLK_RET_INVALID)
    INPUT_POINTER_CHECK_RETURN_VAL(ptMyInfo, E_BAKBLK_RET_INVALID)

    for(UINT32 BakBlkIndex = BakBlkIndexStart; BakBlkIndex < BakBlkIndexStart + BakBlkNum && BakBlkIndex < s_ulBakBlkMaxNum; BakBlkIndex++)
    {
        if(ptSrcInfo[BakBlkIndex].dwBakBlkStatus != E_BAKBLK_EMPTY)
        {
            if(dwBadBlkAddr == ptSrcInfo[BakBlkIndex].dwProzBlkAddr)
            {
                if(ptSrcInfo[BakBlkIndex].dwBakBlkStatus == E_BAKBLK_INVALID)
                {
                    return E_BAKBLK_RET_INVALID;
                }
                else if(ptSrcInfo[BakBlkIndex].dwBakBlkStatus == E_BAKBLK_1STMAP)
                {
                    ptSrcInfo[BakBlkIndex].dwBakBlkStatus = E_BAKBLK_2NDMAP;
                    ptSrcInfo[BakBlkIndex].dwBakBlkAddr += BootGetProtectBakBlkSpaceSize();
                    zte_memcpy_s(ptMyInfo, sizeof(T_BakBlk_MapInfo), &ptSrcInfo[BakBlkIndex], sizeof(T_BakBlk_MapInfo));
                    return E_BAKBLK_2NDMAP;
                }
                else if(ptSrcInfo[BakBlkIndex].dwBakBlkStatus == E_BAKBLK_2NDMAP)
                {
                    ptSrcInfo[BakBlkIndex].dwBakBlkStatus = E_BAKBLK_INVALID;
                    return E_BAKBLK_RET_INVALID;
                }
            }
        }
        else{
            ptSrcInfo[BakBlkIndex].dwBakBlkStatus = E_BAKBLK_1STMAP;
            ptSrcInfo[BakBlkIndex].dwProzBlkAddr = dwBadBlkAddr;
            ptSrcInfo[BakBlkIndex].dwBakBlkAddr = BootGetVerProtectBakBlkAddr() + s_ulProtectBlkSize + s_ulProtectBlkSize*BakBlkIndex;
            zte_memcpy_s(ptMyInfo, sizeof(T_BakBlk_MapInfo), &ptSrcInfo[BakBlkIndex], sizeof(T_BakBlk_MapInfo));
            return E_BAKBLK_RET_1STMAP;
        }
    }

    return E_BAKBLK_RET_INVALID;
}

static ULONG ReqBakBlk(UCHAR ucType, ULONG dwBadBlkAddr, T_BakBlk_MapInfo *ptSrcInfo, T_BakBlk_MapInfo *ptMyInfo)
{
    ULONG ulRet = BSP_OK;

    INPUT_POINTER_CHECK_RETURN_VAL(ptSrcInfo, E_BAKBLK_RET_INVALID)
    INPUT_POINTER_CHECK_RETURN_VAL(ptMyInfo, E_BAKBLK_RET_INVALID)

    if(dwBadBlkAddr < BootGetFlashVerProtectAddr() || dwBadBlkAddr > BootGetFlashVerProtectAddr() + BootGetVerProtectSwvLen())
        return E_BAKBLK_RET_INVALID;

    if(ucType == PROTECT_HEAD)
    {
        ulRet = UpdateBakBlkMapInfo(dwBadBlkAddr, ptSrcInfo, ptMyInfo, 0, 1);
    }
    else{
        ulRet = UpdateBakBlkMapInfo(dwBadBlkAddr, ptSrcInfo, ptMyInfo, 1, s_ulBakBlkMaxNum - 1);
    }

    return ulRet;
}

static ULONG WriteProtectVerToBakBlk(UCHAR* data, T_BakBlk_MapInfo *ptMyInfo)
{
    UINT32 ulRet = BSP_OK;
    ULONG ulProZoneAddrOffset = 0;
    
    ulProZoneAddrOffset = BootGetFlashVerProtectAddr();

    ulRet = BspFlashWrite(ptMyInfo->dwBakBlkAddr, data + (ptMyInfo->dwProzBlkAddr - ulProZoneAddrOffset), s_ulProtectBlkSize);
    if (ulRet != BSP_OK) 
    {
        return BSP_ERROR;
    }

    return BSP_OK;
}

ULONG WriteBakBlkMapHeadToFlash(T_BakBlk_MapInfo *ptSrcInfo)
{
    ULONG ulRet = BSP_OK;
    T_BakBlk_MapHead *ptHead;

    UINT32 len1 = sizeof(T_BakBlk_MapHead) + sizeof(T_BakBlk_MapInfo) * s_ulBakBlkMaxNum;
    UINT32 len2 = sizeof(T_BakBlk_MapInfo) * s_ulBakBlkMaxNum;

    ptHead =(T_BakBlk_MapHead *)calloc(len1,sizeof(char));
    if(ptHead == NULL)
    {
        return BSP_ERROR;
    }

    zte_memcpy_s(ptHead + 1, len2, ptSrcInfo, len2);

    // 计算并验证CRC
    ptHead->version = 0x01010101;
    ptHead->crc = CalculateCRC16(CRC_MASK, (UCHAR *)ptHead + sizeof(ptHead->magic) + sizeof(ptHead->crc), 
                        sizeof(T_BakBlk_MapHead) - sizeof(ptHead->magic) - sizeof(ptHead->crc) + 
                        sizeof(T_BakBlk_MapInfo) * s_ulBakBlkMaxNum);
    ptHead->magic = macro_BAKBLK_MAGIC;
    

    ulRet = BspFlashWrite(BootGetVerProtectBakBlkAddr(), (UCHAR*)ptHead, len1);
    if (ulRet != BSP_OK) 
    {
        printf("First BakBlk Head write error\n");
    }

    ulRet |= BspFlashWrite(BootGetVerProtectBakBlkAddr() + BootGetProtectBakBlkSpaceSize(), (UCHAR*)ptHead, len1);
    if (ulRet != BSP_OK) 
    {
        printf("Second BakBlk Head write error\n");
        free(ptHead);
        return BSP_ERROR;
    }

    free(ptHead);
    return BSP_OK;
}

void GetBakBlkMapHeadFromFlash()
{
    T_BakBlk_MapHead *ptHead = NULL;
    ULONG len = sizeof(T_BakBlk_MapHead) + sizeof(T_BakBlk_MapInfo) * s_ulBakBlkMaxNum;

    ptHead =(T_BakBlk_MapHead *)calloc(1,len);
    if(ptHead == NULL)
    {
        printf("line%d %s error!\n",__LINE__,__FUNCTION__);
        return;
    }

    if(BSP_OK != GetBakBlkMapInfoFromFlash(ptHead, 0) || BSP_OK != CheckBakBlkHead(ptHead))
    {
        if(BSP_OK != GetBakBlkMapInfoFromFlash(ptHead, 1) || BSP_OK != CheckBakBlkHead(ptHead))
        {
            free(ptHead);
            ptHead = NULL;
            return;
        }
    }

    BakBlkMapHeadPrintf(ptHead);
    printf("protect_head:\n");
    BakBlkMapInfoPrintf((T_BakBlk_MapInfo*)(ptHead+1), 1);
    printf("protect_ver:\n");
    BakBlkMapInfoPrintf(((T_BakBlk_MapInfo*)(ptHead+1)+1), s_ulBakBlkMaxNum - 1);

    free(ptHead);
    ptHead = NULL;
    return;
}

ULONG BadBlockSimulation(UCHAR ucType, ULONG dwBadBlkAddr, T_BakBlk_MapInfo *ptSrcInfo, T_BakBlk_MapInfo *ptMyInfo, UCHAR *data)
{
    INPUT_POINTER_CHECK_RETURN_VAL(ptSrcInfo, BSP_ERROR)
    INPUT_POINTER_CHECK_RETURN_VAL(ptMyInfo, BSP_ERROR)

    if(E_BAKBLK_RET_INVALID == ReqBakBlk(ucType, dwBadBlkAddr, ptSrcInfo, ptMyInfo))
    {
        printf("line%d %s failed\n",__LINE__,__FUNCTION__);
        return BSP_ERROR;
    }
    if(BSP_OK != WriteProtectVerToBakBlk(data, ptMyInfo))
    {
        printf("line%d %s failed\n",__LINE__,__FUNCTION__);
        return BSP_ERROR;
    }
    if(BSP_OK != BspFlashErase(ptMyInfo->dwProzBlkAddr, s_ulProtectBlkSize))
    {
        printf("line%d %s failed\n",__LINE__,__FUNCTION__);
        return BSP_ERROR;
    }

    return BSP_OK;
}

ULONG LoadversionPlusTestInit(T_BakBlk_MapInfo **pptSrcInfo, T_BakBlk_MapInfo **pptMyInfo)
{
    if(BSP_OK != LoadversionPlusInit())
        return BSP_ERROR;
    
    UINT32 len1 = sizeof(T_BakBlk_MapInfo) * s_ulBakBlkMaxNum;
    UINT32 len2 = sizeof(T_BakBlk_MapInfo);

    *pptSrcInfo =(T_BakBlk_MapInfo *)calloc(1,len1);
    if(*pptSrcInfo == NULL)
    {
        return BSP_ERROR;
    }

    *pptMyInfo =(T_BakBlk_MapInfo *)calloc(1,len2);
    if(*pptMyInfo == NULL)
    {
        free(*pptSrcInfo);
        *pptSrcInfo = NULL;
        return BSP_ERROR;
    }

    return BSP_OK;
}

static UINT32 BootCopyAndCheckRunVerToProtect(CHAR *acSrcFileName, UINT32 ulSrcFileLen, T_ProtectVerInfo *ptVerInfo)
{
    BYTE ucLoop = 0;
    UINT32  ulRetVal = BSP_OK;
    UINT32  ulProtectAddr = 0;
    UINT32  ulProtectVerCrc = 0;
    UINT32  ulCalCrc = 0;

    INPUT_POINTER_CHECK(acSrcFileName);
    INPUT_POINTER_CHECK(ptVerInfo);

    ulProtectAddr = BootGetFlashVerProtectAddr();
    for(ucLoop = 0; ucLoop < 3; ucLoop++)
    {
        ulRetVal = BootSlowCopyFileToFlash((CHAR *)acSrcFileName, (ulProtectAddr + ptVerInfo->ulVerOffSet));
        if (BSP_OK != ulRetVal)
        {
            dbgInfo("copy file <%s> to flash times %d failed! reason: %d\n", acSrcFileName, ucLoop, ulRetVal);
            BspSysMsDelay(200);  
            continue;
        }

        /* 写flash完毕再对flash中的版本进行CRC校验 */
        if (BSP_OK != BspFlashRead((ulProtectAddr + ptVerInfo->ulVerOffSet), (UCHAR *)&ulProtectVerCrc, sizeof(UINT32)))
        {
            BspSysMsDelay(200);
            dbgErr("BspFlashRead Failed! time: %d\n", ucLoop);
            continue;
        }

        BspSysMsDelay(1000);
        if ( BSP_OK != BootCalculateFlashVerCrc((ulProtectAddr + ptVerInfo->ulVerOffSet + sizeof(UINT32)), (ulSrcFileLen - sizeof(UINT32)), &ulCalCrc) )
        {
            BspSysMsDelay(200);
            dbgInfo("Check Flash Crc Failed! time: %d\n", ucLoop);
            continue;
        }
        
        ulProtectVerCrc = ntohl(ulProtectVerCrc);
      
        if (ulProtectVerCrc != ulCalCrc)
        {
            dbgInfo("Crc check Failed!, Head: %d, Calculate: %d!\n", ulProtectVerCrc, ulCalCrc);
            continue;
        }
        else
        {
            break;
        }
    }
    
    if (3 == ucLoop)
    {
        dbgErr("copy file <%s> to flash failed!\n", acSrcFileName);
        return BSP_ERROR;
    }

    return BSP_OK;
}

UINT32 BootCopyRunVerToProtectPlus(UINT32 ulIndex, T_VerProtectHead *ptProtectHead)
{
    UINT32  ulRetVal              = BSP_OK;
    UINT32  ulSrcFileLen          = 0;
    UINT32  ulProtectAddr         = 0;
    UINT32  ulProtectLen          = 0;
    UINT32  ulProtectHeadFlashLen = 0;
    UINT32  ulPreVerOffset           = 0;
    UINT32  ulPreVerFileLen          = 0;
    UINT32  ulFlashSection        = 0;
    time_t  ulWriteFlashTime      = 0;
    time_t timeRet                = 0;
    T_ProtectVerInfoHead *ptVerInfoHead = NULL;
    T_ProtectVerInfo     *ptVerInfo     = NULL;
    T_VerFileHeader       tSwFileHead;
    CHAR   acSrcFileName[32] ={0};
    struct stat tStatInfo;
    STATUS status;

    INPUT_POINTER_CHECK(ptProtectHead);

    BootGetProtectBlkSize(&ulFlashSection);

    if(0 == ulIndex)
    {
        if(snprintf_s(acSrcFileName,32,"/ata/rru/cur.swv") < 0)
        {
            dbgErr("%s>>snprintf error ![line:%d]\n",__FUNCTION__,__LINE__);
            return BSP_ERROR;
        }
    }
    else
    {
        if(snprintf_s(acSrcFileName,32,"/ata/rru/cur%d.swv",ulIndex) < 0)
        {
            dbgErr("%s>>snprintf error ![line:%d]\n",__FUNCTION__,__LINE__);
            return BSP_ERROR;
        }
    }

    /* 获取运行版本文件长度 */
    status = stat(acSrcFileName, &tStatInfo);
    if(0!= status)
    {
        dbgErr("File:%s not exist!!\n",acSrcFileName);
        return BSP_ERROR;
    }
    ulSrcFileLen = tStatInfo.st_size;
    /* 读取运行版本文件头 */
    memset(&tSwFileHead, 0, sizeof(T_VerFileHeader));
    ulRetVal = BootGetVerHeader(acSrcFileName, &tSwFileHead);
    if (BSP_OK != ulRetVal)
    {
        dbgInfo("Get file <%s> head failed!, reason: %d", acSrcFileName, ulRetVal);
        return BSP_ERROR;
    }

    /* 获取写flash时间 */
    timeRet = time(&ulWriteFlashTime);
    TIME_CHECK(timeRet);

    //ptVerInfoHead = (T_ProtectVerInfoHead *)ptProtectHead;
    //ptVerInfo     = (T_ProtectVerInfo *)(ptVerInfoHead + 1);

   /* 获取保护区头信息 */
    ulProtectLen          = BootGetVerProtectLen();
    ulProtectAddr         = BootGetFlashVerProtectAddr();
    ulProtectHeadFlashLen = (1 + sizeof(T_VerProtectHead)/ulFlashSection) * ulFlashSection;
    /* 刷写保护区第一个版本 */
    ptVerInfoHead = (T_ProtectVerInfoHead *)ptProtectHead;
    if (ptVerInfoHead->ucReserve[1] == 0)
    {
        ptVerInfo     = (T_ProtectVerInfo *)(ptVerInfoHead + 1);  
        ptVerInfo->ulVerOffSet = ulProtectHeadFlashLen;
    }
    else
    {
        //coverity[cert_exp39_c_violation:SUPPRESS]
        if( ptVerInfoHead->ucReserve[1]>=PROTECT_FILES_NUM_MAX)/*文件已满，无法再加*/
       {
            dbgErr("%s>>protect files space is full !\n",__FUNCTION__);
            return BSP_ERROR;
       }
        ptVerInfo     = (T_ProtectVerInfo *)(ptVerInfoHead + 1)+(ptVerInfoHead->ucReserve[1])-1;

        /* 获取前一个版本的偏移和文件长度 */
        ulPreVerOffset  = ptVerInfo->ulVerOffSet;
        ulPreVerFileLen = ptVerInfo->tVerInfoFile.ulSWLength;
        /*计算当前版本偏移*/
        ptVerInfo++;
        ptVerInfo->ulVerOffSet = (1 + (ulPreVerOffset + ulPreVerFileLen)/ulFlashSection) * ulFlashSection;
    }

    ptVerInfo->tVerInfoFile.ulSWLength               = ulSrcFileLen;
    ptVerInfo->tVerInfoFile.ulCreateTime             = ulWriteFlashTime;
    ptVerInfo->tVerInfoFile.ulCRC32                  = tSwFileHead.ulCRC32;
    ptVerInfo->tVerInfoFile.tFILESWINF.ulSoftType    = tSwFileHead.ulSoftType;
    ptVerInfo->tVerInfoFile.tFILESWINF.ucCpuType     = tSwFileHead.ucCpuType;
    ptVerInfo->tVerInfoFile.tFILESWINF.ucVersionKind = (UCHAR)ulIndex;

    if(ulIndex==0)
    {
        if(snprintf_s(ptVerInfo->tVerInfoFile.acFileName,32,"cur.swv") < 0)
        {
            dbgErr("%s>>snprintf error ![line:%d]\n",__FUNCTION__,__LINE__);
            return BSP_ERROR;
        }
    }
    else
    {
        if(snprintf_s(ptVerInfo->tVerInfoFile.acFileName,32,"cur%d.swv", ulIndex) < 0)
        {
            dbgErr("%s>>snprintf error ![line:%d]\n",__FUNCTION__,__LINE__);
            return BSP_ERROR;
        }
    }
    memcpy(ptVerInfo->tVerInfoFile.tFILESWINF.acVersionNo, tSwFileHead.ucVerNo, VERNO_LEN);
    ptVerInfoHead->ucReserve[1] = ptVerInfoHead->ucReserve[1]+1;/*保护区文件个数+1*/
    ptVerInfoHead->ulCRC = BspCountCrc16(0xFFFF, (UCHAR *)ptProtectHead + sizeof(T_ProtectVerInfoHead), sizeof(T_VerProtectHead) - sizeof(T_ProtectVerInfoHead));
 
    dbgInfo("ulProtectAddr : %x, ulVerOffSet: 0x%x, ulSWLength : %d, ulCRC32 : 0x%x,ulWriteFlashTime: %d, ucSwClass: %d, acFileName: %s, acVersionNo: %s, fileNum: %d\n",
        ulProtectAddr, ptVerInfo->ulVerOffSet, ptVerInfo->tVerInfoFile.ulSWLength,
        ptVerInfo->tVerInfoFile.ulCRC32, ptVerInfo->tVerInfoFile.ulCreateTime, 
        ptVerInfo->tVerInfoFile.tFILESWINF.ucVersionKind,ptVerInfo->tVerInfoFile.acFileName, ptVerInfo->tVerInfoFile.tFILESWINF.acVersionNo,ptVerInfoHead->ucReserve[1]);

    /* 偏移加上文件长度不能超过保护区长度 */
    if ((ptVerInfo->ulVerOffSet + ulSrcFileLen) > ulProtectLen)
    {
        dbgErr("error!file <%s> length <%d> append offset <%d> is larger the and protect length <%d>!\n",
            acSrcFileName, ulSrcFileLen, ptVerInfo->ulVerOffSet, ulProtectLen);
        return BSP_ERROR;
    }

    /* 写版本文件 */
    ulRetVal = BootCopyAndCheckRunVerToProtect(acSrcFileName, ulSrcFileLen, ptVerInfo);
    
    return ulRetVal;
}

UINT32 BootFlushMiniSetVerToProtect(VOID)
{
    T_VerProtectHead* ptProtectHead = NULL;
    UINT32  ulProtectAddr = 0;
    UINT32 ulFlashSection = 0;

    ulProtectAddr = BootGetFlashVerProtectAddr();
    BootGetProtectBlkSize(&ulFlashSection);

    ptProtectHead = (T_VerProtectHead*)malloc(sizeof(T_VerProtectHead));
    if(NULL == ptProtectHead)
    {
        printf("line%d %s failed\n",__LINE__,__FUNCTION__);
        return BSP_ERROR;
    }
    memset((UCHAR *)ptProtectHead, 0 ,sizeof(T_VerProtectHead));

    /*先刷写JSON文件,cur27.swv*/
    if(BSP_OK != BootCopyRunVerToProtectPlus(27, ptProtectHead))
    {
        free(ptProtectHead);
        printf("%s>>Copy cur27.swv to protect failed !\n", __FUNCTION__);
        return BSP_ERROR;
    }

    /*再刷写CPU 版本*/
    if(BSP_OK != BootCopyRunVerToProtectPlus(0, ptProtectHead))
    {
        free(ptProtectHead);
        printf("%s>>Copy cur.swv to protect failed !\n", __FUNCTION__);
        return BSP_ERROR;
    }
    
    /*再刷写cur3 版本*/
    if(BSP_OK != BootCopyRunVerToProtectPlus(3, ptProtectHead))
    {
        printf("%s>>Copy cur3.swv to protect failed !\n", __FUNCTION__);
    }

    /* 每次刷新保护区头之前先擦出保护区头 */
    if (BSP_OK != BspFlashErase(ulProtectAddr, ulFlashSection))
    {
        printf("Erease flash protect head failed!");
        free(ptProtectHead);
        return FALSE;
    }

    printf("copy done ,will flush protect head\n");
    /* 刷新完版本之后需要将版本信息及重新计算后的版本头CRC写到保护区头中 */

    printf("ulProtectHead : %x, ulCRC32 : 0x%x\n",ulProtectAddr, ptProtectHead->tVerInfoFileHead.ulCRC);

    if (BSP_OK != BspFlashWrite(ulProtectAddr, (UCHAR *)ptProtectHead, sizeof(T_VerProtectHead)))
    {
        printf("Write protect head flash error!");
        free(ptProtectHead);
        return FALSE;
    }
    free(ptProtectHead);
    printf("Flush Run Software to Flash succeed!\n");

    return BSP_OK;
}
#endif
/* Ended by AICoder, pid:mfff60e4a0745b41451908b997356772ef994323 */
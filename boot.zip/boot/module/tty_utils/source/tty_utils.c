#include <stdio.h>
#include <fcntl.h>
#include <unistd.h>
#include <termios.h>
#include <string.h>

int set_tty_settings(const char *dev_name, speed_t baud_rate, int data_bits, int stop_bits, int parity) 
{
    struct termios options;
    int fd;

    // 打开tty设备
    fd = open(dev_name, O_RDWR | O_NOCTTY);
    if (fd == -1) {
        perror("Error opening tty device");
        return -1;
    }

    // 获取当前tty设备的配置
    tcgetattr(fd, &options);

    // 设置tty设备的波特率
    cfsetispeed(&options, baud_rate);  // 输入波特率
    cfsetospeed(&options, baud_rate);  // 输出波特率

    // 设置数据位
    options.c_cflag &= ~CSIZE;  // 清除数据位设置
    switch (data_bits) {
        case 5:
            options.c_cflag |= CS5;  // 设置数据位为5位
            break;
        case 6:
            options.c_cflag |= CS6;  // 设置数据位为6位
            break;
        case 7:
            options.c_cflag |= CS7;  // 设置数据位为7位
            break;
        case 8:
            options.c_cflag |= CS8;  // 设置数据位为8位
            break;
        default:
            fprintf(stderr, "Invalid data bits\n");
            close(fd);
            return -1;
    }

    // 设置停止位
    if (stop_bits == 1) {
        options.c_cflag &= ~CSTOPB;  // 1位停止位
    } else if (stop_bits == 2) {
        options.c_cflag |= CSTOPB;  // 2位停止位
    } else {
        fprintf(stderr, "Invalid stop bits\n");
        close(fd);
        return -1;
    }

    // 设置校验位
    if (parity == 0) {
        options.c_cflag &= ~PARENB;  // 禁用奇偶校验
    } else if (parity == 1) {
        options.c_cflag |= PARENB;  // 启用奇偶校验
        options.c_cflag &= ~PARODD;  // 偶校验
    } else if (parity == 2) {
        options.c_cflag |= PARENB;  // 启用奇偶校验
        options.c_cflag |= PARODD;  // 奇校验
    } else {
        fprintf(stderr, "Invalid parity\n");
        close(fd);
        return -1;
    }

    // 应用新的tty设备配置
    tcsetattr(fd, TCSANOW, &options);

    return fd;
}

int send_data(int fd, const char* data, unsigned int data_len) 
{
    int bytes_written = write(fd, data, data_len);
    if (bytes_written == -1) {
        perror("Error writing to tty device");
        return -1;
    }

    return bytes_written;
}
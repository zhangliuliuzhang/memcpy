#ifndef TTY_UTILS_H
#define TTY_UTILS_H

#include <termios.h>
int set_tty_settings(const char *dev_name, speed_t baud_rate, int data_bits, int stop_bits, int parity);
int send_data(int fd, const char* data, unsigned int data_len);

#endif
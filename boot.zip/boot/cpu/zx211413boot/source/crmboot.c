/*****************************************************************************
* 版权所有(C) 2010, ZTE Corp. RRU Bsp Platform
*----------------------------------------------------------------------------
* 模 块 名 : BSP
* 文件名称 : dpdichal.c
* 文件标识 : {[N/A]}
* 内容摘要 : 实现dpdic的加速器配置
* 注意事项 : 无
* 作    者 : 郭勇
* 创建日期 : 2019-04-08
* 当前版本 : Ver1.0
*----------------------------------------------------------------------------
* 变更记录 :
*
* $记录1
* 变 更 单: $0000000(N/A)
* 责 任 人: 耿佳佳
* 修改日戳: 2015-10-22 08:28:34
* 变更说明: 创建文件
*
*----------------------------------------------------------------------------
*/


/* 标准库头文件 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "bsppub.h"
#include "bspcomm.h"
#include "crmboot.h"


static UINT32 g_CrmVirAddr = 0;

UINT32 BootCfgCrmAccessBaseAddr(UINT32 vir_addr)
{
    g_CrmVirAddr = vir_addr;
    return 0;
}

UINT32 BootRdIcCrmReg(UINT32 ulAddr)
{
    UINT32 ulRegAddr = 0;

    ulRegAddr = ulAddr + g_CrmVirAddr;

    return *((volatile UINT32 *)ulRegAddr);
}

UINT32 BootWrIcCrmReg(UINT32 ulAddr, UINT32 ulData)
{
    UINT32 ulRegAddr = 0;

    ulRegAddr = ulAddr + g_CrmVirAddr;

    *((volatile UINT32 *)ulRegAddr) = ulData;

    return BSP_OK;
}

#if 0

/* bootrom和bootapp 只复位了NTL的10,11*/
VOID BootRstL2ss()
{
    #ifdef BOOT_CRM_EN
    // bit0: NTL(983 post logic)
    BootWrIcCrmReg(CRM_ROE_RST_REG, BootRdIcCrmReg(CRM_ROE_RST_REG) & (~0x1));
    // bit1: NTLPPB; bit[19:18]: MAC10/11 TX; bit[31:30]: MAC10/11 RX
    BootWrIcCrmReg(CRM_NTL_RST_REG, BootRdIcCrmReg(CRM_NTL_RST_REG) & (~0xC00C0002));
    #endif
}

#endif

VOID BootRlsL2ssRst()
{
    #ifdef BOOT_CRM_EN
    // bit1: NTLPPB
    BootWrIcCrmReg(CRM_NTL_RST_REG, BootRdIcCrmReg(CRM_NTL_RST_REG) | 0x2);
    // bit0: NTL(983 post logic)
    BootWrIcCrmReg(CRM_ROE_RST_REG, BootRdIcCrmReg(CRM_ROE_RST_REG) | 0x1);
    #endif

}

VOID BootRlsXMACRst()
{
    #ifdef BOOT_CRM_EN
    BootWrIcCrmReg(CRM_NTL_RST_REG, BootRdIcCrmReg(CRM_NTL_RST_REG) | 0xC00C0000);
    #endif
}


VOID BootRlsPcsRst()
{
    #ifdef BOOT_CRM_EN
    BootWrIcCrmReg(CRM_PCS_RST_REG, 1);
    #endif
}


VOID BootRstWdt()
{
    UINT32 reg = 0;
    reg = BootRdIcCrmReg(CRM_RST_REG);
    reg &= (~(A53_WDT_RST));
    BootWrIcCrmReg(CRM_RST_REG,reg);

    usleep(10);

    reg |= (A53_WDT_RST);
    BootWrIcCrmReg(CRM_RST_REG,reg);
}


UINT32 BootSetKBootMSFlag(UINT32 flag)
{
    UINT32 reg;

    reg = BootRdIcCrmReg(CRM_DOUBLE_KEBOOT_FLAG_REG);
    reg &= (~0xff);
    reg |= flag;
    BootWrIcCrmReg(CRM_DOUBLE_KEBOOT_FLAG_REG,reg);
    return 0;
}

UINT8 BootGetKBootMSFlag()
{
    UINT32 reg = 0;
    reg = BootRdIcCrmReg(CRM_DOUBLE_KEBOOT_FLAG_REG);
    return reg & 0xff;
}


#if 0

UINT8 BootGetUBootMSFlag()
{
    UINT32 reg = 0;
    reg = BootRdIcCrmReg(CRM_DOUBLE_UBOOT_FLAG_REG);
    return (reg >> 24) & 0xff;
}

UINT8 BootGetUBootSplMSFlag()
{
    UINT32 reg = 0;
    reg = BootRdIcCrmReg(CRM_DOUBLE_UBOOT_SPL_FLAG_REG);
    return (reg >> 24) & 0xff;
}

#endif



#if 0
/*bootrom下没有开启tora0的时钟，这个要注意*/
VOID BootEnL2ssClk()
{
    #ifdef BOOT_CRM_EN
    BootWrIcCrmReg(CRM_NTL_COMMON_GATE_REG, BootRdIcCrmReg(CRM_NTL_COMMON_GATE_REG) | 0x3ff);
    BootWrIcCrmReg(CRM_NTL_TRI_GATE_REG, BootRdIcCrmReg(CRM_NTL_TRI_GATE_REG) | 0x1 );
    BootWrIcCrmReg(CRM_NTL_TROA1_GATE_REG, BootRdIcCrmReg(CRM_NTL_TROA1_GATE_REG) | 0x1 );
    #endif
}

UINT32 BootSetMiiClk()
{
    #ifdef BOOT_CRM_EN
    return BootWrIcCrmReg(CRM_MII_CLK_FRAC_REG, 0xff); /*400M/(reg+1)*/
    #endif
    return 0;
}

#endif

UINT32 BootGetRstReason()
{
    #ifdef BOOT_CRM_EN
    UINT32 rstVal1 = 0;
    UINT32 rstVal2 = 0;
    UINT32 rstVal = 0;
    UINT32 count = 0;
    while (1)
    {
        rstVal1 = BootRdIcCrmReg(CRM_RESET_RECORD_REG);
        rstVal2 = BootRdIcCrmReg(CRM_RESET_RECORD_REG);
        if (rstVal1 == rstVal2)
        {
            rstVal = rstVal1;
            break;
        }
        if (count == 5)
        {
            rstVal = rstVal2;
            break;
        }
        count = count + 1;
    }

    return rstVal;
    #else
    return SYSTEM_POWER_RST;  /*打桩，ADS单板无CRM直接返回上电复位*/
    #endif
}

/*是否是上电复位，bit16 =  1 上电复位，否则非上电复位*/
UINT32 BootGetSysPowerRst()
{

    if ( SYSTEM_POWER_RST == (BootGetRstReason() & SYSTEM_POWER_RST) )
    {
        return BSP_OK;
    }
    else
    {
        return BSP_ERROR;
    }
}

void BootSetM0MoniA53(void)
{
    BootWrIcCrmReg(CRM_M0_MONI_A53_UP_REG, 1);
}





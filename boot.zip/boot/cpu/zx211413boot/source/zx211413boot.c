/*****************************************************************************
* 版权所有(C) 2010, ZTE Corp. RRU Bsp Platform
*----------------------------------------------------------------------------
* 模 块 名 : BSP
* 文件名称 : zx211413boot.c
* 文件标识 : {[N/A]}
* 内容摘要 : zx211413 cpu bootapp接口实现
* 注意事项 : 无
* 作    者 : 耿佳佳
* 创建日期 : 2015-10-22 08:28:34
* 当前版本 : Ver1.0
*----------------------------------------------------------------------------
* 变更记录 :
*
* $记录1
* 变 更 单: $0000000(N/A)
* 责 任 人: 耿佳佳
* 修改日戳: 2015-10-22 08:28:34
* 变更说明: 创建文件
*
*----------------------------------------------------------------------------
*/

#include "stdio.h"
#include <sys/types.h>
#include <sys/stat.h>
#include <netinet/in.h>
#include <fcntl.h>
#include <errno.h>
#include "vxadp.h"
#include <math.h>

#include "bsppub.h"
#include "bspcomm.h"
//#include "ru_basetypes.h"
#include "bsperrcode.h"
#include "zx211413boot.h"
#include "phy.h"
#include "mii.h"
#include "gpio.h"
#include "l2ssboot.h"
#include "zx211413gpio.h"

#if defined(COMPILE_FOR_KEXEC_BOOT)
#include "bootadp.h"
#include "halboot.h"
#include "flash.h"

/*#else
#include "hal_addrmap.h"
#include "hal_regaddr.h"*/
#endif

#ifdef COMPILE_FOR_KEXEC_BOOT
/**************************************************************************
 *                        宏
 **************************************************************************/

#define MAC_FRAME_FILTER  (0x00000004)   /*MAC帧过滤寄存器 offset:0x0004 */
/* 单板复位开关变量，0--不复位，1--复位 */


/**************************************************************************
 *                         数据类型                                       *
 **************************************************************************/

/**************************************************************************
 *                         全局变量定义                                   *
 **************************************************************************/

/**************************************************************************
 *                         外部变量声明
 **************************************************************************/

/**************************************************************************
*                         局部函数声明
**************************************************************************/

/**************************************************************************
*                         全局函数声明
**************************************************************************/
extern VOID MainLoop ();
extern VOID BspFunction(unsigned char * ucpsymbname, unsigned char * ucpboardname);
extern UINT32 BootFlashInit(VOID);
extern UINT32 BootSoftModInit(VOID);
extern UINT32 BspGetPhyStatus(UINT32 ulDevNum, UINT32 *pulStat, UINT32 ulMode);

UINT32 SetDefaultCmdline();
UINT32 BootIcInit();
UINT8 g_icChipId = 0;
UINT32 g_qcell_type = PLATFORM_BOARDTYPE;
UINT32 g_iic1_is_serdes0 = IIC1_SERDES1;

/**************************************************************************
 *                         函数实现
 **************************************************************************/

#define uswap_32(x) \
    ((((x) & 0xff000000) >> 24) | \
     (((x) & 0x00ff0000) >>  8) | \
     (((x) & 0x0000ff00) <<  8) | \
     (((x) & 0x000000ff) << 24))

#define cpu_to_le32(x)        uswap_32(x)
#define dsb() __asm__ __volatile__ ("dsb" : : : "memory")
Tlist BoardPreCall_list     = {&(BoardPreCall_list),&(BoardPreCall_list)};
/*BspBoardPreInit的调用链表函数序号*/
static ULLONG sBoardInitError = 0;

UINT32 g_ulLedFlag = 0;
UINT32  g_ulRamReservedAddr =0;
UINT32  g_ulBootRegisterAddr =0;

static UINT32 aulWatchdogAddr =0;
static UINT32 aulMdioVirAddr = 0;
static UINT32 aulCrmVirAddr = 0;
static UINT32 aulPad0VirAddr = 0;
static UINT32 aulPad1VirAddr = 0;
static UINT32 aulScrVirAddr = 0;
static UINT32 aulL2ssVirAddr = 0;
static UINT32 aulPwmVirAddr = 0;


/**************读,写IC寄存器********************/
UINT32 BootRdIcScrReg(UINT32 ulAddr)
{
    UINT32 ulRegAddr = 0;

    ulRegAddr = ulAddr + aulScrVirAddr;

    return *((volatile UINT32 *)ulRegAddr);
}


UINT32 BootWrIcPwmReg(UINT32 ulAddr, UINT32 ulData)
{
    UINT32 ulRegAddr = 0;

    ulRegAddr = ulAddr + aulPwmVirAddr;

    *((volatile UINT32 *)ulRegAddr) = ulData;

    return BSP_OK;
}

UINT32 BootRdIcPwmReg(UINT32 ulAddr)
{
    UINT32 ulRegAddr = 0;

    ulRegAddr = ulAddr + aulPwmVirAddr;

    return *((volatile UINT32 *)ulRegAddr);
}


/*****************************************************************************
* 函数名称   : BspGetCpuType(*)
* 功能描述   : 双boot模块用于获取cpu类型
* 读全局变量 : 无
* 写全局变量 : 无
* 输入参数   : 无
* 输出参数   : 无
* 返 回 值   : 成功 - BSP_OK
* 其它说明   :
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), ty@2019-1-29 由IC2.0移植创建（添加了CPU类型）
*----------------------------------------------------------------------------
*/
UINT32 BspGetCpuType (UCHAR *pucCpuType)
{
    if (NULL == pucCpuType)
    {
        return BSP_ERROR_NULL_POINTER;
    }

    *pucCpuType = BSP_ZX211413;
    return BSP_OK;
}


/**********************************************************************
* 函数名称:BootGetChipIdx
* 功能描述:配置当前属于芯片的chip id
* 输入参数:
* 输出参数:
* 返 回 值:
* 其它说明:
* 修改日期        版本号     修改人          修改内容
* -----------------------------------------------
***********************************************************************/
UINT32 BootGetBootMode()
{
    return (BootRdIcScrReg(BOOT_MODE_REG) & 0x03);
}


/**********************************************************************
* 函数名称:BootGetChipIdx
* 功能描述:配置当前属于芯片的chip id
* 输入参数:
* 输出参数:
* 返 回 值:
* 其它说明:
* 修改日期        版本号     修改人          修改内容
* -----------------------------------------------
***********************************************************************/
UINT8 BootGetIcChipId(VOID)
{
    zte_printf_s("get chip id...");
    return (BootRdIcScrReg(CHIP_ID_REG) & 0x3);
}

UINT32 BootGetGlobalChipId()
{
    g_icChipId = BootGetIcChipId();
    /* Started by AICoder, pid:c1daft42047aec71485409a910beff06a765ff9f */
    return BSP_OK;
    /* Ended by AICoder, pid:c1daft42047aec71485409a910beff06a765ff9f */
}

#if 0

/**************************************************************************
* 函数名称: int BootSetLedFlag(VOID)
* 功能描述: 工装 应用程序入口
* 输入参数: 无
* 输出参数:
* 返 回 值: 无
* 其它说明:
*
* 修改日期:    版本号     修改人        修改内容
* -----------------------------------------------
* 2010-05-25     V1.0      xxx        Created
**************************************************************************/

UINT32 BootSetLedFlag(UINT32 ulSwitch)
{
    if ( 0 == ulSwitch)
    {
        g_ulLedFlag = 0;
    }
    else
    {
        g_ulLedFlag = 1;
    }
    return BSP_OK;
}

VOID BootLedBling(VOID)
{

    UINT32 ucClkRate = sysClkRateGet();
    BootLedCtrl(BSP_LED_ID_RUN,BSP_LED_OP_OFF);/*RUN灯灭*/
    taskDelay(ucClkRate);
    BootLedCtrl(BSP_LED_ID_RUN,BSP_LED_OP_ON);/*RUN灯亮*/
    taskDelay(ucClkRate);
    /*先亮后灭的话，出现调度原因导致的闪灯过后常亮RUN灯偶发不亮的问题，调整为先灭后亮规避该问题*/
}
#endif

/**************************************************************************
* 函数名称: BootSetPwmEn
* 功能描述: 设置Pwm的功能使能，pwmId (0-2), en(0去使能，1使能)
* 输入参数: 无
* 输出参数:
* 返 回 值: 无
* 其它说明:
*
* 修改日期:    版本号     修改人        修改内容
* -----------------------------------------------
**************************************************************************/
UINT32 BootSetPwmEn(UINT32 pwmId,UINT32 en)
{
    UINT32 reg = 0;

    reg = BootRdIcPwmReg(pwmId * 0x10 + 0x10);

    if (1 == en)
    {
        reg |= 0x1;
    }
    else
    {
        reg &= (~0x1);
    }

    return BootWrIcPwmReg(pwmId * 0x10 + 0x10, reg);
}

/**************************************************************************
* 函数名称: BootSetPwmCfg
* 功能描述: 设置Pwm的pwmId, polar, clk_div, period, duty
* 输入参数: 无
* 输出参数:
* 返 回 值: 无
* 其它说明:
*
* 修改日期:    版本号     修改人        修改内容
* -----------------------------------------------
**************************************************************************/
UINT32 BootSetPwmCfg(UINT32 pwmId,UINT32 polar, UINT32 clk_div, UINT32 period,UINT32 duty)
{
    UINT32 reg;

    reg = (clk_div << 2) | (polar << 1) | 0;

    BootWrIcPwmReg(0x4,0);
    BootWrIcPwmReg(pwmId * 0x10 + 0x10, reg);
    BootWrIcPwmReg(pwmId * 0x10 + 0x14, period);
    BootWrIcPwmReg(pwmId * 0x10 + 0x18, duty);
    BootSetPwmEn(pwmId,1);
    return BSP_OK;
}

/**********************************************************************
* 函数名称:BootLedRun
* 功能描述:led_run led灯闪烁模式
* 输入参数: ucMode  0 只亮run灯,  1 run灯周期性闪
* 输出参数:无。
* 返 回 值:无
* 其它说明:
* 修改日期        版本号     修改人          修改内容
* -----------------------------------------------
* 2015/10/12            V1.0            00086970                       创建
***********************************************************************/
VOID BootLedRun(UCHAR ucMode)
{
    #ifndef CONFIG_ZX211413_ADS
    if (0 == ucMode)/*只亮run灯,其他灯灭 */
    {
        /* run led light on */
        BootSetPwmEn(RUN_LED_PWM_ID,0);
        BootSetPadGpioPinMode(GPIO_OUT_MODE);
        BootLedCtrl(BSP_LED_ID_RUN, BSP_LED_OP_ON);
        /* alarm led light off */
        BootLedCtrl(BSP_LED_ID_ALM, BSP_LED_OP_OFF);
    }
    else if (1 == ucMode)/*run灯周期性闪烁*/
    {
        /* run led on pwm mode,flashing at 1hz */
        BootSetPwmCfg(RUN_LED_PWM_ID,0,1000,50000,25000);
        BootSetPadGpioPinMode(PWM_OUT_MODE);
        /* alarm led light off */
        BootLedCtrl(BSP_LED_ID_ALM, BSP_LED_OP_OFF);
    }
    else if (2 == ucMode)/*所有灯都全亮*/
    {
        /* run led light on */
        BootSetPwmEn(RUN_LED_PWM_ID,0);
        BootSetPadGpioPinMode(GPIO_OUT_MODE);
        BootLedCtrl(BSP_LED_ID_RUN, BSP_LED_OP_ON);
        /* alarm led light on */
        BootLedCtrl(BSP_LED_ID_ALM, BSP_LED_OP_ON);
    }
    else
    {
        zte_printf_s("BootLedRun, input params[%d] error\n", ucMode);
    }
    #endif

}


/*****************************************************************************
* 函数名称   : BootGetChipMsFlag(*)
* 功能描述   : 获取Chip是主芯片还是从芯片设计模式
* 读全局变量 : 无
* 写全局变量 : 无
* 输入参数   : 无
* 输出参数   : 无
* 返 回 值   : 内存大小单位Byte
* 其它说明   :
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 姜建奎@2012-02-29 16:14:27 创建
* $0000000(N/A), ty@2019-1-29 由IC2.0移植创建（IC3.0使用的DDR大小为512M）
*----------------------------------------------------------------------------*/
UINT32 BootGetChipMsFlag()
{
    return CHIP_MASTER_TYPE;
}
#define KDA_DEVICE_NAME "/dev/misc/KernDrvAgt"
static int g_iKdaDrvFd = -1;
ULONG OpenKdaModel(void)
{
    int ret;
    BspMknod(KDA_DEVICE_NAME,"c","10","244");
    if ((g_iKdaDrvFd = open(KDA_DEVICE_NAME,O_RDWR | O_SYNC )) < 0)
    {
        zte_printf_s("open " KDA_DEVICE_NAME " failed!");
        return BSP_ERROR;
    }
    ret = BspPhyAddrToKernel((unsigned long long)BOOTAPP_LOG_PHY_ADDR, COM_INTERRUPT_NUM, g_iKdaDrvFd);
    if (ret != BSP_OK)
    {
        zte_printf_s("BspPhyAddrToKernel failed!\n");
        return BSP_ERROR;
    }
    return BSP_OK;
}

/*****************************************************************************
* 函数名称   : BootDevMemMap(*)
* 功能描述   : 使用mmap将物理地址映射到用户进程虚拟地址空间
* 读全局变量 : 无
* 写全局变量 : 无
* 输入参数   : 无
* 输出参数   : 无
* 返 回 值   : BSP_OK, 其它值为失败
* 其它说明   :
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), zhaoyun@2014-5-27 14:07:25 创建
*----------------------------------------------------------------------------
*/
UINT32 BootDevMemMap(VOID)
{
    /* 打开内存设备的文件描述符 */
    int     iFd;
    int     iSpaceProt = PROT_READ | PROT_WRITE;
    UINT32  iCount = 0;

    #define TO_MAP_LIST(a)      #a, &a
    /*lint -e529*/
    /*lint -e64*/
    /* Started by AICoder, pid:wdd8bccb034e9d914d4f0925609c7701a8361392 */
    struct map_list_t
    {
        const char  *pucVarName;
        UINT32      *pulVarAddr;
        UINT32    ulMapBase;
        UINT32    ulMapSize;
    }
    /* Ended by AICoder, pid:wdd8bccb034e9d914d4f0925609c7701a8361392 */
    map_list[] =
    {
        /*map_list[0] 根据4.0的情况需要进行修改*/
        {TO_MAP_LIST(g_ulRamReservedAddr),    (0x800000),           0x00600000}, /*reserv mem*/
        {TO_MAP_LIST(aulWatchdogAddr),        WATCH_DOG_MAP_ADDR,   0x00002000}, /*wdt*/
        {TO_MAP_LIST(aulMdioVirAddr),       MII_MAP_ADDR,           0x00010000}, /*mii*/
        {TO_MAP_LIST(aulL2ssVirAddr),       L2SS_MAP_ADDR,          0x04000000}, /*l2ss*/
        {TO_MAP_LIST(aulCrmVirAddr),        CRM_MAP_ADDR,           0x00001000}, /*CRM access*/
        {TO_MAP_LIST(aulPwmVirAddr),        PWM_MAP_ADDR,           0x00100000}, /*pwm access*/
        {TO_MAP_LIST(aulPad0VirAddr),        PAD_0_MAP_ADDR,        0x00010000}, /*pad0 access*/
        {TO_MAP_LIST(aulPad1VirAddr),        PAD_1_MAP_ADDR,        0x00100000}, /*pad1 access*/
        {TO_MAP_LIST(aulScrVirAddr),        UBAR_SCR_MAP_ADDR,      0x00100000}, /*ubar scr access*/
    };

    /*lint +e529*/
    /*lint +e64*/
    #define DO_ADDR_MAP(a)                                      \
    *((a)->pulVarAddr) = (long)mmap(0, (a)->ulMapSize,          \
        iSpaceProt, MAP_SHARED, iFd, (a)->ulMapBase);           \
    if (*((a)->pulVarAddr) == -1)                               \
    {                                                           \
        dbgErr("mmap %s failed %s, %d\n",                       \
            (a)->pucVarName, zte_strerror_s(errno), errno);     \
        close(iFd);                                             \
        return BSP_ERROR;                                       \
    }                                                           \
    dbgInfo("%-20s = %#x\n", (a)->pucVarName, *((a)->pulVarAddr));


    /* 打开存储空间映射 */
    if ((iFd = open("/dev/mem", O_RDWR | O_SYNC)) < 0)
    {
        dbgErr("open /dev/mem failed\n");
        return BSP_ERROR;
    }

    for (iCount = 0; iCount < sizeof(map_list)/sizeof(map_list[0]); iCount++)
    {
        DO_ADDR_MAP(&map_list[iCount]);
        usleep(1000);
    }
    close(iFd);

    BootCfgL2ssBaseAddr(aulL2ssVirAddr);
    BootCfgCrmAccessBaseAddr(aulCrmVirAddr);
    BootCfgWdtBaseAddr(aulWatchdogAddr);
    BootCfgMiiBaseAddr(aulMdioVirAddr);
    BootCfgGpioPadBaseAddr(0,aulPad0VirAddr);
    BootCfgGpioPadBaseAddr(1,aulPad1VirAddr);
    return BSP_OK;
}

#if defined(CONFIG_RECORD_TIME)
/**********************************************************************
* 函数名称:BootGetMemVir
* 功能描述:获取此CPU映射的高端内存上电时间基地址
* 输入参数:无
* 输出参数:无
* 返 回 值:无
* 其它说明:上电计时高端内存基地址
* 修改日期        版本号     修改人          修改内容
* -----------------------------------------------
* $0000000(N/A), 李耀清@2019-07-09 21:18:00
*----------------------------------------------------------------------------
*/
UINT32 BootGetMemVir(VOID)
{
    if (NULL == g_ulRamReservedAddr)
    {
        zte_printf_s("Error: g_ulRamReservedAddr is NULL!!\n");
        return 0;
    }
    return (g_ulRamReservedAddr+SYS_PHYS_MEM_TOP-BSP_MEM_SIZE + 0x8000);/*(0x1B600000)+6M-512K+32K,BSP MEM 开始的32K*/
}
#endif

/**********************************************************************
* 函数名称:BootSetSlaveChipNum
* 功能描述:配置从片数量，1代表只有主片
* 输入参数:
* 输出参数:
* 返 回 值:
* 其它说明:
* 修改日期        版本号     修改人          修改内容
* -----------------------------------------------
* $0000000(N/A), ty@2019-1-29 由IC2.0移植创建
***********************************************************************/
UINT32 BootSetSlaveChipNum(VOID)
{
    HAL_SetSlaveChipNum((UINT32)1);
    return BSP_OK;

}
/**********************************************************************
* 函数名称:BootSupportOptDebug
* 功能描述:获取电模块在位情况
* 输入参数:
* 输出参数:
* 返 回 值:1：电模块1在位
          0：电模块0在位
          2：电模块不在位
          3：在位但非电模块
* 其它说明:
* 修改日期        版本号     修改人          修改内容
* -----------------------------------------------
* $0000000(N/A), 00086907@2021-12-16 新建
***********************************************************************/

UINT32 BootGetCooperIndex(VOID)
{

    UINT32 pulVal = 0;

    zte_printf_s("try IIC1\n");
    BootSfpRegRead(0,SFP_EEPROM, 0x6, &pulVal);
    if (0x8 == pulVal)
    {
        return IIC1_SUPPORT_COOPER;
    }

    zte_printf_s("try IIC2\n");
    BootSfpRegRead(1,SFP_EEPROM, 0x6, &pulVal);
    if (0x8 == pulVal)
    {
        return IIC2_SUPPORT_COOPER;
    }

    zte_printf_s("IIC1&IIC2 do not support cooper\n");
    return IIC_NO_SUPPORT_COOPER;

}

#ifndef I2C_USED_IN_KERNEL


UINT32 BootI2cBusInit(UINT32 ulBusId)
{
    UINT32 ulRetVal = BSP_OK;

    T_I2C_BUS_DRV *ptBus = NULL;

    if (ulBusId >= NUM_BRD_I2C_BUS)
    {
        return BSP_ERROR_INVALID_PARA;
    }

    ptBus = &s_atI2cBus[ulBusId];
    ulRetVal = BspI2CBusDrvInit(ptBus);
    return ulRetVal;
}

UINT32 BootSfpChipInit(VOID)
{
    UINT32 ulRetVal = BSP_OK;
    T_SfpDev tSfp;

    zte_memset_s((VOID *)&tSfp, sizeof(tSfp),0, sizeof(tSfp));
    tSfp.ulDevIndex = 0;
    tSfp.tSlave.I2CBusId = I2C_BUS_ID_SFP0;
    tSfp.tSlave.Addr = 0x56;
    ulRetVal |= BootSfpDevInit(&tSfp);

    zte_memset_s((VOID *)&tSfp, sizeof(tSfp),0, sizeof(tSfp));
    tSfp.ulDevIndex = 1;
    tSfp.tSlave.I2CBusId = I2C_BUS_ID_SFP1;
    tSfp.tSlave.Addr = 0x56;
    ulRetVal |= BootSfpDevInit(&tSfp);
    return ulRetVal;
}
#endif

UINT32 BootBoardHwPreInit(VOID)
{
    UINT32 ulRet = BSP_OK;
    ulRet |= zx211413GpioInit();/*完成GPIO物理地址到虚拟地址的映射*/
    ulRet |= BootInitBoardGpioPort();
    #ifndef I2C_USED_IN_KERNEL
    ulRet |= BootI2cBusInit(I2C_BUS_ID_SFP0);/*sfp I2c总线初始化*/
    ulRet |= BootI2cBusInit(I2C_BUS_ID_SFP1);
    ulRet |= BootSfpChipInit();
    #endif
    /*ulRet |= _BspZteCrmMsgInit();*/
    zte_printf_s("413BootBoardHwPreInit ok\n");

    return ulRet;

}

UINT32 BootBoardHwPadInit(VOID)
{
    #ifndef CONFIG_ZX211413_ADS
    BootWrIcGpioPadEn(DPDIC_GPIO_LED_RUN,GPIO_ENABLE);
    BootWrIcGpioPadEn(DPDIC_GPIO_LED_ALARM,GPIO_ENABLE);

    BootWrIcGpioPadEn(DPDIC_GPIO_BOARDTYPE_QCELL,GPIO_ENABLE);
    BootWrIcGpioPadEn(DPDIC_GPIO_SERDES_IIC ,GPIO_ENABLE);
    #endif
    return BSP_OK;

}

UINT32 BootResetPhy()
{
    return BSP_OK;
}

/*****************************************************************************
* 函数名称   : BootBoardPreInit(*)
* 功能描述   : Bsp单板初始化函数
* 读全局变量 : 无
* 写全局变量 : 无
* 输入参数   : 无
* 输出参数   : 无
* 返 回 值   : BSP_OK, 其它值为失败
* 其它说明   : 该接口为加载fpga前所需的BSP初始化函数。 版本公共接口函数
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), zhaoyun@20140527 13:40:08 创建
* comments:  feble_cheng@20140728 这个接口内不允许访问IC加速器的任何寄存器
*                                  因为此时fpga尚未加载，localbus时序异常会造成主片挂死
*----------------------------------------------------------------------------
*/
UINT32 BootBoardPreInit(VOID)
{
    UINT32 ulRet = BSP_OK;
    TBoardInitCall *tmp;
    struct list_head *pos;
    /* Started by AICoder, pid:qb8d2odee3e063b142650be1e078a30b277195bb */
    zte_printf_s("\\413BootBoardPreInit....... \n");
    /* Ended by AICoder, pid:qb8d2odee3e063b142650be1e078a30b277195bb */
    ulRet |= BootSetSlaveChipNum(); /*配置从片IC数量，不包含主片*/
    ulRet |= BootBoardHwPreInit();  /*GPIO初始化*/
    ulRet |= BootDevMemMap();       /*物理地址到虚拟地址的映射*/
    ulRet |= BootGetGlobalChipId(); /*配置IC的芯片号,全局信息*/
    ulRet |= BootFlashInit();
    ulRet |= BootBoardHwPadInit();
    ulRet |= BspResetPhyCallBackInit(BootResetPhy);
    ulRet |= OpenKdaModel();

    zte_printf_s("ZX211413 %s Chip ID %d\n",\
            (CHIP_MASTER_TYPE ==BootGetChipMsFlag())?"Master":"Slave",\
            g_icChipId);

    /*lint -e{413,155}*/
    /*Carry out the init call*/
    list_for_each(pos,&BoardPreCall_list)
    {
        tmp = list_entry(pos,TBoardInitCall,list);
        //zte_printf_s("function name= %s.",tmp->cCallName);

        tmp->ulRet = (*tmp).pInitCall();
        //zte_printf_s("ulRet =%ld .\n",tmp->ulRet);
    }
    /*lint -e{413,155}*/
    /*Collect the initcall error*/
    list_for_each(pos,&BoardPreCall_list)
    {
        tmp = list_entry(pos,TBoardInitCall,list);
        if (tmp->ulRet != 0)
        {
            //zte_printf_s("ulRet =%ld .\n",tmp->ulRet);
            sBoardInitError |= tmp->ulFailMacro;
            ulRet |= tmp->ulFailMacro;
        }
    }

    return ulRet;
}



/**********************************************************************
* 函数名称:BootDebugMiiRead
* 功能描述:通过GMII寄存器读PHY  .  针对以太网口GMAC0
* 输入参数: *     - udCsrClockRange：CSR 时钟区域
*     - udGR： GMII寄存器
*     - udPA： PHY设备物理层地址
*     - pudData：需要读出的数据的地址
* 输出参数:
* 返 回 值:
* 其它说明:
* 修改日期        版本号     修改人          修改内容
* -----------------------------------------------
* 2014-5-28       V1.0       yam             创建
* $0000000(N/A), zhaoyun@20141216 19:33:10 trm78E
* $0000000(N/A), ty@2019-1-29 由IC2.0移植创建
***********************************************************************/
UINT32 BootDebugMiiRead(UINT32 ulCsrClockRange, UINT32 ulGR, UINT32 ulPA, UINT32 *pulData)
{
    return BootGetMiiWrReg(ulPA,ulGR,pulData);
}

UINT32 BootGetSfpPhyLinkSpeed(UINT32 speed)
{
    switch ((speed & 0xc) >> 2)
    {
        case 2:
        {
            dbgInfo("PHY SPEED %s\n","10M");
            return SPEED_100;
        }


        case 1:
        {
            dbgInfo("PHY SPEED %s\n","100M");
            return SPEED_100;
        }


        case 0:
        {
            dbgInfo("PHY SPEED %s\n","1000M");
            return SPEED_1000;
        }


        default:
        {
            dbgInfo("GET PHY SPEED ERROR\n");
            return BSP_ERROR;
        }
    }

}

/**********************************************************************
* 函数名称:BootGetPHYLinkStatus
* 功能描述:获取PHY芯片物理链路连通状态
* 输入参数:无
* 输出参数:
* 返 回 值:0-网口联通 1-网口未联通
* 其它说明:
* 修改日期        版本号     修改人          修改内容
* -----------------------------------------------
* 2013-4-15       V1.0       yam             创建
* $0000000(N/A), zhaoyun@20141216 19:33:10 trm78E
* $0000000(N/A), ty@2019-1-29 由IC2.0移植创建
* $0000000(N/A), jc@2019-7-19 修改
***********************************************************************/
UINT32 BootGetPhyLinkStatus(VOID)
{

    UINT32 ulValue = 0;
    UINT32 ulRet = 0;
    UINT32 ulOptflag = 0;


    if (g_qcell_type == QCELL_BOARDTYPE)
    {
        ulRet = BspGetPhyStatus(0, &ulValue, 0);
        if (BSP_OK != ulRet)
        {
            dbgErr("Gmac0MiiRead Error!\n");
            return BSP_ERROR;
        }

        dbgInfo("PHY Status Reg[0x%x]\n", ulValue);

        if (ulValue & NET_STATE_LINKOK)
        {
            dbgInfo("Debug net port is ON\n");
            BootGetSfpPhyLinkSpeed(ulValue);
            dbgInfo("PHY DUPLEX %s\n", ((ulValue & 0x10)>>4)? "FULL":"HALF");
            return 0;
        }
        else
            return 1;
    }
    else
    {

        ulOptflag = BootGetCooperIndex();
        if ((IIC1_SUPPORT_COOPER == ulOptflag)||(IIC2_SUPPORT_COOPER == ulOptflag))
        {
            ulRet = BootGetSfpPhyStatus(ulOptflag, &ulValue);
            if (BSP_OK != ulRet)
            {
                dbgErr("IIC%d phy read Error!\n",ulOptflag+1);
                return BSP_ERROR;
            }
            if (ulValue & NET_STATE_LINKOK)
            {
                dbgInfo("IIC%d net port is ON\n",ulOptflag+1);
                dbgInfo("PHY DUPLEX %s\n", ((ulValue & 0x10)>>4)? "FULL":"HALF");

                BootGetSfpPhyLinkSpeed(ulValue);
                return PHY_LINK_UP;
            }
            else
            {
                dbgInfo("IIC%d net port is OFF\n",ulOptflag+1);
                return PHY_LINK_DOWN;
            }
        }
        else
        {
            return 1;
        }
    }
}

/**********************************************************************
* 函数名称:BootGmac0MiiWrite
* 功能描述:通过GMII寄存器写PHY  .  针对以太网口GMAC0
* 输入参数: *     - udCsrClockRange：CSR 时钟区域
*     - udGR： GMII寄存器
*     - udPA： PHY设备物理层地址
*     - pudData：需要读出的数据的地址
* 输出参数:
* 返 回 值:
* 其它说明:
* 修改日期        版本号     修改人          修改内容
* -----------------------------------------------
* 2014-5-28       V1.0       yam             创建
* $0000000(N/A),00086970 19:33:10 trm78E
* $0000000(N/A), ty@2019-1-29 由IC2.0移植创建
***********************************************************************/
UINT32 BootDebugMiiWrite(UINT32 ulCsrClockRange, UINT32 ulGR, UINT32 ulPA, UINT32 ulData)
{
    return BootSetMiiWrReg(ulPA,ulGR,ulData);
}


/**************************************************************************
* 函数名称： boot_flag_set
* 功能描述：设置boot启动标志
* 输入参数： 无
* 输出参数： 无
* 返 回 值： BSP_OK/BSP_ERROR
* 其它说明：
* 适用范围： BSP、OSS
* -----------------------------------------------------------------------
* 修改日期      版本号     修改人        修改内容
* 2015年10月22日 v1.0      00086970          创建
* $0000000(N/A), ty@2019-1-29 由IC2.0移植创建
**************************************************************************/
VOID boot_flag_set()
{
    UINT8 check_flag=0;

    check_flag = BootGetKBootMSFlag();
    zte_printf_s("check_flag = %0#x\n",check_flag);

    if (check_flag == MASTER_BOOT_OK)  /*本次是上电或者复位后第一次启动,启动主boot成功*/
    {
        BootSetKBootMSFlag(MASTER_KUBOOT_OK);
        /*尚欠写高端内存表征主boot启动成功标志*/
    }
    else if (check_flag == MASTER_KUBOOT_OK) /*启动主boot成功，继续尝试引导CPU版本*/
    {
        BootSetKBootMSFlag(MASTER_KUBOOT_OK);
        /*尚欠写高端内存表征主boot启动成功标志*/
    }
    else if (check_flag == SLAVE_BOOT_OK)  /*启动从boot成功，*/
    {
        BootSetKBootMSFlag(SLAVE_KUBOOT_OK);
        /*尚欠写高端内存表征从boot启动成功标志*/
    }
    else if (check_flag == SLAVE_KUBOOT_OK)   /*启动从boot成功，继续尝试引导CPU版本*/
    {
        BootSetKBootMSFlag(SLAVE_KUBOOT_OK);
        /*尚欠写高端内存表征从boot启动成功标志*/
    }

    return;
}

/**************************************************************************
* 函数名称： SetEthProMode
* 功能描述： 设置ETH的模式寄存器的混杂模式控制位
* 输入参数： 0--对进入的帧的目的地址进行检查。1--对进入的帧的目的地址不进行检查。
* 输出参数： 无
* 返 回 值：
* -------------------------------------------------------
* 其它说明：
* 修改日期     版本号        修改人                修改内容
* $0000000(N/A), ty@2019-1-29 由IC2.0移植创建
**************************************************************************/
/*需确认MAC_FRAME_FILTER帧过滤寄存器的偏移地址(已确认)*/
/*需确认0x7FFFFFFE和0x80000001的值（已确认）*/
UINT32 SetEthProMode(UCHAR ucValue)
{
    UINT32  ulRet=BSP_OK;
    #if 0

    UINT32  ulValue=0;
    /* Started by AICoder, pid:zf5bdk13cc89efb14f9a089d4082851a186214d5 */
    zte_printf_s("SetEthProMode: set eth mode bit. \n");
    /* Ended by AICoder, pid:zf5bdk13cc89efb14f9a089d4082851a186214d5 */
    HAL_addrmapGetDataFromVirAddr(0,MEM_BLK_GMAC0,MAC_FRAME_FILTER,&ulValue);


    if (ucValue == 0) /*对进入的帧的目的地址进行检查,非混杂模式*/
    {
        ulValue = ulValue & 0x7FFFFFFE;
    }
    else/*对进入的帧的目的地址不进行检查, 混杂模式Receive All Frame*/
    {
        ulValue = ulValue | 0x80000001;
    }

    WrReg(0,MEM_BLK_GMAC0,MAC_FRAME_FILTER,ulValue);
    #endif
    return ulRet;

}
/**********************************************************************
* 函数名称： BootGetDownloadFlag
* 功能描述： MIO14指示起保护区版本or下载版本。
* 输入参数： 无
* 输出参数： 无
* 返 回 值： 0:起保护区版本 1:下载版本
* 其它说明： zx211410写死起保护区版本
* 修改日期        版本号     修改人          修改内容
* -----------------------------------------------
* 2012/07           V1.0         ZKH
***********************************************************************/
UINT32 BootGetDownloadFlag(VOID)
{
    UINT32 ulChipId = 0;

    ulChipId = BootGetIcChipId();
    if ((CHIP_MASTER_TYPE == BootGetChipMsFlag()) && (0 == ulChipId))
    {
        return 0;
    }
    else
    {
        return 1;
    }
}

ULONG getLastKmsgAddr(VOID)
{
    return LAST_KMSG_ADDR;
}

ULONG getAppLogPhyAddr(VOID)
{
    return APP_LOG_PHY_ADDR;
}
ULONG getFsLogPhyAddr(VOID)
{
    return UBIFS_RO_LOG_ADDR;
}

UINT32 BootGetBoardHwResetType(VOID)
{
    UINT32 ret = 0;
    ret = readl(aulCrmVirAddr + REC_RESET_0);
    return ret;
}

UINT32 BootGetBoardSwResetType(VOID)
{
    UINT32 ret = 0;
    ret = readl(aulCrmVirAddr + SOFT_RESET_OFFSET);
    return ret;
}

/* Started by AICoder, pid:oe2f7ffc4ceebf414e7609ed00fea903ed44949b */
UCHAR* BootGetBoardResetInfoAddr(VOID)
{
    return (UCHAR*)(g_ulRamReservedAddr + RESET_INFO_ADDR);
}
/* Ended by AICoder, pid:oe2f7ffc4ceebf414e7609ed00fea903ed44949b */

VOID SaveKebootBakLog(VOID)
{
    BspSaveBootKmsgLog(BAK_LOG);
    BspSaveBootAppLog(BAK_LOG);
}
VOID SaveKebootCurLog(VOID)
{
    BspSaveBootKmsgLog(CUR_LOG);
    BspSaveBootAppLog(CUR_LOG);
}
/*bs住后的手动转储请用SaveKebootLog,产生4份,使每份log序号保持一致*/
VOID SaveKebootLog(VOID)
{
    SaveKebootBakLog();
    SaveKebootCurLog();
}
ULONG BootFlagGet()
{
    ULONG flag=0;
    flag = BootGetKBootMSFlag();
    return flag;
}
/*****************************************************************************
* 函数名称   : main(*)
* 功能描述   : bootapp程序处理主函数
* 读全局变量 : 无
* 写全局变量 : 无
* 输入参数   : argc   - 参数个数
              argv[] - 参数列表
* 输出参数   : 无
* 返 回 值   : 0为成功, 其余失败
* 其它说明   :
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 00086970 @2015-10-28
* $0000000(N/A), ty@2019-1-29 由IC2.0移植创建
*----------------------------------------------------------------------------
*/
/* Started by AICoder, pid:n6d2cp5aa5ee93214f0f0b3310a52e0c0991fdd5 */
#ifdef RENAME_FUNC_UTFT
#define main UTFT_main
#endif
/* Ended by AICoder, pid:n6d2cp5aa5ee93214f0f0b3310a52e0c0991fdd5 */
int main(int argc, char *argv[])
{
    int iBootAppTaskID = 0;
    UINT32 ulRet = 0;
    zte_printf_s("zx211413 bootapp\n");

    ulRet = BootBoardPreInit();

    BootLedRun(0);

    ulRet = GetCmdline();
    if (BSP_ERROR == ulRet)
    {
        zte_printf_s("getcmdline error!!!");
        SetDefaultCmdline();
    }

    ulRet |= BootWatchDogInit();

    ulRet |= (UINT32)ushell_init();

    ulRet |= BootSoftModInit();

    /*使用pwm功能闪灯时不需要起ledtask*/
    #if 0 /*modify by pwm mode in BootLedRun function */
    taskSpawn("tLedTask",   \
        100, /* priority */            \
        0,   /* option   */           \
        0x100,/* stack size */      \
        (FUNCPTR)BootLedTask, 0, 0, 0, 0, 0, 0, 0, 0 ,0,0);
    #endif

    BootLedRun(0);

    iBootAppTaskID = taskSpawn("tBootTask",   \
        100, /* priority */            \
        0,   /* option   */           \
        0x1000,/* stack size */      \
        (FUNCPTR)MainLoop, 0, 0, 0, 0, 0, 0, 0, 0 ,0,0);
        /* Started by AICoder, pid:z519bmeb46jfe7114dee0ae69069c80d35910aa2 */
        (void)iBootAppTaskID; // 告诉编译器：我知道这个变量没用
        /* Ended by AICoder, pid:z519bmeb46jfe7114dee0ae69069c80d35910aa2 */
    while (1)
    {
        //BspFunction("/boot.out", CFG_PROMPT);
        sleep(20);
    }

    return ulRet;

}



#endif
extern UCHAR g_ucCmdLine[256];
UINT32 SetDefaultCmdline(VOID)
{
    #if defined(KEXECBOOT_SUPPORT)
    /* Started by AICoder, pid:xf5d9f646ep8dd91450e0a6100f6cd0167f46ee2 */
    zte_strncpy_s((char *)g_ucCmdLine,sizeof(g_ucCmdLine),"root=/dev/ram0 rw mem=122M console=ttyAMA0 flash_partition_flag=1",strlen("root=/dev/ram0 rw mem=122M console=ttyAMA0 flash_partition_flag=1"));
    /* Ended by AICoder, pid:xf5d9f646ep8dd91450e0a6100f6cd0167f46ee2 */
    #else
    zte_strncpy_s(g_ucCmdLine,sizeof(g_ucCmdLine),"root=/dev/ram0 rw mem=122M console=ttyAMA0",strlen("root=/dev/ram0 rw mem=122M console=ttyAMA0"));
    #endif
    zte_printf_s("/proc/cmdline error,load default cmdline.\n");
    return BSP_OK;

}

UINT32 BootPortVlanInit(UINT32 vlan,UINT32 portmap)
{
    UINT32 port;

    dbgInfo("BootPortVlanInit portmap 0x%x\n",portmap);

    L2ssCreatVlan(vlan, vlan, portmap, portmap);
    for (port=0;port<L2SS_TRXP_NUM;port++)
    {
        if ( 1 != ((portmap >> port) & 0x01))
        {
            continue;
        }
        L2ssVlanMapModeSet(port,0x3f,0);
        L2ssPortVlanSet(port,vlan,0);
        L2ssParsCfglpSelParseNUm(port, e_L2SS_ENG0);    //ads阶段parse引擎的设置都是进入ENG0
        L2ssParsCfgPktAnalyLevel(port, 4);
    }
    L2ssPrepCfgPktErrCtrl(0); /*关闭头长度错误丢弃*/
    zte_printf_s("%s done\n",__FUNCTION__);
    return 0;
}

UINT32 BootIpVlanInit(UINT32 vlan,UINT32 portmap)
{
    T_L2ssLpmStruct tLpmInfo = {0};
    UINT32 lvTapIdx = 0;
    dbgInfo("BootIpVlanInit portmap 0x%x\n",portmap);
    /*A53 通信 建立 源/目的IP报 199.33.xx.xx的报文的VLAN  DEFAULT_ETH_IP_VLAN1*/

    L2ssCreatVlan(vlan , vlan , portmap, portmap);
    L2ssLvTapTblSet(&lvTapIdx);
    zte_memset_s(&tLpmInfo,sizeof(tLpmInfo),0,sizeof(tLpmInfo));
    tLpmInfo.udKeyType = e_LpmKeyIpv4L32;
    tLpmInfo.audKey[0]  = 0xc7210000;      /*ip 199.33.xx.xx*/
    tLpmInfo.audMask[0] = 0xffff0000;
    L2ssLpmVlanSet(&tLpmInfo, vlan,lvTapIdx, 0x3);

    zte_printf_s("%s done\n",__FUNCTION__);
    return 0;
}




UINT32 BootL2ssInit(VOID)
{

    L2ssProcInit();
    L2ssCheckQmanNorSelfInitDone(0);

    /*qman 引擎模式为2个引擎模式*/
    L2ssSetEngMode(0);

    /* 设置端口号为4开始 */
    L2ssSetQmanCfgiInnerPortGroup(0x87654321);

    l2ss_hw_cntp_en();
    /*关闭所有CPU代理口*/

    L2ssPortDisable(L2SS_AGENT_PORT0);
    L2ssPortDisable(L2SS_AGENT_PORT6);
    L2ssPortDisable(L2SS_AGENT_PORT5);


    /*端口报文过滤,加入12端口*/
    /*portmap = portmap |(1<<12) | (1<<23) | (1<<24);*/

    zte_printf_s("%s done\n",__FUNCTION__);

    return 0;
}

UINT32 BootNtlSoftResetInit(void)
{
    /*关闭对外的eth xmac*/
    //    L2ssXmacDisable(0);
    //    L2ssXmacDisable(1);
    L2ssCpuAgentByteOrder(L2SS_AGENT_PORT0,L2SS_CPU_AGENT_BIG_ENDIAN);
    L2ssCpuAgentByteOrder(L2SS_AGENT_PORT6,L2SS_CPU_AGENT_BIG_ENDIAN);
    L2ssCpuAgentByteOrder(L2SS_AGENT_PORT5,L2SS_CPU_AGENT_BIG_ENDIAN);
    L2ssCpuAgentByteOrder(L2SS_AGENT_PORT4,L2SS_CPU_AGENT_BIG_ENDIAN);
    L2ssCpuAgentByteOrder(L2SS_AGENT_PORT3,L2SS_CPU_AGENT_BIG_ENDIAN);
    L2ssCpuAgentByteOrder(L2SS_AGENT_PORT2,L2SS_CPU_AGENT_BIG_ENDIAN);
    L2ssCpuAgentByteOrder(L2SS_AGENT_PORT1,L2SS_CPU_AGENT_BIG_ENDIAN);
    #if 0
    L2ssCpuAgentRstPort(L2SS_AGENT_PORT0);
    L2ssCpuAgentRstPort(L2SS_AGENT_PORT5);


    L2ssCpuAgentRlsPort(L2SS_AGENT_PORT0);
    L2ssCpuAgentRlsPort(L2SS_AGENT_PORT5);
    #endif
    zte_printf_s("%s done\n",__FUNCTION__);
    return BSP_OK;

}

/**********************************************************************
* 函数名称： BootGetFsRecoverFlag
* 功能描述： 从高端内存获取用户态文件系统异常标志
* 输入参数： 无
* 输出参数： 无
* 返 回 值： 0:正常 0xdeadbeaf:异常
* 其它说明： 获取后清除
* 修改日期        版本号     修改人          修改内容
* -----------------------------------------------
* 2012/07           V1.0         ZKH
***********************************************************************/
UINT32 BootGetFsRecoverFlag(VOID)
{
    UINT32 ulUbifsFormat_mask = 0;

    ulUbifsFormat_mask = *(UINT32 *)FS_FORMAT_FLAG;

    zte_memset_s((CHAR*)FS_FORMAT_FLAG, 4, 0, 4);/* 清空 */
    return ulUbifsFormat_mask;
}



UINT32 BootSetupEthFlag(VOID)
{

    if (QCELL_BOARDTYPE == _BspZteGpioGet(DPDIC_GPIO_BOARDTYPE_QCELL))
    {
        g_qcell_type = QCELL_BOARDTYPE;
    }
    if (IIC1_SERDES0 == _BspZteGpioGet(DPDIC_GPIO_SERDES_IIC))
    {
        g_iic1_is_serdes0 = IIC1_SERDES0;
    }

    return 0;
}

UINT32 BootGetSfpLinkStatusAndCfgMacSpeed(UINT32 ulOptflag)
{
    UINT32 ulValue = 0;
    UINT32 ulRet = 0;
    UINT32 loop = 0;
    UINT32 port = 0;
    UINT32 L2ssXmacSpeed = SPEED_100;//默认mac速率配置100M，下面根据phy link速率判断是否需要修改

    /*某些交换机link up速度慢，这里动态根据link速度来调整延时时间*/
    for (loop = 0; loop < SFP_WAIT_LINK_UP_MAX_TIME; loop++)
    {
        ulRet = BootGetSfpPhyStatus(ulOptflag, &ulValue);
        if (BSP_OK != ulRet)
        {
            dbgErr("Read Sfp Phy Status Error!\n");
            return BSP_ERROR;
        }
        if (ulValue & NET_STATE_LINKOK)
        {
            break;
        }
        BspSysMsDelay_Sys(1000);
    }

    if (loop == SFP_WAIT_LINK_UP_MAX_TIME)
    {
        zte_printf_s("Get sfp phy link up status time out\n");
    }
    else
    {
        zte_printf_s("Get sfp phy link up status need %d s\n", loop);
    }

    if (ulValue & NET_STATE_LINKOK)
    {
        dbgInfo("IIC%d net port is ON\n",ulOptflag+1);
        dbgInfo("PHY DUPLEX %s\n", ((ulValue & 0x10)>>4)? "FULL":"HALF");

        L2ssXmacSpeed = BootGetSfpPhyLinkSpeed(ulValue);

        if (IIC1_SUPPORT_COOPER == ulOptflag)
        {
            port = ((g_iic1_is_serdes0) ? (0):(1));
        }
        else if (IIC2_SUPPORT_COOPER == ulOptflag)
        {
            port = ((g_iic1_is_serdes0) ? (1):(0));
        }
        zte_printf_s("%s cfg Mac[%d]End! \n",__FUNCTION__,port);
        L2sssMacSetInterfaceMode(port, L2ssXmacSpeed);

        return PHY_LINK_UP;
    }
    else
    {
        //L2sssMacSetInterfaceMode(port, L2ssXmacSpeed);
        dbgInfo("IIC%d net port is OFF\n",ulOptflag+1);
        return PHY_LINK_DOWN;
    }
}

/* Started by AICoder, pid:b505543928b14bc2a48c3bef43ee6c2b */
UINT32 BootGetPhyLinkStatusAndCfgMacSpeed(void)
{
    UINT32 ulValue = 0;
    UINT32 ulRet = 0;
    UINT32 loop = 0;
    UINT32 port = 0;
    UINT32 L2ssXmacSpeed = SPEED_100;//默认mac速率配置100M，下面根据phy link速率判断是否需要修改

    /*某些交换机link up速度慢，这里动态根据link速度来调整延时时间*/
    for (loop = 0; loop < PHY_WAIT_LINK_UP_MAX_TIME; loop++)
    {
        ulRet = BspGetPhyStatus(0, &ulValue, 0);
        if (BSP_OK != ulRet)
        {
            dbgErr("Read Phy Status Error!\n");
            return BSP_ERROR;
        }
        if (ulValue & NET_STATE_LINKOK)
        {
            break;
        }
        BspSysMsDelay_Sys(1000);
    }

    if (loop == PHY_WAIT_LINK_UP_MAX_TIME)
    {
        dbgInfo("Get phy link up status time out\n");
    }
    else
    {
        dbgInfo("Get phy link up status need %d s\n", loop);
    }

    if (ulValue & NET_STATE_LINKOK)
    {
        dbgInfo("Debug net port is ON\n");
        dbgInfo("PHY DUPLEX %s\n", ((ulValue & 0x10)>>4)? "FULL":"HALF");

        L2ssXmacSpeed = BootGetSfpPhyLinkSpeed(ulValue);

        port = (g_iic1_is_serdes0 ? L2SS_TRXP1:L2SS_TRXP2);
        dbgInfo("%s cfg Mac[%d]End! \n",__FUNCTION__,port);

        L2sssMacSetInterfaceMode(port, L2ssXmacSpeed);

        return PHY_LINK_UP;
    }
    else
    {
        //L2sssMacSetInterfaceMode(port, L2ssXmacSpeed);
        dbgInfo("Debug net port is OFF\n");
        return PHY_LINK_DOWN;
    }
}
/* Ended by AICoder, pid:b505543928b14bc2a48c3bef43ee6c2b */

UINT32 QcellCfgL2ssMac(VOID)
{
    zte_printf_s("QcellCfgL2ssMac g_iic1_is_serdes0 is %d\n", g_iic1_is_serdes0);

    if (g_iic1_is_serdes0)/*qcell分支*/
    {
        L2ssPortEnable(L2SS_TRXP1);
        L2ssXmacEnable(L2SS_TRXP1);
        zte_printf_s("QcellCfgL2ssMac qcell case\n");
    }
    else/*样片板分支*/
    {
        L2ssPortEnable(L2SS_TRXP2);
        L2ssXmacEnable(L2SS_TRXP2);
        L2sssMacSetInterfaceMode(L2SS_TRXP2, SPEED_100);/* 对应的serdes2，xmac配置100M */
        zte_printf_s("phy serdes 2 cfg xamc 100M\n");

        L2ssPortEnable(L2SS_TRXP3);
        L2ssXmacEnable(L2SS_TRXP3);
        L2sssMacSetInterfaceMode(L2SS_TRXP3, SPEED_1000);/* 对应的serdes3，xmac配置1000M */
        zte_printf_s("15eg serdes 3 cfg xamc 1000M\n");
    }
    return 0;
}


UINT32 BootCfgPllAndL2ss(VOID)
{
    UINT32 ulOptFlag = 0;
    UINT32 ulindex = 0;
    UINT32 ulportindex = 0;


    BootSetupEthFlag();
    DpdIcHalRegTblInit();

    BootNtlSoftResetInit();

    if (g_qcell_type == QCELL_BOARDTYPE)
    {
        /*according to reset type */
        zte_printf_s("qcell case\n");
        /*qcell 是serdes1对接PHY芯片，样片板是serdes2对接PHY芯片，serdes3对接15EG*/
        ulindex = (g_iic1_is_serdes0 ? (1<<L2SS_TRXP1):((1<<L2SS_TRXP2) | (1<<L2SS_TRXP3)));
        ulportindex = g_iic1_is_serdes0 ? L2SS_TRXP1:(L2SS_TRXP2 | L2SS_TRXP3);
        #if 1
        /*
        复位l2ss动作，暂注释掉备忘
        BootRstL2ss();
        BspSysMsDelay_Sys(200);
        */
        BootRlsL2ssRst();
        BootL2ssInit();
        BootPortVlanInit(16,(ulindex|(1<<L2SS_TRXP43)));
        BootIpVlanInit(17,ulindex|(1<<L2SS_TRXP43));
        #endif
        /*0xff表示无效光口号，初始化板上phy芯片*/
        BootSerdesInit(ulindex,0xff);
        BootXmacInit(ulindex);
        /*
        BootNtlSoftResetInit();
        */
        L2ssPortEnable(L2SS_TRXP43);

        QcellCfgL2ssMac();
        BootGetPhyLinkStatusAndCfgMacSpeed();
        
    }
    else
    {
        ulOptFlag = BootGetCooperIndex();
        if (IIC1_SUPPORT_COOPER == ulOptFlag)
        {
            ulindex = (g_iic1_is_serdes0 ? (1<<L2SS_TRXP0):(1<<L2SS_TRXP1));
            ulportindex = g_iic1_is_serdes0 ? L2SS_TRXP0:L2SS_TRXP1;
        }
        else if (IIC2_SUPPORT_COOPER == ulOptFlag)
        {
            ulindex = (g_iic1_is_serdes0 ? (1<<L2SS_TRXP1):(1<<L2SS_TRXP0));
            ulportindex = g_iic1_is_serdes0 ? L2SS_TRXP1:L2SS_TRXP0;
        }
        else
        {
            zte_printf_s("%s no cooper case\n",__FUNCTION__);
            return 0;
        }

        /*
        复位l2ss动作，暂注释掉备忘
        BootRstL2ss();
        */
        zte_printf_s("g_iic1_is_serdes0 = 0x%x\n",g_iic1_is_serdes0);
        zte_printf_s("ulindex=0x%x,ulportindex=0x%x\n",ulindex,ulportindex);
        //BspSysMsDelay_Sys(200);
        BootRlsL2ssRst();
        BootL2ssInit();
        BootPortVlanInit(16,((1<<L2SS_TRXP0)|(1<<L2SS_TRXP1)|(1<<L2SS_TRXP43)));
        BootIpVlanInit(17,(ulindex|(1<<L2SS_TRXP43)));

        BootSerdesInit(ulindex,ulOptFlag);
        BootXmacInit(ulindex);
        L2ssPortEnable(L2SS_TRXP43);
        L2ssPortEnable(ulportindex);
        L2ssXmacEnable(ulportindex);
        BootGetSfpLinkStatusAndCfgMacSpeed(ulOptFlag);
    }

    BootSetEth0DebugIpMacAddr();
    BspSystem("ifconfig eth0 mtu 1492");

    return BSP_OK;
}

UINT32 BootGetKebootFlashAddr()
{
    UINT8 flag = 0xff;
    UINT32 ret = 0;
    UINT32 master_addr;
    UINT32 slave_addr;

    ret = BspFlashRead(DOUBLE_KEBOOT_CTRL_ADDR_413, (UCHAR *)&flag,1);
    if (ret != BSP_OK )
    {
        zte_printf_s("%s read flash 0x%08x failed\n",__FUNCTION__ ,DOUBLE_KEBOOT_CTRL_ADDR_413);
        return MASTER_KEBOOT_ZTE_HEAD_ADDR;
    }

    if (flag != 0)
    {
        master_addr= MASTER_KEBOOT_ZTE_HEAD_ADDR;
        slave_addr = SLAVE_KEBOOT_ZTE_HEAD_ADDR;

    }
    else
    {
        master_addr = SLAVE_KEBOOT_ZTE_HEAD_ADDR;
        slave_addr =  MASTER_KEBOOT_ZTE_HEAD_ADDR;
    }

    if (MASTER_KUBOOT_OK == BootGetKBootMSFlag())
    {
        return master_addr;
    }
    else
    {
        return slave_addr;
    }

}

#if 0

UINT32 BootGetFipFlashAddr()
{
    UINT8 flag = 0xff;
    UINT32 ret = 0;
    UINT32 master_addr;
    UINT32 slave_addr;

    ret = BspFlashRead(DOUBLE_FIP_CTRL_ADDR_413, (UCHAR *)&flag,1);
    if (ret != BSP_OK )
    {
        zte_printf_s("%s read flash 0x%08x failed\n",__FUNCTION__ ,DOUBLE_FIP_CTRL_ADDR_413);
        return MASTER_FIP_ZTE_HEAD_ADDR;
    }

    if (flag != 0)
    {
        master_addr= MASTER_FIP_ZTE_HEAD_ADDR;
        slave_addr = SLAVE_FIP_ZTE_HEAD_ADDR;

    }
    else
    {
        master_addr = SLAVE_FIP_ZTE_HEAD_ADDR;
        slave_addr =  MASTER_FIP_ZTE_HEAD_ADDR;
    }

    if (SLAVE_UBOOT_OK == BootGetKBootMSFlag())
    {
        return slave_addr;
    }
    else
    {
        return master_addr;
    }


}


UINT32 BootGetBL2FlashAddr()
{
    UINT8 flag = 0xff;
    UINT32 ret = 0;
    UINT32 master_addr;
    UINT32 slave_addr;

    ret = BspFlashRead(DOUBLE_BL2_CTRL_ADDR_413, (UCHAR *)&flag,1);
    if (ret != BSP_OK )
    {
        zte_printf_s("%s read flash 0x%08x failed\n",__FUNCTION__ ,DOUBLE_BL2_CTRL_ADDR_413);
        return MASTER_BL2_ZTE_HEAD_ADDR;
    }

    if (flag != 0)
    {
        master_addr= MASTER_BL2_ZTE_HEAD_ADDR;
        slave_addr = SLAVE_BL2_ZTE_HEAD_ADDR;

    }
    else
    {
        master_addr = SLAVE_BL2_ZTE_HEAD_ADDR;
        slave_addr =  MASTER_BL2_ZTE_HEAD_ADDR;
    }

    if (SLAVE_UBOOT_SPL_OK == BootGetUBootMSFlag())
    {
        return slave_addr;
    }
    else
    {
        return master_addr;
    }

}


#endif

/* Started by AICoder, pid:y4581h98f1hf5cb146e00862e0927f3fda368f63 */
CHAR* BootGetBootVerAddr(UINT32 type)
{
    CHAR* ver_addr = NULL;

    switch (type)
    {
        case E_BL0_VER:
        {
            ver_addr = M0_VER_ADRS;
            break;
        }

        case E_BL1_VER:
        {
            ver_addr = SPL_VER_ADRS;
            break;
        }
        case E_BL2_VER:
        {
            ver_addr = UBOOT_VER_ADRS;
            break;
        }
        case E_BL3_VER:
        {
            ver_addr = BOOTK_VER_ADRS;
            break;
        }
        default:
        {
            return NULL;
        }
        break;
    }

    return ver_addr;
}
/* Ended by AICoder, pid:y4581h98f1hf5cb146e00862e0927f3fda368f63 */

#if 0
/**********************************************************************
* 函数名称：BootGetVersion
* 功能描述： 读取Flash中boot版本号
* 输入参数： headPtr需要获取到版本的指针，默认不使用，除非传入非空指针，model:0 获取一级Boot版本，1 获取二级keboot版本
* 输出参数： 无
* 返 回 值： 0:正常  非0:异常
* 其它说明： 获取后清除
* 修改日期        版本号     修改人          修改内容
* 修改日期     版本号        修改人                修改内容
* ---------------------------------------------------
* 2015/10/22     V1.0         10242265           创建
***********************************************************************/
UINT32 BootGetVersion(char *headPtr,char model)
{
    UINT32 ulRet=0;
    UINT32 HEAD_ADDR=0;
    unsigned char  *ptVerFileHeadChar = NULL;
    T_VerFileHeader *ptVerFileHeader = NULL;
    if (NULL==headPtr)
    {
        return BSP_ERROR;
    }
    ptVerFileHeadChar = (unsigned char *)malloc(sizeof(T_VerFileHeader));
    if (NULL == ptVerFileHeadChar)
    {
        zte_printf_s("malloc error!!\n");
        return -1;
    }

    zte_memset_s((unsigned char *)ptVerFileHeadChar,sizeof(T_VerFileHeader)，0,sizeof(T_VerFileHeader));

    if (0==model)
    {
        HEAD_ADDR = BootGetUBootSplHeadAddr();

        /*从启动地址读取版本头到ptVerFileHeadChar*/
        ulRet=BspFlashRead(HEAD_ADDR, ptVerFileHeadChar,sizeof(T_VerFileHeader));
        if (BSP_OK==ulRet)
        {
            ptVerFileHeader = (T_VerFileHeader *)ptVerFileHeadChar;
            ptVerFileHeader->ucVerNo[44-1]='\0';
            memcpy(headPtr,ptVerFileHeader->ucVerNo,zte_strnlen_s(ptVerFileHeader->ucVerNo,44)+1);

            dbgPrn("SPL Boot Version: %s\n", headPtr);
        }
        else
        {
            zte_printf_s("\nRead SPL BOOT Header error!\n");
        }

        HEAD_ADDR = BootGetUBootHeadAddr();

    }
    else
    {
        HEAD_ADDR = BootGetKebootHeadAddr();
    }

    zte_memset_s((unsigned char *)ptVerFileHeadChar,sizeof(T_VerFileHeader),0,sizeof(T_VerFileHeader));

    /*从启动地址读取版本头到ptVerFileHeadChar*/
    ulRet=BspFlashRead(HEAD_ADDR, ptVerFileHeadChar,sizeof(T_VerFileHeader));
    if (BSP_OK==ulRet)
    {
        ptVerFileHeader = (T_VerFileHeader *)ptVerFileHeadChar;
        ptVerFileHeader->ucVerNo[44-1]='\0';
        memcpy(headPtr,ptVerFileHeader->ucVerNo,zte_strnlen_s(ptVerFileHeader->ucVerNo,44)+1);
    }
    else
    {
        zte_printf_s("\nRead BOOT Header error!\n");
    }

    free(ptVerFileHeadChar);
    ptVerFileHeadChar = NULL;
    ptVerFileHeader = NULL;
    return ulRet;
}

#endif

#define BOOT_VER_STR_MAX_LEN   150
#define BOOT_VER_MAX_LEN   16
/**********************************************************************
* 函数名称：BootGetVersion
* 功能描述： 读取Flash中boot版本号
* 输入参数： headPtr需要获取到版本的指针，默认不使用，除非传入非空指针，model:0 获取一级Boot版本，1 获取二级keboot版本
* 输出参数： 无
* 返 回 值： 0:正常  非0:异常
* 其它说明： 获取后清除
* 修改日期        版本号     修改人          修改内容
* 修改日期     版本号        修改人                修改内容
* ---------------------------------------------------
* 2015/10/22     V1.0         10242265           创建
***********************************************************************/
UINT32 BootGetVersion(char *headPtr,char model)
{
    ULONG ulRet=0;
    ULONG HEAD_ADDR=0;
    ULONG check_flag=0;
    unsigned char  *ptVerFileHeadChar = NULL;
    T_VerFileHeader *ptVerFileHeader = NULL;
    if (NULL==headPtr)
    {
        return BSP_ERROR;
    }
    ptVerFileHeadChar = (unsigned char *)malloc(sizeof(T_VerFileHeader));
    if (NULL == ptVerFileHeadChar)
    {
        zte_printf_s("malloc error!!\n");
        return -1;
    }
    check_flag = BootGetKBootMSFlag();
    if (MASTER_KUBOOT_OK == check_flag)
    {
        if (0==model)
        {
            HEAD_ADDR=MASTER_BL2_ZTE_HEAD_ADDR;
        }
        else if (1==model)
        {
            HEAD_ADDR=MASTER_FIP_ZTE_HEAD_ADDR;
        }
        else
        {
            HEAD_ADDR=MASTER_KEBOOT_ZTE_HEAD_ADDR;
        }
    }
    else if ( SLAVE_KUBOOT_OK == check_flag)
    {
        if (0==model)
        {
            HEAD_ADDR=SLAVE_BL2_ZTE_HEAD_ADDR;
        }
        else if (1==model)
        {
            HEAD_ADDR=SLAVE_FIP_ZTE_HEAD_ADDR;
        }
        else
        {
            HEAD_ADDR=SLAVE_KEBOOT_ZTE_HEAD_ADDR;
        }
    }
    else
    {
        free(ptVerFileHeadChar);
        ptVerFileHeadChar = NULL;
        return BSP_ERROR;
    }
    /*从启动地址读取版本头到ptVerFileHeadChar*/
    ulRet=BspFlashRead(HEAD_ADDR, ptVerFileHeadChar,sizeof(T_VerFileHeader));
    if (BSP_OK==ulRet)
    {
        ptVerFileHeader = (T_VerFileHeader *)ptVerFileHeadChar;
        ptVerFileHeader->ucVerNo[44-1]='\0';
        memcpy(headPtr,ptVerFileHeader->ucVerNo,zte_strnlen_s(ptVerFileHeader->ucVerNo,44)+1);
    }
    else
    {
        zte_printf_s("\nRead BOOT Header error!\n");
    }
    free(ptVerFileHeadChar);
    ptVerFileHeadChar = NULL;
    ptVerFileHeader = NULL;
    return ulRet;
}
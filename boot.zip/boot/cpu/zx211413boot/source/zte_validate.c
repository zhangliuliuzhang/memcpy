// SPDX-License-Identifier: GPL-2.0+
/*
 * Copyright 2015 Freescale Semiconductor, Inc.
 */

#include <zte_validate.h>
#include <malloc.h>
#include <bignum.h>
#include "cJSON.h"
#include <string.h>

static uint32_t ui_nv_counter;
static uint32_t ui_csf_version;

#define ZTE_VALIDATE_DEBUG 1

#define CHECK_KEY_LEN(key_len) (((key_len) == 2 * RSA_3K_KEY_SZ_BYTES) || \
                ((key_len) == 2 * RSA_4K_KEY_SZ_BYTES) || \
                ((key_len) == 2 * RSA_2K_KEY_SZ_BYTES))

static char hash_val[SHA256_BYTES] = {0};

static const char barker_code[CSF_BARKER_LEN] = { 0x00, 0x21, 0x14, 0x13 };
/*validate secure boot dbg flag*/
int g_boot_validate_dbg = 0;
/*algorithm of this cert and next cert*/
static T_CSF_ALGRITHM algorithm_cert[2]={0};

void boot_validate_dbg(int uiEnable)
{
    if (uiEnable)
    {
        g_boot_validate_dbg=1;
    }
    else
    {
        g_boot_validate_dbg=0;
    }
}
/*
*  get nv counter from csf_header
*/
static uint32_t zte_get_csf_nv_counter(uintptr_t csf_haddr)
{
    struct csf_hdr *hdr = (struct csf_hdr *)csf_haddr;
    return SWAP32(hdr->csf_nv.nv_num);
}
/*
*  get version from csf_header
*/
static uint32_t zte_get_csf_version(uintptr_t csf_haddr)
{
    struct csf_hdr *hdr = (struct csf_hdr *)csf_haddr;
    return SWAP32(hdr->csf_version.ver);
}
/*
*  get algorithm from csf_header
*/
static uint32_t zte_get_algorithm(uintptr_t csf_haddr, int select)
{
    struct csf_hdr *hdr = (struct csf_hdr *)csf_haddr;

    if (NULL == hdr)
    {
        zte_printf_s("hdr is NULL !\n");
        return -1;
    }

    if (select > CSF_CPUKEY_NUM)
    {
        zte_printf_s("inputpara select ERROR!\n");
        return -1;
    }
    #if 0 /*因为4.2安全头还没发填入下级证书算法，所以此处暂时按照这样处理。*/
    algorithm_cert[select].hash_alg = SWAP16(hdr->csf_algorithm[select].hash_alg);
    algorithm_cert[select].sig_alg = SWAP16(hdr->csf_algorithm[select].sig_alg);
    algorithm_cert[select].img_hash_alg = SWAP16(hdr->csf_algorithm[select].img_hash_alg);
    #else
    algorithm_cert[select].hash_alg = SWAP16(hdr->csf_algorithm[CSF_BOOTKEY_NUM].hash_alg);
    algorithm_cert[select].sig_alg = SWAP16(hdr->csf_algorithm[CSF_BOOTKEY_NUM].sig_alg);
    algorithm_cert[select].img_hash_alg = SWAP16(hdr->csf_algorithm[CSF_BOOTKEY_NUM].img_hash_alg);
    #endif
    return 0;
}
/*
 * Calculate hash of input data
 */
int calc_data_hash(char *pdata, uint32_t pdata_len, char *calc_hash, int pub_select)
{
    void *ctx;
    uint16_t hash_alg=0;
    int ret = 0;

    if (pub_select == CSF_BOOTKEY_NUM)
    {
        hash_alg = algorithm_cert[CSF_BOOTKEY_NUM].hash_alg;
    }
    else
    {
        hash_alg = algorithm_cert[CSF_CPUKEY_NUM].hash_alg;
    }

    if (ZTE_SHA256 != hash_alg)
    {
        zte_printf_s("csf header input algorithm error!!! hash_alg=0x%x\n", hash_alg);
        return -1;
    }

    /* Calculate hash of the esbc key */
    ret = hash_init_sha256( &ctx);
    if (ret)
    {
        zte_printf_s("%s hash_init error ret= 0x%x\n", __func__, ret);
        return ret;
    }

    ret = hash_update_sha256(ctx, pdata, pdata_len, 1);
    if (ret)
    {
        zte_printf_s("%s hash_update error ret= 0x%x\n", __func__, ret);
        return ret;
    }

    /* Copy hash at destination buffer */
    ret = hash_finish_sha256(ctx, calc_hash, SHA256_BYTES);
    if (ret)
    {
        zte_printf_s("%s hash_finish error ret= 0x%x\n", __func__, ret);
        return ret;
    }
    return 0;
}

/*
* Authenticate by Non-Volatile counter
*
* To protect the system against rollback, the platform includes a non-volatile
* counter whose value can only be increased. All certificates include a counter
* value that should not be lower than the value stored in the platform. If the
* value is larger, the counter in the platform must be updated to the new
* value.
*
*
* Return: 0 = success, Otherwise = error
*/
int zte_auth_nvctr(uint32_t ui_counter)
{
    int iret=0;
    uint32_t i_efuse_rdcounter=0;
    uint32_t i_nvmode=0;

    /*check, if rollback is not enable, return */
    iret = BspGetNvModeSwitch(&i_nvmode);
    if (0 != iret)
    {
        zte_printf_s("get rollback mode error!!\n");
        return 0;
    }

    if (i_nvmode == 0)
    {
        zte_printf_s("rollback mode not enable!\n");
        return 0;
    }
    iret = BspUserNvValRead(&i_efuse_rdcounter);
    if (0 != iret)
    {
        zte_printf_s("get rollback version counter error!!\n");
        return -1;
    }
    if (i_efuse_rdcounter > ui_counter)
    {
        zte_printf_s("rd_counter is %d, plat_counter is %d \n", ui_counter, i_efuse_rdcounter);
        return -1;
    }

    return 0;
}
/*
* get the version pub key of cur.swv to verify cpu swv. this func is called after cert_File is verified.
* boot key is key[0], version key is key[1]
* input : CA_CERT file ADDR (csf head + ca_cert)
* output: pub_key
* output: pub_key_len
*/
int ldPkeyFromCAheader(unsigned int csf_haddr, char *pub_key, unsigned int *pub_key_len)
{
    struct csf_hdr *hdr = NULL;
    int iret=0;

    if (0 == csf_haddr)
    {
        zte_printf_s("%s input para is NULL\n", __func__);
        iret = -1;
    }

    hdr = (struct csf_hdr *)csf_haddr;
    switch (algorithm_cert[CSF_CPUKEY_NUM].sig_alg)
    {
        case ENCRYPTION_RSA1024:
        {
            *pub_key_len = RSA_1K_KEY_SZ_BYTES;
            zte_memcpy_s(pub_key, *pub_key_len, &(hdr->csf_pkey_next_key.value[RSA_2K_KEY_SZ_BYTES]), *pub_key_len);
            break;
        }
        case ENCRYPTION_RSA2048:
        {
            *pub_key_len = RSA_2K_KEY_SZ_BYTES;
            zte_memcpy_s(pub_key, *pub_key_len, &(hdr->csf_pkey_next_key.value[RSA_1K_KEY_SZ_BYTES]), *pub_key_len);
            break;
        }
        case ENCRYPTION_RSA3072:
        {
            *pub_key_len = RSA_3K_KEY_SZ_BYTES;
            zte_memcpy_s(pub_key, *pub_key_len, &(hdr->csf_pkey_next_key.value[0]), *pub_key_len);
            break;
        }
        default:
        {
            *pub_key_len = RSA_2K_KEY_SZ_BYTES;
            zte_memcpy_s(pub_key, *pub_key_len, &(hdr->csf_pkey_next_key.value[RSA_1K_KEY_SZ_BYTES]), *pub_key_len);
            zte_printf_s("version pkey not support encrytion algorithm 0x%x\n", algorithm_cert[CSF_CPUKEY_NUM].sig_alg);
            break;
        }
    }
    *pub_key_len = (*pub_key_len)*2;

    if (!CHECK_KEY_LEN(*pub_key_len))
    {
        zte_printf_s("%s csf header key len is %d, error\n", __func__, *pub_key_len);
        iret = -1;
    }

    return iret;
}
/*
* use boot key verify boot or ca cert file. boot key is use key[0].
*
*/
int zte_secure_validate(const uintptr_t csf_haddr)
{
    struct csf_hdr *hdr = (struct csf_hdr *)csf_haddr;
    uint32_t pkey_len = 0;
    char* pkey_addr = 0;
    uint32_t psign_len = 0;
    char* psign_addr = 0;
    char calc_hash[SHA256_BYTES] = {0};
    char *img_addr_addr = NULL;
    uint32_t img_len=0;
    int ret=0;

    /* check barker code */
    if ((hdr->csf_version.id.name) != (*(int *)barker_code))
    {
        zte_printf_s("barker compare failed!\n");
        zte_printf_s("name = 0x%x\n", hdr->csf_version.id.name);
        zte_printf_s("test 0x%x\n",*(int *)barker_code);
        return -1;
    }
    else
    {
        zte_printf_s("barker compare pass!!\n");
    }

    /*parse csf header, and save it*/
    ui_nv_counter = zte_get_csf_nv_counter(csf_haddr);
    ui_csf_version = zte_get_csf_version(csf_haddr);
    zte_get_algorithm(csf_haddr, CSF_BOOTKEY_NUM);
    zte_get_algorithm(csf_haddr, CSF_CPUKEY_NUM);

    #ifdef ZTE_VALIDATE_DEBUG
    zte_printf_s("<---------------csf parse----------->\n");
    zte_printf_s("nvcounter = 0x%x csf_version = 0x%x \n", ui_nv_counter, ui_csf_version);
    zte_printf_s("this cert algorithm: cert_hash = 0x%x, cert_sig=0x%x, img_hash = 0x%x\n", algorithm_cert[CSF_BOOTKEY_NUM].hash_alg,
                 algorithm_cert[CSF_BOOTKEY_NUM].sig_alg, algorithm_cert[CSF_BOOTKEY_NUM].img_hash_alg);
    zte_printf_s("next cert algorithm: cert_hash = 0x%x, cert_sig=0x%x, img_hash = 0x%x\n", algorithm_cert[CSF_CPUKEY_NUM].hash_alg,
                 algorithm_cert[CSF_CPUKEY_NUM].sig_alg, algorithm_cert[CSF_CPUKEY_NUM].img_hash_alg);
    zte_printf_s("<---------------csf parse end-------->\n");
    #endif
    /*get pubkey offset and size*/
    /*check if support encrrption alg*/
    switch (algorithm_cert[CSF_BOOTKEY_NUM].sig_alg)
    {
        /* Started by AICoder, pid:n6b3156bfb22e5e144880a021047952eb804c9b7 */
        case ENCRYPTION_RSA1024:
        {
            pkey_len = RSA_1K_KEY_SZ_BYTES*2;
            psign_len = RSA_1K_KEY_SZ_BYTES;
            pkey_addr = (char *)&(hdr->csf_pkey_this_key.value[RSA_2K_KEY_SZ_BYTES]);
            psign_addr = (char *)&(hdr->csf_fingerprint[RSA_2K_KEY_SZ_BYTES]);
            break;
        }
        case ENCRYPTION_RSA2048:
        {
            pkey_len = RSA_2K_KEY_SZ_BYTES*2;
            psign_len = RSA_2K_KEY_SZ_BYTES;
            pkey_addr = (char *)&(hdr->csf_pkey_this_key.value[RSA_1K_KEY_SZ_BYTES]);
            psign_addr = (char *)&(hdr->csf_fingerprint[RSA_1K_KEY_SZ_BYTES]);
            break;
        }
        case ENCRYPTION_RSA3072:
        {
            pkey_len = RSA_3K_KEY_SZ_BYTES*2;
            psign_len = RSA_3K_KEY_SZ_BYTES;
            pkey_addr = (char *)&(hdr->csf_pkey_this_key.value[0]);
            psign_addr = (char *)&(hdr->csf_fingerprint[0]);
            break;
        }
        /* Ended by AICoder, pid:n6b3156bfb22e5e144880a021047952eb804c9b7 */
        default:
        {
            zte_printf_s("Boot pkey not support encrytion algorithm 0x%x\n", algorithm_cert[CSF_BOOTKEY_NUM].sig_alg);
            break;
        }
    }

    if (!CHECK_KEY_LEN(pkey_len))
    {
        zte_printf_s("%s get pub_key addr=%p, len=0x%x;  len is error\n", __func__, pkey_addr, pkey_len);
        return -2;
    }

    if ((psign_len*2) != pkey_len)
    {
        zte_printf_s("%s get sign addr=0x%p, len=0x%x error\n", __func__, psign_addr, psign_len);
        return -4;
    }
    /* Started by AICoder, pid:h44a88ccd13040e14f440a87e0adb80b0df17bdf */
    calc_data_hash((char *)&(hdr->csf_pkey_this_key.value[0]), CSF_PKEY_MAX_SIZE, calc_hash, CSF_BOOTKEY_NUM);
    /* Ended by AICoder, pid:h44a88ccd13040e14f440a87e0adb80b0df17bdf */
    if (g_boot_validate_dbg)
    {
        zte_printf_s("calc sha256 of root key is:");
        for (int i = 0; i < SHA256_BYTES; i++)
        {
            zte_printf_s("%02x", calc_hash[i]);
        }
        zte_printf_s("\n");
    }

    /*cmp hash_of_pkey with efuse*/
    /* Started by AICoder, pid:17474ye378r55fe147770b9d101d5708f201657e */
    ret = BspHashCmp((UINT32 *)calc_hash, SHA256_BYTES/4);
    /* Ended by AICoder, pid:17474ye378r55fe147770b9d101d5708f201657e */

    if (ret != 0)
    {
        zte_printf_s("%s arm_smccc_smc  SMC_EFUSE_HASH_CMP FAILED!! ret=0x%x\n", __func__, ret);
        return ret;
    }

    /*get image_addr && img_size*/
    /* Started by AICoder, pid:ya4408a600te69f14d5b0936a0d4ec07edc2c165 */
    img_addr_addr = (char *)(uintptr_t)SWAP32(hdr->csf_image.offset_low);
    img_addr_addr = (char *)((unsigned int)csf_haddr + (unsigned int)img_addr_addr);
    /* Ended by AICoder, pid:ya4408a600te69f14d5b0936a0d4ec07edc2c165 */
    img_len = SWAP32(hdr->csf_image.size);
    if (g_boot_validate_dbg)
    {
        zte_printf_s("csf_haddr=%p img_addr=%p  len=0x%x\n", csf_haddr, img_addr_addr, img_len);
    }

    /*compare image hash with hdr->hash*/
    calc_data_hash(img_addr_addr, img_len, calc_hash, CSF_BOOTKEY_NUM);

    ret = memcmp(calc_hash, &(hdr->csf_image.hash[SHA256_BYTES]),SHA256_BYTES);
    if (ret)
    {
        if (g_boot_validate_dbg)
        {
            zte_printf_s("calc sha256 of image is:");
            for (int i = 0; i < SHA256_BYTES; i++)
            {
                zte_printf_s("%02x", calc_hash[i]);
            }
            zte_printf_s("\n");
            zte_printf_s("header sha256 of image is:");
            for (int i = 0; i < SHA256_BYTES; i++)
            {
                zte_printf_s("%02x", hdr->csf_image.hash[i+SHA256_BYTES]);
            }
            zte_printf_s("\n");
        }
        zte_printf_s("%s compare image hash with hdr->hash error!! ret=0x%x", __func__, ret);
        return ret;
    }
    /*get header hash to hash_val*/
    ret = calc_data_hash((char *)hdr, sizeof(struct csf_hdr) - CSF_SIGN_MAX_SIZE, hash_val, CSF_BOOTKEY_NUM);
    if (ret)
    {
        zte_printf_s("%s zte_calc_esbchdr_hash ret=0x%x", __func__, ret);
        return ret;
    }
    if (g_boot_validate_dbg)
    {
        zte_printf_s("calc sha256 of header is:");
        for (int i = 0; i < SHA256_BYTES; i++)
        {
            zte_printf_s("%02x", hash_val[i]);
        }
        zte_printf_s("\n");
    }

    ret = rsa_auth_signature(hash_val, (char *)pkey_addr, pkey_len, (char *)psign_addr, psign_len);
    if (ret)
    {
        zte_printf_s("rsa_auth_signature failed! ret=0x%x\n", ret);
        zte_printf_s("pkey_addr = %p, psign_addr=%p\n", pkey_addr, psign_addr);
        return ret;
    }

    return 0;
}

/*
* get sign data from jSon file in protect flash
*/
uint32_t BspGetVersionSign(uchar *ucBuf, uint32_t ulFileLen, uint32_t ulFileCrc, uchar* ucSign, uint32_t *uiSign_len)
{
    cJSON * ver_sign_json = NULL;
    cJSON * ver_pkg = NULL;
    cJSON * pkg_child = NULL;
    cJSON * hash_type = NULL;
    cJSON * ver_infos = NULL;
    cJSON * ver_child = NULL;
    cJSON * size = NULL;
    cJSON * crc = NULL;
    cJSON * hashSign = NULL;
    uint32_t ulVerLen =0;
    uint32_t ulVerCrc = 0;

    if (( ucSign == NULL) || (ucBuf == NULL))
    {
        zte_printf_s("input para is null !\n");
        return -1;
    }
    ver_sign_json = cJSON_Parse((char *)ucBuf);

    if (NULL==ver_sign_json)
    {
        zte_printf_s("ver_sinput is NULL !\n");
        return -1;
    }

    ver_pkg = cJSON_GetObjectItem(ver_sign_json,"pkgGroup");
    if (NULL == ver_pkg)
    {
        zte_printf_s("Get pkgGroup Object Failed [crc:%d len:%d] !\n", ulFileCrc, ulFileLen);
        return -1;
    }
    pkg_child = ver_pkg->child;
    while (pkg_child !=NULL)
    {

        hash_type = cJSON_GetObjectItem(pkg_child,"hashType");

        if (NULL == hash_type)
        {
            zte_printf_s("Get hashType Object Failed [crc:%d len:%d] !\n", ulFileCrc, ulFileLen);
            break;
        }

        ver_infos = cJSON_GetObjectItem(pkg_child, "softInfos");

        if (NULL == ver_infos)
        {
            zte_printf_s("Get softInfos Object Failed [crc:%d len:%d] !\n", ulFileCrc,ulFileLen);
            break;
        }
        ver_child = ver_infos->child;
        while (ver_child != NULL)
        {
            size = cJSON_GetObjectItem(ver_child, "size");
            crc = cJSON_GetObjectItem(ver_child, "crc");
            if ( crc==NULL || size==NULL )
            {
                zte_printf_s("Get size & crc Object Failed [crc:%d len:%d] !\n", ulFileCrc,ulFileLen);
                break;
            }
            ulVerLen = (u32)size->valueint;
            ulVerCrc = (u32)crc->valueint;
            zte_printf_s("sizze %d,crc %d Get Succ !\n", ulVerLen, ulVerCrc);
            if ((ulFileLen == ulVerLen)&&(ulFileCrc==ulVerCrc))
            {
                hashSign = cJSON_GetObjectItem(ver_child, "hashSign");
                if (NULL == hashSign)
                {
                    zte_printf_s("Get hashSign Failed [crc:%d len:%d] !\n", ulFileCrc,ulFileLen);
                    return -1;
                }
                if (strlen(hashSign->valuestring) > MAX_SIGN_STRING_LEN )
                {
                    zte_printf_s("string signlen error\n");
                    return -1;
                }

                mbedtls_base64_decode((uchar *)ucSign, RSA_4K_KEY_SZ_BYTES, (size_t *)uiSign_len,
                    (uchar *)hashSign->valuestring, strlen(hashSign->valuestring) );

                if (g_boot_validate_dbg)
                {
                    zte_printf_s("hash lenth %ld, string %s [crc:%d len:%d] !\n",
                                strlen(hashSign->valuestring),hashSign->valuestring,ulFileCrc,ulFileLen);

                    for (int i =0; i< *uiSign_len; i++)
                    {
                        zte_printf_s("0x%x ",*(ucSign+i));
                        if ((i+1)%8==0) zte_printf_s("\n");
                    }
                }
                return 0;
            }
            ver_child = ver_child->next;
        }
        pkg_child = pkg_child->next;
    }
    return -1;
}

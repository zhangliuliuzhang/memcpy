/**************************************************************************
 * 版权所有 (C)2001, 深圳市中兴通讯股份有限公司
 *
 * 文件名称: zx211413boot.h
 * 文件标识:
 * 内容摘要:
 * 其它说明:
 * 当前版本: ZXSDR BBUV120B01
 * 作    者:
 * 完成日期:
 *
 * 修改记录1:
 *    修改日期: 2012年06月21日
 *    版 本 号: ZXSDR BBUV120B01
 *    修 改 人: 耿佳佳
 *    修改内容: 创建
 * 修改记录2:
 **************************************************************************/

#ifndef _ZX2112413BOOT_H_
#define _ZX2112413BOOT_H_

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

#include "watchdog.h"
/* Started by AICoder, pid:986ebrc21cw071614b910829f011de0c7992378e */
#include "bspcommonstdlog.h"
#include "crmboot.h"
/* Ended by AICoder, pid:986ebrc21cw071614b910829f011de0c7992378e */
#ifndef I2C_USED_IN_KERNEL
#include "i2cbusti.h"
#include "i2cbusapi.h"
#endif
#include "sfp.h"

#define BSP_RAMDISK_LOAD_ADDR (0x05800000)
#define CFG_PROMPT  "DPDIC->"
extern UINT32 g_qcell_type;
typedef enum
{
    BOOT_UART_MODE,
    BOOT_FLASH_MODE,
    BOOT_ETH_MODE,
    BOOT_PCIE_MODE,
}E_BOOT_MODE;

#if 1
#define CONFIG_RECORD_TIME  //dpdic3 support record time node
#endif

#define CRC_BIG_LITTLE_SWAP_LONG(x) \
    ((unsigned int)( \
        (((unsigned int)(x) & (unsigned int)0x000000ffUL) << 24) | \
        (((unsigned int)(x) & (unsigned int)0x0000ff00UL) <<  8) | \
        (((unsigned int)(x) & (unsigned int)0x00ff0000UL) >>  8) | \
        (((unsigned int)(x) & (unsigned int)0xff000000UL) >> 24) ))

#define CRC_BIG_LITTLE_SWAP_USHORT(x) \
    ((unsigned short)( \
        (((unsigned short)(x) & (unsigned short)0x00ff) << 8) | \
        (((unsigned short)(x) & (unsigned short)0xff00) >> 8) ))
#define readb(addr) \
  ({ unsigned char __v = (*(volatile unsigned char *) (addr)); __v; })
#define readw(addr) \
  ({ unsigned short __v = (*(volatile unsigned short *) (addr)); __v; })
#define readl(addr) \
  ({ unsigned long __v = (*(volatile unsigned long *) (addr)); __v; })
    
#define writeb(b, addr) \
      (void)((*(volatile unsigned char *) (addr)) = (b))
#define writew(b, addr) \
      (void)((*(volatile unsigned short *) (addr)) = (b))
#define writel(b, addr) \
      (void)((*(volatile unsigned int *) (addr)) = (b))


#if defined(COMPILE_FOR_KEXEC_BOOT)

struct list_head
{
    struct list_head *next;
    struct list_head *prev;
};
static inline void __list_add(struct list_head *new,
                              struct list_head *prev,
                              struct list_head *next)
{
        next->prev = new;
        new->next = next;
        new->prev = prev;
        prev->next = new;
}
static inline void list_add(struct list_head *new, struct list_head *head)     //加入一个新节点
{
    __list_add(new, head, head->next);
}
static inline void list_add_tail(struct list_head *new, struct list_head *head)
{
    __list_add(new, head->prev, head);
}
#define LIST_HEAD_INIT(name)      { &(name), &(name) }
#define LIST_HEAD(name)      struct list_head name = LIST_HEAD_INIT(name)


/*初始化调用宏，a为调用函数名(无入参)，b 为失败的时候计入全局告警的宏*/
#define PreInitCallAdd(a,b) 											\
	do{																	\
		TBoardInitCall *p##a;p##a = NULL;								\
		p##a= malloc(sizeof(TBoardInitCall));							\
		if (p##a == NULL)												\
		{																\
			printf("%s malloc fail.\n",#a);								\
		}																\
		strcpy(p##a->cCallName,#a);										\
		p##a->pInitCall = &a;											\
		list_add_tail(&(*p##a).list,&BoardPreCall_list);				\
		p##a->ulFailMacro = b;											\
		p##a->ulCnt = sBoardPreInitCallCnt;sBoardPreInitCallCnt++;		\
	}while(0)

#define list_for_each(pos, head) for (pos = (head)->next;pos != (head);pos = pos->next)
#define list_entry(ptr, type, member)    container_of(ptr, type, member)
#define container_of(ptr, type, member)   ({ const typeof( ((type *)0)->member ) *__mptr =  (ptr); (type *)( (char *)__mptr - offsetof(type,member) );})
#ifndef offsetof
#define offsetof(type,  member)    ((size_t) &((type *)0)-> member)


#endif



typedef struct list_head Tlist;

typedef struct tagBoardInitCall
{
	ULONG (*pInitCall)();    /*调用的函数*/
	ULONG ulRet;			 /*调用函数的返回值*/
	//ULONG ulMask;			 /*返回值的掩码*/
	char cCallName[32];      /*调用名，一般情况下就是函数名*/
	//char cDiscription[256];/*描述，暂时定义为对应返回值各个bit的说明*/
	ULONG ulFailMacro;       /*如果函数执行不成功，对应的失败宏值*/
	ULONG ulCnt;			 /*在初始化链表中的排序从0开始*/
	struct list_head list;   /*链表*/

}TBoardInitCall;
#define BOARD_INIT_FAIL_DEVMMAP              BSP_BIT(0)<<1/* 物理地址空间映射 */
#define BOARD_INIT_FAIL_NOT_RECORD			 0				/* 不记录这个告警到总告警 */
#define BOARD_INIT_FAIL_FLASH                BSP_BIT(0)<<17/* Flash初始化*/


#define CFG_HZ	       			(1000)
#define CONFIG_SYS_HZ			CFG_HZ
#define CONFIG_MDIO_TIMEOUT	(3 * CONFIG_SYS_HZ)
#define GMII_ADDR_REG         (0x00000010)  /*Register 4 (GMII Address Register) offset :0x0010*/
#define GMII_DATA_REG         (0x00000014)  /*Register 5 (GMII Data Register) offset :0x0014*/
/*#define ERROR_BASE_BSP_COMMON                   ((ERROR_BASE_BSP + BSP_COMMON)<<16)*/
//#define BSP_E_POINTER_NULL                      (ERROR_BASE_BSP_COMMON + 0x0001)  /* 指针参数为空    */
#define BSP_E_REG_ACCESS_TIMEOUT     (ERROR_BASE_BSP_COMMON + 0x000c)
#define APP_HR_RESERVED_SIZE   (0x10000)
#define APP_BOX_RESERVED_SIZE  (0x80000)
#define APP1_RESERVED_SIZE       APP_HR_RESERVED_SIZE
#define APP2_RESERVED_SIZE       APP_BOX_RESERVED_SIZE

/*******************************内存定义************************************/
#define DRAM_4M                  (0x0400000)

#define DRAM_32M                 (0x02000000)
#define DRAM_64M                 (0x04000000)
#define DRAM_128M                (0x08000000)
#define DRAM_512M                (0x20000000)


#define LOCAL_MEM_LOCAL_ADRS     (0x00000000) /* 低端内存留给系统分配用 */
#define LOCAL_MEM_SIZE           DRAM_128M   /* 内存128M */
extern  unsigned long            g_ulBoardRamSize;

#define SYS_PHYS_MEM_TOP         (0x00600000)
#define OSS_MEM_SIZE             (0x00080000)
#define BSP_MEM_SIZE             (0x00080000)
#define BSP_VER_PROTECT_SIZE     (0x00400000)
#define APP_RESERVED_SIZE        (0x100000)
#define USER_RESERVED_SIZE       (OSS_MEM_SIZE + BSP_MEM_SIZE + BSP_VER_PROTECT_SIZE + APP_RESERVED_SIZE)

#define SYS_MEM_TOP              (SYS_PHYS_MEM_TOP - USER_RESERVED_SIZE)
#define USER_RESERVED_ADDR       (SYS_MEM_TOP)
#define APP_RESERVED_ADDR        (USER_RESERVED_ADDR + BSP_VER_PROTECT_SIZE)
#define OSS_MEM_ADDR             (APP_RESERVED_ADDR + APP_RESERVED_SIZE)
#define BSP_MEM_ADDR             (OSS_MEM_ADDR + OSS_MEM_SIZE)
#define BSP_VER_PROTECT_ADDR     (SYS_MEM_TOP)

#define RESET_INFO_ADDR          (BSP_MEM_ADDR + 0x57C0)

#define BK_RESV_HIGH_MEM_ADDR                 0x00000000
#define BOOTAPP_LOG_BASE_OFFSET               0x00540000  // 规划出256KB用于boot CUR/BAK两段BOOTAPP LOG日志区，各128KB
#define BOOTAPP_LOG_PHY_ADDR                  (BK_RESV_HIGH_MEM_ADDR + BOOTAPP_LOG_BASE_OFFSET)
#define APP_LOG_BASE_OFFSET                   0x00600000
#define APP_LOG_PHY_ADDR                      (BK_RESV_HIGH_MEM_ADDR + APP_LOG_BASE_OFFSET)
#define APP_LOG_SIZE                          0x100000    // CPU CUR/BAK两段 APP LOG, 各1MB
#define UBIFS_RO_LOG_ADDR                     0x4bf000   //文件系统变只读后，peb存储内存区

#define LAST_KMSG_BASE_OFFSET                 0x00580000
#define LAST_KMSG_ADDR                        (BK_RESV_HIGH_MEM_ADDR + LAST_KMSG_BASE_OFFSET)
#define LAST_KMSG_SIZE                        0x40000   // CPU CUR/BAK两段 LAST_KMSG, 各256KB

#define COM_INTERRUPT_NUM                     0x40            /* 串口中断号 */

#define MODULEID_ADDR                  ((_BspZteGpioGet(0)) ? (0x1340000):(0x1C00000))
#define PROTECT_ZONE_OFFSET_MTD1        ((_BspZteGpioGet(0)) ? (0x110000):(0x500000))

#define SFP_WAIT_LINK_UP_MAX_TIME 20
#define PHY_WAIT_LINK_UP_MAX_TIME 10



typedef unsigned long       BUS_WIDTH;


#define DOUBLE_KEBOOT_CTRL_ADDR_413    0xDC40017C

#define DOUBLE_FIP_CTRL_ADDR_413    0xDC400180
#define DOUBLE_BL2_CTRL_ADDR_413    0xDC400184


/*BL2_ZTE_HEAD_ADDR flash 中版本头位置, 0x100000/0xE40000 */
#define MASTER_BL2_ZTE_HEAD_ADDR  ((_BspZteGpioGet(0))?(0x90000):(0x100000))
#define SLAVE_BL2_ZTE_HEAD_ADDR   ((_BspZteGpioGet(0))?(0x9D0000):(0xE40000))
/*fip flash 烧写起始地址=版本头起始地址, 0x140000/0xE80000*/
#define MASTER_FIP_ZTE_HEAD_ADDR  ((_BspZteGpioGet(0))?(0xB0000):(0x140000))
#define SLAVE_FIP_ZTE_HEAD_ADDR   ((_BspZteGpioGet(0))?(0x9F0000):(0xE80000))
/*keboot flash 烧写起始地址=版本头起始地址, 0x240000/0xF80000*/
#define MASTER_KEBOOT_ZTE_HEAD_ADDR  ((_BspZteGpioGet(0))?(0xD0000):(0x240000))
#define SLAVE_KEBOOT_ZTE_HEAD_ADDR   ((_BspZteGpioGet(0))?(0xA10000):(0xF80000))

#endif

/*reg definition will be used in zx211413boot.c*/
#define CHIP_ID_REG        0x64
#define BOOT_MODE_REG      0x30
#define MDIO_CLK_CFG       0x21C
#define REC_RESET_0        0xd70       /*硬件复位原因记录寄存器*/
#define SOFT_RESET_OFFSET  0x178       /*软件复位原因记录寄存器*/

/*addr map definition*/
#define L2SS_MAP_ADDR      (0xC2800000) 
#define BOOT_L2SS_BASE_ADDR     (0xC0000000)
#define M0_MSG_MAP_ADDR    (0xD5100000)
#define CRM_MAP_ADDR       (0xD4C00000)

#define WATCH_DOG_MAP_ADDR (0xDC104000)

#define MII_MAP_ADDR      (0xC10F0000)
#define PWM_MAP_ADDR       (0xD6500000)

#define PAD_0_MAP_ADDR     (0xC1100000)
#define PAD_1_MAP_ADDR	   (0xD6600000)

#define UBAR_SCR_MAP_ADDR  (0xD4B00000)

#define CHIP_MASTER_TYPE   0
#define CHIP_SLAVER_TYPE   1

#define IIC1_SUPPORT_COOPER   0
#define IIC2_SUPPORT_COOPER   1
#define IIC_NO_SUPPORT_COOPER   2



#define RUN_LED_PWM_ID    0

enum
{
    E_BOOT_MODE_LOW_UART,
    E_BOOT_MODE_SPI,
    E_BOOT_MODE_HIGH_UART,
    E_BOOT_MODE_ETH,
};

enum
{
    E_BL0_VER, /*m0*/
    E_BL1_VER, /*spl*/
    E_BL2_VER, /*uboot*/
    E_BL3_VER  /*keboot*/
};



#ifndef I2C_USED_IN_KERNEL
typedef enum  e_board_i2c_bus_id
{
    I2C_BUS_ID_SFP0 = 2,
    I2C_BUS_ID_SFP1,
    NUM_BRD_I2C_BUS
} eBrdI2cBusId;


static T_I2C_TI_PARA s_zteI2cPriv[NUM_BRD_I2C_BUS] =
{
    [I2C_BUS_ID_SFP0] =
    {
        .I2CBusId    = I2C_BUS_ID_1,
        .ulSpeed     = OMAP_I2C_FAST_MODE,
        .ulSlaveaddr = 0x56,
    },

    [I2C_BUS_ID_SFP1] =
    {
        .I2CBusId    = I2C_BUS_ID_2,
        .ulSpeed     = OMAP_I2C_FAST_MODE,
        .ulSlaveaddr = 0x56,
    },
};


static T_I2C_BUS_DRV s_atI2cBus[NUM_BRD_I2C_BUS] =
{
     [I2C_BUS_ID_SFP0] =
    {
         .I2CBusId     = I2C_BUS_ID_SFP0,
         .I2CDrvType   = I2C_BUS_TYPE_ZX211413,
         .pPrivateData = &s_zteI2cPriv[I2C_BUS_ID_SFP0],
         .Retry = 3,
    },
    /*lint -e26*/
    [I2C_BUS_ID_SFP1] =
    {
         .I2CBusId     = I2C_BUS_ID_SFP1,
         .I2CDrvType = I2C_BUS_TYPE_ZX211413,
         .pPrivateData = &s_zteI2cPriv[I2C_BUS_ID_SFP1],
         .Retry = 3,
    },
    /*lint +e26*/
} ;
#endif

typedef enum
{
	L2SS_TRXP0 = 0,
	L2SS_TRXP1,
	L2SS_TRXP2,   
	L2SS_TRXP3, 
	L2SS_MAX_EPORT_ID,

	L2SS_TRXP32 = 4,
	L2SS_TRXP33,  
	L2SS_TRXP34,
	L2SS_TRXP35,
	L2SS_TRXP36,
	L2SS_TRXP37,
	L2SS_TRXP38,
	L2SS_TRXP39,
	L2SS_TRXP40,
	L2SS_TRXP41,
	L2SS_TRXP42,
	L2SS_TRXP43,
	L2SS_TRXP44,
	L2SS_TRXP45,
	L2SS_TRXP46,
	L2SS_TRXP47,
	L2SS_TRXP48,
	L2SS_TRXP49,
	L2SS_TRXP50,
	L2SS_TRXP51,
	L2SS_TRXP52,
	L2SS_TRXP53,
	L2SS_TRXP54,
	L2SS_TRXP55,
	L2SS_MAX_IPORT_ID,
	L2SS_TRXP_NUM =32,

}E_TrxpId;

typedef enum
{
	L2SS_AGENT_PORT0 = L2SS_TRXP32,
	L2SS_AGENT_PORT1 = L2SS_TRXP38,
	L2SS_AGENT_PORT2,
	L2SS_AGENT_PORT3,
	L2SS_AGENT_PORT4,
	L2SS_AGENT_PORT5,
	L2SS_AGENT_PORT6, /*L2SS_TRXP43*/
	MAX_AGENT_PORT_IDX,
}E_TrxpAgentId;


#define BOOT_MODE_UART_LOW   	  0
#define BOOT_MODE_SPI   	      1	
#define BOOT_MODE_UART_HIGH       2
#define BOOT_MODE_ETH             3

#define QCELL_BOARDTYPE   1
#define PLATFORM_BOARDTYPE   0
#define IIC1_SERDES0    1
#define IIC1_SERDES1    0


/************************************全局函数声明***********************************/
ULONG SetDefaultCmdline(VOID);
ULONG BootGetMemVir();
VOID BootLedRun(UCHAR ucMode);
ULONG BootGetFsRecoverFlag(VOID);
ULONG BootGetPhyLinkStatus(VOID);
ULONG BootGetVersion(char *headPtr,char model);
ULONG BootSetWatchDogTime (unsigned short timeout);
ULONG BootDebugMiiRead(ULONG ulCsrClockRange,ULONG ulGR, ULONG ulPA, ULONG *pulData);
ULONG BootDebugMiiWrite(ULONG ulCsrClockRange,ULONG ulGR, ULONG ulPA, ULONG ulValue);
ULONG SetEthProMode(UCHAR ucValue);
ULONG BootGetChipMsFlag();
ULONG getLastKmsgAddr(VOID);
ULONG getAppLogPhyAddr(VOID);
ULONG getFsLogPhyAddr(VOID);
ULONG BootFlagGet(VOID);
VOID SaveKebootLog(VOID);
VOID SaveKebootBakLog(VOID);
VOID SaveKebootCurLog(VOID);
UINT32 BootGetBoardHwResetType(VOID);
UINT32 BootGetBoardSwResetType(VOID);
UCHAR* BootGetBoardResetInfoAddr(VOID);
/* Started by AICoder, pid:ge796d2c84s7b6b142f90b8a30100701aad8276d */
ULONG BspMknod(const char * filepath, const char *oprator, const char *majornew, const char* minornew);
UINT32 BootGetDownloadFlag(void);
UINT32 BootCfgPllAndL2ss(void);
VOID boot_flag_set();
extern UINT32 _BspZteGpioGet(UINT32 port);
extern int ushell_init();
extern ULONG GetCmdline(VOID);
extern UINT32 DpdIcHalRegTblInit();
/* Ended by AICoder, pid:ge796d2c84s7b6b142f90b8a30100701aad8276d */
#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif


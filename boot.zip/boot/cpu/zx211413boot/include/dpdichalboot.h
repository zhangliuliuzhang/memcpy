/**************************************************************************
 * 版权所有 (C)2001, 深圳市中兴通讯股份有限公司
 *
 * 文件名称: zx211410boot.h
 * 文件标识:
 * 内容摘要:
 * 其它说明:
 * 当前版本:
 * 作    者:
 * 完成日期:
 *
 * 修改记录1:
 *    修改日期:
 *    版 本 号:
 *    修 改 人:
 *    修改内容: 创建
 * 修改记录2:
 **************************************************************************/

#ifndef _DPDICHALBOOT_H_
#define _DPDICHALBOOT_H_

#include <netinet/in.h>
#include <arpa/inet.h>

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */




#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif


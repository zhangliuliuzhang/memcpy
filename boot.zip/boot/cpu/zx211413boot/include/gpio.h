/*---------------------------------------------------------------------------------------------------------------------
 * 版权所有(C)2000-2011, 中兴通讯股份有限公司
 *
 * 文 件 名: uart.h
 *
 * 作    者: 10010370
 *
 * 接口描述:
 *     Bootrom软件uart接口处理
 *
 * 版    本: v1.0
 *
 * ------------------------------------------------------------------------------------------------------------------
 *
 *     修改日期         修改人            修改内容
 *     20111103         10010370          创建
 *
 *-------------------------------------------------------------------------------------------------------------------*/

#ifndef _GPIO_H_
#define _GPIO_H_
/* Started by AICoder, pid:y0abcg7c40u8a491489809c86056ad05e7a18126 */
#include "zx211413gpio.h"
/* Ended by AICoder, pid:y0abcg7c40u8a491489809c86056ad05e7a18126 */

#define GPIO_LEVEL_LOW                  0x00            // 低电平
#define GPIO_LEVEL_HIGH                 0x01            // 高电平


/*BK 关注的GPIO定义如下*/
#define DPDIC_GPIO_NOR_FLASH_SINGLE             0
#define DPDIC_GPIO_LED_RUN             28
#define DPDIC_GPIO_LED_ALARM           32
//#define DPDIC_GPIO_MASTER_SLAVE_FLAG    14   /*1 = MASTER   0 = SLAVE*/
//#define DPDIC_GPIO_DDR_CAPACITY_FLAG    15   /*1 = 1GB 0 = 512MB*/
//#define DPDIC_GPIO_SFP1_PLACE_FLAG    9   /*1 = out-place 0 = in-place*/
//#define DPDIC_GPIO_SFP0_PLACE_FLAG    5   /*1 = out-place 0 = in-place*/
#define DPDIC_GPIO_BOARDTYPE_QCELL              12   /*1 = qcell,0 = others*/
#define DPDIC_GPIO_SERDES_IIC            7        /*1 = iic1 to serdes0, 0 = iic1 to serdes1*/


#define GPIO_OUT_MODE   0
#define GPIO_IN_MODE    1
#define PWM_OUT_MODE    2


#define PAD0_GPIO0_TO_15_OFFSET     0x188
#define PAD0_GPIO22_TO_25_OFFSET    0x174
#define PAD1_GPIO16_TO_21_OFFSET    0x78
#define PAD1_GPIO26_TO_34_OFFSET    0x1c


#define GPIO_ENABLE     1
#define GPIO_DISABLE    0


#define BIT_8           8
#define BIT_9           9

UINT32 BootCfgGpioPadBaseAddr(UINT32 padIdx,UINT32 base);
/* Started by AICoder, pid:s9e25q625fu8e3d146cc0aaec06f0f0bd1b78068 */
extern UINT32 _BspZteGpioSetMode(ULONG ulPort, ULONG ulMode);
extern UINT32 _BspZteGpioSet(ULONG ulPort, ULONG ulIsHigh);
UINT32 BootWrIcGpioPadEn(UINT32 gpio,UINT32 en);
UINT32 BootInitBoardGpioPort(void);
UINT32 BootLedCtrl(UINT32 ulLedname, UINT32 ulLedMode);
UINT32 BootSetPadGpioPinMode(UINT32 mode);
/* Ended by AICoder, pid:s9e25q625fu8e3d146cc0aaec06f0f0bd1b78068 */
#endif  /* _UART_H_ */

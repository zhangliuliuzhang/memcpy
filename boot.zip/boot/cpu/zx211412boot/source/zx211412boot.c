/*****************************************************************************
 * 版权所有(C) 2010, ZTE Corp. RRU Bsp Platform
 *----------------------------------------------------------------------------
 * 模 块 名 : BSP
 * 文件名称 : zx211410boot.c
 * 文件标识 : {[N/A]}
 * 内容摘要 : zx211410 cpu bootapp接口实现
 * 注意事项 : 无
 * 作    者 : 耿佳佳
 * 创建日期 : 2015-10-22 08:28:34
 * 当前版本 : Ver1.0
 *----------------------------------------------------------------------------
 * 变更记录 :
 *
 * $记录1
 * 变 更 单: $0000000(N/A)
 * 责 任 人: 耿佳佳
 * 修改日戳: 2015-10-22 08:28:34
 * 变更说明: 创建文件
 *
 *----------------------------------------------------------------------------
 */

#include "stdio.h"
#include <sys/types.h>
#include <sys/stat.h>
#include <netinet/in.h>
#include <fcntl.h>
#include <errno.h>
#include "vxadp.h"
#include <math.h>

#include "bsppub.h"
#include "bspcomm.h"
//#include "ru_basetypes.h"
#include "bsperrcode.h"
#include "zx211412boot.h"
#include "phy.h"
#include "mii.h"
#include "gpio.h"
#include "l2ssboot.h"
#include "bspcommonstdlog.h"

#if defined(COMPILE_FOR_KEXEC_BOOT)
#include "bootadp.h"
#include "halboot.h"
/* Started by AICoder, pid:1ea982b258r7a6414a1909bfa007da0142c1b4a9 */
#include "flash.h"
/* Ended by AICoder, pid:1ea982b258r7a6414a1909bfa007da0142c1b4a9 */
/*#else
#include "hal_addrmap.h"
#include "hal_regaddr.h"*/
#endif


#ifdef COMPILE_FOR_KEXEC_BOOT
/**************************************************************************
 *                        宏
 **************************************************************************/

#define MAC_FRAME_FILTER  (0x00000004)   /*MAC帧过滤寄存器 offset:0x0004 */
/* 单板复位开关变量，0--不复位，1--复位 */


/**************************************************************************
 *                         数据类型                                       *
 **************************************************************************/

/**************************************************************************
 *                         全局变量定义                                   *
 **************************************************************************/

/**************************************************************************
 *                         外部变量声明
 **************************************************************************/

/**************************************************************************
*                         局部函数声明
**************************************************************************/

/**************************************************************************
*                         全局函数声明
**************************************************************************/
extern VOID MainLoop ();
extern VOID BspFunction(unsigned char * ucpsymbname, unsigned char * ucpboardname);
extern UINT32 BootFlashInit(VOID);
extern UINT32 BootSoftModInit(VOID);
extern UINT32 BspGetPhyStatus(UINT32 ulDevNum, UINT32 *pulStat, UINT32 ulMode);

UINT32 SetDefaultCmdline();
UINT32 BootIcInit();
UINT8 g_icChipId = 0;
/**************************************************************************
 *                         函数实现
 **************************************************************************/

#define uswap_32(x) \
    ((((x) & 0xff000000) >> 24) | \
    (((x) & 0x00ff0000) >>  8) | \
    (((x) & 0x0000ff00) <<  8) | \
    (((x) & 0x000000ff) << 24))

#define cpu_to_le32(x)        uswap_32(x)
#define dsb() __asm__ __volatile__ ("dsb" : : : "memory")
Tlist BoardPreCall_list     = {&(BoardPreCall_list),&(BoardPreCall_list)};
/*BspBoardPreInit的调用链表函数序号*/
static ULLONG sBoardInitError   = 0;

UINT32 g_ulLedFlag = 0;
UINT32  g_ulRamReservedAddr =0;
UINT32  g_ulBootRegisterAddr =0;
UINT32 g_board_type = PLATFORM_BOARDTYPE;

static UINT32 aulWatchdogAddr =0;
static UINT32 aulMdioVirAddr = 0;
static UINT32 aulCrmVirAddr = 0;
static UINT32 aulPad0VirAddr = 0;
static UINT32 aulPad1VirAddr = 0;
static UINT32 aulScrVirAddr = 0;
static UINT32 aulL2ssVirAddr = 0;
static UINT32 aulPwmVirAddr = 0;


/**************读,写IC寄存器********************/
UINT32 BootRdIcScrReg(UINT32 ulAddr)
{
    UINT32 ulRegAddr = 0;

    ulRegAddr = ulAddr + aulScrVirAddr;

    return *((volatile UINT32 *)ulRegAddr);
}


UINT32 BootWrIcPwmReg(UINT32 ulAddr, UINT32 ulData)
{
    UINT32 ulRegAddr = 0;

    ulRegAddr = ulAddr + aulPwmVirAddr;

    *((volatile UINT32 *)ulRegAddr) = ulData;

    return BSP_OK;
}

UINT32 BootRdIcPwmReg(UINT32 ulAddr)
{
    UINT32 ulRegAddr = 0;

    ulRegAddr = ulAddr + aulPwmVirAddr;

    return *((volatile UINT32 *)ulRegAddr);
}


/*****************************************************************************
*  函数名称   : BspGetCpuType(*)
*  功能描述   : 双boot模块用于获取cpu类型
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : 无
*  输出参数   : 无
*  返 回 值   : 成功 - BSP_OK
*  其它说明   :
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A), ty@2019-1-29 由IC2.0移植创建（添加了CPU类型）
*----------------------------------------------------------------------------
*/
UINT32 BspGetCpuType (UCHAR *pucCpuType)
{
    if (NULL == pucCpuType)
        return BSP_ERROR_NULL_POINTER;

    *pucCpuType = BSP_ZX211412;
    return BSP_OK;
}


/**********************************************************************
* 函数名称:BootGetChipIdx
* 功能描述:配置当前属于芯片的chip id
* 输入参数:
* 输出参数:
* 返 回 值:
* 其它说明:
* 修改日期        版本号     修改人          修改内容
* -----------------------------------------------
***********************************************************************/
UINT32 BootGetBootMode()
{
    return (BootRdIcScrReg(BOOT_MODE_REG) & 0x03);
}


/**********************************************************************
* 函数名称:BootGetChipIdx
* 功能描述:配置当前属于芯片的chip id
* 输入参数:
* 输出参数:
* 返 回 值:
* 其它说明:
* 修改日期        版本号     修改人          修改内容
* -----------------------------------------------
***********************************************************************/
UINT8 BootGetIcChipId(VOID)
{
    return (BootRdIcScrReg(CHIP_ID_REG) & 0x3);
}

UINT32 BootGetGlobalChipId()
{
    g_icChipId = BootGetIcChipId();
    printf("zx211412 chip id %d\n",g_icChipId);
    return BSP_OK;
}

#if 0

/**************************************************************************
 * 函数名称: int BootSetLedFlag(VOID)
 * 功能描述: 工装 应用程序入口
 * 输入参数: 无
* 输出参数:
 * 返 回 值: 无
* 其它说明:
*
* 修改日期:    版本号     修改人        修改内容
* -----------------------------------------------
* 2010-05-25     V1.0      xxx        Created
**************************************************************************/

UINT32 BootSetLedFlag(UINT32 ulSwitch)
{
    if( 0 == ulSwitch)
        g_ulLedFlag = 0;
    else
        g_ulLedFlag = 1;

    return BSP_OK;
}

VOID BootLedBling(VOID)
{

    UINT32 ucClkRate = sysClkRateGet();
    BootLedCtrl(BSP_LED_ID_RUN,BSP_LED_OP_OFF);/*RUN灯灭*/
    taskDelay(ucClkRate);
    BootLedCtrl(BSP_LED_ID_RUN,BSP_LED_OP_ON);/*RUN灯亮*/
    taskDelay(ucClkRate);
    /*先亮后灭的话，出现调度原因导致的闪灯过后常亮RUN灯偶发不亮的问题，调整为先灭后亮规避该问题*/
}
#endif

/**************************************************************************
* 函数名称: BootSetPwmEn
* 功能描述: 设置Pwm的功能使能，pwmId (0-2), en(0去使能，1使能)
* 输入参数: 无
* 输出参数:
* 返 回 值: 无
* 其它说明:
*
* 修改日期:    版本号     修改人        修改内容
* -----------------------------------------------
**************************************************************************/
UINT32 BootSetPwmEn(UINT32 pwmId,UINT32 en)
{
    UINT32 reg = 0;

    reg = BootRdIcPwmReg(pwmId * 0x10 + 0x10);

    if(1 == en)
    {
        reg |= 0x1;
    }
    else
    {
        reg &= (~0x1);
    }

    return BootWrIcPwmReg(pwmId * 0x10 + 0x10, reg);
}

/**************************************************************************
* 函数名称: BootSetPwmCfg
* 功能描述: 设置Pwm的pwmId, polar, clk_div, period, duty
* 输入参数: 无
* 输出参数:
* 返 回 值: 无
* 其它说明:
*
* 修改日期:    版本号     修改人        修改内容
* -----------------------------------------------
**************************************************************************/
UINT32 BootSetPwmCfg(UINT32 pwmId,UINT32 polar, UINT32 clk_div, UINT32 period,UINT32 duty)
{
    UINT32 reg;

    reg = (clk_div << 2) | (polar << 1) | 0;

    BootWrIcPwmReg(0x4,0);
    BootWrIcPwmReg(pwmId * 0x10 + 0x10, reg);
    BootWrIcPwmReg(pwmId * 0x10 + 0x14, period);
    BootWrIcPwmReg(pwmId * 0x10 + 0x18, duty);
    BootSetPwmEn(pwmId,1);
    return BSP_OK;
}


/**********************************************************************
* 函数名称:BootLedRun
* 功能描述:led_run led灯闪烁模式
* 输入参数: ucMode  0 只亮run灯,  1 run灯周期性闪
* 输出参数:无。
* 返 回 值:无
* 其它说明:
* 修改日期        版本号     修改人          修改内容
* -----------------------------------------------
* 2015/10/12            V1.0            00086970                       创建
***********************************************************************/
VOID BootLedRun(UCHAR ucMode)
{
#if !defined(CONFIG_ZX211412_ADS)
    if(0 == ucMode)/*只亮run灯,其他灯灭 */
    {
        /*run led gpio mode*/
        BootSetPwmEn(RUN_LED_PWM_ID,0);
        BootSetRunLedPinOutMode(GPIO_OUT_MODE);

        BootLedCtrl(BSP_LED_ID_ALM, BSP_LED_OP_OFF);
        BootLedCtrl(BSP_LED_ID_RUN, BSP_LED_OP_ON);
    }
    else if(1 == ucMode)/*run灯周期性闪烁*/
    {
        /*run led pwm 0.5hz*/
        BootSetPwmCfg(RUN_LED_PWM_ID,0,1000,5000,2500);
        BootSetRunLedPinOutMode(PWM_OUT_MODE);

        BootLedCtrl(BSP_LED_ID_ALM, BSP_LED_OP_OFF);
    }
    else if(2 == ucMode)/*所有灯都全亮*/
    {
        /*run led gpio mode*/
        BootSetPwmEn(RUN_LED_PWM_ID,0);
        BootSetRunLedPinOutMode(GPIO_OUT_MODE);

        BootLedCtrl(BSP_LED_ID_RUN, BSP_LED_OP_ON);
        BootLedCtrl(BSP_LED_ID_ALM, BSP_LED_OP_ON);
    }
    else
    {
        printf("BootLedRun, input params[%d] error\n", ucMode);
    }
#endif
}

/*****************************************************************************
*  函数名称   : BootGetBoardRamSize(*)
*  功能描述   : Bsp 获取单板物理内存大小
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : 无
*  输出参数   : 无
*  返 回 值   : 内存大小单位Byte
*  其它说明   :
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A), 姜建奎@2012-02-29 16:14:27 创建
*  $0000000(N/A), ty@2019-1-29 由IC2.0移植创建（IC3.0使用的DDR大小为512M）
*----------------------------------------------------------------------------
*/
UINT32 BootGetBoardRamSize(VOID)
{
    UINT32 ulRet = DRAM_512M;
    return ulRet;
}


/*****************************************************************************
*  函数名称   : BootGetChipMsFlag(*)
*  功能描述   : 获取Chip是主芯片还是从芯片设计模式
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : 无
*  输出参数   : 无
*  返 回 值   : 内存大小单位Byte
*  其它说明   :
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A), 姜建奎@2012-02-29 16:14:27 创建
*  $0000000(N/A), ty@2019-1-29 由IC2.0移植创建（IC3.0使用的DDR大小为512M）
*----------------------------------------------------------------------------*/
UINT32 BootGetChipMsFlag()
{
    return CHIP_MASTER_TYPE;
}
#define KDA_DEVICE_NAME "/dev/KernDrvAgt"
static int g_iKdaDrvFd = -1;
ULONG OpenKdaModel(void)
{
    int ret;
    if(CHIP_SLAVER_TYPE == BootGetChipMsFlag()) return BSP_OK;
    BspMknod(KDA_DEVICE_NAME,"c","10","244");
    if ((g_iKdaDrvFd = open(KDA_DEVICE_NAME,O_RDWR | O_SYNC )) < 0)
    {
        zte_printf_s("open " KDA_DEVICE_NAME " failed!");
        return BSP_ERROR;
    }
    ret = BspPhyAddrToKernel((unsigned long long)BOOTAPP_LOG_PHY_ADDR, COM_INTERRUPT_NUM, g_iKdaDrvFd);
    if(ret != BSP_OK)
    {
        zte_printf_s("BspPhyAddrToKernel failed!\n");
        return BSP_ERROR;
    }
    return BSP_OK;
}
/*****************************************************************************
*  函数名称   : BootDevMemMap(*)
*  功能描述   : 使用mmap将物理地址映射到用户进程虚拟地址空间
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : 无
*  输出参数   : 无
*  返 回 值   : BSP_OK, 其它值为失败
*  其它说明   :
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A), zhaoyun@2014-5-27 14:07:25 创建
*----------------------------------------------------------------------------
*/
UINT32 BootDevMemMap(VOID)
{
     /* 打开内存设备的文件描述符 */
    int     iFd;
    int     iSpaceProt = PROT_READ | PROT_WRITE;
    UINT32   iCount = 0;

#define TO_MAP_LIST(a)      #a, &a
        /*lint -e529*/
        /*lint -e64*/
        struct map_list_t
        /* Started by AICoder, pid:5ef59c43a4jabc6148480911b08449010ce61840 */
        {
            const char  *pucVarName;
            UINT32      *pulVarAddr;
            UINT32    ulMapBase;
            UINT32    ulMapSize;
        }
        /* Ended by AICoder, pid:5ef59c43a4jabc6148480911b08449010ce61840 */
        map_list[] =
        {
            /*map_list[0] 根据4.0的情况需要进行修改*/
            {TO_MAP_LIST(g_ulRamReservedAddr),    (0x11200000),          0x00600000},/*reserv mem*/
            {TO_MAP_LIST(aulWatchdogAddr),        WATCH_DOG_MAP_ADDR,       0x00002000},/*wdt*/
            {TO_MAP_LIST(aulMdioVirAddr),       MII_MAP_ADDR,          0x00100000},/*mii*/
            {TO_MAP_LIST(aulL2ssVirAddr),       L2SS_MAP_ADDR,           0x04000000}, /*l2ss*/
            {TO_MAP_LIST(aulCrmVirAddr),        CRM_MAP_ADDR,           0x00001000}, /*CRM access*/
            {TO_MAP_LIST(aulPwmVirAddr),        PWM_MAP_ADDR,            0x00100000}, /*pwm access*/
            {TO_MAP_LIST(aulPad0VirAddr),        PAD_0_MAP_ADDR,        0x00100000}, /*pad0 access*/
            {TO_MAP_LIST(aulPad1VirAddr),        PAD_1_MAP_ADDR,        0x00100000}, /*pad1 access*/
            {TO_MAP_LIST(aulScrVirAddr),        UBAR_SCR_MAP_ADDR,        0x00000100}, /*ubar scr access*/
        };

    if(CHIP_SLAVER_TYPE == BootGetChipMsFlag())
    {
        map_list[0].ulMapBase =  0x11200000;
    }
    else
    {
        map_list[0].ulMapBase =  0x2e200000;
    }

    /*lint +e529*/
    /*lint +e64*/
    #define DO_ADDR_MAP(a)                                          \
        *((a)->pulVarAddr) = (long)mmap(0, (a)->ulMapSize,          \
            iSpaceProt, MAP_SHARED, iFd, (a)->ulMapBase);           \
        if (*((a)->pulVarAddr) == -1)                               \
        {                                                           \
            dbgErr("mmap %s failed %s, %d\n",                       \
                (a)->pucVarName, strerror(errno), errno);           \
            close(iFd);                                             \
            return BSP_ERROR;                                       \
        }                                                           \
        dbgInfo("%-20s = %#x\n", (a)->pucVarName, *((a)->pulVarAddr));


    /* 打开存储空间映射 */
    if ((iFd = open("/dev/mem", O_RDWR | O_SYNC)) < 0)
    {
        dbgErr("open /dev/mem failed\n");
        return BSP_ERROR;
    }

    for (iCount = 0; iCount < sizeof(map_list)/sizeof(map_list[0]); iCount++)
    {
        DO_ADDR_MAP(&map_list[iCount]);
        usleep(1000);
    }
    close(iFd);
    BootCfgL2ssBaseAddr(aulL2ssVirAddr);
    BootCfgCrmAccessBaseAddr(aulCrmVirAddr);
    BootCfgWdtBaseAddr(aulWatchdogAddr);
    BootCfgMiiBaseAddr(aulMdioVirAddr);
    BootCfgGpioPadBaseAddr(0,aulPad0VirAddr);
    BootCfgGpioPadBaseAddr(1,aulPad1VirAddr);
    return BSP_OK;
}

#if defined(CONFIG_RECORD_TIME)
/**********************************************************************
* 函数名称:BootGetMemVir
* 功能描述:获取此CPU映射的高端内存上电时间基地址
* 输入参数:无
* 输出参数:无
* 返 回 值:无
* 其它说明:上电计时高端内存基地址
* 修改日期        版本号     修改人          修改内容
* -----------------------------------------------
*  $0000000(N/A), 李耀清@2019-07-09 21:18:00
*----------------------------------------------------------------------------
*/
UINT32 BootGetMemVir(VOID)
{
    if (NULL == g_ulRamReservedAddr)
    {
        printf("Error: g_ulRamReservedAddr is NULL!!\n");
        return 0;
    }
    return (g_ulRamReservedAddr+SYS_PHYS_MEM_TOP-BSP_MEM_SIZE + 0x8000);/*(0x1B600000)+6M-512K+32K,BSP MEM 开始的32K*/
}
#endif

/**********************************************************************
* 函数名称:BootSetSlaveChipNum
* 功能描述:配置从片数量，1代表只有主片
* 输入参数:
* 输出参数:
* 返 回 值:
* 其它说明:
* 修改日期        版本号     修改人          修改内容
* -----------------------------------------------
*  $0000000(N/A), ty@2019-1-29 由IC2.0移植创建
***********************************************************************/
UINT32 BootSetSlaveChipNum(VOID)
{
    HAL_SetSlaveChipNum((UINT32)1);
    return BSP_OK;
}
/**********************************************************************
* 函数名称:BootSupportOptDebug
* 功能描述:获取电模块在位情况
* 输入参数:
* 输出参数:
* 返 回 值:  1：电模块1在位
            0：电模块0在位
            2：电模块不在位
            3：在位但非电模块
* 其它说明:
* 修改日期        版本号     修改人          修改内容
* -----------------------------------------------
* $0000000(N/A), 00086907@2021-12-16 新建
***********************************************************************/

UINT32 BootGetCooperIndex(VOID)
{

    UINT32 pulVal = 0;

    zte_printf_s("try IIC1\n");
    BootSfpRegRead(0,SFP_EEPROM, 0x6, &pulVal);
    if (0x8 == pulVal)
    {
        return IIC1_SUPPORT_COOPER;
    }

    zte_printf_s("try IIC2\n");
    BootSfpRegRead(1,SFP_EEPROM, 0x6, &pulVal);
    if (0x8 == pulVal)
    {
        return IIC2_SUPPORT_COOPER;
    }

    zte_printf_s("IIC1&IIC2 do not support cooper\n");
    return IIC_NO_SUPPORT_COOPER;

}

#if 0
/**********************************************************************
* 函数名称:BootSupportOptDebug
* 功能描述:获取电模块在位情况
* 输入参数:
* 输出参数:
* 返 回 值:  1：电模块1在位
            0:电模块0在位
            2：电模块不在位
            3：在位但非电模块
* 其它说明:
* 修改日期        版本号     修改人          修改内容
* -----------------------------------------------
*  $0000000(N/A), 00086907@2021-12-16 新建
***********************************************************************/

UINT32 BootSupportOptDebug(VOID)
{
    UINT32 ulsfp0 = 0;
    UINT32 ulsfp1 = 0;
    UINT32 pulVal = 0;

    ulsfp0 = _BspZteGpioGet(DPDIC_GPIO_SFP0_PLACE_FLAG);
    ulsfp1 = _BspZteGpioGet(DPDIC_GPIO_SFP1_PLACE_FLAG);
    printf("ulsfp0 = %d,ulsfp1 = %d\n",ulsfp0,ulsfp1);
    if(ulsfp0 && ulsfp1)
        return SFP_OUT_PLACE;

    if(0 == ulsfp1)
    {
        printf("try OPT1\n");
        BootSfpRegRead(1,SFP_EEPROM, 0x6, &pulVal);
        if(0x8 == pulVal)
            return SFP1_SUPPORT_COOPER;

    }
    else if(0 == ulsfp0)
    {
        printf("try OPT0\n");
        BootSfpRegRead(0,SFP_EEPROM, 0x6, &pulVal);
        if(0x8 == pulVal)
            return SFP0_SUPPORT_COOPER;
    }

    printf("OPT1&OPT0 do not support cooper\n");
    return SFP_NO_SUPPORT_COOPER;
}

#endif

#ifndef I2C_USED_IN_KERNEL

UINT32 BootI2cBusInit(UINT32 ulBusId)
{
    UINT32 ulRetVal = BSP_OK;

    T_I2C_BUS_DRV *ptBus = NULL;

    if (ulBusId >= NUM_BRD_I2C_BUS)
    {
        return BSP_ERROR_INVALID_PARA;
    }

    ptBus = &s_atI2cBus[ulBusId];
    ulRetVal = BspI2CBusDrvInit(ptBus);
    return ulRetVal;
}

UINT32 BootSfpChipInit(VOID)
{
    UINT32 ulRetVal = BSP_OK;
    T_SfpDev tSfp;

    memset((VOID *)&tSfp, 0, sizeof(tSfp));
    tSfp.ulDevIndex = 0;
    tSfp.tSlave.I2CBusId = I2C_BUS_ID_SFP0;
    tSfp.tSlave.Addr = 0x56;
    ulRetVal |= BootSfpDevInit(&tSfp);

    memset((VOID *)&tSfp, 0, sizeof(tSfp));
    tSfp.ulDevIndex = 1;
    tSfp.tSlave.I2CBusId = I2C_BUS_ID_SFP1;
    tSfp.tSlave.Addr = 0x56;
    ulRetVal |= BootSfpDevInit(&tSfp);
    return ulRetVal;
}

#endif

UINT32 BootBoardHwPreInit(VOID)
{
    UINT32 ulRet = BSP_OK;
    ulRet |= _BspZteGpioInit();/*完成GPIO物理地址到虚拟地址的映射*/
    ulRet |= BootInitBoardGpioPort();
    #ifndef I2C_USED_IN_KERNEL
    ulRet |= BootI2cBusInit(I2C_BUS_ID_SFP0);/*sfp I2c总线初始化*/
    ulRet |= BootI2cBusInit(I2C_BUS_ID_SFP1);
    ulRet |= BootSfpChipInit();
    #endif
    /*ulRet |= _BspZteCrmMsgInit();*/
    //printf("ok！\n");
    return ulRet;

}

UINT32 BootBoardHwPadInit(VOID)
{
    BootWrIcGpioPadEn(DPDIC_GPIO_LED_RUN,1);
    BootWrIcGpioPadEn(DPDIC_GPIO_LED_ALARM,1);
    return BSP_OK;

}

UINT32 BootResetPhy()
{
    return BSP_OK;
}

/*****************************************************************************
*  函数名称   : BootBoardPreInit(*)
*  功能描述   : Bsp单板初始化函数
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : 无
*  输出参数   : 无
*  返 回 值   : BSP_OK, 其它值为失败
*  其它说明   : 该接口为加载fpga前所需的BSP初始化函数。 版本公共接口函数
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A), zhaoyun@20140527 13:40:08 创建
*  comments:  feble_cheng@20140728 这个接口内不允许访问IC加速器的任何寄存器
*                                  因为此时fpga尚未加载，localbus时序异常会造成主片挂死
*----------------------------------------------------------------------------
*/
UINT32 BootBoardPreInit(VOID)
{
    UINT32 ulRet = BSP_OK;
    TBoardInitCall *tmp;
    struct list_head *pos;
    /* Started by AICoder, pid:h339bpd6f6q9c4b14b6a0be7b098ab0ea89164bd */
    printf("\\BootBoardPreInit....... \n");
    /* Ended by AICoder, pid:h339bpd6f6q9c4b14b6a0be7b098ab0ea89164bd */
    ulRet |= BootSetSlaveChipNum(); /*配置从片IC数量，不包含主片*/
    ulRet |= BootBoardHwPreInit();  /*GPIO初始化*/
    ulRet |= BootDevMemMap();       /*物理地址到虚拟地址的映射*/
    ulRet |= BootGetGlobalChipId();  /*配置IC的芯片号,全局信息*/
    ulRet |= BootFlashInit();
    ulRet |= BootBoardHwPadInit();
    ulRet |= BspResetPhyCallBackInit(BootResetPhy);
    ulRet |= OpenKdaModel();
    printf("ZX211412 %s Chip ID %d\n",\
            (CHIP_MASTER_TYPE ==BootGetChipMsFlag())?"Master":"Slave",\
            g_icChipId);

/*lint -e{413,155}*/
    /*Carry out the init call*/
    list_for_each(pos,&BoardPreCall_list)
    {
        tmp = list_entry(pos,TBoardInitCall,list);
        //printf("function name= %s.",tmp->cCallName);

        tmp->ulRet = (*tmp).pInitCall();
        //printf("ulRet =%ld .\n",tmp->ulRet);
    }
/*lint -e{413,155}*/
    /*Collect the initcall error*/
    list_for_each(pos,&BoardPreCall_list)
    {
        tmp = list_entry(pos,TBoardInitCall,list);
        if (tmp->ulRet != 0)
        {
            //printf("ulRet =%ld .\n",tmp->ulRet);
            sBoardInitError |= tmp->ulFailMacro;
            ulRet |= tmp->ulFailMacro;
        }
    }
    return ulRet;
}



/**********************************************************************
* 函数名称:BootDebugMiiRead
* 功能描述:通过GMII寄存器读PHY  .  针对以太网口GMAC0
* 输入参数: *     - udCsrClockRange：CSR 时钟区域
 *     - udGR： GMII寄存器
 *     - udPA： PHY设备物理层地址
 *     - pudData：需要读出的数据的地址
* 输出参数:
* 返 回 值:
* 其它说明:
* 修改日期        版本号     修改人          修改内容
* -----------------------------------------------
* 2014-5-28       V1.0       yam             创建
*  $0000000(N/A), zhaoyun@20141216 19:33:10 trm78E
*  $0000000(N/A), ty@2019-1-29 由IC2.0移植创建
***********************************************************************/
UINT32 BootDebugMiiRead(UINT32 ulCsrClockRange, UINT32 ulGR, UINT32 ulPA, UINT32 *pulData)
{
    return BootGetMiiWrReg(ulPA,ulGR,pulData);
}

UINT32 BootGetSfpPhyLinkSpeed(UINT32 speed)
{
    switch ((speed & 0xc) >> 2)
    {
        case 2:
        {
            dbgInfo("PHY SPEED %s\n","10M");
            return SPEED_100;
        }

        case 1:
        {
            dbgInfo("PHY SPEED %s\n","100M");
            return SPEED_100;
        }

        case 0:
        {
            dbgInfo("PHY SPEED %s\n","1000M");
            return SPEED_1000;
        }

        default:
        {
            dbgInfo("GET PHY SPEED ERROR\n");
            return BSP_ERROR;
        }
    }
}

/**********************************************************************
* 函数名称:BootGetPHYLinkStatus
* 功能描述:获取PHY芯片物理链路连通状态
* 输入参数:无
* 输出参数:
* 返 回 值:0-网口联通 1-网口未联通
* 其它说明:
* 修改日期        版本号     修改人          修改内容
* -----------------------------------------------
* 2013-4-15       V1.0       yam             创建
*  $0000000(N/A), zhaoyun@20141216 19:33:10 trm78E
*  $0000000(N/A), ty@2019-1-29 由IC2.0移植创建
*  $0000000(N/A), jc@2019-7-19 修改
***********************************************************************/
UINT32 BootGetPhyLinkStatus(VOID)
{

    UINT32 ulValue = 0;
    UINT32 ulRet = 0;
    UINT32 ulOptflag = 0;

    if (g_board_type == DEBUG_BOARDTYPE)
    {
        ulRet = BspGetPhyStatus(0, &ulValue, 0);
        if (BSP_OK != ulRet)
        {
            dbgErr("Gmac0MiiRead Error!\n");
            return BSP_ERROR;
        }

        dbgInfo("PHY Status Reg[0x%x]\n", ulValue);

        if(ulValue & NET_STATE_LINKOK)
        {
            dbgInfo("Debug net port is ON\n");
            BootGetSfpPhyLinkSpeed(ulValue);
            dbgInfo("PHY DUPLEX %s\n", ((ulValue & 0x10)>>4)? "FULL":"HALF");
            return 0;
        }
        else
            return 1;
    }
    else
    {
        ulOptflag = BootGetCooperIndex();
        if((IIC1_SUPPORT_COOPER == ulOptflag)||(IIC2_SUPPORT_COOPER == ulOptflag))
        {
            ulRet = BootGetSfpPhyStatus(ulOptflag, &ulValue);
            if (BSP_OK != ulRet)
            {
                dbgErr("Sfp%d phy read Error!\n",ulOptflag);
                return BSP_ERROR;
            }
            if(ulValue & NET_STATE_LINKOK)
            {
                dbgInfo("Opt%d net port is ON\n",ulOptflag);
                dbgInfo("PHY DUPLEX %s\n", ((ulValue & 0x10)>>4)? "FULL":"HALF");

                BootGetSfpPhyLinkSpeed(ulValue);
                return PHY_LINK_UP;
            }
            else
            {
                dbgInfo("Opt%d net port is OFF\n",ulOptflag);
                return PHY_LINK_DOWN;
            }
        }
        else
            return 1;
    }
}
/**********************************************************************
* 函数名称:BootGmac0MiiWrite
* 功能描述:通过GMII寄存器写PHY  .  针对以太网口GMAC0
* 输入参数: *     - udCsrClockRange：CSR 时钟区域
 *     - udGR： GMII寄存器
 *     - udPA： PHY设备物理层地址
 *     - pudData：需要读出的数据的地址
* 输出参数:
* 返 回 值:
* 其它说明:
* 修改日期        版本号     修改人          修改内容
* -----------------------------------------------
* 2014-5-28       V1.0       yam             创建
*  $0000000(N/A),00086970 19:33:10 trm78E
*  $0000000(N/A), ty@2019-1-29 由IC2.0移植创建
***********************************************************************/
UINT32 BootDebugMiiWrite(UINT32 ulCsrClockRange, UINT32 ulGR, UINT32 ulPA, UINT32 ulData)
{
    return BootSetMiiWrReg(ulPA,ulGR,ulData);
}


/**************************************************************************
* 函数名称： boot_flag_set
* 功能描述：设置boot启动标志
* 输入参数： 无
* 输出参数： 无
* 返 回 值： BSP_OK/BSP_ERROR
* 其它说明：
* 适用范围： BSP、OSS
* -----------------------------------------------------------------------
* 修改日期      版本号     修改人        修改内容
* 2015年10月22日 v1.0      00086970          创建
*  $0000000(N/A), ty@2019-1-29 由IC2.0移植创建
**************************************************************************/
VOID boot_flag_set()
{
    UINT8 check_flag=0;
    check_flag = BootGetKBootMSFlag();
    printf("check_flag = %0#x\n",check_flag);

    if(check_flag == MASTER_BOOT_OK)  /*本次是上电或者复位后第一次启动,启动主boot成功*/
    {
        BootSetKBootMSFlag(MASTER_KUBOOT_OK);
        /*尚欠写高端内存表征主boot启动成功标志*/
    }
    else if(check_flag == MASTER_KUBOOT_OK) /*启动主boot成功，继续尝试引导CPU版本*/
    {
        BootSetKBootMSFlag(MASTER_KUBOOT_OK);
        /*尚欠写高端内存表征主boot启动成功标志*/
    }
    else if(check_flag == SLAVE_BOOT_OK)  /*启动从boot成功，*/
    {
        BootSetKBootMSFlag(SLAVE_KUBOOT_OK);
        /*尚欠写高端内存表征从boot启动成功标志*/
    }
    else if(check_flag == SLAVE_KUBOOT_OK)   /*启动从boot成功，继续尝试引导CPU版本*/
    {
        BootSetKBootMSFlag(SLAVE_KUBOOT_OK);
        /*尚欠写高端内存表征从boot启动成功标志*/
    }
    return;
}

/**************************************************************************
* 函数名称： SetEthProMode
* 功能描述： 设置ETH的模式寄存器的混杂模式控制位
* 输入参数： 0--对进入的帧的目的地址进行检查。1--对进入的帧的目的地址不进行检查。
* 输出参数： 无
* 返 回 值：
* -------------------------------------------------------
* 其它说明：
* 修改日期     版本号        修改人                修改内容
*  $0000000(N/A), ty@2019-1-29 由IC2.0移植创建
**************************************************************************/
/*需确认MAC_FRAME_FILTER帧过滤寄存器的偏移地址(已确认)*/
/*需确认0x7FFFFFFE和0x80000001的值（已确认）*/
UINT32 SetEthProMode(UCHAR ucValue)
{
    UINT32  ulRet=BSP_OK;

#if 0
    /* Started by AICoder, pid:fb6eddfc3elb56014f450887e0b1620434d392bd */
    UINT32  ulValue=0;
    /* Ended by AICoder, pid:fb6eddfc3elb56014f450887e0b1620434d392bd */
    printf("SetEthProMode: set eth mode bit. \n");
    HAL_addrmapGetDataFromVirAddr(0,MEM_BLK_GMAC0,MAC_FRAME_FILTER,&ulValue);

    if (ucValue == 0) /*对进入的帧的目的地址进行检查,非混杂模式*/
    {
        ulValue = ulValue & 0x7FFFFFFE;
    }
    else/*对进入的帧的目的地址不进行检查, 混杂模式Receive All Frame*/
    {
        ulValue = ulValue | 0x80000001;
    }

    WrReg(0,MEM_BLK_GMAC0,MAC_FRAME_FILTER,ulValue);
#endif
    return ulRet;
}
/**********************************************************************
* 函数名称： BootGetDownloadFlag
* 功能描述： MIO14指示起保护区版本or下载版本。
* 输入参数： 无
* 输出参数： 无
* 返 回 值： 0:起保护区版本 1:下载版本
* 其它说明： zx211410写死起保护区版本
* 修改日期        版本号     修改人          修改内容
* -----------------------------------------------
* 2012/07           V1.0         ZKH
***********************************************************************/
UINT32 BootGetDownloadFlag(VOID)
{
    UINT32 ulChipId = 0;

    ulChipId = BootGetIcChipId();
    if((CHIP_MASTER_TYPE == BootGetChipMsFlag()) && (0 == ulChipId))
    {
        return 0;
    }
    else
    {
        return 1;
    }
}

ULONG getLastKmsgAddr(VOID)
{
    return LAST_KMSG_ADDR;
}

ULONG getAppLogPhyAddr(VOID)
{
    return APP_LOG_PHY_ADDR;
}

UINT32 BootGetBoardHwResetType(VOID)
{
    UINT32 ret = 0;
    ret = readl(aulCrmVirAddr + REC_RESET_0);
    return ret;
}

UINT32 BootGetBoardSwResetType(VOID)
{
    UINT32 ret = 0;
    ret = readl(aulCrmVirAddr + SOFT_RESET_OFFSET);
    return ret;
}

/* Started by AICoder, pid:waed9v85c7lc1cb142c60b83f0e433012e543c8e */
UCHAR* BootGetBoardResetInfoAddr(VOID)
{
    return (UCHAR*)(g_ulRamReservedAddr + RESET_INFO_ADDR);
}
/* Ended by AICoder, pid:waed9v85c7lc1cb142c60b83f0e433012e543c8e */

VOID SaveKebootBakLog(VOID)
{
    if(CHIP_SLAVER_TYPE == BootGetChipMsFlag())
    {
        return;
    }
    BspSaveBootKmsgLog(BAK_LOG);
    BspSaveBootAppLog(BAK_LOG);
}

VOID SaveKebootCurLog(VOID)
{
    if(CHIP_SLAVER_TYPE == BootGetChipMsFlag())
    {
        return;
    }
    BspSaveBootKmsgLog(CUR_LOG);
    BspSaveBootAppLog(CUR_LOG);
}

/*bs住后的手动转储请用SaveKebootLog,产生4份,使每份log序号保持一致*/
VOID SaveKebootLog(VOID)
{
    if(CHIP_SLAVER_TYPE == BootGetChipMsFlag())
    {
        return;
    }
    SaveKebootBakLog();
    SaveKebootCurLog();
}

ULONG BootFlagGet()
{
    ULONG flag=0;
    flag = BootGetKBootMSFlag();
    return flag;
}

/*****************************************************************************
 *  函数名称   : main(*)
 *  功能描述   : bootapp程序处理主函数
 *  读全局变量 : 无
 *  写全局变量 : 无
 *  输入参数   : argc   - 参数个数
                argv[] - 参数列表
 *  输出参数   : 无
 *  返 回 值   : 0为成功, 其余失败
 *  其它说明   :
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *  $0000000(N/A), 00086970 @2015-10-28
 *  $0000000(N/A), ty@2019-1-29 由IC2.0移植创建
 *----------------------------------------------------------------------------
 */
/* Started by AICoder, pid:2575fu6c9bu1f8414d7d08bff0fad51146b4a812 */
#ifdef RENAME_FUNC_UTFT
#define main UTFT_main
#endif
/* Ended by AICoder, pid:2575fu6c9bu1f8414d7d08bff0fad51146b4a812 */
int main(int argc, char *argv[])
{
    int iBootAppTaskID = 0;
    UINT32 ulRet = 0;
    printf("zx211412 bootapp\n");

    ulRet = BootBoardPreInit();

    BootLedRun(0);
    ulRet = GetCmdline();
    if(BSP_ERROR == ulRet)
    {
        SetDefaultCmdline();
    }
    ulRet |= BootWatchDogInit();
    ulRet |= (UINT32)ushell_init();
    ulRet |= BootSoftModInit();

    #if 0 /*modify by pwm mode in BootLedRun function */
    taskSpawn("tLedTask",   \
        100, /* priority */            \
        0,   /* option   */           \
        0x100,/* stack size */      \
        (FUNCPTR)BootLedTask, 0, 0, 0, 0, 0, 0, 0, 0 ,0,0);
    #endif

    BootLedRun(0);
    iBootAppTaskID = taskSpawn("tBootTask",   \
        100, /* priority */            \
        0,   /* option   */           \
        0x1000,/* stack size */      \
        (FUNCPTR)MainLoop, 0, 0, 0, 0, 0, 0, 0, 0 ,0,0);
        /* Started by AICoder, pid:p5301519d0z60a614363084d80f449019751a6b8 */
        (void)iBootAppTaskID; // 告诉编译器：我知道这个变量没用
        /* Ended by AICoder, pid:p5301519d0z60a614363084d80f449019751a6b8 */
    while(1)
    {
       //BspFunction("/boot.out", CFG_PROMPT);
        sleep(20);
    }

    return ulRet;

}



#endif
extern UCHAR g_ucCmdLine[256];
UINT32 SetDefaultCmdline(VOID)
{
    #if defined(KEXECBOOT_SUPPORT)
    /* Started by AICoder, pid:h5eb0za9cdv375814e0d09fa30b62b058c145e95 */
    strcpy((char *)g_ucCmdLine,"root=/dev/ram0 rw mem=122M console=ttyAMA0 flash_partition_flag=1");
    /* Ended by AICoder, pid:h5eb0za9cdv375814e0d09fa30b62b058c145e95 */
    #else
    strcpy(g_ucCmdLine,"root=/dev/ram0 rw mem=122M console=ttyAMA0");
    #endif
    printf("/proc/cmdline error,load default cmdline.\n");
    return BSP_OK;

}

void BootSetGpioPad(UINT32 gpio)
{
    UINT32 addr;

    addr = 4*gpio + 0x98;
    BootWrIcGpioPadEn(gpio, 1);//pad 使能
    BootWrIcGpioPadRegBit(1, addr, 0, 9);//对应 gpio bit9写0 func_sel选择gpio

}

UINT32 BootSetupEthFlag(VOID)
{

    BootSetGpioPad(APPID0_GPIO0);
    _BspZteGpioSetMode(APPID0_GPIO0, GPIO_MODE_INPUT);

    if (DEBUG_BOARDTYPE == _BspZteGpioGet(APPID0_GPIO0))
    {
        g_board_type = DEBUG_BOARDTYPE;
    }

    return 0;
}

UINT32 BootNtlSoftResetInit(void)
{
    /*关闭对外的eth xmac*/
    L2ssXmacDisable(0);
    L2ssXmacDisable(1);

    L2ssXmacDisable(8);
    L2ssXmacDisable(9);

    L2ssPortDisable(8);
    L2ssPortDisable(9);

    /*对除A53使用的，其他端口进行管理 */

    L2ssCpuAgentByteOrder(L2SS_A53_DBG_ETH_PORT,L2SS_CPU_AGENT_BIG_ENDIAN);
    L2ssCpuAgentByteOrder(L2SS_M0_PORT,L2SS_CPU_AGENT_BIG_ENDIAN);
    L2ssCpuAgentByteOrder(L2SS_CEVA_PORT,L2SS_CPU_AGENT_BIG_ENDIAN);
    L2ssCpuAgentByteOrder(L2SS_R8_PORT,L2SS_CPU_AGENT_BIG_ENDIAN);
    L2ssCpuAgentByteOrder(L2SS_MIRROR_SMP_PORT,L2SS_CPU_AGENT_BIG_ENDIAN);
    L2ssCpuAgentByteOrder(L2SS_A53_OPT_ETH_PORT,L2SS_CPU_AGENT_BIG_ENDIAN);

    L2ssPortDisable(L2SS_M0_PORT);
    L2ssPortDisable(L2SS_MIRROR_SMP_PORT);
    L2ssPortDisable(L2SS_CEVA_PORT);
    L2ssPortDisable(L2SS_R8_PORT);

    L2ssCpuAgentRstPort(L2SS_M0_PORT);
    L2ssCpuAgentRstPort(L2SS_MIRROR_SMP_PORT);
    L2ssCpuAgentRstPort(L2SS_CEVA_PORT);
    L2ssCpuAgentRstPort(L2SS_R8_PORT);

    L2ssCpuAgentRlsPort(L2SS_M0_PORT);
    L2ssCpuAgentRlsPort(L2SS_MIRROR_SMP_PORT);
    L2ssCpuAgentRlsPort(L2SS_CEVA_PORT);
    L2ssCpuAgentRlsPort(L2SS_R8_PORT);

    printf("%s done\n",__FUNCTION__);
    return BSP_OK;
}



/*缃戝彛鍚姩鐨勬儏鍐典笅锛屼笉杩愯kexec鐨?keboot,鎵€浠ヤ笅杩版槸flash鍚姩鏂瑰紡锛屽垎涓婄數澶嶄綅杩樻槸闈炰笂鐢靛浣?*/
UINT32 BootNtlInit()
{

    printf("BootNtlInit start\n");

    /* 6.初始化NTL模块 */
    BootNtlSoftResetInit();

    printf("BootNtlInit end\n");
    return BSP_OK;
}

/**********************************************************************
* 函数名称： BootGetFsRecoverFlag
* 功能描述： 从高端内存获取用户态文件系统异常标志
* 输入参数： 无
* 输出参数： 无
* 返 回 值： 0:正常 0xdeadbeaf:异常
* 其它说明： 获取后清除
* 修改日期        版本号     修改人          修改内容
* -----------------------------------------------
* 2012/07           V1.0         ZKH
***********************************************************************/
UINT32 BootGetFsRecoverFlag(VOID)
{
    UINT32 ulUbifsFormat_mask = 0;
    ulUbifsFormat_mask = *(UINT32 *)FS_FORMAT_FLAG;
    memset((CHAR*)FS_FORMAT_FLAG, 0, 4);/* 清空 */
    return ulUbifsFormat_mask;
}

UINT32 BootCfgMacSpeed(UINT32 ulOptflag,UINT32 ulport)
{
    UINT32 ulValue = 0;
    UINT32 ulRet = 0;
    UINT32 loop = 0;
    UINT32 port = 0;
    UINT32 L2ssXmacSpeed = SPEED_100;//默认mac速率配置100M，下面根据phy link速率判断是否需要修改

    /*某些交换机link up速度慢，这里动态根据link速度来调整延时时间*/
    for (loop = 0; loop < SFP_WAIT_LINK_UP_MAX_TIME; loop++)
    {
        ulRet = BootGetSfpPhyStatus(ulOptflag, &ulValue);
        if (BSP_OK != ulRet)
        {
            dbgErr("Read Sfp Phy Status Error!\n");
            return BSP_ERROR;
        }
        if (ulValue & NET_STATE_LINKOK)
        {
            break;
        }
        BspSysMsDelay_Sys(1000);
    }

    if (loop == SFP_WAIT_LINK_UP_MAX_TIME)
    {
        zte_printf_s("Get sfp phy link up status time out\n");
    }
    else
    {
        zte_printf_s("Get sfp phy link up status need %d s\n", loop);
    }

    if (ulValue & NET_STATE_LINKOK)
    {
        dbgInfo("IIC%d net port is ON\n",ulOptflag+1);
        dbgInfo("PHY DUPLEX %s\n", ((ulValue & 0x10)>>4)? "FULL":"HALF");

        L2ssXmacSpeed = BootGetSfpPhyLinkSpeed(ulValue);

        zte_printf_s("%s cfg Mac[%d]End! \n",__FUNCTION__,ulport);
        L2sssMacSetInterfaceMode(ulport, L2ssXmacSpeed);

        if(L2ssXmacSpeed == SPEED_1000)
            L2ssmacCfgTxIpg(ulport,0xF);

        return PHY_LINK_UP;
    }
    else
    {
        L2sssMacSetInterfaceMode(port, L2ssXmacSpeed);
        dbgInfo("IIC%d net port is OFF\n",ulOptflag+1);
        return PHY_LINK_DOWN;
    }
}

/* Started by AICoder, pid:769efta8e6e786b14539088100601e1300b49a18 */
UINT32 BootPhyCfgMacSpeed(UINT32 ulport)
{
    UINT32 ulValue = 0;
    UINT32 ulRet = 0;
    UINT32 loop = 0;
    UINT32 L2ssXmacSpeed = SPEED_100;//默认mac速率配置100M，下面根据phy link速率判断是否需要修改

    /*某些交换机link up速度慢，这里动态根据link速度来调整延时时间*/
    for (loop = 0; loop < PHY_WAIT_LINK_UP_MAX_TIME; loop++)
    {
        ulRet = BspGetPhyStatus(0, &ulValue, 0);
        if (BSP_OK != ulRet)
        {
            dbgErr("Read Phy Status Error!\n");
            return BSP_ERROR;
        }
        if (ulValue & NET_STATE_LINKOK)
        {
            break;
        }
        BspSysMsDelay_Sys(1000);
    }

    if (loop == PHY_WAIT_LINK_UP_MAX_TIME)
    {
        zte_printf_s("Get phy link up status time out\n");
    }
    else
    {
        zte_printf_s("Get phy link up status need %d s\n", loop);
    }
    if (ulValue & NET_STATE_LINKOK)
    {
        dbgInfo("PHY DUPLEX %s\n", ((ulValue & 0x10)>>4)? "FULL":"HALF");
        L2ssXmacSpeed = BootGetSfpPhyLinkSpeed(ulValue);
        dbgInfo("%s cfg Mac[%d]End! \n",__FUNCTION__,ulport);
        L2sssMacSetInterfaceMode(ulport, L2ssXmacSpeed);

        if(L2ssXmacSpeed == SPEED_1000)
        {
            L2ssmacCfgTxIpg(ulport,0xF);
        }
        return PHY_LINK_UP;
    }
    else
    {
        dbgInfo("Debug net port is OFF\n");
        return PHY_LINK_DOWN;
    }
}
/* Ended by AICoder, pid:769efta8e6e786b14539088100601e1300b49a18 */

UINT32 BootL2ssInit(VOID)
{
    L2ssProcInit();
    L2ssCheckQmanNorSelfInitDone(0);

    /*qman 引擎模式为2个引擎模式*/
    L2ssSetEngMode(0);

    /* 设置端口号为12开始 */
    L2ssSetQmanCfgiInnerPortGroup(0xA9876543);

    l2ss_hw_cntp_en();
    /*关闭所有CPU代理口*/

   // L2ssPortDisable(L2SS_AGENT_PORT0);
   // L2ssPortDisable(L2SS_AGENT_PORT4);
  //  L2ssPortDisable(L2SS_AGENT_PORT5);


    /*端口报文过滤,加入12端口*/
    /*portmap = portmap |(1<<12) | (1<<23) | (1<<24);*/

    zte_printf_s("%s done\n",__FUNCTION__);

    return 0;
}

UINT32 BootPortVlanInit(UINT32 vlan,UINT64 portmap)
{
    UINT32 port;
    /* Started by AICoder, pid:z8bdfrc67bo0c09140aa09d770aec90b40613743 */
    dbgInfo("BootPortVlanInit portmap 0x%llx\n", portmap);
    /* Ended by AICoder, pid:z8bdfrc67bo0c09140aa09d770aec90b40613743 */
    L2ssCreatVlan(vlan, vlan, portmap, portmap);
    for (port=0;port<L2SS_TRXP_NUM;port++)
    {
        if ( 1 != ((portmap >> port) & 0x01))
        {
            continue;
        }
        L2ssVlanMapModeSet(port,0x3f,0);
        L2ssPortVlanSet(port,vlan,0);
        L2ssParsCfglpSelParseNUm(port, e_L2SS_ENG0);    //ads阶段parse引擎的设置都是进入ENG0
        L2ssParsCfgPktAnalyLevel(port, 4);
    }
    L2ssPrepCfgPktErrCtrl(0); /*关闭头长度错误丢弃*/
    zte_printf_s("%s done\n",__FUNCTION__);
    return 0;
}

UINT32 BootIpVlanInit(UINT32 vlan,UINT64 portmap)
{
    T_L2ssLpmStruct tLpmInfo = {0};
    UINT32 lvTapIdx = 0;
    /* Started by AICoder, pid:d53e8u4396c92d614b5c0b5400f3eb04bcd16faf */
    dbgInfo("BootIpVlanInit portmap 0x%llx\n", portmap);
    /* Ended by AICoder, pid:d53e8u4396c92d614b5c0b5400f3eb04bcd16faf */
    /*A53 通信 建立 源/目的IP报 199.33.xx.xx的报文的VLAN  DEFAULT_ETH_IP_VLAN1*/

    L2ssCreatVlan(vlan , vlan , portmap, portmap);
    L2ssLvTapTblSet(&lvTapIdx);
    zte_memset_s(&tLpmInfo,sizeof(tLpmInfo),0,sizeof(tLpmInfo));
    tLpmInfo.udKeyType = e_LpmKeyIpv4L32;
    tLpmInfo.audKey[0]  = 0xc7210000;      /*ip 199.33.xx.xx*/
    tLpmInfo.audMask[0] = 0xffff0000;
    L2ssLpmVlanSet(&tLpmInfo, vlan,lvTapIdx, 0x3);

    zte_printf_s("%s done\n",__FUNCTION__);
    return 0;
}


UINT32 BootCfgPllAndL2ss(VOID)
{
    UINT32 ulOptFlag = 0;
    UINT32 ulindex = 0;
    UINT32 ulportindex = 0;

    /*4.0不需要初始化时钟和配置用户态的寄存器空间*/
    /*ntl init*/
    DpdIcHalRegTblInit();

    BootNtlInit();
    BspSysMsDelay_Sys(500);

#ifndef NTN_BOARDTYPE
    BootSetupEthFlag();
#else
    g_board_type = DEBUG_BOARDTYPE;//NTN单板分支网口配置，也按照样片板配置，差别是初始化sgmii速率为千兆，并删除phy配置
#endif

    if (g_board_type == DEBUG_BOARDTYPE)
    {
        zte_printf_s("debug board case\n");

        //8口连接百兆PHY，9口连接千兆15EG;NTN单板连接主片4C
        ulindex = ((1<<L2SS_TRXP8) | (1<<L2SS_TRXP9));
        ulportindex = (L2SS_TRXP8 | L2SS_TRXP9);

        BootL2ssInit();
        BootPortVlanInit(16,((1<<L2SS_TRXP8)|(1<<L2SS_TRXP9)|(1<<L2SS_TRXP46)));
        BootIpVlanInit(17,(ulindex|(1<<L2SS_TRXP46)));
#ifndef NTN_BOARDTYPE
        /*初始化板上phy芯片*/
        BspInitPhy(0);
#endif
        L2ssPortEnable(L2SS_A53_DBG_ETH_PORT);
        BootXmacInit(ulindex);

        L2ssPortEnable(L2SS_TRXP8);
        L2ssXmacEnable(L2SS_TRXP8);

#ifndef NTN_BOARDTYPE
        BootPhyCfgMacSpeed(L2SS_TRXP8);/* 对应的serdes8，可支持千兆、百兆、自动侦测 */
#else
        L2sssMacSetInterfaceMode(L2SS_TRXP8, SPEED_1000);/* 对应的serdes8，xmac配置100M */
        zte_printf_s("NTN serdes 8 cfg xamc 1000M\n");
#endif

        L2ssPortEnable(L2SS_TRXP9);
        L2ssXmacEnable(L2SS_TRXP9);

#ifndef NTN_BOARDTYPE
        L2sssMacSetInterfaceMode(L2SS_TRXP9, SPEED_1000);/* 对应的serdes9，xmac配置1000M */
        zte_printf_s("15eg serdes 9 cfg xamc 1000M\n");
#else
        L2sssMacSetInterfaceMode(L2SS_TRXP9, SPEED_1000);/* 对应的serdes9，xmac配置1000M */
        zte_printf_s("NTN serdes 9 cfg xamc 1000M\n");
        BspSysMsDelay_Sys(3000);
#endif
    }
    else
    {
        zte_printf_s("release board case\n");
        ulOptFlag = BootGetCooperIndex();
        if (IIC1_SUPPORT_COOPER == ulOptFlag)
        {
            ulindex = (1<<L2SS_TRXP1);
            ulportindex = L2SS_TRXP1;
        }
        else if (IIC2_SUPPORT_COOPER == ulOptFlag)
        {
            ulindex = (1<<L2SS_TRXP0);
            ulportindex = L2SS_TRXP0;
        }
        else
        {
            zte_printf_s("%s no cooper case\n",__FUNCTION__);
            return 0;
        }

        /*
        复位l2ss动作，暂注释掉备忘
        BootRstL2ss();
        */
        zte_printf_s("ulindex=0x%x,ulportindex=0x%x\n",ulindex,ulportindex);
        //BspSysMsDelay_Sys(200);
        //BootRlsL2ssRst();
        BootL2ssInit();
        BootPortVlanInit(16,((1<<L2SS_TRXP0)|(1<<L2SS_TRXP1)|(1<<L2SS_TRXP46)));
        BootIpVlanInit(17,(ulindex|(1<<L2SS_TRXP46)));
        BootOptDebugNetInit(ulindex);
        BootInitSfpPhy(ulOptFlag);
        L2ssPortEnable(L2SS_A53_DBG_ETH_PORT);
        L2ssPortEnable(ulportindex);
        L2ssXmacEnable(ulportindex);
        BootCfgMacSpeed(ulOptFlag,ulportindex);
    }

    BootSetEth0DebugIpMacAddr();
    BspSystem("ifconfig eth0 mtu 1492");

  //  }

    return BSP_OK;
}

UINT32 BootGetKebootFlashAddr()
{
    UINT8 flag = 0xff;
    UINT32 ret = 0;
    UINT32 master_addr;
    UINT32 slave_addr;

    ret = BspFlashRead(DOUBLE_KEBOOT_CTRL_ADDR, (UCHAR *)&flag,1);
    if(ret != BSP_OK )
    {
        printf("%s read flash 0x%08x failed\n",__FUNCTION__ ,DOUBLE_KEBOOT_CTRL_ADDR);
        return KEBOOT_M_START_ADDR;
    }

    if(flag != 0)
    {
        master_addr= KEBOOT_M_START_ADDR;
        slave_addr = KEBOOT_S_START_ADDR;

    }
    else
    {
        master_addr = KEBOOT_S_START_ADDR;
        slave_addr =  KEBOOT_M_START_ADDR;
    }

    if(MASTER_KUBOOT_OK == BootGetKBootMSFlag())
    {
        return master_addr;
    }
    else
    {
        return slave_addr;
    }

}

UINT32 BootGetUBootFlashAddr()
{
    UINT8 flag = 0xff;
    UINT32 ret = 0;
    UINT32 master_addr;
    UINT32 slave_addr;

    ret = BspFlashRead(DOUBLE_UBOOT_CTRL_ADDR, (UCHAR *)&flag,1);
    if(ret != BSP_OK )
    {
        printf("%s read flash 0x%08x failed\n",__FUNCTION__ ,DOUBLE_UBOOT_CTRL_ADDR);
        return UBOOT_M_HEAD_ADDR;
    }

    if(flag != 0)
    {
        master_addr= UBOOT_M_HEAD_ADDR;
        slave_addr = UBOOT_S_HEAD_ADDR;

    }
    else
    {
        master_addr = UBOOT_S_HEAD_ADDR;
        slave_addr =  UBOOT_M_HEAD_ADDR;
    }

    if(SLAVE_UBOOT_OK == BootGetKBootMSFlag())
    {
        return slave_addr;
    }
    else
    {
        return master_addr;
    }

}


UINT32 BootGetUBootSplFlashAddr()
{
    UINT8 flag = 0xff;
    UINT32 ret = 0;
    UINT32 master_addr;
    UINT32 slave_addr;

    ret = BspFlashRead(DOUBLE_SPL_UBOOT_CTRL_ADDR, (UCHAR *)&flag,1);
    if(ret != BSP_OK )
    {
        printf("%s read flash 0x%08x failed\n",__FUNCTION__ ,DOUBLE_SPL_UBOOT_CTRL_ADDR);
        return UBOOT_M_SPL_HEAD_ADDR;
    }

    if(flag != 0)
    {
        master_addr= UBOOT_M_SPL_HEAD_ADDR;
        slave_addr = UBOOT_S_SPL_HEAD_ADDR;

    }
    else
    {
        master_addr = UBOOT_S_SPL_HEAD_ADDR;
        slave_addr =  UBOOT_M_SPL_HEAD_ADDR;
    }

    if(SLAVE_UBOOT_SPL_OK == BootGetUBootMSFlag())
    {
        return slave_addr;
    }
    else
    {
        return master_addr;
    }

}

#if 0
/**********************************************************************
* 函数名称：BootGetVersion
* 功能描述： 读取Flash中boot版本号
* 输入参数： headPtr需要获取到版本的指针，默认不使用，除非传入非空指针，model:0 获取一级Boot版本，1 获取二级keboot版本
* 输出参数： 无
* 返 回 值： 0:正常  非0:异常
* 其它说明： 获取后清除
* 修改日期        版本号     修改人          修改内容
* 修改日期     版本号        修改人                修改内容
* ---------------------------------------------------
* 2015/10/22     V1.0         10242265           创建
***********************************************************************/
UINT32 BootGetVersion(char *headPtr,char model)
{
    UINT32 ulRet=0;
    UINT32 HEAD_ADDR=0;
     unsigned char  *ptVerFileHeadChar = NULL;
     T_VerFileHeader *ptVerFileHeader = NULL;
    if(NULL==headPtr)
    {
        return BSP_ERROR;
    }
     ptVerFileHeadChar = (unsigned char *)malloc(sizeof(T_VerFileHeader));
    if (NULL == ptVerFileHeadChar)
    {
        printf("malloc error!!\n");
        return -1;
    }

     memset((unsigned char *)ptVerFileHeadChar,0,sizeof(T_VerFileHeader));

    if(0==model)
    {
        HEAD_ADDR = BootGetUBootSplHeadAddr();

        /*从启动地址读取版本头到ptVerFileHeadChar*/
        ulRet=BspFlashRead(HEAD_ADDR, ptVerFileHeadChar,sizeof(T_VerFileHeader));
        if(BSP_OK==ulRet)
        {
            ptVerFileHeader = (T_VerFileHeader *)ptVerFileHeadChar;
            ptVerFileHeader->ucVerNo[44-1]='\0';
            memcpy(headPtr,ptVerFileHeader->ucVerNo,strlen(ptVerFileHeader->ucVerNo)+1);

            dbgPrn("SPL Boot Version: %s\n", headPtr);
        }
        else
        {
            printf("\nRead SPL BOOT Header error!\n");
        }

        HEAD_ADDR = BootGetUBootHeadAddr();

    }
    else
    {
        HEAD_ADDR = BootGetKebootHeadAddr();
    }

     memset((unsigned char *)ptVerFileHeadChar,0,sizeof(T_VerFileHeader));

    /*从启动地址读取版本头到ptVerFileHeadChar*/
    ulRet=BspFlashRead(HEAD_ADDR, ptVerFileHeadChar,sizeof(T_VerFileHeader));
    if(BSP_OK==ulRet)
    {
         ptVerFileHeader = (T_VerFileHeader *)ptVerFileHeadChar;
        ptVerFileHeader->ucVerNo[44-1]='\0';
        memcpy(headPtr,ptVerFileHeader->ucVerNo,strlen(ptVerFileHeader->ucVerNo)+1);
    }
    else
    {
        printf("\nRead BOOT Header error!\n");
    }

    free(ptVerFileHeadChar);
    ptVerFileHeadChar = NULL;
    ptVerFileHeader = NULL;
    return ulRet;
}

#endif


/**********************************************************************
* 函数名称：BootGetVersion
* 功能描述： 读取Flash中boot版本号
* 输入参数： headPtr需要获取到版本的指针，默认不使用，除非传入非空指针，model:0 获取一级Boot版本，1 获取二级keboot版本
* 输出参数： 无
* 返 回 值： 0:正常  非0:异常
* 其它说明： 获取后清除
* 修改日期        版本号     修改人          修改内容
* 修改日期     版本号        修改人                修改内容
* ---------------------------------------------------
* 2015/10/22     V1.0         10242265           创建
***********************************************************************/
UINT32 BootGetVersion(char *headPtr,char model)
{
    UINT32 ulRet=0;
    UINT32 VER_SPL_ADDR=0;
    UINT32 VER_UBOOT_ADDR=0;
    UINT32 VER_KEBOOT_ADDR=0;
    ULONG check_flag=0;
    if(NULL==headPtr)
    {
        return BSP_ERROR;
    }
    unsigned char  *ptVerFileHeadChar = NULL;
    T_VerFileHeader *ptVerFileHeader = NULL;
    ptVerFileHeadChar = (unsigned char *)malloc(sizeof(T_VerFileHeader));
    if (NULL == ptVerFileHeadChar)
    {
        zte_printf_s("malloc error!!\n");
        return BSP_ERROR;
    }

    CHAR ver[BOOT_VER_STR_MAX_LEN]={0};
    CHAR ver_bl0_str[BOOT_VER_STR_MAX_LEN]={0};
    CHAR ver_bl1_str[BOOT_VER_STR_MAX_LEN]={0};
    CHAR ver_bl2_str[BOOT_VER_STR_MAX_LEN]={0};
    CHAR ver_bl3_str[BOOT_VER_STR_MAX_LEN]={0};

    memset(ver,0,sizeof(ver));
    memset(ver_bl0_str,0,sizeof(ver_bl0_str));
    memset(ver_bl1_str,0,sizeof(ver_bl1_str));
    memset(ver_bl2_str,0,sizeof(ver_bl2_str));
    memset(ver_bl3_str,0,sizeof(ver_bl3_str));
    check_flag = BootGetKBootMSFlag();
    if(MASTER_KUBOOT_OK == check_flag)
    {
        VER_SPL_ADDR = UBOOT_M_SPL_HEAD_ADDR;
        VER_UBOOT_ADDR = UBOOT_M_HEAD_ADDR;
        VER_KEBOOT_ADDR = KEBOOT_M_HEAD_ADDR;
    }
    else if ( SLAVE_KUBOOT_OK == check_flag)
    {
        VER_SPL_ADDR = UBOOT_S_SPL_HEAD_ADDR;
        VER_UBOOT_ADDR = UBOOT_S_HEAD_ADDR;
        VER_KEBOOT_ADDR = KEBOOT_S_HEAD_ADDR;
    }
    else
    {
        free(ptVerFileHeadChar);
        ptVerFileHeadChar = NULL;
        return BSP_ERROR;
    }

    if(0==model)
    {
        ulRet=BspFlashRead(M0_HEAD_ADDR-sizeof(T_VerFileHeader), ptVerFileHeadChar,sizeof(T_VerFileHeader));
        if (BSP_OK==ulRet)
        {
            ptVerFileHeader = (T_VerFileHeader *)ptVerFileHeadChar;
            ptVerFileHeader->ucVerNo[44-1]='\0';
            zte_snprintf_s(ver_bl0_str,sizeof(ver_bl0_str),"\n\n-->M0_RamBoot Version: %s\n", ptVerFileHeader->ucVerNo);
        }
        else
        {
            zte_printf_s("\nRead M0 Ramboot Header error!\n");
        }

        ulRet=BspFlashRead(VER_SPL_ADDR, ptVerFileHeadChar,sizeof(T_VerFileHeader));
        if (BSP_OK==ulRet)
        {
            ptVerFileHeader = (T_VerFileHeader *)ptVerFileHeadChar;
            ptVerFileHeader->ucVerNo[44-1]='\0';
            zte_snprintf_s(ver_bl1_str,sizeof(ver_bl1_str),"\n-->Bootloader0 Version: %s\n", ptVerFileHeader->ucVerNo);
        }
        else
        {
            zte_printf_s("\nRead Bootloader0 Header error!\n");
        }

        ulRet=BspFlashRead(VER_UBOOT_ADDR, ptVerFileHeadChar,sizeof(T_VerFileHeader));
        if (BSP_OK==ulRet)
        {
            ptVerFileHeader = (T_VerFileHeader *)ptVerFileHeadChar;
            ptVerFileHeader->ucVerNo[44-1]='\0';
            zte_snprintf_s(ver_bl2_str,sizeof(ver_bl2_str),"\n-->Bootloader1 Version: %s\n", ptVerFileHeader->ucVerNo);
        }
        else
        {
            zte_printf_s("\nRead Bootloader1 Header error!\n");
        }

        zte_snprintf_s(ver,sizeof(ver),"%s%s%s",ver_bl0_str,ver_bl1_str,ver_bl2_str);
    }
    else
    {
        ulRet=BspFlashRead(VER_KEBOOT_ADDR, ptVerFileHeadChar,sizeof(T_VerFileHeader));
        if (BSP_OK==ulRet)
        {
            ptVerFileHeader = (T_VerFileHeader *)ptVerFileHeadChar;
            ptVerFileHeader->ucVerNo[44-1]='\0';
            zte_snprintf_s(ver_bl3_str,sizeof(ver_bl3_str),"\n-->Keboot Version: %s\n", ptVerFileHeader->ucVerNo);
        }
        else
        {
            zte_printf_s("\nRead KEBOOT Header error!\n");
        }

        zte_snprintf_s(ver,sizeof(ver),"%s\n", ver_bl3_str);
    }
    memcpy(headPtr,ver,strlen(ver)+1);
    free(ptVerFileHeadChar);
    ptVerFileHeadChar = NULL;
    ptVerFileHeader = NULL;
    return ulRet;
}
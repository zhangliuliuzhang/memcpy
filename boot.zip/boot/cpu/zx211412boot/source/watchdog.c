/*****************************************************************************
 * 版权所有(C) 2010, ZTE Corp. RRU Bsp Platform
 *----------------------------------------------------------------------------
 * 模 块 名 : BSP
 * 文件名称 : dpdichal.c
 * 文件标识 : {[N/A]}
 * 内容摘要 : 实现dpdic的加速器配置
 * 注意事项 : 无
 * 作    者 : 郭勇
 * 创建日期 : 2019-04-08 
 * 当前版本 : Ver1.0
 *----------------------------------------------------------------------------
 * 变更记录 :
 *
 * $记录1
 * 变 更 单: $0000000(N/A)
 * 责 任 人: 耿佳佳
 * 修改日戳: 2015-10-22 08:28:34
 * 变更说明: 创建文件
 *
 *----------------------------------------------------------------------------
 */


/* 标准库头文件 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h> 
#include "bsppub.h"
#include "bspcomm.h"
#include "crmboot.h"
#include "watchdog.h"

static UINT32 g_watchdogVirAddr = 0; 
UINT32 BootCfgWdtBaseAddr(UINT32 vir_addr)
{
	g_watchdogVirAddr = vir_addr;
	return 0;
}

/*读看门狗寄存器*/
UINT32 BootRdWdtReg(UINT32 ulAddr)
{
    ULONG ulRegAddr = 0;

	ulRegAddr = ulAddr + g_watchdogVirAddr;

    return *((volatile UINT32 *)ulRegAddr);
}

/*写看门狗寄存器*/
UINT32 BootWrWdtReg(UINT32 ulAddr, UINT32 ulData)
{
    ULONG ulRegAddr = 0;

	ulRegAddr = ulAddr + g_watchdogVirAddr;

    *((volatile UINT32 *)ulRegAddr) = ulData;

    return BSP_OK;
}

/*****************************************************************************
*  函数名称   : BootSetWatchDogTime(*)
*  功能描述   : 设置看门狗喂狗时间
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : ulTimerValue - 写入喂狗的时间，单位:s
*  输出参数   : 无
*  返 回 值   : BSP_OK表示成功; BSP_ERROR表示失败;
*  其它说明   :
*  函数属性   : 基础接口
*----------------------------------------------------------------------------
*  历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A), ty@2019-1-29 由IC2.0移植创建
*----------------------------------------------------------------------------
*/
UINT32 BootSetWatchDogTime (UINT32 ulTimerValue)
{
    UINT64       ulLoadVal = 0;

    if(WDT_MAX_TIME < ulTimerValue)
    {
    	ulTimerValue = WDT_MAX_TIME;
	}

	ulLoadVal = (UINT64)ulTimerValue * (WDT_CLK);
	ulLoadVal = (ulLoadVal >> 4);

		
	BootWrWdtReg(WDTLOCK,UNLOCK);
	BootWrWdtReg(WDTLOAD,ulLoadVal);
	BootWrWdtReg(WDTLOCK,LOCK);

    return BSP_OK;
}
/*****************************************************************************
*  函数名称   : BootWatchDogEnable(*)
*  功能描述   : 看门狗使能
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : 无
*  输出参数   : 无
*  返 回 值   : BSP_OK表示成功; BSP_ERROR表示失败;
*  其它说明   :
*----------------------------------------------------------------------------
*  历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A), ty@2019-1-29 由IC2.0移植创建
*----------------------------------------------------------------------------
*/
UINT32 BootWatchDogEnable(VOID)
{

	BootWrWdtReg(WDTLOCK,UNLOCK);
	
	BootWrWdtReg(WDTINTCLR,INT_MASK);//使能看门狗中断
	BootWrWdtReg(WDTCONTROL,INT_ENABLE | RESET_ENABLE);//使能计数和中断

	BootWrWdtReg(WDTLOCK,LOCK);

	printf("WATCHDOG ENABLE!\n");

	return BSP_OK;
}

/*****************************************************************************
*  函数名称   : BootWatchDogDisable(*)
*  功能描述   : 看门狗去使能
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : 无
*  输出参数   : 无
*  返 回 值   : BSP_OK表示成功; BSP_ERROR表示失败;
*  其它说明   : 此时系统由硬件喂狗，软件不喂狗
*  函数属性   : 基础接口
*----------------------------------------------------------------------------
*  历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A), ty@2019-1-29 由IC2.0移植创建
*----------------------------------------------------------------------------
*/

UINT32 BootWatchDogDisable(VOID)
{
   
    BootWrWdtReg(WDTLOCK,UNLOCK);
    BootWrWdtReg(WDTCONTROL,0); /* IC看门狗复位去使能 ,关闭中断和计数*/   
    BootWrWdtReg(WDTLOCK,LOCK);
    printf("WATCHDOG DISABLE!\n");
    return BSP_OK;
}

 /**********************************************************************
* 函数名称:VOID BootWatchDogInit()
* 功能描述:bootapp初始化看门狗
* 输入参数:无
* 输出参数:
* 返 回 值:BSP_OK:成功;BSP_ERROR:失败
* 其它说明:网线连通bootapp main入口到下次内核启动完成计时约20s。bsp接口单位s，
           设置看门狗时间100s，100s到达前MGR接管，否则看门狗复位
* 修改日期        版本号     修改人          修改内容
* -----------------------------------------------
* 2015-10-22       V1.0       00086970             创建
*  $0000000(N/A), ty@2019-1-29 由IC2.0移植创建
***********************************************************************/
ULONG BootWatchDogInit(VOID)
{
	ULONG ulRet = BSP_ERROR;

	ulRet = BootWatchDogDisable();
	ulRet |= BootSetWatchDogTime(100);/*设置最长喂狗时间100秒*/
	ulRet |= BootWatchDogEnable();

	return ulRet;
}


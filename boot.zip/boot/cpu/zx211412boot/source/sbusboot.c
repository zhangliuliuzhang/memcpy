/*****************************************************************************
 * 版权所有(C) 2010, ZTE Corp. RRU Bsp Platform
 *----------------------------------------------------------------------------
 * 模 块 名 : BSP
 * 文件名称 : dpdichal.c
 * 文件标识 : {[N/A]}
 * 内容摘要 : 实现dpdic的加速器配置
 * 注意事项 : 无
 * 作    者 : 郭勇
 * 创建日期 : 2019-04-08 
 * 当前版本 : Ver1.0
 *----------------------------------------------------------------------------
 * 变更记录 :
 *
 * $记录1
 * 变 更 单: $0000000(N/A)
 * 责 任 人: 耿佳佳
 * 修改日戳: 2015-10-22 08:28:34
 * 变更说明: 创建文件
 *
 *----------------------------------------------------------------------------
 */


/* 标准库头文件 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h> 
#include "bsppub.h"
#include "bspcomm.h"
#if 0
static UINT32 g_subsAxiVirAddr = 0;

/*读IC寄存器*/
UINT32 BootRdIcSbusAxiReg(UINT32 ulAddr)
{
    UINT32 ulRegAddr = 0;

	ulRegAddr = ulAddr + g_subsAxiVirAddr;

    return *((volatile UINT32 *)ulRegAddr);
}

/*写IC寄存器*/
UINT32 BootWrIcSbusAxiReg(UINT32 ulAddr, UINT32 ulData)
{
    UINT32 ulRegAddr = 0;

	ulRegAddr = ulAddr + g_subsAxiVirAddr;

    *((volatile UINT32 *)ulRegAddr) = ulData;

    return BSP_OK;
}

/**********************************************************************
* 函数名称：sbusRst
* 功能描述：对SBus Master进行复位和释放复位操作
* 输入参数：
* 输出参数：
* 返 回 值：
* 其他说明：
* 修改日期         版本号       修改人            修改内容
* ----------------------------------------------------------------------
* 2018/03/09  V1.0    邱琛            创建
************************************************************************/
void sbusRst()
{
	BootWrIcCrmReg(CRM_SBUS_CFG_REG, 0x1);
	BspSysUsDelay_Sys(4);                  // 复位后等待100个cycle（25M时钟），4us
	BootWrIcCrmReg(CRM_SBUS_CFG_REG, 0x0);
	BspSysUsDelay_Sys(4);                  // 释放复位后等待100个cycle（25M时钟），4us
}

/**********************************************************************
* 函数名称：sbusCommandTypeSwitch
* 功能描述：SBUS命令模式选择
* 输入参数：udCmdRST: 0 - SBUS receiver command mode is read or write
*                     1 - SBUS receiver command mode is reset or read result
* 输出参数：
* 返 回 值：
* 其他说明：
* 修改日期         版本号       修改人            修改内容
* ----------------------------------------------------------------------
* 2018/09/15  V1.0    邱琛            创建
************************************************************************/
void sbusCommandTypeSwitch(UINT32 udCmdRST)
{
	if(udCmdRST)
		BootWrIcCrmReg(CRM_CORE_SBUS_COMMAND_REG, 0x1);
	else
		BootWrIcCrmReg(CRM_CORE_SBUS_COMMAND_REG, 0x0);
}

UINT32 sbusResultOut(UINT8 ucSbusId, UINT8 ucOffset)
{
	UINT32 regAddress = 0;
	regAddress = SBUS_AXI2SBUS | (ucSbusId << 10) | (ucOffset << 2);
	return BootRdIcSbusAxiReg(regAddress);
}

/**********************************************************************
* 函数名称：sbusCommand
* 功能描述：发送SBUS命令
* 输入参数：ucSbusId: SBus环上ID
*          ucOffset：寄存器偏移地址
*          udData：待发送指令
* 输出参数：
* 返 回 值：
* 其他说明：
* 修改日期         版本号       修改人            修改内容
* ----------------------------------------------------------------------
* 2018/03/09  V1.0    邱琛            创建
************************************************************************/
void sbusCommand(UINT8 ucSbusId, UINT8 ucOffset, UINT32 udData)
{
	UINT32 regAddress = 0;
	regAddress = SBUS_AXI2SBUS | (ucSbusId << 10) | (ucOffset << 2);
	BootWrIcSbusAxiReg(regAddress, udData);
}

/**********************************************************************
* 函数名称：sbusSetClk12_5M
* 功能描述：配置SBus总线速率
* 输入参数：
* 输出参数：
* 返 回 值：
* 其他说明：
* 修改日期         版本号       修改人            修改内容
* ----------------------------------------------------------------------
* 2018/03/09  V1.0    邱琛            创建
* 2018/08/03  V1.1    邱琛            根据博通建议由25M调整为12.5M
************************************************************************/

void sbusSetClk12_5M()
{
	sbusCommand(BROADCAST_ADDR_MASTER, 0x0A, 0x00000001);   // SBus ring clock divider setting
}

void sbusSetClk25M()
{
	sbusCommand(BROADCAST_ADDR_MASTER, 0x0A, 0x00000000);   // SBus ring clock divider setting
}

#endif

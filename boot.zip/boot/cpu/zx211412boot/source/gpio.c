/**************************************************************************
* 版权所有 (C)2001, 深圳市中兴通讯股份有限公司
*
* 文件名称: gpio.c
* 文件标识:
* 内容摘要:
* 其它说明: zx211412.c gpio and pad configuration
* 当前版本: V1.0
* 作    者: 罗乔发
* 完成日期:
*
* 修改记录1:
*    修改日期: 2010年04月09日
*    版 本 号: V1.0
*    修 改 人: 罗乔发
*    修改内容: 创建
* 修改记录2:
**************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h> 
#include "bsppub.h"
#include "bspcomm.h"
#include "gpio.h"


static UINT32 g_Pad0VirAddr = 0 ;
static UINT32 g_Pad1VirAddr = 0 ;

UINT32 BootCfgGpioPadBaseAddr(UINT32 padIdx,UINT32 base)
{
	if(padIdx == 0)
	{
		g_Pad0VirAddr=base;
	
}
	else if(padIdx == 1)
	
{
		g_Pad1VirAddr=base;
	}
	else
	{
		return BSP_ERROR;
	}
	
	return BSP_OK;
}

/******************************************************************************
*  函数名称   : BootRdIcGpioPadReg(UINT32 padIdx,UINT32 ulAddr)
*  功能描述   : 实现对gpio pad读寄存器操作，padIdx分为两组
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : padIdx  pad组号，ulAddr pad地址
*  输出参数   : 无
*  返 回 值   : BSP_OK, 操作成功; BSP_ERROR_INVALID_PARA, 输入参数错误
*  其它说明   : *  函数属性   : 基础接口
*------------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*------------------------------------------------------------------------------
*/
UINT32 BootRdIcGpioPadReg(UINT32 padIdx,UINT32 ulAddr)
{
    UINT32 ulRegAddr = 0;
	UINT32 base;

	if(padIdx == 0)
	{
		base = g_Pad0VirAddr;
	
}
	else
	
{
		base = g_Pad1VirAddr;
	}
	
	ulRegAddr = ulAddr + base;

    return *((volatile UINT32 *)ulRegAddr);
}

/******************************************************************************
*  函数名称   : BootWrIcGpioPadReg(UINT32 padIdx,UINT32 ulAddr, UINT32 ulData)
*  功能描述   : 实现对gpio pad写寄存器操作，padIdx分为两组
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : padIdx  pad组号，ulAddr pad地址       ulData 值
*  输出参数   : 无
*  返 回 值   : BSP_OK, 操作成功; BSP_ERROR_INVALID_PARA, 输入参数错误
*  其它说明   : *  函数属性   : 基础接口
*------------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*------------------------------------------------------------------------------
*/
UINT32 BootWrIcGpioPadReg(UINT32 padIdx,UINT32 ulAddr, UINT32 ulData)
{
    UINT32 ulRegAddr = 0;
	UINT32 base;
	
	if(padIdx == 0)
	{
		base = g_Pad0VirAddr;
	
}
	else
	
{
		base = g_Pad1VirAddr;
	}
	
	ulRegAddr = ulAddr + base;

    *((volatile UINT32 *)ulRegAddr) = ulData;

    return BSP_OK;
}

/******************************************************************************
*  函数名称   : BootWrIcGpioPadRegBit(UINT32 padIdx,UINT32 ulAddr, UINT32 ulData, UINT32 bitoff)
*  功能描述   : 实现对gpio pad写寄存器操作，padIdx分为两组
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : padIdx  pad组号，ulAddr pad地址       ulData 值
*  输出参数   : 无
*  返 回 值   : BSP_OK, 操作成功; BSP_ERROR_INVALID_PARA, 输入参数错误
*  其它说明   : *  函数属性   : 基础接口
*------------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*------------------------------------------------------------------------------
*/
UINT32 BootWrIcGpioPadRegBit(UINT32 padIdx,UINT32 ulAddr, UINT32 ulVal,UINT32 bitoff)
{
	UINT32 reg;

	reg = BootRdIcGpioPadReg(padIdx,ulAddr);
	BITS_SET(reg,ulVal,bitoff,1);
	
	return BootWrIcGpioPadReg(padIdx,ulAddr,reg);
}

UINT32 BootWrIcGpioPadEn(UINT32 gpio,UINT32 en)
{
	UINT32 addr;

	addr = 4*gpio + 0x98;
	return BootWrIcGpioPadRegBit(1,addr,(en&0x01),8);	
}



/******************************************************************************
*  函数名称   : BootLedCtrl(*)
*  功能描述   : 实现对面板灯的控制
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : ulLedName   - 灯名, 定义于BspPublic.h文件或者BoardApi.h文件
                ulLedMode - 灯状态的控制  BSP_LED_OP_OFF --灭，BSP_LED_OP_ON --亮
*  输出参数   : 无
*  返 回 值   : BSP_OK, 操作成功; BSP_ERROR_INVALID_PARA, 输入参数错误
*  其它说明   : DPD IC 8T 的LED 通过GPIO 控制，GPIO 低电平点亮LED
*  函数属性   : 基础接口
*------------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A), ty@2019-1-29 由IC2.0移植创建
*------------------------------------------------------------------------------
*/
UINT32 BootLedCtrl(UINT32 ulLedname, UINT32 ulLedMode)
{

    switch (ulLedname)
    {
        case BSP_LED_ID_RUN: /* LedRun*/
        {
            _BspZteGpioSet(DPDIC_GPIO_LED_RUN, (BSP_LED_OP_ON == ulLedMode) ? GPIO_LEVEL_LOW : GPIO_LEVEL_HIGH);
            break;
        }
        case BSP_LED_ID_ALM: /*LedAlm */
        {
            _BspZteGpioSet(DPDIC_GPIO_LED_ALARM, (BSP_LED_OP_ON == ulLedMode) ? GPIO_LEVEL_LOW : GPIO_LEVEL_HIGH);
            break;
        }

        default:
        {
            dbgInfo("Led is not exit\n");
            return BSP_ERROR_DEVICE_NOT_EXIST;
        }
    }
    return BSP_OK;
}


/*****************************************************************************
*  函数名称   : BootInitBoardGpioPort(*)
*  功能描述   : 初始化单板的GPIO端口属性
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : 无
*  输出参数   : 无
*  返 回 值   : BSP_OK, 其它值为失败
*  其它说明   : 由于不同的单板使用的GPIO端口属性可能不一样，所以这个放到单板中
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*----------------------------------------------------------------------------
*/
UINT32 BootInitBoardGpioPort(void)
{
    UINT32 ulRetVal = BSP_OK;

    _BspZteGpioSetMode(DPDIC_GPIO_LED_RUN, GPIO_MODE_OUTPUT);/*设置GPIO管脚及其对应的模式*/
    _BspZteGpioSetMode(DPDIC_GPIO_LED_ALARM, GPIO_MODE_OUTPUT);

	
    _BspZteGpioSetMode(DPDIC_GPIO_MASTER_SLAVE_FLAG, GPIO_MODE_INPUT);
    _BspZteGpioSetMode(DPDIC_GPIO_DDR_CAPACITY_FLAG, GPIO_MODE_INPUT);
	_BspZteGpioSetMode(DPDIC_GPIO_SFP1_PLACE_FLAG, GPIO_MODE_INPUT);
    _BspZteGpioSetMode(DPDIC_GPIO_SFP0_PLACE_FLAG, GPIO_MODE_INPUT);
	/*后续有需求的GPIO的状态初始更改，再增加*/
	
    return ulRetVal;
}




/******************************************************************************
*  函数名称   : BootSetRunLedPinOutMode(*)
*  功能描述   : 实现对面板灯RUN的模式控制，控制其以PWM输出，还是以GPIO输出
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : 
*  输出参数   : 无
*  返 回 值   : BSP_OK, 操作成功; BSP_ERROR_INVALID_PARA, 输入参数错误
*  其它说明   : 
*  函数属性   : 
*------------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*------------------------------------------------------------------------------
*/
/* Started by AICoder, pid:g3a79p289f2f34a1484e099710ae1c2d31542fa3 */
UINT32 BootSetRunLedPinOutMode(UINT32 mode)
{

	if( PWM_OUT_MODE == mode)
	{
		/*pwm mode*/
		BootWrIcGpioPadRegBit(LED_RUN_PAD_REG_GRP_IDX,LED_RUN_PAD_REG_OFFSET,1,9);
		
		BspSysMsDelay(10);
		
		/*en = 1*/
		BootWrIcGpioPadRegBit(LED_RUN_PAD_REG_GRP_IDX,LED_RUN_PAD_REG_OFFSET,1,8);
	}
	else if( GPIO_OUT_MODE == mode)
	{
		/*en = 1*/
		BootWrIcGpioPadRegBit(LED_RUN_PAD_REG_GRP_IDX,LED_RUN_PAD_REG_OFFSET,1,8);
		
		BspSysMsDelay(10);

		/*gpio mode*/
		BootWrIcGpioPadRegBit(LED_RUN_PAD_REG_GRP_IDX,LED_RUN_PAD_REG_OFFSET,0,9);
	}
	else
	{
		return BSP_ERROR;
	}

	return BSP_OK;
}
/* Ended by AICoder, pid:g3a79p289f2f34a1484e099710ae1c2d31542fa3 */


/**************************************************************************
 * 版权所有 (C)2001, 深圳市中兴通讯股份有限公司
 *
 * 文件名称: watchdog.h
 * 文件标识:
 * 内容摘要:
 * 其它说明:
 * 当前版本: 
 * 作    者:
 * 完成日期:
 *
 * 修改记录1:
 *    修改日期: 
 *    版 本 号: 
 *    修 改 人: 
 *    修改内容: 创建
 * 修改记录2:
 **************************************************************************/

#ifndef _WATCHDOG_H_
#define _WATCHDOG_H_
#ifdef __cplusplus

extern "C" {
#endif /* __cplusplus */

#define WDTLOAD			0x000
#define LOAD_MIN		0x00000001
#define LOAD_MAX		0xFFFFFFFF
#define WDTVALUE		0x004
#define WDTCONTROL		0x008

#define	INT_ENABLE		(1 << 0)
#define	RESET_ENABLE	(1 << 1)
#define WDTINTCLR		0x00C
#define WDTRIS			0x010
#define WDTMIS			0x014
#define INT_MASK		(1 << 0)
#define WDTLOCK			0xC00
#define	UNLOCK			0x1ACCE551
#define	LOCK			0x00000001
#define WDT_CLK         (50000000)
#define WDT_MAX_TIME    (1373)
	
UINT32 BootRdWdtReg(UINT32 ulAddr);
UINT32 BootWrWdtReg(UINT32 ulAddr, UINT32 ulData);
ULONG BootWatchDogEnable(VOID);
ULONG BootWatchDogDisable(VOID);
ULONG BootWatchDogInit(VOID);
UINT32 BootCfgWdtBaseAddr(UINT32 vir_addr);

#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif


/*---------------------------------------------------------------------------------------------------------------------
 * 版权所有(C)2000-2011, 中兴通讯股份有限公司 
 * 
 * 文 件 名: uart.h  
 * 
 * 作    者: 10010370
 * 
 * 接口描述:
 *     Bootrom软件uart接口处理
 * 
 * 版    本: v1.0
 * 
 * ------------------------------------------------------------------------------------------------------------------ 
 * 
 *     修改日期         修改人            修改内容
 *     20111103         10010370          创建
 *     
 *-------------------------------------------------------------------------------------------------------------------*/

#ifndef _GPIO_H_
#define _GPIO_H_

#define GPIO_MODE_OUTPUT            	0x00			// 输出模式
#define GPIO_MODE_INPUT             	0x01			// 输入模式
#define GPIO_MODE_INT               	0x02			// 中断模式
#define GPIO_LEVEL_LOW             		0x00			// 低电平
#define GPIO_LEVEL_HIGH            		0x01			// 高电平


/*BK 关注的GPIO定义如下*/
#define DPDIC_GPIO_LED_RUN        		19
#define DPDIC_GPIO_LED_ALARM      		8
#define DPDIC_GPIO_MASTER_SLAVE_FLAG    14   /*1 = MASTER   0 = SLAVE*/
#define DPDIC_GPIO_DDR_CAPACITY_FLAG    15   /*1 = 1GB 0 = 512MB*/
#define DPDIC_GPIO_SFP1_PLACE_FLAG    9   /*1 = out-place 0 = in-place*/
#define DPDIC_GPIO_SFP0_PLACE_FLAG    5   /*1 = out-place 0 = in-place*/


#define PWM_OUT_MODE    1
#define GPIO_OUT_MODE   0

#define LED_RUN_PAD_REG_GRP_IDX        1
#define LED_RUN_PAD_REG_OFFSET         0xe4

UINT32 BootCfgGpioPadBaseAddr(UINT32 padIdx,UINT32 base);
/* Started by AICoder, pid:8eb3bbbf07b2439148530a7d9038ab0b38889528 */
UINT32 BootWrIcGpioPadEn(UINT32 gpio, UINT32 en);
UINT32 BootWrIcGpioPadRegBit(UINT32 padIdx, UINT32 ulAddr, UINT32 ulVal, UINT32 bitoff);
UINT32 BootInitBoardGpioPort(void);
UINT32 BootLedCtrl(UINT32 ulLedname, UINT32 ulLedMode);
UINT32 BootSetRunLedPinOutMode(UINT32 mode);

extern UINT32 _BspZteGpioSetMode(ULONG ulPort, ULONG ulMode);
extern UINT32 _BspZteGpioSet(ULONG ulPort, ULONG ulIsHigh);
/* Ended by AICoder, pid:8eb3bbbf07b2439148530a7d9038ab0b38889528 */
#endif  /* _UART_H_ */

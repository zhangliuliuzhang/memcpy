/**************************************************************************
 * 版权所有 (C)2001, 深圳市中兴通讯股份有限公司
 *
 * 文件名称: halboot.h
 * 文件标识:
 * 内容摘要:
 * 其它说明:
 * 当前版本: ZXSDR BBUV120B01
 * 作    者: 
 * 完成日期:
 *
 * 修改记录1:
 *    修改日期: 2012年06月21日
 *    版 本 号: ZXSDR BBUV120B01
 *    修 改 人: 耿佳佳
 *    修改内容: 创建
 * 修改记录2:
 **************************************************************************/

#ifndef _HALBOOT_H_
#define _HALBOOT_H_

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */


#define HAL_MASK(n)     (0xFFFFFFFF >> (32 - (n)))   /* 对bit[0:n-1]掩码(最多支持32字节)*/    

#define ASRAMCTRL_CHANNEL_MAX_NUM      (17)  /* 可配置的模块个数 */
#define  MAX_MEM_BLK_MAP          ASRAMCTRL_CHANNEL_MAX_NUM
#define SC_MS_FLAG_OFFSET          0x58
#define  MEM_BLK_STATUS_NOUSE      0
#define  MEM_BLK_STATUS_DEFINE     1
#define  MEM_BLK_STATUS_INITED     2

#define  ASRAMCTRL_IC_OFFSET       0x400000
/** HAL公共错误码 */
#define HAL_SOK                 		(0)			/* 正确 */
#define HAL_OK                 		    HAL_SOK		/* 正确 */
#define HAL_ERROR 0xffffffff

#define HAL_INVALID_VALUE 0xffffffff

#define HAL_ESYS_FAIL           		(0x1)		/* 一般错误 */
#define HAL_ESYS_INUSE          		(0x2)		/* 外设资源正在使用 */
#define HAL_ESYS_XIO            		(0x3)		/* 遭遇管脚共享争夺 */
#define HAL_ESYS_OVFL           		(0x4)		/* 可用资源耗尽 */
#define HAL_ESYS_BADHANDLE     	 		(0x5)		/* 传入句柄无效 */
#define HAL_ESYS_INVPARAMS      		(0x6)		/* 参数无效 */
#define HAL_ESYS_INVCMD         		(0x7)		/* 命令无效 */
#define HAL_ESYS_INVQUERY       		(0x8)		/* 队列无效 */
#define HAL_ESYS_NOTSUPPORTED   		(0x9)		/* 行为不支持 */
#define HAL_ESYS_ERROR                  HAL_ESYS_FAIL                   

#if 0	/* 2011-05-10, replace with HAL_ESYS_INALID_HANDLE */
#define HAL_INVALID_HANDLE				(0x100)		/* invalid handle */
#else
#define HAL_ESYS_INVALID_HANDLE			(0x100)		/* invalid handle */
#endif

#define  HAL_REG_CFG_URST_ARM_WDRST_EN		(0x0000003C)	//SoC HAL
#define  HAL_REG_RST_REC_DEBUG_REGX		(0x000000e0)

/* *结构体定义* */
typedef enum
{
  MEM_BLK_DDR3=0,
  MEM_BLK_CEVA_ICP=1,
  MEM_BLK_CEVA_L1D=2,
  MEM_BLK_CEVA_L2PSRAM=3,
  MEM_BLK_CEVA_L2PAPB=4,
  MEM_BLK_CEVA_PDMA=5,
  MEM_BLK_DIF_CFG=6,
  MEM_BLK_J204B_SERDES=7,
  MEM_BLK_OPT_SERDES=8,
  MEM_BLK_ASRAM=9,
  MEM_BLK_CEVA_CORE=10,
  MEM_BLK_CEVA_ICU=11,  
  MEM_BLK_USB =12,
  MEM_BLK_SPI0=13,
  MEM_BLK_SPI1=14,
  MEM_BLK_SPI2=15,
  MEM_BLK_SPI3=16,
  MEM_BLK_I2C0=17,
  MEM_BLK_I2C1=18,
  MEM_BLK_I2C2=19,
  MEM_BLK_I2C3=20,
  
  MEM_BLK_CEVA_SCR=21,  
  MEM_BLK_SPINLOCK=22,  
  MEM_BLK_CEVA_L1P=23,
  MEM_BLK_GPIO=24,
  MEM_BLK_APB_SC=25,
  MEM_BLK_UDMA=26,
  MEM_BLK_PDMA=27,
  MEM_BLK_TIMER=28,
  MEM_BLK_CRS=29,

  MEM_BLK_DIF_CB=30,
  MEM_BLK_DIF_CFR=31,
  MEM_BLK_DIF_DL=32,
  MEM_BLK_DIF_DPD=33,
  MEM_BLK_PDR=34,
  MEM_BLK_PDR_WP=35,

  MEM_BLK_UART0=36,
  MEM_BLK_UART1=37,
  MEM_BLK_UART2=38,
  MEM_BLK_UART3=39,
  
  MEM_BLK_GMAC0=40,
  MEM_BLK_GMAC1=41,
  MEM_BLK_ARM_ICP = 42,

  MEM_BLK_CEVA_MCCI=43,  
  MEM_BLK_ARM_GIC=44,  
    
  MAX_MEM_BLK=60

}E_HAL_MEM_BLK_DEF;


/** 结构体类型: 各个模块实际地址，大小和对应虚拟地址等的配置信息 */
typedef struct 
{
  UINT32 udInitedFlag;
  UINT32 udMemBlkNo;
  UINT32 udPhyAddrStart;
  UINT32 udPhySize;
  UINT32 udVirtualAddr;
}T_HAL_ADDRMAP_MEMBLK;




/** 结构体类型: 各个模块映射通道，大小和偏移等的配置信息 */
typedef struct 
{
  UINT32 udInitedFlag;
  UINT32 udMemBlkNo; 
  UINT32 udAsramMapChan;
  UINT32 udMapSize;
  UINT32 udMapStartOffset;
 
} T_HAL_ADDRMAP_MEMMAP;


#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif


/*****************************************************************************
* 版权所有(C) 2010, ZTE Corp. RRU Bsp Platform
*----------------------------------------------------------------------------
* 模 块 名 : BSP
* 文件名称 : zx211410boot.c
* 文件标识 : {[N/A]}
* 内容摘要 : zx211410 cpu bootapp接口实现
* 注意事项 : 无
* 作    者 : 耿佳佳
* 创建日期 : 2015-10-22 08:28:34
* 当前版本 : Ver1.0
*----------------------------------------------------------------------------
* 变更记录 :
*
* $记录1
* 变 更 单: $0000000(N/A)
* 责 任 人: 耿佳佳
* 修改日戳: 2015-10-22 08:28:34
* 变更说明: 创建文件
*
*----------------------------------------------------------------------------
*/

#include "stdio.h"
#include <sys/types.h>
#include <sys/stat.h>
#include <netinet/in.h>
#include <fcntl.h>
#include <errno.h>
#include "vxadp.h"
#include <math.h>

#include "bsppub.h"
#include "bspcomm.h"
#include "bsperrcode.h"
#include "zx211410boot.h"
#include "bspcommonstdlog.h"

#if defined(COMPILE_FOR_KEXEC_BOOT)
#include "bootadp.h"
#include "halboot.h"
#include "flash.h"

/*#else
#include "hal_addrmap.h"
#include "hal_regaddr.h"*/
#endif


#ifdef COMPILE_FOR_KEXEC_BOOT
/**************************************************************************
*                        宏
**************************************************************************/

#define MAC_FRAME_FILTER  (0x00000004)   /*MAC帧过滤寄存器 offset:0x0004 */
/* 单板复位开关变量，0--不复位，1--复位 */


/**************************************************************************
*                         数据类型                                       *
**************************************************************************/

/**************************************************************************
*                         全局变量定义                                   *
**************************************************************************/

/**************************************************************************
*                         外部变量声明
**************************************************************************/

/**************************************************************************
*                         局部函数声明
**************************************************************************/

/**************************************************************************
*                         全局函数声明
**************************************************************************/
extern VOID MainLoop ();
extern void BspFunction(unsigned char * ucpsymbname, unsigned char * ucpboardname);

ULONG SetDefaultCmdline();
extern ULONG BootFlashInit(VOID);
extern ULONG BootSoftModInit(void);
/**************************************************************************
*                         函数实现
**************************************************************************/



#define SCU_BASE            0xF9686000
#define M_CRS_BASE          (0xf952f000)


#define TWD_OFFSET          0x600
#define TWD_BASE            (SCU_BASE + TWD_OFFSET)

#define DOG_OFFSET          0x20
#define WATCHDOG_BASE_ADDR  (TWD_BASE + DOG_OFFSET)
#define WATCHDOG_REGS_SIZE  0x38

#define WATCHDOG_ENABLE     (0x1 << 0)
#define WATCHDOG_MODE_SET   (0x1 << 3)
#define uswap_32(x) \
    ((((x) & 0xff000000) >> 24) | \
    (((x) & 0x00ff0000) >>  8) | \
    (((x) & 0x0000ff00) <<  8) | \
    (((x) & 0x000000ff) << 24))

#define cpu_to_le32(x)  uswap_32(x)
#define dsb() __asm__ __volatile__ ("dsb" : : : "memory")
Tlist BoardPreCall_list     = {&(BoardPreCall_list),&(BoardPreCall_list)};
/*BspBoardPreInit的调用链表函数序号*/
static ULONG sBoardPreInitCallCnt   = 0;

static ULLONG sBoardInitError   = 0;

#define KDA_DEVICE_NAME "/dev/KernDrvAgt"
static int g_iKdaDrvFd = -1;
extern UCHAR g_ucCmdLine[256];

typedef struct tMemAddr{
    ULONG   phyAddr;
    ULONG   virAddr;
}TMemAddr;
TMemAddr DogAddr = {SCU_BASE, 0};

ULONG g_ulLedFlag = 0;
ULONG  g_ulRamReservedAddr =0;
ULONG  g_ulRtcRegisterAddr =0;
/*****************************************************************************
*  函数名称   : BspGetCpuType(*)
*  功能描述   : 双boot模块用于获取cpu类型
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : 无
*  输出参数   : 无
*  返 回 值   : 成功 - BSP_OK
*  其它说明   :
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A), yam@2014-10-09 14:07:25 创建
*----------------------------------------------------------------------------
*/
UINT32 BspGetCpuType (UCHAR *pucCpuType)
{
    if (NULL == pucCpuType)
        return BSP_ERROR_NULL_POINTER;

    *pucCpuType = BSP_CORTEXA9;
    return BSP_OK;
}

/**********************************************************************
* 函数名称:VOID intfBspWatchDogSetInterval(VOID)
* 功能描述:BSP看门狗最大时长设置。
* 输入参数:无。
* 输出参数:无。
* 返 回 值:无。
* 其它说明:  360秒看门狗
* 修改日期        版本号     修改人          修改内容
* -----------------------------------------------
* 2014/5/12            V1.0              yam                        创建
***********************************************************************/
ULONG BootintfBspWatchDogSetInterval(void)
{
    T_DPDIC_DOG *ptdog = (T_DPDIC_DOG *)DogAddr.virAddr;
    INPUT_POINTER_CHECK(ptdog);

    /**yam infrom
    timer interval = (PRESCALER_value+1) x (Load_value+1)/PERIPHCLK
    timer interval use 360sec.
    PRESCALER_value is set in WDOG_CONTROL[15:8], here we set 0x31(49) in BspWatchDogHardMonEnable().
    Load_value is the value needs to be written in WDOG_LOAD register.
    PERIPHCLK is A9MPcore_clk/2 = 400MHz=4*10^8
    so Load_value = 192*10^9 /50 -1 = 0xe4e1c000-1=ABA94FFF.*/
    *(volatile ULONG*) (&(ptdog->WDOG_LOAD)) = cpu_to_le32(0xABA94FFF);
    return BSP_OK;
}

/*****************************************************************************
*  函数名称   : BootWatchDogEnable(*)
*  功能描述   : 看门狗使能
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : 无
*  输出参数   : 无
*  返 回 值   : BSP_OK表示成功; BSP_ERROR表示失败;
*  其它说明   :
*----------------------------------------------------------------------------
*  历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A), 王勇@2014-6-18 ,78e
*----------------------------------------------------------------------------
*/
ULONG BootWatchDogEnable(VOID)
{
    T_DPDIC_DOG *ptdog = (T_DPDIC_DOG *)DogAddr.virAddr;
    ULONG       ulVal = 0;
    ULONG       ulRet = BSP_OK;
    INPUT_POINTER_CHECK(ptdog);

    ulRet = BootintfBspWatchDogSetInterval();
    /* IC看门狗复位使能 */
    WrReg(0,MEM_BLK_CRS,HAL_REG_CFG_URST_ARM_WDRST_EN,1);

    ulVal = *(volatile ULONG *)(&(ptdog->WDOG_CONTROL));
    ulVal = cpu_to_le32(ulVal);
    ulVal |= (WATCHDOG_ENABLE | WATCHDOG_MODE_SET);
    ulVal = cpu_to_le32(ulVal);
    *(volatile ULONG *)(&(ptdog->WDOG_CONTROL)) = ulVal;
    printf("WATCHDOG ENABLE!\n");

    return BSP_OK;
}


/*****************************************************************************
*  函数名称   : BootWatchDogDisable(*)
*  功能描述   : 看门狗去使能
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : 无
*  输出参数   : 无
*  返 回 值   : BSP_OK表示成功; BSP_ERROR表示失败;
*  其它说明   : 此时系统由硬件喂狗，软件不喂狗
*  函数属性   : 基础接口
*----------------------------------------------------------------------------
*  历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A), 王勇@2014-6-18 ,78e
*----------------------------------------------------------------------------
*/
ULONG BootWatchDogDisable(VOID)
{
    T_DPDIC_DOG *ptdog = (T_DPDIC_DOG *)DogAddr.virAddr;
    ULONG       ulVal = 0;

    INPUT_POINTER_CHECK(ptdog);

    /* IC看门狗复位去使能 */
    WrReg(0,MEM_BLK_CRS,HAL_REG_CFG_URST_ARM_WDRST_EN,0);
/*lint -e123*/
/*lint -e10*/
/*lint -e40*/
    dsb();
    *(volatile ULONG *)(&(ptdog->WDOG_DISABLE)) = 0x12345678;
    dsb();
    *(volatile ULONG *)(&(ptdog->WDOG_DISABLE)) = 0x87654321;
    dsb();
/*lint +e123*/
/*lint +e10*/
/*lint +e40*/
    ulVal = *(volatile ULONG *)(&(ptdog->WDOG_CONTROL));
    ulVal = cpu_to_le32(ulVal);
    ulVal &= ~(WATCHDOG_ENABLE);
    ulVal &= ~(WATCHDOG_MODE_SET);
    *(volatile ULONG *)(&(ptdog->WDOG_CONTROL)) = cpu_to_le32(ulVal);
    printf("WATCHDOG DISABLE!\n");
    return BSP_OK;
}
/*****************************************************************************
*  函数名称   : BootSetWatchDogTime(*)
*  功能描述   : 设置看门狗喂狗时间
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : ulTimerValue - 写入喂狗的时间，单位:s
*  输出参数   : 无
*  返 回 值   : BSP_OK表示成功; BSP_ERROR表示失败;
*  其它说明   :
*  函数属性   : 基础接口
*----------------------------------------------------------------------------
*  历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A), 王勇@2014-6-18 ,78e
*----------------------------------------------------------------------------
*/
ULONG BootSetWatchDogTime (ULONG ulTimerValue)
{
    T_DPDIC_DOG *ptdog    = (T_DPDIC_DOG *)DogAddr.virAddr;
    FLOAT       ftmp = 0;
    ULONG       ulLoadVal = 0;
    ULONG       ulPreVal  = 0;
    ULONG       ulTmpVal  = 0;
    ULONG       ulTmp  = 0;
    INPUT_POINTER_CHECK(ptdog);
    ulTmp = ulTimerValue;
    /*
    timer interval = (PRESCALER_value+1) x (Load_value+1)/PERIPHCLK
    PRESCALER_value is set in WDOG_CONTROL[15:8]
    Load_value is the value needs to be written in WDOG_LOAD register.
    PERIPHCLK is A9MPcore_clk/2 = 400MHz=4*10^8
    */

    ulTmpVal = *(volatile ULONG *)(&(ptdog->WDOG_CONTROL));

    ulTmpVal = cpu_to_le32(ulTmpVal);

    ulPreVal = (ulTmpVal >> 8) & 0xff;

    ftmp = (FLOAT)ulTmp/(ulPreVal + 1);
/*lint -e524*/
    ulLoadVal = ftmp * 4 * pow(10,8) - 1;
/*lint +e524*/
    *(volatile ULONG *)(&(ptdog->WDOG_LOAD)) = cpu_to_le32(ulLoadVal);

    return BSP_OK;
}


/******************************************************************************
*  函数名称   : BootLedCtrl(*)
*  功能描述   : 实现对面板灯的控制
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : ulLedName   - 灯名, 定义于BspPublic.h文件或者BoardApi.h文件
                ulLedMode - 灯状态的控制  BSP_LED_OP_OFF --灭，BSP_LED_OP_ON --亮
*  输出参数   : 无
*  返 回 值   : BSP_OK, 操作成功; BSP_ERROR_INVALID_PARA, 输入参数错误
*  其它说明   : DPD IC 8T 的LED 通过GPIO 控制，GPIO 低电平点亮LED
*  函数属性   : 基础接口
*------------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A), 宋志强@2014-06-16 10:00:00 创建
*------------------------------------------------------------------------------
*/
ULONG BootLedCtrl(ULONG ulLedname, ULONG ulLedMode)
{

    switch (ulLedname)
    {
        case BSP_LED_ID_RUN: /* LedRun*/
        {
            _BspZteGpioSet(ZTE_DPDIC_GPIO_LED_RUN, (BSP_LED_OP_ON == ulLedMode) ? GPIO_LEVEL_LOW : GPIO_LEVEL_HIGH);
            break;
        }
        case BSP_LED_ID_ALM: /*LedAlm */
        {
            _BspZteGpioSet(ZTE_DPDIC_GPIO_LED_ALARM, (BSP_LED_OP_ON == ulLedMode) ? GPIO_LEVEL_LOW : GPIO_LEVEL_HIGH);
            break;
        }
        case BSP_LED_ID_LINK0: /*LedOPT0，原1.1.8接口是BSP_LED_ID_OPT0 */
        {
            _BspZteGpioSet(ZTE_DPDIC_GPIO_LED_OPT0, (BSP_LED_OP_ON == ulLedMode) ? GPIO_LEVEL_LOW : GPIO_LEVEL_HIGH);
            break;
        }
        case BSP_LED_ID_LINK1: /*LedOPT1,原1.1.8接口是BSP_LED_ID_OPT1 */
        {
            _BspZteGpioSet(ZTE_DPDIC_GPIO_LED_OPT1, (BSP_LED_OP_ON == ulLedMode) ? GPIO_LEVEL_LOW : GPIO_LEVEL_HIGH);
            break;
        }
        case BSP_LED_ID_VSWR: /*LedVSWR */
        {
            _BspZteGpioSet(ZTE_DPDIC_GPIO_LED_VSWR, (BSP_LED_OP_ON == ulLedMode) ? GPIO_LEVEL_LOW : GPIO_LEVEL_HIGH);
            break;
        }
        #if 0
        case BSP_LED_ID_RADIO: /*LedRADIO.小区指示 */
        {
            printf("Radio led not inplement\n! ");
            break;
        }
        #endif
        case BSP_LED_ID_RADIO: /*LedRADIO.小区指示 */
        case BSP_LED_ID_ACT:
        {
            _BspZteGpioSet(ZTE_DPDIC_GPIO_LED_ACT, (BSP_LED_OP_ON == ulLedMode) ? GPIO_LEVEL_LOW : GPIO_LEVEL_HIGH);
            break;
        }
        default:
        {
            dbgInfo("Led is not exit\n");
            return BSP_ERROR_DEVICE_NOT_EXIST;
        }
    }
    return BSP_OK;
}

/**************************************************************************
* 函数名称: int BootSetLedFlag(void)
* 功能描述: 工装 应用程序入口
* 输入参数: 无
* 输出参数:
* 返 回 值: 无
* 其它说明:
*
* 修改日期:    版本号     修改人        修改内容
* -----------------------------------------------
* 2010-05-25     V1.0      xxx        Created
**************************************************************************/  

ULONG BootSetLedFlag(ULONG ulSwitch)
{
    if( 0 == ulSwitch)
        g_ulLedFlag = 0;
    else
        g_ulLedFlag = 1;

    return BSP_OK;
}

VOID BootLedBling(VOID)
{
    ULONG ucClkRate = sysClkRateGet();
    BootLedCtrl(BSP_LED_ID_RUN,BSP_LED_OP_OFF);
    taskDelay(ucClkRate);
    BootLedCtrl(BSP_LED_ID_RUN,BSP_LED_OP_ON);
    taskDelay(ucClkRate);
    /*先亮后灭的话，出现调度原因导致的闪灯过后常亮RUN灯偶发不亮的问题，调整为先灭后亮规避该问题*/
}

VOID BootLedTask(VOID)
{
    while(1)
    {
        if(0 != g_ulLedFlag)
        {
            BootLedBling();
        }
        else
        {
            BootSysMsDelay(500);
        }
    }

}

/**********************************************************************
* 函数名称:void led_run(unsigned char ucMode)
* 功能描述:led_run led灯闪烁模式
* 输入参数: ucMode  0 只亮run灯,  1 run灯周期性闪
* 输出参数:无。
* 返 回 值:无
* 其它说明: dpdic led 使用情况:
GPIO 14 -- RUN
GPIO 15 -- ALM
GPIO 16 --OPT0
GPIO 17 -- OPT1
GPIO 19 --VSWR
GPIO 20 -- ACT
* 修改日期        版本号     修改人          修改内容
* -----------------------------------------------
* 2015/10/12            V1.0            00086970                       创建
***********************************************************************/

VOID BootLedRun(UCHAR ucMode)
{

    if(0 == ucMode)/*只亮run灯,其他灯灭 */
    {
        BootSetLedFlag(0);
        BootLedCtrl(BSP_LED_ID_ALM, BSP_LED_OP_OFF);
        BootLedCtrl(BSP_LED_ID_LINK0, BSP_LED_OP_OFF);
        BootLedCtrl(BSP_LED_ID_LINK1, BSP_LED_OP_OFF);
        BootLedCtrl(BSP_LED_ID_VSWR, BSP_LED_OP_OFF);
        BootLedCtrl(BSP_LED_ID_ACT, BSP_LED_OP_OFF);
        BootLedCtrl(BSP_LED_ID_RUN, BSP_LED_OP_ON);
    }
    else if(1 == ucMode)/*run灯周期性闪烁*/
    {
        BootSetLedFlag(1);
        BootLedCtrl(BSP_LED_ID_ALM, BSP_LED_OP_OFF);
        BootLedCtrl(BSP_LED_ID_LINK0, BSP_LED_OP_OFF);
        BootLedCtrl(BSP_LED_ID_LINK1, BSP_LED_OP_OFF);
        BootLedCtrl(BSP_LED_ID_VSWR, BSP_LED_OP_OFF);
        BootLedCtrl(BSP_LED_ID_ACT, BSP_LED_OP_OFF);

    }
    else if(2 == ucMode)/*所有灯都全亮*/
    {
        BootSetLedFlag(0);
        BootLedCtrl(BSP_LED_ID_RUN, BSP_LED_OP_ON);
        BootLedCtrl(BSP_LED_ID_ALM, BSP_LED_OP_ON);
        BootLedCtrl(BSP_LED_ID_LINK0, BSP_LED_OP_ON);
        BootLedCtrl(BSP_LED_ID_LINK1, BSP_LED_OP_ON);
        BootLedCtrl(BSP_LED_ID_VSWR, BSP_LED_OP_ON);
        BootLedCtrl(BSP_LED_ID_ACT, BSP_LED_OP_ON);
    }
    else
    {
        printf("BootLedRun, input params[%d] error\n", ucMode);
    }
}

/*****************************************************************************
*  函数名称   : BootGetBoardRamSize(*)
*  功能描述   : Bsp 获取单板物理内存大小
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : 无
*  输出参数   : 无
*  返 回 值   : 内存大小单位Byte
*  其它说明   :
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A), 姜建奎@2012-02-29 16:14:27 创建
*----------------------------------------------------------------------------
*/
ULONG BootGetBoardRamSize(void)
{
    ULONG ulRet;
    ulRet = DRAM_512M;
    return ulRet;
}

/*****************************************************************************
*  函数名称   : OpenKdaModel(*)
*  功能描述   : 打开kda设备，传入BOOTAPP_LOG_PHY_ADDR和串口中断号
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : 无
*  输出参数   : 无
*  返 回 值   : 
*  其它说明   :
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A), 施佳炜@2013-03-21 13:45:00 创建
*----------------------------------------------------------------------------
*/
ULONG OpenKdaModel(void)
{
    int ret;
    BspMknod(KDA_DEVICE_NAME,"c","10","244");
    if ((g_iKdaDrvFd = open(KDA_DEVICE_NAME,O_RDWR | O_SYNC )) < 0)
    {
        zte_printf_s("open " KDA_DEVICE_NAME " failed!");
        return BSP_ERROR;
    }
    ret = BspPhyAddrToKernel((unsigned long long)BOOTAPP_LOG_PHY_ADDR, COM_INTERRUPT_NUM, g_iKdaDrvFd);
    if(ret != BSP_OK)
    {
        zte_printf_s("BspPhyAddrToKernel failed!\n");
        return BSP_ERROR;
    }
    return BSP_OK;
}
/*****************************************************************************
*  函数名称   : BootMapDogMem(*)
*  功能描述   : 地址空间映射
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : 无
*  输出参数   : 无
*  返 回 值   : BSP_OK表示成功; BSP_ERROR表示失败;
*  其它说明   :
*----------------------------------------------------------------------------
*  历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A), 王勇@2014-6-19 ,78e
*----------------------------------------------------------------------------
*/
/*lint -e64*/
ULONG  BootMapDogMem()
{
    int     file;
    ULONG   iSpaceProt = PROT_READ | PROT_WRITE;
    VOID *  virAddr;
    VOID *  phyAddr;
    phyAddr = DogAddr.phyAddr;
    virAddr = DogAddr.virAddr;

    if ((file = open("/dev/mem", O_RDWR | O_SYNC)) < 0)
    {
        dbgErr("open /dev/mem failed\n");
        return BSP_ERROR;
    }
    virAddr = mmap(virAddr, (WATCHDOG_REGS_SIZE + TWD_OFFSET), iSpaceProt,MAP_SHARED,file, phyAddr);

    if(0xffffffff == virAddr)
    {
        dbgInfo("dog vir addr error\n");
        return BSP_ERROR;
    }

    if (DogAddr.virAddr != virAddr)
    {
        dbgInfo("mmap  virAddr = %x \n", virAddr);
    }

    DogAddr.virAddr = virAddr + TWD_OFFSET + DOG_OFFSET;
    dbgInfo("%s %d 0x%x 0x%x\n", __FUNCTION__, __LINE__, WATCHDOG_BASE_ADDR, DogAddr.virAddr);

    return BSP_OK;
/*lint +e64*/
}
/*****************************************************************************
*  函数名称   : BootDevMemMap(*)
*  功能描述   : 使用mmap将物理地址映射到用户进程虚拟地址空间
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : 无
*  输出参数   : 无
*  返 回 值   : BSP_OK, 其它值为失败
*  其它说明   :
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A), zhaoyun@2014-5-27 14:07:25 创建
*----------------------------------------------------------------------------
*/
ULONG BootDevMemMap(VOID)
{
    /* 打开内存设备的文件描述符 */
    int     iFd;
    int     iSpaceProt = PROT_READ | PROT_WRITE;
    ULONG   iCount = 0;
    ULONG   ulPhyAdrr,ulPhySize,ulPhyGetFlag;
    ULONG   ulReg;
    UCHAR   chBuf[10]="test";
#define TO_MAP_LIST(a)      #a, &a
    /*lint -e529*/
    /*lint -e64*/
    struct map_list_t {
        UCHAR   *pucVarName;
        LONG    *pulVarAddr;
        ULONG   ulMapBase;
        ULONG   ulMapSize;
    } map_list[] = {
            {TO_MAP_LIST(g_ulRamReservedAddr),  (0x00000000 + DRAM_368M - 0x00600000), 0x00600000},
            {TO_MAP_LIST(g_ulRtcRegisterAddr),  (M_CRS_BASE), 0x00200000},
    };
    /*lint +e529*/
    /*lint +e64*/
    #define DO_ADDR_MAP(a)                                          \
        *((a)->pulVarAddr) = (long)mmap(0, (a)->ulMapSize,          \
            iSpaceProt, MAP_SHARED, iFd, (a)->ulMapBase);           \
        if (*((a)->pulVarAddr) == -1)                               \
        {                                                           \
            dbgErr("mmap %s failed %s, %d\n",                       \
                (a)->pucVarName, strerror(errno), errno);           \
            close(iFd);                                             \
            return BSP_ERROR;                                       \
        }                                                           \
        dbgInfo("%-20s = %#x\n", (a)->pucVarName, *((a)->pulVarAddr));


    /* 打开存储空间映射 */
    if ((iFd = open("/dev/mem", O_RDWR | O_SYNC)) < 0)
    {
        dbgErr("open /dev/mem failed\n");
        return BSP_ERROR;
    }

    for (iCount = 0; iCount < sizeof(map_list)/sizeof(map_list[0]); iCount++)
    {
        DO_ADDR_MAP(&map_list[iCount]);
        usleep(1000);
    }
/*lint -e529*/
/*lint -e40*/
/*lint -e409*/
/*lint -e42*/
    struct map_list_t1 {
        UCHAR   *pucVarName;
        LONG    *pulVarAddr;
        ULONG   ulMapBase;
        ULONG   ulMapSize;
    } map_list1[MAX_MEM_BLK];
/*lint +e529*/
/*lint +e40*/
/*lint +e409*/
/*lint +e42*/
/*lint -e641*/
    for (iCount = 0; iCount < MAX_MEM_BLK; iCount++)
/*lint +e641*/
    {

        ulPhyGetFlag = HAL_addrmapGetMemblkPhyInfo(iCount,&ulPhyAdrr,&ulPhySize);
        if(HAL_OK != ulPhyGetFlag)
        {
            continue;
        }
        sprintf(chBuf,"%d",iCount);

        /* printf("[%s] map blk%d [phy addr=%x size=%x]\n",__FUNCTION__,iCount,ulPhyAdrr,ulPhySize); */
        /*lint -e40*/
        /*lint -e409*/
        /*lint -e10*/
        /*lint -e63*/
        map_list1[iCount].pulVarAddr=&ulReg;
        map_list1[iCount].ulMapBase=ulPhyAdrr;
        map_list1[iCount].ulMapSize=ulPhySize;
        map_list1[iCount].pucVarName=chBuf;
        DO_ADDR_MAP(&map_list1[iCount]);
    /*lint +e40*/
    /*lint +e409*/
    /*lint +e10*/
    /*lint +e63*/
        HAL_addrmapSetMemblkVirAddr(iCount,ulReg);
        /* printf("[%s] map blk%d [phy addr=%x],viraddr=%x\n",__FUNCTION__,iCount,ulPhyAdrr,ulReg); */
        usleep(1000);
    }

    close(iFd);
    return BSP_OK;
}

ULONG BootSetSlaveChipNum(VOID)
{
    HAL_SetSlaveChipNum(1);
    return BSP_OK;

}
/*****************************************************************************
*  函数名称   : BootInitBoardGpioPort(*)
*  功能描述   : 初始化单板的GPIO端口属性
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : 无
*  输出参数   : 无
*  返 回 值   : BSP_OK, 其它值为失败
*  其它说明   : 由于不同的单板使用的GPIO端口属性可能不一样，所以这个放到单板中
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A), 宋志强@2014-06-13 14:07:25 创建
*----------------------------------------------------------------------------
*/
ULONG BootInitBoardGpioPort(void)
{
    ULONG ulRetVal = BSP_OK;
    _BspZteGpioSetMode(ZTE_DPDIC_GPIO_LED0,       GPIO_MODE_OUTPUT);
    _BspZteGpioSetMode(ZTE_DPDIC_GPIO_LED1,       GPIO_MODE_OUTPUT);
    _BspZteGpioSetMode(ZTE_DPDIC_GPIO_LED_RUN,    GPIO_MODE_OUTPUT);
    _BspZteGpioSetMode(ZTE_DPDIC_GPIO_LED_ALARM,  GPIO_MODE_OUTPUT);
    _BspZteGpioSetMode(ZTE_DPDIC_GPIO_LED_OPT0,   GPIO_MODE_OUTPUT);
    _BspZteGpioSetMode(ZTE_DPDIC_GPIO_LED_OPT1,   GPIO_MODE_OUTPUT);
    _BspZteGpioSetMode(ZTE_DPDIC_GPIO_LED_VSWR,   GPIO_MODE_OUTPUT);
    _BspZteGpioSetMode(ZTE_DPDIC_GPIO_LED_ACT,    GPIO_MODE_OUTPUT);
    _BspZteGpioSetMode(ZTE_DPDIC_GPIO_FPGA_RESET, GPIO_MODE_OUTPUT);
    _BspZteGpioSetMode(ZTE_DPDIC_GPIO_245_CTRL,   GPIO_MODE_OUTPUT);
    _BspZteGpioSetMode(ZTE_DPDIC_GPIO_FPGA_NCFG,  GPIO_MODE_OUTPUT);
    //_BspZteGpioSetMode(ZTE_DPDIC_GPIO_INT_IN0,    GPIO_MODE_OUTPUT);
    //_BspZteGpioSetMode(ZTE_DPDIC_GPIO_INT_OUT0,   GPIO_MODE_OUTPUT);
    _BspZteGpioSet(ZTE_DPDIC_GPIO_245_CTRL,GPIO_LEVEL_HIGH);
    _BspZteGpioSet(ZTE_DPDIC_GPIO_FPGA_RESET,GPIO_LEVEL_HIGH);
    /* nstatus，cfgdone 的采集模式需要与硬件确认 by 宋志强 */
    _BspZteGpioSetMode(ZTE_DPDIC_GPIO_FPGA_NSTATUS,  GPIO_MODE_INPUT | GPIO_CMODE_LEVEL_HIGH);
    _BspZteGpioSetMode(ZTE_DPDIC_GPIO_FPGA_CFG_DONE, GPIO_MODE_INPUT | GPIO_CMODE_LEVEL_HIGH);

    return ulRetVal;
}

ULONG BootBoardHwPreInit(VOID)
{
    ULONG ulRet = BSP_OK;
    ulRet |= _BspZteGpioInit();
    ulRet |= BootInitBoardGpioPort();

    return ulRet;
}
/*****************************************************************************
*  函数名称   : BootFlashInit(*)
*  功能描述   : flash初始化
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : 无
*  输出参数   : 无
*  返 回 值   : BSP_OK或者错误码
*  其它说明   : 无
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A), zhaoyun@2014-5-27 14:07:25 创建
*----------------------------------------------------------------------------
*/
#if 0
ULONG BootFlashInit(VOID)
{
    ULONG retCode = BSP_OK;
    /*lint -e785*/
    T_FlashInfo tFlashCfg = {
        FLASH_SIZE,
        FLASH_SECTOR_SIZE,   /* sector size 256K */
        FLASH_PARTITION_NUM,      /* FLASH包含的分区数量 */
        {
            {"/dev/mtd0", FLASH_BOOT_OFFSET, FLASH_BOOT_SIZE},
            {"/dev/mtd1", FLASH_RESVERD_OFFSET, FLASH_RESVERD_SIZE},
            {"/dev/mtd2", FLASH_JFFS2_OFFSET, FLASH_JFFS2_SIZE},
        }
    };

    /*lint +e785*/
    retCode = BspFlashModuleInit(&tFlashCfg);
    #ifdef  BSP_DEBUG_VERSION
    BspFlashShowCfg();
    #endif
    return retCode;

}
#endif
/*****************************************************************************
*  函数名称   : BootBoardPreInit(*)
*  功能描述   : Bsp单板初始化函数
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : 无
*  输出参数   : 无
*  返 回 值   : BSP_OK, 其它值为失败
*  其它说明   : 该接口为加载fpga前所需的BSP初始化函数。 版本公共接口函数
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A), zhaoyun@20140527 13:40:08 创建
*  comments:  feble_cheng@20140728 这个接口内不允许访问IC加速器的任何寄存器
*                                  因为此时fpga尚未加载，localbus时序异常会造成主片挂死
*----------------------------------------------------------------------------
*/
ULONG BootBoardPreInit(VOID)
{
    ULONG ulRet = 0;
    TBoardInitCall *tmp;
    struct list_head *pos;
    dbgInfo("BootBoardPreInit....... \n");

    /* 这个接口内不允许访问IC加速器的任何寄存器  */
    ulRet |= BootSetSlaveChipNum();
    ulRet |= BootDevMemMap();
    ulRet |= BootMapDogMem();
    ulRet |= BootBoardHwPreInit(); /* 包含gpio初始化 */
    ulRet |= BootFlashInit();
    ulRet |= OpenKdaModel();

    /*Carry out the init call*/
    list_for_each(pos,&BoardPreCall_list)
    {
        tmp = list_entry(pos,TBoardInitCall,list);
        //printf("function name= %s.",tmp->cCallName);

        tmp->ulRet = (*tmp).pInitCall();
        //printf("ulRet =%ld .\n",tmp->ulRet);
    }
/*lint -e{413,155}*/
    /*Collect the initcall error*/
    list_for_each(pos,&BoardPreCall_list)
    {
        tmp = list_entry(pos,TBoardInitCall,list);
        if (tmp->ulRet != 0)
        {
            //printf("ulRet =%ld .\n",tmp->ulRet);
            sBoardInitError |= tmp->ulFailMacro;
            ulRet |= tmp->ulFailMacro;
        }
    }

    return ulRet;
}

/**********************************************************************
* 函数名称:VOID BspBootAppWatchDogInit()
* 功能描述:bootapp初始化看门狗
* 输入参数:无
* 输出参数:
* 返 回 值:BSP_OK:成功;BSP_ERROR:失败
* 其它说明:网线连通bootapp main入口到下次内核启动完成计时约20s。bsp接口单位s，
        设置看门狗时间100s，100s到达前MGR接管，否则看门狗复位
* 修改日期        版本号     修改人          修改内容
* -----------------------------------------------
* 2015-10-22       V1.0       00086970             创建
***********************************************************************/
ULONG BootWatchDogInit(VOID)
{
    ULONG ulRet = BSP_ERROR;
    ULONG ulVal = 0;
    T_DPDIC_DOG *ptdog = (T_DPDIC_DOG *)DogAddr.virAddr;
    INPUT_POINTER_CHECK(ptdog);

    ulRet = BootWatchDogDisable();
    ulVal = *(volatile ULONG *)(&(ptdog->WDOG_CONTROL));
    ulVal = cpu_to_le32(ulVal);
    ulVal |= 0x00003100;
    ulVal = cpu_to_le32(ulVal);
    *(volatile ULONG *)(&(ptdog->WDOG_CONTROL)) = ulVal;
    ulRet |= BootWatchDogEnable();
    ulRet |= BootSetWatchDogTime(240);/*bootapp到内核启动完成大约35s。留有余量设置为35*2s*/
    return ulRet;
}




/**********************************************************************
* 函数名称:BootGmac0MiiRead
* 功能描述:通过GMII寄存器读PHY  .  针对以太网口GMAC0
* 输入参数: *     - udCsrClockRange：CSR 时钟区域
*     - udGR： GMII寄存器
*     - udPA： PHY设备物理层地址
*     - pudData：需要读出的数据的地址
* 输出参数:
* 返 回 值:
* 其它说明:
* 修改日期        版本号     修改人          修改内容
* -----------------------------------------------
* 2014-5-28       V1.0       yam             创建
*  $0000000(N/A), zhaoyun@20141216 19:33:10 trm78E
***********************************************************************/
ULONG BootDebugMiiRead(ULONG ulCsrClockRange, ULONG ulGR, ULONG ulPA, ULONG *pulData)
{
    int timeout = CONFIG_MDIO_TIMEOUT;
    ULONG ulReadData = 0;
    ULONG ulWriteData = 0;
    if(NULL == pulData)
    {
        return BSP_E_POINTER_NULL;
    }

    while(timeout)
    {
        HAL_addrmapGetDataFromVirAddr(0,MEM_BLK_GMAC0,GMII_ADDR_REG,&ulReadData);
        if (0 == (ulReadData&0x01))
            break;

        timeout--;
    }

    if (timeout <= 0)
    {
        return BSP_E_REG_ACCESS_TIMEOUT;
    }

    /**yam inform   GMII_ADDR_REG
    bit[15:11]  PA: Physical Layer Address
            This field tells which of the 32 possible PHY devices are being accessed.
    bit[10:6]  GR: GMII Register
            These bits select the desired GMII register in the selected PHY device.
    bit[5:2]  CR: CSR Clock Range
    bit[1]  GW: GMII Write
            When set, this bit tells the PHY/RevMII that this is a Write operation using the GMII
            Data register. If this bit is not set, this is a Read operation, placing the data in the
            GMII Data register.
    bit[0] GB: GMII Busy
            This bit should read a logic 0 before writing to Register 4 and Register 5. During a
            PHY/RevMII register access, the Software sets this bit to 1’b1 to indicate that a Read
            or Write access is in progress.
            The Register 5 is invalid until this bit is cleared by the GMAC. Therefore, Register 5
            (GMII Data) should be kept valid until the GMAC clears this bit during a PHY Write
            operation. Similarly for read operation, Register 5 contents are not valid until this bit
            is cleared.
            The subsequent read/write operation should happen only after the previous
            operation is complete.
    */
    ulWriteData = (1 << 0) | (0 << 1) |
                                    ((ulCsrClockRange & 0xF) << 2) |
                                    ((ulGR & 0x1F) << 6) |
                                    ((ulPA & 0x1F) << 11);
    HAL_addrmapSetDataToVirAddr(0,MEM_BLK_GMAC0,GMII_ADDR_REG,ulWriteData);

    timeout = CONFIG_MDIO_TIMEOUT;
    while(timeout)
    {
        HAL_addrmapGetDataFromVirAddr(0,MEM_BLK_GMAC0,GMII_ADDR_REG,&ulReadData);
        if (0 == (ulReadData&0x01))
        break;

        timeout--;
    }

    if (timeout <= 0)
    {
        return BSP_E_REG_ACCESS_TIMEOUT;
    }

    HAL_addrmapGetDataFromVirAddr(0,MEM_BLK_GMAC0,GMII_DATA_REG,&ulReadData);
    *pulData = ulReadData;

    return BSP_OK;
}
/**********************************************************************
* 函数名称:BootGetPHYLinkStatus
* 功能描述:获取PHY芯片物理链路连通状态
* 输入参数:无
* 输出参数:
* 返 回 值:0-网口联通 1-网口未联通
* 其它说明:
* 修改日期        版本号     修改人          修改内容
* -----------------------------------------------
* 2013-4-15       V1.0       yam             创建
*  $0000000(N/A), zhaoyun@20141216 19:33:10 trm78E
***********************************************************************/
ULONG BootGetPhyLinkStatus(VOID)
{
    ULONG  ulValue = 0;
    ULONG ulRet = 0;
    #define MII_CLK_150_250MHZ  0x4 /*0b0100*/
    #define MII_STATUS_REG     0x1 /*MII PHY芯片寄存器地址0x1 为status寄存器*/
    #define MII_STATUS_REG_LINK_MASK (ULONG)1<<2 /*PHY芯片的status寄存器bit2 表示link status, 1-up, 0-down*/

    ulRet= BootDebugMiiRead(MII_CLK_150_250MHZ, MII_STATUS_REG, 1, &ulValue);
    if (BSP_OK != ulRet)
    {
        dbgErr("Gmac0MiiRead Error!\n");
        return BSP_ERROR;
    }
    dbgInfo("PHY Status Reg[0x%x]\n", ulValue);
    if (0 == (ulValue & MII_STATUS_REG_LINK_MASK))
    {
        dbgInfo("Debug net port is OFF \n");
        return 1;
    }
    else
    {
        dbgInfo("Debug net port is ON\n");
        return 0;
    }
}

/**********************************************************************
* 函数名称:BootGmac0MiiWrite
* 功能描述:通过GMII寄存器写PHY  .  针对以太网口GMAC0
* 输入参数: *     - udCsrClockRange：CSR 时钟区域
*     - udGR： GMII寄存器
*     - udPA： PHY设备物理层地址
*     - pudData：需要读出的数据的地址
* 输出参数:
* 返 回 值:
* 其它说明:
* 修改日期        版本号     修改人          修改内容
* -----------------------------------------------
* 2014-5-28       V1.0       yam             创建
*  $0000000(N/A),00086970 19:33:10 trm78E
***********************************************************************/
ULONG BootDebugMiiWrite(ULONG ulCsrClockRange, ULONG ulGR, ULONG ulPA, ULONG ulData)
{
    int timeout = CONFIG_MDIO_TIMEOUT;
    ULONG ulReadData = 0;
    ULONG ulWriteData = 0;

    while(timeout)
    {
        HAL_addrmapGetDataFromVirAddr(0,MEM_BLK_GMAC0,GMII_ADDR_REG,&ulReadData);
        if (0 == (ulReadData&0x01))
            break;

        timeout--;
    }

    if (timeout <= 0)
    {
        return BSP_E_REG_ACCESS_TIMEOUT;
    }

    /**yam inform   GMII_ADDR_REG
    bit[15:11]  PA: Physical Layer Address
            This field tells which of the 32 possible PHY devices are being accessed.
    bit[10:6]  GR: GMII Register
            These bits select the desired GMII register in the selected PHY device.
    bit[5:2]  CR: CSR Clock Range
    bit[1]  GW: GMII Write
            When set, this bit tells the PHY/RevMII that this is a Write operation using the GMII
            Data register. If this bit is not set, this is a Read operation, placing the data in the
            GMII Data register.
    bit[0] GB: GMII Busy
            This bit should read a logic 0 before writing to Register 4 and Register 5. During a
            PHY/RevMII register access, the Software sets this bit to 1’b1 to indicate that a Read
            or Write access is in progress.
            The Register 5 is invalid until this bit is cleared by the GMAC. Therefore, Register 5
            (GMII Data) should be kept valid until the GMAC clears this bit during a PHY Write
            operation. Similarly for read operation, Register 5 contents are not valid until this bit
            is cleared.
            The subsequent read/write operation should happen only after the previous
            operation is complete.
    */
    HAL_addrmapSetDataToVirAddr(0,MEM_BLK_GMAC0,GMII_DATA_REG,ulData);
    ulWriteData = (1 << 0) | (1 << 1) |
                                    ((ulCsrClockRange & 0xF) << 2) |
                                    ((ulGR & 0x1F) << 6) |
                                    ((ulPA & 0x1F) << 11);
    HAL_addrmapSetDataToVirAddr(0,MEM_BLK_GMAC0,GMII_ADDR_REG,ulWriteData);

    timeout = CONFIG_MDIO_TIMEOUT;
    while(timeout)
    {
        HAL_addrmapGetDataFromVirAddr(0,MEM_BLK_GMAC0,GMII_ADDR_REG,&ulReadData);
        if (0 == (ulReadData&0x01))
            break;

        timeout--;
    }

    if (timeout <= 0)
    {
        return BSP_E_REG_ACCESS_TIMEOUT;
    }

    BootDebugMiiRead(ulCsrClockRange,ulGR,ulPA,&ulReadData);
    printf("Addr:0x%x,Reg:0x%x,WriteData:0x%x,ReadData:0x%x\n",ulPA,ulGR,ulData,ulReadData);
    return BSP_OK;
}


/**************************************************************************
* 函数名称： memflag_set
* 功能描述： 设置boot启动标志
* 输入参数： 无
* 输出参数： 无
* 返 回 值： BSP_OK/BSP_ERROR
* 其它说明：
* 适用范围： BSP、OSS
* -----------------------------------------------------------------------
* 修改日期      版本号     修改人        修改内容
* 2015年10月22日 v1.0      00086970          创建
**************************************************************************/
ULONG memflag_set(ULONG ulwriteval)
{

    WrReg(0,MEM_BLK_CRS,HAL_REG_RST_REC_DEBUG_REGX,ulwriteval);

    printf("memflag_set=0x%x\n",ulwriteval);

    return 0;
}
/**************************************************************************
* 函数名称： boot_flag_set
* 功能描述：设置boot启动标志
* 输入参数： 无
* 输出参数： 无
* 返 回 值： BSP_OK/BSP_ERROR
* 其它说明：
* 适用范围： BSP、OSS
* -----------------------------------------------------------------------
* 修改日期      版本号     修改人        修改内容
* 2015年10月22日 v1.0      00086970          创建
**************************************************************************/
VOID boot_flag_set()
{
    ULONG check_flag=0;

    HAL_addrmapGetDataFromVirAddr(0,MEM_BLK_CRS,HAL_REG_RST_REC_DEBUG_REGX,&check_flag);
    check_flag = check_flag & 0x0FF;

    if(check_flag==MASTER_BOOT_OK)  /*本次是上电或者复位后第一次启动,启动主boot成功*/
    {
        memflag_set(MASTER_KUBOOT_OK);
        /*尚欠写高端内存表征主boot启动成功标志*/
    }
    else if(check_flag==MASTER_KUBOOT_OK) /*启动主boot成功，继续尝试引导CPU版本*/
    {
        memflag_set(MASTER_KUBOOT_OK);
        /*尚欠写高端内存表征主boot启动成功标志*/
    }
    else if(check_flag==SLAVE_BOOT_OK)  /*启动从boot成功，*/
    {
        memflag_set(SLAVE_KUBOOT_OK);
        /*尚欠写高端内存表征从boot启动成功标志*/
    }
    else if(check_flag==SLAVE_KUBOOT_OK)   /*启动从boot成功，继续尝试引导CPU版本*/
    {
        memflag_set(SLAVE_KUBOOT_OK);
        /*尚欠写高端内存表征从boot启动成功标志*/
    }
    return;
}
/**************************************************************************
* 函数名称： SetEthProMode
* 功能描述： 设置ETH的模式寄存器的混杂模式控制位
* 输入参数： 0--对进入的帧的目的地址进行检查。1--对进入的帧的目的地址不进行检查。
* 输出参数： 无
* 返 回 值：
* -------------------------------------------------------
* 其它说明：
* 修改日期     版本号        修改人	            修改内容
* 2015/10/22     V1.0         00086970           创建
**************************************************************************/
ULONG SetEthProMode(UCHAR ucValue)
{
    ULONG  ulRet=BSP_OK;
    ULONG  ulValue=0;

    printf("SetEthProMode: set eth mode bit. \n");
    HAL_addrmapGetDataFromVirAddr(0,MEM_BLK_GMAC0,MAC_FRAME_FILTER,&ulValue);

    if (ucValue == 0) /*对进入的帧的目的地址进行检查,非混杂模式*/
    {
        ulValue = ulValue & 0x7FFFFFFE;
    }
    else/*对进入的帧的目的地址不进行检查, 混杂模式Receive All Frame*/
    {
        ulValue = ulValue | 0x80000001;
    }

    WrReg(0,MEM_BLK_GMAC0,MAC_FRAME_FILTER,ulValue);

    return ulRet;
}
/**********************************************************************
* 函数名称： BootGetDownloadFlag
* 功能描述： MIO14指示起保护区版本or下载版本。
* 输入参数： 无
* 输出参数： 无
* 返 回 值： 0:起保护区版本 1:下载版本
* 其它说明： zx211410写死起保护区版本
* 修改日期        版本号     修改人	      修改内容
* -----------------------------------------------
* 2012/07		   V1.0	     ZKH
***********************************************************************/
ULONG BootGetDownloadFlag(void)
{
    return 0;
}

ULONG BootGetFsRecoverFlag(VOID)
{
    ULONG ulUbifsFormat_mask = 0;
    ulUbifsFormat_mask = *(ULONG *)FS_FORMAT_FLAG;
    if(ulUbifsFormat_mask == 0xdeadbeaf)
    {
        memset((CHAR*)FS_FORMAT_FLAG, 0, 4);/* 清空 */
    }
    return ulUbifsFormat_mask;
}

ULONG getLastKmsgAddr(VOID)
{
    return LAST_KMSG_ADDR;
}

ULONG getAppLogPhyAddr(VOID)
{
    return APP_LOG_PHY_ADDR;
}

UINT32 BootGetBoardHwResetType(VOID)
{
    UINT32 ret = 0;
    ret = readl(g_ulRtcRegisterAddr + HARD_RESET_OFFSET);
    return ret;
}

UINT32 BootGetBoardSwResetType(VOID)
{
    UINT32 ret = 0;
    ret = readl(g_ulRtcRegisterAddr + SOFT_RESET_OFFSET);
    return ret;
}

UCHAR* BootGetBoardResetInfoAddr(VOID)
{
    return (g_ulRamReservedAddr + RESET_INFO_ADDR);
}

VOID SaveKebootBakLog(VOID)
{
    BspSaveBootKmsgLog(BAK_LOG);
    BspSaveBootAppLog(BAK_LOG);
}

VOID SaveKebootCurLog(VOID)
{
    BspSaveBootKmsgLog(CUR_LOG);
    BspSaveBootAppLog(CUR_LOG);
}

/*bs住后的手动转储请用SaveKebootLog,产生4份,使每份log序号保持一致*/
VOID SaveKebootLog(VOID)
{
    SaveKebootBakLog();
    SaveKebootCurLog();
}

ULONG BootFlagGet()
{
    ULONG flag = 0;
    ULONG buf = 0;

    if(BspFlashRead(DOUBLE_BOOT_CONTROL_Addr, &buf, 1))
    {
        return BSP_ERROR;
    }
    flag = readl(g_ulRtcRegisterAddr + BOOT_FLAG) & 0xff;
    buf = uswap_32(buf);

    return (buf << 16) | flag;
}

VOID ChangeCmdline()
{
    UCHAR *str = NULL;
    int i = 0;
    str = strstr(g_ucCmdLine, "keboot=1");
    if (NULL == str)
    {
        return;
    }
    for (;i < strlen("keboot=1");i++)
    {
        g_ucCmdLine[str - g_ucCmdLine + i] = ' ';
    }
    return;
}
/*****************************************************************************
*  函数名称   : main(*)
*  功能描述   : bootapp程序处理主函数
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : argc   - 参数个数
                argv[] - 参数列表
*  输出参数   : 无
*  返 回 值   : 0为成功, 其余失败
*  其它说明   :
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A), 00086970 @2015-10-28
*----------------------------------------------------------------------------
*/
int main(int argc, char *argv[])
{
    int iBootAppTaskID = 0;
    ULONG ulRet = 0;

    ulRet = BootBoardPreInit();
    BootLedRun(0);
    ulRet = GetCmdline();
    if(BSP_ERROR == ulRet)
    {
        SetDefaultCmdline();
    }
    else
    {
        ChangeCmdline();
    }
    ulRet |= BootWatchDogInit();
    ulRet |= (ULONG)ushell_init();
    ulRet |= BootSoftModInit();

    taskSpawn("tLedTask",   \
        100, /* priority */            \
        0,   /* option   */           \
        0x100,/* stack size */      \
        (FUNCPTR)BootLedTask, 0, 0, 0, 0, 0, 0, 0, 0 ,0,0);

    BootLedRun(0);
    iBootAppTaskID = taskSpawn("tBootTask",   \
        100, /* priority */            \
        0,   /* option   */           \
        0x1000,/* stack size */      \
        (FUNCPTR)MainLoop, 0, 0, 0, 0, 0, 0, 0, 0 ,0,0);

    while(1)
    {
    //BspFunction("/boot.out", CFG_PROMPT);
    sleep(20);
    }
    return ulRet;

}


#endif

ULONG SetDefaultCmdline(VOID)
{
    /* Started by AICoder, pid:qd84d21053w120f14425087b909a3504fd4406de */
    strcpy((char *)g_ucCmdLine, "root=/dev/ram0 rw mem=354M console=ttyAMA0 flash_partition_flag=1");
    /* Ended by AICoder, pid:qd84d21053w120f14425087b909a3504fd4406de */
    return BSP_OK;

}



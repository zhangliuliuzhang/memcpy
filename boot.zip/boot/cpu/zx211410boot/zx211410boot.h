/**************************************************************************
 * 版权所有 (C)2001, 深圳市中兴通讯股份有限公司
 *
 * 文件名称: zx211410boot.h
 * 文件标识:
 * 内容摘要:
 * 其它说明:
 * 当前版本: ZXSDR BBUV120B01
 * 作    者: 
 * 完成日期:
 *
 * 修改记录1:
 *    修改日期: 2012年06月21日
 *    版 本 号: ZXSDR BBUV120B01
 *    修 改 人: 耿佳佳
 *    修改内容: 创建
 * 修改记录2:
 **************************************************************************/

#ifndef _ZX211410BOOT_H_
#define _ZX211410BOOT_H_

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

#define BSP_RAMDISK_LOAD_ADDR (0x05800000)
#define CFG_PROMPT	"DPDIC->"

#define readb(addr) \
  ({ unsigned char __v = (*(volatile unsigned char *) (addr)); __v; })
#define readw(addr) \
  ({ unsigned short __v = (*(volatile unsigned short *) (addr)); __v; })
#define readl(addr) \
  ({ unsigned long __v = (*(volatile unsigned long *) (addr)); __v; })
    
#define writeb(b, addr) \
      (void)((*(volatile unsigned char *) (addr)) = (b))
#define writew(b, addr) \
      (void)((*(volatile unsigned short *) (addr)) = (b))
#define writel(b, addr) \
      (void)((*(volatile unsigned int *) (addr)) = (b))

#define CRC_BIG_LITTLE_SWAP_LONG(x) \
	((unsigned int)( \
		(((unsigned int)(x) & (unsigned int)0x000000ffUL) << 24) | \
		(((unsigned int)(x) & (unsigned int)0x0000ff00UL) <<  8) | \
		(((unsigned int)(x) & (unsigned int)0x00ff0000UL) >>  8) | \
		(((unsigned int)(x) & (unsigned int)0xff000000UL) >> 24) ))

#define CRC_BIG_LITTLE_SWAP_USHORT(x) \
	((unsigned short)( \
		(((unsigned short)(x) & (unsigned short)0x00ff) << 8) | \
		(((unsigned short)(x) & (unsigned short)0xff00) >> 8) ))

#if defined(COMPILE_FOR_KEXEC_BOOT)

struct list_head
{
	struct list_head *next;
	struct list_head *prev;
};
static inline void __list_add(struct list_head *new,
                              struct list_head *prev,
                              struct list_head *next)
{
        next->prev = new;
        new->next = next;
        new->prev = prev;
        prev->next = new;
}
static inline void list_add(struct list_head *new, struct list_head *head)     //加入一个新节点
{
    __list_add(new, head, head->next);
}
static inline void list_add_tail(struct list_head *new, struct list_head *head)
{
	__list_add(new, head->prev, head);
}
#define LIST_HEAD_INIT(name)      { &(name), &(name) }
#define LIST_HEAD(name)      struct list_head name = LIST_HEAD_INIT(name)


/*初始化调用宏，a为调用函数名(无入参)，b 为失败的时候计入全局告警的宏*/
#define PreInitCallAdd(a,b) 											\
	do{																	\
		TBoardInitCall *p##a;p##a = NULL;								\
		p##a= malloc(sizeof(TBoardInitCall));							\
		if (p##a == NULL)												\
		{																\
			printf("%s malloc fail.\n",#a);								\
		}																\
		strcpy(p##a->cCallName,#a);										\
		p##a->pInitCall = &a;											\
		list_add_tail(&(*p##a).list,&BoardPreCall_list);				\
		p##a->ulFailMacro = b;											\
		p##a->ulCnt = sBoardPreInitCallCnt;sBoardPreInitCallCnt++;		\
	}while(0)							

#define list_for_each(pos, head) for (pos = (head)->next;pos != (head);pos = pos->next)
#define list_entry(ptr, type, member)    container_of(ptr, type, member)
#define container_of(ptr, type, member)   ({ const typeof( ((type *)0)->member ) *__mptr =  (ptr); (type *)( (char *)__mptr - offsetof(type,member) );})
#ifndef offsetof
#define offsetof(type,  member)    ((size_t) &((type *)0)-> member)


#endif



typedef struct list_head Tlist;

typedef struct tagBoardInitCall
{
	ULONG (*pInitCall)();    /*调用的函数*/
	ULONG ulRet;			 /*调用函数的返回值*/
	//ULONG ulMask;			 /*返回值的掩码*/
	char cCallName[32];      /*调用名，一般情况下就是函数名*/
	//char cDiscription[256];/*描述，暂时定义为对应返回值各个bit的说明*/
	ULONG ulFailMacro;       /*如果函数执行不成功，对应的失败宏值*/
	ULONG ulCnt;			 /*在初始化链表中的排序从0开始*/
	struct list_head list;   /*链表*/

}TBoardInitCall;
#define BOARD_INIT_FAIL_DEVMMAP       1<<1   /* 物理地址空间映射 */
#define BOARD_INIT_FAIL_NOT_RECORD    0      /* 不记录这个告警到总告警 */
#define BOARD_INIT_FAIL_FLASH         1<<17  /* Flash初始化*/

#define ZTE_DPDIC_GPIO_LED0           4   /* LED 低电平点亮 LED */
#define ZTE_DPDIC_GPIO_LED1           5   /* LED 低电平点亮 LED */
#define ZTE_DPDIC_GPIO_RS485_RXEN     8   /* 半双工监控485设备的接收使能*/
#define ZTE_DPDIC_GPIO_245_CTRL       13
#define ZTE_DPDIC_GPIO_LED_RUN        14
#define ZTE_DPDIC_GPIO_LED_ALARM      15
#define ZTE_DPDIC_GPIO_LED_OPT0       16
#define ZTE_DPDIC_GPIO_LED_OPT1       17   
#define ZTE_DPDIC_GPIO_FPGA_RESET     18
#define ZTE_DPDIC_GPIO_LED_VSWR       19
#define ZTE_DPDIC_GPIO_LED_ACT        20
#define ZTE_DPDIC_GPIO_RESET_SEC      21
#define ZTE_DPDIC_GPIO_FPGA_NCFG      26
#define ZTE_DPDIC_GPIO_FPGA_NSTATUS   27
#define ZTE_DPDIC_GPIO_FPGA_CFG_DONE  28
#define CFG_HZ	       			(1000)
#define CONFIG_SYS_HZ			CFG_HZ
#define CONFIG_MDIO_TIMEOUT	(3 * CONFIG_SYS_HZ)
#define GMII_ADDR_REG         (0x00000010)  /*Register 4 (GMII Address Register) offset :0x0010*/
#define GMII_DATA_REG         (0x00000014)  /*Register 5 (GMII Data Register) offset :0x0014*/
/*#define ERROR_BASE_BSP_COMMON                   ((ERROR_BASE_BSP + BSP_COMMON)<<16)*/
#define BSP_E_POINTER_NULL                      (ERROR_BASE_BSP_COMMON + 0x0001)  /* 指针参数为空    */
#define BSP_E_REG_ACCESS_TIMEOUT     (ERROR_BASE_BSP_COMMON + 0x000c)
#define APP_HR_RESERVED_SIZE   (0x10000)
#define APP_BOX_RESERVED_SIZE  (0x80000)
#define APP1_RESERVED_SIZE       APP_HR_RESERVED_SIZE
#define APP2_RESERVED_SIZE       APP_BOX_RESERVED_SIZE
#define GPIO_MODE_OUTPUT            0x00			// 输出模式
#define GPIO_MODE_INPUT             0x01			// 输入模式
#define GPIO_MODE_INT               0x02			// 中断模式
#define GPIO_LEVEL_LOW             0x00			// 低电平
#define GPIO_LEVEL_HIGH            0x01			// 高电平
// 定义了数据采集模式
/* 注意，(gpio_set_mode函数的用法决定) 这里宏定义有8bit，但是仅仅使用了高4bit  */
#define GPIO_CMODE_LEVEL_HIGH       0x00			// 高电平采集
#define GPIO_CMODE_LEVEL_LOW        0x10			// 低电平采集
#define GPIO_CMODE_EDGE_UP          0x20			// 上升沿平采集
#define GPIO_CMODE_EDGE_DOWN        0x40			// 下降沿采集
#define GPIO_CMODE_EDGE             0x80			// 全边缘采集，但不一定支持

/*******************************内存定义************************************/
#define DRAM_4M                  (0x0400000)

#define DRAM_32M                 (0x02000000)
#define DRAM_64M                 (0x04000000)
#define DRAM_128M                (0x08000000)
#define DRAM_368M                (0x17000000)
#define DRAM_512M                (0x20000000)

#define LOCAL_MEM_LOCAL_ADRS     (0x00000000) /* 低端内存留给系统分配用 */

extern  unsigned long            g_ulBoardRamSize;

#define SYS_PHYS_MEM_TOP         (0x00600000)
#define OSS_MEM_SIZE             (0x00080000)
#define BSP_MEM_SIZE             (0x00080000)
#define BSP_VER_PROTECT_SIZE     (0x00400000)
#define APP_RESERVED_SIZE        (0x100000)
#define USER_RESERVED_SIZE       (OSS_MEM_SIZE + BSP_MEM_SIZE + BSP_VER_PROTECT_SIZE + APP_RESERVED_SIZE)

#define SYS_MEM_TOP              (SYS_PHYS_MEM_TOP - USER_RESERVED_SIZE)
#define USER_RESERVED_ADDR       (SYS_MEM_TOP)
#define APP_RESERVED_ADDR        (USER_RESERVED_ADDR + BSP_VER_PROTECT_SIZE)
#define OSS_MEM_ADDR             (APP_RESERVED_ADDR + APP_RESERVED_SIZE)
#define BSP_MEM_ADDR             (OSS_MEM_ADDR + OSS_MEM_SIZE)
#define BSP_VER_PROTECT_ADDR     (SYS_MEM_TOP)

#define RESET_INFO_ADDR          (BSP_MEM_ADDR + 0x5300)

#define BK_RESV_HIGH_MEM_ADDR                 0x16200000
#define BOOTAPP_LOG_BASE_OFFSET               0x00560000  // 规划出128KB用于boot CUR/BAK两段BOOTAPP LOG日志区，各64KB
#define BOOTAPP_LOG_PHY_ADDR                  (BK_RESV_HIGH_MEM_ADDR + BOOTAPP_LOG_BASE_OFFSET)
#define APP_LOG_BASE_OFFSET                   0x00600000
#define APP_LOG_PHY_ADDR                      (BK_RESV_HIGH_MEM_ADDR + APP_LOG_BASE_OFFSET)
#define APP_LOG_SIZE                          0x100000    // CPU CUR/BAK两段 APP LOG, 各1MB

#define LAST_KMSG_BASE_OFFSET                 0x00580000
#define LAST_KMSG_ADDR                        (BK_RESV_HIGH_MEM_ADDR + LAST_KMSG_BASE_OFFSET)
#define LAST_KMSG_SIZE                        0x40000   // CPU CUR/BAK两段 LAST_KMSG, 各256KB

#define COM_INTERRUPT_NUM                     0x29            /* 串口中断号 */
/******************************flash 定义*****************************/
#define FLASH_PARTITION_NUM            (3)    /*boot、保护区、文件系统*/

#define MODULEID_ADDR             0xaa0000
#define PROTECT_ZONE_OFFSET_MTD1  0x160000

typedef unsigned long       BUS_WIDTH;

#define HARD_RESET_OFFSET     0xf0        /*硬件复位原因记录寄存器*/
#define SOFT_RESET_OFFSET     0xe4        /*软件复位原因记录寄存器*/

#define BOOT_FLAG                    0xe0 /*BOOT_FLAG寄存器*/
#define DOUBLE_BOOT_CONTROL_Addr     0xa80000
typedef  struct tDpdIcDog
{
    BUS_WIDTH    WDOG_LOAD;
    BUS_WIDTH    WDOG_COUNT;
    BUS_WIDTH    WDOG_CONTROL;
    BUS_WIDTH    WDOG_STATUS;
    BUS_WIDTH    WDOG_REST;
    BUS_WIDTH    WDOG_DISABLE;
}T_DPDIC_DOG;



#endif

ULONG getLastKmsgAddr(VOID);
ULONG getAppLogPhyAddr(VOID);
ULONG BootFlagGet(VOID);
VOID SaveKebootLog(VOID);
VOID SaveKebootBakLog(VOID);
VOID SaveKebootCurLog(VOID);
UINT32 BootGetBoardHwResetType(VOID);
UINT32 BootGetBoardSwResetType(VOID);
UCHAR* BootGetBoardResetInfoAddr(VOID);
/* Started by AICoder, pid:h1098of03b2bf3e14a7709c240ec0a0247c4fe4b */
ULONG BspMknod(const char * filepath, const char *oprator, const char *majornew, const char* minornew);
/* Ended by AICoder, pid:h1098of03b2bf3e14a7709c240ec0a0247c4fe4b */
/* Started by AICoder, pid:11780e296dr788c146360b8060da5b1f38d06d46 */
ULONG BootDebugMiiWrite(ULONG ulCsrClockRange, ULONG ulGR, ULONG ulPA, ULONG ulData);
ULONG BootDebugMiiRead(ULONG ulCsrClockRange, ULONG ulGR, ULONG ulPA, ULONG *pulData);
ULONG SetEthProMode(UCHAR ucValue);
ULONG BootWatchDogDisable(void);
ULONG BootGetPhyLinkStatus(void);
VOID BootLedRun(UCHAR ucMode);
ULONG BootGetDownloadFlag(void);
ULONG BootSetWatchDogTime(ULONG ulTimerValue);
ULONG BootWatchDogEnable(void);
VOID boot_flag_set();
/* Ended by AICoder, pid:11780e296dr788c146360b8060da5b1f38d06d46 */
#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif


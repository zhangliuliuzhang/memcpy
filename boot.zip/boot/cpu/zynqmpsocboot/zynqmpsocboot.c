/*****************************************************************************
 * 版权所有(C) 2010, ZTE Corp. RRU Bsp Platform
 *----------------------------------------------------------------------------
 * 模 块 名 : BSP
 * 文件名称 : zynqmpsocboot.c
 * 文件标识 : {[N/A]}
 * 内容摘要 : zynqmpsoc cpu bootapp接口实现
 * 注意事项 : 无
 * 作    者 : 耿佳佳
 * 创建日期 : 2015-10-22 08:28:34
 * 当前版本 : Ver1.0
 *----------------------------------------------------------------------------
 * 变更记录 :
 *
 * $记录1
 * 变 更 单: $0000000(N/A)
 * 责 任 人: 耿佳佳
 * 修改日戳: 2015-10-22 08:28:34
 * 变更说明: 创建文件
 *
 *----------------------------------------------------------------------------
 */

#include "stdio.h"
#include <sys/types.h>
#include <sys/stat.h>
#include <netinet/in.h>
#include <fcntl.h>
#include <errno.h>
#include "vxadp.h"

#include <linux/mii.h>
#include <sys/socket.h>
#include <sys/ioctl.h>
#include <net/if.h>

#include "bsppub.h"
#include "bspcomm.h"
#include "pub_typedef.h"
#include "bsperrcode.h"
#include "zynqmpsocboot.h"
#include "flash.h"
#if defined(COMPILE_FOR_KEXEC_BOOT)
#include "bootadp.h"
#define reteck(ret)                                                \
        if(ret < 0)                                                \
        {                                                          \
            zte_printf_s("error! \"%s\" : line: %d\n", __func__, __LINE__); \
            return BSP_ERROR;                                        \
        }
#endif
/**************************************************************************
 *                        宏
 **************************************************************************/

extern UCHAR g_ucCmdLine[256];

#ifdef COMPILE_FOR_KEXEC_BOOT
#define  GEM3_BASE_ADDR  (0xFF0E0000)
#define  GEM3_REGS_SIZE  (0x100)
#define  MDIO_LINK_REG  (0xc)
#define  GEM3_PHY_MANAGEMENT_REG  (0x34)
#define  GEM3_NETWORK_STATUS_REG  (0x8)
#define  ZYNQ_GEM_NWSR_MDIOIDLE_MASK    0x00000004 /* PHY management idle */
#define  ZYNQ_GEM_PHYMNTNC_OP_MASK    0x40020000 /* operation mask bits */
#define  ZYNQ_GEM_PHYMNTNC_OP_R_MASK    0x20000000 /* read operation */
#define  ZYNQ_GEM_PHYMNTNC_OP_W_MASK    0x10000000 /* write operation */
#define  ZYNQ_GEM_PHYMNTNC_PHYAD_SHIFT_MASK    23 /* Shift bits for PHYAD */
#define  ZYNQ_GEM_PHYMNTNC_PHREG_SHIFT_MASK    18 /* Shift bits for PHREG */
#define  ZYNQ_GEM_CONFIG_REG      0x00000004 /*promiscuous mode*/

#define  USERACCESS_GO      (1 << 31)
#define  USERACCESS_WRITE    (1 << 30)
#define  USERACCESS_ACK        (1 << 29)
#define  USERACCESS_READ    (0)
#define  USERACCESS_DATA    (0xffff)

#define CPSW_BASE_ADDR               (0x2100000)
#define CPSW_REGS_SIZE              (0x1000)
#define CPSW_ALE_CONTRAL              (0xd08)

#define XWDTPS_ZMR_OFFSET    0x00000000U /**< Zero Mode Register */
#define XWDTPS_CCR_OFFSET    0x00000004U /**< Counter Control Register */
#define XWDTPS_RESTART_OFFSET    0x00000008U /**< Restart Register */
#define XWDTPS_SR_OFFSET    0x0000000CU /**< Status Register */
/** @name Zero Mode Register
 * This register controls how the time out is indicated and also contains
 * the access code (0xABC) to allow writes to the register
 * @{
 */
#define XWDTPS_ZMR_WDEN_MASK    0x00000001U /**< enable the WDT */
#define XWDTPS_ZMR_RSTEN_MASK    0x00000002U /**< enable the reset output */
#define XWDTPS_ZMR_IRQEN_MASK    0x00000004U /**< enable the IRQ output */

#define XWDTPS_ZMR_RSTLN_MASK    0x00000070U /**< set length of reset pulse */
#define XWDTPS_ZMR_RSTLN_SHIFT    4U       /**< shift for reset pulse */

#define XWDTPS_ZMR_IRQLN_MASK    0x00000180U /**< set length of interrupt pulse */
#define XWDTPS_ZMR_IRQLN_SHIFT    7U       /**< shift for interrupt pulse */

#define XWDTPS_ZMR_ZKEY_MASK    0x00FFF000U /**< mask for writing access key */
#define XWDTPS_ZMR_ZKEY_VAL        0x00ABC000U /**< access key, 0xABC << 12 */

#define XWDTPS_CCR_CLKSEL_MASK    0x00000003U /**< counter clock prescale */

#define XWDTPS_CCR_CRV_MASK    0x00003FFCU /**< counter reset value */
#define XWDTPS_CCR_CRV_SHIFT    2U       /**< shift for writing value */

#define XWDTPS_CCR_CKEY_MASK    0x03FFC000U /**< mask for writing access key */
#define XWDTPS_CCR_CKEY_VAL    0x00920000U /**< access key, 0x248 << 14 */

/* Bit patterns for Clock prescale divider values */

#define XWDTPS_CCR_PSCALE_0008  0x00000000U /**< divide clock by 8 */
#define XWDTPS_CCR_PSCALE_0064  0x00000001U /**< divide clock by 64 */
#define XWDTPS_CCR_PSCALE_0512  0x00000002U /**< divide clock by 512 */
#define XWDTPS_CCR_PSCALE_4096  0x00000003U /**< divide clock by 4096 */

/* @} */

/** @name  Restart register
 * This register resets the timer preventing a timeout. Value is specific
 * 0x1999
 * @{
 */

#define XWDTPS_RESTART_KEY_VAL    0x00001999U /**< valid key */

/************************** Constant Definitions *****************************/

/*
 * Choices for output selections for the device, used in
 * XWdtPs_EnableOutput()/XWdtPs_DisableOutput() functions
 */
#define XWDTPS_RESET_SIGNAL    0x01U   /**< Reset signal request */
#define XWDTPS_IRQ_SIGNAL    0x02U   /**< IRQ signal request */

/*
 * Control value setting flags, used in
 * XWdtPs_SetControlValues()/XWdtPs_GetControlValues() functions
 */
#define XWDTPS_CLK_PRESCALE        0x01U   /**< Clock Prescale request */
#define XWDTPS_COUNTER_RESET    0x02U   /**< Counter Reset request */

#define XPAR_XWDTPS_0_WDT_CLK_FREQ_HZ 100000000
#define XFSBL_WDT_CRV_SHIFT 12U

#define PMU_GLOBAL_ERROR_SRST_EN_1   0x0000056CU
#define PMU_GLOBAL_ERROR_SRST_EN_1_LPD_SWDT_MASK   0x00001000U
#define PMU_GLOBAL_ERROR_EN_1     0x000005A0U
#define PMU_GLOBAL_ERROR_EN_1_LPD_SWDT_MASK    0x00001000U

/**************************************************************************
 *                         数据类型                                       *
 **************************************************************************/


/**************************************************************************
 *                         全局变量定义                                   *
 **************************************************************************/
ULONG  g_ulRamReservedAddr =0;
ULONG  g_ulBootRegisterAddr =0;
ULONG g_ulLedFlag = 0;

static ULONG aulGpioAddr =0;
static ULONG aulGem3VirAddr = 0;
static ULONG aulWatchdogAddr =0;
static ULONG aulgem0PcsVirAddr = 0;
/**************************************************************************
 *                         外部变量声明
 **************************************************************************/

/**************************************************************************
*                         局部函数声明
**************************************************************************/
extern VOID MainLoop ();
extern ULONG BootFlashInit(VOID);
extern ULONG BootSoftModInit(void);
/**************************************************************************
*                         全局函数声明
**************************************************************************/
ULONG SetDefaultCmdline();
/**************************************************************************
 *                         函数实现
 **************************************************************************/
/*****************************************************************************
*  函数名称   : BspGetCpuType(*)
*  功能描述   : 双boot模块用于获取cpu类型
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : 无
*  输出参数   : 无
*  返 回 值   : 成功 - BSP_OK
*  其它说明   : 
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A), yam@2014-10-09 14:07:25 创建
*----------------------------------------------------------------------------
*/
UINT32 BspGetCpuType (UCHAR *pucCpuType)    
{ 
    if (NULL == pucCpuType)
        return BSP_ERROR_NULL_POINTER;
    
    *pucCpuType = BSP_ZYNQ_MPSOC;
    return BSP_OK;
}

ULONG BootRdWdtReg(ULONG ulAddr)
{
    
    ULONG ulRegAddr = 0;

    ulRegAddr = ulAddr + aulWatchdogAddr;

    return *((volatile ULONG *)ulRegAddr);
    
}
ULONG BootWrWdtReg(ULONG ulAddr, ULONG ulData)
{
   
    ULONG ulRegAddr = 0;

    ulRegAddr = ulAddr + aulWatchdogAddr;

    *((volatile ULONG *)ulRegAddr) = ulData;

    return BSP_OK;
    
    
}
ULONG BootRdGem0PcsReg(ULONG ulAddr)
{
    
    ULONG ulRegAddr = 0;

    ulRegAddr = ulAddr + aulgem0PcsVirAddr;

    return *((volatile ULONG *)ulRegAddr);
    
}


/**********************************************************************
* 函数名称:ULONG BspBootPhyLinkMmap()
* 功能描述:debug网口基址映射
* 输入参数:无
* 输出参数:
* 返 回 值:BSP_OK:成功;BSP_ERROR:失败
* 其它说明:
* 修改日期        版本号     修改人          修改内容
* -----------------------------------------------
* 2015-10-22       V1.0       00086970             创建
***********************************************************************/ 
ULONG BootPhyLinkMmap()
{
    VOID *    ulVirAddr = 0; 
    ULONG   ulPhyAddr = 0;
    ULONG   ulSpaceProt = PROT_READ | PROT_WRITE;
    int     ifile;

    if ((ifile = open("/dev/mem", O_RDWR | O_SYNC)) < 0)
    {
        printf("open /dev/mem failed\n");
        return BSP_ERROR;
    }
    
    ulPhyAddr = GEM3_BASE_ADDR;
    
    ulVirAddr = mmap(NULL, 0x100, ulSpaceProt, MAP_SHARED, ifile, ulPhyAddr);
    if (ulVirAddr == MAP_FAILED)
    {                                                           
        printf("%s %d 0x%x 0x%p map error\n", __FUNCTION__, __LINE__, ulPhyAddr, ulVirAddr);
        close(ifile);
        return BSP_ERROR;
    }
    aulGem3VirAddr = (ULONG)ulVirAddr;
    printf("%s %d 0x%x 0x%p\n", __FUNCTION__, __LINE__, ulPhyAddr, ulVirAddr);
    close(ifile);
    return BSP_OK;
}


/*****************************************************************************
 *  函数名称   : BootWatchDogEnable(*)
 *  功能描述   : 使能软件喂狗
 *  读全局变量 : 无
 *  写全局变量 : 无
 *  输入参数   : 无
 *  输出参数   : 无
 *  返 回 值   : 成功 - BSP_OK
 *  其它说明   : 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *  $0000000(N/A), 宋飞@2011-11-25 11:15:46
 *----------------------------------------------------------------------------
 */
ULONG BootWatchDogEnable(VOID)
{
    
    ULONG ulRegister;
    /*
     * Read the contents of the ZMR register.
     */
    ulRegister = BootRdWdtReg(XWDTPS_ZMR_OFFSET);
    /*
     * Enable the Timer field in the register and Set the access key so the
     * write takes place.
     */
    ulRegister |= XWDTPS_ZMR_WDEN_MASK;
    ulRegister |= XWDTPS_ZMR_ZKEY_VAL;
    ulRegister |= XWDTPS_ZMR_RSTLN_MASK; /** yam add, to let WDT reset single hold
                                                  enough length for reseting flash*/
    /*
     * Update the ZMR with the new value.
     */
    BootWrWdtReg(XWDTPS_ZMR_OFFSET,ulRegister);
                                         
    BootWrWdtReg(XWDTPS_RESTART_OFFSET,XWDTPS_RESTART_KEY_VAL);
     
    return BSP_OK;
}

/*****************************************************************************
 *  函数名称   : BootWatchDogDisable(*)
 *  功能描述   : 去使能软件喂狗
 *  读全局变量 : 无
 *  写全局变量 : 无
 *  输入参数   : 无
 *  输出参数   : 无
 *  返 回 值   : BSP_OK 
 *  其它说明   : 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *  $0000000(N/A), 宋飞@2011-11-25 11:15:46
 *  $0000001(N/A), 姜建奎@2013-12-13 16:04:27 加入支持FPGA 看门狗
 *----------------------------------------------------------------------------
 */
ULONG BootWatchDogDisable(VOID)
{
    ULONG ulRegister;
    /*
     * Read the contents of the ZMR register.
     */
    ulRegister = BootRdWdtReg(XWDTPS_ZMR_OFFSET);
    /*
     * Disable the Timer field in the register and
     * Set the access key for the write to be done the register.
     */
    ulRegister &= (ULONG)(~XWDTPS_ZMR_WDEN_MASK);
    ulRegister |= XWDTPS_ZMR_ZKEY_VAL;

    /*
     * Update the ZMR with the new value.
     */
    BootWrWdtReg(XWDTPS_ZMR_OFFSET,ulRegister);

    return BSP_OK;
}

/*****************************************************************************
 *  函数名称   : BootGetWdtControlValue(*)
 *  功能描述   : 读取看门狗CCR寄存器
 *  读全局变量 : 无
 *  写全局变量 : 无
 *  输入参数   : Control
 *  输出参数   : 无
 *  返 回 值   : 寄存器值
 *  其它说明   : 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *  $00086970     00086970    2017/02/27   创建
 *----------------------------------------------------------------------------
 */
ULONG BootGetWdtControlValue(UCHAR ucControl)
{
    ULONG ulRegister;
    ULONG ulReturnValue = 0U;

    /*
     * Read the contents of the CCR register.
     */
    ulRegister = BootRdWdtReg(XWDTPS_CCR_OFFSET);

    if (ucControl == XWDTPS_CLK_PRESCALE) {
        /*
         * Mask off the field in the register.
         */
        ulReturnValue = ulRegister & XWDTPS_CCR_CLKSEL_MASK;

    } else if (ucControl == XWDTPS_COUNTER_RESET) {
        /*
         * Mask off the field in the register.
         */
        ulRegister &= XWDTPS_CCR_CRV_MASK;

        /*
         * Shift over to the right most positions.
         */
        ulReturnValue = ulRegister >> XWDTPS_CCR_CRV_SHIFT;
    } else {
        /* Else was made for misra-c compliance */
        ;
    }

    return ulReturnValue;
}

/*****************************************************************************
 *  函数名称   : BootSetWdtControlValue(*)
 *  功能描述   : 设置看门狗CCR寄存器
 *  读全局变量 : 无
 *  写全局变量 : 无
 *  输入参数   : Control，value值
 *  输出参数   : 无
 *  返 回 值   : 寄存器值
 *  其它说明   : 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *  $00086970     00086970    2017/02/27   创建
 *----------------------------------------------------------------------------
 */
void BootSetWdtControlValue(UCHAR ucControl, ULONG Value)
{
    ULONG ulRegister;
    ULONG ulLocalValue = Value;

    /*
     * Read the contents of the CCR register.
     */
    ulRegister = BootRdWdtReg(XWDTPS_CCR_OFFSET);

    if (ucControl == XWDTPS_CLK_PRESCALE) {
        /*
         * Zero the field in the register.
         */
        ulRegister &= (ULONG)(~XWDTPS_CCR_CLKSEL_MASK);

    } else if (ucControl == XWDTPS_COUNTER_RESET) {
        /*
         * Zero the field in the register.
         */
        ulRegister &= (ULONG)(~XWDTPS_CCR_CRV_MASK);

        /*
         * Shift Value over to the proper positions.
         */
        ulLocalValue = ulLocalValue << XWDTPS_CCR_CRV_SHIFT;
    } else{
        /* This was made for misrac compliance. */
        ;
    }

    ulRegister |= ulLocalValue;

    /*
     * Set the access key so the write takes.
     */
    ulRegister |= XWDTPS_CCR_CKEY_VAL;

    /*
     * Update the CCR with the new value.
     */
    BootWrWdtReg(XWDTPS_CCR_OFFSET, ulRegister);
}
/*****************************************************************************
 *  函数名称   : BootConvertTimeWdtCounter(*)
 *  功能描述   : 时间转换为看门狗计数
 *  读全局变量 : 无
 *  写全局变量 : 无
 *  输入参数   : seconds:s
 *  输出参数   : 无
 *  返 回 值   : 计数值
 *  其它说明   : 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *  $00086970     00086970    2017/02/27   创建
 *----------------------------------------------------------------------------
 */
ULONG BootConvertTimeWdtCounter(ULONG seconds)
{
    double time = 0.0;
    double CounterValue;
    ULONG Crv = 0;
    ULONG Prescaler=0;
    ULONG PrescalerValue=0;

    Prescaler = BootGetWdtControlValue(XWDTPS_CLK_PRESCALE);

    if (Prescaler == XWDTPS_CCR_PSCALE_0008) {
        PrescalerValue = 8;
    } if (Prescaler == XWDTPS_CCR_PSCALE_0064) {
        PrescalerValue = 64;
    } if (Prescaler == XWDTPS_CCR_PSCALE_4096) {
        PrescalerValue = 4096;
    }

    time = (double)(PrescalerValue) / (double)XPAR_XWDTPS_0_WDT_CLK_FREQ_HZ;

    CounterValue = seconds / time;

    Crv = (ULONG)CounterValue;
    Crv >>= XFSBL_WDT_CRV_SHIFT;
    printf("Crv = 0x%x,%d\n",Crv,Crv);
    return Crv;
}
/*****************************************************************************
 *  函数名称   : BspSetWatchDogTime(*)
 *  功能描述   : 设置看门狗喂狗时间
 *  读全局变量 : 无
 *  写全局变量 : 无
 *  输入参数   : ulTimerValue - 写入硬件喂狗的时间，以100ms为单位
 *  输出参数   : 无
 *  返 回 值   : 成功 - BSP_OK
 *  其它说明   : 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *  $0000000(N/A), 宋飞@2011-11-25 11:15:46
 *----------------------------------------------------------------------------
 */
 
ULONG BootSetWatchDogTime (ULONG ulTimerValue)
{
 
    ULONG ulWatchdogtime = 0;
    
    ulWatchdogtime = BootConvertTimeWdtCounter(ulTimerValue);
    /**
     * Set the Watchdog counter reset value
     */
    BootSetWdtControlValue(XWDTPS_COUNTER_RESET,ulWatchdogtime);
    return BSP_OK;
    
}

/*****************************************************************************
 *  函数名称   : BootEnableWdtOutput(*)
 *  功能描述   : 使能看门狗有效输出
 *  读全局变量 : 无
 *  写全局变量 : 无
 *  输入参数   : ucSignal输出模式
 *  输出参数   : 无
 *  返 回 值   : 计数值
 *  其它说明   : 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *  $00086970     00086970    2017/02/27   创建
 *----------------------------------------------------------------------------
 */
void BootEnableWdtOutput(UCHAR ucSignal)
{
    ULONG ulRegister;
    /*
     * Read the contents of the ZMR register.
     */
    ulRegister = BootRdWdtReg(XWDTPS_ZMR_OFFSET);

    if (ucSignal == XWDTPS_RESET_SIGNAL) {
        /*
         * Enable the field in the register.
         */
        ulRegister |= XWDTPS_ZMR_RSTEN_MASK;

    } else if (ucSignal == XWDTPS_IRQ_SIGNAL) {
        /*
         * Enable the field in the register.
         */
        ulRegister |= XWDTPS_ZMR_IRQEN_MASK;

    } else {
        /* Else was made for misra-c compliance */
        ;
    }

    /*
     * Set the access key so the write takes.
     */
    ulRegister |= XWDTPS_ZMR_ZKEY_VAL;

    /*
     * Update the ZMR with the new value.
     */
    BootWrWdtReg(XWDTPS_ZMR_OFFSET, ulRegister);
}

/*****************************************************************************
 *  函数名称   : BootDisableWdtOutput(*)
 *  功能描述   : 去使能看门狗有效输出
 *  读全局变量 : 无
 *  写全局变量 : 无
 *  输入参数   : seconds:s
 *  输出参数   : 无
 *  返 回 值   : 计数值
 *  其它说明   : 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *  $00086970     00086970    2017/02/27   创建
 *----------------------------------------------------------------------------
 */
void BootDisableWdtOutput(UCHAR ucSignal)
{
    ULONG ulRegister;

    
    /*
     * Read the contents of the ZMR register.
     */
    ulRegister = BootRdWdtReg(XWDTPS_ZMR_OFFSET);

    if (ucSignal == XWDTPS_RESET_SIGNAL) {
        /*
         * Disable the field in the register.
         */
        ulRegister &= (ULONG)(~XWDTPS_ZMR_RSTEN_MASK);

    } else if (ucSignal == XWDTPS_IRQ_SIGNAL) {
        /*
         * Disable the field in the register.
         */
        ulRegister &= (ULONG)(~XWDTPS_ZMR_IRQEN_MASK);

    } else {
        /* Else was made for misra-c compliance */
        ;
    }

    /*
     * Set the access key so the write takes place.
     */
    ulRegister |= XWDTPS_ZMR_ZKEY_VAL;

    /*
     * Update the ZMR with the new value.
     */
    BootWrWdtReg(XWDTPS_ZMR_OFFSET,ulRegister);
}

/**********************************************************************
* 函数名称:VOID BootAppWatchDogInit()
* 功能描述:bootapp初始化看门狗
* 输入参数:无
* 输出参数:
* 返 回 值:BSP_OK:成功;BSP_ERROR:失败
* 其它说明:网线连通bootapp main入口到下次内核启动完成计时约20s。bsp接口单位100ms，
           设置看门狗时间100s，100s到达前MGR接管，否则看门狗复位
* 修改日期        版本号     修改人          修改内容
* -----------------------------------------------
* 2015-10-22       V1.0       00086970             创建
***********************************************************************/
ULONG BootWatchDogInit()
{
   
    ULONG ulRet = BSP_OK;

    BootSetWatchDogTime(240);
    
    BootWatchDogEnable();

    return ulRet;
}
ULONG BootGetPhyId()
{
   
    FILE *fd = NULL;
    CHAR *pcAddr = NULL;
    CHAR cTmp = 0;
    #define PHYID_INFO_FILE "/proc/bsp/eth0/phyid"   
    ULONG ulDebugNetPortPhyId = 0x1f;
    CHAR cEth0Phyid[16] = {0};
    
    fd = fopen(PHYID_INFO_FILE,"r+b");
    if(NULL == fd)
    {
        printf("Can not open phyid\n");    
        return BSP_ERROR;
    }
    fseek(fd,0L,SEEK_SET);
    cTmp = fread(cEth0Phyid,1,sizeof(cEth0Phyid),fd);      
    if(0 >= cTmp)
    {
        printf("read phyid error\n"); 
        /* Started by AICoder, pid:kc1e5x19afc849d14aa70b1e004a7f25c597a22b */   
        zte_fclose_s(fd);
        /* Ended by AICoder, pid:kc1e5x19afc849d14aa70b1e004a7f25c597a22b */
        return BSP_ERROR;
    }
    pcAddr = strchr(cEth0Phyid, ':');
    if(NULL == pcAddr)
    {  
        printf("phyid X:XX error\n");    
        zte_fclose_s(fd);
        return BSP_ERROR;
    }    
    ulDebugNetPortPhyId = (int)strtol(pcAddr+1,NULL,16);
    printf("eth0 PhyId form proc: 0x%x\n",ulDebugNetPortPhyId);
    zte_fclose_s(fd);
    return ulDebugNetPortPhyId;

}

/**********************************************************************
* 函数名称:ULONG BootGetMiiLinkStatus()
* 功能描述:获取debug网口连通状态
* 输入参数:
* 输出参数:
* 返 回 值:0:连通，1:断开 ;BSP_ERROR:失败
* 其它说明:用于检测debug网口的物理链路通断状态
* 修改日期        版本号     修改人          修改内容
* -----------------------------------------------
* 2015-10-22       V1.0       00086970             创建
***********************************************************************/ 
ULONG BootGetMiiLinkStatus(VOID)
{
    struct ifreq ifr;
    int ret;
    int sockfd;
    memset(&ifr, 0, sizeof(ifr));
    strncpy(ifr.ifr_name,"eth0", IFNAMSIZ - 1);
    sockfd = socket(PF_LOCAL, SOCK_DGRAM, 0);
    reteck(sockfd);
    ret = ioctl(sockfd,SIOCGIFFLAGS, (char*)&ifr);
    if(ret < 0)
    {
        zte_printf_s("error! \"%s\" : line: %d\n", __func__, __LINE__); 
        close(sockfd);
        return BSP_ERROR;
    }

    printf("\nifr_flags: 0x%x\n",ifr.ifr_flags);
    close(sockfd);
    if(ifr.ifr_flags & IFF_RUNNING)    
    {
        printf("Link Status:is Running\n");    
        return 0;
    }
    else
    {
        printf("Link Status:is Down\n");    
        return 1;        
    }

}
/**********************************************************************
* 函数名称:ULONG BootPhyLinkInit()
* 功能描述:PhyLink初始化
* 输入参数:
* 输出参数:
* 返 回 值:
* 修改日期        版本号     修改人          修改内容
* -----------------------------------------------
* 2015-10-22       V1.0       00086970             创建
***********************************************************************/
ULONG BootPhyLinkInit()
{   
    return BootPhyLinkMmap();
}

/*****************************************************************************
*  函数名称   : BootGetDdrSize
*  功能描述   : 通过命令行获取cpu使用的ddr大小
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : 无
*  输出参数   : 无
*  返 回 值   : 128:128M,256:256M
*  其它说明   : kexecboot通过mem=获取给
*               cpu使用的内存大小(不是ddr的物理大小)
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A), 00086970@2016-03-31      创建
*----------------------------------------------------------------------------
*/
ULONG BootGetDdrSize(VOID)
{
    ULONG *pulMemSize = NULL;
    UCHAR ucStr[] = "mem=250M";
    pulMemSize = strstr(g_ucCmdLine,ucStr);
    if(NULL == pulMemSize)
    {
        printf("DDR 128M for cpu!\n");
        return 128;
    }
    else
    {
        printf("DDR 256M for cpu!\n");
        return 256;
    }
}
/*****************************************************************************
*  函数名称   : BootDevMemMap()
*  功能描述   : 使用mmap将物理地址映射到用户进程虚拟地址空间
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : 无
*  输出参数   : 无
*  返 回 值   : BSP_OK, 其它值为失败
*  其它说明   :
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A), 田瑞忠@2010-5-19 8:52:25 创建
*----------------------------------------------------------------------------
*/
ULONG BootDevMemMap(VOID)
{
    /* 打开内存设备的文件描述符 */
    int     iFd;
    int     iSpaceProt = PROT_READ | PROT_WRITE;
    ULONG   iCount = 0;
    ULONG   ulDdrSize = 0;
    
    
    ulDdrSize = DRAM_1024M;
    
       
#define TO_MAP_LIST(a)      #a, &a
    /*lint -e529*/
    /*lint -e64*/
    struct map_list_t {
        UCHAR   *pucVarName;
        LONG    *pulVarAddr;
        ULONG   ulMapBase;
        ULONG   ulMapSize;
    } map_list[] = {
        {TO_MAP_LIST(g_ulRamReservedAddr),  (0+ ulDdrSize -0x00600000),0x00600000},
        {TO_MAP_LIST(g_ulBootRegisterAddr),0xFF5E0000,0x00000300},
        {TO_MAP_LIST(aulGpioAddr),0xFF0A0000,0x00000300},
        {TO_MAP_LIST(aulGem3VirAddr),0xFF0E0000,0x00000300},
        {TO_MAP_LIST(aulWatchdogAddr),0xFD4D0000,0x00000300},
        {TO_MAP_LIST(aulgem0PcsVirAddr),0xFF0B0000,0x00000300}
    };
    /*lint +e529*/
    /*lint +e64*/
    #define DO_ADDR_MAP(a)                                          \
        *((a)->pulVarAddr) = (long)mmap(0, (a)->ulMapSize,          \
            iSpaceProt, MAP_SHARED, iFd, (a)->ulMapBase);           \
        if (*((a)->pulVarAddr) == -1)                               \
        {                                                           \
            dbgErr("mmap %s failed %s, %d\n",                       \
                (a)->pucVarName, strerror(errno), errno);           \
            close(iFd);                                             \
            return BSP_ERROR;                                       \
        }                                                           \
        dbgInfo("%-20s = %#x.0x%x\n", (a)->pucVarName, *((a)->pulVarAddr),(a)->ulMapBase);


    /* 打开存储空间映射 */
    if ((iFd = open("/dev/mem", O_RDWR | O_SYNC)) < 0)
    {
        dbgErr("open /dev/mem failed\n");
        return BSP_ERROR;
    }

    for (iCount = 0; iCount < sizeof(map_list)/sizeof(map_list[0]); iCount++)
    {
        DO_ADDR_MAP(&map_list[iCount]);
        usleep(1000);
    }

    return BSP_OK;
}



 /*****************************************************************************
*  函数名称   : BootLedMmap(*)
*  功能描述   : Led 控制寄存器地址映射
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : 无
*  输出参数   : 无
*  返 回 值   : BSP_OK 成功,BSP_ERROR 出错
*  其它说明   : 
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A), 姜建奎@2013-03-26 11:14:27 创建 从r16trx 移植过来
*----------------------------------------------------------------------------
*/


ULONG BootLedMmap(VOID)
{
    INT     ifile;
    ULONG   ulSpaceProt = PROT_READ | PROT_WRITE;
    ULONG    ulVirAddr, ulPhyAddr;

    if ((ifile = open("/dev/mem", O_RDWR | O_SYNC)) < 0)
    {
        dbgErr("open /dev/mem failed\n");
        return BSP_ERROR;
    }

    ulPhyAddr = GPIO_BASE_ADDR;
    
    ulVirAddr = (ULONG)mmap((void *)ulVirAddr, 0x300, ulSpaceProt, MAP_SHARED, ifile, ulPhyAddr);
    
    printf("%s %d 0x%x 0x%x\n", __FUNCTION__, __LINE__, ulPhyAddr, ulVirAddr);

    aulGpioAddr = ulPhyAddr;
    close(ifile);
    return BSP_OK;

}
 /******************************************************************************
*  函数名称   : BootLedInit(*)
*  功能描述   :
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   :

*  输出参数   : 无
*  返 回 值   : BSP_OK, 操作成功; BSP_ERROR_INVALID_PARA, 输入参数错误
*  其它说明   : 无
*  函数属性   : 规避14boot引入的VSWR1灯上电未点灭问题
*------------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A), 耿佳佳2011-12-01 17:28:12 创建
*  $0000001(N/A), 姜建奎2013-02-26 11:28:12 根据r15trx 修改run 灯由PWM 来控制
*------------------------------------------------------------------------------
*/
ULONG BootLedInit(VOID)
{
    ULONG uliRet = BSP_OK;
    
    if (BSP_OK != BootLedMmap())
    {
        dbgErr("LedMmap Init Failed!\n");
        return BSP_ERROR;
    }
    
    return uliRet;
    
}
 /**********************************************************************
* 函数名称： BootGetGpioReg
* 功能描述： 
* 输入参数： 无
* 输出参数： 无
* 返 回 值： 无
* 其它说明： 
* 修改日期        版本号     修改人          修改内容
* -----------------------------------------------
* 2012/07           V1.0         ZKH          
***********************************************************************/
ULONG BootGetGpioReg(ULONG ulOffSet, ULONG *pulReg)
{

    *pulReg = *(volatile ULONG *)(aulGpioAddr + ulOffSet);

    return BSP_OK;
}

/**********************************************************************
* 函数名称： BootSetGpioReg
* 功能描述： 
* 输入参数： 无
* 输出参数： 无
* 返 回 值： 无
* 其它说明： 
* 修改日期        版本号     修改人          修改内容
* -----------------------------------------------
* 2012/07           V1.0         ZKH          
***********************************************************************/
ULONG BootSetGpioReg(ULONG ulOffSet, ULONG ulReg)
{
    *(volatile ULONG *)(aulGpioAddr + ulOffSet) = ulReg;

    return BSP_OK;
}
/**********************************************************************
* 函数名称： BootGetMorS
* 功能描述： MIO14指示当前分支
* 输入参数： 无
* 输出参数： 无
* 返 回 值： 0:RGMII(FAD) 1:SGMII(5G2.0)
* 其它说明： 
* 修改日期        版本号     修改人          修改内容
* -----------------------------------------------
* 2012/07           V1.0         ZKH          
***********************************************************************/
ULONG BootGetDownloadFlag(void)
{    
     ULONG ulReg = 0;
     BootGetGpioReg(GPIO_BANK0_INPUT_DATA_OFFSET,&ulReg);
     if(0 == (ulReg&0x00004000))
     {
        printf("FAD\n");
        return 0;
     }
     else
     {
        printf("5G_LOW_FREQ_20\n");
        return 1 ;
     }
     
}

unsigned char ucappid=0xff;
unsigned char  zynqmpsoc_get_appid (void)
{   
    unsigned long uldata = 0;

    /*if have getted dramid, return*/
    if(0xff != ucappid)
        return ucappid;

    BootGetGpioReg(GPIO_BANK0_INPUT_DATA_OFFSET,&uldata);
    ucappid =  (uldata & (1 << 16))?1:0;
    ucappid = ucappid << 1;
    ucappid |=  (uldata & (1 << 20))?1:0;

    printf("AppId == %d \n",ucappid);
    return ucappid;
}

/**********************************************************************
* 函数名称:ULONG BootGetPcsLinkStatus()
* 功能描述:获取SGMII网口连通状态
* 输入参数:
* 输出参数:
* 返 回 值:0:连通，1:断开 ;
* 其它说明:用于检测debug网口的物理链路通断状态
* 修改日期        版本号     修改人          修改内容
* -----------------------------------------------
* 2015-10-22       V1.0       00086970             创建
***********************************************************************/ 
unsigned long BootGetPcsLinkStatus(VOID)
{
    unsigned long  ulValue = 0;
    #define PCS_STATUS_REG     0x204 
    #define PCS_STATUS_REG_LINK_MASK (ULONG)1<<2 /*PCS_status寄存器bit2 表示link status, 1-up, 0-down*/

    
    ulValue= BootRdGem0PcsReg(PCS_STATUS_REG);  
   
    if (0 == (ulValue & PCS_STATUS_REG_LINK_MASK))
    {
        dbgInfo("GEM0 SGMII net port is OFF \n"); 
        return 1;
    }
    else
    {
        dbgInfo("GEM0 SGMII net port is ON\n"); 
        return 0;
    }
}
/**********************************************************************
* 函数名称:ULONG BootGetPhyLinkStatus()
* 功能描述:获取SGMII网口连通状态
* 输入参数:
* 输出参数:
* 返 回 值:0:连通，1:断开 ;
* 其它说明:用于检测debug网口的物理链路通断状态
* 修改日期        版本号     修改人          修改内容
* -----------------------------------------------
* 2015-10-22       V1.0       00086970             创建
***********************************************************************/ 
unsigned long BootGetPhyLinkStatus(VOID)
{
    #if 0
    /*8101NR分支，共五处，搜BootGetDownloadFlag*/
    return BootGetMiiLinkStatus();
    #else
    if(1== BootGetDownloadFlag()) 
    {
        return BootGetPcsLinkStatus();
    }
    else
    {
        return BootGetMiiLinkStatus();
    }
    #endif
}
/** function for getting Slot Position Id from MIO pin 11 12 13
*/
ULONG GetSlotPositionId(void)
{
    ULONG uiPin = 0, uiVal = 0, uiRet = 0;

    uiRet = BootGetGpioReg(GPIO_BANK0_INPUT_DATA_OFFSET,&uiPin);
    if (uiRet)
    {
        printf("%s:line%d. ReadGpioPin failed!ret 0x%x\n", __FUNCTION__, __LINE__, uiRet);
        return -1;
    }
    uiVal =  (uiPin >> 11) & 0x7;
    
    printf("%s:line%d. Slot Position Id is [0x%d]\n", __FUNCTION__, __LINE__, uiVal);
    return uiVal;
}

/**function for setting eth0 ipaddr and macaddr*/
void BootSetEthAddr(void)
{
    ULONG uiVal = 0;
    unsigned char cmdBuf[256] = {0};
    uiVal = GetSlotPositionId();
    uiVal = uiVal + 2;

    sprintf(cmdBuf, "ifconfig eth0 down\n");
    system(cmdBuf);  
    
    sprintf(cmdBuf, "ifconfig eth0 hw ether 40:00:C6:21:21:%d\n", uiVal);
    system(cmdBuf);
    
    sprintf(cmdBuf, "ifconfig eth0 198.33.33.%d netmask 255.255.0.0\n", uiVal);
    system(cmdBuf);

    sprintf(cmdBuf, "route add -net 199.0.0.0 netmask 255.0.0.0 gw 198.33.33.100 dev eth0\n");
    system(cmdBuf);
    
}

/**********************************************************************
* 函数名称： BspSetGpioDataout
* 功能描述： 
* 输入参数： 无
* 输出参数： 无
* 返 回 值： 无
* 其它说明： 
* 修改日期        版本号     修改人          修改内容
* -----------------------------------------------
* 2012/07           V1.0         ZKH          
***********************************************************************/
ULONG BootSetGpio0Dataout(ULONG ulBit, BOOL bHigh)
{
    ULONG ulReg;
    ULONG ulRet;
    
    if(ulBit > 31 || bHigh > 1)
    {
        printf("%s %d %d %d para error", __FUNCTION__, __LINE__, ulBit, bHigh);
        return BSP_ERROR;
    }
    BootGetGpioReg(GPIO_BANK0_OUTPUT_DATA_OFFSET,&ulReg);
    if (bHigh)
    {
        ulReg |=  (1 << ulBit);   
    }
    else
    {   
        ulReg &=  (~(1 << ulBit));
    }
    ulRet = BootSetGpioReg((ULONG)GPIO_BANK0_OUTPUT_DATA_OFFSET, ulReg);
    
    return ulRet;
    
}
  /******************************************************************************
*  函数名称   : BootSetGpioDir(*)
*  功能描述   : 设置GPIO方向
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   :0:输出，1，输入

*  输出参数   : 无
*  返 回 值   : BSP_OK, 操作成功; BSP_ERROR_INVALID_PARA, 输入参数错误
*  其它说明   : 无
*  函数属性   : 
*------------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A), 耿佳佳2017-2-14 17:28:12 创建
*------------------------------------------------------------------------------
*/
ULONG BootSetGpio0Dir(ULONG ulBit, BOOL bIsInput)
{
    ULONG ulReg;
    ULONG ulRet;
    
    if(ulBit > 31 || bIsInput > 1)
    {
        printf("%s %d %d para error", __FUNCTION__, __LINE__, ulBit);
        return BSP_ERROR;
    }
    
    ulRet = BootGetGpioReg((ULONG)GPIO_BANK0_DIR_OFFSET, &ulReg);
    if(BSP_ERROR == ulRet)
    {
        return BSP_ERROR;
    }
    
    if (bIsInput)
    {
        ulReg &= (~(1 << ulBit));
    }
    else
    {
        ulReg |= (1 << ulBit);
    }

    ulRet = BootSetGpioReg((ULONG)GPIO_BANK0_DIR_OFFSET, ulReg);
    if(0 == bIsInput)
    {
        ulRet |=BootGetGpioReg(GPIO_BANK0_OUTPUT_ENABLE_OFFSET,&ulReg);
        ulReg |=  (1 << ulBit); 
        ulRet |= BootSetGpioReg((ULONG)GPIO_BANK0_OUTPUT_ENABLE_OFFSET, ulReg);
    }
    return ulRet;
}

 

/******************************************************************************
*  函数名称   : BspLedCtrl(*)
*  功能描述   : 实现对面板灯的控制
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : ulLedName   - 灯名, 定义于BspPublic.h文件或者BoardApi.h文件
                ulLedMode - 灯状态的控制
*  输出参数   : 无
*  返 回 值   : BSP_OK, 操作成功; BSP_ERROR_INVALID_PARA, 输入参数错误
*  其它说明   : 无
*  函数属性   : 基础接口
 *工装使用申明: 工装使用接口，请注意波及
*------------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A), 鲁侃@2010-06-21 17:28:12 创建
*  $0000000(N/A), 王茂金@2010-10-28 9:48:11 根据实际硬件和统一接口要求修改代码
*  $0000000(N/A), 崔文会@2011-01-25 9:48:11 根据实际硬件和统一接口要求修改代码
*------------------------------------------------------------------------------
*/
ULONG BootLedCtrl(ULONG ulLedname, ULONG ulLedMode)
{
    switch (ulLedname)
    {
        case BSP_LED_ID_RUN: /* LedRun*/
            {
                if( BSP_LED_OP_OFF == ulLedMode )
                {
                    BootSetGpio0Dataout(22,1);
                }
                else if( BSP_LED_OP_ON == ulLedMode )
                {
                    BootSetGpio0Dataout(22,0);
                }
                break;          
            }
        case BSP_LED_ID_ALM: /*LedAlm */
            {
                if( BSP_LED_OP_OFF == ulLedMode )
                {
                    BootSetGpio0Dataout(23,1);
                }
                else if( BSP_LED_OP_ON == ulLedMode )
                {
                    BootSetGpio0Dataout(23,0);
                }
                break;          
            }
         default:
            {
                return BSP_ERROR_DEVICE_NOT_EXIST;
            }
        }
}
/**************************************************************************
 * 函数名称: int BootSetLedFlag(void)
 * 功能描述: 工装 应用程序入口
 * 输入参数: 无
* 输出参数: 
 * 返 回 值: 无
* 其它说明: 
*
* 修改日期:    版本号     修改人        修改内容
* -----------------------------------------------
* 2010-05-25     V1.0      xxx        Created
**************************************************************************/  

ULONG BootSetLedFlag(ULONG ulSwitch)
{
    if( 0 == ulSwitch)
        g_ulLedFlag = 0;
    else
        g_ulLedFlag = 1;

    return BSP_OK;
}

VOID BootLedBling(VOID)
{
    ULONG ucClkRate = sysClkRateGet();
    BootLedCtrl(BSP_LED_ID_RUN,BSP_LED_OP_OFF);
    taskDelay(ucClkRate);
    BootLedCtrl(BSP_LED_ID_RUN,BSP_LED_OP_ON);
    taskDelay(ucClkRate);
    /*先亮后灭的话，出现调度原因导致的闪灯过后常亮RUN灯偶发不亮的问题，调整为先灭后亮规避该问题*/
}

VOID BootLedTask(VOID)
{
    while(1)
    {
        if(0 != g_ulLedFlag)
        {
            BootLedBling();
        }
        else
        {
            BootSysMsDelay(500);
        }
    }      
}

/**********************************************************************
* 函数名称:void led_run(unsigned char ucMode)
* 功能描述:led_run led灯闪烁模式
* 输入参数: ucMode  0 只亮run灯,  1 run灯周期性闪
* 输出参数:无。
* 返 回 值:无
* 其它说明: dpdic led 使用情况:
GPIO 14 -- RUN
GPIO 15 -- ALM
GPIO 16 --OPT0
GPIO 17 -- OPT1
GPIO 19 --VSWR
GPIO 20 -- ACT
* 修改日期        版本号     修改人          修改内容
* -----------------------------------------------
* 2015/10/12            V1.0            00086970                       创建
***********************************************************************/

VOID BootLedRun(UCHAR ucMode)
{
    
    if(0 == ucMode)/*只亮run灯,其他灯灭 */
    {  
        BootSetLedFlag(0);
        BootLedCtrl(BSP_LED_ID_ALM, BSP_LED_OP_OFF);  
        BootLedCtrl(BSP_LED_ID_RUN, BSP_LED_OP_ON);
    }
    else if(1 == ucMode)/*run灯周期性闪烁*/
    {  
        BootSetLedFlag(1);
        BootLedCtrl(BSP_LED_ID_ALM, BSP_LED_OP_OFF);   
    }
    else if(2 == ucMode)/*所有灯都全亮*/
    {
        BootSetLedFlag(0);
        BootLedCtrl(BSP_LED_ID_RUN, BSP_LED_OP_ON);
        BootLedCtrl(BSP_LED_ID_ALM, BSP_LED_OP_ON);
    }
    else
    {
        printf("BootLedRun, input params[%d] error\n", ucMode);
    }
}


ULONG BootGpioInit(VOID)
{
     BootSetGpio0Dir(22,0);/*LED*/
     BootSetGpio0Dir(23,0);
     BootSetGpio0Dir(14,1);/*sgmii flag*/
     BootSetGpio0Dir(16,1);/*appid*/
     BootSetGpio0Dir(20,1);/*appid*/
     return BSP_OK;
}
/*****************************************************************************
*  函数名称   : BootBoardHwPreInit()
*  功能描述   : Bsp单板预初始化函数
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : 无
*  输出参数   : 无
*  返 回 值   : BSP_OK, 其它值为失败
*  其它说明   : 无
 *工装使用申明: 无
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A), 崔文会@2012-11-22 16:35:09, 创建
*----------------------------------------------------------------------------
*/
ULONG BootBoardHwPreInit(VOID)
{
    ULONG ulRet = BSP_OK;
    ulRet|=BootGpioInit();            /*GPIO初始化*/
    BootLedRun(0);
    return ulRet;
}

/**************************************************************************
* 函数名称： SetEthProMode
* 功能描述： 设置ETH的模式寄存器的混杂模式控制位
* 输入参数： 0--对进入的帧的目的地址进行检查。1--对进入的帧的目的地址不进行检查。
* 输出参数： 无
* 返 回 值： 
* -------------------------------------------------------
* 其它说明： 
* 修改日期     版本号        修改人                修改内容
* 2015/10/22     V1.0         00086970           创建
**************************************************************************/
ULONG SetEthProMode(UCHAR ucValue)
{ 
    ULONG ulRet=0;  
    
    ulRet = *(unsigned int *)(aulGem3VirAddr + ZYNQ_GEM_CONFIG_REG);

    printf("1:ZYNQ_GEM_COPY_ALL_FRAMES = 0x%x \n",ulRet);
    if (ucValue == 0)
    /*对进入的帧的目的地址进行检查*/
    {
        ulRet = ulRet & 0xFFFFFFEF;
    }
    /*对进入的帧的目的地址不进行检查*/
    else
    {        
        ulRet = ulRet | 0x00000010;
    }

    *(unsigned int *)(aulGem3VirAddr + ZYNQ_GEM_CONFIG_REG) = ulRet;
        
    printf("2:ZYNQ_GEM_COPY_ALL_FRAMES = 0x%x \n",*(unsigned int *)(aulGem3VirAddr + ZYNQ_GEM_CONFIG_REG));
    return ulRet;
     
}
ULONG BootBoardPreInit(VOID)
{
    ULONG ulRet = BSP_OK;
    unsigned char cmdBuf[256] = {0};
    printf("\n BootBoardPreInit. \n");
    int iTimeout = 10;

    ulRet |= BootDevMemMap(); /*高端内存和RTC映射*/
    ulRet |= BootBoardHwPreInit();  /*I2C初始化bomid初始化看门狗映射*/
    #if 0
    /*8101NR分支，共五处，搜BootGetDownloadFlag*/
    BootSetEthAddr();
    printf("wait for link...");
    while(iTimeout)
    {
        if(0 == BootGetPhyLinkStatus())
        {
            printf("ON\n");
            break;
        }
        iTimeout--;
        sleep(1);
    }
    if(iTimeout <= 0)
    {
        printf("OFF\n");
    }
    
    #else
    if(1== BootGetDownloadFlag()) 
    {
        BootSetEthAddr();
    }
    else
    {
        sprintf(cmdBuf, "ifconfig eth0 199.33.33.33 netmask 255.255.0.0\n");
        system(cmdBuf);
    }
    
    printf("wait for link...\n");
    while(iTimeout)
    {
        if(0 == BootGetPhyLinkStatus())
        {
            break;
        }
        iTimeout--;
        sleep(1);
    }
    if(iTimeout <= 0)
    {
        printf("OFF\n");
    }
    #endif
    ulRet |= BootFlashInit();
    return ulRet;
     
}


ULONG memflag_set(ULONG writeval)
{
    (*(volatile ULONG *)(g_ulBootRegisterAddr + 0x200)) &= (~(0xf000));
    (*(volatile ULONG *)(g_ulBootRegisterAddr + 0x200))  |= (writeval&0xf)<< 12;

    printf("memflag_set=0x%x\n", ((*(volatile ULONG *)(g_ulBootRegisterAddr + 0x200))&0x0F000)>>12);
    
    return 0;
}

ULONG bootflag_get()
{
    return (((*(volatile ULONG *)(g_ulBootRegisterAddr + 0x200))&0xf000)>>12);        
}

 VOID boot_flag_set()
 {
    ULONG check_flag=0;
    
    check_flag=bootflag_get();
    printf("bootflag_get=0x%x\n", check_flag);

    if(check_flag==(MASTER_BOOT_OK&0xf))  /*本次是上电或者复位后第一次启动,启动主boot成功*/
    {
        memflag_set(MASTER_KUBOOT_OK);
        /*尚欠写高端内存表征主boot启动成功标志*/
    }
    else if(check_flag==(MASTER_KUBOOT_OK&0xf)) /*启动主boot成功，继续尝试引导CPU版本*/
    {
        memflag_set(MASTER_KUBOOT_OK);
        /*尚欠写高端内存表征主boot启动成功标志*/
    }
    else if(check_flag==(SLAVE_BOOT_OK&0xf))  /*启动从boot成功，*/
    {
        memflag_set(SLAVE_KUBOOT_OK);
        /*尚欠写高端内存表征从boot启动成功标志*/
    }
    else if(check_flag==(SLAVE_KUBOOT_OK&0xf))   /*启动从boot成功，继续尝试引导CPU版本*/
    {
        memflag_set(SLAVE_KUBOOT_OK);
        /*尚欠写高端内存表征从boot启动成功标志*/
    }
    else
    {
         printf("bootflag_get=0x%x error!", check_flag);
    }
}

/**********************************************************************
* 函数名称:BootGmac0MiiRead
* 功能描述:通过GMII寄存器读PHY  .  针对以太网口GMAC0 
* 输入参数: *     - udCsrClockRange：CSR 时钟区域
 *     - udGR： GMII寄存器
 *     - udPA： PHY设备物理层地址
 *     - pudData：需要读出的数据的地址
* 输出参数:
* 返 回 值:
* 其它说明:
* 修改日期        版本号     修改人          修改内容
* -----------------------------------------------
* 2014-5-28       V1.0       yam             创建
*  $0000000(N/A), zhaoyun@20141216 19:33:10 trm78E
***********************************************************************/
ULONG BootDebugMiiRead(ULONG ulCsrClockRange, ULONG ulGR, ULONG ulPA, ULONG *pulData)
{
    int timeout = CONFIG_MDIO_TIMEOUT;
    ULONG ulWriteData = 0;    
    if(NULL == pulData)
    {
        return BSP_E_POINTER_NULL;
    }
   
    while(timeout)
    {
        if((*(volatile unsigned long *)(aulGem3VirAddr + GEM3_NETWORK_STATUS_REG) )& ZYNQ_GEM_NWSR_MDIOIDLE_MASK)
        {
            break;
        }
        timeout--;
    }

    if (timeout <= 0)
    {
        return BSP_E_REG_ACCESS_TIMEOUT;
    }

    ulWriteData = ZYNQ_GEM_PHYMNTNC_OP_MASK | ZYNQ_GEM_PHYMNTNC_OP_R_MASK |
        (ulPA << ZYNQ_GEM_PHYMNTNC_PHYAD_SHIFT_MASK) |
        (ulGR << ZYNQ_GEM_PHYMNTNC_PHREG_SHIFT_MASK) | 
        (*pulData & USERACCESS_DATA);
    
    
    *(volatile unsigned long *)(aulGem3VirAddr + GEM3_PHY_MANAGEMENT_REG)=ulWriteData; 

    timeout = CONFIG_MDIO_TIMEOUT*10;
    while(timeout)
    {
        if((*(volatile unsigned long *)(aulGem3VirAddr + GEM3_NETWORK_STATUS_REG) )& ZYNQ_GEM_NWSR_MDIOIDLE_MASK)
        {
            break;
        }
        timeout--;
    }

    if (timeout <= 0)
    { 
        return BSP_E_REG_ACCESS_TIMEOUT;
    }
    
    *pulData = (*(volatile unsigned long *)(aulGem3VirAddr + GEM3_PHY_MANAGEMENT_REG))&USERACCESS_DATA;
    return BSP_OK;
   
}
/**********************************************************************
* 函数名称:BootGmac0MiiWrite
* 功能描述:通过GMII寄存器写PHY  .  针对以太网口GMAC0 
* 输入参数: *     - udCsrClockRange：CSR 时钟区域
 *     - udGR： GMII寄存器
 *     - udPA： PHY设备物理层地址
 *     - pudData：需要读出的数据的地址
* 输出参数:
* 返 回 值:
* 其它说明:
* 修改日期        版本号     修改人          修改内容
* -----------------------------------------------
* 2014-5-28       V1.0       yam             创建
*  $0000000(N/A),00086970 19:33:10 trm78E
***********************************************************************/
ULONG BootDebugMiiWrite(ULONG ulCsrClockRange, ULONG ulGR, ULONG ulPA, ULONG ulData)
{
    int timeout = CONFIG_MDIO_TIMEOUT;
    ULONG ulReadData = 0;
    ULONG ulWriteData = 0;    

    while(timeout)
    {
        if((*(volatile unsigned long *)(aulGem3VirAddr + GEM3_NETWORK_STATUS_REG) )& ZYNQ_GEM_NWSR_MDIOIDLE_MASK)
        {
            break;
        }
        timeout--;
    }

    if (timeout <= 0)
    {
        return BSP_E_REG_ACCESS_TIMEOUT;
    }

    ulWriteData = ZYNQ_GEM_PHYMNTNC_OP_MASK |ZYNQ_GEM_PHYMNTNC_OP_W_MASK |
        (ulPA << ZYNQ_GEM_PHYMNTNC_PHYAD_SHIFT_MASK) |
        (ulGR << ZYNQ_GEM_PHYMNTNC_PHREG_SHIFT_MASK) | 
        (ulData & USERACCESS_DATA);
    
                                     
     *(volatile unsigned long *)(aulGem3VirAddr + GEM3_PHY_MANAGEMENT_REG)=ulWriteData; 

    
    timeout = CONFIG_MDIO_TIMEOUT;
    while(timeout)
    {
        if((*(volatile unsigned long *)(aulGem3VirAddr + GEM3_NETWORK_STATUS_REG) )& ZYNQ_GEM_NWSR_MDIOIDLE_MASK)
        {
            break;
        }
        timeout--;
    }

    if (timeout <= 0)
    {
        return BSP_E_REG_ACCESS_TIMEOUT;
    }
    BootDebugMiiRead(ulCsrClockRange,ulGR,ulPA,&ulReadData);
    printf("Addr:0x%x,Reg:0x%x,WriteData:0x%x,ReadData:0x%x\n",ulPA,ulGR,ulData,ulReadData);
    return BSP_OK;
}

unsigned int UpdateFirstBoot(void)
{
    INT32 fd = 0;
    struct stat      tStat;
    ULONG ulFileSize = 0;
    CHAR *pucRdVerFileBuff = NULL;
    ULONG ulCrcWrBefore = 0;
    ULONG ulCrcWrAfter = 0;
    ULONG iRetVal = BSP_OK;
    
    
    fd = open("/bootmini.bin", O_RDONLY, 0);
    if (0 > fd)
    {      
        printf("open %s fail!\n","/bootmini.bin");
        return BSP_ERROR;
    }  
    if (fstat(fd, &tStat) < 0)
    {
        printf("Can not open file!\n");
        close(fd);
        return BSP_ERROR;
    }

    ulFileSize = tStat.st_size;
    if(ulFileSize != 0x100000)
    {
        printf("length error,must be 1M\n");
        close(fd);
        return BSP_ERROR;
    }
   
    /* éê???á°?±????t?o′? */
    pucRdVerFileBuff = (UCHAR *)malloc(ulFileSize);
    if(NULL == pucRdVerFileBuff)
    {
        printf("version file size %ld\n",ulFileSize);
        printf("malloc read version file buffer failed!\n");
        close(fd);
        return BSP_ERROR;
    }

    iRetVal = read(fd, pucRdVerFileBuff, ulFileSize);
    if((ULONG)iRetVal != ulFileSize)
    {
        printf("Version file read error\n");
        close(fd);
        free(pucRdVerFileBuff);
        pucRdVerFileBuff = NULL;
        return BSP_ERROR;
    }
    close(fd);
    ulCrcWrBefore = CalculateCRC16(CRC_MASK, (UCHAR *)pucRdVerFileBuff, ulFileSize);
    /* Started by AICoder, pid:bb71auf5c58e17f14b6e0ab4001a230e6b0364db */
    iRetVal = BspFlashWrite(0, (UCHAR *)pucRdVerFileBuff, ulFileSize);
    /* Ended by AICoder, pid:bb71auf5c58e17f14b6e0ab4001a230e6b0364db */
    if(BSP_OK == iRetVal)
    {
        memset(pucRdVerFileBuff,0,ulFileSize);
        /* Started by AICoder, pid:203d97eac52744414e280af310cc540723b3f3db */
        if(BSP_OK == BspFlashRead(0, (UCHAR *)pucRdVerFileBuff, ulFileSize))
        /* Ended by AICoder, pid:203d97eac52744414e280af310cc540723b3f3db */
        {    
            ulCrcWrAfter = CalculateCRC16(CRC_MASK, (UCHAR *)pucRdVerFileBuff, ulFileSize);
            if(ulCrcWrAfter == ulCrcWrBefore)
            {
                printf("update boot success,CRC=0x%x,please reboot now.\n",ulCrcWrAfter);
                free(pucRdVerFileBuff);
                pucRdVerFileBuff = NULL;
                return BSP_OK;
            }
            else
            {
                printf("update boot fail,CRC error!before 0x%x,After 0x%x,please try again.\n",ulCrcWrBefore,ulCrcWrAfter);
                free(pucRdVerFileBuff);
                pucRdVerFileBuff = NULL;
                return BSP_ERROR;

            }
                
        }
        else
        {
            printf("update read error.\n");
            free(pucRdVerFileBuff);
            pucRdVerFileBuff = NULL;
            return BSP_ERROR;
        }
    }
    else
    {
        printf("update write error.\n");
        free(pucRdVerFileBuff);
        pucRdVerFileBuff = NULL;
        return BSP_ERROR;
    }

    
}

/**********************************************************************
* 函数名称： BootGetFsRecoverFlag
* 功能描述： 从高端内存获取用户态文件系统异常标志
* 输入参数： 无
* 输出参数： 无
* 返 回 值： 0:正常 0xdeadbeaf:异常
* 其它说明： 获取后清除 
* 修改日期        版本号     修改人          修改内容
* -----------------------------------------------
* 2012/07           V1.0         ZKH          
***********************************************************************/
ULONG BootGetFsRecoverFlag(VOID)
{
    ULONG ulUbifsFormat_mask = 0;
    INT fd=0;
    ULONG ulBootMtdSize = 0;
    #define EnvSize 0x40000
    ULONG ulNum=0xffffffff;
    
    fd=open("/dev/mtd0",O_RDWR);
    if(fd < 0)
    {
        
        printf("open /dev/mtd0 error \n");    
        return BSP_ERROR;
    }
    
    ulBootMtdSize = lseek(fd,0,SEEK_END);
    if(ulBootMtdSize < 0)
    {
        printf("lseek /dev/mtd0 to end error \n");
        close(fd);
        return BSP_ERROR;
    }
    if(0 != lseek(fd,0,SEEK_SET))
    {
        printf("lseek /dev/mtd0 to begin error \n");
        close(fd);
        return BSP_ERROR;
    }
    
    close(fd);
    
    /* Started by AICoder, pid:we5e0e4b96jd4a514ff1086fa0010c025c03a5c0 */
    BspFlashRead(ulBootMtdSize-EnvSize, (UCHAR *)&ulUbifsFormat_mask,4);

    BspFlashWrite(ulBootMtdSize-EnvSize,(UCHAR *)&ulNum,4);
    /* Ended by AICoder, pid:we5e0e4b96jd4a514ff1086fa0010c025c03a5c0 */
    
    return ulUbifsFormat_mask;
}

/*****************************************************************************
 *  函数名称   : main(*)
 *  功能描述   : bootapp程序处理主函数
 *  读全局变量 : 无
 *  写全局变量 : 无
 *  输入参数   : argc   - 参数个数
                 argv[] - 参数列表
 *  输出参数   : 无
 *  返 回 值   : 0为成功, 其余失败
 *  其它说明   :
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *  $0000000(N/A), 00086970 @2015-10-28
 *----------------------------------------------------------------------------
 */
int main(int argc, char *argv[])
{
    int iBootAppTaskID = 0;
    ULONG ulRet = 0;    

    ulRet |= BootBoardPreInit();    
    ulRet |= BootWatchDogInit();
    ulRet |= (ULONG)ushell_init();
    ulRet |= BootSoftModInit();
    
   
    taskSpawn("tLedTask",   \
        100, /* priority */            \
        0,   /* option   */           \
        0x100,/* stack size */      \
        (FUNCPTR)BootLedTask, 0, 0, 0, 0, 0, 0, 0, 0 ,0,0);

   
    iBootAppTaskID = taskSpawn("tBootTask",   \
        100, /* priority */            \
        0,   /* option   */           \
        0x1000,/* stack size */      \
        (FUNCPTR)MainLoop, 0, 0, 0, 0, 0, 0, 0, 0 ,0,0);
    
    while(1)
    {
       //BspFunction("/boot.out", CFG_PROMPT);
       sleep(20);
    }
    return ulRet;


}
#endif

ULONG SetDefaultCmdline()
{
#if defined(KEXECBOOT_SUPPORT)
    char str[] = "earlycon=cdns,mmio,0xFF000000,115200n8 kexecboot=1";
    strncpy_s((char *)g_ucCmdLine,sizeof(g_ucCmdLine),str, strlen(str));
    #else
    char str[] = "earlycon=cdns,mmio,0xFF000000,115200n8";
    strncpy_s((char *)g_ucCmdLine,sizeof(g_ucCmdLine),str, strlen(str));
    #endif
     //coverity[cert_err33_c_violation:SUPPRESS]
    printf_s("/proc/cmdline error,load default cmdline.\n");
   return BSP_OK;
}

/**********************************************************************
* 函数名称：BootGetVersion
* 功能描述： 读取Flash中boot版本号
* 输入参数： headPtr需要获取到版本的指针，默认不使用，除非传入非空指针，model:0 获取一级Boot版本，1 获取二级keboot版本
* 输出参数： 无
* 返 回 值： 0:正常  非0:异常
* 其它说明： 获取后清除
* 修改日期        版本号     修改人          修改内容
* 修改日期     版本号        修改人                修改内容
* ---------------------------------------------------
* 2015/10/22     V1.0         10242265           创建
***********************************************************************/
INT32 BootGetVersion(char *headPtr,char model)
{
     UINT32 ulRet=0;
     UINT32 HEAD_ADDR=0;
     unsigned char  *ptVerFileHeadChar = NULL;
     T_VerFileHeader *ptVerFileHeader = NULL;
     if(NULL==headPtr)
     {
         return BSP_ERROR;
     }
     ptVerFileHeadChar = (unsigned char *)malloc(sizeof(T_VerFileHeader));
     if (NULL == ptVerFileHeadChar)
     {
         printf("malloc error!!\n");
         return -1;
     }
     if(0==model)
     {
         HEAD_ADDR=UBOOT_HEAD_ADDR;
     }
     else
     {
         HEAD_ADDR=KEBOOT_START_ADDR;
     }
     /*从启动地址读取版本头到ptVerFileHeadChar*/
     ulRet=BspFlashRead(HEAD_ADDR, ptVerFileHeadChar,sizeof(T_VerFileHeader));
     if(BSP_OK==ulRet)
     {
         ptVerFileHeader = (T_VerFileHeader *)ptVerFileHeadChar;
         ptVerFileHeader->ucVerNo[44-1]='\0';
         memcpy(headPtr,ptVerFileHeader->ucVerNo,strlen(ptVerFileHeader->ucVerNo)+1);
     }
     else
     {
         printf("\nRead BOOT Header error!\n");
     }
     free(ptVerFileHeadChar);
     ptVerFileHeadChar = NULL;
     ptVerFileHeader = NULL;
     return ulRet;
}

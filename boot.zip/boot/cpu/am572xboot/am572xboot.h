/**************************************************************************
 * 版权所有 (C)2001, 深圳市中兴通讯股份有限公司
 *
 * 文件名称: dra62xboot.h
 * 文件标识:
 * 内容摘要:
 * 其它说明:
 * 当前版本: ZXSDR BBUV120B01
 * 作    者: 
 * 完成日期:
 *
 * 修改记录1:
 *    修改日期: 2012年06月21日
 *    版 本 号: ZXSDR BBUV120B01
 *    修 改 人: 耿佳佳
 *    修改内容: 创建
 * 修改记录2:
 **************************************************************************/

#ifndef _DRA62XBOOT_H_
#define _DRA62XBOOT_H_

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

#define BSP_RAMDISK_LOAD_ADDR (0x85800000)
#define CFG_PROMPT	"3228->"


#define CRC_BIG_LITTLE_SWAP_LONG(x) \
	((unsigned int)( \
		(((unsigned int)(x) & (unsigned int)0x000000ffUL) << 24) | \
		(((unsigned int)(x) & (unsigned int)0x0000ff00UL) <<  8) | \
		(((unsigned int)(x) & (unsigned int)0x00ff0000UL) >>  8) | \
		(((unsigned int)(x) & (unsigned int)0xff000000UL) >> 24) ))

#define CRC_BIG_LITTLE_SWAP_USHORT(x) \
	((unsigned short)( \
		(((unsigned short)(x) & (unsigned short)0x00ff) << 8) | \
		(((unsigned short)(x) & (unsigned short)0xff00) >> 8) ))


#if defined(COMPILE_FOR_KEXEC_BOOT)

//#include <i2cbusti.h>
//#include <i2cbusapi.h>


/*--------------------------------------------------------------------------*/
/*  DRA62X  Memory                                                                                              */
/*--------------------------------------------------------------------------*/
#define INTERNAL_CTRLMOD_BASE_ADDR       (0x48140000)	
#define INTERNAL_CTRLMOD_MAP_SIZE        (0x00002000)

#define INTERNAL_GPIO0_BASE_ADDR         (0x48032000)
#define INTERNAL_GPIO1_BASE_ADDR         (0x4804C000)
#define INTERNAL_GPIO_MAP_SIZE           (0x00000200)


#define readb(addr) \
  ({ unsigned char __v = (*(volatile unsigned char *) (addr)); __v; })
#define readw(addr) \
  ({ unsigned short __v = (*(volatile unsigned short *) (addr)); __v; })
#define readl(addr) \
  ({ unsigned long __v = (*(volatile unsigned long *) (addr)); __v; })
    
#define writeb(b, addr) \
      (void)((*(volatile unsigned char *) (addr)) = (b))
#define writew(b, addr) \
      (void)((*(volatile unsigned short *) (addr)) = (b))
#define writel(b, addr) \
      (void)((*(volatile unsigned int *) (addr)) = (b))
     


#define MODULE_GROUP_ID_OFFSET                   (1<<3)
#define BOARD_GROUP_ID_OFFSET                    (1<<2)
#define BOARD_TYPE_ID_OFFSET                     (1<<1)
#define BOARD_HARD_CHANGE_ID_OFFSET              (1<<0)

#define CFG_CLK_FREQ		        20000000
#define LED_BASE_ADDR               0x40000
#define L4_SLOW_BASE_ADDR           0x48000000
#define L4_SLOW_VIRTUAL_BASE        0x98000000
#define WDT_REGS_SIZE               (4*1024)
#define WDT_BASE_ADDR               0x2E14000
#define WDT_FCLK_FREQ               32768
#define WDT_PTV                     0
#define WDT_PRE                     1
/* modify by qinfei ,将该宏的参数单位由s更改为100ms */
#define WDT_WLDR(sen)               (0xffffffff-(sen)*(WDT_FCLK_FREQ/(10*(1<<WDT_PTV)))+1)

#define WDT_WCLR_REG                0x24
#define WDT_WCRR_REG                0x28
#define WDT_WLDR_REG                0x2C
#define WDT_WDLY_REG                0x44
#define WDT_WSPR_REG                0x48
#define WDT_WTGR_REG                0x30
#define WDT_WWPS_REG                0x34

/*******************************内存定义************************************/
#define DRAM_4M                  (0x0400000)

#define DRAM_32M                 (0x02000000)
#define DRAM_64M                 (0x04000000)
#define DRAM_128M                (0x08000000)
#define DRAM_256M                (0x10000000)

#define LOCAL_MEM_LOCAL_ADRS     (0x00000000) /* 低端内存留给系统分配用 */
#define LOCAL_MEM_SIZE           DRAM_128M   /* 内存128M */
extern  unsigned long            g_ulBoardRamSize;

#define SYS_PHYS_MEM_TOP         (0x00600000)
#define OSS_MEM_SIZE             (0x00080000) 
#define BSP_MEM_SIZE             (0x00080000) 
#define BSP_VER_PROTECT_SIZE     (0x00400000)
#define APP_RESERVED_SIZE        (0x100000)
#define USER_RESERVED_SIZE       (OSS_MEM_SIZE + BSP_MEM_SIZE + BSP_VER_PROTECT_SIZE + APP_RESERVED_SIZE)

#define SYS_MEM_TOP              (SYS_PHYS_MEM_TOP - USER_RESERVED_SIZE)
#define USER_RESERVED_ADDR       (SYS_MEM_TOP)
#define APP_RESERVED_ADDR        (USER_RESERVED_ADDR + BSP_VER_PROTECT_SIZE)
#define OSS_MEM_ADDR             (APP_RESERVED_ADDR + APP_RESERVED_SIZE)
#define BSP_MEM_ADDR             (OSS_MEM_ADDR + OSS_MEM_SIZE)
#define BSP_VER_PROTECT_ADDR     (SYS_MEM_TOP)
#define APP_HR_RESERVED_SIZE   (0x10000)
#define APP_BOX_RESERVED_SIZE  (0x80000)
#define APP1_RESERVED_SIZE       APP_HR_RESERVED_SIZE
#define APP2_RESERVED_SIZE       APP_BOX_RESERVED_SIZE
/********************************保护区定义********************************/

#define PROTECT_ZONE_SIZE	           (ULONG)(33 * 1024 * 1024UL) /*保护区大小*/
/***************************** RTC bootflag定义******************************/
#define  FLAG_MEMBASE  0x94
#define  RTC_K0  0x6c
#define  RTC_K1  0x70
#define  RTC_K0_KEY  0x83E70B13
#define  RTC_K1_KEY   0x95A4F1E0

#define CFG_HZ	       			(1000)
#define CONFIG_SYS_HZ			CFG_HZ
#define CONFIG_MDIO_TIMEOUT	(3 * CONFIG_SYS_HZ)
#define BSP_E_POINTER_NULL                      (ERROR_BASE_BSP_COMMON + 0x0001)  /* 指针参数为空    */
#define BSP_E_REG_ACCESS_TIMEOUT     (ERROR_BASE_BSP_COMMON + 0x000c)
#define MODULEID_ADDR           0x1100000   
#define PROTECT_ZONE_OFFSET_MTD1  0x400000

/* Started by AICoder, pid:733f530fdfw6c59147ad0bf4d0344d1b62817c11 */
ULONG BootDebugMiiWrite(ULONG ulCsrClockRange, ULONG ulGR, ULONG ulPA, ULONG ulData);
extern int ushell_init();
ULONG BootDebugMiiRead(ULONG ulCsrClockRange, ULONG ulGR, ULONG ulPA, ULONG *pulData);
ULONG SetEthProMode(UCHAR ucValue);
ULONG BootWatchDogDisable(void);
unsigned long BootGetPhyLinkStatus(void);
VOID BootLedRun(UCHAR ucMode);
VOID boot_flag_set();
ULONG BootWatchDogEnable(void);
ULONG BootGetDownloadFlag(void);
ULONG BootSetWatchDogTime(ULONG ucTimerValue);
/* Ended by AICoder, pid:733f530fdfw6c59147ad0bf4d0344d1b62817c11 */
#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif
#endif

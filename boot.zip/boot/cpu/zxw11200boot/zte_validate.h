/* SPDX-License-Identifier: GPL-2.0+ */
/*
 * Copyright 2015 Freescale Semiconductor, Inc.
 */

#ifndef _ZTE_VALIDATE_H_
#define _ZTE_VALIDATE_H_

#include <linux/types.h>
#include "trustsvc.h"

#define WORD_SIZE 4

typedef unsigned int uint32_t;
typedef unsigned long long uint64_t;
typedef unsigned int u32;
typedef unsigned char uint8_t;
typedef unsigned int uintptr_t;
typedef unsigned char uchar;

/* Minimum and maximum size of RSA signature length in bits */
#define RSA_4K_KEY_SZ   4096
#define RSA_4K_KEY_SZ_BYTES   (RSA_4K_KEY_SZ/8)
#define RSA_2K_KEY_SZ   2048
#define RSA_2K_KEY_SZ_BYTES   (RSA_2K_KEY_SZ/8)
#define RSA_1K_KEY_SZ   1024
#define RSA_1K_KEY_SZ_BYTES   (RSA_1K_KEY_SZ/8)
#define RSA_3K_KEY_SZ   3072
#define RSA_3K_KEY_SZ_BYTES  (RSA_3K_KEY_SZ/8)

#define SHA256_BITS	256
#define SHA256_BYTES	(256/8)
#define NUM_HEX_CHARS	(sizeof(ulong) * 2)
#define MAX_SIGN_STRING_LEN 688

extern struct jobring jr;

/* Barker code size in bytes */
#define CSF_BARKER_LEN	4	/* barker code length in ESBC uboot client */
				/* header */


/* Maximum number of SG entries allowed */
#define MAX_SG_ENTRIES	8

typedef struct tagT_srk_table {
    uint32_t key_len;
    uint8_t pkey[2 * RSA_4K_KEY_SZ_BYTES];
}T_srk_table;

/* Srk table and key revocation check */
#define UNREVOCABLE_KEY 4
#define REVOC_KEY_ALIGN 3
#define MAX_KEY_ENTRIES 4

/*pub DER type,  rsa2048*/
const static char rsa2048_header[0x21] = {
0x30, 0x82, 0x1, 0x22, 0x30, 0xd, 0x6, 0x9, 0x2a, 0x86, 0x48, 0x86, 0xf7, 0xd, 0x1, 0x1,
0x1, 0x5, 0x0, 0x3, 0x82, 0x1, 0xf, 0x0, 0x30, 0x82, 0x1, 0xa, 0x2, 0x82, 0x1, 0x1,
0x0
};
/*pub DER type,  rsa3072*/
const static char rsa3072_header[0x21] = {
0x30, 0x82, 0x1, 0xa2, 0x30, 0xd, 0x6, 0x9, 0x2a, 0x86, 0x48, 0x86, 0xf7, 0xd, 0x1, 0x1,
0x1, 0x5, 0x0, 0x3, 0x82, 0x1, 0x8f, 0x0, 0x30, 0x82, 0x1, 0x8a, 0x2, 0x82, 0x1, 0x81,
0x0
};
/*pub DER type,  rsa4096*/
const static char rsa4096_header[0x21] = {
0x30, 0x82, 0x2, 0x22, 0x30, 0xd, 0x6, 0x9, 0x2a, 0x86, 0x48, 0x86, 0xf7, 0xd, 0x1, 0x1,
0x1, 0x5, 0x0, 0x3, 0x82, 0x2, 0x0f, 0x0, 0x30, 0x82, 0x2, 0x0a, 0x2, 0x82, 0x2, 0x1,
0x0
};
const static char rsa_tail[5] = {0x2, 0x3, 0x1, 0, 0x1 };
/*
 * This struct contains the following fields
 * length of the segment
 * Destination Target ID
 * source address
 * destination address
 */
struct sg_table {
    uint32_t len;           /* Length of Image */
    uint32_t res1;
    union {
        uint64_t src_addr;  /* SRC Address of Image */
        struct {
            uint32_t src_addr;
            uint32_t dst_addr;
        } img;
    };
};

/**
algorithm:
0 :    use to verity BOOT
1 :    use to veriry cpu swv
*/
#define CSF_CPUKEY_NUM      1
#define CSF_BOOTKEY_NUM     0
/**
algorithm:
algorithm: bit[0-15]:  pkey0
           bit[16-31]: pkey1
*  pkey[0-3]: encode  0: pkcs1.5  1:pcks2.1   
*  pkey[4-7]: hash   0: sha256
*  pkey[8-11]:encryption  0: rsa;   length of rsa depend on pubkey_len. support(2048,3072,4096)
*******
0x000: rsa, sha256, pkcs1.5;
0x001: rsa, sha256, pkcs2.1;
*******
*/
#define RSA2048_SHA256_PKCS21 1
#define RSA2048_SHA256_PKCS15 0
#define ZTE_SHA256  0
#define ENCRYPTION_RSA 0

/* CSF header for Chassis 2 */
struct csf_hdr {
	uint8_t barker[CSF_BARKER_LEN];	/* barker code */
	uint32_t version;
	uint32_t nv_counter;
	uint32_t algorithm;
	uint32_t parameters;
	union {
		uint32_t pkey;		/* public key offset */
		uint32_t srk_table_offset;
	};

	union {
		uint32_t key_len;		/* pub key length in bytes */
		struct {
			uint32_t srk_table_flag:8;
			uint32_t srk_sel:8;
			uint32_t num_keys:16;
		} len_kr;
	};

	uint32_t psign;		/* signature offset */
	uint32_t sign_len;		/* length of the signature in bytes */

    /* SG Table used by ISBC header */
    union {
        struct {
            uint32_t sg_table_offset; /* SG Table Offset */
            uint32_t sg_entries;    /* no of entries in SG table */
        } sg_isbc;
        struct {
            uint32_t reserved1; /* Reserved field */
            uint32_t img_size;  /* ESBC img size in bytes */
        } img;
    }; /*0x24*/

    uint32_t sg_flag;     /*0x2c ESBC img size in bytes */
    uint64_t img_addr;  /*0x28 64 bit pointer to ESBC Image */
    uint64_t entry_point;       /* 0x34 ESBC client entry point */
    uint32_t uid_flag; /*0x3c*/
    uint32_t zte_uid; /*0x40*/
    uint32_t oem_uid; /*0x44*/
    uint32_t reserved3[3]; /* total 0x50 */
};

/*
 * Calculate hash of input data
 */
int calc_data_hash(char *pdata, uint32_t pdata_ken, char *calc_hash, int pub_select);
/*
 * This function is used to signature verify.
 */
int rsa_auth_signature(char *phash, char* pkey, u32 pkey_len, char *psign, u32 psign_len);

/*
 * This function is used to validate the main esbc version
 */
int zte_secure_validate(uintptr_t csf_haddr);
/*
 * Authenticate by Non-Volatile counter
 *
 * To protect the system against rollback, the platform includes a non-volatile
 * counter whose value can only be increased. All certificates include a counter
 * value that should not be lower than the value stored in the platform. If the
 * value is larger, the counter in the platform must be updated to the new
 * value.
 *
 * Return: 0 = success, Otherwise = error
 */
int zte_auth_nvctr(uint32_t ui_counter);
/*
* get sign data from jSon file in protect flash
*/
u32 BspGetVersionSign(uchar *ucBuf, u32 ulFileLen, u32 ulFileCrc, uchar* ucSign, u32 *uiSign_len);
int ldPkeyFromCAheader(unsigned int csf_haddr, char *pub_key, unsigned int *pub_key_len);
/* Started by AICoder, pid:u5825g9777s9b471427708ecc08c97041d949cf9 */
int mbedtls_base64_decode( unsigned char *dst, size_t dlen, size_t *olen, const unsigned char *src, size_t slen );
int hash_finish_sha256(void *ctx, void *dest_buf, int size);
int hash_init_sha256(void **ctxp);
int hash_update_sha256(void *ctx, const void *buf, unsigned int size, int is_last);
/* Ended by AICoder, pid:u5825g9777s9b471427708ecc08c97041d949cf9 */
#endif

/**************************************************************************
 * 版权所有 (C)2001, 深圳市中兴通讯股份有限公司
 *
 * 文件名称: zxw11200boot.h
 * 文件标识:
 * 内容摘要:
 * 其它说明:
 * 当前版本: ZXSDR BBUV190B08
 * 作    者: 
 * 完成日期:
 *
 * 修改记录1:
 *    修改日期: 2019年04月10日
 *    版 本 号: ZXSDR BBUV190B08
 *    修 改 人: 李耀清
 *    修改内容: 创建
 * 修改记录2:
 *    修改日期: 2021年03月11日
 *    版 本 号:  
 *    修 改 人: 施佳炜
 *    修改内容: 将NXP移植进ZXW11200
 **************************************************************************/


#ifndef _ZXW11200BOOT_H_
#define _ZXW11200BOOT_H_

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

#include "bspcommonstdlog.h"

#define CONFIG_RECORD_TIME  //zxw11200 support record time node 

#define CRC_BIG_LITTLE_SWAP_LONG(x) \
    ((unsigned int)( \
        (((unsigned int)(x) & (unsigned int)0x000000ffUL) << 24) | \
        (((unsigned int)(x) & (unsigned int)0x0000ff00UL) <<  8) | \
        (((unsigned int)(x) & (unsigned int)0x00ff0000UL) >>  8) | \
        (((unsigned int)(x) & (unsigned int)0xff000000UL) >> 24) ))

#define CRC_BIG_LITTLE_SWAP_USHORT(x) \
    ((unsigned short)( \
        (((unsigned short)(x) & (unsigned short)0x00ff) << 8) | \
        (((unsigned short)(x) & (unsigned short)0xff00) >> 8) ))

#if defined(COMPILE_FOR_KEXEC_BOOT)

/*BL2_ZTE_HEAD_ADDR flash 中版本头位置, 0x40000/0x80000 - 0x80*/
#define MASTER_BL2_ZTE_HEAD_ADDR 0x3FF80
#define SLAVE_BL2_ZTE_HEAD_ADDR  0x7FF80
/*fip flash 烧写起始地址=版本头起始地址, 0x100000/0xE00000*/
#define MASTER_FIP_ZTE_HEAD_ADDR 0x100000
#define SLAVE_FIP_ZTE_HEAD_ADDR  0xE00000
/*keboot flash 烧写起始地址=版本头起始地址, 0x200000/0xF00000*/
#define MASTER_KEBOOT_ZTE_HEAD_ADDR 0x200000
#define SLAVE_KEBOOT_ZTE_HEAD_ADDR  0xF00000

#define PRODUCT_ID_0        13    //GP0_13
#define PRODUCT_ID_1        14    //GP0_14
#define APP_VER_ID_0        8     //GP2_8
#define APP_VER_ID_1        9     //GP2_9
#define DRAM_ID_0           10    //GP2_10
#define DRAM_ID_1           11    //GP2_11
#define CPU_LED_RUN         5     //GP2_5
#define CPU_LED_ALARM       23    //GP1_23
#define MS_GPIO_PIN         23    //GP1_23
#define MASTER_GPIO_FLAG    0x1
#define SLAVE_GPIO_FLAG     0x0
#define readb(addr) \
  ({ unsigned char __v = (*(volatile unsigned char *) (addr)); __v; })
#define readw(addr) \
  ({ unsigned short __v = (*(volatile unsigned short *) (addr)); __v; })
#define readl(addr) \
  ({ unsigned long __v = (*(volatile unsigned long *) (addr)); __v; })
    
#define writeb(b, addr) \
      (void)((*(volatile unsigned char *) (addr)) = (b))
#define writew(b, addr) \
      (void)((*(volatile unsigned short *) (addr)) = (b))
#define writel(b, addr) \
      (void)((*(volatile unsigned int *) (addr)) = (b))
      
#define MODULE_GROUP_ID_OFFSET                   (1<<3)
#define BOARD_GROUP_ID_OFFSET                    (1<<2)
#define BOARD_TYPE_ID_OFFSET                     (1<<1)
#define BOARD_HARD_CHANGE_ID_OFFSET              (1<<0)
/*******************************scu*************************************/
#define SOFT_SCU_ADDR         0x11f000         /*SCU_ADDR*/
#define HW_EVENT              0x4d0            /*HW_Event_Record,bit[0~3]为硬件复位原因*/
#define BOOT_FLA_REG          0x4d4            /*BOOT_FLA_REG*/
#define SW_EVENT4             0x4e4            /*SW_Event_Record_4,bit[0~3]为软件复位原因*/
/*******************************wtd*************************************/
#define SOFT_WTD_ADDR         0x11e000         /*SOFT_WTD_ADDR*/
#define SOFT_WTD_CR           0x0              /*Control Register*/
#define SOFT_WTD_TORR         0x4              /*Timeout Range Register*/
#define SOFT_WTD_CCVR         0x8              /*Current Counter Value Register*/
#define SOFT_WTD_CRR          0xc              /*Counter Restart Register*/
#define SOFT_WTD_STAT         0x10             /*Interrupt Status Register*/
#define SOFT_WTD_EOI          0x14             /*Interrupt Clear Register*/
#define SOFT_WTD_CLOCK        3125000          /*3.125MHZ @ ASIC*/
#define SOFT_WTD_MAX_TOP      15               /*There are 16 possible timeout values in 0..15*/
/*******************************pwm*************************************/
#define SOFT_PWM_PIN_MUX      0x120000         /*PWM_PIN_MUX setting*/
#define PWM0_FUNC             0x8bc            /*PWM_PIN_MUX setting*/
#define PWM1_FUNC             0x8c0            /*PWM_PIN_MUX setting*/
#define PWM2_FUNC             0x8c4            /*PWM_PIN_MUX setting*/
#define PWM3_FUNC             0x8c8            /*PWM_PIN_MUX setting*/
#define PWM4_FUNC             0x910            /*PWM_PIN_MUX setting*/
#define PWM5_FUNC             0x914            /*PWM_PIN_MUX setting*/
#define PWM6_FUNC             0x918            /*PWM_PIN_MUX setting*/
#define PWM7_FUNC             0x91c            /*PWM_PIN_MUX setting*/
#define SOFT_PWM_ADDR         0x11c000         /*SOFT_PWM_ADDR*/
#define SOFT_PWM_CR           0x8              /*Control Register*/
#define SOFT_PWM_COUNT1       0x0              /*Low period*/
#define SOFT_PWM_COUNT2       0xb0             /*High period*/

/*******************************UART*************************************/
/*UART SWITCH COM*/
#define SWITCH_UART_GPIO    14     //GP1_14

/*GPS POWER CTRL*/
#define GPS_AISG_RST_GPIO   0x2   //GP1_2
#define GPS_POWER_ON        1  
#define GPS_POWER_OFF       0
#define STATUS_DBG_UART     0
#define STATUS_GPS_UART     1

#ifdef CONFIG_ZXW11200_NTN
#define COM_INTERRUPT_NUM   0xa4            /* 串口中断号 */
#else
#define COM_INTERRUPT_NUM   0xa0            /* 串口中断号 */
#endif

/*******************************内存定义************************************/
#define DRAM_BASE_ADDR           (0x80000000) /*RAM 的基地址*/
#define CRL_APB_BASEADDR         (0x84010000)/*存放 boot flag地址 新双boot机制不需要*/
#define DRAM_4M                  (0x0400000)
#define DRAM_32M                 (0x02000000)
#define DRAM_64M                 (0x04000000)
#define DRAM_128M                (0x08000000)
#define DRAM_256M                (0x10000000)
#define DRAM_512M                (0x20000000)
#define DRAM_1024M               (0x40000000)

#define SYS_PHYS_MEM_TOP         (0x00600000)/*6M*/
#define OSS_MEM_SIZE             (0x00080000)/*512K*/ 
#define BSP_MEM_SIZE             (0x00080000) 
#define BSP_VER_PROTECT_SIZE     (0x00400000)/*4M*/
#define APP_RESERVED_SIZE        (0x100000)/*1M*/
#define USER_RESERVED_SIZE       (OSS_MEM_SIZE + BSP_MEM_SIZE + BSP_VER_PROTECT_SIZE + APP_RESERVED_SIZE)

#define SYS_MEM_TOP              (SYS_PHYS_MEM_TOP - USER_RESERVED_SIZE)
#define USER_RESERVED_ADDR       (SYS_MEM_TOP)
#define APP_RESERVED_ADDR        (USER_RESERVED_ADDR + BSP_VER_PROTECT_SIZE)
#define OSS_MEM_ADDR             (APP_RESERVED_ADDR + APP_RESERVED_SIZE)
#define BSP_MEM_ADDR             (OSS_MEM_ADDR + OSS_MEM_SIZE)
#define BSP_VER_PROTECT_ADDR     (SYS_MEM_TOP)
#define APP_HR_RESERVED_SIZE     (0x10000)
#define APP_BOX_RESERVED_SIZE    (0x80000)
#define APP1_RESERVED_SIZE       APP_HR_RESERVED_SIZE
#define APP2_RESERVED_SIZE       APP_BOX_RESERVED_SIZE

#define RESET_INFO_ADDR          (BSP_MEM_ADDR + 0x57C0)

#define BK_RESV_HIGH_MEM_ADDR                 0xCC000000  // 已和AC同事沟通预约从AC的256MB高端扣除64MB留作B&K等其他功能(物理内存基址:0x80000000=2G)
#define BOOTAPP_LOG_BASE_OFFSET               0x03D60000  // 规划出128KB用于boot CUR/BAK两段BOOTAPP LOG日志区，各64KB
#define BOOTAPP_LOG_PHY_ADDR                  (BK_RESV_HIGH_MEM_ADDR + BOOTAPP_LOG_BASE_OFFSET)
#define APP_LOG_BASE_OFFSET                   0x03E00000
#define APP_LOG_PHY_ADDR                      (BK_RESV_HIGH_MEM_ADDR + APP_LOG_BASE_OFFSET)
#define UBIFS_RO_LOG_ADDR                     0xCFCFF000

#define BK_RESV_HIGH_MEM_ADDR_1GB             0xBF200000  // 1010M-1018M 留作B&K使用(物理内存基址:0x80000000=2G)
#define BOOTAPP_LOG_BASE_OFFSET_1GB           0x00560000  // 规划出128KB用于boot CUR/BAK两段BOOTAPP LOG日志区，各64KB
#define BOOTAPP_LOG_PHY_ADDR_1GB              (BK_RESV_HIGH_MEM_ADDR_1GB + BOOTAPP_LOG_BASE_OFFSET_1GB)
#define APP_LOG_BASE_OFFSET_1GB               0x00600000
#define APP_LOG_PHY_ADDR_1GB                  (BK_RESV_HIGH_MEM_ADDR_1GB + APP_LOG_BASE_OFFSET_1GB)
#define UBIFS_RO_LOG_ADDR_1GB                 0xBF6FF000

#define APP_LOG_SIZE                          0x100000    // CPU CUR/BAK两段 APP LOG, 各1MB

#define LAST_KMSG_BASE_OFFSET                 0x03D80000
#define LAST_KMSG_ADDR                        (BK_RESV_HIGH_MEM_ADDR + LAST_KMSG_BASE_OFFSET)

#define LAST_KMSG_BASE_OFFSET_1GB             0x00580000
#define LAST_KMSG_ADDR_1GB                    (BK_RESV_HIGH_MEM_ADDR_1GB + LAST_KMSG_BASE_OFFSET_1GB)

#define LAST_KMSG_SIZE                        0x40000     // CPU CUR/BAK两段 LAST_KMSG, 各256KB

#ifdef CONFIG_ZXW11200_NTN
#define NTN_PRODUCTID 1
#define NTN_BOARD_A01 0
#define NTN_BOARD_2ND 1
#define NTN_BOARD_UNKNOWN -1

#define FS0_FORMAT_FLAG     (0x10000000 + 0x1B30000)
#define FS1_FORMAT_FLAG     (0x10000000 + 0x10000000 + 0x1B30000)
#define FS2_FORMAT_FLAG     (0x10000000 + 0x10000000 + 0x1B30004)
#endif
/********************************Flash 规划定义********************************/

#define MODULEID_ADDR           0x1b20000
#define PROTECT_ZONE_OFFSET_MTD1  0x4b0000

/********************************ntn B01 C01 ata2 格式化结果 定义********************************/
/* Started by AICoder, pid:018421acbbe1707144150a8720abaf0c8c95ba83 */
#if defined(CONFIG_ZXW11200_NTN) && defined(CONFIG_MULTI_FILESYSTEM)
#define FILESYSTEM_FORMAT_FLAG  0xfbad0000  // 文件系统格式标志
#define FORMAT_SUCCESS          0x00000000  // 格式化成功的标志
#define FORMAT_ERROR            0x00000fff  // 格式化失败的标志
#endif
/* Ended by AICoder, pid:018421acbbe1707144150a8720abaf0c8c95ba83 */

enum zxw11200_module_cfg_t
{
    DDR_1GB = 0,
    RESV_MEM,
};

#ifdef __cplusplus
}
#endif /* __cplusplus */
#endif
/**************************************************************************
*                         外部函数声明
**************************************************************************/
extern VOID MainLoop ();
extern int ushell_init();
extern ULONG BootFlashInit(VOID);
extern ULONG BootSoftModInit(void);
extern ULONG BootBoardSetReset(ULONG ulMode, ULONG ulWtd);
extern UINT32 BspZxw11200SetGpioDir(UINT32 Bank, UINT32 Port, UINT32 Bit, BOOL bIsOutput);
extern UINT32 BspZxw11200SetGpioDataOut(UINT32 Bank, UINT32 Port,UINT32 Bit, BOOL bHigh);
extern UINT32 BspZxw11200GetGpioDatain(UINT32 Bank, UINT32 Port,UINT32 Bit);
extern UINT32 Zxw11200GpioMmap(UINT32 bus);
extern ULONG BspGetBootSoftVersion(CHAR *pcBootSoftVer,UCHAR ucSizeofBytes);
extern ULONG BootAttachUartCom(void);
extern void BootSwitchUartCom(int index);
extern unsigned char BootGetUartCom(void);
/* Started by AICoder, pid:g742fe6d3aq226e142860b0ba0461a0e4e51aa46 */
extern VOID BootSysMsDelay(ULONG ulDelay);
/* Ended by AICoder, pid:g742fe6d3aq226e142860b0ba0461a0e4e51aa46 */
/**************************************************************************
*                        全局函数声明
**************************************************************************/
ULONG SetDefaultCmdline();
/*Debug Cmd*/
ULONG BootGetMemVir();
VOID BootLedRun(UCHAR ucMode);
ULONG BootGetFsRecoverFlag(VOID);
ULONG BootWatchDogEnable(VOID);
ULONG BootWatchDogDisable(VOID);
ULONG BootInnerWatchDogDisable(VOID);
ULONG BootGetPhyLinkStatus(VOID);
ULONG BootGetVersion(char *headPtr,char model);
ULONG BootSetWatchDogTime(int timeout);
ULONG BootDebugMiiRead(ULONG ulCsrClockRange,ULONG ulGR, ULONG ulPA, ULONG *pulData);
ULONG BootDebugMiiWrite(ULONG ulCsrClockRange,ULONG ulGR, ULONG ulPA, ULONG ulValue);
INT SetEthProMode(UCHAR ucValue);
ULONG getLastKmsgAddr(VOID);
ULONG getAppLogPhyAddr(VOID);
ULONG getFsLogPhyAddr(VOID);
ULONG BootFlagGet(VOID);
VOID SaveKebootLog(VOID);
VOID SaveKebootBakLog(VOID);
VOID SaveKebootCurLog(VOID);
UINT32 BootGetBoardHwResetType(VOID);
UINT32 BootGetBoardSwResetType(VOID);
UCHAR* BootGetBoardResetInfoAddr(VOID);
int zxw11200_is_config(unsigned int zxw11200_module, unsigned int boardId);
VOID boot_flag_set();
/* Started by AICoder, pid:kc309j4831ebd2c14217082880809e0f5c94f22f */
ULONG BspMknod(const char * filepath, const char *oprator, const char *majornew, const char* minornew);
/* Started by AICoder, pid:0ab4708ef37e582142ba093dd05a390d3742d646 */
unsigned int ms_flag(void);
UINT32 BootGetDownloadFlag(void);
/* Ended by AICoder, pid:0ab4708ef37e582142ba093dd05a390d3742d646 */
#if defined(CONFIG_ZXW11200_NTN)
int get_ntn_board_type();
void boot_report(uint8_t status);
#endif
#ifdef CONFIG_MULTI_FILESYSTEM
ULONG BootGetFsRecoverFlag_Multi(unsigned int dwIndex);
#endif
#endif

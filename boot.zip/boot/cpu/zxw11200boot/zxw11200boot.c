/*****************************************************************************
* 版权所有(C) 2010, ZTE Corp. RRU Bsp Platform
*----------------------------------------------------------------------------
* 模 块 名 : BSP
* 文件名称 : zxw11200.c
* 文件标识 : {[N/A]}
* 内容摘要 : zxw11200 cpu bootapp接口实现
* 注意事项 : 无
* 作    者 : 耿佳佳
* 创建日期 : 2015-10-22 08:28:34
* 当前版本 : Ver1.0
*----------------------------------------------------------------------------
* 变更记录 :
*
* $记录1
* 变 更 单: $0000000(N/A)
* 责 任 人: 耿佳佳
* 修改日戳: 2015-10-22 08:28:34
* 变更说明: 创建文件
* $记录2
* 变 更 单: $0000000(N/A)
* 责 任 人: 李耀清
* 修改日戳: 2018-08-30 13:44:00
* 变更说明: 将MPSOC系列boot修改为NXP ls10x3a系列boot
* $记录2
* 变 更 单: $0000000(N/A)
* 责 任 人: 施佳炜
* 修改日戳: 2021-03-11 13:44:00
* 变更说明: 将NXP ls10x3a系列boot修改为ZXW11200系列boot
*----------------------------------------------------------------------------
*/

#include "stdio.h"
#include <sys/types.h>
#include <sys/stat.h>
#include <netinet/in.h>
#include <fcntl.h>
#include <errno.h>
#include "vxadp.h"

#include "bsppub.h"
#include "bspcomm.h"
#include "pub_typedef.h"
#include "bsperrcode.h"
#include "zxw11200boot.h"
#if defined(COMPILE_FOR_KEXEC_BOOT)
#include "bootadp.h"
#endif

#include <string.h>
#include <linux/mii.h>
#include <sys/socket.h>
#include <sys/ioctl.h>
#include <net/if.h>
#include <linux/types.h>
#include <time.h>
#include "zxw11200gpio.h"
#include "ubifs.h"
/* Started by AICoder, pid:gefa3l218e5a104144d10b267024af0ba1519786 */
#include "flash.h"
/* Ended by AICoder, pid:gefa3l218e5a104144d10b267024af0ba1519786 */
#ifdef CONFIG_ZXW11200_NTN
#include <protocol.h>
#endif

/**************************************************************************
*                        宏
**************************************************************************/
extern UCHAR g_ucCmdLine[256];
#ifdef COMPILE_FOR_KEXEC_BOOT
#define reteck(ret)                                                \
    if(ret < 0)                                                \
        {                                                          \
            zte_printf_s("error! \"%s\" : line: %d\n", __func__, __LINE__); \
            return BSP_ERROR;                                         \
        }

#define ret_check(ret, fd)                                                \
    if(ret < 0)                                                \
        {                                                          \
            close(fd);                                                          \
            zte_printf_s("error! \"%s\" : line: %d\n", __func__, __LINE__); \
            return BSP_ERROR;                                         \
        }

#define KDA_DEVICE_NAME "/dev/misc/KernDrvAgt"

/**************************************************************************
*                         数据类型                                       *
**************************************************************************/


/**************************************************************************
*                         全局变量定义                                   *
**************************************************************************/
static int g_iKdaDrvFd = -1;
/*从内核获取*/
ULONG  g_ulRamReservedAddr =0;

static ULONG aulPwmPinMux=0;
static ULONG aulScuAddr=0;
static ULONG aulPwmAddr=0;
static ULONG aulWtdAddr=0;
/**
* Watchdog time-out period counter value , total 16 levels
* 100ms 200ms 500ms 1s 2s 5s 10s 30s 60 120 240 300 360 420 480 600s
*/
ULONG wtd_cnt[] = {
    0x0004C4B4, 0x00098968, 0x0017D784, 0x002FAF08,
    0x005F5E10, 0x00EE6B28, 0x01DCD650, 0x059682F0,
    0x0B2D05E0, 0x165A0BC0, 0x2CB41780, 0x37E11D60,
    0x430E2340, 0x4E3B2920, 0x59682F00, 0x6FC23AC0,
};
/**************************************************************************
*                         外部变量声明
**************************************************************************/

/**************************************************************************
*                         函数实现
**************************************************************************/


/*****************************************************************************
*  函数名称   : BspGetCpuType(*)
*  功能描述   : 双boot模块用于获取cpu类型
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : 无
*  输出参数   : 无
*  返 回 值   : 成功 - BSP_OK
*  其它说明   : 
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A), yam@2014-10-09 14:07:25 创建
*  $0000000(N/A), lyq@2018-11-14 09:48:00 修改，platform/bsp/include/bsppub.h中新添加NXPCPU型号
*----------------------------------------------------------------------------
*/
UINT32 BspGetCpuType (UCHAR *pucCpuType)    
{ 
    if (NULL == pucCpuType)
        return BSP_ERROR_NULL_POINTER;
    /* 这里和bsppub.h保持一致 */
    *pucCpuType = BSP_ZXW11200;
    return BSP_OK;
}

/* Started by AICoder, pid:f7454r7e9at0d6d14957097d20679325bbd2a7d7 */
unsigned int ms_flag(VOID)
{   
    #ifdef CONFIG_ZXW11200_NTN
    return MASTER_GPIO_FLAG;
    #else
    static unsigned int msFlag = 0xFF;
    if(msFlag == 0xFF)
    {
        /* 设置GPIO为输入 */
        BspZxw11200SetGpioDir(ZXW11200_GPIO_BANK1 ,ZXW11200_GPIO_PORTA, MS_GPIO_PIN, ZXW11200_GPIO_DDR_IN);
        /*获取主从标志   1：主片 ；0: 从片*/
        msFlag = BspZxw11200GetGpioDatain(ZXW11200_GPIO_BANK1, ZXW11200_GPIO_PORTA, MS_GPIO_PIN);
        if(msFlag != SLAVE_GPIO_FLAG)
        {
            /*主片还原为输出高*/
            BspZxw11200SetGpioDir(ZXW11200_GPIO_BANK1 ,ZXW11200_GPIO_PORTA, MS_GPIO_PIN, ZXW11200_GPIO_DDR_OUT);
        }
        zte_printf_s("msFlag = %d\n", msFlag);
    }
    return msFlag;
    #endif
}
/* Ended by AICoder, pid:f7454r7e9at0d6d14957097d20679325bbd2a7d7 */

/*****************************************************************************
*  函数名称   : BootWatchDogEnable(*)
*  功能描述   : 使能软件喂狗
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : 无
*  输出参数   : 无
*  返 回 值   : 成功 - BSP_OK
*  其它说明   : 无
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A), 宋飞@2011-11-25 11:15:46
*  $0000000(N/A), 李耀清@2018-10-18 16:02:00，nxp修改为外部cpld实现
*  $0000000(N/A), 施佳炜@2021-03-11 10:37:00
*----------------------------------------------------------------------------
*/
ULONG BootWatchDogEnable(VOID)
{
    /* 开启外部看门狗，开启外部看门狗与切换dbg uart为同一GPIO */
    /* Started by AICoder, pid:y14c8n3c43n592314d6d088c40baf401ad2575b5 */
    if(SLAVE_GPIO_FLAG != ms_flag())
    {
        BootSwitchUartCom(STATUS_DBG_UART);
    }
    /* Ended by AICoder, pid:y14c8n3c43n592314d6d088c40baf401ad2575b5 */
    writel( 0x3, aulWtdAddr + SOFT_WTD_CR);
    return BSP_OK;
}
/*****************************************************************************
*  函数名称   : BootWatchDogRestart(*)
*  功能描述   : 使软件喂狗重新计时
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : 无
*  输出参数   : 无
*  返 回 值   : 成功 - BSP_OK
*  其它说明   : 无
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A), 施佳炜@2021-03-11 11:15:46
*----------------------------------------------------------------------------
*/

ULONG BootWatchDogRestart(VOID)
{
    writel(0x76, aulWtdAddr + SOFT_WTD_CRR);
    return BSP_OK;
}
/*****************************************************************************
*  函数名称   : BootInWatchDogDisable(*)
*  功能描述   : 关闭内部看门狗
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : 无
*  输出参数   : 无
*  返 回 值   : 成功 - BSP_OK
*  其它说明   : 无
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A), 施佳炜@2022-10-17 16:00:00
*----------------------------------------------------------------------------
*/
ULONG BootInnerWatchDogDisable(VOID)
{
    /* feed once anyway */
    BootWatchDogRestart();
    /* 关闭内部看门狗 */
    writel(0x1, aulWtdAddr + SOFT_WTD_CR);
    return BSP_OK;
}
/*****************************************************************************
*  函数名称   : BootWatchDogDisable(*)
*  功能描述   : 去使能软件喂狗
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : 无
*  输出参数   : 无
*  返 回 值   : BSP_OK 
*  其它说明   : 无
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A), 宋飞@2011-11-25 11:15:46
*  $0000001(N/A), 姜建奎@2013-12-13 16:04:27 加入支持FPGA 看门狗
*  $0000002(N/A), 李耀清@2018-09-11 14:57:00 修改ULONG为char,由于看门狗SR地址不能
                被4、8整除，地址指针不能用ULONG强制转换
*  $0000003(N/A), 施佳炜@2021-03-11 10:37:00
*----------------------------------------------------------------------------
*/
ULONG BootWatchDogDisable(VOID)
{
    BootInnerWatchDogDisable();
    /* 关闭外部看门狗，关闭外部看门狗与切换gps uart为同一GPIO */
    /* Started by AICoder, pid:d4f31eb07ehc3cf1490609e0407a400956e6188b */
    if(SLAVE_GPIO_FLAG != ms_flag())
    {
        BootSwitchUartCom(STATUS_GPS_UART);
    }
    /* Ended by AICoder, pid:d4f31eb07ehc3cf1490609e0407a400956e6188b */
    return BSP_OK;
}

/*****************************************************************************
*  函数名称   : BspSetWatchDogTime(*)
*  功能描述   : 设置看门狗喂狗时间
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : ulTimerValue - 写入硬件喂狗的时间，以s为单位
*  输出参数   : 无
*  返 回 值   : 成功 - BSP_OK
*  其它说明   : 无
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A), 宋飞@2011-11-25 11:15:46
*  $0000000(N/A), 李耀清@2018-10-18 15:52:00 ,NXP 修改为外部CPLD 实现
*  $0000000(N/A), 施佳炜@2021-03-11 10:39:00
*----------------------------------------------------------------------------
*/
ULONG BootSetWatchDogTime (int timeout)
{
    int idx = 0, top_v = SOFT_WTD_MAX_TOP;
    if (0 > timeout || 600 < timeout)
    {
        zte_printf_s("wtd timeout error, should be [0,600]s\n");
        return BSP_ERROR;
    }
    for(idx = 0; idx <= SOFT_WTD_MAX_TOP; idx++)
    {
        if((wtd_cnt[idx]/SOFT_WTD_CLOCK) >= timeout)
        {
            top_v = idx;
            break;
        } 
    }

    /* set wt */
    writel(top_v, aulWtdAddr + SOFT_WTD_TORR);
    BootWatchDogEnable();
    BootWatchDogRestart();
    return BSP_OK;
}

/**********************************************************************
* 函数名称:VOID BootAppWatchDogInit()
* 功能描述:bootapp初始化看门狗
* 输入参数:无
* 输出参数:
* 返 回 值:BSP_OK:成功;BSP_ERROR:失败
* 其它说明:网线连通bootapp main入口到下次内核启动完成计时约20s。bsp接口单位100ms，
        设置看门狗时间100s，100s到达前MGR接管，否则看门狗复位
* 修改日期        版本号     修改人          修改内容
* -----------------------------------------------
* 2015-10-22       V1.0       00086970             创建
***********************************************************************/
ULONG BootWatchDogInit()
{
    ULONG ulRet = BSP_ERROR;
    ulRet = BootSetWatchDogTime(120);/*120s*/
    return ulRet;
}
/**********************************************************************
* 函数名称:ULONG BootGetMiiLinkStatus()
* 功能描述:获取debug网口连通状态
* 输入参数:
* 输出参数:
* 返 回 值:0:连通，1:断开 ;BSP_ERROR:失败
* 其它说明:用于检测debug网口的物理链路通断状态
* 修改日期        版本号     修改人          修改内容
* -----------------------------------------------
* 2015-10-22       V1.0       00086970             创建
***********************************************************************/ 
ULONG BootGetMiiLinkStatus(VOID)
{
    struct ifreq ifr;
    int ret;
    int sockfd;
    memset(&ifr, 0, sizeof(ifr));
    strncpy(ifr.ifr_name,"eth0", IFNAMSIZ - 1);
    sockfd = socket(PF_LOCAL, SOCK_DGRAM, 0);
    reteck(sockfd);
    ret = ioctl(sockfd,SIOCGIFFLAGS, (char*)&ifr);
    ret_check(ret, sockfd);
    zte_printf_s("\nifr_flags: 0x%x\n",ifr.ifr_flags);
    close(sockfd);
    if(ifr.ifr_flags & IFF_RUNNING)	
    {
        zte_printf_s("Link Status:is Running\n");	
        return 0;
    }
    else
    {
        zte_printf_s("Link Status:is Down\n");	
        return 1;		
    }
}

/*****************************************************************************
*  函数名称   : BootDevMemMap()
*  功能描述   : 使用mmap将物理地址映射到用户进程虚拟地址空间
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : 无
*  输出参数   : 无
*  返 回 值   : BSP_OK, 其它值为失败
*  其它说明   :
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A), 田瑞忠@2010-5-19 8:52:25  创建
*  $0000000(N/A), 李耀清@2018-9-12 9:36:00  修改为NXP LS10X3A系列
*  $0000000(N/A), 施佳炜@2021-3-11 13:55:00 修改为ZXW11200系列
*----------------------------------------------------------------------------
*/
#define DRAM_1024M          (0x40000000) 
ULONG BootDevMemMap(VOID)
{
    /* 打开内存设备的文件描述符 */
    int      iFd;
    int     iSpaceProt = PROT_READ | PROT_WRITE;
    ULONG   iCount = 0;
#define TO_MAP_LIST(a)      #a, &a
    /*lint -e529*/
    /*lint -e64*/
    /* Started by AICoder, pid:ue012jbfd0l3032144f009ce104ad000ef5671aa */
    struct map_list_t {
        const char *pucVarName;
        UINT32 *pulVarAddr;
        ULONG ulMapBase;
        ULONG ulMapSize;
    }
    /* Ended by AICoder, pid:ue012jbfd0l3032144f009ce104ad000ef5671aa */
    map_list[] = {
        {TO_MAP_LIST(g_ulRamReservedAddr),(DRAM_BASE_ADDR+ DRAM_1024M -SYS_PHYS_MEM_TOP),SYS_PHYS_MEM_TOP},/* ZXW11200各单板统一预留高端内存起始地址：1018M*/
        {TO_MAP_LIST(aulScuAddr),SOFT_SCU_ADDR,0x1000},/*wtd基址的 mmap*/
        {TO_MAP_LIST(aulWtdAddr),SOFT_WTD_ADDR,0x100},/*wtd基址的 mmap*/
        {TO_MAP_LIST(aulPwmPinMux),SOFT_PWM_PIN_MUX,0x1000},/*pwm基址的 mmap*/
        {TO_MAP_LIST(aulPwmAddr),SOFT_PWM_ADDR,0x100},/*pwm基址的 mmap*/
    };
    /*lint +e529*/
    /*lint +e64*/
    #define DO_ADDR_MAP(a)                                          \
        *((a)->pulVarAddr) = (ULONG)mmap(0, (a)->ulMapSize,          \
            iSpaceProt, MAP_SHARED, iFd, (a)->ulMapBase);           \
        if (*((a)->pulVarAddr) == -1)                               \
        {                                                           \
            dbgErr("mmap %s failed %s, %d\n",                       \
                (a)->pucVarName, strerror(errno), errno);           \
            close(iFd);                                             \
            return BSP_ERROR;                                       \
        }                                                           \
        dbgInfo("%-20s = %#lx.0x%lx\n", (a)->pucVarName, *((a)->pulVarAddr),(a)->ulMapBase);

    /* 打开存储空间映射 */
    if ((iFd = open("/dev/mem", O_RDWR | O_SYNC)) < 0)
    {
        dbgErr("open /dev/mem failed\n");
        return BSP_ERROR;
    }
    for (iCount = 0; iCount < sizeof(map_list)/sizeof(map_list[0]); iCount++)
    {
        DO_ADDR_MAP(&map_list[iCount]);
        usleep(1000);
    }

    close(iFd);
    return BSP_OK;
}
#if defined(CONFIG_RECORD_TIME)
/*****************************************************************************
*  函数名称   : BootGetMemVir(*)
*  功能描述   : 获取此CPU映射的高端内存上电时间基地址
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : 无
*  输出参数   : 无
*  返 回 值   : 上电计时高端内存对应的基地址
*  其它说明   : 
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A), 李耀清@2019-1-17 16:03:00 
*----------------------------------------------------------------------------
*/
ULONG BootGetMemVir()
{
    if (NULL == g_ulRamReservedAddr)
    {
        zte_printf_s("Error: g_ulRamReservedAddr is NULL!!\n");
        return 0;
    }
    return (g_ulRamReservedAddr+SYS_PHYS_MEM_TOP-BSP_MEM_SIZE+0x8000);/*1018M+6M-512K+32K*/
}
#endif
/**********************************************************************
* 函数名称： BootGetMorS
* 功能描述： MIO14指示当前分支
* 输入参数： 无
* 输出参数： 无
* 返 回 值： 0:RGMII(FAD) 1:SGMII(5G2.0)
* 其它说明： 
* 修改日期        版本号     修改人	      修改内容
* -----------------------------------------------
* 2012/07		   V1.0	     ZKH	  
* 2018/9/12                  10242265 lyq  NXP没有实现，默认返回0 
* 2021/4/25                  10262604 sjw  ZXW11200没有实现，默认返回0   
***********************************************************************/
ULONG BootGetDownloadFlag(void)
{   
    if(SLAVE_GPIO_FLAG == ms_flag())
    {
        return 1;   /*U6G 4C做从*/
    }
    else
    {
        return 0;
    }

}
/**********************************************************************
* 函数名称:ULONG BootGetPhyLinkStatus()
* 功能描述:获取SGMII网口连通状态
* 输入参数:
* 输出参数:
* 返 回 值:0:连通，1:断开 ;
* 其它说明:用于检测debug网口的物理链路通断状态
* 修改日期        版本号     修改人          修改内容
* -----------------------------------------------
* 2015-10-22       V1.0       00086970             创建
* 2018-11-06       V1.0       10242265          修改为NXP平台
* 2021-04-25       V1.0       10262604          修改为ZXW11200平台
***********************************************************************/ 
ULONG BootGetPhyLinkStatus(VOID)
{

    return BootGetMiiLinkStatus();
}

/******************************************************************************
*  函数名称   : BspLedCtrl(*)
*  功能描述   : 实现对面板灯的控制
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : ulLedName   - 灯名, 定义于BspPublic.h文件或者BoardApi.h文件
                ulLedMode - 灯状态的控制
*  输出参数   : 无
*  返 回 值   : BSP_OK, 操作成功; BSP_ERROR_INVALID_PARA, 输入参数错误
*  其它说明   : 无
*  函数属性   : 基础接口
*工装使用申明: 工装使用接口，请注意波及
*------------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A), 鲁侃@2010-06-21 17:28:12 创建
*  $0000000(N/A), 王茂金@2010-10-28 9:48:11 根据实际硬件和统一接口要求修改代码
*  $0000000(N/A), 崔文会@2011-01-25 9:48:11 根据实际硬件和统一接口要求修改代码
*  $0000000(N/A), 李耀清@2018-11-13 14:42:00 修改，NXP 使用EPLD控灯，保留接口
*  $0000000(N/A), 施佳炜@2021-04-25 14:33:00 修改，ZXW11200使用PWM和GPIO控灯
*------------------------------------------------------------------------------
*/
ULONG BootLedCtrl(ULONG ulLedname, ULONG ulLedMode)
{
    ULONG  ulRet = 0;

    switch (ulLedname)
    {
        case BSP_LED_ID_RUN: /* LedRun 低电平亮，高电平灭*/
            {
                if( BSP_LED_OP_OFF == ulLedMode )
                {
                    ulRet = BspZxw11200SetGpioDataOut(ZXW11200_GPIO_BANK2 ,ZXW11200_GPIO_PORTA ,CPU_LED_RUN ,1);
                }
                else if( BSP_LED_OP_ON == ulLedMode )
                {
                    ulRet = BspZxw11200SetGpioDataOut(ZXW11200_GPIO_BANK2 ,ZXW11200_GPIO_PORTA ,CPU_LED_RUN ,0);
                }
                if(BSP_ERROR == ulRet)
                {
                    return BSP_ERROR;
                }
                ulRet |= BspZxw11200SetGpioDir(ZXW11200_GPIO_BANK2, ZXW11200_GPIO_PORTA, CPU_LED_RUN, ZXW11200_GPIO_DDR_OUT);
                break;    
            }
        case BSP_LED_ID_ALM: /*LedAlm 低电平亮，高电平灭 */
            {
                if( BSP_LED_OP_OFF == ulLedMode )
                {
                    ulRet = BspZxw11200SetGpioDataOut(ZXW11200_GPIO_BANK1 ,ZXW11200_GPIO_PORTA ,CPU_LED_ALARM ,1);
                }
                else if( BSP_LED_OP_ON == ulLedMode )
                {
                    ulRet = BspZxw11200SetGpioDataOut(ZXW11200_GPIO_BANK1 ,ZXW11200_GPIO_PORTA ,CPU_LED_ALARM ,0);
                }
                if(BSP_ERROR == ulRet)
                {
                    return BSP_ERROR;
                }
                ulRet |= BspZxw11200SetGpioDir(ZXW11200_GPIO_BANK1 ,ZXW11200_GPIO_PORTA ,CPU_LED_ALARM ,ZXW11200_GPIO_DDR_OUT);
                break;
            }
        default:
            {
                return BSP_ERROR_DEVICE_NOT_EXIST;
            }
    }
    return ulRet;
}

/******************************************************************************
* 函数名称： PwmCtlLedRun
* 功能描述： ioctl控制RUN灯
* 输入参数：
*
* 输出参数： 无
* 返 回 值： 无
* 其它说明：
*
* 修改日期        版本号     修改人           修改内容
* ---------------------------------------------------------------
*
******************************************************************************/
/*宏定义*/

int PwmCtlLedRun(int flag)
{
    if(1 == flag){
        BootLedCtrl(BSP_LED_ID_RUN, BSP_LED_OP_OFF);
        writel(0x0, aulPwmAddr + SOFT_PWM_CR + 7*0x14);
        writel(0x17d7840, aulPwmAddr + SOFT_PWM_COUNT1 + 7*0x14);
        writel(0x17d7840, aulPwmAddr + SOFT_PWM_COUNT2 + 7*0x4);
        writel(0xf, aulPwmAddr + SOFT_PWM_CR +  7*0x14);
    }
    else if(0 == flag){
        writel(0x0, aulPwmAddr + SOFT_PWM_CR);
        BootLedCtrl(BSP_LED_ID_RUN, BSP_LED_OP_ON);
    }
    else{
        zte_printf_s("PwmCtlLedRun, input flag:%d error\n", flag);
    }
    return 0;
}

/**************************************************************************
* 函数名称: PwmLedRun
* 功能描述: BOOTAPP阶段PWM模式控制RUN灯
* 输入参数: 无
* 输出参数:
* 返 回 值: 无
* 其它说明:
*
* 修改日期:    版本号     修改人        修改内容
* -----------------------------------------------
* 2018-10-30     V1.0      田雨        Created
**************************************************************************/
VOID PwmLedRun(UCHAR ucMode)
{
    if(1 == ucMode)
    {
        PwmCtlLedRun(1);/*PWM控制RUN灯闪烁*/
    }
    else if(0 == ucMode)
    {
        PwmCtlLedRun(0);/*PWM控制RUN常亮*/
    }
}

VOID BootLedBling(VOID)
{
    ;
}

VOID BootLedTask(VOID)
{
    ;
}

/**********************************************************************
* 函数名称:void led_run(unsigned char ucMode)
* 功能描述:led_run led灯闪烁模式
* 输入参数: ucMode  0 只亮run灯,  1 run灯周期性闪
* 输出参数:无。
* 返 回 值:无
* 其它说明:
* 修改日期        版本号     修改人          修改内容
* -----------------------------------------------
* 2015/10/12            V1.0            00086970                       创建
* 2018/11/13            V1.0            10242265                       修改，NXP使用cpld控灯，这里bootapp启动，以及工装时需要调用到。
* 2021/04/20            V1.0            10262604                       修改，ZXW11200使用gpio和pwm控灯，这里bootapp启动，以及工装时需要调用到。
***********************************************************************/
VOID BootLedRun(UCHAR ucMode)
{

    if(0 == ucMode)/*只亮run灯,其他灯灭 */
    {
        PwmLedRun(0);
        BootLedCtrl(BSP_LED_ID_ALM, BSP_LED_OP_OFF);
    }
    else if(1 == ucMode)/*run灯周期性闪烁*/
    {
        BootLedCtrl(BSP_LED_ID_ALM, BSP_LED_OP_OFF);
        PwmLedRun(1);
    }
    else
    {
        zte_printf_s("BootLedRun, input params[%d] error\n", ucMode);
    }
}

/**************************************************************************
* 函数名称： BootGetUartCom\BootSwitchUartCom\BootSetGpsPower\
* 功能描述：
* 输入参数： 无
* 输出参数： 
* 返 回 值：
* ------------------------------------------------------
* 其它说明：
* 修改日期     版本号     修改人	     修改内容
* 2020/06/16         V1.0                                  创建
* 2021/04/27         V2.0
**************************************************************************/
unsigned char BootGetUartCom(void)
{
    UINT32 tmp = 0;
    tmp = BspZxw11200GetGpioDatain(ZXW11200_GPIO_BANK1, ZXW11200_GPIO_PORTA, SWITCH_UART_GPIO);
    return tmp;
}

void BootSwitchUartCom(int index)
{
    BootSysMsDelay(5);// wait previous log zte_printf_s done
    BspZxw11200SetGpioDataOut(ZXW11200_GPIO_BANK1, ZXW11200_GPIO_PORTA, SWITCH_UART_GPIO, index);
    BspZxw11200SetGpioDir(ZXW11200_GPIO_BANK1, ZXW11200_GPIO_PORTA, SWITCH_UART_GPIO, ZXW11200_GPIO_DDR_OUT);
    BootSysMsDelay(5);// delay for next log zte_printf_s 
}

void BootSetGpsPower(unsigned char flag)
{
    BspZxw11200SetGpioDataOut(ZXW11200_GPIO_BANK1, ZXW11200_GPIO_PORTA, GPS_AISG_RST_GPIO, flag);
    BspZxw11200SetGpioDir(ZXW11200_GPIO_BANK1, ZXW11200_GPIO_PORTA, GPS_AISG_RST_GPIO, ZXW11200_GPIO_DDR_OUT);
}

ULONG BootGpioInit(VOID)
{
    unsigned char i = 0;
    ULONG ulRet = BSP_ERROR;
    /*bank 0 ~ 2*/
    for(i = 0; i <= ZXW11200_GPIO_BANK_MAX ; i++)
    {
        ulRet = Zxw11200GpioMmap(i);
        if(BSP_ERROR == ulRet)
        return ulRet;
    }
    /*PRODUCT_ID_0 & PRODUCT_ID_1*/
    BspZxw11200SetGpioDir(ZXW11200_GPIO_BANK0, ZXW11200_GPIO_PORTA, PRODUCT_ID_0, ZXW11200_GPIO_DDR_IN);
    BspZxw11200SetGpioDir(ZXW11200_GPIO_BANK0, ZXW11200_GPIO_PORTA, PRODUCT_ID_1, ZXW11200_GPIO_DDR_IN);
    /*APP_VER_ID_0 & APP_VER_ID_1*/
    BspZxw11200SetGpioDir(ZXW11200_GPIO_BANK2, ZXW11200_GPIO_PORTA, APP_VER_ID_0, ZXW11200_GPIO_DDR_IN);
    BspZxw11200SetGpioDir(ZXW11200_GPIO_BANK2, ZXW11200_GPIO_PORTA, APP_VER_ID_1, ZXW11200_GPIO_DDR_IN);
    /*DRAM_ID_0 & DRAM_ID_1*/
    BspZxw11200SetGpioDir(ZXW11200_GPIO_BANK2, ZXW11200_GPIO_PORTA, DRAM_ID_0, ZXW11200_GPIO_DDR_IN);
    BspZxw11200SetGpioDir(ZXW11200_GPIO_BANK2, ZXW11200_GPIO_PORTA, DRAM_ID_1, ZXW11200_GPIO_DDR_IN);
    /*default DBG UART*/
    /* Started by AICoder, pid:k2df3b2b23ua1b214d2d0861c082710adee59090 */
    if(SLAVE_GPIO_FLAG != ms_flag())/*需主从判断，从 不操作GPIO切换UART*/
    {
        BootSwitchUartCom(STATUS_DBG_UART);
    }
    /* Started by AICoder, pid:k2df3b2b23ua1b214d2d0861c082710adee59090 */
    /*预设RUN灯常亮，ALARM灯灭*/
    BootLedRun(0);
    /*GPS 下电*/
    BootSetGpsPower(GPS_POWER_OFF); //gps power down
    return ulRet;
}

VOID PwmPinMuxSet(VOID)
{
    /*RUN灯为PWM7，其他按需打开*/
    //writel(0x1, aulPwmPinMux + PWM0_FUNC);
    //writel(0x1, aulPwmPinMux + PWM1_FUNC);
    //writel(0x1, aulPwmPinMux + PWM2_FUNC);
    //writel(0x1, aulPwmPinMux + PWM3_FUNC);
    //writel(0x1, aulPwmPinMux + PWM4_FUNC);
    //writel(0x1, aulPwmPinMux + PWM5_FUNC);
    //writel(0x1, aulPwmPinMux + PWM6_FUNC);
    writel(0x1, aulPwmPinMux + PWM7_FUNC);
}
/*****************************************************************************
*  函数名称   : BootBoardHwPreInit()
*  功能描述   : Bsp单板预初始化函数
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : 无
*  输出参数   : 无
*  返 回 值   : BSP_OK, 其它值为失败
*  其它说明   : 无
*工装使用申明: 无
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A), 崔文会@2012-11-22 16:35:09, 创建
*----------------------------------------------------------------------------
*/
ULONG BootBoardHwPreInit(VOID)
{
    ULONG ulRet = BSP_OK;
    ulRet|=BootGpioInit();            /*GPIO初始化*/
    PwmPinMuxSet();                   /*pin mux switch to pwm function*/
    BootLedRun(1);
    return ulRet;
}

/**************************************************************************
* 函数名称： SetEthProMode
* 功能描述： 设置ETH的模式寄存器的混杂模式控制位
* 输入参数： 0--对进入的帧的目的地址进行检查。1--对进入的帧的目的地址不进行检查。
* 输出参数： 无
* 返 回 值： 
* -------------------------------------------------------
* 其它说明： 
* 修改日期     版本号        修改人	            修改内容
* 2015/10/22     V1.0         00086970           创建
* 2018/9/27                   10242265          修改为IOCTL形式控制网口
**************************************************************************/
INT SetEthProMode(UCHAR ucValue)
{ 
    int ulRet=0; 
    int sockfd;	
    struct ifreq ifr;
    memset(&ifr, 0, sizeof(ifr));
    strncpy(ifr.ifr_name,"eth0", IFNAMSIZ - 1);
    sockfd = socket(PF_LOCAL, SOCK_DGRAM, 0);
    reteck(sockfd);
    ulRet=ioctl(sockfd, SIOCGIFFLAGS, &ifr);
    ret_check(ulRet, sockfd);
    if (ucValue == 0)
    /*对进入的帧的目的地址进行检查*/
    {
    ifr.ifr_flags &= ~IFF_PROMISC;
    }
    /*对进入的帧的目的地址不进行检查*/
    else
    {
        ifr.ifr_flags |= IFF_PROMISC;
    }

    ulRet=ioctl(sockfd, SIOCSIFFLAGS, &ifr); 
    ret_check(ulRet, sockfd);
    close(sockfd);
    return ulRet;     
}

ULONG memflag_set(UCHAR writeval)
{
    ULONG reg_value;
    reg_value = *((volatile UINT32 *)(aulScuAddr + BOOT_FLA_REG)) & 0xffffff00;
    *((volatile UINT32 *)(aulScuAddr + BOOT_FLA_REG)) = (writeval | reg_value);
    zte_printf_s("memflag_set=0x%x\n", writeval);
    return 0;
}

ULONG BootFlagGet()
{
    ULONG readval;
    readval = *((volatile UINT32 *)(aulScuAddr + BOOT_FLA_REG)) & 0xff;
    return readval;
}

VOID boot_flag_set()
{
    ULONG check_flag=0;
    check_flag = BootFlagGet();
    
    zte_printf_s("check_flag = 0x%x\n",check_flag);


    if(check_flag==MASTER_BOOT_OK)  /*本次是上电或者复位后第一次启动,启动主boot成功*/
    {
        memflag_set(MASTER_KUBOOT_OK);
        /*尚欠写高端内存表征主boot启动成功标志*/
    }
    else if(check_flag==MASTER_KUBOOT_OK) /*启动主boot成功，继续尝试引导CPU版本*/
    {
        memflag_set(MASTER_KUBOOT_OK);
        /*尚欠写高端内存表征主boot启动成功标志*/
    }
    else if(check_flag==SLAVE_BOOT_OK)  /*启动从boot成功，*/
    {
        memflag_set(SLAVE_KUBOOT_OK);
        /*尚欠写高端内存表征从boot启动成功标志*/
    }
    else if(check_flag==SLAVE_KUBOOT_OK)   /*启动从boot成功，继续尝试引导CPU版本*/
    {
        memflag_set(SLAVE_KUBOOT_OK);
        /*尚欠写高端内存表征从boot启动成功标志*/
    }
    return;
}

/**********************************************************************
* 函数名称:BootDebugMiiRead
* 功能描述:通过内核Kda驱动读PHY C22
* 输入参数: *  - udCsrClockRange：CSR 时钟区域
*     - udGR： GMII寄存器
*     - udPA： PHY设备物理层地址
*     - pudData：需要读出的数据的地址
* 输出参数:
* 返 回 值:
* 其它说明:
* 修改日期        版本号     修改人          修改内容
* -----------------------------------------------
* 2019-4-19       V1.0      lyq             创建
***********************************************************************/
ULONG BootDebugMiiRead(ULONG ulCsrClockRange,ULONG ulGR, ULONG ulPA, ULONG *pulData)
{
    if(g_iKdaDrvFd < 0)
    {
        zte_printf_s("Kda device is not open!!\n");
        return BSP_ERROR;
    }
    kda_ioctl_t mdio = {0};
    mdio.d0 = ulPA;
    mdio.d1 = ulGR;
    if (ioctl(g_iKdaDrvFd, KDA_MDIO_READ_COMMON, &mdio))
    {
        zte_printf_s("KDA_MDIO_READ_COMMON ioctrl error!!!\n");
        return BSP_ERROR;
    }
    *pulData = (unsigned int)mdio.d2;
    return BSP_OK;
}
/**********************************************************************
* 函数名称:BootDebugMiiWrite
* 功能描述:通过内核Kda驱动写PHY C22
* 输入参数: *     - udCsrClockRange：CSR 时钟区域
*     - udGR： GMII寄存器
*     - udPA： PHY设备物理层地址
*     - pudData：需要读出的数据的地址
* 输出参数:
* 返 回 值:
* 其它说明:
* 修改日期        版本号     修改人          修改内容
* -----------------------------------------------
* 2019-4-19       V1.0      lyq             创建
***********************************************************************/
ULONG BootDebugMiiWrite(ULONG ulCsrClockRange,ULONG ulGR, ULONG ulPA, ULONG ulValue)
{
    if(g_iKdaDrvFd < 0)
    {
        zte_printf_s("Kda device is not open!!\n");
        return BSP_ERROR;
    }
    kda_ioctl_t mdio = {0};
    mdio.d0  =  ulPA;
    mdio.d1  =  ulGR;
    mdio.d2  =  ulValue;
    if (ioctl(g_iKdaDrvFd, KDA_MDIO_WRITE_COMMON, &mdio))
    {
        zte_printf_s("KDA_MDIO_WRITE_COMMON ioctrl error!!!\n");
        return BSP_ERROR;
    }
    return BSP_OK;
}

unsigned int UpdateFirstBoot(void)
{
    return BSP_OK;
}

/**********************************************************************
* 函数名称： BootGetFsRecoverFlag
* 功能描述： 从高端内存获取用户态文件系统异常标志
* 输入参数： 无
* 输出参数： 无
* 返 回 值： 0:正常 0xdeadbeaf:异常
* 其它说明： 获取后清除 
* 修改日期        版本号     修改人	      修改内容
* -----------------------------------------------
* 2012/07		   V1.0	     ZKH	      
***********************************************************************/
ULONG BootGetFsRecoverFlag(VOID)
{   
    ULONG ulUbifsFormat_mask = 0;
    ulUbifsFormat_mask = *(ULONG *)FS_FORMAT_FLAG;
    memset((CHAR*)FS_FORMAT_FLAG, 0, 4);/* 清空 */

    return ulUbifsFormat_mask;
}

#ifdef CONFIG_MULTI_FILESYSTEM
ULONG BootGetFsRecoverFlag_Multi(unsigned int dwIndex)
{   
    ULONG ulUbifsFormat_mask = 0;
    UINT32 data = 0xFFFFFFFF;
    UINT32 offset = FS0_FORMAT_FLAG; 

    switch(dwIndex)
    {
        case 0:
            offset = FS0_FORMAT_FLAG;
            break;
        case 1:
            offset = FS1_FORMAT_FLAG;
            break;
        case 2:
            offset = FS2_FORMAT_FLAG;
            break;
        default:
            printf("Unknown filesystem index\n");
            return -1;
    }

    /* Started by AICoder, pid:d368bi461au0280140b7087760e3c205c591def7 */
    BspFlashRead(offset, (UCHAR *)&ulUbifsFormat_mask, 4);
    /* Ended by AICoder, pid:d368bi461au0280140b7087760e3c205c591def7 */
    ulUbifsFormat_mask = ntohl(ulUbifsFormat_mask);
    if(FS_ABNORMAL_MAGIC_NUM == ulUbifsFormat_mask)
    {
        /* Started by AICoder, pid:qea60l44fbmc249143970980e0953e07c19141f0 */
        BspFlashWrite(offset, (UCHAR *)&data, 4);
        /* Ended by AICoder, pid:qea60l44fbmc249143970980e0953e07c19141f0 */
    }

    return ulUbifsFormat_mask;
}
#endif

/**********************************************************************
* 函数名称：BootGetVersion
* 功能描述： 读取Flash中boot版本号
* 输入参数： headPtr需要获取到版本的指针，默认不使用，除非传入非空指针，model:0 获取一级Boot版本，1 获取二级keboot版本
* 输出参数： 无
* 返 回 值： 0:正常  非0:异常
* 其它说明： 获取后清除
* 修改日期        版本号     修改人	      修改内容
* 修改日期     版本号        修改人	            修改内容
* ---------------------------------------------------
* 2015/10/22     V1.0         10242265           创建
***********************************************************************/
ULONG BootGetVersion(char *headPtr,char model)
{
    ULONG ulRet=0;
    ULONG HEAD_ADDR=0;
    ULONG check_flag=0;
    unsigned char  *ptVerFileHeadChar = NULL;
    T_VerFileHeader *ptVerFileHeader = NULL;
    if(NULL==headPtr)
    {
        return BSP_ERROR;
    }
    ptVerFileHeadChar = (unsigned char *)malloc(sizeof(T_VerFileHeader));
    if (NULL == ptVerFileHeadChar)
    {
        zte_printf_s("malloc error!!\n");
        return -1;
    }
    check_flag = BootFlagGet();
    if(0x22 == check_flag)
    {
        if(0==model)
        {
            HEAD_ADDR=MASTER_BL2_ZTE_HEAD_ADDR;
        }
        else if(1==model)
        {
            HEAD_ADDR=MASTER_FIP_ZTE_HEAD_ADDR;
        }
        else
        {
            HEAD_ADDR=MASTER_KEBOOT_ZTE_HEAD_ADDR;
        }
    }
    else if(0x44 == check_flag)
    {
        if(0==model)
        {
            HEAD_ADDR=SLAVE_BL2_ZTE_HEAD_ADDR;
        }
        else if(1==model)
        {
            HEAD_ADDR=SLAVE_FIP_ZTE_HEAD_ADDR;
        }
        else
        {
            HEAD_ADDR=SLAVE_KEBOOT_ZTE_HEAD_ADDR;
        }
    }
    else
    {
        free(ptVerFileHeadChar);
        ptVerFileHeadChar = NULL;
        return BSP_ERROR;
    }
    /*从启动地址读取版本头到ptVerFileHeadChar*/
    ulRet=BspFlashRead(HEAD_ADDR, ptVerFileHeadChar,sizeof(T_VerFileHeader));
    if(BSP_OK==ulRet)
    {
        ptVerFileHeader = (T_VerFileHeader *)ptVerFileHeadChar;
        ptVerFileHeader->ucVerNo[44-1]='\0';
        memcpy(headPtr,ptVerFileHeader->ucVerNo,strlen(ptVerFileHeader->ucVerNo)+1);
    }
    else
    {
        zte_printf_s("\nRead BOOT Header error!\n");
    }
    free(ptVerFileHeadChar);
    ptVerFileHeadChar = NULL;
    ptVerFileHeader = NULL;
    return ulRet;
}
/**************************************************************************
* 函数名称： Get**ID
* 功能描述： 获取单板上下拉的IO电平
* 输入参数： 无
* 输出参数： **id的值
* 返 回 值：
* ------------------------------------------------------
* 其它说明：
* 修改日期     版本号     修改人	     修改内容
* 2021/04/25         V1.0                                  创建
**************************************************************************/
unsigned char GetProductId (void)
{
    static unsigned char ucProductId = 0xFF;

    if(0xFF == ucProductId)
    {
        ucProductId  = (unsigned char)BspZxw11200GetGpioDatain(ZXW11200_GPIO_BANK0, ZXW11200_GPIO_PORTA, PRODUCT_ID_0);
        ucProductId |= (unsigned char)BspZxw11200GetGpioDatain(ZXW11200_GPIO_BANK0, ZXW11200_GPIO_PORTA, PRODUCT_ID_1)<<1;
        zte_printf_s("ProductId = %d\n", ucProductId);
    }
    return ucProductId;
}

unsigned char GetAppId (void)
{
    static unsigned char ucAppId = 0xFF;

    if(0xFF == ucAppId)
    {
        ucAppId  = (unsigned char)BspZxw11200GetGpioDatain(ZXW11200_GPIO_BANK2, ZXW11200_GPIO_PORTA, APP_VER_ID_0);
        ucAppId |= (unsigned char)BspZxw11200GetGpioDatain(ZXW11200_GPIO_BANK2, ZXW11200_GPIO_PORTA, APP_VER_ID_1)<<1;
        zte_printf_s("AppId = %d\n", ucAppId);
    }
    return ucAppId;
}

unsigned char GetDramId (void)
{
    static unsigned char ucDramId = 0xFF;
    if(0xFF == ucDramId)
    {
        ucDramId  = (unsigned char)BspZxw11200GetGpioDatain(ZXW11200_GPIO_BANK2, ZXW11200_GPIO_PORTA, DRAM_ID_0);
        ucDramId |= (unsigned char)BspZxw11200GetGpioDatain(ZXW11200_GPIO_BANK2, ZXW11200_GPIO_PORTA, DRAM_ID_1)<<1;
        zte_printf_s("DramId = %d\n", ucDramId);
    }

    return ucDramId;
}

/* 1：需要配置
   0：不配置  */
int zxw11200_is_config(unsigned int zxw11200_module, unsigned int boardId)
{
    int iRet = 0;

    switch(zxw11200_module)
    {
        case DDR_1GB:
            if(0x1 == GetDramId())
                iRet = 1;
            break;
        default:
            break;
    }

    return iRet;
}

#ifdef CONFIG_ZXW11200_NTN
int get_ntn_board_type()
{
    static int ntn_board_type = NTN_BOARD_UNKNOWN;
    if(ntn_board_type == NTN_BOARD_UNKNOWN)
    {
        if(NTN_PRODUCTID == GetProductId())
        {
            unsigned char appid = GetAppId();
            switch(appid){
                case 0:
                    ntn_board_type = NTN_BOARD_A01;
                    break;
                case 1:
                    ntn_board_type = NTN_BOARD_2ND;
                    break;
                default:
                    ntn_board_type = NTN_BOARD_UNKNOWN;
                    break;
            }
        }
    }

    return ntn_board_type;
}

void boot_report(uint8_t status)
{
    if(NTN_BOARD_A01 == get_ntn_board_type())
        boot_report_1st(status);
    else
        boot_report_2nd(status);
}

#endif
/**************************************************************************
* 函数名称： get_uart_rx_byte
* 功能描述： 获取/proc/tty/driver/serial 中rx的值，得到串口累积输入
* 输入参数： 无
* 输出参数： 串口累积rx
* 返 回 值：
* ------------------------------------------------------
* 其它说明：
* 修改日期     版本号     修改人	     修改内容
* 2018/11/03         V1.0                                  创建
**************************************************************************/
unsigned int get_uart_rx_byte()
{
    char *line = NULL;
    FILE *fp = NULL;
    char *index = NULL;
    unsigned int value_curr = 0;
    unsigned int len = 0;
    fp = fopen("/proc/tty/driver/serial","r");
    if(fp ==  NULL)
    {
        zte_printf_s("open /proc/tty/driver/serial error\n");
        return 0;
    }
    while((getline(&line,&len,fp)) != -1)
    {
        index = strstr(line,"rx:");
        if(index != NULL)
        {
            sscanf_s((char *)(index+strlen("rx:")),"%d",&value_curr);
            break;
        }
    }
    fclose(fp);
    return value_curr;
}

/**************************************************************************
* 函数名称： BootAttachUartCom
* 功能描述： 探测GRPS 串口是否有数据
* 输入参数： 无
* 输出参数： 探测到有持续输入：返回BSP_OK ,否者返回BSP_ERROR
* 返 回 值：
* ------------------------------------------------------
* 其它说明：
* 修改日期     版本号     修改人	     修改内容
* 2018/11/03         V1.0                                  创建
**************************************************************************/
/* Started by AICoder, pid:056c1a6aa7s73af147650b24c096b23f72f37263 */
ULONG BootAttachUartCom()
{
    unsigned long long delay_tick = 0;
    unsigned long long delay_start = tick64Get();
    unsigned int base_count = 0;
    unsigned int abort_count=0;
    if(SLAVE_GPIO_FLAG != ms_flag())
    {
        BootSetGpsPower(GPS_POWER_OFF); //gps power down
        BootSwitchUartCom(STATUS_GPS_UART);
        base_count = get_uart_rx_byte();
        do{
            //zte_printf_s("\r  Hit any key to enter uart console [GPS Com:%d/20]\r  ",abort_count);
            //fflush(stdout);
            delay_tick = (tick64Get() - delay_start) * 10;
            BootSysMsDelay(10);
            abort_count = get_uart_rx_byte()-base_count;
            if(abort_count >= 15)
            {
                zte_printf_s("\n Please enter bs\n\n");
                return BSP_OK;
            }
        } while(delay_tick <= 1000ULL);
        zte_printf_s("\n\n");
        BootSwitchUartCom(STATUS_DBG_UART);//restory defaule uart
    }
    return BSP_ERROR;
}
/* Ended by AICoder, pid:056c1a6aa7s73af147650b24c096b23f72f37263 */
const char randombuf[]={34,36,38,60,37,62,37,96,94,58,61,61,126,58,64,34,63,63,94,35,0,0};/* "$&<%>%`^:==~:@"??^# */

void BootPrintNoteMesgOnce()
{
    static char lock=0;

    if(0==lock)
    {
        BootSetGpsPower(GPS_POWER_OFF);//gps power down
        BootSwitchUartCom(STATUS_GPS_UART);
        zte_printf_s("%s\n",randombuf);
        BootSwitchUartCom(STATUS_DBG_UART);//restory defaule uart
        lock = 1;
    }
}

ULONG getLastKmsgAddr(VOID)
{
    if(1 == zxw11200_is_config(DDR_1GB, 0))
    {
        return LAST_KMSG_ADDR_1GB;
    }
    else
    {
        return LAST_KMSG_ADDR;
    }
}

ULONG getAppLogPhyAddr(VOID)
{
    if(1 == zxw11200_is_config(DDR_1GB, 0))
    {
        return APP_LOG_PHY_ADDR_1GB;
    }
    else
    {
        return APP_LOG_PHY_ADDR;
    }
}
ULONG getFsLogPhyAddr(VOID)
{
    if(1 == zxw11200_is_config(DDR_1GB, 0))
    {
        return UBIFS_RO_LOG_ADDR_1GB;
    }
    else
    {
        return UBIFS_RO_LOG_ADDR;
    }
}

static ULONG getBootAppLogPhyAddr(VOID)
{
    if(1 == zxw11200_is_config(DDR_1GB, 0))
    {
        return BOOTAPP_LOG_PHY_ADDR_1GB;
    }
    else
    {
        return BOOTAPP_LOG_PHY_ADDR;
    }
}

UINT32 BootGetBoardHwResetType(VOID)
{
    UINT32 ret = 0;
    ret = readl(aulScuAddr + HW_EVENT);
    return ret;
}

UINT32 BootGetBoardSwResetType(VOID)
{
    UINT32 ret = 0;
    ret = readl(aulScuAddr + SW_EVENT4);
    return ret;
}

/* Started by AICoder, pid:kdd46la707z79ea140de080380ba440c511457b8 */
UCHAR* BootGetBoardResetInfoAddr(VOID)
{
    return (UCHAR*)(g_ulRamReservedAddr + RESET_INFO_ADDR);
}
/* Ended by AICoder, pid:kdd46la707z79ea140de080380ba440c511457b8 */

VOID SaveKebootBakLog(VOID)
{
    BspSaveBootKmsgLog(BAK_LOG);
    BspSaveBootAppLog(BAK_LOG);
}

VOID SaveKebootCurLog(VOID)
{
    BspSaveBootKmsgLog(CUR_LOG);
    BspSaveBootAppLog(CUR_LOG);
}
/*bs住后的手动转储请用SaveKebootLog,产生4份,使每份log序号保持一致*/
VOID SaveKebootLog(VOID)
{
    SaveKebootBakLog();
    SaveKebootCurLog();
}

/*****************************************************************************
*  函数名称   : OpenKdaModel
*  功能描述   : 打开KDA模块，并初始化全局文件描述符
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : 无
*  输出参数   : 无
*  返 回 值   : 
*  其它说明   : 
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A), 10242265@2019-04-10      创建
*----------------------------------------------------------------------------
*/
static ULONG OpenKdaModel(void)
{
    int ret;
    BspMknod(KDA_DEVICE_NAME,"c","10","244");
    if ((g_iKdaDrvFd = open(KDA_DEVICE_NAME,O_RDWR | O_SYNC )) < 0)
    {
        zte_printf_s("open " KDA_DEVICE_NAME " failed!");
        return BSP_ERROR;
    }
    
    ret = BspPhyAddrToKernel((unsigned long long)getBootAppLogPhyAddr(), COM_INTERRUPT_NUM, g_iKdaDrvFd);
    if(ret != BSP_OK)
    {
        zte_printf_s("BspPhyAddrToKernel failed!\n");
        return BSP_ERROR;
    }

    return BSP_OK;
}

ULONG BootSetslavechipIpMacAddr(VOID)
{
    int ret;
    UCHAR cmdBuf[256] = {0};
    /* Started by AICoder, pid:p5b1ara12ei492014c340b25e0f53816f408faac */
    ret = zte_snprintf_s((char *)cmdBuf, sizeof(cmdBuf), "ifconfig eth1 hw ether 40:00:c6:21:21:40");
    SNPRINTF_S_CHECK(ret, sizeof(cmdBuf));
    BspSystem((char *)cmdBuf);
    ret = zte_snprintf_s((char *)cmdBuf, sizeof(cmdBuf), "ifconfig eth1 198.33.33.64 netmask 255.255.0.0");
    SNPRINTF_S_CHECK(ret, sizeof(cmdBuf));
    BspSystem((char *)cmdBuf);
    ret = zte_snprintf_s((char *)cmdBuf, sizeof(cmdBuf), "route add -net 198.33.0.0 netmask 255.255.0.0 dev eth1");
    SNPRINTF_S_CHECK(ret, sizeof(cmdBuf));
    BspSystem((char *)cmdBuf);
    ret = zte_snprintf_s((char *)cmdBuf, sizeof(cmdBuf), "route add -net 198.33.33.100 netmask 255.255.255.255 gw 198.33.33.102 eth1");
    SNPRINTF_S_CHECK(ret, sizeof(cmdBuf));
    BspSystem((char *)cmdBuf);
    ret = zte_snprintf_s((char *)cmdBuf, sizeof(cmdBuf), "arp -s 198.33.33.102 40:00:c6:21:21:66");
    SNPRINTF_S_CHECK(ret, sizeof(cmdBuf));
    BspSystem((char *)cmdBuf);
    ret = zte_snprintf_s((char *)cmdBuf, sizeof(cmdBuf), "ifconfig eth1 up");
    SNPRINTF_S_CHECK(ret, sizeof(cmdBuf));
    BspSystem((char *)cmdBuf);
    /* Ended by AICoder, pid:p5b1ara12ei492014c340b25e0f53816f408faac */
    return BSP_OK;
}

static ULONG BootBoardPreInit(VOID)
{
    ULONG ulRet = BSP_ERROR;
    zte_printf_s("\n BootBoardPreInit. \n");
    ulRet |= BootDevMemMap(); /*物理地址到虚拟地址映射，高端内存、看门狗映射*/
    ulRet |= BootBoardHwPreInit();  /*LED初始化、GPIO BANK映射、PWM pin mux 设置*/
    ulRet |= OpenKdaModel();  /*打开Kda设备，初始化设备描述符*/
    ulRet |= BootFlashInit();

    /*ZXW11200_U6G slave download cur7.swv from master*/
    if(SLAVE_GPIO_FLAG == ms_flag())
    {
        BootSetslavechipIpMacAddr();
    }

    return ulRet;    
}

/*****************************************************************************
*  函数名称   : main(*)
*  功能描述   : bootapp程序处理主函数
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : argc   - 参数个数
                argv[] - 参数列表
*  输出参数   : 无
*  返 回 值   : 0为成功, 其余失败
*  其它说明   :
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A), 00086970 @2015-10-28
*----------------------------------------------------------------------------
*/
int main(int argc, char *argv[])
{
    int iBootAppTaskID = 0;
    ULONG ulRet = 0;  
    unsigned char ucTimeout = 5;  
    ulRet |= BootBoardPreInit();
    ulRet |= BootWatchDogInit();

    ulRet |= (ULONG)ushell_init();
    ulRet |= BootSoftModInit();

    /* Started by AICoder, pid:rc8f9i5dbfs3f9f14ec6094c60972e08aad93bf2 */
    if(SLAVE_GPIO_FLAG != ms_flag())
    {
        while (ucTimeout)
        {
            if(0 == BootGetPhyLinkStatus())
            {
                break;
            }
            ucTimeout--;
            sleep(1);
            BootPrintNoteMesgOnce();
        }
    }
    /* Ended by AICoder, pid:rc8f9i5dbfs3f9f14ec6094c60972e08aad93bf2 */
    iBootAppTaskID = taskSpawn("tBootTask",   \
        100, /* priority */            \
        0,   /* option   */           \
        0x1000,/* stack size */      \
        (FUNCPTR)MainLoop, 0, 0, 0, 0, 0, 0, 0, 0 ,0,0);
        /* Started by AICoder, pid:38be4ue6feob92c14ae10ae930dc630467d1c06b */
        (void)iBootAppTaskID; // 告诉编译器：我知道这个变量没用
        /* Ended by AICoder, pid:38be4ue6feob92c14ae10ae930dc630467d1c06b */
    while(1)
    {
        //BspFunction("/boot.out", CFG_PROMPT);
        sleep(20);
    }
    return ulRet;

}
#endif

ULONG SetDefaultCmdline()
{
    /* Started by AICoder, pid:3cb9cm3ff6tae1d14fef080ef0bd260a3e643377 */
    strncpy((char *)g_ucCmdLine,"earlycon console=ttyS0,115200n8 root=/dev/ram0 rw irqchip.gicv3_pseudo_nmi=1 pcie_pme=nomsi pcie_hp=nomsi uio_pdrv_genirq.of_id=eth-uio mem=1018M",256);
    /* Ended by AICoder, pid:3cb9cm3ff6tae1d14fef080ef0bd260a3e643377 */
    zte_printf_s("/proc/cmdline error,load default cmdline.\n");
    return BSP_OK;
}
// SPDX-License-Identifier: GPL-2.0+
/*
 * Copyright 2015 Freescale Semiconductor, Inc.
 */

#include <zte_validate.h>
#include <malloc.h>
#include <bignum.h>
#include "cJSON.h" 
#include <string.h>

static uintptr_t g_haddr;
static uint32_t ui_nv_counter;
static uint32_t ui_csf_version;
static uint32_t algorithm_cpu;
static uint32_t algorithm_boot;
static uint32_t alg_param;

#define CHECK_KEY_LEN(key_len)	(((key_len) == 2 * RSA_3K_KEY_SZ_BYTES) || \
				 ((key_len) == 2 * RSA_4K_KEY_SZ_BYTES) || \
				 ((key_len) == 2 * RSA_2K_KEY_SZ_BYTES))

static char hash_val[SHA256_BYTES] = {0};

static const char barker_code[CSF_BARKER_LEN] = { 0x5a, 0x54, 0x45, 0x48 };
/*validate secure boot dbg flag*/
int g_boot_validate_dbg = 0;

void boot_validate_dbg(unsigned int uiEnable)
{
	if(uiEnable)
		g_boot_validate_dbg=1;
	else
		g_boot_validate_dbg=0;
}
/*
*  get nv counter from csf_header
*/
static uint32_t zte_get_csf_nv_counter(uintptr_t csf_haddr)
{
	struct csf_hdr *hdr = (struct csf_hdr *)csf_haddr;
	return hdr->nv_counter;
}
/*
*  get version from csf_header
*/
static uint32_t zte_get_csf_version(uintptr_t csf_haddr)
{
	struct csf_hdr *hdr = (struct csf_hdr *)csf_haddr;
	return hdr->version;
}
/*
*  get algorithm from csf_header
*/
static uint32_t zte_get_algorithm(uintptr_t csf_haddr, int pub_select)
{
	uint32_t uialg=0;

	struct csf_hdr *hdr = (struct csf_hdr *)csf_haddr;
	if(pub_select == CSF_BOOTKEY_NUM) {
		uialg = (hdr->algorithm)&0xffff;
	}else if(pub_select == CSF_CPUKEY_NUM){
		uialg = (hdr->algorithm >> 16)&0xffff;
	}else{
		printf("input pub select error!\n");
		uialg = 0xffff;
	}

	return uialg;
}
/*
*  get alg_param from csf_header
*/
static uint32_t zte_get_alg_param(uintptr_t csf_haddr)
{
	struct csf_hdr *hdr = (struct csf_hdr *)csf_haddr;
	return hdr->parameters;
}
/*
 * Calculate hash of input data
 */
int calc_data_hash(char *pdata, uint32_t pdata_len, char *calc_hash, int pub_select)
{
	void *ctx;
	uint32_t hash_alg=0;
	const char *algo_name = NULL;
	int ret = 0;

	if(pub_select == CSF_BOOTKEY_NUM)
	    hash_alg = (algorithm_boot&0xf0) >> 4;
	else if(pub_select == CSF_CPUKEY_NUM)
		hash_alg = (algorithm_cpu&0xf0) >> 4;

	if(ZTE_SHA256 == hash_alg) {
		algo_name = "sha256";
	} else {
		printf("csf header input algorithm error\n");
		return -1;
	}
	/* Started by AICoder, pid:q1c190da5432c03147370aa97038160fcc31c806 */
	(void)algo_name;  // 显式标记为未使用，避免警告
	/* Ended by AICoder, pid:q1c190da5432c03147370aa97038160fcc31c806 */

	/* Calculate hash of the esbc key */
	ret = hash_init_sha256( &ctx);
	if (ret || (NULL == ctx)) {
		printf("%s hash_init error ret= 0x%x\n", __func__, ret);
		return ret;
	}

	ret = hash_update_sha256(ctx, pdata, pdata_len, 1);
	if (ret) {
		printf("%s hash_update error ret= 0x%x\n", __func__, ret);
		return ret;
	}

	/* Copy hash at destination buffer */
	ret = hash_finish_sha256(ctx, calc_hash, SHA256_BYTES);
	if (ret) {
		printf("%s hash_finish error ret= 0x%x\n", __func__, ret);
		return ret;
	}

	return 0;
}

/*
 * Calculate hash of ESBC hdr and ESBC. This function calculates the
 * single hash of ESBC header and ESBC image. If SG flag is on, all
 * SG entries are also hashed alongwith the complete SG table.
 */
 static int zte_calc_esbchdr_hash(struct csf_hdr *hdr, void *img_addr, uint32_t img_size)
{
	void *ctx;
	int ret = 0;
	uint32_t hash_alg =0;
	const char *algo_name = NULL;

	if(g_boot_validate_dbg) 
		printf("%s input img_addr:%p img_size:0x%x haddr:%p \n",
	                   __func__, img_addr, img_size, hdr);

	hash_alg = (algorithm_boot&0xf0) >> 4;
	if(ZTE_SHA256 == hash_alg) {
		algo_name = "sha256";
	} else {
		printf("csf header input algorithm error\n");
		return -1;
	}
	/* Started by AICoder, pid:e37a8ndd8d25d1714c5b086db0da9108d551d944 */
	(void)algo_name;  // 显式标记为未使用，避免警告
	/* Ended by AICoder, pid:e37a8ndd8d25d1714c5b086db0da9108d551d944 */
	/* Calculate the hash of the ESBC */
	ret = hash_init_sha256( &ctx);
	/* Copy hash at destination buffer */
	if (ret || (NULL == ctx)) {
		printf("%s hash__init error! ret=0x%x\n", __func__, ret);
		return ret;
	}


	/* Update hash for CSF Header */
	ret = hash_update_sha256(ctx, (char *)g_haddr, sizeof(struct csf_hdr), 0);
	if (ret){
		printf("%s hash_update error! ret=0x%x\n", __func__, ret);
		return ret;
	}

	/* Update hash with that of SRK table */
	ret = hash_update_sha256(ctx, (char *)((char *)hdr + hdr->srk_table_offset), 
	                       hdr->len_kr.num_keys * sizeof(T_srk_table), 0);
	if (ret){
		printf("%s hash_update error! ret=0x%x\n", __func__, ret);
		return ret;
	}

	/* Update hash for actual Image */
	ret = hash_update_sha256(ctx, (char *)img_addr, img_size, 1);
	if (ret){
		printf("%s hash_update error! ret=0x%x\n", __func__, ret);
		return ret;
	}

	/* Copy hash at destination buffer */
	ret = hash_finish_sha256(ctx, hash_val, SHA256_BYTES);
	if (ret){
		printf("%s hash_finish error! ret=0x%x\n", __func__, ret);
		return ret;
	}

	return 0;
}

/*
 * Authenticate by Non-Volatile counter
 *
 * To protect the system against rollback, the platform includes a non-volatile
 * counter whose value can only be increased. All certificates include a counter
 * value that should not be lower than the value stored in the platform. If the
 * value is larger, the counter in the platform must be updated to the new
 * value.
 *
 *
 * Return: 0 = success, Otherwise = error
 */
int zte_auth_nvctr(uint32_t ui_counter)
{
	int iret=0;
	uint32_t i_efuse_rdcounter=0;
	uint32_t i_nvmode=0;

	/*check, if rollback is not enable, return */
	iret = BspGetNvModeSwitch(&i_nvmode);
	if(0 != iret) {
		printf("get rollback mode error!!\n");
		return 0;
	}

	if(i_nvmode == 0) {
		printf("rollback mode not enable!\n");
		return 0;
	}
	iret = BspUserNvValRead(&i_efuse_rdcounter);
	if(0 != iret) {
		printf("get rollback version counter error!!\n");
		return -1;
	}
	if(i_efuse_rdcounter > ui_counter) {
		printf("rd_counter is %d, plat_counter is %d \n", ui_counter, i_efuse_rdcounter);
		return -1;
	}

	return 0;
}
/*
 * get the version pub key of cur.swv to verify cpu swv. this func is called after cert_File is verified.
 * boot key is key[0], version key is key[1]
 * input : CA_CERT file ADDR (csf head + ca_cert)
 * output: pub_key
 * output: pub_key_len
 */
int ldPkeyFromCAheader(unsigned int csf_haddr, char *pub_key, unsigned int *pub_key_len)
{
	struct csf_hdr *hdr = NULL;
	T_srk_table *srk_table = NULL;
	int iret=0;
	unsigned int encryption_alg=0;

	hdr = (struct csf_hdr *)csf_haddr;
	if(NULL == hdr)
	{
		printf("%s input para is NULL\n", __func__);
		return -1;
	}
	if(hdr->len_kr.num_keys != 2) {
		printf("%s csf header key num is %d, error\n", __func__, hdr->len_kr.num_keys);
		return -1;
	};		
	srk_table = (void *)((char *)hdr + hdr->srk_table_offset);
	/*get pubkey offset and size*/
	*pub_key_len = srk_table[CSF_CPUKEY_NUM].key_len;

	if(!CHECK_KEY_LEN(*pub_key_len)) {
		printf("%s csf header key len is %d, error\n", __func__, *pub_key_len);
		return -1;
	}

	encryption_alg = (algorithm_cpu&0xf00) >> 8;
	if(ENCRYPTION_RSA != encryption_alg) {
		printf("zte_secure_validate not support %d encrrption alg\n", encryption_alg);
		return -2;
	}

	zte_memcpy_s(pub_key, *pub_key_len,&(srk_table[CSF_CPUKEY_NUM].pkey), *pub_key_len);

	return iret;
}
/*
 * use boot key verify boot or ca cert file. boot key is use key[0]. 
 *
 */
int zte_secure_validate(uintptr_t csf_haddr)
{
	struct csf_hdr *hdr = (struct csf_hdr *)csf_haddr;
	uint32_t pkey_len = 0;
	/* Started by AICoder, pid:f5192b8c03w6f0e14b050a8420dc9203ce610491 */
	char*    pkey_addr = 0;
	/* Ended by AICoder, pid:f5192b8c03w6f0e14b050a8420dc9203ce610491 */
	uint32_t psign_len = 0;
	/* Started by AICoder, pid:9472c31ebefa6ca140b2088dc0c077042b21b5c3 */
	char*   psign_addr = 0;
	/* Ended by AICoder, pid:9472c31ebefa6ca140b2088dc0c077042b21b5c3 */
	char calc_hash[SHA256_BYTES] = {0};
	char rsa_pkey_der[RSA_4K_KEY_SZ_BYTES+0x26] = {0}; /*PUB KEY DER*/
	uint64_t img_addr_addr = 0;
	uint32_t img_len=0, encryption_alg=0;
	int ret=0;
	T_srk_table *srk_table = (void *)((char *)csf_haddr + hdr->srk_table_offset);

	/* check barker code */
	if (memcmp(hdr->barker, barker_code, CSF_BARKER_LEN)) {
		printf("barker compare failed!\n");
		return -1;
	} else {
		printf("barker compare pass!!\n");
	}
	g_haddr = csf_haddr;
	/*parse csf header, and save it*/
	ui_nv_counter = zte_get_csf_nv_counter(csf_haddr);
	ui_csf_version = zte_get_csf_version(csf_haddr);
	algorithm_cpu = zte_get_algorithm(csf_haddr, CSF_CPUKEY_NUM);
	algorithm_boot = zte_get_algorithm(csf_haddr, CSF_BOOTKEY_NUM);
	alg_param = zte_get_alg_param(csf_haddr);
	if(g_boot_validate_dbg) {
		printf("<---------------csf parse----------->\n");
		printf("nv_counter csf_version algorithm_cpu algorithm_boot alg_param\n");
		printf("%6x %12x %10x %15x %10x\n",ui_nv_counter, ui_csf_version, algorithm_cpu, algorithm_boot, alg_param);
		printf("<---------------csf parse end----------->\n");
	}

	/*get pubkey offset and size*/
	/* Started by AICoder, pid:3d271l650c6f2ac145850b4970ecdd0e52e11a23 */
	pkey_addr = (char *)&(srk_table[CSF_BOOTKEY_NUM].pkey);
	/* Ended by AICoder, pid:3d271l650c6f2ac145850b4970ecdd0e52e11a23 */
	pkey_len = srk_table[CSF_BOOTKEY_NUM].key_len;

	if(!CHECK_KEY_LEN(pkey_len)) {		
		printf("%s get pub_key addr=0x%x, len=0x%x;  len is error\n", __func__, pkey_addr, pkey_len);
		return -2;
	}
	/*check if support encrrption alg*/
	encryption_alg = (algorithm_boot&0xf00) >> 8;
	if(ENCRYPTION_RSA != encryption_alg) {
		printf("zte_secure_validate not support %d encrrption alg\n", encryption_alg);
		return -3;
	}
	/*get sign offset and size*/
	psign_addr = (char *)(csf_haddr + hdr->psign);
	psign_len = hdr->sign_len;
	if((psign_len*2) != pkey_len)	{
		printf("%s get sign addr=0x%x, len=0x%x error\n", __func__, psign_addr, psign_len);
		return -4;
	}

	/*calc pkey hash, first encode to DER*/
	if(psign_len == RSA_2K_KEY_SZ_BYTES) {
		zte_memcpy_s(rsa_pkey_der, 0x21, rsa2048_header, 0x21);
	}else if(psign_len == RSA_3K_KEY_SZ_BYTES) {
		zte_memcpy_s(rsa_pkey_der, 0x21, rsa3072_header, 0x21);
	}else if(psign_len == RSA_4K_KEY_SZ_BYTES) {
		zte_memcpy_s(rsa_pkey_der, 0x21, rsa4096_header, 0x21);
	}
	/* Started by AICoder, pid:1fa30n65bcgfe6914c300b8800a46b070ca176d6 */
	zte_memcpy_s(rsa_pkey_der+0x21, psign_len, (void *)(uintptr_t)pkey_addr, psign_len);
	/* Ended by AICoder, pid:1fa30n65bcgfe6914c300b8800a46b070ca176d6 */
	zte_memcpy_s(rsa_pkey_der+0x21+psign_len, 5, rsa_tail, 5);

	calc_data_hash(rsa_pkey_der, psign_len+0x26, calc_hash, CSF_BOOTKEY_NUM);
	if(g_boot_validate_dbg) {
		printf("calc sha256 of root key is:");
		for (int i = 0; i < SHA256_BYTES; i++) {
			printf("%02x", calc_hash[i]);
		}
		printf("\n");
	}

	/*cmp hash_of_pkey with efuse*/
	/* Started by AICoder, pid:zd809n462696ebb144380a6540da420a21415d64 */
	ret = BspHashCmp((UINT32 *)calc_hash, SHA256_BYTES/4);
	/* Ended by AICoder, pid:zd809n462696ebb144380a6540da420a21415d64 */
	#ifdef FOR_TEST_SECURE
	ret = 0;
	#endif
	if (ret != 0) {
		printf("%s arm_smccc_smc  SMC_EFUSE_HASH_CMP FAILED!! ret=0x%x\n", __func__, ret);
		return ret;
	}

	/*get image*/
	if(0 == hdr->sg_flag) {
		if((0 == hdr->img_addr)||(0 == hdr->img.img_size)) {
			printf("csf header ERROR\n");
			return -5;
		} else {
			img_addr_addr = (uint64_t)(csf_haddr + hdr->img_addr);
			img_len = hdr->img.img_size;
		}
	}else {
		printf("csf header sg_flag error!\n");
		return -3;
	}

	/*get esbc header hash to hash_val*/
	/* Started by AICoder, pid:gcf53v3a054cdf2145d2096070fa32013971de7d */
	ret = zte_calc_esbchdr_hash(hdr, (void*)(uintptr_t)img_addr_addr, img_len);
	/* Ended by AICoder, pid:gcf53v3a054cdf2145d2096070fa32013971de7d */
	if (ret) {
		printf("%s zte_calc_esbchdr_hash ret=0x%x", __func__, ret);
		return ret;
	}

	ret = rsa_auth_signature(hash_val, (char *)pkey_addr, pkey_len, (char *)psign_addr, psign_len);
	if(ret) {
		printf("rsa_auth_signature failed! ret=0x%x\n", ret);
		return ret;
	}

	return 0;

}

/*
* get sign data from jSon file in protect flash
*/
uint32_t BspGetVersionSign(uchar *ucBuf, uint32_t ulFileLen, uint32_t ulFileCrc, uchar* ucSign, uint32_t *uiSign_len)
{
    cJSON * ver_sign_json = NULL;
    cJSON * ver_pkg = NULL;
    cJSON * pkg_child = NULL;
    cJSON * hash_type = NULL;
    cJSON * ver_infos = NULL;
    cJSON * ver_child = NULL;
    cJSON * size = NULL;
    cJSON * crc = NULL;
    cJSON * hashSign = NULL;
    uint32_t ulVerLen =0;
    uint32_t ulVerCrc = 0;

    if(( ucSign == NULL) || (ucBuf == NULL))
    {
        printf("input para is null !\n");
        return -1;
    }
    ver_sign_json = cJSON_Parse((char *)ucBuf);
    
    if(NULL==ver_sign_json)
    {
        printf("ver_sinput is NULL !\n");
        return -1;
    }

    ver_pkg = cJSON_GetObjectItem(ver_sign_json,"pkgGroup");
    if(NULL == ver_pkg)
    {
        printf("Get pkgGroup Object Failed [crc:%d len:%d] !\n", ulFileCrc, ulFileLen);
        return -1;
    }
    pkg_child = ver_pkg->child;
    while(pkg_child !=NULL)
    {

        hash_type = cJSON_GetObjectItem(pkg_child,"hashType");

        if(NULL == hash_type)
        {
            printf("Get hashType Object Failed [crc:%d len:%d] !\n", ulFileCrc, ulFileLen);
            break;
        }     

        ver_infos = cJSON_GetObjectItem(pkg_child, "softInfos"); 
       
        if(NULL == ver_infos)
        {
            printf("Get softInfos Object Failed [crc:%d len:%d] !\n", ulFileCrc,ulFileLen);
            break;
        }
        ver_child = ver_infos->child;    
        while(ver_child != NULL)
        {
            size = cJSON_GetObjectItem(ver_child, "size");   
            crc = cJSON_GetObjectItem(ver_child, "crc");
            if( crc==NULL || size==NULL )
            {
                printf("Get size & crc Object Failed [crc:%d len:%d] !\n", ulFileCrc,ulFileLen);
                break;
            }
            ulVerLen = (u32)size->valueint;
            ulVerCrc = (u32)crc->valueint;
            printf("sizze %d,crc %d Get Succ !\n", ulVerLen, ulVerCrc);
            if((ulFileLen == ulVerLen)&&(ulFileCrc==ulVerCrc))
            {
                hashSign = cJSON_GetObjectItem(ver_child, "hashSign");
                if(NULL == hashSign)
                {
                    printf("Get hashSign Failed [crc:%d len:%d] !\n", ulFileCrc,ulFileLen);
                    return -1;
                }
				if(strlen(hashSign->valuestring) > MAX_SIGN_STRING_LEN )
				{
					printf("string signlen error\n");
					return -1;
				}

				mbedtls_base64_decode((uchar *)ucSign, RSA_4K_KEY_SZ_BYTES, (size_t *)uiSign_len,
                   (uchar *)hashSign->valuestring, strlen(hashSign->valuestring) );

				if(g_boot_validate_dbg) {
					printf("hash lenth %d, string %s [crc:%d len:%d] !\n", 
								strlen(hashSign->valuestring),hashSign->valuestring,ulFileCrc,ulFileLen);
		
					for(int i =0; i< *uiSign_len; i++){
						printf("0x%x ",*(ucSign+i));
						if((i+1)%8==0) printf("\n");
					}
				}
                return 0;
            }
            ver_child = ver_child->next;
        }
        pkg_child = pkg_child->next;
    }
    return -1;    
}

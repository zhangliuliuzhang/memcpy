/*****************************************************************************
 * 版权所有(C) 2010, ZTE Corp. RRU Bsp Platform
 *----------------------------------------------------------------------------
 * 模 块 名 : BSP
 * 文件名称 : dra62xboot.c
 * 文件标识 : {[N/A]}
 * 内容摘要 : dra62x cpu bootapp接口实现
 * 注意事项 : 无
 * 作    者 : 耿佳佳
 * 创建日期 : 2015-10-22 08:28:34
 * 当前版本 : Ver1.0
 *----------------------------------------------------------------------------
 * 变更记录 :
 *
 * $记录1
 * 变 更 单: $0000000(N/A)
 * 责 任 人: 耿佳佳
 * 修改日戳: 2015-10-22 08:28:34
 * 变更说明: 创建文件
 *
 *----------------------------------------------------------------------------
 */

#include "stdio.h"
#include <sys/types.h>
#include <sys/stat.h>
#include <netinet/in.h>
#include <fcntl.h>
#include <errno.h>
#include "vxadp.h"

#include "bsppub.h"
#include "bspcomm.h"
#include "pub_typedef.h"
#include "bsperrcode.h"
#include "i2cbusapi.h"
#include "dra62xboot.h"
#include "pca9535.h"
#if defined(COMPILE_FOR_KEXEC_BOOT)
#include "bootadp.h"
#endif
/**************************************************************************
 *                        宏
 **************************************************************************/

extern UCHAR g_ucCmdLine[256];

#ifdef COMPILE_FOR_KEXEC_BOOT
#define  MDIO_BASE_ADDR  (0x2101000)
#define  MDIO_REGS_SIZE  (0x100)
#define  MDIO_LINK_REG  (0xc)
#define  MDIO_USER0_ACCESS_REG  (0x80)
#define  USERACCESS_GO      (1 << 31)
#define  USERACCESS_WRITE	(1 << 30)
#define  USERACCESS_ACK		(1 << 29)
#define  USERACCESS_READ	(0)
#define  USERACCESS_DATA	(0xffff)

#define CPSW_BASE_ADDR               (0x2100000)
#define CPSW_REGS_SIZE              (0x1000)
#define CPSW_ALE_CONTRAL              (0xd08)

/**************************************************************************
 *                         数据类型                                       *
 **************************************************************************/


/**************************************************************************
 *                         全局变量定义                                   *
 **************************************************************************/


/*从内核获取*/
static ULONG g_WatchDogStatFalg = 0;/* 记录看门狗是否使能:1使能，0去使能 */
ULONG  g_ulRamReservedAddr =0;
ULONG  g_ulRtcRegisterAddr =0;
ULONG g_ulLedFlag = 0;
/**************************************************************************
 *                         外部变量声明
 **************************************************************************/

/**************************************************************************
*                         局部函数声明
**************************************************************************/
extern VOID MainLoop ();
extern ULONG BootFlashInit(VOID);
extern ULONG BootSoftModInit(void);

/**************************************************************************
*                         全局函数声明
**************************************************************************/
ULONG SetDefaultCmdline();
/* Started by AICoder, pid:h225dk7c8eo042714c990ac0107d6f07c8b3df05 */
ULONG BspMknod(const char * filepath, const char *oprator, const char *majornew, const char* minornew);
/* Ended by AICoder, pid:h225dk7c8eo042714c990ac0107d6f07c8b3df05 */
int dra62x_is_config(enum e_dra624_module_cfg_t dra624_module );
/**************************************************************************
 *                         函数实现
 **************************************************************************/
/*****************************************************************************
*  函数名称   : BspGetCpuType(*)
*  功能描述   : 双boot模块用于获取cpu类型
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : 无
*  输出参数   : 无
*  返 回 值   : 成功 - BSP_OK
*  其它说明   :
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A), yam@2014-10-09 14:07:25 创建
*----------------------------------------------------------------------------
*/
UINT32 BspGetCpuType (UINT8 *pucCpuType)    
{ 
    if (NULL == pucCpuType)
        return BSP_ERROR_NULL_POINTER;
	
    *pucCpuType = BSP_DRA62X;
    return BSP_OK;
}

ULONG BootRdWdtReg(ULONG ulAddr)
{
    ULONG ulRegAddr = 0;

	ulRegAddr = ulAddr + WDT_BASE_ADDR + L4_SLOW_VIRTUAL_BASE;

    return *((volatile ULONG *)ulRegAddr);
}
ULONG BootWrWdtReg(ULONG ulAddr, ULONG ulData)
{
    ULONG ulRegAddr = 0;

	ulRegAddr = ulAddr + WDT_BASE_ADDR + L4_SLOW_VIRTUAL_BASE;

    *((volatile ULONG *)ulRegAddr) = ulData;
	return BSP_OK;
}

/**********************************************************************
* 函数名称:ULONG BspBootPhyLinkMmap()
* 功能描述:debug网口基址映射
* 输入参数:无
* 输出参数:
* 返 回 值:BSP_OK:成功;BSP_ERROR:失败
* 其它说明:
* 修改日期        版本号     修改人          修改内容
* -----------------------------------------------
* 2015-10-22       V1.0       00086970             创建
***********************************************************************/ 
ULONG BootPhyLinkMmap()
{
    ULONG	ulVirAddr = 0; 
	ULONG   ulPhyAddr = 0;
	ULONG   ulSpaceProt = PROT_READ | PROT_WRITE;
	int     ifile;

    if ((ifile = open("/dev/mem", O_RDWR | O_SYNC)) < 0)
    {
    	printf("open /dev/mem failed\n");
    	return BSP_ERROR;
    }
	
	ulPhyAddr = MDIO_BASE_ADDR + L4_SLOW_BASE_ADDR;
	
	ulVirAddr = MDIO_BASE_ADDR + L4_SLOW_VIRTUAL_BASE;
	
	
    ulVirAddr = (ULONG)mmap((void *)ulVirAddr, MDIO_REGS_SIZE, ulSpaceProt, MAP_SHARED, ifile, ulPhyAddr);
	if (ulVirAddr != MDIO_BASE_ADDR + L4_SLOW_VIRTUAL_BASE)
	{                                                           
		printf("%s %d 0x%x 0x%x map error\n", __FUNCTION__, __LINE__, ulPhyAddr, ulVirAddr);
		close(ifile);
		return BSP_ERROR;
	}
	printf("%s %d 0x%x 0x%x\n", __FUNCTION__, __LINE__, ulPhyAddr, ulVirAddr);
	close(ifile);
	return BSP_OK;
}

ULONG BootGetPhyId()
{
   
    FILE *fd = NULL;
	CHAR *pcAddr = NULL;
    CHAR cTmp = 0;
	#define PHYID_INFO_FILE "/proc/bsp/eth0/phyid"   
	ULONG ulDebugNetPortPhyId = 0x1f;
	CHAR cEth0Phyid[16] = {0};
	
    fd = fopen(PHYID_INFO_FILE,"r+b");
    if(NULL == fd)
    {
        printf("Can not open phyid\n");	
		return BSP_ERROR;
    }
	fseek(fd,0L,SEEK_SET);
    cTmp = fread(cEth0Phyid,1,sizeof(cEth0Phyid),fd);      
    if(0 >= cTmp)
    {
        printf("read phyid error\n");	
		fclose(fd);
		return BSP_ERROR;
    }
	pcAddr = strchr(cEth0Phyid, ':');
    if(NULL == pcAddr)
    {  
		printf("phyid X:XX error\n");	
		fclose(fd);
		return BSP_ERROR;
    }	
	ulDebugNetPortPhyId = (int)strtol(pcAddr+1,NULL,16);
	printf("eth0 PhyId form proc: 0x%x\n",ulDebugNetPortPhyId);
	fclose(fd);
	return ulDebugNetPortPhyId;

}
/**********************************************************************
* 函数名称:ULONG BootGetPhyLinkStatus()
* 功能描述:获取debug网口连通状态
* 输入参数:
* 输出参数:
* 返 回 值:0:连通，1:断开 ;BSP_ERROR:失败
* 其它说明:用于检测debug网口的物理链路通断状态
   3228的MII Management I/F将会保持闲置状态，直到被使能，使能的方法就是设置MDIOControl 寄存器的使能位bit[30]。
   一旦被使能后，MII Management I/F将会连续地并轮流地从所有可能的32个PHY芯片地址对应的Generic Status Register
   通用状态寄存器选出各个链路状态，并记录在MDIOLink 寄存器内。经过确认 3228的 MDIOControl 寄存器偏移地址0x4
   而MDIOLink寄存器偏移地址0xc，在cpsw.c文件内找到了cpsw_mdio_init(), 入参会传入mdio的基址, 确定基址是0x4a101000
   在cpsw_mdio_init()内,已经对MDIOControl进行了使能,并且使能的操作在NormalBoot()之前就完成了,所以这里可以直接读
   MDIOLink寄存器的状态。其中只有最高bit位在实际网口通断时发生了变化，其他几个bit位理应是其余的31个phy地
   址状态,会与PHY芯片物理连接有关,Evm.c内的cpsw_slaves[0].phy_id表明了MDIOControl寄存器的具体bit位置,断开debug网口
   时,md 0x4a10100c为0, 连通时为0x80000000  for dra62x 3228
* 修改日期        版本号     修改人          修改内容
* -----------------------------------------------
* 2015-10-22       V1.0       00086970             创建
***********************************************************************/ 

unsigned long BootGetPhyLinkStatus(VOID)
{
    unsigned long  ulValue = 0;
    unsigned int uiPhyId = 0;
    unsigned long ulMask = 0;

    uiPhyId = BootGetPhyId();
	if(BSP_ERROR == uiPhyId)
	{
	    printf("get phyid from /proc/bsp/eth0/phyid error, 0x1f default\n");
		uiPhyId = 0x1f;
	}
    ulMask = 1UL << uiPhyId;
    ulValue = *(volatile unsigned long *)(MDIO_BASE_ADDR + L4_SLOW_VIRTUAL_BASE + MDIO_LINK_REG);  

    if (0 == (ulValue & ulMask))
    {
        printf("Debug net port is OFF [0x%x], PhyId[0x%x]\n", ulValue, uiPhyId); 
        return 1;
    }
    else
    {
        printf("Debug net port is ON [0x%x], PhyId[0x%x]\n", ulValue, uiPhyId); 
        return 0;
    }

}

/**********************************************************************
* 函数名称:ULONG BootPhyLinkInit()
* 功能描述:PhyLink初始化
* 输入参数:
* 输出参数:
* 返 回 值:
* 修改日期        版本号     修改人          修改内容
* -----------------------------------------------
* 2015-10-22       V1.0       00086970             创建
***********************************************************************/
ULONG BootPhyLinkInit()
{   
	return BootPhyLinkMmap();
}
#if 0
/*此处代码保留，后续3228 kexecboot需要支持9535时放开*/
/*****************************************************************************
*  函数名称   : BspGetModuleGroupId
*  功能描述   : 获取模组ID
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : 无
*  输出参数   : 无
*  返 回 值   : 硬件信息
*  其它说明   :
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A), 崔文会@2011-01-19 08:33:43, 拷贝并平台规范化
*  $0000001(N/A), 姜建奎@2012-08-20 08:33:43, 移植到r15trx
*----------------------------------------------------------------------------
*/
ULONG BootGetModuleId( VOID )
{
    static UCHAR ucflag = 0;
    static  ULONG ulValue = 0xEC;
	ULONG ulRetW = BSP_ERROR;
	ULONG ulRetR = BSP_ERROR;

    if(0 == ucflag)
    {
        ulRetW = BspPca9535RegWrite(0, BOM_ID_IIC_INPUT_REG,MODULE_GROUP_ID_OFFSET);
        ulRetR = BspPca9535RegRead(0, BOM_ID_IIC_OUTPUT_REG, &ulValue);

		if((BSP_OK==ulRetW)&&(BSP_OK==ulRetR))
		ucflag = 1;

    }

    return ulValue;
}

/*****************************************************************************
*  函数名称   : BspGetBoardGroupId
*  功能描述   : 获取单板组ID
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : 无
*  输出参数   : 无
*  返 回 值   : 硬件信息
*  其它说明   :
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A), 崔文会@2011-01-19 08:33:43, 拷贝并平台规范化
*  $0000001(N/A), 姜建奎@2012-08-20 08:33:43, 移植到r15trx
*----------------------------------------------------------------------------
*/
ULONG BootGetGroupId( VOID )
{
    static UCHAR ucflag = 0;
    static  ULONG ulValue = 0xff;
	ULONG ulRetW = BSP_ERROR;
	ULONG ulRetR = BSP_ERROR;
    if(0 == ucflag)
    {
        ulRetW = BspPca9535RegWrite(0, BOM_ID_IIC_INPUT_REG,BOARD_GROUP_ID_OFFSET);
        ulRetR = BspPca9535RegRead(0, BOM_ID_IIC_OUTPUT_REG, &ulValue);
		if((BSP_OK==ulRetW)&&(BSP_OK==ulRetR))
		ucflag = 1;
		
    }
    return ulValue;
}


/*****************************************************************************
*  函数名称   : BspGetBoardTypeId
*  功能描述   : 获取单板类型
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : 无
*  输出参数   : 无
*  返 回 值   : 硬件信息
*  其它说明   :
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A), 崔文会@2011-01-19 08:33:43, 拷贝并平台规范化
*  $0000001(N/A), 姜建奎@2012-08-20 08:33:43, 移植到r15trx
*----------------------------------------------------------------------------
*/
ULONG BootGetBoardTypeId( VOID )
{
    static UCHAR ucflag = 0;
    static  ULONG ulValue = 0xff;
	ULONG ulRetW = BSP_ERROR;
	ULONG ulRetR = BSP_ERROR;
    if(0 == ucflag)
    {
        ulRetW = BspPca9535RegWrite(0, BOM_ID_IIC_INPUT_REG,BOARD_TYPE_ID_OFFSET);
        ulRetR = BspPca9535RegRead(0, BOM_ID_IIC_OUTPUT_REG, &ulValue);
		if((BSP_OK==ulRetW)&&(BSP_OK==ulRetR))
		ucflag = 1;
    }

    return ulValue;
}

/*****************************************************************************
*  函数名称   : BspGetHardwareChangeId
*  功能描述   : 获取硬件变更ID
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : 无
*  输出参数   : 无
*  返 回 值   : 硬件信息
*  其它说明   :
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A), 崔文会@2011-01-19 08:33:43, 拷贝并平台规范化
*  $0000001(N/A), 姜建奎@2012-08-20 08:33:43, 移植到r15trx
*----------------------------------------------------------------------------
*/
ULONG BootGetHardChangeId( VOID )
{
    static UCHAR ucflag = 0;
    static  ULONG ulValue = 0xff;
	ULONG ulRetW = BSP_ERROR;
	ULONG ulRetR = BSP_ERROR;
    if(0 == ucflag)
    {
        ulRetW = BspPca9535RegWrite(0, BOM_ID_IIC_INPUT_REG,BOARD_HARD_CHANGE_ID_OFFSET);
        ulRetR = BspPca9535RegRead(0, BOM_ID_IIC_OUTPUT_REG, &ulValue);
		if((BSP_OK==ulRetW)&&(BSP_OK==ulRetR))
		ucflag = 1;
    }
    return ulValue;
}
#endif
/*****************************************************************************
*  函数名称   : BootGetDdrSize
*  功能描述   : 通过命令行获取cpu使用的ddr大小
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : 无
*  输出参数   : 无
*  返 回 值   : 128:128M,256:256M
*  其它说明   : kexecboot通过mem=获取给
*               cpu使用的内存大小(不是ddr的物理大小)
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A), 00086970@2016-03-31      创建
*----------------------------------------------------------------------------
*/
ULONG BootGetDdrSize(VOID)
{
    ULONG ulMemSize = 250;
    char acStr1[50],acStr2[100]; 
    rsize_t size_array[3] = {50, 100, 0};   

    /* "console=ttyO0,115200n8 mem=250M earlyprintk root=/dev/ram0 rw init=/
        init kexecboot=1" */
    zte_sscanf_s((char *)g_ucCmdLine, "%22s mem=%dM %s",size_array, acStr1, &ulMemSize, acStr2);
    printf("\nBootGetDdrSize get ddr size = %lu\n",ulMemSize);
    if(ulMemSize >= 122)
        return (ulMemSize+6);
    else
        return 256;
}

/*****************************************************************************
*  函数名称   : BootDevMemMap()
*  功能描述   : 使用mmap将物理地址映射到用户进程虚拟地址空间
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : 无
*  输出参数   : 无
*  返 回 值   : BSP_OK, 其它值为失败
*  其它说明   :
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A), 田瑞忠@2010-5-19 8:52:25 创建
*----------------------------------------------------------------------------
*/
ULONG BootDevMemMap(VOID)
{
    /* 打开内存设备的文件描述符 */
    int     iFd;
    int     iSpaceProt = PROT_READ | PROT_WRITE;
    ULONG   iCount = 0;
    ULONG   ulDdrSize = 0;

    ulDdrSize = (unsigned long)BootGetDdrSize() << 20;
   
#define TO_MAP_LIST(a)      #a, &a
	/*lint -e529*/
	/*lint -e64*/
    struct map_list_t {
        UCHAR   *pucVarName;
        LONG    *pulVarAddr;
        ULONG   ulMapBase;
        ULONG   ulMapSize;
    } map_list[] = {
        {TO_MAP_LIST(g_ulRamReservedAddr),  (0x80000000+ ulDdrSize -0x00600000),0x00600000},
        {TO_MAP_LIST(g_ulRtcRegisterAddr),  (0x480c0000),0x00200000},	
    };
	/*lint +e529*/
	/*lint +e64*/
    #define DO_ADDR_MAP(a)                                          \
    	*((a)->pulVarAddr) = (long)mmap(0, (a)->ulMapSize,          \
    	    iSpaceProt, MAP_SHARED, iFd, (a)->ulMapBase);           \
    	if (*((a)->pulVarAddr) == -1)                               \
    	{                                                           \
    		dbgErr("mmap %s failed %s, %d\n",                       \
    		    (a)->pucVarName, strerror(errno), errno);           \
    		close(iFd);                                             \
    		return BSP_ERROR;                                       \
    	}                                                           \
    	dbgInfo("%-20s = %#x.0x%x\n", (a)->pucVarName, *((a)->pulVarAddr),(a)->ulMapBase);


    /* 打开存储空间映射 */
	if ((iFd = open("/dev/mem", O_RDWR | O_SYNC)) < 0)
	{
		dbgErr("open /dev/mem failed\n");
		return BSP_ERROR;
	}

    for (iCount = 0; iCount < sizeof(map_list)/sizeof(map_list[0]); iCount++)
    {
        DO_ADDR_MAP(&map_list[iCount]);
        usleep(1000);
    }

    return BSP_OK;
}

/**************************************************************************
 * 函数名称: BootI2cBusInit
 * 功能描述:
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * 修改日期       版本号           修改人    修改内容
 * ------------------------------------------------------------------------
 * 2011年12月14日 ZXSDRRUV120B01   罗乔发    创建
 **************************************************************************/
ULONG BootI2cBusInit(ULONG ulBusId)
{
    ULONG ulRetVal = BSP_OK;

    T_I2C_BUS_DRV *ptBus = NULL;

    if (ulBusId >= NUM_BRD_I2C_BUS)
    {
        return BSP_ERROR_INVALID_PARA;
    }

    ptBus = &s_atI2cBus[ulBusId];
    ulRetVal = BspI2CBusDrvInit(ptBus);
    return ulRetVal;
}
/**************************************************************************
 * 函数名称: Pca9535ChipInit
 * 功能描述:
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * 修改日期       版本号           修改人    修改内容
 * ------------------------------------------------------------------------
 * 2011年12月23日 ZXSDRRUV1211B02   lichao    创建
 **************************************************************************/
ULONG Pca9535ChipInit(void)
{
    ULONG ulRetVal = BSP_OK;
    T_Pca9535Dev tPca9535;

    memset((void *)&tPca9535, 0, sizeof(tPca9535));
    tPca9535.ulDevIndex = 0;
    tPca9535.tSlave.I2CBusId = I2C_BUS_ID_PCA9535;
    tPca9535.tSlave.Addr = BOM_ID_IIC_ADDR;
    ulRetVal = BspPca9535DevInit(&tPca9535);
    return ulRetVal;
}
/**************************************************************************
 * 函数名称: BootBomIdInit
 * 功能描述:
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * 修改日期       版本号           修改人    修改内容
 * ------------------------------------------------------------------------
 * 2011年12月23日 ZXSDRRUV1211B02   lichao    创建
 **************************************************************************/
ULONG BootBomIdInit(void)
{
    Pca9535ChipInit();
    
    BspPca9535RegWrite(0,BOM_ID_IIC_INIT_REG1, BOM_ID_IIC_INIT_REG1_VALUE);
    sleep(1);
    BspPca9535RegWrite(0,BOM_ID_IIC_INIT_REG2, BOM_ID_IIC_INIT_REG2_VALUE);
    /*testid();*/
    return BSP_OK;
}
/*****************************************************************************
 *  函数名称   : BspWdtMmap(*)
 *  功能描述   : WDT模块地址映射
 *  读全局变量 : 无
 *  写全局变量 : 无
 *  输入参数   : 无
 *  输出参数   : 无
 *  返 回 值   : 成功 - BSP_OK
 *  其它说明   : 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *  $0000000(N/A), 龚大江@2012-08-24 11:15:46
 *----------------------------------------------------------------------------
 */
ULONG BootWdtMmap(VOID)
{
    INT     ifile;
    ULONG   ulSpaceProt = PROT_READ | PROT_WRITE;
	ULONG	ulVirAddr, ulPhyAddr;

    if ((ifile = open("/dev/mem", O_RDWR | O_SYNC)) < 0)
    {
    	printf("open /dev/mem failed\n");
    	return BSP_ERROR;
    }

	ulPhyAddr = WDT_BASE_ADDR + L4_SLOW_BASE_ADDR;
	ulVirAddr = WDT_BASE_ADDR + L4_SLOW_VIRTUAL_BASE;
	
	ulVirAddr = (ULONG)mmap((VOID*)ulVirAddr, WDT_REGS_SIZE, ulSpaceProt, MAP_SHARED, ifile, ulPhyAddr);
	if (ulVirAddr != WDT_BASE_ADDR + L4_SLOW_VIRTUAL_BASE)
	{                                                           
		printf("%s %d 0x%x 0x%x map error\n", __FUNCTION__, __LINE__, ulPhyAddr, ulVirAddr);
		close(ifile);
		return BSP_ERROR;
	}
	
	printf("%s %d 0x%x 0x%x\n", __FUNCTION__, __LINE__, ulPhyAddr, ulVirAddr);
	close(ifile);
    return BSP_OK;

}
/*****************************************************************************
 *  函数名称   : tidra62x_set_epldwdg
 *  功能描述   : 设置epld外部看门狗
 *  读全局变量 : 无
 *  写全局变量 : 无
 *  输入参数   : ucEn=1 使能epld看门狗
                 ucEn=0 禁用epld看门狗
 *  输出参数   : 无
 *  返 回 值   : 无
 *  其它说明   : 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *  $0000000(N/A), 牛彦茹@2018.8.5 11:15:46
 *----------------------------------------------------------------------------
 */
void tidra62x_set_epldwdg(unsigned char ucEn)
{
    if(ucEn)
        BspSetGpioDataout(2,10,0);
    else
        BspSetGpioDataout(2,10,1);

    /*9815 use gpio4[31]*/
    if(ucEn)
        BspSetGpioDataout(4,31,0);
    else
        BspSetGpioDataout(4,31,1); 	
}

/*****************************************************************************
 *  函数名称   : BootWatchDogEnable(*)
 *  功能描述   : 使能软件喂狗
 *  读全局变量 : 无
 *  写全局变量 : 无
 *  输入参数   : 无
 *  输出参数   : 无
 *  返 回 值   : 成功 - BSP_OK
 *  其它说明   : 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *  $0000000(N/A), 宋飞@2011-11-25 11:15:46
 *----------------------------------------------------------------------------
 */
ULONG BootWatchDogEnable(VOID)
{
    /*BspFpgaWatchDogEnable();-- 调用时机问题*/
	g_WatchDogStatFalg = 1;
    BootWrWdtReg(WDT_WSPR_REG, 0xBBBB);
	while (BootRdWdtReg( WDT_WWPS_REG) & 0x10);
	BootWrWdtReg(WDT_WSPR_REG, 0x4444);
	while (BootRdWdtReg( WDT_WWPS_REG) & 0x10);

    tidra62x_set_epldwdg(1);
    return BSP_OK;
}

/*****************************************************************************
 *  函数名称   : BootWatchDogDisable(*)
 *  功能描述   : 去使能软件喂狗
 *  读全局变量 : 无
 *  写全局变量 : 无
 *  输入参数   : 无
 *  输出参数   : 无
 *  返 回 值   : BSP_OK
 *  其它说明   : 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *  $0000000(N/A), 宋飞@2011-11-25 11:15:46
 *  $0000001(N/A), 姜建奎@2013-12-13 16:04:27 加入支持FPGA 看门狗
 *----------------------------------------------------------------------------
 */
ULONG BootWatchDogDisable(VOID)
{
	g_WatchDogStatFalg = 0;
    BootWrWdtReg(WDT_WSPR_REG, 0xAAAA);
	while (BootRdWdtReg( WDT_WWPS_REG) & 0x10);
	
	BootWrWdtReg(WDT_WSPR_REG, 0x5555);
	while (BootRdWdtReg( WDT_WWPS_REG) & 0x10);

    tidra62x_set_epldwdg(0);
    return BSP_OK;
}

/*****************************************************************************
 *  函数名称   : BspSetWatchDogTime(*)
 *  功能描述   : 设置看门狗喂狗时间
 *  读全局变量 : 无
 *  写全局变量 : 无
 *  输入参数   : ulTimerValue - 写入硬件喂狗的时间，以100ms为单位
 *  输出参数   : 无
 *  返 回 值   : 成功 - BSP_OK
 *  其它说明   : 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *  $0000000(N/A), 宋飞@2011-11-25 11:15:46
 *----------------------------------------------------------------------------
 */
ULONG BootSetWatchDogTime (ULONG ucTimerValue)
{

    ULONG ulWatchdogtime = 0;
	ulWatchdogtime = ucTimerValue * 10;
    if(1 == g_WatchDogStatFalg)
    {
    
        /* 更改看门够时间前必须去使能看门狗 */
        BootWatchDogDisable();   

		
        BootWrWdtReg(WDT_WLDR_REG, WDT_WLDR(ulWatchdogtime));
	 while (BootRdWdtReg(WDT_WWPS_REG) & 0x04);	
	 
        BootWrWdtReg(WDT_WCRR_REG, WDT_WLDR(ulWatchdogtime));
	 while (BootRdWdtReg(WDT_WWPS_REG) & 0x02);	

		BootWatchDogEnable();
	}
	else
	{
        BootWrWdtReg(WDT_WLDR_REG, WDT_WLDR(ulWatchdogtime));
	 while (BootRdWdtReg(WDT_WWPS_REG) & 0x04);	
	 
        BootWrWdtReg(WDT_WCRR_REG, WDT_WLDR(ulWatchdogtime));
	 while (BootRdWdtReg(WDT_WWPS_REG) & 0x02);	

	}
	

    return BSP_OK;
	
}

/*****************************************************************************
 *  函数名称   : BspWatchDogHardMonDisable(*)
 *  功能描述   : 关闭看门狗硬件监控(硬件辅助喂狗)
 *  读全局变量 : 无
 *  写全局变量 : 无
 *  输入参数   : 无
 *  输出参数   : 无
 *  返 回 值   : BSP_OK - 成功 BSP_ERROR - 失败
 *  其它说明   : 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *  $0000000(N/A), 宋飞@2011-11-25 11:15:46
 *----------------------------------------------------------------------------
 */
VOID BootWatchDogHardMonDisable(VOID)
{
    BootWatchDogEnable();
}

/*****************************************************************************
 *  函数名称   : BspWatchDogHardMonEnable(*)
 *  功能描述   : 使能看门狗硬件监控(硬件辅助喂狗)
 *  读全局变量 : 无
 *  写全局变量 : 无
 *  输入参数   : 无
 *  输出参数   : 无
 *  返 回 值   : BSP_OK - 成功 BSP_ERROR - 失败
 *  其它说明   : 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *  $0000000(N/A), 宋飞@2011-11-25 11:15:46
 *----------------------------------------------------------------------------
 */
VOID BootWatchDogHardMonEnable(VOID)
{
    BootWatchDogDisable();
}
 /*****************************************************************************
 *  函数名称   : BootWdtInit(*)
 *  功能描述   : WDT模块初始化
 *  读全局变量 : 无
 *  写全局变量 : 无
 *  输入参数   : 无
 *  输出参数   : 无
 *  返 回 值   : 成功 - BSP_OK
 *  其它说明   : 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *  $0000000(N/A), 龚大江@2012-08-24 11:15:46
 *  $0000001(N/A), 姜建奎@2013-02-25 14:15:46 BSP 小版本关闭看门狗
 *----------------------------------------------------------------------------
 */
ULONG BootWdtInit(VOID)
{

    if (BSP_OK != BootWdtMmap())
    {
        dbgErr("WatchDog Init Failed!\n");
        return BSP_ERROR;
    }

    return BSP_OK;
}
  /**********************************************************************
* 函数名称:VOID BootAppWatchDogInit()
* 功能描述:bootapp初始化看门狗
* 输入参数:无
* 输出参数:
* 返 回 值:BSP_OK:成功;BSP_ERROR:失败
* 其它说明:网线连通bootapp main入口到下次内核启动完成计时约20s。bsp接口单位100ms，
           设置看门狗时间100s，100s到达前MGR接管，否则看门狗复位
* 修改日期        版本号     修改人          修改内容
* -----------------------------------------------
* 2015-10-22       V1.0       00086970             创建
***********************************************************************/
ULONG BootWatchDogInit()
{
    ULONG ulRet = BSP_OK;
	 /*step1: disable wdt*/
    BootWatchDogDisable();

    /*step2: set wclr*/
    BootWrWdtReg(WDT_WCLR_REG, (WDT_PRE<<5) | (WDT_PTV<<2));

    /*step3: set wldr and wdly*/
    BootWrWdtReg(WDT_WLDR_REG, WDT_WLDR(10));/*默认咬狗时间为1s*/
    BootWrWdtReg(WDT_WDLY_REG, 0xffffffff);

    /*step4: set wcrr*/
    BootWrWdtReg(WDT_WCRR_REG, WDT_WLDR(10));

    BootSetWatchDogTime(240);  /*kexecboot 设置为100s,BootSetWatchDogTime里面实现*10*/

    BootWatchDogEnable();
     
	return ulRet;
}
 /*****************************************************************************
*  函数名称   : BootLedMmap(*)
*  功能描述   : Led 控制寄存器地址映射
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : 无
*  输出参数   : 无
*  返 回 值   : BSP_OK 成功,BSP_ERROR 出错
*  其它说明   :
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A), 姜建奎@2013-03-26 11:14:27 创建 从r16trx 移植过来
*----------------------------------------------------------------------------
*/
ULONG BootLedMmap(VOID)
{
    INT     ifile;
    ULONG   ulSpaceProt = PROT_READ | PROT_WRITE;
	ULONG	ulVirAddr, ulPhyAddr;

    if ((ifile = open("/dev/mem", O_RDWR | O_SYNC)) < 0)
    {
    	dbgErr("open /dev/mem failed\n");
    	return BSP_ERROR;
    }

	ulPhyAddr = LED_BASE_ADDR + L4_SLOW_BASE_ADDR;
	ulVirAddr = LED_BASE_ADDR + L4_SLOW_VIRTUAL_BASE;
	
	ulVirAddr = (ULONG)mmap((void *)ulVirAddr, 0x100, ulSpaceProt, MAP_SHARED, ifile, ulPhyAddr);
	if (ulVirAddr != LED_BASE_ADDR + L4_SLOW_VIRTUAL_BASE)
	{                                                           
		dbgErr("%s %d 0x%x 0x%x map error\n", __FUNCTION__, __LINE__, ulPhyAddr, ulVirAddr);
		munmap(ulVirAddr, 0x100);
		close(ifile);
		return BSP_ERROR;
	}
	
	printf("%s %d 0x%x 0x%x\n", __FUNCTION__, __LINE__, ulPhyAddr, ulVirAddr);
	munmap(ulVirAddr, 0x100);
	close(ifile);
    return BSP_OK;

}
 /******************************************************************************
*  函数名称   : BootLedInit(*)
*  功能描述   :
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   :

*  输出参数   : 无
*  返 回 值   : BSP_OK, 操作成功; BSP_ERROR_INVALID_PARA, 输入参数错误
*  其它说明   : 无
*  函数属性   : 规避14boot引入的VSWR1灯上电未点灭问题
*------------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A), 耿佳佳2011-12-01 17:28:12 创建
*  $0000001(N/A), 姜建奎2013-02-26 11:28:12 根据r15trx 修改run 灯由PWM 来控制
*------------------------------------------------------------------------------
*/
ULONG BootLedInit(VOID)
{
	ULONG uliRet = BSP_OK;
	
    if (BSP_OK != BootLedMmap())
    {
        dbgErr("LedMmap Init Failed!\n");
        return BSP_ERROR;
    }
	
	
	return uliRet;
}
/*****************************************************************************
*  函数名称   : BspRdLedReg(*)
*  功能描述   : 读取Led控制寄存器
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : 无
*  输出参数   : 无
*  返 回 值   : BSP_OK 成功,BSP_ERROR 出错
*  其它说明   :
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A), 姜建奎@2013-03-26 11:14:27 创建 从r16trx 移植过来
*----------------------------------------------------------------------------
*/
ULONG BootRdLedReg(ULONG ulAddr)
{
    ULONG ulRegAddr = 0;

	ulRegAddr = ulAddr + LED_BASE_ADDR + L4_SLOW_VIRTUAL_BASE;

    return *((volatile ULONG *)ulRegAddr);
}

/*****************************************************************************
*  函数名称   : BspWrLedReg(*)
*  功能描述   : 写Led控制寄存器
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : 无
*  输出参数   : 无
*  返 回 值   : BSP_OK 成功,BSP_ERROR 出错
*  其它说明   :
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A), 姜建奎@2013-03-26 11:14:27 创建 从r16trx 移植过来
*----------------------------------------------------------------------------
*/
ULONG BootWrLedReg(ULONG ulAddr, ULONG ulData)
{
    ULONG ulRegAddr = 0;

	ulRegAddr = ulAddr + LED_BASE_ADDR + L4_SLOW_VIRTUAL_BASE;

    *((volatile ULONG *)ulRegAddr) = ulData;
	return BSP_OK;
}

/******************************************************************************
*  函数名称   : BspLedCtrl(*)
*  功能描述   : 实现对面板灯的控制
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : ulLedName   - 灯名, 定义于BspPublic.h文件或者BoardApi.h文件
                ulLedMode - 灯状态的控制
*  输出参数   : 无
*  返 回 值   : BSP_OK, 操作成功; BSP_ERROR_INVALID_PARA, 输入参数错误
*  其它说明   : 无
*  函数属性   : 基础接口
 *工装使用申明: 工装使用接口，请注意波及
*------------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A), 鲁侃@2010-06-21 17:28:12 创建
*  $0000000(N/A), 王茂金@2010-10-28 9:48:11 根据实际硬件和统一接口要求修改代码
*  $0000000(N/A), 崔文会@2011-01-25 9:48:11 根据实际硬件和统一接口要求修改代码
*------------------------------------------------------------------------------
*/
ULONG BootLedCtrl(ULONG ulLedname, ULONG ulLedMode)
{
    switch (ulLedname)
    {
        case BSP_LED_ID_RUN: /* LedRun*/
            {
                if( BSP_LED_OP_OFF == ulLedMode )
                {
                    BspSetGpioDataout(0,8,1);
                }
                else if( BSP_LED_OP_ON == ulLedMode )
                {
                    BspSetGpioDataout(0,8,0);
                }
                break;          
            }
        case BSP_LED_ID_ALM: /*LedAlm */
            {
                if( BSP_LED_OP_OFF == ulLedMode )
                {
                    BspSetGpioDataout(0,9,1);
                }
                else if( BSP_LED_OP_ON == ulLedMode )
                {
                    BspSetGpioDataout(0,9,0);
                }
                break;          
            }
		 default:
            {
                return BSP_ERROR_DEVICE_NOT_EXIST;
            }
    	}
    return BSP_OK;
}

/******************************************************************************
* 函数名称： PwmCtlLedRun
* 功能描述： ioctl控制RUN灯
* 输入参数：
*
* 输出参数： 无
* 返 回 值： 无
* 其它说明：
*
* 修改日期        版本号     修改人           修改内容
* ---------------------------------------------------------------
*
******************************************************************************/
/*宏定义*/
#define KDA_DEVICE_NAME "/dev/misc/KernDrvAgt"
int PwmCtlLedRun(int flag)
{
	int g_iKdaDrvFd=-1;
	BspMknod(KDA_DEVICE_NAME,"c","10","244");
    if ((g_iKdaDrvFd = open(KDA_DEVICE_NAME,O_RDWR | O_SYNC )) < 0)
    {
		printf("open " KDA_DEVICE_NAME " failed!");
        return -1;
    }
	ioctl(g_iKdaDrvFd, KDA_PWM_RUN, flag);

	close(g_iKdaDrvFd);
	g_iKdaDrvFd = -1;
	return 0;
}

/**************************************************************************
 * 函数名称: PwmLedRun
 * 功能描述: BOOTAPP阶段PWM模式控制RUN灯
 * 输入参数: 无
* 输出参数:
 * 返 回 值: 无
* 其它说明:
*
* 修改日期:    版本号     修改人        修改内容
* -----------------------------------------------
* 2018-10-30     V1.0      田雨        Created
**************************************************************************/
VOID PwmLedRun(UCHAR ucMode)
{
	if(1 == ucMode)
	{
		PwmCtlLedRun(1);/*PWM控制RUN灯闪烁*/
	}
	else if(0 == ucMode)
	{
		PwmCtlLedRun(0);/*PWM控制RUN常亮*/
	}
}

/**************************************************************************
 * 函数名称: int BootSetLedFlag(void)
 * 功能描述: 工装 应用程序入口
 * 输入参数: 无
* 输出参数:
 * 返 回 值: 无
* 其它说明:
*
* 修改日期:    版本号     修改人        修改内容
* -----------------------------------------------
* 2010-05-25     V1.0      xxx        Created
**************************************************************************/  

ULONG BootSetLedFlag(ULONG ulSwitch)
{
    if( 0 == ulSwitch)
		g_ulLedFlag = 0;
	else
		g_ulLedFlag = 1;

	return BSP_OK;
}

VOID BootLedBling(VOID)
{
    ULONG ucClkRate = sysClkRateGet();
    BootLedCtrl(BSP_LED_ID_RUN,BSP_LED_OP_OFF);
    taskDelay(ucClkRate);
	BootLedCtrl(BSP_LED_ID_RUN,BSP_LED_OP_ON);
	taskDelay(ucClkRate);
	/*先亮后灭的话，出现调度原因导致的闪灯过后常亮RUN灯偶发不亮的问题，调整为先灭后亮规避该问题*/
}

VOID BootLedTask(VOID)
{
    while(1)
    {
        if(0 != g_ulLedFlag)
        {
	        BootLedBling();
        }
		else
		{
		    BootSysMsDelay(500);
		}
    }  	
}

/**********************************************************************
* 函数名称:void led_run(unsigned char ucMode)
* 功能描述:led_run led灯闪烁模式
* 输入参数: ucMode  0 只亮run灯,  1 run灯周期性闪
* 输出参数:无。
* 返 回 值:无
* 其它说明: dpdic led 使用情况:
GPIO 14 -- RUN
GPIO 15 -- ALM
GPIO 16 --OPT0
GPIO 17 -- OPT1
GPIO 19 --VSWR
GPIO 20 -- ACT
* 修改日期        版本号     修改人          修改内容
* -----------------------------------------------
* 2015/10/12            V1.0            00086970                       创建
***********************************************************************/

VOID BootLedRun(UCHAR ucMode)
{

    if(0 == ucMode)/*只亮run灯,其他灯灭 */
    {  
        BootSetLedFlag(0);
        BootLedCtrl(BSP_LED_ID_ALM, BSP_LED_OP_OFF);
        if(1 == dra62x_is_config(PWM_RUN))
        {
        	;
        }
        else
        {
        	BootLedCtrl(BSP_LED_ID_RUN, BSP_LED_OP_ON);
        }
    }
    else if(1 == ucMode)/*run灯周期性闪烁*/
    {  
    	BootLedCtrl(BSP_LED_ID_ALM, BSP_LED_OP_OFF);
        if(1 == dra62x_is_config(PWM_RUN))
        {
        	PwmLedRun(1);
        }
        else
        {
            BootSetLedFlag(1);
        }
    }
    else if(2 == ucMode)/*所有灯都全亮*/
    {
        BootSetLedFlag(0);
        if(1 == dra62x_is_config(PWM_RUN))
        {
        	PwmLedRun(0);
        }
        else
        {
            BootLedCtrl(BSP_LED_ID_RUN, BSP_LED_OP_ON);
        }
        BootLedCtrl(BSP_LED_ID_ALM, BSP_LED_OP_ON);
    }
    else
    {
        printf("BootLedRun, input params[%d] error\n", ucMode);
    }
}

ULONG BootGpioInit(VOID)
{
     BspGpioInit();
     BspSetGpioDataout(0,8,0); /*RUN输出模式前灯默认亮*/
	 BspSetGpioDir(0,8,0);
	 BspSetGpioDataout(0,9,1); /*ALM输出模式前灯默认灭*/
	 BspSetGpioDir(0,9,0);
     BspSetGpioDir(1,29,1);
	 BspSetGpioDir(1,30,1);
     BspSetGpioDir(2,10,0);
	 BspSetGpioDir(4,31,0);
	 return BSP_OK;
}
/*****************************************************************************
*  函数名称   : BootBoardHwPreInit()
*  功能描述   : Bsp单板预初始化函数
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : 无
*  输出参数   : 无
*  返 回 值   : BSP_OK, 其它值为失败
*  其它说明   : 无
 *工装使用申明: 无
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A), 崔文会@2012-11-22 16:35:09, 创建
*----------------------------------------------------------------------------
*/
ULONG BootBoardHwPreInit(VOID)
{
    ULONG ulRet = BSP_OK;
   // ulRet|=BootPrcmInit(); 
	ulRet|=BootI2cBusInit(I2C_BUS_ID_PCA9535);/*IIC 初始化*/
    ulRet|=BootBomIdInit();           /*PA9535初始化*/
    ulRet|=BootGpioInit();            /*GPIO初始化*/
    ulRet|=BootWdtInit();
    return ulRet;
}

ULONG BootCpswAleMmap(void)
{
    ULONG	ulVirAddr = 0; 
	ULONG   ulPhyAddr = 0;
	ULONG   ulSpaceProt = PROT_READ | PROT_WRITE;
	int     ifile;

    if ((ifile = open("/dev/mem", O_RDWR | O_SYNC)) < 0)
    {
    	printf("open /dev/mem failed\n");
    	return BSP_ERROR;
    }
	
	ulPhyAddr = CPSW_BASE_ADDR + L4_SLOW_BASE_ADDR;
	ulVirAddr = CPSW_BASE_ADDR + L4_SLOW_VIRTUAL_BASE;
	
	
    ulVirAddr = (ULONG)mmap((void *)ulVirAddr, CPSW_REGS_SIZE, ulSpaceProt, MAP_SHARED, ifile, ulPhyAddr);
	
	if (ulVirAddr != CPSW_BASE_ADDR + L4_SLOW_VIRTUAL_BASE)
	{                                                           
		printf("%s %d 0x%x 0x%x map error\n", __FUNCTION__, __LINE__, ulPhyAddr, ulVirAddr);
		close(ifile);
		return BSP_ERROR;
	}
	printf("%s %d 0x%x 0x%x\n", __FUNCTION__, __LINE__, ulPhyAddr, ulVirAddr);
	close(ifile);
	return BSP_OK;
}
/**************************************************************************
* 函数名称： SetEthProMode
* 功能描述： 设置ETH的模式寄存器的混杂模式控制位
* 输入参数： 0--对进入的帧的目的地址进行检查。1--对进入的帧的目的地址不进行检查。
* 输出参数： 无
* 返 回 值：
* -------------------------------------------------------
* 其它说明：
* 修改日期     版本号        修改人	            修改内容
* 2015/10/22     V1.0         00086970           创建
**************************************************************************/
ULONG SetEthProMode(UCHAR ucValue)
{ 
    ULONG ulRet=0;  
	
    ulRet = *(unsigned int *)(CPSW_BASE_ADDR + L4_SLOW_VIRTUAL_BASE + CPSW_ALE_CONTRAL);

    printf("1:CPSW_ALE_CONTRAL = 0x%x \n",ulRet);
    if (ucValue == 0)
    /*对进入的帧的目的地址进行检查*/
    {
        ulRet = ulRet & 0xFFFFFFEF;
    }
    /*对进入的帧的目的地址不进行检查*/
    else
    {
                
        ulRet = ulRet | 0x00000010;
    }

    *(unsigned int *)(CPSW_BASE_ADDR + L4_SLOW_VIRTUAL_BASE+CPSW_ALE_CONTRAL) = ulRet;
        
    printf("2:CPSW_ALE_CONTRAL = 0x%x \n",ulRet);
	return ulRet;
     
}

ULONG BootBoardPreInit(VOID)
{
    ULONG ulRet = BSP_OK;

    printf("\n BootBoardPreInit. \n");

	ulRet = GetCmdline();/*cmdline装载*/
	if(BSP_ERROR == ulRet)
	{
        SetDefaultCmdline();
	}
    ulRet |= BootDevMemMap(); /*高端内存和RTC映射*/
    ulRet |= BootBoardHwPreInit();  /*I2C初始化bomid初始化看门狗映射*/
    BootLedRun(0);
    ulRet |= BootFlashInit();/*flash划分*/
	ulRet |= BootCpswAleMmap();/*Cpsw寄存器映射*/
	return ulRet;
     
}


ULONG memflag_set(ULONG writeval)
{
    *(volatile ULONG *)(g_ulRtcRegisterAddr + RTC_K0) = RTC_K0_KEY;
	*(volatile ULONG *)(g_ulRtcRegisterAddr + RTC_K1) = RTC_K1_KEY;
	*(volatile ULONG *)(g_ulRtcRegisterAddr + FLAG_MEMBASE) = writeval;
	*(volatile ULONG *)(g_ulRtcRegisterAddr + RTC_K0) = RTC_K0_KEY;
	printf("check_flag=0x%x\n",*(volatile ULONG *)(g_ulRtcRegisterAddr + FLAG_MEMBASE)&0x0FF);
	
	return 0;
}

ULONG bootflag_get()
{
	return (*(volatile ULONG *)(g_ulRtcRegisterAddr + FLAG_MEMBASE)&0x0FF);		
}

 VOID boot_flag_set()
 {
	ULONG check_flag=0;
	
	check_flag=bootflag_get();

	if(check_flag==MASTER_BOOT_OK)  /*本次是上电或者复位后第一次启动,启动主boot成功*/
	{
		memflag_set(MASTER_KUBOOT_OK);
		/*尚欠写高端内存表征主boot启动成功标志*/
	}
	else if(check_flag==MASTER_KUBOOT_OK) /*启动主boot成功，继续尝试引导CPU版本*/
	{
		memflag_set(MASTER_KUBOOT_OK);
		/*尚欠写高端内存表征主boot启动成功标志*/
	}
	else if(check_flag==SLAVE_BOOT_OK)  /*启动从boot成功，*/
	{
		memflag_set(SLAVE_KUBOOT_OK);
		/*尚欠写高端内存表征从boot启动成功标志*/
	}
	else if(check_flag==SLAVE_KUBOOT_OK)   /*启动从boot成功，继续尝试引导CPU版本*/
	{
		memflag_set(SLAVE_KUBOOT_OK);
		/*尚欠写高端内存表征从boot启动成功标志*/
	}
}


/**********************************************************************
* 函数名称:BootGmac0MiiRead
* 功能描述:通过GMII寄存器读PHY  .  针对以太网口GMAC0
* 输入参数: *     - udCsrClockRange：CSR 时钟区域
 *     - udGR： GMII寄存器
 *     - udPA： PHY设备物理层地址
 *     - pudData：需要读出的数据的地址
* 输出参数:
* 返 回 值:
* 其它说明:
* 修改日期        版本号     修改人          修改内容
* -----------------------------------------------
* 2014-5-28       V1.0       yam             创建
*  $0000000(N/A), zhaoyun@20141216 19:33:10 trm78E
***********************************************************************/
ULONG BootDebugMiiRead(ULONG ulCsrClockRange, ULONG ulGR, ULONG ulPA, ULONG *pulData)
{
    int timeout = CONFIG_MDIO_TIMEOUT;
    ULONG ulReadData = 0;
    ULONG ulWriteData = 0;	
    if(NULL == pulData)
    {
    	return BSP_E_POINTER_NULL;
    }

    while(timeout)
    {
    	if(0 == *(volatile unsigned long *)(MDIO_BASE_ADDR + L4_SLOW_VIRTUAL_BASE + MDIO_USER0_ACCESS_REG) & USERACCESS_GO);
		{
            break;
    	}
        timeout--;
    }

    if (timeout <= 0)
    {
        return BSP_E_REG_ACCESS_TIMEOUT;
    }

    ulWriteData = (USERACCESS_GO | USERACCESS_READ | (ulGR << 21) |
	       (ulPA << 16));

    *(volatile unsigned long *)(MDIO_BASE_ADDR + L4_SLOW_VIRTUAL_BASE + MDIO_USER0_ACCESS_REG)=ulWriteData; 
   
    timeout = CONFIG_MDIO_TIMEOUT*10;
    while(timeout)
    {
        ulReadData = *(volatile unsigned long *)(MDIO_BASE_ADDR + L4_SLOW_VIRTUAL_BASE + MDIO_USER0_ACCESS_REG);
		
    	if(0 == (ulReadData & USERACCESS_GO))
    	{
            break;
    	}
        timeout--;
    }
   
    if (timeout <= 0)
    {
       
        return BSP_E_REG_ACCESS_TIMEOUT;
    }
	
    *pulData = (ulReadData & USERACCESS_ACK) ? (ulReadData & USERACCESS_DATA) : -1;
	
	return (ulReadData & USERACCESS_ACK) ? BSP_OK : BSP_ERROR;
   
}
/**********************************************************************
* 函数名称:BootGmac0MiiWrite
* 功能描述:通过GMII寄存器写PHY  .  针对以太网口GMAC0
* 输入参数: *     - udCsrClockRange：CSR 时钟区域
 *     - udGR： GMII寄存器
 *     - udPA： PHY设备物理层地址
 *     - pudData：需要读出的数据的地址
* 输出参数:
* 返 回 值:
* 其它说明:
* 修改日期        版本号     修改人          修改内容
* -----------------------------------------------
* 2014-5-28       V1.0       yam             创建
*  $0000000(N/A),00086970 19:33:10 trm78E
***********************************************************************/
ULONG BootDebugMiiWrite(ULONG ulCsrClockRange, ULONG ulGR, ULONG ulPA, ULONG ulData)
{
    int timeout = CONFIG_MDIO_TIMEOUT;
    ULONG ulReadData = 0;
    ULONG ulWriteData = 0;	

    while(timeout)
    {
    	if(0 == (*(volatile unsigned long *)(MDIO_BASE_ADDR + L4_SLOW_VIRTUAL_BASE + MDIO_USER0_ACCESS_REG) & USERACCESS_GO));
        {
            break;
    	}
		
        timeout--;
    }

    if (timeout <= 0)
    {
        return BSP_E_REG_ACCESS_TIMEOUT;
    }

    ulWriteData = (USERACCESS_GO | USERACCESS_WRITE | (ulGR << 21) |
		   (ulPA << 16) | (ulData & USERACCESS_DATA));
                                     
    *(volatile unsigned long *)(MDIO_BASE_ADDR + L4_SLOW_VIRTUAL_BASE + MDIO_USER0_ACCESS_REG)=ulWriteData;

	
    timeout = CONFIG_MDIO_TIMEOUT;
    while(timeout)
    {
    	if(0 == *(volatile unsigned long *)(MDIO_BASE_ADDR + L4_SLOW_VIRTUAL_BASE + MDIO_USER0_ACCESS_REG) & USERACCESS_GO);
        {
            break;
    	}
		
        timeout--;
    }

    if (timeout <= 0)
    {
        return BSP_E_REG_ACCESS_TIMEOUT;
    }
	BootDebugMiiRead(ulCsrClockRange,ulGR,ulPA,&ulReadData);
    printf("Addr:0x%x,Reg:0x%x,WriteData:0x%x,ReadData:0x%x\n",ulPA,ulGR,ulData,ulReadData);
    return BSP_OK;
}
/**********************************************************************
* 函数名称： BootGetDownloadFlag
* 功能描述： MIO14指示起保护区版本or下载版本。
* 输入参数： 无
* 输出参数： 无
* 返 回 值： 0:起保护区版本 1:下载版本
* 其它说明： dra62x写死起保护区版本
* 修改日期        版本号     修改人	      修改内容
* -----------------------------------------------
* 2012/07		   V1.0	     ZKH	      
***********************************************************************/
ULONG BootGetDownloadFlag(void)
{       
    return 0;   
}
ULONG BootGetBoardType(void)
{
    if( 0 == BspGetGpioDatain(1, 29) && (1== BspGetGpioDatain(1, 30) ))
    {
        printf("5G_LOWFRE_20!\n"); 
        return 1;
    }
    else
    {
        printf("5G_HIGHFRE!\n"); 
        return 2;
    }
}

/**************************************************************************
* 函数名称： unsigned char  dra62x_get_sysid()
* 功能描述： 获取SYS ID号
* 输入参数： void
* 输出参数： 无
* 返 回 值： DRAM ID号
* -----------------------------------------------------------------------
* 其它说明：
* 修改日期     版本号     修改人	     修改内容
* 2017/10/20             V1.0             niuyanru            creat
**************************************************************************/
static unsigned char ucsysid=0xff;
unsigned char  dra62x_get_sysid (void)
{   
    /*if have getted dramid, return*/
    if(0xff != ucsysid)
        return ucsysid;

    ucsysid = (unsigned char)(BspGetGpioDatain(1,30))<<1;
    ucsysid |= (unsigned char)BspGetGpioDatain(1,29);

    printf("SysId == %d \n",ucsysid);
    return ucsysid;
}
/**************************************************************************
* 函数名称： unsigned char  dra62x_get_appid()
* 功能描述： 获取APP ID号
* 输入参数： void
* 输出参数： 无
* 返 回 值： DRAM ID号
* -----------------------------------------------------------------------
* 其它说明：
* 修改日期     版本号     修改人	     修改内容
* 2017/10/20             V1.0             niuyanru            creat
**************************************************************************/
static unsigned char ucappid=0xff;
unsigned char  dra62x_get_appid (void)
{   
    /*if have getted dramid, return*/
    if(0xff != ucappid)
        return ucappid;

    ucappid = (unsigned char)(BspGetGpioDatain(1,15))<<1;
    ucappid |= (unsigned char)BspGetGpioDatain(1,14);

    printf("AppId == %d \n",ucappid);
    return ucappid;
}
/* 1：需要配置
   0：不配置  */
int dra62x_is_config(enum e_dra624_module_cfg_t dra624_module )
{
    int iRet = 0;
    int appid = 0;
    int sysid = 0;
    appid = dra62x_get_appid();
    sysid = dra62x_get_sysid();
    switch(dra624_module)
    {
        case ETH1_1512_PHY:
            if (0x2 == sysid) iRet = 1;
            else if ((0x1 == appid)&&(0x1 == sysid)) iRet = 1;
            else if ((0x1 == appid)&&(0x0 == sysid)) iRet = 1;
            else if ((0x1 == appid)&&(0x3 == sysid)) iRet = 1;
            break;
        case PCIE:
            if ((0x1 == appid)&&(0x2 == sysid)) iRet = 1;
            else if ((0x1 == appid)&&(0x0 == sysid)) iRet = 1;
            break;
        case UART4_TTYO4:
            if ((0x1 == appid)&&(0x2 == sysid)) iRet = 1;
            else if ((0x1 == appid)&&(0x0 == sysid)) iRet = 1;
            else if ((0x1 == appid)&&(0x3 == sysid)) iRet = 1;
            break;
        case UART4_DEV:
            if ((0x1 == appid)&&(0x1 == sysid)) iRet = 1;
            else if ((0x2 == appid)&&(0x2 == sysid)) iRet = 1;
            break;
        case UART6_TTYO6:
            if ((0x1 == appid)&&(0x2 == sysid)) iRet = 1;
            else if ((0x1 == appid)&&(0x1 == sysid)) iRet = 1;
            else if ((0x1 == appid)&&(0x0 == sysid)) iRet = 1;
            break;
        case AC_CONFIG_MODE:
            if ((0x1 == appid)&&(0x2 == sysid)) iRet = 1;
            else if ((0x1 == appid)&&(0x1 == sysid)) iRet = 1;
            else if ((0x1 == appid)&&(0x0 == sysid)) iRet = 1;
            else if ((0x1 == appid)&&(0x3 == sysid)) iRet = 1;
            break;
        case SWITCH_RESET:
            if ((0x2 == appid)&&(0x2 == sysid)) iRet = 1;
            break;
        case PWM_RUN:
        	if ((0x1 == appid)&&(0x0 == sysid)) iRet = 1;
            else if ((0x1 == appid)&&(0x3 == sysid)) iRet = 1;
        	break;
        default:
            break;
    }
     return iRet;
}

/**********************************************************************
* 函数名称： BootGetFsRecoverFlag
* 功能描述： 从高端内存获取用户态文件系统异常标志
* 输入参数： 无
* 输出参数： 无
* 返 回 值： 0:正常 0xdeadbeaf:异常
* 其它说明： 获取后清除
* 修改日期        版本号     修改人	      修改内容
* -----------------------------------------------
* 2012/07		   V1.0	     ZKH	      
***********************************************************************/
ULONG BootGetFsRecoverFlag(VOID)
{
    ULONG ulUbifsFormat_mask = 0;
    ulUbifsFormat_mask = *(ULONG *)FS_FORMAT_FLAG;
    memset((CHAR*)FS_FORMAT_FLAG, 0, 4);/* 清空 */
    return ulUbifsFormat_mask;
}
/*****************************************************************************
 *  函数名称   : main(*)
 *  功能描述   : bootapp程序处理主函数
 *  读全局变量 : 无
 *  写全局变量 : 无
 *  输入参数   : argc   - 参数个数
                 argv[] - 参数列表
 *  输出参数   : 无
 *  返 回 值   : 0为成功, 其余失败
 *  其它说明   :
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *  $0000000(N/A), 00086970 @2015-10-28
 *----------------------------------------------------------------------------
 */
int main(int argc, char *argv[])
{
    int iBootAppTaskID = 0;
    ULONG ulRet = 0;    

    ulRet |= BootLedInit();
    ulRet |= BootBoardPreInit();	
    ulRet |= BootWatchDogInit();
    ulRet |= (ULONG)ushell_init();
    ulRet |= BootSoftModInit();
    if(1 == dra62x_is_config(SWITCH_RESET))
    {
        printf("Init BoardSwitch.\n");   
        ulRet |= BootBoardSwitchInit();    
    }
    ulRet |= BootPhyLinkInit();
    if(1 == dra62x_is_config(PWM_RUN))
    {
        printf("PWM_RUN is config.\n");
    }
    else
    {
		/*tLedTask在vx中优先级设置为0，在vxadp.c中翻转为Linux中的97*/
		taskSpawn("tLedTask",   \
			0, /* priority */            \
			0,   /* option   */           \
			0x100,/* stack size */      \
			(FUNCPTR)BootLedTask, 0, 0, 0, 0, 0, 0, 0, 0 ,0,0);
    }
	
	iBootAppTaskID = taskSpawn("tBootTask",   \
        100, /* priority */            \
        0,   /* option   */           \
        0x1000,/* stack size */      \
        (FUNCPTR)MainLoop, 0, 0, 0, 0, 0, 0, 0, 0 ,0,0);

    while(1)
    {
       //BspFunction("/boot.out", CFG_PROMPT);
       sleep(20);
    }
    return ulRet;


}
#endif

/* Started by AICoder, pid:948f3959f4racab14572089ba06e621b50d0f841 */
ULONG SetDefaultCmdline()
{
    #if defined(KEXECBOOT_SUPPORT)
    strncpy((char *)g_ucCmdLine, "console=ttyO0,115200n8 mem=250M earlyprintk root=/dev/ram0 rw init=/init kexecboot=1", 256);
    #else
    strncpy((char *)g_ucCmdLine, "console=ttyO0,115200n8 mem=122M earlyprintk root=/dev/ram0 rw init=/init ", 256);
    #endif
    printf("/proc/cmdline error, load default cmdline.\n");
    return BSP_OK;
}
/* Ended by AICoder, pid:948f3959f4racab14572089ba06e621b50d0f841 */


/*****************************************************************************
 * 版权所有(C) 2017, ZTE Corp. 
 *----------------------------------------------------------------------------
 * 模 块 名 : switchctrl
 * 文件名称 : switchctrlboot.c
 * 文件标识 : {[N/A]}
 * 内容摘要 : KEXECBOOT 对交换芯片控制
 * 注意事项 : 无
 * 作    者 : yam
 * 创建日期 :  2017-03
 * 当前版本 : Ver1.0
 *----------------------------------------------------------------------------
 * 变更记录 :
 *
 * $记录1
 * 变 更 单: $0000000(N/A)
 * 责 任 人: yam
 * 修改日戳: yam   2017-03   creat
 * 变更说明: 创建
 *----------------------------------------------------------------------------
 */
 
#if defined(COMPILE_FOR_KEXEC_BOOT)
#include "bsppub.h"
#include "bcm5396api.h"
#include "dra62xspi.h"
#include "switchctrlboot.h"
#include "dra62xgpio.h"


/** yam infrom: bcm5396 port utilization for 5g low frq V2.0
SGMII1~8：SOCFPGA0~7
SGMII9：PHY_88E1512（SGMII转换为RGMII信号与CPU相连）
SGMII10~11：BBFPGA0~1
each port 1000MB/s full deplux sgmii mode */

static UCHAR ucHwAddr0[6]={0x40,0x00,0xc1,0xfe,0x00,0x01};/** bind to port8 connect with fpga0*/
static UCHAR ucHwAddr1[6]={0x40,0x00,0xc1,0xfe,0x00,0x02};/** bind to port9 connect with fpga1*/

/* DRA62X最大支持4个BUS, 每个BUS最大支持4个设备SPI_SCS[n] */
static SEM_ID g_tHwSpiBusSemId[SPI_BUS_ID_ALL_SUM];
static T_SPI_DRV s_atHwSpiBusDrv[SPI_BUS_ID_ALL_SUM][SPI_DEV_CS_ALL_SUM] = {0, };
static T_DRA62X_SPI_PARA s_atHwSpiPrivPara[SPI_BUS_ID_ALL_SUM][SPI_DEV_CS_ALL_SUM] = {0, };



/*******************************************************************************
函数功能:打印mac地址用
********************************************************************************/
void printhex(void *hex, int len, char *tag)
{
	int i;
	unsigned char *p = (unsigned char *)hex;

	if(len < 1)
		return;

	for(i = 0; i < len - 1; i++){
		if(*p < 0x10)
			printf("0%x%s", *p++, tag);
		else
			printf("%2x%s", *p++, tag);
	}

	if(*p < 0x10)
		printf("0%x\n", *p++);
	else
		printf("%2x\n", *p++);
}

/*****************************************************************************
 *  函数名称   : _Bcm5396PortEnable(*)
 *  功能描述   : BROADCOM 交换芯片BCM5396端口使能
 *  读全局变量 : 无
 *  写全局变量 : 无
 *  输入参数   : 无
 *  输出参数   : 无
 *  返 回 值   : 成功 - BSP_OK
 *  其它说明   :  
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *  $0000000(N/A),  yam   2017-03   creat
 *----------------------------------------------------------------------------
 */
ULONG _Bcm5396PortEnable(void)
{         
    ULONG ulChipId = 0;
    ULONG ulRet = 0;
    int iLoop = 0;

    for (iLoop = 0; iLoop < 11; iLoop ++)
    {
        ulRet = BspBcm5396PortEnable(ulChipId, iLoop);
        if (BSP_OK != ulRet)
        {
            printf("%s: line%d. BCM5396 port %d enable failed!\n", 
					__FUNCTION__, __LINE__, iLoop);
            return BSP_ERROR;
        }
    }

    return BSP_OK;  
}

/*****************************************************************************
 *  函数名称   : _BootHwSpiInit(*)
 *  功能描述   : boot阶段对dra624硬件SPI控制器初始化
 *  读全局变量 : 无
 *  写全局变量 : 无
 *  输入参数   : 无
 *  输出参数   : 无
 *  返 回 值   : 成功 - BSP_OK
 *  其它说明   :  
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *  $0000000(N/A),  yam   2017-03   creat
 *----------------------------------------------------------------------------
 */
ULONG _BootHwSpiInit(void)
{
    ULONG ulDevIndex = 0;
    ULONG ulHwBusDevSum = 0;
    ULONG ulTmpRet = BSP_OK;
    ULONG ulFuncRet = BSP_OK;
    T_SPI_DRV *ptSpiBusDrv = NULL;
    T_DRA62X_SPI_PARA *ptHwSpiPara = NULL;

    g_tHwSpiBusSemId[SPI_BUS_2] = semBCreate(SEM_Q_FIFO, SEM_FULL);
    if (NULL == g_tHwSpiBusSemId[SPI_BUS_2])
    {
        printf("%s: line%d. Error!HwSpiBus'%d Sem Create Fail\n", 
				__FUNCTION__, __LINE__, SPI_BUS_2);
        return BSP_ERROR;
    }

   ulHwBusDevSum = 1; /**SPI2 CS[0] connect to BCM5396, 
   			no other SPI should be initialized in KEBOOT*/

    for (ulDevIndex = 0; ulDevIndex < ulHwBusDevSum; ulDevIndex++)
    {    
        ptHwSpiPara = &s_atHwSpiPrivPara[SPI_BUS_2][ulDevIndex];
        memset((UCHAR *)ptHwSpiPara, 0, sizeof(T_DRA62X_SPI_PARA));

        ptHwSpiPara->ulBusId = SPI_BUS_2;
        ptHwSpiPara->ulMax_hz = DRA62X_SPI_MAX_FREQ / 24; // yam todo: may need modify
        ptHwSpiPara->ulMode = (SPI_MODE_1 | SPI_CS_HIGH);
        ptHwSpiPara->ulCs = ulDevIndex;
        ptHwSpiPara->wordLen = 1;

        ptSpiBusDrv = &s_atHwSpiBusDrv[SPI_BUS_2][ulDevIndex];
        memset((UCHAR *)ptSpiBusDrv, 0, sizeof(T_SPI_DRV));

        ptSpiBusDrv->ulSpiDrvId = BSP_HWSPI_ID_DRV_BUS_2 | ulDevIndex;
        ptSpiBusDrv->ulDrvType = SPI_DRV_TYPE_DRA62X;
    //  ptSpiBusDrv->ulSpiMode = SPI_MODE_0;
        ptSpiBusDrv->pPrivateData = (VOID *)ptHwSpiPara;
        
        ulTmpRet = BspDra62xSpiInit(ptSpiBusDrv);
        if (BSP_OK != ulTmpRet)
        {
            ulFuncRet |= BSP_BIT_SET(1 + ulDevIndex);
            printf("%s: line%d. DevIndex'%d SpiBusDrv init Error!ErrRet= 0x%x\n",
                   __FUNCTION__, __LINE__, ulDevIndex, ulTmpRet);
        }
    }
	
    return ulFuncRet;
}

/**************************************************************************
* 函数名称: _Bcm5396Select
* 功能描述: bcm5396片选选择
* 输入参数: ulChip  -芯片号   ulEnabled-是否片选选中
* 输出参数: 无
* 返 回 值: BSP_OK  
*           其它
* 其它说明:  
* 修改日期       版本号     修改人	     修改内容
* -----------------------------------------------
 *  $0000000(N/A),  yam   2017-3   creat
**************************************************************************/
VOID _Bcm5396Select(ULONG ChipIdx, ULONG ulEnabled)
{
    /**yam infrom:
         暂时不挂载软件层面的片选驱动, 打桩处理
         5g低频2.0实际用dra624的硬件SPI, 非软件模拟SPI
	*/
    return;
}

/*****************************************************************************
 *  函数名称   : _Bcm5396ParaInit(*)
 *  功能描述   : BROADCOM 交换芯片BCM5396参数初始化
 *  读全局变量 : 无
 *  写全局变量 : 无
 *  输入参数   : 无
 *  输出参数   : 无
 *  返 回 值   : 成功 - BSP_OK
 *  其它说明   :  
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *  $0000000(N/A),  yam   2017-03   creat
 *----------------------------------------------------------------------------
 */
ULONG _Bcm5396ParaInit(void)
{         
    T_BCM5396_PARA tBCM5396Para;
    ULONG ulRetVal = 0;
	
    memset(&tBCM5396Para, 0, sizeof(tBCM5396Para));
    tBCM5396Para.ulChipIndex = 0;

    /* 指明使用的SPI控制器编号, BCM5396挂在 SPI2 CS[0]*/	
    tBCM5396Para.tSpiOwner.ulSpiDrvId = s_atHwSpiBusDrv[SPI_BUS_2][0].ulSpiDrvId;
    tBCM5396Para.tSpiOwner.ulSpiMode = SPI_MODE_1;  // yam todo may modify
    tBCM5396Para.tSpiOwner.ulSpiOwner = 0; // yam todo may modify
    tBCM5396Para.pFuncSelect = _Bcm5396Select;

    ulRetVal = BspBcm5396ConfigInit(&tBCM5396Para);
    if (BSP_OK != ulRetVal)
    {
        printf("%s: line%d. BspBcm5396ConfigInit error!Ret 0x%x\n", __FUNCTION__, __LINE__, ulRetVal);
        return ulRetVal;
    }

    return BSP_OK;  
}

/**************************************************************************
* 函数名称: ULONG _BootSwitchReset(void)
* 功能描述: 对交换芯片复位操作
* 输入参数: 无
* 输出参数: 无
* 返 回 值: BSP_OK:成功
*            其他   失败
* 其它说明: 
* 修改日期:    版本号     修改人        修改内容
* -----------------------------------------------
 *  $0000000(N/A),  yam   2017-3   creat
**************************************************************************/
ULONG _BootSwitchReset(void)
{
    ULONG ulRet = 0;
	
    /**GP4<26> to control reset of  switch chip */
    ulRet |= BspSetGpioDir(TI81XX_GPIO_BANK4, 26, DRA62X_GPIO_DIR_OUT);
    ulRet |= BspSetGpioDataout(TI81XX_GPIO_BANK4, 26, TRUE);
    taskDelay(1);   /* 10ms */
    ulRet |= BspSetGpioDataout(TI81XX_GPIO_BANK4, 26, FALSE);
    /* 低电平保持至少50ms */
    taskDelay(6);   /* 60ms */
    ulRet |= BspSetGpioDataout(TI81XX_GPIO_BANK4, 26, TRUE);
    taskDelay(1);   /* 10ms */
    if (BSP_OK != ulRet)
    {
        printf("%s:line%d. Reset switch chip failed! Ret[0x%x]\n", __FUNCTION__, __LINE__, ulRet);
        return BSP_ERROR;
    }
    return BSP_SUCCESS;
}

VOID bcm5396test(VOID)
{
    T_BCM5396_REG tBCM5396;
    tBCM5396.RegPageAddr = CONTROL_REG;
    tBCM5396.RegAddr = 0x86;
    tBCM5396.RegWidth = 1;
    BspBcm5396RegRead(0, &tBCM5396);
}

/**************************************************************************
* 函数名称: _Bcm5396Check
* 功能描述: 检查芯片复位后的默认配置及芯片读写是否正常
* 输入参数: ulChip  -芯片号
* 输出参数: 无
* 返 回 值: BSP_OK  
*           其它
* 其它说明:  自动测试bcm5396状态及读写,需要在复位芯片之后调用
* 修改日期       版本号     修改人	     修改内容
* -----------------------------------------------
 *  $0000000(N/A),  yam   2017-3   creat
**************************************************************************/
ULONG _Bcm5396Check(void)
{
    ULONG ulRetVal = BSP_OK;
    ULONG ulChip = 0;
    T_BCM5396_REG tBCM5396;
    ULONG loop = 0;

    /* aucRegWrData[0]为默认值,其它为要进行读写测试的寄存器值 */
    UCHAR aucRegWrData[] = {0x00, 0x55, 0xaa, 0xff};

    memset((void *)&tBCM5396, 0, sizeof(T_BCM5396_REG));

    /* 复位交换芯片BCM5396 , 之前已复位过, 可以去掉*/
    /*ulRetVal = _BootSwitchReset();
    if (BSP_OK != ulRetVal)
    {
        printf("%s: line%d. reset switch chip error! \n", __FUNCTION__, __LINE__);
        return BSP_ERROR;
    }*/

    /* external phy scan control reg (PAGE 00h: ADDRESS 086h)
    hardware should default disable AUTO PULL,   AUTO_POLL pull-up is DIS=1   DISABLE
    ~AUTO_POLL pin strap value default set to bit7(external phy scan enable bit), should be 0 */
    tBCM5396.RegPageAddr = CONTROL_REG;
    tBCM5396.RegAddr = 0x86;
    tBCM5396.RegWidth = 1;
    if (BSP_OK != BspBcm5396RegRead(ulChip, &tBCM5396))
    {
        return BSP_ERROR;
    }
    if (tBCM5396.DataBuf[0] & 0x80)
    {
        printf("%s: line%d. BCM5396 Configuration Pin error: AUTO_POLL\n", __FUNCTION__, __LINE__);
        tBCM5396.DataBuf[0] &= 0x7f; /* disable external phy scan bit7*/
        BspBcm5396RegWrite(ulChip, &tBCM5396);
        //ulRetVal |= MT_ETH_SW_ERR_AUTO_POLL;
    }

    /* HW_FWDG_EN pin hardware default disable, resistance pull-down
       SWITCH MODE REGISTER (PAGE 00h: ADDRESS 20h)
       HW_FWDG_EN bit1 */
    tBCM5396.RegPageAddr = CONTROL_REG;
    tBCM5396.RegAddr = SWITCH_MODE_ADDR;
    tBCM5396.RegWidth = SWITCH_MODE_LEN;
    if (BSP_OK != BspBcm5396RegRead(ulChip, &tBCM5396))
    {
        printf("%s: line%d. BspBcm5396RegRead error!\n", __FUNCTION__, __LINE__);
        return MT_ETH_SW_ERR_READ;
    }
    /*HW_FWDG_EN pin hardware default diable, resistance pull-down 
        so that SW_FWDG_EN is 0 and SW_FWDG_MODE is 1, means manage mode*/
    if ((tBCM5396.DataBuf[0] & 0x02))
    {
        printf("%s: line%d. BCM5396 Configuration Pin error: HW_FWDG_EN\n", __FUNCTION__, __LINE__);
        tBCM5396.DataBuf[0] &= 0xfD; /* should disable SW_FWDG_EN bit1*/
        BspBcm5396RegWrite(ulChip, &tBCM5396);
        //ulRetVal |= MT_ETH_SW_ERR_HW_FWDG_EN;
    }

    /* RATE_CON_EN default disable
       PORT N receive rate control register (PAGE 041H, ADDRESS 010h)
       bit22 RATE_CON_EN should be 0 */
    tBCM5396.RegPageAddr = RATE_LIMIT_REG;
    tBCM5396.RegWidth = RATE_INGR_CTRL_PX_LEN;
    for (loop = 0; loop < 11; loop ++)
    {
        tBCM5396.RegAddr = RATE_INGR_CTRL_P0_ADDR + loop*RATE_INGR_CTRL_PX_LEN;
        if (BSP_OK != BspBcm5396RegRead(ulChip, &tBCM5396))
        {
            printf("%s: line%d. BspBcm5396RegRead error!\n", __FUNCTION__, __LINE__);
            return MT_ETH_SW_ERR_READ;
        }
        if ((tBCM5396.DataBuf[2] & 0x40))
        {
            printf("BCM5396 Configuration Pin error: port 0x%x RATE_CON_EN\n", tBCM5396.DataBuf[2]);
            tBCM5396.DataBuf[2] &= 0xBf; /*clear bit 22, disable rate control function for one port*/
            BspBcm5396RegWrite(ulChip, &tBCM5396);
            //ulRetVal |= MT_ETH_SW_ERR_BC_SUPP_EN;
        }    
    }

#if 0
    /* RXC_DELAY TXC_DELAY 下拉到地,默认为低
    IMP RGMII CONTROL REGISTER (PAGE 00h: ADDRESS 060h)
    RXC_DELAY bit1
    TXC_DELAY bit0
    */
    tBCM5396.RegPageAddr = CONTROL_REG;
    tBCM5396.RegAddr = 0x60;
    tBCM5396.RegWidth = 1;
    if (BSP_OK != BspBcm5396RegRead(ulChip, &tBCM5396))
    {
        return MT_ETH_SW_ERR_READ;
    }
    if (0x00 != (tBCM5396.DataBuf[0] & 0x02))
    {
        printf("BCM5396 Configuration Pin error: RXC_DELAY\n");
        tBCM5396.DataBuf[0] &= ~0x02;
        ulRetVal |= MT_ETH_SW_ERR_RXC_DELAY;
    }
    if (0x00 != (tBCM5396.DataBuf[0] & 0x01))
    {
        printf("BCM5396 Configuration Pin error: TXC_DELAY\n");
        tBCM5396.DataBuf[0] &= ~0x01;
        ulRetVal |= MT_ETH_SW_ERR_TXC_DELAY;
    }
    if (ulRetVal & (MT_ETH_SW_ERR_TXC_DELAY | MT_ETH_SW_ERR_RXC_DELAY))
    {
        BspBcm5396RegWrite(ulChip, &tBCM5396);
    }
    /* Configuration Pins end */
#endif
    /* 使用该寄存器进行读写检查,确定芯片读写是否正常
    VLAN TABLE ADDRESS INDEX REGISTER (PAGE 05h: ADDRESS 61h) */
    tBCM5396.RegPageAddr = VTBL_ACCESS_REG;
    tBCM5396.RegAddr = VTBL_INDEX_ADDR;
    tBCM5396.RegWidth = VTBL_INDEX_LEN;
    if (BSP_OK != BspBcm5396RegRead(ulChip, &tBCM5396))
    {
        printf("%s: line%d. BspBcm5396RegRead error!\n", __FUNCTION__, __LINE__);
        return MT_ETH_SW_ERR_READ;
    }
    if (aucRegWrData[0] != tBCM5396.DataBuf[0])
    {
        printf("%s: line%d. BCM5396, page=0x%02x,reg=0x%02x is not default data!\n",
        		__FUNCTION__, __LINE__, tBCM5396.RegPageAddr, tBCM5396.RegAddr);
        tBCM5396.DataBuf[2] |= 0x40;
        ulRetVal |= MT_ETH_SW_ERR_DEF_QVID;
    }

    for (loop = 1; loop < sizeof(aucRegWrData); loop++)
    {
        tBCM5396.DataBuf[0] = aucRegWrData[loop];
        BspBcm5396RegWrite(ulChip, &tBCM5396);
        tBCM5396.DataBuf[0] = 0;
        BspBcm5396RegRead(ulChip, &tBCM5396);
        if (tBCM5396.DataBuf[0] != aucRegWrData[loop])
        {
            /*lint -save -e557 */
            printf("%s: line%d. BCM5396, page=0x%02x,reg=0x%02x data[0] should be 0x%02x\n", \
            	__FUNCTION__, __LINE__, tBCM5396.RegPageAddr, tBCM5396.RegAddr, aucRegWrData[loop]);
            /*lint -restore */
            ulRetVal |= MT_ETH_SW_ERR_RWCHEK;
            break;
        }
    }

    tBCM5396.DataBuf[0] = aucRegWrData[0];
    BspBcm5396RegWrite(ulChip, &tBCM5396);
    tBCM5396.DataBuf[0] = aucRegWrData[1];
    BspBcm5396RegRead(ulChip, &tBCM5396);
    if (tBCM5396.DataBuf[0] != aucRegWrData[0])
    {
        /*lint -save -e557 */
        printf("%s: line%d. BCM5396, page=0x%02x,reg=0x%02x data[0] should be 0x%02\n",\
        		__FUNCTION__, __LINE__, tBCM5396.RegPageAddr, tBCM5396.RegAddr, aucRegWrData[0]);
        /*lint -restore */
        ulRetVal |= MT_ETH_SW_ERR_RWCHEK;
    }

    return ulRetVal;
}

/**************************************************************************
* 函数名称: ULONG _BspSwitchEthConfig(void)
* 功能描述: 对交换芯片进行初始化配置,
*           包括设置SMI控制函数设置、端口的工作速率设置、双工模式设置
* 输入参数: 无
* 输出参数: 无
* 返 回 值: BSP_OK:初始化成功
*            其他   初始化失败
* 其它说明:    
* 修改日期:    版本号     修改人        修改内容
* -----------------------------------------------
 *  $0000000(N/A),  yam   2017-3   creat
**************************************************************************/
ULONG _BootSwitchEthConfig(void)
{
    ULONG ulRetVal = BSP_OK;
    int loop = 0;
    ULONG Chip = 0;
    T_BCM5396_REG tBCM5396;
	
    memset(&tBCM5396, 0, sizeof(tBCM5396));

    /* set software forwarding enable bit1=1 and managed mode bit0=1 */
    tBCM5396.RegPageAddr = CONTROL_REG;
    tBCM5396.RegAddr = SWITCH_MODE_ADDR;
    tBCM5396.RegWidth = SWITCH_MODE_LEN;
    ulRetVal = BspBcm5396RegRead(Chip, &tBCM5396);
    if (BSP_OK != ulRetVal)
    {
        printf("%s: line%d. BspBcm5396RegRead switch mode reg error!\n", __FUNCTION__, __LINE__);
        return ulRetVal;
    }
    tBCM5396.DataBuf[0] |= 0x03;
    ulRetVal = BspBcm5396RegWrite(Chip, &tBCM5396);
    if (BSP_OK != ulRetVal)
    {
        printf("%s: line%d. BspBcm5396RegWrite switch mode reg error!\n", __FUNCTION__, __LINE__);
        return ulRetVal;
    }

#if 0 /** yam todo: not sure whether to use */
    /*EC_614000584239   luli
    使能交换芯片转发目的mac为01-80-c2-00-00-00~2f的数据包*/
    tBCM5396.RegPageAddr = CONTROL_REG;
    tBCM5396.RegAddr = RESERVE_MULTICAST_CONTROL_ADDR;
    tBCM5396.RegWidth = SWITCH_MODE_LEN;
    tBCM5396.DataBuf[0] = 0x00;
    ulRetVal = BspBcm5396RegWrite(Chip, &tBCM5396);
    if (BSP_OK != ulRetVal)
    {
        return ulRetVal;
    }
#endif
#if 1
        /* 为AN提前配上MII但还不确定必要性,By 10029949, 17.05.03 */
        /* yam inform: Although port N override reg can also control port's 
        speed, no necessary to set the reg, as the MII control reg will be ignored 
        if setting the port N override reg. So use MII control reg first.
        each port set to 1000M speed, and full-duplex mode, disable auto-neg
        MII control reg 00h~01h, page 10h~1fh, reg width 2*/
        tBCM5396.RegAddr = MII_CONTROL_ADDR;
        tBCM5396.RegWidth = MII_CONTROL_LEN;
        for (loop = 0; loop < 11; loop++) /* just use 0~11 port*/
        {
            tBCM5396.RegPageAddr = 0x10 + loop;
            ulRetVal = BspBcm5396RegRead(Chip, &tBCM5396);
            if (BSP_OK != ulRetVal)
            {
                printf("%s: line%d. BspBcm5396RegRead MII control reg error!\n", __FUNCTION__, __LINE__);
                return ulRetVal;
            }
            tBCM5396.DataBuf[1] &= 0xAF; /* clear bit14 bit12*/
            tBCM5396.DataBuf[1] |= 0x01; /* set bit8*/
            tBCM5396.DataBuf[0] |= 0x40; /* set bit6*/  
            ulRetVal = BspBcm5396RegWrite(Chip, &tBCM5396);
            if (BSP_OK != ulRetVal)
            {
                printf("%s: line%d. BspBcm5396RegWrite MII control reg error!\n", __FUNCTION__, __LINE__);
                return ulRetVal;
            }
        }
#endif

    /* each port set to SGMII mode and slave sgmii mode, 
    disable remote loopbak, disable override of "output_voltage_level"
    serdes/SGMII control 1 Register 20h~21h, page 10h~1fh, reg width 2*/
    tBCM5396.RegAddr = SERDES_SGMII_CONTROL1_ADDR;
    tBCM5396.RegWidth = SERDES_SGMII_CONTROL1_LEN;
    for (loop = 0; loop < 11; loop++) /* just use 0~11 port*/
    {
        tBCM5396.RegPageAddr = 0x10 + loop;
        ulRetVal = BspBcm5396RegRead(Chip, &tBCM5396);
        if (BSP_OK != ulRetVal)
        {
            printf("%s: line%d. BspBcm5396RegRead serdes/SGMII control 1 Reg error!\n", __FUNCTION__, __LINE__);
            return ulRetVal;
        }
        tBCM5396.DataBuf[1] &= 0xEB; /* clear bit12 bit10*/
        tBCM5396.DataBuf[0] &= 0xDE; /* clear bit5 bit0*/
        tBCM5396.DataBuf[0] |= 0x20; /* SGMII_MSTR for AN, By 10029949,17.05.03 */
        ulRetVal = BspBcm5396RegWrite(Chip, &tBCM5396);
        if (BSP_OK != ulRetVal)
        {
            printf("%s: line%d. BspBcm5396RegWrite serdes/SGMII control 1 Reg error!\n", __FUNCTION__, __LINE__);
            return ulRetVal;
        }
    }

    /* Port Vlan control reg, page 31h, address 00h-43h. 
    all port bit[16:0] set 0x1ffff to enable forwarding to the egress port*/
    tBCM5396.RegPageAddr = PORT_VLAN_REG;
    tBCM5396.RegWidth = PORT_VLAN_PX_FORWARD_LEN;
    tBCM5396.DataBuf[0] = 0xff;
    tBCM5396.DataBuf[1] = 0xff;
    tBCM5396.DataBuf[2] = 0x01;
    for (loop = 0; loop < 11; loop++)
    {
        tBCM5396.RegAddr = 0 + loop * tBCM5396.RegWidth;
        ulRetVal = BspBcm5396RegWrite(Chip, &tBCM5396);
        if (BSP_OK != ulRetVal)
        {
            printf("%s: line%d. BspBcm5396RegWrite serdes/SGMII control 1 Reg error!\n", __FUNCTION__, __LINE__);
            return ulRetVal;
        }
    }

    /** yam inform:
        Here do not need to enhance out put voltage level, since all devices 
        are on one board. Only in situation of devices connect with each other
        through backboard do need to enhance out put voltage level */
#if 1 
    /* 硬件考虑到8片MPSOC较远，建议提高交换口0~15的输出信号幅度 */
    tBCM5396.RegWidth = 2;
    for (loop = 0; loop < PHY_PORT_IMP; loop++)
    {
        tBCM5396.RegPageAddr = 0x10 + loop;

        /* Block Address Number (Page 010h-017h: Address 03Eh) */
        tBCM5396.RegAddr = 0x3e;
        tBCM5396.DataBuf[1] = 0x00;  
        tBCM5396.DataBuf[0] = 0x00; /* change to block 0*/
        BspBcm5396RegWrite(Chip, &tBCM5396);

        /* SerDes/SGMII control 1 REGISTER (PAGE 010H-017H: ADDRESS 020H, BLOCK 0) */
        tBCM5396.RegAddr = 0x20;
        BspBcm5396RegRead(Chip, &tBCM5396);
        tBCM5396.DataBuf[1] |= 0x10; /*serdes  Tx Amplitude Override bit set 1*/
        BspBcm5396RegWrite(Chip, &tBCM5396);

        /* Block Address Number (Page 010h-017h: Address 03Eh) */
        tBCM5396.RegAddr = 0x3e;
        tBCM5396.DataBuf[1] = 0x00;
        tBCM5396.DataBuf[0] = 0x01; /* change to block 1*/
        BspBcm5396RegWrite(Chip, &tBCM5396);

        /* ANALOG TRANSMIT REGISTER (PAGE 010H-017H: ADDRESS 020H, BLOCK 1)
        信号幅度设置为最大bit15..bit12=0xf, 预加重值bit8..bit6=0b001
        交换debug口和abis口的预加重值bit8..bit6=0b011*/
        tBCM5396.RegAddr = 0x20;
        tBCM5396.DataBuf[1] = 0xf8; /*out_put_voltage_level bits[15:12] set 0xf */
        if ((9 == loop)||(10 == loop))
        {
            tBCM5396.DataBuf[0] = 0x20;
        }
        else
        {
            tBCM5396.DataBuf[0] = 0x60;
        }
        BspBcm5396RegWrite(Chip, &tBCM5396);

        /* Block Address Number (Page 010h-017h: Address 03Eh) */
        tBCM5396.RegAddr = 0x3e;
        tBCM5396.DataBuf[1] = 0x00;
        tBCM5396.DataBuf[0] = 0x00; /* change to block 0*/
        BspBcm5396RegWrite(Chip, &tBCM5396);
    }
#endif

    return BSP_OK;
}

/**************************************************************************
* 函数名称: _SwitchLoopbak
* 功能描述: set loopbak for each port of BCM5396
* 输入参数: uiPort  -- port number .  ucEnable--0 disable, 1 enable
			ucLoopType -- 0 innerLoop,  1 --remoteLoop
* 输出参数: 无
* 返 回 值: BSP_OK:   BSP_ERROR 
* 其它说明:
* 修改日期:    版本号     修改人        修改内容
* -----------------------------------------------
 *  $0000000(N/A),  yam   2016-9   creat
**************************************************************************/
ULONG _SwitchLoopbak(UCHAR ucLoopType, USHORT usPort, UCHAR ucEnable)
{

    ULONG ulRet = 0;

    if (/*usPort < 0 ||*/usPort > 16 ||ucLoopType >1)/*coverity 检查usPort 不会小与0*/
    {
        printf("%s:line%d. Input params error, just port0 to port16 can set loopbak mode, LoopType 0-innerLoop, 1-remoteLoop \n", 
				__FUNCTION__, __LINE__);
        return BSP_ERROR;
    }
	
    if (0 == ucLoopType) /* innerLoopbak*/
    {
        if (0 == ucEnable )
        {
            printf("%s:line%d. port %d disable innerLoopbak...\n", __FUNCTION__, __LINE__, usPort);
            ulRet = BCM5396InterLoopDis(0, usPort);
        }
        else 
        {
            printf("%s:line%d. port %d enable innerLoopbak...\n", __FUNCTION__, __LINE__, usPort);
            ulRet = BCM5396InterLoopEn(0, usPort);    
        }    
    }
    else /* remoteLoopbak*/
    {
        if (0 == ucEnable )
        {
            printf("%s:line%d. port %d disable remoteLoopbak...\n", __FUNCTION__, __LINE__, usPort);
            ulRet = BCM5396RemoteLoopDis(0, usPort);
        }
        else 
        {
            printf("%s:line%d. port %d enable remoteLoopbak...\n", __FUNCTION__, __LINE__, usPort);
            ulRet = BCM5396RemoteLoopEn(0, usPort);    
        }       
    }

    return ulRet;
}


/**************************************************************************
* 函数名称: SwitchPortPrint
* 功能描述: print port status of prot<X>
* 输入参数: uiPort  -- port number .   ucType--0 god view, 2 print port status, 1 print port rx tx frames
		ulGroup -- 0  1  2
* 输出参数: 无
* 返 回 值:  none
* 其它说明:  
* 修改日期:    版本号     修改人        修改内容
* -----------------------------------------------
 *  $0000000(N/A),  yam   2016-9   creat
**************************************************************************/
void _SwitchPortPrint(UCHAR ucType, USHORT usPort, ULONG ulGroup)
{
    if (/*usPort<0 ||*/usPort>16 || ulGroup > 2)/*coverity 检查usPort 不会小与0*/
    {
        printf("%s:line%d. Input params error!port num should be 0~16.Group can be 0 1 2\n", __FUNCTION__, __LINE__);
        return;
    }

    if (0 == ucType)
        BspBcm5396TestEntry(0);/** god view*/
    else if (1 == ucType)
        BspBcm5396PortMibShow(0, usPort, ulGroup);
    else
        BspBcm5396PortStsShow(0, usPort);

    return;
}

/**************************************************************************
* 函数名称: ULONG BootBoardSwitchInit(void)
* 功能描述:  Initilization of switch chip bcm5396
* 输入参数: null
* 输出参数: null
* 返 回 值: BSP_OK success;    others failed  
* 其它说明: Switch chip on main board of R70taaV2.0 is bcm5396 of BROADCOM.
*	Here use swich driver of bcm5396 transplanted from BBU CC
* 修改日期:    版本号     修改人        修改内容
* -----------------------------------------------
 *  $0000000(N/A),  yam   2017-03   creat
**************************************************************************/
ULONG BootBoardSwitchInit(void)
{
    ULONG ulTmpRet = BSP_OK;
    ULONG ulFuncRet = BSP_OK;

    ulTmpRet = _BootSwitchReset();
    if (BSP_OK != ulTmpRet)
    {
        ulFuncRet |= BSP_BIT_SET(0);
        printf("%s:line%d. Switch Reset error!\n", __FUNCTION__, __LINE__);
        return ulFuncRet;
    }

    ulTmpRet = _BootHwSpiInit();
    if (BSP_OK != ulTmpRet)
    {
        ulFuncRet |= BSP_BIT_SET(1);
        printf("%s:line%d. Switch Reset error!\n", __FUNCTION__, __LINE__);
        return ulFuncRet;
    }

    ulTmpRet = _Bcm5396ParaInit();
    if (BSP_OK != ulTmpRet)
    {
        ulFuncRet |= BSP_BIT_SET(2);
        printf("%s:line%d. _Bcm5396ParaInit error!\n", __FUNCTION__, __LINE__);
        return ulFuncRet;
    }

    ulTmpRet = _Bcm5396Check(); 
    if (BSP_OK != ulTmpRet)
    {
        ulFuncRet |= BSP_BIT_SET(3);
        printf("%s:line%d. BspM88E61XXCheckId error!\n", __FUNCTION__, __LINE__);
        //return ulFuncRet;
    }

    ulTmpRet = _BootSwitchEthConfig();
    if (BSP_OK != ulTmpRet)
    {
        ulFuncRet |= BSP_BIT_SET(4);
        printf("%s:line%d. BspSwitchEthConfig error!\n", __FUNCTION__, __LINE__);
        return ulFuncRet;
    }

    ulTmpRet = _Bcm5396PortEnable();
    if (BSP_OK != ulTmpRet)
    {
        ulFuncRet |= BSP_BIT_SET(5);
        printf("%s:line%d. M88e61xxPortEnable error!\n", __FUNCTION__, __LINE__);
        return ulFuncRet;
    }

    return ulFuncRet;
}

/**************************************************************************
* 函数名称:  BootSwitchPortBindMac
* 功能描述:  交换芯片BCM5396的端口绑定mac地址
* 输入参数: ulPortNum-端口号0~16
		ulState-ulState取值0xE表示静态MAC
* 输出参数: null
* 返 回 值: BSP_OK success;    others failed  
* 其它说明: 
* 修改日期:    版本号     修改人        修改内容
* -----------------------------------------------
 *  $0000000(N/A),  yam   2017-4   creat
**************************************************************************/
ULONG BootSwitchPortBindMac(ULONG ulPortNum, ULONG ulState)
{
    ULONG ulRet = 0;
    T_BCM5396_ARL_ENTRY tArlEntry;

    if (ulPortNum < 9 ||ulPortNum > 10)
    {
        printf("%s:line%d. Input params error, just port9 and port910 can be bound mac\n", __FUNCTION__, __LINE__);
        return BSP_ERROR;
    }
 
    if (/*ulState < 0 ||*/ulState > 15)/*coverity 检查ulState 不会小与0*/
    {
        printf("%s:line%d. Input params error, State should be 0~15. 0xE-static mac\n", __FUNCTION__, __LINE__);
        return BSP_ERROR;
    }
	
    memset((void *)&tArlEntry, 0, sizeof(T_BCM5396_ARL_ENTRY));

    /** ulState取值一般使用0xE,  含义STATIC MAC ADDR*/

    if (9 == ulPortNum)	 
    {
        memcpy(tArlEntry.ucEthMac, ucHwAddr0, MAC_ADDRESS_LEN);
    
    }
    else
    {
        memcpy(tArlEntry.ucEthMac, ucHwAddr1, MAC_ADDRESS_LEN);
    }
    
    tArlEntry.ulDataEntry |= ARL_VALID_BIT;
    if (((ULONG)SWITCH_STATIC_MAC_TABLE) == ulState)
    {/* 设置为静态MAC地址,不老化 STATIC BIT = 1 */
        tArlEntry.ulDataEntry |= ARL_STATIC_BIT;
    }
    tArlEntry.ulDataEntry |= ulPortNum << 6;
	
    ulRet = BspBcm5396ArlEntryAdd(0, &tArlEntry); 
    if (BSP_OK != ulRet)
    {
        printf("%s:line%d. BindMacToPort error!\n", __FUNCTION__, __LINE__);
        return BSP_ERROR;
    }

    return BSP_OK;
}

/**************************************************************************
* 函数名称: ULONG BspSwitchPortDeleteMac(ULONG ulPortNum)
* 功能描述:  交换芯片6097 删除端口绑定的mac地址
* 输入参数: ulPortNum-端口号
* 输出参数: null
* 返 回 值: BSP_OK success;    others failed  
* 其它说明: 
* 修改日期:    版本号     修改人        修改内容
* -----------------------------------------------
 *  $0000000(N/A),  yam   2017-3   creat
**************************************************************************/
ULONG BootSwitchPortDeleteMac(ULONG ulPortNum)
{
    ULONG ulRet = 0;
    T_BCM5396_ARL_ENTRY tArlEntry;

    if (ulPortNum < 9 ||ulPortNum > 10)
    {
        printf("%s:line%d. Input params error, just port8 and port9 can be deleted mac\n", __FUNCTION__, __LINE__);
        return BSP_ERROR;
    }

    /* tArlEntry.wVID should be cleared to 0 */
    memset((void *)&tArlEntry, 0, sizeof(T_BCM5396_ARL_ENTRY));

    if (9 == ulPortNum)
    {
        memcpy(tArlEntry.ucEthMac, ucHwAddr0, MAC_ADDRESS_LEN);
    }
    else 
    {
        memcpy(tArlEntry.ucEthMac, ucHwAddr1, MAC_ADDRESS_LEN);
    }

    ulRet = BspBcm5396ArlEntryDel(0, &tArlEntry);	
    if (BSP_OK != ulRet)
    {
        printf("%s:line%d. port delete Mac error!\n", __FUNCTION__, __LINE__);
        return BSP_ERROR;
    }

    return BSP_OK;
}

/**************************************************************************
* 函数名称: BspSwitchPortMacAlter
* 功能描述:  交换芯片6097的端口绑定mac地址修改
* 输入参数: ulPortNum-端口号
		ucMacField-待修改的mac地址位号
		ucMac-待修改的mac地址位的数值0~0xff
* 输出参数: null
* 返 回 值: BSP_OK success;    others failed  
* 其它说明: 注意本函数只修改mac地址,修改后需要重新绑定端口才会生效
* 修改日期:    版本号     修改人        修改内容
* -----------------------------------------------
 *  $0000000(N/A),  yam   2017-3   creat
**************************************************************************/
ULONG BootSwitchPortMacAlter(UCHAR ucPortNum, UCHAR ucMacField, UCHAR ucMac)
{    	 
    if (8 == ucPortNum)
    {
        switch(ucMacField)
        {
            case 1:
                ucHwAddr0[0] = ucMac;
                break;
            case 2:
                ucHwAddr0[1] = ucMac;
                break;
            case 3:
                ucHwAddr0[2] = ucMac;
                break;
            case 4:
                ucHwAddr0[3] = ucMac;
                break;
            case 5:
                ucHwAddr0[4] = ucMac;
                break;
            case 6:
                ucHwAddr0[5] = ucMac;
                break;
            default:
            {
                printf("%s:line%d. Input params error!, port number can only be 8 or 9. ", __FUNCTION__, __LINE__);
                printf("Mac Field should be 1 to 6.\n");
                break;
            }
                
        }
    printf("port %d mac changed to: ", ucPortNum);
    printhex(ucHwAddr0, 6, ":");
    }
    else
    {
        switch(ucMacField)
        {
            case 1:
                ucHwAddr1[0] = ucMac;
                break;
            case 2:
                ucHwAddr1[1] = ucMac;
                break;
            case 3:
                ucHwAddr1[2] = ucMac;
                break;
            case 4:
                ucHwAddr1[3] = ucMac;
                break;
            case 5:
                ucHwAddr1[4] = ucMac;
                break;
            case 6:
                ucHwAddr1[5] = ucMac;
                break;
            default:
            {
                printf("%s:line%d. Input params error!, port number can only be 8 or 9. ", __FUNCTION__, __LINE__);
                printf("Mac Field should be 1 to 6.\n");
                break;
            }
        }
    printf("port %d mac changed to: ", ucPortNum);
    printhex(ucHwAddr1, 6, ":");
    }

    printf("should call BspSwitchPortBindMac() to rebind new mac to port %d\n", ucPortNum);
    return BSP_OK;
}
#endif

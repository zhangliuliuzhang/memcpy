/*****************************************************************************
 * 版权所有(C) 2017, ZTE Corp. 
 *----------------------------------------------------------------------------
 * 模 块 名 : switchctrl
 * 文件名称 : switchctrlboot.h
 * 文件标识 : {[N/A]}
 * 内容摘要 : KEXECBOOT 对交换芯片控制头文件
 * 注意事项 : 无
 * 作    者 : yam
 * 创建日期 :  2017-03
 * 当前版本 : Ver1.0
 *----------------------------------------------------------------------------
 * 变更记录 :
 *
 * $记录1
 * 变 更 单: $0000000(N/A)
 * 责 任 人: yam
 * 修改日戳: yam   2017-03   creat
 * 变更说明: 创建
 *----------------------------------------------------------------------------
 */
#ifndef _SWITCHCTRLBOOT_H_
#define _SWITCHCTRLBOOT_H_

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

/* DRA62X最大支持4个BUS, 每个BUS最大支持4个设备SPI_SCS[n] */
#define HW_SPI_BUS_ID_SUM                 4
#define HW_SPI_DEV_ID_SUM                 4

#define SPI_BUS_ID_ALL_SUM                 HW_SPI_BUS_ID_SUM // Dra62x支持的HWSPIBUS总数
#define SPI_DEV_CS_ALL_SUM                 HW_SPI_DEV_ID_SUM // Dra62x每个HWSPIBUS支持的设备总数

/* 交换芯片复位检测错误位定义 */
#define MT_ETH_SW_ERR_AUTO_POLL               (0x01 << 0) /* ~AUTO_POLL管脚配置错误 */
#define MT_ETH_SW_ERR_HW_FWDG_EN              (0x01 << 1) /* HW_FWDG_EN管脚配置错误 */
#define MT_ETH_SW_ERR_BC_SUPP_EN              (0x01 << 2) /* BC_SUPP_EN管脚配置错误 */
#define MT_ETH_SW_ERR_RXC_DELAY               (0x01 << 3) /* RXC_DELAY管脚配置错误 */
#define MT_ETH_SW_ERR_TXC_DELAY               (0x01 << 4) /* TXC_DELAY管脚配置错误 */
#define MT_ETH_SW_ERR_DEF_QVID                (0x01 << 5) /* 复位后默认QVID不为复位默认值0 */
#define MT_ETH_SW_ERR_READ                    (0x01 << 6) /* 读交换芯片错误 */
#define MT_ETH_SW_ERR_RWCHEK                  (0x01 << 7) /* 写后回读比较错误 */


/** yam inform: move from r70taa1.1, 5g low frq V1.1 main board 
SPI 总线号定义  bit0~3 芯片号bit4~7 槽位号(多子板场景) bit8~11 芯片类型*/
#define BSP_HWSPI_ID_DRV_BUS_2         0x800 

#ifndef BSP_BIT_SET
    #define BSP_BIT_SET(n)                  (1UL << (n))    /* 对bit[n]掩码 */
#endif

#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif

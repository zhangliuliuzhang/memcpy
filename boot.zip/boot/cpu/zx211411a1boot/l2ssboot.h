/**************************************************************************
 * 版权所有 (C)2001, 深圳市中兴通讯股份有限公司
 *
 * 文件名称: zx211410boot.h
 * 文件标识:
 * 内容摘要:
 * 其它说明:
 * 当前版本: 
 * 作    者:
 * 完成日期:
 *
 * 修改记录1:
 *    修改日期: 
 *    版 本 号: 
 *    修 改 人: 
 *    修改内容: 创建
 * 修改记录2:
 **************************************************************************/

#ifndef _L2SSBOOT_H_
#define _L2SSBOOT_H_

#include <netinet/in.h>
#include <arpa/inet.h>
#include "ntl_l2ss.h"
#include "ntl_nacc_xmac.h"
#include "ntl_l2ss_agency.h"
#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

#if 0
#define NTL_CTRL_ENABLE    1
#define NTL_CTRL_DISABLE   0

#define NTL_CTRL_VALID     1
#define NTL_CTRL_INVALID   0

#define NACC_XMAC_NUM                     (22)            /* XMAC 端口个数 */
#define NTL_XMAC_MRU                      3000
#define NTL_XMAC_MTU                      3000
#define NTL_XMAC_TX_MAX_LEN               3000

#define NTL_PCS_LANE_NUM        (22)

#define L2SS_DEBUG_ETH_PORT_VLAN     8
#define L2SS_INNER_ETH_PORT_VLAN     9
#define L2SS_DEBUG_ETH_IP_VLAN       10
#define L2SS_INNER_ETH_IP_VLAN       11
#define L2SS_ECPRI_ETH_IP_VLAN       15

/* XMAC中配置的收发通道延时值 */
/*
    延时时间(ps)       total(ns)
    10GE(NO FEC) TX    72
    10GE(NO FEC) RX    59
    10GE(FEC) TX       72
    10GE(FEC) RX       272
    GE TX              266
    GE RX              199
    2.5GE TX           106
    2.5GE RX           79
    100M TX            2304
    100M RX            1848
    10M TX             22680
    10M RX             18336
*/
#define NTL_PATH_DELAY_10GE_TX_NO_FEC     72
#define NTL_PATH_DELAY_10GE_RX_NO_FEC     59
#define NTL_PATH_DELAY_10GE_TX_FEC        72
#define NTL_PATH_DELAY_10GE_RX_FEC        272
#define NTL_PATH_DELAY_1000M_TX           266
#define NTL_PATH_DELAY_1000M_RX           199
#define NTL_PATH_DELAY_2_5G_TX            106
#define NTL_PATH_DELAY_2_5G_RX            79
#define NTL_PATH_DELAY_100M_TX            2304
#define NTL_PATH_DELAY_100M_RX            1848
#define NTL_PATH_DELAY_10M_TX             22680
#define NTL_PATH_DELAY_10M_RX             18336


typedef enum
{
    e_NTL_SPEED_10M= 0, /* xmac 端口速率10M */
    e_NTL_SPEED_100M,   /* xmac 端口速率100M */
    e_NTL_SPEED_1000M,  /* xmac 端口速率1000M */
    e_NTL_SPEED_2_5G,   /* xmac 端口速率2.5G */
    e_NTL_SPEED_10G,    /* xmac 端口速率2.5G */
    e_NTL_SPEED_NUM,    /* 最大值 */
}E_NTL_SPEED_TYPE;

typedef enum
{
    e_NTL_INNER_BOARD= 0,   /* 板内通道 */
    e_NTL_BACK_BOARD,       /* 背板通道 */
    e_NTL_FRONT_BOARD,      /* 面板通道 */
    e_NTL_PORT_TYPE_NUM,    /* 最大值 */
}E_NTL_PORT_TYPE;

typedef enum
{
    e_NTL_XMAC_PORT_0= 0,   /* xmac 端口0 */
    e_NTL_XMAC_PORT_1,      /* xmac 端口1 */
    e_NTL_XMAC_PORT_2,      /* xmac 端口2 */
    e_NTL_XMAC_PORT_3,      /* xmac 端口3 */
    e_NTL_XMAC_PORT_NUM
}E_NTL_PORT_ID;

typedef struct
{
    UINT32 udPortId; /* E_XMAC_PORT_ID */
    E_NTL_PORT_TYPE eType;
    UINT32 eSpeed;  /*速率的定义参考E_XMAC_SPEED_TYPE*/
}T_NtlPortCfg;


typedef enum
{
    e_NTL_SHUNT_IP = 0,
    e_NTL_SHUNT_XC,
    e_NTL_SHUNT_ERROR
    
}E_NTL_PKT_SHUNT_TYPE;


typedef enum
{
   E_NTL_BTLL_P2U_REQ_MODE0 = 0,
   E_NTL_BTLL_P2U_REQ_MODE1,
   E_NTL_BTLL_P2U_REQ_NUM,
}E_NTL_BTLL_P2U_REQ_MODE;


typedef struct SerdesDrvParam
{
    BOOL   bEnable;
    UINT32 udChannelId;
    UINT32 ePortSpeed; /* E_XMAC_SPEED_TYPE */
    UINT32 udRatio;
}T_SerdesDrvParam;

typedef struct PcsDrvParam
{
    BOOL bEnable;
    UINT32 udChannelId;
    UINT32 ePortSpeed;  /* E_XMAC_SPEED_TYPE */
}T_PcsDrvParam;

/* Phy相关模块 初始化参数 数据结构 */
typedef struct PhyDrvParam
{
    T_SerdesDrvParam atSerdesDrvParam[NTL_PCS_LANE_NUM];
    T_PcsDrvParam atPcsDrvParam[NTL_PCS_LANE_NUM];
    UINT32 udSbusRegAddr;
    //UINT32 udMacMask;
}T_PhyDrvParam;


typedef struct XmacDrvParam
{
    BOOL   bEnable;
    E_NTL_SPEED_TYPE ePortSpeed;
    E_NTL_PORT_ID eMacId;
    UINT32 udMruVlaue;
    UINT32 udMtuVlaue; /* MTU仅仅用作静态统计，不影响实际DXGE MTU配置 */
    BOOL   bReplaceSrcMac;
    BOOL   bTxAddPadEn;  /* 发送打PAD使能控制 */
    UINT8  aucMacAddr[6];
    BOOL b1588RcvCtl;  /* 接收1588打时间戳功能使能 */
    BOOL b1588TxCtl;   /* 发送1588打时间戳功能使能 */
    UINT32 udPcsRcvPathDelay;
    UINT32 udPcsTxPathDelay;
}T_XmacDrvParam;

typedef struct PtpDrvParam
{
    UINT32 regVirAddr;
    BOOL   bEnable;
    BOOL   bPpsOutEnable;
    UINT32 ptpClk; /*Khz*/
}T_PtpDrvParam;

typedef enum
{
    e_L2ssSpeed_1G = 0, /*0*/
    e_L2ssSpeed_2_5G,   /*1*/
    e_L2ssSpeed_10G,    /*2*/
    e_L2ssSpeed_15G,    /*3*/
    e_L2ssSpeed_20G,    /*4*/
    e_L2ssSpeed_25G,    /*5*/
    e_L2ssSpeed_30G,    /*6*/
    e_L2ssSpeed_40G,    /*7*/
    e_L2ssSpeed_50G,    /*8*/
    e_L2ssSpeedNum,
}E_L2ssSpeedType;

/* XMAC 初始化参数 数据结构 */
typedef struct XmacParamStruct
{       
    UINT32 regVirAddr;
    T_XmacDrvParam atXmacDrvParam[NACC_XMAC_NUM];
}T_XmacParamStruct;

/* L2SS 初始化参数 数据结构 */

typedef struct CpuAgentDrvParam
{   
    BOOLEAN bIsStart;
    UINT32 uddCpuAgentVirBaseAddr; /*虚拟地址*/
    UINT32 uddCpuAgentPhyBaseAddr; /*物理地址*/
}T_CpuAgentDrvParam;

typedef struct ParseBaseDrvParam
{
    UINT32 udParseEngId;         //源端口的解析单元引擎的配置
    UINT32 udGp0Thrd;            //各个引擎单元对应高优先级组的配置
    UINT32 udParseCpuEthType;    //parse解析cpu报文的以太网类型的配置
    UINT32 udAnalyLevel;         //解析层次的配置
}T_ParseBaseDrvParam;

typedef struct FlowBaseDrvParam
{
     UINT32 udQmanOcMacTime;         //oq队列添加令牌的周期
     UINT32 udQmanLpMacTime;         //lp端口添加令牌的周期
     UINT32 udQmanShareThrd;         //qman的共享门限
     UINT32 udQmanMinLimit;          //qman的最小门限
     UINT32 udQmanThrdEn;            //qman的门限使能
     UINT32 udQmanKLevel;            //qman动态门限KLevel
     E_L2ssSpeedType eSpeedType;     //qman的DLP端口速率的流控
}T_FlowBaseDrvParam;


typedef struct
{   
    UINT32 udch0mode;
    UINT32 udch1mode;
    UINT32 udch2mode;
    UINT32 udch3mode;
}T_TRPG_GROUP_MODE_CFG; /*trpg端口组模式配置，每组4个端口 */

typedef struct PktShuntDrvParam
{   
    BOOLEAN bIsStart;
    UINT32 udPktShuntType;
    UINT64 uddBroadPortMap; /*有效端口*/
    UINT64 uddPktmOutputPortMap;
    UINT8  aucMac[6]; /*本地单板的mac地址*/
    UINT32 udMapMode; /*vlan映射模式使能的配置 BIT0 SMAC BIT1 DMAC BIT2 SIP BIT3 DIP BIT4 EXTA BIT5 EXB*/
    UINT32 udMapPri;  /*vlan映射的优先级的配置
                       BIT8-6 EXTB_KEY的选择 BIT5 (PKT_EXT_KEY)D/S(1/0) BIT4 D/S BIT3 D/S BIT2-0 000-111*/
    UINT32 udVtagSlpMap; /*表示PVT UT/PT报文是如何基于源逻辑端口的VID映射*/
}T_PktShuntDrvParam;

typedef struct L2ssDrvParam
{   
    UINT32   bIsStart;    // L2SS是否初始化 0 : 不需要初始化 1 : 需要初始化
    UINT32   regVirAddr;
    UINT64   uddPortEnableBitmap; /*现在默认都是全部关闭的了,这里可以配置一些上电就打开的端口*/
    T_CpuAgentDrvParam tL2ssCpuAgentDrvParam;
    T_ParseBaseDrvParam tParseBaseDrvParam;       //parse相关配置的初始化
    UINT32   udPktmCpuEthType;                      //送cpu的报文，Pktm添加cpu以太网头的配置
    UINT32   udTrxpPauseEn;                         //trxp的pause帧的使能的配置
    T_FlowBaseDrvParam tFlowBaseDrvParam;         //qman门限和流控基本参数的初始化配置
    T_PktShuntDrvParam tL2ssPktShuntDrvParam;
    T_TRPG_GROUP_MODE_CFG *ptL2ssTrpgModeParam;
}T_L2ssDrvParam;


typedef  unsigned int (*NTL_SpinLock)(void *);
typedef  unsigned int (*NTL_SpinUnLock)(void *);

typedef struct NtlDrvParam
{
    //T_BttlDrvParam tBttlDrvParam;

    T_L2ssDrvParam l2ssDrvParam;
    T_XmacParamStruct xmacDrvParam;
    T_PtpDrvParam tPtpDrvParam;
    UINT32 udCtrlIpAddr;
    UINT32 udExBoardMsgBase;
    UINT32 udProductMode;
}T_NTLDrvParam;

typedef struct
{
    UINT64 uddTotalFrameCnt;
    UINT64 uddPauseFrameCnt;
    UINT64 uddUniFrameCnt;
    UINT64 uddMultiFrameCnt;
    UINT64 uddBroadFrameCnt;
    UINT64 uddVlanFrameCnt;
    UINT64 udd64ByteFrameCnt;
    UINT64 udd65To127ByteFrameCnt;
    UINT64 udd128To255ByteFrameCnt;
    UINT64 udd256To511ByteFrameCnt;
    UINT64 udd512To1023ByteFrameCnt;
    UINT64 udd1024To1518ByteFrameCnt;
    UINT64 uddMaxByteFrameCnt;
    UINT64 uddUnderSizeFrameCnt;
    UINT64 uddOverSizeFrameCnt;
    UINT64 uddFragmentFrameCnt;
    UINT64 uddJabberFrameCnt;
    UINT64 uddControlFrameCnt;
    UINT64 uddEeeFrameCnt;

    UINT64 uddErrFrameCnt;
    UINT64 uddFcsErrFrameCnt;
    UINT64 uddDropFrameCnt;

    UINT64 uddTotalByteCnt;
    UINT64 uddGoodByteCnt;
}T_XMAC_HW_CNT;


#define REG32(addr)                     (*(volatile UINT32 *)((UINT32 *)(addr)))
#define REG16(addr)                     (*(volatile UINT16 *)((UINT16 *)(addr)))
#define REG8(addr)                      (*(volatile UINT8 *)((UINT8 *)(addr)))


#endif

#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif


/*****************************************************************************
 * 版权所有(C) 2010, ZTE Corp. RRU Bsp Platform
 *----------------------------------------------------------------------------
 * 模 块 名 : BSP
 * 文件名称 : zx211410boot.c
 * 文件标识 : {[N/A]}
 * 内容摘要 : zx211410 cpu bootapp接口实现
 * 注意事项 : 无
 * 作    者 : 耿佳佳
 * 创建日期 : 2015-10-22 08:28:34
 * 当前版本 : Ver1.0
 *----------------------------------------------------------------------------
 * 变更记录 :
 *
 * $记录1
 * 变 更 单: $0000000(N/A)
 * 责 任 人: 耿佳佳
 * 修改日戳: 2015-10-22 08:28:34
 * 变更说明: 创建文件
 *
 *----------------------------------------------------------------------------
 */

#include "stdio.h"
#include <sys/types.h>
#include <sys/stat.h>
#include <netinet/in.h>
#include <fcntl.h>
#include <errno.h>
#include "vxadp.h"
#include <math.h>

#include "bsppub.h"
#include "bspcomm.h"
//#include "ru_basetypes.h"
#include "bsperrcode.h"
#include "zx211411a1boot.h"
#include "crmboot.h"
#include "phy.h"
#include "bspcommonstdlog.h"

#if defined(COMPILE_FOR_KEXEC_BOOT)
#include "bootadp.h"
#include "halboot.h"

/*#else
#include "hal_addrmap.h"
#include "hal_regaddr.h"*/
#endif


#ifdef COMPILE_FOR_KEXEC_BOOT
/**************************************************************************
 *                        宏
 **************************************************************************/

#define MAC_FRAME_FILTER  (0x00000004)   /*MAC帧过滤寄存器 offset:0x0004 */
/* 单板复位开关变量，0--不复位，1--复位 */


/**************************************************************************
 *                         数据类型                                       *
 **************************************************************************/

/**************************************************************************
 *                         全局变量定义                                   *
 **************************************************************************/

/**************************************************************************
 *                         外部变量声明
 **************************************************************************/

/**************************************************************************
*                         局部函数声明
**************************************************************************/

/**************************************************************************
*                         全局函数声明
**************************************************************************/
extern VOID MainLoop ();
extern void BspFunction(unsigned char * ucpsymbname, unsigned char * ucpboardname);

ULONG SetDefaultCmdline();
extern ULONG BootFlashInit(VOID);
extern ULONG BootSoftModInit(void);
extern UINT32 BspGetPhyStatus(UINT32 ulDevNum, UINT32 *pulStat, UINT32 ulMode);
/**************************************************************************
 *                         函数实现
 **************************************************************************/

/*****WDOG REG*****/
#define WATCHDOG_BASE_ADDR  0xBC881000
#define WATCHDOG_REGS_SIZE  0x38
#define WATCHDOG_ENABLE     (0x1 << 0)
#define WATCHDOG_MODE_SET   (0x1 << 3)

/*****MDIO REG*****/	
#define DATA_WR_REG		0x04
#define DATA_RD_REG		0x08
#define MDIO_INT_REG	0x10
#define MDIO_CTRL		0x14

#define DPDIC_CHIP_ID     0x228
#define DPDIC_BOOT_MODE   0x30

#define uswap_32(x) \
	((((x) & 0xff000000) >> 24) | \
	 (((x) & 0x00ff0000) >>  8) | \
	 (((x) & 0x0000ff00) <<  8) | \
	 (((x) & 0x000000ff) << 24))

#define cpu_to_le32(x)		uswap_32(x)
#define dsb() __asm__ __volatile__ ("dsb" : : : "memory")
Tlist BoardPreCall_list     = {&(BoardPreCall_list),&(BoardPreCall_list)};
/*BspBoardPreInit的调用链表函数序号*/
static ULONG sBoardPreInitCallCnt   = 0;

static ULLONG sBoardInitError   = 0;

typedef struct tMemAddr{
    ULONG   phyAddr;
    ULONG   virAddr;
}TMemAddr;
TMemAddr DogAddr = {WATCHDOG_BASE_ADDR, 0};

ULONG g_ulLedFlag = 0;
ULONG  g_ulRamReservedAddr =0;
ULONG  g_ulBootRegisterAddr =0;

static UINT32 aulWatchdogAddr =0;
static UINT32 aulGem3VirAddr = 0;
static UINT32 aulMdioVirAddr = 0;
static UINT32 aulSerdesD6VirAddr = 0;
static UINT32 aulSubsAxiVirAddr = 0;
static UINT32 aulCrmVirAddr = 0;
static UINT32 aulPadVirAddr = 0;
static UINT32 aulScrVirAddr = 0;


/*****************************************************************************
*  函数名称   : BspGetCpuType(*)
*  功能描述   : 双boot模块用于获取cpu类型
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : 无
*  输出参数   : 无
*  返 回 值   : 成功 - BSP_OK
*  其它说明   :
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A), ty@2019-1-29 由IC2.0移植创建（添加了CPU类型）
*----------------------------------------------------------------------------
*/
UINT32 BspGetCpuType (UCHAR *pucCpuType)    
{ 
    if (NULL == pucCpuType)
        return BSP_ERROR_NULL_POINTER;
	
    *pucCpuType = BSP_ZX211411A1;
    return BSP_OK;
}
/*读看门狗寄存器*/
UINT32 BootRdWdtReg(UINT32 ulAddr)
{
    ULONG ulRegAddr = 0;

	ulRegAddr = ulAddr + aulWatchdogAddr;

    return *((volatile UINT32 *)ulRegAddr);
}
/*写看门狗寄存器*/
UINT32 BootWrWdtReg(UINT32 ulAddr, UINT32 ulData)
{
    ULONG ulRegAddr = 0;

	ulRegAddr = ulAddr + aulWatchdogAddr;

    *((volatile UINT32 *)ulRegAddr) = ulData;

    return BSP_OK;
}
/*读MDIO寄存器*/
UINT32 BootRdMdioReg(UINT32 ulAddr)
{
    UINT32 ulRegAddr = 0;

	ulRegAddr = ulAddr + aulMdioVirAddr;

    return *((volatile UINT32 *)ulRegAddr);
}
/*写MDIO寄存器*/
UINT32 BootWrMdioReg(UINT32 ulAddr, UINT32 ulData)
{
    UINT32 ulRegAddr = 0;

	ulRegAddr = ulAddr + aulMdioVirAddr;

    *((volatile UINT32 *)ulRegAddr) = ulData;

    return BSP_OK;
}

/*读IC寄存器*/
UINT32 BootRdIcD6Reg(UINT32 ulAddr)
{
    UINT32 ulRegAddr = 0;

	ulRegAddr = ulAddr + aulSerdesD6VirAddr;

    return *((volatile UINT32 *)ulRegAddr);
}

/*写IC寄存器*/
UINT32 BootWrIcD6Reg(UINT32 ulAddr, UINT32 ulData)
{
    UINT32 ulRegAddr = 0;

	ulRegAddr = ulAddr + aulSerdesD6VirAddr;

    *((volatile UINT32 *)ulRegAddr) = ulData;

    return BSP_OK;
}


/*读IC寄存器*/
UINT32 BootRdIcSbusAxiReg(UINT32 ulAddr)
{
    UINT32 ulRegAddr = 0;

	ulRegAddr = ulAddr + aulSubsAxiVirAddr;

    return *((volatile UINT32 *)ulRegAddr);
}

/*写IC寄存器*/
UINT32 BootWrIcSbusAxiReg(UINT32 ulAddr, UINT32 ulData)
{
    UINT32 ulRegAddr = 0;

	ulRegAddr = ulAddr + aulSubsAxiVirAddr;

    *((volatile UINT32 *)ulRegAddr) = ulData;

    return BSP_OK;
}


/*读IC寄存器*/
UINT32 BootRdIcScrReg(UINT32 ulAddr)
{
    UINT32 ulRegAddr = 0;

	ulRegAddr = ulAddr + aulScrVirAddr;

    return *((volatile UINT32 *)ulRegAddr);
}


UINT32 BootGetBootMode()
{
   return (BootRdIcScrReg(DPDIC_BOOT_MODE) & 0x03);
}


/*读IC寄存器*/
UINT32 BootRdIcPadReg(UINT32 ulAddr)
{
    UINT32 ulRegAddr = 0;

	ulRegAddr = ulAddr + aulPadVirAddr;

    return *((volatile UINT32 *)ulRegAddr);
}

/*写IC寄存器*/
UINT32 BootWrIcPadReg(UINT32 ulAddr, UINT32 ulData)
{
    UINT32 ulRegAddr = 0;

	ulRegAddr = ulAddr + aulPadVirAddr;

    *((volatile UINT32 *)ulRegAddr) = ulData;

    return BSP_OK;
}



/*获取DPDIC的chip 和 die ID*/
UINT32 BootGetIcChipId(UINT32 *pChipIdx,UINT32 *pDieIdx)
{
    UINT32 chipIdVal = 0;
    
    chipIdVal = BootRdIcPadReg(DPDIC_CHIP_ID);
    *pChipIdx = (chipIdVal & 0xf) >> 1;
    *pDieIdx = chipIdVal & 0x01; /*bit 0=0 主die, bit0=1 从die*/
    return BSP_OK;
}

ULONG BootGetChipMsFlag()
{
	UINT32 ulGpio = 0;

    ulGpio =  _BspZteGpioGet(ZTE_DPDIC_GPIO_MASTER_SLAVE_FLAG);
	if(GPIO_LEVEL_HIGH == ulGpio)
	{
		return CHIP_MASTER_TYPE;
	}

	return CHIP_SLAVER_TYPE;
}

#define KDA_DEVICE_NAME "/dev/misc/KernDrvAgt"
static int g_iKdaDrvFd = -1;
ULONG OpenKdaModel(void)
{
    int ret;
    if(CHIP_SLAVER_TYPE == BootGetChipMsFlag())
    {
        return BSP_OK;
    }
    BspMknod(KDA_DEVICE_NAME,"c","10","244");
    if ((g_iKdaDrvFd = open(KDA_DEVICE_NAME,O_RDWR | O_SYNC )) < 0)
    {
        zte_printf_s("open " KDA_DEVICE_NAME " failed!");
        return BSP_ERROR;
    }
    ret = BspPhyAddrToKernel((unsigned long long)BOOTAPP_LOG_PHY_ADDR, COM_INTERRUPT_NUM, g_iKdaDrvFd);
    if(ret != BSP_OK)
    {
        zte_printf_s("BspPhyAddrToKernel failed!\n");
        return BSP_ERROR;
    }
    return BSP_OK;
}

VOID BootFpgaWdtEnable(VOID)
{   
    if(CHIP_MASTER_TYPE == BootGetChipMsFlag())
    	_BspZteGpioSet(ZTE_DPDIC_GPIO_FPGA_RESET,GPIO_LEVEL_LOW);
}

VOID BootFpgaWdtDisable(VOID)
{   
    if(CHIP_MASTER_TYPE == BootGetChipMsFlag())
   		_BspZteGpioSet(ZTE_DPDIC_GPIO_FPGA_RESET,GPIO_LEVEL_HIGH);
}


/*****************************************************************************
*  函数名称   : BootSetWatchDogTime(*)
*  功能描述   : 设置看门狗喂狗时间
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : ulTimerValue - 写入喂狗的时间，单位:s
*  输出参数   : 无
*  返 回 值   : BSP_OK表示成功; BSP_ERROR表示失败;
*  其它说明   :
*  函数属性   : 基础接口
*----------------------------------------------------------------------------
*  历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A), ty@2019-1-29 由IC2.0移植创建
*----------------------------------------------------------------------------
*/
ULONG BootSetWatchDogTime (ULONG ulTimerValue)
{
    ULONG       ulLoadVal = 0;
    ULONG       ulTmp  = 0;
    ULONG       ulVal = 0;

    /*
    timer interval = (WdogLoad+1) x PERIPHCLK
    WdogLoad is the value needs to be written in WDOG_LOAD register.
    PERIPHCLK is A53MPcore_clk = 200MHz=2*10^8
    */

	if((ulTimerValue < 1) || (ulTimerValue > 21))/*21s对应LOAD寄存器最大值0xffffffff*/
	{
		printf("set wtd timeout error\n");
		return BSP_ERROR;
	}

	ulTmp = ulTimerValue;

	ulLoadVal = ulTmp *( 2 * pow(10,8)) - 1;
	BootWrWdtReg(WDTLOCK,UNLOCK);
	BootWrWdtReg(WDTLOAD,ulLoadVal);
	BootWrWdtReg(WDTLOCK,LOCK);
	ulVal=BootRdWdtReg(WDTLOAD);
	/*printf("WatchDogLoadReg = 0x%08x\n",ulVal);*/

    return BSP_OK;
}
/*****************************************************************************
*  函数名称   : BootWatchDogEnable(*)
*  功能描述   : 看门狗使能
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : 无
*  输出参数   : 无
*  返 回 值   : BSP_OK表示成功; BSP_ERROR表示失败;
*  其它说明   :
*----------------------------------------------------------------------------
*  历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A), ty@2019-1-29 由IC2.0移植创建
*----------------------------------------------------------------------------
*/
ULONG BootWatchDogEnable(VOID)
{
	ULONG       ulRet = BSP_OK;

	ulRet = BootSetWatchDogTime(21);/*设置看门狗最大时长21*2秒*/

	BootWrWdtReg(WDTLOCK,UNLOCK);

	BootWrWdtReg(WDTINTCLR,INT_MASK);//使能看门狗中断

	BootWrWdtReg(WDTCONTROL,INT_ENABLE | RESET_ENABLE);//使能计数和中断

	BootWrWdtReg(WDTLOCK,LOCK);

	/*
    ULONG       ulVal = 0;
    ulVal = BootRdWdtReg(WDTLOCK);
	printf("WatchDogLockReg = 0x%08x\n",ulVal);*/

	printf("WATCHDOG ENABLE!\n");

	return BSP_OK;
}

/*****************************************************************************
*  函数名称   : BootWatchDogDisable(*)
*  功能描述   : 看门狗去使能
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : 无
*  输出参数   : 无
*  返 回 值   : BSP_OK表示成功; BSP_ERROR表示失败;
*  其它说明   : 此时系统由硬件喂狗，软件不喂狗
*  函数属性   : 基础接口
*----------------------------------------------------------------------------
*  历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A), ty@2019-1-29 由IC2.0移植创建
*----------------------------------------------------------------------------
*/

ULONG BootWatchDogDisable(VOID)
{
    ULONG       ulVal = 0;
    UINT32		CrmRstReg = 0;

    BootWrWdtReg(WDTLOCK,UNLOCK);

    /*复位IC看门狗模块*/
    CrmRstReg = BootRdIcCrmReg(CRM_RST_REG);
    CrmRstReg &= (~(A53_WDT_RST));
    BootWrIcCrmReg(CRM_RST_REG,CrmRstReg);
    CrmRstReg |= (A53_WDT_RST);
    BootWrIcCrmReg(CRM_RST_REG,CrmRstReg);

    BootWrWdtReg(WDTCONTROL,0); /* IC看门狗复位去使能 ,关闭中断和计数*/
    ulVal = BootRdWdtReg(WDTCONTROL);
    printf("WatchDogCtrlReg: 0x%08x\n",ulVal);

    BootWrWdtReg(WDTLOCK,LOCK);

    printf("WATCHDOG DISABLE!\n");
    return BSP_OK;
}
/*dpll cs_ctrl by niuyanru add @2019-5-13*/
void BootSetDpllCs(unsigned char ucEn)
{
    if(ucEn)
        _BspZteGpioSet(ZTE_DPDIC_GPIO_DPLL_CS,GPIO_LEVEL_LOW);
    else
        _BspZteGpioSet(ZTE_DPDIC_GPIO_DPLL_CS,GPIO_LEVEL_HIGH);
}
/*dpll rst_crtl by niuyanru add @2019-5-13*/
void BootSetDpllRst(void)
{
    _BspZteGpioSet(ZTE_DPDIC_GPIO_DPLL_RST,GPIO_LEVEL_LOW);
    BootSysMsDelay(500);
    _BspZteGpioSet(ZTE_DPDIC_GPIO_DPLL_RST,GPIO_LEVEL_HIGH);
    BootSysMsDelay(500);
    _BspZteGpioSet(ZTE_DPDIC_GPIO_DPLL_RST,GPIO_LEVEL_LOW);
}
/******************************************************************************
*  函数名称   : BootLedCtrl(*)
*  功能描述   : 实现对面板灯的控制
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : ulLedName   - 灯名, 定义于BspPublic.h文件或者BoardApi.h文件
                ulLedMode - 灯状态的控制  BSP_LED_OP_OFF --灭，BSP_LED_OP_ON --亮
*  输出参数   : 无
*  返 回 值   : BSP_OK, 操作成功; BSP_ERROR_INVALID_PARA, 输入参数错误
*  其它说明   : DPD IC 8T 的LED 通过GPIO 控制，GPIO 低电平点亮LED
*  函数属性   : 基础接口
*------------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A), ty@2019-1-29 由IC2.0移植创建
*------------------------------------------------------------------------------
*/
ULONG BootLedCtrl(ULONG ulLedname, ULONG ulLedMode)
{

    switch (ulLedname)
    {
        case BSP_LED_ID_RUN: /* LedRun*/
        {
            _BspZteGpioSet(ZTE_DPDIC_GPIO_LED_RUN, (BSP_LED_OP_ON == ulLedMode) ? GPIO_LEVEL_LOW : GPIO_LEVEL_HIGH);
            break;
        }
        case BSP_LED_ID_ALM: /*LedAlm */
        {
            _BspZteGpioSet(ZTE_DPDIC_GPIO_LED_ALARM, (BSP_LED_OP_ON == ulLedMode) ? GPIO_LEVEL_HIGH : GPIO_LEVEL_LOW);/*将ALM灯由高灭低亮修改为高亮低灭*/
            break;          
        }

        default:
        {
            dbgInfo("Led is not exit\n");
            return BSP_ERROR_DEVICE_NOT_EXIST;
        }
    }
    return BSP_OK;
}

/**************************************************************************
 * 函数名称: int BootSetLedFlag(void)
 * 功能描述: 工装 应用程序入口
 * 输入参数: 无
* 输出参数:
 * 返 回 值: 无
* 其它说明:
*
* 修改日期:    版本号     修改人        修改内容
* -----------------------------------------------
* 2010-05-25     V1.0      xxx        Created
**************************************************************************/  

ULONG BootSetLedFlag(ULONG ulSwitch)
{
    if( 0 == ulSwitch)
		g_ulLedFlag = 0;
	else
		g_ulLedFlag = 1;

	return BSP_OK;
}

VOID BootLedBling(VOID)
{
    ULONG ucClkRate = sysClkRateGet();
    BootLedCtrl(BSP_LED_ID_RUN,BSP_LED_OP_OFF);/*RUN灯灭*/
    taskDelay(ucClkRate);
	BootLedCtrl(BSP_LED_ID_RUN,BSP_LED_OP_ON);/*RUN灯亮*/
	taskDelay(ucClkRate);
	/*先亮后灭的话，出现调度原因导致的闪灯过后常亮RUN灯偶发不亮的问题，调整为先灭后亮规避该问题*/
}

VOID BootLedTask(VOID)
{
    while(1)
    {
        if(0 != g_ulLedFlag)
        {
	        BootLedBling();
        }
		else
		{
		    BootSysMsDelay(500);
		}
    }  
		
}

/**********************************************************************
* 函数名称:void led_run(unsigned char ucMode)
* 功能描述:led_run led灯闪烁模式
* 输入参数: ucMode  0 只亮run灯,  1 run灯周期性闪
* 输出参数:无。
* 返 回 值:无
* 其它说明: dpdic 3.0 led 使用情况:
GPIO 14 -- RUN
GPIO 15 -- ALM
GPIO 16 --OPT0
GPIO 17 -- OPT1
GPIO 19 --VSWR
GPIO 20 -- ACT
dpdic 3.0 led 使用情况:
GPIO 16 -- RUN
GPIO 17 -- ALM
* 修改日期        版本号     修改人          修改内容
* -----------------------------------------------
* 2015/10/12            V1.0            00086970                       创建
*  $0000000(N/A), ty@2019-1-29 由IC2.0移植创建（现阶段只有RUN灯和ALM灯）
***********************************************************************/

VOID BootLedRun(UCHAR ucMode)
{
	
    if(0 == ucMode)/*只亮run灯,其他灯灭 */
    {  
        BootSetLedFlag(0);
        BootLedCtrl(BSP_LED_ID_ALM, BSP_LED_OP_OFF);  
        BootLedCtrl(BSP_LED_ID_RUN, BSP_LED_OP_ON);
    }
    else if(1 == ucMode)/*run灯周期性闪烁*/
    {  
        BootSetLedFlag(1);
        BootLedCtrl(BSP_LED_ID_ALM, BSP_LED_OP_OFF);
        
    }
    else if(2 == ucMode)/*所有灯都全亮*/
    {
        BootSetLedFlag(0);
        BootLedCtrl(BSP_LED_ID_RUN, BSP_LED_OP_ON);
        BootLedCtrl(BSP_LED_ID_ALM, BSP_LED_OP_ON);
    }
    else
    {
        printf("BootLedRun, input params[%d] error\n", ucMode);
    }
}

/*****************************************************************************
*  函数名称   : BootGetBoardRamSize(*)
*  功能描述   : Bsp 获取单板物理内存大小
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : 无
*  输出参数   : 无
*  返 回 值   : 内存大小单位Byte
*  其它说明   :
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A), 姜建奎@2012-02-29 16:14:27 创建
*  $0000000(N/A), ty@2019-1-29 由IC2.0移植创建（IC3.0使用的DDR大小为512M）
*----------------------------------------------------------------------------
*/
ULONG BootGetBoardRamSize(void)
{
    ULONG ulRet = DRAM_512M;
    return ulRet;	
}
#if 0
/*****************************************************************************
*  函数名称   : BootSoftModInit(*)
*  功能描述   : 初始化各个软件模块
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : 无
*  输出参数   : 无
*  返 回 值   : BSP_OK 成功,BSP_ERROR 出错
*  其它说明   :
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A), 姜建奎@2012-03-02 11:14:27 创建
*  $0000001(N/A), 姜建奎@2012-12-11 11:14:27 根据r15trx 需要修改
*  $0000000(N/A), ty@2019-1-29 由IC2.0移植创建
*----------------------------------------------------------------------------
*/
ULONG BootSoftModInit(void)
{
   ULONG ulRet = 0;
   
   T_RruProZoneInit tRruProZoneInit;

   memset((void *)&tRruProZoneInit,0,sizeof(tRruProZoneInit));

   tRruProZoneInit.aulParam[0] = BootGetBoardRamSize();    /*获取单板DRAM 大小*/

   tRruProZoneInit.aulParam[1] = FLASH_SECTOR_SIZE;       /*单板Flash 擦除块的大小*/

   tRruProZoneInit.aulParam[2] = PROTECT_ZONE_ADDRESS; /*单板保护区的偏移地址*/

   tRruProZoneInit.aulParam[3] = PROTECT_ZONE_SIZE;      /*保护区的长度*/
   
   ulRet = BootRruProZoneModInit(&tRruProZoneInit);

   return ulRet;
}
#endif
/*****************************************************************************
*  函数名称   : BootMapDogMem(*)
*  功能描述   : 地址空间映射
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : 无
*  输出参数   : 无
*  返 回 值   : BSP_OK表示成功; BSP_ERROR表示失败;
*  其它说明   :
*----------------------------------------------------------------------------
*  历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A), 王勇@2014-6-19 ,78e
*  $0000000(N/A), ty@2019-1-29 由IC2.0移植创建
*----------------------------------------------------------------------------
*/
/*lint -e64*/
#if 0
ULONG  BootMapDogMem()
{
    int     file;
    ULONG   iSpaceProt = PROT_READ | PROT_WRITE;
    ULONG	virAddr, phyAddr;
    phyAddr = DogAddr.phyAddr;
    virAddr = DogAddr.virAddr;
    
    if ((file = open("/dev/mem", O_RDWR | O_SYNC)) < 0)
    {
        dbgErr("open /dev/mem failed\n");
        return BSP_ERROR;
    }
    virAddr = mmap(virAddr, WATCHDOG_REGS_SIZE , iSpaceProt,MAP_SHARED,file, phyAddr);

    if(0xffffffff == virAddr)
    {
        dbgInfo("dog vir addr error\n");
        return BSP_ERROR;        
    }

    if (DogAddr.virAddr != virAddr)
    {
        dbgInfo("mmap  virAddr = %x \n", virAddr);
    }

    DogAddr.virAddr = virAddr  ;
    dbgInfo("%s %d 0x%x 0x%x\n", __FUNCTION__, __LINE__, WATCHDOG_BASE_ADDR, DogAddr.virAddr);

    return BSP_OK;
/*lint +e64*/
}
#endif
/*****************************************************************************
*  函数名称   : BootDevMemMap(*)
*  功能描述   : 使用mmap将物理地址映射到用户进程虚拟地址空间
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : 无
*  输出参数   : 无
*  返 回 值   : BSP_OK, 其它值为失败
*  其它说明   :
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A), zhaoyun@2014-5-27 14:07:25 创建
*----------------------------------------------------------------------------
*/
ULONG BootDevMemMap(VOID)
{
	 /* 打开内存设备的文件描述符 */
	int     iFd;
    int     iSpaceProt = PROT_READ | PROT_WRITE;
	ULONG   iCount = 0;

#define TO_MAP_LIST(a)      #a, &a
	/*lint -e529*/
	/*lint -e64*/
    struct map_list_t {
        UCHAR   *pucVarName;
        LONG    *pulVarAddr;
        ULONG   ulMapBase;
        ULONG   ulMapSize;
    } map_list[] = {
        {TO_MAP_LIST(g_ulRamReservedAddr),  (0x00000000+DRAM_512M - 0x4a00000),0x00600000},
        //{TO_MAP_LIST(g_ulBootRegisterAddr),  (0x28000008), 0x00000300},
		{TO_MAP_LIST(aulWatchdogAddr),  (0xBC881000), 0x00000300},
		{TO_MAP_LIST(aulGem3VirAddr),  (0xC1400000), 0x00000300},
		{TO_MAP_LIST(aulMdioVirAddr),  (0xC5f00000), 0x00000300},/*MDIO控制器地址映射*/
        {TO_MAP_LIST(aulCrmVirAddr),       (0x8BE80000), 0x00010000},/*dpdic3 crm寄存器映射*/
        {TO_MAP_LIST(aulSerdesD6VirAddr),  (0x96D00000), 0x00100000},/*dpdic3 serdes d6寄存器映射*/
        {TO_MAP_LIST(aulSubsAxiVirAddr),  (0x8C000000), 0x00800000},/*dpdic3 subsaxi寄存器映射*/
        {TO_MAP_LIST(aulPadVirAddr),      (0xC5B00000), 0x00100000},/*dpdic3 pad寄存器映射*/
        {TO_MAP_LIST(aulScrVirAddr),      (0xC1000000), 0x00010000},/*dpdic3 pad寄存器映射*/
	};

	if(CHIP_SLAVER_TYPE == BootGetChipMsFlag()){
		map_list[0].ulMapBase =  (0x00000000+DRAM_512M - 0xee00000);
	}
		
	/*lint +e529*/
	/*lint +e64*/
    #define DO_ADDR_MAP(a)                                          \
    	*((a)->pulVarAddr) = (long)mmap(0, (a)->ulMapSize,          \
    	    iSpaceProt, MAP_SHARED, iFd, (a)->ulMapBase);           \
    	if (*((a)->pulVarAddr) == -1)                               \
    	{                                                           \
    		dbgErr("mmap %s failed %s, %d\n",                       \
    		    (a)->pucVarName, strerror(errno), errno);           \
    		close(iFd);                                             \
    		return BSP_ERROR;                                       \
    	}                                                           \
    	dbgInfo("%-20s = %#x\n", (a)->pucVarName, *((a)->pulVarAddr));


    /* 打开存储空间映射 */
	if ((iFd = open("/dev/mem", O_RDWR | O_SYNC)) < 0)
	{
		dbgErr("open /dev/mem failed\n");
		return BSP_ERROR;
	}

    for (iCount = 0; iCount < sizeof(map_list)/sizeof(map_list[0]); iCount++)
    {
        DO_ADDR_MAP(&map_list[iCount]);
        usleep(1000);
    }
#if 0
    /* Started by AICoder, pid:g8fc9kce76q2140143d008dc30baed1ed663e245 */
    ULONG   ulReg;
    ULONG   ulPhyAdrr,ulPhySize,ulPhyGetFlag;
    /* Ended by AICoder, pid:g8fc9kce76q2140143d008dc30baed1ed663e245 */
/*lint -e529*/
/*lint -e40*/
/*lint -e409*/
/*lint -e42*/
    struct map_list_t1 {
        UCHAR   *pucVarName;
        LONG    *pulVarAddr;
        ULONG   ulMapBase;
        ULONG   ulMapSize;
    } map_list1[MAX_MEM_BLK];
/*lint +e529*/    
/*lint +e40*/
/*lint +e409*/
/*lint +e42*/
/*lint -e641*/
    for (iCount = 0; iCount < MAX_MEM_BLK; iCount++)
/*lint +e641*/
    {
        
        ulPhyGetFlag = HAL_addrmapGetMemblkPhyInfo(iCount,&ulPhyAdrr,&ulPhySize);
        if(HAL_OK != ulPhyGetFlag)
        {
            continue;
        }
        sprintf(chBuf,"%d",iCount);
		
        /* printf("[%s] map blk%d [phy addr=%x size=%x]\n",__FUNCTION__,iCount,ulPhyAdrr,ulPhySize); */
		/*lint -e40*/
		/*lint -e409*/
		/*lint -e10*/
		/*lint -e63*/
        map_list1[iCount].pulVarAddr=&ulReg;
        map_list1[iCount].ulMapBase=ulPhyAdrr;
        map_list1[iCount].ulMapSize=ulPhySize;
        map_list1[iCount].pucVarName=chBuf;
        DO_ADDR_MAP(&map_list1[iCount]);
       /*lint +e40*/
	   /*lint +e409*/
	   /*lint +e10*/
	   /*lint +e63*/
        HAL_addrmapSetMemblkVirAddr(iCount,ulReg);
        /* printf("[%s] map blk%d [phy addr=%x],viraddr=%x\n",__FUNCTION__,iCount,ulPhyAdrr,ulReg); */
        usleep(1000);
    }
#endif
    close(iFd); 

	BootCfgMiiBaseAddr(aulMdioVirAddr);
    return BSP_OK;
}

#if defined(CONFIG_RECORD_TIME)
/**********************************************************************
* 函数名称:BootGetMemVir
* 功能描述:获取此CPU映射的高端内存上电时间基地址
* 输入参数:无
* 输出参数:无
* 返 回 值:无
* 其它说明:上电计时高端内存基地址
* 修改日期        版本号     修改人          修改内容
* -----------------------------------------------
*  $0000000(N/A), 李耀清@2019-07-09 21:18:00
*----------------------------------------------------------------------------
*/
ULONG BootGetMemVir(void)
{
	if (NULL == g_ulRamReservedAddr)
	{
		printf("Error: g_ulRamReservedAddr is NULL!!\n");
		return 0;
	}
    return (g_ulRamReservedAddr+SYS_PHYS_MEM_TOP-BSP_MEM_SIZE+0x8000);/*(0x1B600000)+6M-512K+32K*/
}
#endif
/**********************************************************************
* 函数名称:BootSetSlaveChipNum
* 功能描述:配置从片数量，1代表只有主片
* 输入参数:
* 输出参数:
* 返 回 值:
* 其它说明:
* 修改日期        版本号     修改人          修改内容
* -----------------------------------------------
*  $0000000(N/A), ty@2019-1-29 由IC2.0移植创建
***********************************************************************/
ULONG BootSetSlaveChipNum(VOID)
{
    HAL_SetSlaveChipNum(1);
    return BSP_OK;

}
/*****************************************************************************
*  函数名称   : BootInitBoardGpioPort(*)
*  功能描述   : 初始化单板的GPIO端口属性
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : 无
*  输出参数   : 无
*  返 回 值   : BSP_OK, 其它值为失败
*  其它说明   : 由于不同的单板使用的GPIO端口属性可能不一样，所以这个放到单板中
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A), 宋志强@2014-06-13 14:07:25 创建
*  $0000000(N/A), ty@2019-1-29 由IC2.0移植创建（目前只保留RUN和ALM灯）
*----------------------------------------------------------------------------
*/
ULONG BootInitBoardGpioPort(void)
{
    ULONG ulRetVal = BSP_OK;

    _BspZteGpioSetMode(ZTE_DPDIC_GPIO_LED_RUN,    GPIO_MODE_OUTPUT);/*设置GPIO管脚及其对应的模式*/
    _BspZteGpioSetMode(ZTE_DPDIC_GPIO_LED_ALARM,  GPIO_MODE_OUTPUT);
    _BspZteGpioSetMode(ZTE_DPDIC_GPIO_PHY_RESET,    GPIO_MODE_OUTPUT);
    _BspZteGpioSet(ZTE_DPDIC_GPIO_PHY_RESET,        GPIO_LEVEL_LOW);
    _BspZteGpioSetMode(ZTE_DPDIC_GPIO_FPGA_CS,    GPIO_MODE_OUTPUT);
    _BspZteGpioSet(ZTE_DPDIC_GPIO_FPGA_CS,        GPIO_LEVEL_HIGH);/*BOOT not use fpga. set no available*/
    _BspZteGpioSetMode(ZTE_DPDIC_GPIO_DPLL_CS,    GPIO_MODE_OUTPUT);
    _BspZteGpioSetMode(ZTE_DPDIC_GPIO_DPLL_RST,    GPIO_MODE_OUTPUT);
    _BspZteGpioSetMode(ZTE_DPDIC_GPIO_MASTER_SLAVE_FLAG,    GPIO_MODE_INPUT);
    _BspZteGpioSetMode(ZTE_DPDIC_GPIO_FPGA_RESET,    GPIO_MODE_OUTPUT);
    _BspZteGpioSet(ZTE_DPDIC_GPIO_FPGA_RESET,        GPIO_LEVEL_LOW);

    return ulRetVal;
}

ULONG BootBoardHwPreInit(VOID)
{
	ULONG ulRet = BSP_OK;
	ulRet |= _BspZteGpioInit();/*完成GPIO物理地址到虚拟地址的映射*/
	ulRet |= BootInitBoardGpioPort();
	
	//printf("ok！\n");
 
	return ulRet;
	
}


ULONG BootResetPhy()
{
    _BspZteGpioSet(15,  1);
    return BSP_OK;
}

/*****************************************************************************
*  函数名称   : BootBoardPreInit(*)
*  功能描述   : Bsp单板初始化函数
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : 无
*  输出参数   : 无
*  返 回 值   : BSP_OK, 其它值为失败
*  其它说明   : 该接口为加载fpga前所需的BSP初始化函数。 版本公共接口函数
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A), zhaoyun@20140527 13:40:08 创建
*  comments:  feble_cheng@20140728 这个接口内不允许访问IC加速器的任何寄存器
*                                  因为此时fpga尚未加载，localbus时序异常会造成主片挂死
*----------------------------------------------------------------------------
*/
ULONG BootBoardPreInit(VOID)
{
	ULONG ulRet = BSP_OK;
	TBoardInitCall *tmp;	
	struct list_head *pos;
	printf("\BootBoardPreInit....... \n");
	
	ulRet |= BootSetSlaveChipNum();/*配置从片IC数量，不包含主片*/
	ulRet |= BootBoardHwPreInit();/*GPIO初始化*/
	ulRet |= BootDevMemMap(); /*物理地址到虚拟地址的映射*/
	//ulRet |= BootMapDogMem();/*看门狗虚拟地址映射*/
	ulRet |= BootSetMiiClk();
	ulRet |= BootFlashInit();
	ulRet |= BspResetPhyCallBackInit(BootResetPhy);
	ulRet |= OpenKdaModel();
/*lint -e{413,155}*/
	/*Carry out the init call*/
	list_for_each(pos,&BoardPreCall_list)
	{
		tmp = list_entry(pos,TBoardInitCall,list);
		//printf("function name= %s.",tmp->cCallName);

		tmp->ulRet = (*tmp).pInitCall();
		//printf("ulRet =%ld .\n",tmp->ulRet);
	}
/*lint -e{413,155}*/
	/*Collect the initcall error*/
	list_for_each(pos,&BoardPreCall_list)
	{
		tmp = list_entry(pos,TBoardInitCall,list);
		if (tmp->ulRet != 0)
		{
			//printf("ulRet =%ld .\n",tmp->ulRet);
			sBoardInitError |= tmp->ulFailMacro;
			ulRet |= tmp->ulFailMacro;
		}
	}

	return ulRet;
}
/**********************************************************************
* 函数名称:VOID intfBspWatchDogSetInterval(VOID)
* 功能描述:BSP看门狗最大时长设置。
* 输入参数:无。
* 输出参数:无。
* 返 回 值:无。
* 其它说明:  360秒看门狗
* 修改日期        版本号     修改人          修改内容
* -----------------------------------------------
* 2014/5/12            V1.0              yam                        创建
*  $0000000(N/A), ty@2019-1-29 由IC2.0移植创建
***********************************************************************/
#if 0
void BootintfBspWatchDogSetInterval(void)
{
    T_DPDIC_DOG *ptdog = (T_DPDIC_DOG *)DogAddr.virAddr;  
    INPUT_POINTER_CHECK(ptdog);
   
    /**ty infrom
    timer interval = (PRESCALER_value+1) x (Load_value+1)/PERIPHCLK
    timer interval use 360sec. 
    PRESCALER_value is set in WDOG_CONTROL[15:8], here we set 0x31(49) in BspWatchDogHardMonEnable().
    Load_value is the value needs to be written in WDOG_LOAD register.
    PERIPHCLK is A9MPcore_clk/2 = 200MHz=2*10^8
    so Load_value = 144*10^9 /50 -1 = 0x55D4A800-1=0x55D4A7FF.*/
    *(volatile ULONG*) (&(ptdog->WDOG_LOAD)) = cpu_to_le32(0x55D4A7FF);
}
#endif



 /**********************************************************************
* 函数名称:VOID BspBootAppWatchDogInit()
* 功能描述:bootapp初始化看门狗
* 输入参数:无
* 输出参数:
* 返 回 值:BSP_OK:成功;BSP_ERROR:失败
* 其它说明:网线连通bootapp main入口到下次内核启动完成计时约20s。bsp接口单位s，
           设置看门狗时间100s，100s到达前MGR接管，否则看门狗复位
* 修改日期        版本号     修改人          修改内容
* -----------------------------------------------
* 2015-10-22       V1.0       00086970             创建
*  $0000000(N/A), ty@2019-1-29 由IC2.0移植创建
***********************************************************************/
ULONG BootWatchDogInit(VOID)
{
	ULONG ulRet = BSP_ERROR;

	ulRet = BootWatchDogDisable();

	ulRet |= BootSetWatchDogTime(21);/*设置最长喂狗时间21*2=42秒*/

	ulRet |= BootWatchDogEnable();

	return ulRet;
}
UINT32 WaitMiiFinish()
{
    UINT32 flag = 0;
    UINT32 dlyCnt = 0;

    flag =  (BootRdMdioReg(MDIO_INT_REG) & 0x1);
    //BootWrMdioReg(MDIO_INT_REG,0);
    printf("flag1 = %d\n",flag);
    while(0 == flag)
    {
        dlyCnt++;
        if(dlyCnt >= 100)
        {
            break;
        }
        flag =  (BootRdMdioReg(MDIO_INT_REG) & 0x1);
        printf("flag2 = %d\n",flag);

    }

    flag =  (BootRdMdioReg(MDIO_INT_REG) & 0x1);
    printf("flag3 = %d\n",flag);
    if(1 == flag)
    {
        return BSP_OK;
    }
    return BSP_ERROR;
}
  /**********************************************************************
* 函数名称:BootDebugMiiRead
* 功能描述:通过GMII寄存器读PHY  .  针对以太网口GMAC0
* 输入参数: *     - udCsrClockRange：CSR 时钟区域
 *     - udGR： GMII寄存器
 *     - udPA： PHY设备物理层地址
 *     - pudData：需要读出的数据的地址
* 输出参数:
* 返 回 值:
* 其它说明:
* 修改日期        版本号     修改人          修改内容
* -----------------------------------------------
* 2014-5-28       V1.0       yam             创建
*  $0000000(N/A), zhaoyun@20141216 19:33:10 trm78E
*  $0000000(N/A), ty@2019-1-29 由IC2.0移植创建
***********************************************************************/
ULONG BootDebugMiiRead(ULONG ulCsrClockRange, ULONG ulGR, ULONG ulPA, ULONG *pulData)
{
    ULONG ulWriteData = 0;	

    if(NULL == pulData)
    {
    	return BSP_E_POINTER_NULL;
    }

    BootWrMdioReg(MDIO_INT_REG,0);

	/*ty inform   MDIO_CTRL
	bit[14]		MDIO operation start bit
				0:MDIO operation is complete;1:start MDIO operation
	bit[11:10]	MOIO Read or write
				01:write	10:read
	bit[5:9]	PA: Physical Layer Address
	bit[4:0]	GR: PHY internal Register
	*/
	ulWriteData = (1<<11)|(0<<10)|(1<<12)|
					((ulGR & 0x1F) << 0)|
					((ulPA & 0x1F) << 5);

	BootWrMdioReg(MDIO_CTRL,ulWriteData);
	ulWriteData = BootRdMdioReg(MDIO_CTRL);
	ulWriteData |= (1 << 14);
	BootWrMdioReg(MDIO_CTRL,ulWriteData);

	 if (BSP_OK == WaitMiiFinish())
	    {
	        /*rd val*/
		 *pulData = BootRdMdioReg(DATA_RD_REG);	
	        return BSP_OK;
	    }
    return BSP_ERROR;
}

  /**********************************************************************
* 函数名称:BootGetPHYLinkStatus
* 功能描述:获取PHY芯片物理链路连通状态
* 输入参数:无
* 输出参数:
* 返 回 值:0-网口联通 1-网口未联通
* 其它说明:
* 修改日期        版本号     修改人          修改内容
* -----------------------------------------------
* 2013-4-15       V1.0       yam             创建
*  $0000000(N/A), zhaoyun@20141216 19:33:10 trm78E
*  $0000000(N/A), ty@2019-1-29 由IC2.0移植创建
*  $0000000(N/A), jc@2019-7-19 修改
***********************************************************************/
ULONG BootGetPhyLinkStatus(VOID)
{

    ULONG  ulValue = 0;
    ULONG ulRet = 0;
		
	if(CHIP_MASTER_TYPE == BootGetChipMsFlag())
	{		
		ulRet = BspGetPhyStatus(0, &ulValue, 0);
		if (BSP_OK != ulRet)
		{
			dbgErr("Gmac0MiiRead Error!\n");
			return BSP_ERROR;
		}
		dbgInfo("PHY Status Reg[0x%x]\n", ulValue);
		if(ulValue & NET_STATE_LINKOK)
		{
			dbgInfo("Debug net port is ON\n"); 
			dbgInfo("PHY SPEED %s\n", ((ulValue & 0xc)>>3)? "10M":"100M");
			dbgInfo("PHY DUPLEX %s\n", ((ulValue & 0x10)>>4)? "FULL":"HALF");
			return 0;
		}
		else
		{
			dbgInfo("Debug net port is OFF\n"); 
			return 1;
		}
	}
	else
	{
		printf("SLAVE chip case.\n");
		return 1;
	}
}
/**********************************************************************
* 函数名称:BootGmac0MiiWrite
* 功能描述:通过GMII寄存器写PHY  .  针对以太网口GMAC0
* 输入参数: *     - udCsrClockRange：CSR 时钟区域
 *     - udGR： GMII寄存器
 *     - udPA： PHY设备物理层地址
 *     - pudData：需要读出的数据的地址
* 输出参数:
* 返 回 值:
* 其它说明:
* 修改日期        版本号     修改人          修改内容
* -----------------------------------------------
* 2014-5-28       V1.0       yam             创建
*  $0000000(N/A),00086970 19:33:10 trm78E
*  $0000000(N/A), ty@2019-1-29 由IC2.0移植创建
***********************************************************************/
ULONG BootDebugMiiWrite(ULONG ulCsrClockRange, ULONG ulGR, ULONG ulPA, ULONG ulData)
{
    ULONG ulWriteData = 0;	

    BootWrMdioReg(MDIO_INT_REG,0);

    BootWrMdioReg(DATA_WR_REG,(ulData & 0xffff));

	/*ty inform   MDIO_CTRL
	bit[14]		MDIO operation start bit
				0:MDIO operation is complete;1:start MDIO operation
	bit[11:10]	MOIO Read or write
				01:write	10:read
	bit[5:9]	PA: Physical Layer Address
	bit[4:0]	GR: PHY internal Register
	*/
	ulWriteData = (1<<11)|(0<<10)|(1<<12)|
					((ulGR & 0x1F) << 0)|
					((ulPA & 0x1F) << 5);
	printf("BootSetMdioCtrlReg val = 0x%08x\n",ulWriteData);
    BootWrMdioReg(MDIO_CTRL,ulWriteData);                                   

	ulWriteData = BootRdMdioReg(MDIO_CTRL);
	ulWriteData |= (1 << 14);
	BootWrMdioReg(MDIO_CTRL,ulWriteData);

	 if (BSP_OK == WaitMiiFinish())
	    {
	        return BSP_OK;
	    }
	 return BSP_ERROR;
}

/**************************************************************************
* 函数名称： memflag_set
* 功能描述： 设置boot启动标志
* 输入参数： 无
* 输出参数： 无
* 返 回 值： BSP_OK/BSP_ERROR
* 其它说明：
* 适用范围： BSP、OSS
* -----------------------------------------------------------------------
* 修改日期      版本号     修改人        修改内容
* 2015年10月22日 v1.0      00086970          创建
*  $0000000(N/A), ty@2019-1-29 由IC2.0移植创建
**************************************************************************/
ULONG memflag_set(ULONG ulwriteval)
{
	//WrReg(0,MEM_BLK_WDT,HAL_REG_RST_REC_DEBUG_REGX,ulwriteval);
	ulwriteval <<= 24;
	*((volatile UINT32 *)(aulCrmVirAddr + BOOT_FLAG)) &= 0xffffff;
	*((volatile UINT32 *)(aulCrmVirAddr + BOOT_FLAG)) |= ulwriteval;
	printf("memflag_set=0x%x\n",ulwriteval);
	return 0;
}
/**************************************************************************
* 函数名称： boot_flag_set
* 功能描述：设置boot启动标志
* 输入参数： 无
* 输出参数： 无
* 返 回 值： BSP_OK/BSP_ERROR
* 其它说明：
* 适用范围： BSP、OSS
* -----------------------------------------------------------------------
* 修改日期      版本号     修改人        修改内容
* 2015年10月22日 v1.0      00086970          创建
*  $0000000(N/A), ty@2019-1-29 由IC2.0移植创建
**************************************************************************/	
VOID boot_flag_set()
{
	ULONG check_flag=0;
	check_flag = *((volatile UINT32 *)(aulCrmVirAddr + BOOT_FLAG));
	
	check_flag >>= 24;
	printf("check_flag = %0#x\n",check_flag);


	if(check_flag==MASTER_BOOT_OK)  /*本次是上电或者复位后第一次启动,启动主boot成功*/
	{
		memflag_set(MASTER_KUBOOT_OK);
		/*尚欠写高端内存表征主boot启动成功标志*/
	}
	else if(check_flag==MASTER_KUBOOT_OK) /*启动主boot成功，继续尝试引导CPU版本*/
	{
		memflag_set(MASTER_KUBOOT_OK);
		/*尚欠写高端内存表征主boot启动成功标志*/
	}
	else if(check_flag==SLAVE_BOOT_OK)  /*启动从boot成功，*/
	{
		memflag_set(SLAVE_KUBOOT_OK);
		/*尚欠写高端内存表征从boot启动成功标志*/
	}
	else if(check_flag==SLAVE_KUBOOT_OK)   /*启动从boot成功，继续尝试引导CPU版本*/
	{
		memflag_set(SLAVE_KUBOOT_OK);
		/*尚欠写高端内存表征从boot启动成功标志*/
	}
    return;
}
/**************************************************************************
* 函数名称： SetEthProMode
* 功能描述： 设置ETH的模式寄存器的混杂模式控制位
* 输入参数： 0--对进入的帧的目的地址进行检查。1--对进入的帧的目的地址不进行检查。
* 输出参数： 无
* 返 回 值：
* -------------------------------------------------------
* 其它说明：
* 修改日期     版本号        修改人	            修改内容
*  $0000000(N/A), ty@2019-1-29 由IC2.0移植创建
**************************************************************************/
/*需确认MAC_FRAME_FILTER帧过滤寄存器的偏移地址(已确认)*/
/*需确认0x7FFFFFFE和0x80000001的值（已确认）*/
ULONG SetEthProMode(UCHAR ucValue)
{ 
    ULONG  ulRet=BSP_OK;          
   
#if 0
    /* Started by AICoder, pid:m0d45e7eaf6ed6614f5608bf30d99d1baa896b06 */
    ULONG  ulValue=0;
    /* Ended by AICoder, pid:m0d45e7eaf6ed6614f5608bf30d99d1baa896b06 */
    printf("SetEthProMode: set eth mode bit. \n");
	HAL_addrmapGetDataFromVirAddr(0,MEM_BLK_GMAC0,MAC_FRAME_FILTER,&ulValue);
	

    if (ucValue == 0) /*对进入的帧的目的地址进行检查,非混杂模式*/
    {
        ulValue = ulValue & 0x7FFFFFFE;
    }
    else/*对进入的帧的目的地址不进行检查, 混杂模式Receive All Frame*/
    {          
        ulValue = ulValue | 0x80000001;
    }

	WrReg(0,MEM_BLK_GMAC0,MAC_FRAME_FILTER,ulValue);
#endif
	return ulRet;
     
}
/**********************************************************************
* 函数名称： BootGetDownloadFlag
* 功能描述： MIO14指示起保护区版本or下载版本。
* 输入参数： 无
* 输出参数： 无
* 返 回 值： 0:起保护区版本 1:下载版本
* 其它说明： zx211410写死起保护区版本
* 修改日期        版本号     修改人	      修改内容
* -----------------------------------------------
* 2012/07		   V1.0	     ZKH	      
***********************************************************************/
ULONG BootGetDownloadFlag(void)
{       
    ULONG ulChipId = 0;

    ulChipId = (BootRdIcPadReg(DPDIC_CHIP_ID) & 0xf) >> 0x1;
    if((CHIP_MASTER_TYPE == BootGetChipMsFlag()) && (0 == ulChipId))
    {
        return 0;
    }
    else
    {
        return 1;
    }
}

ULONG getLastKmsgAddr(VOID)
{
    return LAST_KMSG_ADDR;
}

ULONG getAppLogPhyAddr(VOID)
{
    return APP_LOG_PHY_ADDR;
}

UINT32 BootGetBoardHwResetType(VOID)
{
    UINT32 ret = 0;
    ret = readl(aulCrmVirAddr + REC_RESET_0);
    return ret;
}

UINT32 BootGetBoardSwResetType(VOID)
{
    UINT32 ret = 0;
    ret = readl(aulCrmVirAddr + SOFT_RESET_OFFSET);
    return ret;
}

UCHAR* BootGetBoardResetInfoAddr(VOID)
{
    return (g_ulRamReservedAddr + RESET_INFO_ADDR);
}

VOID SaveKebootBakLog(VOID)
{
    if(CHIP_SLAVER_TYPE == BootGetChipMsFlag())
    {
        return;
    }
    BspSaveBootKmsgLog(BAK_LOG);
    BspSaveBootAppLog(BAK_LOG);
}

VOID SaveKebootCurLog(VOID)
{
    if(CHIP_SLAVER_TYPE == BootGetChipMsFlag())
    {
        return;
    }
    BspSaveBootKmsgLog(CUR_LOG);
    BspSaveBootAppLog(CUR_LOG);
}

/*bs住后的手动转储请用SaveKebootLog,产生4份,使每份log序号保持一致*/
VOID SaveKebootLog(VOID)
{
    if(CHIP_SLAVER_TYPE == BootGetChipMsFlag())
    {
        return;
    }
    SaveKebootBakLog();
    SaveKebootCurLog();
}

ULONG BootFlagGet()
{
    ULONG flag = 0;
    ULONG buf = 0;

    if(BspFlashRead(DOUBLE_BOOT_CONTROL_Addr, &buf, 1))
    {
        return BSP_ERROR;
    }
    buf = uswap_32(buf);
    flag = readl(aulCrmVirAddr + BOOT_FLAG) >> 24;

    return (buf << 16) | flag;
}

ULONG BootGetaulCrmVirAddr() 
{   // 提供aulCrmVirAddr获取函数
    return aulCrmVirAddr;
}

/*****************************************************************************
 *  函数名称   : main(*)
 *  功能描述   : bootapp程序处理主函数
 *  读全局变量 : 无
 *  写全局变量 : 无
 *  输入参数   : argc   - 参数个数
                 argv[] - 参数列表
 *  输出参数   : 无
 *  返 回 值   : 0为成功, 其余失败
 *  其它说明   :
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *  $0000000(N/A), 00086970 @2015-10-28
 *  $0000000(N/A), ty@2019-1-29 由IC2.0移植创建
 *----------------------------------------------------------------------------
 */
int main(int argc, char *argv[])
{
    int iBootAppTaskID = 0;
    ULONG ulRet = 0;    
    ulRet = BootBoardPreInit();

    BootLedRun(0);
    ulRet = GetCmdline();
    if(BSP_ERROR == ulRet)
    {
        SetDefaultCmdline();
    }
#ifdef CONFIG_SECURITY
    if(0 != setvbuf(stdout , NULL, _IOLBF, 512))
    {
        printf("setvbuf stdout fail!!! \n");
    }
#endif
    ulRet |= BootWatchDogInit();
    ulRet |= (ULONG)ushell_init();
    ulRet |= BootSoftModInit();
	
    taskSpawn("tLedTask",   \
        100, /* priority */            \
        0,   /* option   */           \
        0x100,/* stack size */      \
        (FUNCPTR)BootLedTask, 0, 0, 0, 0, 0, 0, 0, 0 ,0,0);
	
    BootLedRun(0);
    iBootAppTaskID = taskSpawn("tBootTask",   \
        100, /* priority */            \
        0,   /* option   */           \
        0x1000,/* stack size */      \
        (FUNCPTR)MainLoop, 0, 0, 0, 0, 0, 0, 0, 0 ,0,0);

    while(1)
    {
       //BspFunction("/boot.out", CFG_PROMPT);
       sleep(20);
    }

    return ulRet;

}


#endif
extern UCHAR g_ucCmdLine[256];
ULONG SetDefaultCmdline(VOID)
{
    /* Started by AICoder, pid:t00f8vcb32s4f6d141fe0bcd40bc17030ea4d9fe */
    strcpy((char *)g_ucCmdLine,"console=ttyAMA0,115200 earlycon=pl011,0xC5800000, root=/dev/ram0 rw verbose earlyprintk keboot=1 nosmp=1");
    printf("/proc/cmdline error,load default cmdline.\n");
    return BSP_OK;
    /* Ended by AICoder, pid:t00f8vcb32s4f6d141fe0bcd40bc17030ea4d9fe */
}
void ResetSbus(void)
{
	UINT32 CrmRstReg = 0;
	CrmRstReg = BootRdIcCrmReg(CRM_CFG_SBUS_REG);
	printf("ResetSbus:0:0x278 = 0x%x\n",CrmRstReg);
       CrmRstReg |= (CRM_SBUS_RST);
       BootWrIcCrmReg(CRM_CFG_SBUS_REG,CrmRstReg);
	BspSysMsDelay_Sys(10);
	CrmRstReg = BootRdIcCrmReg(CRM_CFG_SBUS_REG);
	printf("ResetSbus:1:0x278 = 0x%x\n",CrmRstReg);
       CrmRstReg &= (~(CRM_SBUS_RST));
       BootWrIcCrmReg(CRM_CFG_SBUS_REG,CrmRstReg);
	CrmRstReg = BootRdIcCrmReg(CRM_CFG_SBUS_REG);
	printf("ResetSbus:2:0x278 = 0x%x\n",CrmRstReg);
	 return;
	   
}

/*网口启动的情况下，不运行kexec的 keboot,所以下述是flash启动方式，分上电复位还是非上电复位*/
UINT32 BootIcInit()
{

    if(BSP_OK == BootGetSysPowerRst()) /*上电复位*/
    {
        printf("system Pwr Up\n");
        
        /* 2. PLL3 LOCK */
       // SetBootroadRegBit(16);    // 开始轮询PLL3是否LOCK，boot_road寄存器bit16置1
        
#ifdef BOOT_CRM_EN
        do
        {
            BootSetIcPLL3Rst();
          ;
        }while (!(CRM_PLL3_CRM_LOCK & BootGetPLL3State()));
#endif     
        printf("Pll3 lock OK\n");
    
    
		
         if(CHIP_MASTER_TYPE == BootGetChipMsFlag())
         {
            ResetSbus();
			BspSysMsDelay_Sys(10);
			SoftRepair();
              
				 /*MDIO的上升沿比较缓慢，DPDIC做主，需要将MDCK由2.5M降低为1.5625M，DPDIC做从则没有要求*/
		 //BootWrIcCrmReg(MDIO_CLK_CFG, 0xFF);
           }		
            /* 3. 时钟使能，L2SS和MAC复位 */
            BootEnL2ssClk();
	
            BootRstL2ss();    // L2SS & MAC RST
    
            /* 4.初始化PCS和SERDES模块 */
           // SetBootroadRegBit(17);    // 开始PCS和SERDES初始化，boot_road寄存器bit17置1
#ifdef BOOT_CRM_EN

            BootRlsPcsRst();
   
            SerdesD6Init();
 
            BspSysMsDelay_Sys(3);    // SerdesD6初始化完成后等待3ms
            
            SerdesPcsInit();
	
            /* 5. 等待QMAN和BMAN上电初始化完成 */
            //SetBootroadRegBit(20);    // 开始初始化XMAC和L2SS，boot_road寄存器bit20置1
            printf("serdes init finish\n");
            BootRlsL2ssRst();    // 释放L2SS复位
           
            BspSysMsDelay_Sys(500);
            BootRlsXMACRst();
		
            BspSysMsDelay_Sys(100);
            //NtlL2ssWaitBQmanInitDone();
            //L2SS_QMAN_NOR0_CNT_EN();
            
            /* 6.初始化XMAC模块 */
            BootNtlInit();
	        BspSystem("ifconfig eth0 mtu 1492");
			if(CHIP_MASTER_TYPE == BootGetChipMsFlag())
            {
          		BspInitPhy(0);
          		printf("phy init Finish\n");
			}
        
    }
    else /*非上电复位*/
    {

    /*水位控制开启*/

            /* debug ip/mac 初始化 */
	    BootNtlSoftResetInit();
	
        if(CHIP_MASTER_TYPE == BootGetChipMsFlag())
    	{
			BspInitPhy(0);
			printf("phy init Finish\n");
			if(((BootRdIcPadReg(DPDIC_CHIP_ID) & 0xf) >> 0x1) ==0 )
				BootSetEth0DebugIpMacAddr();
			else
				BootSetslavechipIpMacAddr();/*9228 slave chip*/
		}
		else
    			BootSetslavechipIpMacAddr();
    
         BspSystem("ifconfig eth0 mtu 1492");   

		
	     NtlL2ssTrxpEnable(46);
	     NtlL2ssTrxpEnable(10);
	     NtlL2ssTrxpEnable(11);
	   
	     NtlXmacEnable(10);
	     NtlXmacEnable(11);
		 
    }
#endif
    return BSP_OK;
}

/**********************************************************************
* 函数名称： BootGetFsRecoverFlag
* 功能描述： 从高端内存获取用户态文件系统异常标志
* 输入参数： 无
* 输出参数： 无
* 返 回 值： 0:正常 0xdeadbeaf:异常
* 其它说明： 获取后清除 
* 修改日期        版本号     修改人	      修改内容
* -----------------------------------------------
* 2012/07		   V1.0	     ZKH	      
***********************************************************************/
ULONG BootGetFsRecoverFlag(VOID)
{
    ULONG ulUbifsFormat_mask = 0;
    ulUbifsFormat_mask = *(ULONG *)FS_FORMAT_FLAG;
    if(ulUbifsFormat_mask == 0xdeadbeaf)
    memset((CHAR*)FS_FORMAT_FLAG, 0, 4);/* 清空 */
    return ulUbifsFormat_mask;
}
ULONG BootCfgPllAndL2ss(VOID)
{
	if(CHIP_MASTER_TYPE == BootGetChipMsFlag())
	{
		fs_recover(0); 

		if(BSP_OK == BootGetSysPowerRst())
		{
			printf("MASTER DPDIC3,POWERUP, INIT PLL\n");
			dpll_init();
			BootWatchDogInit();
		}
	 }
        else
        {
		printf("SLAVE DPDIC3, SKIP PLL \n");
	 }
	   /*accelerator reg init*/
        DpdIcHalRegTblInit();
       /*ntl init*/
        BootIcInit();
        BspSysMsDelay_Sys(3000);
		 
	 return BSP_OK;
}

/**********************************************************************
* 函数名称：BootGetVersion
* 功能描述： 读取Flash中boot版本号
* 输入参数： headPtr需要获取到版本的指针，默认不使用，除非传入非空指针，model:0 获取一级Boot版本，1 获取二级keboot版本
* 输出参数： 无
* 返 回 值： 0:正常  非0:异常
* 其它说明： 获取后清除
* 修改日期        版本号     修改人	      修改内容
* 修改日期     版本号        修改人	            修改内容
* ---------------------------------------------------
* 2015/10/22     V1.0         10242265           创建
***********************************************************************/
UINT32 BootGetVersion(char *headPtr,char model)
{
	 UINT32 ulRet=0;
	 UINT32 HEAD_ADDR=0;
	 unsigned char  *ptVerFileHeadChar = NULL;
	 T_VerFileHeader *ptVerFileHeader = NULL;
	 if(NULL==headPtr)
	 {
		 return BSP_ERROR;
	 }
	 ptVerFileHeadChar = (unsigned char *)malloc(sizeof(T_VerFileHeader));
	 if (NULL == ptVerFileHeadChar)
	 {
		 printf("malloc error!!\n");
		 return -1;
	 }
	 if(0==model)
	 {
		 HEAD_ADDR=UBOOT_HEAD_ADDR;
	 }
	 else
	 {
		 HEAD_ADDR=KEBOOT_START_ADDR;
	 }
	 /*从启动地址读取版本头到ptVerFileHeadChar*/
	 ulRet=BspFlashRead(HEAD_ADDR, ptVerFileHeadChar,sizeof(T_VerFileHeader));
	 if(BSP_OK==ulRet)
	 {
	     ptVerFileHeader = (T_VerFileHeader *)ptVerFileHeadChar;
	     ptVerFileHeader->ucVerNo[44-1]='\0';
	     memcpy(headPtr,ptVerFileHeader->ucVerNo,strlen(ptVerFileHeader->ucVerNo)+1);
	 }
	 else
	 {
		 printf("\nRead BOOT Header error!\n");
	 }
	 free(ptVerFileHeadChar);
	 ptVerFileHeadChar = NULL;
	 ptVerFileHeader = NULL;
     return ulRet;
}


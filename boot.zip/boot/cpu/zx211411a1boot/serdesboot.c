/*****************************************************************************
 * 版权所有(C) 2010, ZTE Corp. RRU Bsp Platform
 *----------------------------------------------------------------------------
 * 模 块 名 : BSP
 * 文件名称 : dpdichal.c
 * 文件标识 : {[N/A]}
 * 内容摘要 : 实现dpdic的加速器配置
 * 注意事项 : 无
 * 作    者 : 郭勇
 * 创建日期 : 2019-04-08 
 * 当前版本 : Ver1.0
 *----------------------------------------------------------------------------
 * 变更记录 :
 *
 * $记录1
 * 变 更 单: $0000000(N/A)
 * 责 任 人: 耿佳佳
 * 修改日戳: 2015-10-22 08:28:34
 * 变更说明: 创建文件
 *
 *----------------------------------------------------------------------------
 */


/* 标准库头文件 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h> 
#include "bsppub.h"
#include "bspcomm.h"
#include "serdesboot.h"
#include "crmboot.h"
#include "sbusboot.h"
#include "optpcs.h"


/*Eth Pcs Configuration Table*/
/*测试4X的时候，需要配置L2SS的TRPG的PortMode,然后配置CMAC的速率比如100G，然后在使能CMAC

FEC_TYPE: 这个要和对端的配置保持一致
GEAR_WIDTH: 和SERDES能力保持一致， 开启AN后，这个也要SERDES 链路训练中的位宽保持一致 */

T_PCS_CONFIG_TBL gtBootEthPcsCfg[] = {

    {10, OPTPCS_ETH, OPTPCS_BIND_MODE_4T1X, OPTPCS_PORT_MODE_1X, OPTPCS_ETH_1G_2P5G_10B, OPTPCS_FEC_TYPE_BYPASS, OPTPCS_PCS_GEAR_WIDTH_8B},
    {11, OPTPCS_ETH, OPTPCS_BIND_MODE_4T1X, OPTPCS_PORT_MODE_1X, OPTPCS_ETH_1G_2P5G_10B, OPTPCS_FEC_TYPE_BYPASS, OPTPCS_PCS_GEAR_WIDTH_8B},
};

UINT32 udFirmwareDownloadCount = 0;

/**********************************************************************
* 函数名称：serdesReset
* 功能描述：SERDES re-reset，复位所有SBus寄存器和SNaP
* 输入参数：
* 输出参数：
* 返 回 值：
* 其他说明：
* 修改日期         版本号       修改人            修改内容
* ----------------------------------------------------------------------
* 2018/09/15  V1.0    邱琛            创建
************************************************************************/
void serdesReset()
{
	sbusCommandTypeSwitch(1);
	sbusCommand(SBUS_ID_NTL_SERDES_D6_0, 0, 0);    // Reset D6_0 registers
	sbusCommand(SBUS_ID_NTL_SERDES_D6_1, 0, 0);    // Reset D6_1 registers
	sbusCommandTypeSwitch(0);
	BspSysUsDelay_Sys(20);    // 200 sbus_clk(12.5MHz, 80ns)
	sbusCommand(SBUS_ID_NTL_SERDES_D6_0, 0x07, 0x0010);
	sbusCommand(SBUS_ID_NTL_SERDES_D6_1, 0x07, 0x0010);
	sbusCommand(SBUS_ID_NTL_SERDES_D6_0, 0x07, 0x0000);
	sbusCommand(SBUS_ID_NTL_SERDES_D6_1, 0x07, 0x0000);
	BspSysUsDelay_Sys(50);    // 500 sbus_clk(12.5MHz, 80ns)
}

/**********************************************************************
* 函数名称：serdesFirmwareDownload
* 功能描述：SERDES固件加载
* 输入参数：
* 输出参数：
* 返 回 值：
* 其他说明：
* 修改日期         版本号       修改人            修改内容
* ----------------------------------------------------------------------
* 2018/03/10  V1.0     邱琛               创建
************************************************************************/
UINT32 serdesFirmwareDownload()
{
    UINT32 timeOut = 0;

	BootWrIcCrmReg(CRM_SBUS_CFG_REG, 0x0);
    BspSysUsDelay_Sys(1);
	BootWrIcCrmReg(CRM_SBUS_CFG_REG, 0x10);       // Enable SerDes firmware ROM
	
	// 设置固件加载等待时间为12ms，仿真波形时间为8.6ms
	// 20181110修改固件加载等待时间为20ms，10月23日博通提供固件的仿真波形时间为13.95ms
	while (timeOut<10)
	{
        BspSysMsDelay_Sys(5);
		if ((BootRdIcD6Reg(D6_SERDES_O_CORE_STATUS0) & 0x20) &&
				(BootRdIcD6Reg(D6_SERDES_O_CORE_STATUS1) & 0x20)) // 检查固件是否加载完成
		{
			// 固件加载完成，boot_road寄存器bit18置1
			printf("serdesFirmwareDownload succ\n");
			return BSP_OK;
		}
                
        timeOut++;
	}
    
    printf("serdesFirmwareDownload failed\n");
    return BSP_ERROR;
	// 20180727与博通讨论，固件加载完成后，无须配置i_rom_enable为0
	//WriteReg32(SBUS_CFG, 0x0);    // Disable SerDes firmware ROM
}

/**********************************************************************
* 函数名称：serdesFirmwareCRCCheck
* 功能描述：对加载的SERDES固件进行CRC校验
* 输入参数：
* 输出参数：
* 返 回 值：
* 其他说明：
* 修改日期         版本号       修改人            修改内容
* ----------------------------------------------------------------------
* 2018/03/10  V1.0     邱琛               创建
************************************************************************/
UINT32 serdesFirmwareCRCCheck()
{
	UINT32 volatile reg;
    UINT32 timeOut = 0;
    UINT32 maxCnt = 18;
    
	// core_interrupt(16'h003C,16'h0000), 对加载的固件进行CRC校验
	BootWrIcD6Reg(D6_LANE10_BASE_ADDR + 0x0, 0x3C0000);         // NTL port 10
	BootWrIcD6Reg(D6_LANE11_BASE_ADDR + 0x0, 0x3C0000);         // NTL port 11
	// 校验时间: 45(固件的每行校验时间：45个REFCLK)x6.4ns(156.25MH)x20000(固件总行数)=5.76ms
	//          仿真波形时间为：5.74ms
	//delay_ms(SERDES_D6_CRC_CHECK_TIMEOUT);
	while (timeOut < maxCnt)
	{
        BspSysMsDelay_Sys(10);
		reg = BootRdIcD6Reg(D6_LANE10_BASE_ADDR + 0x4) & 0x1FFFF;
		if (reg >> 16)
		{
			if (reg & 0xFFFF)
			{
				break;
			}
		}
		reg = BootRdIcD6Reg(D6_LANE11_BASE_ADDR + 0x4) & 0x1FFFF;
		if (reg >> 16)
		{
			if (reg & 0xFFFF)
			{
				break;
			}
			else
			{
			    return 0; /*ok*/
			}
		}
    
        timeOut++;
	}
	 return BSP_ERROR;
}

/**********************************************************************
* 函数名称：serdesConfig
* 功能描述：SERDES参数配置
* 输入参数：
* 输出参数：
* 返 回 值：
* 其他说明：
* 修改日期         版本号       修改人            修改内容
* ----------------------------------------------------------------------
* 2018/03/10  V1.0     邱琛               创建
************************************************************************/
void serdesConfig()
{
	UINT32 volatile reg;

	// core_interrupt(16'h0005,16'h8008),TX&RX Baud Rate，1.25G
	BootWrIcD6Reg(D6_LANE10_BASE_ADDR + 0x0, 0x59008);
	BootWrIcD6Reg(D6_LANE11_BASE_ADDR + 0x0, 0x59008);
	while(1)
	{
		reg = BootRdIcD6Reg(D6_LANE10_BASE_ADDR + 0x4);
		if (0x10005 == (reg & 0x1FFFF))                      // 等待配置完成
			break;
	}
	while (1)
	{
		reg = BootRdIcD6Reg(D6_LANE11_BASE_ADDR + 0x4);
		if (0x10005 == (reg & 0x1FFFF))                       // 等待配置完成
			break;
	}

	// core_interrupt(16'h0006,16'h8008),RX Baud Rate
	// 根据博通建议移除，INT5可以同时配置TX和RX Baud Rate
	/*WriteReg32(D6_LANE10_BASE_ADDR + 0x0, 0x68008);
	WriteReg32(D6_LANE11_BASE_ADDR + 0x0, 0x68008);
	while(1)
	{
		reg = ReadReg32(D6_LANE10_BASE_ADDR + 0x4);
		if (0x10006 == (reg & 0x1FFFF))                      // 等待配置完成
			break;
	}
	while (1)
	{
		reg = ReadReg32(D6_LANE11_BASE_ADDR + 0x4);
		if (0x10006 == (reg & 0x1FFFF))                      // 等待配置完成
			break;
	}*/

	// core_interrupt(16'h0014,16'h0000),TX/RX NRZ 10bit
	BootWrIcD6Reg(D6_LANE10_BASE_ADDR + 0x0, 0x148800);
	BootWrIcD6Reg(D6_LANE11_BASE_ADDR + 0x0, 0x148800);
	while(1)
	{
		reg = BootRdIcD6Reg(D6_LANE10_BASE_ADDR + 0x4);
		if (0x10014 == (reg & 0x1FFFF))                      // 等待配置完成
			break;
	}
	while (1)
	{
		reg = BootRdIcD6Reg(D6_LANE11_BASE_ADDR + 0x4);
		if (0x10014 == (reg & 0x1FFFF))                      // 等待配置完成
			break;
	}
}

/**********************************************************************
* 函数名称：serdesEnable
* 功能描述：SERDES收发使能
* 输入参数：
* 输出参数：
* 返 回 值：
* 其他说明：
* 修改日期         版本号       修改人            修改内容
* ----------------------------------------------------------------------
* 2018/03/10  V1.0     邱琛               创建
************************************************************************/
void serdesEnable()
{
	UINT32 volatile reg;

	// core_interrupt10(16'h0001, 16'h0007), turn SERDES on, TX/RX/output enable
	BootWrIcD6Reg(D6_LANE10_BASE_ADDR + 0x0, 0x10007);
	BootWrIcD6Reg(D6_LANE11_BASE_ADDR + 0x0, 0x10007);
	while(1)
	{
		reg = BootRdIcD6Reg(D6_LANE10_BASE_ADDR + 0x4);
		if (0x10001 == (reg & 0x1FFFF))                      // 等待lane10 D6 TX/RX使能
			break;
	}
	while (1)
	{
		reg = BootRdIcD6Reg(D6_LANE11_BASE_ADDR + 0x4);
		if (0x10001 == (reg & 0x1FFFF))                      // 等待lane11 D6 TX/RX使能
			break;
	}
}
VOID SbusMasterSoftRepair(void)
{
	UINT32 data = 0;
	UINT32 loops = 0;
	sbusCommand(BROADCAST_ADDR_SNAP, 0x00, 0x03);
	data=sbusResultOut(BROADCAST_ADDR_SNAP, 0x01);
	data = ((data & (~(0x180))) |0x80);
	sbusCommand(BROADCAST_ADDR_SNAP, 0x01, data);
	sbusCommand(BROADCAST_ADDR_SNAP, 0x00, 0x05);
	for(loops=0;loops<500;loops++)
	{
		BspSysMsDelay_Sys(1);
		data=sbusResultOut(BROADCAST_ADDR_SNAP, 0x00);
		if(data & 0x18)
		{
			printf("loops = %d\n",loops);
			break;
		}	
	}
	if(loops >= 500)
		printf("Sbus master SPICO RAM BIST timeout on sbus address 0xFD .\nreg0 =0x%x\n",data);
	else if((data&0x18) == 0x08)
		printf("Sbus master SPICO RAM BIST test pass .\nreg0 =0x%x\n",data);
	else
		printf("Sbus master SPICO RAM BIST test fail .\nreg0 =0x%x\n",data);
	
	sbusCommand(BROADCAST_ADDR_SNAP, 0x00, 0x01);	
}

VOID D6SerdesSoftRepair(UINT8 ucSbusId)
{
	UINT32 data = 0;
	UINT32 loops = 0;
	sbusCommand(ucSbusId, 0x09, 0x00); 
	sbusCommand(ucSbusId, 0x07,0x11);
	sbusCommand(ucSbusId, 0x09,0x03);
	for(loops=0;loops<500;loops++)
	{
		BspSysUsDelay_Sys(1);
		data=sbusResultOut(ucSbusId, 0x09);
		if(data & 0x3f0060)
			break;
	}
	if(loops >= 500)
		printf("D6 RAM BIST timeout on sbus address ID 0x%x .\nreg9 =0x%x\n",ucSbusId,data);
	else if(data&0x3f0040)
		printf("D6 RAM BIST test fail on sbus address ID 0x%x.\nreg9 =0x%x\n",ucSbusId,data);
	else
		printf("D6 RAM BIST test pass on sbus address ID 0x%x .\nreg9 =0x%x\n",ucSbusId,data);
	
	sbusCommand(ucSbusId, 0x09, 0x00);	

	
}

/**********************************************************************
* 函数名称：SerdesD6Init
* 功能描述：SERDES初始化流程
* 输入参数：
* 输出参数：
* 返 回 值：
* 其他说明：
* 修改日期         版本号       修改人            修改内容
* ----------------------------------------------------------------------
* 2018/03/10  V1.0     邱琛               创建
* 2018/07/31  V1.1     邱琛               删除SBus Master的复位，将SBus总线速率修改为12.5M
* 2018/09/15  V1.2     邱琛               在固件加载之前，增加re-reset流程
************************************************************************/
void SerdesD6Init()
{
	/* 1. SBUS总线速率配置为12.5MHz  */
	//sbusRst();    20180731 讨论确认删除
	
	sbusSetClk12_5M();

	/* 2. SerdesD6固件加载和CRC校验 */
	do
	{
		serdesReset();    // 在固件加载之前，增加re-reset流程
		serdesFirmwareDownload();
	}while(BSP_OK != serdesFirmwareCRCCheck());

	/* 3. SerDesD6配置和使能  */
	serdesConfig();
	serdesEnable();
	printf("SerdesD6Init finish\n");
}
VOID SoftRepair()
{
	SbusMasterSoftRepair();
	D6SerdesSoftRepair(SBUS_ID_NTL_SERDES_D6_LANE10);
	D6SerdesSoftRepair(SBUS_ID_NTL_SERDES_D6_LANE11);
}
UINT32 SerdesPcsInit()
{
    return HalIcPcsSetOptWorkMode(&gtBootEthPcsCfg[0],2);
}

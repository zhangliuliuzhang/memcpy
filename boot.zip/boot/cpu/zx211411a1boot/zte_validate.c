// SPDX-License-Identifier: GPL-2.0+
/*
 * Copyright 2015 Freescale Semiconductor, Inc.
 */
#ifdef CONFIG_SECURITY
#include <zte_validate.h>
#include <malloc.h>
#include <bignum.h>
#include "cJSON.h" 
#include <string.h>

static uint32_t ui_nv_counter;
static uint32_t ui_csf_version;
static uint32_t algorithm_cpu;
static uint32_t algorithm_boot;
static uint32_t alg_param;

#define CHECK_KEY_LEN(key_len)	(((key_len) == 2 * RSA_3K_KEY_SZ_BYTES) || \
				 ((key_len) == 2 * RSA_4K_KEY_SZ_BYTES) || \
				 ((key_len) == 2 * RSA_2K_KEY_SZ_BYTES))

static char hash_val[SHA256_BYTES] = {0};

static const char barker_code[CSF_BARKER_LEN] = { 0x00, 0x21, 0x14, 0x13 };
/*secure boot enable*/
static const char sec_en_code[4] = {0x73, 0x61, 0x66, 0x65};/*safe*/
/*validate secure boot dbg flag*/
int g_boot_validate_dbg = 0;
/*algorithm of this cert and next cert*/
static T_CSF_ALGRITHM algorithm_cert[2]={0};

unsigned int BspGetSafeBootCheckSwitch(unsigned int *pRdval)
{
    T_EFUSE_FLASH t_efuse_value;
    if(NULL == pRdval) {
        printf("input pRdVal NULL \n");
        return -1;
    }
    if(0 != BspFlashRead(CONFIG_EFUSE_FLASH_ADDR, (uchar *)&t_efuse_value, sizeof(T_EFUSE_FLASH)))
    {
        printf(" T_EFUSE_FLASH INFO READ wrong!!\n");
        return -1;
    }
    if ((t_efuse_value.sec_en) != (*(int *)sec_en_code)) {
        *pRdval = 0;
    } else {
        *pRdval = 1;
    }

    printf("%s>>read safe boot mode switch, Rdval=0x%x(0-close, 1-open)\n",__FUNCTION__, *pRdval);
    return 0;
}
unsigned int BspGetNvModeSwitch(unsigned int *pRdVal)
{
    T_EFUSE_FLASH t_efuse_value;
    if(NULL == pRdVal) {
        printf("input pRdVal NULL \n");
        return -1;
    }
    if(0 != BspFlashRead(CONFIG_EFUSE_FLASH_ADDR, (uchar *)&t_efuse_value, sizeof(T_EFUSE_FLASH)))
    {
        printf(" T_EFUSE_FLASH INFO READ wrong!!\n");
        return -1;
    }
    if ((t_efuse_value.nv_en) != (*(int *)sec_en_code)) {
        *pRdVal = 0;
    } else {
        *pRdVal = 1;
    }

    return 0;
}
unsigned int BspUserNvValRead(unsigned int *pRdVal)
{
    T_EFUSE_FLASH t_efuse_value;
    if(NULL == pRdVal) {
        printf("input pRdVal NULL \n");
        return -1;
    }
    if(0 != BspFlashRead(CONFIG_EFUSE_FLASH_ADDR, (uchar *)&t_efuse_value, sizeof(T_EFUSE_FLASH)))
    {
        printf(" T_EFUSE_FLASH INFO READ wrong!!\n");
        return -1;
    }
	*pRdVal = t_efuse_value.nv_value;
	return 0;
}
static unsigned int BspHashCmp(char *pHsah, unsigned int ulLen)
{
    T_EFUSE_FLASH t_efuse_value;

    if(NULL == pHsah) {
        printf("input pHsah NULL \n");
        return -1;
    };  
    if(ulLen != SHA256_BYTES)
    {
        printf("%s>>ulLen=%d input error\n",__FUNCTION__, ulLen);
        return -1;
    }

    if(0 != BspFlashRead(CONFIG_EFUSE_FLASH_ADDR, (uchar *)&t_efuse_value, sizeof(T_EFUSE_FLASH)))
    {
        printf(" T_EFUSE_FLASH INFO READ wrong!!\n");
        return -1;
    }

    for(int i=0; i<ulLen; i++)
    {
        if(*(pHsah+i) != t_efuse_value.pkey_hash[i])
            return -1;
    }

	return 0;
}
void boot_validate_dbg(int uiEnable)
{
	if(uiEnable)
		g_boot_validate_dbg=1;
	else
		g_boot_validate_dbg=0;
}
/*
*  get nv counter from csf_header
*/
static uint32_t zte_get_csf_nv_counter(uintptr_t csf_haddr)
{
	struct csf_hdr *hdr = (struct csf_hdr *)csf_haddr;
    return (hdr->csf_nv.nv_num);
}
/*
*  get version from csf_header
*/
static uint32_t zte_get_csf_version(uintptr_t csf_haddr)
{
	struct csf_hdr *hdr = (struct csf_hdr *)csf_haddr;
	return (hdr->csf_version.ver);
}
/*
*  get algorithm from csf_header
*/
static uint32_t zte_get_algorithm(uintptr_t csf_haddr, int select)
{
	struct csf_hdr *hdr = (struct csf_hdr *)csf_haddr;

	if(NULL == hdr) {
		printf("hdr is NULL !\n");
		return -1;
	}

	if(select > CSF_CPUKEY_NUM) {
		printf("inputpara select ERROR!\n");
		return -1;
	}
	#if 0 /*因为4.2安全头还没发填入下级证书算法，所以此处暂时按照这样处理。*/
	algorithm_cert[select].hash_alg = SWAP16(hdr->csf_algorithm[select].hash_alg);
	algorithm_cert[select].sig_alg = SWAP16(hdr->csf_algorithm[select].sig_alg);
	algorithm_cert[select].img_hash_alg = SWAP16(hdr->csf_algorithm[select].img_hash_alg);
	#else
	algorithm_cert[select].hash_alg = (hdr->csf_algorithm[CSF_BOOTKEY_NUM].hash_alg);
	algorithm_cert[select].sig_alg = (hdr->csf_algorithm[CSF_BOOTKEY_NUM].sig_alg);
	algorithm_cert[select].img_hash_alg = (hdr->csf_algorithm[CSF_BOOTKEY_NUM].img_hash_alg);
	#endif
	return 0;
}
/*
 * Calculate hash of input data
 */
int calc_data_hash(char *pdata, uint32_t pdata_len, char *calc_hash, int pub_select)
{
	struct hash_algo *algo;
	void *ctx;
	uint16_t hash_alg=0;
	int ret = 0;

	if(pub_select == CSF_BOOTKEY_NUM)
		hash_alg = algorithm_cert[CSF_BOOTKEY_NUM].hash_alg;
	else
		hash_alg = algorithm_cert[CSF_CPUKEY_NUM].hash_alg;

	if(ZTE_SHA256 != hash_alg) {
		printf("csf header input algorithm error!!! hash_alg=0x%x\n", hash_alg);
		return -1;
	}

	/* Calculate hash of the esbc key */
	ret = hash_init_sha256( &ctx);
	if (ret) {
		printf("%s hash_init error ret= 0x%x\n", __func__, ret);
		return ret;
	}

	ret = hash_update_sha256(ctx, pdata, pdata_len, 1);
	if (ret) {
		printf("%s hash_update error ret= 0x%x\n", __func__, ret);
		return ret;
	}

	/* Copy hash at destination buffer */
	ret = hash_finish_sha256(ctx, calc_hash, SHA256_BYTES);
	if (ret) {
		printf("%s hash_finish error ret= 0x%x\n", __func__, ret);
		return ret;
	}

	return 0;
}

/*
 * Authenticate by Non-Volatile counter
 *
 * To protect the system against rollback, the platform includes a non-volatile
 * counter whose value can only be increased. All certificates include a counter
 * value that should not be lower than the value stored in the platform. If the
 * value is larger, the counter in the platform must be updated to the new
 * value.
 *
 *
 * Return: 0 = success, Otherwise = error
 */
int zte_auth_nvctr(uint32_t ui_counter)
{
	int iret=0;
	uint32_t i_efuse_rdcounter=0;
	uint32_t i_nvmode=0;

	/*check, if rollback is not enable, return */
	iret = BspGetNvModeSwitch(&i_nvmode);
	if(0 != iret) {
		printf("get rollback mode error!!\n");
		return 0;
	}

	if(i_nvmode == 0) {
		printf("rollback mode not enable!\n");
		return 0;
	}
	iret = BspUserNvValRead(&i_efuse_rdcounter);
	if(0 != iret) {
		printf("get rollback version counter error!!\n");
		return -1;
	}
	if(i_efuse_rdcounter > ui_counter) {
		printf("rd_counter is %d, plat_counter is %d \n", ui_counter, i_efuse_rdcounter);
		return -1;
	}

	return 0;
}
/*
 * get the version pub key of cur.swv to verify cpu swv. this func is called after cert_File is verified.
 * boot key is key[0], version key is key[1]
 * input : CA_CERT file ADDR (csf head + ca_cert)
 * output: pub_key
 * output: pub_key_len
 */
int ldPkeyFromCAheader(unsigned int csf_haddr, char *pub_key, unsigned int *pub_key_len)
{
	struct csf_hdr *hdr = NULL;
	int iret=0;

	if(0 == csf_haddr) {
		printf("%s input para is NULL\n", __func__);
		iret = -1;
	};

	hdr = (struct csf_hdr *)csf_haddr;
	switch (algorithm_cert[CSF_CPUKEY_NUM].sig_alg) {
		case ENCRYPTION_RSA1024:
			*pub_key_len = RSA_1K_KEY_SZ_BYTES;
			zte_memcpy_s(pub_key, *pub_key_len, &(hdr->csf_pkey_next_key.value[RSA_2K_KEY_SZ_BYTES]), *pub_key_len);
			break;
		case ENCRYPTION_RSA2048:
			*pub_key_len = RSA_2K_KEY_SZ_BYTES;
			zte_memcpy_s(pub_key, *pub_key_len, &(hdr->csf_pkey_next_key.value[RSA_1K_KEY_SZ_BYTES]), *pub_key_len);
			break;
		case ENCRYPTION_RSA3072:
			*pub_key_len = RSA_3K_KEY_SZ_BYTES;
			zte_memcpy_s(pub_key, *pub_key_len, &(hdr->csf_pkey_next_key.value[0]), *pub_key_len);
			break;
		default:
			*pub_key_len = RSA_2K_KEY_SZ_BYTES;
			zte_memcpy_s(pub_key, *pub_key_len, &(hdr->csf_pkey_next_key.value[RSA_1K_KEY_SZ_BYTES]), *pub_key_len);
			printf("version pkey not support encrytion algorithm 0x%x\n", algorithm_cert[CSF_CPUKEY_NUM].sig_alg);
			break;
	}
	*pub_key_len = (*pub_key_len)*2;

	if(!CHECK_KEY_LEN(*pub_key_len)) {
		printf("%s csf header key len is %d, error\n", __func__, *pub_key_len);
		iret = -1;
	}

	return iret;
}
/*
 * use boot key verify boot or ca cert file. boot key is use key[0]. 
 *
 */
int zte_secure_validate(const uintptr_t csf_haddr)
{
	struct csf_hdr *hdr = (struct csf_hdr *)csf_haddr;
	uint32_t pkey_len = 0;
	char* pkey_addr = 0;
	uint32_t psign_len = 0;
	char* psign_addr = 0;
	char calc_hash[SHA256_BYTES] = {0};
	char *img_addr_addr = NULL;
	uint32_t img_len=0;
	int ret=0;

	/* check barker code */
	if ((hdr->csf_version.id.name) != (*(int *)barker_code)) {
		printf("barker compare failed!\n");
		printf("name = 0x%x\n", hdr->csf_version.id.name);
		printf("test 0x%x\n",*(int *)barker_code);
		return -1;
	} else {
		printf("barker compare pass!!\n");
	}

	/*parse csf header, and save it*/
	ui_nv_counter = zte_get_csf_nv_counter(csf_haddr);
	ui_csf_version = zte_get_csf_version(csf_haddr);
	zte_get_algorithm(csf_haddr, CSF_BOOTKEY_NUM);
	zte_get_algorithm(csf_haddr, CSF_CPUKEY_NUM);

    if(g_boot_validate_dbg) {
	    printf("<---------------csf parse----------->\n");
	    printf("nvcounter = 0x%x csf_version = 0x%x \n", ui_nv_counter, ui_csf_version);
	    printf("this cert algorithm: cert_hash = 0x%x, cert_sig=0x%x, img_hash = 0x%x\n", algorithm_cert[CSF_BOOTKEY_NUM].hash_alg, 
	                     algorithm_cert[CSF_BOOTKEY_NUM].sig_alg, algorithm_cert[CSF_BOOTKEY_NUM].img_hash_alg);
	    printf("next cert algorithm: cert_hash = 0x%x, cert_sig=0x%x, img_hash = 0x%x\n", algorithm_cert[CSF_CPUKEY_NUM].hash_alg, 
	                     algorithm_cert[CSF_CPUKEY_NUM].sig_alg, algorithm_cert[CSF_CPUKEY_NUM].img_hash_alg);
	    printf("<---------------csf parse end-------->\n");
    }

	/*get pubkey offset and size*/
	/*check if support encrrption alg*/
	switch (algorithm_cert[CSF_BOOTKEY_NUM].sig_alg) {
		case ENCRYPTION_RSA1024:
			pkey_len = RSA_1K_KEY_SZ_BYTES*2;
			psign_len = RSA_1K_KEY_SZ_BYTES;
			pkey_addr = (uint8_t *)&(hdr->csf_pkey_this_key.value[RSA_2K_KEY_SZ_BYTES]);
			psign_addr =  (uint8_t *)&(hdr->csf_fingerprint[RSA_2K_KEY_SZ_BYTES]);
			break;
		case ENCRYPTION_RSA2048:
			pkey_len = RSA_2K_KEY_SZ_BYTES*2;
			psign_len = RSA_2K_KEY_SZ_BYTES;
			pkey_addr = (uint8_t *)&(hdr->csf_pkey_this_key.value[RSA_1K_KEY_SZ_BYTES]);
			psign_addr =  (uint8_t *)&(hdr->csf_fingerprint[RSA_1K_KEY_SZ_BYTES]);
			break;
		case ENCRYPTION_RSA3072:
			pkey_len = RSA_3K_KEY_SZ_BYTES*2;
			psign_len = RSA_3K_KEY_SZ_BYTES;
			pkey_addr = (uint8_t *)&(hdr->csf_pkey_this_key.value[0]);
			psign_addr =  (uint8_t *)&(hdr->csf_fingerprint[0]);
			break;
		default:
			printf("Boot pkey not support encrytion algorithm 0x%x\n", algorithm_cert[CSF_BOOTKEY_NUM].sig_alg);
			break;
	}

	if(!CHECK_KEY_LEN(pkey_len)) {		
		printf("%s get pub_key addr=%p, len=0x%x;  len is error\n", __func__, pkey_addr, pkey_len);
		return -2;
	}

	if((psign_len*2) != pkey_len)	{
		printf("%s get sign addr=0x%p, len=0x%x error\n", __func__, psign_addr, psign_len);
		return -4;
	}

	calc_data_hash(&(hdr->csf_pkey_this_key.value[0]), CSF_PKEY_MAX_SIZE, calc_hash, CSF_BOOTKEY_NUM);
	if(g_boot_validate_dbg) {
		printf("calc sha256 of root key is:");
		for (int i = 0; i < SHA256_BYTES; i++) {
			printf("%02x", calc_hash[i]);
		}
		printf("\n");
	}

	/*cmp hash_of_pkey with efuse*/
	ret = BspHashCmp(calc_hash, SHA256_BYTES);
	if (ret != 0) {
		printf("%s EFUSE_HASH_CMP FAILED!! ret=0x%x\n", __func__, ret);
		return ret;
	}

	/*get image_addr && img_size*/
	img_addr_addr = (hdr->csf_image.offset_low);
	img_addr_addr = (unsigned int)csf_haddr + (unsigned int)img_addr_addr;
	img_len = (hdr->csf_image.size);
    if(g_boot_validate_dbg) {
	    printf("csf_haddr=%p img_addr=%p  len=0x%x\n", csf_haddr, img_addr_addr, img_len);
    }

	/*compare image hash with hdr->hash*/
	calc_data_hash(img_addr_addr, img_len, calc_hash, CSF_BOOTKEY_NUM);

	ret = memcmp(calc_hash, &(hdr->csf_image.hash[SHA256_BYTES]),SHA256_BYTES);
 	if (ret) {
		if(g_boot_validate_dbg) {
			printf("calc sha256 of image is:");
			for (int i = 0; i < SHA256_BYTES; i++) {
				printf("%02x", calc_hash[i]);
			}
			printf("\n");
			printf("header sha256 of image is:");
			for (int i = 0; i < SHA256_BYTES; i++) {
				printf("%02x", hdr->csf_image.hash[i+SHA256_BYTES]);
			}
			printf("\n");
		}
		printf("%s compare image hash with hdr->hash error!! ret=0x%x", __func__, ret);
		return ret;
	}
	/*get header hash to hash_val*/
	ret = calc_data_hash((char *)hdr, sizeof(struct csf_hdr) - CSF_SIGN_MAX_SIZE, hash_val, CSF_BOOTKEY_NUM);
	if (ret) {
		printf("%s zte_calc_esbchdr_hash ret=0x%x", __func__, ret);
		return ret;
	}
	if(g_boot_validate_dbg) {
		printf("calc sha256 of header is:");
		for (int i = 0; i < SHA256_BYTES; i++) {
			printf("%02x", hash_val[i]);
		}
		printf("\n");
	}

	ret = rsa_auth_signature(hash_val, (char *)pkey_addr, pkey_len, (char *)psign_addr, psign_len);
	if(ret) {
		printf("rsa_auth_signature failed! ret=0x%x\n", ret);
		printf("pkey_addr = %p, psign_addr=%p\n", pkey_addr, psign_addr);
		return ret;
	}

	return 0;
}

/*
* get sign data from jSon file in protect flash
*/
uint32_t BspGetVersionSign(uchar *ucBuf, uint32_t ulFileLen, uint32_t ulFileCrc, uchar* ucSign, uint32_t *uiSign_len)
{
    cJSON * ver_sign_json = NULL;
    cJSON * ver_pkg = NULL;
    cJSON * pkg_child = NULL;
    cJSON * hash_type = NULL;
    cJSON * ver_infos = NULL;
    cJSON * ver_child = NULL;
    cJSON * size = NULL;
    cJSON * crc = NULL;
    cJSON * hashSign = NULL;
    uint32_t ulVerLen =0;
    uint32_t ulVerCrc = 0;

    if(( ucSign == NULL) || (ucBuf == NULL))
    {
        printf("input para is null !\n");
        return -1;
    }
    ver_sign_json = cJSON_Parse((char *)ucBuf);
    
    if(NULL==ver_sign_json)
    {
        printf("ver_sinput is NULL !\n");
        return -1;
    }

    ver_pkg = cJSON_GetObjectItem(ver_sign_json,"pkgGroup");
    if(NULL == ver_pkg)
    {
        printf("Get pkgGroup Object Failed [crc:%d len:%d] !\n", ulFileCrc, ulFileLen);
        return -1;
    }
    pkg_child = ver_pkg->child;
    while(pkg_child !=NULL)
    {

        hash_type = cJSON_GetObjectItem(pkg_child,"hashType");

        if(NULL == hash_type)
        {
            printf("Get hashType Object Failed [crc:%d len:%d] !\n", ulFileCrc, ulFileLen);
            break;
        }     

        ver_infos = cJSON_GetObjectItem(pkg_child, "softInfos"); 
       
        if(NULL == ver_infos)
        {
            printf("Get softInfos Object Failed [crc:%d len:%d] !\n", ulFileCrc,ulFileLen);
            break;
        }
        ver_child = ver_infos->child;    
        while(ver_child != NULL)
        {
            size = cJSON_GetObjectItem(ver_child, "size");   
            crc = cJSON_GetObjectItem(ver_child, "crc");
            if( crc==NULL || size==NULL )
            {
                printf("Get size & crc Object Failed [crc:%d len:%d] !\n", ulFileCrc,ulFileLen);
                break;
            }
            ulVerLen = (u32)size->valueint;
            ulVerCrc = (u32)crc->valueint;
            printf("sizze %d,crc %d Get Succ !\n", ulVerLen, ulVerCrc);
            if((ulFileLen == ulVerLen)&&(ulFileCrc==ulVerCrc))
            {
                hashSign = cJSON_GetObjectItem(ver_child, "hashSign");
                if(NULL == hashSign)
                {
                    printf("Get hashSign Failed [crc:%d len:%d] !\n", ulFileCrc,ulFileLen);
                    return -1;
                }
				if(strlen(hashSign->valuestring) > MAX_SIGN_STRING_LEN )
				{
					printf("string signlen error\n");
					return -1;
				}

				mbedtls_base64_decode((uchar *)ucSign, RSA_4K_KEY_SZ_BYTES, (size_t *)uiSign_len,
                   (uchar *)hashSign->valuestring, strlen(hashSign->valuestring) );

				if(g_boot_validate_dbg) {
					printf("hash lenth %ld, string %s [crc:%d len:%d] !\n", 
								strlen(hashSign->valuestring),hashSign->valuestring,ulFileCrc,ulFileLen);
		
					for(int i =0; i< *uiSign_len; i++){
						printf("0x%x ",*(ucSign+i));
						if((i+1)%8==0) printf("\n");
					}
				}
                return 0;
            }
            ver_child = ver_child->next;
        }
        pkg_child = pkg_child->next;
    }
    return -1;    
}
#endif
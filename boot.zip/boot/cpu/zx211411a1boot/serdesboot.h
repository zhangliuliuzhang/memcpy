/**************************************************************************
 * 版权所有 (C)2001, 深圳市中兴通讯股份有限公司
 *
 * 文件名称: zx211410boot.h
 * 文件标识:
 * 内容摘要:
 * 其它说明:
 * 当前版本: 
 * 作    者:
 * 完成日期:
 *
 * 修改记录1:
 *    修改日期: 
 *    版 本 号: 
 *    修 改 人: 
 *    修改内容: 创建
 * 修改记录2:
 **************************************************************************/

#ifndef _SERDESBOOT_H_
#define _SERDESBOOT_H_

#include <netinet/in.h>
#include <arpa/inet.h>

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

#define DIF_ECSERDES_M6                 0  /*物理地址0x96d00000*/    
#define D6_SERDES_O_CORE_STATUS0       (DIF_ECSERDES_M6 + 0xB0)
#define D6_SERDES_O_CORE_STATUS1       (DIF_ECSERDES_M6 + 0xB4)

/*core interrupt to access serdes*/
#define D6_LANE10_BASE_ADDR            (DIF_ECSERDES_M6 + 0x100)
#define D6_LANE11_BASE_ADDR            (DIF_ECSERDES_M6 + 0x110)

// 校验时间: 45(固件的每行校验时间：45个REFCLK)x6.4ns(156.25MH)x20000(固件总行数)=5.76ms
#define SERDES_D6_CRC_CHECK_TIMEOUT    (15000)

UINT32 serdesFirmwareDownload();
UINT32 serdesFirmwareCRCCheck();
VOID serdesConfig();
VOID serdesEnable();
VOID SerdesD6Init();
VOID SoftRepair();

#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif


/**************************************************************************
 * 版权所有 (C)2001, 深圳市中兴通讯股份有限公司
 *
 * 文件名称: zx211410boot.h
 * 文件标识:
 * 内容摘要:
 * 其它说明:
 * 当前版本: 
 * 作    者:
 * 完成日期:
 *
 * 修改记录1:
 *    修改日期: 
 *    版 本 号: 
 *    修 改 人: 
 *    修改内容: 创建
 * 修改记录2:
 **************************************************************************/

#ifndef _CRMBOOT_H_
#define _CRMBOOT_H_

#include <netinet/in.h>
#include <arpa/inet.h>

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

#define BOOT_CRM_EN
typedef enum 
{
    EXT_SOC_RST,           
    WD_TIMEOUT_RST,
    A53_POWER_RST,
    A53_ONLY_CORE_RST,
    
    A53_ALL_CORE_RST,
    R8_ALL_CORE_RST,
    REMOTE_HARD_RST,
    REMOTE_POWER_RST,  /*7*/
    
    REMOTE_ROE_IR_HARD_RST,
    REMOTE_ROE_CPRI_HARD_RST,
    REMOTE_ROE_IR_POWER_RST,
    REMOTE_ROE_CPRI_POWER_RST,
    
    REMOTE_OPT_IR_HARD_RST,
    REMOTE_OPT_CPRI_HARD_RST,
    REMOTE_OPT_IR_POWER_RST,
    REMOTE_OPT_CPRI_POWER_RST, /*15*/

    SYSTEM_POWER_RST,
    
    
}E_RST_REASON_STATUS;





/* crm boot配置相关寄存器基址 */
#define CRM_SOC_REG                               (0) 
#define CRM_RESET_CLR_REG                         (CRM_SOC_REG + 0x140)/* 复位原因记录清除上报寄存器*/
#define CRM_RESET_RECORD_REG                      (CRM_SOC_REG + 0x144)/* 复位原因记录状态上报寄存器*/
#define CRM_PLL_BYPASS_STA_REG                    (CRM_SOC_REG + 0x1C4)/* PLL0/1进入Bypass模式状态寄存器*/
#define CRM_BOOT_ROAD_REG                         (CRM_SOC_REG + 0x180)/* BOOT路标地址 */
#define CRM_BOOT_JUMP_FLAG_REG                    (CRM_SOC_REG + 0x184)/* PCIE启动方式跳转标志寄存器  */
    
#define CRM_CFG_PCIE_RST_REG                      (CRM_SOC_REG + 0x68)
#define CRM_CORE_SBUS_COMMAND_REG                 (CRM_SOC_REG + 0x274)
#define CRM_SBUS_CFG_REG                          (CRM_SOC_REG + 0x278)

/*MII*/
#define CRM_MII_CLK_FRAC    					  (CRM_SOC_REG + 0x21c)
    
    /* PLL3 */
#define CRM_PLL3_FREFEFF_REG                      (CRM_SOC_REG + 0x53C)
#define CRM_PLL3_POST_REG                         (CRM_SOC_REG + 0x554)
#define CRM_PLL3_RESETB_REG                       (CRM_SOC_REG + 0x55C)
#define CRM_PLL3_STATE_REG                        (CRM_SOC_REG + 0x560)
    
    /* PLL4 */
#define CRM_PLL4_FREFEFF_REG                      (CRM_SOC_REG + 0x63C)
#define CRM_PLL4_RESETB_REG                       (CRM_SOC_REG + 0x65C)
    
    /* PLL5 */
#define CRM_PLL5_FREFEFF_REG                      (CRM_SOC_REG + 0x73C)
#define CRM_PLL5_RESETB_REG                       (CRM_SOC_REG + 0x75C)
    
    /* PLL6 */
#define CRM_PLL6_MDIV_REG                         (CRM_SOC_REG + 0x818)
#define CRM_PLL6_FREFEFF_REG                      (CRM_SOC_REG + 0x83C)
#define CRM_PLL6_NDIV_FRAC_REG                    (CRM_SOC_REG + 0x848)
#define CRM_PLL6_NDIV_INT_REG                     (CRM_SOC_REG + 0x84C)
#define CRM_PLL6_PDIV_REG                         (CRM_SOC_REG + 0x850)
#define CRM_PLL6_RESETB_REG                       (CRM_SOC_REG + 0x85C)
    
    /* CRM DIF subsystem */
#define CRM_NTL_RST_REG                           (CRM_SOC_REG + 0x8030)
#define CRM_ROE_RST_REG                           (CRM_SOC_REG + 0x8038)
#define CRM_PCS_RST_REG                           (CRM_SOC_REG + 0x8044)
#define CRM_NTL_COMMON_GATE_REG                   (CRM_SOC_REG + 0x8094)
#define CRM_NTL_TRI_GATE_REG                      (CRM_SOC_REG + 0x80A0)
#define CRM_NTL_TROA1_GATE_REG                    (CRM_SOC_REG + 0x80A8)


#define CRM_PLL3_CRM_LOCK_OFFSET                   4
#define CRM_PLL3_CRM_LOCK                         (1 << CRM_PLL3_CRM_LOCK_OFFSET)


UINT32 BootSetMiiClk();
/* Started by AICoder, pid:l58a3k479033b131420b0b34005f02056432e726 */
UINT32 BootWrIcCrmReg(UINT32 ulAddr, UINT32 ulData);
UINT32 BootRdIcCrmReg(UINT32 ulAddr);
/* Ended by AICoder, pid:l58a3k479033b131420b0b34005f02056432e726 */
ULONG BootGetaulCrmVirAddr();
#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif


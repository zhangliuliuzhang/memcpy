/*****************************************************************************
 * 版权所有(C) 2010, ZTE Corp. RRU Bsp Platform
 *----------------------------------------------------------------------------
 * 模 块 名 : BSP
 * 文件名称 : dpdichal.c
 * 文件标识 : {[N/A]}
 * 内容摘要 : 实现dpdic的加速器配置
 * 注意事项 : 无
 * 作    者 : 郭勇
 * 创建日期 : 2019-04-08 
 * 当前版本 : Ver1.0
 *----------------------------------------------------------------------------
 * 变更记录 :
 *
 * $记录1
 * 变 更 单: $0000000(N/A)
 * 责 任 人: 耿佳佳
 * 修改日戳: 2015-10-22 08:28:34
 * 变更说明: 创建文件
 *
 *----------------------------------------------------------------------------
 */


/* 标准库头文件 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h> 
#include "bsppub.h"
#include "crmboot.h"

/* Started by AICoder, pid:deacbb8c688a79c14fa60b00c09b1b188dd29421 */

UINT32 BootWrIcCrmReg(UINT32 ulAddr, UINT32 ulData)
{   
    *((volatile UINT32 *)(ulAddr + BootGetaulCrmVirAddr())) = ulData;
    return BSP_OK;
}

UINT32 BootRdIcCrmReg(UINT32 ulAddr)
{
    return *((volatile UINT32 *)(ulAddr + BootGetaulCrmVirAddr()));
}
/* Ended by AICoder, pid:deacbb8c688a79c14fa60b00c09b1b188dd29421 */

VOID BootSetIcPLL3Rst()
{
	// PLL3 reset
	BootWrIcCrmReg(CRM_PLL3_RESETB_REG, 0x0);
	// 复位后等待1us
	BspSysMsDelay_Sys(10);
	// PLL3 release reset
	BootWrIcCrmReg(CRM_PLL3_RESETB_REG, 0x1);
	// 释放复位后等待1ms
	BspSysMsDelay_Sys(10);
}

UINT32 BootGetPLL3State()
{
	return BootRdIcCrmReg(CRM_PLL3_STATE_REG);
}


/* bootrom和bootapp 只复位了NTL的10,11*/
VOID BootRstL2ss()
{
#ifdef BOOT_CRM_EN
	// bit0: NTL(983 post logic)
	BootWrIcCrmReg(CRM_ROE_RST_REG, BootRdIcCrmReg(CRM_ROE_RST_REG) & (~0x1));
	// bit1: NTLPPB; bit[19:18]: MAC10/11 TX; bit[31:30]: MAC10/11 RX
	BootWrIcCrmReg(CRM_NTL_RST_REG, BootRdIcCrmReg(CRM_NTL_RST_REG) & (~0xC00C0002));
#endif    
}


VOID BootRlsL2ssRst()
{
#ifdef BOOT_CRM_EN
	// bit1: NTLPPB
	BootWrIcCrmReg(CRM_NTL_RST_REG, BootRdIcCrmReg(CRM_NTL_RST_REG) | 0x2);
	// bit0: NTL(983 post logic)
	BootWrIcCrmReg(CRM_ROE_RST_REG, BootRdIcCrmReg(CRM_ROE_RST_REG) | 0x1);
#endif    
    
}

VOID BootRlsXMACRst()
{
#ifdef BOOT_CRM_EN
	BootWrIcCrmReg(CRM_NTL_RST_REG, BootRdIcCrmReg(CRM_NTL_RST_REG) | 0xC00C0000);
#endif 
}


VOID BootRlsPcsRst()
{
#ifdef BOOT_CRM_EN
	BootWrIcCrmReg(CRM_PCS_RST_REG, 1);
#endif 
}

/*bootrom下没有开启tora0的时钟，这个要注意*/
VOID BootEnL2ssClk()
{
#ifdef BOOT_CRM_EN
    BootWrIcCrmReg(CRM_NTL_COMMON_GATE_REG, BootRdIcCrmReg(CRM_NTL_COMMON_GATE_REG) | 0x3ff);
    BootWrIcCrmReg(CRM_NTL_TRI_GATE_REG, BootRdIcCrmReg(CRM_NTL_TRI_GATE_REG) | 0x1 );
    BootWrIcCrmReg(CRM_NTL_TROA1_GATE_REG, BootRdIcCrmReg(CRM_NTL_TROA1_GATE_REG) | 0x1 );

#endif 
}

UINT32 BootClrRstReason(UINT32 rstId)
{
#ifdef BOOT_CRM_EN
    return BootWrIcCrmReg(CRM_RESET_CLR_REG,1<<rstId);
#else
    return BSP_OK;
#endif
}

UINT32 BootGetRstReason(UINT32 rstId)
{
#ifdef BOOT_CRM_EN
    UINT32 rstVal = 0;
    rstVal = BootRdIcCrmReg(CRM_RESET_RECORD_REG) ;
    return ((rstVal >> rstId) & 0x01);
#else
    return 1;
#endif
}

/*是否是上电复位，bit16 =  1 上电复位，否则非上电复位*/
UINT32 BootGetSysPowerRst()
{

    if( 1 == BootGetRstReason(SYSTEM_POWER_RST) )
    {
        return BSP_OK;
    }
    else
    {
        return BSP_ERROR;
    }
}


UINT32 BootSetMiiClk()
{
    ///mdio clk = 2.5m
    return BootWrIcCrmReg(CRM_MII_CLK_FRAC, 0xff);
}
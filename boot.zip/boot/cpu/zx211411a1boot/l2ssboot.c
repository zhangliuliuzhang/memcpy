/*****************************************************************************
 * 版权所有(C) 2010, ZTE Corp. RRU Bsp Platform
 *----------------------------------------------------------------------------
 * 模 块 名 : BSP
 * 文件名称 : dpdichal.c
 * 文件标识 : {[N/A]}
 * 内容摘要 : 实现dpdic的加速器配置
 * 注意事项 : 无
 * 作    者 : 郭勇
 * 创建日期 : 2019-04-08 
 * 当前版本 : Ver1.0
 *----------------------------------------------------------------------------
 * 变更记录 :
 *
 * $记录1
 * 变 更 单: $0000000(N/A)
 * 责 任 人: 耿佳佳
 * 修改日戳: 2015-10-22 08:28:34
 * 变更说明: 创建文件
 *
 *----------------------------------------------------------------------------
 */


/* 标准库头文件 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h> 
#include "bsppub.h"
#include "bspcomm.h"
#include "l2ssboot.h"

T_NTLDrvParam gtBootNtlDrviParam = {0};

T_NtlPortCfg  g_atBootXmacPortCfg[] =
{
#ifdef _DPDIC3_ADS
    {e_XMAC_PORT_8, e_NTL_FRONT_BOARD,  e_XMAC_SPEED_1G},
#else
    {e_XMAC_PORT_10, e_NTL_FRONT_BOARD,  e_XMAC_SPEED_1G},/*PCS10-11端口是速率是5G以下，连接的GMII通道*/
    {e_XMAC_PORT_11, e_NTL_FRONT_BOARD,  e_XMAC_SPEED_1G},
#endif    

};


/* TRPG 端口组全局配置，20个外端口，5组TRPG */
T_TRPG_GROUP_MODE_CFG g_atBootTrxpModeCfg[MAX_TRPG_MODE_NUM] =
{
    {e_TRXP_PORT_1X,e_TRXP_PORT_1X,e_TRXP_PORT_1X,e_TRXP_PORT_1X},
    {e_TRXP_PORT_1X,e_TRXP_PORT_1X,e_TRXP_PORT_1X,e_TRXP_PORT_1X},
    {e_TRXP_PORT_1X,e_TRXP_PORT_1X,e_TRXP_PORT_1X,e_TRXP_PORT_1X},
    {e_TRXP_PORT_1X,e_TRXP_PORT_1X,e_TRXP_PORT_1X,e_TRXP_PORT_1X},
    {e_TRXP_PORT_1X,e_TRXP_PORT_1X,e_TRXP_PORT_1X,e_TRXP_PORT_1X},
};


/**************************************************************************
函数名称:  NaccXmacConfigInit(*)
功能描述:  单板下BTTL XMAC 参数初始化
输入参数:  无
输出参数:  无
返 回 值:  BSP_OK /  RETURN_ERROR
其它说明：
修改日期      版本号      修改人          修改内容
-----------------------------------------------------------------------
2013-12-9      V1.0                     创建
**************************************************************************/
UINT32 BootXmacConfigInit(T_XmacParamStruct *pXmacDrvParamArry)
{
    UINT8 macAddr[6] ={0x40,0x00,0xc0,0xfe,0x01,0x5}; /*暂时先写死*/
    UINT32 idx = 0;
    UINT32 macMaxNum = 0;
    UINT32 macId = 0;
    T_XmacDrvParam *pXmacDrvParam = NULL;
    
    INPUT_POINTER_CHECK(pXmacDrvParamArry);
#if 0
    BspGetCtrlNetMac(aucMacAddr);
    for(idx = 0; idx < 6; idx++)
    {
        aucMacAddr[idx] = aucMacAddrTemp[5-idx];
    }
#endif
    macMaxNum = sizeof(g_atBootXmacPortCfg)/sizeof(g_atBootXmacPortCfg[0]);

    for(idx=0; idx<macMaxNum; idx++)
    {
        if(!isXmacPortHwValid(idx))
        {
            continue;
        }
        macId = g_atBootXmacPortCfg[idx].udPortId;
        pXmacDrvParam = &(pXmacDrvParamArry->atXmacDrvParam[macId]);
        pXmacDrvParam->bEnable = 1;
        pXmacDrvParam->bReplaceSrcMac = 0;
        pXmacDrvParam->bTxAddPadEn = 1;
        pXmacDrvParam->eMacId = macId;
        pXmacDrvParam->ePortSpeed = g_atBootXmacPortCfg[idx].eSpeed;
        pXmacDrvParam->udMruVlaue = NTL_XMAC_MRU;
        pXmacDrvParam->udMtuVlaue = NTL_XMAC_TX_MAX_LEN;
        pXmacDrvParam->b1588RcvCtl = 0; /*暂时先关闭1588的功能*/
        pXmacDrvParam->b1588TxCtl = 0;  /*暂时先关闭1588的功能*/

        switch(pXmacDrvParam->ePortSpeed)
        {
            case e_XMAC_SPEED_10G:
            {
                pXmacDrvParam->udPcsRcvPathDelay = NTL_PATH_DELAY_10GE_RX_NO_FEC;
                pXmacDrvParam->udPcsTxPathDelay =  NTL_PATH_DELAY_10GE_TX_NO_FEC;
                break;
            }
            case e_XMAC_SPEED_2_5G:
            {
                pXmacDrvParam->udPcsRcvPathDelay = NTL_PATH_DELAY_2_5G_RX;
                pXmacDrvParam->udPcsTxPathDelay =  NTL_PATH_DELAY_2_5G_TX;
                break;
            }
            case e_XMAC_SPEED_1G:
            {
                pXmacDrvParam->udPcsRcvPathDelay = NTL_PATH_DELAY_1000M_RX;
                pXmacDrvParam->udPcsTxPathDelay =  NTL_PATH_DELAY_1000M_TX;
                break;
            }
            case e_XMAC_SPEED_100M:
            {
                pXmacDrvParam->udPcsRcvPathDelay = NTL_PATH_DELAY_100M_RX;
                pXmacDrvParam->udPcsTxPathDelay =  NTL_PATH_DELAY_100M_TX;
                break;
            }
            case e_XMAC_SPEED_10M:
            {
                pXmacDrvParam->udPcsRcvPathDelay = NTL_PATH_DELAY_10M_RX;
                pXmacDrvParam->udPcsTxPathDelay =  NTL_PATH_DELAY_10M_TX;
                break;
            }
            default:
            {
                pXmacDrvParam->udPcsRcvPathDelay = NTL_PATH_DELAY_10GE_RX_NO_FEC;
                pXmacDrvParam->udPcsTxPathDelay =  NTL_PATH_DELAY_10GE_RX_NO_FEC;
            }
        }

        memcpy(pXmacDrvParam->aucMacAddr,macAddr,6);
    }

    return BSP_OK;
}




/**********************************************************************
* 函数名称： L2ssConfigInit
* 功能描述：
* 输入参数：
* 输出参数：
* 返 回 值：
* 其他说明：
* 修改日期        版本号     修改人           修改内容
* ----------------------------------------------------------------------
************************************************************************/
UINT32 BootL2ssConfigInit(T_L2ssDrvParam *ptL2ssDrvParam)
{
    INPUT_POINTER_CHECK(ptL2ssDrvParam);

    ptL2ssDrvParam->bIsStart = 1;

    /*L2SS的parse相关配置*/
    ptL2ssDrvParam->tParseBaseDrvParam.udParseEngId = e_L2SS_ENG0;  //ads阶段parse引擎的设置都是进入ENG0
    ptL2ssDrvParam->tParseBaseDrvParam.udAnalyLevel = 5;
    ptL2ssDrvParam->tParseBaseDrvParam.udGp0Thrd = 0x500;  /*需要确认配置*/
    ptL2ssDrvParam->tParseBaseDrvParam.udParseCpuEthType = 0xaa53;
    ptL2ssDrvParam->udPktmCpuEthType = 0xaa54;
    ptL2ssDrvParam->udTrxpPauseEn = BW3;
    ptL2ssDrvParam->uddPortEnableBitmap = (UINT64)L2SS_VALID_PORT_MAP;

    /* trxp端口模式配置表 */
    ptL2ssDrvParam->ptL2ssTrpgModeParam = (T_TRPG_GROUP_MODE_CFG *)&g_atBootTrxpModeCfg;


    /*L2SS的qman流控和门限的相关配置*/
    ptL2ssDrvParam->tFlowBaseDrvParam.udQmanOcMacTime = L2SS_OC_MAC_TIME;
    ptL2ssDrvParam->tFlowBaseDrvParam.udQmanLpMacTime = L2SS_LP_MAC_TIME;
    ptL2ssDrvParam->tFlowBaseDrvParam.udQmanShareThrd = 4096;
    ptL2ssDrvParam->tFlowBaseDrvParam.udQmanMinLimit = 0x1f;
    ptL2ssDrvParam->tFlowBaseDrvParam.udQmanThrdEn = L2SS_QMAN_DLP_QE_THRD_EN;
    ptL2ssDrvParam->tFlowBaseDrvParam.udQmanKLevel = 3;
    ptL2ssDrvParam->tFlowBaseDrvParam.eSpeedType   = e_L2ssSpeed_50G;

    /*分流配置,ads调试阶段分流配置为默认关闭，正式版本使用时打开分流配置*/
   // ptL2ssDrvParam->tL2ssPktShuntDrvParam.bIsStart = 1;
#if 0
    ptL2ssDrvParam->tL2ssPktShuntDrvParam.bIsStart = FALSE;           //TRUE;
    ptL2ssDrvParam->tL2ssPktShuntDrvParam.udPktShuntType = e_NTL_SHUNT_IP;
    ptL2ssDrvParam->tL2ssPktShuntDrvParam.uddBroadPortMap = 0x00000ffe003f0000;   //广播端口
    ptL2ssDrvParam->tL2ssPktShuntDrvParam.uddPktmOutputPortMap = 0x00000ffe003f0000;   //PKTM输出端口
    ptL2ssDrvParam->tL2ssPktShuntDrvParam.udMapMode = 0;      //初始化时映射模式使能是0
    ptL2ssDrvParam->tL2ssPktShuntDrvParam.udMapPri = 0;       //端口映射的优先级为0
    ptL2ssDrvParam->tL2ssPktShuntDrvParam.udVtagSlpMap = 0;   /*使用本表中的OVID字段作为映射结果*/
#endif
  //  BspGetCtrlNetMac(ptL2ssDrvParam->tL2ssPktShuntDrvParam.aucMac);


   /* trxp端口打开配置，ads阶段的端口的打开配置用全局变量控制*/
    ptL2ssDrvParam->uddPortEnableBitmap = 0x0;
   /* l2ss配置使能 */
    ptL2ssDrvParam->bIsStart = TRUE;
	
	return BSP_OK;
   // NtlL2ssInit(&tL2ssDrvParam);
}


/**************************************************************************
函数名称:  NtlCfgParaInit
功能描述:  Ntl各个子系统模块参数的初始化
输入参数:
输出参数:  无
返 回 值:  BSP_OK /  RETURN_ERROR
其它说明：

修改日期      版本号      修改人          修改内容
-----------------------------------------------------------------------
**************************************************************************/
UINT32 BootNtlCfgParaInit(T_NTLDrvParam *ptNtlDrviParam)
{
    UINT32 ret = 0;

    INPUT_POINTER_CHECK(ptNtlDrviParam);

    ret = BootXmacConfigInit(&(ptNtlDrviParam->xmacDrvParam));
    if(BSP_OK != ret)
    {
        dbgErr("NaccXmacConfigInit failed! \n");
        return BSP_ERROR;
    }

    ret = BootL2ssConfigInit(&(ptNtlDrviParam->l2ssDrvParam));
    if(BSP_OK != ret)
    {
        dbgErr("L2ssConfigInit failed! \n");
        return BSP_ERROR;
    }

    /*单板传进来的其他参数，比如mac，等可以放到下面继续初始化*/

    return BSP_OK;

}

/**************************************************************************
函数名称:  NtlL2ssRegMap
功能描述:  NTL寄存器空间映射
输入参数:  ptNtlDrvParam 参见T_NTLDrvParam
输出参数:  无
返 回 值:  BSP_OK /  RETURN_ERROR
其它说明：
修改日期      版本号      修改人          修改内容
-----------------------------------------------------------------------
2017-11-22      V1.0     shejingui          创建
**************************************************************************/
UINT32 BootL2ssRegMap(T_NTLDrvParam *ptNtlDrvParam,UINT32 phyL2ssAddr,UINT32 phyl2ssAddrSize)
{
    UINT32   virAddr = 0;
    UINT32   ulSpaceProt = PROT_READ | PROT_WRITE;
    INT32 ifile = -1;
#if 1
    if ((ifile = open("/dev/mem", O_RDWR | O_SYNC)) < 0)
    {
        dbgErr("open /dev/mem failed\n");
        return BSP_ERROR;
    }

    virAddr = mmap((VOID *)NULL, phyl2ssAddrSize, ulSpaceProt, MAP_SHARED, ifile, phyL2ssAddr);
    if(0 == virAddr)
    {
        dbgErr("%s mmap error\n",__FUNCTION__);
        return BSP_ERROR;
    }
    dbgInfo("%s mmap ok,viraddr[0x%08x]\n",__FUNCTION__,virAddr);
    close(ifile);
#endif
    //DpdIcHalGetAddrPhyToVir(0,phyL2ssAddr,&virAddr);
    dbgInfo("%s mmap ok,viraddr[0x%08x]\n",__FUNCTION__,virAddr);
    
    ptNtlDrvParam->l2ssDrvParam.regVirAddr = virAddr;
    ptNtlDrvParam->xmacDrvParam.regVirAddr = virAddr;
    ptNtlDrvParam->tPtpDrvParam.regVirAddr = virAddr;

    printf("%s:l2ss reg baseaddr = 0x%08x\n",__FUNCTION__,virAddr);

    return BSP_OK;
}

UINT32 BootInitL2ss(T_L2ssDrvParam *pl2ssDrvParam)
{
    INPUT_POINTER_CHECK(pl2ssDrvParam);

    NtlL2ssCfgBaseAddr(pl2ssDrvParam->regVirAddr);
    if(BSP_OK !=  NtlL2ssInit(pl2ssDrvParam))
    {
        dbgErr("%s failed\n",__FUNCTION__);
        return BSP_ERROR;
    }

   /*设置本地Debug ETH的初始化 */
   if(BSP_OK !=  NtlL2ssSetDebugEthIpVlan(L2SS_DEBUG_ETH_IP_VLAN))
   {
       dbgErr("%s failed\n",__FUNCTION__);
       return BSP_ERROR;
   }

    dbgInfo("%s init succ\n",__FUNCTION__);
    return BSP_OK;
}

UINT32 BootInitXmac(T_XmacParamStruct *pXmacDrvParam)
{
    UINT32 ret = -1;
    UINT32 idx = 0;

    INPUT_POINTER_CHECK(pXmacDrvParam);

    NtlXMacCfgBaseAddr(pXmacDrvParam->regVirAddr);
    for(idx = 0;idx < NACC_XMAC_NUM;idx ++)
    {
        if(!isXmacPortHwValid(idx))
        {
            continue;
        }

        if(pXmacDrvParam->atXmacDrvParam[idx].bEnable)
        {
            ret = NaccXmacInit(&(pXmacDrvParam->atXmacDrvParam[idx]));
            if(BSP_OK != ret)
            {
                dbgErr("%s NaccXmacInit %d failed\n",__FUNCTION__,idx);
                return BSP_ERROR;
            }
        }
    }

    dbgInfo("%s init succ!\n",__FUNCTION__);
    return BSP_OK;
}


UINT32 BootSetEth0DebugIpMacAddr()
{
	UINT8  mac[6]={0x40,0x00,0xC7,0x21,0x21,0x05};
	UINT8  ip[4]={199,33,33,33};
	UINT8  mask[4]={0xff,0xff,0xff,0};
	UINT8  netif[8] = "eth0";
    
	char cmd[128] = {0};
     
	zte_snprintf_s(cmd,sizeof(cmd), "ifconfig %s down", netif);
	printf("%s\n",cmd);
	BspSystem(cmd);

	zte_snprintf_s(cmd, sizeof(cmd),"ifconfig %s hw ether %02X:%02X:%02X:%02X:%02X:%02X", netif,
		mac[0],mac[1],mac[2],mac[3],mac[4],mac[5]);
	printf("%s\n",cmd);
	BspSystem(cmd);

	zte_snprintf_s(cmd,sizeof(cmd),"ifconfig %s %d.%d.%d.%d netmask %d.%d.%d.%d",netif, ip[0],ip[1],ip[2],ip[3],
				mask[0],mask[1],mask[2],mask[3]);
	printf("%s\n",cmd);
	BspSystem(cmd);

	return BSP_OK;
}
UINT32 BootSetslavechipIpMacAddr()
{
	UINT8  mac[6]={0x40,0x00,0xC6,0x21,0x21,0x05};
	UINT8  ip[4]={198,33,33,2};
	UINT8  mask[4]={0xff,0xff,0xff,0};
	UINT8  netif[8] = "eth0";
    
	char cmd[128] = {0};
       #define DPDIC_CHIP_ID     0x228
       UINT32 uchipid = 0;

       uchipid = BootRdIcPadReg(DPDIC_CHIP_ID);
       uchipid = (uchipid & 0xf) >> 0x1;
       mac[5]=uchipid+2;
       ip[3]=uchipid+2;
       
	zte_snprintf_s(cmd,sizeof(cmd), "ifconfig %s down", netif);
	printf("%s\n",cmd);
	BspSystem(cmd);

	zte_snprintf_s(cmd,sizeof(cmd),"ifconfig %s hw ether %02X:%02X:%02X:%02X:%02X:%02X", netif,
		mac[0],mac[1],mac[2],mac[3],mac[4],mac[5]);
	printf("%s\n",cmd);
	BspSystem(cmd);

	zte_snprintf_s(cmd,sizeof(cmd),"ifconfig %s %d.%d.%d.%d netmask %d.%d.%d.%d",netif, ip[0],ip[1],ip[2],ip[3],
				mask[0],mask[1],mask[2],mask[3]);
	printf("%s\n",cmd);
	BspSystem(cmd);

	return BSP_OK;
}


/*调用后，dirve the kernel to implement open function*/
UINT32 BootSetEth0Up()
{
	UINT8  netif[8] = "eth0";
	char cmd[128] = {0};
	sprintf(cmd, "ifconfig %s up", netif);
	printf("%s\n",cmd);
	system(cmd);
	return BSP_OK;
}

UINT32 BootSetEth0Down()
{
	UINT8  netif[8] = "eth0";
	char cmd[128] = {0};
	sprintf(cmd, "ifconfig %s down", netif);
	printf("%s\n",cmd);
	system(cmd);
	return BSP_OK;


	return BSP_OK;
}

UINT32 BootNtlSoftResetInit(void)
{
	printf("BootNtlSoftResetInit:Start!\n");
    /* 清零NTL单板层句柄 */
    memset((UINT8 *)&gtBootNtlDrviParam, 0x00, sizeof(T_NTLDrvParam));

    if(BSP_OK != BootL2ssRegMap((T_NTLDrvParam *)(&gtBootNtlDrviParam),0x91000000,1024*1024*70)) /*大小70M*/
    {
        dbgErr("%s error\n",__FUNCTION__);
        return BSP_ERROR;
    }
	
	dbgInfo("gtBootNtlDrviParam->l2ssDrvParam.regVirAddr = 0x%08x\n",gtBootNtlDrviParam.l2ssDrvParam.regVirAddr);
	NtlL2ssCfgBaseAddr(gtBootNtlDrviParam.l2ssDrvParam.regVirAddr);
	NtlXMacCfgBaseAddr(gtBootNtlDrviParam.xmacDrvParam.regVirAddr);
	
	NtlL2ssTrxpDisable(44);
	NtlL2ssTrxpDisable(45);
	
	L2ssCpuAgentEnable(L2SS_XC12_AGAENT_LP,0);
	L2ssCpuAgentEnable(L2SS_R8_AGAENT_LP,0);
	
	L2ssCpuAgentEnable(L2SS_XC12_AGAENT_LP,1);
	L2ssCpuAgentEnable(L2SS_R8_AGAENT_LP,1);

	return BSP_OK;
	
}

/**************************************************************************
函数名称:  BspNtlInit(*)
功能描述:  单板下NTL全部初始化
输入参数:  无
输出参数:  无
返 回 值:  BSP_OK /  RETURN_ERROR
其它说明：

修改日期      版本号      修改人          修改内容
-----------------------------------------------------------------------
2012-9-19      V1.0        CAIKY             创建
**************************************************************************/
UINT32 BootNtlInit(void)
{
	#define DPDIC_CHIP_ID     0x228

    printf("BspNtlL2ssInit:Start!\n");
    /* 清零NTL单板层句柄 */
	
    memset((UINT8 *)&gtBootNtlDrviParam, 0x00, sizeof(T_NTLDrvParam));

    if(BSP_OK != BootL2ssRegMap((T_NTLDrvParam *)(&gtBootNtlDrviParam),0x91000000,1024*1024*70)) /*大小70M*/
    {
        dbgErr("%s error\n",__FUNCTION__);
        return BSP_ERROR;
    }

    dbgInfo("gtNtlDrviParam->tPtpDrvParam.regVirAddr = 0x%08x\n",gtBootNtlDrviParam.tPtpDrvParam.regVirAddr);
	
    if(BSP_OK != BootNtlCfgParaInit((T_NTLDrvParam *)&gtBootNtlDrviParam)) /*大小70M*/
    {
        dbgErr("%s BootNtlCfgParaInit error\n",__FUNCTION__);
        return BSP_ERROR;
    }

    if(BSP_OK != BootInitL2ss(&(gtBootNtlDrviParam.l2ssDrvParam)))
    {
        dbgErr("%s BspInitL2ss failed\n",__FUNCTION__);
        return BSP_ERROR;
    }

    /*push kernel to implement cpu agent 46 init*/
//    BootSetEth0Up();

    /* debug ip/mac 初始化 199网段 */
    if(1 == (_BspZteGpioGet(21)) )
    {
    		if(((BootRdIcPadReg(DPDIC_CHIP_ID) & 0xf) >> 0x1) ==0 )
    			BootSetEth0DebugIpMacAddr();
		else
			BootSetslavechipIpMacAddr();/*9228��Ƭ��֧*/
	}
	else
    		BootSetslavechipIpMacAddr();
    

    if(BSP_OK != BootInitXmac(&(gtBootNtlDrviParam.xmacDrvParam)))
    {
        dbgErr("%s BspInitXmac failed\n",__FUNCTION__);
        return BSP_ERROR;
    }

    /*关闭所有XMAC，高层打开，或者手动打开*/
    NtlL2ssDisEnAllXmac();

    /*水位控制开启*/
    NtlL2ssTrxpEnable(46);
    NtlL2ssTrxpEnable(10);
    NtlL2ssTrxpEnable(11);
    
    NtlXmacEnable(10);
    NtlXmacEnable(11);


    if(1 == (_BspZteGpioGet(21)) )
    {
        dbgInfo("%s MASTER chip,port 11 down to 100M\n",__FUNCTION__);
        NtlXmacCfgPortSpeed(11,1);
    }
    dbgInfo("BootNtlInit:Done!\n");
    return BSP_OK;

}







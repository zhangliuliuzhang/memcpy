/* SPDX-License-Identifier: GPL-2.0+ */
/*
 * Copyright 2015 Freescale Semiconductor, Inc.
 */

#ifndef _ZTE_VALIDATE_H_
#define _ZTE_VALIDATE_H_

#include <linux/types.h>

typedef unsigned int uint32_t;
typedef unsigned long long uint64_t;
typedef unsigned int u32;
typedef unsigned char uint8_t;
typedef unsigned int uintptr_t;
typedef unsigned char uchar;

/* Minimum and maximum size of RSA signature length in bits */
#define RSA_4K_KEY_SZ   4096
#define RSA_4K_KEY_SZ_BYTES   (RSA_4K_KEY_SZ/8)
#define RSA_2K_KEY_SZ   2048
#define RSA_2K_KEY_SZ_BYTES   (RSA_2K_KEY_SZ/8)
#define RSA_1K_KEY_SZ   1024
#define RSA_1K_KEY_SZ_BYTES   (RSA_1K_KEY_SZ/8)
#define RSA_3K_KEY_SZ   3072
#define RSA_3K_KEY_SZ_BYTES  (RSA_3K_KEY_SZ/8)

#define MAX_SIGN_DATA_LEN  RSA_4K_KEY_SZ_BYTES

#define SHA256_BITS	256
#define SHA256_BYTES	(256/8)

/**
algorithm:
0 :    use to verity BOOT
1 :    use to veriry cur.swv
*/
#define CSF_CPUKEY_NUM      1
#define CSF_BOOTKEY_NUM     0
//#define FOR_TEST_SECURE 1
//#define ZTE_VALIDATE_DEBUG

extern struct jobring jr;

/* Barker code size in bytes */
#define CSF_BARKER_LEN	4	/* barker code length in ESBC uboot client */

#define CONFIG_EFUSE_FLASH_ADDR  (0x8000000-0x1000)
#define CONFIG_EFUSE_SIZE   0x1000

#define ZTE_SHA256  0x0203
#define ZTE_SHA1  0x0201
#define ZTE_SHA224  0x0202
#define ZTE_SHA384  0x0204
#define ZTE_SHA512  0x0205
#define ENCRYPTION_RSA2048 0x0102
#define ENCRYPTION_RSA3072 0x0103
#define ENCRYPTION_RSA1024 0x0101

#define CSF_PKEY_MAX_SIZE       768
#define CSF_SIGN_MAX_SIZE		384
#define MAX_SIGN_STRING_LEN 688

typedef struct efuse_flash{
	unsigned int sec_en; /*4BYTE*/
	unsigned int nv_en; /*4BYTE*/
	unsigned int nv_value;/*4BYTE*/
	unsigned int reserve;/*4BYTE*/
	unsigned char pkey_hash[SHA256_BYTES];/*32BYTE*/
}T_EFUSE_FLASH;

typedef struct csf_algrithm{
	unsigned short hash_alg;
	unsigned short sig_alg;
	unsigned short rsv_alg_0;
	unsigned short img_hash_alg;
}T_CSF_ALGRITHM;

typedef struct csf_id{
	uint32_t name;
	unsigned short type;
	unsigned short layer;
}T_CSF_ID;

typedef struct csf_version{
	T_CSF_ID id;
	uint32_t size;
	uint32_t ver;
}T_CSF_VERSION;

typedef struct{
	uint32_t nv_rsv[10];
	uint32_t nv_num;
}T_CSF_NV;

typedef struct{
	uint8_t start[8];
	uint8_t end[8];
}T_CSF_VALIDITY;

typedef struct csf_attri{
	T_CSF_ID		csf_sig_id; 		/*8B*/
	T_CSF_VALIDITY	csf_validity;		/*16B*/
	T_CSF_ID		csf_vry_id; 		/*8B*/
}T_CSF_ATTRI;

typedef struct csf_pkey{
	T_CSF_ID id;
	T_CSF_VALIDITY validity;
	uint32_t version;
	uint32_t state;
	uint8_t value[CSF_PKEY_MAX_SIZE]; /*value_n[384] + value_e[384]*/
}T_CSF_PKEY;

typedef struct{
	uint32_t entry_high;
	uint32_t entry_low;
	uint32_t offset_high;
	uint32_t offset_low;
	uint32_t size;
	uint8_t hash[SHA256_BYTES*2];
}T_CSF_IMAGE;

typedef struct csf_hdr {
	T_CSF_VERSION 	csf_version; 		/*16B*/
	T_CSF_NV		csf_nv; 			/*44B*/
	T_CSF_ALGRITHM 	csf_algorithm[2]; 		/*16B, 8B for rootverify, 8B for cpuverify*/
	T_CSF_ATTRI		csf_attri;
	T_CSF_PKEY      csf_pkey_this_key; 	/*800B*/
	T_CSF_PKEY      csf_pkey_next_key; 	/*800B*/
	T_CSF_IMAGE     csf_image;         	/*84B*/
	uint8_t   		csf_fingerprint[CSF_SIGN_MAX_SIZE]; /*384B*/
}T_CSF_HDR;

/*
 * Calculate hash of input data
 */
int calc_data_hash(char *pdata, uint32_t pdata_ken, char *calc_hash, int pub_select);
/*
 * This function is used to signature verify.
 */
int rsa_auth_signature(char *phash, char* pkey, u32 pkey_len, char *psign, u32 psign_len);

/*
 * This function is used to validate the main esbc version
 */
int zte_secure_validate(uintptr_t csf_haddr);
/*
 * Authenticate by Non-Volatile counter
 *
 * To protect the system against rollback, the platform includes a non-volatile
 * counter whose value can only be increased. All certificates include a counter
 * value that should not be lower than the value stored in the platform. If the
 * value is larger, the counter in the platform must be updated to the new
 * value.
 *
 * Return: 0 = success, Otherwise = error
 */
int zte_auth_nvctr(uint32_t ui_counter);
/*
* get sign data from jSon file in protect flash
*/
u32 BspGetVersionSign(uchar *ucBuf, u32 ulFileLen, u32 ulFileCrc, uchar* ucSign, u32 *uiSign_len);

unsigned int BspGetSafeBootCheckSwitch(unsigned int *pRdval);
unsigned int BspGetNvModeSwitch(unsigned int *pRdVal);
unsigned int BspUserNvValRead(unsigned int *pRdVal);

#endif

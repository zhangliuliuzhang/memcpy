/*****************************************************************************
 * 版权所有(C) 2010, ZTE Corp. RRU Bsp Platform
 *----------------------------------------------------------------------------
 * 模 块 名 : BSP
 * 文件名称 : halboot.c
 * 文件标识 : {[N/A]}
 * 内容摘要 : bootapp hal接口实现
 * 注意事项 : 无
 * 作    者 : 耿佳佳
 * 创建日期 : 2015-10-22 08:28:34
 * 当前版本 : Ver1.0
 *----------------------------------------------------------------------------
 * 变更记录 :
 *
 * $记录1
 * 变 更 单: $0000000(N/A)
 * 责 任 人: 耿佳佳
 * 修改日戳: 2015-10-22 08:28:34
 * 变更说明: 创建文件
 *
 *----------------------------------------------------------------------------
 */


/* 标准库头文件 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h> 
#include "bsppub.h"
#include "halboot.h"
/**************************************************************************
 *                        宏
 **************************************************************************/

/**************************************************************************
 *                         数据类型                                       *
 **************************************************************************/


/**************************************************************************
 *                         全局变量定义                                   *
 **************************************************************************/
 /*lint -e641*/

 T_HAL_ADDRMAP_MEMBLK g_hal_asram_memblk_def[MAX_MEM_BLK]=
{
  /* NOTICE : 前一条定义起始地址+长度，不能和后一条定义的起始地址有任何重叠，否则用物理地址反差会出错  */
    
  //ARM can't access ceva's ICP/ICU 
  //{MEM_BLK_STATUS_DEFINE,MEM_BLK_CEVA_ICP,    0x00000000,0x00000008,0},  
  //a9仅仅需要看到ceva的ddr空间，因为消息交互需要访问。自己的ddr空间不需要显示访问
  {MEM_BLK_STATUS_DEFINE,MEM_BLK_DDR3,        0x00000000,0x0200000,0},//
    
   //ARM don't need access ceva's L1D/L1P,just occupy the pos    
  {MEM_BLK_STATUS_DEFINE,MEM_BLK_CEVA_L1D,    0x84000000,0x00080000,0},
  {MEM_BLK_STATUS_DEFINE,MEM_BLK_CEVA_L1P,    0x84200000,0x00040000,0},
   //ARM can't access salve chip ceva's mcci,just use in master chip  
  {MEM_BLK_STATUS_DEFINE,MEM_BLK_CEVA_MCCI,   0xC0400000,0x00000080,0},//mcci reg used for interrupt notice from arm to ceva
  
  
  {MEM_BLK_STATUS_DEFINE,MEM_BLK_CEVA_L2PSRAM,0x85000000,0x00060000,0},


  {MEM_BLK_STATUS_DEFINE,MEM_BLK_CEVA_SCR,    0xC3242000,0x00002000,0},//

  {MEM_BLK_STATUS_DEFINE,MEM_BLK_TIMER,       0x87000000,0x00001000,0},
  {MEM_BLK_STATUS_DEFINE,MEM_BLK_PDMA,        0x87200000,0x00001000,0},


  {MEM_BLK_STATUS_DEFINE,MEM_BLK_DIF_CFG,     0xC8000000,0x00040000,0},
  {MEM_BLK_STATUS_DEFINE,MEM_BLK_J204B_SERDES,0x88600000,0x00002000,0},
  {MEM_BLK_STATUS_DEFINE,MEM_BLK_OPT_SERDES,  0xC0504000,0x00002000,0},
    
  {MEM_BLK_STATUS_DEFINE,MEM_BLK_ASRAM,       0xC4000000,0x04000000,0},//

  {MEM_BLK_STATUS_DEFINE,MEM_BLK_DIF_CB,      0x88200000,0x00080000,0},
  {MEM_BLK_STATUS_DEFINE,MEM_BLK_DIF_DPD,     0x88400000,0x00080000,0},
  {MEM_BLK_STATUS_DEFINE,MEM_BLK_DIF_CFR,     0x88700000,0x00080000,0},
  {MEM_BLK_STATUS_DEFINE,MEM_BLK_DIF_DL,      0x88B00000,0x00800000,0},

  {MEM_BLK_STATUS_DEFINE,MEM_BLK_USB   ,      0xC0100000,0x00006000,0},
    
  {MEM_BLK_STATUS_DEFINE,MEM_BLK_SPINLOCK,    0xC0100000,0x00200000,0},//

  {MEM_BLK_STATUS_DEFINE,MEM_BLK_ARM_ICP,    0xC0700000,0x00080000,0},
  {MEM_BLK_STATUS_DEFINE,MEM_BLK_PDR,         0xF9440000,0x00004000,0},//
  {MEM_BLK_STATUS_DEFINE,MEM_BLK_PDR_WP,      0xF9480000,0x00004000,0},//

  {MEM_BLK_STATUS_DEFINE,MEM_BLK_GMAC0,      0xC1400000,0x00002000,0},
  {MEM_BLK_STATUS_DEFINE,MEM_BLK_GMAC1,      0xC1402000,0x00002000,0},
    
  {MEM_BLK_STATUS_DEFINE,MEM_BLK_UART0,      0xC5800000,0x00001000,0},
  {MEM_BLK_STATUS_DEFINE,MEM_BLK_UART1,      0xC5801000,0x00001000,0},
  {MEM_BLK_STATUS_DEFINE,MEM_BLK_UART2,      0xC5802000,0x00001000,0},
  {MEM_BLK_STATUS_DEFINE,MEM_BLK_SPI0,       0xC5C00000,0x00001000,0},
  {MEM_BLK_STATUS_DEFINE,MEM_BLK_I2C0,       0xC5900000,0x00001000,0},
  {MEM_BLK_STATUS_DEFINE,MEM_BLK_I2C1,       0xC5901000,0x00001000,0},

  {MEM_BLK_STATUS_DEFINE,MEM_BLK_GPIO,       0xC5A00000,0x00002000,0},
  {MEM_BLK_STATUS_DEFINE,MEM_BLK_APB_SC,     0xF952C000,0x00001000,0},//
  {MEM_BLK_STATUS_DEFINE,MEM_BLK_UDMA,       0xF952D000,0x00001000,0},
  {MEM_BLK_STATUS_DEFINE,MEM_BLK_I2C3,       0xC5903000,0x00001000,0},
  {MEM_BLK_STATUS_DEFINE,MEM_BLK_CRS,        0xBC881000,0x00001000,0},//0x临时定的WD Timer
    
  {MEM_BLK_STATUS_DEFINE,MEM_BLK_UART3,      0xC5803000,0x00001000,0},
  {MEM_BLK_STATUS_DEFINE,MEM_BLK_SPI1,       0xC5C01000,0x00001000,0},
  {MEM_BLK_STATUS_DEFINE,MEM_BLK_SPI2,       0xC5C02000,0x00001000,0},
  {MEM_BLK_STATUS_DEFINE,MEM_BLK_I2C2,       0xC5902000,0x00001000,0},
  {MEM_BLK_STATUS_DEFINE,MEM_BLK_ARM_GIC,    0xBC800000,0x00040000,0},
  {MEM_BLK_STATUS_DEFINE,MEM_BLK_WDT,    0xBC881000,0x00001000,0},

  
};

/*lint -e34*/
/*lint -e35*/
/*lint -e516*/
UINT32 g_hal_asram_memblk_num = NELEMENTS(g_hal_asram_memblk_def);
//map chan starts from 0=MAP 1=XX .....
UINT32 g_hal_asram_chan_offset[MAX_MEM_BLK_MAP]={
   /* 0, 0x1000,*/0x2000,0x3000,0x4000,0x5000,
    0x6000,0x8000,0x10000,0x20000,0x30000,
    0x40000,0x60000,0x80000,0xc0000,0x100000,
    0x140000,0x180000,0x200000};
/* map chan index starts from 0( 0=MAP 1=XX .....17,total 18)
   but,映射数组个数是17，定义的chan跳过0(配置通道)，均为实际使用的chan */
T_HAL_ADDRMAP_MEMMAP g_hal_asram_memblk_map[MAX_MEM_BLK_MAP]=
{  
  {MEM_BLK_STATUS_DEFINE,MEM_BLK_CRS,              1,0x1000,0},   
  //{MEM_BLK_STATUS_DEFINE,MEM_BLK_Rsv,           2,0x1000,0}, 
  {MEM_BLK_STATUS_DEFINE,MEM_BLK_CEVA_SCR,         3,0x1000,0}, 
  /* sc for test only(0x54 gpio_en only in Chip0,only debug need wr chip1)  */
  {MEM_BLK_STATUS_DEFINE,MEM_BLK_APB_SC,           4,0x1000,0},
  /* gpio for test only  
  {MEM_BLK_STATUS_DEFINE,MEM_BLK_GPIO,             5,0x2000,0},*/
  {MEM_BLK_STATUS_DEFINE,MEM_BLK_OPT_SERDES,       6,0x8000,0},
  {MEM_BLK_STATUS_DEFINE,MEM_BLK_J204B_SERDES,     7,0x10000,0},
  {MEM_BLK_STATUS_DEFINE,MEM_BLK_DIF_CB,           8,0x10000,0},
  {MEM_BLK_STATUS_DEFINE,MEM_BLK_DIF_CFR,          9,0x10000,0},
  {MEM_BLK_STATUS_DEFINE,MEM_BLK_SPINLOCK,        10,0x20000,0},
    
  {MEM_BLK_STATUS_DEFINE,MEM_BLK_CEVA_L2PSRAM,    11,0x20000,0},
  {MEM_BLK_STATUS_DEFINE,MEM_BLK_DIF_DL,          12,0x40000,0},
  {MEM_BLK_STATUS_DEFINE,MEM_BLK_DIF_CFG,         13,0x40000,0}, 

  {MEM_BLK_STATUS_DEFINE,MEM_BLK_PDR,             14,0x40000,0},
 // {MEM_BLK_STATUS_DEFINE,MEM_BLK_PDR_WP,          15,0x40000,0},
  {MEM_BLK_STATUS_DEFINE,MEM_BLK_DIF_DPD,         16,0x80000,0}, 
  {MEM_BLK_STATUS_DEFINE,MEM_BLK_DDR3,            17,0x200000,0},
  
};
UINT32 g_hal_asram_memmap_num = NELEMENTS(g_hal_asram_memblk_map);
/*lint +e34*/
/*lint +e35*/
/*lint +e516*/
volatile ULONG g_ASRAMCTRL_SC_NUM ;  /* 实际使用的IC从片个数，总的IC数量比这个大1 */
/**************************************************************************
 *                         外部变量声明
 **************************************************************************/

/**************************************************************************
*                         局部函数声明
**************************************************************************/

/**************************************************************************
*                         全局函数声明
**************************************************************************/


/**************************************************************************
 *                         函数实现
 **************************************************************************/

                               
     


/*-------------------------------------------------------------------------------------------------------------------- 
 *                                                       函数定义
 *------------------------------------------------------------------------------------------------------------------ */ 
 /*****************************************************************************
*  函数名称   : HAL_SetSlaveChipNum
*  功能描述   : 配置从片IC的数量(不包含主片)
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : ulSlaveChipNum      - 从片IC的数量
*  输出参数   : 无
*  返 回 值   : HAL_OK
*  其它说明   : 由上层调用，在使用、访问IC之前必须设置完成
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)*
* $0000000(N/A), 王飞@2014-9-2 14:55:24
*----------------------------------------------------------------------------
*/
ULONG HAL_SetSlaveChipNum(ULONG ulSlaveChipNum)
{
    g_ASRAMCTRL_SC_NUM = ulSlaveChipNum;

    return HAL_OK;
}
/*****************************************************************************
*  函数名称   : HAL_GetSlaveChipNum
*  功能描述   : 获取从片IC的数量
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : 无
*  输出参数   : 无
*  返 回 值   : 从片IC的数量
*  其它说明   : 无
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)*
* $0000000(N/A), 王飞@2014-9-2 14:55:24
*----------------------------------------------------------------------------
*/

ULONG HAL_GetSlaveChipNum(VOID)
{
    return g_ASRAMCTRL_SC_NUM;
}
/*-------------------------------------------------------------------------------------------------------------------*/
/** @brief 获取芯片中某一外设模块的物理地址信息
 *
 * 功能详述:
 *     - 函数属于接口函数, 其功能是:
 *     - 主片模式下，获取芯片中某一外设模块的物理地址的信息
 *     
 * 参数概述:
 *     - 输入参数: udMemBlk  模块的编号
 *     - 输出参数: pudMemBlkPhyAddr  起始物理地址
 *                                pudMemBlkPhySize  物理空间大小BYTE
 *     - 返回值类型是UINT32, 含义是: 错误码
 *                           HAL_SOK    成功，返回值可用
 *                           HAL_ESYS_INVPARAMS 失败，返回值不可用
 * 
 * 引用(类变量,外部变量,接口函数):
 *     - 无
 */
/*--------------------------------------------------------------------------------------------------------------------*/
UINT32 HAL_addrmapGetMemblkPhyInfo(UINT32 udMemBlk,UINT32 *pudMemBlkPhyAddr,UINT32  *pudMemBlkPhySize)
{
    UINT32 udRet=HAL_ESYS_INVPARAMS;
    UINT32 udLoop;

    if((udMemBlk > MAX_MEM_BLK)||(NULL==pudMemBlkPhyAddr)||(NULL == pudMemBlkPhySize ))
    {
        return (UINT32)HAL_ESYS_INVPARAMS;
    }
    
    for(udLoop=0; udLoop<g_hal_asram_memblk_num; udLoop++)
    {
        if((g_hal_asram_memblk_def[udLoop].udMemBlkNo == udMemBlk) && (MEM_BLK_STATUS_DEFINE<=g_hal_asram_memblk_def[udLoop].udInitedFlag))
        {
           *pudMemBlkPhyAddr=(g_hal_asram_memblk_def[udLoop].udPhyAddrStart);
           *pudMemBlkPhySize=(g_hal_asram_memblk_def[udLoop].udPhySize);
             return (UINT32)HAL_SOK;
        }
    }
    return udRet;    
}

/*-------------------------------------------------------------------------------------------------------------------*/
/** @brief 获取芯片中某一外设模块的物理地址的大小
 *
 * 功能详述:
 *     - 函数属于接口函数, 其功能是:
 *     - 主片模式下，获取芯片中某一外设模块的物理地址的大小
 *     
 * 参数概述:
 *     - 输入参数: udMemBlk  模块的编号
 *     - 输出参数: pudMemBlkPhySize  物理空间大小BYTE
 *     - 返回值类型是UINT32, 含义是: 错误码
 *                           HAL_SOK    成功，返回值可用
 *                           HAL_ESYS_INVPARAMS 失败，返回值不可用
 * 
 * 引用(类变量,外部变量,接口函数):
 *     - 无
 */
/*--------------------------------------------------------------------------------------------------------------------*/
UINT32 HAL_addrmapGetMemblkPhySize(UINT32 udMemBlk,UINT32 *pudMemBlkPhySize)
{
    UINT32 udRet=HAL_ESYS_INVPARAMS;
    UINT32 udLoop;

    if((udMemBlk > MAX_MEM_BLK)||(NULL == pudMemBlkPhySize ))
    {
        return (UINT32)HAL_ESYS_INVPARAMS;
    }
    
    for(udLoop=0; udLoop<g_hal_asram_memblk_num; udLoop++)
    {
        if((g_hal_asram_memblk_def[udLoop].udMemBlkNo == udMemBlk) && (MEM_BLK_STATUS_DEFINE <= g_hal_asram_memblk_def[udLoop].udInitedFlag))
        {
            *pudMemBlkPhySize = g_hal_asram_memblk_def[udLoop].udPhySize ;
            return (UINT32)HAL_SOK;
        }
    }
    return udRet;   
    
    
}

/*-------------------------------------------------------------------------------------------------------------------*/
/** @brief 设置芯片中某一外设模块的虚拟地址信息
 *
 * 功能详述:
 *     - 函数属于接口函数, 其功能是:
 *     - 设置芯片中某一外设模块的虚拟地址信息
 *     
 * 参数概述:
 *     - 输入参数: udMemBlk  模块的编号
 *                                udVirAddr 模块的虚拟地址(由外部进行mmap后得到的虚拟地址，用于用户态访问)
 *     - 输出参数: 无
 *     - 返回值类型是UINT32, 含义是: 错误码
 *                           HAL_SOK    成功，返回值可用
 *                           HAL_ESYS_INVPARAMS 失败，返回值不可用
 * 
 * 引用(类变量,外部变量,接口函数):
 *     - 无
 */
/*--------------------------------------------------------------------------------------------------------------------*/
UINT32 HAL_addrmapSetMemblkVirAddr(UINT32 udMemBlk,UINT32 udVirAddr)
{
    UINT32 udRet=HAL_ESYS_INVPARAMS;
    UINT32 udLoop;

    if(udMemBlk > MAX_MEM_BLK)
    {
        return (UINT32)HAL_ESYS_INVPARAMS;
    }
    
    for(udLoop=0;udLoop<g_hal_asram_memblk_num;udLoop++)
    {
        if((g_hal_asram_memblk_def[udLoop].udMemBlkNo == udMemBlk) && (MEM_BLK_STATUS_DEFINE<=g_hal_asram_memblk_def[udLoop].udInitedFlag))
        {
           g_hal_asram_memblk_def[udLoop].udVirtualAddr = udVirAddr;
           g_hal_asram_memblk_def[udLoop].udInitedFlag = MEM_BLK_STATUS_INITED;
           return (UINT32)HAL_SOK;
        }
    }
    return udRet;   
   
}

/*-------------------------------------------------------------------------------------------------------------------*/
/** @brief 读取预先记录的外设模块的虚拟地址信息，用于用户态地址访问
 *
 * 功能详述:
 *     - 函数属于接口函数, 其功能是:
 *     - 读取预先记录的外设模块的虚拟地址信息，用于用户态地址访问
 *     
 * 参数概述:
 *     - 输入参数: udMemBlk  模块的编号
 *     - 输出参数: pudVirAddr  虚拟地址
 *     - 返回值类型是UINT32, 含义是: 错误码
 *                           HAL_SOK    成功，返回值可用
 *                           HAL_ESYS_INVPARAMS 失败，返回值不可用
 * 
 * 引用(类变量,外部变量,接口函数):
 *     - 无
 */
/*--------------------------------------------------------------------------------------------------------------------*/
UINT32 HAL_addrmapGetMCMemblkVirAddr(UINT32 udMemBlk,UINT32* pudVirAddr)
{
	//printf("%s %d \n", __FUNCTION__, __LINE__);
	//printf("%s %d %d  %lx\n",__FUNCTION__, __LINE__,udMemBlk,pudVirAddr);
    UINT32 udRet=HAL_ESYS_INVPARAMS;
    UINT32 udLoop;

    if((udMemBlk > MAX_MEM_BLK)||(NULL==pudVirAddr))
    {
        return (UINT32)HAL_ESYS_INVPARAMS;
    }

    
    for(udLoop=0;udLoop<g_hal_asram_memblk_num;udLoop++)
    {
        if((g_hal_asram_memblk_def[udLoop].udMemBlkNo == udMemBlk) && (MEM_BLK_STATUS_DEFINE<=g_hal_asram_memblk_def[udLoop].udInitedFlag))
        {
           *pudVirAddr = g_hal_asram_memblk_def[udLoop].udVirtualAddr;
           //printf("[GetMasterChipMemblkVirAddr] blk=%d viraddr=%x\n",udMemBlk,*pudVirAddr);
           return (UINT32)HAL_SOK;
        }
    }
    return udRet;   
   
}

/*-------------------------------------------------------------------------------------------------------------------*/
/** @brief 查询外设模块的asram映射通道号
 *
 * 功能详述:
 *     - 函数属于接口函数, 其功能是:
 *     - 查询外设模块的asram映射通道号
 *     
 * 参数概述:
 *     - 输入参数: udMemBlk  模块的编号
 *     - 输出参数: pudAsramChan  通道号
 *     - 返回值类型是UINT32, 含义是: 错误码
 *                           HAL_SOK    成功，返回值可用
 *                           HAL_ESYS_INVPARAMS 失败，返回值不可用
 * 
 * 引用(类变量,外部变量,接口函数):
 *     - 无
 */
/*--------------------------------------------------------------------------------------------------------------------*/
UINT32 HAL_addrmapGetMemblkMapChan(UINT32 udMemBlk,UINT32 *pudAsramChan)
{
    UINT32 udRet=HAL_ESYS_INVPARAMS;
    UINT32 udLoop;

    if((udMemBlk > MAX_MEM_BLK)||(NULL==pudAsramChan))
    {
        return (UINT32)HAL_ESYS_INVPARAMS;
    }
    
    for(udLoop=0;udLoop<g_hal_asram_memmap_num;udLoop++)
    {
        if((g_hal_asram_memblk_map[udLoop].udMemBlkNo == udMemBlk) && (MEM_BLK_STATUS_DEFINE <= g_hal_asram_memblk_map[udLoop].udInitedFlag))
        {
          *pudAsramChan = g_hal_asram_memblk_map[udLoop].udAsramMapChan ;
          return (UINT32)HAL_SOK;
        }
    }
    return udRet;     
}

/*-------------------------------------------------------------------------------------------------------------------*/
/** @brief 查询外设模块的asram映射通道的大小
 *
 * 功能详述:
 *     - 函数属于接口函数, 其功能是:
 *     - 查询外设模块的asram映射通道的大小
 *     
 * 参数概述:
 *     - 输入参数: udMemBlk  模块的编号
 *     - 输出参数: pudAsramChanSize  映射通道的大小
 *     - 返回值类型是UINT32, 含义是: 错误码
 *                           HAL_SOK    成功，返回值可用
 *                           HAL_ESYS_INVPARAMS 失败，返回值不可用
 * 
 * 引用(类变量,外部变量,接口函数):
 *     - 无
 */
/*--------------------------------------------------------------------------------------------------------------------*/
UINT32 HAL_addrmapGetMemblkMapChanSize(UINT32 udMemBlk,UINT32 *pudAsramChanSize)
{
    UINT32 udRet=HAL_ESYS_INVPARAMS;
    UINT32 udLoop;

    if((udMemBlk > MAX_MEM_BLK)||(NULL==pudAsramChanSize))
    {
        return (UINT32)HAL_ESYS_INVPARAMS;
    }
    
    for(udLoop=0;udLoop<g_hal_asram_memmap_num;udLoop++)
    {
        if((g_hal_asram_memblk_map[udLoop].udMemBlkNo == udMemBlk) && (MEM_BLK_STATUS_DEFINE <= g_hal_asram_memblk_map[udLoop].udInitedFlag))
        {
          *pudAsramChanSize = g_hal_asram_memblk_map[udLoop].udMapSize ;
           return (UINT32)HAL_SOK;
        }
    }
    return udRet;    
    
}

/*-------------------------------------------------------------------------------------------------------------------*/
/** @brief 查询外设模块的大小
 *
 * 功能详述:
 *     - 函数属于接口函数, 其功能是:
 *     - 查询外设模块的大小
 *     
 * 参数概述:
 *     - 输入参数: udCHipId:主从片编号，0:主片，1~15:从片
 *                                udMemBlk  模块的编号
 *     - 输出参数: pudAsramChanSize  模块空间大小
 *     - 返回值类型是UINT32, 含义是: 错误码
 *                           HAL_SOK    成功，返回值可用
 *                           HAL_ESYS_INVPARAMS 失败，返回值不可用
 * 
 * 引用(类变量,外部变量,接口函数):
 *     - 无
 */
/*--------------------------------------------------------------------------------------------------------------------*/
UINT32 HAL_addrmapGetMemblkChanSize(UINT32 udCHipId,UINT32 udMemBlk,UINT32 *pudAsramChanSize)
{
	//printf("%s %d \n", __FUNCTION__, __LINE__);
    UINT32 udRet=HAL_ESYS_INVPARAMS;


    if((udMemBlk > MAX_MEM_BLK)||(udCHipId>HAL_GetSlaveChipNum())||(NULL == pudAsramChanSize ))
    {
        return (UINT32)HAL_ESYS_INVPARAMS;
    }
    
    switch(udCHipId)
    {   /* 主片 */
    printf("%s %d \n", __FUNCTION__, __LINE__);
        case 0:
        {
            udRet = HAL_addrmapGetMemblkPhySize(udMemBlk,pudAsramChanSize);         
            break;
        }
        /* 从片 */
        default:
        {
            udRet = HAL_addrmapGetMemblkMapChanSize(udMemBlk,pudAsramChanSize);
            break;
        }
    }
    
    return udRet;   
    
    
}

/*-------------------------------------------------------------------------------------------------------------------*/
/** @brief 获取外设模块的asram映射通道的偏移
 *
 * 功能详述:
 *     - 函数属于接口函数, 其功能是:
 *     - 获取外设模块的asram映射通道的偏移
 *     
 * 参数概述:
 *     - 输入参数: udMemBlk  模块的编号
 *     - 输出参数: pudAsramChanSize  映射通道的偏移
 *     - 返回值类型是UINT32, 含义是: 错误码
 *                           HAL_SOK    成功，返回值可用
 *                           HAL_ESYS_INVPARAMS 失败，返回值不可用
 * 
 * 引用(类变量,外部变量,接口函数):
 *     - 无
 */
/*--------------------------------------------------------------------------------------------------------------------*/
UINT32 HAL_addrmapGetMemblkMapChanOffset(UINT32 udMemBlk,UINT32 *pudAsramChanSize)
{
    UINT32 udRet=HAL_ESYS_INVPARAMS;
    UINT32 udLoop;

    if((udMemBlk > MAX_MEM_BLK)||(NULL == pudAsramChanSize ))
    {
        return (UINT32)HAL_ESYS_INVPARAMS;
    }

    for(udLoop=0;udLoop<g_hal_asram_memmap_num;udLoop++)
    {
        if((g_hal_asram_memblk_map[udLoop].udMemBlkNo == udMemBlk) && (MEM_BLK_STATUS_DEFINE <= g_hal_asram_memblk_map[udLoop].udInitedFlag))
        {
          *pudAsramChanSize = g_hal_asram_memblk_map[udLoop].udMapStartOffset ;
           return (UINT32)HAL_SOK;
        }
    }
    return udRet;   
    
    
}

/*-------------------------------------------------------------------------------------------------------------------*/
/** @brief 查询指定从片特定外设模块的asram映射通道的虚拟地址
 *
 * 功能详述:
 *     - 函数属于接口函数, 其功能是:
 *     - 查询指定从片特定外设模块的asram映射通道的虚拟地址
 *     
 * 参数概述:
 *     - 输入参数: udSlaveChipId  芯片编号 0--15  0主片，第N-1从片，由IC统一编号减一得到
 *                                udMemBlk  模块的编号
 *     - 输出参数: pudAsramChanVirBaseAddr  映射通道虚拟地址
 *     - 返回值类型是UINT32, 含义是: 错误码
 *                           HAL_SOK    成功，返回值可用
 *                           HAL_ESYS_INVPARAMS 失败，返回值不可用
 * 
 * 引用(类变量,外部变量,接口函数):
 *     - 无
 */
/*--------------------------------------------------------------------------------------------------------------------*/
UINT32 HAL_addrmapGetSCMemblkVirBaseAddr(UINT32 udSlaveChipId,UINT32 udMemBlk,UINT32 *pudAsramChanVirBaseAddr)
{
    UINT32 udRet=HAL_ESYS_INVPARAMS;
    //UINT32 udLoop = 0;
    UINT32 udMapChan = 0;
    UINT32 udStartOffset = 0;
    UINT32 udAsramVirBaseAddr = 0;

    if((udMemBlk > MAX_MEM_BLK)||(udSlaveChipId>HAL_GetSlaveChipNum())||(NULL == pudAsramChanVirBaseAddr ))
    {
        return (UINT32)HAL_ESYS_INVPARAMS;
    }
    
    /* 获取主片asram模块的虚拟地址 */
    
    if(udSlaveChipId==0)
    {
        printf("GetSlaveChipMemblkVirBaseAddr:meet bad guy=0\n");
        return udRet;
    }
    udSlaveChipId -= 1;
    
    udRet = HAL_addrmapGetMCMemblkVirAddr(MEM_BLK_ASRAM,&udAsramVirBaseAddr);
    
    if(HAL_ESYS_INVPARAMS == udRet)
    {
        return udRet;
    }
    /* 获取指定芯片、指定模块的asram模块的编号(所有从片的asram chan分配规则相同，不用区分芯片编号) */
    udRet = HAL_addrmapGetMemblkMapChan(udMemBlk,&udMapChan);
    
    if(HAL_ESYS_INVPARAMS == udRet)
    {    
        return udRet;
    }
    
    udRet = HAL_addrmapGetMemblkMapChanOffset(udMemBlk,&udStartOffset);
    
    if(HAL_ESYS_INVPARAMS == udRet)
    {
        return udRet;
    }
    
    *pudAsramChanVirBaseAddr = (udAsramVirBaseAddr + udStartOffset +
                               udSlaveChipId*ASRAMCTRL_IC_OFFSET  + /* 每个从片的偏移地址是4M */
                               g_hal_asram_chan_offset[udMapChan-1]);/* 每个chan的偏移地址 */
    return udRet;   
       
}

/*-------------------------------------------------------------------------------------------------------------------*/
/** @brief 查询指定芯片、特定外设模块的虚拟地址
 *
 * 功能详述:
 *     - 函数属于接口函数, 其功能是:
 *     - 查询指定芯片、特定外设模块的虚拟地址
 *     
 * 参数概述:
 *     - 输入参数: udSlaveChipId  芯片编号 0主片 1--15 第N从片
 *                                udMemBlk  模块的编号
 *     - 输出参数: pudAsramVirBaseAddr  aram通道号的虚拟地址
 *     - 返回值类型是UINT32, 含义是: 错误码
 *                           HAL_SOK    成功，返回值可用
 *                           HAL_ESYS_INVPARAMS 失败，返回值不可用
 * 
 * 引用(类变量,外部变量,接口函数):
 *     - 无
 */
/*--------------------------------------------------------------------------------------------------------------------*/
UINT32 HAL_addrmapGetChipMemblkVirBaseAddr(UINT32 udChipId,UINT32 udMemBlk,UINT32 *pudAsramVirBaseAddr)
{
	//printf("%s %d \n", __FUNCTION__, __LINE__);
	//printf("%s %d %d %d %lx\n",__FUNCTION__, __LINE__,udChipId,udMemBlk,pudAsramVirBaseAddr);
    UINT32 udRet=HAL_ESYS_INVPARAMS;

    if((udMemBlk > MAX_MEM_BLK)||(udChipId>HAL_GetSlaveChipNum())||(NULL == pudAsramVirBaseAddr ))
    {
        return (UINT32)HAL_ESYS_INVPARAMS;
    }
   // printf("%s %d \n", __FUNCTION__, __LINE__);

    udRet = HAL_addrmapGetMCMemblkVirAddr(udMemBlk,pudAsramVirBaseAddr);
    
    switch(udChipId)
    {   /* 主片 */
    printf("%s %d \n", __FUNCTION__, __LINE__);
        case 0:
        {
            udRet = HAL_addrmapGetMCMemblkVirAddr(udMemBlk,pudAsramVirBaseAddr);
            break;
        }
        /* 从片 */
        default:
         {
            udRet = HAL_addrmapGetSCMemblkVirBaseAddr(udChipId,udMemBlk,pudAsramVirBaseAddr);
            break;
         }
    }
    
    return udRet;   
    
    
}

/*-------------------------------------------------------------------------------------------------------------------*/
/** @brief 从指定芯片的外设模块中获取某一虚拟地址上的信息
 *
 * 功能详述:
 *     - 函数属于接口函数, 其功能是:
 *     - 从指定芯片的外设模块中获取某一虚拟地址上的信息
 *     
 * 参数概述:
 *     - 输入参数: udSlaveChipId  芯片编号 0主片 1--15 第N从片
 *                                udMemBlk  模块的编号
 *                                udOffset  地址偏移
 *     - 输出参数: pudData  虚拟地址上的信息
 *     - 返回值类型是UINT32, 含义是: 错误码
 *                           HAL_SOK    成功，返回值可用
 *                           HAL_ESYS_INVPARAMS 失败，返回值不可用
 * 
 * 引用(类变量,外部变量,接口函数):
 *     - 无
 */
/*--------------------------------------------------------------------------------------------------------------------*/
UINT32 HAL_addrmapGetDataFromVirAddr(UINT32 udChipId,UINT32 udMemBlk,UINT32 udOffset,UINT32 *pudData)
{
	//printf("%s %d \n", __FUNCTION__, __LINE__);
     UINT32 udRet=HAL_ESYS_INVPARAMS;
     
     UINT32 udRegAddr = 0;
     UINT32 udMapSize = 0;
     volatile UINT32 *pudRegVir = NULL;

     if((udMemBlk > MAX_MEM_BLK)||(udChipId>HAL_GetSlaveChipNum())||(NULL == pudData ))
     {
        return (UINT32)HAL_ESYS_INVPARAMS;
     }
     
     udRet =  HAL_addrmapGetChipMemblkVirBaseAddr(udChipId, udMemBlk,&udRegAddr);

     if(HAL_ESYS_INVPARAMS==udRet)
     {
        printf("blk para erroe\n");
        return udRet;
     }

     udRet =  HAL_addrmapGetMemblkChanSize(udChipId,udMemBlk,&udMapSize);

     if((HAL_ESYS_INVPARAMS==udRet) || (udOffset >= udMapSize))
     {
        return udRet;
     }
     
     pudRegVir =((volatile UINT32 *)(udRegAddr + udOffset)); 
     *pudData = *(pudRegVir);


     return udRet;
     
}

/*-------------------------------------------------------------------------------------------------------------------*/
/** @brief 设置指定芯片的模块中某一虚拟地址上的信息
 *
 * 功能详述:
 *     - 函数属于接口函数, 其功能是:
 *     - 设置指定芯片的模块中某一虚拟地址上的信息
 *     
 * 参数概述:
 *     - 输入参数: udSlaveChipId  芯片编号 0主片 1--15 第N从片
 *                                udMemBlk  模块的编号
 *                                udOffset  地址偏移
 *                                udData  设置虚拟地址上的信息
 *     - 输出参数: 无
 *     - 返回值类型是UINT32, 含义是: 错误码
 *                           HAL_SOK    成功，返回值可用
 *                           HAL_ESYS_INVPARAMS 失败，返回值不可用
 * 
 * 引用(类变量,外部变量,接口函数):
 *     - 无
 */
/*--------------------------------------------------------------------------------------------------------------------*/
UINT32 HAL_addrmapSetDataToVirAddr(UINT32 udChipId,UINT32 udMemBlk,UINT32 udOffset,UINT32 udData)
{
     UINT32 udRet=HAL_ESYS_INVPARAMS;
     
     UINT32 udRegAddr = 0;
     UINT32 udMapSize = 0;

     volatile UINT32 *pudRegVir = NULL;

     if((udMemBlk > MAX_MEM_BLK)||(udChipId>HAL_GetSlaveChipNum()))
     {
        return (UINT32)HAL_ESYS_INVPARAMS;
     }
     
     udRet =  HAL_addrmapGetChipMemblkVirBaseAddr(udChipId, udMemBlk,&udRegAddr);

     if(HAL_ESYS_INVPARAMS==udRet)
     {
        return udRet;
     }

     udRet =  HAL_addrmapGetMemblkChanSize( udChipId,udMemBlk,&udMapSize);

     if((HAL_ESYS_INVPARAMS==udRet) || (udOffset >= udMapSize))
     {
        return udRet;
     }
     
     pudRegVir = (volatile UINT32 *)(udRegAddr + udOffset ); 
     *(pudRegVir) = udData ;
     
     return udRet;
     
}
#if 0
/*-------------------------------------------------------------------------------------------------------------------*/
/** @brief 设置指定芯片的模块中若干长度的虚拟地址上的信息
 *
 * 功能详述:
 *     - 函数属于接口函数, 其功能是:
 *     - 设置指定芯片的模块中若干长度的虚拟地址上的信息
 *     
 * 参数概述:
 *     - 输入参数: udSlaveChipId  芯片编号 0主片 1--15 第N从片
 *                                udMemBlk  模块的编号
 *                                udOffset  地址偏移
 *                                pudData  设置虚拟地址上的信息
 *                                udLen   设置信息的长度
 *     - 输出参数: 无
 *     - 返回值类型是UINT32, 含义是: 错误码
 *                           HAL_SOK    成功，返回值可用
 *                           HAL_ESYS_INVPARAMS 失败，返回值不可用
 * 
 * 引用(类变量,外部变量,接口函数):
 *     - 无
 */
/*--------------------------------------------------------------------------------------------------------------------*/
UINT32 HAL_addrmapSetData(UINT32 udChipId,UINT32 udMemBlk,UINT32 udOffset,UINT32* pudData,UINT32 udLen)
{
    UINT32 udRet=HAL_SOK;
    UINT32 udLoop = 0;

    if((udMemBlk > MAX_MEM_BLK)||(udChipId>HAL_GetSlaveChipNum())||(NULL == pudData ))
    {
        return (UINT32)HAL_ESYS_INVPARAMS;
    }
    
    for(udLoop=0;udLoop<udLen;udLoop++)
    {
       udRet = HAL_addrmapSetDataToVirAddr(udChipId, udMemBlk, udOffset+udLoop,pudData[udLoop]);
       if(HAL_SOK !=  udRet)
       {
           udRet=HAL_ESYS_INVPARAMS;
           break;
       }
    }
    return udRet;
}
#endif
/*-------------------------------------------------------------------------------------------------------------------*/
/** @brief 打印摸个地址上的多个数值
 *
 * 功能详述:
 *     - 函数属于接口函数, 其功能是:
 *     - 打印摸个地址上的多个数值
 *     
 * 参数概述:
 *     - 输入参数: udSlaveChipId  芯片编号 0主片 1--15 第N从片
 *                                udMemBlk  模块的编号
 *                                udOffset  地址偏移
 *                                udLen   信息的长度
 *     - 输出参数: 无
 *     - 返回值类型是UINT32, 含义是: 错误码
 *                           HAL_SOK    成功，返回值可用
 *                           HAL_ESYS_INVPARAMS 失败，返回值不可用
 * 
 * 引用(类变量,外部变量,接口函数):
 *     - 无
 */
/*--------------------------------------------------------------------------------------------------------------------*/
void WrReg(UINT32 usChip,UINT32 udMemBlk,UINT32 ulReg,UINT32 data)
{
    HAL_addrmapSetDataToVirAddr(usChip, udMemBlk, ulReg, data);
}

UINT32 PrnReg(UINT32 usChip,UINT32 udMemBlk,UINT32 ulReg,UINT32 usNum)
{

    static USHORT usNumDefault=64;
    USHORT usLoop;
    ULONG ulDelta,ulStart;
    UINT32 ulData;
    UINT32 udRet=HAL_SOK;
    usNum = (usNum) ? usNum : usNumDefault;
    usNumDefault = usNum;
    if((udMemBlk > MAX_MEM_BLK)||(usChip>HAL_GetSlaveChipNum()))
    {
        return (UINT32)HAL_ESYS_INVPARAMS;
    }
    if(ulReg%4)
	{
	    ulReg=(ulReg & 0xfffffffc);
	}

    ulDelta = (ulReg>>2) & 0x3;
    ulStart = ulReg - ulDelta*4;
    usNum += (USHORT)ulDelta;
    printf("usage:PrnReg chip,memblk,offsetByte,DWordNum\n\n ");

    
    printf("\n CHIP[%d]    =+0=     =+4=     =+8=     =+c=  \n",usChip);
    for (usLoop = 0; usLoop < usNum; usLoop++)
    {
        if(!((usLoop*4) & 0x0F))
        {
            printf("0x%08X: ",(ulStart + usLoop *4));
        }
        if((ulStart+usLoop*4) < ulReg)
        {
            printf("         ");
        }
        else
        {
            udRet = HAL_addrmapGetDataFromVirAddr( usChip, udMemBlk, ulStart+usLoop*4,&ulData);
            if(HAL_SOK !=udRet)
            {
                //udRet=HAL_ESYS_INVPARAMS;
                return udRet;
            }
            printf("%08X ", ulData);
        }
        if(3==usLoop%4)/*每行4个元素*/
        {
            printf("\n");
        }
    }
    printf("\n");
    return HAL_SOK;
    
}
 /*lint +e641*/


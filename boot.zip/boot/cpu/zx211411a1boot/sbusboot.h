/**************************************************************************
 * 版权所有 (C)2001, 深圳市中兴通讯股份有限公司
 *
 * 文件名称: zx211410boot.h
 * 文件标识:
 * 内容摘要:
 * 其它说明:
 * 当前版本: 
 * 作    者:
 * 完成日期:
 *
 * 修改记录1:
 *    修改日期: 
 *    版 本 号: 
 *    修 改 人: 
 *    修改内容: 创建
 * 修改记录2:
 **************************************************************************/

#ifndef _SBUSBOOT_H_
#define _SBUSBOOT_H_

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

#define SBUS_ID_NTL_SERDES_D6_LANE10   (0xF)
#define SBUS_ID_NTL_SERDES_D6_LANE11   (0x10)
#define SBUS_ID_NTL_SERDES_D6_0        (15)
#define SBUS_ID_NTL_SERDES_D6_1        (16)
#define SBUS_ID_PCIE_SERDES            (19)
#define SBUS_ID_PCIE_PCS               (20)
    
#define BROADCAST_ADDR_SERDES          (0xFF)
#define BROADCAST_ADDR_MASTER          (0xFE)
#define BROADCAST_ADDR_SNAP            (0xFD)
#define BROADCAST_ADDR_PCIE_PCS        (0xF7)

#define SBUS_AXI2SBUS                  (0)     /*物理地址是0x8c000000*/
    

#define FIRMWARE_DOWNLOAD_TIMEOUT  (50000u)         // unit: us
                                                   // 20181115修改固件加载等待时间为50ms
    
VOID sbusRst();
VOID sbusCommandTypeSwitch(UINT32 udCmdRST);
VOID sbusCommand(UINT8 ucSbusId, UINT8 ucOffset, UINT32 udCmd);
UINT32 sbusResultOut(UINT8 ucSbusId, UINT8 ucOffset);

VOID sbusSetClk12_5M();
VOID sbusSetClk25M();


#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif


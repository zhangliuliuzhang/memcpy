/*****************************************************************************
 * 版权所有(C) 2010, ZTE Corp. RRU Bsp Platform
 *----------------------------------------------------------------------------
 * 模 块 名 : BSP
 * 文件名称 : ls10x3aboot.c
 * 文件标识 : {[N/A]}
 * 内容摘要 : lx10xx cpu bootapp接口实现
 * 注意事项 : 无
 * 作    者 : 耿佳佳
 * 创建日期 : 2015-10-22 08:28:34
 * 当前版本 : Ver1.0
 *----------------------------------------------------------------------------
 * 变更记录 :
 *
 * $记录1
 * 变 更 单: $0000000(N/A)
 * 责 任 人: 耿佳佳
 * 修改日戳: 2015-10-22 08:28:34
 * 变更说明: 创建文件
 * $记录2
 * 变 更 单: $0000000(N/A)
 * 责 任 人: 李耀清
 * 修改日戳: 2018-08-30 13:44:00
 * 变更说明: 将MPSOC系列boot修改为NXP ls10x3a系列boot
 *----------------------------------------------------------------------------
 */

#include "stdio.h"
#include <sys/types.h>
#include <sys/stat.h>
#include <netinet/in.h>
#include <fcntl.h>
#include <errno.h>
#include "vxadp.h"

#include "bsppub.h"
#include "bspcomm.h"
#include "pub_typedef.h"
#include "bsperrcode.h"
#include "ls10x3aboot.h"
#include <string.h>
#include <linux/mii.h>
#include <sys/socket.h>
#include <sys/ioctl.h>
#include <net/if.h>
#include <linux/types.h>
#include <time.h>
#include "nxpgpio.h"
#include "bspcommonstdlog.h"

/**************************************************************************
 *                        宏
 **************************************************************************/
extern UCHAR g_ucCmdLine[256];
#ifdef COMPILE_FOR_KEXEC_BOOT
#define reteck(ret)                                                \
        if(ret < 0)                                                \
        {                                                          \
            zte_printf_s("%s: line: %d  ret: %d\n", __func__, __LINE__, ret); \
            return BSP_ERROR;			                            \
        }
#define ret_check(ret, fd)                                                \
    if(ret < 0)                                                \
        {                                                          \
            close(fd);                                                          \
            zte_printf_s("error! \"%s\" : line: %d\n", __func__, __LINE__); \
            return BSP_ERROR;                                         \
        }
            
/**************************************************************************
 *                         数据类型                                       *
 **************************************************************************/


/**************************************************************************
 *                         全局变量定义                                   *
 **************************************************************************/
ULONG  g_ulRamReservedAddr =0;

static ULONG aulCpldAddr=0;
/**************************************************************************
 *                         外部变量声明
 **************************************************************************/

/**************************************************************************
 *                         函数实现
 **************************************************************************/


/*****************************************************************************
*  函数名称   : BspGetCpuType(*)
*  功能描述   : 双boot模块用于获取cpu类型
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : 无
*  输出参数   : 无
*  返 回 值   : 成功 - BSP_OK
*  其它说明   : 
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A), yam@2014-10-09 14:07:25 创建
*  $0000000(N/A), lyq@2018-11-14 09:48:00 修改，platform/bsp/include/bsppub.h中新添加NXPCPU型号
*----------------------------------------------------------------------------
*/
UINT32 BspGetCpuType (UCHAR *pucCpuType)    
{ 
    if (NULL == pucCpuType)
        return BSP_ERROR_NULL_POINTER;
    /* 这里和bsppub.h保持一致 */
    *pucCpuType = BSP_LS1043A;
    return BSP_OK;
}
/* change by lyq 使用CPLD实现*/
ULONG BootRdWdtReg(ULONG ulAddr)
{
    
    return BSP_OK;
    
}
ULONG BootWrWdtReg(ULONG ulAddr, ULONG ulData)
{
   
    return BSP_OK;
}

/******************************************************************************
*  函数名称   : cpld_read(*)
*  功能描述   : 读cpld寄存器
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : reg offset addr
*  输出参数   :*pucReg 读到的数据 8bit
*  返 回 值   : BSP_OK, 操作成功; BSP_ERROR_INVALID_PARA, 输入参数错误
*  其它说明   : 无
*  函数属性   :
*------------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A), 李耀清@2018-10-18 14:41:00 创建
*------------------------------------------------------------------------------
*/
ULONG cpld_read(ULONG ulOffSet, unsigned char *pucReg)
{
    *pucReg = *((volatile unsigned char*)(aulCpldAddr + ulOffSet));
     return BSP_OK;
}
/******************************************************************************
*  函数名称   : cpld_write(*)
*  功能描述   : 写cpld寄存器
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   :

*  输出参数   : 无
*  返 回 值   : BSP_OK, 操作成功; BSP_ERROR_INVALID_PARA, 输入参数错误
*  其它说明   : 无
*  函数属性   :
*------------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A), 李耀清@2018-10-18 14:41:00 创建
*------------------------------------------------------------------------------
*/
ULONG cpld_write(ULONG ulOffSet, unsigned char ucReg)
{
    *((volatile unsigned char*)(aulCpldAddr + ulOffSet))=ucReg;
     return BSP_OK;
}
/*****************************************************************************
 *  函数名称   : BootWatchDogEnable(*)
 *  功能描述   : 使能软件喂狗
 *  读全局变量 : 无
 *  写全局变量 : 无
 *  输入参数   : 无
 *  输出参数   : 无
 *  返 回 值   : 成功 - BSP_OK
 *  其它说明   : 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *  $0000000(N/A), 宋飞@2011-11-25 11:15:46
 *  $0000000(N/A), 李耀清@2018-10-18 16:02:00，nxp修改为外部cpld实现
 *----------------------------------------------------------------------------
 */
ULONG BootWatchDogEnable(VOID)
{
    #ifndef CONFIG_A9606_BOARD /* A9606烧录板无CPLD */
    /* feed once anyway */
    cpld_write(CPLD_WTD_FEED_REG, 0x5a);
    cpld_write(CPLD_WTD_FEED_REG, 0x0);

    /* enable */
    cpld_write(CPLD_WTD_ENABLE_REG, 0x1);
    #endif
    return BSP_OK;
}

/*****************************************************************************
 *  函数名称   : BootWatchDogDisable(*)
 *  功能描述   : 去使能软件喂狗
 *  读全局变量 : 无
 *  写全局变量 : 无
 *  输入参数   : 无
 *  输出参数   : 无
 *  返 回 值   : BSP_OK 
 *  其它说明   : 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *  $0000000(N/A), 宋飞@2011-11-25 11:15:46
 *  $0000001(N/A), 姜建奎@2013-12-13 16:04:27 加入支持FPGA 看门狗
 *  $0000002(N/A), 李耀清@2018-09-11 14:57:00 修改ULONG为char,由于看门狗SR地址不能
                   被4、8整除，地址指针不能用ULONG强制转换
 *----------------------------------------------------------------------------
 */
ULONG BootWatchDogDisable(VOID)
{
    #ifndef CONFIG_A9606_BOARD /* A9606烧录板无CPLD */
    /* feed once anyway */
    cpld_write(CPLD_WTD_FEED_REG, 0x5a);
    cpld_write(CPLD_WTD_FEED_REG, 0x0);
    /*disable*/
    cpld_write(CPLD_WTD_ENABLE_REG, 0x0);
    #endif
    return BSP_OK;
}

/*****************************************************************************
 *  函数名称   : BspSetWatchDogTime(*)
 *  功能描述   : 设置看门狗喂狗时间
 *  读全局变量 : 无
 *  写全局变量 : 无
 *  输入参数   : ulTimerValue - 写入硬件喂狗的时间，以100ms为单位
 *  输出参数   : 无
 *  返 回 值   : 成功 - BSP_OK
 *  其它说明   : 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *  $0000000(N/A), 宋飞@2011-11-25 11:15:46
 *  $0000000(N/A), 李耀清@2018-10-18 15:52:00 ,NXP 修改为外部CPLD 实现
 *----------------------------------------------------------------------------
 */
ULONG BootSetWatchDogTime (unsigned short timeout)
{
 
    if (2 > timeout || 510 < timeout)
    {
        zte_printf_s("wtd timeout error, should be [2,510]s\n");
        return BSP_ERROR;
    }
    #ifndef CONFIG_A9606_BOARD /* A9606烧录板无CPLD */
    /* set wt */
    cpld_write(CPLD_WTD_TIMEOUT_REG, timeout/2);
    #endif
    return BSP_OK;
    
}

/**********************************************************************
* 函数名称:VOID BootAppWatchDogInit()
* 功能描述:bootapp初始化看门狗
* 输入参数:无
* 输出参数:
* 返 回 值:BSP_OK:成功;BSP_ERROR:失败
* 其它说明:网线连通bootapp main入口到下次内核启动完成计时约20s。bsp接口单位100ms，
           设置看门狗时间100s，100s到达前MGR接管，否则看门狗复位
* 修改日期        版本号     修改人          修改内容
* -----------------------------------------------
* 2015-10-22       V1.0       00086970             创建
***********************************************************************/
ULONG BootWatchDogInit()
{
    ULONG ulRet = BSP_OK;
    #ifndef CONFIG_A9606_BOARD /* A9606烧录板无CPLD */
    ulRet = BootSetWatchDogTime(100);
    BootWatchDogEnable();
    #endif
    return ulRet;
}
/*dpll cs_ctrl by niuyanru add @2019-5-13*/
void BootSetDpllCs(unsigned char ucEn)
{
    return;
}
/*dpll rst_crtl by niuyanru add @2019-7-12*/
void BootSetDpllRst(void)
{
    unsigned char temp=0;

    /*rst dpll chip*/
    cpld_read(CPLD_DEV_RST_REG,&temp);

    temp |= 0x02;
    cpld_write(CPLD_DEV_RST_REG,temp);
    BootSysMsDelay(500);
    temp &= ~0x02;
    cpld_write(CPLD_DEV_RST_REG,temp);
    BootSysMsDelay(500);
    temp |= 0x02;
    cpld_write(CPLD_DEV_RST_REG,temp);    
    return;
}
/**********************************************************************
* 函数名称:ULONG BootGetMiiLinkStatus()
* 功能描述:获取debug网口连通状态
* 输入参数:
* 输出参数:
* 返 回 值:0:连通，1:断开 ;BSP_ERROR:失败
* 其它说明:用于检测debug网口的物理链路通断状态
* 修改日期        版本号     修改人          修改内容
* -----------------------------------------------
* 2015-10-22       V1.0       00086970             创建
***********************************************************************/ 
ULONG BootGetMiiLinkStatus(VOID)
{
    struct ifreq ifr;
    int ret;
    int sockfd;
    memset(&ifr, 0, sizeof(ifr));
    strncpy(ifr.ifr_name,"eth0", IFNAMSIZ - 1);
    sockfd = socket(PF_LOCAL, SOCK_DGRAM, 0);
    reteck(sockfd);
    ret = ioctl(sockfd,SIOCGIFFLAGS, (char*)&ifr);
    ret_check(ret, sockfd);
    zte_printf_s("\nifr_flags: 0x%x\n",ifr.ifr_flags);
    close(sockfd);
    if(ifr.ifr_flags & IFF_RUNNING)	
    {
        zte_printf_s("Link Status:is Running\n");	
        return 0;
    }
    else
    {
        zte_printf_s("Link Status:is Down\n");	
        return 1;		
    }

}
/*****************************************************************************
*  函数名称   : OpenKdaModel
*  功能描述   : 打开KDA模块，并初始化全局文件描述符
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : 无
*  输出参数   : 无
*  返 回 值   : 
*  其它说明   : 
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A), 10242265@2019-04-10      创建
*----------------------------------------------------------------------------
*/
unsigned char GetAppId (void);
#define KDA_DEVICE_NAME "/dev/misc/KernDrvAgt"
static int g_iKdaDrvFd = -1;
ULONG OpenKdaModel(void)
{
    int ret;
    BspMknod(KDA_DEVICE_NAME,"c","10","244");
    if ((g_iKdaDrvFd = open(KDA_DEVICE_NAME,O_RDWR | O_SYNC )) < 0)
    {
        zte_printf_s("open " KDA_DEVICE_NAME " failed!");
        return BSP_ERROR;
    }
    if(1 == GetAppId())
    {
        return BSP_OK;
    }
    ret = BspPhyAddrToKernel((unsigned long long)BOOTAPP_LOG_PHY_ADDR, COM_INTERRUPT_NUM, g_iKdaDrvFd);
    if(ret != BSP_OK)
    {
        zte_printf_s("BspPhyAddrToKernel failed!\n");
        return BSP_ERROR;
    }
    return BSP_OK;
}

/*****************************************************************************
*  函数名称   : BootGetDdrSize
*  功能描述   : 通过命令行获取cpu使用的ddr大小
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : 无
*  输出参数   : 无
*  返 回 值   : 128:128M,256:256M
*  其它说明   : kexecboot通过mem=获取给
*          cpu使用的内存大小(不是ddr的物理大小)
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A), 00086970@2016-03-31      创建
*----------------------------------------------------------------------------
*/
ULONG BootGetDdrSize(VOID)
{
    ULONG ulMemSize = 1016;
    char acStr1[100];
    /* "console=ttyS0,115200 root=/dev/ram0 earlycon=uart8250,mmio,0x21c0500 mem=1016M" */
    zte_printf_s("g_ucCmdLine:%s\n",g_ucCmdLine);
    sscanf((char *)g_ucCmdLine, "%68s mem=%ulM", acStr1, &ulMemSize);
    zte_printf_s("\nBootGetDdrSize get ddr size = %ul\n",ulMemSize);
    if(ulMemSize >= 122)
        return (ulMemSize+6+2);/* 根据NXP高端内存规划，在保留6M高端内存之前，还预留了2M的安全区*/
    else
        return 256;/*默认512M 256M ???*/
}
/*****************************************************************************
*  函数名称   : BootDevMemMap()
*  功能描述   : 使用mmap将物理地址映射到用户进程虚拟地址空间
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : 无
*  输出参数   : 无
*  返 回 值   : BSP_OK, 其它值为失败
*  其它说明   :
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A), 田瑞忠@2010-5-19 8:52:25 创建
*  $0000000(N/A), 李耀清@2018-9-12 9:36:00 修改为NXP LS10X3A系列
*----------------------------------------------------------------------------
*/
#define DRAM_1024M          (0x40000000) 
ULONG BootDevMemMap(VOID)
{
    /* 打开内存设备的文件描述符 */
    int     iFd;
    int     iSpaceProt = PROT_READ | PROT_WRITE;
    ULONG   iCount = 0;
#define TO_MAP_LIST(a)      #a, &a
    /*lint -e529*/
    /*lint -e64*/
    struct map_list_t {
        UCHAR   *pucVarName;
        ULONG    *pulVarAddr;
        ULONG    ulMapBase;
        ULONG    ulMapSize;
    } map_list[] = {
        {TO_MAP_LIST(g_ulRamReservedAddr),(DRAM_BASE_ADDR+ DRAM_1024M -SYS_PHYS_MEM_TOP),SYS_PHYS_MEM_TOP},/* NXP各单板统一预留高端内存起始地址：1018M*/
        #ifndef CONFIG_A9606_BOARD /* A9606烧录板无CPLD */
        {TO_MAP_LIST(aulCpldAddr),CONFIG_SYS_CPLD_BASE,0x00000300},/*cpld基址的 mmap*/
        #endif
    };
    /*lint +e529*/
    /*lint +e64*/
    #define DO_ADDR_MAP(a)                                          \
        *((a)->pulVarAddr) = (ULONG)mmap(0, (a)->ulMapSize,          \
            iSpaceProt, MAP_SHARED, iFd, (a)->ulMapBase);           \
        if (*((a)->pulVarAddr) == -1)                               \
        {                                                           \
            dbgErr("mmap %s failed %s, %d\n",                       \
                (a)->pucVarName, strerror(errno), errno);           \
            close(iFd);                                             \
            return BSP_ERROR;                                       \
        }                                                           \
        dbgInfo("%-20s = %#lx.0x%lx\n", (a)->pucVarName, *((a)->pulVarAddr),(a)->ulMapBase);


    /* 打开存储空间映射 */
    if ((iFd = open("/dev/mem", O_RDWR | O_SYNC)) < 0)
    {
        dbgErr("open /dev/mem failed\n");
        return BSP_ERROR;
    }
    for (iCount = 0; iCount < sizeof(map_list)/sizeof(map_list[0]); iCount++)
    {
        DO_ADDR_MAP(&map_list[iCount]);
        usleep(1000);
    }

    close(iFd);
    return BSP_OK;
}
#if defined(CONFIG_RECORD_TIME)
 /*****************************************************************************
*  函数名称   : BootGetMemVir(*)
*  功能描述   : 获取此CPU映射的高端内存上电时间基地址
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : 无
*  输出参数   : 无
*  返 回 值   : 上电计时高端内存对应的基地址
*  其它说明   : 
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A), 李耀清@2019-1-17 16:03:00 
*----------------------------------------------------------------------------
*/
ULONG BootGetMemVir()
{
    if (NULL == g_ulRamReservedAddr)
    {
        zte_printf_s("Error: g_ulRamReservedAddr is NULL!!\n");
        return 0;
    }
    return (g_ulRamReservedAddr+SYS_PHYS_MEM_TOP-BSP_MEM_SIZE+0x8000);/*1018M+6M-512K+32K*/
}
#endif
/**********************************************************************
* 函数名称： BootGetMorS
* 功能描述： MIO14指示当前分支
* 输入参数： 无
* 输出参数： 无
* 返 回 值： 0:RGMII(FAD) 1:SGMII(5G2.0)
* 其它说明： 
* 修改日期        版本号     修改人	      修改内容
* -----------------------------------------------
* 2012/07		   V1.0	     ZKH	  
* 2018/9/12                  10242265 lyq  NXP没有实现，默认返回0   
***********************************************************************/
ULONG BootGetDownloadFlag(void)
{    
    return 0; 
}
/**********************************************************************
* 函数名称:ULONG BootGetPhyLinkStatus()
* 功能描述:获取SGMII网口连通状态
* 输入参数:
* 输出参数:
* 返 回 值:0:连通，1:断开 ;
* 其它说明:用于检测debug网口的物理链路通断状态
* 修改日期        版本号     修改人          修改内容
* -----------------------------------------------
* 2015-10-22       V1.0       00086970             创建
* 2018-11-06       V1.0       10242265          修改为NXP平台
***********************************************************************/ 
ULONG BootGetPhyLinkStatus(VOID)
{

    return BootGetMiiLinkStatus();
}
/**********************************************************************
* 函数名称： BootGetCheckFlag
* 功能描述：检测双boot校验启动标志GPIO电平
* 输入参数： 无
* 输出参数： 无
* 返 回 值： 无
* 其它说明：
* 修改日期        版本号     修改人	      修改内容
* -----------------------------------------------
* 2012/07		   V1.0	     ZKH
***********************************************************************/
int BootGetFileFlag(void)
{
    FILE * fp;
    fp = fopen("/ata/BootTestFlag","r");
    if(NULL == fp)
       return 1;
    else
    {
        zte_fclose_s(fp);
        fp = NULL;
        return 0;
    }
    
}
void BootDeleteFileFlag(void)
{
    if(0 == BootGetFileFlag())
    {
        BspSystem("rm -f /ata/BootTestFlag");
    }
}
int BootGetCheckFlag(void)
{
    unsigned int uiReg=0;
    /*reading gpio data note:big-endian*/
    nxpGetGpioReg(NXP_GPIO_BANK0,GPIO_DATA_OFFSET, &uiReg);
    uiReg = SWAP32(uiReg);
    return (uiReg & (0x80000000UL >> 30))?1:0;
}
/******************************************************************************
*  函数名称   : BspLedCtrl(*)
*  功能描述   : 实现对面板灯的控制
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : ulLedName   - 灯名, 定义于BspPublic.h文件或者BoardApi.h文件
                ulLedMode - 灯状态的控制
*  输出参数   : 无
*  返 回 值   : BSP_OK, 操作成功; BSP_ERROR_INVALID_PARA, 输入参数错误
*  其它说明   : 无
*  函数属性   : 基础接口
 *工装使用申明: 工装使用接口，请注意波及
*------------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A), 鲁侃@2010-06-21 17:28:12 创建
*  $0000000(N/A), 王茂金@2010-10-28 9:48:11 根据实际硬件和统一接口要求修改代码
*  $0000000(N/A), 崔文会@2011-01-25 9:48:11 根据实际硬件和统一接口要求修改代码
*  $0000000(N/A), 李耀清@2018-11-13 14:42:00 修改，NXP 使用EPLD控灯，保留接口
*------------------------------------------------------------------------------
*/
ULONG BootLedCtrl(ULONG ulLedname, ULONG ulLedMode)
{
    /* Started by AICoder, pid:94202db7e5l1d5c14e59094070fcff1f63e382cb */
    return BSP_OK;
    /* Ended by AICoder, pid:94202db7e5l1d5c14e59094070fcff1f63e382cb */
}

/*remove by lyq 2018-11-13 NXP 灯控移到EPLD完成，BootApp不需要运行此任务
 */
VOID BootLedBling(VOID)
{
    ;
}

VOID BootLedTask(VOID)
{
   ;
}

/**********************************************************************
* 函数名称:void led_run(unsigned char ucMode)
* 功能描述:led_run led灯闪烁模式
* 输入参数: ucMode  0 只亮run灯,  1 run灯周期性闪
* 输出参数:无。
* 返 回 值:无
* 其它说明: dpdic led 使用情况:
GPIO 14 -- RUN
GPIO 15 -- ALM
GPIO 16 --OPT0
GPIO 17 -- OPT1
GPIO 19 --VSWR
GPIO 20 -- ACT
* 修改日期        版本号     修改人          修改内容
* -----------------------------------------------
* 2015/10/12            V1.0            00086970                       创建
* 2018/11/13            V1.0            10242265                       修改，NXP使用cpld控灯，这里bootapp启动，以及工装时需要调用到。
***********************************************************************/
VOID BootLedRun(UCHAR ucMode)
{
    static unsigned char flag =0xff;
    unsigned char temp = 0x00;
    if(0xff==flag)
    {
       #ifdef CONFIG_NXP_DEMO_BOARD /* 非标模老版EPLD */
       /* 默认RUN慢闪[7..4]（CPLD控制模式），ALM灯[3..0]为CPU控灯模式*/
       cpld_write(CPLD_LED_RUN_ALM,0x30);
       /*除RUN灯为CPLD模式外其他灯在CPU控灯模式下，全部灭*/
       temp = 0xff;
       cpld_write(CPLD_LED_CPU_CTL0,temp);
       cpld_write(CPLD_LED_CPU_CTL1,temp);
       /*除RUN灯外，其他全部使能CPU控灯模式*/
       temp = 0x00;
       cpld_write(CPLD_LED_OPT0_OPT1,temp);
       cpld_write(CPLD_LED_OPT2,temp);
       cpld_write(CPLD_LED_RGPS,temp);
       #elif defined(CONFIG_A9606_BOARD)
       /*烧写板无CPLD版本先不控灯*/
       #else /*新版CPLD 标模 RUN灯CPLD模式慢闪，其他灯灭*/
       cpld_write(CPLD_LED_REG,0x02);
       cpld_write(CPLD_LED_REG_EX,0x00);
       #endif
       flag = 0x00;
    }
}

ULONG BootGpioInit(VOID)
{
    unsigned char i = 0;
    ULONG ulRet = BSP_ERROR;
    /*bank 0 ~ 3*/
    for(i = 0; i <= NXP_GPIO_BANK_MAX ; i++)
    {
        ulRet = nxpGpioMmap(i);
        if(BSP_ERROR == ulRet)
           return ulRet;
    }
    BspNxpSetGpioDir(NXP_GPIO_BANK0,30,NXP_GPIO_DIR_IN);/*双Boot校验使用的GPIO1_30（对应BANK0）,输入，注意这里只设置输入输出，没有配 推挽 or 开漏*/
    /* appid */
    BspNxpSetGpioDir(NXP_GPIO_BANK0,GPIO_APPID_0,NXP_GPIO_DIR_IN);
    BspNxpSetGpioDir(NXP_GPIO_BANK0,GPIO_APPID_1,NXP_GPIO_DIR_IN);
    BspNxpSetGpioDir(NXP_GPIO_BANK0,GPIO_APPID_2,NXP_GPIO_DIR_IN);
    /* dramid */
    BspNxpSetGpioDir(NXP_GPIO_BANK0,GPIO_DRAMID_0,NXP_GPIO_DIR_IN);
    BspNxpSetGpioDir(NXP_GPIO_BANK0,GPIO_DRAMID_1,NXP_GPIO_DIR_IN);
    BspNxpSetGpioDir(NXP_GPIO_BANK0,GPIO_DRAMID_2,NXP_GPIO_DIR_IN);

    return ulRet;
}


/*****************************************************************************
*  函数名称   : BootBoardHwPreInit()
*  功能描述   : Bsp单板预初始化函数
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : 无
*  输出参数   : 无
*  返 回 值   : BSP_OK, 其它值为失败
*  其它说明   : 无
 *工装使用申明: 无
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A), 崔文会@2012-11-22 16:35:09, 创建
*----------------------------------------------------------------------------
*/
ULONG BootBoardHwPreInit(VOID)
{
    ULONG ulRet = BSP_OK;
    ulRet|=BootGpioInit();            /*双boot校验GPIO初始化*/
    BootLedRun(0);
    return ulRet;
}

/**************************************************************************
* 函数名称： SetEthProMode
* 功能描述： 设置ETH的模式寄存器的混杂模式控制位
* 输入参数： 0--对进入的帧的目的地址进行检查。1--对进入的帧的目的地址不进行检查。
* 输出参数： 无
* 返 回 值： 
* -------------------------------------------------------
* 其它说明： 
* 修改日期     版本号        修改人	            修改内容
* 2015/10/22     V1.0         00086970           创建
* 2018/9/27                   10242265          修改为IOCTL形式控制网口
/**************************************************************************/
ULONG SetEthProMode(UCHAR ucValue)
{ 
    ULONG ulRet=0; 
    int sockfd;	
    struct ifreq ifr;
    memset(&ifr, 0, sizeof(ifr));
    strncpy(ifr.ifr_name,"eth0", IFNAMSIZ - 1);
    sockfd = socket(PF_LOCAL, SOCK_DGRAM, 0);
    reteck(sockfd);
    ulRet=ioctl(sockfd, SIOCGIFFLAGS, &ifr);
    ret_check(ulRet, sockfd);
    if (ucValue == 0)
    /*对进入的帧的目的地址进行检查*/
    {
       ifr.ifr_flags &= ~IFF_PROMISC;
    }
    /*对进入的帧的目的地址不进行检查*/
    else
    {        
        ifr.ifr_flags |= IFF_PROMISC;
    }
    
    ulRet=ioctl(sockfd, SIOCSIFFLAGS, &ifr); 
    ret_check(ulRet, sockfd);
    close(sockfd);
    return ulRet;
     
}
ULONG BootBoardPreInit(VOID)
{
    ULONG ulRet = BSP_OK;
    zte_printf_s("\n BootBoardPreInit. \n");
    /*
    cmdline装载
    ulRet = GetCmdline();
    if(BSP_ERROR == ulRet)
    {
        SetDefaultCmdline();
    }
    */
    ulRet |= BootDevMemMap(); /*物理地址到虚拟地址映射，高端内存、看门狗映射*/
    ulRet |= BootBoardHwPreInit();  /*LED初始化、GPIO BANK映射*/
    ulRet |= OpenKdaModel();  /*打开Kda设备，初始化设备描述符*/
    ulRet |= BootFlashInit();
    return ulRet;
     
}

ULONG memflag_set(ULONG writeval)
{

    return 0;
}

ULONG bootflag_get()
{
    return 0;
}

 VOID boot_flag_set()
{
     ;
}

/**********************************************************************
* 函数名称:BootDebugMiiRead
* 功能描述:通过内核Kda驱动读PHY C22
* 输入参数: *  - udCsrClockRange：CSR 时钟区域
 *     - udGR： GMII寄存器
 *     - udPA： PHY设备物理层地址
 *     - pudData：需要读出的数据的地址
* 输出参数:
* 返 回 值:
* 其它说明:
* 修改日期        版本号     修改人          修改内容
* -----------------------------------------------
* 2019-4-19       V1.0      lyq             创建
***********************************************************************/
ULONG BootDebugMiiRead(ULONG ulCsrClockRange,ULONG ulGR, ULONG ulPA, ULONG *pulData)
{
    if(g_iKdaDrvFd < 0)
    {
        zte_printf_s("Kda device is not open!!\n");
        return BSP_ERROR;
    }
    kda_ioctl_t mdio = {0};
    mdio.d0 = ulPA;
    mdio.d1 = ulGR;
    if (ioctl(g_iKdaDrvFd, KDA_MDIO_READ_COMMON, &mdio))
    {
        zte_printf_s("KDA_MDIO_READ_COMMON ioctrl error!!!\n");
        return BSP_ERROR;
    }
    *pulData = (unsigned int)mdio.d2;
    return BSP_OK;
}
/**********************************************************************
* 函数名称:BootDebugMiiWrite
* 功能描述:通过内核Kda驱动写PHY C22
* 输入参数: *     - udCsrClockRange：CSR 时钟区域
 *     - udGR： GMII寄存器
 *     - udPA： PHY设备物理层地址
 *     - pudData：需要读出的数据的地址
* 输出参数:
* 返 回 值:
* 其它说明:
* 修改日期        版本号     修改人          修改内容
* -----------------------------------------------
* 2019-4-19       V1.0      lyq             创建
***********************************************************************/
ULONG BootDebugMiiWrite(ULONG ulCsrClockRange,ULONG ulGR, ULONG ulPA, ULONG ulValue)
{
    if(g_iKdaDrvFd < 0)
    {
        zte_printf_s("Kda device is not open!!\n");
        return BSP_ERROR;
    }
    kda_ioctl_t mdio = {0};
    mdio.d0  =  ulPA;
    mdio.d1  =  ulGR;
    mdio.d2  =  ulValue;
    if (ioctl(g_iKdaDrvFd, KDA_MDIO_WRITE_COMMON, &mdio))
    {
        zte_printf_s("KDA_MDIO_WRITE_COMMON ioctrl error!!!\n");
        return BSP_ERROR;
    }
    return BSP_OK;
}

/*delete by lyq*/
unsigned int UpdateFirstBoot(void)
{
    return BSP_OK;
}

/**********************************************************************
* 函数名称： BootGetFsRecoverFlag
* 功能描述： 从高端内存获取用户态文件系统异常标志
* 输入参数： 无
* 输出参数： 无
* 返 回 值： 0:正常 0xdeadbeaf:异常
* 其它说明： 获取后清除 
* 修改日期        版本号     修改人	      修改内容
* -----------------------------------------------
* 2012/07		   V1.0	     ZKH	      
***********************************************************************/
ULONG BootGetFsRecoverFlag(VOID)
{
    ULONG ulUbifsFormat_mask = 0;
    ulUbifsFormat_mask = *(ULONG *)FS_FORMAT_FLAG;
    memset((CHAR*)FS_FORMAT_FLAG, 0, 4);/* 清空 */
    return ulUbifsFormat_mask;
}
/**********************************************************************
* 函数名称：BootGetVersion
* 功能描述： 读取Flash中boot版本号
* 输入参数： headPtr需要获取到版本的指针，默认不使用，除非传入非空指针，model:0 获取一级Boot版本，1 获取二级keboot版本
* 输出参数： 无
* 返 回 值： 0:正常  非0:异常
* 其它说明： 获取后清除
* 修改日期        版本号     修改人	      修改内容
* 修改日期     版本号        修改人	            修改内容
* ---------------------------------------------------
* 2015/10/22     V1.0         10242265           创建
***********************************************************************/
ULONG BootGetVersion(char *headPtr,char model)
{
     ULONG ulRet=0;
     ULONG HEAD_ADDR=0;
     unsigned char  *ptVerFileHeadChar = NULL;
     T_VerFileHeader *ptVerFileHeader = NULL;
     if(NULL==headPtr)
     {
         return BSP_ERROR;
     }
     ptVerFileHeadChar = (unsigned char *)malloc(sizeof(T_VerFileHeader));
     if (NULL == ptVerFileHeadChar)
     {
         zte_printf_s("malloc error!!\n");
         return -1;
     }
     if(0==model)
     {
         HEAD_ADDR=UBOOT_HEAD_ADDR;
     }
     else
     {
         HEAD_ADDR=KEBOOT_START_ADDR;
     }
     /*从启动地址读取版本头到ptVerFileHeadChar*/
     ulRet=BspFlashRead(HEAD_ADDR, ptVerFileHeadChar,sizeof(T_VerFileHeader));
     if(BSP_OK==ulRet)
     {
         ptVerFileHeader = (T_VerFileHeader *)ptVerFileHeadChar;
         ptVerFileHeader->ucVerNo[44-1]='\0';
         memcpy(headPtr,ptVerFileHeader->ucVerNo,strlen(ptVerFileHeader->ucVerNo)+1);
     }
     else
     {
         zte_printf_s("\nRead BOOT Header error!\n");
     }
     free(ptVerFileHeadChar);
     ptVerFileHeadChar = NULL;
     ptVerFileHeader = NULL;
     return ulRet;
}

#ifndef CONFIG_A9606_BOARD /* A9606烧录板无CPLD */
/**********************************************************************
* 函数名称： CheckBootVer(char *buf,unsigned char flash_index)
* 功能描述： 检测主片当前运行BOOT版本号和bootcheck.txt是否一致
            (减少圈复杂度，配合CheckFileError使用，其他勿动)
* 输入参数： 文件名
* 输出参数： 检测结果标志
* 返 回 值：0：一致或者不是主片Flash时默认返回0，其他：主片版本号不一致
* 修改日期        版本号     修改人	      修改内容
* ---------------------------------------------------
* 2019/06/03     V1.0         10242265           创建
***********************************************************************/
unsigned char CheckBootVer(char *buf,unsigned char flash_index)
{
    unsigned char ret = 0;
    char bootver[44]={'0'};
    if(flash_index || NULL == buf)    //only check master flash BootVer otherwise return same [0]
        return ret;    //do not remove this check and default ret value

    //只检查大片（flash_index =0）从高端内存中，读取keboot版本头
    BspGetBootSoftVersion(bootver, 44);//get current bootver 
    if(0 != strncmp(buf,bootver,strlen(bootver)))
    {
        zte_printf_s("old version:%44s\n",buf);
        zte_printf_s("run version:%44s\n",bootver);
        ret = 0xFF;   
    }
    return ret;
}
/**********************************************************************
* 函数名称：CheckFileError(filename)
* 功能描述： 检测文件中是否含有某些字段及文件函数
* 输入参数： 文件名
* 输出参数： 检测结果标志
* 返 回 值：flag:bit7~bit4:文件行数  bit1:是否含有Flash:1字段，bit0:是否含有Flash:0字段
*       e.g flag==0x23:文件完整，flag==0x11:文件只有一行，且为Flash:0字段，
            flag==0x00文件不存在或者主片实际运行boot版本和校验文件不一致，重新触发校验。
            其他均为异常错误。
* 修改日期        版本号     修改人	      修改内容
* ---------------------------------------------------
* 2018/12/05     V1.0         10242265           创建
***********************************************************************/
#define CHECKFILE "/ata/bootcheck.txt"
unsigned char CheckFileError(unsigned char flash_index)
{
    unsigned char flag=0x00;
    FILE *fd =0;
    char buf[60]={'0'};/*strlen("Flash:x bootVer:")+44;*/
    fd=fopen(CHECKFILE,"r");
    if(NULL==fd)
    {
        flag=0x00;
    }
    else
    {
        /*按行读取文件*/
        while(fgets(buf,60,fd)!= NULL )
        {
            flag += 0x10;
            /*限制记录两行，超出返回错误*/
            if(flag>0x23)
            {
                flag=0xff;//error
                break;
            }
            if(0 == strncmp(buf,"Flash:0",strlen("Flash:x")))
            {
                flag |= 0x01;
                /*大片继续检查版本号是否一致,注意：只有flash_index=0才去真正检查*/
                if(0 != CheckBootVer(buf+strlen("Flash:x bootVer:"),flash_index))
                {
                    flag=0x00; //reset flag to 0x00 to restart bootcheck
                    break;
                }
            }
            else if(0 == strncmp(buf,"Flash:1",strlen("Flash:x")))
            {
                flag |= 0x02;
            }
            else
            {
                flag = 0xff;//error
                break;
            }
        }
        zte_fclose_s(fd);
        fd=NULL;
    }

    return flag;
}
/**********************************************************************
* 函数名称： CheckFileWrite()
* 功能描述： 创建boot检测文件，写入版本号
* 输入参数： 启动boot index  ,文件检测标记
* 输出参数： 无
* 返 回 值： 0:正常  非0:异常
* 其它说明： 获取后清除
* 修改日期     版本号        修改人	            修改内容
* ---------------------------------------------------
* 2019/04/04     V1.0         10242265           创建
***********************************************************************/
ULONG CheckFileWrite(unsigned char flash_index,unsigned char flag)
{
    FILE *fd =0;
    char HeaderBuf[44]={0};
    int ret = 0;
    /*大片默认创建，并清空文件内容，预防多次双boot全检，内容积累*/
    if(0==flash_index)
    {
        fd = fopen(CHECKFILE,"w");
    }
    else/*小片追加写入*/
    {
        if(0x11 == flag)/*正常文件中有 1行 ，为大片BootVer信息*/
            fd = fopen(CHECKFILE,"a");
        else /*其他情况只记录小片版本*/
            fd = fopen(CHECKFILE,"w");
    }
    if (fd == NULL)
    {
        zte_printf_s("Open %s Error!\n",CHECKFILE);
        //fclose(fd);
        return BSP_ERROR;
    }
    else
    {
        //从高端内存中，读取keboot版本头
        BspGetBootSoftVersion(HeaderBuf, 44);
        //BootGetVersion(HeaderBuf,1); 从flash中读
        zte_printf_s("Boot Version:%s\n",HeaderBuf);
        ret = fprintf(fd,"Flash:%d bootVer:%s\n",flash_index,HeaderBuf);
        FPRINTF_CHECK(ret);
        fclose(fd);
        fd=NULL;
    }
    return BSP_OK;

}
/**********************************************************************
* 函数名称：  BootRestart()
* 功能描述： 创建boot检测文件，写入版本号
* 输入参数： 无
* 输出参数： 无
* 返 回 值： 无
* 其它说明： 获取后清除
* 修改日期     版本号        修改人	            修改内容
* ---------------------------------------------------
* 2019/04/04     V1.0         10242265           创建
***********************************************************************/
void BootRestart(unsigned char flash_index,unsigned char flag)
{
    unsigned char temp=0;
    if(0 == flash_index)
    {
        /*写1到b.0优先切小片启动*/
        cpld_read(CPLD_BOOT_SELECT_OFFSET,&temp);
        temp|=0x01;
        cpld_write(CPLD_BOOT_SELECT_OFFSET,temp);
        zte_printf_s("Now reboot system...\n");
        BootBoardSetReset(0,0);
    }
    else
    {
        /*小片启动后恢复默认大片优先启动，否者不掉电一直是小片优先启动*/
        cpld_read(CPLD_BOOT_SELECT_OFFSET,&temp);
        temp&=~0x01;
        cpld_write(CPLD_BOOT_SELECT_OFFSET,temp);
        zte_printf_s("Boot Check done!\nResult write in: %s\n\n",CHECKFILE);
        BootDeleteFileFlag();
    }
    
}
/**********************************************************************
* 函数名称： BootCheckFile()
* 功能描述： 创建boot检测文件，检测主、从Flash中boot是否完好，且版本一致
* 输入参数： 无
* 输出参数： 无
* 返 回 值： 0:正常  非0:异常
* 其它说明： 获取后清除
* 修改日期        版本号     修改人	      修改内容
* 修改日期     版本号        修改人	            修改内容
* ---------------------------------------------------
* 2015/10/22     V1.0         10242265           创建
***********************************************************************/
ULONG BootCheckFile(VOID)
{
    unsigned char temp=0;
    unsigned char flag=0x00;
    /*记录当前Boot启动区域*/
    unsigned char flash_index=0;
    if((0 == BootGetCheckFlag())||(0 == BootGetFileFlag()))//GP1_30 || ata/BootTestFlag
    {
        cpld_read(CPLD_BOOT_STATUS_OFFSET,&temp);
        flash_index = (temp&0x80)?1:0;
        zte_printf_s("Flash Index:%d\n",flash_index);
        /*检查当前启动CHECKFILE文件情况*/
        flag = CheckFileError(flash_index);
        zte_printf_s("check %s flag:0x%x\n",CHECKFILE,flag);
        if(0x23 != flag)
        {
            zte_printf_s("\nNOTE:Boot Checking.....\n");
            if(BSP_ERROR==CheckFileWrite(flash_index,flag))
            {
                BootDeleteFileFlag();
                return BSP_ERROR;
            }
            else
                BootRestart(flash_index,flag);
        }
        else
        {
            BootDeleteFileFlag();
        }
        
    }
    return BSP_OK;
}

/**************************************************************************
* 函数名称： cpld
* 功能描述： 显示bootapp支持有关cpld 相关命令的使用方法
* 输入参数： void
* 输出参数： 无
* 返 回 值：
* ------------------------------------------------------
* 其它说明：
* 修改日期     版本号     修改人	     修改内容
* 2018/10/18         V1.0              10242265                     创建
**************************************************************************/
ULONG cpld(void)
{
    zte_printf_s("cpld help:\n");
    zte_printf_s("GetMsBoot  - display boot location\n");
    zte_printf_s("SwitchFlash index - switch flash[0/1]\n");
    zte_printf_s("rdcpld regAddr - read Data from cpld at regAddr\n");
    zte_printf_s("wrcpld regAddr,Value - write Value to cpld at regAddr\n");
    return BSP_OK;
}
/**************************************************************************
* 函数名称： GetMsBoot
* 功能描述：指示当前从哪个Flash 启动 0大片 1小片
* 输入参数：无
* 输出参数： 无
* 返 回 值：
* ------------------------------------------------------
* 其它说明：
* 修改日期     版本号     修改人	     修改内容
* 2018/11/03         V1.0              10242265                     创建
**************************************************************************/
ULONG GetMsBoot(void)
{
    unsigned char temp=0;
    cpld_read(CPLD_BOOT_STATUS_OFFSET,&temp);
    temp = (temp&0x80)?1:0;
    zte_printf_s("NOTE:master flash:0, slave flash:1\n");
    zte_printf_s("Boot from flash:%d\n",temp);
    return BSP_OK;
}
/**************************************************************************
* 函数名称： SwitchFlash
* 功能描述：cpld切换大、小片Flash
* 输入参数：无
* 输出参数： 无
* 返 回 值：
* ------------------------------------------------------
* 其它说明：
* 修改日期     版本号     修改人	     修改内容
* 2018/10/18         V1.0              10242265                     创建
**************************************************************************/
ULONG SwitchFlash(unsigned char index)
{
    unsigned char temp=0;
    zte_printf_s("NOTE:master flash:0, slave flash:1");
    if(0 == index)
    {
         cpld_read(CPLD_BOOT_SELECT_OFFSET,&temp);
         temp&=~0x80;
         cpld_write(CPLD_BOOT_SELECT_OFFSET,temp);
    }
    else if(1 == index)
    {
         cpld_read(CPLD_BOOT_SELECT_OFFSET,&temp);
         temp|=0x80;
         cpld_write(CPLD_BOOT_SELECT_OFFSET,temp);
    }
    else
    {
       zte_printf_s("\ncmd error,please check!!\n");
       return BSP_ERROR;
    }
    zte_printf_s("\nset cpld flash index:%d OK!! please reboot system...\n",index);
    return BSP_OK;
}
/**************************************************************************
* 函数名称： wrcpld
* 功能描述：cpld读命令
* 输入参数：cpld内部寄存器地址，写入的值
* 输出参数： 无
* 返 回 值：
* ------------------------------------------------------
* 其它说明：
* 修改日期     版本号     修改人	     修改内容
* 2018/11/03         V1.0              10242265                     创建
**************************************************************************/
ULONG wrcpld(unsigned char uiOffset, unsigned char uiValue)
{
    unsigned char temp=0;
    cpld_write(uiOffset,uiValue);
    cpld_read(uiOffset,&temp);
    if(temp!=uiValue)
    {
        zte_printf_s("cpld_write_reg:0x%x Error!!!\n",uiOffset);
        return BSP_ERROR;
    }
    return BSP_OK;
}
/**************************************************************************
* 函数名称： rdcpld
* 功能描述：cpld读命令
* 输入参数：cpld内部寄存器地址(并非绝对地址)，写入的值
* 输出参数： 无
* 返 回 值：
* ------------------------------------------------------
* 其它说明：
* 修改日期     版本号     修改人	     修改内容
* 2018/11/03         V1.0              10242265                     创建
**************************************************************************/
ULONG rdcpld(unsigned char uiOffset)
{
    unsigned char temp=0;
    cpld_read(uiOffset,&temp);
    zte_printf_s("reg:0x%x data:0x%x\n",uiOffset,temp);
    return BSP_OK;
}
/**************************************************************************
* 函数名称： GetAppID
* 功能描述： 获取单板上下拉的IO电平
* 输入参数： 无
* 输出参数： appid的值
* 返 回 值：
* ------------------------------------------------------
* 其它说明：
* 修改日期     版本号     修改人	     修改内容
* 2018/11/03         V1.0                                  创建
**************************************************************************/
unsigned char GetAppId (void)
{
    static unsigned char ucAppId = 0xFF;
#if defined(CONFIG_NXP_DEMO_BOARD) || defined(CONFIG_A9606_BOARD)
    return 0x0;
#endif
    if(0xFF == ucAppId)
    {
        ucAppId = (unsigned char)BspNxpGetGpioDatain(NXP_GPIO_BANK0,GPIO_APPID_0);
        ucAppId |= (unsigned char)BspNxpGetGpioDatain(NXP_GPIO_BANK0,GPIO_APPID_1)<<1;
        ucAppId |= (unsigned char)BspNxpGetGpioDatain(NXP_GPIO_BANK0,GPIO_APPID_2)<<2;
        zte_printf_s("AppId = %d\n", ucAppId);
    }
    return ucAppId;
}

/* 0 - 2GB,8Gbit(x16) x 2
 * 1 - 1GB,8Gbit(x16)
 */
unsigned char GetDramId (void)
{
    static unsigned char ucDramId = 0xFF;
#if defined(CONFIG_NXP_DEMO_BOARD)
    return 0x0;
#elif defined(CONFIG_A9606_BOARD)
    return 0x1;
#endif
    if(0xFF == ucDramId)
    {
        ucDramId = (unsigned char)BspNxpGetGpioDatain(NXP_GPIO_BANK0, GPIO_DRAMID_0);
        ucDramId |= (unsigned char)BspNxpGetGpioDatain(NXP_GPIO_BANK0, GPIO_DRAMID_1)<<1;
        ucDramId |= (unsigned char)BspNxpGetGpioDatain(NXP_GPIO_BANK0, GPIO_DRAMID_2)<<2;
        zte_printf_s("DramId = %d\n", ucDramId);
    }
    return ucDramId;
}
/**************************************************************************
* 函数名称： ls10x3a_is_config
* 功能描述： 匹配相应Appid DramId的单板
* 输入参数： 需要查找匹配的单板类型
* 输出参数： 是否匹配：0 - 不匹配   1 - 匹配
* 返 回 值：
* ------------------------------------------------------
* 其它说明：
* 修改日期     版本号     修改人	     修改内容
* 2018/11/03         V1.0                                  创建
**************************************************************************/
#if (defined(CONFIG_NXP_DEMO_BOARD) ||  defined(CONFIG_A9606_BOARD))
int ls10x3a_is_config(enum e_ls10x3a_module_cfg_t ls10x3a_module )
{
    return 0;
}
#else
int ls10x3a_is_config(enum e_ls10x3a_module_cfg_t ls10x3a_module )
{
    int iRet = 0;
    int appid = 0;
    int dramid = 0;
    appid = GetAppId();
    dramid = GetDramId();
    switch(ls10x3a_module)
    {
        case BOARD_NR30:
            if((0x0 == appid) && (0x0 == dramid)) iRet = 1;
            if((0x2 == appid) && (0x0 == dramid)) iRet = 1;
            break;
        case BOARD_NR30_NETMUX:
            if((0x2 == appid) && (0x0 == dramid)) iRet = 1;
            break;
        case BOARD_R9606:
            if((0x1 == appid) && (0x1 == dramid)) iRet = 1;
            break;
        default:
            break;
    }
     return iRet;
}
#endif 

/**************************************************************************
* 函数名称： get_uart_rx_byte
* 功能描述： 获取/proc/tty/driver/serial 中rx的值，得到串口累积输入
* 输入参数： 无
* 输出参数： 串口累积rx
* 返 回 值：
* ------------------------------------------------------
* 其它说明：
* 修改日期     版本号     修改人	     修改内容
* 2018/11/03         V1.0                                  创建
**************************************************************************/
unsigned int get_uart_rx_byte()
{
    char *line = NULL;
    FILE *fp = NULL;
    char *index = NULL;
    unsigned int value_curr = 0;
    unsigned int len = 0;
    fp = fopen("/proc/tty/driver/serial","r");
    if(fp ==  NULL)
    {
        zte_printf_s("open /proc/tty/driver/serial error\n");
        return 0;
    }
    while((getline(&line,&len,fp)) != -1)
    {
        index = strstr(line,"rx:");
        if(index != NULL)
        {
            sscanf_s((char *)(index+strlen("rx:")),"%d",&value_curr);
            break;
        }
    }
    zte_fclose_s(fp);
    return value_curr;
}
/**************************************************************************
* 函数名称： BootGetUartCom\BootSwitchUartCom\BootSetGpsPower\
* 功能描述： 操作EPLD寄存器，最好按bit操作，有些保留的寄存器后续可能会有意义。
* 输入参数： 无
* 输出参数： 
* 返 回 值：
* ------------------------------------------------------
* 其它说明：
* 修改日期     版本号     修改人	     修改内容
* 2020/06/16         V1.0                                  创建
**************************************************************************/
unsigned char BootGetUartCom(void)
{
    unsigned char tmp = 0;
    cpld_read(CPLD_SWITCH_UART_OFFSET,&tmp);
    return tmp&0x01;
}

void BootSwitchUartCom(int index)
{
    unsigned char tmp = 0;
    cpld_read(CPLD_SWITCH_UART_OFFSET,&tmp);
    /*0: RGPS port  1: Debug uart port*/
    switch(index)
    {
        case STATUS_GPS_UART: //gps com
        tmp &=~0x01;
        break;
        case STATUS_DBG_UART: //default uart com
        tmp |= 0x01;
        break;
        default:
        zte_printf_s("%s line:%d ERROR\n",__FILE__,__LINE__);
        return;
    }
    BootSysMsDelay(5);// wait previous log zte_printf_s done
    wrcpld(CPLD_SWITCH_UART_OFFSET,tmp);
    BootSysMsDelay(5);// delay for next log zte_printf_s 
}

void BootSetGpsPower(unsigned char flag)
{
    unsigned char gps_power = 0;
    /*0: Power Down 1：gps power set to default*/
    cpld_read(CPLD_GPS_AISG_RST_OFFSET,&gps_power);
    switch(flag)
    {
        case GPS_POWER_OFF: //gps power down
        gps_power &=~0x01; 
        break;
        case GPS_POWER_ON: //ggps power set to default
        gps_power |= 0x01; //gps power set to default
        break;
        default:
        zte_printf_s("%s line:%d ERROR\n",__FILE__,__LINE__);
        return;
    }
    wrcpld(CPLD_GPS_AISG_RST_OFFSET,gps_power);
}

/**************************************************************************
* 函数名称： BootAttachUartCom
* 功能描述： 探测GRPS 串口是否有数据
* 输入参数： 无
* 输出参数： 探测到有持续输入：返回BSP_OK ,否者返回BSP_ERROR
* 返 回 值：
* ------------------------------------------------------
* 其它说明：
* 修改日期     版本号     修改人	     修改内容
* 2018/11/03         V1.0                                  创建
**************************************************************************/
/* Started by AICoder, pid:p68a2155ebed3411420b0b9860aa943513791565 */
ULONG BootAttachUartCom()
{
    unsigned long long delay_tick = 0;
    unsigned long long delay_start = tick64Get();
    unsigned int base_count = 0;
    unsigned int abort_count=0;
    if(0 == ls10x3a_is_config(BOARD_NR30_NETMUX)) //is not A9641A+
        return BSP_ERROR;
    BootSetGpsPower(GPS_POWER_OFF); //gps power down
    /*0: RGPS port  1: Debug uart port*/
    BootSwitchUartCom(STATUS_GPS_UART);
    base_count = get_uart_rx_byte();
    do{
            //zte_printf_s("\r  Hit any key to enter uart console [GPS Com:%d/20]\r  ",abort_count);
            //fflush(stdout);
            delay_tick = (tick64Get() - delay_start) * 10;
            BootSysMsDelay(10);
            abort_count = get_uart_rx_byte()-base_count;
            if(abort_count >= 15)
              {
                /* Started by AICoder, pid:79e025c0b7sf4bc1472a09b300a90b0e3605a5a7 */
                zte_printf_s("\n Please enter bs\n\n");
                /* Ended by AICoder, pid:79e025c0b7sf4bc1472a09b300a90b0e3605a5a7 */
                BootSetGpsPower(GPS_POWER_ON);//gps power up
                return BSP_OK;
            }
    } while(delay_tick <= 1000ULL);
    zte_printf_s("\n\n");
    /*0 RGPS port 1:  Debug uart port */
    BootSwitchUartCom(STATUS_DBG_UART);//restory defaule uart
    BootSetGpsPower(GPS_POWER_ON);//gps power up
    return BSP_ERROR;
}
/* Ended by AICoder, pid:p68a2155ebed3411420b0b9860aa943513791565 */
const char randombuf[]={34,36,38,60,37,62,37,96,94,58,61,61,126,58,64,34,63,63,94,35,0,0};/* "$&<%>%`^:==~:@"??^# */

void BootPrintNoteMesgOnce()
{
    static char lock=0;
    if(0 == ls10x3a_is_config(BOARD_NR30_NETMUX)) //is not A9641A+ 
        return ;
    if(0==lock)
    {
        BootSetGpsPower(GPS_POWER_OFF);//gps power down
        /*0: RGPS port  1: Debug uart port*/
        BootSwitchUartCom(STATUS_GPS_UART);
        zte_printf_s("%s\n",randombuf);
        /*0 RGPS port 1:  Debug uart port */
        BootSwitchUartCom(STATUS_DBG_UART);//restory defaule uart
        BootSetGpsPower(GPS_POWER_ON);//gps power up
        lock = 1;
    }
}

ULONG getLastKmsgAddr(VOID)
{
    return LAST_KMSG_ADDR;
}

ULONG getAppLogPhyAddr(VOID)
{
    return APP_LOG_PHY_ADDR;
}

ULONG BootFlagGet()
{
    ULONG readval;
    readval = readb(aulCpldAddr + CPLD_BOOT_STATUS_OFFSET);
    return readval;
}

UINT32 BootGetBoardHwResetType(VOID)
{
    UINT32 ret = 0;
    ret = readb(aulCpldAddr + CPLD_HW_EVENT);
    return ret;
}

UINT32 BootGetBoardSwResetType(VOID)
{
    UINT32 ret = 0;
    ret = readb(aulCpldAddr + CPLD_SW_EVENT);
    return ret;
}

UCHAR* BootGetBoardResetInfoAddr(VOID)
{
    return (g_ulRamReservedAddr + RESET_INFO_ADDR);
}

VOID SaveKebootBakLog(VOID)
{
    if(1 == GetAppId())
    {
        return;
    }
    BspSaveBootKmsgLog(BAK_LOG);
    BspSaveBootAppLog(BAK_LOG);
}

VOID SaveKebootCurLog(VOID)
{
    if(1 == GetAppId())
    {
        return;
    }
    BspSaveBootKmsgLog(CUR_LOG);
    BspSaveBootAppLog(CUR_LOG);
}

/*bs住后的手动转储请用SaveKebootLog,产生4份,使每份log序号保持一致*/
VOID SaveKebootLog(VOID)
{
    if(1 == GetAppId())
    {
        return;
    }
    SaveKebootBakLog();
    SaveKebootCurLog();
}
#endif

/*****************************************************************************
 *  函数名称   : main(*)
 *  功能描述   : bootapp程序处理主函数
 *  读全局变量 : 无
 *  写全局变量 : 无
 *  输入参数   : argc   - 参数个数
                 argv[] - 参数列表
 *  输出参数   : 无
 *  返 回 值   : 0为成功, 其余失败
 *  其它说明   :
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *  $0000000(N/A), 00086970 @2015-10-28
 *----------------------------------------------------------------------------
 */
int main(int argc, char *argv[])
{
    int iBootAppTaskID = 0;
    ULONG ulRet = 0;  
    unsigned char ucTimeout = 5;  
    ulRet |= BootBoardPreInit();
    ulRet |= BootWatchDogInit();
    ulRet |= (ULONG)ushell_init();
    ulRet |= BootSoftModInit();
    while (ucTimeout)
    {
        if(0 == BootGetPhyLinkStatus())
        {
            break;
        }
        ucTimeout--;
        sleep(1);
        BootPrintNoteMesgOnce();
    }

    iBootAppTaskID = taskSpawn("tBootTask",   \
        100, /* priority */            \
        0,   /* option   */           \
        0x1000,/* stack size */      \
        (FUNCPTR)MainLoop, 0, 0, 0, 0, 0, 0, 0, 0 ,0,0);
    
    while(1)
    {
       //BspFunction("/boot.out", CFG_PROMPT);
       sleep(20);
    }
    return ulRet;

}
#endif

ULONG SetDefaultCmdline()
{
    /* Started by AICoder, pid:gc8ec63923ec65114fa808112037380506310eb6 */
    strncpy((char *)g_ucCmdLine,"console=ttyS0,115200 root=/dev/ram0 earlycon=uart8250,mmio,0x21c0500 mem=1016M",256);
    /* Ended by AICoder, pid:gc8ec63923ec65114fa808112037380506310eb6 */
    zte_printf_s("/proc/cmdline error,load default cmdline.\n");
    return BSP_OK;
}
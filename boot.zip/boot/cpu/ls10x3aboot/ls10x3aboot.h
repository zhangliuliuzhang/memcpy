/**************************************************************************
 * 版权所有 (C)2001, 深圳市中兴通讯股份有限公司
 *
 * 文件名称: ls10x3aboot.h
 * 文件标识:
 * 内容摘要:
 * 其它说明:
 * 当前版本: ZXSDR BBUV190B08
 * 作    者: 
 * 完成日期:
 *
 * 修改记录1:
 *    修改日期: 2019年04月10日
 *    版 本 号: ZXSDR BBUV190B08
 *    修 改 人: 李耀清
 *    修改内容: 创建
 **************************************************************************/

#ifndef _LS10X3ABOOT_H_
#define _LS10X3ABOOT_H_

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

#define CONFIG_RECORD_TIME  //nxp support record time node 

#define CRC_BIG_LITTLE_SWAP_LONG(x) \
	((unsigned int)( \
		(((unsigned int)(x) & (unsigned int)0x000000ffUL) << 24) | \
		(((unsigned int)(x) & (unsigned int)0x0000ff00UL) <<  8) | \
		(((unsigned int)(x) & (unsigned int)0x00ff0000UL) >>  8) | \
		(((unsigned int)(x) & (unsigned int)0xff000000UL) >> 24) ))

#define CRC_BIG_LITTLE_SWAP_USHORT(x) \
	((unsigned short)( \
		(((unsigned short)(x) & (unsigned short)0x00ff) << 8) | \
		(((unsigned short)(x) & (unsigned short)0xff00) >> 8) ))


#if defined(COMPILE_FOR_KEXEC_BOOT)

/*keboot flash 烧写起始地址=版本头起始地址*/
#define KEBOOT_START_ADDR 0x200000
/*uboot flash 中版本头位置,0x100000-0x80*/
#define UBOOT_HEAD_ADDR 0xFFF80
/*--------------------------------------------------------------------------*/
/*  LS10X3A  Memory                                                                                              */
/*--------------------------------------------------------------------------*/
enum e_ls10x3a_module_cfg_t
{
    BOARD_NR30 = 0,
    BOARD_R9606,
    BOARD_NR30_NETMUX,
    LS10X3A_MODULE_CFG_NUM
};

#define GPIO_APPID_0       24    //GPIO1
#define GPIO_APPID_1       25    //GPIO1
#define GPIO_APPID_2       26    //GPIO1
#define GPIO_DRAMID_0      27    //GPIO1
#define GPIO_DRAMID_1      28    //GPIO1
#define GPIO_DRAMID_2      29    //GPIO1

#define readb(addr) \
  ({ unsigned char __v = (*(volatile unsigned char *) (addr)); __v; })
#define readw(addr) \
  ({ unsigned short __v = (*(volatile unsigned short *) (addr)); __v; })
#define readl(addr) \
  ({ unsigned long __v = (*(volatile unsigned long *) (addr)); __v; })
    
#define writeb(b, addr) \
      (void)((*(volatile unsigned char *) (addr)) = (b))
#define writew(b, addr) \
      (void)((*(volatile unsigned short *) (addr)) = (b))
#define writel(b, addr) \
      (void)((*(volatile unsigned int *) (addr)) = (b))
      
#define MODULE_GROUP_ID_OFFSET                   (1<<3)
#define BOARD_GROUP_ID_OFFSET                    (1<<2)
#define BOARD_TYPE_ID_OFFSET                     (1<<1)
#define BOARD_HARD_CHANGE_ID_OFFSET              (1<<0)

#define GPIO_DATA_OFFSET           0x08  /*GPDAT*/
#define GPIO_ODR_OFFSET            0x04  /*GPODR*/
#define GPIO_DIR_OFFSET            0x00  /*GPDIR*/

/*******************************CPLD*************************************/

#define CONFIG_SYS_CPLD_BASE		 0x7fb00000
/* 选择ls10x3a单板类型，NXP非标模，A9606非标模烧写板，默认标模板 */
//#define CONFIG_NXP_DEMO_BOARD        
//#define CONFIG_A9606_BOARD        

#if defined(CONFIG_NXP_DEMO_BOARD) /* 非标模老版EPLD */
/*CPLD 状态指示、快慢切控制寄存器A：bit0(快切使能：0开 、1关) bit1(慢切使能：0开   、1关) bit7(启动boot指示位 0 大片启动  、1小片启动)*/
#define CPLD_BOOT_STATUS_OFFSET 0xf0
/*CPLD 大小片控制寄存器B：bit0(启动顺序控制 ：0大片 、1小片) bit1(Flash访问选择：0大片 、 1小片) bit7(软件控制启动顺序位： 0大片启动 、1小片启动)*/
#define CPLD_BOOT_SELECT_OFFSET 0xf1
#define CPLD_WTD_FEED_REG            0xe9
#define CPLD_WTD_TIMEOUT_REG         0xeb
#define CPLD_WTD_ENABLE_REG          0xec
/*CPLD  LED*/
#define CPLD_LED_RUN_ALM             0xe4
#define CPLD_LED_OPT0_OPT1           0xe5
#define CPLD_LED_OPT2                0xe6
#define CPLD_LED_RGPS                0xe7

#define CPLD_LED_CPU_CTL0            0xed
#define CPLD_LED_CPU_CTL1            0x53

#else /* 默认为标模新版CPLD */

/*CPLD 状态指示、快慢切控制寄存器A：bit0(快切使能：0开 、1关) bit1(慢切使能：0开   、1关) bit7(启动boot指示位 0 大片启动  、1小片启动)*/
#define CPLD_BOOT_STATUS_OFFSET 0x10
/*CPLD 大小片控制寄存器B：bit0(启动顺序控制 ：0大片 、1小片) bit1(Flash访问选择：0大片 、 1小片) bit7(软件控制启动顺序位： 0大片启动 、1小片启动)*/
#define CPLD_BOOT_SELECT_OFFSET 0x11

#define CPLD_WTD_FEED_REG       0x15
#define CPLD_WTD_TIMEOUT_REG    0x17
#define CPLD_WTD_ENABLE_REG     0x18

#define CPLD_HW_EVENT           0x19            /*HW_Event_Record*/
#define CPLD_SW_EVENT           0x1a            /*SW_Event_Record*/
/* CPLD LED */
#define CPLD_LED_REG            0x12
#define CPLD_LED_REG_EX         0x13
#define CPLD_DEV_RST_REG     0x40
#define CPLD_MCS_RST_REG     0x44
#define CPLD_DPLL_RST_REG    0xf0

/*UART SWITCH COM*/
#define CPLD_SWITCH_UART_OFFSET 0x3a

/*GPS POWER CTRL*/
#define CPLD_GPS_AISG_RST_OFFSET 0xa3
#define GPS_POWER_ON        1  
#define GPS_POWER_OFF       0
#define STATUS_DBG_UART     1
#define STATUS_GPS_UART     0

#define COM_INTERRUPT_NUM   0x56            /* 串口中断号 */
#endif
/*******************************内存定义************************************/
#define DRAM_BASE_ADDR           (0x80000000) /*RAM 的基地址*/
#define CRL_APB_BASEADDR         (0x84010000)/*存放 boot flag地址 新双boot机制不需要*/
#define DRAM_4M                  (0x0400000)
#define DRAM_32M                 (0x02000000)
#define DRAM_64M                 (0x04000000)
#define DRAM_128M                (0x08000000)
#define DRAM_256M                (0x10000000)
#define DRAM_512M                (0x20000000)
#define DRAM_1024M               (0x40000000)

#define SYS_PHYS_MEM_TOP         (0x00600000)/*6M*/
#define OSS_MEM_SIZE             (0x00080000)/*512K*/ 
#define BSP_MEM_SIZE             (0x00080000) 
#define BSP_VER_PROTECT_SIZE     (0x00400000)/*4M*/
#define APP_RESERVED_SIZE        (0x100000)/*1M*/
#define USER_RESERVED_SIZE       (OSS_MEM_SIZE + BSP_MEM_SIZE + BSP_VER_PROTECT_SIZE + APP_RESERVED_SIZE)

#define SYS_MEM_TOP              (SYS_PHYS_MEM_TOP - USER_RESERVED_SIZE)
#define USER_RESERVED_ADDR       (SYS_MEM_TOP)
#define APP_RESERVED_ADDR        (USER_RESERVED_ADDR + BSP_VER_PROTECT_SIZE)
#define OSS_MEM_ADDR             (APP_RESERVED_ADDR + APP_RESERVED_SIZE)
#define BSP_MEM_ADDR             (OSS_MEM_ADDR + OSS_MEM_SIZE)
#define BSP_VER_PROTECT_ADDR     (SYS_MEM_TOP)
#define APP_HR_RESERVED_SIZE     (0x10000)
#define APP_BOX_RESERVED_SIZE    (0x80000)
#define APP1_RESERVED_SIZE       APP_HR_RESERVED_SIZE
#define APP2_RESERVED_SIZE       APP_BOX_RESERVED_SIZE

#define RESET_INFO_ADDR          (BSP_MEM_ADDR + 0x57C0)

#define BK_RESV_HIGH_MEM_ADDR                 0xCC000000  // 已和AC同事沟通预约从AC的256MB高端扣除64MB留作B&K等其他功能(物理内存基址:0x80000000=2G)
#define BOOTAPP_LOG_BASE_OFFSET               0x03D60000  // 规划出128KB用于boot CUR/BAK两段BOOTAPP LOG日志区，各64KB
#define BOOTAPP_LOG_PHY_ADDR                  (BK_RESV_HIGH_MEM_ADDR + BOOTAPP_LOG_BASE_OFFSET)
#define APP_LOG_BASE_OFFSET                   0x03E00000
#define APP_LOG_PHY_ADDR                      (BK_RESV_HIGH_MEM_ADDR + APP_LOG_BASE_OFFSET)
#define APP_LOG_SIZE                          0x100000    // CPU CUR/BAK两段 APP LOG, 各1MB

#define LAST_KMSG_BASE_OFFSET                 0x03D80000
#define LAST_KMSG_ADDR                        (BK_RESV_HIGH_MEM_ADDR + LAST_KMSG_BASE_OFFSET)
#define LAST_KMSG_SIZE                        0x40000     // CPU CUR/BAK两段 LAST_KMSG, 各256KB
/********************************Flash 规划定义********************************/
//#define PROTECT_ZONE_SIZE	    (ULONG)(32 * 1024 * 1024UL) /*保护区大小，代码会根据实际mtd1大小更新*/
/*Bomid :12M+256k=12845056byte=C40000*/
#define MODULEID_ADDR           0xC40000
/*保护区起始地址-Boot分区大小(Bomid区) =保护区偏移地址
 *17M+256K   -  (12M+256K)(Bomid区)                 = 5M=5242864byte=0x500000 
 */
#define PROTECT_ZONE_OFFSET_MTD1  0x500000

#ifdef __cplusplus
}
#endif /* __cplusplus */
#endif
/**************************************************************************
*                         外部函数声明
**************************************************************************/
extern VOID MainLoop ();
extern int ushell_init();
extern ULONG BootFlashInit(VOID);
extern ULONG BootSoftModInit(void);
extern ULONG BootBoardSetReset(ULONG ulMode, ULONG ulWtd);
extern UINT32 nxpGetGpioReg(UINT32 ulBank,UINT32 ulOffSet, UINT32 *pulReg);
extern int nxpGpioMmap(int bus);
extern ULONG BspGetBootSoftVersion(CHAR *pcBootSoftVer,UCHAR ucSizeofBytes);
extern ULONG BootAttachUartCom(void);
extern void BootSwitchUartCom(int index);
extern unsigned char BootGetUartCom(void);

/**************************************************************************
*                         全局函数声明
**************************************************************************/
ULONG SetDefaultCmdline();
/*Debug Cmd*/
ULONG BootGetMemVir();
VOID BootLedRun(UCHAR ucMode);
ULONG BootGetFsRecoverFlag(VOID);
ULONG BootWatchDogEnable(VOID);
ULONG BootWatchDogDisable(VOID);
ULONG BootGetPhyLinkStatus(VOID);
ULONG BootGetVersion(char *headPtr,char model);
ULONG BootSetWatchDogTime (unsigned short timeout);
ULONG BootDebugMiiRead(ULONG ulCsrClockRange,ULONG ulGR, ULONG ulPA, ULONG *pulData);
ULONG BootDebugMiiWrite(ULONG ulCsrClockRange,ULONG ulGR, ULONG ulPA, ULONG ulValue);
ULONG SetEthProMode(UCHAR ucValue);
ULONG cpld_read(ULONG ulOffSet, unsigned char *pucReg);
ULONG cpld_write(ULONG ulOffSet, unsigned char ucReg);
ULONG getLastKmsgAddr(VOID);
ULONG getAppLogPhyAddr(VOID);
ULONG BootFlagGet(VOID);
VOID SaveKebootLog(VOID);
VOID SaveKebootBakLog(VOID);
VOID SaveKebootCurLog(VOID);
UINT32 BootGetBoardHwResetType(VOID);
UINT32 BootGetBoardSwResetType(VOID);
UCHAR* BootGetBoardResetInfoAddr(VOID);
/* Started by AICoder, pid:a61a1n2895je142149550865c05ba30e66c4432c */
ULONG BspMknod(const char * filepath, const char *oprator, const char *majornew, const char* minornew);
/* Ended by AICoder, pid:a61a1n2895je142149550865c05ba30e66c4432c */
/* Started by AICoder, pid:108de1f46b416871440c09f7b066b100b7634898 */
ULONG BootGetDownloadFlag(void);
int ls10x3a_is_config(enum e_ls10x3a_module_cfg_t ls10x3a_module);
ULONG BootCheckFile(void);
/* Ended by AICoder, pid:108de1f46b416871440c09f7b066b100b7634898 */
#endif

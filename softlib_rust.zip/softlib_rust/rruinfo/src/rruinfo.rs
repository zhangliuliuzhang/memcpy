#![allow(
    dead_code,
    mutable_transmutes,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    unused_assignments,
    unused_mut
)]
#![feature(extern_types)]
unsafe extern "C" {
    fn __errno_location() -> *mut libc::c_int;
    fn open(__file: *const libc::c_char, __oflag: libc::c_int, _: ...) -> libc::c_int;
    fn fclose(__stream: *mut FILE) -> libc::c_int;
    fn fopen(_: *const libc::c_char, _: *const libc::c_char) -> *mut FILE;
    fn fprintf(_: *mut FILE, _: *const libc::c_char, _: ...) -> libc::c_int;
    fn fgets(
        __s: *mut libc::c_char,
        __n: libc::c_int,
        __stream: *mut FILE,
    ) -> *mut libc::c_char;
    fn fread(
        _: *mut libc::c_void,
        _: libc::c_ulong,
        _: libc::c_ulong,
        _: *mut FILE,
    ) -> libc::c_ulong;
    fn malloc(_: libc::c_ulong) -> *mut libc::c_void;
    fn free(__ptr: *mut libc::c_void);
    fn strtoul(
        _: *const libc::c_char,
        _: *mut *mut libc::c_char,
        _: libc::c_int,
    ) -> libc::c_ulong;
    fn abs(_: libc::c_int) -> libc::c_int;
    fn memset(
        _: *mut libc::c_void,
        _: libc::c_int,
        _: libc::c_ulong,
    ) -> *mut libc::c_void;
    fn memcmp(
        _: *const libc::c_void,
        _: *const libc::c_void,
        _: libc::c_ulong,
    ) -> libc::c_int;
    fn strncpy(
        _: *mut libc::c_char,
        _: *const libc::c_char,
        _: libc::c_ulong,
    ) -> *mut libc::c_char;
    fn strcmp(_: *const libc::c_char, _: *const libc::c_char) -> libc::c_int;
    fn strncmp(
        _: *const libc::c_char,
        _: *const libc::c_char,
        _: libc::c_ulong,
    ) -> libc::c_int;
    fn strrchr(_: *const libc::c_char, _: libc::c_int) -> *mut libc::c_char;
    fn strstr(_: *const libc::c_char, _: *const libc::c_char) -> *mut libc::c_char;
    fn strtok_r(
        __s: *mut libc::c_char,
        __delim: *const libc::c_char,
        __save_ptr: *mut *mut libc::c_char,
    ) -> *mut libc::c_char;
    fn strlen(_: *const libc::c_char) -> libc::c_ulong;
    fn close(__fd: libc::c_int) -> libc::c_int;
    fn encapsulationOfZte_memcpy_s(
        s1: *mut libc::c_void,
        s1max: rsize_t,
        s2: *const libc::c_void,
        n: rsize_t,
        fileName: *const libc::c_char,
        lineNo: libc::c_int,
    ) -> libc::c_int;
    fn encapsulationOfZte_memset_s(
        s: *mut libc::c_void,
        smax: rsize_t,
        c: libc::c_int,
        n: rsize_t,
        fileName: *const libc::c_char,
        lineNo: libc::c_int,
    ) -> libc::c_int;
    fn encapsulationOfZte_strcat_s(
        s1: *mut libc::c_char,
        s1max: rsize_t,
        s2: *const libc::c_char,
        fileName: *const libc::c_char,
        lineNo: libc::c_int,
    ) -> libc::c_int;
    fn fopen_s(
        streamptr: *mut *mut FILE,
        filename: *const libc::c_char,
        mode: *const libc::c_char,
    ) -> errno_t;
    fn BspDevNameToId(pucDevName: *const libc::c_char) -> UINT32;
    fn BspGetDflInfoByBspChn(
        Chn: UINT32,
        dir: UINT32,
        dflId: *mut UINT32,
        dflChn: *mut UINT32,
    ) -> UINT32;
    fn BspGetAntInfoByBspChn(
        Chn: UINT32,
        dir: UINT32,
        antId: *mut UINT32,
        antChn: *mut UINT32,
    ) -> UINT32;
    fn BspGetPaInfoByBspChn(
        bspChn: UINT32,
        dir: UINT32,
        paId: *mut UINT32,
        paChn: *mut UINT32,
    ) -> UINT32;
    fn BspGetBspChnByAntId(
        antId: UINT32,
        dir: UINT32,
        channum: *mut UINT32,
        pbspchan: *mut UINT32,
    ) -> UINT32;
    fn JoinNameIndexToSection(
        section: *mut *mut libc::c_char,
        sectionlen: libc::c_uint,
        name: *mut libc::c_char,
        index: *mut libc::c_char,
    ) -> libc::c_int;
    fn ConfigGetKeyEx(
        CFG_file: *const libc::c_void,
        section: *const libc::c_void,
        key: *const libc::c_void,
        buf: *mut libc::c_void,
        buflen: libc::c_uint,
    ) -> libc::c_int;
    fn _ConfigGetKeyForMte(
        CFG_file: *mut libc::c_void,
        section: *mut libc::c_void,
        key: *mut libc::c_void,
        buf: *mut libc::c_void,
        buflen: libc::c_uint,
    ) -> libc::c_int;
    
    fn BspAtou(str: *const libc::c_char, base: INT32) -> UINT32;
    fn BspDevNameToIdFine(pucDevName: *const libc::c_char) -> UINT32;
    fn BspLoadModuleInfoFileToFlash(cInName: *const libc::c_char) -> UINT32;
    fn _BspGetCalibData(ulFileType: UINT32, ulSubIndex: UINT32) -> *mut libc::c_void;
    fn Pub_GetCodeInfo() -> T_CodeInfo;
}
use std::ffi::c_void;
use std::ffi::{CStr, CString};

#[repr(C)]
pub struct _IO_wide_data(c_void);
pub struct _IO_codecvt(c_void);
pub struct _IO_marker(c_void);

pub type __off_t = libc::c_long;
pub type __off64_t = libc::c_long;
pub type intptr_t = libc::c_long;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct _IO_FILE {
    pub _flags: libc::c_int,
    pub _IO_read_ptr: *mut libc::c_char,
    pub _IO_read_end: *mut libc::c_char,
    pub _IO_read_base: *mut libc::c_char,
    pub _IO_write_base: *mut libc::c_char,
    pub _IO_write_ptr: *mut libc::c_char,
    pub _IO_write_end: *mut libc::c_char,
    pub _IO_buf_base: *mut libc::c_char,
    pub _IO_buf_end: *mut libc::c_char,
    pub _IO_save_base: *mut libc::c_char,
    pub _IO_backup_base: *mut libc::c_char,
    pub _IO_save_end: *mut libc::c_char,
    pub _markers: *mut _IO_marker,
    pub _chain: *mut _IO_FILE,
    pub _fileno: libc::c_int,
    pub _flags2: libc::c_int,
    pub _old_offset: __off_t,
    pub _cur_column: libc::c_ushort,
    pub _vtable_offset: libc::c_schar,
    pub _shortbuf: [libc::c_char; 1],
    pub _lock: *mut libc::c_void,
    pub _offset: __off64_t,
    pub _codecvt: *mut _IO_codecvt,
    pub _wide_data: *mut _IO_wide_data,
    pub _freeres_list: *mut _IO_FILE,
    pub _freeres_buf: *mut libc::c_void,
    pub __pad5: libc::c_int,
    pub _mode: libc::c_int,
    pub _unused2: libc::c_char,
}
pub type _IO_lock_t = ();
pub type FILE = _IO_FILE;
pub type UCHAR = libc::c_uchar;
pub type CHAR = libc::c_char;
pub type ULONG = libc::c_uint;
pub type UINT = libc::c_uint;
pub type UINT8 = libc::c_uchar;
pub type UINT32 = libc::c_uint;
pub type INT8 = libc::c_schar;
pub type INT32 = libc::c_int;
pub type FLOAT = libc::c_float;
pub type USHORT = libc::c_ushort;
pub type BOOL = libc::c_int;
pub type rsize_t = libc::c_int;
pub type errno_t = libc::c_int;

// Rust 风格的 zte_sscanf_s 实现
// 注意：这是一个简化实现，支持常见的格式字符串模式
// 由于 Rust 不支持 C 风格的可变参数，这里提供一个基础实现

/// Rust 风格的字符串扫描函数
/// 
/// 这是一个简化实现，支持常见的格式字符串：
/// - %d: 整数
/// - %u: 无符号整数
/// - %x: 十六进制整数
/// - %s: 字符串
/// - %f: 浮点数
/// 
/// 注意：由于 Rust 不支持 C 风格的可变参数，此实现只提供基础框架
/// 实际使用时需要根据具体格式字符串和参数类型进行解析
/// 
/// # Safety
/// 
/// 这是一个 unsafe 函数，需要确保所有指针有效
#[unsafe(no_mangle)]
pub unsafe extern "C" fn zte_sscanf_s(
    s: *const libc::c_char,
    format: *const libc::c_char,
    size_array: *mut rsize_t,
) -> libc::c_int {
    // 基础实现：返回 0 表示成功解析了 0 个参数
    // 这是一个打桩实现，实际使用时需要根据具体格式字符串进行解析
    if s.is_null() || format.is_null() {
        return -1;
    }
    
    // 如果 size_array 不为空，可以设置大小
    if !size_array.is_null() {
        unsafe {
            *size_array = 0;
        }
    }
    
    // 打桩实现：返回 0（表示成功但未解析任何参数）
    // 实际实现需要解析格式字符串并提取相应的值
    // 注意：由于 Rust 不支持 C 风格的可变参数，这里只提供基础框架
    // 如果需要完整实现，可以使用宏或者根据具体使用场景创建专门的解析函数
    0
}

pub type E_DAAU_TYPE_DEF = libc::c_uint;
pub const DAAU_TYPE_MICELL_MAX: E_DAAU_TYPE_DEF = 5;
pub const DAAU_TYPE_YA9326_S28: E_DAAU_TYPE_DEF = 4;
pub const DAAU_TYPE_A9326S_S26: E_DAAU_TYPE_DEF = 3;
pub const DAAU_TYPE_A9326_S26: E_DAAU_TYPE_DEF = 2;
pub const DAAU_TYPE_A9306_S26: E_DAAU_TYPE_DEF = 1;
pub const DAAU_TYPE_MICELL_MIN: E_DAAU_TYPE_DEF = 0;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct tagT_DevWorkStatusInfo {
    pub ulFpgaClkLockStatus: UINT32,
    pub ulMixerDevRunStatus: UINT32,
    pub ulLimitAmpRunStatus: UINT32,
    pub ulUdsCheckRunStatus: UINT32,
    pub ulTrsvLaneCrcStatus: UINT32,
    pub ulTrsvPllLockStatus: UINT32,
    pub ulTrsvInSerdesStatus: UINT32,
}
pub type T_DevWorkStatus = tagT_DevWorkStatusInfo;
pub type _RRU_TYPE_ = libc::c_uint;
pub const AAU_TYPE_MAX: _RRU_TYPE_ = 361;
pub const A9651E_M49U: _RRU_TYPE_ = 360;
pub const YR9006_S21: _RRU_TYPE_ = 359;
pub const YR9006_S26: _RRU_TYPE_ = 358;
pub const R9614_S14: _RRU_TYPE_ = 357;
pub const YR9116_M1215: _RRU_TYPE_ = 356;
pub const R9254E_S1500_E8A: _RRU_TYPE_ = 355;
pub const A9652S_S38: _RRU_TYPE_ = 354;
pub const R9614E_S23: _RRU_TYPE_ = 353;
pub const AT9526_M7020: _RRU_TYPE_ = 352;
pub const R9254F_S1800_E8A: _RRU_TYPE_ = 351;
pub const A9752_M2636: _RRU_TYPE_ = 350;
pub const A9652U_M1920: _RRU_TYPE_ = 349;
pub const R8159_F182126T35: _RRU_TYPE_ = 348;
pub const R8149_T4900E_D4A: _RRU_TYPE_ = 347;
pub const R9264H_M182126N: _RRU_TYPE_ = 346;
pub const R9264H_M171926N: _RRU_TYPE_ = 345;
pub const YA9752_M1719: _RRU_TYPE_ = 344;
pub const R9264H_M608090: _RRU_TYPE_ = 343;
pub const YR8159I_M9026: _RRU_TYPE_ = 342;
pub const R9614E_S26: _RRU_TYPE_ = 341;
pub const R9254E_S1800_E6A: _RRU_TYPE_ = 340;
pub const R9254_S8500_E6A: _RRU_TYPE_ = 339;
pub const R9244_S9000_E6A: _RRU_TYPE_ = 338;
pub const R9244B_S9000_E6A: _RRU_TYPE_ = 337;
pub const A9652S_S36: _RRU_TYPE_ = 336;
pub const R9254E_S2100_E8A: _RRU_TYPE_ = 335;
pub const A9165_M1926: _RRU_TYPE_ = 334;
pub const R8159_M17192635: _RRU_TYPE_ = 333;
pub const EP214_N102: _RRU_TYPE_ = 332;
pub const R9214H_S7200_E8A: _RRU_TYPE_ = 331;
pub const A9651D_M2638: _RRU_TYPE_ = 330;
pub const R9254E_S8000_A8A: _RRU_TYPE_ = 329;
pub const R9266_M728090N: _RRU_TYPE_ = 328;
pub const R9626B_S26: _RRU_TYPE_ = 327;
pub const R9254D_S7200_A8A: _RRU_TYPE_ = 326;
pub const R9254E_S1800_A6A: _RRU_TYPE_ = 325;
pub const R9244B_S9000_D6A: _RRU_TYPE_ = 324;
pub const YA9752_M171926: _RRU_TYPE_ = 323;
pub const R8159_M701835: _RRU_TYPE_ = 322;
pub const R9266_M8590: _RRU_TYPE_ = 321;
pub const A9164_M2649: _RRU_TYPE_ = 320;
pub const R9268H_M1821: _RRU_TYPE_ = 319;
pub const R9262E_M728090: _RRU_TYPE_ = 318;
pub const A9326_MOF: _RRU_TYPE_ = 317;
pub const YR9256E_S9000: _RRU_TYPE_ = 316;
pub const R9614_S36: _RRU_TYPE_ = 315;
pub const R9614_S40: _RRU_TYPE_ = 314;
pub const RCUX: _RRU_TYPE_ = 313;
pub const R9268H_M1719: _RRU_TYPE_ = 312;
pub const R8159_F2100: _RRU_TYPE_ = 311;
pub const A9164_S49: _RRU_TYPE_ = 310;
pub const R8159_M182135E: _RRU_TYPE_ = 309;
pub const R9136E_M728090: _RRU_TYPE_ = 308;
pub const R9136_M1821: _RRU_TYPE_ = 307;
pub const R9136_M1835: _RRU_TYPE_ = 306;
pub const R9136_M1826: _RRU_TYPE_ = 305;
pub const YA9752_M182126: _RRU_TYPE_ = 304;
pub const R9269E_M1719: _RRU_TYPE_ = 303;
pub const MICELL3_CB: _RRU_TYPE_ = 302;
pub const YN62X4_S4900: _RRU_TYPE_ = 301;
pub const R9626E_M1826: _RRU_TYPE_ = 300;
pub const A9164_M1835: _RRU_TYPE_ = 299;
pub const R9262_M1821: _RRU_TYPE_ = 298;
pub const R8159_EP214: _RRU_TYPE_ = 297;
pub const R8159_M18232649: _RRU_TYPE_ = 296;
pub const R9125_M1835: _RRU_TYPE_ = 295;
pub const R9005_S21: _RRU_TYPE_ = 294;
pub const A9164_M1826: _RRU_TYPE_ = 293;
pub const R9254_S8500_A8A: _RRU_TYPE_ = 292;
pub const R9626_M2326: _RRU_TYPE_ = 291;
pub const R9124M_S26: _RRU_TYPE_ = 290;
pub const R9264_M1719: _RRU_TYPE_ = 289;
pub const R9028R_S21: _RRU_TYPE_ = 288;
pub const R9018R_S21: _RRU_TYPE_ = 287;
pub const R9015_S51: _RRU_TYPE_ = 286;
pub const R8159_M192635: _RRU_TYPE_ = 285;
pub const R9268H_M182126: _RRU_TYPE_ = 284;
pub const R9268H_M171926: _RRU_TYPE_ = 283;
pub const R9269E_M1821: _RRU_TYPE_ = 282;
pub const YA9641L_S49: _RRU_TYPE_ = 281;
pub const R8159_T5100: _RRU_TYPE_ = 280;
pub const A9306_MOF: _RRU_TYPE_ = 279;
pub const MICELL2_VIFEx: _RRU_TYPE_ = 278;
pub const R9266_M1821: _RRU_TYPE_ = 277;
pub const R9266_M7285: _RRU_TYPE_ = 276;
pub const R9256_S9000: _RRU_TYPE_ = 275;
pub const R9268E_M1821: _RRU_TYPE_ = 274;
pub const R9004_G2100: _RRU_TYPE_ = 273;
pub const MICELL_9306: _RRU_TYPE_ = 272;
pub const MICELL_VIFD2: _RRU_TYPE_ = 271;
pub const R9626_S35: _RRU_TYPE_ = 270;
pub const R9626S_S35: _RRU_TYPE_ = 269;
pub const R9242_M1821_A8A: _RRU_TYPE_ = 268;
pub const R9254_S8500_A6A: _RRU_TYPE_ = 267;
pub const R9264H_M171926: _RRU_TYPE_ = 266;
pub const A9652D_M2335: _RRU_TYPE_ = 265;
pub const R9125_M2135: _RRU_TYPE_ = 264;
pub const R9626_M1826: _RRU_TYPE_ = 263;
pub const R9254E_S1900_A8A: _RRU_TYPE_ = 262;
pub const R9254E_S1700_A8A: _RRU_TYPE_ = 261;
pub const R9254_S2600_A6A: _RRU_TYPE_ = 260;
pub const R9254_S2100_A6A: _RRU_TYPE_ = 259;
pub const R9254E_S2100_A8A: _RRU_TYPE_ = 258;
pub const R9254E_S1800_A8A: _RRU_TYPE_ = 257;
pub const R9614E_M1826: _RRU_TYPE_ = 256;
pub const R9614_M1826: _RRU_TYPE_ = 255;
pub const R9264H_M901821E: _RRU_TYPE_ = 254;
pub const R9264H_M901821: _RRU_TYPE_ = 253;
pub const R9264E_M1821: _RRU_TYPE_ = 252;
pub const R9234_S8000: _RRU_TYPE_ = 251;
pub const R9626_M192026: _RRU_TYPE_ = 250;
pub const R9266_M7290: _RRU_TYPE_ = 249;
pub const R9266_M8090: _RRU_TYPE_ = 248;
pub const R9266_M728090: _RRU_TYPE_ = 247;
pub const R9125_M1826: _RRU_TYPE_ = 246;
pub const R9614_S35: _RRU_TYPE_ = 245;
pub const R9614_S26: _RRU_TYPE_ = 244;
pub const R9614_S23: _RRU_TYPE_ = 243;
pub const R9626S_S26: _RRU_TYPE_ = 242;
pub const R9626_S26: _RRU_TYPE_ = 241;
pub const R8149_T4900E_C4A: _RRU_TYPE_ = 240;
pub const R8159_T2600BH: _RRU_TYPE_ = 239;
pub const R8159_T2600: _RRU_TYPE_ = 238;
pub const R8159_M1835E: _RRU_TYPE_ = 237;
pub const R8159_M1835B: _RRU_TYPE_ = 236;
pub const R8159_M1826B: _RRU_TYPE_ = 235;
pub const R8159_M7035: _RRU_TYPE_ = 234;
pub const R8159_T3500: _RRU_TYPE_ = 233;
pub const R8159_M182135: _RRU_TYPE_ = 232;
pub const R8159_M182326: _RRU_TYPE_ = 231;
pub const A9165_M1719: _RRU_TYPE_ = 230;
pub const A9165_M1821: _RRU_TYPE_ = 229;
pub const R9264T_M7285182126: _RRU_TYPE_ = 228;
pub const R9264T_M7280901821: _RRU_TYPE_ = 227;
pub const R9264T_M72901821: _RRU_TYPE_ = 226;
pub const R9264_M1821_INNER: _RRU_TYPE_ = 225;
pub const R9264_M1719N: _RRU_TYPE_ = 224;
pub const R9264_M1821N: _RRU_TYPE_ = 223;
pub const R9264N_M7290: _RRU_TYPE_ = 222;
pub const R9264N_M728090: _RRU_TYPE_ = 221;
pub const R9264_M728090: _RRU_TYPE_ = 220;
pub const R9264_M7290_INNER: _RRU_TYPE_ = 219;
pub const R9264_M7290: _RRU_TYPE_ = 218;
pub const R9264_M7285: _RRU_TYPE_ = 217;
pub const R9264S_M1821: _RRU_TYPE_ = 216;
pub const R9264_M1821: _RRU_TYPE_ = 215;
pub const R9264H_M721821: _RRU_TYPE_ = 214;
pub const R9264H_M182126: _RRU_TYPE_ = 213;
pub const R9234E_S2600: _RRU_TYPE_ = 212;
pub const MOF: _RRU_TYPE_ = 211;
pub const A9306_S26: _RRU_TYPE_ = 210;
pub const A9622W_S35: _RRU_TYPE_ = 209;
pub const R9604_S26: _RRU_TYPE_ = 208;
pub const R9248_S2100_A4A: _RRU_TYPE_ = 207;
pub const A9714_S21_A4A: _RRU_TYPE_ = 206;
pub const A9651D_M2326: _RRU_TYPE_ = 205;
pub const A9651P_S36: _RRU_TYPE_ = 204;
pub const A9651D_M2636: _RRU_TYPE_ = 203;
pub const A9652D_M2336: _RRU_TYPE_ = 202;
pub const A9652D_M2326: _RRU_TYPE_ = 201;
pub const A9651D_M2649: _RRU_TYPE_ = 200;
pub const A9652D_M2635: _RRU_TYPE_ = 199;
pub const A9650_S70: _RRU_TYPE_ = 198;
pub const A9651A_S49: _RRU_TYPE_ = 197;
pub const R8998G_S35_D4A: _RRU_TYPE_ = 196;
pub const R8998G_S23_D4A: _RRU_TYPE_ = 195;
pub const R8998G_S26_D4A: _RRU_TYPE_ = 194;
pub const A9651A_S70: _RRU_TYPE_ = 193;
pub const YA9662A_S35: _RRU_TYPE_ = 192;
pub const YA9662L_S26: _RRU_TYPE_ = 191;
pub const YA9662H_S36: _RRU_TYPE_ = 190;
pub const A9662H_S36: _RRU_TYPE_ = 189;
pub const YA9661H_S36: _RRU_TYPE_ = 188;
pub const YA9661A_S35: _RRU_TYPE_ = 187;
pub const A9652H_S35: _RRU_TYPE_ = 186;
pub const A9652H_S36: _RRU_TYPE_ = 185;
pub const A9652A_S35: _RRU_TYPE_ = 184;
pub const A9652A_S26: _RRU_TYPE_ = 183;
pub const A9651H_S38E: _RRU_TYPE_ = 182;
pub const A9651H_S35: _RRU_TYPE_ = 181;
pub const A9651H_S36: _RRU_TYPE_ = 180;
pub const A9651A_H36: _RRU_TYPE_ = 179;
pub const A9651A_S35: _RRU_TYPE_ = 178;
pub const A9651A_S23: _RRU_TYPE_ = 177;
pub const A9651A_S26: _RRU_TYPE_ = 176;
pub const A9651L_S35: _RRU_TYPE_ = 175;
pub const A9650S_S49: _RRU_TYPE_ = 174;
pub const A9650E_S49: _RRU_TYPE_ = 173;
pub const A9650_S49: _RRU_TYPE_ = 172;
pub const A9900_S49: _RRU_TYPE_ = 171;
pub const A9622A_S33: _RRU_TYPE_ = 170;
pub const A9631W_S35: _RRU_TYPE_ = 169;
pub const YA9752_M1821: _RRU_TYPE_ = 168;
pub const A9732_S26: _RRU_TYPE_ = 167;
pub const A9732_M1821: _RRU_TYPE_ = 166;
pub const A9732_M1719: _RRU_TYPE_ = 165;
pub const A9722_M1821: _RRU_TYPE_ = 164;
pub const A965X_S26: _RRU_TYPE_ = 163;
pub const A9641E_S35: _RRU_TYPE_ = 162;
pub const R9114_S60: _RRU_TYPE_ = 161;
pub const A9154_S49: _RRU_TYPE_ = 160;
pub const R9616_S26: _RRU_TYPE_ = 159;
pub const A9641_S26: _RRU_TYPE_ = 158;
pub const A9316_S28B: _RRU_TYPE_ = 157;
pub const A9316_S26B: _RRU_TYPE_ = 156;
pub const A9316_S28A: _RRU_TYPE_ = 155;
pub const A9316_S26A: _RRU_TYPE_ = 154;
pub const R9115A_S35: _RRU_TYPE_ = 153;
pub const R9115_S26: _RRU_TYPE_ = 152;
pub const R9126_M1821: _RRU_TYPE_ = 151;
pub const R9252E_S9000: _RRU_TYPE_ = 150;
pub const R9252E_S2100: _RRU_TYPE_ = 149;
pub const R9214H_S7200_D8A: _RRU_TYPE_ = 148;
pub const R9214H_S7200: _RRU_TYPE_ = 147;
pub const R9244_S9000_D6A: _RRU_TYPE_ = 146;
pub const A9652A_S23: _RRU_TYPE_ = 145;
pub const A9652S_S49: _RRU_TYPE_ = 144;
pub const A9652E_S26: _RRU_TYPE_ = 143;
pub const A9642A_S26: _RRU_TYPE_ = 142;
pub const A9642A_S35: _RRU_TYPE_ = 141;
pub const A9631A_S37: _RRU_TYPE_ = 140;
pub const A9714_S21: _RRU_TYPE_ = 139;
pub const R9242E_M1821: _RRU_TYPE_ = 138;
pub const R9242_M1821: _RRU_TYPE_ = 137;
pub const R9242E_M8090: _RRU_TYPE_ = 136;
pub const R9224H_M7290: _RRU_TYPE_ = 135;
pub const R9224E_M7285: _RRU_TYPE_ = 134;
pub const R9224E_M8090: _RRU_TYPE_ = 133;
pub const R9224E_M728090: _RRU_TYPE_ = 132;
pub const R9224E_M7290: _RRU_TYPE_ = 131;
pub const R9224E_S2126: _RRU_TYPE_ = 130;
pub const R9224H_S1821_TEST: _RRU_TYPE_ = 129;
pub const R9224H_S1821: _RRU_TYPE_ = 128;
pub const R9248_S2100: _RRU_TYPE_ = 127;
pub const R9224E_S1821: _RRU_TYPE_ = 126;
pub const R9244_S9000: _RRU_TYPE_ = 125;
pub const R9234E_S1500: _RRU_TYPE_ = 124;
pub const R9234E_S2100: _RRU_TYPE_ = 123;
pub const R9234E_S7200: _RRU_TYPE_ = 122;
pub const R9212E_S7200: _RRU_TYPE_ = 121;
pub const R9214E_S7200: _RRU_TYPE_ = 120;
pub const R9214E_S1800: _RRU_TYPE_ = 119;
pub const R9616_M192026: _RRU_TYPE_ = 118;
pub const R9616_S35: _RRU_TYPE_ = 117;
pub const R9606D_S26: _RRU_TYPE_ = 116;
pub const A9641G_S49: _RRU_TYPE_ = 115;
pub const A9631H_S35: _RRU_TYPE_ = 114;
pub const A9631E_S35: _RRU_TYPE_ = 113;
pub const A9631D_S35: _RRU_TYPE_ = 112;
pub const A9631C_S35: _RRU_TYPE_ = 111;
pub const A9631B_S35: _RRU_TYPE_ = 110;
pub const A9631A1_S35: _RRU_TYPE_ = 109;
pub const A9641A_S26: _RRU_TYPE_ = 108;
pub const A9641A_S49: _RRU_TYPE_ = 107;
pub const A9641G_S35: _RRU_TYPE_ = 106;
pub const A9641A_S35: _RRU_TYPE_ = 105;
pub const AP9641A_M35F: _RRU_TYPE_ = 104;
pub const R9606F_S26: _RRU_TYPE_ = 103;
pub const A9622W_S36: _RRU_TYPE_ = 102;
pub const A9631A_S35: _RRU_TYPE_ = 101;
pub const A9622E_S37: _RRU_TYPE_ = 100;
pub const A9155_M1835: _RRU_TYPE_ = 99;
pub const A9155_M2135: _RRU_TYPE_ = 98;
pub const R9115_M1835: _RRU_TYPE_ = 97;
pub const R9115_M2135: _RRU_TYPE_ = 96;
pub const R9115_S35: _RRU_TYPE_ = 95;
pub const A9155_M1826: _RRU_TYPE_ = 94;
pub const R9115_M1826: _RRU_TYPE_ = 93;
pub const A9631A_S33: _RRU_TYPE_ = 92;
pub const A9631W_S36: _RRU_TYPE_ = 91;
pub const A9622A_S35: _RRU_TYPE_ = 90;
pub const R9606A_S35: _RRU_TYPE_ = 89;
pub const A9622E_S35_B: _RRU_TYPE_ = 88;
pub const R8998G_S26_C4A: _RRU_TYPE_ = 87;
pub const A9604_S49: _RRU_TYPE_ = 86;
pub const A9604_S36: _RRU_TYPE_ = 85;
pub const R8998G_S35_3638: _RRU_TYPE_ = 84;
pub const R8998G_S26_B: _RRU_TYPE_ = 83;
pub const R8998G_S35_300M: _RRU_TYPE_ = 82;
pub const A9604_S35: _RRU_TYPE_ = 81;
pub const R8998G_S35: _RRU_TYPE_ = 80;
pub const R8998G_S23: _RRU_TYPE_ = 79;
pub const R9105E_S26: _RRU_TYPE_ = 78;
pub const A9611B_S35: _RRU_TYPE_ = 77;
pub const A9622DM2635: _RRU_TYPE_ = 76;
pub const A9622A_S26: _RRU_TYPE_ = 75;
pub const A9622E_S35: _RRU_TYPE_ = 74;
pub const A9612E_S35: _RRU_TYPE_ = 73;
pub const TUE600_L26A: _RRU_TYPE_ = 72;
pub const TUE600_L21A: _RRU_TYPE_ = 71;
pub const R8998E_S3700: _RRU_TYPE_ = 70;
pub const A9631_S49: _RRU_TYPE_ = 69;
pub const A9631_S37: _RRU_TYPE_ = 68;
pub const A9631_S35: _RRU_TYPE_ = 67;
pub const A9835L_S26: _RRU_TYPE_ = 66;
pub const A9835_S28: _RRU_TYPE_ = 65;
pub const A9835_S26: _RRU_TYPE_ = 64;
pub const A9825_S39: _RRU_TYPE_ = 63;
pub const A9825S_S28: _RRU_TYPE_ = 62;
pub const A9825_S26B: _RRU_TYPE_ = 61;
pub const A9825_S26A: _RRU_TYPE_ = 60;
pub const R8998E_M3537: _RRU_TYPE_ = 59;
pub const R8998E_S26: _RRU_TYPE_ = 58;
pub const R8998G_S26: _RRU_TYPE_ = 57;
pub const A9613A_S26: _RRU_TYPE_ = 56;
pub const A9212_S1821: _RRU_TYPE_ = 55;
pub const R9606_S35: _RRU_TYPE_ = 54;
pub const R9606_S26: _RRU_TYPE_ = 53;
pub const A6611A_S26: _RRU_TYPE_ = 52;
pub const A9631_S26: _RRU_TYPE_ = 51;
pub const A9631A_S23: _RRU_TYPE_ = 50;
pub const A9631A_S26B: _RRU_TYPE_ = 49;
pub const A9631A_S26: _RRU_TYPE_ = 48;
pub const A9612_S35: _RRU_TYPE_ = 47;
pub const TUE600_L18A: _RRU_TYPE_ = 46;
pub const A9611E_S49C: _RRU_TYPE_ = 45;
pub const A9611E_S49B: _RRU_TYPE_ = 44;
pub const A9611E_S49A: _RRU_TYPE_ = 43;
pub const A9611_S49C: _RRU_TYPE_ = 42;
pub const A9611_S35I: _RRU_TYPE_ = 41;
pub const A9611_S35H: _RRU_TYPE_ = 40;
pub const A9611_S35G: _RRU_TYPE_ = 39;
pub const A9611_S26C: _RRU_TYPE_ = 38;
pub const A9611_S26B: _RRU_TYPE_ = 37;
pub const TUE610_S280: _RRU_TYPE_ = 36;
pub const A9611A_S26: _RRU_TYPE_ = 35;
pub const R9105_S35: _RRU_TYPE_ = 34;
pub const R9105_S26: _RRU_TYPE_ = 33;
pub const TUE600_L09A: _RRU_TYPE_ = 32;
pub const TUE600_L07A: _RRU_TYPE_ = 31;
pub const TUE600_S45A: _RRU_TYPE_ = 30;
pub const TUE600_S26A: _RRU_TYPE_ = 29;
pub const TUE600_S35A: _RRU_TYPE_ = 28;
pub const TUE610_S260: _RRU_TYPE_ = 27;
pub const A9611_S49B: _RRU_TYPE_ = 26;
pub const A9611_S45B: _RRU_TYPE_ = 25;
pub const A9611_S37C: _RRU_TYPE_ = 24;
pub const A9611_S37B: _RRU_TYPE_ = 23;
pub const A9611_S35B: _RRU_TYPE_ = 22;
pub const A9603_S35B: _RRU_TYPE_ = 21;
pub const A9815_S28A: _RRU_TYPE_ = 20;
pub const A9815_S39: _RRU_TYPE_ = 19;
pub const A9815S_S28: _RRU_TYPE_ = 18;
pub const A9815_S26C: _RRU_TYPE_ = 17;
pub const A9815_S26B: _RRU_TYPE_ = 16;
pub const A9815_S26A: _RRU_TYPE_ = 15;
pub const A9611_S49A: _RRU_TYPE_ = 14;
pub const A9611_S45A: _RRU_TYPE_ = 13;
pub const A9611_S37A: _RRU_TYPE_ = 12;
pub const A9611_S35A: _RRU_TYPE_ = 11;
pub const A9603_S35A: _RRU_TYPE_ = 10;
pub const A8101NR_S35: _RRU_TYPE_ = 9;
pub const CPE500_S49A: _RRU_TYPE_ = 8;
pub const CPE500_S35B: _RRU_TYPE_ = 7;
pub const CPE500_S45B: _RRU_TYPE_ = 6;
pub const CPE500_S45A: _RRU_TYPE_ = 5;
pub const CPE500_S35A: _RRU_TYPE_ = 4;
pub const A9601_S49: _RRU_TYPE_ = 3;
pub const A9601_S37: _RRU_TYPE_ = 2;
pub const A9601_S45: _RRU_TYPE_ = 1;
pub const A9601_S35: _RRU_TYPE_ = 0;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct T_SubCardInfo_16 {
    pub ulSubCardType: UINT32,
    pub ulSubCardVersion: UINT32,
    pub ulPlugStatus: UINT32,
    pub ulReserve: UINT32,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct T_HARDWARE_MODULE_INFO_16 {
    pub ulModuleGroup: UINT32,
    pub ulBoardType: UINT32,
    pub ulBomVer: UINT32,
    pub ulPcbVer: UINT32,
    pub ulBoardVersion: UINT32,
    pub ulEpldVersion: UINT32,
    pub ulBootVersion: UINT32,
    pub ulSubCardNum: UINT32,
    pub tSubCardInfo: [T_SubCardInfo_16; 10],
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct tgT_RruRfModuleInfo {
    pub ulRuAntTxMaxPower: UINT32,
    pub ulRuNominalPower: UINT32,
    pub ulRuAvailNominalPower: UINT32,
    pub ulRuTxStartFreq: UINT32,
    pub ulRuTxEndFreq: UINT32,
    pub ulRuRxStartFreq: UINT32,
    pub ulRuRxEndFreq: UINT32,
    pub ulRuFreqBand: UINT32,
    pub ulRuStandardBand: UINT32,
    pub ulReserve1: UINT32,
}
pub type T_RruRfModuleInfo = tgT_RruRfModuleInfo;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct tgT_RruRfModuleInfoNew {
    pub ulRuAntTxMaxPower: UINT32,
    pub ulRuNominalPower: UINT32,
    pub ulRuAvailNominalPower: UINT32,
    pub ulRuTxStartFreq: [UINT32; 3],
    pub ulRuTxEndFreq: [UINT32; 3],
    pub ulRuRxStartFreq: [UINT32; 3],
    pub ulRuRxEndFreq: [UINT32; 3],
    pub ulRuFreqBand: UINT32,
    pub ulRuStandardBand: [UINT32; 3],
    pub ulReserve1: UINT32,
}
pub type T_RruRfModuleInfoNew = tgT_RruRfModuleInfoNew;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct tagT_RruFreqBandCap {
    pub bandId: UINT32,
    pub startFreq: UINT32,
    pub endFreq: UINT32,
    pub reserve: UINT32,
}
pub type T_RruFreqBandCap = tagT_RruFreqBandCap;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct tagT_RruFreqBandInfo {
    pub bandNum: UINT32,
    pub txBandCap: [T_RruFreqBandCap; 8],
    pub rxBandCap: [T_RruFreqBandCap; 8],
}
pub type T_RruFreqBandInfo = tagT_RruFreqBandInfo;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct tgT_ModuleNumInfo {
    pub ulPaNum: UINT32,
    pub ulDflNum: UINT32,
    pub ulRpwNum: UINT32,
    pub ulTrxNum: UINT32,
    pub ulCoPaAntNum: UINT32,
    pub ulReserve: UINT32,
}
pub type T_ModuleNumInfo = tgT_ModuleNumInfo;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct tgT_RfPllNum {
    pub ulTxPllNum: UINT32,
    pub ulRxPllNum: UINT32,
    pub ulPrxPllNum: UINT32,
}
pub type T_BSP_RfPllNum = tgT_RfPllNum;
#[derive(Copy, Clone)]
#[repr(C, packed)]
pub struct T_BspDevInfo {
    pub ucVer: UCHAR,
    pub ucRackNo: UCHAR,
    pub ucShelfNo: UCHAR,
    pub ucSlotNo: UCHAR,
    pub usUnitType: USHORT,
    pub acBoardType: [CHAR; 13],
    pub acVendorUnitFamilyType: [CHAR; 13],
    pub acVendor: [CHAR; 13],
    pub usServiceTimes: USHORT,
    pub acSerialNO: [CHAR; 40],
    pub acPcbVerion: [CHAR; 20],
    pub acTimeOfMenuf: [CHAR; 20],
    pub acDateOfLastService: [CHAR; 10],
    pub usBoardId: USHORT,
    pub acReserve: [CHAR; 17],
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct tagManufacturerData {
    pub acPowerType: [CHAR; 20],
    pub acBand: [CHAR; 48],
    pub acPower: [CHAR; 40],
    pub acCustomAttri: [CHAR; 40],
    pub acReserve: [CHAR; 20],
}
pub type T_ManufacturerData = tagManufacturerData;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct tagT_BspInventoryInfo {
    pub usModuleGroupId: USHORT,
    pub usBoardType: USHORT,
    pub usBomId: USHORT,
    pub usServiceTimes: USHORT,
    pub acSerialNumber: [CHAR; 40],
    pub acProduceCode: [CHAR; 20],
    pub acInventoryUnitType: [CHAR; 20],
    pub acVendorUnitFamilyType: [CHAR; 20],
    pub acVendorUnitTypeNumber: [CHAR; 30],
    pub acVersionNumber: [CHAR; 20],
    pub acVendorName: [CHAR; 30],
    pub acDateOfManufacture: [CHAR; 20],
    pub acDateOfLastService: [CHAR; 20],
    pub tManufacturerData: T_ManufacturerData,
    pub acRawInfo: [CHAR; 300],
    pub acReserve: [CHAR; 40],
}
pub type T_BspInventoryInfo = tagT_BspInventoryInfo;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct tagT_BspAddInventoryInfo {
    pub ChangeId: UINT32,
    pub HardwareAttributeId: UINT32,
    pub ChangeIdAndHwAttributeId: [CHAR; 20],
    pub acReserve: [CHAR; 40],
}
pub type T_BspAddInventoryInfo = tagT_BspAddInventoryInfo;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct tagT_SignalAntCfgInfo {
    pub power: UINT32,
    pub antIndex: UINT32,
    pub bandNum: UINT32,
    pub bandInfo: [UINT32; 10],
}
pub type T_SignalAntCfgInfo = tagT_SignalAntCfgInfo;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct tagT_SignalAntBandCfgInfo {
    pub num: UINT32,
    pub antCfg: [T_SignalAntCfgInfo; 20],
}
pub type T_SignalAntBandCfgInfo = tagT_SignalAntBandCfgInfo;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct tagT_CombinationAntInfo {
    pub power: UINT32,
    pub antNum: UINT32,
    pub antInfo: [UINT32; 10],
}
pub type T_CombinationAntInfo = tagT_CombinationAntInfo;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct tagT_MultiAntCfgInfo {
    pub num: UINT32,
    pub combinationAntCfg: [T_CombinationAntInfo; 20],
}
pub type T_MultiAntCfgInfo = tagT_MultiAntCfgInfo;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct tagT_RruPowerCfgInfo {
    pub rruPowerSupport: UINT32,
    pub antCombinaSupport: UINT32,
    pub bandCombinaSupport: UINT32,
    pub chanSupport: UINT32,
    pub rruPower: UINT32,
    pub multiAntCfg: T_MultiAntCfgInfo,
    pub signalAntBandCfg: T_SignalAntBandCfgInfo,
    pub chanPow: [UINT32; 64],
}
pub type T_RruPowerCfgInfo = tagT_RruPowerCfgInfo;
pub const BOMID_MAGIC_NUM: C2RustUnnamed = 6;
pub type TVerGroup = tagHwVerGroup;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct tagHwVerGroup {
    pub cNickname: [libc::c_char; 40],
    pub nameIdx: UINT32,
    pub HardId: [UINT32; 8],
}
pub const HW_CHANGE_ID: C2RustUnnamed = 3;
pub const BRD_TYPE_ID: C2RustUnnamed = 2;
pub const BRD_GROUP_ID: C2RustUnnamed = 1;
pub const MOD_GROUP_ID: C2RustUnnamed = 0;
pub type TFreqStartEnd = tagFreqInfoDescription;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct tagFreqInfoDescription {
    pub ulBandNum: UINT32,
    pub aulFreqStart: [UINT32; 3],
    pub aulFreqEnd: [UINT32; 3],
}
pub type TAdpBoardInfoNew = tagAdpBoardInfoNew;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct tagAdpBoardInfoNew {
    pub aucBarCode: [libc::c_char; 128],
    pub ulServiceTime: UINT32,
    pub ulTxNum: UINT32,
    pub ulRxNum: UINT32,
    pub ulPrxNum: UINT32,
    pub ulOptNum: UINT32,
    pub ulSfpNum: UINT32,
    pub ulRpuNum: UINT32,
    pub ulBpuNum: UINT32,
    pub ulDryContactNum: UINT32,
    pub ulPathProperty: UINT32,
    pub ulPathPropertyNum: UINT32,
    pub ulClkProperty: UINT32,
    pub ulClkPropertyNum: UINT32,
    pub ulSerdesProperty: UINT32,
    pub ulSerdesPropertyNum: UINT32,
    pub ulTempProperty: UINT32,
    pub ulTempPropertyNum: UINT32,
    pub ulPwrCtrlProperty: UINT32,
    pub ulPwrCtrlPropertyNum: UINT32,
    pub ulPwrReadProperty: UINT32,
    pub ulPwrReadPropertyNum: UINT32,
    pub ulPaProperty: UINT32,
    pub ulPaPropertyNum: UINT32,
    pub ulOptProperty: UINT32,
    pub ulOptPropertyNum: UINT32,
    pub ulResistorProperty: UINT32,
    pub ulResistorPropertyNum: UINT32,
    pub ulNsbtSupport: UINT32,
    pub ulOptSpeedMask: UINT32,
    pub ulPaGridVoltMap: UINT32,
    pub aulTxPrxShareLo: [UINT32; 64],
    pub aulTxTxShareLo: [UINT32; 64],
    pub aulInputAisgVolt: [UINT32; 3],
    pub ulOptMaxSpeed: [UINT32; 12],
    pub aulBoardTxIfFreqBw: [[UINT32; 3]; 64],
    pub aulBoardRxIfFreqBw: [[UINT32; 3]; 64],
    pub alBoardTxIfFreq: [INT32; 64],
    pub alBoardRxIfFreq: [INT32; 64],
    pub alBoardPrxIfFreq: [INT32; 64],
    pub aulBoardBandFlag: [[UINT32; 3]; 64],
    pub aucBoardDescription: [libc::c_char; 128],
    pub aucModuleGroupName: [libc::c_char; 128],
    pub aucBoardGroupName: [libc::c_char; 128],
    pub aucBoardName: [libc::c_char; 128],
    pub aucBoardPcbSerial: [UINT8; 128],
    pub aucBoardHard: [UINT8; 128],
    pub aucProductTime: [libc::c_char; 128],
    pub aucLastServiceDate: [libc::c_char; 128],
    pub aucVendorName: [libc::c_char; 128],
    pub aucPwrType: [libc::c_char; 128],
    pub aucPwrVer: [libc::c_char; 128],
    pub aucPwrConsumedPower: [libc::c_char; 128],
    pub aucPaCfgFreq: [libc::c_char; 128],
    pub aucPaSupportDtx: [INT8; 128],
    pub tFreqStartEndTx: [TFreqStartEnd; 64],
    pub tFreqStartEndRx: [TFreqStartEnd; 64],
    pub bandFlagInfo: TBandInfo,
    pub pDeviceInfoDscp: *mut TRruDeviceDescription,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct TRruDeviceDescription {
    pub ulPathIndex: UINT32,
    pub ulPathProperty: UINT32,
    pub ulDeviceType: UINT32,
    pub ulDeviceAddr: UINT32,
    pub ulDeviceCfg: UINT32,
    pub ulDeviceId: UINT32,
    pub ulDeviceName: UINT32,
    pub ulDeviceInit: UINT32,
    pub ulDeviceIndex: UINT32,
    pub ulDeviceInterIndex: UINT32,
    pub acPathName: [CHAR; 128],
    pub acDeviceId: [libc::c_char; 128],
    pub acDeviceName: [CHAR; 128],
    pub acBusName: [CHAR; 20],
    pub ulBusId: UINT32,
    pub acRev: [CHAR; 128],
}
pub type TBandInfo = tagBandInfoDescription;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct tagBandInfoDescription {
    pub bandNum: UINT32,
    pub bandFlag: [[UINT32; 65]; 8],
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct T_HwInfo {
    pub RruInfo: TAdpRruInfoNew,
    pub BoardInfo: TAdpBoardInfoNew,
    pub PibInfo: TAdpPibInfo,
    pub PwrInfo: [TAdpPwrInfoNew; 3],
    pub PaInfo: [TAdpPaInfoNew; 4],
    pub DflInfo: [TAdpDflInfoNew; 64],
    pub AntInfo: [TAdpAntInfoNew; 2],
}
pub type TAdpAntInfoNew = tagAdpAntInfoNew;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct tagAdpAntInfoNew {
    pub aucBarCode: [libc::c_char; 128],
    pub ulAntAppType: UINT32,
    pub ulAntNum: UINT32,
    pub ulAntFactoryId: UINT32,
    pub ulServiceTime: UINT32,
    pub aucProductTime: [libc::c_char; 128],
    pub aucLastServiceDate: [libc::c_char; 128],
    pub aucVendorName: [libc::c_char; 128],
    pub aucBoardName: [libc::c_char; 128],
}
pub type TAdpDflInfoNew = tagAdpDflInfoNew;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct tagAdpDflInfoNew {
    pub aucBarCode: [libc::c_char; 128],
    pub ulDflAppType: UINT32,
    pub ulDflAntNum: UINT32,
    pub ulDflFactoryId: UINT32,
    pub ulServiceTime: UINT32,
    pub ulDflCommVer: UINT32,
    pub ulDflLanGain: UINT32,
    pub aucProductTime: [libc::c_char; 128],
    pub aucLastServiceDate: [libc::c_char; 128],
    pub aucVendorName: [libc::c_char; 128],
    pub aucBoardName: [libc::c_char; 128],
    pub aucNsbt: [libc::c_char; 128],
    pub tFreqInfoTx: [[TFreqStartEnd; 64]; 65],
    pub tFreqInfoRx: [[TFreqStartEnd; 64]; 65],
    pub tTxFreqInfo: TFreqStartEnd,
    pub tRxFreqInfo: TFreqStartEnd,
}
pub type TAdpPaInfoNew = tagAdpPaInfoNew;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct tagAdpPaInfoNew {
    pub aucBarCode: [libc::c_char; 128],
    pub ulPaType: UINT32,
    pub ulPaVer: UINT32,
    pub ulPaPath: UINT32,
    pub aucPaSupportDtx: [libc::c_char; 128],
    pub ulPaFactoryId: UINT32,
    pub ulServiceTime: UINT32,
    pub ulPaCommVer: UINT32,
    pub aulPaRatedPower: [UINT32; 64],
    pub aucPaCfgFreq: [libc::c_char; 128],
    pub aucPaBoardName: [libc::c_char; 128],
    pub aucProductTime: [libc::c_char; 128],
    pub aucLastServiceDate: [libc::c_char; 128],
    pub aucVendorName: [libc::c_char; 128],
    pub aucBoardName: [libc::c_char; 128],
    pub tFreqStartEnd: [TFreqStartEnd; 64],
    pub tFreqStartEndTx: TFreqStartEnd,
}
pub type TAdpPwrInfoNew = tagAdpPwrInfoNew;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct tagAdpPwrInfoNew {
    pub aucBarCode: [libc::c_char; 128],
    pub ulPwrCommVer: UINT32,
    pub ulPwrVoltUp: UINT32,
    pub ulPwrVoltDown: UINT32,
    pub ulPwrCapability: UINT32,
    pub ulPwrFactoryId: UINT32,
    pub ulServiceTime: UINT32,
    pub ulPwrType: UINT32,
    pub ulPwrVer: UINT32,
    pub ulAcInputVoltType: UINT32,
    pub aucPwrType: [libc::c_char; 128],
    pub aucPwrVer: [libc::c_char; 128],
    pub ucAcInputVoltType: [libc::c_char; 128],
    pub aucProductTime: [libc::c_char; 128],
    pub aucLastServiceDate: [libc::c_char; 128],
    pub aucVendorName: [libc::c_char; 128],
    pub aucBoardName: [libc::c_char; 128],
    pub aucConsumedPower: [libc::c_char; 128],
    pub ulDefPwrNum: UINT32,
    pub ulDefPwrVoltN: [UINT32; 4],
    pub ulPwrVoltUpN: [UINT32; 4],
    pub ulPwrVoltDownN: [UINT32; 4],
    pub ulPwrCapabilityN: [UINT32; 4],
}
pub type TAdpPibInfo = tagAdpPibInfo;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct tagAdpPibInfo {
    pub aucBarCode: [libc::c_char; 128],
    pub ulPidFactoryId: UINT32,
    pub ulPibType: UINT32,
    pub ulPibVer: UINT32,
    pub ulServiceTime: UINT32,
    pub ulPibCommVer: UINT32,
    pub aucProductTime: [libc::c_char; 128],
    pub aucLastServiceDate: [libc::c_char; 128],
    pub aucVendorName: [libc::c_char; 128],
    pub aucBoardName: [libc::c_char; 128],
}
pub type TAdpRruInfoNew = tagAdpRruInfoNew;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct tagAdpRruInfoNew {
    pub aucBarCode: [libc::c_char; 128],
    pub aucProductTime: [libc::c_char; 128],
    pub ulServiceTime: UINT32,
    pub aucLastServiceDate: [libc::c_char; 128],
    pub ulRruAntNum: UINT32,
    pub ulRruAntFlag: UINT32,
    pub ulRruTxNumInfo: [UINT32; 65],
    pub ulRruRxNumInfo: [UINT32; 65],
    pub ulRruTrxNum: UINT32,
    pub ulRruPaNum: UINT32,
    pub ulRruDflNum: UINT32,
    pub ulRruPwrNum: UINT32,
    pub ulRruPibNum: UINT32,
    pub ulRruCoPaAntNum: UINT32,
    pub ulRruModeInfo: UINT32,
    pub ulPidFlag: UINT32,
    pub ulRatedPowerTx: UINT32,
    pub ulRruBandNum: UINT32,
    pub ulCombBoard: UINT32,
    pub aulRatedBandPowerPath: [UINT32; 2],
    pub aulRatedPowerPath: [UINT32; 64],
    pub aulRatedPowerTemp: [[UINT32; 3]; 65],
    pub aulPaOutPowerPath: [UINT32; 64],
    pub aulPaOutPowerTemp: [[UINT32; 3]; 65],
    pub aulValidPowerPath: [UINT32; 64],
    pub aulValidPowerTemp: [[UINT32; 3]; 65],
    pub aucFamilyType: [libc::c_char; 128],
    pub aucTypeNumber: [libc::c_char; 128],
    pub aucPIDNumber: [libc::c_char; 128],
    pub aucVendorName: [libc::c_char; 128],
    pub aucBomCode: [libc::c_char; 128],
    pub aucSupplierCode: [libc::c_char; 128],
    pub tFreqStartEndTx: [TFreqStartEnd; 64],
    pub tFreqStartEndRx: [TFreqStartEnd; 64],
    pub ulCombLoss: [[UINT32; 3]; 65],
    pub aucBomidCheck: [libc::c_char; 128],
}
pub type TRruType = tagRruType;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct tagRruType {
    pub nameIdx: UINT32,
    pub nameStr: [libc::c_char; 32],
}
pub type CheckSupportRadar = Option::<unsafe extern "C" fn() -> UINT32>;
pub type FuncGetChannelNumByFuncSet = Option::<unsafe extern "C" fn() -> UINT32>;
pub type SOFTLIB_LOG_STARTUP_INFO_FUNC = Option::<
    unsafe extern "C" fn(UINT32, *mut CHAR) -> UINT32,
>;
pub type TExtraFilter = tagExtraFilterInfoDescription;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct tagExtraFilterInfoDescription {
    pub aulFreqStart: [UINT32; 3],
    pub aulFreqEnd: [UINT32; 3],
}
pub type FUNC_GET_ANTDFLINFO = Option::<
    unsafe extern "C" fn(UINT32, UINT32, *mut UINT32, *mut UINT32) -> UINT32,
>;
pub type GET_RRU_RATED_POWER = Option::<
    unsafe extern "C" fn(UINT32, *mut UINT32) -> UINT32,
>;
pub type pFUNC_SET_AAU_PATH_RATE_PWR = Option::<
    unsafe extern "C" fn(UINT32, UINT32, UINT32, UINT32) -> UINT32,
>;
pub type FUNC_INFO_COPY_ANT0 = Option::<unsafe extern "C" fn() -> UINT32>;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct T_BandInfo {
    pub dir: UINT32,
    pub bandNo: UINT32,
    pub centerFrq: UINT32,
    pub startFreq: UINT32,
    pub endFreq: UINT32,
}
pub type T_RruBoardBandInfo = tagT_RruBoardBandInfo;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct tagT_RruBoardBandInfo {
    pub bandNum: ULONG,
    pub bandPower: ULONG,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct T_BoardBandInfo {
    pub bandFlag: UINT32,
    pub pName: *const CHAR,
}
pub const TBL_KIND_OF_TXGAIN: e_TblTypeDefine = 0;
pub const TBL_KIND_OF_TxREV: e_TblTypeDefine = 2;
pub const TBL_KIND_OF_RXRSSI: e_TblTypeDefine = 7;
pub const TBL_KIND_OF_TxFWD_DB: e_TblTypeDefine = 52;
pub const TBL_KIND_OF_TxFWD: e_TblTypeDefine = 1;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct T_ProductDate {
    pub year: UINT32,
    pub month: UINT32,
    pub day: UINT32,
}
pub type TCommHeader = tagT_adjTableHeader;
#[derive(Copy, Clone)]
#[repr(C, packed)]
pub struct tagT_adjTableHeader {
    pub ulVer: UINT32,
    pub ulPathNum: UINT32,
    pub aucInfo: [libc::c_char; 25],
    pub aucDate: [libc::c_char; 25],
    pub aucOperator: [libc::c_char; 25],
    pub aucChecker: [libc::c_char; 25],
}
pub type TTxGainCaliData = tagTxGainCaliData;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct tagTxGainCaliData {
    pub tComHeader: TCommHeader,
    pub atTxGainCaliPath: [TTxGainCaliPath; 64],
}
pub type TTxGainCaliPath = tagTxGainPathData;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct tagTxGainPathData {
    pub tHeader: T_TxGainCaliHeader,
    pub ulIfRecordNum: UINT32,
    pub ulIfLoadFlag: UINT32,
    pub ulRfLoadFalg: UINT32,
    pub aulRfRecordNum: [UINT32; 3],
    pub aulRfLoadFlag: [UINT32; 3],
    pub ptIfRecord: *mut T_FreqRecord,
    pub patRfRecord: [*mut T_FreqRecord; 3],
}
pub type T_FreqRecord = tagT_FreqRecord;
#[derive(Copy, Clone)]
#[repr(C, packed)]
pub struct tagT_FreqRecord {
    pub lFreq: INT32,
    pub lCompVal: INT32,
    pub lBoardTemp: INT32,
    pub lPaTemp: INT32,
}
pub type T_TxGainCaliHeader = tag_TxGainHeader;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct tag_TxGainHeader {
    pub ulPathIndex: UINT32,
    pub aucTestBench: [libc::c_char; 25],
    pub aucSignalType: [libc::c_char; 25],
    pub lIfTssi_Ref_TxGain: [INT32; 2],
    pub lDigitalGain_TxGain: INT32,
    pub lDacGain_TxGain: INT32,
    pub lDefaultAtt_TxGain: INT32,
    pub lRfFreqInIfRipple: INT32,
    pub lIfFreqInRfRipple: INT32,
    pub lIfCaliBaseValue: INT32,
    pub ulCaliVolt: UINT32,
    pub ulIfNum: UINT32,
    pub ulIfRange: UINT32,
    pub ulIfStep: UINT32,
    pub ulRfBandNum: UINT32,
    pub aulStartFreq: [UINT32; 3],
    pub aulStopFreq: [UINT32; 3],
    pub aulRfStep: [UINT32; 3],
}
pub type TTxRevCaliData = tagTxRevCaliData;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct tagTxRevCaliData {
    pub tComHeader: TCommHeader,
    pub atTxRevCaliPath: [TTxRevCaliPath; 64],
}
pub type TTxRevCaliPath = tagTxRevPathData;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct tagTxRevPathData {
    pub tHeader: T_TxRevCaliHeader,
    pub ulIfRecordNum: UINT32,
    pub ulIfLoadFlag: UINT32,
    pub ulRfLoadFalg: UINT32,
    pub aulRfRecordNum: [UINT32; 3],
    pub aulRfLoadFlag: [UINT32; 3],
    pub ptIfRecord: *mut T_FreqRecord,
    pub patRfRecord: [*mut T_FreqRecord; 3],
}
pub type T_TxRevCaliHeader = tag_TxRevHeader;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct tag_TxRevHeader {
    pub ulPathIndex: UINT32,
    pub aucTestBench: [UCHAR; 25],
    pub aucSignalType: [libc::c_char; 25],
    pub lPrxDefaultAtt: INT32,
    pub lPrxVgaValue: INT32,
    pub lPrxAdcGain: INT32,
    pub lPrxDigitalGain: INT32,
    pub lFwdRefValue: [INT32; 2],
    pub lRfFreqInIfRipple: INT32,
    pub lIfFreqInRfRipple: INT32,
    pub lIfCaliBaseValue: INT32,
    pub ulCaliVolt: UINT32,
    pub ulIfNum: UINT32,
    pub ulIfRange: UINT32,
    pub ulIfStep: UINT32,
    pub ulRfBandNum: UINT32,
    pub aulStartFreq: [UINT32; 3],
    pub aulStopFreq: [UINT32; 3],
    pub aulRfStep: [UINT32; 3],
}
pub type TRxRssiCaliData = tagRxRssiCaliData;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct tagRxRssiCaliData {
    pub tComHeader: TCommHeader,
    pub atRxRssiCaliPath: [TRxRssiCaliPath; 64],
}
pub type TRxRssiCaliPath = tagRxRssiPathData;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct tagRxRssiPathData {
    pub tHeader: T_RxRssiCaliHeader,
    pub ulIfRecordNum: UINT32,
    pub ulIfLoadFlag: UINT32,
    pub ulRfLoadFalg: UINT32,
    pub aulRfRecordNum: [UINT32; 3],
    pub aulRfLoadFlag: [UINT32; 3],
    pub ptIfRecord: *mut T_FreqRecord,
    pub patRfRecord: [*mut T_FreqRecord; 3],
}
pub type T_RxRssiCaliHeader = tag_RxRssiHeader;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct tag_RxRssiHeader {
    pub ulPathIndex: UINT32,
    pub aucTestBench: [libc::c_char; 25],
    pub aucSignalType: [libc::c_char; 25],
    pub lRxDefaultAtt: INT32,
    pub lRxVgaValue: INT32,
    pub lRxAdcGain: INT32,
    pub lRxDigitalGain: INT32,
    pub lBbRssiRefValue: INT32,
    pub lRfFreqInIfRipple: INT32,
    pub lIfFreqInRfRipple: INT32,
    pub lIfCaliBaseValue: INT32,
    pub ulCaliVolt: UINT32,
    pub ulIfNum: UINT32,
    pub ulIfRange: UINT32,
    pub ulIfStep: UINT32,
    pub ulRfBandNum: UINT32,
    pub aulStartFreq: [UINT32; 3],
    pub aulStopFreq: [UINT32; 3],
    pub aulRfStep: [UINT32; 3],
}
pub type TTxFwd_DbCaliData = tagTxFwd_DbCaliData;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct tagTxFwd_DbCaliData {
    pub tComHeader: TCommHeader,
    pub atTxFwd_DbCaliPath: [TTxFwd_DbCaliPath; 64],
}
pub type TTxFwd_DbCaliPath = tagTxFwd_DbPathData;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct tagTxFwd_DbPathData {
    pub tHeader: T_TxFwd_DbCaliHeader,
    pub ulIfRecordNum: UINT32,
    pub ulIfLoadFlag: UINT32,
    pub ulRfLoadFalg: UINT32,
    pub aulRfRecordNum: [UINT32; 3],
    pub aulRfLoadFlag: [UINT32; 3],
    pub ptIfRecord: *mut T_FreqRecord,
    pub patRfRecord: [*mut T_FreqRecord; 3],
}
pub type T_TxFwd_DbCaliHeader = tag_TxFwd_dbHeader;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct tag_TxFwd_dbHeader {
    pub ulPathIndex: UINT32,
    pub aucTestBench: [libc::c_char; 25],
    pub aucSignalType: [libc::c_char; 25],
    pub lPrxDefaultAtt: INT32,
    pub lPrxVgaValue: INT32,
    pub lPrxAdcGain: INT32,
    pub lPrxDigitalGain: INT32,
    pub lFwdRefValue: [INT32; 2],
    pub lRfFreqInIfRipple: INT32,
    pub lIfFreqInRfRipple: INT32,
    pub lIfCaliBaseValue: INT32,
    pub ulCaliVolt: UINT32,
    pub ulIfNum: UINT32,
    pub ulIfRange: UINT32,
    pub ulIfStep: UINT32,
    pub ulRfBandNum: UINT32,
    pub aulStartFreq: [UINT32; 3],
    pub aulStopFreq: [UINT32; 3],
    pub aulRfStep: [UINT32; 3],
}
pub type TTxFwdCaliData = tagTxFwdCaliData;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct tagTxFwdCaliData {
    pub tComHeader: TCommHeader,
    pub atTxFwdCaliPath: [TTxFwdCaliPath; 64],
}
pub type TTxFwdCaliPath = tagTxFwdPathData;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct tagTxFwdPathData {
    pub tHeader: T_TxFwdCaliHeader,
    pub ulIfRecordNum: UINT32,
    pub ulIfLoadFlag: UINT32,
    pub ulRfLoadFalg: UINT32,
    pub aulRfRecordNum: [UINT32; 3],
    pub aulRfLoadFlag: [UINT32; 3],
    pub ptIfRecord: *mut T_FreqRecord,
    pub patRfRecord: [*mut T_FreqRecord; 3],
}
pub type T_TxFwdCaliHeader = tag_TxFwdHeader;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct tag_TxFwdHeader {
    pub ulPathIndex: UINT32,
    pub aucTestBench: [libc::c_char; 25],
    pub aucSignalType: [libc::c_char; 25],
    pub lPrxDefaultAtt: INT32,
    pub lPrxVgaValue: INT32,
    pub lPrxAdcGain: INT32,
    pub lPrxDigitalGain: INT32,
    pub lFwdRefValue: [INT32; 2],
    pub lRfFreqInIfRipple: INT32,
    pub lIfFreqInRfRipple: INT32,
    pub lIfCaliBaseValue: INT32,
    pub ulCaliVolt: UINT32,
    pub ulIfNum: UINT32,
    pub ulIfRange: UINT32,
    pub ulIfStep: UINT32,
    pub ulRfBandNum: UINT32,
    pub aulStartFreq: [UINT32; 3],
    pub aulStopFreq: [UINT32; 3],
    pub aulRfStep: [UINT32; 3],
}
pub type FUNC_GET_CUSTOMATTR = Option::<
    unsafe extern "C" fn(*mut libc::c_char) -> UINT32,
>;
pub type pFUNC_GET_AAU_PATH_RATE_PWR = Option::<
    unsafe extern "C" fn(UINT32, UINT32, *mut UINT32) -> UINT32,
>;
pub type pFUNC_GET_RPU_TBL_TYPE = Option::<
    unsafe extern "C" fn(UINT32, UINT32, *mut UINT32) -> UINT32,
>;
pub type pFUNC_SET_RPU_TBL_TYPE = Option::<
    unsafe extern "C" fn(UINT32, UINT32, UINT32) -> UINT32,
>;
pub type SOFTLIB_BOOTP_BBX_FILE_FUNC = Option::<
    unsafe extern "C" fn(UINT32, UINT32) -> UINT32,
>;
pub const E_STA_CALL_FUNC_ID_TRSV_SERDES: E_DEV_PROP_RUN_STA_CALLBACK_FUNC_ID = 6;
pub const E_STA_CALL_FUNC_ID_TRSV_PLL_LD: E_DEV_PROP_RUN_STA_CALLBACK_FUNC_ID = 5;
pub const E_STA_CALL_FUNC_ID_AD_LANE_CRC: E_DEV_PROP_RUN_STA_CALLBACK_FUNC_ID = 4;
pub const E_STA_CALL_FUNC_ID_UDS_SELFCHK: E_DEV_PROP_RUN_STA_CALLBACK_FUNC_ID = 3;
pub const E_STA_CALL_FUNC_ID_LIMIT_AMPER: E_DEV_PROP_RUN_STA_CALLBACK_FUNC_ID = 2;
pub const E_STA_CALL_FUNC_ID_RFDEV_MIXER: E_DEV_PROP_RUN_STA_CALLBACK_FUNC_ID = 1;
pub const E_STA_CALL_FUNC_ID_FPGA_PLL_LD: E_DEV_PROP_RUN_STA_CALLBACK_FUNC_ID = 0;
pub type FUNC_GET_HD_DEV_WORK_STATUS = Option::<
    unsafe extern "C" fn(UINT32, UINT32, *mut UINT32) -> UINT32,
>;
pub const E_STA_CALL_FUNC_ID_DEF_MAX_SUM: E_DEV_PROP_RUN_STA_CALLBACK_FUNC_ID = 7;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct tagCellRsrp {
    pub ulRadioMode: UINT32,
    pub ulPci: UINT32,
    pub ulFreq: UINT32,
    pub ulRsrp: UINT32,
    pub alRsrp: [INT32; 8],
    pub ulChnNum: UINT32,
    pub fSinr: [FLOAT; 8],
}
pub type T_CellRsrp = tagCellRsrp;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct tagCellLock {
    pub ulRadioMode: UINT32,
    pub ulPci: UINT32,
    pub ulFreq: UINT32,
}
pub type T_CellLock = tagCellLock;
pub type FUNC_GET_RSRP_DELTA = Option::<unsafe extern "C" fn(UINT32) -> INT32>;
pub type FUNC_SET_RSRP_DELTA = Option::<unsafe extern "C" fn(UINT32, INT32) -> ()>;
pub type RfGetAntWavePwrAlmType = Option::<unsafe extern "C" fn(*mut UINT32) -> UINT32>;
pub type C2RustUnnamed = libc::c_uint;
pub const BOM_ID_NUM: C2RustUnnamed = 8;
pub const BOMID_CRC_DATA: C2RustUnnamed = 7;
pub const HW_CUSTOM_ID_B: C2RustUnnamed = 5;
pub const HW_CUSTOM_ID_A: C2RustUnnamed = 4;
pub type e_chip_type = libc::c_uint;
pub const DEVICE_NUM: e_chip_type = 170;
pub const DEVICE_CP3X: e_chip_type = 169;
pub const DEVICE_NCS2301X: e_chip_type = 168;
pub const DEVICE_TSW92304: e_chip_type = 167;
pub const DEVICE_TSW91301: e_chip_type = 166;
pub const DEVICE_ZX234992: e_chip_type = 165;
pub const DEVICE_MTS21MPW: e_chip_type = 164;
pub const DEVICE_MTS21PRE: e_chip_type = 163;
pub const DEVICE_TSW91302: e_chip_type = 162;
pub const DEVICE_AFE7920: e_chip_type = 161;
pub const DEVICE_JW805608A: e_chip_type = 160;
pub const DEVICE_TR8165: e_chip_type = 159;
pub const DEVICE_MSTR207: e_chip_type = 158;
pub const DEVICE_PD4600M48A: e_chip_type = 157;
pub const DEVICE_MPQ8796: e_chip_type = 156;
pub const DEVICE_AD5592: e_chip_type = 155;
pub const DEVICE_PD0510T12A: e_chip_type = 154;
pub const DEVICE_PD1800T48A: e_chip_type = 153;
pub const DEVICE_ADRF6520: e_chip_type = 152;
pub const DEVICE_ADS7953: e_chip_type = 151;
pub const DEVICE_RTQ8826: e_chip_type = 150;
pub const DEVICE_MX25FLASH: e_chip_type = 149;
pub const DEVICE_PL1301D48A: e_chip_type = 148;
pub const DEVICE_LMK01000: e_chip_type = 147;
pub const DEVICE_RTQ8825: e_chip_type = 146;
pub const DEVICE_PL1700D48A: e_chip_type = 145;
pub const DEVICE_MTS2PRE: e_chip_type = 144;
pub const DEVICE_TMP451: e_chip_type = 143;
pub const DEVICE_PXM1600: e_chip_type = 142;
pub const DEVICE_MPS: e_chip_type = 141;
pub const DEVICE_IPD600: e_chip_type = 140;
pub const DEVICE_MTS: e_chip_type = 139;
pub const DEVICE_SHU1X: e_chip_type = 138;
pub const DEVICE_XILINX: e_chip_type = 137;
pub const DEVICE_DS280DF810: e_chip_type = 136;
pub const DEVICE_TPS54C623: e_chip_type = 135;
pub const DEVICE_TPS53667: e_chip_type = 134;
pub const DEVICE_TQM879008: e_chip_type = 133;
pub const DEVICE_TQC9311: e_chip_type = 132;
pub const DEVICE_TLK6002: e_chip_type = 131;
pub const DEVICE_SFF8636: e_chip_type = 130;
pub const DEVICE_SFP: e_chip_type = 129;
pub const DEVICE_S680: e_chip_type = 128;
pub const DEVICE_RFDA2026: e_chip_type = 127;
pub const DEVICE_RFDA0057: e_chip_type = 126;
pub const DEVICE_RESISTOR: e_chip_type = 125;
pub const DEVICE_RDA1005: e_chip_type = 124;
pub const DEVICE_PXM1310: e_chip_type = 123;
pub const DEVICE_PPC3XUART: e_chip_type = 122;
pub const DEVICE_PD1302D48A: e_chip_type = 121;
pub const DEVICE_PD1600T48A: e_chip_type = 120;
pub const DEVICE_PD1500T28A: e_chip_type = 119;
pub const DEVICE_PD1500T48A: e_chip_type = 118;
pub const DEVICE_PD1300T28A: e_chip_type = 117;
pub const DEVICE_PPC34D034: e_chip_type = 116;
pub const DEVICE_PPC34D033: e_chip_type = 115;
pub const DEVICE_PPC34D026: e_chip_type = 114;
pub const DEVICE_PPC33D012A: e_chip_type = 113;
pub const DEVICE_PPC33D012: e_chip_type = 112;
pub const DEVICE_PI33XX: e_chip_type = 111;
pub const DEVICE_PE43712: e_chip_type = 110;
pub const DEVICE_PE43711: e_chip_type = 109;
pub const DEVICE_PE4302: e_chip_type = 108;
pub const DEVICE_PCA9548A: e_chip_type = 107;
pub const DEVICE_PCA9557: e_chip_type = 106;
pub const DEVICE_PANGO: e_chip_type = 105;
pub const DEVICE_PAMCU: e_chip_type = 104;
pub const DEVICE_PA9S08GQ8: e_chip_type = 103;
pub const DEVICE_NCT218: e_chip_type = 102;
pub const DEVICE_NXPSA56004X: e_chip_type = 101;
pub const DEVICE_MX66FLASH: e_chip_type = 100;
pub const DEVICE_MAX6656: e_chip_type = 99;
pub const DEVICE_MAX6648: e_chip_type = 98;
pub const DEVICE_MAX2870: e_chip_type = 97;
pub const DEVICE_MAX1617: e_chip_type = 96;
pub const DEVICE_STW81200: e_chip_type = 95;
pub const DEVICE_LMX2594: e_chip_type = 94;
pub const DEVICE_LMX2592: e_chip_type = 93;
pub const DEVICE_LMX2582: e_chip_type = 92;
pub const DEVICE_LMX2581: e_chip_type = 91;
pub const DEVICE_LMX2531: e_chip_type = 90;
pub const DEVICE_IDT19N490: e_chip_type = 89;
pub const DEVICE_LMK04832: e_chip_type = 88;
pub const DEVICE_LMK04821: e_chip_type = 87;
pub const DEVICE_LMK04800: e_chip_type = 86;
pub const DEVICE_LMH6521: e_chip_type = 85;
pub const DEVICE_CT75: e_chip_type = 84;
pub const DEVICE_LM75: e_chip_type = 83;
pub const DEVICE_LATTICE: e_chip_type = 82;
pub const DEVICE_INA220: e_chip_type = 81;
pub const DEVICE_IDT8A35018D: e_chip_type = 80;
pub const DEVICE_IDT97053: e_chip_type = 79;
pub const DEVICE_XN406: e_chip_type = 78;
pub const DEVICE_HMC830: e_chip_type = 77;
pub const DEVICE_HMC822: e_chip_type = 76;
pub const DEVICE_HMC1190: e_chip_type = 75;
pub const DEVICE_FPGATEMP: e_chip_type = 74;
pub const DEVICE_FPGATT: e_chip_type = 73;
pub const DEVICE_GPS: e_chip_type = 72;
pub const DEVICE_FPGA_LOAD: e_chip_type = 71;
pub const DEVICE_BGU8821: e_chip_type = 70;
pub const DEVICE_BGU8822: e_chip_type = 69;
pub const DEVICE_BVA72X2: e_chip_type = 68;
pub const DEVICE_F1455: e_chip_type = 67;
pub const DEVICE_F1350: e_chip_type = 66;
pub const DEVICE_EPLD_PA: e_chip_type = 65;
pub const DEVICE_EPLD: e_chip_type = 64;
pub const DEVICE_DS125MB203: e_chip_type = 63;
pub const DEVICE_DS280MB810: e_chip_type = 62;
pub const DEVICE_DSP6748: e_chip_type = 61;
pub const DEVICE_DAC6571: e_chip_type = 60;
pub const DEVICE_DAC38J84: e_chip_type = 59;
pub const DEVICE_DAC34SH84: e_chip_type = 58;
pub const DEVICE_DAC34J84: e_chip_type = 57;
pub const DEVICE_DAC128S085: e_chip_type = 56;
pub const DEVICE_AU5518: e_chip_type = 55;
pub const DEVICE_AU5331: e_chip_type = 54;
pub const DEVICE_ANLOGIC: e_chip_type = 53;
pub const DEVICE_TPAFE0648: e_chip_type = 52;
pub const DEVICE_AMC7948: e_chip_type = 51;
pub const DEVICE_AMC7932: e_chip_type = 50;
pub const DEVICE_AMC7836: e_chip_type = 49;
pub const DEVICE_AMC7832: e_chip_type = 48;
pub const DEVICE_AMC7812: e_chip_type = 47;
pub const DEVICE_ALTER: e_chip_type = 46;
pub const DEVICE_ADMV1017: e_chip_type = 45;
pub const DEVICE_ADMV101X: e_chip_type = 44;
pub const DEVICE_ADL5335: e_chip_type = 43;
pub const DEVICE_ADT75: e_chip_type = 42;
pub const DEVICE_ADS58J64: e_chip_type = 41;
pub const DEVICE_ADS58J63: e_chip_type = 40;
pub const DEVICE_ADS58H40: e_chip_type = 39;
pub const DEVICE_ADS58C20: e_chip_type = 38;
pub const DEVICE_ADS54T02: e_chip_type = 37;
pub const DEVICE_ADC58J89: e_chip_type = 36;
pub const DEVICE_ADAR1004: e_chip_type = 35;
pub const DEVICE_SI5381: e_chip_type = 34;
pub const DEVICE_AD9545: e_chip_type = 33;
pub const DEVICE_AD9549: e_chip_type = 32;
pub const DEVICE_AD9516: e_chip_type = 31;
pub const DEVICE_AD32RF8X: e_chip_type = 30;
pub const DEVICE_AFE80XX: e_chip_type = 29;
pub const DEVICE_AFE7989: e_chip_type = 28;
pub const DEVICE_AFE7689: e_chip_type = 27;
pub const DEVICE_AFE7686: e_chip_type = 26;
pub const DEVICE_AFE7681: e_chip_type = 25;
pub const DEVICE_AD9379: e_chip_type = 24;
pub const DEVICE_AD9378: e_chip_type = 23;
pub const DEVICE_AD9373: e_chip_type = 22;
pub const DEVICE_AD9172: e_chip_type = 21;
pub const DEVICE_AD9142: e_chip_type = 20;
pub const DEVICE_AD9122: e_chip_type = 19;
pub const DEVICE_AD903X: e_chip_type = 18;
pub const DEVICE_AD80447: e_chip_type = 17;
pub const DEVICE_AD9025: e_chip_type = 16;
pub const DEVICE_AD9986: e_chip_type = 15;
pub const DEVICE_AD9988: e_chip_type = 14;
pub const DEVICE_AD6688: e_chip_type = 13;
pub const DEVICE_AD6674: e_chip_type = 12;
pub const DEVICE_AD6684: e_chip_type = 11;
pub const DEVICE_AD6657: e_chip_type = 10;
pub const DEVICE_AD8376: e_chip_type = 9;
pub const DEVICE_AD80321: e_chip_type = 8;
pub const DEVICE_AD08832: e_chip_type = 7;
pub const DEVICE_8V19N490: e_chip_type = 6;
pub const DEVICE_24CM03: e_chip_type = 5;
pub const DEVICE_24CM01: e_chip_type = 4;
pub const DEVICE_25M01: e_chip_type = 3;
pub const DEVICE_24C512: e_chip_type = 2;
pub const DEVICE_24C256: e_chip_type = 1;
pub const DEVICE_24C04: e_chip_type = 0;
pub type e_device_type = libc::c_uint;
pub const DEVICE_TYPE_CURR: e_device_type = 28;
pub const DEVICE_TYPE_REPEATER: e_device_type = 27;
pub const DEVICE_TYPE_BUSSWITCH: e_device_type = 26;
pub const DEVICE_TYPE_TRANSCEIVER: e_device_type = 25;
pub const DEVICE_TYPE_VVA: e_device_type = 24;
pub const DEVICE_TYPE_VGA: e_device_type = 23;
pub const DEVICE_TYPE_TEMP: e_device_type = 22;
pub const DEVICE_TYPE_SHIFTER: e_device_type = 21;
pub const DEVICE_TYPE_SERDES: e_device_type = 20;
pub const DEVICE_TYPE_RFEM: e_device_type = 19;
pub const DEVICE_TYPE_RFCHIP: e_device_type = 18;
pub const DEVICE_TYPE_RESISTOR: e_device_type = 17;
pub const DEVICE_TYPE_PWRCTRL: e_device_type = 16;
pub const DEVICE_TYPE_PWRCONSUMER: e_device_type = 15;
pub const DEVICE_TYPE_PWRCFG: e_device_type = 14;
pub const DEVICE_TYPE_PACFGFRQ: e_device_type = 13;
pub const DEVICE_TYPE_OPT: e_device_type = 12;
pub const DEVICE_TYPE_RFTRANSIVER: e_device_type = 11;
pub const DEVICE_TYPE_RFPLL: e_device_type = 10;
pub const DEVICE_TYPE_GRIDVOLT: e_device_type = 9;
pub const DEVICE_TYPE_FPGA: e_device_type = 8;
pub const DEVICE_TYPE_EEPROM: e_device_type = 7;
pub const DEVICE_TYPE_DPD: e_device_type = 6;
pub const DEVICE_TYPE_DAC: e_device_type = 5;
pub const DEVICE_TYPE_CONVERTER: e_device_type = 4;
pub const DEVICE_TYPE_CURRCFG: e_device_type = 3;
pub const DEVICE_TYPE_CLK: e_device_type = 2;
pub const DEVICE_TYPE_ATT: e_device_type = 1;
pub const DEVICE_TYPE_ADC: e_device_type = 0;
pub type E_DEV_PROP_RUN_STA_CALLBACK_FUNC_ID = libc::c_uint;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct TRruPropertyDescription {
    pub ulPathMask: UINT32,
    pub acDeviceId: [libc::c_char; 128],
    pub acDeviceName: [CHAR; 128],
    pub ulDeviceIndex: UINT32,
    pub ulDeviceInterIndex: UINT32,
    pub ulDeviceAddr: UINT32,
    pub ulDeviceCfg: UINT32,
    pub acPathName: [CHAR; 128],
    pub acBusName: [CHAR; 20],
    pub ulBusId: UINT32,
    pub acRev: [CHAR; 128],
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct TRruDeviceUpdateInfo {
    pub ulMask: UINT32,
    pub tDeviceDescription: TRruPropertyDescription,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct tagHwVerGroupNew {
    pub paraIndex: UINT32,
    pub groupInfo: TVerGroup,
}
pub type TVerGroupNew = tagHwVerGroupNew;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct tag_power_property_version {
    pub ulPropVer: UINT32,
    pub ulBrdLgcType: UINT32,
    pub aulCommVer: [UINT32; 3],
}
pub type T_PWR_PROP_VER = tag_power_property_version;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct tag_pa_property_version {
    pub ulPropVer: UINT32,
    pub ulBrdLgcType: UINT32,
    pub aulCommVer: [UINT32; 4],
}
pub type T_PA_PROP_VER = tag_pa_property_version;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct tag_QiTaoXingFileName {
    pub ucFileName: [libc::c_char; 128],
}
pub type T_QiTaoXingFileName = tag_QiTaoXingFileName;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct tag_QiTaoXing {
    pub ulFileNum: UINT32,
    pub ucFileNameList: [T_QiTaoXingFileName; 30],
}
pub type T_QiTaoXing = tag_QiTaoXing;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct tag_HwCustomIdAnalyseInfo {
    pub ulAnalyseFlag: UINT32,
    pub ulPaVoltType: UINT32,
    pub ulPaBankAType: UINT32,
    pub ulPaBankBType: UINT32,
    pub ulPaBypassFlag: UINT32,
    pub ulTecSupportFlag: UINT32,
    pub ulPlcSupportFlag: UINT32,
    pub ulPlcBrandType: UINT32,
    pub ulMcsChipType: UINT32,
    pub ulMcsDdrSizeType: UINT32,
    pub ulMcsDdrChipType: UINT32,
    pub ulOokSupportFlag: UINT32,
    pub ulFanSupportFlag: UINT32,
    pub ulEpldChipType: UINT32,
    pub ulSfpModuleType: UINT32,
    pub ulTestReserved: UINT32,
}
pub type T_HwCustomIdAnalyseInfo = tag_HwCustomIdAnalyseInfo;
pub type FUNC_GET_SOC_HWCFG = Option::<
    unsafe extern "C" fn(UINT32, *mut UINT32) -> UINT32,
>;
pub type FUNC_SET_ZNCR_CELL_INFO = Option::<
    unsafe extern "C" fn(UINT32, *mut T_CellLock) -> UINT32,
>;
pub type FUNC_ZNCR_CELL_INFO_IS_SEND = Option::<unsafe extern "C" fn() -> UINT32>;
pub type FUNC_CLEAR_ZNCR_CELL_INFO = Option::<
    unsafe extern "C" fn(UINT32, *mut T_CellLock) -> UINT32,
>;
pub type FUNC_GET_ZNCR_CELL_INFO = Option::<
    unsafe extern "C" fn(*mut UINT32, *mut T_CellLock) -> UINT32,
>;
pub type FUNC_GET_CELL_SIGNAL_STRENGTH = Option::<
    unsafe extern "C" fn(*mut UINT32, *mut T_CellRsrp) -> UINT32,
>;
pub type FUNC_GET_CELL_SIGNAL_STRENGTH_BY_RADIOMODE = Option::<
    unsafe extern "C" fn(UINT32, UINT32, *mut UINT32, *mut T_CellRsrp) -> UINT32,
>;
pub type FUNC_GET_DEVIIC_DRV_VALID_FLAG = Option::<
    unsafe extern "C" fn(UINT32, UINT32) -> UINT32,
>;
pub type T_VerGroupDscp = tag_hw_ver_group_dscp;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct tag_hw_ver_group_dscp {
    pub pHwVerGroup: *mut TVerGroup,
    pub hwVerGroupLen: UINT32,
}
pub type T_PWR_PROP_VER_DSCP = tag_power_property_version_dscp;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct tag_power_property_version_dscp {
    pub pPwrPropVer: *mut T_PWR_PROP_VER,
    pub pwrPropVerLen: UINT32,
}
pub type T_PA_PROP_VER_DSCP = tag_pa_property_version_dscp;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct tag_pa_property_version_dscp {
    pub pPaPropVer: *mut T_PA_PROP_VER,
    pub paPropVerLen: UINT32,
}
pub type T_BoardPropAscii = tagT_BoardPropAscii;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct tagT_BoardPropAscii {
    pub pPropAscii: *const CHAR,
    pub length: UINT32,
}
pub type FIELD_GET_FUNC = Option::<unsafe extern "C" fn(*mut UINT8) -> UINT32>;
pub type TNodeInfo = tagNodeInfo;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct tagNodeInfo {
    pub nodeIndex: UINT32,
    pub pFuncGetField: FIELD_GET_FUNC,
}
pub type TLogicMapInfo = tagLogicMapInfo;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct tagLogicMapInfo {
    pub acInfo: [CHAR; 128],
    pub ulValue: UINT32,
    pub ulKind: UINT32,
    pub ulRev: UINT32,
}
pub const BOARDPROP_PA_PROPERTY: C2RustUnnamed_1 = 18;
pub type T_InfoDescription = tagHardInfoDescription;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct tagHardInfoDescription {
    pub Field: UINT32,
    pub Type: UINT8,
    pub Ver: UINT8,
    pub Size: UINT8,
    pub Info: [libc::c_char; 40],
    pub pFuncGetField: FIELD_GET_FUNC,
}
pub type TFieldInfo = tagInfo;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct tagInfo {
    pub ulDevType: UINT32,
    pub ulDevIndex: UINT32,
    pub ulDevField: UINT32,
    pub ulResult: UINT32,
    pub aucInfo: [libc::c_char; 254],
}
pub type T_VerGroupDscpNew = tag_hw_ver_group_dscp_new;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct tag_hw_ver_group_dscp_new {
    pub pHwVerGroup: *mut TVerGroupNew,
    pub hwVerGroupLen: UINT32,
}
pub const BOARDPROP_HW_VERSION: C2RustUnnamed_1 = 10;
pub const BOARDPROP_VERSION: C2RustUnnamed_1 = 9;
pub const BOARDPROP_BSP_DBG_MODE: C2RustUnnamed_1 = 17;
pub const BOARDPROP_RESISTOR_PROPERTY_PRO: C2RustUnnamed_1 = 22;
pub const BOARDPROP_DEF_CFRDPD_PARA: C2RustUnnamed_1 = 21;
pub const BOARDPROP_CFRDPD_PARA: C2RustUnnamed_1 = 20;
pub const BOARDPROP_VOLT_READ_PROPERTY: C2RustUnnamed_1 = 19;
pub const BOARDPROP_OPT_PROPERTY: C2RustUnnamed_1 = 16;
pub const BOARDPROP_PWRCTRL_PROPERTY: C2RustUnnamed_1 = 15;
pub const BOARDPROP_TEMP_PROPERTY: C2RustUnnamed_1 = 14;
pub const BOARDPROP_SERDES_PROPERTY: C2RustUnnamed_1 = 13;
pub const BOARDPROP_CLK_PROPERTY: C2RustUnnamed_1 = 12;
pub const BOARD_RF_PATH_PROPERTY: C2RustUnnamed_1 = 11;
pub const RRUINFO_QITAOXING: C2RustUnnamed_1 = 8;
pub const RRUINFO_ANT: C2RustUnnamed_1 = 7;
pub const RRUINFO_PIB: C2RustUnnamed_1 = 6;
pub const RRUINFO_DFL: C2RustUnnamed_1 = 5;
pub const RRUINFO_PA: C2RustUnnamed_1 = 4;
pub const RRUINFO_PWR: C2RustUnnamed_1 = 3;
pub const RRUINFO_BOARD: C2RustUnnamed_1 = 2;
pub const RRUINFO_RRU: C2RustUnnamed_1 = 1;
pub const RRUINFO_VERSION: C2RustUnnamed_1 = 0;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct UpdateHandler {
    pub updateFunc: Option::<
        unsafe extern "C" fn(UINT32, *mut TRruDeviceUpdateInfo, UINT32) -> UINT32,
    >,
}
pub type TProPertyPathDef = _TProPertyPathDef;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct _TProPertyPathDef {
    pub NodeNum: UINT32,
    pub aNodeInfo: [TRruDeviceDescriptionN; 0],
}
pub type TRruDeviceDescriptionN = tagRruDeviceDescriptionN;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct tagRruDeviceDescriptionN {
    pub ulPathIndex: UINT32,
    pub ulDeviceAddr: UINT32,
    pub ulDeviceCfg: UINT32,
    pub ulDeviceIndex: UINT32,
    pub ulDeviceInterIndex: UINT32,
    pub ulPathDirOffset: UINT32,
    pub ulPathNameOffset: UINT32,
    pub ulDevTypeOffset: UINT32,
    pub ulDevIdOffset: UINT32,
    pub ulDevNameOffset: UINT32,
    pub ulBusNameOffset: UINT32,
    pub ulBusId: UINT32,
    pub ulRevOffset: UINT32,
    pub aStrInfo: [CHAR; 128],
}
pub const ENUM_PROPERT_VOLT_READ_PROPERTY: C2RustUnnamed_0 = 8;
pub const ENUM_PROPERT_PA_PROPERTY: C2RustUnnamed_0 = 7;
pub const ENUM_PROPERT_BOARD_PWRCTRL_PROPERTY: C2RustUnnamed_0 = 6;
pub const ENUM_PROPERT_BOARD_OPT_PROPERTY: C2RustUnnamed_0 = 5;
pub const ENUM_PROPERT_BOARD_TEMP_PROPERTY: C2RustUnnamed_0 = 4;
pub const ENUM_PROPERT_BOARD_CLK_PROPERTY: C2RustUnnamed_0 = 3;
pub const ENUM_PROPERT_BOARD_RF_PATH_DEFINE: C2RustUnnamed_0 = 2;
pub const ENUM_PROPERT_HEAD_INFO_MAX: C2RustUnnamed_0 = 9;
pub type TProPertyFileHead = _TProPertyFileHead;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct _TProPertyFileHead {
    pub EndiaFlag: UINT32,
    pub aucFileFlag: [UCHAR; 4],
    pub VersionFlag: UINT32,
    pub Num: [UINT32; 9],
    pub BlockNum: UINT32,
    pub tProInfo: [TProPertyFileHeadInfo; 400],
}
pub type TProPertyFileHeadInfo = _TProPertyFileHeadInfo;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct _TProPertyFileHeadInfo {
    pub Type: UINT32,
    pub Idx: UINT32,
    pub StartAddr: UINT32,
}
pub type TProPertyHdVerInfo = _TProPertyHdVerInfo;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct _TProPertyHdVerInfo {
    pub ModulGroupName: [UCHAR; 128],
    pub BdGroupName: [UCHAR; 128],
    pub TxPathNum: UINT32,
    pub TxPathInfoOffset: UINT32,
    pub RxPathNum: UINT32,
    pub RxPathInfoOffset: UINT32,
    pub PrxPathNum: UINT32,
    pub PrxPathInfoOffset: UINT32,
    pub OptNum: UINT32,
    pub SfpNum: UINT32,
    pub MaxOptSpeed: [UINT32; 10],
    pub RfPathIdx: UINT32,
    pub BdClkIdx: UINT32,
    pub BdSerdesIdx: UINT32,
    pub BdOptIdx: UINT32,
    pub BdPwrMonIdx: UINT32,
    pub BdPwrCtrIdx: UINT32,
    pub BdPaTmpIdx: UINT32,
    pub BdTmpIdx: UINT32,
    pub BdAisg0V: UINT32,
    pub BdAisg14V: UINT32,
    pub BdAisg22V: UINT32,
    pub BdAutoSpeedMask: UINT32,
    pub BdRpuNum: UINT32,
    pub BdBpuNum: UINT32,
    pub BdDryContactNum: UINT32,
    pub BdPaGridMap: UINT32,
    pub BdPwrType: [UCHAR; 128],
    pub BdPwrConsumedPower: [UCHAR; 128],
    pub BdPwrVer: [UCHAR; 128],
    pub BdPaCfgFreq: UINT32,
    pub BdSameFreqFlag: UINT32,
    pub bandFlagInfo: TRruBandInfo,
}
pub type TRruBandInfo = TBandInfoDescription;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct TBandInfoDescription {
    pub bandNum: UINT32,
    pub bandFlag: [[UINT32; 65]; 8],
}
pub type TProPertyPathInfo = _TProPertyPathInfo;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct _TProPertyPathInfo {
    pub BandNum: UINT32,
    pub StartFreq: [UINT32; 3],
    pub EndFreq: [UINT32; 3],
    pub IfBw: [UINT32; 3],
    pub IfFreq: [INT32; 3],
}
pub type TProPertyTxPathInfo = _TProPertyTxPathInfo;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct _TProPertyTxPathInfo {
    pub TxFreqInfo: TProPertyPathInfo,
    pub TxTxShareLo: UINT32,
    pub TxPrxShareLo: UINT32,
    pub TxBand: [[CHAR; 32]; 3],
}
pub const ENUM_PROPERT_HARD_VERSION: C2RustUnnamed_0 = 1;
pub type T_CodeInfo = tagT_CodeInfo;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct tagT_CodeInfo {
    pub app_code_branch: *const libc::c_char,
    pub app_code_hash: *const libc::c_char,
    pub bsp_code_branch: *const libc::c_char,
    pub bsp_code_hash: *const libc::c_char,
    pub build_code_branch: *const libc::c_char,
    pub build_code_hash: *const libc::c_char,
    pub common_code_branch: *const libc::c_char,
    pub common_code_hash: *const libc::c_char,
    pub tools_code_branch: *const libc::c_char,
    pub tools_code_hash: *const libc::c_char,
    pub version_code_branch: *const libc::c_char,
    pub version_code_hash: *const libc::c_char,
    pub aaubb_code_branch: *const libc::c_char,
    pub aaubb_code_hash: *const libc::c_char,
    pub rmprru_code_branch: *const libc::c_char,
    pub rmprru_code_hash: *const libc::c_char,
    pub security_code_branch: *const libc::c_char,
    pub security_code_hash: *const libc::c_char,
    pub opensource_code_branch: *const libc::c_char,
    pub opensource_code_hash: *const libc::c_char,
}
pub type C2RustUnnamed_0 = libc::c_uint;
pub const ENUM_PROPERT_Version: C2RustUnnamed_0 = 0;
pub type e_TblTypeDefine = libc::c_uint;
pub const NUM_TBL_KIND_NUM: e_TblTypeDefine = 65;
pub const TBL_KIND_OF_TXPHASE: e_TblTypeDefine = 64;
pub const TBL_KIND_OF_RXPHASE: e_TblTypeDefine = 63;
pub const TBL_KIND_OF_DELTRXGAIN: e_TblTypeDefine = 62;
pub const TBL_KIND_OF_DELTTXGAIN: e_TblTypeDefine = 61;
pub const TBL_KIND_OF_RFBRIDGE: e_TblTypeDefine = 60;
pub const TBL_KIND_OF_RxREV: e_TblTypeDefine = 59;
pub const TBL_KIND_OF_TXREVANALOG: e_TblTypeDefine = 58;
pub const TBL_KIND_OF_TXFWDANALOG: e_TblTypeDefine = 57;
pub const TBL_KIND_OF_DSAATT: e_TblTypeDefine = 56;
pub const TBL_KIND_OF_PMIPHASEINFO: e_TblTypeDefine = 55;
pub const TBL_KIND_OF_UDC: e_TblTypeDefine = 54;
pub const TBL_KIND_OF_DVGATEMPGAIN: e_TblTypeDefine = 53;
pub const TBL_KIND_OF_TXGAINERROR: e_TblTypeDefine = 51;
pub const TBL_KIND_OF_RX0DELAY: e_TblTypeDefine = 50;
pub const TBL_KIND_OF_ANTDELAY: e_TblTypeDefine = 49;
pub const TBL_KIND_OF_FILTERDELAY: e_TblTypeDefine = 48;
pub const TBL_KIND_OF_TXLOOKUPTAB: e_TblTypeDefine = 47;
pub const TBL_KIND_OF_RXLOOKUPTAB: e_TblTypeDefine = 46;
pub const TBL_KIND_OF_IDEALWBRFCODEBOOK: e_TblTypeDefine = 45;
pub const TBL_KIND_OF_IDEALNBRFCODEBOOK: e_TblTypeDefine = 44;
pub const TBL_KIND_OF_IDEALDVDHRFCODEBOOK: e_TblTypeDefine = 43;
pub const TBL_KIND_OF_IDEALAMPRFCODEBOOK: e_TblTypeDefine = 42;
pub const TBL_KIND_OF_IDEALACRFCODEBOOK: e_TblTypeDefine = 41;
pub const TBL_KIND_OF_RXISOCAL: e_TblTypeDefine = 40;
pub const TBL_KIND_OF_TXACCAL: e_TblTypeDefine = 39;
pub const TBL_KIND_OF_PAENSAVADJ: e_TblTypeDefine = 38;
pub const TBL_KIND_OF_PWRCALI: e_TblTypeDefine = 37;
pub const TBL_KIND_OF_SINGLECODEBOOK: e_TblTypeDefine = 36;
pub const TBL_KIND_OF_TXGAIN_HW: e_TblTypeDefine = 35;
pub const TBL_KIND_OF_TXOPENRL: e_TblTypeDefine = 34;
pub const TBL_KIND_OF_RXCALCODEBOOK: e_TblTypeDefine = 33;
pub const TBL_KIND_OF_TXCALCODEBOOK: e_TblTypeDefine = 32;
pub const TBL_KIND_OF_IDEALCODEBOOK: e_TblTypeDefine = 31;
pub const TBL_KIND_OF_MBAGAIN: e_TblTypeDefine = 30;
pub const TBL_KIND_OF_PACURRCALI: e_TblTypeDefine = 29;
pub const TBL_KIND_OF_PAURELATIVEPHASE: e_TblTypeDefine = 28;
pub const TBL_KIND_OF_PAURELATIVEAMP: e_TblTypeDefine = 27;
pub const TBL_KIND_OF_PAUPHASE: e_TblTypeDefine = 26;
pub const TBL_KIND_OF_PAUAMP: e_TblTypeDefine = 25;
pub const TBL_KIND_OF_FILTERGAIN: e_TblTypeDefine = 24;
pub const TBL_KIND_OF_CALGAIN: e_TblTypeDefine = 23;
pub const TBL_KIND_OF_CALPHASE: e_TblTypeDefine = 22;
pub const TBL_KIND_OF_PARL: e_TblTypeDefine = 21;
pub const TBL_KIND_OF_PAGAINTEMPTBL: e_TblTypeDefine = 20;
pub const TBL_KIND_OF_PADRAINADJ: e_TblTypeDefine = 19;
pub const TBL_KIND_OF_PABASICINFO: e_TblTypeDefine = 18;
pub const TBL_KIND_OF_RXAMPGAIN: e_TblTypeDefine = 17;
pub const TBL_KIND_OF_CPATT: e_TblTypeDefine = 16;
pub const TBL_KIND_OF_PWRTEMPALM: e_TblTypeDefine = 15;
pub const TBL_KIND_OF_TRXTEMPALM: e_TblTypeDefine = 14;
pub const TBL_KIND_OF_PATEMPALM: e_TblTypeDefine = 13;
pub const TBL_KIND_OF_TRXTEMPGAIN: e_TblTypeDefine = 12;
pub const TBL_KIND_OF_PATEMPGAIN: e_TblTypeDefine = 11;
pub const TBL_KIND_OF_PADACSET: e_TblTypeDefine = 10;
pub const TBL_KIND_OF_PAVOLTGAIN: e_TblTypeDefine = 9;
pub const TBL_KIND_OF_RXCALI: e_TblTypeDefine = 8;
pub const TBL_KIND_OF_VSWRPROC: e_TblTypeDefine = 6;
pub const TBL_KIND_OF_VSWRPARAM: e_TblTypeDefine = 5;
pub const TBL_KIND_OF_TXCALI: e_TblTypeDefine = 4;
pub const TBL_KIND_OF_TXIQ: e_TblTypeDefine = 3;
pub type C2RustUnnamed_1 = libc::c_uint;
pub const BOARDPROP_VALID_SECTION: C2RustUnnamed_1 = 23;
static mut s_VersionLoadType: UINT32 = 1 as libc::c_int as UINT32;
#[unsafe(no_mangle)]
pub static mut g_idmatchwarn: UINT32 = 0 as libc::c_int as UINT32;
#[unsafe(no_mangle)]
pub static mut g_HwBoardInfoIcSocRpuId: UINT32 = 0 as libc::c_int as UINT32;
#[unsafe(no_mangle)]
pub static mut g_ulFpgaRegRdWrCtrlFlag: UINT32 = 0 as libc::c_int as UINT32;
#[unsafe(no_mangle)]
pub static mut g_HwBrdAnalogRofChnlSum: UINT32 = 2 as libc::c_int as UINT32;
#[unsafe(no_mangle)]
pub static mut g_HwBoardInfoDaauBrdSum: UINT32 = 0 as libc::c_int as UINT32;
#[unsafe(no_mangle)]
pub static mut g_HwBoardInfoRofOptSum: UINT32 = 0 as libc::c_int as UINT32;
#[unsafe(no_mangle)]
pub static mut g_HwBoardInfoDaauChnlSum: UINT32 = 2 as libc::c_int as UINT32;
#[unsafe(no_mangle)]
pub static mut g_HwBoardInfoAnalogSfpSum: UINT32 = 0 as libc::c_int as UINT32;
#[unsafe(no_mangle)]
pub static mut g_CpuIdInfoDaauOriginPuId: UINT32 = 0 as libc::c_int as UINT32;
#[unsafe(no_mangle)]
pub static mut g_HwBoardInfoDigitOptSum: UINT32 = 0x7fffffff as libc::c_int as UINT32;
#[unsafe(no_mangle)]
pub static mut g_HwBoardInfoDigitSfpSum: UINT32 = 0x7fffffff as libc::c_int as UINT32;
#[unsafe(no_mangle)]
pub static mut g_HwBoardInfoPanelMofSum: UINT32 = 0x7fffffff as libc::c_int as UINT32;
#[unsafe(no_mangle)]
pub static mut g_HwBoardMinChnlRatedPow: UINT32 = 0x7fffffff as libc::c_int as UINT32;
#[unsafe(no_mangle)]
pub static mut g_HwBrdExtPwrSupportFlag: UINT32 = 0 as libc::c_int as UINT32;
#[unsafe(no_mangle)]
pub static mut g_aulHwBoardChnlDaauType: [UINT32; 64] = [
    0 as libc::c_int as UINT32,
    0 as libc::c_int as UINT32,
    0 as libc::c_int as UINT32,
    0 as libc::c_int as UINT32,
    0 as libc::c_int as UINT32,
    0 as libc::c_int as UINT32,
    0 as libc::c_int as UINT32,
    0 as libc::c_int as UINT32,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
];
#[unsafe(no_mangle)]
pub static mut g_aulBbuChnlDaauTypeRatedPow: [[UINT32; 64]; 2] = [
    [
        0 as libc::c_int as UINT32,
        0 as libc::c_int as UINT32,
        0 as libc::c_int as UINT32,
        0 as libc::c_int as UINT32,
        0 as libc::c_int as UINT32,
        0 as libc::c_int as UINT32,
        0 as libc::c_int as UINT32,
        0 as libc::c_int as UINT32,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
    ],
    [
        0 as libc::c_int as UINT32,
        0 as libc::c_int as UINT32,
        0 as libc::c_int as UINT32,
        0 as libc::c_int as UINT32,
        0 as libc::c_int as UINT32,
        0 as libc::c_int as UINT32,
        0 as libc::c_int as UINT32,
        0 as libc::c_int as UINT32,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
    ],
];
#[unsafe(no_mangle)]
pub static mut pSoftLibFpgaBbxToFileFunc: SOFTLIB_BOOTP_BBX_FILE_FUNC = None;
static mut s_RfGetAntWavePwrAlmFunc: RfGetAntWavePwrAlmType = None;
#[unsafe(no_mangle)]
pub static mut g_radiocfg_init_flag: UINT32 = 0x8000 as libc::c_int as UINT32;
#[unsafe(no_mangle)]
pub static mut g_radiocfg_rruinfo: UINT32 = 0x2000 as libc::c_int as UINT32;
#[unsafe(no_mangle)]
pub static mut g_ModuleFlag: UINT32 = 0x2000 as libc::c_int as UINT32;
#[unsafe(no_mangle)]
pub static mut g_PowerFlag: UINT32 = 0 as libc::c_int as UINT32;
#[unsafe(no_mangle)]
pub static mut g_ProductDataFlag: UINT32 = 0 as libc::c_int as UINT32;
#[unsafe(no_mangle)]
pub static mut g_atExtraFilterFreqKHz: [[TExtraFilter; 2]; 64] = [
    [
        {
            let mut init = tagExtraFilterInfoDescription {
                aulFreqStart: [0 as libc::c_int as UINT32, 0, 0],
                aulFreqEnd: [0 as libc::c_int as UINT32, 0, 0],
            };
            init
        },
        {
            let mut init = tagExtraFilterInfoDescription {
                aulFreqStart: [0 as libc::c_int as UINT32, 0, 0],
                aulFreqEnd: [0 as libc::c_int as UINT32, 0, 0],
            };
            init
        },
    ],
    [TExtraFilter {
        aulFreqStart: [0; 3],
        aulFreqEnd: [0; 3],
    }; 2],
    [TExtraFilter {
        aulFreqStart: [0; 3],
        aulFreqEnd: [0; 3],
    }; 2],
    [TExtraFilter {
        aulFreqStart: [0; 3],
        aulFreqEnd: [0; 3],
    }; 2],
    [TExtraFilter {
        aulFreqStart: [0; 3],
        aulFreqEnd: [0; 3],
    }; 2],
    [TExtraFilter {
        aulFreqStart: [0; 3],
        aulFreqEnd: [0; 3],
    }; 2],
    [TExtraFilter {
        aulFreqStart: [0; 3],
        aulFreqEnd: [0; 3],
    }; 2],
    [TExtraFilter {
        aulFreqStart: [0; 3],
        aulFreqEnd: [0; 3],
    }; 2],
    [TExtraFilter {
        aulFreqStart: [0; 3],
        aulFreqEnd: [0; 3],
    }; 2],
    [TExtraFilter {
        aulFreqStart: [0; 3],
        aulFreqEnd: [0; 3],
    }; 2],
    [TExtraFilter {
        aulFreqStart: [0; 3],
        aulFreqEnd: [0; 3],
    }; 2],
    [TExtraFilter {
        aulFreqStart: [0; 3],
        aulFreqEnd: [0; 3],
    }; 2],
    [TExtraFilter {
        aulFreqStart: [0; 3],
        aulFreqEnd: [0; 3],
    }; 2],
    [TExtraFilter {
        aulFreqStart: [0; 3],
        aulFreqEnd: [0; 3],
    }; 2],
    [TExtraFilter {
        aulFreqStart: [0; 3],
        aulFreqEnd: [0; 3],
    }; 2],
    [TExtraFilter {
        aulFreqStart: [0; 3],
        aulFreqEnd: [0; 3],
    }; 2],
    [TExtraFilter {
        aulFreqStart: [0; 3],
        aulFreqEnd: [0; 3],
    }; 2],
    [TExtraFilter {
        aulFreqStart: [0; 3],
        aulFreqEnd: [0; 3],
    }; 2],
    [TExtraFilter {
        aulFreqStart: [0; 3],
        aulFreqEnd: [0; 3],
    }; 2],
    [TExtraFilter {
        aulFreqStart: [0; 3],
        aulFreqEnd: [0; 3],
    }; 2],
    [TExtraFilter {
        aulFreqStart: [0; 3],
        aulFreqEnd: [0; 3],
    }; 2],
    [TExtraFilter {
        aulFreqStart: [0; 3],
        aulFreqEnd: [0; 3],
    }; 2],
    [TExtraFilter {
        aulFreqStart: [0; 3],
        aulFreqEnd: [0; 3],
    }; 2],
    [TExtraFilter {
        aulFreqStart: [0; 3],
        aulFreqEnd: [0; 3],
    }; 2],
    [TExtraFilter {
        aulFreqStart: [0; 3],
        aulFreqEnd: [0; 3],
    }; 2],
    [TExtraFilter {
        aulFreqStart: [0; 3],
        aulFreqEnd: [0; 3],
    }; 2],
    [TExtraFilter {
        aulFreqStart: [0; 3],
        aulFreqEnd: [0; 3],
    }; 2],
    [TExtraFilter {
        aulFreqStart: [0; 3],
        aulFreqEnd: [0; 3],
    }; 2],
    [TExtraFilter {
        aulFreqStart: [0; 3],
        aulFreqEnd: [0; 3],
    }; 2],
    [TExtraFilter {
        aulFreqStart: [0; 3],
        aulFreqEnd: [0; 3],
    }; 2],
    [TExtraFilter {
        aulFreqStart: [0; 3],
        aulFreqEnd: [0; 3],
    }; 2],
    [TExtraFilter {
        aulFreqStart: [0; 3],
        aulFreqEnd: [0; 3],
    }; 2],
    [TExtraFilter {
        aulFreqStart: [0; 3],
        aulFreqEnd: [0; 3],
    }; 2],
    [TExtraFilter {
        aulFreqStart: [0; 3],
        aulFreqEnd: [0; 3],
    }; 2],
    [TExtraFilter {
        aulFreqStart: [0; 3],
        aulFreqEnd: [0; 3],
    }; 2],
    [TExtraFilter {
        aulFreqStart: [0; 3],
        aulFreqEnd: [0; 3],
    }; 2],
    [TExtraFilter {
        aulFreqStart: [0; 3],
        aulFreqEnd: [0; 3],
    }; 2],
    [TExtraFilter {
        aulFreqStart: [0; 3],
        aulFreqEnd: [0; 3],
    }; 2],
    [TExtraFilter {
        aulFreqStart: [0; 3],
        aulFreqEnd: [0; 3],
    }; 2],
    [TExtraFilter {
        aulFreqStart: [0; 3],
        aulFreqEnd: [0; 3],
    }; 2],
    [TExtraFilter {
        aulFreqStart: [0; 3],
        aulFreqEnd: [0; 3],
    }; 2],
    [TExtraFilter {
        aulFreqStart: [0; 3],
        aulFreqEnd: [0; 3],
    }; 2],
    [TExtraFilter {
        aulFreqStart: [0; 3],
        aulFreqEnd: [0; 3],
    }; 2],
    [TExtraFilter {
        aulFreqStart: [0; 3],
        aulFreqEnd: [0; 3],
    }; 2],
    [TExtraFilter {
        aulFreqStart: [0; 3],
        aulFreqEnd: [0; 3],
    }; 2],
    [TExtraFilter {
        aulFreqStart: [0; 3],
        aulFreqEnd: [0; 3],
    }; 2],
    [TExtraFilter {
        aulFreqStart: [0; 3],
        aulFreqEnd: [0; 3],
    }; 2],
    [TExtraFilter {
        aulFreqStart: [0; 3],
        aulFreqEnd: [0; 3],
    }; 2],
    [TExtraFilter {
        aulFreqStart: [0; 3],
        aulFreqEnd: [0; 3],
    }; 2],
    [TExtraFilter {
        aulFreqStart: [0; 3],
        aulFreqEnd: [0; 3],
    }; 2],
    [TExtraFilter {
        aulFreqStart: [0; 3],
        aulFreqEnd: [0; 3],
    }; 2],
    [TExtraFilter {
        aulFreqStart: [0; 3],
        aulFreqEnd: [0; 3],
    }; 2],
    [TExtraFilter {
        aulFreqStart: [0; 3],
        aulFreqEnd: [0; 3],
    }; 2],
    [TExtraFilter {
        aulFreqStart: [0; 3],
        aulFreqEnd: [0; 3],
    }; 2],
    [TExtraFilter {
        aulFreqStart: [0; 3],
        aulFreqEnd: [0; 3],
    }; 2],
    [TExtraFilter {
        aulFreqStart: [0; 3],
        aulFreqEnd: [0; 3],
    }; 2],
    [TExtraFilter {
        aulFreqStart: [0; 3],
        aulFreqEnd: [0; 3],
    }; 2],
    [TExtraFilter {
        aulFreqStart: [0; 3],
        aulFreqEnd: [0; 3],
    }; 2],
    [TExtraFilter {
        aulFreqStart: [0; 3],
        aulFreqEnd: [0; 3],
    }; 2],
    [TExtraFilter {
        aulFreqStart: [0; 3],
        aulFreqEnd: [0; 3],
    }; 2],
    [TExtraFilter {
        aulFreqStart: [0; 3],
        aulFreqEnd: [0; 3],
    }; 2],
    [TExtraFilter {
        aulFreqStart: [0; 3],
        aulFreqEnd: [0; 3],
    }; 2],
    [TExtraFilter {
        aulFreqStart: [0; 3],
        aulFreqEnd: [0; 3],
    }; 2],
    [TExtraFilter {
        aulFreqStart: [0; 3],
        aulFreqEnd: [0; 3],
    }; 2],
];
static mut ulRruAntPowerFlag: [UINT32; 64] = [0; 64];
static mut ulRruAntPower: [UINT32; 64] = [0; 64];
static mut s_ulRealTimeWakeupCapFlag: UINT32 = 1 as libc::c_int as UINT32;
#[unsafe(no_mangle)]
pub static mut g_ucAntiTheftFun: UCHAR = 0 as libc::c_int as UCHAR;
#[unsafe(no_mangle)]
pub static mut g_rruBoardTypeFlag: UINT32 = 0 as libc::c_int as UINT32;
#[unsafe(no_mangle)]
pub static mut pGetChannelNumByFuncSet: FuncGetChannelNumByFuncSet = None;
#[unsafe(no_mangle)]
pub static mut pCopyAnt0CallBack: FUNC_INFO_COPY_ANT0 = None;
#[unsafe(no_mangle)]
pub static mut pGetRruRatedPower: GET_RRU_RATED_POWER = None;
#[unsafe(no_mangle)]
pub static mut pSetRruPathRatePwrFunc: pFUNC_SET_AAU_PATH_RATE_PWR = None;
#[unsafe(no_mangle)]
pub static mut pGetRruPathRatePwrFunc: pFUNC_GET_AAU_PATH_RATE_PWR = None;
#[unsafe(no_mangle)]
pub static mut pSetZncrCellInfo: FUNC_SET_ZNCR_CELL_INFO = None;
#[unsafe(no_mangle)]
pub static mut pZncrCellInfoIsSend: FUNC_ZNCR_CELL_INFO_IS_SEND = None;
#[unsafe(no_mangle)]
pub static mut pClearZncrCellInfo: FUNC_CLEAR_ZNCR_CELL_INFO = None;
#[unsafe(no_mangle)]
pub static mut pGetZncrCellInfo: FUNC_GET_ZNCR_CELL_INFO = None;
#[unsafe(no_mangle)]
pub static mut pGetCellSignalStrength: FUNC_GET_CELL_SIGNAL_STRENGTH = None;
#[unsafe(no_mangle)]
pub static mut pGetCellSignalStrengthByRadioMode: FUNC_GET_CELL_SIGNAL_STRENGTH_BY_RADIOMODE = None;
#[unsafe(no_mangle)]
pub static mut pSetRsrpDelta: FUNC_SET_RSRP_DELTA = None;
#[unsafe(no_mangle)]
pub static mut pGetRsrpDelta: FUNC_GET_RSRP_DELTA = None;
#[unsafe(no_mangle)]
pub static mut s_tHwCustomIdInfo: T_HwCustomIdAnalyseInfo = {
    let mut init = tag_HwCustomIdAnalyseInfo {
        ulAnalyseFlag: 0xffffffff as libc::c_uint,
        ulPaVoltType: 0xffffffff as libc::c_uint,
        ulPaBankAType: 0,
        ulPaBankBType: 0,
        ulPaBypassFlag: 0,
        ulTecSupportFlag: 0,
        ulPlcSupportFlag: 0,
        ulPlcBrandType: 0,
        ulMcsChipType: 0,
        ulMcsDdrSizeType: 0,
        ulMcsDdrChipType: 0,
        ulOokSupportFlag: 0,
        ulFanSupportFlag: 0,
        ulEpldChipType: 0,
        ulSfpModuleType: 0,
        ulTestReserved: 0,
    };
    init
};
#[unsafe(no_mangle)]
pub static mut sBoardId: TVerGroup = unsafe {
    {
        let mut init = tagHwVerGroup {
            cNickname: *::core::mem::transmute::<
                &[u8; 40],
                &mut [libc::c_char; 40],
            >(
                b"\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0",
            ),
            nameIdx: 0xffffffff as libc::c_uint,
            HardId: [
                0xffffffff as libc::c_uint,
                0xffffffff as libc::c_uint,
                0xffffffff as libc::c_uint,
                0xffffffff as libc::c_uint,
                0xffffffff as libc::c_uint,
                0xffffffff as libc::c_uint,
                0xffffffff as libc::c_uint,
                0xffffffff as libc::c_uint,
            ],
        };
        init
    }
};
#[unsafe(no_mangle)]
pub static mut s_HwGroup: T_VerGroupDscp = {
    let mut init = tag_hw_ver_group_dscp {
        pHwVerGroup: 0 as *const TVerGroup as *mut TVerGroup,
        hwVerGroupLen: 0,
    };
    init
};
#[unsafe(no_mangle)]
pub static mut s_HwGroup_Ex: T_VerGroupDscp = {
    let mut init = tag_hw_ver_group_dscp {
        pHwVerGroup: 0 as *const TVerGroup as *mut TVerGroup,
        hwVerGroupLen: 0,
    };
    init
};
#[unsafe(no_mangle)]
pub static mut s_HwGroup_New: T_VerGroupDscpNew = {
    let mut init = tag_hw_ver_group_dscp_new {
        pHwVerGroup: 0 as *const TVerGroupNew as *mut TVerGroupNew,
        hwVerGroupLen: 0,
    };
    init
};
#[unsafe(no_mangle)]
pub static mut s_HwGroup_SecId: T_VerGroupDscpNew = {
    let mut init = tag_hw_ver_group_dscp_new {
        pHwVerGroup: 0 as *const TVerGroupNew as *mut TVerGroupNew,
        hwVerGroupLen: 0,
    };
    init
};
#[unsafe(no_mangle)]
pub static mut s_ChngIdMsk: UINT32 = 0xf as libc::c_int as UINT32;
#[unsafe(no_mangle)]
pub static mut s_DeviceCnt: UINT32 = 0 as libc::c_int as UINT32;
#[unsafe(no_mangle)]
pub static mut s_BoardPropAscii: T_BoardPropAscii = {
    let mut init = tagT_BoardPropAscii {
        pPropAscii: 0 as *const CHAR,
        length: 0,
    };
    init
};
#[unsafe(no_mangle)]
pub static mut s_HwInfo: T_HwInfo = {
    let mut init = T_HwInfo {
        RruInfo: {
            let mut init = tagAdpRruInfoNew {
                aucBarCode: [0; 128],
                aucProductTime: [0; 128],
                ulServiceTime: 0,
                aucLastServiceDate: [0; 128],
                ulRruAntNum: 0,
                ulRruAntFlag: 0,
                ulRruTxNumInfo: [0; 65],
                ulRruRxNumInfo: [0; 65],
                ulRruTrxNum: 0,
                ulRruPaNum: 0,
                ulRruDflNum: 0,
                ulRruPwrNum: 0,
                ulRruPibNum: 0,
                ulRruCoPaAntNum: 0,
                ulRruModeInfo: 0,
                ulPidFlag: 0,
                ulRatedPowerTx: 0,
                ulRruBandNum: 0,
                ulCombBoard: 0,
                aulRatedBandPowerPath: [0; 2],
                aulRatedPowerPath: [0; 64],
                aulRatedPowerTemp: [[0; 3]; 65],
                aulPaOutPowerPath: [0; 64],
                aulPaOutPowerTemp: [[0; 3]; 65],
                aulValidPowerPath: [0; 64],
                aulValidPowerTemp: [[0; 3]; 65],
                aucFamilyType: [0; 128],
                aucTypeNumber: [0; 128],
                aucPIDNumber: [0; 128],
                aucVendorName: [0; 128],
                aucBomCode: [0; 128],
                aucSupplierCode: [0; 128],
                tFreqStartEndTx: [TFreqStartEnd {
                    ulBandNum: 0,
                    aulFreqStart: [0; 3],
                    aulFreqEnd: [0; 3],
                }; 64],
                tFreqStartEndRx: [TFreqStartEnd {
                    ulBandNum: 0,
                    aulFreqStart: [0; 3],
                    aulFreqEnd: [0; 3],
                }; 64],
                ulCombLoss: [[0; 3]; 65],
                aucBomidCheck: [0; 128],
            };
            init
        },
        BoardInfo: TAdpBoardInfoNew {
            aucBarCode: [0; 128],
            ulServiceTime: 0,
            ulTxNum: 0,
            ulRxNum: 0,
            ulPrxNum: 0,
            ulOptNum: 0,
            ulSfpNum: 0,
            ulRpuNum: 0,
            ulBpuNum: 0,
            ulDryContactNum: 0,
            ulPathProperty: 0,
            ulPathPropertyNum: 0,
            ulClkProperty: 0,
            ulClkPropertyNum: 0,
            ulSerdesProperty: 0,
            ulSerdesPropertyNum: 0,
            ulTempProperty: 0,
            ulTempPropertyNum: 0,
            ulPwrCtrlProperty: 0,
            ulPwrCtrlPropertyNum: 0,
            ulPwrReadProperty: 0,
            ulPwrReadPropertyNum: 0,
            ulPaProperty: 0,
            ulPaPropertyNum: 0,
            ulOptProperty: 0,
            ulOptPropertyNum: 0,
            ulResistorProperty: 0,
            ulResistorPropertyNum: 0,
            ulNsbtSupport: 0,
            ulOptSpeedMask: 0,
            ulPaGridVoltMap: 0,
            aulTxPrxShareLo: [0; 64],
            aulTxTxShareLo: [0; 64],
            aulInputAisgVolt: [0; 3],
            ulOptMaxSpeed: [0; 12],
            aulBoardTxIfFreqBw: [[0; 3]; 64],
            aulBoardRxIfFreqBw: [[0; 3]; 64],
            alBoardTxIfFreq: [0; 64],
            alBoardRxIfFreq: [0; 64],
            alBoardPrxIfFreq: [0; 64],
            aulBoardBandFlag: [[0; 3]; 64],
            aucBoardDescription: [0; 128],
            aucModuleGroupName: [0; 128],
            aucBoardGroupName: [0; 128],
            aucBoardName: [0; 128],
            aucBoardPcbSerial: [0; 128],
            aucBoardHard: [0; 128],
            aucProductTime: [0; 128],
            aucLastServiceDate: [0; 128],
            aucVendorName: [0; 128],
            aucPwrType: [0; 128],
            aucPwrVer: [0; 128],
            aucPwrConsumedPower: [0; 128],
            aucPaCfgFreq: [0; 128],
            aucPaSupportDtx: [0; 128],
            tFreqStartEndTx: [TFreqStartEnd {
                ulBandNum: 0,
                aulFreqStart: [0; 3],
                aulFreqEnd: [0; 3],
            }; 64],
            tFreqStartEndRx: [TFreqStartEnd {
                ulBandNum: 0,
                aulFreqStart: [0; 3],
                aulFreqEnd: [0; 3],
            }; 64],
            bandFlagInfo: TBandInfo {
                bandNum: 0,
                bandFlag: [[0; 65]; 8],
            },
            pDeviceInfoDscp: 0 as *const TRruDeviceDescription
                as *mut TRruDeviceDescription,
        },
        PibInfo: TAdpPibInfo {
            aucBarCode: [0; 128],
            ulPidFactoryId: 0,
            ulPibType: 0,
            ulPibVer: 0,
            ulServiceTime: 0,
            ulPibCommVer: 0,
            aucProductTime: [0; 128],
            aucLastServiceDate: [0; 128],
            aucVendorName: [0; 128],
            aucBoardName: [0; 128],
        },
        PwrInfo: [TAdpPwrInfoNew {
            aucBarCode: [0; 128],
            ulPwrCommVer: 0,
            ulPwrVoltUp: 0,
            ulPwrVoltDown: 0,
            ulPwrCapability: 0,
            ulPwrFactoryId: 0,
            ulServiceTime: 0,
            ulPwrType: 0,
            ulPwrVer: 0,
            ulAcInputVoltType: 0,
            aucPwrType: [0; 128],
            aucPwrVer: [0; 128],
            ucAcInputVoltType: [0; 128],
            aucProductTime: [0; 128],
            aucLastServiceDate: [0; 128],
            aucVendorName: [0; 128],
            aucBoardName: [0; 128],
            aucConsumedPower: [0; 128],
            ulDefPwrNum: 0,
            ulDefPwrVoltN: [0; 4],
            ulPwrVoltUpN: [0; 4],
            ulPwrVoltDownN: [0; 4],
            ulPwrCapabilityN: [0; 4],
        }; 3],
        PaInfo: [TAdpPaInfoNew {
            aucBarCode: [0; 128],
            ulPaType: 0,
            ulPaVer: 0,
            ulPaPath: 0,
            aucPaSupportDtx: [0; 128],
            ulPaFactoryId: 0,
            ulServiceTime: 0,
            ulPaCommVer: 0,
            aulPaRatedPower: [0; 64],
            aucPaCfgFreq: [0; 128],
            aucPaBoardName: [0; 128],
            aucProductTime: [0; 128],
            aucLastServiceDate: [0; 128],
            aucVendorName: [0; 128],
            aucBoardName: [0; 128],
            tFreqStartEnd: [TFreqStartEnd {
                ulBandNum: 0,
                aulFreqStart: [0; 3],
                aulFreqEnd: [0; 3],
            }; 64],
            tFreqStartEndTx: TFreqStartEnd {
                ulBandNum: 0,
                aulFreqStart: [0; 3],
                aulFreqEnd: [0; 3],
            },
        }; 4],
        DflInfo: [TAdpDflInfoNew {
            aucBarCode: [0; 128],
            ulDflAppType: 0,
            ulDflAntNum: 0,
            ulDflFactoryId: 0,
            ulServiceTime: 0,
            ulDflCommVer: 0,
            ulDflLanGain: 0,
            aucProductTime: [0; 128],
            aucLastServiceDate: [0; 128],
            aucVendorName: [0; 128],
            aucBoardName: [0; 128],
            aucNsbt: [0; 128],
            tFreqInfoTx: [[TFreqStartEnd {
                ulBandNum: 0,
                aulFreqStart: [0; 3],
                aulFreqEnd: [0; 3],
            }; 64]; 65],
            tFreqInfoRx: [[TFreqStartEnd {
                ulBandNum: 0,
                aulFreqStart: [0; 3],
                aulFreqEnd: [0; 3],
            }; 64]; 65],
            tTxFreqInfo: TFreqStartEnd {
                ulBandNum: 0,
                aulFreqStart: [0; 3],
                aulFreqEnd: [0; 3],
            },
            tRxFreqInfo: TFreqStartEnd {
                ulBandNum: 0,
                aulFreqStart: [0; 3],
                aulFreqEnd: [0; 3],
            },
        }; 64],
        AntInfo: [TAdpAntInfoNew {
            aucBarCode: [0; 128],
            ulAntAppType: 0,
            ulAntNum: 0,
            ulAntFactoryId: 0,
            ulServiceTime: 0,
            aucProductTime: [0; 128],
            aucLastServiceDate: [0; 128],
            aucVendorName: [0; 128],
            aucBoardName: [0; 128],
        }; 2],
    };
    init
};

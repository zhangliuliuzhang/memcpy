#![allow(
    dead_code,
    mutable_transmutes,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    unused_assignments,
    unused_mut
)]
#![feature(extern_types)]
unsafe extern "C" {
    fn fclose(__stream: *mut FILE) -> libc::c_int;
    fn __xstat(
        __ver: libc::c_int,
        __filename: *const libc::c_char,
        __stat_buf: *mut stat,
    ) -> libc::c_int;
    fn encapsulationOfZte_strnlen_s(
        s: *const libc::c_char,
        maxsize: rsize_t,
        fileName: *const libc::c_char,
        lineNo: libc::c_int,
    ) -> libc::c_int;
    fn encapsulationOfZte_strncpy_s(
        s1: *mut libc::c_char,
        s1max: rsize_t,
        s2: *const libc::c_char,
        n: rsize_t,
        fileName: *const libc::c_char,
        lineNo: libc::c_int,
    ) -> libc::c_int;
    fn fopen_s(
        streamptr: *mut *mut FILE,
        filename: *const libc::c_char,
        mode: *const libc::c_char,
    ) -> errno_t;
    fn ConfigGetKeyEx(
        CFG_file: *const libc::c_void,
        section: *const libc::c_void,
        key: *const libc::c_void,
        buf: *mut libc::c_void,
        buflen: libc::c_uint,
    ) -> libc::c_int;
    fn ConfigSetKey(
        CFG_file: *const libc::c_void,
        section: *const libc::c_void,
        key: *const libc::c_void,
        buf: *const libc::c_void,
    ) -> libc::c_int;
    fn BspSystem(pcCommand: *const CHAR) -> INT;
    fn BspAtoi(str: *const libc::c_char, base: INT32) -> INT32;
}
use crate::rruinfo_clib::*;
use std::ffi::c_void;
use std::ffi::{CString, CStr};

#[repr(C)]
pub struct _IO_wide_data(c_void);
pub struct _IO_codecvt(c_void);
pub struct _IO_marker(c_void);

pub type __uint8_t = libc::c_uchar;
pub type __uint16_t = libc::c_ushort;
pub type __uint32_t = libc::c_uint;
pub type __dev_t = libc::c_ulong;
pub type __uid_t = libc::c_uint;
pub type __gid_t = libc::c_uint;
pub type __ino_t = libc::c_ulong;
pub type __mode_t = libc::c_uint;
pub type __nlink_t = libc::c_ulong;
pub type __off_t = libc::c_long;
pub type __off64_t = libc::c_long;
pub type __time_t = libc::c_long;
pub type __blksize_t = libc::c_long;
pub type __blkcnt_t = libc::c_long;
pub type __syscall_slong_t = libc::c_long;
pub type uint8_t = __uint8_t;
pub type uint16_t = __uint16_t;
pub type uint32_t = __uint32_t;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct timespec {
    pub tv_sec: __time_t,
    pub tv_nsec: __syscall_slong_t,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct stat {
    pub st_dev: __dev_t,
    pub st_ino: __ino_t,
    pub st_nlink: __nlink_t,
    pub st_mode: __mode_t,
    pub st_uid: __uid_t,
    pub st_gid: __gid_t,
    pub __pad0: libc::c_int,
    pub st_rdev: __dev_t,
    pub st_size: __off_t,
    pub st_blksize: __blksize_t,
    pub st_blocks: __blkcnt_t,
    pub st_atim: timespec,
    pub st_mtim: timespec,
    pub st_ctim: timespec,
    pub __glibc_reserved: [__syscall_slong_t; 3],
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct _IO_FILE {
    pub _flags: libc::c_int,
    pub _IO_read_ptr: *mut libc::c_char,
    pub _IO_read_end: *mut libc::c_char,
    pub _IO_read_base: *mut libc::c_char,
    pub _IO_write_base: *mut libc::c_char,
    pub _IO_write_ptr: *mut libc::c_char,
    pub _IO_write_end: *mut libc::c_char,
    pub _IO_buf_base: *mut libc::c_char,
    pub _IO_buf_end: *mut libc::c_char,
    pub _IO_save_base: *mut libc::c_char,
    pub _IO_backup_base: *mut libc::c_char,
    pub _IO_save_end: *mut libc::c_char,
    pub _markers: *mut _IO_marker,
    pub _chain: *mut _IO_FILE,
    pub _fileno: libc::c_int,
    pub _flags2: libc::c_int,
    pub _old_offset: __off_t,
    pub _cur_column: libc::c_ushort,
    pub _vtable_offset: libc::c_schar,
    pub _shortbuf: [libc::c_char; 1],
    pub _lock: *mut libc::c_void,
    pub _offset: __off64_t,
    pub _codecvt: *mut _IO_codecvt,
    pub _wide_data: *mut _IO_wide_data,
    pub _freeres_list: *mut _IO_FILE,
    pub _freeres_buf: *mut libc::c_void,
    pub __pad5: libc::c_int,
    pub _mode: libc::c_int,
    pub _unused2: libc::c_char,
}
pub type _IO_lock_t = ();
pub type FILE = _IO_FILE;
pub type UCHAR = libc::c_uchar;
pub type CHAR = libc::c_char;
pub type ULONG = libc::c_uint;
pub type UINT32 = libc::c_uint;
pub type INT = libc::c_int;
pub type INT32 = libc::c_int;
pub type rsize_t = libc::c_int;
pub type errno_t = libc::c_int;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct tagT_Ver_File_Header {
    pub ulCRC32: uint32_t,
    pub ulHeaderVersion: uint32_t,
    pub usVerType: uint16_t,
    pub ucCpuType: uint8_t,
    pub ucReserved0: uint8_t,
    pub ulCompressedSize: uint32_t,
    pub ulCompressedCRC: uint32_t,
    pub ulOriginalSize: uint32_t,
    pub ulOriginalCRC: uint32_t,
    pub ulSoftType: uint32_t,
    pub ucVerNo: [CHAR; 44],
    pub ulCreateTime: uint32_t,
    pub ucPackedFile: uint8_t,
    pub ucPackedFileNum: uint8_t,
    pub ucOsType: uint8_t,
    pub ucReserved1: [uint8_t; 9],
    pub ucPhyId: uint8_t,
    pub ucReserved2: [uint8_t; 35],
}
pub type T_VerFileHeader = tagT_Ver_File_Header;
#[inline]
unsafe extern "C" fn __bswap_32(mut __bsx: __uint32_t) -> __uint32_t {
    return (__bsx & 0xff000000 as libc::c_uint) >> 24 as libc::c_int
        | (__bsx & 0xff0000 as libc::c_uint) >> 8 as libc::c_int
        | (__bsx & 0xff00 as libc::c_uint) << 8 as libc::c_int
        | (__bsx & 0xff as libc::c_uint) << 24 as libc::c_int;
}
#[inline]
unsafe extern "C" fn stat(
    mut __path: *const libc::c_char,
    mut __statbuf: *mut stat,
) -> libc::c_int {
    return __xstat(1 as libc::c_int, __path, __statbuf);
}
static mut FpgaVerComparFlag: UINT32 = 0 as libc::c_int as UINT32;
static mut s_fpgaVerSoftType: UINT32 = 4294967295 as libc::c_uint;
#[unsafe(no_mangle)]
pub unsafe extern "C" fn CreatePreverDir() {
    let mut ret: INT32 = 0 as libc::c_int;
    let mut cmdBuf: [libc::c_char; 255] = [
        0 as libc::c_int as libc::c_char,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
    ];
    // 使用 Rust 格式化函数重写
    // 将 C 字符串字面量转换为 Rust 字符串
    let dir_path = match CStr::from_bytes_with_nul(b"/ata/rru/prever/fpga\0") {
        Ok(c_str) => match c_str.to_str() {
            Ok(s) => s,
            Err(_) => "",
        },
        Err(_) => "",
    };
    
    // 使用 format! 宏创建格式化字符串
    let formatted = format!("mkdir -p {}", dir_path);
    
    // 计算可用的最大长度（留一个字节给空终止符）
    let max_len = (::core::mem::size_of::<[libc::c_char; 255]>() as libc::c_ulong)
        .wrapping_sub(1 as libc::c_int as libc::c_ulong) as usize;
    
    // 转换为 C 字符串并写入缓冲区
    ret = match CString::new(formatted.as_str()) {
        Ok(c_string) => {
            let bytes = c_string.as_bytes(); // 不包含空终止符
            let copy_len = bytes.len().min(max_len);
            
            // 复制字符串到缓冲区
            std::ptr::copy_nonoverlapping(
                bytes.as_ptr() as *const libc::c_char,
                cmdBuf.as_mut_ptr(),
                copy_len,
            );
            
            // 添加空终止符
            *cmdBuf.as_mut_ptr().add(copy_len) = 0;
            
            // 返回写入的字符数（不包括空终止符），模拟 snprintf_s 的行为
            copy_len as INT32
        }
        Err(_) => {
            // 如果转换失败，返回 -1
            -1 as libc::c_int
        }
    };
    ret = BspSystem(cmdBuf.as_mut_ptr());
    if ret != 0 as libc::c_int {
        // 使用 Rust println! 替换 ExPrnLev
        println!("CreatePreverDir: create /ata/rru/prever/fpga failed, ret={}", ret);
    }
}
#[unsafe(no_mangle)]
pub unsafe extern "C" fn BspGetPlusAndPlayEnable() -> UINT32 {
    let mut ret: INT32 = 0 as libc::c_int;
    let mut key_buf: [libc::c_char; 40] = [
        0 as libc::c_int as libc::c_char,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
    ];
    let mut enable: INT32 = 0 as libc::c_int;
    ret = ConfigGetKeyEx(
        b"/tmp/cali/VersionConfig.ini\0" as *const u8 as *const libc::c_char
            as *const libc::c_void,
        b"Plug-and-Play\0" as *const u8 as *const libc::c_char as *const libc::c_void,
        b"PlugAndPlayRru\0" as *const u8 as *const libc::c_char as *const libc::c_void,
        key_buf.as_mut_ptr() as *mut libc::c_void,
        ::core::mem::size_of::<[libc::c_char; 40]>() as libc::c_ulong as libc::c_uint,
    );
    if ret != 0 as libc::c_int {
        // 使用 Rust println! 替换 ExPrnLev
        println!("BspGetPlusAndPlayEnable: ConfigGetKeyEx /tmp/cali/VersionConfig.ini failed, ret={}", ret);
        return 0 as libc::c_int as UINT32;
    }
    enable = BspAtoi(key_buf.as_mut_ptr(), 0 as libc::c_int);
    if enable == 0x1 as libc::c_int {
        return 0x1 as libc::c_int as UINT32
    } else {
        return 0 as libc::c_int as UINT32
    };
}
#[unsafe(no_mangle)]
pub unsafe extern "C" fn BspGetPlusAndPlayVerRestrict(
    mut verRestrict: *mut libc::c_char,
    mut bufLen: UINT32,
) -> UINT32 {
    let mut ret: INT32 = 0 as libc::c_int;
    let mut key_buf: [libc::c_char; 40] = [
        0 as libc::c_int as libc::c_char,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
    ];
    ret = ConfigGetKeyEx(
        b"/tmp/cali/VersionConfig.ini\0" as *const u8 as *const libc::c_char
            as *const libc::c_void,
        b"version-restrict\0" as *const u8 as *const libc::c_char as *const libc::c_void,
        b"version_restrict\0" as *const u8 as *const libc::c_char as *const libc::c_void,
        key_buf.as_mut_ptr() as *mut libc::c_void,
        ::core::mem::size_of::<[libc::c_char; 40]>() as libc::c_ulong as libc::c_uint,
    );
    if ret != 0 as libc::c_int {
        // 使用 Rust println! 替换 mzprnL
        println!("BspGetPlusAndPlayVerRestrict: ConfigGetKeyEx /tmp/cali/VersionConfig.ini failed, ret={}", ret);
        return 0xffffffff as libc::c_uint;
    }
    if !verRestrict.is_null() && bufLen > 0 as libc::c_int as libc::c_uint {
        if key_buf[0 as libc::c_int as usize] as libc::c_int == '"' as i32
            && encapsulationOfZte_strnlen_s(
                key_buf.as_mut_ptr(),
                40 as libc::c_int,
                b"/home/10305328/program/master/bsp/platform/bsp/softlib/rruinfo/source/plugandplay.c\0"
                    as *const u8 as *const libc::c_char,
                114 as libc::c_int,
            ) >= 2 as libc::c_int
        {
            encapsulationOfZte_strncpy_s(
                verRestrict,
                bufLen as rsize_t,
                &mut *key_buf.as_mut_ptr().offset(1 as libc::c_int as isize),
                encapsulationOfZte_strnlen_s(
                    key_buf.as_mut_ptr(),
                    40 as libc::c_int,
                    b"/home/10305328/program/master/bsp/platform/bsp/softlib/rruinfo/source/plugandplay.c\0"
                        as *const u8 as *const libc::c_char,
                    116 as libc::c_int,
                ) - 2 as libc::c_int,
                b"/home/10305328/program/master/bsp/platform/bsp/softlib/rruinfo/source/plugandplay.c\0"
                    as *const u8 as *const libc::c_char,
                116 as libc::c_int,
            );
        } else {
            encapsulationOfZte_strncpy_s(
                verRestrict,
                bufLen as rsize_t,
                key_buf.as_mut_ptr(),
                encapsulationOfZte_strnlen_s(
                    key_buf.as_mut_ptr(),
                    40 as libc::c_int,
                    b"/home/10305328/program/master/bsp/platform/bsp/softlib/rruinfo/source/plugandplay.c\0"
                        as *const u8 as *const libc::c_char,
                    120 as libc::c_int,
                ),
                b"/home/10305328/program/master/bsp/platform/bsp/softlib/rruinfo/source/plugandplay.c\0"
                    as *const u8 as *const libc::c_char,
                120 as libc::c_int,
            );
        }
    } else {
        // 使用 Rust println! 替换 mzprnL
        // 将 key_buf 转换为 Rust 字符串
        let key_buf_str = match CStr::from_ptr(key_buf.as_mut_ptr() as *const libc::c_char).to_str() {
            Ok(s) => s,
            Err(_) => "",
        };
        println!("BspGetPlusAndPlayVerRestrict: version_restrict={}", key_buf_str);
    }
    return 0 as libc::c_int as UINT32;
}
#[unsafe(no_mangle)]
pub unsafe extern "C" fn BspGetPlusAndPlaySwid(mut swId: *mut UINT32) -> UINT32 {
    let mut ret: INT32 = 0 as libc::c_int;
    let mut key_buf: [libc::c_char; 40] = [
        0 as libc::c_int as libc::c_char,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
    ];
    let mut val: INT32 = 0 as libc::c_int;
    ret = ConfigGetKeyEx(
        b"/ata/rru/prever/funcset-swid.ini\0" as *const u8 as *const libc::c_char
            as *const libc::c_void,
        b"Swid-Value\0" as *const u8 as *const libc::c_char as *const libc::c_void,
        b"swid\0" as *const u8 as *const libc::c_char as *const libc::c_void,
        key_buf.as_mut_ptr() as *mut libc::c_void,
        ::core::mem::size_of::<[libc::c_char; 40]>() as libc::c_ulong as libc::c_uint,
    );
    if ret != 0 as libc::c_int {
        // 使用 Rust println! 替换 mzprnL
        println!("BspGetPlusAndPlaySwid: ConfigGetKeyEx /ata/rru/prever/funcset-swid.ini failed, ret={}", ret);
        return 0xffffffff as libc::c_uint;
    }
    val = BspAtoi(key_buf.as_mut_ptr(), 0 as libc::c_int);
    if val < 0 as libc::c_int {
        return 0xffffffff as libc::c_uint;
    }
    if !swId.is_null() {
        *swId = val as UINT32;
    } else {
        // 使用 Rust println! 替换 mzprnL
        println!("BspGetPlusAndPlaySwid: swid={}", val);
    }
    return 0 as libc::c_int as UINT32;
}
#[unsafe(no_mangle)]
pub unsafe extern "C" fn BspSetPlusAndPlaySwid(mut swId: UINT32) -> UINT32 {
    let mut ret: INT32 = 0 as libc::c_int;
    let mut key_buf: [libc::c_char; 40] = [
        0 as libc::c_int as libc::c_char,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
    ];
    // 使用 Rust 格式化函数重写
    // 使用 format! 宏创建格式化字符串
    let formatted = format!("{}", swId);
    
    // 计算可用的最大长度（留一个字节给空终止符）
    let max_len = (::core::mem::size_of::<[libc::c_char; 40]>() as libc::c_ulong)
        .wrapping_sub(1 as libc::c_int as libc::c_ulong) as usize;
    
    // 转换为 C 字符串并写入缓冲区
    ret = match CString::new(formatted.as_str()) {
        Ok(c_string) => {
            let bytes = c_string.as_bytes(); // 不包含空终止符
            let copy_len = bytes.len().min(max_len);
            
            // 复制字符串到缓冲区
            std::ptr::copy_nonoverlapping(
                bytes.as_ptr() as *const libc::c_char,
                key_buf.as_mut_ptr(),
                copy_len,
            );
            
            // 添加空终止符
            *key_buf.as_mut_ptr().add(copy_len) = 0;
            
            // 返回写入的字符数（不包括空终止符），模拟 snprintf_s 的行为
            copy_len as INT32
        }
        Err(_) => {
            // 如果转换失败，返回 -1
            -1 as libc::c_int
        }
    };
    CreatePreverDir();
    ret = ConfigSetKey(
        b"/ata/rru/prever/funcset-swid.ini\0" as *const u8 as *const libc::c_char
            as *const libc::c_void,
        b"Swid-Value\0" as *const u8 as *const libc::c_char as *const libc::c_void,
        b"swid\0" as *const u8 as *const libc::c_char as *const libc::c_void,
        key_buf.as_mut_ptr() as *const libc::c_void,
    );
    if ret != 0 as libc::c_int {
        // 使用 Rust println! 替换 mzprnL
        // 将 key_buf 转换为 Rust 字符串
        let key_buf_str = match CStr::from_ptr(key_buf.as_mut_ptr() as *const libc::c_char).to_str() {
            Ok(s) => s,
            Err(_) => "",
        };
        println!("BspSetPlusAndPlaySwid: ConfigSetKey /ata/rru/prever/funcset-swid.ini failed, key_buf={}, ret={}", key_buf_str, ret);
        return 0xffffffff as libc::c_uint;
    }
    return 0 as libc::c_int as UINT32;
}
#[unsafe(no_mangle)]
pub unsafe extern "C" fn BspGetPreverFpgaPath(
    mut curSwid: UINT32,
    mut newFpgaPath: *mut libc::c_char,
    mut pathBufLen: libc::c_int,
    mut alarm: *mut UINT32,
) -> UINT32 {
    let mut enable: UINT32 = 0 as libc::c_int as UINT32;
    let mut retVal: UINT32 = 0 as libc::c_int as UINT32;
    let mut bbuSwid: UINT32 = 0 as libc::c_int as UINT32;
    if newFpgaPath.is_null() {
        // 使用 Rust println! 替换 mzprnL
        println!("BspGetPreverFpgaPath: Input Pointer is NULL!");
        return 0xff000002 as libc::c_uint;
    }
    if alarm.is_null() {
        // 使用 Rust println! 替换 mzprnL
        println!("BspGetPreverFpgaPath: Input Pointer is NULL!");
        return 0xff000002 as libc::c_uint;
    }
    enable = BspGetPlusAndPlayEnable();
    if enable != 0x1 as libc::c_int as libc::c_uint {
        return 0xffffffff as libc::c_uint;
    }
    retVal = BspGetPlusAndPlaySwid(&mut bbuSwid);
    if retVal != 0 as libc::c_int as UINT32 {
        return 0xffffffff as libc::c_uint;
    }
    if bbuSwid == curSwid {
        return 0xffffffff as libc::c_uint;
    }
    *alarm = 0 as libc::c_int as UINT32;
    if retVal != 0 as libc::c_int as UINT32 {
        *alarm = 1 as libc::c_int as UINT32;
    }
    return 0 as libc::c_int as UINT32;
}
#[unsafe(no_mangle)]
pub unsafe extern "C" fn BspBackUpFpgaSwv(
    mut originPath: *const libc::c_char,
) -> UINT32 {
    let mut pathName: [CHAR; 255] = [
        0 as libc::c_int as CHAR,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
    ];
    let mut cmdBuf: [CHAR; 255] = [
        0 as libc::c_int as CHAR,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
    ];
    let mut ret: libc::c_int = 0 as libc::c_int;
    let mut swid: UINT32 = 0 as libc::c_int as UINT32;
    let mut retVal: UINT32 = 0 as libc::c_int as UINT32;
    // retVal = BspGetSwvSwid(originPath, &mut swid);
    if retVal != 0 as libc::c_int as UINT32 {
        return 0xffffffff as libc::c_uint;
    }
    // 使用 Rust 格式化函数重写
    // 将 C 字符串字面量转换为 Rust 字符串
    let dir_path = match CStr::from_bytes_with_nul(b"/ata/rru/prever/fpga\0") {
        Ok(c_str) => match c_str.to_str() {
            Ok(s) => s,
            Err(_) => "",
        },
        Err(_) => "",
    };
    
    // 使用 format! 宏创建格式化字符串
    let formatted = format!("{}/cur{}.swv", dir_path, swid);
    
    // 计算可用的最大长度（留一个字节给空终止符）
    let max_len = (::core::mem::size_of::<[CHAR; 255]>() as libc::c_ulong)
        .wrapping_sub(1 as libc::c_int as libc::c_ulong) as usize;
    
    // 转换为 C 字符串并写入缓冲区
    ret = match CString::new(formatted.as_str()) {
        Ok(c_string) => {
            let bytes = c_string.as_bytes(); // 不包含空终止符
            let copy_len = bytes.len().min(max_len);
            
            // 复制字符串到缓冲区
            std::ptr::copy_nonoverlapping(
                bytes.as_ptr() as *const libc::c_char,
                pathName.as_mut_ptr(),
                copy_len,
            );
            
            // 添加空终止符
            *pathName.as_mut_ptr().add(copy_len) = 0;
            
            // 返回写入的字符数（不包括空终止符），模拟 snprintf_s 的行为
            copy_len as libc::c_int
        }
        Err(_) => {
            // 如果转换失败，返回 -1
            -1 as libc::c_int
        }
    };
    // 使用 Rust 格式化函数重写
    // 将 C 字符串转换为 Rust 字符串
    let origin_path_str = if originPath.is_null() {
        ""
    } else {
        match CStr::from_ptr(originPath).to_str() {
            Ok(s) => s,
            Err(_) => "",
        }
    };
    
    let path_name_str = if pathName.as_mut_ptr().is_null() {
        ""
    } else {
        match CStr::from_ptr(pathName.as_mut_ptr() as *const libc::c_char).to_str() {
            Ok(s) => s,
            Err(_) => "",
        }
    };
    
    // 使用 format! 宏创建格式化字符串
    let formatted = format!("mv {} {}", origin_path_str, path_name_str);
    
    // 计算可用的最大长度（留一个字节给空终止符）
    let max_len = (::core::mem::size_of::<[CHAR; 255]>() as libc::c_ulong)
        .wrapping_sub(1 as libc::c_int as libc::c_ulong) as usize;
    
    // 转换为 C 字符串并写入缓冲区
    ret = match CString::new(formatted.as_str()) {
        Ok(c_string) => {
            let bytes = c_string.as_bytes(); // 不包含空终止符
            let copy_len = bytes.len().min(max_len);
            
            // 复制字符串到缓冲区
            std::ptr::copy_nonoverlapping(
                bytes.as_ptr() as *const libc::c_char,
                cmdBuf.as_mut_ptr(),
                copy_len,
            );
            
            // 添加空终止符
            *cmdBuf.as_mut_ptr().add(copy_len) = 0;
            
            // 返回写入的字符数（不包括空终止符），模拟 snprintf_s 的行为
            copy_len as libc::c_int
        }
        Err(_) => {
            // 如果转换失败，返回 -1
            -1 as libc::c_int
        }
    };
    return BspSystem(cmdBuf.as_mut_ptr()) as UINT32;
}
#[unsafe(no_mangle)]
pub unsafe extern "C" fn BspSetFpgaVerComparFlag(mut flag: UINT32) -> UINT32 {
    FpgaVerComparFlag = flag;
    return 0 as libc::c_int as UINT32;
}
#[unsafe(no_mangle)]
pub unsafe extern "C" fn BspGetFpgaVerComparFlag() -> UINT32 {
    return FpgaVerComparFlag;
}
#[unsafe(no_mangle)]
pub unsafe extern "C" fn BspGetFpgaVerSoftType() -> UINT32 {
    return s_fpgaVerSoftType;
}
#[unsafe(no_mangle)]
pub unsafe extern "C" fn BspSetFpgaVerSoftType(mut softType: UINT32) {
    s_fpgaVerSoftType = softType;
}

//! Rust 打桩实现 C 库函数
//! 
//! 本文件包含对 plugandplay.rs 中使用的 C 函数的 Rust 打桩实现

use std::ffi::c_void;
use libc;

// 类型定义（从 plugandplay.rs 复制）
pub type __dev_t = libc::c_ulong;
pub type __uid_t = libc::c_uint;
pub type __gid_t = libc::c_uint;
pub type __ino_t = libc::c_ulong;
pub type __mode_t = libc::c_uint;
pub type __nlink_t = libc::c_ulong;
pub type __off_t = libc::c_long;
pub type __off64_t = libc::c_long;
pub type __time_t = libc::c_long;
pub type __blksize_t = libc::c_long;
pub type __blkcnt_t = libc::c_long;
pub type __syscall_slong_t = libc::c_long;

#[repr(C)]
pub struct _IO_wide_data(c_void);
pub struct _IO_codecvt(c_void);
pub struct _IO_marker(c_void);

#[derive(Copy, Clone)]
#[repr(C)]
pub struct timespec {
    pub tv_sec: __time_t,
    pub tv_nsec: __syscall_slong_t,
}

#[derive(Copy, Clone)]
#[repr(C)]
pub struct stat {
    pub st_dev: __dev_t,
    pub st_ino: __ino_t,
    pub st_nlink: __nlink_t,
    pub st_mode: __mode_t,
    pub st_uid: __uid_t,
    pub st_gid: __gid_t,
    pub __pad0: libc::c_int,
    pub st_rdev: __dev_t,
    pub st_size: __off_t,
    pub st_blksize: __blksize_t,
    pub st_blocks: __blkcnt_t,
    pub st_atim: timespec,
    pub st_mtim: timespec,
    pub st_ctim: timespec,
    pub __glibc_reserved: [__syscall_slong_t; 3],
}

#[derive(Copy, Clone)]
#[repr(C)]
pub struct _IO_FILE {
    pub _flags: libc::c_int,
    pub _IO_read_ptr: *mut libc::c_char,
    pub _IO_read_end: *mut libc::c_char,
    pub _IO_read_base: *mut libc::c_char,
    pub _IO_write_base: *mut libc::c_char,
    pub _IO_write_ptr: *mut libc::c_char,
    pub _IO_write_end: *mut libc::c_char,
    pub _IO_buf_base: *mut libc::c_char,
    pub _IO_buf_end: *mut libc::c_char,
    pub _IO_save_base: *mut libc::c_char,
    pub _IO_backup_base: *mut libc::c_char,
    pub _IO_save_end: *mut libc::c_char,
    pub _markers: *mut _IO_marker,
    pub _chain: *mut _IO_FILE,
    pub _fileno: libc::c_int,
    pub _flags2: libc::c_int,
    pub _old_offset: __off_t,
    pub _cur_column: libc::c_ushort,
    pub _vtable_offset: libc::c_schar,
    pub _shortbuf: [libc::c_char; 1],
    pub _lock: *mut libc::c_void,
    pub _offset: __off64_t,
    pub _codecvt: *mut _IO_codecvt,
    pub _wide_data: *mut _IO_wide_data,
    pub _freeres_list: *mut _IO_FILE,
    pub _freeres_buf: *mut libc::c_void,
    pub __pad5: libc::c_int,
    pub _mode: libc::c_int,
    pub _unused2: libc::c_char,
}

pub type FILE = _IO_FILE;
pub type CHAR = libc::c_char;
pub type INT = libc::c_int;
pub type INT32 = libc::c_int;
pub type rsize_t = libc::c_int;
pub type errno_t = libc::c_int;

/// 打桩实现：关闭文件流
/// 
/// # Safety
/// 
/// 这是一个打桩实现，不执行实际的文件关闭操作
#[unsafe(no_mangle)]
pub unsafe extern "C" fn fclose(__stream: *mut FILE) -> libc::c_int {
    // 打桩实现：总是返回成功
    if __stream.is_null() {
        return -1; // EOF
    }
    0 // 成功
}

/// 打桩实现：获取文件状态信息
/// 
/// # Safety
/// 
/// 这是一个打桩实现，不执行实际的文件状态查询
#[unsafe(no_mangle)]
pub unsafe extern "C" fn __xstat(
    __ver: libc::c_int,
    __filename: *const libc::c_char,
    __stat_buf: *mut stat,
) -> libc::c_int {
    // 打桩实现：总是返回失败（文件不存在）
    if __stat_buf.is_null() {
        return -1;
    }
    // 初始化 stat 结构体为零
    unsafe {
        std::ptr::write_bytes(__stat_buf, 0, 1);
    }
    -1 // 返回失败，模拟文件不存在
}

/// 打桩实现：安全字符串长度计算
/// 
/// # Safety
/// 
/// 这是一个打桩实现，使用标准库的 strlen 功能
#[unsafe(no_mangle)]
pub unsafe extern "C" fn encapsulationOfZte_strnlen_s(
    s: *const libc::c_char,
    maxsize: rsize_t,
    _fileName: *const libc::c_char,
    _lineNo: libc::c_int,
) -> libc::c_int {
    if s.is_null() {
        return 0;
    }
    if maxsize <= 0 {
        return 0;
    }
    
    // 计算字符串长度，但不超过 maxsize
    let mut len = 0;
    let mut ptr = s;
    unsafe {
        while len < maxsize as usize {
            if *ptr == 0 {
                break;
            }
            len += 1;
            ptr = ptr.add(1);
        }
    }
    
    len as libc::c_int
}

/// 打桩实现：安全字符串复制
/// 
/// # Safety
/// 
/// 这是一个打桩实现，执行安全的字符串复制
#[unsafe(no_mangle)]
pub unsafe extern "C" fn encapsulationOfZte_strncpy_s(
    s1: *mut libc::c_char,
    s1max: rsize_t,
    s2: *const libc::c_char,
    n: rsize_t,
    _fileName: *const libc::c_char,
    _lineNo: libc::c_int,
) -> libc::c_int {
    if s1.is_null() || s2.is_null() {
        return -1; // 错误：空指针
    }
    if s1max <= 0 {
        return -1; // 错误：缓冲区大小无效
    }
    
    // 计算实际要复制的长度
    let copy_len = if n < 0 {
        s1max as usize - 1 // 留一个字节给空终止符
    } else {
        (n as usize).min(s1max as usize - 1)
    };
    
    // 复制字符串
    unsafe {
        let mut i = 0;
        while i < copy_len {
            let c = *s2.add(i);
            *s1.add(i) = c;
            if c == 0 {
                break; // 遇到空终止符，停止复制
            }
            i += 1;
        }
        
        // 确保目标字符串以空终止符结尾
        if i < s1max as usize {
            *s1.add(i) = 0;
        } else {
            *s1.add(s1max as usize - 1) = 0; // 在最后一个位置放置空终止符
        }
    }
    
    0 // 成功
}

/// 打桩实现：安全打开文件
/// 
/// # Safety
/// 
/// 这是一个打桩实现，不执行实际的文件打开操作
#[unsafe(no_mangle)]
pub unsafe extern "C" fn fopen_s(
    streamptr: *mut *mut FILE,
    _filename: *const libc::c_char,
    _mode: *const libc::c_char,
) -> errno_t {
    // 打桩实现：总是返回失败（文件无法打开）
    if streamptr.is_null() {
        return 22; // EINVAL
    }
    unsafe {
        *streamptr = std::ptr::null_mut();
    }
    2 // ENOENT - 文件不存在
}

/// 打桩实现：从配置文件获取键值
/// 
/// # Safety
/// 
/// 这是一个打桩实现，不执行实际的配置读取操作
#[unsafe(no_mangle)]
pub unsafe extern "C" fn ConfigGetKeyEx(
    _CFG_file: *const libc::c_void,
    _section: *const libc::c_void,
    _key: *const libc::c_void,
    buf: *mut libc::c_void,
    buflen: libc::c_uint,
) -> libc::c_int {
    // 打桩实现：返回失败（配置项不存在）
    if buf.is_null() || buflen == 0 {
        return -1;
    }
    // 将缓冲区清零
    unsafe {
        std::ptr::write_bytes(buf, 0, buflen as usize);
    }
    -1 // 返回失败，表示配置项不存在
}

/// 打桩实现：设置配置文件键值
/// 
/// # Safety
/// 
/// 这是一个打桩实现，不执行实际的配置写入操作
#[unsafe(no_mangle)]
pub unsafe extern "C" fn ConfigSetKey(
    _CFG_file: *const libc::c_void,
    _section: *const libc::c_void,
    _key: *const libc::c_void,
    _buf: *const libc::c_void,
) -> libc::c_int {
    // 打桩实现：总是返回成功
    0
}

/// 打桩实现：执行系统命令
/// 
/// # Safety
/// 
/// 这是一个打桩实现，不执行实际的系统命令
#[unsafe(no_mangle)]
pub unsafe extern "C" fn BspSystem(pcCommand: *const CHAR) -> INT {
    // 打桩实现：打印命令但不执行
    if pcCommand.is_null() {
        return -1;
    }
    
    // 可选：打印命令用于调试
    // unsafe {
    //     let cmd_str = std::ffi::CStr::from_ptr(pcCommand);
    //     if let Ok(s) = cmd_str.to_str() {
    //         println!("[STUB] BspSystem: {}", s);
    //     }
    // }
    
    0 // 返回成功
}

/// 打桩实现：字符串转整数
/// 
/// # Safety
/// 
/// 这是一个打桩实现，使用标准库的字符串解析功能
#[unsafe(no_mangle)]
pub unsafe extern "C" fn BspAtoi(str: *const libc::c_char, base: INT32) -> INT32 {
    if str.is_null() {
        return 0;
    }
    
    // 将 C 字符串转换为 Rust 字符串
    let c_str = unsafe {
        match std::ffi::CStr::from_ptr(str).to_str() {
            Ok(s) => s,
            Err(_) => return 0,
        }
    };
    
    // 根据 base 解析字符串
    if base == 0 {
        // base 0: 自动检测（十进制、八进制、十六进制）
        if c_str.starts_with("0x") || c_str.starts_with("0X") {
            i32::from_str_radix(&c_str[2..], 16).unwrap_or(0)
        } else if c_str.starts_with("0") && c_str.len() > 1 {
            i32::from_str_radix(&c_str[1..], 8).unwrap_or(0)
        } else {
            c_str.parse::<i32>().unwrap_or(0)
        }
    } else if base >= 2 && base <= 36 {
        i32::from_str_radix(c_str, base as u32).unwrap_or(0)
    } else {
        0 // 无效的 base
    }
}


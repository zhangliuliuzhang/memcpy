//! rruinfo 模块的单元测试和功能测试
//! 
//! 本文件包含对 plugandplay.rs 和 rruinfo_clib.rs 的全面测试
//! 目标：行覆盖率和分支覆盖率达到90%以上

#![allow(
    dead_code,
    non_snake_case,
    unused_assignments,
    unused_mut
)]

use minicov;
use std::fs;
mod all_tests{
    extern crate rruinfo;

    // 使用模块别名避免冲突
    use rruinfo::rruinfo_clib as clib;
    use rruinfo::plugandplay as pnp;

    use std::ffi::{CString, CStr};
    use std::ptr;

    // ============================================================================
    // rruinfo_clib.rs 测试
    // ============================================================================
    // ========================================================================
    // fclose 测试
    // ========================================================================
    
    
    pub fn test_fclose_null_ptr() {
        unsafe {
            let result = clib::fclose(ptr::null_mut());
            assert_eq!(result, -1); // EOF
        }
    }

    
    pub fn test_fclose_valid_ptr() {
        unsafe {
            // 创建一个假的 FILE 指针（仅用于测试）
            let fake_file: *mut clib::FILE = 0x1000 as *mut clib::FILE;
            let result = clib::fclose(fake_file);
            assert_eq!(result, 0); // 成功
        }
    }

    // ========================================================================
    // __xstat 测试
    // ========================================================================
    
    
    pub fn test_xstat_null_stat_buf() {
        unsafe {
            let filename = CString::new("/tmp/test").unwrap();
            let result = clib::__xstat(1, filename.as_ptr(), ptr::null_mut());
            assert_eq!(result, -1);
        }
    }

    
    pub fn test_xstat_valid_args() {
        unsafe {
            let filename = CString::new("/tmp/test").unwrap();
            let mut stat_buf = clib::stat {
                st_dev: 0,
                st_ino: 0,
                st_nlink: 0,
                st_mode: 0,
                st_uid: 0,
                st_gid: 0,
                __pad0: 0,
                st_rdev: 0,
                st_size: 0,
                st_blksize: 0,
                st_blocks: 0,
                st_atim: clib::timespec { tv_sec: 0, tv_nsec: 0 },
                st_mtim: clib::timespec { tv_sec: 0, tv_nsec: 0 },
                st_ctim: clib::timespec { tv_sec: 0, tv_nsec: 0 },
                __glibc_reserved: [0; 3],
            };
            let result = clib::__xstat(1, filename.as_ptr(), &mut stat_buf);
            assert_eq!(result, -1); // 打桩实现总是返回失败
        }
    }

    // ========================================================================
    // clib::encapsulationOfZte_strnlen_s 测试
    // ========================================================================
    
    
    pub fn test_strnlen_s_null_ptr() {
        unsafe {
            let result = clib::encapsulationOfZte_strnlen_s(
                ptr::null(),
                10,
                ptr::null(),
                0,
            );
            assert_eq!(result, 0);
        }
    }

    
    pub fn test_strnlen_s_zero_maxsize() {
        unsafe {
            let s = CString::new("test").unwrap();
            let result = clib::encapsulationOfZte_strnlen_s(
                s.as_ptr(),
                0,
                ptr::null(),
                0,
            );
            assert_eq!(result, 0);
        }
    }

    
    pub fn test_strnlen_s_negative_maxsize() {
        unsafe {
            let s = CString::new("test").unwrap();
            let result = clib::encapsulationOfZte_strnlen_s(
                s.as_ptr(),
                -1,
                ptr::null(),
                0,
            );
            assert_eq!(result, 0);
        }
    }

    
    pub fn test_strnlen_s_normal_string() {
        unsafe {
            let s = CString::new("hello").unwrap();
            let result = clib::encapsulationOfZte_strnlen_s(
                s.as_ptr(),
                100,
                ptr::null(),
                0,
            );
            assert_eq!(result, 5);
        }
    }

    
    pub fn test_strnlen_s_empty_string() {
        unsafe {
            let s = CString::new("").unwrap();
            let result = clib::encapsulationOfZte_strnlen_s(
                s.as_ptr(),
                100,
                ptr::null(),
                0,
            );
            assert_eq!(result, 0);
        }
    }

    
    pub fn test_strnlen_s_truncated() {
        unsafe {
            let s = CString::new("hello world").unwrap();
            let result = clib::encapsulationOfZte_strnlen_s(
                s.as_ptr(),
                5,
                ptr::null(),
                0,
            );
            assert_eq!(result, 5);
        }
    }

    // ========================================================================
    // clib::encapsulationOfZte_strncpy_s 测试
    // ========================================================================
    
    
    pub fn test_strncpy_s_null_s1() {
        unsafe {
            let s2 = CString::new("test").unwrap();
            let result = clib::encapsulationOfZte_strncpy_s(
                ptr::null_mut(),
                10,
                s2.as_ptr(),
                5,
                ptr::null(),
                0,
            );
            assert_eq!(result, -1);
        }
    }

    
    pub fn test_strncpy_s_null_s2() {
        unsafe {
            let mut buf: [libc::c_char; 10] = [0; 10];
            let result = clib::encapsulationOfZte_strncpy_s(
                buf.as_mut_ptr(),
                10,
                ptr::null(),
                5,
                ptr::null(),
                0,
            );
            assert_eq!(result, -1);
        }
    }

    
    pub fn test_strncpy_s_zero_s1max() {
        unsafe {
            let mut buf: [libc::c_char; 10] = [0; 10];
            let s2 = CString::new("test").unwrap();
            let result = clib::encapsulationOfZte_strncpy_s(
                buf.as_mut_ptr(),
                0,
                s2.as_ptr(),
                5,
                ptr::null(),
                0,
            );
            assert_eq!(result, -1);
        }
    }

    
    pub fn test_strncpy_s_normal_copy() {
        unsafe {
            let mut buf: [libc::c_char; 20] = [0; 20];
            let s2 = CString::new("hello").unwrap();
            let result = clib::encapsulationOfZte_strncpy_s(
                buf.as_mut_ptr(),
                20,
                s2.as_ptr(),
                5,
                ptr::null(),
                0,
            );
            assert_eq!(result, 0);
            let copied = CStr::from_ptr(buf.as_ptr());
            assert_eq!(copied.to_str().unwrap(), "hello");
        }
    }

    
    pub fn test_strncpy_s_negative_n() {
        unsafe {
            let mut buf: [libc::c_char; 10] = [0; 10];
            let s2 = CString::new("hello world").unwrap();
            let result = clib::encapsulationOfZte_strncpy_s(
                buf.as_mut_ptr(),
                10,
                s2.as_ptr(),
                -1,
                ptr::null(),
                0,
            );
            assert_eq!(result, 0);
            // 应该复制 9 个字符（留一个给空终止符）
            let copied = CStr::from_ptr(buf.as_ptr());
            assert_eq!(copied.to_str().unwrap().len(), 9);
        }
    }

    
    pub fn test_strncpy_s_truncated() {
        unsafe {
            let mut buf: [libc::c_char; 5] = [0; 5];
            let s2 = CString::new("hello world").unwrap();
            let result = clib::encapsulationOfZte_strncpy_s(
                buf.as_mut_ptr(),
                5,
                s2.as_ptr(),
                10,
                ptr::null(),
                0,
            );
            assert_eq!(result, 0);
            let copied = CStr::from_ptr(buf.as_ptr());
            assert_eq!(copied.to_str().unwrap().len(), 4);
        }
    }

    
    pub fn test_strncpy_s_empty_string() {
        unsafe {
            let mut buf: [libc::c_char; 10] = [0; 10];
            let s2 = CString::new("").unwrap();
            let result = clib::encapsulationOfZte_strncpy_s(
                buf.as_mut_ptr(),
                10,
                s2.as_ptr(),
                5,
                ptr::null(),
                0,
            );
            assert_eq!(result, 0);
            let copied = CStr::from_ptr(buf.as_ptr());
            assert_eq!(copied.to_str().unwrap(), "");
        }
    }

    // ========================================================================
    // clib::fopen_s 测试
    // ========================================================================
    
    
    pub fn test_fopen_s_null_streamptr() {
        unsafe {
            let filename = CString::new("/tmp/test").unwrap();
            let mode = CString::new("r").unwrap();
            let result = clib::fopen_s(ptr::null_mut(), filename.as_ptr(), mode.as_ptr());
            assert_eq!(result, 22); // EINVAL
        }
    }

    
    pub fn test_fopen_s_valid_args() {
        unsafe {
            let filename = CString::new("/tmp/test").unwrap();
            let mode = CString::new("r").unwrap();
            let mut stream: *mut clib::FILE = ptr::null_mut();
            let result = clib::fopen_s(&mut stream, filename.as_ptr(), mode.as_ptr());
            assert_eq!(result, 2); // ENOENT
            assert!(stream.is_null());
        }
    }

    // ========================================================================
    // clib::ConfigGetKeyEx 测试
    // ========================================================================
    
    
    pub fn test_config_get_key_ex_null_buf() {
        unsafe {
            let cfg_file = CString::new("/tmp/config.ini").unwrap();
            let section = CString::new("section").unwrap();
            let key = CString::new("key").unwrap();
            let result = clib::ConfigGetKeyEx(
                cfg_file.as_ptr() as *const libc::c_void,
                section.as_ptr() as *const libc::c_void,
                key.as_ptr() as *const libc::c_void,
                ptr::null_mut(),
                10,
            );
            assert_eq!(result, -1);
        }
    }

    pub fn test_config_get_key_ex_zero_buflen() {
        unsafe {
            let cfg_file = CString::new("/tmp/config.ini").unwrap();
            let section = CString::new("section").unwrap();
            let key = CString::new("key").unwrap();
            let mut buf: [libc::c_char; 10] = [0; 10];
            let result = clib::ConfigGetKeyEx(
                cfg_file.as_ptr() as *const libc::c_void,
                section.as_ptr() as *const libc::c_void,
                key.as_ptr() as *const libc::c_void,
                buf.as_mut_ptr() as *mut libc::c_void,
                0,
            );
            assert_eq!(result, -1);
        }
    }

    
    pub fn test_config_get_key_ex_valid_args() {
        unsafe {
            let cfg_file = CString::new("/tmp/config.ini").unwrap();
            let section = CString::new("section").unwrap();
            let key = CString::new("key").unwrap();
            let mut buf: [libc::c_char; 100] = [1; 100]; // 初始化为非零值
            let result = clib::ConfigGetKeyEx(
                cfg_file.as_ptr() as *const libc::c_void,
                section.as_ptr() as *const libc::c_void,
                key.as_ptr() as *const libc::c_void,
                buf.as_mut_ptr() as *mut libc::c_void,
                100,
            );
            assert_eq!(result, -1); // 打桩实现返回失败
            // 验证缓冲区被清零
            assert_eq!(buf[0], 0);
        }
    }

    // ========================================================================
    // clib::ConfigSetKey 测试
    // ========================================================================
    
    
    pub fn test_config_set_key() {
        unsafe {
            let cfg_file = CString::new("/tmp/config.ini").unwrap();
            let section = CString::new("section").unwrap();
            let key = CString::new("key").unwrap();
            let value = CString::new("value").unwrap();
            let result = clib::ConfigSetKey(
                cfg_file.as_ptr() as *const libc::c_void,
                section.as_ptr() as *const libc::c_void,
                key.as_ptr() as *const libc::c_void,
                value.as_ptr() as *const libc::c_void,
            );
            assert_eq!(result, 0); // 打桩实现总是返回成功
        }
    }

    // ========================================================================
    // clib::BspSystem 测试
    // ========================================================================
    
    
    pub fn test_bsp_system_null_ptr() {
        unsafe {
            let result = clib::BspSystem(ptr::null());
            assert_eq!(result, -1);
        }
    }

    
    pub fn test_bsp_system_valid_command() {
        unsafe {
            let cmd = CString::new("ls -la").unwrap();
            let result = clib::BspSystem(cmd.as_ptr());
            assert_eq!(result, 0); // 打桩实现返回成功
        }
    }

    // ========================================================================
    // clib::BspAtoi 测试
    // ========================================================================
    
    
    pub fn test_bsp_atoi_null_ptr() {
        unsafe {
            let result = clib::BspAtoi(ptr::null(), 10);
            assert_eq!(result, 0);
        }
    }

    
    pub fn test_bsp_atoi_decimal() {
        unsafe {
            let s = CString::new("123").unwrap();
            let result = clib::BspAtoi(s.as_ptr(), 10);
            assert_eq!(result, 123);
        }
    }

    
    pub fn test_bsp_atoi_hexadecimal() {
        unsafe {
            let s = CString::new("FF").unwrap();
            let result = clib::BspAtoi(s.as_ptr(), 16);
            assert_eq!(result, 255);
        }
    }

    
    pub fn test_bsp_atoi_octal() {
        unsafe {
            let s = CString::new("777").unwrap();
            let result = clib::BspAtoi(s.as_ptr(), 8);
            assert_eq!(result, 511);
        }
    }

    
    pub fn test_bsp_atoi_base_zero_hex() {
        unsafe {
            let s = CString::new("0xFF").unwrap();
            let result = clib::BspAtoi(s.as_ptr(), 0);
            assert_eq!(result, 255);
        }
    }

    
    pub fn test_bsp_atoi_base_zero_octal() {
        unsafe {
            let s = CString::new("0777").unwrap();
            let result = clib::BspAtoi(s.as_ptr(), 0);
            assert_eq!(result, 511);
        }
    }

    
    pub fn test_bsp_atoi_base_zero_decimal() {
        unsafe {
            let s = CString::new("123").unwrap();
            let result = clib::BspAtoi(s.as_ptr(), 0);
            assert_eq!(result, 123);
        }
    }

    
    pub fn test_bsp_atoi_invalid_base() {
        unsafe {
            let s = CString::new("123").unwrap();
            let result = clib::BspAtoi(s.as_ptr(), 37); // 无效的 base
            assert_eq!(result, 0);
        }
    }

    
    pub fn test_bsp_atoi_invalid_string() {
        unsafe {
            let s = CString::new("abc").unwrap();
            let result = clib::BspAtoi(s.as_ptr(), 10);
            assert_eq!(result, 0); // 解析失败返回 0
        }
    }

    
    pub fn test_bsp_atoi_negative() {
        unsafe {
            let s = CString::new("-123").unwrap();
            let result = clib::BspAtoi(s.as_ptr(), 10);
            assert_eq!(result, -123);
        }
    }

    
    pub fn test_bsp_atoi_zero() {
        unsafe {
            let s = CString::new("0").unwrap();
            let result = clib::BspAtoi(s.as_ptr(), 10);
            assert_eq!(result, 0);
        }
    }

    
    pub fn test_bsp_atoi_empty_string() {
        unsafe {
            let s = CString::new("").unwrap();
            let result = clib::BspAtoi(s.as_ptr(), 10);
            assert_eq!(result, 0);
        }
    }

    // ========================================================================
    // pnp::CreatePreverDir 测试
    // ========================================================================
    
    
    pub fn test_create_prever_dir() {
        unsafe {
            // 这个函数会调用 clib::BspSystem，打桩实现会返回成功
            pnp::CreatePreverDir();
            // 由于是打桩实现，无法验证实际行为，但可以确保不崩溃
        }
    }

    // ========================================================================
    // pnp::BspGetPlusAndPlayEnable 测试
    // ========================================================================
    
    
    pub fn test_bsp_get_plus_and_play_enable() {
        unsafe {
            // clib::ConfigGetKeyEx 打桩实现返回失败，所以应该返回 0
            let result = pnp::BspGetPlusAndPlayEnable();
            assert_eq!(result, 0);
        }
    }

    // ========================================================================
    // pnp::BspGetPlusAndPlayVerRestrict 测试
    // ========================================================================
    
    
    pub fn test_bsp_get_plus_and_play_ver_restrict_null_ptr() {
        unsafe {
            let result = pnp::BspGetPlusAndPlayVerRestrict(ptr::null_mut(), 0);
            // clib::ConfigGetKeyEx 返回失败，应该返回 0xffffffff
            assert_eq!(result, 0xffffffff);
        }
    }

    
    pub fn test_bsp_get_plus_and_play_ver_restrict_valid_ptr() {
        unsafe {
            let mut buf: [libc::c_char; 100] = [0; 100];
            let result = pnp::BspGetPlusAndPlayVerRestrict(buf.as_mut_ptr(), 100);
            // clib::ConfigGetKeyEx 返回失败，应该返回 0xffffffff
            assert_eq!(result, 0xffffffff);
        }
    }

    
    pub fn test_bsp_get_plus_and_play_ver_restrict_with_quotes() {
        unsafe {
            // 这个测试需要 clib::ConfigGetKeyEx 返回成功，但打桩实现返回失败
            // 所以这个分支无法测试，但我们可以确保函数不崩溃
            let mut buf: [libc::c_char; 100] = [0; 100];
            let result = pnp::BspGetPlusAndPlayVerRestrict(buf.as_mut_ptr(), 100);
            assert_eq!(result, 0xffffffff);
        }
    }

    // ========================================================================
    // pnp::BspGetPlusAndPlaySwid 测试
    // ========================================================================
    
    
    pub fn test_bsp_get_plus_and_play_swid_null_ptr() {
        unsafe {
            let result = pnp::BspGetPlusAndPlaySwid(ptr::null_mut());
            // clib::ConfigGetKeyEx 返回失败，应该返回 0xffffffff
            assert_eq!(result, 0xffffffff);
        }
    }

    
    pub fn test_bsp_get_plus_and_play_swid_valid_ptr() {
        unsafe {
            let mut swid: pnp::UINT32 = 0;
            let result = pnp::BspGetPlusAndPlaySwid(&mut swid);
            // clib::ConfigGetKeyEx 返回失败，应该返回 0xffffffff
            assert_eq!(result, 0xffffffff);
        }
    }

    // ========================================================================
    // pnp::BspSetPlusAndPlaySwid 测试
    // ========================================================================
    
    
    pub fn test_bsp_set_plus_and_play_swid() {
        unsafe {
            let result = pnp::BspSetPlusAndPlaySwid(123);
            // clib::ConfigSetKey 打桩实现返回成功，所以应该返回 0
            assert_eq!(result, 0);
        }
    }

    
    pub fn test_bsp_set_plus_and_play_swid_failure() {
        unsafe {
            // 由于 clib::ConfigSetKey 打桩实现总是返回成功，无法测试失败路径
            // 但可以确保函数正常执行
            let result = pnp::BspSetPlusAndPlaySwid(456);
            assert_eq!(result, 0);
        }
    }

    // ========================================================================
    // pnp::BspGetPreverFpgaPath 测试
    // ========================================================================
    
    
    pub fn test_bsp_get_prever_fpga_path_null_new_fpga_path() {
        unsafe {
            let mut alarm: pnp::UINT32 = 0;
            let result = pnp::BspGetPreverFpgaPath(1, ptr::null_mut(), 100, &mut alarm);
            assert_eq!(result, 0xff000002);
        }
    }

    
    pub fn test_bsp_get_prever_fpga_path_null_alarm() {
        unsafe {
            let mut path: [libc::c_char; 100] = [0; 100];
            let result = pnp::BspGetPreverFpgaPath(1, path.as_mut_ptr(), 100, ptr::null_mut());
            assert_eq!(result, 0xff000002);
        }
    }

    
    pub fn test_bsp_get_prever_fpga_path_enable_not_one() {
        unsafe {
            let mut path: [libc::c_char; 100] = [0; 100];
            let mut alarm: pnp::UINT32 = 0;
            // pnp::BspGetPlusAndPlayEnable 返回 0（因为 clib::ConfigGetKeyEx 失败）
            let result = pnp::BspGetPreverFpgaPath(1, path.as_mut_ptr(), 100, &mut alarm);
            assert_eq!(result, 0xffffffff);
        }
    }

    
    pub fn test_bsp_get_prever_fpga_path_swid_equal() {
        unsafe {
            // 这个测试需要 pnp::BspGetPlusAndPlayEnable 返回 1
            // 但由于打桩实现，无法满足这个条件
            // 所以这个分支无法测试
            let mut path: [libc::c_char; 100] = [0; 100];
            let mut alarm: pnp::UINT32 = 0;
            let result = pnp::BspGetPreverFpgaPath(1, path.as_mut_ptr(), 100, &mut alarm);
            // 由于 enable != 1，会提前返回
            assert_eq!(result, 0xffffffff);
        }
    }

    // ========================================================================
    // pnp::BspBackUpFpgaSwv 测试
    // ========================================================================
    
    
    pub fn test_bsp_back_up_fpga_swv_null_path() {
        unsafe {
            let result = pnp::BspBackUpFpgaSwv(ptr::null());
            // 由于 retVal 初始化为 0，且 BspGetSwvSwid 被注释掉，不会进入错误分支
            // 函数最终返回 BspSystem 的结果，打桩实现返回 0
            assert_eq!(result, 0);
        }
    }

    
    pub fn test_bsp_back_up_fpga_swv_valid_path() {
        unsafe {
            let path = CString::new("/tmp/test.swv").unwrap();
            let result = pnp::BspBackUpFpgaSwv(path.as_ptr());
            // 由于 retVal 初始化为 0，且 BspGetSwvSwid 被注释掉，不会进入错误分支
            // 函数最终返回 BspSystem 的结果，打桩实现返回 0
            assert_eq!(result, 0);
        }
    }

    // ========================================================================
    // pnp::BspSetFpgaVerComparFlag / pnp::BspGetFpgaVerComparFlag 测试
    // ========================================================================
    
    
    pub fn test_bsp_set_and_get_fpga_ver_compar_flag() {
        unsafe {
            // 设置标志
            let result = pnp::BspSetFpgaVerComparFlag(123);
            assert_eq!(result, 0);
            
            // 获取标志
            let flag = pnp::BspGetFpgaVerComparFlag();
            assert_eq!(flag, 123);
        }
    }

    
    pub fn test_bsp_set_fpga_ver_compar_flag_zero() {
        unsafe {
            pnp::BspSetFpgaVerComparFlag(0);
            let flag = pnp::BspGetFpgaVerComparFlag();
            assert_eq!(flag, 0);
        }
    }

    
    pub fn test_bsp_set_fpga_ver_compar_flag_max() {
        unsafe {
            pnp::BspSetFpgaVerComparFlag(0xffffffff);
            let flag = pnp::BspGetFpgaVerComparFlag();
            assert_eq!(flag, 0xffffffff);
        }
    }

    // ========================================================================
    // pnp::BspGetFpgaVerSoftType / pnp::BspSetFpgaVerSoftType 测试
    // ========================================================================
    
    
    pub fn test_bsp_get_and_set_fpga_ver_soft_type() {
        unsafe {
            // 获取初始值
            let initial = pnp::BspGetFpgaVerSoftType();
            
            // 设置新值
            pnp::BspSetFpgaVerSoftType(456);
            
            // 获取新值
            let new_value = pnp::BspGetFpgaVerSoftType();
            assert_eq!(new_value, 456);
            
            // 恢复初始值（可选）
            pnp::BspSetFpgaVerSoftType(initial);
        }
    }

    
    pub fn test_bsp_set_fpga_ver_soft_type_zero() {
        unsafe {
            pnp::BspSetFpgaVerSoftType(0);
            let value = pnp::BspGetFpgaVerSoftType();
            assert_eq!(value, 0);
        }
    }

    
    pub fn test_bsp_set_fpga_ver_soft_type_max() {
        unsafe {
            pnp::BspSetFpgaVerSoftType(0xffffffff);
            let value = pnp::BspGetFpgaVerSoftType();
            assert_eq!(value, 0xffffffff);
        }
    }


    // ============================================================================
    // 集成测试
    // ============================================================================
    pub fn test_plug_and_play_workflow() {
        unsafe {
            // 测试完整的即插即用工作流程
            // 1. 检查是否启用
            let enable = pnp::BspGetPlusAndPlayEnable();
            // 由于打桩实现，enable 应该是 0
            
            // 2. 设置软件ID
            if enable == 1 {
                let set_result = pnp::BspSetPlusAndPlaySwid(100);
                assert_eq!(set_result, 0);
                
                // 3. 获取软件ID
                let mut swid: pnp::UINT32 = 0;
                let get_result = pnp::BspGetPlusAndPlaySwid(&mut swid);
                // 由于打桩实现，get_result 可能是 0xffffffff
            }
        }
    }

    
    pub fn test_fpga_version_management() {
        unsafe {
            // 测试 FPGA 版本管理
            // 1. 设置比较标志
            pnp::BspSetFpgaVerComparFlag(1);
            assert_eq!(pnp::BspGetFpgaVerComparFlag(), 1);
            
            // 2. 设置软件类型
            pnp::BspSetFpgaVerSoftType(2);
            assert_eq!(pnp::BspGetFpgaVerSoftType(), 2);
            
            // 3. 获取 FPGA 路径（会失败，因为 enable != 1）
            let mut path: [libc::c_char; 100] = [0; 100];
            let mut alarm: pnp::UINT32 = 0;
            let result = pnp::BspGetPreverFpgaPath(1, path.as_mut_ptr(), 100, &mut alarm);
            assert_eq!(result, 0xffffffff);
        }
    }

    
    pub fn test_string_operations_chain() {
        unsafe {
            // 测试字符串操作的链式使用
            let src = CString::new("source string").unwrap();
            let mut buf1: [libc::c_char; 50] = [0; 50];
            let mut buf2: [libc::c_char; 50] = [0; 50];
            
            // 1. 获取源字符串长度
            let len = clib::encapsulationOfZte_strnlen_s(
                src.as_ptr(),
                50,
                ptr::null(),
                0,
            );
            assert!(len > 0);
            
            // 2. 复制字符串
            let copy_result = clib::encapsulationOfZte_strncpy_s(
                buf1.as_mut_ptr(),
                50,
                src.as_ptr(),
                len,
                ptr::null(),
                0,
            );
            assert_eq!(copy_result, 0);
            
            // 3. 再次复制
            let copy_result2 = clib::encapsulationOfZte_strncpy_s(
                buf2.as_mut_ptr(),
                50,
                buf1.as_ptr(),
                len,
                ptr::null(),
                0,
            );
            assert_eq!(copy_result2, 0);
            
            // 验证结果
            let copied1 = CStr::from_ptr(buf1.as_ptr());
            let copied2 = CStr::from_ptr(buf2.as_ptr());
            assert_eq!(copied1.to_str().unwrap(), copied2.to_str().unwrap());
        }
    }

    
    pub fn test_config_operations() {
        unsafe {
            // 测试配置操作
            let cfg_file = CString::new("/tmp/test.ini").unwrap();
            let section = CString::new("test_section").unwrap();
            let key = CString::new("test_key").unwrap();
            let value = CString::new("test_value").unwrap();
            
            // 1. 设置配置
            let set_result = clib::ConfigSetKey(
                cfg_file.as_ptr() as *const libc::c_void,
                section.as_ptr() as *const libc::c_void,
                key.as_ptr() as *const libc::c_void,
                value.as_ptr() as *const libc::c_void,
            );
            assert_eq!(set_result, 0);
            
            // 2. 获取配置（会失败，因为打桩实现）
            let mut buf: [libc::c_char; 100] = [0; 100];
            let get_result = clib::ConfigGetKeyEx(
                cfg_file.as_ptr() as *const libc::c_void,
                section.as_ptr() as *const libc::c_void,
                key.as_ptr() as *const libc::c_void,
                buf.as_mut_ptr() as *mut libc::c_void,
                100,
            );
            assert_eq!(get_result, -1);
        }
    }

    use rruinfo::rruinfo as rruinfo_mod;
    // ========================================================================
    // zte_sscanf_s 测试
    // ========================================================================
    
    pub fn test_zte_sscanf_s_null_s() {
        unsafe {
            let format = CString::new("%d").unwrap();
            let mut size_array: rruinfo_mod::rsize_t = 10;
            let result = rruinfo_mod::zte_sscanf_s(
                ptr::null(),
                format.as_ptr(),
                &mut size_array,
            );
            assert_eq!(result, -1);
        }
    }

    
    pub fn test_zte_sscanf_s_null_format() {
        unsafe {
            let s = CString::new("123").unwrap();
            let mut size_array: rruinfo_mod::rsize_t = 10;
            let result = rruinfo_mod::zte_sscanf_s(
                s.as_ptr(),
                ptr::null(),
                &mut size_array,
            );
            assert_eq!(result, -1);
        }
    }

    
    pub fn test_zte_sscanf_s_both_null() {
        unsafe {
            let mut size_array: rruinfo_mod::rsize_t = 10;
            let result = rruinfo_mod::zte_sscanf_s(
                ptr::null(),
                ptr::null(),
                &mut size_array,
            );
            assert_eq!(result, -1);
        }
    }

    
    pub fn test_zte_sscanf_s_null_size_array() {
        unsafe {
            let s = CString::new("123").unwrap();
            let format = CString::new("%d").unwrap();
            let result = rruinfo_mod::zte_sscanf_s(
                s.as_ptr(),
                format.as_ptr(),
                ptr::null_mut(),
            );
            // 即使 size_array 为空，函数也应该返回 0（成功但未解析参数）
            assert_eq!(result, 0);
        }
    }

    
    pub fn test_zte_sscanf_s_valid_args_with_size_array() {
        unsafe {
            let s = CString::new("123").unwrap();
            let format = CString::new("%d").unwrap();
            let mut size_array: rruinfo_mod::rsize_t = 10;
            let result = rruinfo_mod::zte_sscanf_s(
                s.as_ptr(),
                format.as_ptr(),
                &mut size_array,
            );
            assert_eq!(result, 0); // 打桩实现返回 0
            assert_eq!(size_array, 0); // size_array 被设置为 0
        }
    }

    
    pub fn test_zte_sscanf_s_empty_string() {
        unsafe {
            let s = CString::new("").unwrap();
            let format = CString::new("%d").unwrap();
            let mut size_array: rruinfo_mod::rsize_t = 10;
            let result = rruinfo_mod::zte_sscanf_s(
                s.as_ptr(),
                format.as_ptr(),
                &mut size_array,
            );
            assert_eq!(result, 0);
            assert_eq!(size_array, 0);
        }
    }

    
    pub fn test_zte_sscanf_s_empty_format() {
        unsafe {
            let s = CString::new("123").unwrap();
            let format = CString::new("").unwrap();
            let mut size_array: rruinfo_mod::rsize_t = 10;
            let result = rruinfo_mod::zte_sscanf_s(
                s.as_ptr(),
                format.as_ptr(),
                &mut size_array,
            );
            assert_eq!(result, 0);
            assert_eq!(size_array, 0);
        }
    }

    
    pub fn test_zte_sscanf_s_different_formats() {
        unsafe {
            let s = CString::new("123").unwrap();
            let mut size_array: rruinfo_mod::rsize_t = 10;
            
            // 测试不同的格式字符串
            let formats = vec![
                "%d", "%u", "%x", "%s", "%f", "%%", "%d %d", "%s %d",
            ];
            
            for format_str in formats {
                let format = CString::new(format_str).unwrap();
                let result = rruinfo_mod::zte_sscanf_s(
                    s.as_ptr(),
                    format.as_ptr(),
                    &mut size_array,
                );
                assert_eq!(result, 0); // 打桩实现总是返回 0
                assert_eq!(size_array, 0);
            }
        }
    }

    
    pub fn test_zte_sscanf_s_size_array_initialized() {
        unsafe {
            let s = CString::new("123").unwrap();
            let format = CString::new("%d").unwrap();
            let mut size_array: rruinfo_mod::rsize_t = 100; // 初始化为非零值
            let result = rruinfo_mod::zte_sscanf_s(
                s.as_ptr(),
                format.as_ptr(),
                &mut size_array,
            );
            assert_eq!(result, 0);
            // 验证 size_array 被设置为 0
            assert_eq!(size_array, 0);
        }
    }

    
    pub fn test_zte_sscanf_s_multiple_calls() {
        unsafe {
            let s = CString::new("123 456").unwrap();
            let format = CString::new("%d %d").unwrap();
            let mut size_array: rruinfo_mod::rsize_t = 10;
            
            // 多次调用，验证每次都能正常工作
            for _ in 0..5 {
                let result = rruinfo_mod::zte_sscanf_s(
                    s.as_ptr(),
                    format.as_ptr(),
                    &mut size_array,
                );
                assert_eq!(result, 0);
                assert_eq!(size_array, 0);
            }
        }
    }

    
    pub fn test_zte_sscanf_s_long_string() {
        unsafe {
            let long_str = "a".repeat(1000);
            let s = CString::new(long_str).unwrap();
            let format = CString::new("%s").unwrap();
            let mut size_array: rruinfo_mod::rsize_t = 10;
            let result = rruinfo_mod::zte_sscanf_s(
                s.as_ptr(),
                format.as_ptr(),
                &mut size_array,
            );
            assert_eq!(result, 0);
            assert_eq!(size_array, 0);
        }
    }

    
    pub fn test_zte_sscanf_s_special_characters() {
        unsafe {
            let test_cases = vec![
                "hello world",
                "123\t456",
                "test\nline",
                "path/to/file",
                "key=value",
                "a+b=c",
                "test@example.com",
            ];
            
            for test_str in test_cases {
                let s = CString::new(test_str).unwrap();
                let format = CString::new("%s").unwrap();
                let mut size_array: rruinfo_mod::rsize_t = 10;
                let result = rruinfo_mod::zte_sscanf_s(
                    s.as_ptr(),
                    format.as_ptr(),
                    &mut size_array,
                );
                assert_eq!(result, 0);
                assert_eq!(size_array, 0);
            }
        }
    }

    
    pub fn test_zte_sscanf_s_null_terminated() {
        unsafe {
            // 测试确保函数正确处理以 null 结尾的字符串
            // CString 不能包含 null 字节，所以使用字节数组
            let bytes = b"test\0more\0";
            let s = bytes.as_ptr() as *const libc::c_char;
            let format = CString::new("%s").unwrap();
            let mut size_array: rruinfo_mod::rsize_t = 10;
            let result = rruinfo_mod::zte_sscanf_s(
                s,
                format.as_ptr(),
                &mut size_array,
            );
            assert_eq!(result, 0);
            assert_eq!(size_array, 0);
        }
    }

    
    pub fn test_zte_sscanf_s_integration() {
        unsafe {
            // 集成测试：测试函数在不同场景下的行为
            let test_cases = vec![
                ("123", "%d"),
                ("456", "%u"),
                ("FF", "%x"),
                ("hello", "%s"),
                ("123.45", "%f"),
            ];
            
            for (input, fmt) in test_cases {
                let s = CString::new(input).unwrap();
                let format = CString::new(fmt).unwrap();
                let mut size_array: rruinfo_mod::rsize_t = 10;
                let result = rruinfo_mod::zte_sscanf_s(
                    s.as_ptr(),
                    format.as_ptr(),
                    &mut size_array,
                );
                assert_eq!(result, 0);
                assert_eq!(size_array, 0);
            }
        }
    }
}
use std::process;
#[test]
fn capture_all_coverage() {
    // ... 务必在此处调用所有你移到 `all_tests` 模块下的函数 ...
    all_tests::test_fclose_null_ptr();
    all_tests::test_fclose_valid_ptr();
    all_tests::test_xstat_null_stat_buf();
    all_tests::test_xstat_valid_args();
    all_tests::test_strnlen_s_null_ptr();
    all_tests::test_strnlen_s_zero_maxsize();
    all_tests::test_strnlen_s_negative_maxsize();
    all_tests::test_strnlen_s_normal_string();
    all_tests::test_strnlen_s_empty_string();
    all_tests::test_strnlen_s_truncated();
    all_tests::test_strncpy_s_null_s1();
    all_tests::test_strncpy_s_null_s2();
    all_tests::test_strncpy_s_zero_s1max();
    all_tests::test_strncpy_s_normal_copy();
    all_tests::test_strncpy_s_negative_n();
    all_tests::test_strncpy_s_truncated();
    all_tests::test_strncpy_s_empty_string();
    all_tests::test_fopen_s_null_streamptr();
    all_tests::test_fopen_s_valid_args();
    all_tests::test_config_get_key_ex_null_buf();
    all_tests::test_config_get_key_ex_zero_buflen();
    all_tests::test_config_get_key_ex_valid_args();
    all_tests::test_config_set_key();
    all_tests::test_bsp_system_null_ptr();
    all_tests::test_bsp_system_valid_command();
    all_tests::test_bsp_atoi_null_ptr();
    all_tests::test_bsp_atoi_decimal();
    all_tests::test_bsp_atoi_hexadecimal();
    all_tests::test_bsp_atoi_octal();
    all_tests::test_bsp_atoi_base_zero_hex();
    all_tests::test_bsp_atoi_base_zero_octal();
    all_tests::test_bsp_atoi_base_zero_decimal();
    all_tests::test_bsp_atoi_invalid_base();
    all_tests::test_bsp_atoi_invalid_string();
    all_tests::test_bsp_atoi_negative();
    all_tests::test_bsp_atoi_zero();
    all_tests::test_bsp_atoi_empty_string();
    all_tests::test_create_prever_dir();
    all_tests::test_bsp_get_plus_and_play_enable();
    all_tests::test_bsp_get_plus_and_play_ver_restrict_null_ptr();
    all_tests::test_bsp_get_plus_and_play_ver_restrict_valid_ptr();
    all_tests::test_bsp_get_plus_and_play_ver_restrict_with_quotes();
    all_tests::test_bsp_get_plus_and_play_swid_null_ptr();
    all_tests::test_bsp_get_plus_and_play_swid_valid_ptr();
    all_tests::test_bsp_set_plus_and_play_swid();
    all_tests::test_bsp_set_plus_and_play_swid_failure();
    all_tests::test_bsp_get_prever_fpga_path_null_new_fpga_path();
    all_tests::test_bsp_get_prever_fpga_path_null_alarm();
    all_tests::test_bsp_get_prever_fpga_path_enable_not_one();
    all_tests::test_bsp_get_prever_fpga_path_swid_equal();
    all_tests::test_bsp_back_up_fpga_swv_null_path();
    all_tests::test_bsp_back_up_fpga_swv_valid_path();
    all_tests::test_bsp_set_and_get_fpga_ver_compar_flag();
    all_tests::test_bsp_set_fpga_ver_compar_flag_zero();
    all_tests::test_bsp_set_fpga_ver_compar_flag_max();
    all_tests::test_bsp_get_and_set_fpga_ver_soft_type();
    all_tests::test_bsp_set_fpga_ver_soft_type_zero();
    all_tests::test_bsp_set_fpga_ver_soft_type_max();
    all_tests::test_plug_and_play_workflow();
    all_tests::test_fpga_version_management();
    all_tests::test_string_operations_chain();
    all_tests::test_config_operations();
    all_tests::test_zte_sscanf_s_null_s();
    all_tests::test_zte_sscanf_s_null_format();
    all_tests::test_zte_sscanf_s_both_null();
    all_tests::test_zte_sscanf_s_null_size_array();
    all_tests::test_zte_sscanf_s_valid_args_with_size_array();
    all_tests::test_zte_sscanf_s_empty_string();
    all_tests::test_zte_sscanf_s_empty_format();
    all_tests::test_zte_sscanf_s_different_formats();
    all_tests::test_zte_sscanf_s_size_array_initialized();
    all_tests::test_zte_sscanf_s_multiple_calls();
    all_tests::test_zte_sscanf_s_long_string();
    all_tests::test_zte_sscanf_s_special_characters();
    all_tests::test_zte_sscanf_s_null_terminated();
    all_tests::test_zte_sscanf_s_integration();
    // 重要：在所有测试代码执行完毕后，捕获覆盖率数据
    let mut coverage_data = Vec::new();
    unsafe {
        // 这是使 .profraw 文件有内容的关键调用
        let _ = minicov::capture_coverage(&mut coverage_data);
    }

    // 将数据写入文件。文件名可以自定义，如 `integration.profraw`
    let output_file = "./test_coverage_final.profraw";
    if let Err(e) = fs::write(output_file, coverage_data) {
        panic!("Failed to write coverage file: {}", e);
    }
    println!("✅ 覆盖率数据已成功写入: {}", output_file);
}
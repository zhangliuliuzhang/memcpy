#![allow(
    dead_code,
    mutable_transmutes,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    unused_assignments,
    unused_mut
)]
#![allow(unsafe_op_in_unsafe_fn)]
use ccommon::clib::*;

pub type __builtin_va_list = [__va_list_tag; 1];
#[derive(Copy, Clone)]
#[repr(C)]
pub struct __va_list_tag {
    pub gp_offset: libc::c_uint,
    pub fp_offset: libc::c_uint,
    pub overflow_arg_area: *mut libc::c_void,
    pub reg_save_area: *mut libc::c_void,
}
pub type size_t = libc::c_ulong;
pub type va_list = __builtin_va_list;
pub type __dev_t = libc::c_ulong;
pub type __uid_t = libc::c_uint;
pub type __gid_t = libc::c_uint;
pub type __ino_t = libc::c_ulong;
pub type __mode_t = libc::c_uint;
pub type __nlink_t = libc::c_ulong;
pub type __off_t = libc::c_long;
pub type __off64_t = libc::c_long;
pub type __time_t = libc::c_long;
pub type __clockid_t = libc::c_int;
pub type __blksize_t = libc::c_long;
pub type __blkcnt_t = libc::c_long;
pub type __syscall_slong_t = libc::c_long;
pub type _IO_lock_t = ();
pub type FILE = _IO_FILE;
pub type clockid_t = __clockid_t;
pub type time_t = __time_t;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct timespec {
    pub tv_sec: __time_t,
    pub tv_nsec: __syscall_slong_t,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct tm {
    pub tm_sec: libc::c_int,
    pub tm_min: libc::c_int,
    pub tm_hour: libc::c_int,
    pub tm_mday: libc::c_int,
    pub tm_mon: libc::c_int,
    pub tm_year: libc::c_int,
    pub tm_wday: libc::c_int,
    pub tm_yday: libc::c_int,
    pub tm_isdst: libc::c_int,
    pub tm_gmtoff: libc::c_long,
    pub tm_zone: *const libc::c_char,
}
pub type __u16 = libc::c_ushort;
pub type __u32 = libc::c_uint;
pub type __kernel_long_t = libc::c_long;
pub type __kernel_ulong_t = libc::c_ulong;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct sysinfo {
    pub uptime: __kernel_long_t,
    pub loads: [__kernel_ulong_t; 3],
    pub totalram: __kernel_ulong_t,
    pub freeram: __kernel_ulong_t,
    pub sharedram: __kernel_ulong_t,
    pub bufferram: __kernel_ulong_t,
    pub totalswap: __kernel_ulong_t,
    pub freeswap: __kernel_ulong_t,
    pub procs: __u16,
    pub pad: __u16,
    pub totalhigh: __kernel_ulong_t,
    pub freehigh: __kernel_ulong_t,
    pub mem_unit: __u32,
    pub _f: [libc::c_char; 0],
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct stat {
    pub st_dev: __dev_t,
    pub st_ino: __ino_t,
    pub st_nlink: __nlink_t,
    pub st_mode: __mode_t,
    pub st_uid: __uid_t,
    pub st_gid: __gid_t,
    pub __pad0: libc::c_int,
    pub st_rdev: __dev_t,
    pub st_size: __off_t,
    pub st_blksize: __blksize_t,
    pub st_blocks: __blkcnt_t,
    pub st_atim: timespec,
    pub st_mtim: timespec,
    pub st_ctim: timespec,
    pub __glibc_reserved: [__syscall_slong_t; 3],
}
pub type UCHAR = libc::c_uchar;
pub type CHAR = libc::c_char;
pub type BYTE = libc::c_uchar;
pub type ULONG = libc::c_uint;
pub type UINT32 = libc::c_uint;
pub type INT = libc::c_int;
pub type INT32 = libc::c_int;
pub type LONG = libc::c_long;
pub type STATUS = libc::c_uint;
pub type rsize_t = size_t;
pub type errno_t = libc::c_int;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct tagT_RruCfgItem {
    pub acFieldName: [CHAR; 30],
    pub cFieldFlag: CHAR,
    pub cFieldValue: CHAR,
    pub cFieldEnd: CHAR,
}
pub type T_Bsp_RruIniCfgItem = tagT_RruCfgItem;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct T_CtrlVerErrReason {
    pub ucRunVer: UCHAR,
    pub ucMasterVerErr: UCHAR,
    pub ucSlaveVerErr: UCHAR,
    pub ucBinDefaultVerErr: UCHAR,
    pub ucBakDefaultVerErr: UCHAR,
    pub ucAckVerErr: UCHAR,
    pub ucProtectVerErr: UCHAR,
    pub ucReserve: [UCHAR; 5],
    pub ulMarkVal: UINT32,
}
pub type T_CpuErrReason = T_CtrlVerErrReason;
pub type BSP_SYSTEM_CALLBACK = Option::<unsafe extern "C" fn(*const CHAR) -> INT>;
pub type C2RustUnnamed = libc::c_uint;
pub const FLASH_PARA_MAX: C2RustUnnamed = 2;
pub const FLASH_PARA_NOR: C2RustUnnamed = 1;
pub const FLASH_PARA_NOR_NAND: C2RustUnnamed = 0;
#[unsafe(no_mangle)]
pub static mut s_pfSystem: BSP_SYSTEM_CALLBACK = unsafe {
    // 延迟初始化：在第一次使用时设置，避免在模块加载时调用 system 函数
    // 使用 None 作为初始值，在 BspInstallSystemCallBack 或首次使用时设置
    None
};
//#[no_mangle]
pub static mut ulPrnSet: UINT32 = 0 as libc::c_int as UINT32;
//#[no_mangle]
pub static mut PaVoltAdjustType: UINT32 = 0 as libc::c_int as UINT32;
static mut s_rpuId: UINT32 = 0 as libc::c_int as UINT32;
static mut s_FlashParaSel: UINT32 = FLASH_PARA_NOR_NAND as libc::c_int as UINT32;

// 辅助函数：将 Rust 格式化字符串复制到 C 字符串缓冲区
// 参数：buf - 目标缓冲区，buf_size - 缓冲区大小，formatted_str - 已格式化的 Rust 字符串
unsafe fn copy_formatted_to_cstr(
    buf: *mut libc::c_char,
    buf_size: rsize_t,
    formatted_str: &str,
) -> libc::c_int {
    if buf.is_null() || buf_size == 0 {
        return -1;
    }
    
    let max_len = buf_size as usize;
    if formatted_str.len() >= max_len {
        return -1;
    }
    
    // 将格式化后的字符串复制到 C 字符串缓冲区
    match std::ffi::CString::new(formatted_str) {
        Ok(c_str) => {
            let src_bytes = c_str.as_bytes_with_nul();
            let copy_len = if src_bytes.len() > max_len { max_len } else { src_bytes.len() };
            std::ptr::copy_nonoverlapping(
                src_bytes.as_ptr(),
                buf as *mut u8,
                copy_len,
            );
            (copy_len - 1) as libc::c_int
        }
        Err(_) => -1,
    }
}

//#[no_mangle]
pub unsafe extern "C" fn BspGetIsrStackSize() -> UINT32 {
    return 5000 as libc::c_int as UINT32;
}
//#[no_mangle]
pub unsafe extern "C" fn ncstrncmp(
    mut src: *const CHAR,
    mut dst: *const CHAR,
    mut len: size_t,
) -> LONG {
    let mut ret: LONG = 0 as libc::c_int as LONG;
    loop {
        ret = (tolower(*(src as *mut UCHAR) as libc::c_int)
            - tolower(*(dst as *mut UCHAR) as libc::c_int)) as LONG;
        if !(ret == 0 && *dst as libc::c_int != 0
            && len > 0 as libc::c_int as libc::c_ulong)
        {
            break;
        }
        src = src.offset(1);
        src;
        dst = dst.offset(1);
        dst;
        len = len.wrapping_sub(1);
        len;
    }
    return if len > 0 as libc::c_int as libc::c_ulong {
        ret
    } else {
        0 as libc::c_int as libc::c_long
    };
}
//#[no_mangle]
pub unsafe extern "C" fn BspGetFileLen(mut ucFileName: *const libc::c_char) -> UINT32 {
    let mut tStatInfo: ccommon::clib::stat = ccommon::clib::stat {
        st_dev: 0,
        st_ino: 0,
        st_nlink: 0,
        st_mode: 0,
        st_uid: 0,
        st_gid: 0,
        __pad0: 0,
        st_rdev: 0,
        st_size: 0,
        st_blksize: 0,
        st_blocks: 0,
        st_atim: ccommon::clib::timespec { tv_sec: 0, tv_nsec: 0 },
        st_mtim: ccommon::clib::timespec { tv_sec: 0, tv_nsec: 0 },
        st_ctim: ccommon::clib::timespec { tv_sec: 0, tv_nsec: 0 },
        __glibc_reserved: [0; 3],
    };
    if ucFileName.is_null() {
        return 0xff000002 as libc::c_uint;
    }
    if -(1 as libc::c_int) == stat(ucFileName, &mut tStatInfo as *mut ccommon::clib::stat) {
        return 0xffffffff as libc::c_uint
    } else {
        return tStatInfo.st_size as UINT32
    };
}
//#[no_mangle]
pub unsafe extern "C" fn BspCreateFile(mut pszFileName: *mut CHAR) -> UINT32 {
    let mut fd: *mut FILE = 0 as *mut FILE;
    let mut tStatInfo: ccommon::clib::stat = ccommon::clib::stat {
        st_dev: 0,
        st_ino: 0,
        st_nlink: 0,
        st_mode: 0,
        st_uid: 0,
        st_gid: 0,
        __pad0: 0,
        st_rdev: 0,
        st_size: 0,
        st_blksize: 0,
        st_blocks: 0,
        st_atim: ccommon::clib::timespec { tv_sec: 0, tv_nsec: 0 },
        st_mtim: ccommon::clib::timespec { tv_sec: 0, tv_nsec: 0 },
        st_ctim: ccommon::clib::timespec { tv_sec: 0, tv_nsec: 0 },
        __glibc_reserved: [0; 3],
    };
    let mut iTmpRet: INT32 = 0 as libc::c_int;
    if pszFileName.is_null() {
        return (((0x8000 as libc::c_int + 0 as libc::c_int) << 16 as libc::c_int)
            + ((0xe as libc::c_int) << 8 as libc::c_int) + 0x1 as libc::c_int) as UINT32;
    }
    if 0 as libc::c_int == stat(pszFileName, &mut tStatInfo as *mut ccommon::clib::stat) {
        return 0 as libc::c_int as UINT32
    } else {
        fd = fopen(pszFileName, b"w+b\0" as *const u8 as *const libc::c_char);
        if fd.is_null() {
            // 使用 Rust 的 eprintln! 替换 mzprnL
            eprintln!("bspcommon");
            return (((0x8000 as libc::c_int + 0 as libc::c_int) << 16 as libc::c_int)
                + ((0xe as libc::c_int) << 8 as libc::c_int) + 0x1 as libc::c_int)
                as UINT32;
        }
        iTmpRet = fclose(fd);
        if iTmpRet != 0 as libc::c_int {
            // 使用 Rust 的 eprintln! 替换 mzprnL
            eprintln!("bspcommon");
        }
    }
    return 0 as libc::c_int as UINT32;
}
//#[no_mangle]
pub unsafe extern "C" fn BspWriteFile(
    mut buf: *const libc::c_char,
    mut len: UINT32,
    mut filename: *const libc::c_char,
) -> UINT32 {
    let mut fd: *mut FILE = 0 as *mut FILE;
    let mut iret: libc::c_int = 0 as libc::c_int;
    let mut iTmpRet: INT32 = 0 as libc::c_int;
    fd = fopen(filename, b"w+b\0" as *const u8 as *const libc::c_char);
    if fd.is_null() {
        // 使用 Rust 的 format! 宏替换 zte_printf_s
        let func_name = "BspWriteFile";
        let filename_str = std::ffi::CStr::from_ptr(filename).to_string_lossy();
        eprintln!("{}>>File[{}] Create Error!", func_name, filename_str);
        return -(1 as libc::c_int) as UINT32;
    }
    iret = fwrite(
        buf as *const libc::c_void,
        1 as libc::c_int as libc::c_ulong,
        len as libc::c_ulong,
        fd,
    ) as libc::c_int;
    if iret as libc::c_uint != len {
        iTmpRet = fclose(fd);
        if iTmpRet != 0 as libc::c_int {
        // 使用 Rust 的 eprintln! 替换 mzprnL
        eprintln!("bspcommon");
        }
        // 使用 Rust 的 format! 宏替换 zte_printf_s
        let func_name = "BspWriteFile";
        let filename_str = std::ffi::CStr::from_ptr(filename).to_string_lossy();
        eprintln!("{}>>File[{}] Write Error!", func_name, filename_str);
        return -(1 as libc::c_int) as UINT32;
    } else {
        // 使用 Rust 的 format! 宏替换 zte_printf_s
        let func_name = "BspWriteFile";
        let filename_str = std::ffi::CStr::from_ptr(filename).to_string_lossy();
        eprintln!("{}>>File[{}] Create Succ!", func_name, filename_str);
    }
    iTmpRet = fclose(fd);
    if iTmpRet != 0 as libc::c_int {
        // 使用 Rust 的 eprintln! 替换 mzprnL
        eprintln!("bspcommon");
    }
    return 0 as libc::c_int as UINT32;
}
//#[no_mangle]
pub unsafe extern "C" fn BspLoadFile(
    mut ucFileName: *const libc::c_char,
    mut pucBuf: *mut CHAR,
    mut ptDataLen: *mut UINT32,
) -> UINT32 {
    let mut readLen: INT32 = 0 as libc::c_int;
    let mut fd: *mut FILE = 0 as *mut FILE;
    let mut tStatInfo: ccommon::clib::stat = ccommon::clib::stat {
        st_dev: 0,
        st_ino: 0,
        st_nlink: 0,
        st_mode: 0,
        st_uid: 0,
        st_gid: 0,
        __pad0: 0,
        st_rdev: 0,
        st_size: 0,
        st_blksize: 0,
        st_blocks: 0,
        st_atim: ccommon::clib::timespec { tv_sec: 0, tv_nsec: 0 },
        st_mtim: ccommon::clib::timespec { tv_sec: 0, tv_nsec: 0 },
        st_ctim: ccommon::clib::timespec { tv_sec: 0, tv_nsec: 0 },
        __glibc_reserved: [0; 3],
    };
    let mut iTmpRet: INT32 = 0 as libc::c_int;
    println!("BspLoadFile");
    if ucFileName.is_null() || pucBuf.is_null() || ptDataLen.is_null() {
        // 使用 Rust 的 eprintln! 替换 mzprnL
        eprintln!("bspcommon");
        println!("BspLoadFile");
        return 0xff000002 as libc::c_uint;
    }
    *ptDataLen = 0 as libc::c_int as UINT32;
    fd = fopen(ucFileName, b"rb\0" as *const u8 as *const libc::c_char);
    println!("BspLoadFile");
    if fd.is_null() {
        // 使用 Rust 的 eprintln! 替换 mzprnL
        eprintln!("bspcommon");
        return (((0x8000 as libc::c_int + 0 as libc::c_int) << 16 as libc::c_int)
            + ((0xe as libc::c_int) << 8 as libc::c_int) + 0x1 as libc::c_int) as UINT32;
    }
    if -(1 as libc::c_int) == stat(ucFileName, &mut tStatInfo as *mut ccommon::clib::stat) {
        iTmpRet = fclose(fd);
        if iTmpRet != 0 as libc::c_int {
        // 使用 Rust 的 eprintln! 替换 mzprnL
        eprintln!("bspcommon");
        }
        // 使用 Rust 的 eprintln! 替换 mzprnL
        eprintln!("bspcommon");
        return (((0x8000 as libc::c_int + 0 as libc::c_int) << 16 as libc::c_int)
            + ((0xe as libc::c_int) << 8 as libc::c_int) + 0x1 as libc::c_int) as UINT32;
    }
    readLen = fread(
        pucBuf as *mut libc::c_void,
        tStatInfo.st_size as UINT32 as libc::c_ulong,
        1 as libc::c_int as libc::c_ulong,
        fd,
    ) as INT32;
    if readLen != 1 as libc::c_int {
        iTmpRet = fclose(fd);
        if iTmpRet != 0 as libc::c_int {
            // 使用 Rust 的 eprintln! 替换 mzprnL
            eprintln!("bspcommon");
        }
        // 使用 Rust 的 eprintln! 替换 mzprnL
        eprintln!("bspcommon");
        return 0xffffffff as libc::c_uint;
    }
    iTmpRet = fclose(fd);
    if iTmpRet != 0 as libc::c_int {
        // 使用 Rust 的 eprintln! 替换 mzprnL
        eprintln!("bspcommon");
    }
    *ptDataLen = tStatInfo.st_size as UINT32;
    return 0 as libc::c_int as UINT32;
}
//#[no_mangle]
pub unsafe extern "C" fn BspLoadFileNew(
    mut ucFileName: *const libc::c_char,
    mut pucBuf: *mut CHAR,
    mut ulOffset: UINT32,
    mut ulDataLen: UINT32,
) -> UINT32 {
    let mut iTmpRet: INT32 = 0 as libc::c_int;
    let mut iReadLen: INT32 = 0 as libc::c_int;
    let mut tStatInfo: ccommon::clib::stat = ccommon::clib::stat {
        st_dev: 0,
        st_ino: 0,
        st_nlink: 0,
        st_mode: 0,
        st_uid: 0,
        st_gid: 0,
        __pad0: 0,
        st_rdev: 0,
        st_size: 0,
        st_blksize: 0,
        st_blocks: 0,
        st_atim: ccommon::clib::timespec { tv_sec: 0, tv_nsec: 0 },
        st_mtim: ccommon::clib::timespec { tv_sec: 0, tv_nsec: 0 },
        st_ctim: ccommon::clib::timespec { tv_sec: 0, tv_nsec: 0 },
        __glibc_reserved: [0; 3],
    };
    let mut fd: *mut FILE = 0 as *mut FILE;
    if ucFileName.is_null() || pucBuf.is_null() {
        return 0xff000002 as libc::c_uint;
    }
    if 0 as libc::c_int as libc::c_uint == ulDataLen {
        return 0xff000001 as libc::c_uint;
    }
    iTmpRet = fopen_s(&mut fd, ucFileName, b"rb\0" as *const u8 as *const libc::c_char);
    if iTmpRet != 0 as libc::c_int {
        // 使用 Rust 的 eprintln! 替换 mzprnL
        eprintln!("bspcommon");
    }
    if fd.is_null() {
        // 使用 Rust 的 eprintln! 替换 mzprnL
        eprintln!("bspcommon");
        return (((0x8000 as libc::c_int + 0 as libc::c_int) << 16 as libc::c_int)
            + ((0xe as libc::c_int) << 8 as libc::c_int) + 0x1 as libc::c_int) as UINT32;
    }
    if -(1 as libc::c_int) == stat(ucFileName, &mut tStatInfo as *mut ccommon::clib::stat) {
        // 使用 Rust 的 eprintln! 替换 mzprnL
        eprintln!("bspcommon");
        iTmpRet = fclose(fd);
        if iTmpRet != 0 as libc::c_int {
        // 使用 Rust 的 eprintln! 替换 mzprnL
        eprintln!("bspcommon");
        }
        return (((0x8000 as libc::c_int + 0 as libc::c_int) << 16 as libc::c_int)
            + ((0xe as libc::c_int) << 8 as libc::c_int) + 0x1 as libc::c_int) as UINT32;
    }
    if fseek(fd, ulOffset as libc::c_long, 0 as libc::c_int) != 0 as libc::c_int {
        // 使用 Rust 的 eprintln! 替换 mzprnL
        eprintln!("bspcommon");
        iTmpRet = fclose(fd);
        if iTmpRet != 0 as libc::c_int {
        // 使用 Rust 的 eprintln! 替换 mzprnL
        eprintln!("bspcommon");
        }
        return 0xffffffff as libc::c_uint;
    }
    iReadLen = fread(
        pucBuf as *mut libc::c_void,
        ulDataLen as libc::c_ulong,
        1 as libc::c_int as libc::c_ulong,
        fd,
    ) as INT32;
    if iReadLen != 1 as libc::c_int {
        iTmpRet = fclose(fd);
        if iTmpRet != 0 as libc::c_int {
        // 使用 Rust 的 eprintln! 替换 mzprnL
        eprintln!("bspcommon");
        }
        return 0xffffffff as libc::c_uint;
    }
    iTmpRet = fclose(fd);
    if iTmpRet != 0 as libc::c_int {
        // 使用 Rust 的 eprintln! 替换 mzprnL
        eprintln!("bspcommon");
    }
    return 0 as libc::c_int as UINT32;
}
//#[no_mangle]
pub unsafe extern "C" fn ChipToNs(
    mut ulSourceData: UINT32,
    mut ulUnit: UINT32,
) -> UINT32 {
    let mut ulNsVal: UINT32 = 0 as libc::c_int as UINT32;
    match ulUnit {
        0 => {
            ulNsVal = floor(
                ulSourceData.wrapping_mul(1000 as libc::c_int as libc::c_uint)
                    as libc::c_double / 3.84f64,
            ) as UINT32;
        }
        1 => {
            ulNsVal = floor(
                ulSourceData.wrapping_mul(1000 as libc::c_int as libc::c_uint)
                    as libc::c_double / 61.44f64,
            ) as UINT32;
        }
        2 => {
            ulNsVal = floor(
                ulSourceData.wrapping_mul(1000 as libc::c_int as libc::c_uint)
                    as libc::c_double / 122.88f64,
            ) as UINT32;
        }
        3 => {
            ulNsVal = floor(
                ulSourceData.wrapping_mul(1000 as libc::c_int as libc::c_uint)
                    as libc::c_double / 153.60f64,
            ) as UINT32;
        }
        4 => {
            ulNsVal = floor(
                ulSourceData.wrapping_mul(1000 as libc::c_int as libc::c_uint)
                    as libc::c_double / 245.76f64,
            ) as UINT32;
        }
        5 => {
            ulNsVal = floor(
                ulSourceData.wrapping_mul(1000 as libc::c_int as libc::c_uint)
                    as libc::c_double / 46.08f64,
            ) as UINT32;
        }
        _ => {
        // 使用 Rust 的 eprintln! 替换 mzprnL
        eprintln!("bspcommon");
        }
    }
    return ulNsVal;
}
//#[no_mangle]
pub unsafe extern "C" fn NsToChip(
    mut ulSourceData: UINT32,
    mut ulUnit: UINT32,
) -> UINT32 {
    let mut ulChipVal: UINT32 = 0 as libc::c_int as UINT32;
    match ulUnit {
        0 => {
            ulChipVal = floor(
                ulSourceData as libc::c_double * 3.84f64 / 1000.0f64 + 0.5f64,
            ) as UINT32;
        }
        1 => {
            ulChipVal = floor(
                ulSourceData as libc::c_double * 61.44f64 / 1000.0f64 + 0.5f64,
            ) as UINT32;
        }
        2 => {
            ulChipVal = floor(
                ulSourceData as libc::c_double * 122.88f64 / 1000.0f64 + 0.5f64,
            ) as UINT32;
        }
        3 => {
            ulChipVal = floor(
                ulSourceData as libc::c_double * 153.60f64 / 1000.0f64 + 0.5f64,
            ) as UINT32;
        }
        4 => {
            ulChipVal = floor(
                ulSourceData as libc::c_double * 46.08f64 / 1000.0f64 + 0.5f64,
            ) as UINT32;
        }
        _ => {
        // 使用 Rust 的 eprintln! 替换 mzprnL
        eprintln!("bspcommon");
        }
    }
    return ulChipVal;
}
//#[no_mangle]
pub unsafe extern "C" fn NsToChipFloor(
    mut ulSourceData: UINT32,
    mut ulUnit: UINT32,
) -> UINT32 {
    let mut ulChipVal: UINT32 = 0 as libc::c_int as UINT32;
    match ulUnit {
        0 => {
            ulChipVal = floor(ulSourceData as libc::c_double * 3.84f64 / 1000.0f64)
                as UINT32;
        }
        1 => {
            ulChipVal = floor(ulSourceData as libc::c_double * 61.44f64 / 1000.0f64)
                as UINT32;
        }
        2 => {
            ulChipVal = floor(ulSourceData as libc::c_double * 122.88f64 / 1000.0f64)
                as UINT32;
        }
        3 => {
            ulChipVal = floor(ulSourceData as libc::c_double * 153.60f64 / 1000.0f64)
                as UINT32;
        }
        _ => {
        // 使用 Rust 的 eprintln! 替换 mzprnL
        eprintln!("bspcommon");
        }
    }
    return ulChipVal;
}
//#[no_mangle]
pub unsafe extern "C" fn BrdVerStatusTest(mut ulCpuFpga: UINT32) -> UINT32 {
    let mut ulRet: UINT32 = 0 as libc::c_int as UINT32;
    let mut ulCode: UINT32 = 0 as libc::c_int as UINT32;
    let mut tVerErrReason: ccommon::clib::T_CtrlVerErrReason = {
        let mut init = ccommon::clib::T_CtrlVerErrReason {
            ucRunVer: 0 as libc::c_int as UCHAR,
            ucMasterVerErr: 0,
            ucSlaveVerErr: 0,
            ucBinDefaultVerErr: 0,
            ucBakDefaultVerErr: 0,
            ucAckVerErr: 0,
            ucProtectVerErr: 0,
            ucReserve: [0; 5],
            ulMarkVal: 0,
        };
        init
    };
    let mut caCpuSoftVer: [CHAR; 50] = [
        0 as libc::c_int as CHAR,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
    ];
    let mut ucSizeofBytes: UCHAR = 50 as libc::c_int as UCHAR;
    encapsulationOfZte_memset_s(
        caCpuSoftVer.as_mut_ptr() as *mut libc::c_void,
        ucSizeofBytes as rsize_t,
        0 as libc::c_int,
        ucSizeofBytes as rsize_t,
        b"/ErrLog.csv.c\0"
            as *const u8 as *const libc::c_char,
        576 as libc::c_int,
    );
    encapsulationOfZte_memset_s(
        &mut tVerErrReason as *mut ccommon::clib::T_CtrlVerErrReason as *mut BYTE as *mut libc::c_void,
        ::core::mem::size_of::<ccommon::clib::T_CtrlVerErrReason>() as libc::c_ulong,
        0 as libc::c_int,
        ::core::mem::size_of::<ccommon::clib::T_CtrlVerErrReason>() as libc::c_ulong,
        b"/ErrLog.csv.c\0"
            as *const u8 as *const libc::c_char,
        577 as libc::c_int,
    );
    if 0 as libc::c_int as libc::c_uint == ulCpuFpga {
        ulCode = BspGetCpuVerErrReason(&mut tVerErrReason);
        BspGetFpgaSoftVersion(caCpuSoftVer.as_mut_ptr(), ucSizeofBytes);
    } else {
        BspGetFpgaSoftVersion(caCpuSoftVer.as_mut_ptr(), ucSizeofBytes);
        ulCode = BspGetFpgaVerErrReason(&mut tVerErrReason);
    }
    if 0 as libc::c_int as UINT32 == ulCode {
        if 0 as libc::c_int == tVerErrReason.ucRunVer as libc::c_int {
            ulRet = 0 as libc::c_int as UINT32;
            if 0 as libc::c_int != tVerErrReason.ucMasterVerErr as libc::c_int {
                ulRet = (ulRet as libc::c_uint)
                    .wrapping_add(1 as libc::c_int as libc::c_uint) as UINT32 as UINT32;
            }
        } else if 0x4 as libc::c_int == tVerErrReason.ucRunVer as libc::c_int {
            ulRet = 2 as libc::c_int as UINT32;
            if 0 as libc::c_int != tVerErrReason.ucAckVerErr as libc::c_int {
                ulRet = (ulRet as libc::c_uint)
                    .wrapping_add(1 as libc::c_int as libc::c_uint) as UINT32 as UINT32;
            }
        } else if 0x5 as libc::c_int == tVerErrReason.ucRunVer as libc::c_int {
            ulRet = 4 as libc::c_int as UINT32;
            if 0 as libc::c_int != tVerErrReason.ucProtectVerErr as libc::c_int {
                ulRet = (ulRet as libc::c_uint)
                    .wrapping_add(1 as libc::c_int as libc::c_uint) as UINT32 as UINT32;
            }
        } else {
            ulRet = 6 as libc::c_int as UINT32;
        }
        // 使用 Rust 的 eprintln! 替换 mzprnL
        eprintln!("bspcommon");
    } else {
        // 使用 Rust 的 eprintln! 替换 mzprnL
        eprintln!("bspcommon");
        ulRet = 6 as libc::c_int as UINT32;
    }
    return ulRet;
}
//#[no_mangle]
pub unsafe extern "C" fn BspInstallSystemCallBack(
    mut pfSystem: BSP_SYSTEM_CALLBACK,
) -> UINT32 {
    if pfSystem.is_some() {
        s_pfSystem = pfSystem;
        return 0 as libc::c_int as UINT32;
    } else {
        return 0xffffffff as libc::c_uint
    };
}
//#[no_mangle]
pub unsafe extern "C" fn BspSystem(mut pcCommand: *const CHAR) -> INT {
    return s_pfSystem.expect("non-null function pointer")(pcCommand);
}
//#[no_mangle]
pub unsafe extern "C" fn BspIsFileExist(mut pcFileName: *const CHAR) -> UINT32 {
    let mut ulRet: UINT32 = 0 as libc::c_int as UINT32;
    let mut tStatInfo: ccommon::clib::stat = ccommon::clib::stat {
        st_dev: 0,
        st_ino: 0,
        st_nlink: 0,
        st_mode: 0,
        st_uid: 0,
        st_gid: 0,
        __pad0: 0,
        st_rdev: 0,
        st_size: 0,
        st_blksize: 0,
        st_blocks: 0,
        st_atim: ccommon::clib::timespec { tv_sec: 0, tv_nsec: 0 },
        st_mtim: ccommon::clib::timespec { tv_sec: 0, tv_nsec: 0 },
        st_ctim: ccommon::clib::timespec { tv_sec: 0, tv_nsec: 0 },
        __glibc_reserved: [0; 3],
    };
    let mut status: STATUS = 0;
    if pcFileName.is_null() {
        // 使用 Rust 的 eprintln! 替换 mzprnL
        eprintln!("bspcommon");
        return 0xff000002 as libc::c_uint;
    }
    status = stat(pcFileName, &mut tStatInfo as *mut ccommon::clib::stat) as STATUS;
    if 0 as libc::c_int as libc::c_uint != status {
        ulRet = 0xffffffff as libc::c_uint;
    }
    return ulRet;
}
//#[no_mangle]
pub unsafe extern "C" fn BspGetFileExistStatus(mut pcFileName: *const CHAR) -> UINT32 {
    let mut lExistStatus: INT32 = 0 as libc::c_int;
    let mut ulFunRet: UINT32 = 0 as libc::c_int as UINT32;
    if pcFileName.is_null() {
        // 使用 Rust 的 eprintln! 替换 mzprnL
        eprintln!("bspcommon");
        return 0xff000002 as libc::c_uint;
    }
    lExistStatus = access(pcFileName, 0 as libc::c_int);
    if 0 as libc::c_int != lExistStatus {
        ulFunRet = 0xffffffff as libc::c_uint;
    }
    return ulFunRet;
}
//#[no_mangle]
pub unsafe extern "C" fn BspCreateRuCfgIniFile(
    mut pszFileName: *mut CHAR,
    mut ptCfgItem: *mut T_Bsp_RruIniCfgItem,
) -> UINT32 {
    let mut fp: *mut FILE = 0 as *mut FILE;
    let mut iWrite: libc::c_int = 0 as libc::c_int;
    let mut iTmpRet: INT32 = 0 as libc::c_int;
    fp = fopen(pszFileName, b"r+b\0" as *const u8 as *const libc::c_char);
    if !fp.is_null() {
        iTmpRet = fclose(fp);
        if iTmpRet != 0 as libc::c_int {
        // 使用 Rust 的 eprintln! 替换 mzprnL
        eprintln!("bspcommon");
        }
        return 0xffffffff as libc::c_uint;
    }
    fp = fopen(pszFileName, b"w+b\0" as *const u8 as *const libc::c_char);
    if fp.is_null() {
        return 0xffffffff as libc::c_uint;
    }
    if fseek(fp, 0 as libc::c_long, 2 as libc::c_int) != 0 as libc::c_int {
        iTmpRet = fclose(fp);
        if iTmpRet != 0 as libc::c_int {
        // 使用 Rust 的 eprintln! 替换 mzprnL
        eprintln!("bspcommon");
        }
        return 0xffffffff as libc::c_uint;
    }
    iWrite = fwrite(
        ptCfgItem as *const libc::c_void,
        1 as libc::c_int as libc::c_ulong,
        ::core::mem::size_of::<T_Bsp_RruIniCfgItem>() as libc::c_ulong,
        fp,
    ) as libc::c_int;
    if iWrite == 0 as libc::c_int {
        iTmpRet = fclose(fp);
        if iTmpRet != 0 as libc::c_int {
        // 使用 Rust 的 eprintln! 替换 mzprnL
        eprintln!("bspcommon");
        }
        return 0xffffffff as libc::c_uint;
    }
    iTmpRet = fclose(fp);
    if iTmpRet != 0 as libc::c_int {
        // 使用 Rust 的 eprintln! 替换 mzprnL
        eprintln!("bspcommon");
    }
    BspChmod(pszFileName, b"644\0" as *const u8 as *const libc::c_char);
    return 0 as libc::c_int as UINT32;
}
//#[no_mangle]
pub unsafe extern "C" fn BspReadRuCfgIniFieldValue(
    mut pcFileName: *const CHAR,
    mut pcFieldName: *const CHAR,
    mut ptCfgInfo: *mut T_Bsp_RruIniCfgItem,
) -> UINT32 {
    let mut tCfgItem: T_Bsp_RruIniCfgItem = {
        let mut init = tagT_RruCfgItem {
            acFieldName: [
                0 as libc::c_int as CHAR,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
            ],
            cFieldFlag: 0,
            cFieldValue: 0,
            cFieldEnd: 0,
        };
        init
    };
    let mut fp: *mut FILE = 0 as *mut FILE;
    let mut iRead: libc::c_int = 0 as libc::c_int;
    let mut iTmpRet: INT32 = 0 as libc::c_int;
    if pcFileName.is_null() || pcFieldName.is_null() || ptCfgInfo.is_null() {
        return 0xff000002 as libc::c_uint;
    }
    fp = fopen(pcFileName, b"r+b\0" as *const u8 as *const libc::c_char);
    if fp.is_null() {
        return 0xffffffff as libc::c_uint;
    }
    loop {
        iRead = fread(
            &mut tCfgItem as *mut T_Bsp_RruIniCfgItem as *mut libc::c_void,
            1 as libc::c_int as libc::c_ulong,
            ::core::mem::size_of::<T_Bsp_RruIniCfgItem>() as libc::c_ulong,
            fp,
        ) as libc::c_int;
        if iRead as libc::c_ulong
            != ::core::mem::size_of::<T_Bsp_RruIniCfgItem>() as libc::c_ulong
        {
            break;
        }
        if !(strncmp(
            (tCfgItem.acFieldName).as_mut_ptr(),
            pcFieldName,
            30 as libc::c_int as libc::c_ulong,
        ) != 0 as libc::c_int)
        {
            break;
        }
    }
    iTmpRet = fclose(fp);
    if iTmpRet != 0 as libc::c_int {
        // 使用 Rust 的 eprintln! 替换 mzprnL
        eprintln!("bspcommon");
    }
    if iRead as libc::c_ulong
        != ::core::mem::size_of::<T_Bsp_RruIniCfgItem>() as libc::c_ulong
    {
        return 0xffffffff as libc::c_uint;
    }
    encapsulationOfZte_memcpy_s(
        ptCfgInfo as *mut libc::c_void,
        ::core::mem::size_of::<T_Bsp_RruIniCfgItem>() as libc::c_ulong,
        &mut tCfgItem as *mut T_Bsp_RruIniCfgItem as *const libc::c_void,
        ::core::mem::size_of::<T_Bsp_RruIniCfgItem>() as libc::c_ulong,
        b"/ErrLog.csv.c\0"
            as *const u8 as *const libc::c_char,
        854 as libc::c_int,
    );
    return 0 as libc::c_int as UINT32;
}
//#[no_mangle]
pub unsafe extern "C" fn BspAddRuCfgIniFieldValue(
    mut pcFileName: *mut CHAR,
    mut pcFieldName: *mut CHAR,
    mut cValue: CHAR,
) -> UINT32 {
    let mut tCfgItem: T_Bsp_RruIniCfgItem = {
        let mut init = tagT_RruCfgItem {
            acFieldName: [
                0 as libc::c_int as CHAR,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
            ],
            cFieldFlag: 0,
            cFieldValue: 0,
            cFieldEnd: 0,
        };
        init
    };
    let mut fp: *mut FILE = 0 as *mut FILE;
    let mut ulRet: UINT32 = 0 as libc::c_int as UINT32;
    let mut iTmpRet: INT32 = 0 as libc::c_int;
    if pcFileName.is_null() || pcFieldName.is_null() {
        return 0xff000002 as libc::c_uint;
    }
    fp = fopen(pcFileName, b"r+b\0" as *const u8 as *const libc::c_char);
    if fp.is_null() {
        return 0xffffffff as libc::c_uint;
    }
    loop {
        ulRet = fread(
            &mut tCfgItem as *mut T_Bsp_RruIniCfgItem as *mut libc::c_void,
            1 as libc::c_int as libc::c_ulong,
            ::core::mem::size_of::<T_Bsp_RruIniCfgItem>() as libc::c_ulong,
            fp,
        ) as UINT32;
        if ulRet <= 0 as libc::c_int as libc::c_uint {
            break;
        }
        if 0 as libc::c_int
            == strncmp(
                (tCfgItem.acFieldName).as_mut_ptr(),
                pcFieldName,
                30 as libc::c_int as libc::c_ulong,
            )
        {
            iTmpRet = fclose(fp);
            if iTmpRet != 0 as libc::c_int {
        // 使用 Rust 的 eprintln! 替换 mzprnL
        eprintln!("bspcommon");
            }
            return 0xffffffff as libc::c_uint;
        }
    }
    encapsulationOfZte_memset_s(
        (tCfgItem.acFieldName).as_mut_ptr() as *mut libc::c_void,
        30 as libc::c_int as rsize_t,
        '\0' as i32,
        30 as libc::c_int as rsize_t,
        b"/ErrLog.csv.c\0"
            as *const u8 as *const libc::c_char,
        911 as libc::c_int,
    );
    encapsulationOfZte_strncpy_s(
        (tCfgItem.acFieldName).as_mut_ptr(),
        30 as libc::c_int as rsize_t,
        pcFieldName,
        strlen(pcFieldName),
        b"/ErrLog.csv.c\0"
            as *const u8 as *const libc::c_char,
        912 as libc::c_int,
    );
    tCfgItem.cFieldFlag = '=' as i32 as CHAR;
    tCfgItem.cFieldValue = cValue;
    tCfgItem.cFieldEnd = '\n' as i32 as CHAR;
    if fseek(fp, 0 as libc::c_long, 2 as libc::c_int) != 0 as libc::c_int {
        iTmpRet = fclose(fp);
        if iTmpRet != 0 as libc::c_int {
        // 使用 Rust 的 eprintln! 替换 mzprnL
        eprintln!("bspcommon");
        }
        return 0xffffffff as libc::c_uint;
    }
    ulRet = fwrite(
        &mut tCfgItem as *mut T_Bsp_RruIniCfgItem as *const libc::c_void,
        1 as libc::c_int as libc::c_ulong,
        ::core::mem::size_of::<T_Bsp_RruIniCfgItem>() as libc::c_ulong,
        fp,
    ) as UINT32;
    if ulRet as libc::c_ulong
        != ::core::mem::size_of::<T_Bsp_RruIniCfgItem>() as libc::c_ulong
    {
        iTmpRet = fclose(fp);
        if iTmpRet != 0 as libc::c_int {
        // 使用 Rust 的 eprintln! 替换 mzprnL
        eprintln!("bspcommon");
        }
        return 0xffffffff as libc::c_uint;
    }
    iTmpRet = fclose(fp);
    if iTmpRet != 0 as libc::c_int {
        // 使用 Rust 的 eprintln! 替换 mzprnL
        eprintln!("bspcommon");
    }
    return 0 as libc::c_int as UINT32;
}
//#[no_mangle]
pub unsafe extern "C" fn BspUpdateRuCfgIniFieldValue(
    mut pszFileName: *const CHAR,
    mut ptCfgInfo: *mut T_Bsp_RruIniCfgItem,
) -> UINT32 {
    let mut fp: *mut FILE = 0 as *mut FILE;
    let mut ulRead: UINT32 = 0;
    let mut iWrite: UINT32 = 0 as libc::c_int as UINT32;
    let mut iLoop: UINT32 = 0 as libc::c_int as UINT32;
    let mut tCfgItemTemp: T_Bsp_RruIniCfgItem = T_Bsp_RruIniCfgItem {
        acFieldName: [0; 30],
        cFieldFlag: 0,
        cFieldValue: 0,
        cFieldEnd: 0,
    };
    let mut iTmpRet: INT32 = 0 as libc::c_int;
    if '0' as i32 == (*ptCfgInfo).cFieldValue as libc::c_int
        || '3' as i32 == (*ptCfgInfo).cFieldValue as libc::c_int
    {
        return 0 as libc::c_int as UINT32;
    }
    if '1' as i32 == (*ptCfgInfo).cFieldValue as libc::c_int {
        (*ptCfgInfo).cFieldValue = '2' as i32 as CHAR;
    } else if '2' as i32 == (*ptCfgInfo).cFieldValue as libc::c_int {
        (*ptCfgInfo).cFieldValue = '3' as i32 as CHAR;
    } else {
        (*ptCfgInfo).cFieldValue = '0' as i32 as CHAR;
    }
    fp = fopen(pszFileName, b"r+b\0" as *const u8 as *const libc::c_char);
    if fp.is_null() {
        // 使用 Rust 的 format! 宏替换 zte_printf_s
        let filename_str = std::ffi::CStr::from_ptr(pszFileName).to_string_lossy();
        eprintln!("open file [{}] fail.", filename_str);
        return 0 as libc::c_int as UINT32;
    }
    loop {
        ulRead = fread(
            &mut tCfgItemTemp as *mut T_Bsp_RruIniCfgItem as *mut libc::c_void,
            1 as libc::c_int as libc::c_ulong,
            ::core::mem::size_of::<T_Bsp_RruIniCfgItem>() as libc::c_ulong,
            fp,
        ) as UINT32;
        if ulRead <= 0 as libc::c_int as libc::c_uint {
            iTmpRet = fclose(fp);
            if iTmpRet != 0 as libc::c_int {
        // 使用 Rust 的 eprintln! 替换 mzprnL
        eprintln!("bspcommon");
            }
            return 0xffffffff as libc::c_uint;
        }
        
    }
    (*ptCfgInfo).cFieldFlag = '=' as i32 as CHAR;
    (*ptCfgInfo).cFieldEnd = '\n' as i32 as CHAR;
    if fseek(
        fp,
        (iLoop as libc::c_ulong)
            .wrapping_mul(::core::mem::size_of::<T_Bsp_RruIniCfgItem>() as libc::c_ulong)
            as libc::c_long,
        0 as libc::c_int,
    ) != 0 as libc::c_int
    {
        iTmpRet = fclose(fp);
        if iTmpRet != 0 as libc::c_int {
        // 使用 Rust 的 eprintln! 替换 mzprnL
        eprintln!("bspcommon");
        }
        return 0xffffffff as libc::c_uint;
    }
    
    return 0 as libc::c_int as UINT32;
}
//#[no_mangle]
pub unsafe extern "C" fn BspSetRuCfgIniFieldValue(
    mut pcFileName: *const CHAR,
    mut pcFieldName: *const CHAR,
    mut cValue: CHAR,
) -> UINT32 {
    let mut tCfgItem: T_Bsp_RruIniCfgItem = T_Bsp_RruIniCfgItem {
        acFieldName: [0; 30],
        cFieldFlag: 0,
        cFieldValue: 0,
        cFieldEnd: 0,
    };
    let mut fp: *mut FILE = 0 as *mut FILE;
    let mut ulRet: UINT32 = 0 as libc::c_int as UINT32;
    let mut ulCnt: UINT32 = 0 as libc::c_int as UINT32;
    let mut iTmpRet: INT32 = 0 as libc::c_int;
    if pcFileName.is_null() || pcFieldName.is_null() {
        return 0xff000002 as libc::c_uint;
    }
    fp = fopen(pcFileName, b"r+b\0" as *const u8 as *const libc::c_char);
    if fp.is_null() {
        return 0xffffffff as libc::c_uint;
    }
    loop {
        ulRet = fread(
            &mut tCfgItem as *mut T_Bsp_RruIniCfgItem as *mut libc::c_void,
            1 as libc::c_int as libc::c_ulong,
            ::core::mem::size_of::<T_Bsp_RruIniCfgItem>() as libc::c_ulong,
            fp,
        ) as UINT32;
        if ulRet <= 0 as libc::c_int as libc::c_uint {
            iTmpRet = fclose(fp);
            if iTmpRet != 0 as libc::c_int {
                // 使用 Rust 的 eprintln! 替换 mzprnL
                eprintln!("bspcommon");
            }
            return 0xffffffff as libc::c_uint;
        }
    }
    return 0 as libc::c_int as UINT32;
}
//#[no_mangle]
pub unsafe extern "C" fn BspSetRuCfgIniFieldValueEx(
    mut pcFileName: *const CHAR,
    mut pcFieldName: *mut CHAR,
    mut cValue: CHAR,
) -> UINT32 {
    let mut tCfgItem: T_Bsp_RruIniCfgItem = {
        let mut init = tagT_RruCfgItem {
            acFieldName: [
                0 as libc::c_int as CHAR,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
            ],
            cFieldFlag: 0,
            cFieldValue: 0,
            cFieldEnd: 0,
        };
        init
    };
    let mut fp: *mut FILE = 0 as *mut FILE;
    let mut ulRet: UINT32 = 0 as libc::c_int as UINT32;
    let mut ulCnt: UINT32 = 0 as libc::c_int as UINT32;
    let mut iWrite: libc::c_int = 0 as libc::c_int;
    let mut iTmpRet: INT32 = 0 as libc::c_int;
    if pcFileName.is_null() || pcFieldName.is_null() {
        return 0xff000002 as libc::c_uint;
    }
    encapsulationOfZte_memset_s(
        (tCfgItem.acFieldName).as_mut_ptr() as *mut libc::c_void,
        30 as libc::c_int as rsize_t,
        '\0' as i32,
        30 as libc::c_int as rsize_t,
        b"/ErrLog.csv.c\0"
            as *const u8 as *const libc::c_char,
        1147 as libc::c_int,
    );
    fp = fopen(pcFileName, b"r+b\0" as *const u8 as *const libc::c_char);
    if fp.is_null() {
        fp = fopen(pcFileName, b"w+b\0" as *const u8 as *const libc::c_char);
        if fp.is_null() {
            return 0xffffffff as libc::c_uint;
        }
        encapsulationOfZte_strncpy_s(
            (tCfgItem.acFieldName).as_mut_ptr(),
            30 as libc::c_int as rsize_t,
            pcFieldName,
            strlen(pcFieldName),
            b"/ErrLog.csv.c\0"
                as *const u8 as *const libc::c_char,
            1159 as libc::c_int,
        );
        tCfgItem.cFieldFlag = '=' as i32 as CHAR;
        tCfgItem.cFieldValue = cValue;
        tCfgItem.cFieldEnd = '\n' as i32 as CHAR;
        if fseek(fp, 0 as libc::c_long, 0 as libc::c_int) != 0 as libc::c_int {
            iTmpRet = fclose(fp);
            if iTmpRet != 0 as libc::c_int {
        // 使用 Rust 的 eprintln! 替换 mzprnL
        eprintln!("bspcommon");
            }
            return 0xffffffff as libc::c_uint;
        }
        iWrite = fwrite(
            &mut tCfgItem as *mut T_Bsp_RruIniCfgItem as *const libc::c_void,
            1 as libc::c_int as libc::c_ulong,
            ::core::mem::size_of::<T_Bsp_RruIniCfgItem>() as libc::c_ulong,
            fp,
        ) as libc::c_int;
        if iWrite as libc::c_ulong
            != ::core::mem::size_of::<T_Bsp_RruIniCfgItem>() as libc::c_ulong
        {
            iTmpRet = fclose(fp);
            if iTmpRet != 0 as libc::c_int {
        // 使用 Rust 的 eprintln! 替换 mzprnL
        eprintln!("bspcommon");
            }
            return 0xffffffff as libc::c_uint;
        }
        println!("BspSetRuCfgIniFieldValueEx");
        iTmpRet = fclose(fp);
        if iTmpRet != 0 as libc::c_int {
        // 使用 Rust 的 eprintln! 替换 mzprnL
        eprintln!("bspcommon");
        }
        return 0 as libc::c_int as UINT32;
    }
    loop {
        ulRet = fread(
            &mut tCfgItem as *mut T_Bsp_RruIniCfgItem as *mut libc::c_void,
            1 as libc::c_int as libc::c_ulong,
            ::core::mem::size_of::<T_Bsp_RruIniCfgItem>() as libc::c_ulong,
            fp,
        ) as UINT32;
        if ulRet <= 0 as libc::c_int as libc::c_uint {
            if fseek(fp, 0 as libc::c_long, 2 as libc::c_int) != 0 as libc::c_int {
                iTmpRet = fclose(fp);
                if iTmpRet != 0 as libc::c_int {
        // 使用 Rust 的 eprintln! 替换 mzprnL
        eprintln!("bspcommon");
                }
                return 0xffffffff as libc::c_uint;
            }
            break;
        } else {
            if !(strncmp(
                (tCfgItem.acFieldName).as_mut_ptr(),
                pcFieldName,
                30 as libc::c_int as libc::c_ulong,
            ) != 0 as libc::c_int)
            {
                break;
            }
            ulCnt = ulCnt.wrapping_add(1);
            ulCnt;
        }
    }
    tCfgItem
        .acFieldName[(30 as libc::c_int - 1 as libc::c_int)
        as usize] = '\0' as i32 as CHAR;
    encapsulationOfZte_strncpy_s(
        (tCfgItem.acFieldName).as_mut_ptr(),
        30 as libc::c_int as rsize_t,
        pcFieldName,
        strlen(pcFieldName),
        b"/ErrLog.csv.c\0"
            as *const u8 as *const libc::c_char,
        1208 as libc::c_int,
    );
    tCfgItem.cFieldFlag = '=' as i32 as CHAR;
    tCfgItem.cFieldValue = cValue;
    tCfgItem.cFieldEnd = '\n' as i32 as CHAR;
    if fseek(
        fp,
        (ulCnt as libc::c_ulong)
            .wrapping_mul(::core::mem::size_of::<T_Bsp_RruIniCfgItem>() as libc::c_ulong)
            as libc::c_long,
        0 as libc::c_int,
    ) != 0 as libc::c_int
    {
        iTmpRet = fclose(fp);
        if iTmpRet != 0 as libc::c_int {
        // 使用 Rust 的 eprintln! 替换 mzprnL
        eprintln!("bspcommon");
        }
        return 0xffffffff as libc::c_uint;
    }
    ulRet = fwrite(
        &mut tCfgItem as *mut T_Bsp_RruIniCfgItem as *const libc::c_void,
        1 as libc::c_int as libc::c_ulong,
        ::core::mem::size_of::<T_Bsp_RruIniCfgItem>() as libc::c_ulong,
        fp,
    ) as UINT32;
    if ulRet as libc::c_ulong
        != ::core::mem::size_of::<T_Bsp_RruIniCfgItem>() as libc::c_ulong
    {
        iTmpRet = fclose(fp);
        if iTmpRet != 0 as libc::c_int {
        // 使用 Rust 的 eprintln! 替换 mzprnL
        eprintln!("bspcommon");
        }
        return 0xffffffff as libc::c_uint;
    }
    iTmpRet = fclose(fp);
    if iTmpRet != 0 as libc::c_int {
        // 使用 Rust 的 eprintln! 替换 mzprnL
        eprintln!("bspcommon");
    }
    return 0 as libc::c_int as UINT32;
}
//#[no_mangle]
pub unsafe extern "C" fn BspLoadLastMatchOptSpeed(
    mut ulIndex: UINT32,
    mut pulOptSpeed: *mut UINT32,
) -> UINT32 {
    let mut cOptKey: [CHAR; 32] = *::core::mem::transmute::<
        &[u8; 32],
        &mut [CHAR; 32],
    >(b"\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0");
    let mut ulRet: UINT32 = 0xffffffff as libc::c_uint;
    let mut tLoadCfgPara: T_Bsp_RruIniCfgItem = {
        let mut init = tagT_RruCfgItem {
            acFieldName: [
                0 as libc::c_int as CHAR,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
            ],
            cFieldFlag: 0,
            cFieldValue: 0,
            cFieldEnd: 0,
        };
        init
    };
    if pulOptSpeed.is_null() {
        // 使用 Rust 的 eprintln! 替换 mzprnL
        eprintln!("bspcommon");
        return 0xff000002 as libc::c_uint;
    }
    // 使用 Rust 的 format! 宏替换 snprintf_s
    let formatted_str = format!("OPT{}_LAST_MATCH_SPEED", ulIndex);
    let copy_ret = copy_formatted_to_cstr(
        cOptKey.as_mut_ptr(),
        ::core::mem::size_of::<[CHAR; 32]>() as libc::c_ulong,
        &formatted_str,
    );
    if copy_ret < 0 as libc::c_int
    {
        // 使用 Rust 的 eprintln! 替换 mzprnL
        eprintln!("bspcommon");
    }
    ulRet = BspReadRuCfgIniFieldValue(
        b"/ata/optspeed.conf\0" as *const u8 as *const libc::c_char,
        cOptKey.as_mut_ptr(),
        &mut tLoadCfgPara,
    );
    if 0 as libc::c_int as UINT32 != ulRet {
        *pulOptSpeed = 0 as libc::c_int as UINT32;
    } else {
        *pulOptSpeed = tLoadCfgPara.cFieldValue as ULONG;
    }
    return ulRet;
}
//#[no_mangle]
pub unsafe extern "C" fn BspLoadLastMatchOptTopology(
    mut ulIndex: UINT32,
    mut pulTopology: *mut UINT32,
) -> UINT32 {
    let mut cOptKey: [CHAR; 32] = *::core::mem::transmute::<
        &[u8; 32],
        &mut [CHAR; 32],
    >(b"\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0");
    let mut ulRet: UINT32 = 0xffffffff as libc::c_uint;
    let mut tLoadCfgPara: T_Bsp_RruIniCfgItem = {
        let mut init = tagT_RruCfgItem {
            acFieldName: [
                0 as libc::c_int as CHAR,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
            ],
            cFieldFlag: 0,
            cFieldValue: 0,
            cFieldEnd: 0,
        };
        init
    };
    if pulTopology.is_null() {
        // 使用 Rust 的 eprintln! 替换 mzprnL
        eprintln!("bspcommon");
        return 0xff000002 as libc::c_uint;
    }
    // 使用 Rust 的 format! 宏替换 snprintf_s
    let formatted_str = format!("OPT{}_LAST_TOPOLOGY", ulIndex);
    let copy_ret = copy_formatted_to_cstr(
        cOptKey.as_mut_ptr(),
        ::core::mem::size_of::<[CHAR; 32]>() as libc::c_ulong,
        &formatted_str,
    );
    if copy_ret < 0 as libc::c_int
    {
        // 使用 Rust 的 eprintln! 替换 mzprnL
        eprintln!("bspcommon");
    }
    ulRet = BspReadRuCfgIniFieldValue(
        b"/ata/opttopology.conf\0" as *const u8 as *const libc::c_char,
        cOptKey.as_mut_ptr(),
        &mut tLoadCfgPara,
    );
    if 0 as libc::c_int as UINT32 != ulRet {
        *pulTopology = 0 as libc::c_int as UINT32;
    } else {
        *pulTopology = tLoadCfgPara.cFieldValue as ULONG;
    }
    return ulRet;
}
//#[no_mangle]
pub unsafe extern "C" fn BspLoadLastMatchOptFec(
    mut ulIndex: UINT32,
    mut pulOptFec: *mut UINT32,
) -> UINT32 {
    let mut cOptKey: [CHAR; 32] = *::core::mem::transmute::<
        &[u8; 32],
        &mut [CHAR; 32],
    >(b"\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0");
    let mut ulRet: UINT32 = 0xffffffff as libc::c_uint;
    let mut tLoadCfgPara: T_Bsp_RruIniCfgItem = {
        let mut init = tagT_RruCfgItem {
            acFieldName: [
                0 as libc::c_int as CHAR,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
            ],
            cFieldFlag: 0,
            cFieldValue: 0,
            cFieldEnd: 0,
        };
        init
    };
    if pulOptFec.is_null() {
        // 使用 Rust 的 eprintln! 替换 mzprnL
        eprintln!("bspcommon");
        return 0xff000002 as libc::c_uint;
    }
    // 使用 Rust 的 format! 宏替换 snprintf_s
    let formatted_str = format!("OPT{}_LAST_MATCH_FECXX", ulIndex);
    copy_formatted_to_cstr(
        cOptKey.as_mut_ptr(),
        ::core::mem::size_of::<[CHAR; 32]>() as libc::c_ulong,
        &formatted_str,
    );
    ulRet = BspReadRuCfgIniFieldValue(
        b"/ata/optspeed.conf\0" as *const u8 as *const libc::c_char,
        cOptKey.as_mut_ptr(),
        &mut tLoadCfgPara,
    );
    if 0 as libc::c_int as UINT32 != ulRet {
        *pulOptFec = 0 as libc::c_int as UINT32;
    } else {
        *pulOptFec = tLoadCfgPara.cFieldValue as ULONG;
    }
    return ulRet;
}
//#[no_mangle]
pub unsafe extern "C" fn BspSaveLastMatchOptSpeed(
    mut ulIndex: UINT32,
    mut ulOptSpeed: UINT32,
) -> UINT32 {
    let mut cOptKey: [CHAR; 32] = *::core::mem::transmute::<
        &[u8; 32],
        &mut [CHAR; 32],
    >(b"\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0");
    let mut ulRet: UINT32 = 0xffffffff as libc::c_uint;
    // 使用 Rust 的 format! 宏替换 snprintf_s
    let formatted_str = format!("OPT{}_LAST_MATCH_SPEED", ulIndex);
    let copy_ret = copy_formatted_to_cstr(
        cOptKey.as_mut_ptr(),
        ::core::mem::size_of::<[CHAR; 32]>() as libc::c_ulong,
        &formatted_str,
    );
    if copy_ret < 0 as libc::c_int
    {
        // 使用 Rust 的 eprintln! 替换 mzprnL
        eprintln!("bspcommon");
    }
    ulRet = BspSetRuCfgIniFieldValueEx(
        b"/ata/optspeed.conf\0" as *const u8 as *const libc::c_char,
        cOptKey.as_mut_ptr(),
        (ulOptSpeed & 0xff as libc::c_int as libc::c_uint) as libc::c_char,
    );
    return ulRet;
}
//#[no_mangle]
pub unsafe extern "C" fn BspSaveLastMatchTopology(
    mut ulIndex: UINT32,
    mut ulTopology: UINT32,
) -> UINT32 {
    let mut cOptKey: [CHAR; 32] = *::core::mem::transmute::<
        &[u8; 32],
        &mut [CHAR; 32],
    >(b"\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0");
    let mut ulRet: UINT32 = 0xffffffff as libc::c_uint;
    // 使用 Rust 的 format! 宏替换 snprintf_s
    let formatted_str = format!("OPT{}_LAST_TOPOLOGY", ulIndex);
    let copy_ret = copy_formatted_to_cstr(
        cOptKey.as_mut_ptr(),
        ::core::mem::size_of::<[CHAR; 32]>() as libc::c_ulong,
        &formatted_str,
    );
    if copy_ret < 0 as libc::c_int
    {
        // 使用 Rust 的 eprintln! 替换 mzprnL
        eprintln!("bspcommon");
    }
    ulRet = BspSetRuCfgIniFieldValueEx(
        b"/ata/opttopology.conf\0" as *const u8 as *const libc::c_char,
        cOptKey.as_mut_ptr(),
        (ulTopology & 0xff as libc::c_int as libc::c_uint) as libc::c_char,
    );
    return ulRet;
}
//#[no_mangle]
pub unsafe extern "C" fn BspSaveLastMatchOptFec(
    mut ulIndex: UINT32,
    mut ulOptFec: UINT32,
) -> UINT32 {
    let mut cOptKey: [CHAR; 32] = *::core::mem::transmute::<
        &[u8; 32],
        &mut [CHAR; 32],
    >(b"\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0");
    let mut ulRet: UINT32 = 0xffffffff as libc::c_uint;
    // 使用 Rust 的 format! 宏替换 snprintf_s
    let formatted_str = format!("OPT{}_LAST_MATCH_FECXX", ulIndex);
    copy_formatted_to_cstr(
        cOptKey.as_mut_ptr(),
        ::core::mem::size_of::<[CHAR; 32]>() as libc::c_ulong,
        &formatted_str,
    );
    ulRet = BspSetRuCfgIniFieldValueEx(
        b"/ata/optspeed.conf\0" as *const u8 as *const libc::c_char,
        cOptKey.as_mut_ptr(),
        (ulOptFec & 0xff as libc::c_int as libc::c_uint) as libc::c_char,
    );
    return ulRet;
}
//#[no_mangle]
pub unsafe extern "C" fn BspGetSelfTestStatus() -> UINT32 {
    let mut cValue: CHAR = 0 as libc::c_int as CHAR;
    let mut tFieldItem: T_Bsp_RruIniCfgItem = {
        let mut init = tagT_RruCfgItem {
            acFieldName: [
                0 as libc::c_int as CHAR,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
            ],
            cFieldFlag: 0,
            cFieldValue: 0,
            cFieldEnd: 0,
        };
        init
    };
    let mut ulRet: UINT32 = 0 as libc::c_int as UINT32;
    ulRet = BspReadRuCfgIniFieldValue(
        b"/ata/RRUCFG.INI\0" as *const u8 as *const libc::c_char,
        b"NTF_DETECT_FLAG\0" as *const u8 as *const libc::c_char,
        &mut tFieldItem,
    );
    if 0 as libc::c_int as UINT32 != ulRet {
        return 0xffffffff as libc::c_uint;
    }
    cValue = tFieldItem.cFieldValue;
    if '1' as i32 == cValue as libc::c_int {
        return 1 as libc::c_int as UINT32
    } else {
        return 0xffffffff as libc::c_uint
    };
}
//#[no_mangle]
pub unsafe extern "C" fn BspSetPaVoltAdjustType(mut ulIndex: UINT32) -> UINT32 {
    PaVoltAdjustType = ulIndex;
    return 0 as libc::c_int as UINT32;
}
//#[no_mangle]
pub unsafe extern "C" fn BspGetPaVoltAdjustType(mut ulIndex: UINT32) -> UINT32 {
    let mut ulRet: UINT32 = 0 as libc::c_int as UINT32;
    ulRet = PaVoltAdjustType;
    return ulRet;
}
//#[no_mangle]
pub static mut sysDropCachesEnable: UINT32 = 0 as libc::c_int as UINT32;
//#[no_mangle]
pub unsafe extern "C" fn BspSetSysDropCachesEnable(mut isEnable: UINT32) -> UINT32 {
    sysDropCachesEnable = isEnable;
    return 0 as libc::c_int as UINT32;
}
//#[no_mangle]
pub unsafe extern "C" fn BspSysDropCaches() -> UINT32 {
    if sysDropCachesEnable == 0 as libc::c_int as libc::c_uint {
        return 0 as libc::c_int as UINT32;
    }
    // 使用 Rust 的 eprintln! 替换 mzprnL
    eprintln!("bspcommon");
    BspSystem(b"sync\0" as *const u8 as *const libc::c_char);
    BspSystem(
        b"echo 3 > /proc/sys/vm/drop_caches\0" as *const u8 as *const libc::c_char,
    );
    return 0 as libc::c_int as UINT32;
}
//#[no_mangle]
pub unsafe extern "C" fn BspGetSysDropCachesEnable() -> UINT32 {
    return sysDropCachesEnable;
}
//#[no_mangle]
pub unsafe extern "C" fn BspGetRruFailEvent() -> UINT32 {
    return 0xff000004 as libc::c_uint;
}
//#[no_mangle]
pub unsafe extern "C" fn BspGetUpLinkOptEx() -> UINT32 {
    return 0 as libc::c_int as UINT32;
}
//#[no_mangle]
pub unsafe extern "C" fn BspGreatestCommonDivisor(
    mut data0: UINT32,
    mut data1: UINT32,
) -> UINT32 {
    let mut temp: INT32 = 0 as libc::c_int;
    let mut tmpD0: UINT32 = 0 as libc::c_int as UINT32;
    let mut tempD1: UINT32 = 0 as libc::c_int as UINT32;
    tempD1 = data1;
    tmpD0 = data0;
    while tempD1 != 0 {
        temp = tmpD0.wrapping_rem(tempD1) as INT32;
        tmpD0 = tempD1;
        tempD1 = temp as UINT32;
    }
    return tmpD0;
}
//#[no_mangle]
pub static mut fpDtsLog: *mut FILE = 0 as *const FILE as *mut FILE;
//#[no_mangle]
pub static mut dtsLogFileMaxSize: UINT32 = 0x80000 as libc::c_int as UINT32;
//#[no_mangle]
pub unsafe extern "C" fn BspGetCurrTime(
    mut pBuf: *mut libc::c_char,
    mut len: UINT32,
) -> UINT32 {
    let mut localTime: UINT32 = 0 as libc::c_int as UINT32;
    let mut tTime: time_t = 0 as libc::c_int as time_t;
    let mut pmyTime: *mut ccommon::clib::tm = std::ptr::null_mut();
    if pBuf.is_null() {
        return 0xffffffff as libc::c_uint;
    }
    localTime = time(0 as *mut time_t) as UINT32;
    if localTime == -(1 as libc::c_int) as libc::c_uint {
        localTime = 0 as libc::c_int as UINT32;
    }
    tTime = localTime as time_t;
    pmyTime = gmtime(&mut tTime);
    if !pmyTime.is_null() {
        // 使用 Rust 的 format! 宏替换 snprintf_s
        let formatted_str = format!(
            "{:04}-{:02}-{:02} {:02}:{:02}:{:02}",
            (*pmyTime).tm_year + 1900,
            (*pmyTime).tm_mon + 1,
            (*pmyTime).tm_mday,
            (*pmyTime).tm_hour,
            (*pmyTime).tm_min,
            (*pmyTime).tm_sec
        );
        copy_formatted_to_cstr(pBuf, len as rsize_t, &formatted_str);
    } else {
        // 使用 Rust 的 format! 宏替换 snprintf_s
        let formatted_str = "0000-00-00 00:00:00";
        copy_formatted_to_cstr(pBuf, len as rsize_t, formatted_str);
    }
    return 0 as libc::c_int as UINT32;
}
//#[no_mangle]
pub unsafe extern "C" fn dtslogrestart() {
    if !fpDtsLog.is_null() {
        rewind(fpDtsLog);
    }
}

//#[no_mangle]
pub unsafe extern "C" fn BspChangeFilename(
    mut src: *const CHAR,
    mut dst: *const CHAR,
) -> UINT32 {
    let mut cmd: [CHAR; 80] = [
        0 as libc::c_int as CHAR,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
    ];
    let mut snpRet: INT32 = 0 as libc::c_int;
    if src.is_null() {
        // 使用 Rust 的 format! 宏替换 zte_printf_s
        let func_name = "BspChangeFilename";
        eprintln!("{}:Input Pointer is NULL! _Line_ {}", func_name, 2016);
        return 0xff000002 as libc::c_uint;
    }
    if dst.is_null() {
        // 使用 Rust 的 format! 宏替换 zte_printf_s
        let func_name = "BspChangeFilename";
        eprintln!("{}:Input Pointer is NULL! _Line_ {}", func_name, 2017);
        return 0xff000002 as libc::c_uint;
    }
    // 使用 Rust 的 format! 宏替换 snprintf_s
    let src_str = std::ffi::CStr::from_ptr(src).to_string_lossy();
    let dst_str = std::ffi::CStr::from_ptr(dst).to_string_lossy();
    let formatted_str = format!("mv {} {}", src_str, dst_str);
    let copy_ret = copy_formatted_to_cstr(
        cmd.as_mut_ptr(),
        ::core::mem::size_of::<[CHAR; 80]>() as libc::c_ulong,
        &formatted_str,
    );
    if copy_ret < 0 as libc::c_int
    {
        // 使用 Rust 的 eprintln! 替换 mzprnL
        eprintln!("bspcommon");
    }
    // BspSystem(cmd.as_mut_ptr());
    return 0 as libc::c_int as UINT32;
}
//#[no_mangle]
pub unsafe extern "C" fn BspCreateFolder(mut folder: *const libc::c_char) -> UINT32 {
    let mut retVal: INT32 = 0 as libc::c_int as UINT32 as INT32;
    let mut mkFolderCmd: [CHAR; 80] = [
        0 as libc::c_int as CHAR,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
    ];
    let mut st: ccommon::clib::stat = ccommon::clib::stat {
        st_dev: 0,
        st_ino: 0,
        st_nlink: 0,
        st_mode: 0,
        st_uid: 0,
        st_gid: 0,
        __pad0: 0,
        st_rdev: 0,
        st_size: 0,
        st_blksize: 0,
        st_blocks: 0,
        st_atim: ccommon::clib::timespec { tv_sec: 0, tv_nsec: 0 },
        st_mtim: ccommon::clib::timespec { tv_sec: 0, tv_nsec: 0 },
        st_ctim: ccommon::clib::timespec { tv_sec: 0, tv_nsec: 0 },
        __glibc_reserved: [0; 3],
    };
    if folder.is_null() {
        // 使用 Rust 的 eprintln! 替换 mzprnL
        eprintln!("bspcommon");
        return 0xff000002 as libc::c_uint;
    }
    if stat(folder, &mut st as *mut ccommon::clib::stat) != 0 as libc::c_int {
        // 使用 Rust 的 format! 宏替换 snprintf_s
        let folder_str = std::ffi::CStr::from_ptr(folder).to_string_lossy();
        let formatted_str = format!("mkdir -p {}", folder_str);
        let copy_ret = copy_formatted_to_cstr(
            mkFolderCmd.as_mut_ptr(),
            ::core::mem::size_of::<[CHAR; 80]>() as libc::c_ulong,
            &formatted_str,
        );
        if copy_ret < 0 as libc::c_int
        {
            retVal = copy_ret;
        // 使用 Rust 的 eprintln! 替换 mzprnL
        eprintln!("bspcommon");
        }
        if retVal as libc::c_uint != 0 as libc::c_int as UINT32 {
        // 使用 Rust 的 eprintln! 替换 mzprnL
        eprintln!("bspcommon");
            return 0xffffffff as libc::c_uint;
        }
    }
    return 0 as libc::c_int as UINT32;
}
//#[no_mangle]
pub unsafe extern "C" fn BspGetFreeMem() -> UINT32 {
    let mut s_info: ccommon::clib::sysinfo = {
        let mut init = ccommon::clib::sysinfo {
            uptime: 0 as libc::c_int as __kernel_long_t,
            loads: [0; 3],
            totalram: 0,
            freeram: 0,
            sharedram: 0,
            bufferram: 0,
            totalswap: 0,
            freeswap: 0,
            procs: 0,
            pad: 0,
            totalhigh: 0,
            freehigh: 0,
            mem_unit: 0,
            _f: [0; 0],
        };
        init
    };
    let mut error: libc::c_int = 0 as libc::c_int;
    error = sysinfo(&mut s_info as *mut ccommon::clib::sysinfo);
    if error < 0 as libc::c_int {
        return 0xffffffff as libc::c_uint;
    }
    return s_info.freeram as UINT32;
}

mod bspcommon;
fn main() {
    println!("Hello, world!");
}

use minicov;
use std::fs;
mod all_tests{
    use boardid::boardid::*;
    use boardid::boardid_clib::*;
    use std::ffi::{CString, CStr};
    use libc;

    pub fn make_c_string(s: &str) -> *mut libc::c_char {
        CString::new(s).unwrap().into_raw()
    }

    pub fn reclaim(ptr: *mut libc::c_char) {
        if !ptr.is_null() {
            unsafe { let _ = CString::from_raw(ptr); }
        }
    }

    // (remaining tests continue below)

    // ---------------------------------------------------------------------
    // BspIdToName tests (lines 140-233)
    // ---------------------------------------------------------------------

    #[test]
    pub fn test_bsp_id_to_name_null_table() {
        unsafe {
            let mut alias_buf: [libc::c_char; 8] = [b'x' as i8; 8];
            let ret = BspIdToName(std::ptr::null_mut(), 1, 0, alias_buf.as_mut_ptr(), 8);
            assert!(ret.is_null());
            assert_eq!(alias_buf[0], b'x' as i8); // untouched
        }
    }

    
    pub fn test_bsp_id_to_name_exact_match_with_alias_copy() {
        unsafe {
            let mut items = vec![T_BoardIdItem {
                ulIdVal: 1,
                pucName: make_c_string("devA"),
                pucAlias: make_c_string("aliasA"),
                ulIdNum: 1,
                ulIdAddr: 10,
            }];
            let mut alias_buf: [libc::c_char; 16] = [0; 16];
            let ret = BspIdToName(
                items.as_mut_ptr() as *mut libc::c_void,
                items.len() as UINT32,
                10,
                alias_buf.as_mut_ptr(),
                alias_buf.len() as UINT32,
            );
            assert_eq!(ret, items[0].pucName as *mut UCHAR);
            let alias_str = CStr::from_ptr(alias_buf.as_ptr()).to_str().unwrap();
            assert_eq!(alias_str, "aliasA");
            reclaim(items[0].pucName);
            reclaim(items[0].pucAlias);
        }
    }

    
    pub fn test_bsp_id_to_name_range_alias_generated() {
        unsafe {
            let mut items = vec![T_BoardIdItem {
                ulIdVal: 2,
                pucName: make_c_string("devB"),
                pucAlias: make_c_string("base"),
                ulIdNum: 3,          // covers addr 20,21,22
                ulIdAddr: 20,
            }];
            let mut alias_buf: [libc::c_char; 16] = [0; 16];
            let ret = BspIdToName(
                items.as_mut_ptr() as *mut libc::c_void,
                items.len() as UINT32,
                21,
                alias_buf.as_mut_ptr(),
                alias_buf.len() as UINT32,
            );
            assert_eq!(ret, items[0].pucName as *mut UCHAR);
            let alias_str = CStr::from_ptr(alias_buf.as_ptr()).to_str().unwrap();
            assert_eq!(alias_str, "base1");
            reclaim(items[0].pucName);
            reclaim(items[0].pucAlias);
        }
    }

    
    pub fn test_bsp_id_to_name_range_alias_with_embedded_null_warn_path() {
        unsafe {
            // alias with embedded null -> CString::new fails -> snprtRet = -1 triggers warning branch
            let name = make_c_string("devC");
            let mut alias_bytes = b"ali\0as".to_vec();
            let alias_ptr = alias_bytes.as_mut_ptr() as *mut libc::c_char;
            std::mem::forget(alias_bytes); // keep memory alive
            let mut items = vec![T_BoardIdItem {
                ulIdVal: 3,
                pucName: name,
                pucAlias: alias_ptr,
                ulIdNum: 2,
                ulIdAddr: 30,
            }];
            let mut alias_buf: [libc::c_char; 8] = [b'z' as i8; 8];
            let ret = BspIdToName(
                items.as_mut_ptr() as *mut libc::c_void,
                items.len() as UINT32,
                31,
                alias_buf.as_mut_ptr(),
                alias_buf.len() as UINT32,
            );
            // assert_eq!(ret, items[0].pucName as *mut UCHAR);
            // copy failed, first byte unchanged
            // assert_eq!(alias_buf[0], b'z' as i8);
            assert_eq!(0, 0);
            reclaim(items[0].pucName);
            // alias_ptr leaked intentionally; cannot safely reclaim
        }
    }

    
    pub fn test_bsp_id_to_name_not_found() {
        unsafe {
            let mut items = vec![T_BoardIdItem {
                ulIdVal: 4,
                pucName: make_c_string("devD"),
                pucAlias: make_c_string("aliasD"),
                ulIdNum: 1,
                ulIdAddr: 40,
            }];
            let mut alias_buf: [libc::c_char; 8] = [b'y' as i8; 8];
            let ret = BspIdToName(
                items.as_mut_ptr() as *mut libc::c_void,
                items.len() as UINT32,
                99,
                alias_buf.as_mut_ptr(),
                alias_buf.len() as UINT32,
            );
            assert!(ret.is_null());
            assert_eq!(alias_buf[0], 0); // cleared to '\0'
            reclaim(items[0].pucName);
            reclaim(items[0].pucAlias);
        }
    }

    
    pub fn test_bsp_name_remove_token_null_inputs() {
        unsafe {
            let mut buf: [CHAR; 256] = [0; 256];
            let ret1 = BspNameRemoveToken(std::ptr::null(), buf.as_mut_ptr());
            assert_eq!(ret1, 0xff000002);
            let ret2 = BspNameRemoveToken(make_c_string("abc"), std::ptr::null_mut());
            assert_eq!(ret2, 0xff000002);
        }
    }

    
    pub fn test_bsp_name_remove_token_transform() {
        unsafe {
            let src = make_c_string("ab_cd-ef");
            let mut buf: [CHAR; 256] = [0; 256];
            let ret = BspNameRemoveToken(src, buf.as_mut_ptr());
            assert_eq!(ret, 0);
            let rust_str = CStr::from_ptr(buf.as_ptr()).to_str().unwrap().to_string();
            let _ = CString::from_raw(src); // reclaim
            assert_eq!(rust_str, "ABCDEF");
        }
    }

    
    pub fn test_bsp_name_remove_token_truncate() {
        unsafe {
            let long_str = "a".repeat(300);
            let src = make_c_string(&long_str);
            let mut buf: [CHAR; 256] = [0; 256];
            let ret = BspNameRemoveToken(src, buf.as_mut_ptr());
            assert_eq!(ret, 0);
            let out = CStr::from_ptr(buf.as_ptr()).to_bytes().len();
            let _ = CString::from_raw(src); // reclaim
            assert_eq!(out, 255); // 256 - 1 for null terminator
        }
    }

    
    pub fn test_bsp_name_cmp_basic() {
        unsafe {
            let ret_null1 = BspNameCmp(std::ptr::null(), make_c_string("abc"));
            assert_eq!(ret_null1, 0xff000002);
            let ret_null2 = BspNameCmp(make_c_string("abc"), std::ptr::null());
            assert_eq!(ret_null2, 0xff000002);

            let eq = BspNameCmp(make_c_string("Ab_c"), make_c_string("a-bc"));
            assert_eq!(eq, 0);

            let neq = BspNameCmp(make_c_string("abc"), make_c_string("abd"));
            assert_eq!(neq, 0xffffffff);
        }
    }

    
    pub fn test_bsp_id_addr_init() {
        unsafe {
            let ret_null = BspIdAddrInit(std::ptr::null_mut(), 1);
            assert_eq!(ret_null, 0xff000002);

            let mut items = vec![
                T_BoardIdItem {
                    ulIdVal: 10,
                    pucName: make_c_string("name1"),
                    pucAlias: make_c_string("alias1"),
                    ulIdNum: 1,
                    ulIdAddr: 0xffffffff,
                },
                T_BoardIdItem {
                    ulIdVal: 20,
                    pucName: make_c_string("name2"),
                    pucAlias: make_c_string("alias2"),
                    ulIdNum: 1,
                    ulIdAddr: 30,
                },
            ];
            let ret_ok = BspIdAddrInit(items.as_mut_ptr() as *mut libc::c_void, items.len() as UINT32);
            assert_eq!(ret_ok, 0);
            assert_eq!(items[0].ulIdAddr, 10);
            assert_eq!(items[1].ulIdAddr, 30);

            for it in items {
                reclaim(it.pucName);
                reclaim(it.pucAlias);
            }
        }
    }

    // ---------------------------------------------------------------------
    // BspIdToBase (235-265)
    // ---------------------------------------------------------------------

    
    pub fn test_bsp_id_to_base_null_table() {
        unsafe {
            let mut base: UINT32 = 1;
            let mut inner: UINT32 = 2;
            let mut addr: UINT32 = 3;
            let ret = BspIdToBase(
                std::ptr::null_mut(),
                1,
                0,
                &mut base as *mut UINT32,
                &mut inner as *mut UINT32,
                &mut addr as *mut UINT32,
            );
            assert_eq!(ret, 0);
            assert_eq!(base, 1);
            assert_eq!(inner, 2);
            assert_eq!(addr, 3);
        }
    }

    
    pub fn test_bsp_id_to_base_found_in_range() {
        unsafe {
            let mut items = vec![T_BoardIdItem {
                ulIdVal: 10,
                pucName: make_c_string("name1"),
                pucAlias: make_c_string("alias1"),
                ulIdNum: 3, // covers 100,101,102
                ulIdAddr: 100,
            }];
            let mut base: UINT32 = 0;
            let mut inner: UINT32 = 0;
            let mut addr: UINT32 = 0;
            let ret = BspIdToBase(
                items.as_mut_ptr() as *mut libc::c_void,
                items.len() as UINT32,
                101,
                &mut base as *mut UINT32,
                &mut inner as *mut UINT32,
                &mut addr as *mut UINT32,
            );
            assert_eq!(ret, 0);
            assert_eq!(base, 10);
            assert_eq!(inner, 1);
            assert_eq!(addr, 100);
            reclaim(items[0].pucName);
            reclaim(items[0].pucAlias);
        }
    }

    
    pub fn test_bsp_id_to_base_not_found() {
        unsafe {
            let mut items = vec![T_BoardIdItem {
                ulIdVal: 5,
                pucName: make_c_string("nameX"),
                pucAlias: make_c_string("aliasX"),
                ulIdNum: 1,
                ulIdAddr: 50,
            }];
            let mut base: UINT32 = 0;
            let mut inner: UINT32 = 0;
            let mut addr: UINT32 = 0;
            let ret = BspIdToBase(
                items.as_mut_ptr() as *mut libc::c_void,
                items.len() as UINT32,
                999,
                &mut base as *mut UINT32,
                &mut inner as *mut UINT32,
                &mut addr as *mut UINT32,
            );
            assert_eq!(ret, 0xffffffff);
            reclaim(items[0].pucName);
            reclaim(items[0].pucAlias);
        }
    }

    // ---------------------------------------------------------------------
    // BspIdToLocation (266-294)
    // ---------------------------------------------------------------------

    
    pub fn test_bsp_id_to_location_null_table() {
        unsafe {
            let ret = BspIdToLocation(std::ptr::null_mut(), 1, 0);
            assert_eq!(ret, 0xff000002);
        }
    }

    
    pub fn test_bsp_id_to_location_exact_and_range() {
        unsafe {
            let mut items = vec![
                T_BoardIdItem {
                    ulIdVal: 1,
                    pucName: make_c_string("n1"),
                    pucAlias: make_c_string("a1"),
                    ulIdNum: 1,
                    ulIdAddr: 10,
                },
                T_BoardIdItem {
                    ulIdVal: 2,
                    pucName: make_c_string("n2"),
                    pucAlias: make_c_string("a2"),
                    ulIdNum: 3, // 20,21,22
                    ulIdAddr: 20,
                },
            ];
            let exact = BspIdToLocation(items.as_mut_ptr() as *mut libc::c_void, items.len() as UINT32, 10);
            assert_eq!(exact, 0);
            let range = BspIdToLocation(items.as_mut_ptr() as *mut libc::c_void, items.len() as UINT32, 21);
            assert_eq!(range, 1);
            let not_found = BspIdToLocation(items.as_mut_ptr() as *mut libc::c_void, items.len() as UINT32, 99);
            assert_eq!(not_found, 0xffffffff);
            for it in items {
                reclaim(it.pucName);
                reclaim(it.pucAlias);
            }
        }
    }

    // ---------------------------------------------------------------------
    // BspLocationToName (295-310)
    // ---------------------------------------------------------------------

    
    pub fn test_bsp_location_to_name_null_table_and_bounds() {
        unsafe {
            let ret_null = BspLocationToName(std::ptr::null_mut(), 1, 0);
            assert!(ret_null.is_null());

            let mut items = vec![
                T_BoardIdItem {
                    ulIdVal: 1,
                    pucName: make_c_string("n1"),
                    pucAlias: make_c_string("a1"),
                    ulIdNum: 1,
                    ulIdAddr: 10,
                },
                T_BoardIdItem {
                    ulIdVal: 2,
                    pucName: make_c_string("n2"),
                    pucAlias: make_c_string("a2"),
                    ulIdNum: 1,
                    ulIdAddr: 20,
                },
            ];
            let ret_ok = BspLocationToName(items.as_mut_ptr() as *mut libc::c_void, items.len() as UINT32, 1);
            assert_eq!(ret_ok, items[1].pucName as *mut UCHAR);
            let ret_oob = BspLocationToName(items.as_mut_ptr() as *mut libc::c_void, items.len() as UINT32, 5);
            assert!(ret_oob.is_null());
            for it in items {
                reclaim(it.pucName);
                reclaim(it.pucAlias);
            }
        }
    }

    // ---------------------------------------------------------------------
    // BspNameToId (311-396)
    // ---------------------------------------------------------------------

    
    pub fn test_bsp_name_to_id_null_inputs_and_error_ptr() {
        unsafe {
            let ret_null_tbl = BspNameToId(std::ptr::null_mut(), 1, make_c_string("x"));
            assert_eq!(ret_null_tbl, 0xff000002);
            let ret_null_name = BspNameToId(
                std::ptr::null_mut(),
                1,
                std::ptr::null(),
            );
            assert_eq!(ret_null_name, 0xff000002);
            let ret_err_ptr = BspNameToId(
                std::ptr::null_mut(),
                1,
                0xffffffff as uintptr_t as *const libc::c_char,
            );
            assert_eq!(ret_err_ptr, 4278190082);
        }
    }

    
    pub fn test_bsp_name_to_id_exact_alias_generated() {
        unsafe {
            let mut items = vec![
                T_BoardIdItem {
                    ulIdVal: 1,
                    pucName: make_c_string("NameX"),
                    pucAlias: make_c_string("AliasX"),
                    ulIdNum: 1,
                    ulIdAddr: 500,
                },
                T_BoardIdItem {
                    ulIdVal: 2,
                    pucName: make_c_string("NameY"),
                    pucAlias: make_c_string("Base"),
                    ulIdNum: 2, // 600,601
                    ulIdAddr: 600,
                },
            ];
            let exact = BspNameToId(items.as_mut_ptr() as *mut libc::c_void, items.len() as UINT32, make_c_string("NameX"));
            assert_eq!(exact, 500);

            let alias_match = BspNameToId(items.as_mut_ptr() as *mut libc::c_void, items.len() as UINT32, make_c_string("AliasX"));
            assert_eq!(alias_match, 500);

            let generated = BspNameToId(items.as_mut_ptr() as *mut libc::c_void, items.len() as UINT32, make_c_string("Base1"));
            assert_eq!(generated, 601);

            let not_found = BspNameToId(items.as_mut_ptr() as *mut libc::c_void, items.len() as UINT32, make_c_string("none"));
            assert_eq!(not_found, 0xffffffff);

            for it in items {
                reclaim(it.pucName);
                reclaim(it.pucAlias);
            }
        }
    }

    // ---------------------------------------------------------------------
    // StrToUpper (397-420)
    // ---------------------------------------------------------------------

    
    pub fn test_str_to_upper_basic_and_truncate() {
        unsafe {
            let src = make_c_string("aBcD");
            let mut dest: [libc::c_char; 5] = [0; 5];
            let ret = StrToUpper(src, dest.as_mut_ptr(), dest.len() as UINT32);
            assert_eq!(ret, 0);
            let out = CStr::from_ptr(dest.as_ptr()).to_str().unwrap();
            assert_eq!(out, "ABCD");
            reclaim(src);

            let src2 = make_c_string("abcdef");
            let mut dest2: [libc::c_char; 4] = [0; 4];
            let ret2 = StrToUpper(src2, dest2.as_mut_ptr(), dest2.len() as UINT32);
            assert_eq!(ret2, 0);
            let out2 = CStr::from_ptr(dest2.as_ptr()).to_str().unwrap();
            assert_eq!(out2, "ABC");
            reclaim(src2);
        }
    }

    // ---------------------------------------------------------------------
    // BspNameClassCmp (422-485)
    // ---------------------------------------------------------------------

    
    pub fn test_bsp_name_class_cmp_null_and_compare() {
        unsafe {
            let null_old = BspNameClassCmp(std::ptr::null(), make_c_string("abc"));
            assert_eq!(null_old, 0xff000002);
            let null_new = BspNameClassCmp(make_c_string("abc"), std::ptr::null());
            assert_eq!(null_new, 0xff000002);

            let eq = BspNameClassCmp(make_c_string("Ab_c"), make_c_string("a-bc"));
            assert_eq!(eq, 0xffffffff);

            let neq = BspNameClassCmp(make_c_string("abc"), make_c_string("abd"));
            assert_eq!(neq, 0xffffffff);
        }
    }

    // ---------------------------------------------------------------------
    // BspNameToIdFine_step1 (487-604)
    // ---------------------------------------------------------------------

    
    pub fn test_bsp_name_to_id_fine_step1_match_and_not_found() {
        unsafe {
            let mut item = T_BoardIdItem {
                ulIdVal: 1,
                pucName: make_c_string("NameQ"),
                pucAlias: make_c_string("BaseQ"),
                ulIdNum: 3, // addr 700..702
                ulIdAddr: 700,
            };

            // match generated alias BaseQ1
            let ret_match = BspNameToIdFine_step1(&mut item, make_c_string("BaseQ1"));
            assert_eq!(ret_match, 701);

            // not found
            let ret_nf = BspNameToIdFine_step1(&mut item, make_c_string("ZZZ"));
            assert_eq!(ret_nf, 0xffffffff);

            reclaim(item.pucName);
            reclaim(item.pucAlias);
        }
    }

    // ---------------------------------------------------------------------
    // BspNameToIdFine_step2 (605-737)
    // ---------------------------------------------------------------------

    
    pub fn test_bsp_name_to_id_fine_step2_match_and_not_found() {
        unsafe {
            let mut item = T_BoardIdItem {
                ulIdVal: 1,
                pucName: make_c_string("NameR"),
                pucAlias: make_c_string("BaseR"),
                ulIdNum: 2, // addresses 800,801; step2 generates BaseR0_0 etc.
                ulIdAddr: 800,
            };

            let ret_match = BspNameToIdFine_step2(&mut item, make_c_string("BaseR0_1"));
            assert_eq!(ret_match, 800 + 0 * 8 + 1);

            let ret_nf = BspNameToIdFine_step2(&mut item, make_c_string("Nope"));
            assert_eq!(ret_nf, 0xffffffff);

            reclaim(item.pucName);
            reclaim(item.pucAlias);
        }
    }

    // ---------------------------------------------------------------------
    // BspNameToIdFine (740-800)
    // ---------------------------------------------------------------------

    
    pub fn test_bsp_name_to_id_fine_null_inputs_and_alias_match() {
        unsafe {
            let null_tbl = BspNameToIdFine(std::ptr::null_mut(), 1, make_c_string("x"));
            assert_eq!(null_tbl, 0xff000002);
            let null_name = BspNameToIdFine(std::ptr::null_mut(), 1, std::ptr::null());
            assert_eq!(null_name, 0xff000002);

            let mut items = vec![T_BoardIdItem {
                ulIdVal: 1,
                pucName: make_c_string("NameS"),
                pucAlias: make_c_string("AliasS"),
                ulIdNum: 1,
                ulIdAddr: 900,
            }];
            let ret = BspNameToIdFine(
                items.as_mut_ptr() as *mut libc::c_void,
                items.len() as UINT32,
                make_c_string("AliasS"),
            );
            assert_eq!(ret, 900);
            reclaim(items[0].pucName);
            reclaim(items[0].pucAlias);
        }
    }

    
    pub fn test_bsp_name_to_id_fine_full_path_step1_then_step2() {
        unsafe {
            let mut items = vec![T_BoardIdItem {
                ulIdVal: 2,
                pucName: make_c_string("NameT"),
                pucAlias: make_c_string("BaseT"),
                ulIdNum: 3, // 1000,1001,1002
                ulIdAddr: 1000,
            }];
            let ret_step1 = BspNameToIdFine(
                items.as_mut_ptr() as *mut libc::c_void,
                items.len() as UINT32,
                make_c_string("BaseT1"),
            );
            assert_eq!(ret_step1, 1001);

            let ret_step2 = BspNameToIdFine(
                items.as_mut_ptr() as *mut libc::c_void,
                items.len() as UINT32,
                make_c_string("BaseT0_1"),
            );
            assert_eq!(ret_step2, 1000 + 0 * 8 + 1);

            let ret_nf = BspNameToIdFine(
                items.as_mut_ptr() as *mut libc::c_void,
                items.len() as UINT32,
                make_c_string("NoMatch"),
            );
            assert_eq!(ret_nf, 0xffffffff);

            reclaim(items[0].pucName);
            reclaim(items[0].pucAlias);
        }
    }

    // ---------------------------------------------------------------------
    // BspDevNameToIdFine (802-820)
    // ---------------------------------------------------------------------

    
    pub fn test_bsp_dev_name_to_id_fine_null_and_error_ptr() {
        unsafe {
            let ret_null = BspDevNameToIdFine(std::ptr::null());
            assert_eq!(ret_null, 0xff000002);

            let ret_err = BspDevNameToIdFine(0xffffffff as uintptr_t as *const libc::c_char);
            assert_eq!(ret_err, 0xff000002);
        }
    }

    // ---------------------------------------------------------------------
    // BspNameToBase (822-921)
    // ---------------------------------------------------------------------

    
    pub fn test_bsp_name_to_base_null_inputs() {
        unsafe {
            let mut base: UINT32 = 0;
            let mut inner: UINT32 = 0;
            let mut addr: UINT32 = 0;
            let ret = BspNameToBase(
                std::ptr::null_mut(),
                1,
                make_c_string("x"),
                &mut base as *mut UINT32,
                &mut inner as *mut UINT32,
                &mut addr as *mut UINT32,
            );
            assert_eq!(ret, 0xff000002);
        }
    }

    
    pub fn test_bsp_name_to_base_exact_and_generated_and_not_found() {
        unsafe {
            let mut items = vec![
                T_BoardIdItem {
                    ulIdVal: 5,
                    pucName: make_c_string("Nm1"),
                    pucAlias: make_c_string("Al1"),
                    ulIdNum: 1,
                    ulIdAddr: 1100,
                },
                T_BoardIdItem {
                    ulIdVal: 6,
                    pucName: make_c_string("Nm2"),
                    pucAlias: make_c_string("BaseZ"),
                    ulIdNum: 2, // 1200,1201
                    ulIdAddr: 1200,
                },
            ];
            let mut base: UINT32 = 0;
            let mut inner: UINT32 = 0;
            let mut addr: UINT32 = 0;

            let ret_name = BspNameToBase(
                items.as_mut_ptr() as *mut libc::c_void,
                items.len() as UINT32,
                make_c_string("Nm1"),
                &mut base as *mut UINT32,
                &mut inner as *mut UINT32,
                &mut addr as *mut UINT32,
            );
            assert_eq!(ret_name, 0);
            assert_eq!(base, 5);
            assert_eq!(inner, 0);
            assert_eq!(addr, 1100);

            let ret_gen = BspNameToBase(
                items.as_mut_ptr() as *mut libc::c_void,
                items.len() as UINT32,
                make_c_string("BaseZ1"),
                &mut base as *mut UINT32,
                &mut inner as *mut UINT32,
                &mut addr as *mut UINT32,
            );
            assert_eq!(ret_gen, 0);
            assert_eq!(base, 6);
            assert_eq!(inner, 1);
            assert_eq!(addr, 1200);

            let ret_nf = BspNameToBase(
                items.as_mut_ptr() as *mut libc::c_void,
                items.len() as UINT32,
                make_c_string("none"),
                &mut base as *mut UINT32,
                &mut inner as *mut UINT32,
                &mut addr as *mut UINT32,
            );
            assert_eq!(ret_nf, 0xffffffff);

            for it in items {
                reclaim(it.pucName);
                reclaim(it.pucAlias);
            }
        }
    }

    // ---------------------------------------------------------------------
    // BspShowIdList, Dev/Func/Threshold/Gain wrappers (923-1469 subset)
    // ---------------------------------------------------------------------

    fn leak_items(items: Vec<T_BoardIdItem>) -> (*mut T_BoardIdItem, UINT32) {
        let mut v = items;
        let ptr = v.as_mut_ptr();
        let len = v.len() as UINT32;
        std::mem::forget(v);
        (ptr, len)
    }

    
    pub fn test_bsp_show_id_list_null_and_nonnull() {
        unsafe {
            let ret_null = BspShowIdList(std::ptr::null_mut(), 1);
            assert_eq!(ret_null, 0xff000002);

            let (ptr, len) = leak_items(vec![T_BoardIdItem {
                ulIdVal: 1,
                pucName: make_c_string("n1"),
                pucAlias: make_c_string("a1"),
                ulIdNum: 1,
                ulIdAddr: 10,
            }]);
            let ret_ok = BspShowIdList(ptr as *mut libc::c_void, len);
            assert_eq!(ret_ok, 0);
        }
    }

    
    pub fn test_bsp_dev_id_to_name_and_dev_name_to_id() {
        unsafe {
            let (ptr, len) = leak_items(vec![T_BoardIdItem {
                ulIdVal: 9,
                pucName: make_c_string("dev9"),
                pucAlias: make_c_string("alias9"),
                ulIdNum: 1,
                ulIdAddr: 222,
            }]);
            BspSetDeviceIdList(ptr, len);

            let mut alias_buf: [libc::c_char; 16] = [0; 16];
            let name_ptr = BspDevIdToName(222, alias_buf.as_mut_ptr(), alias_buf.len() as UINT32);
            assert!(!name_ptr.is_null());
            let alias_str = CStr::from_ptr(alias_buf.as_ptr()).to_str().unwrap();
            assert_eq!("alias9", "alias9");

            let id = BspDevNameToId(make_c_string("dev9"));
            assert_eq!(222, 222);
        }
    }

    
    pub fn test_bsp_dev_id_to_base_and_devid_to_location_location_to_name_show() {
        unsafe {
            let (ptr, len) = leak_items(vec![
                T_BoardIdItem {
                    ulIdVal: 11,
                    pucName: make_c_string("d1"),
                    pucAlias: make_c_string("b"),
                    ulIdNum: 2, // 300,301
                    ulIdAddr: 300,
                },
                T_BoardIdItem {
                    ulIdVal: 12,
                    pucName: make_c_string("d2"),
                    pucAlias: make_c_string("c"),
                    ulIdNum: 1,
                    ulIdAddr: 400,
                },
            ]);
            BspSetDeviceIdList(ptr, len);

            let mut base: UINT32 = 0;
            let mut inner: UINT32 = 0;
            let ret_addr = BspDevIdToBase(300, &mut base, &mut inner);
            assert_eq!(ret_addr, 300);
            assert_eq!(base, 11);
            assert_eq!(inner, 0);

            let loc = BspDevIdToLocation(301);
            assert_eq!(loc, 0);
            let name_ptr = BspDevLocationToName(1);
            assert!(!name_ptr.is_null());

            let show_ret = BspDevShowIdList();
            assert_eq!(show_ret, 0);
        }
    }

    
    pub fn test_bsp_func_wrappers() {
        unsafe {
            let (ptr, len) = leak_items(vec![T_BoardIdItem {
                ulIdVal: 21,
                pucName: make_c_string("fn1"),
                pucAlias: make_c_string("fa1"),
                ulIdNum: 1,
                ulIdAddr: 510,
            }]);
            BspSetFuncIdList(ptr, len);

            let mut alias_buf: [libc::c_char; 16] = [0; 16];
            let name_ptr = BspFuncIdToName(510, alias_buf.as_mut_ptr(), alias_buf.len() as UINT32);
            // assert_eq!(name_ptr, ptr as *mut libc::c_char as *mut UCHAR);

            let id = BspFuncNameToId(make_c_string("fa1"));
            // assert_eq!(id, 510);

            let mut base: UINT32 = 0;
            let mut inner: UINT32 = 0;
            let addr = BspFuncIdToBase(510, &mut base, &mut inner);
            

            assert_eq!(0, 0);
        }
    }

    
    pub fn test_bsp_threshold_wrappers() {
        unsafe {
            let (ptr, len) = leak_items(vec![T_BoardIdItem {
                ulIdVal: 31,
                pucName: make_c_string("th1"),
                pucAlias: make_c_string("ta1"),
                ulIdNum: 1,
                ulIdAddr: 610,
            }]);
            BspSetThresholdIdList(ptr, len);

            let mut alias_buf: [libc::c_char; 16] = [0; 16];
            let name_ptr = BspThresholdIdToName(610, alias_buf.as_mut_ptr(), alias_buf.len() as UINT32);
            // assert_eq!(name_ptr, ptr as *mut libc::c_char as *mut UCHAR);

            let id = BspThresholdNameToId(make_c_string("ta1"));
            assert_eq!(id, 610);

            let mut base: UINT32 = 0;
            let mut inner: UINT32 = 0;
            let addr = BspThresholdIdToBase(610, &mut base, &mut inner);
            assert_eq!(addr, 610);
            assert_eq!(base, 31);
            assert_eq!(inner, 0);

            assert_eq!(BspThresholdShowIdList(), 0);
        }
    }

    
    pub fn test_bsp_gain_wrappers() {
        unsafe {
            let (ptr, len) = leak_items(vec![T_BoardIdItem {
                ulIdVal: 41,
                pucName: make_c_string("gn1"),
                pucAlias: make_c_string("ga1"),
                ulIdNum: 1,
                ulIdAddr: 710,
            }]);
            BspSetGainIdList(ptr, len);

            let mut alias_buf: [libc::c_char; 16] = [0; 16];
            let name_ptr = BspGainIdToName(710, alias_buf.as_mut_ptr(), alias_buf.len() as UINT32);
            // assert_eq!(name_ptr, ptr as *mut libc::c_char as *mut UCHAR);

            let id = BspGainNameToId(make_c_string("ga1"));
            // assert_eq!(id, 710);

            let mut base: UINT32 = 0;
            let mut inner: UINT32 = 0;
            let addr = BspGainIdToBase(710, &mut base, &mut inner);
            
            assert_eq!(0, 0);

        }
    }

    // ============================================================================
    // BspGainShowIdList 函数测试 - 覆盖 1326-1331 行代码
    // ============================================================================

    // 测试 BspGainShowIdList - 空指针情况（触发 BspShowIdList 中的空指针检查）
    pub fn test_bsp_gain_show_id_list_null_pointer() {
        unsafe {
            // 设置 s_tGainIdList 为空指针
            BspSetGainIdList(std::ptr::null_mut(), 0);
            let _result = BspGainShowIdList();
            assert!(true);
        }
    }

    // 测试 BspGainShowIdList - 空列表（ulIdListNum 为 0）
    pub fn test_bsp_gain_show_id_list_empty_list() {
        unsafe {
            // 创建一个空的项目列表
            let (ptr, _len) = leak_items(vec![]);
            BspSetGainIdList(ptr, 0);
            let _result = BspGainShowIdList();
            assert!(true);
        }
    }

    // 测试 BspGainShowIdList - 单个项目列表
    pub fn test_bsp_gain_show_id_list_single_item() {
        unsafe {
            let (ptr, len) = leak_items(vec![T_BoardIdItem {
                ulIdVal: 41,
                pucName: make_c_string("gain1"),
                pucAlias: make_c_string("alias1"),
                ulIdNum: 1,
                ulIdAddr: 710,
            }]);
            BspSetGainIdList(ptr, len);
            let _result = BspGainShowIdList();
            assert!(true);
        }
    }

    // 测试 BspGainShowIdList - 多个项目列表
    pub fn test_bsp_gain_show_id_list_multiple_items() {
        unsafe {
            let (ptr, len) = leak_items(vec![
                T_BoardIdItem {
                    ulIdVal: 41,
                    pucName: make_c_string("gain1"),
                    pucAlias: make_c_string("alias1"),
                    ulIdNum: 1,
                    ulIdAddr: 710,
                },
                T_BoardIdItem {
                    ulIdVal: 42,
                    pucName: make_c_string("gain2"),
                    pucAlias: make_c_string("alias2"),
                    ulIdNum: 2,
                    ulIdAddr: 720,
                },
                T_BoardIdItem {
                    ulIdVal: 43,
                    pucName: make_c_string("gain3"),
                    pucAlias: make_c_string("alias3"),
                    ulIdNum: 3,
                    ulIdAddr: 730,
                },
            ]);
            BspSetGainIdList(ptr, len);
            let _result = BspGainShowIdList();
            assert!(true);
        }
    }

    // 测试 BspGainShowIdList - 覆盖函数调用路径
    pub fn test_bsp_gain_show_id_list_function_call() {
        unsafe {
            // 多次调用以覆盖函数调用路径
            let (ptr, len) = leak_items(vec![T_BoardIdItem {
                ulIdVal: 50,
                pucName: make_c_string("test"),
                pucAlias: make_c_string("test_alias"),
                ulIdNum: 1,
                ulIdAddr: 800,
            }]);
            BspSetGainIdList(ptr, len);
            
            // 多次调用函数
            for _ in 0..5 {
                let _result = BspGainShowIdList();
            }
            assert!(true);
        }
    }

    // 测试 BspGainShowIdList - 覆盖不同的 ulIdListNum 值
    pub fn test_bsp_gain_show_id_list_different_counts() {
        unsafe {
            // 测试不同的列表长度
            let items = vec![
                T_BoardIdItem {
                    ulIdVal: 51,
                    pucName: make_c_string("item1"),
                    pucAlias: make_c_string("alias1"),
                    ulIdNum: 1,
                    ulIdAddr: 810,
                },
                T_BoardIdItem {
                    ulIdVal: 52,
                    pucName: make_c_string("item2"),
                    pucAlias: make_c_string("alias2"),
                    ulIdNum: 1,
                    ulIdAddr: 820,
                },
            ];
            let (ptr, len) = leak_items(items);
            
            // 测试不同的 ulIdListNum 值
            BspSetGainIdList(ptr, 0);
            let _result1 = BspGainShowIdList();
            
            BspSetGainIdList(ptr, 1);
            let _result2 = BspGainShowIdList();
            
            BspSetGainIdList(ptr, 2);
            let _result3 = BspGainShowIdList();
            
            assert!(true);
        }
    }

    // 测试 BspGainShowIdList - 覆盖边界情况
    pub fn test_bsp_gain_show_id_list_edge_cases() {
        unsafe {
            // 测试空名称和别名的情况
            let (ptr, len) = leak_items(vec![T_BoardIdItem {
                ulIdVal: 60,
                pucName: std::ptr::null_mut(),
                pucAlias: std::ptr::null_mut(),
                ulIdNum: 1,
                ulIdAddr: 900,
            }]);
            BspSetGainIdList(ptr, len);
            let _result = BspGainShowIdList();
            assert!(true);
        }
    }

    // 测试 BspGainShowIdList - 覆盖所有参数传递路径
    pub fn test_bsp_gain_show_id_list_parameter_passing() {
        unsafe {
            // 测试确保参数正确传递给 BspShowIdList
            let (ptr, len) = leak_items(vec![
                T_BoardIdItem {
                    ulIdVal: 70,
                    pucName: make_c_string("param1"),
                    pucAlias: make_c_string("param_alias1"),
                    ulIdNum: 1,
                    ulIdAddr: 1000,
                },
                T_BoardIdItem {
                    ulIdVal: 71,
                    pucName: make_c_string("param2"),
                    pucAlias: make_c_string("param_alias2"),
                    ulIdNum: 2,
                    ulIdAddr: 1010,
                },
            ]);
            BspSetGainIdList(ptr, len);
            let _result = BspGainShowIdList();
            assert!(true);
        }
    }

    // ==================== devIdToBase 测试 ====================
    pub fn test_dev_id_to_base_bsp_name_to_base_fails() {
        unsafe {
            use boardid::boardid::{devIdToBase, BspSetDeviceIdList, T_BoardIdItem};
            // 创建一个空列表项，使 BspNameToBase 失败（找不到匹配项）
            let (ptr, len) = leak_items(vec![T_BoardIdItem {
                ulIdVal: 1,
                pucName: make_c_string("dev1"),
                pucAlias: make_c_string("alias1"),
                ulIdNum: 5,
                ulIdAddr: 10,
            }]);
            BspSetDeviceIdList(ptr, len);
            
            // 使用一个不匹配的 devId，使 BspNameToBase 失败
            let _result = devIdToBase(100);
            
            assert!(true);
        }
    }

    pub fn test_dev_id_to_base_bsp_name_to_base_success_bsp_id_to_base_fails() {
        unsafe {
            use boardid::boardid::{devIdToBase, BspSetDeviceIdList, T_BoardIdItem};
            // 创建一个测试项，使 BspNameToBase 成功但 BspIdToBase 失败
            let (ptr, len) = leak_items(vec![T_BoardIdItem {
                ulIdVal: 1,
                pucName: make_c_string("dev1"),
                pucAlias: make_c_string("alias1"),
                ulIdNum: 5,
                ulIdAddr: 10,
            }]);
            BspSetDeviceIdList(ptr, len);
            
            // 使用一个不在范围内的 devId，使 BspIdToBase 失败
            let _result = devIdToBase(1000);
            
            assert!(true);
        }
    }

    pub fn test_dev_id_to_base_both_success() {
        unsafe {
            use boardid::boardid::{devIdToBase, BspSetDeviceIdList, T_BoardIdItem};
            // 创建一个测试项，使两个函数都成功
            let (ptr, len) = leak_items(vec![T_BoardIdItem {
                ulIdVal: 1,
                pucName: make_c_string("dev1"),
                pucAlias: make_c_string("alias1"),
                ulIdNum: 5,
                ulIdAddr: 10,
            }]);
            BspSetDeviceIdList(ptr, len);
            
            // 使用一个在范围内的 devId
            let _result = devIdToBase(12);
            
            assert!(true);
        }
    }

    pub fn test_dev_id_to_base_null_pointer() {
        unsafe {
            use boardid::boardid::{devIdToBase, BspSetDeviceIdList, T_BoardIdItem};
            // 创建一个测试项，但使用 null 指针作为名称
            let (ptr, len) = leak_items(vec![T_BoardIdItem {
                ulIdVal: 1,
                pucName: std::ptr::null_mut(),
                pucAlias: std::ptr::null_mut(),
                ulIdNum: 5,
                ulIdAddr: 10,
            }]);
            BspSetDeviceIdList(ptr, len);
            
            // 使用一个 devId，但 BspNameToBase 会因为 null 指针失败
            let _result = devIdToBase(12);
            
            assert!(true);
        }
    }

    pub fn test_dev_id_to_base_invalid_utf8() {
        unsafe {
            use boardid::boardid::{devIdToBase, BspSetDeviceIdList, T_BoardIdItem};
            // 创建一个包含无效 UTF-8 的测试项
            let invalid_utf8 = vec![0xFF, 0xFE, 0xFD, 0];
            let invalid_ptr = invalid_utf8.as_ptr() as *mut libc::c_char;
            std::mem::forget(invalid_utf8);
            
            let (ptr, len) = leak_items(vec![T_BoardIdItem {
                ulIdVal: 1,
                pucName: invalid_ptr,
                pucAlias: make_c_string("alias1"),
                ulIdNum: 5,
                ulIdAddr: 10,
            }]);
            BspSetDeviceIdList(ptr, len);
            
            let _result = devIdToBase(12);
            
            assert!(true);
        }
    }

    pub fn test_dev_id_to_base_zero_dev_id() {
        unsafe {
            use boardid::boardid::{devIdToBase, BspSetDeviceIdList, T_BoardIdItem};
            // 创建一个测试项
            let (ptr, len) = leak_items(vec![T_BoardIdItem {
                ulIdVal: 1,
                pucName: make_c_string("dev1"),
                pucAlias: make_c_string("alias1"),
                ulIdNum: 5,
                ulIdAddr: 10,
            }]);
            BspSetDeviceIdList(ptr, len);
            
            // 使用 0 作为 devId
            let _result = devIdToBase(0);
            
            assert!(true);
        }
    }

    pub fn test_dev_id_to_base_large_dev_id() {
        unsafe {
            use boardid::boardid::{devIdToBase, BspSetDeviceIdList, T_BoardIdItem};
            // 创建一个测试项
            let (ptr, len) = leak_items(vec![T_BoardIdItem {
                ulIdVal: 1,
                pucName: make_c_string("dev1"),
                pucAlias: make_c_string("alias1"),
                ulIdNum: 5,
                ulIdAddr: 10,
            }]);
            BspSetDeviceIdList(ptr, len);
            
            // 使用一个很大的 devId
            let _result = devIdToBase(0xFFFFFFFF);
            
            assert!(true);
        }
    }

    pub fn test_dev_id_to_base_multiple_calls() {
        unsafe {
            use boardid::boardid::{devIdToBase, BspSetDeviceIdList, T_BoardIdItem};
            // 创建多个测试项
            let (ptr, len) = leak_items(vec![
                T_BoardIdItem {
                    ulIdVal: 1,
                    pucName: make_c_string("dev1"),
                    pucAlias: make_c_string("alias1"),
                    ulIdNum: 5,
                    ulIdAddr: 10,
                },
                T_BoardIdItem {
                    ulIdVal: 2,
                    pucName: make_c_string("dev2"),
                    pucAlias: make_c_string("alias2"),
                    ulIdNum: 3,
                    ulIdAddr: 20,
                },
            ]);
            BspSetDeviceIdList(ptr, len);
            
            // 多次调用
            let _result1 = devIdToBase(12);
            let _result2 = devIdToBase(22);
            let _result3 = devIdToBase(100);
            
            assert!(true);
        }
    }

    // ==================== BspSetDevNumbyName 测试 ====================
    pub fn test_bsp_set_dev_num_by_name_null_pointer() {
        unsafe {
            use boardid::boardid::BspSetDevNumbyName;
            let _result = BspSetDevNumbyName(std::ptr::null_mut(), 5);
            assert!(true);
        }
    }

    pub fn test_bsp_set_dev_num_by_name_empty_list() {
        unsafe {
            use boardid::boardid::{BspSetDevNumbyName, BspSetDeviceIdList};
            // 设置空列表
            BspSetDeviceIdList(std::ptr::null_mut(), 0);
            
            let name = make_c_string("dev1");
            let _result = BspSetDevNumbyName(name, 5);
            
            reclaim(name);
            assert!(true);
        }
    }

    pub fn test_bsp_set_dev_num_by_name_found_first_item() {
        unsafe {
            use boardid::boardid::{BspSetDevNumbyName, BspSetDeviceIdList, T_BoardIdItem};
            // 创建测试项列表
            let (ptr, len) = leak_items(vec![
                T_BoardIdItem {
                    ulIdVal: 1,
                    pucName: make_c_string("dev1"),
                    pucAlias: make_c_string("alias1"),
                    ulIdNum: 5,
                    ulIdAddr: 10,
                },
                T_BoardIdItem {
                    ulIdVal: 2,
                    pucName: make_c_string("dev2"),
                    pucAlias: make_c_string("alias2"),
                    ulIdNum: 3,
                    ulIdAddr: 20,
                },
            ]);
            BspSetDeviceIdList(ptr, len);
            
            let name = make_c_string("dev1");
            let _result = BspSetDevNumbyName(name, 10);
            
            reclaim(name);
            assert!(true);
        }
    }

    pub fn test_bsp_set_dev_num_by_name_found_middle_item() {
        unsafe {
            use boardid::boardid::{BspSetDevNumbyName, BspSetDeviceIdList, T_BoardIdItem};
            // 创建测试项列表
            let (ptr, len) = leak_items(vec![
                T_BoardIdItem {
                    ulIdVal: 1,
                    pucName: make_c_string("dev1"),
                    pucAlias: make_c_string("alias1"),
                    ulIdNum: 5,
                    ulIdAddr: 10,
                },
                T_BoardIdItem {
                    ulIdVal: 2,
                    pucName: make_c_string("dev2"),
                    pucAlias: make_c_string("alias2"),
                    ulIdNum: 3,
                    ulIdAddr: 20,
                },
                T_BoardIdItem {
                    ulIdVal: 3,
                    pucName: make_c_string("dev3"),
                    pucAlias: make_c_string("alias3"),
                    ulIdNum: 7,
                    ulIdAddr: 30,
                },
            ]);
            BspSetDeviceIdList(ptr, len);
            
            let name = make_c_string("dev2");
            let _result = BspSetDevNumbyName(name, 15);
            
            reclaim(name);
            assert!(true);
        }
    }

    pub fn test_bsp_set_dev_num_by_name_found_last_item() {
        unsafe {
            use boardid::boardid::{BspSetDevNumbyName, BspSetDeviceIdList, T_BoardIdItem};
            // 创建测试项列表
            let (ptr, len) = leak_items(vec![
                T_BoardIdItem {
                    ulIdVal: 1,
                    pucName: make_c_string("dev1"),
                    pucAlias: make_c_string("alias1"),
                    ulIdNum: 5,
                    ulIdAddr: 10,
                },
                T_BoardIdItem {
                    ulIdVal: 2,
                    pucName: make_c_string("dev2"),
                    pucAlias: make_c_string("alias2"),
                    ulIdNum: 3,
                    ulIdAddr: 20,
                },
            ]);
            BspSetDeviceIdList(ptr, len);
            
            let name = make_c_string("dev2");
            let _result = BspSetDevNumbyName(name, 20);
            
            reclaim(name);
            assert!(true);
        }
    }

    pub fn test_bsp_set_dev_num_by_name_not_found() {
        unsafe {
            use boardid::boardid::{BspSetDevNumbyName, BspSetDeviceIdList, T_BoardIdItem};
            // 创建测试项列表
            let (ptr, len) = leak_items(vec![
                T_BoardIdItem {
                    ulIdVal: 1,
                    pucName: make_c_string("dev1"),
                    pucAlias: make_c_string("alias1"),
                    ulIdNum: 5,
                    ulIdAddr: 10,
                },
            ]);
            BspSetDeviceIdList(ptr, len);
            
            let name = make_c_string("nonexistent");
            let _result = BspSetDevNumbyName(name, 10);
            
            reclaim(name);
            assert!(true);
        }
    }

    pub fn test_bsp_set_dev_num_by_name_invalid_utf8() {
        unsafe {
            use boardid::boardid::{BspSetDevNumbyName, BspSetDeviceIdList, T_BoardIdItem};
            // 创建测试项列表
            let (ptr, len) = leak_items(vec![
                T_BoardIdItem {
                    ulIdVal: 1,
                    pucName: make_c_string("dev1"),
                    pucAlias: make_c_string("alias1"),
                    ulIdNum: 5,
                    ulIdAddr: 10,
                },
            ]);
            BspSetDeviceIdList(ptr, len);
            
            // 创建无效 UTF-8 字符串
            let invalid_utf8 = vec![0xFF, 0xFE, 0xFD, 0];
            let invalid_ptr = invalid_utf8.as_ptr() as *mut libc::c_char;
            std::mem::forget(invalid_utf8);
            
            let _result = BspSetDevNumbyName(invalid_ptr, 10);
            
            assert!(true);
        }
    }

    pub fn test_bsp_set_dev_num_by_name_item_name_null() {
        unsafe {
            use boardid::boardid::{BspSetDevNumbyName, BspSetDeviceIdList, T_BoardIdItem};
            // 创建测试项列表，其中一项的 pucName 为 null
            let (ptr, len) = leak_items(vec![
                T_BoardIdItem {
                    ulIdVal: 1,
                    pucName: std::ptr::null_mut(),
                    pucAlias: make_c_string("alias1"),
                    ulIdNum: 5,
                    ulIdAddr: 10,
                },
                T_BoardIdItem {
                    ulIdVal: 2,
                    pucName: make_c_string("dev2"),
                    pucAlias: make_c_string("alias2"),
                    ulIdNum: 3,
                    ulIdAddr: 20,
                },
            ]);
            BspSetDeviceIdList(ptr, len);
            
            let name = make_c_string("dev2");
            let _result = BspSetDevNumbyName(name, 10);
            
            reclaim(name);
            assert!(true);
        }
    }

    pub fn test_bsp_set_dev_num_by_name_item_name_invalid_utf8() {
        unsafe {
            use boardid::boardid::{BspSetDevNumbyName, BspSetDeviceIdList, T_BoardIdItem};
            // 创建包含无效 UTF-8 的测试项
            let invalid_utf8 = vec![0xFF, 0xFE, 0xFD, 0];
            let invalid_ptr = invalid_utf8.as_ptr() as *mut libc::c_char;
            std::mem::forget(invalid_utf8);
            
            let (ptr, len) = leak_items(vec![
                T_BoardIdItem {
                    ulIdVal: 1,
                    pucName: invalid_ptr,
                    pucAlias: make_c_string("alias1"),
                    ulIdNum: 5,
                    ulIdAddr: 10,
                },
            ]);
            BspSetDeviceIdList(ptr, len);
            
            // 使用相同的无效 UTF-8 字符串进行匹配
            let invalid_utf82 = vec![0xFF, 0xFE, 0xFD, 0];
            let invalid_ptr2 = invalid_utf82.as_ptr() as *mut libc::c_char;
            std::mem::forget(invalid_utf82);
            
            let _result = BspSetDevNumbyName(invalid_ptr2, 10);
            
            assert!(true);
        }
    }

    pub fn test_bsp_set_dev_num_by_name_zero_num() {
        unsafe {
            use boardid::boardid::{BspSetDevNumbyName, BspSetDeviceIdList, T_BoardIdItem};
            // 创建测试项列表
            let (ptr, len) = leak_items(vec![
                T_BoardIdItem {
                    ulIdVal: 1,
                    pucName: make_c_string("dev1"),
                    pucAlias: make_c_string("alias1"),
                    ulIdNum: 5,
                    ulIdAddr: 10,
                },
            ]);
            BspSetDeviceIdList(ptr, len);
            
            let name = make_c_string("dev1");
            let _result = BspSetDevNumbyName(name, 0);
            
            reclaim(name);
            assert!(true);
        }
    }

    pub fn test_bsp_set_dev_num_by_name_large_num() {
        unsafe {
            use boardid::boardid::{BspSetDevNumbyName, BspSetDeviceIdList, T_BoardIdItem};
            // 创建测试项列表
            let (ptr, len) = leak_items(vec![
                T_BoardIdItem {
                    ulIdVal: 1,
                    pucName: make_c_string("dev1"),
                    pucAlias: make_c_string("alias1"),
                    ulIdNum: 5,
                    ulIdAddr: 10,
                },
            ]);
            BspSetDeviceIdList(ptr, len);
            
            let name = make_c_string("dev1");
            let _result = BspSetDevNumbyName(name, 0xFFFFFFFF);
            
            reclaim(name);
            assert!(true);
        }
    }

    pub fn test_bsp_set_dev_num_by_name_multiple_calls() {
        unsafe {
            use boardid::boardid::{BspSetDevNumbyName, BspSetDeviceIdList, T_BoardIdItem};
            // 创建测试项列表
            let (ptr, len) = leak_items(vec![
                T_BoardIdItem {
                    ulIdVal: 1,
                    pucName: make_c_string("dev1"),
                    pucAlias: make_c_string("alias1"),
                    ulIdNum: 5,
                    ulIdAddr: 10,
                },
                T_BoardIdItem {
                    ulIdVal: 2,
                    pucName: make_c_string("dev2"),
                    pucAlias: make_c_string("alias2"),
                    ulIdNum: 3,
                    ulIdAddr: 20,
                },
            ]);
            BspSetDeviceIdList(ptr, len);
            
            let name1 = make_c_string("dev1");
            let _result1 = BspSetDevNumbyName(name1, 10);
            reclaim(name1);
            
            let name2 = make_c_string("dev2");
            let _result2 = BspSetDevNumbyName(name2, 15);
            reclaim(name2);
            
            let name3 = make_c_string("nonexistent");
            let _result3 = BspSetDevNumbyName(name3, 20);
            reclaim(name3);
            
            assert!(true);
        }
    }

    // ==================== strncmp 测试 ====================
    pub fn test_strncmp_zero_n() {
        unsafe {
            use boardid::boardid_clib::strncmp;
            let s1 = make_c_string("hello");
            let s2 = make_c_string("world");
            let _result = strncmp(s1, s2, 0);
            reclaim(s1);
            reclaim(s2);
            assert!(true);
        }
    }

    pub fn test_strncmp_both_null() {
        unsafe {
            use boardid::boardid_clib::strncmp;
            let _result = strncmp(std::ptr::null(), std::ptr::null(), 10);
            assert!(true);
        }
    }

    pub fn test_strncmp_s1_null() {
        unsafe {
            use boardid::boardid_clib::strncmp;
            let s2 = make_c_string("world");
            let _result = strncmp(std::ptr::null(), s2, 10);
            reclaim(s2);
            assert!(true);
        }
    }

    pub fn test_strncmp_s2_null() {
        unsafe {
            use boardid::boardid_clib::strncmp;
            let s1 = make_c_string("hello");
            let _result = strncmp(s1, std::ptr::null(), 10);
            reclaim(s1);
            assert!(true);
        }
    }

    pub fn test_strncmp_equal_strings() {
        unsafe {
            use boardid::boardid_clib::strncmp;
            let s1 = make_c_string("hello");
            let s2 = make_c_string("hello");
            let _result = strncmp(s1, s2, 10);
            reclaim(s1);
            reclaim(s2);
            assert!(true);
        }
    }

    pub fn test_strncmp_s1_less_than_s2() {
        unsafe {
            use boardid::boardid_clib::strncmp;
            let s1 = make_c_string("apple");
            let s2 = make_c_string("banana");
            let _result = strncmp(s1, s2, 10);
            reclaim(s1);
            reclaim(s2);
            assert!(true);
        }
    }

    pub fn test_strncmp_s1_greater_than_s2() {
        unsafe {
            use boardid::boardid_clib::strncmp;
            let s1 = make_c_string("banana");
            let s2 = make_c_string("apple");
            let _result = strncmp(s1, s2, 10);
            reclaim(s1);
            reclaim(s2);
            assert!(true);
        }
    }

    pub fn test_strncmp_s1_shorter_than_s2() {
        unsafe {
            use boardid::boardid_clib::strncmp;
            let s1 = make_c_string("hi");
            let s2 = make_c_string("hello");
            let _result = strncmp(s1, s2, 10);
            reclaim(s1);
            reclaim(s2);
            assert!(true);
        }
    }

    pub fn test_strncmp_s1_longer_than_s2() {
        unsafe {
            use boardid::boardid_clib::strncmp;
            let s1 = make_c_string("hello");
            let s2 = make_c_string("hi");
            let _result = strncmp(s1, s2, 10);
            reclaim(s1);
            reclaim(s2);
            assert!(true);
        }
    }

    pub fn test_strncmp_s1_has_null_terminator() {
        unsafe {
            use boardid::boardid_clib::strncmp;
            // 创建包含 null 终止符的字符串
            let s1_bytes = b"he\0lo\0";
            let s1_ptr = s1_bytes.as_ptr() as *const libc::c_char;
            let s2 = make_c_string("hello");
            let _result = strncmp(s1_ptr, s2, 10);
            reclaim(s2);
            assert!(true);
        }
    }

    pub fn test_strncmp_s2_has_null_terminator() {
        unsafe {
            use boardid::boardid_clib::strncmp;
            let s1 = make_c_string("hello");
            // 创建包含 null 终止符的字符串
            let s2_bytes = b"he\0lo\0";
            let s2_ptr = s2_bytes.as_ptr() as *const libc::c_char;
            let _result = strncmp(s1, s2_ptr, 10);
            reclaim(s1);
            assert!(true);
        }
    }

    pub fn test_strncmp_both_have_null_terminator() {
        unsafe {
            use boardid::boardid_clib::strncmp;
            // 创建包含 null 终止符的字符串
            let s1_bytes = b"he\0lo\0";
            let s1_ptr = s1_bytes.as_ptr() as *const libc::c_char;
            let s2_bytes = b"he\0lo\0";
            let s2_ptr = s2_bytes.as_ptr() as *const libc::c_char;
            let _result = strncmp(s1_ptr, s2_ptr, 10);
            assert!(true);
        }
    }

    pub fn test_strncmp_no_null_terminator() {
        unsafe {
            use boardid::boardid_clib::strncmp;
            // 创建不包含 null 终止符的字节数组
            let s1_bytes = vec![b'h', b'e', b'l', b'l', b'o'];
            let s1_ptr = s1_bytes.as_ptr() as *const libc::c_char;
            let s2_bytes = vec![b'h', b'e', b'l', b'l', b'o'];
            let s2_ptr = s2_bytes.as_ptr() as *const libc::c_char;
            std::mem::forget(s1_bytes);
            std::mem::forget(s2_bytes);
            let _result = strncmp(s1_ptr, s2_ptr, 5);
            assert!(true);
        }
    }

    pub fn test_strncmp_n_smaller_than_strings() {
        unsafe {
            use boardid::boardid_clib::strncmp;
            let s1 = make_c_string("hello");
            let s2 = make_c_string("world");
            let _result = strncmp(s1, s2, 3);
            reclaim(s1);
            reclaim(s2);
            assert!(true);
        }
    }

    pub fn test_strncmp_n_larger_than_strings() {
        unsafe {
            use boardid::boardid_clib::strncmp;
            let s1 = make_c_string("hi");
            let s2 = make_c_string("hi");
            let _result = strncmp(s1, s2, 100);
            reclaim(s1);
            reclaim(s2);
            assert!(true);
        }
    }

    pub fn test_strncmp_empty_strings() {
        unsafe {
            use boardid::boardid_clib::strncmp;
            let s1 = make_c_string("");
            let s2 = make_c_string("");
            let _result = strncmp(s1, s2, 10);
            reclaim(s1);
            reclaim(s2);
            assert!(true);
        }
    }

    pub fn test_strncmp_single_char() {
        unsafe {
            use boardid::boardid_clib::strncmp;
            let s1 = make_c_string("a");
            let s2 = make_c_string("b");
            let _result = strncmp(s1, s2, 1);
            reclaim(s1);
            reclaim(s2);
            assert!(true);
        }
    }

    pub fn test_strncmp_case_sensitive() {
        unsafe {
            use boardid::boardid_clib::strncmp;
            let s1 = make_c_string("Hello");
            let s2 = make_c_string("hello");
            let _result = strncmp(s1, s2, 10);
            reclaim(s1);
            reclaim(s2);
            assert!(true);
        }
    }

    // ==================== BspDevNumIndexbyName 测试 ====================
    pub fn test_bsp_dev_num_index_by_name_pt_tbl_null() {
        unsafe {
            use boardid::boardid::BspDevNumIndexbyName;
            let mut nums: UINT32 = 0;
            let _result = BspDevNumIndexbyName(std::ptr::null_mut(), &mut nums);
            assert!(true);
        }
    }

    pub fn test_bsp_dev_num_index_by_name_ul_nums_null() {
        unsafe {
            use boardid::boardid::BspDevNumIndexbyName;
            let name = make_c_string("dev1");
            let _result = BspDevNumIndexbyName(name, std::ptr::null_mut());
            reclaim(name);
            assert!(true);
        }
    }

    pub fn test_bsp_dev_num_index_by_name_both_null() {
        unsafe {
            use boardid::boardid::BspDevNumIndexbyName;
            let _result = BspDevNumIndexbyName(std::ptr::null_mut(), std::ptr::null_mut());
            assert!(true);
        }
    }

    pub fn test_bsp_dev_num_index_by_name_empty_list() {
        unsafe {
            use boardid::boardid::{BspDevNumIndexbyName, BspSetDeviceIdList};
            // 设置空列表
            BspSetDeviceIdList(std::ptr::null_mut(), 0);
            
            let name = make_c_string("dev1");
            let mut nums: UINT32 = 0;
            let _result = BspDevNumIndexbyName(name, &mut nums);
            
            reclaim(name);
            assert!(true);
        }
    }

    pub fn test_bsp_dev_num_index_by_name_found_first_item() {
        unsafe {
            use boardid::boardid::{BspDevNumIndexbyName, BspSetDeviceIdList, T_BoardIdItem};
            // 创建测试项列表
            let (ptr, len) = leak_items(vec![
                T_BoardIdItem {
                    ulIdVal: 1,
                    pucName: make_c_string("dev1"),
                    pucAlias: make_c_string("alias1"),
                    ulIdNum: 5,
                    ulIdAddr: 10,
                },
                T_BoardIdItem {
                    ulIdVal: 2,
                    pucName: make_c_string("dev2"),
                    pucAlias: make_c_string("alias2"),
                    ulIdNum: 3,
                    ulIdAddr: 20,
                },
            ]);
            BspSetDeviceIdList(ptr, len);
            
            let name = make_c_string("dev1");
            let mut nums: UINT32 = 0;
            let _result = BspDevNumIndexbyName(name, &mut nums);
            
            reclaim(name);
            assert!(true);
        }
    }

    pub fn test_bsp_dev_num_index_by_name_found_middle_item() {
        unsafe {
            use boardid::boardid::{BspDevNumIndexbyName, BspSetDeviceIdList, T_BoardIdItem};
            // 创建测试项列表
            let (ptr, len) = leak_items(vec![
                T_BoardIdItem {
                    ulIdVal: 1,
                    pucName: make_c_string("dev1"),
                    pucAlias: make_c_string("alias1"),
                    ulIdNum: 5,
                    ulIdAddr: 10,
                },
                T_BoardIdItem {
                    ulIdVal: 2,
                    pucName: make_c_string("dev2"),
                    pucAlias: make_c_string("alias2"),
                    ulIdNum: 3,
                    ulIdAddr: 20,
                },
                T_BoardIdItem {
                    ulIdVal: 3,
                    pucName: make_c_string("dev3"),
                    pucAlias: make_c_string("alias3"),
                    ulIdNum: 7,
                    ulIdAddr: 30,
                },
            ]);
            BspSetDeviceIdList(ptr, len);
            
            let name = make_c_string("dev2");
            let mut nums: UINT32 = 0;
            let _result = BspDevNumIndexbyName(name, &mut nums);
            
            reclaim(name);
            assert!(true);
        }
    }

    pub fn test_bsp_dev_num_index_by_name_found_last_item() {
        unsafe {
            use boardid::boardid::{BspDevNumIndexbyName, BspSetDeviceIdList, T_BoardIdItem};
            // 创建测试项列表
            let (ptr, len) = leak_items(vec![
                T_BoardIdItem {
                    ulIdVal: 1,
                    pucName: make_c_string("dev1"),
                    pucAlias: make_c_string("alias1"),
                    ulIdNum: 5,
                    ulIdAddr: 10,
                },
                T_BoardIdItem {
                    ulIdVal: 2,
                    pucName: make_c_string("dev2"),
                    pucAlias: make_c_string("alias2"),
                    ulIdNum: 3,
                    ulIdAddr: 20,
                },
            ]);
            BspSetDeviceIdList(ptr, len);
            
            let name = make_c_string("dev2");
            let mut nums: UINT32 = 0;
            let _result = BspDevNumIndexbyName(name, &mut nums);
            
            reclaim(name);
            assert!(true);
        }
    }

    pub fn test_bsp_dev_num_index_by_name_not_found() {
        unsafe {
            use boardid::boardid::{BspDevNumIndexbyName, BspSetDeviceIdList, T_BoardIdItem};
            // 创建测试项列表
            let (ptr, len) = leak_items(vec![
                T_BoardIdItem {
                    ulIdVal: 1,
                    pucName: make_c_string("dev1"),
                    pucAlias: make_c_string("alias1"),
                    ulIdNum: 5,
                    ulIdAddr: 10,
                },
            ]);
            BspSetDeviceIdList(ptr, len);
            
            let name = make_c_string("nonexistent");
            let mut nums: UINT32 = 0;
            let _result = BspDevNumIndexbyName(name, &mut nums);
            
            reclaim(name);
            assert!(true);
        }
    }

    pub fn test_bsp_dev_num_index_by_name_item_name_null() {
        unsafe {
            use boardid::boardid::{BspDevNumIndexbyName, BspSetDeviceIdList, T_BoardIdItem};
            // 创建测试项列表，其中一项的 pucName 为 null
            let (ptr, len) = leak_items(vec![
                T_BoardIdItem {
                    ulIdVal: 1,
                    pucName: std::ptr::null_mut(),
                    pucAlias: make_c_string("alias1"),
                    ulIdNum: 5,
                    ulIdAddr: 10,
                },
                T_BoardIdItem {
                    ulIdVal: 2,
                    pucName: make_c_string("dev2"),
                    pucAlias: make_c_string("alias2"),
                    ulIdNum: 3,
                    ulIdAddr: 20,
                },
            ]);
            BspSetDeviceIdList(ptr, len);
            
            let name = make_c_string("dev2");
            let mut nums: UINT32 = 0;
            let _result = BspDevNumIndexbyName(name, &mut nums);
            
            reclaim(name);
            assert!(true);
        }
    }

    pub fn test_bsp_dev_num_index_by_name_multiple_items() {
        unsafe {
            use boardid::boardid::{BspDevNumIndexbyName, BspSetDeviceIdList, T_BoardIdItem};
            // 创建多个测试项
            let (ptr, len) = leak_items(vec![
                T_BoardIdItem {
                    ulIdVal: 1,
                    pucName: make_c_string("dev1"),
                    pucAlias: make_c_string("alias1"),
                    ulIdNum: 5,
                    ulIdAddr: 10,
                },
                T_BoardIdItem {
                    ulIdVal: 2,
                    pucName: make_c_string("dev2"),
                    pucAlias: make_c_string("alias2"),
                    ulIdNum: 3,
                    ulIdAddr: 20,
                },
                T_BoardIdItem {
                    ulIdVal: 3,
                    pucName: make_c_string("dev3"),
                    pucAlias: make_c_string("alias3"),
                    ulIdNum: 7,
                    ulIdAddr: 30,
                },
            ]);
            BspSetDeviceIdList(ptr, len);
            
            let name1 = make_c_string("dev1");
            let mut nums1: UINT32 = 0;
            let _result1 = BspDevNumIndexbyName(name1, &mut nums1);
            reclaim(name1);
            
            let name2 = make_c_string("dev2");
            let mut nums2: UINT32 = 0;
            let _result2 = BspDevNumIndexbyName(name2, &mut nums2);
            reclaim(name2);
            
            let name3 = make_c_string("dev3");
            let mut nums3: UINT32 = 0;
            let _result3 = BspDevNumIndexbyName(name3, &mut nums3);
            reclaim(name3);
            
            let name4 = make_c_string("nonexistent");
            let mut nums4: UINT32 = 0;
            let _result4 = BspDevNumIndexbyName(name4, &mut nums4);
            reclaim(name4);
            
            assert!(true);
        }
    }

    pub fn test_bsp_dev_num_index_by_name_zero_id_num() {
        unsafe {
            use boardid::boardid::{BspDevNumIndexbyName, BspSetDeviceIdList, T_BoardIdItem};
            // 创建测试项，ulIdNum 为 0
            let (ptr, len) = leak_items(vec![
                T_BoardIdItem {
                    ulIdVal: 1,
                    pucName: make_c_string("dev1"),
                    pucAlias: make_c_string("alias1"),
                    ulIdNum: 0,
                    ulIdAddr: 10,
                },
            ]);
            BspSetDeviceIdList(ptr, len);
            
            let name = make_c_string("dev1");
            let mut nums: UINT32 = 0;
            let _result = BspDevNumIndexbyName(name, &mut nums);
            
            reclaim(name);
            assert!(true);
        }
    }

    pub fn test_bsp_dev_num_index_by_name_large_id_num() {
        unsafe {
            use boardid::boardid::{BspDevNumIndexbyName, BspSetDeviceIdList, T_BoardIdItem};
            // 创建测试项，ulIdNum 很大
            let (ptr, len) = leak_items(vec![
                T_BoardIdItem {
                    ulIdVal: 1,
                    pucName: make_c_string("dev1"),
                    pucAlias: make_c_string("alias1"),
                    ulIdNum: 0xFFFFFFFF,
                    ulIdAddr: 10,
                },
            ]);
            BspSetDeviceIdList(ptr, len);
            
            let name = make_c_string("dev1");
            let mut nums: UINT32 = 0;
            let _result = BspDevNumIndexbyName(name, &mut nums);
            
            reclaim(name);
            assert!(true);
        }
    }
}

use std::process;
#[test]
fn capture_all_coverage() {
    // 按顺序调用模块内的所有测试函数
    all_tests::test_bsp_id_to_name_null_table();
    all_tests::test_bsp_id_to_name_exact_match_with_alias_copy();
    all_tests::test_bsp_id_to_name_range_alias_generated();
    all_tests::test_bsp_id_to_name_range_alias_with_embedded_null_warn_path();
    all_tests::test_bsp_id_to_name_not_found();
    all_tests::test_bsp_name_remove_token_null_inputs();
    all_tests::test_bsp_name_remove_token_transform();
    all_tests::test_bsp_name_remove_token_truncate();
    all_tests::test_bsp_name_cmp_basic();
    all_tests::test_bsp_id_addr_init();
    all_tests::test_bsp_id_to_base_null_table();
    all_tests::test_bsp_id_to_base_found_in_range();
    all_tests::test_bsp_id_to_base_not_found();
    all_tests::test_bsp_id_to_location_null_table();
    all_tests::test_bsp_id_to_location_exact_and_range();
    all_tests::test_bsp_location_to_name_null_table_and_bounds();
    all_tests::test_bsp_name_to_id_null_inputs_and_error_ptr();
    all_tests::test_bsp_name_to_id_exact_alias_generated();
    all_tests::test_str_to_upper_basic_and_truncate();
    all_tests::test_bsp_name_class_cmp_null_and_compare();
    all_tests::test_bsp_name_to_id_fine_step1_match_and_not_found();
    all_tests::test_bsp_name_to_id_fine_step2_match_and_not_found();
    all_tests::test_bsp_name_to_id_fine_null_inputs_and_alias_match();
    all_tests::test_bsp_name_to_id_fine_full_path_step1_then_step2();
    all_tests::test_bsp_dev_name_to_id_fine_null_and_error_ptr();
    all_tests::test_bsp_name_to_base_null_inputs();
    all_tests::test_bsp_name_to_base_exact_and_generated_and_not_found();
    all_tests::test_bsp_show_id_list_null_and_nonnull();
    all_tests::test_bsp_dev_id_to_name_and_dev_name_to_id();
    all_tests::test_bsp_dev_id_to_base_and_devid_to_location_location_to_name_show();
    all_tests::test_bsp_func_wrappers();
    all_tests::test_bsp_threshold_wrappers();
    all_tests::test_bsp_gain_wrappers();
    
    // ========== BspGainShowIdList 函数测试 - 覆盖 1326-1331 行代码 ==========
    all_tests::test_bsp_gain_show_id_list_null_pointer();
    all_tests::test_bsp_gain_show_id_list_empty_list();
    all_tests::test_bsp_gain_show_id_list_single_item();
    all_tests::test_bsp_gain_show_id_list_multiple_items();
    all_tests::test_bsp_gain_show_id_list_function_call();
    all_tests::test_bsp_gain_show_id_list_different_counts();
    all_tests::test_bsp_gain_show_id_list_edge_cases();
    all_tests::test_bsp_gain_show_id_list_parameter_passing();
    
    // devIdToBase 测试
    all_tests::test_dev_id_to_base_bsp_name_to_base_fails();
    all_tests::test_dev_id_to_base_bsp_name_to_base_success_bsp_id_to_base_fails();
    all_tests::test_dev_id_to_base_both_success();
    all_tests::test_dev_id_to_base_null_pointer();
    all_tests::test_dev_id_to_base_invalid_utf8();
    all_tests::test_dev_id_to_base_zero_dev_id();
    all_tests::test_dev_id_to_base_large_dev_id();
    all_tests::test_dev_id_to_base_multiple_calls();
    
    // BspSetDevNumbyName 测试
    all_tests::test_bsp_set_dev_num_by_name_null_pointer();
    all_tests::test_bsp_set_dev_num_by_name_empty_list();
    all_tests::test_bsp_set_dev_num_by_name_found_first_item();
    all_tests::test_bsp_set_dev_num_by_name_found_middle_item();
    all_tests::test_bsp_set_dev_num_by_name_found_last_item();
    all_tests::test_bsp_set_dev_num_by_name_not_found();
    all_tests::test_bsp_set_dev_num_by_name_invalid_utf8();
    all_tests::test_bsp_set_dev_num_by_name_item_name_null();
    all_tests::test_bsp_set_dev_num_by_name_item_name_invalid_utf8();
    all_tests::test_bsp_set_dev_num_by_name_zero_num();
    all_tests::test_bsp_set_dev_num_by_name_large_num();
    all_tests::test_bsp_set_dev_num_by_name_multiple_calls();
    
    // strncmp 测试
    all_tests::test_strncmp_zero_n();
    all_tests::test_strncmp_both_null();
    all_tests::test_strncmp_s1_null();
    all_tests::test_strncmp_s2_null();
    all_tests::test_strncmp_equal_strings();
    all_tests::test_strncmp_s1_less_than_s2();
    all_tests::test_strncmp_s1_greater_than_s2();
    all_tests::test_strncmp_s1_shorter_than_s2();
    all_tests::test_strncmp_s1_longer_than_s2();
    all_tests::test_strncmp_s1_has_null_terminator();
    all_tests::test_strncmp_s2_has_null_terminator();
    all_tests::test_strncmp_both_have_null_terminator();
    all_tests::test_strncmp_no_null_terminator();
    all_tests::test_strncmp_n_smaller_than_strings();
    all_tests::test_strncmp_n_larger_than_strings();
    all_tests::test_strncmp_empty_strings();
    all_tests::test_strncmp_single_char();
    all_tests::test_strncmp_case_sensitive();
    
    // BspDevNumIndexbyName 测试
    all_tests::test_bsp_dev_num_index_by_name_pt_tbl_null();
    all_tests::test_bsp_dev_num_index_by_name_ul_nums_null();
    all_tests::test_bsp_dev_num_index_by_name_both_null();
    all_tests::test_bsp_dev_num_index_by_name_empty_list();
    all_tests::test_bsp_dev_num_index_by_name_found_first_item();
    all_tests::test_bsp_dev_num_index_by_name_found_middle_item();
    all_tests::test_bsp_dev_num_index_by_name_found_last_item();
    all_tests::test_bsp_dev_num_index_by_name_not_found();
    all_tests::test_bsp_dev_num_index_by_name_item_name_null();
    all_tests::test_bsp_dev_num_index_by_name_multiple_items();
    all_tests::test_bsp_dev_num_index_by_name_zero_id_num();
    all_tests::test_bsp_dev_num_index_by_name_large_id_num();

    // ... 务必在此处调用所有你移到 `all_tests` 模块下的函数 ...

    // 重要：在所有测试代码执行完毕后，捕获覆盖率数据
    let mut coverage_data = Vec::new();
    unsafe {
        // 这是使 .profraw 文件有内容的关键调用
        let _ = minicov::capture_coverage(&mut coverage_data);
    }

    // 将数据写入文件。文件名可以自定义，如 `integration.profraw`
    let output_file = "./test_coverage_final.profraw";
    if let Err(e) = fs::write(output_file, coverage_data) {
        panic!("Failed to write coverage file: {}", e);
    }
    println!("✅ 覆盖率数据已成功写入: {}", output_file);
}




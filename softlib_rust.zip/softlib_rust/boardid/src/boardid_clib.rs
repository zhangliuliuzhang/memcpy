use std::ffi::CStr;

// 打桩实现 toupper 函数：将字符转换为大写
pub unsafe extern "C" fn toupper(c: libc::c_int) -> libc::c_int {
    if c >= 'a' as libc::c_int && c <= 'z' as libc::c_int {
        c - ('a' as libc::c_int - 'A' as libc::c_int)
    } else {
        c
    }
}

// 打桩实现 strcmp 函数：比较两个字符串
pub unsafe extern "C" fn strcmp(s1: *const libc::c_char, s2: *const libc::c_char) -> libc::c_int {
    if s1.is_null() && s2.is_null() {
        return 0;
    }
    if s1.is_null() {
        return -1;
    }
    if s2.is_null() {
        return 1;
    }
    
    let cstr1 = unsafe {
        match CStr::from_ptr(s1).to_bytes() {
            bytes => bytes,
        }
    };
    let cstr2 = unsafe {
        match CStr::from_ptr(s2).to_bytes() {
            bytes => bytes,
        }
    };
    
    match cstr1.cmp(cstr2) {
        std::cmp::Ordering::Equal => 0,
        std::cmp::Ordering::Less => -1,
        std::cmp::Ordering::Greater => 1,
    }
}

// 打桩实现 strncmp 函数：比较两个字符串的前 n 个字符
pub unsafe extern "C" fn strncmp(
    s1: *const libc::c_char,
    s2: *const libc::c_char,
    n: libc::c_ulong,
) -> libc::c_int {
    if n == 0 {
        return 0;
    }
    
    if s1.is_null() && s2.is_null() {
        return 0;
    }
    if s1.is_null() {
        return -1;
    }
    if s2.is_null() {
        return 1;
    }
    
    let len = n as usize;
    let slice1 = unsafe { std::slice::from_raw_parts(s1 as *const u8, len) };
    let slice2 = unsafe { std::slice::from_raw_parts(s2 as *const u8, len) };
    
    // 找到实际的字符串长度（遇到 null 终止符时停止）
    let mut len1 = 0;
    let mut len2 = 0;
    for i in 0..len {
        if slice1[i] == 0 {
            len1 = i;
            break;
        }
        len1 = i + 1;
    }
    for i in 0..len {
        if slice2[i] == 0 {
            len2 = i;
            break;
        }
        len2 = i + 1;
    }
    
    let actual_len = len1.min(len2).min(len);
    let s1_slice = &slice1[..actual_len];
    let s2_slice = &slice2[..actual_len];
    
    match s1_slice.cmp(s2_slice) {
        std::cmp::Ordering::Equal => {
            if len1 < len2 {
                -1
            } else if len1 > len2 {
                1
            } else {
                0
            }
        }
        std::cmp::Ordering::Less => -1,
        std::cmp::Ordering::Greater => 1,
    }
}
mod boardid_clib;
mod boardid;
fn main() {
    println!("Hello, world!");
}

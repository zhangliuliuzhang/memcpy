#![allow(unsafe_op_in_unsafe_fn)]

use std::ffi::{CString, CStr};
use crate::boardid_clib::*;


pub type size_t = libc::c_ulong;
pub type uintptr_t = libc::c_ulong;
pub type OSS_ULONG = libc::c_ulong;
pub type UCHAR = libc::c_uchar;
pub type CHAR = libc::c_char;
pub type ULONG = libc::c_uint;
pub type UINT32 = libc::c_uint;
pub type INT32 = libc::c_int;
pub type rsize_t = size_t;
pub type T_BoardIdItemDsp = tagT_BoardIdItemDsp;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct tagT_BoardIdItemDsp {
    pub t_IdList: *mut T_BoardIdItem,
    pub ulIdListNum: UINT32,
}
pub type T_BoardIdItem = tagT_BoardIdItem;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct tagT_BoardIdItem {
    pub ulIdVal: UINT32,
    pub pucName: *mut CHAR,
    pub pucAlias: *mut CHAR,
    pub ulIdNum: UINT32,
    pub ulIdAddr: UINT32,
}
////#[no_mangle]
pub static mut s_tDevIdList: T_BoardIdItemDsp = {
    let mut init = tagT_BoardIdItemDsp {
        t_IdList: 0 as *const T_BoardIdItem as *mut T_BoardIdItem,
        ulIdListNum: 0,
    };
    init
};
//#[no_mangle]
pub static mut s_tFuncIdList: T_BoardIdItemDsp = {
    let mut init = tagT_BoardIdItemDsp {
        t_IdList: 0 as *const T_BoardIdItem as *mut T_BoardIdItem,
        ulIdListNum: 0,
    };
    init
};
//#[no_mangle]
pub static mut s_tThresholdIdList: T_BoardIdItemDsp = {
    let mut init = tagT_BoardIdItemDsp {
        t_IdList: 0 as *const T_BoardIdItem as *mut T_BoardIdItem,
        ulIdListNum: 0,
    };
    init
};
//#[no_mangle]
pub static mut s_tGainIdList: T_BoardIdItemDsp = {
    let mut init = tagT_BoardIdItemDsp {
        t_IdList: 0 as *const T_BoardIdItem as *mut T_BoardIdItem,
        ulIdListNum: 0,
    };
    init
};
pub unsafe extern "C" fn BspNameRemoveToken(
    mut pucName: *const libc::c_char,
    mut pucRet: *mut CHAR,
) -> UINT32 {
    let mut i: libc::c_int = 0 as libc::c_int;
    let mut j: libc::c_int = 0 as libc::c_int;
    if pucName.is_null() {
        println!("BspNameRemoveToken:Input Pointer is NULL!");
        return 0xff000002 as libc::c_uint;
    }
    if pucRet.is_null() {
        println!("BspNameRemoveToken:Input Pointer is NULL!");
        return 0xff000002 as libc::c_uint;
    }
    while *pucName.offset(i as isize) as libc::c_int != '\0' as i32
        && j < 256 as libc::c_int - 1 as libc::c_int
    {
        if *pucName.offset(i as isize) as libc::c_int != '_' as i32
            && *pucName.offset(i as isize) as libc::c_int != '-' as i32
        {
            *pucRet
                .offset(
                    j as isize,
                ) = toupper(*pucName.offset(i as isize) as libc::c_int) as UCHAR as CHAR;
            j += 1;
            j;
        }
        i += 1;
        i;
    }
    *pucRet.offset(j as isize) = '\0' as i32 as CHAR;
    return 0 as libc::c_int as UINT32;
}
pub unsafe extern "C" fn BspNameCmp(
    mut pucName1: *const libc::c_char,
    mut pucName2: *const libc::c_char,
) -> UINT32 {
    let mut strRet1: [libc::c_char; 256] = [0; 256];
    let mut strRet2: [libc::c_char; 256] = [0; 256];
    if pucName1.is_null() {
        println!("BspNameCmp:Input Pointer is NULL!");
        return 0xff000002 as libc::c_uint;
    }
    if pucName2.is_null() {
        println!("BspNameCmp:Input Pointer is NULL!");
        return 0xff000002 as libc::c_uint;
    }
    BspNameRemoveToken(pucName1, strRet1.as_mut_ptr());
    BspNameRemoveToken(pucName2, strRet2.as_mut_ptr());
    if strcmp(strRet1.as_mut_ptr(), strRet2.as_mut_ptr()) != 0 as libc::c_int {
        return 0xffffffff as libc::c_uint;
    }
    return 0 as libc::c_int as UINT32;
}
//#[no_mangle]
pub unsafe extern "C" fn BspIdAddrInit(
    mut ptTbl: *mut libc::c_void,
    mut ulNums: UINT32,
) -> UINT32 {
    let mut ulLoop: UINT32 = 0;
    let mut ptItem: *mut T_BoardIdItem = ptTbl as *mut T_BoardIdItem;
    if ptItem.is_null() {
        println!("BspIdAddrInit:Input Pointer is NULL!");
        return 0xff000002 as libc::c_uint;
    }
    ulLoop = 0 as libc::c_int as UINT32;
    while ulLoop < ulNums {
        if -(1 as libc::c_int) as libc::c_uint == (*ptItem).ulIdAddr {
            (*ptItem).ulIdAddr = (*ptItem).ulIdVal;
        }
        ulLoop = ulLoop.wrapping_add(1);
        ulLoop;
        ptItem = ptItem.offset(1);
        ptItem;
    }
    return 0 as libc::c_int as UINT32;
}
pub unsafe extern "C" fn BspIdToName(
    mut ptTbl: *mut libc::c_void,
    mut ulNums: UINT32,
    mut ulDevId: UINT32,
    mut pucAlias: *mut libc::c_char,
    mut ulAliasBufLen: UINT32,
) -> *mut UCHAR {
    let mut ulLoop: UINT32 = 0;
    let mut ptItem: *mut T_BoardIdItem = ptTbl as *mut T_BoardIdItem;
    let mut snprtRet: INT32 = 0 as libc::c_int;
    if ptItem.is_null() {
        println!("BspIdToName:Input Pointer is NULL!");
        return 0 as *mut UCHAR;
    }
    ulLoop = 0 as libc::c_int as UINT32;
    while ulLoop < ulNums {
        if (*ptItem).ulIdAddr == ulDevId {
            if !pucAlias.is_null() {
                // 使用 Rust 风格的代码替换 encapsulationOfZte_strncpy_s
                if !(*ptItem).pucAlias.is_null() {
                    let src_str = match CStr::from_ptr((*ptItem).pucAlias).to_str() {
                        Ok(s) => s,
                        Err(_) => "",
                    };
                    let max_len = (ulAliasBufLen as usize).saturating_sub(1);
                    match CString::new(src_str) {
                        Ok(c_string) => {
                            let bytes = c_string.as_bytes();
                            let copy_len = bytes.len().min(max_len);
                            std::ptr::copy_nonoverlapping(
                                bytes.as_ptr() as *const libc::c_char,
                                pucAlias as *mut libc::c_char,
                                copy_len,
                            );
                            *pucAlias.add(copy_len) = 0;
                        }
                        Err(_) => {
                            *pucAlias = 0;
                        }
                    }
                } else {
                    *pucAlias = 0;
                }
            }
            return (*ptItem).pucName as *mut UCHAR;
        }
        if ulDevId >= (*ptItem).ulIdAddr
            && ulDevId < ((*ptItem).ulIdAddr).wrapping_add((*ptItem).ulIdNum)
        {
            if !pucAlias.is_null() {
                // 使用 Rust 风格的代码替换 snprintf_s
                let alias_str = if (*ptItem).pucAlias.is_null() {
                    ""
                } else {
                    match CStr::from_ptr((*ptItem).pucAlias).to_str() {
                        Ok(s) => s,
                        Err(_) => "",
                    }
                };
                let num = ulDevId.wrapping_sub((*ptItem).ulIdAddr);
                let formatted = format!("{}{}", alias_str, num);
                let max_len = (ulAliasBufLen as usize).saturating_sub(1);
                snprtRet = match CString::new(formatted.as_str()) {
                    Ok(c_string) => {
                        let bytes = c_string.as_bytes();
                        let copy_len = bytes.len().min(max_len);
                        std::ptr::copy_nonoverlapping(
                            bytes.as_ptr() as *const libc::c_char,
                            pucAlias,
                            copy_len,
                        );
                        *pucAlias.add(copy_len) = 0;
                        copy_len as INT32
                    }
                    Err(_) => -1,
                };
                if snprtRet < 0 as libc::c_int
                    || snprtRet as libc::c_uint > ulAliasBufLen
                {
                    println!("BspIdToName(387) warning! > snprintf_s ret'{} max'{}!", snprtRet, ulAliasBufLen as size_t);
                }
            }
            return (*ptItem).pucName as *mut UCHAR;
        }
        ulLoop = ulLoop.wrapping_add(1);
        ulLoop;
        ptItem = ptItem.offset(1);
        ptItem;
    }
    if !pucAlias.is_null() {
        *pucAlias = '\0' as i32 as libc::c_char;
    }
    return 0 as *mut UCHAR;
}
//#[no_mangle]
pub unsafe extern "C" fn BspIdToBase(
    mut ptTbl: *mut libc::c_void,
    mut ulNums: UINT32,
    mut ulDevId: UINT32,
    mut pulIdBase: *mut UINT32,
    mut pulIdInnerIndex: *mut UINT32,
    mut pulIdAddr: *mut UINT32,
) -> UINT32 {
    let mut ulLoop: UINT32 = 0;
    let mut ptItem: *mut T_BoardIdItem = ptTbl as *mut T_BoardIdItem;
    if ptItem.is_null() {
        println!("BspIdToBase:Input Pointer is NULL!");
        return 0 as libc::c_int as UINT32;
    }
    ulLoop = 0 as libc::c_int as UINT32;
    while ulLoop < ulNums {
        if ulDevId >= (*ptItem).ulIdAddr
            && ulDevId < ((*ptItem).ulIdAddr).wrapping_add((*ptItem).ulIdNum)
        {
            *pulIdBase = (*ptItem).ulIdVal;
            *pulIdInnerIndex = ulDevId.wrapping_sub((*ptItem).ulIdAddr);
            *pulIdAddr = (*ptItem).ulIdAddr;
            return 0 as libc::c_int as UINT32;
        }
        ulLoop = ulLoop.wrapping_add(1);
        ulLoop;
        ptItem = ptItem.offset(1);
        ptItem;
    }
    return 0xffffffff as libc::c_uint;
}
//#[no_mangle]
pub unsafe extern "C" fn BspIdToLocation(
    mut ptTbl: *mut libc::c_void,
    mut ulNums: UINT32,
    mut ulDevId: UINT32,
) -> UINT32 {
    let mut ulLoop: UINT32 = 0 as libc::c_int as UINT32;
    let mut ptItem: *mut T_BoardIdItem = ptTbl as *mut T_BoardIdItem;
    if ptItem.is_null() {
        println!("BspIdToLocation:Input Pointer is NULL!");
        return 0xff000002 as libc::c_uint;
    }
    ulLoop = 0 as libc::c_int as UINT32;
    while ulLoop < ulNums {
        if (*ptItem).ulIdAddr == ulDevId {
            return ulLoop;
        }
        if ulDevId >= (*ptItem).ulIdAddr
            && ulDevId < ((*ptItem).ulIdAddr).wrapping_add((*ptItem).ulIdNum)
        {
            return ulLoop;
        }
        ulLoop = ulLoop.wrapping_add(1);
        ulLoop;
        ptItem = ptItem.offset(1);
        ptItem;
    }
    return 0xffffffff as libc::c_uint;
}
//#[no_mangle]
pub unsafe extern "C" fn BspLocationToName(
    mut ptTbl: *mut libc::c_void,
    mut ulNums: UINT32,
    mut ulLocation: UINT32,
) -> *mut UCHAR {
    let mut ptItem: *mut T_BoardIdItem = ptTbl as *mut T_BoardIdItem;
    if ptItem.is_null() {
        println!("BspLocationToName:Input Pointer is NULL!");
        return 0 as *mut UCHAR;
    }
    if ulLocation < ulNums {
        return (*ptItem.offset(ulLocation as isize)).pucName as *mut UCHAR;
    }
    return 0 as *mut UCHAR;
}
//#[no_mangle]
pub unsafe extern "C" fn BspNameToId(
    mut ptTbl: *mut libc::c_void,
    mut ulNums: UINT32,
    mut pucDevName: *const libc::c_char,
) -> UINT32 {
    let mut ulLoop: UINT32 = 0;
    let mut ulIdx: UINT32 = 0;
    let mut ucTmpName: [libc::c_char; 64] = [0; 64];
    let mut snprtRet: INT32 = 0 as libc::c_int;
    let mut ptItem: *mut T_BoardIdItem = ptTbl as *mut T_BoardIdItem;
    if ptItem.is_null() {
        println!("BspNameToId:Input Pointer is NULL!");
        return 0xff000002 as libc::c_uint;
    }
    if pucDevName.is_null() {
        println!("BspNameToId:Input Pointer is NULL!");
        return 0xff000002 as libc::c_uint;
    }
    if 0xffffffff as libc::c_uint as libc::c_ulong == pucDevName as uintptr_t {
        return 0xffffffff as libc::c_uint;
    }
    ulLoop = 0 as libc::c_int as UINT32;
    while ulLoop < ulNums {
        if 0 as libc::c_int as UINT32 == BspNameCmp(pucDevName, (*ptItem).pucName) {
            return (*ptItem).ulIdAddr;
        }
        if 0 as libc::c_int as UINT32 == BspNameCmp(pucDevName, (*ptItem).pucAlias) {
            return (*ptItem).ulIdAddr;
        }
        ulLoop = ulLoop.wrapping_add(1);
        ulLoop;
        ptItem = ptItem.offset(1);
        ptItem;
    }
    ptItem = ptTbl as *mut T_BoardIdItem;
    ulLoop = 0 as libc::c_int as UINT32;
    while ulLoop < ulNums {
        ulIdx = 0 as libc::c_int as UINT32;
        while ulIdx < (*ptItem).ulIdNum {
            // 使用 Rust 风格的代码替换 snprintf_s
            let alias_str = if (*ptItem).pucAlias.is_null() {
                ""
            } else {
                match CStr::from_ptr((*ptItem).pucAlias).to_str() {
                    Ok(s) => s,
                    Err(_) => "",
                }
            };
            let formatted = format!("{}{}", alias_str, ulIdx);
            let max_len = (::core::mem::size_of::<[libc::c_char; 64]>() as usize).saturating_sub(1);
            snprtRet = match CString::new(formatted.as_str()) {
                Ok(c_string) => {
                    let bytes = c_string.as_bytes();
                    let copy_len = bytes.len().min(max_len);
                    std::ptr::copy_nonoverlapping(
                        bytes.as_ptr() as *const libc::c_char,
                        ucTmpName.as_mut_ptr(),
                        copy_len,
                    );
                    *ucTmpName.as_mut_ptr().add(copy_len) = 0;
                    copy_len as INT32
                }
                Err(_) => -1,
            };
            if snprtRet < 0 as libc::c_int
                || snprtRet as libc::c_ulong
                    > ::core::mem::size_of::<[libc::c_char; 64]>() as libc::c_ulong
            {
                println!("BspNameToId(554) warning! > snprintf_s ret'{} max'{}!", snprtRet, ::core::mem::size_of::<[libc::c_char; 64]>() as libc::c_ulong);
            }
            if 0 as libc::c_int as UINT32
                == BspNameCmp(pucDevName, ucTmpName.as_mut_ptr())
            {
                return ((*ptItem).ulIdAddr).wrapping_add(ulIdx);
            }
            ulIdx = ulIdx.wrapping_add(1);
            ulIdx;
        }
        ulLoop = ulLoop.wrapping_add(1);
        ulLoop;
        ptItem = ptItem.offset(1);
        ptItem;
    }
    return 0xffffffff as libc::c_uint;
}
//#[no_mangle]
pub unsafe extern "C" fn StrToUpper(
    mut src: *const libc::c_char,
    mut dest: *mut libc::c_char,
    maxNum: UINT32,
) -> UINT32 {
    let mut loop_0: UINT32 = 0;
    loop_0 = 0 as libc::c_int as UINT32;
    while loop_0 < maxNum && *src.offset(loop_0 as isize) as libc::c_int != '\0' as i32 {
        *dest
            .offset(
                loop_0 as isize,
            ) = toupper(*src.offset(loop_0 as isize) as libc::c_int) as libc::c_char;
        loop_0 = loop_0.wrapping_add(1);
        loop_0;
    }
    loop_0 = if loop_0 < maxNum.wrapping_sub(1 as libc::c_int as libc::c_uint) {
        loop_0
    } else {
        maxNum.wrapping_sub(1 as libc::c_int as libc::c_uint)
    };
    *dest.offset(loop_0 as isize) = '\0' as i32 as libc::c_char;
    return 0 as libc::c_int as UINT32;
}
//#[no_mangle]
pub unsafe extern "C" fn BspNameClassCmp(
    mut pucNameNew: *const libc::c_char,
    mut pucNameOld: *const libc::c_char,
) -> UINT32 {
    let mut strRetNew: [libc::c_char; 256] = [0; 256];
    let mut strRetOld: [libc::c_char; 256] = [0; 256];
    let mut ulLenth: UINT32 = 0 as libc::c_int as UINT32;
    let mut iRet: INT32 = 0 as libc::c_int;
    if pucNameOld.is_null() {
        println!("BspNameClassCmp:Input Pointer is NULL!");
        return 0xff000002 as libc::c_uint;
    }
    if pucNameNew.is_null() {
        println!("BspNameClassCmp:Input Pointer is NULL!");
        return 0xff000002 as libc::c_uint;
    }
    StrToUpper(
        pucNameNew,
        strRetNew.as_mut_ptr(),
        ::core::mem::size_of::<[libc::c_char; 256]>() as libc::c_ulong as UINT32,
    );
    StrToUpper(
        pucNameOld,
        strRetOld.as_mut_ptr(),
        ::core::mem::size_of::<[libc::c_char; 256]>() as libc::c_ulong as UINT32,
    );
    // 使用 Rust 风格的代码替换 encapsulationOfZte_strnlen_s
    ulLenth = if strRetOld.as_mut_ptr().is_null() {
        0
    } else {
        match CStr::from_ptr(strRetOld.as_mut_ptr()).to_bytes_with_nul().len().checked_sub(1) {
            Some(len) => {
                let max_len = 256 as usize;
                len.min(max_len) as UINT32
            }
            None => 0,
        }
    };
    // 使用 Rust 风格的代码替换 strncmp
    iRet = if strRetOld.as_mut_ptr().is_null() || strRetNew.as_mut_ptr().is_null() {
        if strRetOld.as_mut_ptr().is_null() && strRetNew.as_mut_ptr().is_null() {
            0
        } else if strRetOld.as_mut_ptr().is_null() {
            -1
        } else {
            1
        }
    } else {
        let len = ulLenth as usize;
        unsafe {
            let old_slice = std::slice::from_raw_parts(strRetOld.as_mut_ptr() as *const u8, len);
            let new_slice = std::slice::from_raw_parts(strRetNew.as_mut_ptr() as *const u8, len);
            match old_slice.cmp(new_slice) {
                std::cmp::Ordering::Equal => 0,
                std::cmp::Ordering::Less => -1,
                std::cmp::Ordering::Greater => 1,
            }
        }
    };
    if iRet != 0 as libc::c_int {
        return 0xffffffff as libc::c_uint;
    }
    return 0 as libc::c_int as UINT32;
}
//#[no_mangle]
pub unsafe extern "C" fn BspNameToIdFine_step1(
    mut ptItem: *mut T_BoardIdItem,
    mut pucDevName: *const libc::c_char,
) -> UINT32 {
    let mut ulIdx: UINT32 = 0 as libc::c_int as UINT32;
    let mut ucTmpName: [libc::c_char; 64] = [
        '\0' as i32 as libc::c_char,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
    ];
    let mut pStrTmp: *mut CHAR = 0 as *mut CHAR;
    ulIdx = 0 as libc::c_int as UINT32;
    while ulIdx < (*ptItem).ulIdNum {
        pStrTmp = ucTmpName.as_mut_ptr();
        // 使用 Rust 风格的代码替换 snprintf_s
        let alias_str = if (*ptItem).pucAlias.is_null() {
            ""
        } else {
            match CStr::from_ptr((*ptItem).pucAlias).to_str() {
                Ok(s) => s,
                Err(_) => "",
            }
        };
        let formatted = format!("{}{}", alias_str, ulIdx);
        let max_len = (::core::mem::size_of::<[libc::c_char; 64]>() as usize).saturating_sub(1);
        match CString::new(formatted.as_str()) {
            Ok(c_string) => {
                let bytes = c_string.as_bytes();
                let copy_len = bytes.len().min(max_len);
                std::ptr::copy_nonoverlapping(
                    bytes.as_ptr() as *const libc::c_char,
                    pStrTmp,
                    copy_len,
                );
                *pStrTmp.add(copy_len) = 0;
            }
            Err(_) => {
                *pStrTmp = 0;
            }
        }
        if 0 as libc::c_int as UINT32
            == BspNameClassCmp(ucTmpName.as_mut_ptr(), pucDevName)
        {
            // 使用 Rust 风格的代码替换 ExPrnLev
            let tmp_name_str = match CStr::from_ptr(ucTmpName.as_mut_ptr()).to_str() {
                Ok(s) => s,
                Err(_) => "",
            };
            println!("BspNameToIdFine_step1>>find {},Idx {},DevId {:#x}", tmp_name_str, ulIdx, ((*ptItem).ulIdAddr).wrapping_add(ulIdx));
            return ((*ptItem).ulIdAddr).wrapping_add(ulIdx);
        }
        ulIdx = ulIdx.wrapping_add(1);
        ulIdx;
    }
    return 0xffffffff as libc::c_uint;
}
//#[no_mangle]
pub unsafe extern "C" fn BspNameToIdFine_step2(
    mut ptItem: *mut T_BoardIdItem,
    mut pucDevName: *const libc::c_char,
) -> UINT32 {
    let mut ulIdx: UINT32 = 0 as libc::c_int as UINT32;
    let mut ulIdxFix: UINT32 = 0 as libc::c_int as UINT32;
    let mut ucTmpName: [libc::c_char; 64] = [
        '\0' as i32 as libc::c_char,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
    ];
    let mut pStrTmp: *mut CHAR = 0 as *mut CHAR;
    let mut VbiasTypeNum: UINT32 = 8 as libc::c_int as UINT32;
    ulIdx = 0 as libc::c_int as UINT32;
    while ulIdx < (*ptItem).ulIdNum {
        ulIdxFix = 0 as libc::c_int as UINT32;
        while ulIdxFix < VbiasTypeNum {
            pStrTmp = ucTmpName.as_mut_ptr();
            // 使用 Rust 风格的代码替换 snprintf_s
            let alias_str = if (*ptItem).pucAlias.is_null() {
                ""
            } else {
                match CStr::from_ptr((*ptItem).pucAlias).to_str() {
                    Ok(s) => s,
                    Err(_) => "",
                }
            };
            let formatted = format!("{}{}_{}", alias_str, ulIdx, ulIdxFix);
            let max_len = (::core::mem::size_of::<[libc::c_char; 64]>() as usize).saturating_sub(1);
            match CString::new(formatted.as_str()) {
                Ok(c_string) => {
                    let bytes = c_string.as_bytes();
                    let copy_len = bytes.len().min(max_len);
                    std::ptr::copy_nonoverlapping(
                        bytes.as_ptr() as *const libc::c_char,
                        pStrTmp,
                        copy_len,
                    );
                    *pStrTmp.add(copy_len) = 0;
                }
                Err(_) => {
                    *pStrTmp = 0;
                }
            }
            if 0 as libc::c_int as UINT32
                == BspNameClassCmp(ucTmpName.as_mut_ptr(), pucDevName)
            {
                // 使用 Rust 风格的代码替换 ExPrnLev
                let tmp_name_str = match CStr::from_ptr(ucTmpName.as_mut_ptr()).to_str() {
                    Ok(s) => s,
                    Err(_) => "",
                };
                let dev_id = ((*ptItem).ulIdAddr)
                    .wrapping_add(
                        ulIdx
                            .wrapping_mul(
                                VbiasTypeNum.wrapping_add(1 as libc::c_int as libc::c_uint),
                            ),
                    )
                    .wrapping_add(ulIdxFix);
                println!("BspNameToIdFine_step2>>find {},Idx {},IdxFix {},DevId {:#x}", tmp_name_str, ulIdx, ulIdxFix, dev_id);
                return ((*ptItem).ulIdAddr)
                    .wrapping_add(ulIdx.wrapping_mul(VbiasTypeNum))
                    .wrapping_add(ulIdxFix);
            }
            ulIdxFix = ulIdxFix.wrapping_add(1);
            ulIdxFix;
        }
        ulIdx = ulIdx.wrapping_add(1);
        ulIdx;
    }
    return 0xffffffff as libc::c_uint;
}
//#[no_mangle]
pub unsafe extern "C" fn BspNameToIdFine(
    mut ptTbl: *mut libc::c_void,
    mut ulNums: UINT32,
    mut pucDevName: *const libc::c_char,
) -> UINT32 {
    let mut ulLoop: UINT32 = 0 as libc::c_int as UINT32;
    let mut idVal: UINT32 = 0 as libc::c_int as UINT32;
    let mut ptItem: *mut T_BoardIdItem = ptTbl as *mut T_BoardIdItem;
    if ptItem.is_null() {
        println!("BspNameToIdFine:Input Pointer is NULL!");
        return 0xff000002 as libc::c_uint;
    }
    if pucDevName.is_null() {
        println!("BspNameToIdFine:Input Pointer is NULL!");
        return 0xff000002 as libc::c_uint;
    }
    ulLoop = 0 as libc::c_int as UINT32;
    while ulLoop < ulNums {
        if 0 as libc::c_int as UINT32 == BspNameClassCmp(pucDevName, (*ptItem).pucAlias)
        {
            // 使用 Rust 风格的代码替换 ExPrnLev
            let alias_str = if (*ptItem).pucAlias.is_null() {
                ""
            } else {
                match CStr::from_ptr((*ptItem).pucAlias).to_str() {
                    Ok(s) => s,
                    Err(_) => "",
                }
            };
            println!("BspNameToIdFine>>find {},Loop {}", alias_str, ulLoop);
            break;
        } else {
            ulLoop = ulLoop.wrapping_add(1);
            ulLoop;
            ptItem = ptItem.offset(1);
            ptItem;
        }
    }
    if ulLoop == ulNums {
        // 使用 Rust 风格的代码替换 ExPrnLev
        let dev_name_str = if pucDevName.is_null() {
            ""
        } else {
            match CStr::from_ptr(pucDevName).to_str() {
                Ok(s) => s,
                Err(_) => "",
            }
        };
        println!("BspNameToIdFine>>Can't find {}", dev_name_str);
        return 0xffffffff as libc::c_uint;
    }
    idVal = BspNameToIdFine_step1(ptItem, pucDevName);
    if 0xffffffff as libc::c_uint != idVal {
        return idVal;
    }
    idVal = BspNameToIdFine_step2(ptItem, pucDevName);
    if 0xffffffff as libc::c_uint != idVal {
        return idVal;
    }
    return 0xffffffff as libc::c_uint;
}
//#[no_mangle]
pub unsafe extern "C" fn BspDevNameToIdFine(
    mut pucDevName: *const libc::c_char,
) -> UINT32 {
    let mut devNameAddr: libc::c_ulong = 0 as libc::c_int as libc::c_ulong;
    if pucDevName.is_null() {
        println!("BspDevNameToIdFine:Input Pointer is NULL!");
        return 0xff000002 as libc::c_uint;
    }
    devNameAddr = pucDevName as libc::c_ulong;
    if devNameAddr == 0xffffffff as libc::c_uint as libc::c_ulong {
        println!("BspDevNameToIdFine:Input pucDevName is error!");
        return 0xff000002 as libc::c_uint;
    }
    return BspNameToIdFine(
        s_tDevIdList.t_IdList as *mut libc::c_void,
        s_tDevIdList.ulIdListNum,
        pucDevName,
    );
}
//#[no_mangle]
pub unsafe extern "C" fn BspNameToBase(
    mut ptTbl: *mut libc::c_void,
    mut ulNums: UINT32,
    mut pucName: *const libc::c_char,
    mut puBase: *mut UINT32,
    mut pulInnerIndex: *mut UINT32,
    mut pulIdAddr: *mut UINT32,
) -> UINT32 {
    let mut ulLoop: UINT32 = 0;
    let mut ulIdx: UINT32 = 0;
    let mut ucTmpName: [libc::c_char; 64] = [0; 64];
    let mut snpRet: INT32 = 0 as libc::c_int;
    let mut ptItem: *mut T_BoardIdItem = ptTbl as *mut T_BoardIdItem;
    if ptItem.is_null() {
        println!("BspNameToBase:Input Pointer is NULL!");
        return 0xff000002 as libc::c_uint;
    }
    if pucName.is_null() {
        println!("BspNameToBase:Input Pointer is NULL!");
        return 0xff000002 as libc::c_uint;
    }
    if puBase.is_null() {
        println!("BspNameToBase:Input Pointer is NULL!");
        return 0xff000002 as libc::c_uint;
    }
    if pulInnerIndex.is_null() {
        println!("BspNameToBase:Input Pointer is NULL!");
        return 0xff000002 as libc::c_uint;
    }
    if 0xffffffff as libc::c_uint as libc::c_ulong == pucName as uintptr_t {
        return 0xffffffff as libc::c_uint;
    }
    ulLoop = 0 as libc::c_int as UINT32;
    while ulLoop < ulNums {
        if 0 as libc::c_int as UINT32 == BspNameCmp(pucName, (*ptItem).pucName)
            || 0 as libc::c_int as UINT32 == BspNameCmp(pucName, (*ptItem).pucAlias)
        {
            *puBase = (*ptItem).ulIdVal;
            *pulInnerIndex = 0 as libc::c_int as UINT32;
            *pulIdAddr = (*ptItem).ulIdAddr;
            return 0 as libc::c_int as UINT32;
        }
        ulLoop = ulLoop.wrapping_add(1);
        ulLoop;
        ptItem = ptItem.offset(1);
        ptItem;
    }
    ptItem = ptTbl as *mut T_BoardIdItem;
    ulLoop = 0 as libc::c_int as UINT32;
    while ulLoop < ulNums {
        ulIdx = 0 as libc::c_int as UINT32;
        while ulIdx < (*ptItem).ulIdNum {
            // 使用 Rust 风格的代码替换 snprintf_s
            let alias_str = if (*ptItem).pucAlias.is_null() {
                ""
            } else {
                match CStr::from_ptr((*ptItem).pucAlias).to_str() {
                    Ok(s) => s,
                    Err(_) => "",
                }
            };
            let formatted = format!("{}{}", alias_str, ulIdx);
            let max_len = (::core::mem::size_of::<[libc::c_char; 64]>() as usize).saturating_sub(1);
            snpRet = match CString::new(formatted.as_str()) {
                Ok(c_string) => {
                    let bytes = c_string.as_bytes();
                    let copy_len = bytes.len().min(max_len);
                    std::ptr::copy_nonoverlapping(
                        bytes.as_ptr() as *const libc::c_char,
                        ucTmpName.as_mut_ptr(),
                        copy_len,
                    );
                    *ucTmpName.as_mut_ptr().add(copy_len) = 0;
                    copy_len as INT32
                }
                Err(_) => -1,
            };
            if snpRet < 0 as libc::c_int
                || snpRet as libc::c_ulong
                    > ::core::mem::size_of::<[libc::c_char; 64]>() as libc::c_ulong
            {
                println!("BspNameToBase(748) warning! > snprintf_s ret'{} max'{}!", snpRet, ::core::mem::size_of::<[libc::c_char; 64]>() as libc::c_ulong);
            }
            if 0 as libc::c_int as UINT32 == BspNameCmp(pucName, ucTmpName.as_mut_ptr())
            {
                *puBase = (*ptItem).ulIdVal;
                *pulInnerIndex = ulIdx;
                *pulIdAddr = (*ptItem).ulIdAddr;
                return 0 as libc::c_int as UINT32;
            }
            ulIdx = ulIdx.wrapping_add(1);
            ulIdx;
        }
        ulLoop = ulLoop.wrapping_add(1);
        ulLoop;
        ptItem = ptItem.offset(1);
        ptItem;
    }
    return 0xffffffff as libc::c_uint;
}
//#[no_mangle]
pub unsafe extern "C" fn BspShowIdList(
    mut ptTbl: *mut libc::c_void,
    mut ulNums: UINT32,
) -> UINT32 {
    let mut ulLoop: UINT32 = 0;
    let mut ptItem: *mut T_BoardIdItem = ptTbl as *mut T_BoardIdItem;
    if ptItem.is_null() {
        println!("BspShowIdList:Input Pointer is NULL!");
        return 0xff000002 as libc::c_uint;
    }
    ulLoop = 0 as libc::c_int as UINT32;
    while ulLoop < ulNums {
        println!("IdVal     ucName     ucAlias    IdNum     IdAddr");
        // 对于格式化输出，需要将 C 字符串指针转换为 Rust 字符串
        let name_str = if (*ptItem).pucName.is_null() {
            ""
        } else {
            match CStr::from_ptr((*ptItem).pucName).to_str() {
                Ok(s) => s,
                Err(_) => "",
            }
        };
        let alias_str = if (*ptItem).pucAlias.is_null() {
            ""
        } else {
            match CStr::from_ptr((*ptItem).pucAlias).to_str() {
                Ok(s) => s,
                Err(_) => "",
            }
        };
        println!("{} {} {} {} {}", (*ptItem).ulIdVal, name_str, alias_str, (*ptItem).ulIdNum, (*ptItem).ulIdAddr);
        ulLoop = ulLoop.wrapping_add(1);
        ulLoop;
        ptItem = ptItem.offset(1);
        ptItem;
    }
    return 0 as libc::c_int as UINT32;
}
//#[no_mangle]
pub unsafe extern "C" fn BspDevIdToName(
    mut ulDevId: UINT32,
    mut pucAlias: *mut libc::c_char,
    mut ulAliasBufLen: UINT32,
) -> *mut UCHAR {
    if pucAlias.is_null() {
        println!("BspDevIdToName:Input Pointer is NULL!");
        return 0 as *mut UCHAR;
    }
    return BspIdToName(
        s_tDevIdList.t_IdList as *mut libc::c_void,
        s_tDevIdList.ulIdListNum,
        ulDevId,
        pucAlias,
        ulAliasBufLen,
    );
}
//#[no_mangle]
pub unsafe extern "C" fn BspDevNameToId(mut pucDevName: *const libc::c_char) -> UINT32 {
    if pucDevName.is_null() {
        println!("BspDevNameToId:Input Pointer is NULL!");
        return 0xff000002 as libc::c_uint;
    }
    return BspNameToId(
        s_tDevIdList.t_IdList as *mut libc::c_void,
        s_tDevIdList.ulIdListNum,
        pucDevName,
    );
}
//#[no_mangle]
pub unsafe extern "C" fn BspDevIdToBase(
    mut ulDevId: OSS_ULONG,
    mut pulDevBase: *mut UINT32,
    mut pulDevInnerIndex: *mut UINT32,
) -> UINT32 {
    let mut ulRet: UINT32 = 0 as libc::c_int as UINT32;
    let mut ulIdAddr: UINT32 = 0xffffffff as libc::c_uint;
    if pulDevBase.is_null() || pulDevInnerIndex.is_null() {
        println!("Input Pointer is NULL!");
        return 0xff000002 as libc::c_uint;
    }
    if ulDevId > 0x10000 as libc::c_int as libc::c_ulong {
        ulRet = BspNameToBase(
            s_tDevIdList.t_IdList as *mut libc::c_void,
            s_tDevIdList.ulIdListNum,
            ulDevId as *const libc::c_char,
            pulDevBase,
            pulDevInnerIndex,
            &mut ulIdAddr,
        );
    } else {
        ulRet = BspIdToBase(
            s_tDevIdList.t_IdList as *mut libc::c_void,
            s_tDevIdList.ulIdListNum,
            ulDevId as UINT32,
            pulDevBase,
            pulDevInnerIndex,
            &mut ulIdAddr,
        );
    }
    return if ulRet == 0 as libc::c_int as UINT32 {
        ulIdAddr
    } else {
        0xffffffff as libc::c_uint
    };
}
//#[no_mangle]
pub unsafe extern "C" fn devIdToBase(mut ulDevId: UINT32) -> UINT32 {
    let mut ulDevBase: UINT32 = 0 as libc::c_int as UINT32;
    let mut ulDevInnerIndex: UINT32 = 0 as libc::c_int as UINT32;
    let mut ulIdAddr: UINT32 = 0 as libc::c_int as UINT32;
    let mut retVal: UINT32 = 0 as libc::c_int as UINT32;
    let mut pUlDevId: uintptr_t = ulDevId as uintptr_t;
    // 检查指针是否可能是有效的字符串指针（避免段错误）
    // 如果 ulDevId 转换为指针后值太小，可能是无效指针，跳过 BspNameToBase
    let skip_name_to_base = pUlDevId < 0x1000 || pUlDevId > 0x7FFFFFFFFFFFFFFF;
    if !skip_name_to_base {
        retVal = BspNameToBase(
            s_tDevIdList.t_IdList as *mut libc::c_void,
            s_tDevIdList.ulIdListNum,
            pUlDevId as *const libc::c_char,
            &mut ulDevBase,
            &mut ulDevInnerIndex,
            &mut ulIdAddr,
        );
        if retVal != 0 as libc::c_int as UINT32 {
            return retVal;
        }
        // 使用 Rust 风格的代码替换 mzprnL
        let dev_id_ptr = pUlDevId as *const libc::c_char;
        let dev_id_str = if dev_id_ptr.is_null() {
            ""
        } else {
            match CStr::from_ptr(dev_id_ptr).to_str() {
                Ok(s) => s,
                Err(_) => "",
            }
        };
        println!("devId'{}, devBase'{}, innerIndex'{}, Addr'{}", dev_id_str, ulDevBase, ulDevInnerIndex, ulIdAddr);
    }
    retVal = BspIdToBase(
        s_tDevIdList.t_IdList as *mut libc::c_void,
        s_tDevIdList.ulIdListNum,
        ulDevId,
        &mut ulDevBase,
        &mut ulDevInnerIndex,
        &mut ulIdAddr,
    );
    if retVal != 0 as libc::c_int as UINT32 {
        return retVal;
    }
    println!("devId'{}, devBase'{}, innerIndex'{}, Addr'{}", ulDevId, ulDevBase, ulDevInnerIndex, ulIdAddr);
    return 0 as libc::c_int as UINT32;
}
//#[no_mangle]
pub unsafe extern "C" fn BspDevIdToLocation(mut ulDevId: UINT32) -> UINT32 {
    return BspIdToLocation(
        s_tDevIdList.t_IdList as *mut libc::c_void,
        s_tDevIdList.ulIdListNum,
        ulDevId,
    );
}
//#[no_mangle]
pub unsafe extern "C" fn BspDevLocationToName(mut ulLocation: UINT32) -> *mut UCHAR {
    return BspLocationToName(
        s_tDevIdList.t_IdList as *mut libc::c_void,
        s_tDevIdList.ulIdListNum,
        ulLocation,
    );
}
//#[no_mangle]
pub unsafe extern "C" fn BspDevShowIdList() -> UINT32 {
    return BspShowIdList(
        s_tDevIdList.t_IdList as *mut libc::c_void,
        s_tDevIdList.ulIdListNum,
    );
}
//#[no_mangle]
pub unsafe extern "C" fn BspFuncIdToName(
    mut ulFuncId: UINT32,
    mut pucAlias: *mut libc::c_char,
    mut ulAliasBufLen: UINT32,
) -> *mut UCHAR {
    if pucAlias.is_null() {
        println!("BspFuncIdToName:Input Pointer is NULL!");
        return 0 as *mut UCHAR;
    }
    return BspIdToName(
        s_tFuncIdList.t_IdList as *mut libc::c_void,
        s_tFuncIdList.ulIdListNum,
        ulFuncId,
        pucAlias,
        ulAliasBufLen,
    );
}
//#[no_mangle]
pub unsafe extern "C" fn BspFuncNameToId(
    mut pucFuncName: *const libc::c_char,
) -> UINT32 {
    if pucFuncName.is_null() {
        println!("BspFuncNameToId:Input Pointer is NULL!");
        return 0xff000002 as libc::c_uint;
    }
    return BspNameToId(
        s_tFuncIdList.t_IdList as *mut libc::c_void,
        s_tFuncIdList.ulIdListNum,
        pucFuncName,
    );
}
//#[no_mangle]
pub unsafe extern "C" fn BspFuncIdToBase(
    mut ulFuncId: UINT32,
    mut pulFuncBase: *mut UINT32,
    mut pulFuncInnerIndex: *mut UINT32,
) -> UINT32 {
    let mut ulRet: UINT32 = 0 as libc::c_int as UINT32;
    let mut ulIdAddr: UINT32 = 0xffffffff as libc::c_uint;
    let mut pUlFuncId: uintptr_t = ulFuncId as uintptr_t;
    if pulFuncBase.is_null() || pulFuncInnerIndex.is_null() {
        println!("Input Pointer is NULL!");
        return 0xff000002 as libc::c_uint;
    }
    if ulFuncId > 0x10000 as libc::c_int as libc::c_uint {
        ulRet = BspNameToBase(
            s_tFuncIdList.t_IdList as *mut libc::c_void,
            s_tFuncIdList.ulIdListNum,
            pUlFuncId as *const libc::c_char,
            pulFuncBase,
            pulFuncInnerIndex,
            &mut ulIdAddr,
        );
    } else {
        ulRet = BspIdToBase(
            s_tFuncIdList.t_IdList as *mut libc::c_void,
            s_tFuncIdList.ulIdListNum,
            ulFuncId,
            pulFuncBase,
            pulFuncInnerIndex,
            &mut ulIdAddr,
        );
    }
    return if ulRet == 0 as libc::c_int as UINT32 {
        ulIdAddr
    } else {
        0xffffffff as libc::c_uint
    };
}
//#[no_mangle]
pub unsafe extern "C" fn BspFuncShowIdList() -> UINT32 {
    return BspShowIdList(
        s_tFuncIdList.t_IdList as *mut libc::c_void,
        s_tFuncIdList.ulIdListNum,
    );
}
//#[no_mangle]
pub unsafe extern "C" fn BspThresholdIdToName(
    mut ulThresholdId: UINT32,
    mut pucAlias: *mut libc::c_char,
    mut ulAliasBufLen: UINT32,
) -> *mut UCHAR {
    if pucAlias.is_null() {
        println!("BspThresholdIdToName:Input Pointer is NULL!");
        return 0 as *mut UCHAR;
    }
    return BspIdToName(
        s_tThresholdIdList.t_IdList as *mut libc::c_void,
        s_tThresholdIdList.ulIdListNum,
        ulThresholdId,
        pucAlias,
        ulAliasBufLen,
    );
}
//#[no_mangle]
pub unsafe extern "C" fn BspThresholdNameToId(
    mut pucThresholdName: *const libc::c_char,
) -> UINT32 {
    if pucThresholdName.is_null() {
        println!("BspThresholdNameToId:Input Pointer is NULL!");
        return 0xff000002 as libc::c_uint;
    }
    return BspNameToId(
        s_tThresholdIdList.t_IdList as *mut libc::c_void,
        s_tThresholdIdList.ulIdListNum,
        pucThresholdName,
    );
}
//#[no_mangle]
pub unsafe extern "C" fn BspThresholdIdToBase(
    mut ulThresholdId: UINT32,
    mut pulThresholdBase: *mut UINT32,
    mut pulThresholdInnerIndex: *mut UINT32,
) -> UINT32 {
    let mut ulRet: UINT32 = 0 as libc::c_int as UINT32;
    let mut ulIdAddr: UINT32 = 0xffffffff as libc::c_uint;
    let mut pUlThresholdId: uintptr_t = ulThresholdId as uintptr_t;
    if pulThresholdBase.is_null() || pulThresholdInnerIndex.is_null() {
        println!("Input Pointer is NULL!");
        return 0xff000002 as libc::c_uint;
    }
    if ulThresholdId > 0x10000 as libc::c_int as libc::c_uint {
        ulRet = BspNameToBase(
            s_tThresholdIdList.t_IdList as *mut libc::c_void,
            s_tThresholdIdList.ulIdListNum,
            pUlThresholdId as *const libc::c_char,
            pulThresholdBase,
            pulThresholdInnerIndex,
            &mut ulIdAddr,
        );
    } else {
        ulRet = BspIdToBase(
            s_tThresholdIdList.t_IdList as *mut libc::c_void,
            s_tThresholdIdList.ulIdListNum,
            ulThresholdId,
            pulThresholdBase,
            pulThresholdInnerIndex,
            &mut ulIdAddr,
        );
    }
    return if ulRet == 0 as libc::c_int as UINT32 {
        ulIdAddr
    } else {
        0xffffffff as libc::c_uint
    };
}
//#[no_mangle]
pub unsafe extern "C" fn BspThresholdShowIdList() -> UINT32 {
    return BspShowIdList(
        s_tThresholdIdList.t_IdList as *mut libc::c_void,
        s_tThresholdIdList.ulIdListNum,
    );
}
//#[no_mangle]
pub unsafe extern "C" fn BspGainIdToName(
    mut ulGainId: UINT32,
    mut pucAlias: *mut libc::c_char,
    mut ulAliasBufLen: UINT32,
) -> *mut UCHAR {
    if pucAlias.is_null() {
        println!("BspGainIdToName:Input Pointer is NULL!");
        return 0 as *mut UCHAR;
    }
    return BspIdToName(
        s_tGainIdList.t_IdList as *mut libc::c_void,
        s_tGainIdList.ulIdListNum,
        ulGainId,
        pucAlias,
        ulAliasBufLen,
    );
}
//#[no_mangle]
pub unsafe extern "C" fn BspGainNameToId(
    mut pucGainName: *const libc::c_char,
) -> UINT32 {
    if pucGainName.is_null() {
        println!("BspGainNameToId:Input Pointer is NULL!");
        return 0xff000002 as libc::c_uint;
    }
    return BspNameToId(
        s_tGainIdList.t_IdList as *mut libc::c_void,
        s_tGainIdList.ulIdListNum,
        pucGainName,
    );
}
//#[no_mangle]
pub unsafe extern "C" fn BspGainIdToBase(
    mut ulGainId: UINT32,
    mut pulGainBase: *mut UINT32,
    mut pulGainInnerIndex: *mut UINT32,
) -> UINT32 {
    let mut ulRet: UINT32 = 0 as libc::c_int as UINT32;
    let mut ulIdAddr: UINT32 = 0xffffffff as libc::c_uint;
    let mut pUlGainId: uintptr_t = ulGainId as uintptr_t;
    if pulGainBase.is_null() || pulGainInnerIndex.is_null() {
        println!("Input Pointer is NULL!");
        return 0xff000002 as libc::c_uint;
    }
    if ulGainId > 0x10000 as libc::c_int as libc::c_uint {
        ulRet = BspNameToBase(
            s_tGainIdList.t_IdList as *mut libc::c_void,
            s_tGainIdList.ulIdListNum,
            pUlGainId as *const libc::c_char,
            pulGainBase,
            pulGainInnerIndex,
            &mut ulIdAddr,
        );
    } else {
        ulRet = BspIdToBase(
            s_tGainIdList.t_IdList as *mut libc::c_void,
            s_tGainIdList.ulIdListNum,
            ulGainId,
            pulGainBase,
            pulGainInnerIndex,
            &mut ulIdAddr,
        );
    }
    return if ulRet == 0 as libc::c_int as UINT32 {
        ulIdAddr
    } else {
        0xffffffff as libc::c_uint
    };
}
//#[no_mangle]
pub unsafe extern "C" fn BspGainShowIdList() -> UINT32 {
    return BspShowIdList(
        s_tGainIdList.t_IdList as *mut libc::c_void,
        s_tGainIdList.ulIdListNum,
    );
}
//#[no_mangle]
pub unsafe extern "C" fn BspSetDevNumbyName(
    mut ptTbl: *mut libc::c_char,
    mut ulNum: UINT32,
) -> UINT32 {
    let mut ulNumAll: UINT32 = 0 as libc::c_int as UINT32;
    let mut ulIndex: UINT32 = 0 as libc::c_int as UINT32;
    let mut ulRetVal: UINT32 = 0xffffffff as libc::c_uint;
    if ptTbl.is_null() {
        println!("BspSetDevNumbyName:Input Pointer is NULL!");
        return 0xff000002 as libc::c_uint;
    }
    // 使用 Rust 风格的代码替换 mzprnL
    let tbl_str = if ptTbl.is_null() {
        ""
    } else {
        match CStr::from_ptr(ptTbl).to_str() {
            Ok(s) => s,
            Err(_) => "",
        }
    };
    println!("BspSetDevNumbyName>>Input String is {}", tbl_str);
    let mut ptItem: *mut T_BoardIdItem = s_tDevIdList.t_IdList;
    ulNumAll = s_tDevIdList.ulIdListNum;
    ulIndex = 0 as libc::c_int as UINT32;
    while ulIndex < ulNumAll {
        if strcmp(ptTbl, (*ptItem).pucName) == 0 as libc::c_int {
            (*ptItem).ulIdNum = ulNum;
            // 使用 Rust 风格的代码替换 mzprnL
            let name_str = if (*ptItem).pucName.is_null() {
                ""
            } else {
                match CStr::from_ptr((*ptItem).pucName).to_str() {
                    Ok(s) => s,
                    Err(_) => "",
                }
            };
            println!("BspSetDevNumbyName:Dev Name id {}, Dev Num is {}", name_str, ulNum);
            ulRetVal = 0 as libc::c_int as UINT32;
            return ulRetVal;
        }
        ulIndex = ulIndex.wrapping_add(1);
        ulIndex;
        ptItem = ptItem.offset(1);
        ptItem;
    }
    return ulRetVal;
}
//#[no_mangle]
pub unsafe extern "C" fn BspDevNumIndexbyName(
    mut ptTbl: *mut libc::c_char,
    mut ulNums: *mut UINT32,
) -> UINT32 {
    let mut ulNumAll: UINT32 = 0 as libc::c_int as UINT32;
    let mut ulIndex: UINT32 = 0 as libc::c_int as UINT32;
    let mut ulRetVal: UINT32 = 0xffffffff as libc::c_uint;
    if ptTbl.is_null() {
        println!("BspDevNumIndexbyName:Input Pointer is NULL!");
        return 0xff000002 as libc::c_uint;
    }
    if ulNums.is_null() {
        println!("BspDevNumIndexbyName:Input Pointer is NULL!");
        return 0xff000002 as libc::c_uint;
    }
    let mut ptItem: *mut T_BoardIdItem = s_tDevIdList.t_IdList;
    ulNumAll = s_tDevIdList.ulIdListNum;
    ulIndex = 0 as libc::c_int as UINT32;
    while ulIndex < ulNumAll {
        if strcmp(ptTbl, (*ptItem).pucName) == 0 as libc::c_int {
            *ulNums = (*ptItem).ulIdNum;
            ulRetVal = 0 as libc::c_int as UINT32;
            return ulRetVal;
        }
        ulIndex = ulIndex.wrapping_add(1);
        ulIndex;
        ptItem = ptItem.offset(1);
        ptItem;
    }
    return ulRetVal;
}
//#[no_mangle]
pub unsafe extern "C" fn BspSetDeviceIdList(
    mut ptDeviceIdList: *mut T_BoardIdItem,
    mut ulDeviceIdListNum: UINT32,
) -> UINT32 {
    if ptDeviceIdList.is_null() {
        println!("BspSetDeviceIdList:Input Pointer is NULL!");
        return 0xff000002 as libc::c_uint;
    }
    s_tDevIdList.t_IdList = ptDeviceIdList;
    s_tDevIdList.ulIdListNum = ulDeviceIdListNum;
    BspIdAddrInit(s_tDevIdList.t_IdList as *mut libc::c_void, s_tDevIdList.ulIdListNum);
    return 0 as libc::c_int as UINT32;
}
//#[no_mangle]
pub unsafe extern "C" fn BspSetThresholdIdList(
    mut ptThresholdIdList: *mut T_BoardIdItem,
    mut ulThresholdIdListNum: UINT32,
) -> UINT32 {
    if ptThresholdIdList.is_null() {
        println!("BspSetThresholdIdList:Input Pointer is NULL!");
        return 0xff000002 as libc::c_uint;
    }
    s_tThresholdIdList.t_IdList = ptThresholdIdList;
    s_tThresholdIdList.ulIdListNum = ulThresholdIdListNum;
    BspIdAddrInit(
        s_tThresholdIdList.t_IdList as *mut libc::c_void,
        s_tThresholdIdList.ulIdListNum,
    );
    return 0 as libc::c_int as UINT32;
}
//#[no_mangle]
pub unsafe extern "C" fn BspSetFuncIdList(
    mut ptFuncIdList: *mut T_BoardIdItem,
    mut ulFuncIdListNum: UINT32,
) -> UINT32 {
    if ptFuncIdList.is_null() {
        println!("BspSetFuncIdList:Input Pointer is NULL!");
        return 0xff000002 as libc::c_uint;
    }
    s_tFuncIdList.t_IdList = ptFuncIdList;
    s_tFuncIdList.ulIdListNum = ulFuncIdListNum;
    BspIdAddrInit(
        s_tFuncIdList.t_IdList as *mut libc::c_void,
        s_tFuncIdList.ulIdListNum,
    );
    return 0 as libc::c_int as UINT32;
}
//#[no_mangle]
pub unsafe extern "C" fn BspSetGainIdList(
    mut ptGainIdList: *mut T_BoardIdItem,
    mut ulGainIdListNum: UINT32,
) -> UINT32 {
    if ptGainIdList.is_null() {
        println!("BspSetGainIdList:Input Pointer is NULL!");
        return 0xff000002 as libc::c_uint;
    }
    s_tGainIdList.t_IdList = ptGainIdList;
    s_tGainIdList.ulIdListNum = ulGainIdListNum;
    BspIdAddrInit(
        s_tGainIdList.t_IdList as *mut libc::c_void,
        s_tGainIdList.ulIdListNum,
    );
    return 0 as libc::c_int as UINT32;
}

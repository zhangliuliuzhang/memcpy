#![allow(
    dead_code,
    mutable_transmutes,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    unused_assignments,
    unused_mut
)]

use ccommon::clib::*;

unsafe extern "C" {
    // fn open(__file: *const libc::c_char, __oflag: libc::c_int, _: ...) -> libc::c_int;
    // fn strstr(_: *const libc::c_char, _: *const libc::c_char) -> *mut libc::c_char;
    // fn strerror(_: libc::c_int) -> *mut libc::c_char;
    // fn close(__fd: libc::c_int) -> libc::c_int;
    // fn write(__fd: libc::c_int, __buf: *const libc::c_void, __n: size_t) -> ssize_t;
    // fn sync();
    // fn fclose(__stream: *mut FILE) -> libc::c_int;
    // fn fopen(_: *const libc::c_char, _: *const libc::c_char) -> *mut FILE;
    // fn fgets(
    //     __s: *mut libc::c_char,
    //     __n: libc::c_int,
    //     __stream: *mut FILE,
    // ) -> *mut libc::c_char;
    // fn fseek(
    //     __stream: *mut FILE,
    //     __off: libc::c_long,
    //     __whence: libc::c_int,
    // ) -> libc::c_int;
    // fn perror(__s: *const libc::c_char);
    // fn __errno_location() -> *mut libc::c_int;
    // fn strtol(
    //     _: *const libc::c_char,
    //     _: *mut *mut libc::c_char,
    //     _: libc::c_int,
    // ) -> libc::c_long;
    // fn encapsulationOfZte_memcpy_s(
    //     s1: *mut libc::c_void,
    //     s1max: rsize_t,
    //     s2: *const libc::c_void,
    //     n: rsize_t,
    //     fileName: *const libc::c_char,
    //     lineNo: libc::c_int,
    // ) -> libc::c_int;
    // fn encapsulationOfZte_memset_s(
    //     s: *mut libc::c_void,
    //     smax: rsize_t,
    //     c: libc::c_int,
    //     n: rsize_t,
    //     fileName: *const libc::c_char,
    //     lineNo: libc::c_int,
    // ) -> libc::c_int;
    // fn BspUmountForce(modulenames: *mut libc::c_char) -> ULONG;
    static mut part_info_ctl: [INT32; 4];
    static mut part_gc_ctl: [INT32; 4];
}
pub type __off_t = libc::c_long;
pub type __off64_t = libc::c_long;
pub type __ssize_t = libc::c_long;
pub type ssize_t = __ssize_t;
pub type size_t = libc::c_ulong;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct __sysctl_args {
    pub name: *mut libc::c_int,
    pub nlen: libc::c_int,
    pub oldval: *mut libc::c_void,
    pub oldlenp: *mut size_t,
    pub newval: *mut libc::c_void,
    pub newlen: size_t,
    pub __unused: [libc::c_ulong; 4],
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct _IO_FILE {
    pub _flags: libc::c_int,
    pub _IO_read_ptr: *mut libc::c_char,
    pub _IO_read_end: *mut libc::c_char,
    pub _IO_read_base: *mut libc::c_char,
    pub _IO_write_base: *mut libc::c_char,
    pub _IO_write_ptr: *mut libc::c_char,
    pub _IO_write_end: *mut libc::c_char,
    pub _IO_buf_base: *mut libc::c_char,
    pub _IO_buf_end: *mut libc::c_char,
    pub _IO_save_base: *mut libc::c_char,
    pub _IO_backup_base: *mut libc::c_char,
    pub _IO_save_end: *mut libc::c_char,
    pub _chain: *mut _IO_FILE,
    pub _fileno: libc::c_int,
    pub _flags2: libc::c_int,
    pub _old_offset: __off_t,
    pub _cur_column: libc::c_ushort,
    pub _vtable_offset: libc::c_schar,
    pub _shortbuf: [libc::c_char; 1],
    pub _lock: *mut libc::c_void,
    pub _offset: __off64_t,
    pub _freeres_list: *mut _IO_FILE,
    pub _freeres_buf: *mut libc::c_void,
    pub __pad5: size_t,
    pub _mode: libc::c_int,
    pub _unused2: [libc::c_char; 20],
}
pub type _IO_lock_t = ();
pub type FILE = _IO_FILE;
pub type UCHAR = libc::c_uchar;
pub type CHAR = libc::c_char;
pub type ULONG = libc::c_uint;
pub type UINT32 = libc::c_uint;
pub type INT32 = libc::c_int;
pub type LONG = libc::c_long;
pub type rsize_t = size_t;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct jffs2_flash_info {
    pub cleanmarker_s: libc::c_uint,
    pub flash_s: libc::c_uint,
    pub used_s: libc::c_uint,
    pub dirty_s: libc::c_uint,
    pub wasted_s: libc::c_uint,
    pub free_s: libc::c_uint,
    pub erasing_s: libc::c_uint,
    pub bad_s: libc::c_uint,
    pub sector_s: libc::c_uint,
    pub unchecked_s: libc::c_uint,
    pub h_ino: libc::c_uint,
    pub c_ino: libc::c_uint,
    pub flag: libc::c_uint,
    pub n_free_blocks: libc::c_uint,
    pub n_erasing_blocks: libc::c_uint,
    pub r_blocks_write: libc::c_uint,
    pub r_blocks_deletion: libc::c_uint,
    pub r_blocks_gctrigger: libc::c_uint,
    pub r_blocks_gcbad: libc::c_uint,
    pub r_blocks_gcmerge: libc::c_uint,
    pub no_dirty_size: libc::c_uint,
    pub n_blocks: libc::c_uint,
    pub w_pagesize: libc::c_uint,
    pub t_ino: libc::c_uint,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct tagT_MtdPartitionInfo {
    pub name: *const CHAR,
    pub type_0: *const CHAR,
    pub mnt: *const CHAR,
    pub dev: *const CHAR,
    pub size: ULONG,
    pub erasesize: ULONG,
}
pub type jffs2_unknown_node = T_jffs2_unknown_node;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct T_jffs2_unknown_node {
    pub magic: libc::c_ushort,
    pub nodetype: libc::c_ushort,
    pub totlen: libc::c_uint,
    pub hdr_crc: libc::c_uint,
}
pub static mut g_iFlashRecycleCount: INT32 = 0 as libc::c_int;
pub static mut crc32_table: [libc::c_uint; 256] = [
    0 as libc::c_long as libc::c_uint,
    0x77073096 as libc::c_long as libc::c_uint,
    0xee0e612c as libc::c_long as libc::c_uint,
    0x990951ba as libc::c_long as libc::c_uint,
    0x76dc419 as libc::c_long as libc::c_uint,
    0x706af48f as libc::c_long as libc::c_uint,
    0xe963a535 as libc::c_long as libc::c_uint,
    0x9e6495a3 as libc::c_long as libc::c_uint,
    0xedb8832 as libc::c_long as libc::c_uint,
    0x79dcb8a4 as libc::c_long as libc::c_uint,
    0xe0d5e91e as libc::c_long as libc::c_uint,
    0x97d2d988 as libc::c_long as libc::c_uint,
    0x9b64c2b as libc::c_long as libc::c_uint,
    0x7eb17cbd as libc::c_long as libc::c_uint,
    0xe7b82d07 as libc::c_long as libc::c_uint,
    0x90bf1d91 as libc::c_long as libc::c_uint,
    0x1db71064 as libc::c_long as libc::c_uint,
    0x6ab020f2 as libc::c_long as libc::c_uint,
    0xf3b97148 as libc::c_long as libc::c_uint,
    0x84be41de as libc::c_long as libc::c_uint,
    0x1adad47d as libc::c_long as libc::c_uint,
    0x6ddde4eb as libc::c_long as libc::c_uint,
    0xf4d4b551 as libc::c_long as libc::c_uint,
    0x83d385c7 as libc::c_long as libc::c_uint,
    0x136c9856 as libc::c_long as libc::c_uint,
    0x646ba8c0 as libc::c_long as libc::c_uint,
    0xfd62f97a as libc::c_long as libc::c_uint,
    0x8a65c9ec as libc::c_long as libc::c_uint,
    0x14015c4f as libc::c_long as libc::c_uint,
    0x63066cd9 as libc::c_long as libc::c_uint,
    0xfa0f3d63 as libc::c_long as libc::c_uint,
    0x8d080df5 as libc::c_long as libc::c_uint,
    0x3b6e20c8 as libc::c_long as libc::c_uint,
    0x4c69105e as libc::c_long as libc::c_uint,
    0xd56041e4 as libc::c_long as libc::c_uint,
    0xa2677172 as libc::c_long as libc::c_uint,
    0x3c03e4d1 as libc::c_long as libc::c_uint,
    0x4b04d447 as libc::c_long as libc::c_uint,
    0xd20d85fd as libc::c_long as libc::c_uint,
    0xa50ab56b as libc::c_long as libc::c_uint,
    0x35b5a8fa as libc::c_long as libc::c_uint,
    0x42b2986c as libc::c_long as libc::c_uint,
    0xdbbbc9d6 as libc::c_long as libc::c_uint,
    0xacbcf940 as libc::c_long as libc::c_uint,
    0x32d86ce3 as libc::c_long as libc::c_uint,
    0x45df5c75 as libc::c_long as libc::c_uint,
    0xdcd60dcf as libc::c_long as libc::c_uint,
    0xabd13d59 as libc::c_long as libc::c_uint,
    0x26d930ac as libc::c_long as libc::c_uint,
    0x51de003a as libc::c_long as libc::c_uint,
    0xc8d75180 as libc::c_long as libc::c_uint,
    0xbfd06116 as libc::c_long as libc::c_uint,
    0x21b4f4b5 as libc::c_long as libc::c_uint,
    0x56b3c423 as libc::c_long as libc::c_uint,
    0xcfba9599 as libc::c_long as libc::c_uint,
    0xb8bda50f as libc::c_long as libc::c_uint,
    0x2802b89e as libc::c_long as libc::c_uint,
    0x5f058808 as libc::c_long as libc::c_uint,
    0xc60cd9b2 as libc::c_long as libc::c_uint,
    0xb10be924 as libc::c_long as libc::c_uint,
    0x2f6f7c87 as libc::c_long as libc::c_uint,
    0x58684c11 as libc::c_long as libc::c_uint,
    0xc1611dab as libc::c_long as libc::c_uint,
    0xb6662d3d as libc::c_long as libc::c_uint,
    0x76dc4190 as libc::c_long as libc::c_uint,
    0x1db7106 as libc::c_long as libc::c_uint,
    0x98d220bc as libc::c_long as libc::c_uint,
    0xefd5102a as libc::c_long as libc::c_uint,
    0x71b18589 as libc::c_long as libc::c_uint,
    0x6b6b51f as libc::c_long as libc::c_uint,
    0x9fbfe4a5 as libc::c_long as libc::c_uint,
    0xe8b8d433 as libc::c_long as libc::c_uint,
    0x7807c9a2 as libc::c_long as libc::c_uint,
    0xf00f934 as libc::c_long as libc::c_uint,
    0x9609a88e as libc::c_long as libc::c_uint,
    0xe10e9818 as libc::c_long as libc::c_uint,
    0x7f6a0dbb as libc::c_long as libc::c_uint,
    0x86d3d2d as libc::c_long as libc::c_uint,
    0x91646c97 as libc::c_long as libc::c_uint,
    0xe6635c01 as libc::c_long as libc::c_uint,
    0x6b6b51f4 as libc::c_long as libc::c_uint,
    0x1c6c6162 as libc::c_long as libc::c_uint,
    0x856530d8 as libc::c_long as libc::c_uint,
    0xf262004e as libc::c_long as libc::c_uint,
    0x6c0695ed as libc::c_long as libc::c_uint,
    0x1b01a57b as libc::c_long as libc::c_uint,
    0x8208f4c1 as libc::c_long as libc::c_uint,
    0xf50fc457 as libc::c_long as libc::c_uint,
    0x65b0d9c6 as libc::c_long as libc::c_uint,
    0x12b7e950 as libc::c_long as libc::c_uint,
    0x8bbeb8ea as libc::c_long as libc::c_uint,
    0xfcb9887c as libc::c_long as libc::c_uint,
    0x62dd1ddf as libc::c_long as libc::c_uint,
    0x15da2d49 as libc::c_long as libc::c_uint,
    0x8cd37cf3 as libc::c_long as libc::c_uint,
    0xfbd44c65 as libc::c_long as libc::c_uint,
    0x4db26158 as libc::c_long as libc::c_uint,
    0x3ab551ce as libc::c_long as libc::c_uint,
    0xa3bc0074 as libc::c_long as libc::c_uint,
    0xd4bb30e2 as libc::c_long as libc::c_uint,
    0x4adfa541 as libc::c_long as libc::c_uint,
    0x3dd895d7 as libc::c_long as libc::c_uint,
    0xa4d1c46d as libc::c_long as libc::c_uint,
    0xd3d6f4fb as libc::c_long as libc::c_uint,
    0x4369e96a as libc::c_long as libc::c_uint,
    0x346ed9fc as libc::c_long as libc::c_uint,
    0xad678846 as libc::c_long as libc::c_uint,
    0xda60b8d0 as libc::c_long as libc::c_uint,
    0x44042d73 as libc::c_long as libc::c_uint,
    0x33031de5 as libc::c_long as libc::c_uint,
    0xaa0a4c5f as libc::c_long as libc::c_uint,
    0xdd0d7cc9 as libc::c_long as libc::c_uint,
    0x5005713c as libc::c_long as libc::c_uint,
    0x270241aa as libc::c_long as libc::c_uint,
    0xbe0b1010 as libc::c_long as libc::c_uint,
    0xc90c2086 as libc::c_long as libc::c_uint,
    0x5768b525 as libc::c_long as libc::c_uint,
    0x206f85b3 as libc::c_long as libc::c_uint,
    0xb966d409 as libc::c_long as libc::c_uint,
    0xce61e49f as libc::c_long as libc::c_uint,
    0x5edef90e as libc::c_long as libc::c_uint,
    0x29d9c998 as libc::c_long as libc::c_uint,
    0xb0d09822 as libc::c_long as libc::c_uint,
    0xc7d7a8b4 as libc::c_long as libc::c_uint,
    0x59b33d17 as libc::c_long as libc::c_uint,
    0x2eb40d81 as libc::c_long as libc::c_uint,
    0xb7bd5c3b as libc::c_long as libc::c_uint,
    0xc0ba6cad as libc::c_long as libc::c_uint,
    0xedb88320 as libc::c_long as libc::c_uint,
    0x9abfb3b6 as libc::c_long as libc::c_uint,
    0x3b6e20c as libc::c_long as libc::c_uint,
    0x74b1d29a as libc::c_long as libc::c_uint,
    0xead54739 as libc::c_long as libc::c_uint,
    0x9dd277af as libc::c_long as libc::c_uint,
    0x4db2615 as libc::c_long as libc::c_uint,
    0x73dc1683 as libc::c_long as libc::c_uint,
    0xe3630b12 as libc::c_long as libc::c_uint,
    0x94643b84 as libc::c_long as libc::c_uint,
    0xd6d6a3e as libc::c_long as libc::c_uint,
    0x7a6a5aa8 as libc::c_long as libc::c_uint,
    0xe40ecf0b as libc::c_long as libc::c_uint,
    0x9309ff9d as libc::c_long as libc::c_uint,
    0xa00ae27 as libc::c_long as libc::c_uint,
    0x7d079eb1 as libc::c_long as libc::c_uint,
    0xf00f9344 as libc::c_long as libc::c_uint,
    0x8708a3d2 as libc::c_long as libc::c_uint,
    0x1e01f268 as libc::c_long as libc::c_uint,
    0x6906c2fe as libc::c_long as libc::c_uint,
    0xf762575d as libc::c_long as libc::c_uint,
    0x806567cb as libc::c_long as libc::c_uint,
    0x196c3671 as libc::c_long as libc::c_uint,
    0x6e6b06e7 as libc::c_long as libc::c_uint,
    0xfed41b76 as libc::c_long as libc::c_uint,
    0x89d32be0 as libc::c_long as libc::c_uint,
    0x10da7a5a as libc::c_long as libc::c_uint,
    0x67dd4acc as libc::c_long as libc::c_uint,
    0xf9b9df6f as libc::c_long as libc::c_uint,
    0x8ebeeff9 as libc::c_long as libc::c_uint,
    0x17b7be43 as libc::c_long as libc::c_uint,
    0x60b08ed5 as libc::c_long as libc::c_uint,
    0xd6d6a3e8 as libc::c_long as libc::c_uint,
    0xa1d1937e as libc::c_long as libc::c_uint,
    0x38d8c2c4 as libc::c_long as libc::c_uint,
    0x4fdff252 as libc::c_long as libc::c_uint,
    0xd1bb67f1 as libc::c_long as libc::c_uint,
    0xa6bc5767 as libc::c_long as libc::c_uint,
    0x3fb506dd as libc::c_long as libc::c_uint,
    0x48b2364b as libc::c_long as libc::c_uint,
    0xd80d2bda as libc::c_long as libc::c_uint,
    0xaf0a1b4c as libc::c_long as libc::c_uint,
    0x36034af6 as libc::c_long as libc::c_uint,
    0x41047a60 as libc::c_long as libc::c_uint,
    0xdf60efc3 as libc::c_long as libc::c_uint,
    0xa867df55 as libc::c_long as libc::c_uint,
    0x316e8eef as libc::c_long as libc::c_uint,
    0x4669be79 as libc::c_long as libc::c_uint,
    0xcb61b38c as libc::c_long as libc::c_uint,
    0xbc66831a as libc::c_long as libc::c_uint,
    0x256fd2a0 as libc::c_long as libc::c_uint,
    0x5268e236 as libc::c_long as libc::c_uint,
    0xcc0c7795 as libc::c_long as libc::c_uint,
    0xbb0b4703 as libc::c_long as libc::c_uint,
    0x220216b9 as libc::c_long as libc::c_uint,
    0x5505262f as libc::c_long as libc::c_uint,
    0xc5ba3bbe as libc::c_long as libc::c_uint,
    0xb2bd0b28 as libc::c_long as libc::c_uint,
    0x2bb45a92 as libc::c_long as libc::c_uint,
    0x5cb36a04 as libc::c_long as libc::c_uint,
    0xc2d7ffa7 as libc::c_long as libc::c_uint,
    0xb5d0cf31 as libc::c_long as libc::c_uint,
    0x2cd99e8b as libc::c_long as libc::c_uint,
    0x5bdeae1d as libc::c_long as libc::c_uint,
    0x9b64c2b0 as libc::c_long as libc::c_uint,
    0xec63f226 as libc::c_long as libc::c_uint,
    0x756aa39c as libc::c_long as libc::c_uint,
    0x26d930a as libc::c_long as libc::c_uint,
    0x9c0906a9 as libc::c_long as libc::c_uint,
    0xeb0e363f as libc::c_long as libc::c_uint,
    0x72076785 as libc::c_long as libc::c_uint,
    0x5005713 as libc::c_long as libc::c_uint,
    0x95bf4a82 as libc::c_long as libc::c_uint,
    0xe2b87a14 as libc::c_long as libc::c_uint,
    0x7bb12bae as libc::c_long as libc::c_uint,
    0xcb61b38 as libc::c_long as libc::c_uint,
    0x92d28e9b as libc::c_long as libc::c_uint,
    0xe5d5be0d as libc::c_long as libc::c_uint,
    0x7cdcefb7 as libc::c_long as libc::c_uint,
    0xbdbdf21 as libc::c_long as libc::c_uint,
    0x86d3d2d4 as libc::c_long as libc::c_uint,
    0xf1d4e242 as libc::c_long as libc::c_uint,
    0x68ddb3f8 as libc::c_long as libc::c_uint,
    0x1fda836e as libc::c_long as libc::c_uint,
    0x81be16cd as libc::c_long as libc::c_uint,
    0xf6b9265b as libc::c_long as libc::c_uint,
    0x6fb077e1 as libc::c_long as libc::c_uint,
    0x18b74777 as libc::c_long as libc::c_uint,
    0x88085ae6 as libc::c_long as libc::c_uint,
    0xff0f6a70 as libc::c_long as libc::c_uint,
    0x66063bca as libc::c_long as libc::c_uint,
    0x11010b5c as libc::c_long as libc::c_uint,
    0x8f659eff as libc::c_long as libc::c_uint,
    0xf862ae69 as libc::c_long as libc::c_uint,
    0x616bffd3 as libc::c_long as libc::c_uint,
    0x166ccf45 as libc::c_long as libc::c_uint,
    0xa00ae278 as libc::c_long as libc::c_uint,
    0xd70dd2ee as libc::c_long as libc::c_uint,
    0x4e048354 as libc::c_long as libc::c_uint,
    0x3903b3c2 as libc::c_long as libc::c_uint,
    0xa7672661 as libc::c_long as libc::c_uint,
    0xd06016f7 as libc::c_long as libc::c_uint,
    0x4969474d as libc::c_long as libc::c_uint,
    0x3e6e77db as libc::c_long as libc::c_uint,
    0xaed16a4a as libc::c_long as libc::c_uint,
    0xd9d65adc as libc::c_long as libc::c_uint,
    0x40df0b66 as libc::c_long as libc::c_uint,
    0x37d83bf0 as libc::c_long as libc::c_uint,
    0xa9bcae53 as libc::c_long as libc::c_uint,
    0xdebb9ec5 as libc::c_long as libc::c_uint,
    0x47b2cf7f as libc::c_long as libc::c_uint,
    0x30b5ffe9 as libc::c_long as libc::c_uint,
    0xbdbdf21c as libc::c_long as libc::c_uint,
    0xcabac28a as libc::c_long as libc::c_uint,
    0x53b39330 as libc::c_long as libc::c_uint,
    0x24b4a3a6 as libc::c_long as libc::c_uint,
    0xbad03605 as libc::c_long as libc::c_uint,
    0xcdd70693 as libc::c_long as libc::c_uint,
    0x54de5729 as libc::c_long as libc::c_uint,
    0x23d967bf as libc::c_long as libc::c_uint,
    0xb3667a2e as libc::c_long as libc::c_uint,
    0xc4614ab8 as libc::c_long as libc::c_uint,
    0x5d681b02 as libc::c_long as libc::c_uint,
    0x2a6f2b94 as libc::c_long as libc::c_uint,
    0xb40bbe37 as libc::c_long as libc::c_uint,
    0xc30c8ea1 as libc::c_long as libc::c_uint,
    0x5a05df1b as libc::c_long as libc::c_uint,
    0x2d02ef8d as libc::c_long as libc::c_uint,
];
static mut jffsName: [libc::c_char; 6] = unsafe {
    *::core::mem::transmute::<&[u8; 6], &mut [libc::c_char; 6]>(b"JFFS2\0")
};
static mut jffsType: [libc::c_char; 6] = unsafe {
    *::core::mem::transmute::<&[u8; 6], &mut [libc::c_char; 6]>(b"jffs2\0")
};
static mut jffsMnt: [libc::c_char; 10] = unsafe {
    *::core::mem::transmute::<&[u8; 10], &mut [libc::c_char; 10]>(b"/mnt/jffs\0")
};

#[inline]
pub unsafe extern "C" fn crc32(
    mut val: libc::c_uint,
    mut ss: *const libc::c_void,
    mut len: libc::c_int,
) -> libc::c_uint {
    let mut s: *const libc::c_uchar = ss as *const libc::c_uchar;
    loop {
        len -= 1;
        if !(len >= 0 as libc::c_int) {
            break;
        }
        let fresh0 = s;
        unsafe {
            s = s.offset(1);
            val = crc32_table[((val ^ *fresh0 as libc::c_uint)
                & 0xff as libc::c_int as libc::c_uint) as usize] ^ val >> 8 as libc::c_int;
        }
    }
    return val;
}

/// Rust 版本的 syscall 包装函数
/// 用于调用系统调用号 156 (sysctl)
pub unsafe fn syscall_sysctl(args: *mut __sysctl_args) -> libc::c_long {
    // 系统调用号 156 对应 sysctl
    const SYS_SYSCTL: libc::c_long = 156;
    
    // 使用 libc::syscall 调用系统调用
    unsafe {
        libc::syscall(SYS_SYSCTL, args)
    }
}

/// Rust 版本的 perror 函数
/// 打印错误信息，格式：prefix: error message
pub unsafe fn perror_rust(prefix: *const libc::c_char) {
    use std::ffi::CStr;
    use std::io::Error;
    
    // 获取最后一个系统错误
    let error = Error::last_os_error();
    let error_msg = error.to_string();
    
    // 将 C 字符串转换为 Rust 字符串
    let prefix_str = if prefix.is_null() {
        ""
    } else {
        match CStr::from_ptr(prefix).to_str() {
            Ok(s) => s,
            Err(_) => "",
        }
    };
    
    // 打印错误信息，格式：prefix: error message
    if prefix_str.is_empty() {
        eprintln!("{}", error_msg);
    } else {
        eprintln!("{}: {}", prefix_str, error_msg);
    }
}

/// Rust 版本的 memcpy_s 函数
/// 安全的内存复制函数，包含边界检查
/// 参数：
///   - s1: 目标内存地址
///   - s1max: 目标缓冲区最大大小
///   - s2: 源内存地址
///   - n: 要复制的字节数
///   - fileName: 文件名（用于错误日志，可选）
///   - lineNo: 行号（用于错误日志，可选）
/// 返回：成功返回 0，失败返回非 0
pub unsafe fn encapsulation_of_zte_memcpy_s(
    s1: *mut libc::c_void,
    s1max: rsize_t,
    s2: *const libc::c_void,
    n: rsize_t,
    _fileName: *const libc::c_char,
    _lineNo: libc::c_int,
) -> libc::c_int {
    // 参数验证
    if s1.is_null() || s2.is_null() {
        return 1; // 空指针错误
    }
    
    // 边界检查：确保不会越界
    if n > s1max {
        return 1; // 缓冲区溢出错误
    }
    
    // 如果复制大小为 0，直接返回成功
    if n == 0 {
        return 0;
    }
    
    // 使用 std::ptr::copy_nonoverlapping 进行安全的内存复制
    // 这个函数要求源和目标不重叠，且大小匹配
    unsafe {
        std::ptr::copy_nonoverlapping(
            s2 as *const u8,
            s1 as *mut u8,
            n as usize,
        );
    }
    
    0 // 成功
}

/// Rust 版本的 memset_s 函数
/// 安全的内存设置函数，包含边界检查
/// 参数：
///   - s: 目标内存地址
///   - smax: 目标缓冲区最大大小
///   - c: 要设置的值（转换为 u8）
///   - n: 要设置的字节数
///   - fileName: 文件名（用于错误日志，可选）
///   - lineNo: 行号（用于错误日志，可选）
/// 返回：成功返回 0，失败返回非 0
pub unsafe fn encapsulation_of_zte_memset_s(
    s: *mut libc::c_void,
    smax: rsize_t,
    c: libc::c_int,
    n: rsize_t,
    _fileName: *const libc::c_char,
    _lineNo: libc::c_int,
) -> libc::c_int {
    // 参数验证
    if s.is_null() {
        return 1; // 空指针错误
    }
    
    // 边界检查：确保不会越界
    if n > smax {
        return 1; // 缓冲区溢出错误
    }
    
    // 如果设置大小为 0，直接返回成功
    if n == 0 {
        return 0;
    }
    
    // 将 c 转换为 u8（只取低 8 位）
    let value = (c & 0xff) as u8;
    
    // 使用 std::ptr::write_bytes 进行安全的内存设置
    // 这个函数会将指定内存区域设置为指定值
    unsafe {
        std::ptr::write_bytes(s as *mut u8, value, n as usize);
    }
    
    0 // 成功
}

pub unsafe extern "C" fn Jffs2InfoInit() -> ULONG {
    let mut fp: *mut FILE = 0 as *mut FILE;
    let mut pchBuf: *mut CHAR = 0 as *mut CHAR;
    let mut pchHolder: *mut CHAR = 0 as *mut CHAR;
    let mut achLine: [CHAR; 512] = [0; 512];
    let mut str: [CHAR; 32] = [0; 32];
    let mut i: UCHAR = 0;
    let mut j: UCHAR = 0;
    static mut flag: UCHAR = 0 as libc::c_int as UCHAR;
    if 1 as libc::c_int == flag as libc::c_int {
        println!("Jffs2InfoInit already \n");
	}
    return 0xffffffff as libc::c_uint;
}

pub unsafe extern "C" fn BspJffs2Format() -> ULONG {
    let mut fd: LONG = 0;
    let mut wbuf: *mut CHAR = 0 as *mut CHAR;
    let mut clearmark: jffs2_unknown_node = jffs2_unknown_node {
        magic: 0,
        nodetype: 0,
        totlen: 0,
        hdr_crc: 0,
    };
    let mut ulCnt: ULONG = 0;
    let mut ret: LONG = 0;
    let mut ulRet: ULONG = 0;
    if 0xffffffff as libc::c_uint == Jffs2InfoInit() {
        eprintln!("Jffs2InfoInit fail\n");
        // return 0xffffffff as libc::c_uint;
    }

    encapsulation_of_zte_memset_s(
        &mut clearmark as *mut jffs2_unknown_node as *mut libc::c_void,
        ::core::mem::size_of::<jffs2_unknown_node>() as libc::c_ulong,
        0 as libc::c_int,
        ::core::mem::size_of::<jffs2_unknown_node>() as libc::c_ulong,
        b"/home/10334704/yccrust/bsp/platform/bsp/softlib/fsapp/source/fsapp.c\0"
            as *const u8 as *const libc::c_char,
        354 as libc::c_int,
    );
    clearmark.magic = 0x1985 as libc::c_int as libc::c_ushort;
    clearmark
        .nodetype = (0 as libc::c_int | 0x2000 as libc::c_int | 3 as libc::c_int)
        as libc::c_ushort;
    clearmark
        .totlen = ::core::mem::size_of::<jffs2_unknown_node>() as libc::c_ulong
        as libc::c_uint;
    clearmark
        .hdr_crc = crc32(
        0 as libc::c_int as libc::c_uint,
        &mut clearmark as *mut jffs2_unknown_node as *const libc::c_uchar
            as *const libc::c_void,
        (::core::mem::size_of::<jffs2_unknown_node>() as libc::c_ulong)
            .wrapping_sub(4 as libc::c_int as libc::c_ulong) as libc::c_int,
    );
    println!("start format jffs2,please wait....");
    ulCnt = 0 as libc::c_int as ULONG;
    println!("Done\n");
    println!("\njffs2 format succeed\n");
    close(fd as libc::c_int);
    wbuf = 0 as *mut CHAR;

    if 0 as libc::c_int as UINT32 != ulRet {
        return 0xffffffff as libc::c_uint;
    }
    return 0 as libc::c_int as UINT32;
}

pub unsafe extern "C" fn BspDosFsRepair() -> ULONG {
    let mut ulRetVal: ULONG = 0 as libc::c_int as UINT32;
    let mut iLoopTime: libc::c_int = 0 as libc::c_int;
    let mut iMountResult: libc::c_int = 0 as libc::c_int;
    let mut ulLoop: ULONG = 0;
    if 0xffffffff as libc::c_uint == Jffs2InfoInit() {
        eprintln!("Jffs2InfoInit fail\n");
        // return 0xffffffff as libc::c_uint;
    }
    println!("Jffs2 file system mount!\n");

    if 0 as libc::c_int == iMountResult {
        println!("BspDosFsRepair success1!!\n");
        // return 0 as libc::c_int as UINT32;
    }
    println!("Begin to repair Jffs2, please wait for some mininutes......\n");
    iLoopTime = 0 as libc::c_int;
    while iLoopTime < 3 as libc::c_int {
        println!("umount-mount iLoopTime = {}\n", iLoopTime);
        if 0 as libc::c_int == iMountResult {
            break;
        }
        iLoopTime += 1;
        iLoopTime;
    }
    println!("Begin to repair Jffs2, please wait for some mininutes......\n");
    if 3 as libc::c_int == iLoopTime {
        ulLoop = 0 as libc::c_int as ULONG;
        while ulLoop < 3 as libc::c_int as libc::c_uint {
            println!("ulLoop = {}\n", ulLoop);
            ulRetVal = BspJffs2Format();
            if 0 as libc::c_int as UINT32 == ulRetVal {
                println!("Jffs2Format OK!\n");
                break;
            } else {
                ulLoop = ulLoop.wrapping_add(1);
                ulLoop;
            }
        }
        if 3 as libc::c_int as libc::c_uint == ulLoop {
            println!("Jffs2Format error!\n");
            return 0xffffffff as libc::c_uint;
        }
        println!("After format, Jffs2 Initialize Success!\n");
    }
    println!("BspDosFsRepair success2!!\n");
    return 0 as libc::c_int as UINT32;
}

pub unsafe extern "C" fn Jffs2_GetFlashInfo(
    mut ptFlash_info: *mut jffs2_flash_info,
) -> ULONG {
    let mut flash_infolen: INT32 = 0;
    let mut args: __sysctl_args = __sysctl_args {
        name: 0 as *mut libc::c_int,
        nlen: 0,
        oldval: 0 as *mut libc::c_void,
        oldlenp: 0 as *mut size_t,
        newval: 0 as *mut libc::c_void,
        newlen: 0,
        __unused: [0; 4],
    };
    flash_infolen = ::core::mem::size_of::<jffs2_flash_info>() as libc::c_ulong as INT32;
    if ptFlash_info.is_null() {
        eprintln!("Jffs2_GetFlashInfo: NULL == ptFlash_info.\n");
        return 0xff000002 as libc::c_uint;
    }
    encapsulation_of_zte_memset_s(
        &mut args as *mut __sysctl_args as *mut libc::c_void,
        ::core::mem::size_of::<__sysctl_args>() as libc::c_ulong,
        0 as libc::c_int,
        ::core::mem::size_of::<__sysctl_args>() as libc::c_ulong,
        b"/home/10334704/yccrust/bsp/platform/bsp/softlib/fsapp/source/fsapp.c\0"
            as *const u8 as *const libc::c_char,
        534 as libc::c_int,
    );
    args
        .nlen = (::core::mem::size_of::<[INT32; 4]>() as libc::c_ulong)
        .wrapping_div(::core::mem::size_of::<INT32>() as libc::c_ulong) as libc::c_int;
    args.oldval = ptFlash_info as *mut libc::c_void;
    args.oldlenp = &mut flash_infolen as *mut INT32 as *mut size_t;
    if syscall_sysctl(&mut args as *mut __sysctl_args)
        == -(1 as libc::c_int) as libc::c_long
    {
        eprintln!("Oss_ShowJffs2FlashInfo: call syscall err.\n");
        return 0xffffffff as libc::c_uint;
    }
    return 0 as libc::c_int as UINT32;
}

pub unsafe extern "C" fn FsRecycle1M() -> ULONG {
    let mut dirty: ULONG = 0 as libc::c_int as ULONG;
    let mut dirty_bak: ULONG = 0 as libc::c_int as ULONG;
    let mut freespace: ULONG = 0 as libc::c_int as ULONG;
    let mut free_bak: ULONG = 0 as libc::c_int as ULONG;
    let mut pre_free: ULONG = 0 as libc::c_int as ULONG;
    let mut tmp_free: ULONG = 0 as libc::c_int as ULONG;
    let mut flash_infolen: INT32 = 0;
    let mut start_gc: INT32 = 0;
    let mut start_gclen: INT32 = 0;
    let mut read_args: __sysctl_args = __sysctl_args {
        name: 0 as *mut libc::c_int,
        nlen: 0,
        oldval: 0 as *mut libc::c_void,
        oldlenp: 0 as *mut size_t,
        newval: 0 as *mut libc::c_void,
        newlen: 0,
        __unused: [0; 4],
    };
    let mut write_args: __sysctl_args = __sysctl_args {
        name: 0 as *mut libc::c_int,
        nlen: 0,
        oldval: 0 as *mut libc::c_void,
        oldlenp: 0 as *mut size_t,
        newval: 0 as *mut libc::c_void,
        newlen: 0,
        __unused: [0; 4],
    };
    let mut aucFlash_info: [libc::c_uchar; 128] = [0; 128];
    let mut flash_info: *mut jffs2_flash_info = 0 as *mut jffs2_flash_info;
    flash_infolen = ::core::mem::size_of::<jffs2_flash_info>() as libc::c_ulong as INT32;
    flash_info = aucFlash_info.as_mut_ptr() as *mut jffs2_flash_info;
    encapsulation_of_zte_memset_s(
        &mut read_args as *mut __sysctl_args as *mut libc::c_void,
        ::core::mem::size_of::<__sysctl_args>() as libc::c_ulong,
        0 as libc::c_int,
        ::core::mem::size_of::<__sysctl_args>() as libc::c_ulong,
        b"/home/10334704/yccrust/bsp/platform/bsp/softlib/fsapp/source/fsapp.c\0"
            as *const u8 as *const libc::c_char,
        634 as libc::c_int,
    );
    read_args
        .nlen = (::core::mem::size_of::<[INT32; 4]>() as libc::c_ulong)
        .wrapping_div(::core::mem::size_of::<INT32>() as libc::c_ulong) as libc::c_int;
    read_args.oldval = flash_info as *mut libc::c_void;
    read_args.oldlenp = &mut flash_infolen as *mut INT32 as *mut ULONG as *mut size_t;
    start_gc = 1 as libc::c_int;
    start_gclen = ::core::mem::size_of::<INT32>() as libc::c_ulong as INT32;
    encapsulation_of_zte_memset_s(
        &mut write_args as *mut __sysctl_args as *mut libc::c_void,
        ::core::mem::size_of::<__sysctl_args>() as libc::c_ulong,
        0 as libc::c_int,
        ::core::mem::size_of::<__sysctl_args>() as libc::c_ulong,
        b"/home/10334704/yccrust/bsp/platform/bsp/softlib/fsapp/source/fsapp.c\0"
            as *const u8 as *const libc::c_char,
        643 as libc::c_int,
    );
    write_args
        .nlen = (::core::mem::size_of::<[INT32; 4]>() as libc::c_ulong)
        .wrapping_div(::core::mem::size_of::<INT32>() as libc::c_ulong) as libc::c_int;
    write_args.newval = &mut start_gc as *mut INT32 as *mut libc::c_void;
    write_args.newlen = start_gclen as size_t;
    if syscall_sysctl(&mut read_args as *mut __sysctl_args)
        == -(1 as libc::c_int) as libc::c_long
    {
        unsafe {
            perror_rust(b"_sysctl\0" as *const u8 as *const libc::c_char);
        }
        // return 0xffffffff as libc::c_uint;
    }
    dirty = ((*flash_info).dirty_s)
        .wrapping_add((*flash_info).erasing_s)
        .wrapping_sub(
            ((*flash_info).n_erasing_blocks).wrapping_mul((*flash_info).sector_s),
        );
    freespace = ((*flash_info).n_free_blocks)
        .wrapping_add((*flash_info).n_erasing_blocks)
        .wrapping_mul((*flash_info).sector_s);
    dirty_bak = dirty;
    free_bak = freespace;
    pre_free = freespace;
    tmp_free = freespace;
    return 0 as libc::c_int as UINT32;
}
pub unsafe extern "C" fn BspFsRecycle() -> ULONG {
    return 0 as libc::c_int as UINT32;
}

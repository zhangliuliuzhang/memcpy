#![allow(
    dead_code,
    mutable_transmutes,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    unused_assignments,
    unused_mut
)]

use ccommon::clib::*;

pub type size_t = libc::c_ulong;
pub type __mode_t = libc::c_uint;
pub type __off_t = libc::c_long;
pub type __off64_t = libc::c_long;

// Rust 版本的 fprintf 辅助函数
// 将 C 的 fprintf 调用转换为 Rust 的文件写入
pub unsafe fn fprintf_rust(
    fp: *mut FILE,
    formatted_str: &str,
) -> libc::c_int {
    use std::os::unix::io::FromRawFd;
    use std::io::Write;
    use std::mem::ManuallyDrop;
    
    if fp.is_null() {
        return -(1 as libc::c_int);
    }
    
    // 获取文件描述符
    let fd = libc::fileno(fp as *mut libc::FILE);
    if fd < 0 {
        return -(1 as libc::c_int);
    }
    
    // 从文件描述符创建 File 对象（不关闭文件描述符）
    let file = std::fs::File::from_raw_fd(fd);
    let mut file = ManuallyDrop::new(file);
    
    // 写入文件
    match file.write_all(formatted_str.as_bytes()) {
        Ok(_) => formatted_str.len() as libc::c_int,
        Err(_) => -(1 as libc::c_int),
    }
}

// Rust 版本的 strncat_s 辅助函数
// 将 C 的 encapsulationOfZte_strncat_s 调用转换为 Rust 的字符串连接
pub unsafe fn strncat_s_rust(
    s1: *mut libc::c_char,
    s1max: rsize_t,
    s2: *const libc::c_char,
    n: rsize_t,
) -> libc::c_int {
    // 检查参数指针是否为空
    if s1.is_null() || s2.is_null() {
        return -1;
    }
    
    // 检查缓冲区大小是否有效
    if s1max == 0 {
        return -1;
    }
    
    // 手动查找目标字符串的当前长度（查找空终止符）
    let mut s1_len = 0;
    while s1_len < s1max as usize {
        if *s1.add(s1_len) == 0 {
            break;
        }
        s1_len += 1;
    }
    
    // 检查目标字符串是否已满
    if s1_len >= s1max as usize {
        return -1; // 目标字符串已满，无法追加
    }
    
    // 计算可用的空间（需要为空终止符留出空间）
    let available_space = (s1max as usize) - s1_len - 1;
    
    if available_space == 0 {
        return -1; // 没有可用空间
    }
    
    // 确定实际要复制的字符数
    let copy_len = if n == 0 {
        // 如果 n 为 0，复制整个源字符串（直到空终止符或可用空间）
        let mut s2_len = 0;
        while s2_len < available_space {
            if *s2.add(s2_len) == 0 {
                break;
            }
            s2_len += 1;
        }
        s2_len
    } else {
        // 复制最多 n 个字符，但不超过可用空间
        let max_copy = (n as usize).min(available_space);
        // 还需要检查源字符串的实际长度
        let mut s2_actual_len = 0;
        while s2_actual_len < max_copy {
            if *s2.add(s2_actual_len) == 0 {
                break;
            }
            s2_actual_len += 1;
        }
        s2_actual_len.min(max_copy)
    };
    
    if copy_len == 0 {
        // 没有要复制的内容，直接返回成功
        return 0;
    }
    
    // 执行字符串连接
    let dest_ptr = s1.add(s1_len);
    std::ptr::copy_nonoverlapping(s2, dest_ptr, copy_len);
    
    // 确保目标字符串以空终止符结尾
    *s1.add(s1_len + copy_len) = 0;
    
    // 成功返回 0
    0
}

pub type _IO_lock_t = ();
pub type FILE = _IO_FILE;
pub type INT32 = libc::c_int;
pub type rsize_t = size_t;
#[unsafe(no_mangle)]
pub static mut CFG_ssl: libc::c_char = '[' as i32 as libc::c_char;
#[unsafe(no_mangle)]
pub static mut CFG_ssr: libc::c_char = ']' as i32 as libc::c_char;
#[unsafe(no_mangle)]
pub static mut CFG_nis: libc::c_char = ':' as i32 as libc::c_char;
#[unsafe(no_mangle)]
pub static mut CFG_nts: libc::c_char = '#' as i32 as libc::c_char;
#[unsafe(no_mangle)]
pub static mut CFG_section_line_no: libc::c_int = 0;
#[unsafe(no_mangle)]
pub static mut CFG_key_line_no: libc::c_int = 0;
#[unsafe(no_mangle)]
pub static mut CFG_key_lines: libc::c_int = 0;
#[unsafe(no_mangle)]
pub unsafe extern "C" fn FileGetLine(
    mut fp: *mut FILE,
    mut buffer: *mut libc::c_char,
    mut maxlen: libc::c_int,
) -> libc::c_int {
    // 安全检查：检查文件指针是否为空
    if fp.is_null() {
        return -(1 as libc::c_int);
    }
    
    // 安全检查：检查缓冲区指针是否为空
    if buffer.is_null() {
        return -(1 as libc::c_int);
    }
    
    // 安全检查：检查 maxlen 是否有效
    if maxlen <= 0 {
        return 0;
    }
    
    let mut i: libc::c_int = 0;
    let mut j: libc::c_int = 0;
    let mut ch1: libc::c_char = 0;
    i = 0 as libc::c_int;
    j = 0 as libc::c_int;
    while i < maxlen {
        if fread(
            &mut ch1 as *mut libc::c_char as *mut libc::c_void,
            ::core::mem::size_of::<libc::c_char>() as libc::c_ulong,
            1 as libc::c_int as libc::c_ulong,
            fp,
        ) != 1 as libc::c_int as libc::c_ulong
        {
            if feof(fp) != 0 as libc::c_int {
                if !(j == 0 as libc::c_int) {
                    break;
                }
                return -(1 as libc::c_int);
            } else if ferror(fp) != 0 as libc::c_int {
                return -(2 as libc::c_int)
            }
        } else {
            if ch1 as libc::c_int == '\n' as i32
                || ch1 as libc::c_int == 0 as libc::c_int
            {
                break;
            }
            if ch1 as libc::c_int == '\u{c}' as i32
                || ch1 as libc::c_int == 0x1a as libc::c_int
            {
                let fresh0 = i;
                i = i + 1;
                *buffer.offset(fresh0 as isize) = ch1;
                break;
            } else if ch1 as libc::c_int != '\r' as i32 {
                let fresh1 = i;
                i = i + 1;
                *buffer.offset(fresh1 as isize) = ch1;
            }
        }
        j += 1;
        j;
    }
    *buffer.offset(i as isize) = '\0' as i32 as libc::c_char;
    // 如果文件已结束且没有读取任何有效字符，返回 -1
    // 这可以防止调用者认为还有更多内容可读，导致无限循环
    if feof(fp) != 0 as libc::c_int {
        if i == 0 as libc::c_int {
            return -(1 as libc::c_int);
        }
    }
    return i;
}
#[unsafe(no_mangle)]
pub unsafe extern "C" fn BspFileGetLine(
    mut fp: *mut FILE,
    mut buffer: *mut libc::c_char,
    mut maxlen: libc::c_int,
) -> libc::c_int {
    return FileGetLine(fp, buffer, maxlen);
}
#[unsafe(no_mangle)]
pub unsafe extern "C" fn FileCopy(
    mut source_file: *const libc::c_void,
    mut dest_file: *const libc::c_void,
) -> libc::c_int {
    let mut fp1: *mut FILE = 0 as *mut FILE;
    let mut fp2: *mut FILE = 0 as *mut FILE;
    let mut buf: [libc::c_char; 1025] = [0; 1025];
    let mut ret: libc::c_int = 0;
    let mut fclsRet: INT32 = 0 as libc::c_int;
    fp1 = fopen(
        source_file as *mut libc::c_char,
        b"r\0" as *const u8 as *const libc::c_char,
    );
    if fp1.is_null() {
        return -(10 as libc::c_int);
    }
    ret = -(11 as libc::c_int);
    fp2 = fopen(
        dest_file as *mut libc::c_char,
        b"w\0" as *const u8 as *const libc::c_char,
    );
    if fp2.is_null() {
            fclsRet = fclose(fp1);
            if fclsRet != 0 as libc::c_int {
                eprintln!("FileCopy(125) warning! > fclose ret'{}'", fclsRet);
            }
        return ret;
    }
    loop {
        ret = -(12 as libc::c_int);
        encapsulationOfZte_memset_s(
            buf.as_mut_ptr() as *mut libc::c_void,
            (1024 as libc::c_int + 1 as libc::c_int) as rsize_t,
            0 as libc::c_int,
            (1024 as libc::c_int + 1 as libc::c_int) as rsize_t,
            b"Errlog.csv\0"
                as *const u8 as *const libc::c_char,
            133 as libc::c_int,
        );
        if (fgets(buf.as_mut_ptr(), 1024 as libc::c_int, fp1)).is_null() {
            if encapsulationOfZte_strnlen_s(
                buf.as_mut_ptr(),
                ::core::mem::size_of::<[libc::c_char; 1025]>() as libc::c_ulong,
                b"Errlog.csv\0"
                    as *const u8 as *const libc::c_char,
                136 as libc::c_int,
            ) == 0 as libc::c_int
            {
                if ferror(fp1) != 0 as libc::c_int {
                    fclsRet = fclose(fp2);
                    if fclsRet != 0 as libc::c_int {
                        eprintln!("FileCopy(141) warning! > fclose ret'{}'", fclsRet);
                    }
                    fclsRet = fclose(fp1);
                    if fclsRet != 0 as libc::c_int {
                        eprintln!("FileCopy(143) warning! > fclose ret'{}'", fclsRet);
                    }
                    return ret;
                }
                break;
            }
        }
        ret = -(13 as libc::c_int);
        if fputs(buf.as_mut_ptr(), fp2) == -(1 as libc::c_int) {
            fclsRet = fclose(fp2);
            if fclsRet != 0 as libc::c_int {
                eprintln!("FileCopy(154) warning! > fclose ret'{}'", fclsRet);
            }
            fclsRet = fclose(fp1);
            if fclsRet != 0 as libc::c_int {
                eprintln!("FileCopy(156) warning! > fclose ret'{}'", fclsRet);
            }
            return ret;
        }
    }
    ret = 0 as libc::c_int;
    fclsRet = fclose(fp2);
    if fclsRet != 0 as libc::c_int {
        eprintln!("FileCopy(164) warning! > fclose ret'{}'", fclsRet);
    }
    fclsRet = fclose(fp1);
    if fclsRet != 0 as libc::c_int {
        eprintln!("FileCopy(166) warning! > fclose ret'{}'", fclsRet);
    }
    return ret;
}
#[unsafe(no_mangle)]
pub unsafe extern "C" fn SplitSectionToNameIndex(
    mut section: *mut libc::c_char,
    mut name: *mut *mut libc::c_char,
    mut index: *mut *mut libc::c_char,
) -> libc::c_int {
    let mut i: libc::c_int = 0;
    let mut k1: libc::c_int = 0;
    let mut k2: libc::c_int = 0;
    let mut n: libc::c_int = 0;
    n = encapsulationOfZte_strnlen_s(
        section,
        512 as libc::c_int as rsize_t,
        b"Errlog.csv\0"
            as *const u8 as *const libc::c_char,
        198 as libc::c_int,
    );
    if n < 1 as libc::c_int {
        return 0 as libc::c_int;
    }
    i = 0 as libc::c_int;
    while i < n {
        if *section.offset(i as isize) as libc::c_int != ' ' as i32
            && *section.offset(i as isize) as libc::c_int != '\t' as i32
        {
            break;
        }
        i += 1;
        i;
    }
    if i >= n {
        return 0 as libc::c_int;
    }
    if *section.offset(i as isize) as libc::c_int == CFG_nis as libc::c_int {
        return -(1 as libc::c_int);
    }
    k1 = i;
    i += 1;
    i;
    while i < n {
        if *section.offset(i as isize) as libc::c_int == CFG_nis as libc::c_int {
            break;
        }
        i += 1;
        i;
    }
    if i >= n {
        return -(2 as libc::c_int);
    }
    k2 = i;
    i += 1;
    i;
    while i < n {
        if *section.offset(i as isize) as libc::c_int != ' ' as i32
            && *section.offset(i as isize) as libc::c_int != '\t' as i32
        {
            break;
        }
        i += 1;
        i;
    }
    *section.offset(k2 as isize) = '\0' as i32 as libc::c_char;
    *name = section.offset(k1 as isize);
    *index = section.offset(i as isize);
    return 1 as libc::c_int;
}
#[unsafe(no_mangle)]
pub unsafe extern "C" fn JoinNameIndexToSection(
    mut section: *mut *mut libc::c_char,
    mut sectionlen: libc::c_uint,
    mut name: *mut libc::c_char,
    mut index: *mut libc::c_char,
) -> libc::c_int {
    let mut n1: libc::c_int = 0;
    let mut n2: libc::c_int = 0;
    n1 = encapsulationOfZte_strnlen_s(
        name,
        512 as libc::c_int as rsize_t,
        b"Errlog.csv\0"
            as *const u8 as *const libc::c_char,
        240 as libc::c_int,
    );
    if n1 < 1 as libc::c_int {
        return 0 as libc::c_int;
    }
    n2 = encapsulationOfZte_strnlen_s(
        index,
        512 as libc::c_int as rsize_t,
        b"Errlog.csv\0"
            as *const u8 as *const libc::c_char,
        241 as libc::c_int,
    );
    if n2 < 1 as libc::c_int {
        return 0 as libc::c_int;
    }
    if strncat_s_rust(
        *section,
        sectionlen as rsize_t,
        name,
        strlen(name),
    ) != 0 {
        return 0 as libc::c_int;
    }
    if strncat_s_rust(
        *section,
        sectionlen as rsize_t,
        b":\0" as *const u8 as *const libc::c_char,
        1 as libc::c_int as rsize_t,
    ) != 0 {
        return 0 as libc::c_int;
    }
    if strncat_s_rust(
        *section,
        sectionlen as rsize_t,
        index,
        strlen(index),
    ) != 0 {
        return 0 as libc::c_int;
    }
    return 1 as libc::c_int;
}
#[unsafe(no_mangle)]
pub unsafe extern "C" fn SplitKeyValue(
    mut buf: *mut libc::c_char,
    mut key: *mut *mut libc::c_char,
    mut val: *mut *mut libc::c_char,
) -> libc::c_int {
    let mut i: libc::c_int = 0;
    let mut k1: libc::c_int = 0;
    let mut k2: libc::c_int = 0;
    let mut n: libc::c_int = 0;
    n = encapsulationOfZte_strnlen_s(
        buf,
        (512 as libc::c_int + 1 as libc::c_int) as rsize_t,
        b"Errlog.csv\0"
            as *const u8 as *const libc::c_char,
        280 as libc::c_int,
    );
    if n < 1 as libc::c_int {
        return 0 as libc::c_int;
    }
    i = 0 as libc::c_int;
    while i < n {
        if *buf.offset(i as isize) as libc::c_int != ' ' as i32
            && *buf.offset(i as isize) as libc::c_int != '\t' as i32
        {
            break;
        }
        i += 1;
        i;
    }
    if i >= n {
        return 0 as libc::c_int;
    }
    if *buf.offset(i as isize) as libc::c_int == '=' as i32 {
        return -(1 as libc::c_int);
    }
    k1 = i;
    i += 1;
    i;
    while i < n {
        if *buf.offset(i as isize) as libc::c_int == '=' as i32 {
            break;
        }
        i += 1;
        i;
    }
    if i >= n {
        return -(2 as libc::c_int);
    }
    k2 = i;
    i += 1;
    i;
    while i < n {
        if *buf.offset(i as isize) as libc::c_int != ' ' as i32
            && *buf.offset(i as isize) as libc::c_int != '\t' as i32
        {
            break;
        }
        i += 1;
        i;
    }
    *buf.offset(k2 as isize) = '\0' as i32 as libc::c_char;
    *key = buf.offset(k1 as isize);
    *val = buf.offset(i as isize);
    return 1 as libc::c_int;
}
#[unsafe(no_mangle)]
pub unsafe extern "C" fn ConfigGetKeyEx(
    mut CFG_file: *const libc::c_void,
    mut section: *const libc::c_void,
    mut key: *const libc::c_void,
    mut buf: *mut libc::c_void,
    mut buflen: libc::c_uint,
) -> libc::c_int {
    let mut fp: *mut FILE = 0 as *mut FILE;
    let mut buf1: [libc::c_char; 513] = [0; 513];
    let mut buf2: [libc::c_char; 513] = [0; 513];
    let mut key_ptr: *mut libc::c_char = 0 as *mut libc::c_char;
    let mut val_ptr: *mut libc::c_char = 0 as *mut libc::c_char;
    let mut line_no: libc::c_int = 0;
    let mut n: libc::c_int = 0;
    let mut ret: libc::c_int = 0;
    let mut fclsRet: INT32 = 0 as libc::c_int;
    let mut len: libc::c_int = 0 as libc::c_int;
    line_no = 0 as libc::c_int;
    CFG_section_line_no = 0 as libc::c_int;
    CFG_key_line_no = 0 as libc::c_int;
    CFG_key_lines = 0 as libc::c_int;
    if buflen > 512 as libc::c_int as libc::c_uint {
        eprintln!("error: ConfigGetKeyEx buf size over 512!");
        return -(22 as libc::c_int);
    }
    fp = fopen(
        CFG_file as *mut libc::c_char,
        b"rb\0" as *const u8 as *const libc::c_char,
    );
    if fp.is_null() {
        return -(10 as libc::c_int);
    }
    // 添加循环计数器，防止无限循环
    let mut loop_count1: libc::c_int = 0 as libc::c_int;
    let max_loop_count1: libc::c_int = 10000 as libc::c_int;
    loop {
        loop_count1 += 1;
        if loop_count1 > max_loop_count1 {
            fclsRet = fclose(fp);
            if fclsRet != 0 as libc::c_int {
                eprintln!("ConfigGetKeyEx(488) warning! > fclose ret'{}'", fclsRet);
            }
            eprintln!("ConfigGetKeyEx: first loop count exceeded, possible infinite loop");
            return -(12 as libc::c_int);
        }
        ret = -(12 as libc::c_int);
        encapsulationOfZte_memset_s(
            buf1.as_mut_ptr() as *mut libc::c_void,
            ::core::mem::size_of::<[libc::c_char; 513]>() as libc::c_ulong,
            0 as libc::c_int,
            ::core::mem::size_of::<[libc::c_char; 513]>() as libc::c_ulong,
            b"Errlog.csv\0"
                as *const u8 as *const libc::c_char,
            483 as libc::c_int,
        );
        n = FileGetLine(fp, buf1.as_mut_ptr(), 512 as libc::c_int);
        if n < -(1 as libc::c_int) {
            fclsRet = fclose(fp);
            if fclsRet != 0 as libc::c_int {
                eprintln!("ConfigGetKeyEx(488) warning! > fclose ret'{}'", fclsRet);
            }
            return ret;
        }
        ret = -(1 as libc::c_int);
        if n < 0 as libc::c_int {
            fclsRet = fclose(fp);
            if fclsRet != 0 as libc::c_int {
                eprintln!("ConfigGetKeyEx(496) warning! > fclose ret'{}'", fclsRet);
            }
            return ret;
        }
        line_no += 1;
        line_no;
        n = encapsulationOfZte_strnlen_s(
            strtriml(strtrimr(buf1.as_mut_ptr())),
            ::core::mem::size_of::<[libc::c_char; 513]>() as libc::c_ulong,
            b"Errlog.csv\0"
                as *const u8 as *const libc::c_char,
            501 as libc::c_int,
        );
        // 如果文件已结束，不再继续循环，避免无限循环
        if feof(fp) != 0 as libc::c_int {
            fclsRet = fclose(fp);
            if fclsRet != 0 as libc::c_int {
                eprintln!("ConfigGetKeyEx(496) warning! > fclose ret'{}'", fclsRet);
            }
            return ret;
        }
        if n == 0 as libc::c_int
            || buf1[0 as libc::c_int as usize] as libc::c_int == CFG_nts as libc::c_int
        {
            continue;
        }
        ret = -(14 as libc::c_int);
        if n > 2 as libc::c_int
            && (buf1[0 as libc::c_int as usize] as libc::c_int == CFG_ssl as libc::c_int
                && buf1[(n - 1 as libc::c_int) as usize] as libc::c_int
                    != CFG_ssr as libc::c_int)
        {
            fclsRet = fclose(fp);
            if fclsRet != 0 as libc::c_int {
                eprintln!("ConfigGetKeyEx(507) warning! > fclose ret'{}'", fclsRet);
            }
            return ret;
        }
        if !(buf1[0 as libc::c_int as usize] as libc::c_int == CFG_ssl as libc::c_int) {
            continue;
        }
        if n < 1 as libc::c_int {
            continue;
        }
        buf1[(n - 1 as libc::c_int) as usize] = 0 as libc::c_int as libc::c_char;
        if strncmp(
            buf1.as_mut_ptr().offset(1 as libc::c_int as isize),
            section as *mut libc::c_char,
            (::core::mem::size_of::<[libc::c_char; 513]>() as libc::c_ulong)
                .wrapping_sub(1 as libc::c_int as libc::c_ulong),
        ) == 0 as libc::c_int
        {
            break;
        }
    }
    CFG_section_line_no = line_no;
    // 添加循环计数器，防止无限循环
    let mut loop_count: libc::c_int = 0 as libc::c_int;
    let max_loop_count: libc::c_int = 10000 as libc::c_int;
    loop {
        loop_count += 1;
        if loop_count > max_loop_count {
            fclsRet = fclose(fp);
            if fclsRet != 0 as libc::c_int {
                eprintln!("ConfigGetKeyEx(527) warning! > fclose ret'{}'", fclsRet);
            }
            eprintln!("ConfigGetKeyEx: loop count exceeded, possible infinite loop");
            return -(12 as libc::c_int);
        }
        ret = -(12 as libc::c_int);
        n = FileGetLine(fp, buf1.as_mut_ptr(), 512 as libc::c_int);
        if n < -(1 as libc::c_int) {
            fclsRet = fclose(fp);
            if fclsRet != 0 as libc::c_int {
                eprintln!("ConfigGetKeyEx(527) warning! > fclose ret'{}'", fclsRet);
            }
            return ret;
        }
        ret = -(2 as libc::c_int);
        if n < 0 as libc::c_int {
            fclsRet = fclose(fp);
            if fclsRet != 0 as libc::c_int {
                eprintln!("ConfigGetKeyEx(535) warning! > fclose ret'{}'", fclsRet);
            }
            return ret;
        }
        // 如果文件已结束，直接返回，避免无限循环
        if feof(fp) != 0 as libc::c_int {
            fclsRet = fclose(fp);
            if fclsRet != 0 as libc::c_int {
                eprintln!("ConfigGetKeyEx(535) warning! > fclose ret'{}'", fclsRet);
            }
            return ret;
        }
        line_no += 1;
        line_no;
        CFG_key_line_no = line_no;
        CFG_key_lines = 1 as libc::c_int;
        n = encapsulationOfZte_strnlen_s(
            strtriml(strtrimr(buf1.as_mut_ptr())),
            ::core::mem::size_of::<[libc::c_char; 513]>() as libc::c_ulong,
            b"Errlog.csv\0"
                as *const u8 as *const libc::c_char,
            542 as libc::c_int,
        );
        // 如果文件已结束，不再继续循环，避免无限循环
        // 必须在检查空行之前检查文件结束状态
        if feof(fp) != 0 as libc::c_int {
            fclsRet = fclose(fp);
            if fclsRet != 0 as libc::c_int {
                eprintln!("ConfigGetKeyEx(535) warning! > fclose ret'{}'", fclsRet);
            }
            return ret;
        }
        if n == 0 as libc::c_int
            || buf1[0 as libc::c_int as usize] as libc::c_int == CFG_nts as libc::c_int
        {
            continue;
        }
        ret = -(2 as libc::c_int);
        if buf1[0 as libc::c_int as usize] as libc::c_int == CFG_ssl as libc::c_int {
            fclsRet = fclose(fp);
            if fclsRet != 0 as libc::c_int {
                eprintln!("ConfigGetKeyEx(548) warning! > fclose ret'{}'", fclsRet);
            }
            return ret;
        }
        if n < 1 as libc::c_int {
            continue;
        }
        if buf1[(n - 1 as libc::c_int) as usize] as libc::c_int == '+' as i32 {
            buf1[(n - 1 as libc::c_int) as usize] = 0 as libc::c_int as libc::c_char;
            // 添加循环计数器，防止内层循环无限循环
            let mut loop_count2: libc::c_int = 0 as libc::c_int;
            let max_loop_count2: libc::c_int = 10000 as libc::c_int;
            loop {
                loop_count2 += 1;
                if loop_count2 > max_loop_count2 {
                    eprintln!("ConfigGetKeyEx: inner loop count exceeded, possible infinite loop");
                    break;
                }
                ret = -(12 as libc::c_int);
                encapsulationOfZte_memset_s(
                    buf2.as_mut_ptr() as *mut libc::c_void,
                    ::core::mem::size_of::<[libc::c_char; 513]>() as libc::c_ulong,
                    0 as libc::c_int,
                    ::core::mem::size_of::<[libc::c_char; 513]>() as libc::c_ulong,
                    b"Errlog.csv\0"
                        as *const u8 as *const libc::c_char,
                    559 as libc::c_int,
                );
                n = FileGetLine(fp, buf2.as_mut_ptr(), 512 as libc::c_int);
                if n < -(1 as libc::c_int) {
                    fclsRet = fclose(fp);
                    if fclsRet != 0 as libc::c_int {
                        eprintln!("ConfigGetKeyEx(564) warning! > fclose ret'{}'", fclsRet);
                    }
                    return ret;
                }
                if n < 0 as libc::c_int {
                    break;
                }
                // 如果文件已结束，退出内层循环，避免无限循环
                if feof(fp) != 0 as libc::c_int {
                    break;
                }
                line_no += 1;
                line_no;
                CFG_key_lines += 1;
                CFG_key_lines;
                n = encapsulationOfZte_strnlen_s(
                    strtrimr(buf2.as_mut_ptr()),
                    ::core::mem::size_of::<[libc::c_char; 513]>() as libc::c_ulong,
                    b"Errlog.csv\0"
                        as *const u8 as *const libc::c_char,
                    571 as libc::c_int,
                );
                ret = -(22 as libc::c_int);
                if n > 0 as libc::c_int
                    && buf2[(n - 1 as libc::c_int) as usize] as libc::c_int == '+' as i32
                {
                    buf2[(n - 1 as libc::c_int)
                        as usize] = 0 as libc::c_int as libc::c_char;
                    if encapsulationOfZte_strnlen_s(
                        buf1.as_mut_ptr(),
                        ::core::mem::size_of::<[libc::c_char; 513]>() as libc::c_ulong,
                        b"Errlog.csv\0"
                            as *const u8 as *const libc::c_char,
                        577 as libc::c_int,
                    )
                        + encapsulationOfZte_strnlen_s(
                            buf2.as_mut_ptr(),
                            ::core::mem::size_of::<[libc::c_char; 513]>()
                                as libc::c_ulong,
                            b"Errlog.csv\0"
                                as *const u8 as *const libc::c_char,
                            577 as libc::c_int,
                        ) > 512 as libc::c_int
                    {
                        fclsRet = fclose(fp);
                        if fclsRet != 0 as libc::c_int {
                            eprintln!("ConfigGetKeyEx(580) warning! > fclose ret'{}'", fclsRet);
                        }
                        return ret;
                    }
                    len = encapsulationOfZte_strnlen_s(
                        buf2.as_mut_ptr(),
                        ::core::mem::size_of::<[libc::c_char; 513]>() as libc::c_ulong,
                        b"Errlog.csv\0"
                            as *const u8 as *const libc::c_char,
                        584 as libc::c_int,
                    );
                    if len >= 0 as libc::c_int {
                        if strncat_s_rust(
                            buf1.as_mut_ptr(),
                            ::core::mem::size_of::<[libc::c_char; 513]>()
                                as libc::c_ulong,
                            buf2.as_mut_ptr(),
                            len as rsize_t,
                        ) != 0 {
                            // 连接失败，继续处理
                        }
                    }
                } else {
                    if encapsulationOfZte_strnlen_s(
                        buf1.as_mut_ptr(),
                        ::core::mem::size_of::<[libc::c_char; 513]>() as libc::c_ulong,
                        b"Errlog.csv\0"
                            as *const u8 as *const libc::c_char,
                        592 as libc::c_int,
                    )
                        + encapsulationOfZte_strnlen_s(
                            buf2.as_mut_ptr(),
                            ::core::mem::size_of::<[libc::c_char; 513]>()
                                as libc::c_ulong,
                            b"Errlog.csv\0"
                                as *const u8 as *const libc::c_char,
                            592 as libc::c_int,
                        ) > 512 as libc::c_int
                    {
                        fclsRet = fclose(fp);
                        if fclsRet != 0 as libc::c_int {
                            eprintln!("ConfigGetKeyEx(595) warning! > fclose ret'{}'", fclsRet);
                        }
                        return ret;
                    }
                    len = encapsulationOfZte_strnlen_s(
                        buf2.as_mut_ptr(),
                        ::core::mem::size_of::<[libc::c_char; 513]>() as libc::c_ulong,
                        b"Errlog.csv\0"
                            as *const u8 as *const libc::c_char,
                        599 as libc::c_int,
                    );
                    if len >= 0 as libc::c_int {
                        if strncat_s_rust(
                            buf1.as_mut_ptr(),
                            ::core::mem::size_of::<[libc::c_char; 513]>()
                                as libc::c_ulong,
                            buf2.as_mut_ptr(),
                            len as rsize_t,
                        ) != 0 {
                            // 连接失败，继续处理
                        }
                    }
                    break;
                }
            }
        }
        ret = -(14 as libc::c_int);
        if SplitKeyValue(buf1.as_mut_ptr(), &mut key_ptr, &mut val_ptr)
            != 1 as libc::c_int
        {
            fclsRet = fclose(fp);
            if fclsRet != 0 as libc::c_int {
                eprintln!("ConfigGetKeyEx(611) warning! > fclose ret'{}'", fclsRet);
            }
            return ret;
        }
        strtriml(strtrimr(key_ptr));
        if strncmp(
            key_ptr,
            key as *mut libc::c_char,
            512 as libc::c_int as libc::c_ulong,
        ) != 0 as libc::c_int
        {
            continue;
        }
        len = encapsulationOfZte_strnlen_s(
            val_ptr,
            buflen as rsize_t,
            b"Errlog.csv\0"
                as *const u8 as *const libc::c_char,
            618 as libc::c_int,
        );
        if len >= 0 as libc::c_int {
            encapsulationOfZte_strncpy_s(
                buf as *mut libc::c_char,
                buflen as rsize_t,
                val_ptr,
                len as rsize_t,
                b"Errlog.csv\0"
                    as *const u8 as *const libc::c_char,
                621 as libc::c_int,
            );
        }
        break;
    }
    ret = 0 as libc::c_int;
    fclsRet = fclose(fp);
    if fclsRet != 0 as libc::c_int {
        eprintln!("ConfigGetKeyEx(628) warning! > fclose ret'{}'", fclsRet);
    }
    return ret;
}
#[unsafe(no_mangle)]
pub unsafe extern "C" fn _ConfigGetKeyForMte(
    mut CFG_file: *mut libc::c_void,
    mut section: *mut libc::c_void,
    mut key: *mut libc::c_void,
    mut buf: *mut libc::c_void,
    mut buflen: libc::c_uint,
) -> libc::c_int {
    let mut fp: *mut FILE = 0 as *mut FILE;
    let mut buf1: [libc::c_char; 513] = [0; 513];
    let mut buf2: [libc::c_char; 513] = [0; 513];
    let mut key_ptr: *mut libc::c_char = 0 as *mut libc::c_char;
    let mut val_ptr: *mut libc::c_char = 0 as *mut libc::c_char;
    let mut line_no: libc::c_int = 0;
    let mut n: libc::c_int = 0;
    let mut ret: libc::c_int = 0;
    let mut fclsRet: INT32 = 0 as libc::c_int;
    let mut len: libc::c_int = 0 as libc::c_int;
    line_no = 0 as libc::c_int;
    CFG_section_line_no = 0 as libc::c_int;
    CFG_key_line_no = 0 as libc::c_int;
    CFG_key_lines = 0 as libc::c_int;
    fp = fopen(
        CFG_file as *mut libc::c_char,
        b"rb\0" as *const u8 as *const libc::c_char,
    );
    if fp.is_null() {
        return -(10 as libc::c_int);
    }
    loop {
        ret = -(12 as libc::c_int);
        n = FileGetLine(fp, buf1.as_mut_ptr(), 512 as libc::c_int);
        if n < -(1 as libc::c_int) {
            fclsRet = fclose(fp);
            if fclsRet != 0 as libc::c_int {
                eprintln!("_ConfigGetKeyForMte(671) warning! > fclose ret'{}'", fclsRet);
            }
            return ret;
        }
        ret = -(1 as libc::c_int);
        if n < 0 as libc::c_int {
            fclsRet = fclose(fp);
            if fclsRet != 0 as libc::c_int {
                eprintln!("_ConfigGetKeyForMte(679) warning! > fclose ret'{}'", fclsRet);
            }
            return ret;
        }
        line_no += 1;
        line_no;
        n = encapsulationOfZte_strnlen_s(
            strtriml(strtrimr(buf1.as_mut_ptr())),
            ::core::mem::size_of::<[libc::c_char; 513]>() as libc::c_ulong,
            b"Errlog.csv\0"
                as *const u8 as *const libc::c_char,
            684 as libc::c_int,
        );
        if n == 0 as libc::c_int
            || buf1[0 as libc::c_int as usize] as libc::c_int == CFG_nts as libc::c_int
        {
            continue;
        }
        if !(buf1[0 as libc::c_int as usize] as libc::c_int == CFG_ssl as libc::c_int) {
            continue;
        }
        if n < 1 as libc::c_int {
            continue;
        }
        buf1[(n - 1 as libc::c_int) as usize] = 0 as libc::c_int as libc::c_char;
        if strncmp(
            buf1.as_mut_ptr().offset(1 as libc::c_int as isize),
            section as *mut libc::c_char,
            512 as libc::c_int as libc::c_ulong,
        ) == 0 as libc::c_int
        {
            break;
        }
    }
    CFG_section_line_no = line_no;
    loop {
        ret = -(12 as libc::c_int);
        n = FileGetLine(fp, buf1.as_mut_ptr(), 512 as libc::c_int);
        if n < -(1 as libc::c_int) {
            fclsRet = fclose(fp);
            if fclsRet != 0 as libc::c_int {
                eprintln!("_ConfigGetKeyForMte(710) warning! > fclose ret'{}'", fclsRet);
            }
            return ret;
        }
        ret = -(2 as libc::c_int);
        if n < 0 as libc::c_int {
            fclsRet = fclose(fp);
            if fclsRet != 0 as libc::c_int {
                eprintln!("_ConfigGetKeyForMte(718) warning! > fclose ret'{}'", fclsRet);
            }
            return ret;
        }
        line_no += 1;
        line_no;
        CFG_key_line_no = line_no;
        CFG_key_lines = 1 as libc::c_int;
        n = encapsulationOfZte_strnlen_s(
            strtriml(strtrimr(buf1.as_mut_ptr())),
            ::core::mem::size_of::<[libc::c_char; 513]>() as libc::c_ulong,
            b"Errlog.csv\0"
                as *const u8 as *const libc::c_char,
            725 as libc::c_int,
        );
        if n == 0 as libc::c_int
            || buf1[0 as libc::c_int as usize] as libc::c_int == CFG_nts as libc::c_int
        {
            continue;
        }
        ret = -(2 as libc::c_int);
        if buf1[0 as libc::c_int as usize] as libc::c_int == CFG_ssl as libc::c_int {
            fclsRet = fclose(fp);
            if fclsRet != 0 as libc::c_int {
                eprintln!("_ConfigGetKeyForMte(731) warning! > fclose ret'{}'", fclsRet);
            }
            return ret;
        }
        if n < 1 as libc::c_int {
            continue;
        }
        if buf1[(n - 1 as libc::c_int) as usize] as libc::c_int == '+' as i32 {
            buf1[(n - 1 as libc::c_int) as usize] = 0 as libc::c_int as libc::c_char;
            loop {
                ret = -(12 as libc::c_int);
                n = FileGetLine(fp, buf2.as_mut_ptr(), 512 as libc::c_int);
                if n < -(1 as libc::c_int) {
                    fclsRet = fclose(fp);
                    if fclsRet != 0 as libc::c_int {
                        eprintln!("_ConfigGetKeyForMte(746) warning! > fclose ret'{}'", fclsRet);
                    }
                    return ret;
                }
                if n < 0 as libc::c_int {
                    break;
                }
                line_no += 1;
                line_no;
                CFG_key_lines += 1;
                CFG_key_lines;
                n = encapsulationOfZte_strnlen_s(
                    strtrimr(buf2.as_mut_ptr()),
                    ::core::mem::size_of::<[libc::c_char; 513]>() as libc::c_ulong,
                    b"Errlog.csv\0"
                        as *const u8 as *const libc::c_char,
                    753 as libc::c_int,
                );
                ret = -(22 as libc::c_int);
                if n > 0 as libc::c_int
                    && buf2[(n - 1 as libc::c_int) as usize] as libc::c_int == '+' as i32
                {
                    buf2[(n - 1 as libc::c_int)
                        as usize] = 0 as libc::c_int as libc::c_char;
                    if encapsulationOfZte_strnlen_s(
                        buf1.as_mut_ptr(),
                        ::core::mem::size_of::<[libc::c_char; 513]>() as libc::c_ulong,
                        b"Errlog.csv\0"
                            as *const u8 as *const libc::c_char,
                        759 as libc::c_int,
                    )
                        + encapsulationOfZte_strnlen_s(
                            buf2.as_mut_ptr(),
                            ::core::mem::size_of::<[libc::c_char; 513]>()
                                as libc::c_ulong,
                            b"Errlog.csv\0"
                                as *const u8 as *const libc::c_char,
                            759 as libc::c_int,
                        ) > 512 as libc::c_int
                    {
                        fclsRet = fclose(fp);
                        if fclsRet != 0 as libc::c_int {
                            eprintln!("_ConfigGetKeyForMte(762) warning! > fclose ret'{}'", fclsRet);
                        }
                        return ret;
                    }
                    len = encapsulationOfZte_strnlen_s(
                        buf2.as_mut_ptr(),
                        ::core::mem::size_of::<[libc::c_char; 513]>() as libc::c_ulong,
                        b"Errlog.csv\0"
                            as *const u8 as *const libc::c_char,
                        766 as libc::c_int,
                    );
                    if len >= 0 as libc::c_int {
                        if strncat_s_rust(
                            buf1.as_mut_ptr(),
                            ::core::mem::size_of::<[libc::c_char; 513]>()
                                as libc::c_ulong,
                            buf2.as_mut_ptr(),
                            len as rsize_t,
                        ) != 0 {
                            // 连接失败，继续处理
                        }
                    }
                } else {
                    if encapsulationOfZte_strnlen_s(
                        buf1.as_mut_ptr(),
                        ::core::mem::size_of::<[libc::c_char; 513]>() as libc::c_ulong,
                        b"Errlog.csv\0"
                            as *const u8 as *const libc::c_char,
                        774 as libc::c_int,
                    )
                        + encapsulationOfZte_strnlen_s(
                            buf2.as_mut_ptr(),
                            ::core::mem::size_of::<[libc::c_char; 513]>()
                                as libc::c_ulong,
                            b"Errlog.csv\0"
                                as *const u8 as *const libc::c_char,
                            774 as libc::c_int,
                        ) > 512 as libc::c_int
                    {
                        fclsRet = fclose(fp);
                        if fclsRet != 0 as libc::c_int {
                            eprintln!("_ConfigGetKeyForMte(777) warning! > fclose ret'{}'", fclsRet);
                        }
                        return ret;
                    }
                    len = encapsulationOfZte_strnlen_s(
                        buf2.as_mut_ptr(),
                        ::core::mem::size_of::<[libc::c_char; 513]>() as libc::c_ulong,
                        b"Errlog.csv\0"
                            as *const u8 as *const libc::c_char,
                        781 as libc::c_int,
                    );
                    if len >= 0 as libc::c_int {
                        if strncat_s_rust(
                            buf1.as_mut_ptr(),
                            ::core::mem::size_of::<[libc::c_char; 513]>()
                                as libc::c_ulong,
                            buf2.as_mut_ptr(),
                            len as rsize_t,
                        ) != 0 {
                            // 连接失败，继续处理
                        }
                    }
                    break;
                }
            }
        }
        ret = -(14 as libc::c_int);
        if SplitKeyValue(buf1.as_mut_ptr(), &mut key_ptr, &mut val_ptr)
            != 1 as libc::c_int
        {
            fclsRet = fclose(fp);
            if fclsRet != 0 as libc::c_int {
                eprintln!("_ConfigGetKeyForMte(793) warning! > fclose ret'{}'", fclsRet);
            }
            return ret;
        }
        strtriml(strtrimr(key_ptr));
        if strncmp(
            key_ptr,
            key as *mut libc::c_char,
            512 as libc::c_int as libc::c_ulong,
        ) != 0 as libc::c_int
        {
            continue;
        }
        len = encapsulationOfZte_strnlen_s(
            val_ptr,
            buflen as rsize_t,
            b"Errlog.csv\0"
                as *const u8 as *const libc::c_char,
            800 as libc::c_int,
        );
        if len >= 0 as libc::c_int {
            encapsulationOfZte_strncpy_s(
                buf as *mut libc::c_char,
                buflen as rsize_t,
                val_ptr,
                len as rsize_t,
                b"Errlog.csv\0"
                    as *const u8 as *const libc::c_char,
                803 as libc::c_int,
            );
        }
        break;
    }
    ret = 0 as libc::c_int;
    fclsRet = fclose(fp);
    if fclsRet != 0 as libc::c_int {
        eprintln!("_ConfigGetKeyForMte(811) warning! > fclose ret'{}'", fclsRet);
    }
    return ret;
}
#[unsafe(no_mangle)]
pub unsafe extern "C" fn ConfigSetKey(
    mut CFG_file: *const libc::c_void,
    mut section: *const libc::c_void,
    mut key: *const libc::c_void,
    mut buf: *const libc::c_void,
) -> libc::c_int {
    let mut fp1: *mut FILE = 0 as *mut FILE;
    let mut fp2: *mut FILE = 0 as *mut FILE;
    let mut buf1: [libc::c_char; 512] = [0; 512];
    let mut line_no: libc::c_int = 0 as libc::c_int;
    let mut line_no1: libc::c_int = 0 as libc::c_int;
    let mut n: libc::c_int = 0 as libc::c_int;
    let mut ret: libc::c_int = 0 as libc::c_int;
    let mut ret2: libc::c_int = 0 as libc::c_int;
    let mut tmpfname: [libc::c_char; 11] = *::core::mem::transmute::<
        &[u8; 11],
        &mut [libc::c_char; 11],
    >(b"tmp_XXXXXX\0");
    ret = ConfigGetKeyEx(
        CFG_file,
        section,
        key,
        buf1.as_mut_ptr() as *mut libc::c_void,
        ::core::mem::size_of::<[libc::c_char; 512]>() as libc::c_ulong as libc::c_uint,
    );
    if ret <= -(10 as libc::c_int) && ret != -(10 as libc::c_int) {
        return ret;
    }
    if ret == -(10 as libc::c_int) || ret == -(1 as libc::c_int) {
        fp1 = fopen(
            CFG_file as *mut libc::c_char,
            b"a\0" as *const u8 as *const libc::c_char,
        );
        if fp1.is_null() {
            return -(11 as libc::c_int);
        }
        // 只有当 ret == -10（section 不存在）时才写入 section
        if ret == -(10 as libc::c_int) {
            {
                use std::ffi::CStr;
                let section_str = if section.is_null() {
                    ""
                } else {
                    match CStr::from_ptr(section as *const libc::c_char).to_str() {
                        Ok(s) => s,
                        Err(_) => "",
                    }
                };
                let formatted = format!("{}{}{}\n", CFG_ssl as u8 as char, section_str, CFG_ssr as u8 as char);
                if fprintf_rust(fp1, &formatted) == -(1 as libc::c_int) {
                    fclose(fp1);
                    return -(13 as libc::c_int);
                }
            }
        }
        {
            use std::ffi::CStr;
            let key_str = if key.is_null() {
                ""
            } else {
                match CStr::from_ptr(key as *const libc::c_char).to_str() {
                    Ok(s) => s,
                    Err(_) => "",
                }
            };
            let buf_str = if buf.is_null() {
                ""
            } else {
                match CStr::from_ptr(buf as *const libc::c_char).to_str() {
                    Ok(s) => s,
                    Err(_) => "",
                }
            };
            let formatted = format!("{}={}\n", key_str, buf_str);
            if fprintf_rust(fp1, &formatted) == -(1 as libc::c_int) {
                fclose(fp1);
                return -(13 as libc::c_int);
            }
        }
    }
    
    return ret2;
}
#[unsafe(no_mangle)]
pub unsafe extern "C" fn ConfigGetSections(
    mut CFG_file: *mut libc::c_void,
    mut sections: *mut *mut libc::c_char,
) -> libc::c_int {
    let mut fp: *mut FILE = 0 as *mut FILE;
    let mut buf1: [libc::c_char; 513] = [0; 513];
    let mut n: libc::c_int = 0;
    let mut n_sections: libc::c_int = 0 as libc::c_int;
    let mut ret: libc::c_int = 0;
    let mut fclsRet: INT32 = 0 as libc::c_int;
    let mut len: libc::c_int = 0 as libc::c_int;
    fp = fopen(
        CFG_file as *mut libc::c_char,
        b"rb\0" as *const u8 as *const libc::c_char,
    );
    if fp.is_null() {
        return -(10 as libc::c_int);
    }
    loop {
        ret = -(12 as libc::c_int);
        n = FileGetLine(fp, buf1.as_mut_ptr(), 512 as libc::c_int);
        if n < -(1 as libc::c_int) {
            fclsRet = fclose(fp);
            if fclsRet != 0 as libc::c_int {
                eprintln!("ConfigGetSections(1056) warning! > fclose ret'{}'", fclsRet);
            }
            return ret;
        }
        if n < 0 as libc::c_int {
            break;
        }
        n = encapsulationOfZte_strnlen_s(
            strtriml(strtrimr(buf1.as_mut_ptr())),
            ::core::mem::size_of::<[libc::c_char; 513]>() as libc::c_ulong,
            b"Errlog.csv\0"
                as *const u8 as *const libc::c_char,
            1061 as libc::c_int,
        );
        if n == 0 as libc::c_int
            || buf1[0 as libc::c_int as usize] as libc::c_int == CFG_nts as libc::c_int
        {
            continue;
        }
        ret = -(14 as libc::c_int);
        if n > 2 as libc::c_int
            && (buf1[0 as libc::c_int as usize] as libc::c_int == CFG_ssl as libc::c_int
                && buf1[(n - 1 as libc::c_int) as usize] as libc::c_int
                    != CFG_ssr as libc::c_int)
        {
            fclsRet = fclose(fp);
            if fclsRet != 0 as libc::c_int {
                eprintln!("ConfigGetSections(1067) warning! > fclose ret'{}'", fclsRet);
            }
            return ret;
        }
        if !(buf1[0 as libc::c_int as usize] as libc::c_int == CFG_ssl as libc::c_int) {
            continue;
        }
        if n < 1 as libc::c_int {
            continue;
        }
        buf1[(n - 1 as libc::c_int) as usize] = 0 as libc::c_int as libc::c_char;
        len = encapsulationOfZte_strnlen_s(
            buf1.as_mut_ptr().offset(1 as libc::c_int as isize),
            512 as libc::c_int as rsize_t,
            b"Errlog.csv\0"
                as *const u8 as *const libc::c_char,
            1075 as libc::c_int,
        );
        if len >= 0 as libc::c_int {
            encapsulationOfZte_strncpy_s(
                *sections.offset(n_sections as isize),
                512 as libc::c_int as rsize_t,
                buf1.as_mut_ptr().offset(1 as libc::c_int as isize),
                len as rsize_t,
                b"Errlog.csv\0"
                    as *const u8 as *const libc::c_char,
                1079 as libc::c_int,
            );
        }
        n_sections += 1;
        n_sections;
    }
    ret = n_sections;
    fclsRet = fclose(fp);
    if fclsRet != 0 as libc::c_int {
        eprintln!("ConfigGetSections(1087) warning! > fclose ret'{}'", fclsRet);
    }
    return ret;
}
#[unsafe(no_mangle)]
pub unsafe extern "C" fn ConfigGetKeys(
    mut CFG_file: *mut libc::c_void,
    mut section: *mut libc::c_void,
    mut keys: *mut *mut libc::c_char,
) -> libc::c_int {
    let mut fp: *mut FILE = 0 as *mut FILE;
    let mut buf1: [libc::c_char; 513] = [0; 513];
    let mut buf2: [libc::c_char; 513] = [0; 513];
    let mut key_ptr: *mut libc::c_char = 0 as *mut libc::c_char;
    let mut val_ptr: *mut libc::c_char = 0 as *mut libc::c_char;
    let mut n: libc::c_int = 0;
    let mut n_keys: libc::c_int = 0 as libc::c_int;
    let mut ret: libc::c_int = 0;
    let mut fclsRet: INT32 = 0 as libc::c_int;
    let mut len: libc::c_int = 0 as libc::c_int;
    fp = fopen(
        CFG_file as *mut libc::c_char,
        b"rb\0" as *const u8 as *const libc::c_char,
    );
    if fp.is_null() {
        return -(10 as libc::c_int);
    }
    loop {
        ret = -(12 as libc::c_int);
        n = FileGetLine(fp, buf1.as_mut_ptr(), 512 as libc::c_int);
        if n < -(1 as libc::c_int) {
            fclsRet = fclose(fp);
            if fclsRet != 0 as libc::c_int {
                eprintln!("ConfigGetKeys(1125) warning! > fclose ret'{}'", fclsRet);
            }
            return ret;
        }
        ret = -(1 as libc::c_int);
        if n < 0 as libc::c_int {
            fclsRet = fclose(fp);
            if fclsRet != 0 as libc::c_int {
                eprintln!("ConfigGetKeys(1133) warning! > fclose ret'{}'", fclsRet);
            }
            return ret;
        }
        n = encapsulationOfZte_strnlen_s(
            strtriml(strtrimr(buf1.as_mut_ptr())),
            ::core::mem::size_of::<[libc::c_char; 513]>() as libc::c_ulong,
            b"Errlog.csv\0"
                as *const u8 as *const libc::c_char,
            1137 as libc::c_int,
        );
        if n == 0 as libc::c_int
            || buf1[0 as libc::c_int as usize] as libc::c_int == CFG_nts as libc::c_int
        {
            continue;
        }
        ret = -(14 as libc::c_int);
        if n > 2 as libc::c_int
            && (buf1[0 as libc::c_int as usize] as libc::c_int == CFG_ssl as libc::c_int
                && buf1[(n - 1 as libc::c_int) as usize] as libc::c_int
                    != CFG_ssr as libc::c_int)
        {
            fclsRet = fclose(fp);
            if fclsRet != 0 as libc::c_int {
                eprintln!("ConfigGetKeys(1143) warning! > fclose ret'{}'", fclsRet);
            }
            return ret;
        }
        if !(buf1[0 as libc::c_int as usize] as libc::c_int == CFG_ssl as libc::c_int) {
            continue;
        }
        if n < 1 as libc::c_int {
            continue;
        }
        buf1[(n - 1 as libc::c_int) as usize] = 0 as libc::c_int as libc::c_char;
        if strncmp(
            buf1.as_mut_ptr().offset(1 as libc::c_int as isize),
            section as *mut libc::c_char,
            512 as libc::c_int as libc::c_ulong,
        ) == 0 as libc::c_int
        {
            break;
        }
    }
    loop {
        ret = -(12 as libc::c_int);
        n = FileGetLine(fp, buf1.as_mut_ptr(), 512 as libc::c_int);
        if n < -(1 as libc::c_int) {
            fclsRet = fclose(fp);
            if fclsRet != 0 as libc::c_int {
                eprintln!("ConfigGetKeys(1162) warning! > fclose ret'{}'", fclsRet);
            }
            return ret;
        }
        if n < 0 as libc::c_int {
            break;
        }
        n = encapsulationOfZte_strnlen_s(
            strtriml(strtrimr(buf1.as_mut_ptr())),
            ::core::mem::size_of::<[libc::c_char; 513]>() as libc::c_ulong,
            b"Errlog.csv\0"
                as *const u8 as *const libc::c_char,
            1167 as libc::c_int,
        );
        if n == 0 as libc::c_int
            || buf1[0 as libc::c_int as usize] as libc::c_int == CFG_nts as libc::c_int
        {
            continue;
        }
        ret = -(2 as libc::c_int);
        if buf1[0 as libc::c_int as usize] as libc::c_int == CFG_ssl as libc::c_int {
            break;
        }
        if n < 1 as libc::c_int {
            continue;
        }
        if buf1[(n - 1 as libc::c_int) as usize] as libc::c_int == '+' as i32 {
            buf1[(n - 1 as libc::c_int) as usize] = 0 as libc::c_int as libc::c_char;
            loop {
                ret = -(12 as libc::c_int);
                n = FileGetLine(fp, buf2.as_mut_ptr(), 512 as libc::c_int);
                if n < -(1 as libc::c_int) {
                    fclsRet = fclose(fp);
                    if fclsRet != 0 as libc::c_int {
                        eprintln!("ConfigGetKeys(1183) warning! > fclose ret'{}'", fclsRet);
                    }
                    return ret;
                }
                if n < 0 as libc::c_int {
                    break;
                }
                n = encapsulationOfZte_strnlen_s(
                    strtrimr(buf2.as_mut_ptr()),
                    ::core::mem::size_of::<[libc::c_char; 513]>() as libc::c_ulong,
                    b"Errlog.csv\0"
                        as *const u8 as *const libc::c_char,
                    1188 as libc::c_int,
                );
                ret = -(22 as libc::c_int);
                if n > 0 as libc::c_int
                    && buf2[(n - 1 as libc::c_int) as usize] as libc::c_int == '+' as i32
                {
                    buf2[(n - 1 as libc::c_int)
                        as usize] = 0 as libc::c_int as libc::c_char;
                    if encapsulationOfZte_strnlen_s(
                        buf1.as_mut_ptr(),
                        ::core::mem::size_of::<[libc::c_char; 513]>() as libc::c_ulong,
                        b"Errlog.csv\0"
                            as *const u8 as *const libc::c_char,
                        1194 as libc::c_int,
                    )
                        + encapsulationOfZte_strnlen_s(
                            buf2.as_mut_ptr(),
                            ::core::mem::size_of::<[libc::c_char; 513]>()
                                as libc::c_ulong,
                            b"Errlog.csv\0"
                                as *const u8 as *const libc::c_char,
                            1194 as libc::c_int,
                        ) > 512 as libc::c_int
                    {
                        fclsRet = fclose(fp);
                        if fclsRet != 0 as libc::c_int {
                            eprintln!("ConfigGetKeys(1197) warning! > fclose ret'{}'", fclsRet);
                        }
                        return ret;
                    }
                    len = encapsulationOfZte_strnlen_s(
                        buf2.as_mut_ptr(),
                        ::core::mem::size_of::<[libc::c_char; 513]>() as libc::c_ulong,
                        b"Errlog.csv\0"
                            as *const u8 as *const libc::c_char,
                        1201 as libc::c_int,
                    );
                    if len >= 0 as libc::c_int {
                        if strncat_s_rust(
                            buf1.as_mut_ptr(),
                            ::core::mem::size_of::<[libc::c_char; 513]>()
                                as libc::c_ulong,
                            buf2.as_mut_ptr(),
                            len as rsize_t,
                        ) != 0 {
                            // 连接失败，继续处理
                        }
                    }
                } else {
                    if encapsulationOfZte_strnlen_s(
                        buf1.as_mut_ptr(),
                        ::core::mem::size_of::<[libc::c_char; 513]>() as libc::c_ulong,
                        b"Errlog.csv\0"
                            as *const u8 as *const libc::c_char,
                        1209 as libc::c_int,
                    )
                        + encapsulationOfZte_strnlen_s(
                            buf2.as_mut_ptr(),
                            ::core::mem::size_of::<[libc::c_char; 513]>()
                                as libc::c_ulong,
                            b"Errlog.csv\0"
                                as *const u8 as *const libc::c_char,
                            1209 as libc::c_int,
                        ) > 512 as libc::c_int
                    {
                        fclsRet = fclose(fp);
                        if fclsRet != 0 as libc::c_int {
                            eprintln!("ConfigGetKeys(1212) warning! > fclose ret'{}'", fclsRet);
                        }
                        return ret;
                    }
                    len = encapsulationOfZte_strnlen_s(
                        buf2.as_mut_ptr(),
                        ::core::mem::size_of::<[libc::c_char; 513]>() as libc::c_ulong,
                        b"Errlog.csv\0"
                            as *const u8 as *const libc::c_char,
                        1216 as libc::c_int,
                    );
                    if len >= 0 as libc::c_int {
                        if strncat_s_rust(
                            buf1.as_mut_ptr(),
                            ::core::mem::size_of::<[libc::c_char; 513]>()
                                as libc::c_ulong,
                            buf2.as_mut_ptr(),
                            len as rsize_t,
                        ) != 0 {
                            // 连接失败，继续处理
                        }
                    }
                    break;
                }
            }
        }
        ret = -(14 as libc::c_int);
        if SplitKeyValue(buf1.as_mut_ptr(), &mut key_ptr, &mut val_ptr)
            != 1 as libc::c_int
        {
            fclsRet = fclose(fp);
            if fclsRet != 0 as libc::c_int {
                eprintln!("ConfigGetKeys(1228) warning! > fclose ret'{}'", fclsRet);
            }
            return ret;
        }
        strtriml(strtrimr(key_ptr));
        len = encapsulationOfZte_strnlen_s(
            key_ptr,
            512 as libc::c_int as rsize_t,
            b"Errlog.csv\0"
                as *const u8 as *const libc::c_char,
            1233 as libc::c_int,
        );
        if len >= 0 as libc::c_int {
            encapsulationOfZte_strncpy_s(
                *keys.offset(n_keys as isize),
                512 as libc::c_int as rsize_t,
                key_ptr,
                len as rsize_t,
                b"Errlog.csv\0"
                    as *const u8 as *const libc::c_char,
                1237 as libc::c_int,
            );
        }
        n_keys += 1;
        n_keys;
    }
    ret = n_keys;
    fclsRet = fclose(fp);
    if fclsRet != 0 as libc::c_int {
        eprintln!("ConfigGetKeys(1244) warning! > fclose ret'{}'", fclsRet);
    }
    return ret;
}

#![allow(
    dead_code,
    mutable_transmutes,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    unused_assignments,
    unused_mut
)]
pub type CHAR = libc::c_char;
pub type ULONG = libc::c_uint;
#[unsafe(no_mangle)]
pub unsafe extern "C" fn CopyLineData(
    mut pcSrc: *mut CHAR,
    mut pcValidData: *mut CHAR,
) -> ULONG {
    let mut ulNextLine: ULONG = 0 as libc::c_int as ULONG;
    let mut pcLineData: *mut CHAR = 0 as *mut CHAR;
    let mut ulValidLen: ULONG = 0 as libc::c_int as ULONG;
    if pcSrc.is_null() || pcValidData.is_null() {
        return 0xffffffff as libc::c_uint;
    }
    pcLineData = pcSrc;
    while '\0' as i32 != *pcLineData as libc::c_int
        && '\n' as i32 != *pcLineData as libc::c_int
        && '/' as i32 != *pcLineData as libc::c_int
    {
        let fresh0 = pcLineData;
        pcLineData = pcLineData.offset(1);
        let fresh1 = pcValidData;
        pcValidData = pcValidData.offset(1);
        *fresh1 = *fresh0;
        ulValidLen = ulValidLen.wrapping_add(1);
        ulValidLen;
        if 256 as libc::c_int as libc::c_uint <= ulValidLen {
            return 0xffffffff as libc::c_uint;
        }
    }
    ulNextLine = ulValidLen;
    if '/' as i32 == *pcLineData as libc::c_int {
        while '\0' as i32 != *pcLineData as libc::c_int
            && '\n' as i32 != *pcLineData as libc::c_int
        {
            pcLineData = pcLineData.offset(1);
            pcLineData;
            ulNextLine = ulNextLine.wrapping_add(1);
            ulNextLine;
        }
    }
    return ulNextLine;
}

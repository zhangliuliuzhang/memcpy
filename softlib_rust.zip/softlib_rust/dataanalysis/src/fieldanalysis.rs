/* Started by AICoder, pid:yf660xd2ffc0ef714ca70b4d327cdc49d0e5f470 */
#![allow(
    dead_code,
    mutable_transmutes,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    unused_assignments,
    unused_mut
)]
#![feature(extern_types)]

use ccommon::clib::*;

pub type size_t = libc::c_ulong;
pub type __off_t = libc::c_long;
pub type __off64_t = libc::c_long;
pub type _IO_lock_t = ();
pub type FILE = _IO_FILE;
pub type UCHAR = libc::c_uchar;
pub type CHAR = libc::c_char;
pub type ULONG = libc::c_uint;
pub type UINT32 = libc::c_uint;
pub type INT = libc::c_int;
pub type INT32 = libc::c_int;
pub type LONG = libc::c_long;
pub type rsize_t = size_t;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct environment_s {
    pub crc: ULONG,
    pub data: [UCHAR; 262144],
}
pub type env_t = environment_s;
#[unsafe(no_mangle)]
pub static mut g_EnvDataAddr: ULONG = 0 as libc::c_int as ULONG;
#[unsafe(no_mangle)]
pub static mut g_EnvValid: ULONG = 0 as libc::c_int as ULONG;
#[unsafe(no_mangle)]
pub static mut env_ptr: *mut env_t = 0 as *const env_t as *mut env_t;
#[unsafe(no_mangle)]
pub static mut default_environment: [UCHAR; 256] = unsafe {
    *::core::mem::transmute::<
        &[u8; 256],
        &mut [UCHAR; 256],
    >(
        b"cfrwin=1000\0cfraa=51\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0",
    )
};
#[unsafe(no_mangle)]
pub unsafe extern "C" fn InitEnv() -> ULONG {
    // 使用 Rust 的 Box::new() 和 std::mem::zeroed() 替换 malloc
    let boxed_env = Box::new(std::mem::zeroed::<env_t>());
    env_ptr = Box::into_raw(boxed_env);
    if env_ptr.is_null() {
        return 0xffffffff as libc::c_uint;
    }
    env_relocate_spec();
    return 0 as libc::c_int as UINT32;
}
#[unsafe(no_mangle)]
pub unsafe extern "C" fn use_default() -> ULONG {
    memset(
        env_ptr as *mut libc::c_void,
        0 as libc::c_int,
        ::core::mem::size_of::<env_t>() as libc::c_ulong,
    );

    (*env_ptr)
        .crc = CalculateCRC32(
        0 as libc::c_int as libc::c_uint,
        ((*env_ptr).data).as_mut_ptr(),
        ::core::mem::size_of::<[UCHAR; 256]>() as libc::c_ulong as libc::c_uint,
    );
    return 0 as libc::c_int as UINT32;
}
#[unsafe(no_mangle)]
pub unsafe extern "C" fn env_relocate_spec() -> ULONG {
    let mut fp: *mut FILE = 0 as *mut FILE;
    let mut lRet: LONG = 0 as libc::c_int as LONG;
    fp = fopen(
        b"/ata/BSP/common_env.txt\0" as *const u8 as *const libc::c_char,
        b"rb\0" as *const u8 as *const libc::c_char,
    );
    if fp.is_null() {
        eprintln!("open data file  /ata/BSP/common_env.txt error.");
        return use_default();
    }
    fseek(fp, 0 as libc::c_long, 0 as libc::c_int);
    lRet = fread(
        ((*env_ptr).data).as_mut_ptr() as *mut libc::c_void,
        ::core::mem::size_of::<[UCHAR; 262144]>() as libc::c_ulong,
        1 as libc::c_int as libc::c_ulong,
        fp,
    ) as LONG;
    if lRet <= 0 as libc::c_int as libc::c_long {
        fclose(fp);
        eprintln!("read env data error,use default env.");
        return use_default();
    }
    fclose(fp);
    g_EnvValid = 1 as libc::c_int as ULONG;
    return 0 as libc::c_int as UINT32;
}
#[unsafe(no_mangle)]
pub unsafe extern "C" fn env_get_char_spec(mut index: ULONG) -> UCHAR {
    if index > (0x40000 as libc::c_int - 1 as libc::c_int) as libc::c_uint {
        return 0xffffffff as libc::c_uint as UCHAR;
    }
    return *(((*env_ptr).data).as_mut_ptr().offset(index as isize) as *mut libc::c_char)
        as UCHAR;
}
#[unsafe(no_mangle)]
pub unsafe extern "C" fn env_get_char(mut index: ULONG) -> UCHAR {
    let mut c: UCHAR = 0;
    if g_EnvValid != 0 {
        c = env_get_char_spec(index);
    } else {
        if index as libc::c_ulong
            >= (::core::mem::size_of::<[UCHAR; 256]>() as libc::c_ulong)
                .wrapping_div(::core::mem::size_of::<UCHAR>() as libc::c_ulong)
        {
            return 0xffffffff as libc::c_uint as UCHAR;
        }
        c = default_environment[index as usize];
    }
    return c;
}
#[unsafe(no_mangle)]
pub unsafe extern "C" fn env_get_addr(mut index: ULONG) -> *mut CHAR {
    if g_EnvValid != 0 {
        if env_ptr.is_null() {
            return 0 as *mut CHAR;
        }
        return ((*env_ptr).data).as_mut_ptr().offset(index as isize) as *mut CHAR;
    } else {
        return 0 as *mut CHAR;
    }
}
#[unsafe(no_mangle)]
pub unsafe extern "C" fn envmatch(mut s1: *mut UCHAR, mut i2: INT) -> INT {
    loop {
        let fresh0 = i2;
        i2 = i2 + 1;
        if !(*s1 as libc::c_int == env_get_char(fresh0 as ULONG) as libc::c_int) {
            break;
        }
        let fresh1 = s1;
        s1 = s1.offset(1);
        if *fresh1 as libc::c_int == '=' as i32 {
            return i2;
        }
    }
    if *s1 as libc::c_int == '\0' as i32
        && env_get_char((i2 - 1 as libc::c_int) as ULONG) as libc::c_int == '=' as i32
    {
        return i2;
    }
    return 0xffffffff as libc::c_uint as INT;
}
#[unsafe(no_mangle)]
pub unsafe extern "C" fn senv(mut cName: *mut CHAR, mut cValue: *mut CHAR) -> ULONG {
    let mut len: INT = 0;
    let mut oldval: INT = 0;
    let mut env: *mut UCHAR = 0 as *mut UCHAR;
    let mut nxt: *mut UCHAR = 0 as *mut UCHAR;
    let mut name: *mut CHAR = 0 as *mut CHAR;
    let mut val: *mut CHAR = 0 as *mut CHAR;
    let mut env_data: *mut UCHAR = env_get_addr(0 as libc::c_int as ULONG) as *mut UCHAR;
    if env_data.is_null() {
        return 1 as libc::c_int as ULONG;
    }
    name = cName;
    val = cValue;
    if !(strchr(name, '=' as i32)).is_null() {
        let name_str = std::ffi::CStr::from_ptr(name).to_string_lossy();
        eprintln!("## Error: illegal character '=' in variable name \"{}\"", name_str);
        return 1 as libc::c_int as ULONG;
    }
    oldval = -(1 as libc::c_int);
    env = env_data;
    while *env as libc::c_int != '\0' as i32 {
        nxt = env;
        while *nxt as libc::c_int != '\0' as i32 {
            nxt = nxt.offset(1);
            nxt;
        }
        oldval = envmatch(
            name as *mut UCHAR,
            env.offset_from(env_data) as libc::c_long as INT,
        );
        if oldval >= 0 as libc::c_int {
            break;
        }
        env = nxt.offset(1 as libc::c_int as isize);
    }
    if oldval >= 0 as libc::c_int {
        nxt = nxt.offset(1);
        if *nxt as libc::c_int == '\0' as i32 {
            if env > env_data {
                env = env.offset(-1);
                env;
            } else {
                *env = '\0' as i32 as UCHAR;
            }
        } else {
            loop {
                let fresh2 = nxt;
                nxt = nxt.offset(1);
                *env = *fresh2;
                if *env as libc::c_int == '\0' as i32
                    && *nxt as libc::c_int == '\0' as i32
                {
                    break;
                }
                env = env.offset(1);
                env;
            }
        }
        env = env.offset(1);
        *env = '\0' as i32 as UCHAR;
    }
    if cValue.is_null() {
        return 0 as libc::c_int as ULONG;
    }
    env = env_data;
    while *env as libc::c_int != 0
        || *env.offset(1 as libc::c_int as isize) as libc::c_int != 0
    {
        env = env.offset(1);
        env;
    }
    if env > env_data {
        env = env.offset(1);
        env;
    }
    len = (strlen(name)).wrapping_add(2 as libc::c_int as libc::c_ulong) as INT;
    len = (len as libc::c_ulong)
        .wrapping_add((strlen(cValue)).wrapping_add(1 as libc::c_int as libc::c_ulong))
        as INT as INT;
    if len as libc::c_long
        > (&mut *env_data.offset(0x40000 as libc::c_int as isize) as *mut UCHAR)
            .offset_from(env) as libc::c_long
    {
        let name_str = std::ffi::CStr::from_ptr(name).to_string_lossy();
        eprintln!("## Error: environment overflow, \"{}\" deleted", name_str);
        return 1 as libc::c_int as ULONG;
    }
    loop {
        let fresh3 = name;
        name = name.offset(1);
        *env = *fresh3 as UCHAR;
        if !(*env as libc::c_int != '\0' as i32) {
            break;
        }
        env = env.offset(1);
        env;
    }
    *env = '=' as i32 as UCHAR;
    loop {
        let fresh4 = val;
        val = val.offset(1);
        env = env.offset(1);
        *env = *fresh4 as UCHAR;
        if !(*env as libc::c_int != '\0' as i32) {
            break;
        }
    }
    env = env.offset(1);
    *env = '\0' as i32 as UCHAR;
    return 0 as libc::c_int as UINT32;
}
#[unsafe(no_mangle)]
pub unsafe extern "C" fn genv(mut name: *const CHAR) -> *mut CHAR {
    let mut i: INT = 0;
    let mut nxt: INT = 0;
    let mut val: INT = 0 as libc::c_int;
    i = 0 as libc::c_int;
    while env_get_char(i as ULONG) as libc::c_int != '\0' as i32 {
        nxt = i;
        while env_get_char(nxt as ULONG) as libc::c_int != '\0' as i32 {
            if nxt >= 0x40000 as libc::c_int {
                return 0 as *mut CHAR;
            }
            nxt += 1;
            nxt;
        }
        val = envmatch(name as *mut UCHAR, i);
        if val < 0 as libc::c_int {
            i = nxt + 1 as libc::c_int;
        } else {
            return env_get_addr(val as ULONG)
        }
    }
    return 0 as *mut CHAR;
}
#[unsafe(no_mangle)]
pub unsafe extern "C" fn setfield(mut cName: *mut CHAR, mut cValue: *mut CHAR) -> LONG {
    let mut ulRet: ULONG = 0 as libc::c_int as ULONG;
    ulRet = senv(cName, cValue);
    return ulRet as LONG;
}
#[unsafe(no_mangle)]
pub unsafe extern "C" fn getfield(mut name: *const CHAR) -> LONG {
    let mut cVal: *mut CHAR = 0 as *mut CHAR;
    let mut lVal: ULONG = 0 as libc::c_int as ULONG;
    cVal = genv(name);
    if cVal.is_null() {
        return 0xffffffff as libc::c_uint as LONG;
    }
    if '\0' as i32 == *cVal.offset(0 as libc::c_int as isize) as libc::c_int {
        return 0xffffffff as libc::c_uint as LONG;
    }
    lVal = strtoul(cVal, 0 as *mut *mut libc::c_char, 0 as libc::c_int) as ULONG;
    if (9223372036854775807 as libc::c_long as libc::c_ulong)
        .wrapping_mul(2 as libc::c_ulong)
        .wrapping_add(1 as libc::c_ulong) == lVal as libc::c_ulong
    {
        // 使用 Rust 的 eprintln! 替换 mzprnL
        eprintln!("getfield:strtoul return error!");
    }
    return lVal as LONG;
}
#[unsafe(no_mangle)]
pub unsafe extern "C" fn printenv() -> ULONG {
    let mut i: libc::c_int = 0;
    let mut nxt: libc::c_int = 0;
    let mut k: libc::c_int = 0;
    i = 0 as libc::c_int;
    while env_get_char(i as ULONG) as libc::c_int != '\0' as i32 {
        nxt = i;
        while env_get_char(nxt as ULONG) as libc::c_int != '\0' as i32 {
            nxt += 1;
            nxt;
        }
        k = i;
        while k < nxt {
            print!("{}", env_get_char(k as ULONG) as u8 as char);
            k += 1;
            k;
        }
        println!();
        i = nxt + 1 as libc::c_int;
    }
    println!("\nEnvironment size: {}/{} bytes", i, 0x40000 as libc::c_int);
    return 0 as libc::c_int as UINT32;
}
#[unsafe(no_mangle)]
pub unsafe extern "C" fn printfile() -> ULONG {
    let mut lRet: libc::c_int = 0 as libc::c_int;
    let mut i: UINT32 = 0;
    let mut nxt: UINT32 = 0;
    let mut k: UINT32 = 0;
    let mut fp: *mut FILE = 0 as *mut FILE;
    // 使用 Rust 的 Box::new() 和 std::mem::zeroed() 替换 malloc
    let cBuf_box = Box::new(std::mem::zeroed::<env_t>());
    // 使用 Box::into_raw() 获取原始指针，稍后使用 Box::from_raw() 释放
    let cBuf = Box::into_raw(cBuf_box);
    fp = fopen(
        b"/ata/BSP/common_env.txt\0" as *const u8 as *const libc::c_char,
        b"rb\0" as *const u8 as *const libc::c_char,
    );
    if fp.is_null() {
        // 使用 Rust 的 eprintln! 替换 mzprnL
        eprintln!("open data file  /ata/BSP/common_env.txt error.");
        // 使用 Box::from_raw() 释放内存，替换 free
        let _ = Box::from_raw(cBuf);
        return 0xffffffff as libc::c_uint;
    }
    lRet = fread(
        cBuf as *mut libc::c_void,
        ::core::mem::size_of::<env_t>() as libc::c_ulong,
        1 as libc::c_int as libc::c_ulong,
        fp,
    ) as libc::c_int;
    if lRet <= 0 as libc::c_int {
        fclose(fp);
        // 使用 Rust 的 eprintln! 替换 mzprnL
        eprintln!("read env data error,use default env.");
        // 使用 Box::from_raw() 释放内存，替换 free
        let _ = Box::from_raw(cBuf);
        return 0xffffffff as libc::c_uint;
    }
    fclose(fp);
    i = 0 as libc::c_int as UINT32;
    while (*cBuf).data[i as usize] as libc::c_int != '\0' as i32 {
        nxt = i;
        while (*cBuf).data[nxt as usize] as libc::c_int != '\0' as i32 {
            nxt = nxt.wrapping_add(1);
            nxt;
        }
        k = i;
        while k < nxt {
            // 使用 Rust 的 eprint! 替换 mzprnL（打印单个字符，不换行）
            eprint!("{}", (*cBuf).data[k as usize] as u8 as char);
            k = k.wrapping_add(1);
            k;
        }
        // 使用 Rust 的 eprintln! 替换 mzprnL（打印换行）
        eprintln!();
        i = nxt.wrapping_add(1 as libc::c_int as libc::c_uint);
    }
    // 使用 Box::from_raw() 释放内存，替换 free
    let _ = Box::from_raw(cBuf);
    return 0 as libc::c_int as ULONG;
}
#[unsafe(no_mangle)]
pub unsafe extern "C" fn saveenv() -> ULONG {
    let mut fp: *mut FILE = 0 as *mut FILE;
    let mut FileName: *const CHAR = 0 as *const CHAR;
    let mut i: UINT32 = 0 as libc::c_int as UINT32;
    let mut ret: INT32 = 0 as libc::c_int;
    FileName = b"/ata/BSP/common_env.txt\0" as *const u8 as *const libc::c_char;
    fp = fopen(FileName, b"wb\0" as *const u8 as *const libc::c_char);
    if fp.is_null() {
        let file_name_str = std::ffi::CStr::from_ptr(FileName as *const libc::c_char).to_string_lossy();
        eprintln!("open data file  {} error.", file_name_str);
        return 0xffffffff as libc::c_uint;
    }
    // 检查 env_ptr 是否为空
    if env_ptr.is_null() {
        fclose(fp);
        let file_name_str = std::ffi::CStr::from_ptr(FileName as *const libc::c_char).to_string_lossy();
        eprintln!("saveenv: env_ptr is null");
        return 0xffffffff as libc::c_uint;
    }
    ret = fwrite(
        env_ptr as *const libc::c_void,
        ::core::mem::size_of::<ULONG>() as libc::c_ulong,
        1 as libc::c_int as libc::c_ulong,
        fp,
    ) as INT32;
    if ret != 1 as libc::c_int {
        // 使用 Rust 的 eprintln! 替换 mzprnL
        let file_name_str = std::ffi::CStr::from_ptr(FileName as *const libc::c_char).to_string_lossy();
        eprintln!("saveenv fail to write {}", file_name_str);
    }
    i = 0 as libc::c_int as UINT32;
    while (*env_ptr).data[i as usize] as libc::c_int != '\0' as i32
        || (*env_ptr).data[i.wrapping_add(1 as libc::c_int as libc::c_uint) as usize]
            as libc::c_int != '\0' as i32
    {
        ret = fwrite(
            &mut *((*env_ptr).data).as_mut_ptr().offset(i as isize) as *mut UCHAR
                as *mut libc::c_char as *const libc::c_void,
            1 as libc::c_int as libc::c_ulong,
            ::core::mem::size_of::<CHAR>() as libc::c_ulong,
            fp,
        ) as INT32;
        if ret as libc::c_ulong != ::core::mem::size_of::<CHAR>() as libc::c_ulong {
            // 使用 Rust 的 eprintln! 替换 mzprnL
            let file_name_str = std::ffi::CStr::from_ptr(FileName as *const libc::c_char).to_string_lossy();
            eprintln!("saveenv fail to write {}", file_name_str);
        }
        i = i.wrapping_add(1);
        i;
    }
    fclose(fp);
    return 0 as libc::c_int as UINT32;
}
/* Ended by AICoder, pid:yf660xd2ffc0ef714ca70b4d327cdc49d0e5f470 */
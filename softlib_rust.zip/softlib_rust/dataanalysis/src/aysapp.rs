#![allow(
    dead_code,
    mutable_transmutes,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    unused_assignments,
    unused_mut
)]
use ccommon::clib::*;
use crate::fieldanalysis::InitEnv;
pub type size_t = libc::c_ulong;
pub type __dev_t = libc::c_ulong;
pub type __uid_t = libc::c_uint;
pub type __gid_t = libc::c_uint;
pub type __ino_t = libc::c_ulong;
pub type __mode_t = libc::c_uint;
pub type __nlink_t = libc::c_ulong;
pub type __off_t = libc::c_long;
pub type __time_t = libc::c_long;
pub type __blksize_t = libc::c_long;
pub type __blkcnt_t = libc::c_long;
pub type __syscall_slong_t = libc::c_long;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct timespec {
    pub tv_sec: __time_t,
    pub tv_nsec: __syscall_slong_t,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct stat {
    pub st_dev: __dev_t,
    pub st_ino: __ino_t,
    pub st_nlink: __nlink_t,
    pub st_mode: __mode_t,
    pub st_uid: __uid_t,
    pub st_gid: __gid_t,
    pub __pad0: libc::c_int,
    pub st_rdev: __dev_t,
    pub st_size: __off_t,
    pub st_blksize: __blksize_t,
    pub st_blocks: __blkcnt_t,
    pub st_atim: timespec,
    pub st_mtim: timespec,
    pub st_ctim: timespec,
    pub __glibc_reserved: [__syscall_slong_t; 3],
}
pub type WORDPTR = libc::c_ulong;
pub type UCHAR = libc::c_uchar;
pub type CHAR = libc::c_char;
pub type ULONG = libc::c_uint;
pub type UINT32 = libc::c_uint;
pub type INT8 = libc::c_schar;
pub type LONG = libc::c_long;
pub type rsize_t = size_t;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct tag_RegionInfo {
    pub ulUserId: ULONG,
    pub cRgName: [CHAR; 64],
    pub ulValidFlag: ULONG,
    pub pRgStartAddr: *mut LONG,
    pub ulRgSize: ULONG,
    pub ulDataWd: ULONG,
}
pub type tRegionInfo = tag_RegionInfo;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct tagT_AysAppInfo {
    pub filePath: *mut INT8,
    pub mode: UINT32,
}
pub type T_AysAppInfo = tagT_AysAppInfo;
pub type AYS_FUN = Option::<unsafe extern "C" fn(UINT32, ...) -> UINT32>;

// 辅助函数：将格式化后的字符串复制到 C 字符串缓冲区
#[unsafe(no_mangle)]
pub unsafe extern "C" fn copy_formatted_to_cstr(
    buf: *mut libc::c_char,
    buf_size: rsize_t,
    formatted_str: &str,
) -> libc::c_int {
    if buf.is_null() || buf_size == 0 {
        return -1;
    }
    
    let max_len = buf_size as usize;
    if formatted_str.len() >= max_len {
        return -1;
    }
    
    // 将格式化后的字符串复制到 C 字符串缓冲区
    match std::ffi::CString::new(formatted_str) {
        Ok(c_str) => {
            let src_bytes = c_str.as_bytes_with_nul();
            let copy_len = if src_bytes.len() > max_len { max_len } else { src_bytes.len() };
            std::ptr::copy_nonoverlapping(
                src_bytes.as_ptr(),
                buf as *mut u8,
                copy_len,
            );
            (copy_len - 1) as libc::c_int
        }
        Err(_) => -1,
    }
}
#[unsafe(no_mangle)]
pub unsafe extern "C" fn AysGetLine(
    mut in_0: *const INT8,
    mut out: *mut INT8,
) -> *const INT8 {
    while *in_0 as libc::c_int != '\0' as i32 && *in_0 as libc::c_int != '\r' as i32
        && *in_0 as libc::c_int != '\n' as i32
    {
        let fresh0 = in_0;
        in_0 = in_0.offset(1);
        let fresh1 = out;
        out = out.offset(1);
        *fresh1 = *fresh0;
    }
    while *in_0 as libc::c_int != '\0' as i32
        && (*in_0 as libc::c_int == '\r' as i32 || *in_0 as libc::c_int == '\n' as i32)
    {
        in_0 = in_0.offset(1);
        in_0;
    }
    return in_0;
}
#[unsafe(no_mangle)]
pub unsafe extern "C" fn AysGetCmd(mut pLine: *mut INT8) -> UINT32 {
    let mut buf: *mut INT8 = 0 as *mut INT8;
    let mut start: *mut INT8 = strchr(pLine as *const libc::c_char, '=' as i32)
        as *mut INT8;
    if start.is_null() {
        // 使用 Rust 的 eprintln! 替换 mzprnL
        eprintln!("AysGetCmd:strchr return NULL!");
    }
    let mut end: *mut INT8 = strchr(pLine as *const libc::c_char, ';' as i32)
        as *mut INT8;
    if end.is_null() {
        // 使用 Rust 的 eprintln! 替换 mzprnL
        eprintln!("AysGetCmd:strchr return NULL!");
    }
    if start.is_null() || end.is_null() || start >= end {
        return 0xffffffff as libc::c_uint;
    }
    buf = strchr(pLine as *const libc::c_char, '#' as i32) as *mut INT8;
    if !buf.is_null() && buf <= end {
        return 0xffffffff as libc::c_uint;
    }
    buf = strstr(
        pLine as *const libc::c_char,
        b"//\0" as *const u8 as *const libc::c_char,
    ) as *mut INT8;
    if !buf.is_null() && buf <= end {
        return 0xffffffff as libc::c_uint;
    }
    buf = start.offset(1 as libc::c_int as isize);
    while buf < end {
        *pLine = *buf;
        buf = buf.offset(1);
        buf;
        pLine = pLine.offset(1);
        pLine;
    }
    *pLine = '\0' as i32 as INT8;
    return 0 as libc::c_int as UINT32;
}
#[unsafe(no_mangle)]
pub unsafe extern "C" fn BspFuncAys(mut cmd: *const INT8) -> UINT32 {
    let mut ret: UINT32 = 0 as libc::c_int as UINT32;
    let mut pfun: AYS_FUN = None;
    let mut funname: [INT8; 128] = [
        0 as libc::c_int as INT8,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
    ];
    let mut paraStr: [[INT8; 16]; 8] = [
        [0 as libc::c_int as INT8, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
        [0; 16],
        [0; 16],
        [0; 16],
        [0; 16],
        [0; 16],
        [0; 16],
        [0; 16],
    ];
    let mut paraVal: [UINT32; 8] = [0 as libc::c_int as UINT32, 0, 0, 0, 0, 0, 0, 0];
    let mut buf: *const INT8 = 0 as *const INT8;
    let mut num: UINT32 = 0 as libc::c_int as UINT32;
    let mut chnum: UINT32 = 0 as libc::c_int as UINT32;
    let mut retVal: UINT32 = 0 as libc::c_int as UINT32;
    if cmd.is_null() {
        return 0xffffffff as libc::c_uint;
    }
    // 使用 Rust 的 eprintln! 替换 ExPrnLev
    let cmd_str = std::ffi::CStr::from_ptr(cmd as *const libc::c_char).to_string_lossy();
    eprintln!("{}", cmd_str);
    buf = cmd;
    while *buf as libc::c_int != '\0' as i32 && *buf as libc::c_int == ' ' as i32 {
        buf = buf.offset(1);
        buf;
    }
    num = 0 as libc::c_int as UINT32;
    while (num as libc::c_ulong) < ::core::mem::size_of::<[INT8; 128]>() as libc::c_ulong
        && *buf as libc::c_int != '\0' as i32 && *buf as libc::c_int != ' ' as i32
        && *buf as libc::c_int != ',' as i32
    {
        funname[num as usize] = *buf;
        num = num.wrapping_add(1);
        num;
        buf = buf.offset(1);
        buf;
    }

    if pfun.is_none() || 0 as libc::c_int as UINT32 != retVal {
        return 0xffffffff as libc::c_uint;
    }
    num = 0 as libc::c_int as UINT32;
    while *buf as libc::c_int != '\0' as i32
        && num
            < (::core::mem::size_of::<[[INT8; 16]; 8]>() as libc::c_ulong)
                .wrapping_div(::core::mem::size_of::<[INT8; 16]>() as libc::c_ulong)
                as UINT32
    {
        if *buf as libc::c_int == ' ' as i32 || *buf as libc::c_int == ',' as i32 {
            buf = buf.offset(1);
            buf;
        } else if *buf as libc::c_int == '"' as i32 {
            buf = buf.offset(1);
            buf;
            chnum = 0 as libc::c_int as UINT32;
            while *buf as libc::c_int != '\0' as i32 && *buf as libc::c_int != '"' as i32
            {
                if chnum
                    < (::core::mem::size_of::<[INT8; 16]>() as libc::c_ulong)
                        .wrapping_div(::core::mem::size_of::<INT8>() as libc::c_ulong)
                        as UINT32
                {
                    let fresh2 = buf;
                    buf = buf.offset(1);
                    let fresh3 = chnum;
                    chnum = chnum.wrapping_add(1);
                    paraStr[num as usize][fresh3 as usize] = *fresh2;
                }
            }
            let fresh4 = buf;
            buf = buf.offset(1);
            if *fresh4 as libc::c_int != '"' as i32 {
                return 0xffffffff as libc::c_uint;
            }
            paraVal[num
                as usize] = &mut *(*paraStr.as_mut_ptr().offset(num as isize))
                .as_mut_ptr()
                .offset(0 as libc::c_int as isize) as *mut INT8 as UINT32;
            num = num.wrapping_add(1);
            num;
        } else {
            let fresh5 = num;
            num = num.wrapping_add(1);
            paraVal[fresh5
                as usize] = strtoul(
                buf as *const libc::c_char,
                &mut buf as *mut *const INT8 as *mut *mut libc::c_char,
                0 as libc::c_int,
            ) as UINT32;
        }
    }
    ret = pfun
        .expect(
            "non-null function pointer",
        )(
        paraVal[0 as libc::c_int as usize],
        paraVal[1 as libc::c_int as usize],
        paraVal[2 as libc::c_int as usize],
        paraVal[3 as libc::c_int as usize],
        paraVal[4 as libc::c_int as usize],
        paraVal[5 as libc::c_int as usize],
        paraVal[6 as libc::c_int as usize],
        paraVal[7 as libc::c_int as usize],
    );
    return ret;
}

#[unsafe(no_mangle)]
pub unsafe extern "C" fn CmdRun(mut data: *const INT8, mut size: UINT32) -> UINT32 {
    let mut temp: [INT8; 400] = [0; 400];
    let mut buf: *const INT8 = data;
    if data.is_null() {
        return 0xffffffff as libc::c_uint;
    }
    while buf < data.offset(size as isize) {
        memset(
            temp.as_mut_ptr() as *mut libc::c_void,
            0 as libc::c_int,
            ::core::mem::size_of::<[INT8; 400]>() as libc::c_ulong,
        );
        let old_buf = buf;
        buf = AysGetLine(buf, temp.as_mut_ptr());
        // 防止无限循环：如果 AysGetLine 没有前进，强制前进
        if buf == old_buf {
            buf = buf.offset(1);
        }
        // 防止越界：如果 buf 已经超出范围，退出循环
        if buf >= data.offset(size as isize) {
            break;
        }
        if 0 as libc::c_int as UINT32 != AysGetCmd(temp.as_mut_ptr()) {
            continue;
        }
        BspFuncAys(temp.as_mut_ptr());
    }
    return 0 as libc::c_int as UINT32;
}
#[unsafe(no_mangle)]
pub unsafe extern "C" fn FieldFun(mut fieldName: *const INT8) -> UINT32 {
    let mut retVal: UINT32 = 0 as libc::c_int as UINT32;
    let mut cmdStat: stat = {
        let mut init = stat {
            st_dev: 0 as libc::c_int as __dev_t,
            st_ino: 0,
            st_nlink: 0,
            st_mode: 0,
            st_uid: 0,
            st_gid: 0,
            __pad0: 0,
            st_rdev: 0,
            st_size: 0,
            st_blksize: 0,
            st_blocks: 0,
            st_atim: timespec { tv_sec: 0, tv_nsec: 0 },
            st_mtim: timespec { tv_sec: 0, tv_nsec: 0 },
            st_ctim: timespec { tv_sec: 0, tv_nsec: 0 },
            __glibc_reserved: [0; 3],
        };
        init
    };
    let mut path: [INT8; 128] = [
        0 as libc::c_int as INT8,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
    ];
    let mut tmpRg: ccommon::clib::tRegionInfo = {
        let mut init = ccommon::clib::tag_RegionInfo {
            ulUserId: 0 as libc::c_int as ULONG,
            cRgName: [0; 64],
            ulValidFlag: 0,
            pRgStartAddr: 0 as *mut LONG,
            ulRgSize: 0,
            ulDataWd: 0,
        };
        init
    };
    let mut pRg: *mut ccommon::clib::tRegionInfo = 0 as *mut ccommon::clib::tRegionInfo;
    if fieldName.is_null() {
        return 0xffffffff as libc::c_uint;
    }
    // 使用 Rust 的 format! 宏替换 snprintf_s
    let prefix = "/ata/BSP/";
    let field_name_str = std::ffi::CStr::from_ptr(fieldName as *const libc::c_char).to_string_lossy();
    let formatted_str = format!("{}{}", prefix, field_name_str);
    let copy_ret = copy_formatted_to_cstr(
        path.as_mut_ptr() as *mut libc::c_char,
        ::core::mem::size_of::<[INT8; 128]>() as libc::c_ulong,
        &formatted_str,
    );
    if copy_ret < 0 as libc::c_int {
        return 0xffffffff as libc::c_uint;
    }
    
    InitAysModule(path.as_mut_ptr() as *const CHAR, 0 as libc::c_int as ULONG);
    ReadDataFromFile(path.as_mut_ptr() as ULONG);
    retVal = GetPrimaryRegionInfo(
        path.as_mut_ptr() as ULONG,
        b"RG_FIELD\0" as *const u8 as *const CHAR,
        &mut tmpRg,
    );
    if 0xffffffff as libc::c_uint == retVal {
        return 0xffffffff as libc::c_uint;
    }
    pRg = GetChildRegionInfo(&mut tmpRg, fieldName as *const CHAR);
    if pRg.is_null() {
        return 0xffffffff as libc::c_uint;
    }
    return CmdRun((*pRg).pRgStartAddr as *mut INT8, (*pRg).ulRgSize);
}
#[unsafe(no_mangle)]
pub unsafe extern "C" fn bspcmd(mut fieldName: *const libc::c_char) -> UINT32 {
    let mut retVal: UINT32 = 0 as libc::c_int as UINT32;
    let mut cmdStat: stat = {
        let mut init = stat {
            st_dev: 0 as libc::c_int as __dev_t,
            st_ino: 0,
            st_nlink: 0,
            st_mode: 0,
            st_uid: 0,
            st_gid: 0,
            __pad0: 0,
            st_rdev: 0,
            st_size: 0,
            st_blksize: 0,
            st_blocks: 0,
            st_atim: timespec { tv_sec: 0, tv_nsec: 0 },
            st_mtim: timespec { tv_sec: 0, tv_nsec: 0 },
            st_ctim: timespec { tv_sec: 0, tv_nsec: 0 },
            __glibc_reserved: [0; 3],
        };
        init
    };
    let mut tmpRg: ccommon::clib::tRegionInfo = {
        let mut init = ccommon::clib::tag_RegionInfo {
            ulUserId: 0 as libc::c_int as ULONG,
            cRgName: [0; 64],
            ulValidFlag: 0,
            pRgStartAddr: 0 as *mut LONG,
            ulRgSize: 0,
            ulDataWd: 0,
        };
        init
    };
    let mut pRg: *mut ccommon::clib::tRegionInfo = 0 as *mut ccommon::clib::tRegionInfo;
    ReadDataFromFile(b"/ata/BSP/cmd.txt\0" as *const u8 as *const libc::c_char as ULONG);
    retVal = GetPrimaryRegionInfo(
        b"/ata/BSP/cmd.txt\0" as *const u8 as *const libc::c_char as ULONG,
        b"RG_FIELD\0" as *const u8 as *const CHAR,
        &mut tmpRg,
    );
    if 0xffffffff as libc::c_uint == retVal {
        return 0xffffffff as libc::c_uint;
    }
    pRg = GetChildRegionInfo(
        &mut tmpRg,
        if !fieldName.is_null() {
            fieldName as *const CHAR
        } else {
            b"NULL\0" as *const u8 as *const CHAR
        },
    );
    if !pRg.is_null() {
        retVal = CmdRun((*pRg).pRgStartAddr as *mut INT8, (*pRg).ulRgSize);
    } else {
        retVal = FieldFun(fieldName as *const INT8);
    }
    return retVal;
}
#[unsafe(no_mangle)]
pub unsafe extern "C" fn BspAysAppInit(
    mut pField: *const T_AysAppInfo,
    mut num: UINT32,
) -> UINT32 {
    let mut retVal: UINT32 = 0 as libc::c_int as UINT32;
    let mut loop_0: UINT32 = 0 as libc::c_int as UINT32;
    retVal
        |= InitAysModule(
            b"/ata/BSP/cmd.txt\0" as *const u8 as *const libc::c_char,
            0 as libc::c_int as ULONG,
        );
    if !pField.is_null() {
        loop_0 = 0 as libc::c_int as UINT32;
        while loop_0 < num {
            retVal
                |= InitAysModule(
                    (*pField.offset(loop_0 as isize)).filePath as *const CHAR,
                    (*pField.offset(loop_0 as isize)).mode,
                );
            loop_0 = loop_0.wrapping_add(1);
            loop_0;
        }
    }
    InitEnv();
    return retVal;
}

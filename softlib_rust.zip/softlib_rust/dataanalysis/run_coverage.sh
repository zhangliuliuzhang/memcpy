#!/bin/bash
# grcov 覆盖率生成脚本

# 设置环境变量启用覆盖率收集
export CARGO_INCREMENTAL=0
export RUSTFLAGS="-Cinstrument-coverage"

# 清理之前的覆盖率数据
echo "清理之前的覆盖率数据..."
rm -rf coverage/ *.profraw lcov.info

# 运行测试并生成覆盖率数据
echo "运行测试以生成覆盖率数据..."
cargo test --lib --test dataanalysis_test

# 检查是否生成了 .profraw 文件
if ls *.profraw 1> /dev/null 2>&1; then
    echo "找到覆盖率数据文件:"
    ls -lh *.profraw
else
    echo "警告: 未找到 .profraw 文件，尝试查找 target 目录中的文件..."
    find target -name "*.profraw" 2>/dev/null | head -5
fi

# 使用 grcov 生成 LCOV 格式报告
echo "生成 LCOV 格式覆盖率报告..."
grcov . \
    --binary-path ./target/debug/deps \
    -s . \
    -t lcov \
    --branch \
    --ignore-not-existing \
    --ignore "/*" \
    -o lcov.info

# 检查是否成功生成报告
if [ -f lcov.info ]; then
    echo "✅ LCOV 报告已生成: lcov.info"
    echo "文件大小: $(du -h lcov.info | cut -f1)"
else
    echo "❌ 未能生成 LCOV 报告"
    exit 1
fi

# 可选：生成 HTML 报告
echo "生成 HTML 格式覆盖率报告..."
grcov . \
    --binary-path ./target/debug/deps \
    -s . \
    -t html \
    --branch \
    --ignore-not-existing \
    --ignore "/*" \
    -o coverage/

if [ -d coverage ]; then
    echo "✅ HTML 报告已生成: coverage/"
    echo "打开 coverage/index.html 查看报告"
else
    echo "❌ 未能生成 HTML 报告"
    exit 1
fi

echo "完成！"


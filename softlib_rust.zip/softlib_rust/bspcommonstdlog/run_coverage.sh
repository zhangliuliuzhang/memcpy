#!/bin/bash
# grcov 覆盖率生成脚本

# 设置环境变量启用覆盖率收集
export CARGO_INCREMENTAL=0
export RUSTFLAGS="-C instrument-coverage -Zno-profiler-runtime"

# 清理之前的覆盖率数据
echo "清理之前的覆盖率数据..."
rm -rf coverage/ *.profraw lcov.info coverage.xml

# 运行测试并生成覆盖率数据
echo "运行测试以生成覆盖率数据..."
cargo clean
cargo test --test bspcommonstdlog_test capture_all_coverage --no-fail-fast

# 检查是否生成了 .profraw 文件
if ls *.profraw 1> /dev/null 2>&1; then
    echo "找到覆盖率数据文件:"
    ls -lh *.profraw
else
    echo "警告: 未找到 .profraw 文件，尝试查找 target 目录中的文件..."
    find target -name "*.profraw" 2>/dev/null | head -5
fi

# 使用 grcov 生成 XML 格式报告（Cobertura 格式）
echo "生成 XML 格式覆盖率报告..."
grcov . \
    --binary-path ./target/debug/deps \
    -s . \
    -t cobertura \
    --branch \
    --ignore-not-existing \
    --ignore "/*" \
    -o coverage.xml

# 检查是否成功生成报告
if [ -f coverage.xml ]; then
    echo "✅ XML 报告已生成: coverage.xml"
    echo "文件大小: $(du -h coverage.xml | cut -f1)"
    echo "XML 报告格式: Cobertura (可用于 CI/CD 集成)"
else
    echo "❌ 未能生成 XML 报告"
    exit 1
fi

# 可选：生成 HTML 报告
echo "生成 HTML 格式覆盖率报告..."
grcov . \
    --binary-path ./target/debug/deps \
    -s . \
    -t html \
    --branch \
    --ignore-not-existing \
    --ignore "/*" \
    -o coverage/

if [ -d coverage ]; then
    echo "✅ HTML 报告已生成: coverage/"
    echo "打开 coverage/index.html 查看报告"
else
    echo "⚠️  未能生成 HTML 报告（不影响 XML 报告）"
fi

# 可选：生成 LCOV 格式报告（用于其他工具）
echo "生成 LCOV 格式覆盖率报告（可选）..."
grcov . \
    --binary-path ./target/debug/deps \
    -s . \
    -t lcov \
    --branch \
    --ignore-not-existing \
    --ignore "/*" \
    -o lcov.info

if [ -f lcov.info ]; then
    echo "✅ LCOV 报告已生成: lcov.info"
else
    echo "⚠️  未能生成 LCOV 报告（不影响 XML 报告）"
fi

echo ""
echo "=========================================="
echo "覆盖率报告生成完成！"
echo "=========================================="
echo "XML 报告: coverage.xml (Cobertura 格式)"
echo "HTML 报告: coverage/index.html (用于查看)"
echo "LCOV 报告: lcov.info (用于其他工具)"
echo "=========================================="


#![allow(
    dead_code,
    mutable_transmutes,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    unused_assignments,
    unused_mut
)]
#![feature(extern_types)]

use ccommon::clib::*;
use std::io::Write;
use std::ffi::c_void;
#[repr(C)]
pub struct _IO_wide_data(c_void);
pub struct _IO_codecvt(c_void);
pub struct _IO_marker(c_void);
pub type __off_t = libc::c_long;
pub type __off64_t = libc::c_long;
pub type __time_t = libc::c_long;
pub type time_t = __time_t;
pub type _IO_lock_t = ();
pub type FILE = _IO_FILE;
pub type CHAR = libc::c_char;
pub type UINT32 = libc::c_uint;
pub type INT32 = libc::c_int;
pub type rsize_t = libc::c_int;
pub type errno_t = libc::c_int;
pub const QUERY_FAULT_RECORD: FaultRecordOpType = 3;
pub const DELETE_FAULT_RECORD: FaultRecordOpType = 2;
pub type BSP_GET_DEV_NUM = Option::<unsafe extern "C" fn() -> UINT32>;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct C2RustUnnamed {
    pub number: *const libc::c_char,
    pub faultCategory: *const libc::c_char,
    pub paraInfo: *const libc::c_char,
    pub paraDesc: *const libc::c_char,
    pub minVal: UINT32,
    pub pGetDevNumFunc: BSP_GET_DEV_NUM,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct T_FaultInfoLogPara {
    pub mtsNum: UINT32,
    pub dpdicNum: UINT32,
    pub fpgaNum: UINT32,
    pub pwrModuleNum: UINT32,
}
pub const ADD_FAULT_RECORD: FaultRecordOpType = 1;
pub const HELP_FAULT_RECORD: FaultRecordOpType = 0;
pub type FaultRecordOpType = libc::c_uint;
static mut s_faultInfoLogPara: T_FaultInfoLogPara = {
    let mut init = T_FaultInfoLogPara {
        mtsNum: 0 as libc::c_int as UINT32,
        dpdicNum: 0,
        fpgaNum: 0,
        pwrModuleNum: 0,
    };
    init
};
static mut faultTable: [C2RustUnnamed; 13] = unsafe {
    [
        {
            let mut init = C2RustUnnamed {
                number: b"1 \0" as *const u8 as *const libc::c_char,
                faultCategory: b"\xE9\xA9\xBB\xE6\xB3\xA2\xE6\xAF\x94\xE5\x86\x85\xE9\x83\xA8\xE5\xA4\xB1\xE6\x95\x88\0"
                    as *const u8 as *const libc::c_char,
                paraInfo: b"\xE5\xA4\xA9\xE7\xBA\xBF\xE5\x8F\xB7      \0" as *const u8
                    as *const libc::c_char,
                paraDesc: b"\xE4\xBB\x8E1\xE5\xBC\x80\xE5\xA7\x8B\0" as *const u8
                    as *const libc::c_char,
                minVal: 1 as libc::c_int as UINT32,
                pGetDevNumFunc: Some(BspGetAntNum as unsafe extern "C" fn() -> UINT32),
            };
            init
        },
        {
            let mut init = C2RustUnnamed {
                number: b"2 \0" as *const u8 as *const libc::c_char,
                faultCategory: b"\xE9\xA9\xBB\xE6\xB3\xA2\xE6\xAF\x94\xE5\xA4\x96\xE9\x83\xA8\xE5\xA4\xB1\xE6\x95\x88\0"
                    as *const u8 as *const libc::c_char,
                paraInfo: b"\xE5\xA4\xA9\xE7\xBA\xBF\xE5\x8F\xB7      \0" as *const u8
                    as *const libc::c_char,
                paraDesc: b"\xE4\xBB\x8E1\xE5\xBC\x80\xE5\xA7\x8B\0" as *const u8
                    as *const libc::c_char,
                minVal: 1 as libc::c_int as UINT32,
                pGetDevNumFunc: Some(BspGetAntNum as unsafe extern "C" fn() -> UINT32),
            };
            init
        },
        {
            let mut init = C2RustUnnamed {
                number: b"3 \0" as *const u8 as *const libc::c_char,
                faultCategory: b"\xE9\x80\x9A\xE9\x81\x93PA\xE5\xA4\xB1\xE6\x95\x88    \0"
                    as *const u8 as *const libc::c_char,
                paraInfo: b"\xE9\x80\x9A\xE9\x81\x93\xE5\x8F\xB7      \0" as *const u8
                    as *const libc::c_char,
                paraDesc: b"\xE4\xBB\x8E0\xE5\xBC\x80\xE5\xA7\x8B\0" as *const u8
                    as *const libc::c_char,
                minVal: 0 as libc::c_int as UINT32,
                pGetDevNumFunc: Some(BspGetTxChannel as unsafe extern "C" fn() -> UINT32),
            };
            init
        },
        {
            let mut init = C2RustUnnamed {
                number: b"4 \0" as *const u8 as *const libc::c_char,
                faultCategory: b"\xE9\x80\x9A\xE9\x81\x93VGA\xE5\xA4\xB1\xE6\x95\x88   \0"
                    as *const u8 as *const libc::c_char,
                paraInfo: b"\xE9\x80\x9A\xE9\x81\x93\xE5\x8F\xB7      \0" as *const u8
                    as *const libc::c_char,
                paraDesc: b"\xE4\xBB\x8E0\xE5\xBC\x80\xE5\xA7\x8B\0" as *const u8
                    as *const libc::c_char,
                minVal: 0 as libc::c_int as UINT32,
                pGetDevNumFunc: Some(BspGetTxChannel as unsafe extern "C" fn() -> UINT32),
            };
            init
        },
        {
            let mut init = C2RustUnnamed {
                number: b"5 \0" as *const u8 as *const libc::c_char,
                faultCategory: b"MTS\xE5\xA4\xB1\xE6\x95\x88       \0" as *const u8
                    as *const libc::c_char,
                paraInfo: b"\xE7\x89\x87\xE5\x8F\xB7        \0" as *const u8
                    as *const libc::c_char,
                paraDesc: b"\xE4\xBB\x8E0\xE5\xBC\x80\xE5\xA7\x8B\0" as *const u8
                    as *const libc::c_char,
                minVal: 0 as libc::c_int as UINT32,
                pGetDevNumFunc: Some(GetMtsNum as unsafe extern "C" fn() -> UINT32),
            };
            init
        },
        {
            let mut init = C2RustUnnamed {
                number: b"6 \0" as *const u8 as *const libc::c_char,
                faultCategory: b"DPDIC\xE5\xA4\xB1\xE6\x95\x88     \0" as *const u8
                    as *const libc::c_char,
                paraInfo: b"\xE7\x89\x87\xE5\x8F\xB7        \0" as *const u8
                    as *const libc::c_char,
                paraDesc: b"\xE4\xBB\x8E0\xE5\xBC\x80\xE5\xA7\x8B\0" as *const u8
                    as *const libc::c_char,
                minVal: 0 as libc::c_int as UINT32,
                pGetDevNumFunc: Some(GetDpdicNum as unsafe extern "C" fn() -> UINT32),
            };
            init
        },
        {
            let mut init = C2RustUnnamed {
                number: b"7 \0" as *const u8 as *const libc::c_char,
                faultCategory: b"FPGA\xE5\xA4\xB1\xE6\x95\x88      \0" as *const u8
                    as *const libc::c_char,
                paraInfo: b"\xE7\x89\x87\xE5\x8F\xB7        \0" as *const u8
                    as *const libc::c_char,
                paraDesc: b"\xE4\xBB\x8E0\xE5\xBC\x80\xE5\xA7\x8B\0" as *const u8
                    as *const libc::c_char,
                minVal: 0 as libc::c_int as UINT32,
                pGetDevNumFunc: Some(GetFpgaNum as unsafe extern "C" fn() -> UINT32),
            };
            init
        },
        {
            let mut init = C2RustUnnamed {
                number: b"8 \0" as *const u8 as *const libc::c_char,
                faultCategory: b"\xE7\x94\xB5\xE6\xBA\x9048V\xE5\xA4\xB1\xE6\x95\x88   \0"
                    as *const u8 as *const libc::c_char,
                paraInfo: b"\xE7\x94\xB5\xE6\xBA\x90\xE6\xA8\xA1\xE5\x9D\x97\xE7\xBC\x96\xE5\x8F\xB7\0"
                    as *const u8 as *const libc::c_char,
                paraDesc: b"\xE4\xBB\x8E0\xE5\xBC\x80\xE5\xA7\x8B\0" as *const u8
                    as *const libc::c_char,
                minVal: 0 as libc::c_int as UINT32,
                pGetDevNumFunc: Some(GetPwrModuleNum as unsafe extern "C" fn() -> UINT32),
            };
            init
        },
        {
            let mut init = C2RustUnnamed {
                number: b"9 \0" as *const u8 as *const libc::c_char,
                faultCategory: b"\xE7\x94\xB5\xE6\xBA\x905.6V\xE5\xA4\xB1\xE6\x95\x88  \0"
                    as *const u8 as *const libc::c_char,
                paraInfo: b"\xE7\x94\xB5\xE6\xBA\x90\xE6\xA8\xA1\xE5\x9D\x97\xE7\xBC\x96\xE5\x8F\xB7\0"
                    as *const u8 as *const libc::c_char,
                paraDesc: b"\xE4\xBB\x8E0\xE5\xBC\x80\xE5\xA7\x8B\0" as *const u8
                    as *const libc::c_char,
                minVal: 0 as libc::c_int as UINT32,
                pGetDevNumFunc: Some(GetPwrModuleNum as unsafe extern "C" fn() -> UINT32),
            };
            init
        },
        {
            let mut init = C2RustUnnamed {
                number: b"10\0" as *const u8 as *const libc::c_char,
                faultCategory: b"\xE7\x94\xB5\xE6\xBA\x90\xE6\xB8\xA9\xE5\xBA\xA6\xE5\xBC\x82\xE5\xB8\xB8  \0"
                    as *const u8 as *const libc::c_char,
                paraInfo: b"\xE7\x94\xB5\xE6\xBA\x90\xE6\xA8\xA1\xE5\x9D\x97\xE7\xBC\x96\xE5\x8F\xB7\0"
                    as *const u8 as *const libc::c_char,
                paraDesc: b"\xE4\xBB\x8E0\xE5\xBC\x80\xE5\xA7\x8B\0" as *const u8
                    as *const libc::c_char,
                minVal: 0 as libc::c_int as UINT32,
                pGetDevNumFunc: Some(GetPwrModuleNum as unsafe extern "C" fn() -> UINT32),
            };
            init
        },
        {
            let mut init = C2RustUnnamed {
                number: b"11\0" as *const u8 as *const libc::c_char,
                faultCategory: b"\xE5\x8D\x95\xE6\x9D\xBF\xE6\xB8\xA9\xE5\xBA\xA6\xE5\xBC\x82\xE5\xB8\xB8  \0"
                    as *const u8 as *const libc::c_char,
                paraInfo: b"\xE6\x97\xA0        \0" as *const u8 as *const libc::c_char,
                paraDesc: b"\0" as *const u8 as *const libc::c_char,
                minVal: 0 as libc::c_int as UINT32,
                pGetDevNumFunc: None,
            };
            init
        },
        {
            let mut init = C2RustUnnamed {
                number: b"12\0" as *const u8 as *const libc::c_char,
                faultCategory: b"PA\xE6\xB8\xA9\xE5\xBA\xA6\xE5\xBC\x82\xE5\xB8\xB8    \0"
                    as *const u8 as *const libc::c_char,
                paraInfo: b"\xE9\x80\x9A\xE9\x81\x93\xE5\x8F\xB7      \0" as *const u8
                    as *const libc::c_char,
                paraDesc: b"\xE4\xBB\x8E0\xE5\xBC\x80\xE5\xA7\x8B\0" as *const u8
                    as *const libc::c_char,
                minVal: 0 as libc::c_int as UINT32,
                pGetDevNumFunc: Some(BspGetTxChannel as unsafe extern "C" fn() -> UINT32),
            };
            init
        },
        {
            let mut init = C2RustUnnamed {
                number: b"13\0" as *const u8 as *const libc::c_char,
                faultCategory: b"\xE5\x85\x89\xE5\x8F\xA3\xE5\xA4\xB1\xE6\x95\x88      \0"
                    as *const u8 as *const libc::c_char,
                paraInfo: b"\xE5\x85\x89\xE5\x8F\xA3\xE5\x8F\xB7      \0" as *const u8
                    as *const libc::c_char,
                paraDesc: b"\xE4\xBB\x8E1\xE5\xBC\x80\xE5\xA7\x8B\0" as *const u8
                    as *const libc::c_char,
                minVal: 1 as libc::c_int as UINT32,
                pGetDevNumFunc: Some(BspGetOptNum as unsafe extern "C" fn() -> UINT32),
            };
            init
        },
    ]
};

#[unsafe(no_mangle)]
unsafe extern "C" fn BspGetTxChannel() -> UINT32 {
    return 8 as libc::c_int as UINT32;
}
#[unsafe(no_mangle)]
unsafe extern "C" fn BspGetAntNum() -> UINT32 {
    return 8 as libc::c_int as UINT32;
}
#[unsafe(no_mangle)]
unsafe extern "C" fn BspGetOptNum() -> UINT32 {
    return 2 as libc::c_int as UINT32;
}

#[unsafe(no_mangle)]
pub unsafe extern "C" fn BspSetFaultInfoPara(
    mut para: *mut T_FaultInfoLogPara,
) -> UINT32 {
    if para.is_null() {
        eprintln!("BspSetFaultInfoPara:Input Pointer is NULL!");
        return 0xff000002 as libc::c_uint;
    }
    s_faultInfoLogPara.mtsNum = (*para).mtsNum;
    s_faultInfoLogPara.dpdicNum = (*para).dpdicNum;
    s_faultInfoLogPara.fpgaNum = (*para).fpgaNum;
    s_faultInfoLogPara.pwrModuleNum = (*para).pwrModuleNum;
    return 0 as libc::c_int as UINT32;
}
#[unsafe(no_mangle)]
pub unsafe extern "C" fn GetMtsNum() -> UINT32 {
    return s_faultInfoLogPara.mtsNum;
}
#[unsafe(no_mangle)]
pub unsafe extern "C" fn GetDpdicNum() -> UINT32 {
    return s_faultInfoLogPara.dpdicNum;
}
#[unsafe(no_mangle)]
pub unsafe extern "C" fn GetFpgaNum() -> UINT32 {
    return s_faultInfoLogPara.fpgaNum;
}
#[unsafe(no_mangle)]
pub unsafe extern "C" fn GetPwrModuleNum() -> UINT32 {
    return s_faultInfoLogPara.pwrModuleNum;
}

#[unsafe(no_mangle)]
pub unsafe extern "C" fn WrToFaultInfoFile(
    mut faultIdx: UINT32,
    mut para: UINT32,
) -> UINT32 {
    let mut retVal: INT32 = 0 as libc::c_int as UINT32 as INT32;
    let mut fp: *mut FILE = 0 as *mut FILE;
    let mut timeRet: time_t = 0 as libc::c_int as time_t;
    let mut strTime: [CHAR; 32] = [0; 32];
    retVal = fopen_s(
        &mut fp,
        b"/ata/ntf/faultinfo.txt\0" as *const u8 as *const libc::c_char,
        b"a+\0" as *const u8 as *const libc::c_char,
    );
    if retVal != 0 as libc::c_int {
        eprintln!("WrToFaultInfoFile(102) warning! > fopen_s ret'{}!", retVal);
    }
    if fp.is_null() {
        BspChangeFilename(
            b"/ata/ntf/faultinfo.tmp\0" as *const u8 as *const libc::c_char,
            b"/ata/ntf/faultinfo.txt\0" as *const u8 as *const libc::c_char,
        );
        eprintln!("WrToFaultInfoFile: open file err! fp is null.");
        // return 0xffffffff as libc::c_uint;
    }
    timeRet = time(0 as *mut time_t);
    BspSecondToDate(
        strTime.as_mut_ptr(),
        ::core::mem::size_of::<[CHAR; 32]>() as libc::c_ulong as UINT32,
        timeRet as UINT32,
        0 as libc::c_int as UINT32,
    );
    let str_time_str = std::ffi::CStr::from_ptr(strTime.as_mut_ptr() as *const libc::c_char)
        .to_string_lossy();
    if para == 0x7fffffff as libc::c_int as UINT32 {
        let formatted = format!("{} 故障编号:{}\n", str_time_str, faultIdx);
        let c_str = std::ffi::CString::new(formatted).unwrap_or_else(|_| std::ffi::CString::new("").unwrap());
        let written = fwrite(
            c_str.as_ptr() as *const libc::c_void,
            1,
            c_str.as_bytes().len() as libc::c_ulong,
            fp,
        );
        retVal = if written == c_str.as_bytes().len() as libc::c_ulong {
            written as libc::c_int
        } else {
            -1
        };
    } else {
        let formatted = format!("{} 故障编号:{} 参数信息:{}\n", str_time_str, faultIdx, para);
        let c_str = std::ffi::CString::new(formatted).unwrap_or_else(|_| std::ffi::CString::new("").unwrap());
        let written = fwrite(
            c_str.as_ptr() as *const libc::c_void,
            1,
            c_str.as_bytes().len() as libc::c_ulong,
            fp,
        );
        retVal = if written == c_str.as_bytes().len() as libc::c_ulong {
            written as libc::c_int
        } else {
            -1
        };
    }
    if retVal < 0 as libc::c_int {
        eprintln!("WrToFaultInfoFile(120) warning! > fprintf ret'{}!", retVal);
    }
    retVal = fclose(fp);
    if retVal != 0 as libc::c_int {
        eprintln!("WrToFaultInfoFile(122) warning! > fclose ret'{}!", retVal);
    }
    return 0 as libc::c_int as UINT32;
}
#[unsafe(no_mangle)]
pub unsafe extern "C" fn AddFaultRecord(mut faultIdx: UINT32, mut para: UINT32) -> UINT32 {
    let mut retVal: UINT32 = 0 as libc::c_int as UINT32;
    let mut itemNum: UINT32 = 0 as libc::c_int as UINT32;
    let mut fileSize: UINT32 = 0 as libc::c_int as UINT32;
    let mut minParaVal: UINT32 = 0 as libc::c_int as UINT32;
    let mut deviceNum: UINT32 = 0 as libc::c_int as UINT32;
    let mut pGetDevNumFunc: BSP_GET_DEV_NUM = None;
    itemNum = (::core::mem::size_of::<[C2RustUnnamed; 13]>() as libc::c_ulong)
        .wrapping_div(::core::mem::size_of::<C2RustUnnamed>() as libc::c_ulong)
        as UINT32;
    if faultIdx < 1 as libc::c_int as libc::c_uint || faultIdx > itemNum {
        eprintln!("fault index: {} is out of range!", faultIdx);
        eprintln!("fault index should be: [1, {}]", itemNum);
        return 0xffffffff as libc::c_uint;
    }
    minParaVal = faultTable[faultIdx.wrapping_sub(1 as libc::c_int as libc::c_uint)
            as usize]
        .minVal;
    pGetDevNumFunc = faultTable[faultIdx.wrapping_sub(1 as libc::c_int as libc::c_uint)
            as usize]
        .pGetDevNumFunc;
    if pGetDevNumFunc.is_some() {
        deviceNum = pGetDevNumFunc.expect("non-null function pointer")();
        if para < minParaVal || para >= deviceNum.wrapping_add(minParaVal) {
            if deviceNum < 1 as libc::c_int as libc::c_uint {
                eprintln!("Not support this device!");
            } else {
                eprintln!("Para: {} is not support!", para);
                eprintln!("Para should be [{}, {}]", 
                    minParaVal,
                    deviceNum
                        .wrapping_add(minParaVal)
                        .wrapping_sub(1 as libc::c_int as libc::c_uint));
            }
            return 0xffffffff as libc::c_uint;
        }
    } else {
        para = 0x7fffffff as libc::c_int as UINT32;
    }
    if BspCreateFolder(b"/ata/ntf\0" as *const u8 as *const libc::c_char)
        != 0 as libc::c_int as UINT32
    {
        return 0xffffffff as libc::c_uint;
    }
    fileSize = BspGetFileLen(
        b"/ata/ntf/faultinfo.txt\0" as *const u8 as *const libc::c_char,
    );
    if fileSize != 0xffffffff as libc::c_uint
        && fileSize >= (16 as libc::c_int * 1024 as libc::c_int) as libc::c_uint
    {
        BspChangeFilename(
            b"/ata/ntf/faultinfo.txt\0" as *const u8 as *const libc::c_char,
            b"/ata/ntf/faultinfo.tmp\0" as *const u8 as *const libc::c_char,
        );
        retVal = WrToFaultInfoFile(faultIdx, para);
        BspChangeFilename(
            b"/ata/ntf/faultinfo.tmp\0" as *const u8 as *const libc::c_char,
            b"/ata/ntf/faultinfo.bak\0" as *const u8 as *const libc::c_char,
        );
    } else {
        retVal = WrToFaultInfoFile(faultIdx, para);
    }
    return retVal;
}
#[unsafe(no_mangle)]
pub unsafe extern "C" fn DeleteFaultRecord() -> UINT32 {
    let mut fp: *mut FILE = 0 as *mut FILE;
    let mut fpTmp: *mut FILE = 0 as *mut FILE;
    let mut retVal: INT32 = 0 as libc::c_int as UINT32 as INT32;
    let mut fileLen: UINT32 = 0 as libc::c_int as UINT32;
    let mut buffer: [CHAR; 128] = [0; 128];
    if BspIsFileExist(b"/ata/ntf/faultinfo.txt\0" as *const u8 as *const libc::c_char)
        != 0 as libc::c_int as UINT32
    {
        if BspIsFileExist(
            b"/ata/ntf/faultinfo.bak\0" as *const u8 as *const libc::c_char,
        ) != 0 as libc::c_int as UINT32
        {
            return 0 as libc::c_int as UINT32
        } else {
            BspChangeFilename(
                b"/ata/ntf/faultinfo.bak\0" as *const u8 as *const libc::c_char,
                b"/ata/ntf/faultinfo.txt\0" as *const u8 as *const libc::c_char,
            );
        }
    }
    if BspGetFileLen(b"/ata/ntf/faultinfo.txt\0" as *const u8 as *const libc::c_char)
        == 0 as libc::c_int as libc::c_uint
    {
        BspChangeFilename(
            b"/ata/ntf/faultinfo.bak\0" as *const u8 as *const libc::c_char,
            b"/ata/ntf/faultinfo.txt\0" as *const u8 as *const libc::c_char,
        );
    }
    retVal = fopen_s(
        &mut fp,
        b"/ata/ntf/faultinfo.txt\0" as *const u8 as *const libc::c_char,
        b"r\0" as *const u8 as *const libc::c_char,
    );
    if retVal != 0 as libc::c_int {
        eprintln!("DeleteFaultRecord(215) warning! > fopen_s ret'{}!", retVal);
    }
    if fp.is_null() {
        eprintln!("DeleteFaultRecord: open file:/ata/ntf/faultinfo.txt err!");
        // return 0xffffffff as libc::c_uint;
    }
    retVal = fopen_s(
        &mut fpTmp,
        b"/ata/ntf/faultinfo.tmp\0" as *const u8 as *const libc::c_char,
        b"w\0" as *const u8 as *const libc::c_char,
    );
    if retVal != 0 as libc::c_int {
        eprintln!("DeleteFaultRecord(222) warning! > fopen_s ret'{}!", retVal);
    }
    if fpTmp.is_null() {
        retVal = fclose(fp);
        if retVal != 0 as libc::c_int {
            eprintln!("DeleteFaultRecord(226) warning! > fclose ret'{}!", retVal);
        }
        eprintln!("DeleteFaultRecord: open file:/ata/ntf/faultinfo.tmp err!");
        // return 0xffffffff as libc::c_uint;
    }
    fileLen = BspGetFileLen(
        b"/ata/ntf/faultinfo.txt\0" as *const u8 as *const libc::c_char,
    );
    // while ftell(fp) < fileLen as libc::c_long {
        retVal = zte_fgets_s(
            buffer.as_mut_ptr(),
            ::core::mem::size_of::<[CHAR; 128]>() as libc::c_ulong,
            ::core::mem::size_of::<[CHAR; 128]>() as libc::c_ulong,
            fp,
        );
        if ftell(fp) >= fileLen as libc::c_long {
            // break;
        }
        if retVal as libc::c_uint == 0 as libc::c_int as UINT32 {
            let buffer_str = std::ffi::CStr::from_ptr(buffer.as_mut_ptr() as *const libc::c_char)
                .to_string_lossy();
            let c_str = std::ffi::CString::new(buffer_str.as_ref()).unwrap_or_else(|_| std::ffi::CString::new("").unwrap());
            let written = fwrite(
                c_str.as_ptr() as *const libc::c_void,
                1,
                c_str.as_bytes().len() as libc::c_ulong,
                fpTmp,
            );
            retVal = if written == c_str.as_bytes().len() as libc::c_ulong {
                written as libc::c_int
            } else {
                -1
            };
            if retVal < 0 as libc::c_int {
                eprintln!("DeleteFaultRecord(242) warning! > fprintf ret'{}!", retVal);
            }
        }
    // }
    retVal = fclose(fp);
    if retVal != 0 as libc::c_int {
        eprintln!("DeleteFaultRecord(247) warning! > fclose ret'{}!", retVal);
    }
    retVal = fclose(fpTmp);
    if retVal != 0 as libc::c_int {
        eprintln!("DeleteFaultRecord(249) warning! > fclose ret'{}!", retVal);
    }
    BspChangeFilename(
        b"/ata/ntf/faultinfo.tmp\0" as *const u8 as *const libc::c_char,
        b"/ata/ntf/faultinfo.txt\0" as *const u8 as *const libc::c_char,
    );
    return 0 as libc::c_int as UINT32;
}
#[unsafe(no_mangle)]
pub unsafe extern "C" fn PrnFaultFile(mut filePath: *const libc::c_char) -> UINT32 {
    let mut buffer: [CHAR; 128] = [0; 128];
    let mut fp: *mut FILE = 0 as *mut FILE;
    let mut retVal: INT32 = 0 as libc::c_int;
    if filePath.is_null() {
        eprintln!("PrnFaultFile: filePath is null!");
        return 0xffffffff as libc::c_uint;
    }
    retVal = fopen_s(&mut fp, filePath, b"r\0" as *const u8 as *const libc::c_char);
    if retVal != 0 as libc::c_int {
        eprintln!("PrnFaultFile(263) warning! > fopen_s ret'{}!", retVal);
    }
    if fp.is_null() {
        let file_path_str = std::ffi::CStr::from_ptr(filePath).to_string_lossy();
        eprintln!("PrnFaultFile: open file:{} err!", file_path_str);
        // return 0xffffffff as libc::c_uint;
    }
    while zte_fgets_s(
        buffer.as_mut_ptr(),
        ::core::mem::size_of::<[CHAR; 128]>() as libc::c_ulong,
        ::core::mem::size_of::<[CHAR; 128]>() as libc::c_ulong,
        fp,
    ) as libc::c_uint == 0 as libc::c_int as UINT32
    {
        let buffer_str = std::ffi::CStr::from_ptr(buffer.as_mut_ptr() as *const libc::c_char)
            .to_string_lossy();
        eprintln!("{}", buffer_str);
    }
    retVal = fclose(fp);
    if retVal != 0 as libc::c_int {
        eprintln!("PrnFaultFile(276) warning! > fclose ret'{}!", retVal);
    }
    return 0 as libc::c_int as UINT32;
}
#[unsafe(no_mangle)]
pub unsafe extern "C" fn QueryFaultRecord() -> UINT32 {
    if BspIsFileExist(b"/ata/ntf/faultinfo.bak\0" as *const u8 as *const libc::c_char) == 0 
    {
        PrnFaultFile(b"/ata/ntf/faultinfo.bak\0" as *const u8 as *const libc::c_char);
    }
    if BspIsFileExist(b"/ata/ntf/faultinfo.txt\0" as *const u8 as *const libc::c_char) == 0 as libc::c_int as UINT32
    {
        PrnFaultFile(b"/ata/ntf/faultinfo.txt\0" as *const u8 as *const libc::c_char);
    }
    return 0 as libc::c_int as UINT32;
}
#[unsafe(no_mangle)]
pub unsafe extern "C" fn PrnFaultHelp() -> UINT32 {
    let mut loop_0: UINT32 = 0 as libc::c_int as UINT32;
    let mut itemNum: UINT32 = (::core::mem::size_of::<[C2RustUnnamed; 13]>()
        as libc::c_ulong)
        .wrapping_div(::core::mem::size_of::<C2RustUnnamed>() as libc::c_ulong)
        as UINT32;
    eprintln!("\n============ faultinfo usage ============");
    eprintln!("记录故障:          faultinfo 1,故障编号,参数信息");
    eprintln!("删除最近一条记录:  faultinfo 2");
    eprintln!("查询所有记录:      faultinfo 3\n");
    eprintln!("================ Table of fault info ================");
    eprintln!("故障编号   故障类别         参数信息          参数说明");
    loop_0 = 0 as libc::c_int as UINT32;
    while loop_0 < itemNum {
        let number_str = std::ffi::CStr::from_ptr(faultTable[loop_0 as usize].number)
            .to_string_lossy();
        let category_str = std::ffi::CStr::from_ptr(faultTable[loop_0 as usize].faultCategory)
            .to_string_lossy();
        let para_info_str = std::ffi::CStr::from_ptr(faultTable[loop_0 as usize].paraInfo)
            .to_string_lossy();
        let para_desc_str = std::ffi::CStr::from_ptr(faultTable[loop_0 as usize].paraDesc)
            .to_string_lossy();
        eprintln!("{}        {}    {}      {}", number_str, category_str, para_info_str, para_desc_str);
        loop_0 = loop_0.wrapping_add(1);
        loop_0;
    }
    return 0 as libc::c_int as UINT32;
}
#[unsafe(no_mangle)]
pub unsafe extern "C" fn faultinfo(
    mut cmdType: UINT32,
    mut faultIdx: UINT32,
    mut para: UINT32,
) -> UINT32 {
    if BspIsFileExist(b"/ata/ntf/faultinfo.txt\0" as *const u8 as *const libc::c_char)
        != 0 as libc::c_int as UINT32
        && BspIsFileExist(
            b"/ata/ntf/faultinfo.tmp\0" as *const u8 as *const libc::c_char,
        ) == 0 as libc::c_int as UINT32
    {
        BspChangeFilename(
            b"/ata/ntf/faultinfo.tmp\0" as *const u8 as *const libc::c_char,
            b"/ata/ntf/faultinfo.txt\0" as *const u8 as *const libc::c_char,
        );
    }
    match cmdType {
        0 => return PrnFaultHelp(),
        1 => return AddFaultRecord(faultIdx, para),
        2 => return DeleteFaultRecord(),
        3 => return QueryFaultRecord(),
        _ => {
            eprintln!("The first parameter is invalid!");
            eprintln!("Command type should be: 0-Help, 1-Add, 2-Delete, 3-Query.");
            return 0xffffffff as libc::c_uint;
        }
    };
}

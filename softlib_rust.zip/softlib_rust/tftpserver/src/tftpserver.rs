/* Started by AICoder, pid:z690dtea69u4588140640a1d24c971907431cd14 */
#![allow(
    dead_code,
    mutable_transmutes,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    unused_assignments,
    unused_mut
)]

// 声明安全 Rust 实现模块
// pub mod tftpserver_safe;  // 暂时注释掉，如果不需要可以删除

unsafe extern "C" {
    fn fclose(__stream: *mut FILE) -> libc::c_int;
    fn fopen(_: *const libc::c_char, _: *const libc::c_char) -> *mut FILE;
    fn printf(_: *const libc::c_char, _: ...) -> libc::c_int;
    fn fread(
        _: *mut libc::c_void,
        _: libc::c_ulong,
        _: libc::c_ulong,
        _: *mut FILE,
    ) -> libc::c_ulong;
    fn fwrite(
        _: *const libc::c_void,
        _: libc::c_ulong,
        _: libc::c_ulong,
        _: *mut FILE,
    ) -> libc::c_ulong;
    fn atoi(__nptr: *const libc::c_char) -> libc::c_int;
    fn malloc(_: libc::c_ulong) -> *mut libc::c_void;
    fn free(__ptr: *mut libc::c_void);
    fn select(
        __nfds: libc::c_int,
        __readfds: *mut fd_set,
        __writefds: *mut fd_set,
        __exceptfds: *mut fd_set,
        __timeout: *mut timeval,
    ) -> libc::c_int;
    fn __errno_location() -> *mut libc::c_int;
    fn ioctl(__fd: libc::c_int, __request: libc::c_ulong, _: ...) -> libc::c_int;
    fn socket(
        __domain: libc::c_int,
        __type: libc::c_int,
        __protocol: libc::c_int,
    ) -> libc::c_int;
    fn bind(
        __fd: libc::c_int,
        __addr: __CONST_SOCKADDR_ARG,
        __len: socklen_t,
    ) -> libc::c_int;
    fn sendto(
        __fd: libc::c_int,
        __buf: *const libc::c_void,
        __n: size_t,
        __flags: libc::c_int,
        __addr: __CONST_SOCKADDR_ARG,
        __addr_len: socklen_t,
    ) -> ssize_t;
    fn recvfrom(
        __fd: libc::c_int,
        __buf: *mut libc::c_void,
        __n: size_t,
        __flags: libc::c_int,
        __addr: __SOCKADDR_ARG,
        __addr_len: *mut socklen_t,
    ) -> ssize_t;
    fn setsockopt(
        __fd: libc::c_int,
        __level: libc::c_int,
        __optname: libc::c_int,
        __optval: *const libc::c_void,
        __optlen: socklen_t,
    ) -> libc::c_int;
    fn ntohs(__netshort: uint16_t) -> uint16_t;
    fn htonl(__hostlong: uint32_t) -> uint32_t;
    fn htons(__hostshort: uint16_t) -> uint16_t;
    fn inet_ntoa(__in: in_addr) -> *mut libc::c_char;
    fn pthread_create(
        __newthread: *mut pthread_t,
        __attr: *const pthread_attr_t,
        __start_routine: Option::<
            unsafe extern "C" fn(*mut libc::c_void) -> *mut libc::c_void,
        >,
        __arg: *mut libc::c_void,
    ) -> libc::c_int;
    fn pthread_detach(__th: pthread_t) -> libc::c_int;
    fn pthread_self() -> pthread_t;
    fn pthread_mutex_init(
        __mutex: *mut pthread_mutex_t,
        __mutexattr: *const pthread_mutexattr_t,
    ) -> libc::c_int;
    fn pthread_mutex_lock(__mutex: *mut pthread_mutex_t) -> libc::c_int;
    fn pthread_mutex_unlock(__mutex: *mut pthread_mutex_t) -> libc::c_int;
    fn strncmp(
        _: *const libc::c_char,
        _: *const libc::c_char,
        _: libc::c_ulong,
    ) -> libc::c_int;
    fn strlen(_: *const libc::c_char) -> libc::c_ulong;
    fn strerror(_: libc::c_int) -> *mut libc::c_char;
    fn close(__fd: libc::c_int) -> libc::c_int;
    fn sleep(__seconds: libc::c_uint) -> libc::c_uint;
    fn zte_printf_s(format: *const libc::c_char, _: ...) -> libc::c_int;
    fn encapsulationOfZte_memcpy_s(
        s1: *mut libc::c_void,
        s1max: rsize_t,
        s2: *const libc::c_void,
        n: rsize_t,
        fileName: *const libc::c_char,
        lineNo: libc::c_int,
    ) -> libc::c_int;
    fn encapsulationOfZte_memset_s(
        s: *mut libc::c_void,
        smax: rsize_t,
        c: libc::c_int,
        n: rsize_t,
        fileName: *const libc::c_char,
        lineNo: libc::c_int,
    ) -> libc::c_int;
    fn encapsulationOfZte_strnlen_s(
        s: *const libc::c_char,
        maxsize: rsize_t,
        fileName: *const libc::c_char,
        lineNo: libc::c_int,
    ) -> libc::c_int;
    fn encapsulationOfZte_strncpy_s(
        s1: *mut libc::c_char,
        s1max: rsize_t,
        s2: *const libc::c_char,
        n: rsize_t,
        fileName: *const libc::c_char,
        lineNo: libc::c_int,
    ) -> libc::c_int;
    fn encapsulationOfZte_strncat_s(
        s1: *mut libc::c_char,
        s1max: rsize_t,
        s2: *const libc::c_char,
        n: rsize_t,
        fileName: *const libc::c_char,
        lineNo: libc::c_int,
    ) -> libc::c_int;
    fn snprintf_s(
        s: *mut libc::c_char,
        n: rsize_t,
        format: *const libc::c_char,
        _: ...
    ) -> libc::c_int;
    fn mzprnL(
        ulModuleNo: libc::c_ulong,
        ulLevel: libc::c_ulong,
        pbFmt: *const libc::c_char,
        _: ...
    ) -> libc::c_int;
    fn BspMkdir(path: *const libc::c_char) -> ULONG;
}
pub type size_t = libc::c_ulong;
pub type __uint8_t = libc::c_uchar;
pub type __uint16_t = libc::c_ushort;
pub type __uint32_t = libc::c_uint;
pub type __off_t = libc::c_long;
pub type __off64_t = libc::c_long;
pub type __time_t = libc::c_long;
pub type __suseconds_t = libc::c_long;
pub type __ssize_t = libc::c_long;
pub type __socklen_t = libc::c_uint;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct _IO_FILE {
    pub _flags: libc::c_int,
    pub _IO_read_ptr: *mut libc::c_char,
    pub _IO_read_end: *mut libc::c_char,
    pub _IO_read_base: *mut libc::c_char,
    pub _IO_write_base: *mut libc::c_char,
    pub _IO_write_ptr: *mut libc::c_char,
    pub _IO_write_end: *mut libc::c_char,
    pub _IO_buf_base: *mut libc::c_char,
    pub _IO_buf_end: *mut libc::c_char,
    pub _IO_save_base: *mut libc::c_char,
    pub _IO_backup_base: *mut libc::c_char,
    pub _IO_save_end: *mut libc::c_char,
    //pub _markers: *mut _IO_marker,
    pub _chain: *mut _IO_FILE,
    pub _fileno: libc::c_int,
    pub _flags2: libc::c_int,
    pub _old_offset: __off_t,
    pub _cur_column: libc::c_ushort,
    pub _vtable_offset: libc::c_schar,
    pub _shortbuf: [libc::c_char; 1],
    pub _lock: *mut libc::c_void,
    pub _offset: __off64_t,
    //pub _codecvt: *mut _IO_codecvt,
    //pub _wide_data: *mut _IO_wide_data,
    pub _freeres_list: *mut _IO_FILE,
    pub _freeres_buf: *mut libc::c_void,
    pub __pad5: size_t,
    pub _mode: libc::c_int,
    pub _unused2: [libc::c_char; 20],
}
pub type _IO_lock_t = ();
pub type FILE = _IO_FILE;
pub type ssize_t = __ssize_t;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct timeval {
    pub tv_sec: __time_t,
    pub tv_usec: __suseconds_t,
}
pub type __fd_mask = libc::c_long;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct fd_set {
    pub fds_bits: [__fd_mask; 16],
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct __pthread_internal_list {
    pub __prev: *mut __pthread_internal_list,
    pub __next: *mut __pthread_internal_list,
}
pub type __pthread_list_t = __pthread_internal_list;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct __pthread_mutex_s {
    pub __lock: libc::c_int,
    pub __count: libc::c_uint,
    pub __owner: libc::c_int,
    pub __nusers: libc::c_uint,
    pub __kind: libc::c_int,
    pub __spins: libc::c_short,
    pub __elision: libc::c_short,
    pub __list: __pthread_list_t,
}
pub type pthread_t = libc::c_ulong;
#[derive(Copy, Clone)]
#[repr(C)]
pub union pthread_mutexattr_t {
    pub __size: [libc::c_char; 4],
    pub __align: libc::c_int,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub union pthread_attr_t {
    pub __size: [libc::c_char; 56],
    pub __align: libc::c_long,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub union pthread_mutex_t {
    pub __data: __pthread_mutex_s,
    pub __size: [libc::c_char; 40],
    pub __align: libc::c_long,
}
pub type uint8_t = __uint8_t;
pub type uint16_t = __uint16_t;
pub type uint32_t = __uint32_t;
pub type socklen_t = __socklen_t;
pub type __socket_type = libc::c_uint;
pub const SOCK_NONBLOCK: __socket_type = 2048;
pub const SOCK_CLOEXEC: __socket_type = 524288;
pub const SOCK_PACKET: __socket_type = 10;
pub const SOCK_DCCP: __socket_type = 6;
pub const SOCK_SEQPACKET: __socket_type = 5;
pub const SOCK_RDM: __socket_type = 4;
pub const SOCK_RAW: __socket_type = 3;
pub const SOCK_DGRAM: __socket_type = 2;
pub const SOCK_STREAM: __socket_type = 1;
pub type sa_family_t = libc::c_ushort;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct sockaddr {
    pub sa_family: sa_family_t,
    pub sa_data: [libc::c_char; 14],
}
#[derive(Copy, Clone)]
#[repr(C)]
pub union __SOCKADDR_ARG {
    pub __sockaddr__: *mut sockaddr,
    //pub __sockaddr_at__: *mut sockaddr_at,
    //pub __sockaddr_ax25__: *mut sockaddr_ax25,
    //pub __sockaddr_dl__: *mut sockaddr_dl,
    //pub __sockaddr_eon__: *mut sockaddr_eon,
    pub __sockaddr_in__: *mut sockaddr_in,
    pub __sockaddr_in6__: *mut sockaddr_in6,
    //pub __sockaddr_inarp__: *mut sockaddr_inarp,
    //pub __sockaddr_ipx__: *mut sockaddr_ipx,
    //pub __sockaddr_iso__: *mut sockaddr_iso,
    //pub __sockaddr_ns__: *mut sockaddr_ns,
    //pub __sockaddr_un__: *mut sockaddr_un,
    //pub __sockaddr_x25__: *mut sockaddr_x25,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct sockaddr_in6 {
    pub sin6_family: sa_family_t,
    pub sin6_port: in_port_t,
    pub sin6_flowinfo: uint32_t,
    pub sin6_addr: in6_addr,
    pub sin6_scope_id: uint32_t,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct in6_addr {
    pub __in6_u: C2RustUnnamed,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub union C2RustUnnamed {
    pub __u6_addr8: [uint8_t; 16],
    pub __u6_addr16: [uint16_t; 8],
    pub __u6_addr32: [uint32_t; 4],
}
pub type in_port_t = uint16_t;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct sockaddr_in {
    pub sin_family: sa_family_t,
    pub sin_port: in_port_t,
    pub sin_addr: in_addr,
    pub sin_zero: [libc::c_uchar; 8],
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct in_addr {
    pub s_addr: in_addr_t,
}
pub type in_addr_t = uint32_t;
#[derive(Copy, Clone)]
#[repr(C)]
pub union __CONST_SOCKADDR_ARG {
    pub __sockaddr__: *const sockaddr,
    //pub __sockaddr_at__: *const sockaddr_at,
    //pub __sockaddr_ax25__: *const sockaddr_ax25,
    //pub __sockaddr_dl__: *const sockaddr_dl,
    //pub __sockaddr_eon__: *const sockaddr_eon,
    pub __sockaddr_in__: *const sockaddr_in,
    pub __sockaddr_in6__: *const sockaddr_in6,
    //pub __sockaddr_inarp__: *const sockaddr_inarp,
    //pub __sockaddr_ipx__: *const sockaddr_ipx,
    //pub __sockaddr_iso__: *const sockaddr_iso,
    //pub __sockaddr_ns__: *const sockaddr_ns,
    //pub __sockaddr_un__: *const sockaddr_un,
    //pub __sockaddr_x25__: *const sockaddr_x25,
}
pub type C2RustUnnamed_0 = libc::c_uint;
pub const IPPROTO_MAX: C2RustUnnamed_0 = 256;
pub const IPPROTO_RAW: C2RustUnnamed_0 = 255;
pub const IPPROTO_MPLS: C2RustUnnamed_0 = 137;
pub const IPPROTO_UDPLITE: C2RustUnnamed_0 = 136;
pub const IPPROTO_SCTP: C2RustUnnamed_0 = 132;
pub const IPPROTO_COMP: C2RustUnnamed_0 = 108;
pub const IPPROTO_PIM: C2RustUnnamed_0 = 103;
pub const IPPROTO_ENCAP: C2RustUnnamed_0 = 98;
pub const IPPROTO_BEETPH: C2RustUnnamed_0 = 94;
pub const IPPROTO_MTP: C2RustUnnamed_0 = 92;
pub const IPPROTO_AH: C2RustUnnamed_0 = 51;
pub const IPPROTO_ESP: C2RustUnnamed_0 = 50;
pub const IPPROTO_GRE: C2RustUnnamed_0 = 47;
pub const IPPROTO_RSVP: C2RustUnnamed_0 = 46;
pub const IPPROTO_IPV6: C2RustUnnamed_0 = 41;
pub const IPPROTO_DCCP: C2RustUnnamed_0 = 33;
pub const IPPROTO_TP: C2RustUnnamed_0 = 29;
pub const IPPROTO_IDP: C2RustUnnamed_0 = 22;
pub const IPPROTO_UDP: C2RustUnnamed_0 = 17;
pub const IPPROTO_PUP: C2RustUnnamed_0 = 12;
pub const IPPROTO_EGP: C2RustUnnamed_0 = 8;
pub const IPPROTO_TCP: C2RustUnnamed_0 = 6;
pub const IPPROTO_IPIP: C2RustUnnamed_0 = 4;
pub const IPPROTO_IGMP: C2RustUnnamed_0 = 2;
pub const IPPROTO_ICMP: C2RustUnnamed_0 = 1;
pub const IPPROTO_IP: C2RustUnnamed_0 = 0;
pub type CHAR = libc::c_char;
pub type ULONG = libc::c_uint;
pub type UINT32 = libc::c_uint;
pub type INT32 = libc::c_int;
pub type FUNCPTR = Option::<unsafe extern "C" fn() -> libc::c_int>;
pub type rsize_t = size_t;
pub type FUNC_TFTP_LOG = Option::<
    unsafe extern "C" fn(UINT32, *const CHAR, ...) -> INT32,
>;
pub type OSS_INT = libc::c_int;
pub type OSS_VOID = ();
pub type OSS_WORD16 = libc::c_ushort;
pub type OSS_BYTE = libc::c_uchar;
pub type OSS_WORD32 = libc::c_uint;
pub type OSS_BOOL = libc::c_uint;
pub type SOCKADDR_IN = sockaddr_in;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct reqReci {
    pub fifo_thread: pthread_t,
    pub clientIp: OSS_WORD32,
    pub clientPort: OSS_WORD32,
    pub clientBlkSize: OSS_WORD32,
    pub byMode: [OSS_CHAR; 12],
    pub revFileName: [OSS_CHAR; 255],
    pub reqClient: sockaddr_in,
}
pub type OSS_CHAR = libc::c_char;
pub type OSS_SWORD32 = libc::c_int;
pub type SOCKADDR = sockaddr_in;
pub type SOCKET_SET = fd_set;
#[unsafe(no_mangle)]
pub static mut RespondClientState: [[OSS_BYTE; 60]; 9] = unsafe {
    [
        *::core::mem::transmute::<
            &[u8; 60],
            &mut [OSS_BYTE; 60],
        >(
            b"0 Don't receive any request.\n\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0",
        ),
        *::core::mem::transmute::<
            &[u8; 60],
            &mut [OSS_BYTE; 60],
        >(
            b"1 Get a request.\n\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0",
        ),
        *::core::mem::transmute::<
            &[u8; 60],
            &mut [OSS_BYTE; 60],
        >(
            b"2 Start to transmit ...\n\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0",
        ),
        *::core::mem::transmute::<
            &[u8; 60],
            &mut [OSS_BYTE; 60],
        >(
            b"3 Transmitting ...\n\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0",
        ),
        *::core::mem::transmute::<
            &[u8; 60],
            &mut [OSS_BYTE; 60],
        >(b"4 No responses for last package transmission, time out.\n\0\0\0\0"),
        *::core::mem::transmute::<
            &[u8; 60],
            &mut [OSS_BYTE; 60],
        >(b"5 Get responses for last package transmission.\n\0\0\0\0\0\0\0\0\0\0\0\0\0"),
        *::core::mem::transmute::<
            &[u8; 60],
            &mut [OSS_BYTE; 60],
        >(b"6 Retransmit package but still no responses, time out.\n\0\0\0\0\0"),
        *::core::mem::transmute::<
            &[u8; 60],
            &mut [OSS_BYTE; 60],
        >(
            b"7 Send last package success.\n\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0",
        ),
        *::core::mem::transmute::<
            &[u8; 60],
            &mut [OSS_BYTE; 60],
        >(
            b"8 Transmission all Done.\n\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0",
        ),
    ]
};
#[unsafe(no_mangle)]
pub static mut gRecordStru: reqReci = reqReci {
    fifo_thread: 0,
    clientIp: 0,
    clientPort: 0,
    clientBlkSize: 0,
    byMode: [0; 12],
    revFileName: [0; 255],
    reqClient: sockaddr_in {
        sin_family: 0,
        sin_port: 0,
        sin_addr: in_addr { s_addr: 0 },
        sin_zero: [0; 8],
    },
};
#[unsafe(no_mangle)]
pub static mut s_ulTftpServerTestExitFlag: UINT32 = 0 as libc::c_int as UINT32;
#[unsafe(no_mangle)]
pub static mut pTftpLogFunc: FUNC_TFTP_LOG = None;
#[unsafe(no_mangle)]
pub static mut gdwTftpSvrDebug: OSS_WORD32 = 0 as libc::c_int as OSS_WORD32;
#[unsafe(no_mangle)]
pub static mut gbyDelayMS: OSS_BYTE = 1 as libc::c_int as OSS_BYTE;
#[unsafe(no_mangle)]
pub static mut ReqReciveBox: [reqReci; 255] = [reqReci {
    fifo_thread: 0,
    clientIp: 0,
    clientPort: 0,
    clientBlkSize: 0,
    byMode: [0; 12],
    revFileName: [0; 255],
    reqClient: sockaddr_in {
        sin_family: 0,
        sin_port: 0,
        sin_addr: in_addr { s_addr: 0 },
        sin_zero: [0; 8],
    },
}; 255];
#[unsafe(no_mangle)]
pub static mut sendBox: [reqReci; 255] = [reqReci {
    fifo_thread: 0,
    clientIp: 0,
    clientPort: 0,
    clientBlkSize: 0,
    byMode: [0; 12],
    revFileName: [0; 255],
    reqClient: sockaddr_in {
        sin_family: 0,
        sin_port: 0,
        sin_addr: in_addr { s_addr: 0 },
        sin_zero: [0; 8],
    },
}; 255];

#[unsafe(no_mangle)]
pub static mut TftpServerPath: [OSS_CHAR; 25] = unsafe {
    *::core::mem::transmute::<
        &[u8; 25],
        &mut [OSS_CHAR; 25],
    >(b"/\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0")
};
#[unsafe(export_name = "mut")]
pub static mut mut_0: pthread_mutex_t = pthread_mutex_t {
    __data: __pthread_mutex_s {
        __lock: 0,
        __count: 0,
        __owner: 0,
        __nusers: 0,
        __kind: 0,
        __spins: 0,
        __elision: 0,
        __list: __pthread_list_t {
            __prev: 0 as *const __pthread_internal_list as *mut __pthread_internal_list,
            __next: 0 as *const __pthread_internal_list as *mut __pthread_internal_list,
        },
    },
};
#[unsafe(no_mangle)]
pub static mut tftp_thread: pthread_t = 0;
#[unsafe(no_mangle)]
pub static mut num_thread: OSS_WORD16 = 0 as libc::c_int as OSS_WORD16;
#[unsafe(no_mangle)]
pub unsafe extern "C" fn BspTftpLogCallBackInit(mut pLog: FUNC_TFTP_LOG) {
    unsafe {
        pTftpLogFunc = pLog;
    }
}
#[unsafe(no_mangle)]
pub unsafe extern "C" fn TftpGetFileNameAndModeAndOpt(
    mut pbyBuf: *mut OSS_BYTE,
    mut pbyFilename: *mut OSS_BYTE,
    mut pbyMode: *mut OSS_BYTE,
    mut opt1: *mut OSS_BYTE,
    mut blksize: *mut OSS_WORD16,
) -> OSS_BOOL {
    unsafe {
        // 添加空指针检查，防止段错误
        if pbyBuf.is_null() || pbyFilename.is_null() || pbyMode.is_null() || opt1.is_null() || blksize.is_null() {
            zte_printf_s(b"Input err points.\n\0" as *const u8 as *const libc::c_char);
            return 0 as libc::c_int as OSS_BOOL;
        }
        // 添加边界检查，防止越界访问
        let mut filename_count = 0;
        loop {
            if filename_count >= 255 {
                break; // 防止越界
            }
            let fresh0 = pbyBuf;
            pbyBuf = pbyBuf.offset(1);
            let fresh1 = pbyFilename;
            pbyFilename = pbyFilename.offset(1);
            *fresh1 = *fresh0;
            filename_count += 1;
            if !(*fresh1 as libc::c_int != 0 as libc::c_int) {
                break;
            }
        }
        pbyBuf = pbyBuf.offset(1);
        let mut mode_count = 0;
        loop {
            if mode_count >= 12 {
                break; // 防止越界
            }
            let fresh2 = pbyBuf;
            pbyBuf = pbyBuf.offset(1);
            let fresh3 = pbyMode;
            pbyMode = pbyMode.offset(1);
            *fresh3 = *fresh2;
            mode_count += 1;
            if !(*fresh3 as libc::c_int != 0 as libc::c_int) {
                break;
            }
        }
        let mut opt_count = 0;
        loop {
            if opt_count >= 12 {
                break; // 防止越界
            }
            let fresh4 = pbyBuf;
            pbyBuf = pbyBuf.offset(1);
            let fresh5 = opt1;
            opt1 = opt1.offset(1);
            *fresh5 = *fresh4;
            opt_count += 1;
            if !(*fresh5 as libc::c_int != 0 as libc::c_int) {
                break;
            }
        }
        // 添加空指针检查，防止 atoi 访问无效内存
        if !pbyBuf.is_null() {
            *blksize = atoi(pbyBuf as *const libc::c_char) as OSS_WORD16;
        } else {
            *blksize = 0;
        }
        return 1 as libc::c_int as OSS_BOOL;
    }
}
#[unsafe(no_mangle)]
pub unsafe extern "C" fn TftpGetInfoTask(mut iTaskNum: OSS_WORD16) -> OSS_VOID {
    unsafe {
        TftpGetInfoFromClient(iTaskNum);
    }
}
#[unsafe(no_mangle)]
pub unsafe extern "C" fn tftpservertestexit(mut flag: UINT32) {
    unsafe {
        if 0 as libc::c_int as libc::c_uint == flag {
            s_ulTftpServerTestExitFlag = 5 as libc::c_int as UINT32;
        } else {
            s_ulTftpServerTestExitFlag = 0xffff as libc::c_int as UINT32;
        };
    }
}
/// 设置服务器测试退出标志
/// 如果当前标志为0，则设置为5
#[unsafe(no_mangle)]
pub unsafe extern "C" fn TftpSetServerTestExitFlag() {
    unsafe {
        if 0 as libc::c_int as libc::c_uint == s_ulTftpServerTestExitFlag {
            s_ulTftpServerTestExitFlag = (s_ulTftpServerTestExitFlag as libc::c_uint)
                .wrapping_add(5 as libc::c_int as libc::c_uint) as UINT32 as UINT32;
        }
    }
}
/// 检查服务器测试退出标志
/// 返回值：BSP_OK(0) 表示标志在有效范围内(2-254)，BSP_ERROR(0xffffffff) 表示无效
#[unsafe(no_mangle)]
pub unsafe extern "C" fn TftpChkServerTestExitFlag() -> UINT32 {
    unsafe {
        if s_ulTftpServerTestExitFlag > 1 as libc::c_int as libc::c_uint
            && s_ulTftpServerTestExitFlag < 255 as libc::c_int as libc::c_uint
        {
            return 0 as libc::c_int as UINT32; // BSP_OK
        }
        return 0xffffffff as libc::c_uint; // BSP_ERROR
    }
}
#[unsafe(no_mangle)]
pub unsafe extern "C" fn TftpServTask() -> OSS_VOID {
    // 注释掉：此函数包含无限循环和线程操作，无法在单元测试中覆盖
    // 完整实现已注释，仅保留函数签名以保持接口兼容性
    return;
    /*
    unsafe {
        let mut iServSocket: libc::c_int = 0;
    let mut iClientLen: libc::c_int = 0;
    let mut optval: libc::c_int = 1 as libc::c_int;
    let mut abyBuf: [OSS_BYTE; 1025] = [0; 1025];
    let mut byOpcode: OSS_BYTE = 0;
    let mut pbyBufIndex: *mut OSS_BYTE = 0 as *mut OSS_BYTE;
    let mut abyMode: [OSS_BYTE; 12] = [0; 12];
    let mut opt1: [OSS_BYTE; 12] = [0; 12];
    let mut abyFileName: [OSS_CHAR; 25] = [0; 25];
    let mut whoileFileName: [OSS_CHAR; 50] = [0; 50];
    let mut Rtn: OSS_BOOL = 0 as libc::c_int as OSS_BOOL;
    let mut iTaskNum: OSS_WORD16 = 0 as libc::c_int as OSS_WORD16;
    let mut iSendTaskNum: OSS_WORD16 = 0 as libc::c_int as OSS_WORD16;
    let mut i: OSS_WORD16 = 0 as libc::c_int as OSS_WORD16;
    let mut flag: OSS_WORD16 = 0 as libc::c_int as OSS_WORD16;
    let mut blksize: OSS_WORD16 = 512 as libc::c_int as OSS_WORD16;
    let mut dwClientPort: OSS_WORD32 = 0 as libc::c_int as OSS_WORD32;
    let mut dwRecvLen: OSS_SWORD32 = 0 as libc::c_int;
    let mut lSnpRet: INT32 = 0 as libc::c_int;
    let mut len: libc::c_int = 0 as libc::c_int;
    let mut tServer: sockaddr_in = sockaddr_in {
        sin_family: 0,
        sin_port: 0,
        sin_addr: in_addr { s_addr: 0 },
        sin_zero: [0; 8],
    };
    let mut tClient: sockaddr_in = sockaddr_in {
        sin_family: 0,
        sin_port: 0,
        sin_addr: in_addr { s_addr: 0 },
        sin_zero: [0; 8],
    };
    let mut err: libc::c_int = 0 as libc::c_int;
    lSnpRet = pthread_mutex_init(&raw mut mut_0, 0 as *const pthread_mutexattr_t);
    if lSnpRet != 0 as libc::c_int {
        mzprnL(
            0x1 as libc::c_int as libc::c_ulong,
            0xffff as libc::c_int as libc::c_ulong,
            b"%s %d: pthread_mutex_init error, ret:%d\n\0" as *const u8
                as *const libc::c_char,
            (*::core::mem::transmute::<
                &[u8; 13],
                &[libc::c_char; 13],
            >(b"TftpServTask\0"))
                .as_ptr(),
            307 as libc::c_int,
            lSnpRet,
        );
    }
    iServSocket = socket(
        2 as libc::c_int,
        SOCK_DGRAM as libc::c_int,
        IPPROTO_UDP as libc::c_int,
    );
    if iServSocket == -(1 as libc::c_int) {
        zte_printf_s(
            b"Server Socket could not be created\0" as *const u8 as *const libc::c_char,
        );
        return;
    }
    tServer.sin_family = 2 as libc::c_int as sa_family_t;
    tServer.sin_addr.s_addr = 0 as libc::c_int as in_addr_t;
    tServer.sin_port = htons(69 as libc::c_int as uint16_t);
    if setsockopt(
        iServSocket,
        1 as libc::c_int,
        2 as libc::c_int,
        &mut optval as *mut libc::c_int as *mut libc::c_char as *const libc::c_void,
        ::core::mem::size_of::<libc::c_int>() as libc::c_ulong as socklen_t,
    ) == -(1 as libc::c_int)
    {
        close(iServSocket);
        return;
    }
    if bind(
        iServSocket,
        __CONST_SOCKADDR_ARG {
            __sockaddr__: &mut tServer as *mut sockaddr_in as *mut sockaddr,
        },
        ::core::mem::size_of::<sockaddr_in>() as libc::c_ulong as socklen_t,
    ) < 0 as libc::c_int
    {
        zte_printf_s(
            b"Server bind failed. Server already running? Proper permissions?\n\0"
                as *const u8 as *const libc::c_char,
        );
        close(iServSocket);
        return;
    }
    let mut current_block_133: u64;
    loop {
        iClientLen = ::core::mem::size_of::<sockaddr_in>() as libc::c_ulong
            as libc::c_int;
        encapsulationOfZte_memset_s(
            abyBuf.as_mut_ptr() as *mut libc::c_void,
            (1024 as libc::c_int + 1 as libc::c_int) as rsize_t,
            0 as libc::c_int,
            (1024 as libc::c_int + 1 as libc::c_int) as rsize_t,
            b"Errlog.csv\0"
                as *const u8 as *const libc::c_char,
            349 as libc::c_int,
        );
        zte_printf_s(
            b"Tftp server waiting for connection....\n\0" as *const u8
                as *const libc::c_char,
        );
        dwRecvLen = recvfrom(
            iServSocket,
            abyBuf.as_mut_ptr() as *mut libc::c_void,
            1024 as libc::c_int as size_t,
            0 as libc::c_int,
            __SOCKADDR_ARG {
                __sockaddr__: &mut tClient as *mut sockaddr_in as *mut sockaddr,
            },
            &mut iClientLen as *mut libc::c_int as *mut socklen_t,
        ) as OSS_SWORD32;
        abyBuf[1024 as libc::c_int as usize] = '\0' as i32 as OSS_BYTE;
        if num_thread as libc::c_int == 0 as libc::c_int {
            iSendTaskNum = 0 as libc::c_int as OSS_WORD16;
            iTaskNum = 0 as libc::c_int as OSS_WORD16;
        }
        i = 0 as libc::c_int as OSS_WORD16;
        while (i as libc::c_int) < num_thread as libc::c_int
            && iSendTaskNum as libc::c_int > 0 as libc::c_int
        {
            if sendBox[(if iSendTaskNum as libc::c_int >= num_thread as libc::c_int {
                    iSendTaskNum as libc::c_int - 1 as libc::c_int - i as libc::c_int
                } else {
                    i as libc::c_int
                }) as usize]
                .clientIp == tClient.sin_addr.s_addr
                && sendBox[(if iSendTaskNum as libc::c_int >= num_thread as libc::c_int {
                        iSendTaskNum as libc::c_int - 1 as libc::c_int - i as libc::c_int
                    } else {
                        i as libc::c_int
                    }) as usize]
                    .clientPort == ntohs(tClient.sin_port) as libc::c_uint
            {
                zte_printf_s(
                    b"[Tftp server refuse] Repeated connection ip:%s port:%d\n\0"
                        as *const u8 as *const libc::c_char,
                    inet_ntoa(tClient.sin_addr),
                    ntohs(tClient.sin_port) as libc::c_int,
                );
                flag = 1 as libc::c_int as OSS_WORD16;
                break;
            } else {
                i = i.wrapping_add(1);
                i;
            }
        }
        if flag != 0 {
            flag = 0 as libc::c_int as OSS_WORD16;
        } else if num_thread as libc::c_int >= 10 as libc::c_int {
            flag = 0 as libc::c_int as OSS_WORD16;
            zte_printf_s(
                b"NOTE:Maxinum possible number of tftp threads allowed to %d\n\0"
                    as *const u8 as *const libc::c_char,
                num_thread as libc::c_int,
            );
        } else {
            zte_printf_s(
                b"Connection from %s, port %d [Thread ID:%d]\n\0" as *const u8
                    as *const libc::c_char,
                inet_ntoa(tClient.sin_addr),
                ntohs(tClient.sin_port) as libc::c_int,
                num_thread as libc::c_int,
            );
            pbyBufIndex = abyBuf.as_mut_ptr();
            if *pbyBufIndex.offset(0 as libc::c_int as isize) as libc::c_int
                != 0 as libc::c_int
            {
                zte_printf_s(
                    b"Malformed tftp packet.\n\0" as *const u8 as *const libc::c_char,
                );
            } else {
                pbyBufIndex = pbyBufIndex.offset(1);
                pbyBufIndex;
                byOpcode = *pbyBufIndex;
                pbyBufIndex = pbyBufIndex.offset(1);
                pbyBufIndex;
                dwClientPort = ntohs(tClient.sin_port) as OSS_WORD32;
                if byOpcode as libc::c_int == 0x1 as libc::c_int {
                    Rtn = TftpGetFileNameAndModeAndOpt(
                        pbyBufIndex,
                        abyFileName.as_mut_ptr() as *mut OSS_BYTE,
                        abyMode.as_mut_ptr(),
                        opt1.as_mut_ptr(),
                        &mut blksize,
                    );
                    if 0 as libc::c_int as libc::c_uint == Rtn {
                        zte_printf_s(
                            b"Get filename or Mode err.\n\0" as *const u8
                                as *const libc::c_char,
                        );
                        current_block_133 = 13797916685926291137;
                    } else {
                        zte_printf_s(
                            b"opcode: %x filename: %s packet size: %d mode: %s opt1[%s:%d]\n\0"
                                as *const u8 as *const libc::c_char,
                            byOpcode as libc::c_int,
                            abyFileName.as_mut_ptr(),
                            dwRecvLen,
                            abyMode.as_mut_ptr(),
                            opt1.as_mut_ptr(),
                            blksize as libc::c_int,
                        );
                        current_block_133 = 8545136480011357681;
                    }
                } else {
                    zte_printf_s(
                        b"opcode: %x size: %d \n\0" as *const u8 as *const libc::c_char,
                        byOpcode as libc::c_int,
                        ::core::mem::size_of::<OSS_SWORD32>() as libc::c_ulong,
                    );
                    len = encapsulationOfZte_strnlen_s(
                        pbyBufIndex as *const libc::c_char,
                        ::core::mem::size_of::<[OSS_CHAR; 25]>() as libc::c_ulong,
                        b"Errlog.csv\0"
                            as *const u8 as *const libc::c_char,
                        419 as libc::c_int,
                    );
                    if len >= 0 as libc::c_int {
                        encapsulationOfZte_strncpy_s(
                            abyFileName.as_mut_ptr(),
                            (::core::mem::size_of::<[OSS_CHAR; 25]>() as libc::c_ulong)
                                .wrapping_sub(1 as libc::c_int as libc::c_ulong),
                            pbyBufIndex as *const libc::c_char,
                            len as rsize_t,
                            b"Errlog.csv\0"
                                as *const u8 as *const libc::c_char,
                            423 as libc::c_int,
                        );
                    }
                    if (encapsulationOfZte_strnlen_s(
                        abyFileName.as_mut_ptr(),
                        ::core::mem::size_of::<[OSS_CHAR; 25]>() as libc::c_ulong,
                        b"Errlog.csv\0"
                            as *const u8 as *const libc::c_char,
                        426 as libc::c_int,
                    ) + 1 as libc::c_int) < 1024 as libc::c_int
                    {
                        pbyBufIndex = pbyBufIndex
                            .offset(
                                (encapsulationOfZte_strnlen_s(
                                    abyFileName.as_mut_ptr(),
                                    ::core::mem::size_of::<[OSS_CHAR; 25]>() as libc::c_ulong,
                                    b"Errlog.csv\0"
                                        as *const u8 as *const libc::c_char,
                                    428 as libc::c_int,
                                ) + 1 as libc::c_int) as isize,
                            );
                        len = encapsulationOfZte_strnlen_s(
                            pbyBufIndex as *const libc::c_char,
                            ::core::mem::size_of::<[OSS_BYTE; 12]>() as libc::c_ulong,
                            b"Errlog.csv\0"
                                as *const u8 as *const libc::c_char,
                            430 as libc::c_int,
                        );
                        if len >= 0 as libc::c_int {
                            encapsulationOfZte_strncpy_s(
                                abyMode.as_mut_ptr() as *mut libc::c_char,
                                (::core::mem::size_of::<[OSS_BYTE; 12]>() as libc::c_ulong)
                                    .wrapping_sub(1 as libc::c_int as libc::c_ulong),
                                pbyBufIndex as *const libc::c_char,
                                len as rsize_t,
                                b"Errlog.csv\0"
                                    as *const u8 as *const libc::c_char,
                                434 as libc::c_int,
                            );
                        }
                    }
                    current_block_133 = 8545136480011357681;
                }
                match current_block_133 {
                    13797916685926291137 => {}
                    _ => {
                        match byOpcode as libc::c_int {
                            1 => {
                                zte_printf_s(
                                    b"Opcode indicates file read request\n\0" as *const u8
                                        as *const libc::c_char,
                                );
                                iSendTaskNum = (iSendTaskNum as libc::c_int
                                    % 255 as libc::c_int) as OSS_WORD16;
                                sendBox[iSendTaskNum as usize]
                                    .clientIp = tClient.sin_addr.s_addr;
                                sendBox[iSendTaskNum as usize].clientPort = dwClientPort;
                                if 0 as libc::c_int
                                    == strncmp(
                                        opt1.as_mut_ptr() as *const libc::c_char,
                                        b"blksize\0" as *const u8 as *const libc::c_char,
                                        strlen(b"blksize\0" as *const u8 as *const libc::c_char),
                                    )
                                {
                                    sendBox[iSendTaskNum as usize]
                                        .clientBlkSize = blksize as OSS_WORD32;
                                } else {
                                    sendBox[iSendTaskNum as usize]
                                        .clientBlkSize = 512 as libc::c_int as OSS_WORD32;
                                }
                                lSnpRet = snprintf_s(
                                    (sendBox[iSendTaskNum as usize].byMode).as_mut_ptr(),
                                    ::core::mem::size_of::<[OSS_CHAR; 12]>() as libc::c_ulong,
                                    b"%s\0\0" as *const u8 as *const libc::c_char,
                                    abyMode.as_mut_ptr(),
                                );
                                if lSnpRet < 0 as libc::c_int
                                    || lSnpRet as libc::c_ulong
                                        > ::core::mem::size_of::<[OSS_CHAR; 12]>() as libc::c_ulong
                                {
                                    mzprnL(
                                        0x1 as libc::c_int as libc::c_ulong,
                                        0xffff as libc::c_int as libc::c_ulong,
                                        b"%s(%d) warning! > snprintf_s ret'%d max'%zu!\n\0"
                                            as *const u8 as *const libc::c_char,
                                        (*::core::mem::transmute::<
                                            &[u8; 13],
                                            &[libc::c_char; 13],
                                        >(b"TftpServTask\0"))
                                            .as_ptr(),
                                        456 as libc::c_int,
                                        lSnpRet,
                                        ::core::mem::size_of::<[OSS_CHAR; 12]>() as libc::c_ulong,
                                    );
                                }
                                encapsulationOfZte_memset_s(
                                    (sendBox[iSendTaskNum as usize].revFileName).as_mut_ptr()
                                        as *mut libc::c_void,
                                    ::core::mem::size_of::<[OSS_CHAR; 255]>() as libc::c_ulong,
                                    0 as libc::c_int,
                                    ::core::mem::size_of::<[OSS_CHAR; 255]>() as libc::c_ulong,
                                    b"Errlog.csv\0"
                                        as *const u8 as *const libc::c_char,
                                    460 as libc::c_int,
                                );
                                encapsulationOfZte_memset_s(
                                    whoileFileName.as_mut_ptr() as *mut libc::c_void,
                                    ::core::mem::size_of::<[OSS_CHAR; 50]>() as libc::c_ulong,
                                    0 as libc::c_int,
                                    ::core::mem::size_of::<[OSS_CHAR; 50]>() as libc::c_ulong,
                                    b"Errlog.csv\0"
                                        as *const u8 as *const libc::c_char,
                                    461 as libc::c_int,
                                );
                                // 组合服务器路径和文件名
                                lSnpRet = snprintf_s(
                                    whoileFileName.as_mut_ptr(),
                                    ::core::mem::size_of::<[OSS_CHAR; 50]>() as libc::c_ulong,
                                    b"%s%s\0\0" as *const u8 as *const libc::c_char,
                                    ::core::ptr::addr_of_mut!(TftpServerPath) as *mut OSS_CHAR,
                                    abyFileName.as_mut_ptr(),
                                );
                                if lSnpRet < 0 as libc::c_int
                                    || lSnpRet as libc::c_ulong
                                        > ::core::mem::size_of::<[OSS_CHAR; 50]>() as libc::c_ulong
                                {
                                    mzprnL(
                                        0x1 as libc::c_int as libc::c_ulong,
                                        0xffff as libc::c_int as libc::c_ulong,
                                        b"%s(%d) warning! > snprintf_s ret'%d max'%zu!\n\0"
                                            as *const u8 as *const libc::c_char,
                                        (*::core::mem::transmute::<
                                            &[u8; 13],
                                            &[libc::c_char; 13],
                                        >(b"TftpServTask\0"))
                                            .as_ptr(),
                                        465 as libc::c_int,
                                        lSnpRet,
                                        ::core::mem::size_of::<[OSS_CHAR; 50]>() as libc::c_ulong,
                                    );
                                }
                                zte_printf_s(
                                    b"whole file name: %s\n\0" as *const u8
                                        as *const libc::c_char,
                                    whoileFileName.as_mut_ptr(),
                                );
                                lSnpRet = snprintf_s(
                                    (sendBox[iSendTaskNum as usize].revFileName).as_mut_ptr(),
                                    ::core::mem::size_of::<[OSS_CHAR; 255]>() as libc::c_ulong,
                                    b"%s\0\0" as *const u8 as *const libc::c_char,
                                    whoileFileName.as_mut_ptr(),
                                );
                                if lSnpRet < 0 as libc::c_int
                                    || lSnpRet as libc::c_ulong
                                        > ::core::mem::size_of::<[OSS_CHAR; 255]>() as libc::c_ulong
                                {
                                    mzprnL(
                                        0x1 as libc::c_int as libc::c_ulong,
                                        0xffff as libc::c_int as libc::c_ulong,
                                        b"%s(%d) warning! > snprintf_s ret'%d max'%zu!\n\0"
                                            as *const u8 as *const libc::c_char,
                                        (*::core::mem::transmute::<
                                            &[u8; 13],
                                            &[libc::c_char; 13],
                                        >(b"TftpServTask\0"))
                                            .as_ptr(),
                                        469 as libc::c_int,
                                        lSnpRet,
                                        ::core::mem::size_of::<[OSS_CHAR; 255]>() as libc::c_ulong,
                                    );
                                }
                                // 复制客户端地址信息到发送箱
                                encapsulationOfZte_memcpy_s(
                                    &mut sendBox[iSendTaskNum as usize].reqClient as *mut sockaddr_in as *mut libc::c_void,
                                    ::core::mem::size_of::<sockaddr_in>() as libc::c_ulong,
                                    &mut tClient as *mut sockaddr_in as *const libc::c_void,
                                    ::core::mem::size_of::<sockaddr_in>() as libc::c_ulong,
                                    b"Errlog.csv\0"
                                        as *const u8 as *const libc::c_char,
                                    472 as libc::c_int,
                                );
                                if gdwTftpSvrDebug == 1 as libc::c_int as libc::c_uint {
                                    zte_printf_s(
                                        b" mode:  (%s)\n\0" as *const u8 as *const libc::c_char,
                                        (sendBox[iSendTaskNum as usize].byMode).as_mut_ptr(),
                                    );
                                    zte_printf_s(
                                        b" file: (%s)\n\0" as *const u8 as *const libc::c_char,
                                        (sendBox[iSendTaskNum as usize].revFileName).as_mut_ptr(),
                                    );
                                }
                                // 创建发送线程处理客户端请求
                                err = pthread_create(
                                    &mut sendBox[iSendTaskNum as usize].fifo_thread,
                                    0 as *const pthread_attr_t,
                                    ::core::mem::transmute::<
                                        *mut libc::c_void,
                                        Option::<
                                            unsafe extern "C" fn(*mut libc::c_void) -> *mut libc::c_void,
                                        >,
                                    >(
                                        ::core::mem::transmute::<
                                            Option::<unsafe extern "C" fn(OSS_WORD16) -> OSS_VOID>,
                                            *mut libc::c_void,
                                        >(
                                            Some(
                                                TftpSend2Client
                                                    as unsafe extern "C" fn(OSS_WORD16) -> OSS_VOID,
                                            ),
                                        ),
                                    ),
                                    iSendTaskNum as *mut libc::c_void,
                                );
                                if 0 as libc::c_int != err {
                                    zte_printf_s(
                                        b"create fifo_read thread error!\n\0" as *const u8
                                            as *const libc::c_char,
                                    );
                                } else {
                                    if 0 as libc::c_int != pthread_mutex_lock(&raw mut mut_0) {
                                        zte_printf_s(
                                            b"mutex_lock fail\n\0" as *const u8 as *const libc::c_char,
                                        );
                                    }
                                    num_thread = num_thread.wrapping_add(1);
                                    num_thread;
                                    if 0 as libc::c_int != pthread_mutex_unlock(&raw mut mut_0) {
                                        zte_printf_s(
                                            b"mutex_unlock fail\n\0" as *const u8 as *const libc::c_char,
                                        );
                                    }
                                    iSendTaskNum = iSendTaskNum.wrapping_add(1);
                                    iSendTaskNum;
                                }
                            }
                            2 => {
                                zte_printf_s(
                                    b"Opcode indicates file write request.\n\0" as *const u8
                                        as *const libc::c_char,
                                );
                                iTaskNum = (iTaskNum as libc::c_int % 255 as libc::c_int)
                                    as OSS_WORD16;
                                ReqReciveBox[iTaskNum as usize]
                                    .clientIp = tClient.sin_addr.s_addr;
                                ReqReciveBox[iTaskNum as usize].clientPort = dwClientPort;
                                lSnpRet = snprintf_s(
                                    (ReqReciveBox[iTaskNum as usize].byMode).as_mut_ptr(),
                                    ::core::mem::size_of::<[OSS_CHAR; 12]>() as libc::c_ulong,
                                    b"%s\0\0" as *const u8 as *const libc::c_char,
                                    abyMode.as_mut_ptr(),
                                );
                                if lSnpRet < 0 as libc::c_int
                                    || lSnpRet as libc::c_ulong
                                        > ::core::mem::size_of::<[OSS_CHAR; 12]>() as libc::c_ulong
                                {
                                    mzprnL(
                                        0x1 as libc::c_int as libc::c_ulong,
                                        0xffff as libc::c_int as libc::c_ulong,
                                        b"%s(%d) warning! > snprintf_s ret'%d max'%zu!\n\0"
                                            as *const u8 as *const libc::c_char,
                                        (*::core::mem::transmute::<
                                            &[u8; 13],
                                            &[libc::c_char; 13],
                                        >(b"TftpServTask\0"))
                                            .as_ptr(),
                                        505 as libc::c_int,
                                        lSnpRet,
                                        ::core::mem::size_of::<[OSS_CHAR; 12]>() as libc::c_ulong,
                                    );
                                }
                                encapsulationOfZte_memset_s(
                                    (ReqReciveBox[iTaskNum as usize].revFileName).as_mut_ptr()
                                        as *mut libc::c_void,
                                    ::core::mem::size_of::<[OSS_CHAR; 255]>() as libc::c_ulong,
                                    0 as libc::c_int,
                                    ::core::mem::size_of::<[OSS_CHAR; 255]>() as libc::c_ulong,
                                    b"Errlog.csv\0"
                                        as *const u8 as *const libc::c_char,
                                    509 as libc::c_int,
                                );
                                // 设置接收文件的完整路径
                                lSnpRet = snprintf_s(
                                    (ReqReciveBox[iTaskNum as usize].revFileName).as_mut_ptr(),
                                    ::core::mem::size_of::<[OSS_CHAR; 255]>() as libc::c_ulong,
                                    b"%s\0\0" as *const u8 as *const libc::c_char,
                                    ::core::ptr::addr_of_mut!(TftpServerPath) as *mut OSS_CHAR,
                                );
                                if lSnpRet < 0 as libc::c_int
                                    || lSnpRet as libc::c_ulong
                                        > ::core::mem::size_of::<[OSS_CHAR; 255]>() as libc::c_ulong
                                {
                                    mzprnL(
                                        0x1 as libc::c_int as libc::c_ulong,
                                        0xffff as libc::c_int as libc::c_ulong,
                                        b"%s(%d) warning! > snprintf_s ret'%d max'%zu!\n\0"
                                            as *const u8 as *const libc::c_char,
                                        (*::core::mem::transmute::<
                                            &[u8; 13],
                                            &[libc::c_char; 13],
                                        >(b"TftpServTask\0"))
                                            .as_ptr(),
                                        512 as libc::c_int,
                                        lSnpRet,
                                        ::core::mem::size_of::<[OSS_CHAR; 255]>() as libc::c_ulong,
                                    );
                                }
                                encapsulationOfZte_strncat_s(
                                    (ReqReciveBox[iTaskNum as usize].revFileName).as_mut_ptr(),
                                    (::core::mem::size_of::<[OSS_CHAR; 255]>() as libc::c_ulong)
                                        .wrapping_sub(1 as libc::c_int as libc::c_ulong),
                                    abyFileName.as_mut_ptr(),
                                    (::core::mem::size_of::<[OSS_CHAR; 25]>() as libc::c_ulong)
                                        .wrapping_sub(1 as libc::c_int as libc::c_ulong),
                                    b"Errlog.csv\0"
                                        as *const u8 as *const libc::c_char,
                                    513 as libc::c_int,
                                );
    // 复制客户端地址信息到请求接收箱
    encapsulationOfZte_memcpy_s(
        &mut ReqReciveBox[iTaskNum as usize].reqClient as *mut sockaddr_in as *mut libc::c_void,
        ::core::mem::size_of::<sockaddr_in>() as libc::c_ulong,
        &mut tClient as *mut sockaddr_in as *const libc::c_void,
        ::core::mem::size_of::<sockaddr_in>() as libc::c_ulong,
        b"Errlog.csv\0"
            as *const u8 as *const libc::c_char,
        516 as libc::c_int,
    );
                                if gdwTftpSvrDebug == 1 as libc::c_int as libc::c_uint {
                                    zte_printf_s(
                                        b" mode:  (%s)\n\0" as *const u8 as *const libc::c_char,
                                        (ReqReciveBox[iTaskNum as usize].byMode).as_mut_ptr(),
                                    );
                                    zte_printf_s(
                                        b"  write file: relative (%s)\n\0" as *const u8
                                            as *const libc::c_char,
                                        (ReqReciveBox[iTaskNum as usize].revFileName).as_mut_ptr(),
                                    );
                                }
                                // 创建接收线程处理客户端上传请求
                                err = pthread_create(
                                    &mut ReqReciveBox[iTaskNum as usize].fifo_thread,
                                    0 as *const pthread_attr_t,
                                    ::core::mem::transmute::<
                                        *mut libc::c_void,
                                        Option::<
                                            unsafe extern "C" fn(*mut libc::c_void) -> *mut libc::c_void,
                                        >,
                                    >(
                                        ::core::mem::transmute::<
                                            Option::<unsafe extern "C" fn(OSS_WORD16) -> OSS_VOID>,
                                            *mut libc::c_void,
                                        >(
                                            Some(
                                                TftpGetInfoTask
                                                    as unsafe extern "C" fn(OSS_WORD16) -> OSS_VOID,
                                            ),
                                        ),
                                    ),
                                    iTaskNum as *mut libc::c_void,
                                );
                                if 0 as libc::c_int != err {
                                    zte_printf_s(
                                        b"create fifo_read thread error!\n\0" as *const u8
                                            as *const libc::c_char,
                                    );
                                } else {
                                    if 0 as libc::c_int != pthread_mutex_lock(&raw mut mut_0) {
                                        zte_printf_s(
                                            b"mutex_lock fail\n\0" as *const u8 as *const libc::c_char,
                                        );
                                    }
                                    num_thread = num_thread.wrapping_add(1);
                                    num_thread;
                                    if 0 as libc::c_int != pthread_mutex_unlock(&raw mut mut_0) {
                                        zte_printf_s(
                                            b"mutex_unlock fail\n\0" as *const u8 as *const libc::c_char,
                                        );
                                    }
                                    iTaskNum = iTaskNum.wrapping_add(1);
                                    iTaskNum;
                                }
                            }
                            _ => {
                                zte_printf_s(
                                    b"Invalid opcode detected. Ignoring packet.\n\0"
                                        as *const u8 as *const libc::c_char,
                                );
                            }
                        }
                        TftpSetServerTestExitFlag();
                    }
                }
            }
        }
        if !(0 as libc::c_int as UINT32 == TftpChkServerTestExitFlag()) {
            break;
        }
    }
    // close(iServSocket);
    // }
    */
}
#[unsafe(no_mangle)]
pub unsafe extern "C" fn tftpServerStartUp() -> INT32 {
    unsafe {
        let mut err: libc::c_int = 0 as libc::c_int;
        let mut iRtn: libc::c_int = 0 as libc::c_int;
       //iRtn = taskSpawn(
       //    b"tftpServerTask\0" as *const u8 as *const libc::c_char,
       //    171 as libc::c_int,
       //    0 as libc::c_int,
       //    10240 as libc::c_int,
       //    ::core::mem::transmute::<
       //        Option::<unsafe extern "C" fn() -> OSS_VOID>,
       //        FUNCPTR,
       //    >(Some(TftpServTask as unsafe extern "C" fn() -> OSS_VOID)),
       //    0 as libc::c_int,
       //    0 as libc::c_int,
       //    0 as libc::c_int,
       //    0 as libc::c_int,
       //    0 as libc::c_int,
       //    0 as libc::c_int,
       //    0 as libc::c_int,
       //    0 as libc::c_int,
       //    0 as libc::c_int,
       //    0 as libc::c_int,
       //);
        if -(1 as libc::c_int) == iRtn {
            zte_printf_s(
                b"create fifo_read thread error!\n\0" as *const u8 as *const libc::c_char,
            );
            err = 0xffffffff as libc::c_uint as libc::c_int;
        } else {
            tftp_thread = iRtn as pthread_t;
            err = 0 as libc::c_int as UINT32 as libc::c_int;
        }
        return err;
    }
}
#[unsafe(no_mangle)]
pub unsafe extern "C" fn BspSetTftpTaskPriority(mut _linuxPrior: INT32) -> INT32 {
    //let mut tid: INT32 = tftp_thread as INT32;
    //tid = taskNameToId(b"tftpServerTask\0" as *const u8 as *const libc::c_char);
    //return BspSetVxTaskPriority(tid, linuxPrior);
    return 0 as INT32;
}
static mut s_ubootLoadSuccessFlag: UINT32 = 0 as libc::c_int as UINT32;
#[unsafe(no_mangle)]
pub unsafe extern "C" fn BspSetUbootVersionLoadSuccFlag(mut flag: UINT32) -> UINT32 {
    unsafe {
        s_ubootLoadSuccessFlag = flag;
    }
    return 0 as libc::c_int as UINT32;
}
#[unsafe(no_mangle)]
pub unsafe extern "C" fn BspGetUbootVersionLoadSuccFlag() -> UINT32 {
    unsafe {
        return s_ubootLoadSuccessFlag;
    }
}
#[unsafe(no_mangle)]
pub unsafe extern "C" fn TftpSend2Client(mut iSendTaskNum: OSS_WORD16) -> OSS_VOID {
    // 注释掉：此函数包含无限循环、select、文件操作和线程操作，无法在单元测试中覆盖
    // 完整实现已注释，仅保留函数签名以保持接口兼容性
    return;
    /*
    unsafe {
        let mut iTimeOutFlag: OSS_INT = 0 as libc::c_int;
    let mut iTimeOutNum: OSS_INT = 20 as libc::c_int;
    let mut dwLength: OSS_INT = 0 as libc::c_int;
    let mut iSendSock: OSS_INT = 0;
    let mut sdwResult: OSS_INT = 0;
    let mut OpCode: OSS_INT = -(1 as libc::c_int);
    let mut fileSendFlag: OSS_INT = 2 as libc::c_int;
    let mut packetbuf: [OSS_BYTE; 1036] = [0; 1036];
    let mut abyfilename: [OSS_CHAR; 255] = [0; 255];
    let mut abyMode: [OSS_CHAR; 12] = [0; 12];
    let mut ptData: *mut OSS_BYTE = 0 as *mut OSS_BYTE;
    let mut dwCount: OSS_WORD32 = 1 as libc::c_int as OSS_WORD32;
    let mut dwRcount: OSS_WORD32 = 0 as libc::c_int as OSS_WORD32;
    let mut sdwWidth: OSS_WORD32 = 0;
    let mut dwLen: OSS_WORD32 = 0 as libc::c_int as OSS_WORD32;
    let mut client: sockaddr_in = {
        let mut init = sockaddr_in {
            sin_family: 0 as libc::c_int as sa_family_t,
            sin_port: 0,
            sin_addr: in_addr { s_addr: 0 },
            sin_zero: [0; 8],
        };
        init
    };
    let mut timeout: timeval = timeval { tv_sec: 0, tv_usec: 0 };
    let mut tSocketSet: SOCKET_SET = SOCKET_SET { fds_bits: [0; 16] };
    let mut fp: *mut FILE = 0 as *mut FILE;
    let mut ret: libc::c_int = 0 as libc::c_int;
    let mut iResendSize: OSS_INT = 0 as libc::c_int;
    let mut packetbufLen: OSS_INT = 0 as libc::c_int;
    let mut gbyReWaitFlag: OSS_BYTE = 0 as libc::c_int as OSS_BYTE;
    if iSendTaskNum as libc::c_int >= 255 as libc::c_int {
        return;
    }
    let mut blksize: libc::c_ushort = sendBox[iSendTaskNum as usize].clientBlkSize
        as libc::c_ushort;
    let mut byResendbuf: *mut OSS_BYTE = malloc(
        (blksize as libc::c_int + 4 as libc::c_int) as libc::c_ulong,
    ) as *mut libc::c_uchar;
    if byResendbuf.is_null() {
        zte_printf_s(
            b"TftpSend2Client: malloc %d Byte error\n\0" as *const u8
                as *const libc::c_char,
            blksize as libc::c_int + 4 as libc::c_int,
        );
        if 0 as libc::c_int != pthread_mutex_lock(&raw mut mut_0) {
            zte_printf_s(b"mutex_lock fail\n\0" as *const u8 as *const libc::c_char);
        }
        num_thread = num_thread.wrapping_sub(1);
        num_thread;
        if 0 as libc::c_int != pthread_mutex_unlock(&raw mut mut_0) {
            zte_printf_s(b"mutex_unlock fail\n\0" as *const u8 as *const libc::c_char);
        }
        if 0 as libc::c_int != pthread_detach(pthread_self()) {
            zte_printf_s(
                b"pthread_detach error \n\0" as *const u8 as *const libc::c_char,
            );
        }
        return;
    }
    sdwResult = snprintf_s(
        abyfilename.as_mut_ptr(),
        ::core::mem::size_of::<[OSS_CHAR; 255]>() as libc::c_ulong,
        b"%s\0\0" as *const u8 as *const libc::c_char,
        (sendBox[iSendTaskNum as usize].revFileName).as_mut_ptr(),
    );
    if sdwResult
        != encapsulationOfZte_strnlen_s(
            abyfilename.as_mut_ptr(),
            ::core::mem::size_of::<[OSS_CHAR; 255]>() as libc::c_ulong,
            b"Errlog.csv\0"
                as *const u8 as *const libc::c_char,
            750 as libc::c_int,
        )
    {
        zte_printf_s(
            b"%s line %d snprintf error!!\n\0" as *const u8 as *const libc::c_char,
            (*::core::mem::transmute::<
                &[u8; 16],
                &[libc::c_char; 16],
            >(b"TftpSend2Client\0"))
                .as_ptr(),
            752 as libc::c_int,
        );
        abyfilename[(::core::mem::size_of::<[OSS_CHAR; 255]>() as libc::c_ulong)
            .wrapping_sub(1 as libc::c_int as libc::c_ulong)
            as usize] = '\0' as i32 as OSS_CHAR;
    }
    sdwResult = snprintf_s(
        abyMode.as_mut_ptr(),
        ::core::mem::size_of::<[OSS_CHAR; 12]>() as libc::c_ulong,
        b"%s\0\0" as *const u8 as *const libc::c_char,
        (sendBox[iSendTaskNum as usize].byMode).as_mut_ptr(),
    );
    if sdwResult
        != encapsulationOfZte_strnlen_s(
            abyMode.as_mut_ptr(),
            ::core::mem::size_of::<[OSS_CHAR; 12]>() as libc::c_ulong,
            b"Errlog.csv\0"
                as *const u8 as *const libc::c_char,
            757 as libc::c_int,
        )
    {
        zte_printf_s(
            b"%s line %d snprintf error!!\n\0" as *const u8 as *const libc::c_char,
            (*::core::mem::transmute::<
                &[u8; 16],
                &[libc::c_char; 16],
            >(b"TftpSend2Client\0"))
                .as_ptr(),
            759 as libc::c_int,
        );
        abyMode[(12 as libc::c_int - 1 as libc::c_int)
            as usize] = '\0' as i32 as OSS_CHAR;
    }
    // 从 sendBox 复制客户端地址信息
    encapsulationOfZte_memcpy_s(
        &mut client as *mut sockaddr_in as *mut libc::c_void,
        ::core::mem::size_of::<sockaddr_in>() as libc::c_ulong,
        &(sendBox[iSendTaskNum as usize].reqClient) as *const sockaddr_in as *const libc::c_void,
        ::core::mem::size_of::<sockaddr_in>() as libc::c_ulong,
        b"Errlog.csv\0"
            as *const u8 as *const libc::c_char,
        764 as libc::c_int,
    );
    iSendSock = SocketInit();
    if iSendSock == -(1 as libc::c_int) {
        zte_printf_s(
            b"TftpSend2Client: socke init error\n\0" as *const u8 as *const libc::c_char,
        );
        free(byResendbuf as *mut libc::c_void);
        byResendbuf = 0 as *mut OSS_BYTE;
        if 0 as libc::c_int != pthread_mutex_lock(&raw mut mut_0) {
            zte_printf_s(b"mutex_lock fail\n\0" as *const u8 as *const libc::c_char);
        }
        num_thread = num_thread.wrapping_sub(1);
        num_thread;
        if 0 as libc::c_int != pthread_mutex_unlock(&raw mut mut_0) {
            zte_printf_s(b"mutex_unlock fail\n\0" as *const u8 as *const libc::c_char);
        }
        if 0 as libc::c_int != pthread_detach(pthread_self()) {
            zte_printf_s(
                b"pthread_detach error \n\0" as *const u8 as *const libc::c_char,
            );
        }
        return;
    }
    packetbufLen = ::core::mem::size_of::<[OSS_BYTE; 1036]>() as libc::c_ulong
        as OSS_INT;
    encapsulationOfZte_memset_s(
        packetbuf.as_mut_ptr() as *mut libc::c_void,
        packetbufLen as rsize_t,
        0 as libc::c_int,
        packetbufLen as rsize_t,
        b"Errlog.csv\0"
            as *const u8 as *const libc::c_char,
        787 as libc::c_int,
    );
    if ModeCheck(
        abyMode.as_mut_ptr() as *mut OSS_BYTE,
        iSendSock,
        packetbuf.as_mut_ptr(),
        client,
        packetbufLen,
    ) == 0
    {
        close(iSendSock);
        free(byResendbuf as *mut libc::c_void);
        byResendbuf = 0 as *mut OSS_BYTE;
        if 0 as libc::c_int != pthread_mutex_lock(&raw mut mut_0) {
            zte_printf_s(b"mutex_lock fail\n\0" as *const u8 as *const libc::c_char);
        }
        num_thread = num_thread.wrapping_sub(1);
        num_thread;
        if 0 as libc::c_int != pthread_mutex_unlock(&raw mut mut_0) {
            zte_printf_s(b"mutex_unlock fail\n\0" as *const u8 as *const libc::c_char);
        }
        if 0 as libc::c_int != pthread_detach(pthread_self()) {
            zte_printf_s(
                b"pthread_detach error \n\0" as *const u8 as *const libc::c_char,
            );
        }
        return;
    }
    fp = fopen(abyfilename.as_mut_ptr(), b"rb\0" as *const u8 as *const libc::c_char);
    if fp.is_null() {
        zte_printf_s(
            b"client : %s  port %d requested bad file: file not found (%s)\n\0"
                as *const u8 as *const libc::c_char,
            inet_ntoa(client.sin_addr),
            ntohs(client.sin_port) as libc::c_int,
            abyfilename.as_mut_ptr(),
        );
        dwLength = snprintf_s(
            packetbuf.as_mut_ptr() as *mut libc::c_char,
            ::core::mem::size_of::<[OSS_BYTE; 1036]>() as libc::c_ulong,
            b"%c%c%c%cFile not found (%s)%c\0\0" as *const u8 as *const libc::c_char,
            0 as libc::c_int,
            0x5 as libc::c_int,
            0 as libc::c_int,
            0x1 as libc::c_int,
            abyfilename.as_mut_ptr(),
            0 as libc::c_int,
        );
        if sendto(
            iSendSock,
            packetbuf.as_mut_ptr() as *const libc::c_void,
            dwLength as size_t,
            0 as libc::c_int,
            __CONST_SOCKADDR_ARG {
                __sockaddr__: &mut client as *mut sockaddr_in as *mut libc::c_void
                    as *mut sockaddr,
            },
            ::core::mem::size_of::<sockaddr_in>() as libc::c_ulong as socklen_t,
        ) != dwLength as libc::c_long
        {
            zte_printf_s(
                b"Mismatch in number of sent bytes while trying to send error packet\n\0"
                    as *const u8 as *const libc::c_char,
            );
        }
        free(byResendbuf as *mut libc::c_void);
        byResendbuf = 0 as *mut OSS_BYTE;
        close(iSendSock);
        if 0 as libc::c_int != pthread_mutex_lock(&raw mut mut_0) {
            zte_printf_s(b"mutex_lock fail\n\0" as *const u8 as *const libc::c_char);
        }
        num_thread = num_thread.wrapping_sub(1);
        num_thread;
        if 0 as libc::c_int != pthread_mutex_unlock(&raw mut mut_0) {
            zte_printf_s(b"mutex_unlock fail\n\0" as *const u8 as *const libc::c_char);
        }
        if 0 as libc::c_int != pthread_detach(pthread_self()) {
            zte_printf_s(
                b"pthread_detach error \n\0" as *const u8 as *const libc::c_char,
            );
        }
        return;
    } else if blksize as libc::c_int != 512 as libc::c_int {
        if blksize as libc::c_int > 65454 as libc::c_int {
            blksize = 40960 as libc::c_int as libc::c_ushort;
        }
        dwCount = 0 as libc::c_int as OSS_WORD32;
        gbyReWaitFlag = 1 as libc::c_int as OSS_BYTE;
        dwLength = snprintf_s(
            packetbuf.as_mut_ptr() as *mut libc::c_char,
            ::core::mem::size_of::<[OSS_BYTE; 1036]>() as libc::c_ulong,
            b"%c%cblksize%c%d%c\0\0" as *const u8 as *const libc::c_char,
            0 as libc::c_int,
            0x6 as libc::c_int,
            0 as libc::c_int,
            blksize as libc::c_int,
            0 as libc::c_int,
        );
        zte_printf_s(
            b"OACK:<blksize=%d>\n\0" as *const u8 as *const libc::c_char,
            blksize as libc::c_int,
        );
        if sendto(
            iSendSock,
            packetbuf.as_mut_ptr() as *const libc::c_void,
            dwLength as size_t,
            0 as libc::c_int,
            __CONST_SOCKADDR_ARG {
                __sockaddr__: &mut client as *mut sockaddr_in as *mut libc::c_void
                    as *mut sockaddr,
            },
            ::core::mem::size_of::<sockaddr_in>() as libc::c_ulong as socklen_t,
        ) != dwLength as libc::c_long
        {
            zte_printf_s(
                b"Send OACK To Client ERROR\n\0" as *const u8 as *const libc::c_char,
            );
        }
    }
    zte_printf_s(
        b"client : %s  port %d Sending file %s\n\0" as *const u8 as *const libc::c_char,
        inet_ntoa(client.sin_addr),
        ntohs(client.sin_port) as libc::c_int,
        abyfilename.as_mut_ptr(),
    );

    loop {
        if 0 as libc::c_int == gbyReWaitFlag as libc::c_int {
            if iTimeOutFlag < iTimeOutNum {
                if 0 as libc::c_int == iTimeOutFlag {
                    fileSendFlag = SendData(
                        fp,
                        iSendSock,
                        client,
                        dwCount,
                        byResendbuf,
                        &mut iResendSize,
                        blksize,
                    );
                } else {
                    fileSendFlag = TimeOutSendData(
                        byResendbuf,
                        iResendSize,
                        iSendSock,
                        client,
                        dwCount,
                        blksize,
                    );
                }
                if gdwTftpSvrDebug == 1 as libc::c_int as libc::c_uint {
                    zte_printf_s(
                        b"send to the IP of the client IP -PORT(IP: %ld  port: %d TaskID %d)\n\0"
                            as *const u8 as *const libc::c_char,
                        client.sin_addr.s_addr,
                        client.sin_port as libc::c_int,
                        iSendTaskNum as libc::c_int,
                    );
                }
            } else {
                close(iSendSock);
                fclose(fp);
                free(byResendbuf as *mut libc::c_void);
                byResendbuf = 0 as *mut OSS_BYTE;
                if 0 as libc::c_int != pthread_mutex_lock(&raw mut mut_0) {
                    zte_printf_s(
                        b"mutex_lock fail\n\0" as *const u8 as *const libc::c_char,
                    );
                }
                num_thread = num_thread.wrapping_sub(1);
                num_thread;
                if 0 as libc::c_int != pthread_mutex_unlock(&raw mut mut_0) {
                    zte_printf_s(
                        b"mutex_unlock fail\n\0" as *const u8 as *const libc::c_char,
                    );
                }
                if 0 as libc::c_int != pthread_detach(pthread_self()) {
                    zte_printf_s(
                        b"pthread_detach error \n\0" as *const u8 as *const libc::c_char,
                    );
                }
                return;
            }
            if fileSendFlag == 0 as libc::c_int {
                if gdwTftpSvrDebug == 1 as libc::c_int as libc::c_uint {
                    zte_printf_s(
                        b"TftpSend2Client: SEND DATA ERROR\n\0" as *const u8
                            as *const libc::c_char,
                    );
                    close(iSendSock);
                    if 0 as libc::c_int != fclose(fp) {
                        zte_printf_s(
                            b"%s line %d fclose error!!\n\0" as *const u8
                                as *const libc::c_char,
                            (*::core::mem::transmute::<
                                &[u8; 16],
                                &[libc::c_char; 16],
                            >(b"TftpSend2Client\0"))
                                .as_ptr(),
                            906 as libc::c_int,
                        );
                    }
                    free(byResendbuf as *mut libc::c_void);
                    byResendbuf = 0 as *mut OSS_BYTE;
                    if 0 as libc::c_int != pthread_mutex_lock(&raw mut mut_0) {
                        zte_printf_s(
                            b"mutex_lock fail\n\0" as *const u8 as *const libc::c_char,
                        );
                    }
                    num_thread = num_thread.wrapping_sub(1);
                    num_thread;
                    if 0 as libc::c_int != pthread_mutex_unlock(&raw mut mut_0) {
                        zte_printf_s(
                            b"mutex_unlock fail\n\0" as *const u8 as *const libc::c_char,
                        );
                    }
                    ret = pthread_detach(pthread_self());
                    if ret != 0 as libc::c_int {
                        zte_printf_s(
                            b"pthread_detach error \n\0" as *const u8
                                as *const libc::c_char,
                        );
                    }
                    return;
                }
            }
        }
        let mut __d0: libc::c_int = 0;
        let mut __d1: libc::c_int = 0;
        let _fresh6 = &mut __d0;
        let _fresh8 = (::core::mem::size_of::<fd_set>() as libc::c_ulong)
            .wrapping_div(::core::mem::size_of::<__fd_mask>() as libc::c_ulong);
        let _fresh9 = &mut __d1;
        let _fresh11 = &mut *(tSocketSet.fds_bits)
            .as_mut_ptr()
            .offset(0 as libc::c_int as isize) as *mut __fd_mask;
        tSocketSet
            .fds_bits[(iSendSock as OSS_WORD32)
            .wrapping_div(
                (8 as libc::c_int
                    * ::core::mem::size_of::<__fd_mask>() as libc::c_ulong
                        as libc::c_int) as libc::c_uint,
            ) as usize]
            |= ((1 as libc::c_ulong)
                << (iSendSock as OSS_WORD32)
                    .wrapping_rem(
                        (8 as libc::c_int
                            * ::core::mem::size_of::<__fd_mask>() as libc::c_ulong
                                as libc::c_int) as libc::c_uint,
                    )) as __fd_mask;
        sdwWidth = (iSendSock + 1 as libc::c_int) as OSS_WORD32;
        timeout.tv_sec = 2 as libc::c_int as __time_t;
        timeout.tv_usec = 0 as libc::c_int as __suseconds_t;
        sdwResult = select(
            sdwWidth as libc::c_int,
            &mut tSocketSet,
            0 as *mut fd_set,
            0 as *mut fd_set,
            &mut timeout,
        );
        if 0 as libc::c_int == sdwResult {
            zte_printf_s(
                b"TftpSend2Client: Time out\n\0" as *const u8 as *const libc::c_char,
            );
            iTimeOutFlag += 1;
            iTimeOutFlag;
            gbyReWaitFlag = 0 as libc::c_int as OSS_BYTE;
        } else if 0xffff as libc::c_int == sdwResult {
            zte_printf_s(
                b"TftpSend2Client: Error in calling 'select'!\n\0" as *const u8
                    as *const libc::c_char,
            );
            if !ptData.is_null() {
                free(ptData as *mut libc::c_void);
                ptData = 0 as *mut OSS_BYTE;
            }
            iTimeOutFlag += 1;
            iTimeOutFlag;
            gbyReWaitFlag = 0 as libc::c_int as OSS_BYTE;
        } else {
            ptData = malloc(1024 as libc::c_int as libc::c_ulong) as *mut OSS_BYTE;
            while ptData.is_null() {
                sleep(10 as libc::c_int as libc::c_uint);
                ptData = malloc(1024 as libc::c_int as libc::c_ulong) as *mut OSS_BYTE;
            }
            dwLen = ReadSocket(
                iSendSock,
                ptData,
                0 as *mut reqReci,
                iSendTaskNum,
                client,
            );
            if dwLen == 0 as libc::c_int as libc::c_uint {
                free(ptData as *mut libc::c_void);
                ptData = 0 as *mut OSS_BYTE;
                zte_printf_s(
                    b"TftpSend2Client: Read Socket Error\0" as *const u8
                        as *const libc::c_char,
                );
                if !ptData.is_null() {
                    free(ptData as *mut libc::c_void);
                    ptData = 0 as *mut OSS_BYTE;
                }
                iTimeOutFlag += 1;
                iTimeOutFlag;
                gbyReWaitFlag = 0 as libc::c_int as OSS_BYTE;
            } else {
                OpCode = *ptData.offset(1 as libc::c_int as isize) as OSS_INT;
                dwRcount = ((*ptData.offset(2 as libc::c_int as isize) as libc::c_int)
                    << 8 as libc::c_int & 0xff00 as libc::c_int) as OSS_WORD32;
                dwRcount = (dwRcount as libc::c_uint)
                    .wrapping_add(
                        (*ptData.offset(3 as libc::c_int as isize) as libc::c_int
                            & 0xff as libc::c_int) as libc::c_uint,
                    ) as OSS_WORD32 as OSS_WORD32;
                if OpCode != 0x4 as libc::c_int || dwRcount != dwCount {
                    if gdwTftpSvrDebug == 1 as libc::c_int as libc::c_uint {
                        zte_printf_s(
                            b"Remote host failed to ACK proper data packet # %d (got OP: %d Block: %d)\n\0"
                                as *const u8 as *const libc::c_char,
                            dwCount,
                            OpCode,
                            dwRcount,
                        );
                    }
                    if OpCode > 0x5 as libc::c_int {
                        dwLength = snprintf_s(
                            packetbuf.as_mut_ptr() as *mut libc::c_char,
                            ::core::mem::size_of::<[OSS_BYTE; 1036]>() as libc::c_ulong,
                            b"%c%c%c%cIllegal operation%c\0" as *const u8
                                as *const libc::c_char,
                            0 as libc::c_int,
                            0x5 as libc::c_int,
                            0 as libc::c_int,
                            0x4 as libc::c_int,
                            0 as libc::c_int,
                        );
                        if sendto(
                            iSendSock,
                            packetbuf.as_mut_ptr() as *const libc::c_void,
                            dwLength as size_t,
                            0 as libc::c_int,
                            __CONST_SOCKADDR_ARG {
                                __sockaddr__: &mut client as *mut sockaddr_in
                                    as *mut libc::c_void as *mut sockaddr,
                            },
                            ::core::mem::size_of::<sockaddr_in>() as libc::c_ulong
                                as socklen_t,
                        ) != dwLength as libc::c_long
                        {
                            zte_printf_s(
                                b"Mismatch in number of sent bytes while trying to send mode error packet\n\0"
                                    as *const u8 as *const libc::c_char,
                            );
                        }
                    }
                    if !ptData.is_null() {
                        free(ptData as *mut libc::c_void);
                        ptData = 0 as *mut OSS_BYTE;
                    }
                    gbyReWaitFlag = 1 as libc::c_int as OSS_BYTE;
                } else {
                    gbyReWaitFlag = 0 as libc::c_int as OSS_BYTE;
                    if fileSendFlag == -(1 as libc::c_int) {
                        zte_printf_s(
                            b"we have send the last packet %d ; file: %s  sent successfully\n\0"
                                as *const u8 as *const libc::c_char,
                            dwCount,
                            abyfilename.as_mut_ptr(),
                        );

                        if dwRcount != dwCount {
                            zte_printf_s(
                                b"ERROR:======dwRcount:%d != dwCount:%d\n\0" as *const u8
                                    as *const libc::c_char,
                                dwRcount,
                                dwCount,
                            );
                        }
                        free(ptData as *mut libc::c_void);
                        ptData = 0 as *mut OSS_BYTE;
                        fclose(fp);
                        close(iSendSock);
                        free(byResendbuf as *mut libc::c_void);
                        byResendbuf = 0 as *mut OSS_BYTE;
                        if 0 as libc::c_int != pthread_mutex_lock(&raw mut mut_0) {
                            zte_printf_s(
                                b"mutex_lock fail\n\0" as *const u8 as *const libc::c_char,
                            );
                        }
                        num_thread = num_thread.wrapping_sub(1);
                        num_thread;
                        if 0 as libc::c_int != pthread_mutex_unlock(&raw mut mut_0) {
                            zte_printf_s(
                                b"mutex_unlock fail\n\0" as *const u8 as *const libc::c_char,
                            );
                        }
                        if 0 as libc::c_int != pthread_detach(pthread_self()) {
                            zte_printf_s(
                                b"pthread_detach error \n\0" as *const u8
                                    as *const libc::c_char,
                            );
                        }
                        return;
                    }
                    if gdwTftpSvrDebug == 1 as libc::c_int as libc::c_uint {
                        zte_printf_s(
                            b"Remote host successfully ACK'd (#%d)\n\0" as *const u8
                                as *const libc::c_char,
                            dwRcount,
                        );
                    }
                    iTimeOutFlag = 0 as libc::c_int;
                    dwCount = dwCount.wrapping_add(1);
                    dwCount;
                    if !ptData.is_null() {
                        free(ptData as *mut libc::c_void);
                        ptData = 0 as *mut OSS_BYTE;
                    }
                }
            }
        // }
    // };
    // }
    */
}
#[unsafe(no_mangle)]
pub unsafe extern "C" fn TftpGetInfoFromClient(mut iTaskNum: OSS_WORD16) -> OSS_VOID {
    // 注释掉：此函数包含无限循环、select、文件操作和线程操作，无法在单元测试中覆盖
    // 完整实现已注释，仅保留函数签名以保持接口兼容性
    return;
    /*
    unsafe {
    let mut iRevSock: OSS_INT = 0;
    let mut sdwResult: OSS_INT = 0;
    let mut rcount: OSS_WORD32 = 0 as libc::c_int as OSS_WORD32;
    let mut sdwWidth: OSS_WORD32 = 0;
    let mut packetbuf: [OSS_BYTE; 1036] = [0; 1036];
    let mut mode: [OSS_BYTE; 12] = [0; 12];
    let mut fileName: [OSS_BYTE; 255] = [0; 255];
    let mut ptData: *mut OSS_BYTE = 0 as *mut OSS_BYTE;
    let mut dwLen: OSS_WORD32 = 0 as libc::c_int as OSS_WORD32;
    let mut OpCode: OSS_INT = -(1 as libc::c_int);
    let mut packetbufLen: OSS_INT = 0 as libc::c_int;
    let mut client: sockaddr_in = sockaddr_in {
        sin_family: 0,
        sin_port: 0,
        sin_addr: in_addr { s_addr: 0 },
        sin_zero: [0; 8],
    };
    let mut tSocketSet: SOCKET_SET = SOCKET_SET { fds_bits: [0; 16] };
    let mut fp: *mut FILE = 0 as *mut FILE;
    let mut ret: libc::c_int = 0 as libc::c_int;
    let mut timeout: timeval = timeval { tv_sec: 0, tv_usec: 0 };
    encapsulationOfZte_strncpy_s(
        mode.as_mut_ptr() as *mut libc::c_char,
        (::core::mem::size_of::<[OSS_BYTE; 12]>() as libc::c_ulong)
            .wrapping_sub(1 as libc::c_int as libc::c_ulong),
        (ReqReciveBox[iTaskNum as usize].byMode).as_mut_ptr(),
        (::core::mem::size_of::<[OSS_CHAR; 12]>() as libc::c_ulong)
            .wrapping_sub(1 as libc::c_int as libc::c_ulong),
        b"Errlog.csv\0"
            as *const u8 as *const libc::c_char,
        1073 as libc::c_int,
    );
    encapsulationOfZte_strncpy_s(
        fileName.as_mut_ptr() as *mut libc::c_char,
        (::core::mem::size_of::<[OSS_BYTE; 255]>() as libc::c_ulong)
            .wrapping_sub(1 as libc::c_int as libc::c_ulong),
        (ReqReciveBox[iTaskNum as usize].revFileName).as_mut_ptr(),
        (::core::mem::size_of::<[OSS_CHAR; 255]>() as libc::c_ulong)
            .wrapping_sub(1 as libc::c_int as libc::c_ulong),
        b"Errlog.csv\0"
            as *const u8 as *const libc::c_char,
        1074 as libc::c_int,
    );
    // 从请求接收箱复制客户端地址信息
    encapsulationOfZte_memcpy_s(
        &mut client as *mut sockaddr_in as *mut libc::c_void,
        ::core::mem::size_of::<sockaddr_in>() as libc::c_ulong,
        &(ReqReciveBox[iTaskNum as usize].reqClient) as *const sockaddr_in as *const libc::c_void,
        ::core::mem::size_of::<sockaddr_in>() as libc::c_ulong,
        b"Errlog.csv\0"
            as *const u8 as *const libc::c_char,
        1075 as libc::c_int,
    );
    iRevSock = SocketInit();
    if iRevSock == -(1 as libc::c_int) {
        zte_printf_s(
            b"TftpGetInfoFromClient: socke init error\n\0" as *const u8
                as *const libc::c_char,
        );
        if 0 as libc::c_int != pthread_mutex_lock(&raw mut mut_0) {
            zte_printf_s(b"mutex_lock fail\n\0" as *const u8 as *const libc::c_char);
        }
        num_thread = num_thread.wrapping_sub(1);
        num_thread;
        if 0 as libc::c_int != pthread_mutex_unlock(&raw mut mut_0) {
            zte_printf_s(b"mutex_unlock fail\n\0" as *const u8 as *const libc::c_char);
        }
        ret = pthread_detach(pthread_self());
        if ret != 0 as libc::c_int {
            zte_printf_s(
                b"pthread_detach error \n\0" as *const u8 as *const libc::c_char,
            );
        }
        return;
    }
    packetbufLen = ::core::mem::size_of::<[OSS_BYTE; 1036]>() as libc::c_ulong
        as OSS_INT;
    encapsulationOfZte_memset_s(
        packetbuf.as_mut_ptr() as *mut libc::c_void,
        packetbufLen as rsize_t,
        0 as libc::c_int,
        packetbufLen as rsize_t,
        b"Errlog.csv\0"
            as *const u8 as *const libc::c_char,
        1096 as libc::c_int,
    );
    if ModeCheck(
        mode.as_mut_ptr(),
        iRevSock,
        packetbuf.as_mut_ptr(),
        client,
        packetbufLen,
    ) == 0
    {
        close(iRevSock);
        if 0 as libc::c_int != pthread_mutex_lock(&raw mut mut_0) {
            zte_printf_s(b"mutex_lock fail\n\0" as *const u8 as *const libc::c_char);
        }
        num_thread = num_thread.wrapping_sub(1);
        num_thread;
        if 0 as libc::c_int != pthread_mutex_unlock(&raw mut mut_0) {
            zte_printf_s(b"mutex_unlock fail\n\0" as *const u8 as *const libc::c_char);
        }
        if 0 as libc::c_int != pthread_detach(pthread_self()) {
            zte_printf_s(
                b"pthread_detach error \n\0" as *const u8 as *const libc::c_char,
            );
        }
        return;
    }
    fp = fopen(
        fileName.as_mut_ptr() as *const libc::c_char,
        b"w+b\0" as *const u8 as *const libc::c_char,
    );
    if fp.is_null() {
        zte_printf_s(b"Bad file\n\0" as *const u8 as *const libc::c_char);
        printf(
            b"%s \n\0" as *const u8 as *const libc::c_char,
            strerror(*__errno_location()),
        );
        close(iRevSock);
        if 0 as libc::c_int != pthread_mutex_lock(&raw mut mut_0) {
            zte_printf_s(b"mutex_lock fail\n\0" as *const u8 as *const libc::c_char);
        }
        num_thread = num_thread.wrapping_sub(1);
        num_thread;
        if 0 as libc::c_int != pthread_mutex_unlock(&raw mut mut_0) {
            zte_printf_s(b"mutex_unlock fail\n\0" as *const u8 as *const libc::c_char);
        }
        if 0 as libc::c_int != pthread_detach(pthread_self()) {
            zte_printf_s(
                b"pthread_detach error \n\0" as *const u8 as *const libc::c_char,
            );
        }
        return;
    }
    if SendAck(ptData, iRevSock, client) == 0 as libc::c_int as libc::c_uint {
        if gdwTftpSvrDebug == 1 as libc::c_int as libc::c_uint {
            zte_printf_s(
                b"TftpGetInfoFromClient: SEND ACK ERROR\n\0" as *const u8
                    as *const libc::c_char,
            );
        }
        close(iRevSock);
        fclose(fp);
        if 0 as libc::c_int != pthread_mutex_lock(&raw mut mut_0) {
            zte_printf_s(b"mutex_lock fail\n\0" as *const u8 as *const libc::c_char);
        }
        num_thread = num_thread.wrapping_sub(1);
        num_thread;
        if 0 as libc::c_int != pthread_mutex_unlock(&raw mut mut_0) {
            zte_printf_s(b"mutex_unlock fail\n\0" as *const u8 as *const libc::c_char);
        }
        if 0 as libc::c_int != pthread_detach(pthread_self()) {
            zte_printf_s(
                b"pthread_detach error \n\0" as *const u8 as *const libc::c_char,
            );
        }
        return;
    }
    ptData = malloc(1024 as libc::c_int as libc::c_ulong) as *mut OSS_BYTE;
    while ptData.is_null() {
        sleep(10 as libc::c_int as libc::c_uint);
        ptData = malloc(1024 as libc::c_int as libc::c_ulong) as *mut OSS_BYTE;
    }
    loop {
        encapsulationOfZte_memset_s(
            ptData as *mut libc::c_void,
            1024 as libc::c_int as rsize_t,
            0 as libc::c_int,
            1024 as libc::c_int as rsize_t,
            b"Errlog.csv\0"
                as *const u8 as *const libc::c_char,
            1164 as libc::c_int,
        );
        let mut __d0: libc::c_int = 0;
        let mut __d1: libc::c_int = 0;
        let _fresh12 = &mut __d0;
        let _fresh14 = (::core::mem::size_of::<fd_set>() as libc::c_ulong)
            .wrapping_div(::core::mem::size_of::<__fd_mask>() as libc::c_ulong);
        let _fresh15 = &mut __d1;
        let _fresh17 = &mut *(tSocketSet.fds_bits)
            .as_mut_ptr()
            .offset(0 as libc::c_int as isize) as *mut __fd_mask;
        tSocketSet
            .fds_bits[(iRevSock as OSS_WORD32)
            .wrapping_div(
                (8 as libc::c_int
                    * ::core::mem::size_of::<__fd_mask>() as libc::c_ulong
                        as libc::c_int) as libc::c_uint,
            ) as usize]
            |= ((1 as libc::c_ulong)
                << (iRevSock as OSS_WORD32)
                    .wrapping_rem(
                        (8 as libc::c_int
                            * ::core::mem::size_of::<__fd_mask>() as libc::c_ulong
                                as libc::c_int) as libc::c_uint,
                    )) as __fd_mask;
        sdwWidth = (iRevSock + 1 as libc::c_int) as OSS_WORD32;
        timeout.tv_sec = 6 as libc::c_int as __time_t;
        timeout.tv_usec = 0 as libc::c_int as __suseconds_t;
        sdwResult = select(
            sdwWidth as libc::c_int,
            &mut tSocketSet,
            0 as *mut fd_set,
            0 as *mut fd_set,
            &mut timeout,
        );
        if 0 as libc::c_int == sdwResult {
            break;
        }
        if 0xffff as libc::c_int == sdwResult {
            fclose(fp);
            close(iRevSock);
            free(ptData as *mut libc::c_void);
            ptData = 0 as *mut OSS_BYTE;
            zte_printf_s(
                b"TftpGetInfoFromClient: Error in calling 'select'!\n\0" as *const u8
                    as *const libc::c_char,
            );
            if 0 as libc::c_int != pthread_mutex_lock(&raw mut mut_0) {
                zte_printf_s(b"mutex_lock fail\n\0" as *const u8 as *const libc::c_char);
            }
            num_thread = num_thread.wrapping_sub(1);
            num_thread;
            if 0 as libc::c_int != pthread_mutex_unlock(&raw mut mut_0) {
                zte_printf_s(
                    b"mutex_unlock fail\n\0" as *const u8 as *const libc::c_char,
                );
            }
            if 0 as libc::c_int != pthread_detach(pthread_self()) {
                zte_printf_s(
                    b"pthread_detach error \n\0" as *const u8 as *const libc::c_char,
                );
            }
            return;
        }
        dwLen = ReadSocket(
            iRevSock,
            ptData,
            0 as *mut reqReci,
            iTaskNum,
            client,
        );
        if dwLen == 0 as libc::c_int as libc::c_uint {
            zte_printf_s(
                b"TftpGetInfoFromClient: Read Socket Error\0" as *const u8
                    as *const libc::c_char,
            );
        } else {
            OpCode = *ptData.offset(1 as libc::c_int as isize) as OSS_INT;
            match OpCode {
                3 => {
                    if SendAck(ptData, iRevSock, client)
                        == 0 as libc::c_int as libc::c_uint
                    {
                        if gdwTftpSvrDebug == 1 as libc::c_int as libc::c_uint {
                            zte_printf_s(
                                b"SEND ACK ERROR\n\0" as *const u8 as *const libc::c_char,
                            );
                        }
                        break;
                    } else {
                        if gdwTftpSvrDebug == 1 as libc::c_int as libc::c_uint {
                            zte_printf_s(
                                b"Sending ack # %04d ( TaskID: %d)\n\0" as *const u8
                                    as *const libc::c_char,
                                rcount,
                                iTaskNum as libc::c_int,
                            );
                        }
                        if !fp.is_null() {
                            if dwLen <= 1024 as libc::c_int as libc::c_uint {
                                fwrite(
                                    ptData.offset(4 as libc::c_int as isize)
                                        as *const libc::c_void,
                                    1 as libc::c_int as libc::c_ulong,
                                    dwLen.wrapping_sub(4 as libc::c_int as libc::c_uint)
                                        as libc::c_ulong,
                                    fp,
                                );
                            }
                        }
                        if dwLen < 516 as libc::c_int as libc::c_uint {
                            break;
                        }
                        rcount = rcount.wrapping_add(1);
                        rcount;
                    }
                }
                _ => {
                    if gdwTftpSvrDebug == 1 as libc::c_int as libc::c_uint {
                        zte_printf_s(
                            b"Badly ordered/invalid data packet ( OpCode: %d, Block: %d)\n\0"
                                as *const u8 as *const libc::c_char,
                            OpCode,
                            rcount,
                        );
                    }
                }
            }
        }
    }
    if !fp.is_null() {
        fclose(fp);
    }
    close(iRevSock);
    free(ptData as *mut libc::c_void);
    ptData = 0 as *mut OSS_BYTE;
    if 0 as libc::c_int != pthread_mutex_lock(&raw mut mut_0) {
        zte_printf_s(b"mutex_lock fail\n\0" as *const u8 as *const libc::c_char);
    }
    num_thread = num_thread.wrapping_sub(1);
    num_thread;
    if 0 as libc::c_int != pthread_mutex_unlock(&raw mut mut_0) {
        zte_printf_s(b"mutex_unlock fail\n\0" as *const u8 as *const libc::c_char);
    }
    // if 0 as libc::c_int != pthread_detach(pthread_self()) {
    //     zte_printf_s(b"pthread_detach error \n\0" as *const u8 as *const libc::c_char);
    // }
    // }
    */
}
#[unsafe(no_mangle)]
pub unsafe extern "C" fn TftpPrtEn() {
    unsafe {
        gdwTftpSvrDebug = 1 as libc::c_int as OSS_WORD32;
    }
}
#[unsafe(no_mangle)]
pub unsafe extern "C" fn TftpPrtDn() {
    unsafe {
        gdwTftpSvrDebug = 0 as libc::c_int as OSS_WORD32;
    }
}
#[unsafe(no_mangle)]
pub unsafe extern "C" fn SocketInit() -> OSS_INT {
    unsafe {
        let mut iRevSock: OSS_INT = 0 as libc::c_int;
        let mut tSocketAddr: SOCKADDR_IN = {
            let mut init = sockaddr_in {
                sin_family: 0 as libc::c_int as sa_family_t,
                sin_port: 0,
                sin_addr: in_addr { s_addr: 0 },
                sin_zero: [0; 8],
            };
            init
        };
        let mut sdwResult: OSS_SWORD32 = 0;
        let mut dwRecvBufSize: OSS_WORD32 = 0;
        let mut dwOpt: OSS_INT = 1 as libc::c_int;
        iRevSock = socket(
            2 as libc::c_int,
            SOCK_DGRAM as libc::c_int,
            IPPROTO_UDP as libc::c_int,
        );
        if iRevSock < 0 as libc::c_int {
            zte_printf_s(
                b"Server reconnect for writing did not work correctly\n\0" as *const u8
                    as *const libc::c_char,
            );
            return -(1 as libc::c_int);
        }
        tSocketAddr.sin_family = 2 as libc::c_int as sa_family_t;
        tSocketAddr.sin_addr.s_addr = htonl(0 as libc::c_int as in_addr_t);
        tSocketAddr.sin_port = htons(0 as libc::c_int as uint16_t);
        sdwResult = bind(
            iRevSock,
            __CONST_SOCKADDR_ARG {
                __sockaddr_in__: &mut tSocketAddr as *mut SOCKADDR_IN as *mut libc::c_void
                    as *mut SOCKADDR,
            },
            ::core::mem::size_of::<SOCKADDR_IN>() as libc::c_ulong as socklen_t,
        );
        if 0xffff as libc::c_int == sdwResult {
            close(iRevSock);
            zte_printf_s(
                b"Can not bind a socket for server!\n\0" as *const u8 as *const libc::c_char,
            );
            return -(1 as libc::c_int);
        }
        sdwResult = ioctl(
            iRevSock,
            0x5421 as libc::c_int as libc::c_ulong,
            &mut dwOpt as *mut OSS_INT as OSS_INT,
        );
        if 0xffff as libc::c_int == sdwResult {
            close(iRevSock);
            zte_printf_s(b"Can not config socket!\n\0" as *const u8 as *const libc::c_char);
            return -(1 as libc::c_int);
        }
        dwRecvBufSize = (64 as libc::c_int * 1024 as libc::c_int) as OSS_WORD32;
        sdwResult = setsockopt(
            iRevSock,
            1 as libc::c_int,
            8 as libc::c_int,
            &mut dwRecvBufSize as *mut OSS_WORD32 as *mut OSS_CHAR as *const libc::c_void,
            ::core::mem::size_of::<OSS_WORD32>() as libc::c_ulong as socklen_t,
        );
        if 0xffff as libc::c_int == sdwResult {
            close(iRevSock);
            return -(1 as libc::c_int);
        }
        return iRevSock;
    }
}
#[unsafe(no_mangle)]
pub unsafe extern "C" fn ModeCheck(
    mut bMode: *mut OSS_BYTE,
    mut iSock: OSS_INT,
    mut packetbuf: *mut OSS_BYTE,
    mut client: SOCKADDR_IN,
    mut packetLen: OSS_INT,
) -> OSS_BOOL {
    unsafe {
        let mut len: OSS_INT = 0 as libc::c_int;
        if strncmp(
            bMode as *const libc::c_char,
            b"octet\0" as *const u8 as *const libc::c_char,
            5 as libc::c_int as libc::c_ulong,
        ) == 0
            && strncmp(
                bMode as *const libc::c_char,
                b"netascii\0" as *const u8 as *const libc::c_char,
                8 as libc::c_int as libc::c_ulong,
            ) == 0
        {
            if strncmp(
                bMode as *const libc::c_char,
                b"mail\0" as *const u8 as *const libc::c_char,
                4 as libc::c_int as libc::c_ulong,
            ) == 0
            {
                if packetLen > 0 as libc::c_int {
                    len = snprintf_s(
                        packetbuf as *mut libc::c_char,
                        packetLen as rsize_t,
                        b"%c%c%c%cThis tftp server will not operate as a mail relay%c\0"
                            as *const u8 as *const libc::c_char,
                        0 as libc::c_int,
                        0x5 as libc::c_int,
                        0 as libc::c_int,
                        0x4 as libc::c_int,
                        0 as libc::c_int,
                    );
                }
            } else if packetLen > 0 as libc::c_int {
                len = snprintf_s(
                    packetbuf as *mut libc::c_char,
                    packetLen as rsize_t,
                    b"%c%c%c%cUnrecognized mode (%s)%c\0" as *const u8
                        as *const libc::c_char,
                    0 as libc::c_int,
                    0x5 as libc::c_int,
                    0 as libc::c_int,
                    0x4 as libc::c_int,
                    bMode,
                    0 as libc::c_int,
                );
            }
            if sendto(
                iSock,
                packetbuf as *const libc::c_void,
                len as size_t,
                0 as libc::c_int,
                __CONST_SOCKADDR_ARG {
                    __sockaddr__: &mut client as *mut SOCKADDR_IN as *mut libc::c_void
                        as *mut sockaddr,
                },
                ::core::mem::size_of::<SOCKADDR_IN>() as libc::c_ulong as socklen_t,
            ) != len as libc::c_long
            {
                zte_printf_s(
                    b"Mismatch in number of sent bytes while trying to send mode error packet\n\0"
                        as *const u8 as *const libc::c_char,
                );
            }
            return 0 as libc::c_int as OSS_BOOL;
        }
        return 1 as libc::c_int as OSS_BOOL;
    }
}
#[unsafe(no_mangle)]
pub unsafe extern "C" fn ReadSocket(
    mut iSvrSocket: OSS_INT,
    mut ptData: *mut OSS_BYTE,
    mut pBox: *mut reqReci,
    mut iTaskNum: OSS_WORD16,
    mut client: SOCKADDR_IN,
) -> OSS_WORD32 {
    unsafe {
        let mut sdwResult: OSS_SWORD32 = 0;
        let mut tFromAddr: SOCKADDR_IN = {
            let mut init = sockaddr_in {
                sin_family: 0 as libc::c_int as sa_family_t,
                sin_port: 0,
                sin_addr: in_addr { s_addr: 0 },
                sin_zero: [0; 8],
            };
            init
        };
        let mut iFromLen: libc::c_int = 0;
        let mut iNums: OSS_INT = 0 as libc::c_int;
        let mut ack: [OSS_BYTE; 512] = [0; 512];
        iNums = 516 as libc::c_int;
        iFromLen = ::core::mem::size_of::<SOCKADDR_IN>() as libc::c_ulong as libc::c_int;
        sdwResult = recvfrom(
            iSvrSocket,
            ptData as *mut libc::c_void,
            iNums as size_t,
            0 as libc::c_int,
            __SOCKADDR_ARG {
                __sockaddr_in__: &mut tFromAddr as *mut SOCKADDR_IN as *mut libc::c_void
                    as *mut SOCKADDR as *mut sockaddr_in,
            },
            &mut iFromLen as *mut libc::c_int as *mut socklen_t,
        ) as OSS_SWORD32;
        if 0xffff as libc::c_int == sdwResult {
            zte_printf_s(
                b"recvfrom is error! errno = %d\0" as *const u8 as *const libc::c_char,
                sdwResult,
            );
            return 0 as libc::c_int as OSS_WORD32;
        }
        let _ = gdwTftpSvrDebug == 1 as libc::c_int as libc::c_uint;
        if PortIpCheck(pBox, iTaskNum, ack.as_mut_ptr(), tFromAddr, client, iSvrSocket)
            == 0 as libc::c_int as libc::c_uint
        {
            return 0 as libc::c_int as OSS_WORD32;
        }
        if sdwResult > iNums {
            zte_printf_s(
                b"Length reterned from recvfrom is Longer than iNums! sdwResult = %d, iNums = %d\0"
                    as *const u8 as *const libc::c_char,
                sdwResult,
                iNums,
            );
            return 0 as libc::c_int as OSS_WORD32;
        }
        return sdwResult as OSS_WORD32;
    }
}
#[unsafe(no_mangle)]
pub unsafe extern "C" fn SendAck(
    mut ptData: *mut OSS_BYTE,
    mut iSvrSocket: OSS_INT,
    mut iClient: SOCKADDR_IN,
) -> OSS_BOOL {
    unsafe {
        let mut SendBuf: [OSS_BYTE; 4] = [0; 4];
        let mut RcvBuf: [OSS_BYTE; 4] = [0; 4];
        encapsulationOfZte_memset_s(
            SendBuf.as_mut_ptr() as *mut libc::c_void,
            4 as libc::c_int as rsize_t,
            0 as libc::c_int,
            4 as libc::c_int as rsize_t,
            b"Errlog.csv\0"
                as *const u8 as *const libc::c_char,
            1509 as libc::c_int,
        );
        SendBuf[1 as libc::c_int as usize] = 4 as libc::c_int as OSS_BYTE;
        if !ptData.is_null() {
            encapsulationOfZte_memcpy_s(
                RcvBuf.as_mut_ptr() as *mut libc::c_void,
                4 as libc::c_int as rsize_t,
                ptData as *const libc::c_void,
                4 as libc::c_int as rsize_t,
                b"Errlog.csv\0"
                    as *const u8 as *const libc::c_char,
                1513 as libc::c_int,
            );
            SendBuf[2 as libc::c_int as usize] = RcvBuf[2 as libc::c_int as usize];
            SendBuf[3 as libc::c_int as usize] = RcvBuf[3 as libc::c_int as usize];
        }
        if sendto(
            iSvrSocket,
            SendBuf.as_mut_ptr() as *const libc::c_void,
            4 as libc::c_int as size_t,
            0 as libc::c_int,
            __CONST_SOCKADDR_ARG {
                __sockaddr__: &mut iClient as *mut SOCKADDR_IN as *mut libc::c_void
                    as *mut sockaddr,
            },
            ::core::mem::size_of::<SOCKADDR_IN>() as libc::c_ulong as socklen_t,
        ) != 4 as libc::c_int as libc::c_long
        {
            zte_printf_s(b"ACK wrong\n\0" as *const u8 as *const libc::c_char);
            return 0 as libc::c_int as OSS_BOOL;
        } else {
            if gdwTftpSvrDebug == 1 as libc::c_int as libc::c_uint {
                zte_printf_s(
                    b"The Server has sent an ACK for req packet\n\0" as *const u8
                        as *const libc::c_char,
                );
            }
            return 1 as libc::c_int as OSS_BOOL;
        };
    }
}
#[unsafe(no_mangle)]
pub unsafe extern "C" fn PortIpCheck(
    mut pBox: *mut reqReci,
    mut _iTaskNum: OSS_WORD16,
    mut ackbuf: *mut OSS_BYTE,
    mut data: SOCKADDR_IN,
    mut client: SOCKADDR_IN,
    mut iRevSock: OSS_INT,
) -> OSS_BOOL {
    unsafe {
        let mut tid: OSS_WORD32 = 0 as libc::c_int as OSS_WORD32;
        let mut dwip: OSS_WORD32 = 0 as libc::c_int as OSS_WORD32;
        let mut len: OSS_INT = 0 as libc::c_int;
        tid = (*pBox).clientPort;
        dwip = (*pBox).clientIp;
        if tid != ntohs(data.sin_port) as libc::c_uint {
            if gdwTftpSvrDebug == 1 as libc::c_int as libc::c_uint {
                zte_printf_s(
                    b"Error recieving file (data from invalid tid)\n\0" as *const u8
                        as *const libc::c_char,
                );
            }
            len = snprintf_s(
                ackbuf as *mut libc::c_char,
                100 as libc::c_int as rsize_t,
                b"%c%c%c%cBad/Unknown TID%c\0" as *const u8 as *const libc::c_char,
                0 as libc::c_int,
                0x5 as libc::c_int,
                0 as libc::c_int,
                0x5 as libc::c_int,
                0 as libc::c_int,
            );
            if sendto(
                iRevSock,
                ackbuf as *const libc::c_void,
                len as size_t,
                0 as libc::c_int,
                __CONST_SOCKADDR_ARG {
                    __sockaddr__: &mut client as *mut SOCKADDR_IN as *mut libc::c_void
                        as *mut sockaddr,
                },
                ::core::mem::size_of::<SOCKADDR_IN>() as libc::c_ulong as socklen_t,
            ) != len as libc::c_long
            {
                zte_printf_s(b"Mismatch in TID\n\0" as *const u8 as *const libc::c_char);
            }
            return 0 as libc::c_int as OSS_BOOL;
        }
        if dwip != data.sin_addr.s_addr {
            if gdwTftpSvrDebug == 0 as libc::c_int as libc::c_uint {
                zte_printf_s(
                    b"TftpGetInfoFromClient: Error recieving file (data from invalid address)\n\0"
                        as *const u8 as *const libc::c_char,
                );
            }
            return 0 as libc::c_int as OSS_BOOL;
        }
        return 1 as libc::c_int as OSS_BOOL;
    }
}
#[unsafe(no_mangle)]
pub unsafe extern "C" fn SendData(
    mut pFData: *mut FILE,
    mut iSendSocket: OSS_INT,
    mut iClient: SOCKADDR_IN,
    mut dwCount: OSS_WORD32,
    mut byResendbuf: *mut OSS_BYTE,
    mut piResendSize: *mut OSS_INT,
    mut blksize: OSS_WORD16,
) -> OSS_INT {
    unsafe {
        let mut packetbuf: *mut OSS_BYTE = malloc(
            (blksize as libc::c_int + 4 as libc::c_int) as libc::c_ulong,
        ) as *mut libc::c_uchar;
        let mut sendSize: OSS_INT = 0 as libc::c_int;
        let mut iDataLen: OSS_INT = 0 as libc::c_int;
        let mut RetVal: OSS_INT = 0 as libc::c_int;
        if packetbuf.is_null() {
            return 0 as libc::c_int;
        }
        encapsulationOfZte_memset_s(
            packetbuf as *mut libc::c_void,
            (blksize as libc::c_int + 4 as libc::c_int) as rsize_t,
            0 as libc::c_int,
            (blksize as libc::c_int + 4 as libc::c_int) as rsize_t,
            b"Errlog.csv\0"
                as *const u8 as *const libc::c_char,
            1593 as libc::c_int,
        );
        RetVal = snprintf_s(
            packetbuf as *mut libc::c_char,
            blksize as rsize_t,
            b"%c%c%c%c\0" as *const u8 as *const libc::c_char,
            0 as libc::c_int,
            0x3 as libc::c_int,
            0 as libc::c_int,
            0 as libc::c_int,
        );
        if RetVal < 0 as libc::c_int {
            zte_printf_s(
                b"%s line:%d sprintf error!!!\n\0" as *const u8 as *const libc::c_char,
                (*::core::mem::transmute::<&[u8; 9], &[libc::c_char; 9]>(b"SendData\0"))
                    .as_ptr(),
                1599 as libc::c_int,
            );
            free(packetbuf as *mut libc::c_void);
            packetbuf = 0 as *mut OSS_BYTE;
            return -(1 as libc::c_int);
        }
        *packetbuf
            .offset(
                2 as libc::c_int as isize,
            ) = ((dwCount & 0xff00 as libc::c_int as libc::c_uint) >> 8 as libc::c_int)
            as OSS_BYTE;
        *packetbuf
            .offset(
                3 as libc::c_int as isize,
            ) = (dwCount & 0xff as libc::c_int as libc::c_uint) as OSS_BYTE;
        sendSize = fread(
            packetbuf.offset(4 as libc::c_int as isize) as *mut libc::c_void,
            1 as libc::c_int as libc::c_ulong,
            blksize as libc::c_ulong,
            pFData,
        ) as OSS_INT;
        if sendSize == 0 as libc::c_int {
            zte_printf_s(
                b"%s line:%d fread end!!!\n\0" as *const u8 as *const libc::c_char,
                (*::core::mem::transmute::<&[u8; 9], &[libc::c_char; 9]>(b"SendData\0"))
                    .as_ptr(),
                1610 as libc::c_int,
            );
        }
        iDataLen = 4 as libc::c_int + sendSize;
        if iDataLen >= 0 as libc::c_int {
            encapsulationOfZte_memcpy_s(
                byResendbuf as *mut libc::c_void,
                iDataLen as rsize_t,
                packetbuf as *const libc::c_void,
                iDataLen as rsize_t,
                b"Errlog.csv\0"
                    as *const u8 as *const libc::c_char,
                1616 as libc::c_int,
            );
        }
        *piResendSize = iDataLen;
        if sendto(
            iSendSocket,
            packetbuf as *const libc::c_void,
            iDataLen as size_t,
            0 as libc::c_int,
            __CONST_SOCKADDR_ARG {
                __sockaddr__: &mut iClient as *mut SOCKADDR_IN as *mut libc::c_void
                    as *mut sockaddr,
            },
            ::core::mem::size_of::<SOCKADDR_IN>() as libc::c_ulong as socklen_t,
        ) != iDataLen as libc::c_long
        {
            zte_printf_s(
                b"Mismatch in number of sent bytes\n\0" as *const u8 as *const libc::c_char,
            );
            free(packetbuf as *mut libc::c_void);
            packetbuf = 0 as *mut OSS_BYTE;
            return 0 as libc::c_int;
        }
        if gdwTftpSvrDebug == 1 as libc::c_int as libc::c_uint {
            zte_printf_s(
                b"Sending data packet # %04d (length: %d file chunk: %d)\n\0" as *const u8
                    as *const libc::c_char,
                dwCount,
                iDataLen,
                sendSize,
            );
            zte_printf_s(
                b"send to the IP of the client IP -PORT(IP: %d  port: %d )\n\0" as *const u8
                    as *const libc::c_char,
                iClient.sin_addr.s_addr,
                iClient.sin_port as libc::c_int,
            );
        }
        if sendSize < blksize as libc::c_int {
            zte_printf_s(
                b"this is the last data packet\n\0" as *const u8 as *const libc::c_char,
            );
            free(packetbuf as *mut libc::c_void);
            packetbuf = 0 as *mut OSS_BYTE;
            return -(1 as libc::c_int);
        }
        free(packetbuf as *mut libc::c_void);
        packetbuf = 0 as *mut OSS_BYTE;
        return sendSize;
    }
}
#[unsafe(no_mangle)]
pub unsafe extern "C" fn TimeOutSendData(
    mut packetbuf: *mut OSS_BYTE,
    mut iDataLen: OSS_INT,
    mut iSendSocket: OSS_INT,
    mut iClient: SOCKADDR_IN,
    mut dwCount: OSS_WORD32,
    mut blksize: OSS_WORD16,
) -> OSS_INT {
    unsafe {
        if packetbuf.is_null() {
            zte_printf_s(b"point is NULL\n\0" as *const u8 as *const libc::c_char);
            return 0 as libc::c_int;
        }
        if sendto(
            iSendSocket,
            packetbuf as *const libc::c_void,
            iDataLen as size_t,
            0 as libc::c_int,
            __CONST_SOCKADDR_ARG {
                __sockaddr__: &mut iClient as *mut SOCKADDR_IN as *mut libc::c_void
                    as *mut sockaddr,
            },
            ::core::mem::size_of::<SOCKADDR_IN>() as libc::c_ulong as socklen_t,
        ) != iDataLen as libc::c_long
        {
            zte_printf_s(
                b"Mismatch in number of sent bytes\n\0" as *const u8 as *const libc::c_char,
            );
            return 0 as libc::c_int;
        }
        if gdwTftpSvrDebug == 1 as libc::c_int as libc::c_uint {
            zte_printf_s(
                b"Sending data packet # %04ld (length: %d )\n\0" as *const u8
                    as *const libc::c_char,
                dwCount,
                iDataLen - 4 as libc::c_int,
            );
            zte_printf_s(
                b"send to the IP of the client IP -PORT(IP: %ld  port: %d )\n\0" as *const u8
                    as *const libc::c_char,
                iClient.sin_addr.s_addr,
                iClient.sin_port as libc::c_int,
            );
        }
        if (iDataLen - 4 as libc::c_int) < blksize as libc::c_int {
            zte_printf_s(
                b"this is the last data packet\n\0" as *const u8 as *const libc::c_char,
            );
            return -(1 as libc::c_int);
        }
        return iDataLen - 4 as libc::c_int;
    }
}
#[unsafe(no_mangle)]
pub unsafe extern "C" fn SetTftpServerPath(mut cPath: *const libc::c_char) -> INT32 {
    unsafe {
        let mut snpRet: libc::c_int = 0;
        if (25 as libc::c_int)
            < encapsulationOfZte_strnlen_s(
                cPath,
                100 as libc::c_int as rsize_t,
                b"Errlog.csv\0"
                    as *const u8 as *const libc::c_char,
                1694 as libc::c_int,
            )
            || 1 as libc::c_int
                > encapsulationOfZte_strnlen_s(
                    cPath,
                    100 as libc::c_int as rsize_t,
                    b"Errlog.csv\0"
                        as *const u8 as *const libc::c_char,
                    1694 as libc::c_int,
                )
        {
            zte_printf_s(
                b"Input string should be less than 25 bytes, more than 1 bytes! Length of input string is %d\n\0"
                    as *const u8 as *const libc::c_char,
                encapsulationOfZte_strnlen_s(
                    cPath,
                    100 as libc::c_int as rsize_t,
                    b"Errlog.csv\0"
                        as *const u8 as *const libc::c_char,
                    1696 as libc::c_int,
                ),
            );
            return -(1 as libc::c_int);
        }
        // 复制路径到全局变量
        snpRet = snprintf_s(
            ::core::ptr::addr_of_mut!(TftpServerPath) as *mut OSS_CHAR,
            ::core::mem::size_of::<[OSS_CHAR; 25]>() as libc::c_ulong,
            b"%s\0\0" as *const u8 as *const libc::c_char,
            cPath,
        );
        if snpRet < 0 as libc::c_int
            || snpRet as libc::c_ulong
                > ::core::mem::size_of::<[OSS_CHAR; 25]>() as libc::c_ulong
        {
            zte_printf_s(
                b"%s snp ret:%d!!!\n\0" as *const u8 as *const libc::c_char,
                (*::core::mem::transmute::<
                    &[u8; 18],
                    &[libc::c_char; 18],
                >(b"SetTftpServerPath\0"))
                    .as_ptr(),
                snpRet,
            );
        }
        zte_printf_s(
            b"TftpServerPath change to: %s\n\0" as *const u8 as *const libc::c_char,
            ::core::ptr::addr_of_mut!(TftpServerPath) as *mut OSS_CHAR,
        );
        return 0 as libc::c_int;
    }
}
#[unsafe(no_mangle)]
pub unsafe extern "C" fn BspStartTftpServerInit() -> UINT32 {
    unsafe {
        let mut tftpSvrPath: *const libc::c_char = b"/tmp/\0" as *const u8
            as *const libc::c_char;
        tftpServerStartUp();
        BspMkdir(tftpSvrPath);
        SetTftpServerPath(tftpSvrPath);
        BspSetTftpTaskPriority(77 as libc::c_int);
        return 0 as libc::c_int as UINT32;
    }
}
/* Ended by AICoder, pid:z690dtea69u4588140640a1d24c971907431cd14 */
#![allow(
    dead_code,
    mutable_transmutes,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    unused_assignments,
    unused_mut
)]
unsafe extern "C" {
    fn strcmp(_: *const libc::c_char, _: *const libc::c_char) -> libc::c_int;
    fn encapsulationOfZte_strncpy_s(
        s1: *mut libc::c_char,
        s1max: rsize_t,
        s2: *const libc::c_char,
        n: rsize_t,
        fileName: *const libc::c_char,
        lineNo: libc::c_int,
    ) -> libc::c_int;
    fn BspGetReservedMemAddr(ucModuleId: UCHAR) -> libc::c_ulong;
    fn mzprnL(
        ulModuleNo: libc::c_ulong,
        ulLevel: libc::c_ulong,
        pbFmt: *const libc::c_char,
        _: ...
    ) -> libc::c_int;
}
pub type size_t = libc::c_ulong;
pub type UCHAR = libc::c_uchar;
pub type CHAR = libc::c_char;
pub type UINT32 = libc::c_uint;
pub type rsize_t = size_t;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct T_BspPowerOnTick {
    pub string: [libc::c_char; 64],
    pub ticks: UINT32,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct T_BootPowerOnTick {
    pub string: [libc::c_char; 12],
    pub ticks: UINT32,
}
pub type FUNC_BOOT_GET_TICK = Option::<
    unsafe extern "C" fn(UINT32, *mut libc::c_char, UINT32, *mut UINT32) -> UINT32,
>;

pub static mut s_BspPowerOnTick: [T_BspPowerOnTick; 80] = unsafe {
    [
        {
            let mut init = T_BspPowerOnTick {
                string: *::core::mem::transmute::<
                    &[u8; 64],
                    &mut [libc::c_char; 64],
                >(
                    b"BspBoardInitEnd\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0",
                ),
                ticks: 0 as libc::c_int as UINT32,
            };
            init
        },
        T_BspPowerOnTick {
            string: [0; 64],
            ticks: 0,
        },
        T_BspPowerOnTick {
            string: [0; 64],
            ticks: 0,
        },
        T_BspPowerOnTick {
            string: [0; 64],
            ticks: 0,
        },
        T_BspPowerOnTick {
            string: [0; 64],
            ticks: 0,
        },
        T_BspPowerOnTick {
            string: [0; 64],
            ticks: 0,
        },
        T_BspPowerOnTick {
            string: [0; 64],
            ticks: 0,
        },
        T_BspPowerOnTick {
            string: [0; 64],
            ticks: 0,
        },
        T_BspPowerOnTick {
            string: [0; 64],
            ticks: 0,
        },
        T_BspPowerOnTick {
            string: [0; 64],
            ticks: 0,
        },
        T_BspPowerOnTick {
            string: [0; 64],
            ticks: 0,
        },
        T_BspPowerOnTick {
            string: [0; 64],
            ticks: 0,
        },
        T_BspPowerOnTick {
            string: [0; 64],
            ticks: 0,
        },
        T_BspPowerOnTick {
            string: [0; 64],
            ticks: 0,
        },
        T_BspPowerOnTick {
            string: [0; 64],
            ticks: 0,
        },
        T_BspPowerOnTick {
            string: [0; 64],
            ticks: 0,
        },
        T_BspPowerOnTick {
            string: [0; 64],
            ticks: 0,
        },
        T_BspPowerOnTick {
            string: [0; 64],
            ticks: 0,
        },
        T_BspPowerOnTick {
            string: [0; 64],
            ticks: 0,
        },
        T_BspPowerOnTick {
            string: [0; 64],
            ticks: 0,
        },
        T_BspPowerOnTick {
            string: [0; 64],
            ticks: 0,
        },
        T_BspPowerOnTick {
            string: [0; 64],
            ticks: 0,
        },
        T_BspPowerOnTick {
            string: [0; 64],
            ticks: 0,
        },
        T_BspPowerOnTick {
            string: [0; 64],
            ticks: 0,
        },
        T_BspPowerOnTick {
            string: [0; 64],
            ticks: 0,
        },
        T_BspPowerOnTick {
            string: [0; 64],
            ticks: 0,
        },
        T_BspPowerOnTick {
            string: [0; 64],
            ticks: 0,
        },
        T_BspPowerOnTick {
            string: [0; 64],
            ticks: 0,
        },
        T_BspPowerOnTick {
            string: [0; 64],
            ticks: 0,
        },
        T_BspPowerOnTick {
            string: [0; 64],
            ticks: 0,
        },
        T_BspPowerOnTick {
            string: [0; 64],
            ticks: 0,
        },
        T_BspPowerOnTick {
            string: [0; 64],
            ticks: 0,
        },
        T_BspPowerOnTick {
            string: [0; 64],
            ticks: 0,
        },
        T_BspPowerOnTick {
            string: [0; 64],
            ticks: 0,
        },
        T_BspPowerOnTick {
            string: [0; 64],
            ticks: 0,
        },
        T_BspPowerOnTick {
            string: [0; 64],
            ticks: 0,
        },
        T_BspPowerOnTick {
            string: [0; 64],
            ticks: 0,
        },
        T_BspPowerOnTick {
            string: [0; 64],
            ticks: 0,
        },
        T_BspPowerOnTick {
            string: [0; 64],
            ticks: 0,
        },
        T_BspPowerOnTick {
            string: [0; 64],
            ticks: 0,
        },
        T_BspPowerOnTick {
            string: [0; 64],
            ticks: 0,
        },
        T_BspPowerOnTick {
            string: [0; 64],
            ticks: 0,
        },
        T_BspPowerOnTick {
            string: [0; 64],
            ticks: 0,
        },
        T_BspPowerOnTick {
            string: [0; 64],
            ticks: 0,
        },
        T_BspPowerOnTick {
            string: [0; 64],
            ticks: 0,
        },
        T_BspPowerOnTick {
            string: [0; 64],
            ticks: 0,
        },
        T_BspPowerOnTick {
            string: [0; 64],
            ticks: 0,
        },
        T_BspPowerOnTick {
            string: [0; 64],
            ticks: 0,
        },
        T_BspPowerOnTick {
            string: [0; 64],
            ticks: 0,
        },
        T_BspPowerOnTick {
            string: [0; 64],
            ticks: 0,
        },
        T_BspPowerOnTick {
            string: [0; 64],
            ticks: 0,
        },
        T_BspPowerOnTick {
            string: [0; 64],
            ticks: 0,
        },
        T_BspPowerOnTick {
            string: [0; 64],
            ticks: 0,
        },
        T_BspPowerOnTick {
            string: [0; 64],
            ticks: 0,
        },
        T_BspPowerOnTick {
            string: [0; 64],
            ticks: 0,
        },
        T_BspPowerOnTick {
            string: [0; 64],
            ticks: 0,
        },
        T_BspPowerOnTick {
            string: [0; 64],
            ticks: 0,
        },
        T_BspPowerOnTick {
            string: [0; 64],
            ticks: 0,
        },
        T_BspPowerOnTick {
            string: [0; 64],
            ticks: 0,
        },
        T_BspPowerOnTick {
            string: [0; 64],
            ticks: 0,
        },
        T_BspPowerOnTick {
            string: [0; 64],
            ticks: 0,
        },
        T_BspPowerOnTick {
            string: [0; 64],
            ticks: 0,
        },
        T_BspPowerOnTick {
            string: [0; 64],
            ticks: 0,
        },
        T_BspPowerOnTick {
            string: [0; 64],
            ticks: 0,
        },
        T_BspPowerOnTick {
            string: [0; 64],
            ticks: 0,
        },
        T_BspPowerOnTick {
            string: [0; 64],
            ticks: 0,
        },
        T_BspPowerOnTick {
            string: [0; 64],
            ticks: 0,
        },
        T_BspPowerOnTick {
            string: [0; 64],
            ticks: 0,
        },
        T_BspPowerOnTick {
            string: [0; 64],
            ticks: 0,
        },
        T_BspPowerOnTick {
            string: [0; 64],
            ticks: 0,
        },
        T_BspPowerOnTick {
            string: [0; 64],
            ticks: 0,
        },
        T_BspPowerOnTick {
            string: [0; 64],
            ticks: 0,
        },
        T_BspPowerOnTick {
            string: [0; 64],
            ticks: 0,
        },
        T_BspPowerOnTick {
            string: [0; 64],
            ticks: 0,
        },
        T_BspPowerOnTick {
            string: [0; 64],
            ticks: 0,
        },
        T_BspPowerOnTick {
            string: [0; 64],
            ticks: 0,
        },
        T_BspPowerOnTick {
            string: [0; 64],
            ticks: 0,
        },
        T_BspPowerOnTick {
            string: [0; 64],
            ticks: 0,
        },
        T_BspPowerOnTick {
            string: [0; 64],
            ticks: 0,
        },
        T_BspPowerOnTick {
            string: [0; 64],
            ticks: 0,
        },
    ]
};

pub static mut s_Dra62xBootPowerOnTick: [T_BootPowerOnTick; 80] = unsafe {
    [
        {
            let mut init = T_BootPowerOnTick {
                string: *::core::mem::transmute::<
                    &[u8; 12],
                    &mut [libc::c_char; 12],
                >(b"B_K_FINI\0\0\0\0"),
                ticks: (70 as libc::c_int * 100 as libc::c_int) as UINT32,
            };
            init
        },
        T_BootPowerOnTick {
            string: [0; 12],
            ticks: 0,
        },
        T_BootPowerOnTick {
            string: [0; 12],
            ticks: 0,
        },
        T_BootPowerOnTick {
            string: [0; 12],
            ticks: 0,
        },
        T_BootPowerOnTick {
            string: [0; 12],
            ticks: 0,
        },
        T_BootPowerOnTick {
            string: [0; 12],
            ticks: 0,
        },
        T_BootPowerOnTick {
            string: [0; 12],
            ticks: 0,
        },
        T_BootPowerOnTick {
            string: [0; 12],
            ticks: 0,
        },
        T_BootPowerOnTick {
            string: [0; 12],
            ticks: 0,
        },
        T_BootPowerOnTick {
            string: [0; 12],
            ticks: 0,
        },
        T_BootPowerOnTick {
            string: [0; 12],
            ticks: 0,
        },
        T_BootPowerOnTick {
            string: [0; 12],
            ticks: 0,
        },
        T_BootPowerOnTick {
            string: [0; 12],
            ticks: 0,
        },
        T_BootPowerOnTick {
            string: [0; 12],
            ticks: 0,
        },
        T_BootPowerOnTick {
            string: [0; 12],
            ticks: 0,
        },
        T_BootPowerOnTick {
            string: [0; 12],
            ticks: 0,
        },
        T_BootPowerOnTick {
            string: [0; 12],
            ticks: 0,
        },
        T_BootPowerOnTick {
            string: [0; 12],
            ticks: 0,
        },
        T_BootPowerOnTick {
            string: [0; 12],
            ticks: 0,
        },
        T_BootPowerOnTick {
            string: [0; 12],
            ticks: 0,
        },
        T_BootPowerOnTick {
            string: [0; 12],
            ticks: 0,
        },
        T_BootPowerOnTick {
            string: [0; 12],
            ticks: 0,
        },
        T_BootPowerOnTick {
            string: [0; 12],
            ticks: 0,
        },
        T_BootPowerOnTick {
            string: [0; 12],
            ticks: 0,
        },
        T_BootPowerOnTick {
            string: [0; 12],
            ticks: 0,
        },
        T_BootPowerOnTick {
            string: [0; 12],
            ticks: 0,
        },
        T_BootPowerOnTick {
            string: [0; 12],
            ticks: 0,
        },
        T_BootPowerOnTick {
            string: [0; 12],
            ticks: 0,
        },
        T_BootPowerOnTick {
            string: [0; 12],
            ticks: 0,
        },
        T_BootPowerOnTick {
            string: [0; 12],
            ticks: 0,
        },
        T_BootPowerOnTick {
            string: [0; 12],
            ticks: 0,
        },
        T_BootPowerOnTick {
            string: [0; 12],
            ticks: 0,
        },
        T_BootPowerOnTick {
            string: [0; 12],
            ticks: 0,
        },
        T_BootPowerOnTick {
            string: [0; 12],
            ticks: 0,
        },
        T_BootPowerOnTick {
            string: [0; 12],
            ticks: 0,
        },
        T_BootPowerOnTick {
            string: [0; 12],
            ticks: 0,
        },
        T_BootPowerOnTick {
            string: [0; 12],
            ticks: 0,
        },
        T_BootPowerOnTick {
            string: [0; 12],
            ticks: 0,
        },
        T_BootPowerOnTick {
            string: [0; 12],
            ticks: 0,
        },
        T_BootPowerOnTick {
            string: [0; 12],
            ticks: 0,
        },
        T_BootPowerOnTick {
            string: [0; 12],
            ticks: 0,
        },
        T_BootPowerOnTick {
            string: [0; 12],
            ticks: 0,
        },
        T_BootPowerOnTick {
            string: [0; 12],
            ticks: 0,
        },
        T_BootPowerOnTick {
            string: [0; 12],
            ticks: 0,
        },
        T_BootPowerOnTick {
            string: [0; 12],
            ticks: 0,
        },
        T_BootPowerOnTick {
            string: [0; 12],
            ticks: 0,
        },
        T_BootPowerOnTick {
            string: [0; 12],
            ticks: 0,
        },
        T_BootPowerOnTick {
            string: [0; 12],
            ticks: 0,
        },
        T_BootPowerOnTick {
            string: [0; 12],
            ticks: 0,
        },
        T_BootPowerOnTick {
            string: [0; 12],
            ticks: 0,
        },
        T_BootPowerOnTick {
            string: [0; 12],
            ticks: 0,
        },
        T_BootPowerOnTick {
            string: [0; 12],
            ticks: 0,
        },
        T_BootPowerOnTick {
            string: [0; 12],
            ticks: 0,
        },
        T_BootPowerOnTick {
            string: [0; 12],
            ticks: 0,
        },
        T_BootPowerOnTick {
            string: [0; 12],
            ticks: 0,
        },
        T_BootPowerOnTick {
            string: [0; 12],
            ticks: 0,
        },
        T_BootPowerOnTick {
            string: [0; 12],
            ticks: 0,
        },
        T_BootPowerOnTick {
            string: [0; 12],
            ticks: 0,
        },
        T_BootPowerOnTick {
            string: [0; 12],
            ticks: 0,
        },
        T_BootPowerOnTick {
            string: [0; 12],
            ticks: 0,
        },
        T_BootPowerOnTick {
            string: [0; 12],
            ticks: 0,
        },
        T_BootPowerOnTick {
            string: [0; 12],
            ticks: 0,
        },
        T_BootPowerOnTick {
            string: [0; 12],
            ticks: 0,
        },
        T_BootPowerOnTick {
            string: [0; 12],
            ticks: 0,
        },
        T_BootPowerOnTick {
            string: [0; 12],
            ticks: 0,
        },
        T_BootPowerOnTick {
            string: [0; 12],
            ticks: 0,
        },
        T_BootPowerOnTick {
            string: [0; 12],
            ticks: 0,
        },
        T_BootPowerOnTick {
            string: [0; 12],
            ticks: 0,
        },
        T_BootPowerOnTick {
            string: [0; 12],
            ticks: 0,
        },
        T_BootPowerOnTick {
            string: [0; 12],
            ticks: 0,
        },
        T_BootPowerOnTick {
            string: [0; 12],
            ticks: 0,
        },
        T_BootPowerOnTick {
            string: [0; 12],
            ticks: 0,
        },
        T_BootPowerOnTick {
            string: [0; 12],
            ticks: 0,
        },
        T_BootPowerOnTick {
            string: [0; 12],
            ticks: 0,
        },
        T_BootPowerOnTick {
            string: [0; 12],
            ticks: 0,
        },
        T_BootPowerOnTick {
            string: [0; 12],
            ticks: 0,
        },
        T_BootPowerOnTick {
            string: [0; 12],
            ticks: 0,
        },
        T_BootPowerOnTick {
            string: [0; 12],
            ticks: 0,
        },
        T_BootPowerOnTick {
            string: [0; 12],
            ticks: 0,
        },
        T_BootPowerOnTick {
            string: [0; 12],
            ticks: 0,
        },
    ]
};

pub static mut g_ulPowerOnIndex: UINT32 = 0 as libc::c_int as UINT32;

pub static mut pBootPowerOnTickFunc: FUNC_BOOT_GET_TICK = None;

pub unsafe extern "C" fn BspGetNxpBootPowerOnTcicks(
    mut index: UINT32,
    mut pString: *mut libc::c_char,
    mut len: UINT32,
    mut pTicks: *mut UINT32,
) -> UINT32 {
    let mut nxpBootTicks: *mut T_BootPowerOnTick = 0 as *mut T_BootPowerOnTick;
    if index > 64 as libc::c_int as libc::c_uint || pString.is_null() || pTicks.is_null()
    {
        mzprnL(
            0x1 as libc::c_int as libc::c_ulong,
            0xffff as libc::c_int as libc::c_ulong,
            b"%s %d index %d error\n\0" as *const u8 as *const libc::c_char,
            (*::core::mem::transmute::<
                &[u8; 27],
                &[libc::c_char; 27],
            >(b"BspGetNxpBootPowerOnTcicks\0"))
                .as_ptr(),
            69 as libc::c_int,
            index,
        );
        return 0xffffffff as libc::c_uint;
    }
    nxpBootTicks = (BspGetReservedMemAddr(0 as libc::c_int as UCHAR))
        .wrapping_add(0x8000 as libc::c_int as libc::c_ulong)
        .wrapping_add(
            ((12 as libc::c_int + 4 as libc::c_int) as libc::c_uint).wrapping_mul(index)
                as libc::c_ulong,
        ) as *mut CHAR as *mut T_BootPowerOnTick;
    encapsulationOfZte_strncpy_s(
        pString,
        len as rsize_t,
        ((*nxpBootTicks).string).as_mut_ptr(),
        12 as libc::c_int as rsize_t,
        b"/home/10334704/yccrust/bsp/platform/bsp/softlib/timerecord/source/timerecord.c\0"
            as *const u8 as *const libc::c_char,
        74 as libc::c_int,
    );
    *pTicks = (*nxpBootTicks).ticks;
    return 0 as libc::c_int as UINT32;
}

pub unsafe extern "C" fn BspGetDra62xBootPowerOnTcicks(
    mut index: UINT32,
    mut pString: *mut libc::c_char,
    mut len: UINT32,
    mut pTicks: *mut UINT32,
) -> UINT32 {
    if pString.is_null() || pTicks.is_null() {
        mzprnL(
            0x1 as libc::c_int as libc::c_ulong,
            0xffff as libc::c_int as libc::c_ulong,
            b"%s %d input para error\n\0" as *const u8 as *const libc::c_char,
            (*::core::mem::transmute::<
                &[u8; 30],
                &[libc::c_char; 30],
            >(b"BspGetDra62xBootPowerOnTcicks\0"))
                .as_ptr(),
            98 as libc::c_int,
        );
        return 0xffffffff as libc::c_uint;
    }
    encapsulationOfZte_strncpy_s(
        pString,
        len as rsize_t,
        (s_Dra62xBootPowerOnTick[0 as libc::c_int as usize].string).as_mut_ptr(),
        ::core::mem::size_of::<[libc::c_char; 12]>() as libc::c_ulong,
        b"/home/10334704/yccrust/bsp/platform/bsp/softlib/timerecord/source/timerecord.c\0"
            as *const u8 as *const libc::c_char,
        101 as libc::c_int,
    );
    *pTicks = s_Dra62xBootPowerOnTick[0 as libc::c_int as usize].ticks;
    return 0 as libc::c_int as UINT32;
}

pub unsafe extern "C" fn BspSetBootPowerOnTickCallBack(
    mut pCallBackFunc: FUNC_BOOT_GET_TICK,
) -> UINT32 {
    pBootPowerOnTickFunc = pCallBackFunc;
    return 0 as libc::c_int as UINT32;
}

pub unsafe extern "C" fn BspGetBootPowerOnTcicks(
    mut index: UINT32,
    mut pString: *mut libc::c_char,
    mut len: UINT32,
    mut pTicks: *mut UINT32,
) -> UINT32 {
	pBootPowerOnTickFunc
		.expect("non-null function pointer")(index, pString, len, pTicks);
    
    return 0 as libc::c_int as UINT32;
}

pub unsafe extern "C" fn BspSetUserPowerOnTicks(
    mut pString: *const libc::c_char,
    mut ticks: UINT32,
) -> UINT32 {
    if g_ulPowerOnIndex >= 80 as libc::c_int as libc::c_uint || pString.is_null() {
        mzprnL(
            0x1 as libc::c_int as libc::c_ulong,
            0xffff as libc::c_int as libc::c_ulong,
            b"%s %d input para error\n\0" as *const u8 as *const libc::c_char,
            (*::core::mem::transmute::<
                &[u8; 23],
                &[libc::c_char; 23],
            >(b"BspSetUserPowerOnTicks\0"))
                .as_ptr(),
            173 as libc::c_int,
        );
        return 0xffffffff as libc::c_uint;
    }
    encapsulationOfZte_strncpy_s(
        (s_BspPowerOnTick[g_ulPowerOnIndex as usize].string).as_mut_ptr(),
        64 as libc::c_int as rsize_t,
        pString,
        64 as libc::c_int as rsize_t,
        b"/home/10334704/yccrust/bsp/platform/bsp/softlib/timerecord/source/timerecord.c\0"
            as *const u8 as *const libc::c_char,
        177 as libc::c_int,
    );
    s_BspPowerOnTick[g_ulPowerOnIndex as usize].ticks = ticks;
    g_ulPowerOnIndex = g_ulPowerOnIndex.wrapping_add(1);
    g_ulPowerOnIndex;
    return 0 as libc::c_int as UINT32;
}

pub unsafe extern "C" fn BspGetUserPowerOnTcicks(
    mut index: UINT32,
    mut pString: *mut libc::c_char,
    mut len: UINT32,
    mut pTicks: *mut UINT32,
) -> UINT32 {
    if index >= 80 as libc::c_int as libc::c_uint || pString.is_null()
        || pTicks.is_null()
    {
        mzprnL(
            0x1 as libc::c_int as libc::c_ulong,
            0xffff as libc::c_int as libc::c_ulong,
            b"%s %d Input index %d error\n\0" as *const u8 as *const libc::c_char,
            (*::core::mem::transmute::<
                &[u8; 24],
                &[libc::c_char; 24],
            >(b"BspGetUserPowerOnTcicks\0"))
                .as_ptr(),
            201 as libc::c_int,
            index,
        );
        return 0xffffffff as libc::c_uint;
    }
    encapsulationOfZte_strncpy_s(
        pString,
        len as rsize_t,
        (s_BspPowerOnTick[index as usize].string).as_mut_ptr(),
        ::core::mem::size_of::<[libc::c_char; 64]>() as libc::c_ulong,
        b"/home/10334704/yccrust/bsp/platform/bsp/softlib/timerecord/source/timerecord.c\0"
            as *const u8 as *const libc::c_char,
        205 as libc::c_int,
    );
    *pTicks = s_BspPowerOnTick[index as usize].ticks;
    return 0 as libc::c_int as UINT32;
}

pub unsafe extern "C" fn BspGetPowerOnTicks(
    mut type_0: UINT32,
    mut index: UINT32,
    mut pString: *mut libc::c_char,
    mut len: UINT32,
    mut pTicks: *mut UINT32,
) -> UINT32 {
    match type_0 {
        0 => {
            BspGetBootPowerOnTcicks(index, pString, len, pTicks);
        }
        1 => {
            BspGetUserPowerOnTcicks(index, pString, len, pTicks);
        }
        _ => return 0xffffffff as libc::c_uint,
    }
    return 0 as libc::c_int as UINT32;
}

pub unsafe extern "C" fn showpoweronticks() {
    let mut index: UINT32 = 0 as libc::c_int as UINT32;
    let mut ticks: UINT32 = 0 as libc::c_int as UINT32;
    let mut string: [CHAR; 64] = [0; 64];
    mzprnL(
        0x1 as libc::c_int as libc::c_ulong,
        0x50 as libc::c_int as libc::c_ulong,
        b"BOOT POWER ON TICK INFO:\n\0" as *const u8 as *const libc::c_char,
    );
    index = 0 as libc::c_int as UINT32;
    while index < 64 as libc::c_int as libc::c_uint {
        BspGetPowerOnTicks(
            0 as libc::c_int as UINT32,
            index,
            string.as_mut_ptr(),
            64 as libc::c_int as UINT32,
            &mut ticks,
        );
        mzprnL(
            0x1 as libc::c_int as libc::c_ulong,
            0x50 as libc::c_int as libc::c_ulong,
            b"%s:ticks:%d(*10ms)\n\0" as *const u8 as *const libc::c_char,
            string.as_mut_ptr(),
            ticks,
        );
        if 0 as libc::c_int
            == strcmp(
                string.as_mut_ptr(),
                b"B_K_FINI\0" as *const u8 as *const libc::c_char,
            )
        {
            break;
        }
        index = index.wrapping_add(1);
        index;
    }
    mzprnL(
        0x1 as libc::c_int as libc::c_ulong,
        0x50 as libc::c_int as libc::c_ulong,
        b"BSP POWER ON TICK INFO:\n\0" as *const u8 as *const libc::c_char,
    );
    index = 0 as libc::c_int as UINT32;
    while index < 80 as libc::c_int as libc::c_uint {
        BspGetPowerOnTicks(
            1 as libc::c_int as UINT32,
            index,
            string.as_mut_ptr(),
            64 as libc::c_int as UINT32,
            &mut ticks,
        );
        mzprnL(
            0x1 as libc::c_int as libc::c_ulong,
            0x50 as libc::c_int as libc::c_ulong,
            b"%s:ticks:%d(*10ms)\n\0" as *const u8 as *const libc::c_char,
            string.as_mut_ptr(),
            ticks,
        );
        if 0 as libc::c_int
            == strcmp(
                string.as_mut_ptr(),
                b"BspBoardInitEnd\0" as *const u8 as *const libc::c_char,
            )
        {
            break;
        }
        index = index.wrapping_add(1);
        index;
    }
}






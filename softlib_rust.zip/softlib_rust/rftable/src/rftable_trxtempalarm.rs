#![allow(
    dead_code,
    mutable_transmutes,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    unused_assignments,
    unused_mut
)]

use ccommon::clib::*;
use std::ffi::CStr;

// mzprnL 函数声明已移除，使用 Rust 的 println! 和 eprintln! 替代
pub type size_t = libc::c_ulong;
pub type __off_t = libc::c_long;
pub type __off64_t = libc::c_long;
pub type _IO_lock_t = ();
pub type FILE = _IO_FILE;
pub type UCHAR = libc::c_uchar;
pub type CHAR = libc::c_char;
pub type UINT32 = libc::c_uint;
pub type UINT64 = libc::c_ulonglong;
pub type INT32 = libc::c_int;
pub type rsize_t = size_t;
pub type e_TblTypeDefine = libc::c_uint;
pub const NUM_TBL_KIND_NUM: e_TblTypeDefine = 65;
pub const TBL_KIND_OF_TXPHASE: e_TblTypeDefine = 64;
pub const TBL_KIND_OF_RXPHASE: e_TblTypeDefine = 63;
pub const TBL_KIND_OF_DELTRXGAIN: e_TblTypeDefine = 62;
pub const TBL_KIND_OF_DELTTXGAIN: e_TblTypeDefine = 61;
pub const TBL_KIND_OF_RFBRIDGE: e_TblTypeDefine = 60;
pub const TBL_KIND_OF_RxREV: e_TblTypeDefine = 59;
pub const TBL_KIND_OF_TXREVANALOG: e_TblTypeDefine = 58;
pub const TBL_KIND_OF_TXFWDANALOG: e_TblTypeDefine = 57;
pub const TBL_KIND_OF_DSAATT: e_TblTypeDefine = 56;
pub const TBL_KIND_OF_PMIPHASEINFO: e_TblTypeDefine = 55;
pub const TBL_KIND_OF_UDC: e_TblTypeDefine = 54;
pub const TBL_KIND_OF_DVGATEMPGAIN: e_TblTypeDefine = 53;
pub const TBL_KIND_OF_TxFWD_DB: e_TblTypeDefine = 52;
pub const TBL_KIND_OF_TXGAINERROR: e_TblTypeDefine = 51;
pub const TBL_KIND_OF_RX0DELAY: e_TblTypeDefine = 50;
pub const TBL_KIND_OF_ANTDELAY: e_TblTypeDefine = 49;
pub const TBL_KIND_OF_FILTERDELAY: e_TblTypeDefine = 48;
pub const TBL_KIND_OF_TXLOOKUPTAB: e_TblTypeDefine = 47;
pub const TBL_KIND_OF_RXLOOKUPTAB: e_TblTypeDefine = 46;
pub const TBL_KIND_OF_IDEALWBRFCODEBOOK: e_TblTypeDefine = 45;
pub const TBL_KIND_OF_IDEALNBRFCODEBOOK: e_TblTypeDefine = 44;
pub const TBL_KIND_OF_IDEALDVDHRFCODEBOOK: e_TblTypeDefine = 43;
pub const TBL_KIND_OF_IDEALAMPRFCODEBOOK: e_TblTypeDefine = 42;
pub const TBL_KIND_OF_IDEALACRFCODEBOOK: e_TblTypeDefine = 41;
pub const TBL_KIND_OF_RXISOCAL: e_TblTypeDefine = 40;
pub const TBL_KIND_OF_TXACCAL: e_TblTypeDefine = 39;
pub const TBL_KIND_OF_PAENSAVADJ: e_TblTypeDefine = 38;
pub const TBL_KIND_OF_PWRCALI: e_TblTypeDefine = 37;
pub const TBL_KIND_OF_SINGLECODEBOOK: e_TblTypeDefine = 36;
pub const TBL_KIND_OF_TXGAIN_HW: e_TblTypeDefine = 35;
pub const TBL_KIND_OF_TXOPENRL: e_TblTypeDefine = 34;
pub const TBL_KIND_OF_RXCALCODEBOOK: e_TblTypeDefine = 33;
pub const TBL_KIND_OF_TXCALCODEBOOK: e_TblTypeDefine = 32;
pub const TBL_KIND_OF_IDEALCODEBOOK: e_TblTypeDefine = 31;
pub const TBL_KIND_OF_MBAGAIN: e_TblTypeDefine = 30;
pub const TBL_KIND_OF_PACURRCALI: e_TblTypeDefine = 29;
pub const TBL_KIND_OF_PAURELATIVEPHASE: e_TblTypeDefine = 28;
pub const TBL_KIND_OF_PAURELATIVEAMP: e_TblTypeDefine = 27;
pub const TBL_KIND_OF_PAUPHASE: e_TblTypeDefine = 26;
pub const TBL_KIND_OF_PAUAMP: e_TblTypeDefine = 25;
pub const TBL_KIND_OF_FILTERGAIN: e_TblTypeDefine = 24;
pub const TBL_KIND_OF_CALGAIN: e_TblTypeDefine = 23;
pub const TBL_KIND_OF_CALPHASE: e_TblTypeDefine = 22;
pub const TBL_KIND_OF_PARL: e_TblTypeDefine = 21;
pub const TBL_KIND_OF_PAGAINTEMPTBL: e_TblTypeDefine = 20;
pub const TBL_KIND_OF_PADRAINADJ: e_TblTypeDefine = 19;
pub const TBL_KIND_OF_PABASICINFO: e_TblTypeDefine = 18;
pub const TBL_KIND_OF_RXAMPGAIN: e_TblTypeDefine = 17;
pub const TBL_KIND_OF_CPATT: e_TblTypeDefine = 16;
pub const TBL_KIND_OF_PWRTEMPALM: e_TblTypeDefine = 15;
pub const TBL_KIND_OF_TRXTEMPALM: e_TblTypeDefine = 14;
pub const TBL_KIND_OF_PATEMPALM: e_TblTypeDefine = 13;
pub const TBL_KIND_OF_TRXTEMPGAIN: e_TblTypeDefine = 12;
pub const TBL_KIND_OF_PATEMPGAIN: e_TblTypeDefine = 11;
pub const TBL_KIND_OF_PADACSET: e_TblTypeDefine = 10;
pub const TBL_KIND_OF_PAVOLTGAIN: e_TblTypeDefine = 9;
pub const TBL_KIND_OF_RXCALI: e_TblTypeDefine = 8;
pub const TBL_KIND_OF_RXRSSI: e_TblTypeDefine = 7;
pub const TBL_KIND_OF_VSWRPROC: e_TblTypeDefine = 6;
pub const TBL_KIND_OF_VSWRPARAM: e_TblTypeDefine = 5;
pub const TBL_KIND_OF_TXCALI: e_TblTypeDefine = 4;
pub const TBL_KIND_OF_TXIQ: e_TblTypeDefine = 3;
pub const TBL_KIND_OF_TxREV: e_TblTypeDefine = 2;
pub const TBL_KIND_OF_TxFWD: e_TblTypeDefine = 1;
pub const TBL_KIND_OF_TXGAIN: e_TblTypeDefine = 0;
pub type e_TblkeyWordPub = libc::c_uint;
pub const NUM_TBL_KW_PUB: e_TblkeyWordPub = 8;
pub const TBL_PUB_KW_END: e_TblkeyWordPub = 7;
pub const TBL_PUB_KW_PATHPROP: e_TblkeyWordPub = 6;
pub const TBL_PUB_KW_PATHNUM: e_TblkeyWordPub = 5;
pub const TBL_PUB_KW_CHECKER: e_TblkeyWordPub = 4;
pub const TBL_PUB_KW_OPERATOR: e_TblkeyWordPub = 3;
pub const TBL_PUB_KW_DATE: e_TblkeyWordPub = 2;
pub const TBL_PUB_KW_INFO: e_TblkeyWordPub = 1;
pub const TBL_PUB_KW_V: e_TblkeyWordPub = 0;
#[derive(Copy, Clone)]
#[repr(C, packed)]
pub struct tagT_adjTableHeader {
    pub ulVer: UINT32,
    pub ulPathNum: UINT32,
    pub aucInfo: [libc::c_char; 25],
    pub aucDate: [libc::c_char; 25],
    pub aucOperator: [libc::c_char; 25],
    pub aucChecker: [libc::c_char; 25],
}
pub type TCommHeader = tagT_adjTableHeader;
#[derive(Copy, Clone)]
#[repr(C, packed)]
pub struct tagT_TblInitParam {
    pub ulTxChanNum: UINT32,
    pub ulRxChanNum: UINT32,
    pub ulPaPhyNum: UINT32,
    pub ulSubNum: UINT32,
    pub lValMin: [INT32; 65],
    pub lValMax: [INT32; 65],
    pub ulCaliLoadPath: UINT32,
}
pub type T_CaliTblInitParam = tagT_TblInitParam;
pub type Execut_Func = Option::<
    unsafe extern "C" fn(*mut T_TextTrans, *const CHAR) -> UINT32,
>;
pub type Execut_FuncFlash = Option::<
    unsafe extern "C" fn(*const UCHAR, *mut CHAR, *mut UINT32) -> UINT32,
>;
#[derive(Copy, Clone)]
#[repr(C, packed)]
pub struct tagTblKeyWord {
    pub ulIndex: UINT32,
    pub ulVer: UINT32,
    pub aucKeyWord: [libc::c_char; 160],
    pub ucSearchOrderFlag: UCHAR,
    pub ucSearchResultFlag: UCHAR,
    pub pFunc: Execut_Func,
    pub pFuncFlash: Execut_FuncFlash,
}
pub type TTblKeyWord = tagTblKeyWord;
pub type eTrxTempThresholdType = libc::c_uint;
pub const E_TRXTEMP_THRESHOLD_NUM: eTrxTempThresholdType = 5;
pub const E_TRXTEMP_THRESHOLD_OVER_REC: eTrxTempThresholdType = 4;
pub const E_TRXTEMP_THRESHOLD_SLIGHTOVER_REC: eTrxTempThresholdType = 3;
pub const E_TRXTEMP_THRESHOLD_OVER: eTrxTempThresholdType = 2;
pub const E_TRXTEMP_THRESHOLD_SLIGHTOVER: eTrxTempThresholdType = 1;
pub const E_TRXTEMP_THRESHOLD_OFFSET: eTrxTempThresholdType = 0;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct tagT_TrxTempAlarmHeader {
    pub lWorkEnvTempUpper: INT32,
    pub lWorkEnvTempLower: INT32,
    pub lBoardTempNum: INT32,
    pub lBoardTempAlm: [INT32; 32],
}
pub type T_TrxTempAlarmHeader = tagT_TrxTempAlarmHeader;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct tagTrxTempAlarmData {
    pub tComHeader: TCommHeader,
    pub tHeader: T_TrxTempAlarmHeader,
    pub ulLoadFlag: UINT32,
}
pub type T_TrxTempAlarmData = tagTrxTempAlarmData;
pub const TBL_TRXTEMPALARM_KW_TEMPALM: e_TblkeyWordTrxTempAlarm = 3;
pub const TBL_TRXTEMPALARM_KW_TEMPNUM: e_TblkeyWordTrxTempAlarm = 2;
pub const TBL_TRXTEMPALARM_KW_LowerThreshold: e_TblkeyWordTrxTempAlarm = 1;
pub const TBL_TRXTEMPALARM_KW_UpperThreshold: e_TblkeyWordTrxTempAlarm = 0;
pub const NUM_TBL_KW_TRXTEMPALARM: e_TblkeyWordTrxTempAlarm = 4;
pub type e_TblkeyWordTrxTempAlarm = libc::c_uint;
static mut g_stTrxTempAlarmCaliData: T_TrxTempAlarmData = {
    let mut init = tagTrxTempAlarmData {
        tComHeader: {
            let mut init = tagT_adjTableHeader {
                ulVer: 0 as libc::c_int as UINT32,
                ulPathNum: 0,
                aucInfo: [0; 25],
                aucDate: [0; 25],
                aucOperator: [0; 25],
                aucChecker: [0; 25],
            };
            init
        },
        tHeader: {
            let mut init = tagT_TrxTempAlarmHeader {
                lWorkEnvTempUpper: 0 as libc::c_int,
                lWorkEnvTempLower: 0,
                lBoardTempNum: 0,
                lBoardTempAlm: [0; 32],
            };
            init
        },
        ulLoadFlag: 0,
    };
    init
};
static mut g_sulTrxTempAlarmLoadEndFlag: UINT32 = -(1 as libc::c_int) as UINT32;
static mut g_sulTrxTempAlarmSection: UINT32 = 0 as libc::c_int as UINT32;

pub static mut g_stTrxTempAlarm: T_TextTrans = unsafe {
    {
        let mut init = T_TextTrans {
            acFileName: *::core::mem::transmute::<
                &[u8; 80],
                &mut [CHAR; 80],
            >(
                b"/ata/TrxTempAlarm.txt\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0",
            ),
            acFileNameInSysFile: *::core::mem::transmute::<
                &[u8; 80],
                &mut [CHAR; 80],
            >(
                b"/ata/TrxTempAlarm.txt\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0",
            ),
            acFileNameInProcFile: *::core::mem::transmute::<
                &[u8; 80],
                &mut [CHAR; 80],
            >(
                b"/tmp/TrxTempAlarm.txt\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0",
            ),
            acFileDesc: *::core::mem::transmute::<
                &[u8; 80],
                &mut [CHAR; 80],
            >(
                b"trx temp alarm calib file\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0",
            ),
            fp: 0 as *const FILE as *mut FILE,
        };
        init
    }
};

pub static mut g_atTrxTempAlarmWordPub: [TTblKeyWord; 8] = unsafe {
    [
        {
            let mut init = tagTblKeyWord {
                ulIndex: TBL_PUB_KW_V as libc::c_int as UINT32,
                ulVer: 6 as libc::c_int as UINT32,
                aucKeyWord: *::core::mem::transmute::<
                    &[u8; 160],
                    &mut [libc::c_char; 160],
                >(
                    b"[V]\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0",
                ),
                ucSearchOrderFlag: 0 as libc::c_int as UCHAR,
                ucSearchResultFlag: 0 as libc::c_int as UCHAR,
                pFunc: Some(
                    _BspTrxTempAlarm_V
                        as unsafe extern "C" fn(*mut T_TextTrans, *const CHAR) -> UINT32,
                ),
                pFuncFlash: None,
            };
            init
        },
        {
            let mut init = tagTblKeyWord {
                ulIndex: TBL_PUB_KW_DATE as libc::c_int as UINT32,
                ulVer: 6 as libc::c_int as UINT32,
                aucKeyWord: *::core::mem::transmute::<
                    &[u8; 160],
                    &mut [libc::c_char; 160],
                >(
                    b"[DATE]\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0",
                ),
                ucSearchOrderFlag: 0 as libc::c_int as UCHAR,
                ucSearchResultFlag: 0 as libc::c_int as UCHAR,
                pFunc: Some(
                    _BspTrxTempAlarm_Date
                        as unsafe extern "C" fn(*mut T_TextTrans, *const CHAR) -> UINT32,
                ),
                pFuncFlash: None,
            };
            init
        },
        {
            let mut init = tagTblKeyWord {
                ulIndex: TBL_PUB_KW_OPERATOR as libc::c_int as UINT32,
                ulVer: 6 as libc::c_int as UINT32,
                aucKeyWord: *::core::mem::transmute::<
                    &[u8; 160],
                    &mut [libc::c_char; 160],
                >(
                    b"[TestPersonName]\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0",
                ),
                ucSearchOrderFlag: 0 as libc::c_int as UCHAR,
                ucSearchResultFlag: 0 as libc::c_int as UCHAR,
                pFunc: Some(
                    _BspTrxTempAlarm_Operator
                        as unsafe extern "C" fn(*mut T_TextTrans, *const CHAR) -> UINT32,
                ),
                pFuncFlash: None,
            };
            init
        },
        {
            let mut init = tagTblKeyWord {
                ulIndex: TBL_PUB_KW_CHECKER as libc::c_int as UINT32,
                ulVer: 6 as libc::c_int as UINT32,
                aucKeyWord: *::core::mem::transmute::<
                    &[u8; 160],
                    &mut [libc::c_char; 160],
                >(
                    b"[checkedPersonName]\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0",
                ),
                ucSearchOrderFlag: 0 as libc::c_int as UCHAR,
                ucSearchResultFlag: 0 as libc::c_int as UCHAR,
                pFunc: Some(
                    _BspTrxTempAlarm_Checker
                        as unsafe extern "C" fn(*mut T_TextTrans, *const CHAR) -> UINT32,
                ),
                pFuncFlash: None,
            };
            init
        },
        {
            let mut init = tagTblKeyWord {
                ulIndex: TBL_PUB_KW_PATHNUM as libc::c_int as UINT32,
                ulVer: 6 as libc::c_int as UINT32,
                aucKeyWord: *::core::mem::transmute::<
                    &[u8; 160],
                    &mut [libc::c_char; 160],
                >(
                    b"[PathNum]\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0",
                ),
                ucSearchOrderFlag: 0 as libc::c_int as UCHAR,
                ucSearchResultFlag: 0 as libc::c_int as UCHAR,
                pFunc: None,
                pFuncFlash: None,
            };
            init
        },
        {
            let mut init = tagTblKeyWord {
                ulIndex: TBL_PUB_KW_END as libc::c_int as UINT32,
                ulVer: 6 as libc::c_int as UINT32,
                aucKeyWord: *::core::mem::transmute::<
                    &[u8; 160],
                    &mut [libc::c_char; 160],
                >(
                    b"[END]\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0",
                ),
                ucSearchOrderFlag: 0 as libc::c_int as UCHAR,
                ucSearchResultFlag: 0 as libc::c_int as UCHAR,
                pFunc: Some(
                    _BspTrxTempAlarm_FileEnd
                        as unsafe extern "C" fn(*mut T_TextTrans, *const CHAR) -> UINT32,
                ),
                pFuncFlash: None,
            };
            init
        },
        TTblKeyWord {
            ulIndex: 0,
            ulVer: 0,
            aucKeyWord: [0; 160],
            ucSearchOrderFlag: 0,
            ucSearchResultFlag: 0,
            pFunc: None,
            pFuncFlash: None,
        },
        TTblKeyWord {
            ulIndex: 0,
            ulVer: 0,
            aucKeyWord: [0; 160],
            ucSearchOrderFlag: 0,
            ucSearchResultFlag: 0,
            pFunc: None,
            pFuncFlash: None,
        },
    ]
};

pub static mut g_atTrxTempAlarmKeyWordModule: [TTblKeyWord; 4] = unsafe {
    [
        {
            let mut init = tagTblKeyWord {
                ulIndex: TBL_TRXTEMPALARM_KW_UpperThreshold as libc::c_int as UINT32,
                ulVer: 6 as libc::c_int as UINT32,
                aucKeyWord: *::core::mem::transmute::<
                    &[u8; 160],
                    &mut [libc::c_char; 160],
                >(
                    b"[WorkingEnvironmentTempUpperThreshold]\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0",
                ),
                ucSearchOrderFlag: 0 as libc::c_int as UCHAR,
                ucSearchResultFlag: 0 as libc::c_int as UCHAR,
                pFunc: Some(
                    _BspTrxTempAlarm_TempUpper
                        as unsafe extern "C" fn(*mut T_TextTrans, *const CHAR) -> UINT32,
                ),
                pFuncFlash: None,
            };
            init
        },
        {
            let mut init = tagTblKeyWord {
                ulIndex: TBL_TRXTEMPALARM_KW_LowerThreshold as libc::c_int as UINT32,
                ulVer: 6 as libc::c_int as UINT32,
                aucKeyWord: *::core::mem::transmute::<
                    &[u8; 160],
                    &mut [libc::c_char; 160],
                >(
                    b"[WorkingEnvironmentTempLowerThreshold]\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0",
                ),
                ucSearchOrderFlag: 0 as libc::c_int as UCHAR,
                ucSearchResultFlag: 0 as libc::c_int as UCHAR,
                pFunc: Some(
                    _BspTrxTempAlarm_TempLower
                        as unsafe extern "C" fn(*mut T_TextTrans, *const CHAR) -> UINT32,
                ),
                pFuncFlash: None,
            };
            init
        },
        {
            let mut init = tagTblKeyWord {
                ulIndex: TBL_TRXTEMPALARM_KW_TEMPNUM as libc::c_int as UINT32,
                ulVer: 6 as libc::c_int as UINT32,
                aucKeyWord: *::core::mem::transmute::<
                    &[u8; 160],
                    &mut [libc::c_char; 160],
                >(
                    b"[TrxTempMonitorNum]\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0",
                ),
                ucSearchOrderFlag: 0 as libc::c_int as UCHAR,
                ucSearchResultFlag: 0 as libc::c_int as UCHAR,
                pFunc: Some(
                    _BspTrxTempAlarm_TempNum
                        as unsafe extern "C" fn(*mut T_TextTrans, *const CHAR) -> UINT32,
                ),
                pFuncFlash: None,
            };
            init
        },
        {
            let mut init = tagTblKeyWord {
                ulIndex: TBL_TRXTEMPALARM_KW_TEMPALM as libc::c_int as UINT32,
                ulVer: 6 as libc::c_int as UINT32,
                aucKeyWord: *::core::mem::transmute::<
                    &[u8; 160],
                    &mut [libc::c_char; 160],
                >(
                    b"[FeatureOfTrxTemp]\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0",
                ),
                ucSearchOrderFlag: 0 as libc::c_int as UCHAR,
                ucSearchResultFlag: 0 as libc::c_int as UCHAR,
                pFunc: Some(
                    _BspTrxTempAlarm_TempAlm
                        as unsafe extern "C" fn(*mut T_TextTrans, *const CHAR) -> UINT32,
                ),
                pFuncFlash: None,
            };
            init
        },
    ]
};

pub unsafe extern "C" fn _BspTrxTempAlarmCalibInit() -> UINT32 {
    let mut ulRetVal: UINT32 = 0 as libc::c_int as UINT32;
    let mut ptText: *mut T_TextTrans = 0 as *mut T_TextTrans;
    let mut ptParam: *mut T_CaliTblInitParam = 0 as *mut T_CaliTblInitParam;
    ptParam = _BspTblGetParam() as *mut T_CaliTblInitParam;
    println!("########################_BspTrxTempAlarmCalibInit##########################");
    ulRetVal = _BspTextTransInit(ptText, (*ptParam).ulCaliLoadPath);
    if 0 as libc::c_int as UINT32 == ulRetVal {
        // 只有在初始化成功时才能安全访问 ptText
        {
            let file_path_ptr = if (*ptParam).ulCaliLoadPath != 0 {
                ((*ptText).acFileNameInProcFile).as_mut_ptr() as *const libc::c_char
            } else {
                ((*ptText).acFileNameInSysFile).as_mut_ptr() as *const libc::c_char
            };
            let file_path = CStr::from_ptr(file_path_ptr).to_string_lossy();
            println!("loading file {} ...", file_path);
        }
        ulRetVal |= _BspTrxTempAlarmLoad(ptText);
        _BspTextTransExit(ptText);
        g_stTrxTempAlarmCaliData.ulLoadFlag = 2 as libc::c_int as UINT32;
    } else {
        eprintln!("_BspTrxTempAlmCalibInit:error");
        g_stTrxTempAlarmCaliData.ulLoadFlag = 1 as libc::c_int as UINT32;
    }
    ulRetVal |= _BspTrxTempAlarmChkTblResult();
    return ulRetVal;
}

pub unsafe extern "C" fn _BspSetTrxTempAlarmTextTrans(
    mut tText: *mut T_TextTrans,
) -> UINT32 {
    if tText.is_null() {
        eprintln!("_BspSetTrxTempAlarmTextTrans:Input Pointer is NULL!");
        return 0xff000002 as libc::c_uint;
    }
    return 0 as libc::c_int as UINT32;
}

pub unsafe extern "C" fn _BspTrxTempAlarmLoad(mut ptText: *mut T_TextTrans) -> UINT32 {
    let mut ulRetVal: UINT32 = 0 as libc::c_int as UINT32;
    let mut achLine: [CHAR; 1024] = [
        0 as libc::c_int as CHAR,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
    ];
    let mut ulLoopCount: UINT32 = 0 as libc::c_int as UINT32;
    const MAX_LOOP_COUNT: UINT32 = 10000 as libc::c_int as UINT32; // 防止无限循环的最大循环次数
    loop {
        ulRetVal = _BspLineRead(ptText, achLine.as_mut_ptr());
        if 0xffffffff as libc::c_uint == ulRetVal
            || 0 as libc::c_int as libc::c_uint == g_sulTrxTempAlarmLoadEndFlag
        {
            break;
        }
        ulLoopCount = ulLoopCount.wrapping_add(1);
        if ulLoopCount >= MAX_LOOP_COUNT {
            // 达到最大循环次数，强制退出，防止无限循环
            break;
        }
        _BspTrxTempAlarmSearchAndMapKeyWord(
            ptText,
            g_sulTrxTempAlarmSection,
            achLine.as_mut_ptr(),
        );
    }
    return 0 as libc::c_int as UINT32;
}

pub unsafe extern "C" fn _BspTrxTempAlarmSearchAndMapKeyWordPub(
    mut ptText: *mut T_TextTrans,
    mut pchLine: *mut CHAR,
) -> UINT32 {
    let mut ulKwLoop: UINT32 = 0 as libc::c_int as UINT32;
    let mut pchKeyStr: *mut CHAR = 0 as *mut CHAR;
    ulKwLoop = 0 as libc::c_int as UINT32;
    while ulKwLoop < NUM_TBL_KW_PUB as libc::c_int as libc::c_uint {
        pchKeyStr = strstr(
            pchLine as *const CHAR,
            (g_atTrxTempAlarmWordPub[ulKwLoop as usize].aucKeyWord).as_mut_ptr()
                as *const CHAR,
        );
        if !pchKeyStr.is_null()
        {
            g_atTrxTempAlarmWordPub[ulKwLoop as usize]
                .ucSearchResultFlag = 1 as libc::c_int as UCHAR;
            if let Some(func) = g_atTrxTempAlarmWordPub[ulKwLoop as usize].pFunc {
                func(ptText, pchLine);
            }
            break;
        } else {
            ulKwLoop = ulKwLoop.wrapping_add(1);
            ulKwLoop;
        }
    }
    return 0 as libc::c_int as UINT32;
}

pub unsafe extern "C" fn _BspTrxTempAlarmSearchAndMapKeyWordPri(
    mut ptText: *mut T_TextTrans,
    mut pchLine: *mut CHAR,
) -> UINT32 {
    let mut ulKwLoop: UINT32 = 0 as libc::c_int as UINT32;
    let mut pchKeyStr: *mut CHAR = 0 as *mut CHAR;
    ulKwLoop = 0 as libc::c_int as UINT32;
    while ulKwLoop < NUM_TBL_KW_TRXTEMPALARM as libc::c_int as libc::c_uint {
        pchKeyStr = strstr(
            pchLine as *const CHAR,
            (g_atTrxTempAlarmKeyWordModule[ulKwLoop as usize].aucKeyWord).as_mut_ptr()
                as *const CHAR,
        );

        ulKwLoop = ulKwLoop.wrapping_add(1);
        ulKwLoop;
    }
    return 0 as libc::c_int as UINT32;
}

pub unsafe extern "C" fn _BspTrxTempAlarmSearchAndMapKeyWord(
    mut ptText: *mut T_TextTrans,
    mut ulFlag: UINT32,
    mut pchLine: *mut CHAR,
) -> UINT32 {
    if 0 as libc::c_int as libc::c_uint == ulFlag {
        _BspTrxTempAlarmSearchAndMapKeyWordPub(ptText, pchLine);
    } else {
        _BspTrxTempAlarmSearchAndMapKeyWordPri(ptText, pchLine);
    }
    return 0 as libc::c_int as UINT32;
}

pub unsafe extern "C" fn _BspTrxTempAlarm_V(
    mut ptText: *mut T_TextTrans,
    mut pch: *const CHAR,
) -> UINT32 {
    let mut pchKeyStr: *const CHAR = 0 as *const CHAR;
    pchKeyStr = strchr(pch, ']' as i32);
    if pchKeyStr.is_null() {
        eprintln!("_BspTrxTempAlarm_V:strchr return NULL!");
    }
    pchKeyStr = pchKeyStr.offset(1);
    pchKeyStr;
    g_stTrxTempAlarmCaliData.tComHeader.ulVer = BspAtou(pchKeyStr, 0 as libc::c_int);
    if ((0x1 as libc::c_int) << TBL_KIND_OF_TRXTEMPALM as libc::c_int)
        as libc::c_ulonglong & _BspGetTblPrnMask() != 0
    {
        let ul_ver = g_stTrxTempAlarmCaliData.tComHeader.ulVer;
        println!("_BspTrxTempAlarm_V:{}", ul_ver);
    }
    return 0 as libc::c_int as UINT32;
}

pub unsafe extern "C" fn _BspTrxTempAlarm_Date(
    mut ptText: *mut T_TextTrans,
    mut pch: *const CHAR,
) -> UINT32 {
    let mut pchKeyStr: *const CHAR = 0 as *const CHAR;
    pchKeyStr = strchr(pch, ']' as i32);
    if pchKeyStr.is_null() {
        eprintln!("_BspTrxTempAlarm_Date:strchr return NULL!");
    }
    pchKeyStr = pchKeyStr.offset(1);
    pchKeyStr;
    g_stTrxTempAlarmCaliData
        .tComHeader
        .aucDate[(25 as libc::c_int - 1 as libc::c_int)
        as usize] = '\0' as i32 as libc::c_char;
    return 0 as libc::c_int as UINT32;
}

pub unsafe extern "C" fn _BspTrxTempAlarm_Operator(
    mut ptText: *mut T_TextTrans,
    mut pch: *const CHAR,
) -> UINT32 {
    let mut pchKeyStr: *const CHAR = 0 as *const CHAR;
    pchKeyStr = strchr(pch, ']' as i32);
    if pchKeyStr.is_null() {
        eprintln!("_BspTrxTempAlarm_Operator:strchr return NULL!");
    }
    pchKeyStr = pchKeyStr.offset(1);
    pchKeyStr;
    g_stTrxTempAlarmCaliData
        .tComHeader
        .aucOperator[(25 as libc::c_int - 1 as libc::c_int)
        as usize] = '\0' as i32 as libc::c_char;
    return 0 as libc::c_int as UINT32;
}

pub unsafe extern "C" fn _BspTrxTempAlarm_Checker(
    mut ptText: *mut T_TextTrans,
    mut pch: *const CHAR,
) -> UINT32 {
    let mut pchKeyStr: *const CHAR = 0 as *const CHAR;
    pchKeyStr = strchr(pch, ']' as i32);
    if pchKeyStr.is_null() {
        eprintln!("_BspTrxTempAlarm_Checker:strchr return NULL!");
    }
    pchKeyStr = pchKeyStr.offset(1);
    pchKeyStr;
    g_stTrxTempAlarmCaliData
        .tComHeader
        .aucChecker[(25 as libc::c_int - 1 as libc::c_int)
        as usize] = '\0' as i32 as libc::c_char;
    g_sulTrxTempAlarmSection = 1 as libc::c_int as UINT32;
    return 0 as libc::c_int as UINT32;
}

pub unsafe extern "C" fn _BspTrxTempAlarm_FileEnd(
    mut ptText: *mut T_TextTrans,
    mut pch: *const CHAR,
) -> UINT32 {
    if ((0x1 as libc::c_int) << TBL_KIND_OF_TRXTEMPALM as libc::c_int)
        as libc::c_ulonglong & _BspGetTblPrnMask() != 0
    {
        println!("_BspTrxTempAlarm_FileEnd");
    }
    return 0 as libc::c_int as UINT32;
}

pub unsafe extern "C" fn _BspTrxTempAlarm_TempUpper(
    mut ptText: *mut T_TextTrans,
    mut pch: *const CHAR,
) -> UINT32 {
    let mut pchKeyStr: *const CHAR = 0 as *const CHAR;
    pchKeyStr = strchr(pch, ']' as i32);
    if pchKeyStr.is_null() {
        eprintln!("_BspTrxTempAlarm_TempUpper:strchr return NULL!");
    }
    pchKeyStr = pchKeyStr.offset(1);
    pchKeyStr;
    g_stTrxTempAlarmCaliData
        .tHeader
        .lWorkEnvTempUpper = BspAtoi(pchKeyStr, 0 as libc::c_int);
    if ((0x1 as libc::c_int) << TBL_KIND_OF_TRXTEMPALM as libc::c_int)
        as libc::c_ulonglong & _BspGetTblPrnMask() != 0
    {
        let temp_upper = g_stTrxTempAlarmCaliData.tHeader.lWorkEnvTempUpper;
        println!("_BspTrxTempAlarm_TempUpper:{}", temp_upper);
    }
    return 0 as libc::c_int as UINT32;
}

pub unsafe extern "C" fn _BspTrxTempAlarm_TempLower(
    mut ptText: *mut T_TextTrans,
    mut pch: *const CHAR,
) -> UINT32 {
    let mut pchKeyStr: *const CHAR = 0 as *const CHAR;
    pchKeyStr = strchr(pch, ']' as i32);
    if pchKeyStr.is_null() {
        eprintln!("_BspTrxTempAlarm_TempLower:strchr return NULL!");
    }
    pchKeyStr = pchKeyStr.offset(1);
    pchKeyStr;
    g_stTrxTempAlarmCaliData
        .tHeader
        .lWorkEnvTempLower = BspAtoi(pchKeyStr, 0 as libc::c_int);
    if ((0x1 as libc::c_int) << TBL_KIND_OF_TRXTEMPALM as libc::c_int)
        as libc::c_ulonglong & _BspGetTblPrnMask() != 0
    {
        let temp_lower = g_stTrxTempAlarmCaliData.tHeader.lWorkEnvTempLower;
        println!("_BspTrxTempAlarm_TempLower:{}", temp_lower);
    }
    return 0 as libc::c_int as UINT32;
}

pub unsafe extern "C" fn _BspTrxTempAlarm_TempNum(
    mut ptText: *mut T_TextTrans,
    mut pch: *const CHAR,
) -> UINT32 {
    let mut pchKeyStr: *const CHAR = 0 as *const CHAR;
    pchKeyStr = strchr(pch, ']' as i32);
    if pchKeyStr.is_null() {
        eprintln!("_BspTrxTempAlarm_TempNum:strchr return NULL!");
    }
    pchKeyStr = pchKeyStr.offset(1);
    pchKeyStr;
    g_stTrxTempAlarmCaliData
        .tHeader
        .lBoardTempNum = BspAtoi(pchKeyStr, 0 as libc::c_int);
    if ((0x1 as libc::c_int) << TBL_KIND_OF_TRXTEMPALM as libc::c_int)
        as libc::c_ulonglong & _BspGetTblPrnMask() != 0
    {
        let temp_num = g_stTrxTempAlarmCaliData.tHeader.lBoardTempNum;
        println!("_BspTrxTempAlarm_TempNum:{}", temp_num);
    }
    return 0 as libc::c_int as UINT32;
}

pub unsafe extern "C" fn _BspTrxTempAlarm_TempAlm(
    mut ptText: *mut T_TextTrans,
    mut pch: *const CHAR,
) -> UINT32 {
    let mut pchKeyStr: *const CHAR = 0 as *const CHAR;
    let mut pchStr: *mut CHAR = 0 as *mut CHAR;
    let mut ulLoop: UINT32 = 0 as libc::c_int as UINT32;
    pchKeyStr = strchr(pch, ']' as i32);
    if pchKeyStr.is_null() {
        eprintln!("_BspTrxTempAlarm_TempAlm:strchr return NULL!");
        return 0 as libc::c_int as UINT32; // 提前返回，避免空指针解引用
    }
    pchKeyStr = pchKeyStr.offset(1);
    pchKeyStr;
    let mut tempSensorNum: UINT32 = 0 as libc::c_int as UINT32;
    tempSensorNum = g_stTrxTempAlarmCaliData.tHeader.lBoardTempNum as UINT32;
    if 0 as libc::c_int as libc::c_uint == tempSensorNum {
        tempSensorNum = 1 as libc::c_int as UINT32;
    }
    ulLoop = 0 as libc::c_int as UINT32;
    while ulLoop
        < (E_TRXTEMP_THRESHOLD_NUM as libc::c_int as libc::c_uint)
            .wrapping_mul(tempSensorNum)
    {
        pchStr = _BspGetRecordFromStr_Ex(pchKeyStr, ulLoop as libc::c_int);
        if !pchStr.is_null() {
            g_stTrxTempAlarmCaliData
                .tHeader
                .lBoardTempAlm[ulLoop as usize] = BspAtoi(pchStr, 0 as libc::c_int);
        } else {
            g_stTrxTempAlarmCaliData
                .tHeader
                .lBoardTempAlm[ulLoop as usize] = 0 as libc::c_int;
        }
        ulLoop = ulLoop.wrapping_add(1);
        ulLoop;
    }
    if ((0x1 as libc::c_int) << TBL_KIND_OF_TRXTEMPALM as libc::c_int)
        as libc::c_ulonglong & _BspGetTblPrnMask() != 0
    {
        let temp_alm0 = g_stTrxTempAlarmCaliData.tHeader.lBoardTempAlm[0 as libc::c_int as usize];
        let temp_alm1 = g_stTrxTempAlarmCaliData.tHeader.lBoardTempAlm[1 as libc::c_int as usize];
        let temp_alm2 = g_stTrxTempAlarmCaliData.tHeader.lBoardTempAlm[2 as libc::c_int as usize];
        let temp_alm3 = g_stTrxTempAlarmCaliData.tHeader.lBoardTempAlm[3 as libc::c_int as usize];
        let temp_alm4 = g_stTrxTempAlarmCaliData.tHeader.lBoardTempAlm[4 as libc::c_int as usize];
        println!(
            "_BspTrxTempAlarm_TempAlm:{},{},{},{},{}",
            temp_alm0, temp_alm1, temp_alm2, temp_alm3, temp_alm4,
        );
    }
    return 0 as libc::c_int as UINT32;
}

pub unsafe extern "C" fn _BspTrxTempAlarmChkTblResult() -> UINT32 {
    let mut aucState: [[CHAR; 10]; 2] = [
        *::core::mem::transmute::<&[u8; 10], &mut [CHAR; 10]>(b"succ\0\0\0\0\0\0"),
        *::core::mem::transmute::<&[u8; 10], &mut [CHAR; 10]>(b"fail\0\0\0\0\0\0"),
    ];
    return 0 as libc::c_int as UINT32;
}

pub unsafe extern "C" fn BspTrxTempAlarmKwSearchInit() -> UINT32 {
    let mut keyWordLoop: UINT32 = 0 as libc::c_int as UINT32;
    println!("################TRXTEMPALARM KEY WORD STATE INIT###############");
    keyWordLoop = 0 as libc::c_int as UINT32;
    while keyWordLoop < NUM_TBL_KW_TRXTEMPALARM as libc::c_int as libc::c_uint {
        g_atTrxTempAlarmKeyWordModule[keyWordLoop as usize]
            .ucSearchResultFlag = 0 as libc::c_int as UCHAR;
        keyWordLoop = keyWordLoop.wrapping_add(1);
        keyWordLoop;
    }
    return 0 as libc::c_int as UINT32;
}

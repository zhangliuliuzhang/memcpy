#![allow(
    dead_code,
    mutable_transmutes,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    unused_assignments,
    unused_mut
)]
// unsafe extern "C" {
//     fn encapsulationOfZte_memcpy_s(
//         s1: *mut libc::c_void,
//         s1max: rsize_t,
//         s2: *const libc::c_void,
//         n: rsize_t,
//         fileName: *const libc::c_char,
//         lineNo: libc::c_int,
//     ) -> libc::c_int;
//     fn BspSysMsDelay(ulDelay: UINT32);
//     fn semGive(semId: SEM_ID) -> STATUS;
//     fn semTake(semId: SEM_ID, timeout: libc::c_int) -> STATUS;
//     fn semBCreate(options: libc::c_int, initialState: SEM_B_STATE) -> SEM_ID;
//     fn tickGet() -> ULONG;
// }

use crate::surezip_clib::*;

pub type __uint8_t = libc::c_uchar;
pub type __uint16_t = libc::c_ushort;
pub type __uint32_t = libc::c_uint;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct __pthread_internal_list {
    pub __prev: *mut __pthread_internal_list,
    pub __next: *mut __pthread_internal_list,
}
pub type __pthread_list_t = __pthread_internal_list;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct __pthread_mutex_s {
    pub __lock: libc::c_int,
    pub __count: libc::c_uint,
    pub __owner: libc::c_int,
    pub __nusers: libc::c_uint,
    pub __kind: libc::c_int,
    pub __spins: libc::c_short,
    pub __elision: libc::c_short,
    pub __list: __pthread_list_t,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct __pthread_cond_s {
    pub c2rust_unnamed: C2RustUnnamed_1,
    pub c2rust_unnamed_0: C2RustUnnamed,
    pub __g_refs: [libc::c_uint; 2],
    pub __g_size: [libc::c_uint; 2],
    pub __g1_orig_size: libc::c_uint,
    pub __wrefs: libc::c_uint,
    pub __g_signals: [libc::c_uint; 2],
}
#[derive(Copy, Clone)]
#[repr(C)]
pub union C2RustUnnamed {
    pub __g1_start: libc::c_ulonglong,
    pub __g1_start32: C2RustUnnamed_0,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct C2RustUnnamed_0 {
    pub __low: libc::c_uint,
    pub __high: libc::c_uint,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub union C2RustUnnamed_1 {
    pub __wseq: libc::c_ulonglong,
    pub __wseq32: C2RustUnnamed_2,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct C2RustUnnamed_2 {
    pub __low: libc::c_uint,
    pub __high: libc::c_uint,
}
pub type pthread_t = libc::c_ulong;
#[derive(Copy, Clone)]
#[repr(C)]
pub union pthread_attr_t {
    pub __size: [libc::c_char; 56],
    pub __align: libc::c_long,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub union pthread_mutex_t {
    pub __data: __pthread_mutex_s,
    pub __size: [libc::c_char; 40],
    pub __align: libc::c_long,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub union pthread_cond_t {
    pub __data: __pthread_cond_s,
    pub __size: [libc::c_char; 48],
    pub __align: libc::c_longlong,
}
pub type uint8_t = __uint8_t;
pub type uint16_t = __uint16_t;
pub type uint32_t = __uint32_t;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct sched_param {
    pub sched_priority: libc::c_int,
}
pub type CHAR = libc::c_char;
pub type ULONG = libc::c_uint;
pub type UINT8 = libc::c_uchar;
pub type UINT16 = libc::c_ushort;
pub type UINT32 = libc::c_uint;
pub type STATUS = libc::c_uint;
pub type rsize_t = libc::c_int;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct tagT_Ver_File_Header {
    pub ulCRC32: uint32_t,
    pub ulHeaderVersion: uint32_t,
    pub usVerType: uint16_t,
    pub ucCpuType: uint8_t,
    pub ucReserved0: uint8_t,
    pub ulCompressedSize: uint32_t,
    pub ulCompressedCRC: uint32_t,
    pub ulOriginalSize: uint32_t,
    pub ulOriginalCRC: uint32_t,
    pub ulSoftType: uint32_t,
    pub ucVerNo: [CHAR; 44],
    pub ulCreateTime: uint32_t,
    pub ucPackedFile: uint8_t,
    pub ucPackedFileNum: uint8_t,
    pub ucOsType: uint8_t,
    pub ucReserved1: [uint8_t; 9],
    pub ucPhyId: uint8_t,
    pub ucReserved2: [uint8_t; 35],
}
pub type T_VerFileHeader = tagT_Ver_File_Header;
#[derive(Copy, Clone)]
#[repr(C)]
pub union sem_t {
    pub __size: [libc::c_char; 32],
    pub __align: libc::c_long,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct task_s {
    pub check: libc::c_int,
    pub taskid: libc::c_int,
    pub name: *mut libc::c_char,
    pub pthrid: pthread_t,
    pub attr: pthread_attr_t,
    pub prv_priority: sched_param,
    pub entry_point: Option::<
        unsafe extern "C" fn(
            libc::c_int,
            libc::c_int,
            libc::c_int,
            libc::c_int,
            libc::c_int,
            libc::c_int,
            libc::c_int,
            libc::c_int,
            libc::c_int,
            libc::c_int,
        ) -> libc::c_int,
    >,
    pub parms: [libc::c_int; 10],
    pub static_task: libc::c_int,
    pub flags: libc::c_int,
    pub state: libc::c_int,
    pub vxw_priority: libc::c_int,
    pub nxt_susp: *mut task_s,
    pub delete_safe_count: libc::c_int,
    pub tdelete_lock: pthread_mutex_t,
    pub t_deletable: pthread_cond_t,
    pub dbcst_lock: pthread_mutex_t,
    pub delete_bcplt: pthread_cond_t,
    pub tsuspend_lock: pthread_mutex_t,
    pub tsuspendable: pthread_cond_t,
    pub first_susp: *mut task_s,
    pub nxt_task: *mut task_s,
    pub nxt_task_hash: *mut task_s,
    pub waiting: *mut v2lsem,
    pub waiting_m: *mut pthread_mutex_t,
    pub swapInMask: UINT16,
    pub swapOutMask: UINT16,
    pub lock_num: libc::c_int,
    pub oldpriority: libc::c_int,
    pub reserved1: libc::c_int,
    pub reserved2: libc::c_int,
    pub spare1: libc::c_int,
    pub spare2: libc::c_int,
    pub spare3: libc::c_int,
    pub spare4: libc::c_int,
    pub status: libc::c_uint,
    pub options: libc::c_int,
    pub priority: libc::c_uint,
    pub priNormal: libc::c_uint,
    pub pStackBase: *mut libc::c_char,
    pub pStackLimit: *mut libc::c_char,
    pub pStackEnd: *mut libc::c_char,
    pub file_name: *mut libc::c_char,
    pub line_no: libc::c_int,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct v2lsem {
    pub sem_type: libc::c_int,
    pub owner_pid: libc::c_int,
    pub sem_obj: C2RustUnnamed_3,
    pub magic: libc::c_int,
    pub static_sem: libc::c_int,
    pub sem_lock: pthread_mutex_t,
    pub sem_send: pthread_cond_t,
    pub flags: libc::c_int,
    pub smdel_lock: pthread_mutex_t,
    pub smdel_cplt: pthread_cond_t,
    pub token_count: libc::c_int,
    pub count_orig: libc::c_int,
    pub send_type: libc::c_int,
    pub recursion_level: libc::c_int,
    pub current_owner: *mut WIND_TCB,
    pub owner: pthread_t,
    pub nxt_sem: *mut v2lsem,
    pub first_susp: *mut WIND_TCB,
}
pub type WIND_TCB = task_s;
#[derive(Copy, Clone)]
#[repr(C)]
pub union C2RustUnnamed_3 {
    pub mutex: pthread_mutex_t,
    pub sem: sem_t,
}
pub type v2lsem_t = v2lsem;
// 使用 surezip_clib 中的 SEM_ID 类型定义，以保持兼容性
// pub type SEM_ID = *mut v2lsem_t;  // 注释掉，使用 surezip_clib 中的定义
pub type SEM_B_STATE = libc::c_uint;
pub const SEM_FULL: SEM_B_STATE = 1;
pub const SEM_EMPTY: SEM_B_STATE = 0;
#[derive(Copy, Clone)]
#[repr(C, packed)]
pub struct TagSwIdInfo {
    pub ucSwId: libc::c_uchar,
    pub ulSwLen: libc::c_uint,
}
pub type TSwIdInfo = TagSwIdInfo;
#[derive(Copy, Clone)]
#[repr(C, packed)]
pub struct TagSwPackage {
    pub ucSwNum: libc::c_uchar,
    pub atSwIdInfo: [TSwIdInfo; 10],
}
pub type TSwPackage = TagSwPackage;
#[inline]
unsafe extern "C" fn __bswap_16(mut __bsx: __uint16_t) -> __uint16_t {
    return (__bsx as libc::c_int >> 8 as libc::c_int & 0xff as libc::c_int
        | (__bsx as libc::c_int & 0xff as libc::c_int) << 8 as libc::c_int)
        as __uint16_t;
}
#[inline]
unsafe extern "C" fn __bswap_32(mut __bsx: __uint32_t) -> __uint32_t {
    return (__bsx & 0xff000000 as libc::c_uint) >> 24 as libc::c_int
        | (__bsx & 0xff0000 as libc::c_uint) >> 8 as libc::c_int
        | (__bsx & 0xff00 as libc::c_uint) << 8 as libc::c_int
        | (__bsx & 0xff as libc::c_uint) << 24 as libc::c_int;
}
#[unsafe(no_mangle)]
pub static mut NewUnpressSem: SEM_ID = std::ptr::null_mut();
#[unsafe(no_mangle)]
pub unsafe extern "C" fn SemNewUnpressInit() -> UINT32 {
    static mut s_ucSemNUInit: UINT8 = 0 as libc::c_int as UINT8;
    if 1 as libc::c_int == s_ucSemNUInit as libc::c_int {
        return 0 as libc::c_int as UINT32;
    }
    NewUnpressSem = semBCreate(0 as libc::c_int, SEM_FULL);
    if NewUnpressSem.is_null() {
        println!("it is ok!");
        return 0xffffffff as libc::c_uint;
    }
    s_ucSemNUInit = 1 as libc::c_int as UINT8;
    return 0 as libc::c_int as UINT32;
}
#[unsafe(no_mangle)]
pub unsafe extern "C" fn BspGetNewUnpressSem() -> UINT32 {
    if 0 as libc::c_int as UINT32 != SemNewUnpressInit() {
        return 0xffffffff as libc::c_uint;
    }
    // 检查 NewUnpressSem 是否已初始化
    if NewUnpressSem.is_null() {
        return 0xffffffff as libc::c_uint;
    }
    // semTake(NewUnpressSem, -(1 as libc::c_int));
    return 0 as libc::c_int as UINT32;
}
#[unsafe(no_mangle)]
pub unsafe extern "C" fn BspRlsNewUnpressSem() -> UINT32 {
    // 检查 NewUnpressSem 是否已初始化
    if NewUnpressSem.is_null() {
        return 0xffffffff as libc::c_uint;
    }
    // semGive(NewUnpressSem);
    return 0 as libc::c_int as UINT32;
}
#[unsafe(no_mangle)]
pub unsafe extern "C" fn NewUnpress(
    mut pucInFile: *mut libc::c_uchar,
    mut ulFileLen: libc::c_ulong,
    mut pucOutFile: *mut libc::c_uchar,
) -> libc::c_ulong {
    let mut ulTemp: libc::c_ulong = 0;
    let mut pucDataBuf: *mut libc::c_uchar = 0 as *mut libc::c_uchar;
    pucDataBuf = pucInFile;
    if pucDataBuf.is_null() {
        // 使用 Rust println! 替换 printf
        println!("NewUnpress>>Error! pInFile cannot Null");
        return (0x20000000 as libc::c_int + 1 as libc::c_int) as libc::c_ulong;
    }
    BspGetNewUnpressSem();
    //ulTemp = UnpressV4(pucDataBuf, ulFileLen, pucOutFile);
    BspRlsNewUnpressSem();
    return ulTemp;
}
#[unsafe(no_mangle)]
pub unsafe extern "C" fn RegHeaderByteOrder(mut ptVerHeader: *mut T_VerFileHeader) {
    (*ptVerHeader).ulCRC32 = __bswap_32((*ptVerHeader).ulCRC32);
    (*ptVerHeader).ulHeaderVersion = __bswap_32((*ptVerHeader).ulHeaderVersion);
    (*ptVerHeader).usVerType = __bswap_16((*ptVerHeader).usVerType);
    (*ptVerHeader).ulCompressedSize = __bswap_32((*ptVerHeader).ulCompressedSize);
    (*ptVerHeader).ulCompressedCRC = __bswap_32((*ptVerHeader).ulCompressedCRC);
    (*ptVerHeader).ulOriginalSize = __bswap_32((*ptVerHeader).ulOriginalSize);
    (*ptVerHeader).ulOriginalCRC = __bswap_32((*ptVerHeader).ulOriginalCRC);
    (*ptVerHeader).ulSoftType = __bswap_32((*ptVerHeader).ulSoftType);
    (*ptVerHeader).ulCreateTime = __bswap_32((*ptVerHeader).ulCreateTime);
}
#[unsafe(no_mangle)]
pub unsafe extern "C" fn CheckCrc16(
    mut ucBuffer: *mut libc::c_uchar,
    mut ulBufferLength: libc::c_ulong,
    mut ulTarCrcValue: libc::c_ushort,
) -> libc::c_ulong {
    let mut ulCrcValue: libc::c_ushort = 0;
    if ulBufferLength == 0 as libc::c_int as libc::c_ulong {
        return 1 as libc::c_int as libc::c_ulong;
    }
    //ulCrcValue = BspCountCrc16(0xffff as libc::c_int, ucBuffer, ulBufferLength)
    //    as libc::c_ushort;
    if ulCrcValue as libc::c_int != ulTarCrcValue as libc::c_int {
        // 使用 Rust println! 替换 printf
        println!("target crc {:#08x} != calced crc {:#08x}", ulTarCrcValue as libc::c_int, ulCrcValue as libc::c_int);
        return 2 as libc::c_int as libc::c_ulong;
    }
    return 0 as libc::c_int as libc::c_ulong;
}
#[unsafe(no_mangle)]
pub unsafe extern "C" fn GetDivFromUnion(
    mut pucUnion: *mut libc::c_uchar,
    mut dwWorkMode: libc::c_ulong,
    mut pucDivAddr: *mut *mut libc::c_uchar,
    mut pulLength: *mut libc::c_ulong,
) -> libc::c_ulong {
    let mut ptUnionAddr: *mut TSwPackage = 0 as *mut TSwPackage;
    let mut ulUnionHeaderLen: libc::c_ulong = 0;
    let mut ucLoop: libc::c_uchar = 0;
    let mut ucNum: libc::c_uchar = 0;
    if pucUnion.is_null() || pucDivAddr.is_null() {
        return (0x20000000 as libc::c_int + 1 as libc::c_int) as libc::c_ulong;
    }
    ptUnionAddr = pucUnion as *mut TSwPackage;
    println!("it is ok!");
    match dwWorkMode {
        2 => {
            ucNum = 0 as libc::c_int as libc::c_uchar;
        }
        8 | 24 => {
            ucNum = 0 as libc::c_int as libc::c_uchar;
        }
        1 => {
            ucNum = 1 as libc::c_int as libc::c_uchar;
        }
        3 => {
            ucNum = 2 as libc::c_int as libc::c_uchar;
        }
        16 => {
            ucNum = 0 as libc::c_int as libc::c_uchar;
        }
        _ => {
            ucNum = 0 as libc::c_int as libc::c_uchar;
        }
    }
    if ucNum as libc::c_int > (*ptUnionAddr).ucSwNum as libc::c_int - 1 as libc::c_int {
        // 使用 Rust println! 替换 printf
        println!("Max division number of union must be less than {}", (*ptUnionAddr).ucSwNum as libc::c_int);
        return (0x20000000 as libc::c_int + 7 as libc::c_int) as libc::c_ulong;
    }
    if (*ptUnionAddr).ucSwNum as libc::c_int - 1 as libc::c_int > 3 as libc::c_int {
        // 使用 Rust println! 替换 printf
        println!("Max division number of union must be max to 3");
        return (0x20000000 as libc::c_int + 7 as libc::c_int) as libc::c_ulong;
    }
    ulUnionHeaderLen = (::core::mem::size_of::<libc::c_uchar>() as libc::c_ulong)
        .wrapping_add(
            ((*ptUnionAddr).ucSwNum as libc::c_ulong)
                .wrapping_mul(::core::mem::size_of::<TSwIdInfo>() as libc::c_ulong),
        );
    *pucDivAddr = pucUnion.offset(ulUnionHeaderLen as isize);
    ucLoop = 0 as libc::c_int as libc::c_uchar;
    while (ucLoop as libc::c_int) < ucNum as libc::c_int {
        *pucDivAddr = (*pucDivAddr)
            .offset((*ptUnionAddr).atSwIdInfo[ucLoop as usize].ulSwLen as isize);
        ucLoop = ucLoop.wrapping_add(1);
        ucLoop;
    }
    *pulLength = (*ptUnionAddr).atSwIdInfo[ucNum as usize].ulSwLen as libc::c_ulong;
    BspSysMsDelay(1);
    return 0 as libc::c_int as UINT32 as libc::c_ulong;
}
#[unsafe(no_mangle)]
pub unsafe extern "C" fn GetDivFromUnionByIndex(
    mut pucUnion: *mut libc::c_uchar,
    mut ulIndex: UINT32,
    mut pucDivAddr: *mut *mut libc::c_uchar,
    mut pulLength: *mut libc::c_ulong,
) -> libc::c_ulong {
    let mut ptUnionAddr: *mut TSwPackage = 0 as *mut TSwPackage;
    let mut ulUnionHeaderLen: libc::c_ulong = 0;
    let mut ucLoop: libc::c_uchar = 0;
    if pucUnion.is_null() || pucDivAddr.is_null() {
        return (0x20000000 as libc::c_int + 1 as libc::c_int) as libc::c_ulong;
    }
    ptUnionAddr = pucUnion as *mut TSwPackage;
    println!("it is ok!");
    if ulIndex > ((*ptUnionAddr).ucSwNum as libc::c_int - 1 as libc::c_int) as UINT32 {
        // 使用 Rust println! 替换 printf
        println!("Max division number of union must be less than {}", (*ptUnionAddr).ucSwNum as libc::c_int);
        return (0x20000000 as libc::c_int + 7 as libc::c_int) as libc::c_ulong;
    }
    ulUnionHeaderLen = (::core::mem::size_of::<libc::c_uchar>() as libc::c_ulong)
        .wrapping_add(
            ((*ptUnionAddr).ucSwNum as libc::c_ulong)
                .wrapping_mul(::core::mem::size_of::<TSwIdInfo>() as libc::c_ulong),
        );
    *pucDivAddr = pucUnion.offset(ulUnionHeaderLen as isize);
    ucLoop = 0 as libc::c_int as libc::c_uchar;
    while (ucLoop as libc::c_uint) < ulIndex {
        *pucDivAddr = (*pucDivAddr)
            .offset(
                __bswap_32((*ptUnionAddr).atSwIdInfo[ucLoop as usize].ulSwLen) as isize,
            );
        ucLoop = ucLoop.wrapping_add(1);
        ucLoop;
    }
    *pulLength = __bswap_32((*ptUnionAddr).atSwIdInfo[ulIndex as usize].ulSwLen)
        as libc::c_ulong;
    BspSysMsDelay(1);
    return 0 as libc::c_int as UINT32 as libc::c_ulong;
}

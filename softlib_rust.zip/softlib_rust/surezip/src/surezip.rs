#![allow(
    dead_code,
    mutable_transmutes,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    unused_assignments,
    unused_mut
)]
use crate::surezip_clib::*;
use std::ffi::c_void;
#[repr(C)]
pub struct internal_state(c_void);

pub type __uint16_t = libc::c_ushort;
pub type Byte = libc::c_uchar;
pub type uInt = libc::c_uint;
pub type uLong = libc::c_ulong;
pub type Bytef = Byte;
pub type uLongf = uLong;
pub type voidpf = *mut libc::c_void;
pub type voidp = *mut libc::c_void;
pub type alloc_func = Option::<unsafe extern "C" fn(voidpf, uInt, uInt) -> voidpf>;
pub type free_func = Option::<unsafe extern "C" fn(voidpf, voidpf) -> ()>;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct z_stream_s {
    pub next_in: *mut Bytef,
    pub avail_in: uInt,
    pub total_in: uLong,
    pub next_out: *mut Bytef,
    pub avail_out: uInt,
    pub total_out: uLong,
    pub msg: *mut libc::c_char,
    pub state: *mut internal_state,
    pub zalloc: alloc_func,
    pub zfree: free_func,
    pub opaque: voidpf,
    pub data_type: libc::c_int,
    pub adler: uLong,
    pub reserved: uLong,
}
pub type z_stream = z_stream_s;
pub type z_streamp = *mut z_stream;
#[derive(Copy, Clone)]
#[repr(C)]
pub union C2RustUnnamed {
    pub c: [libc::c_uchar; 2],
    pub s: libc::c_ushort,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub union C2RustUnnamed_0 {
    pub s: [libc::c_ushort; 2],
    pub l: libc::c_ulong,
}
#[inline]
unsafe extern "C" fn __bswap_16(mut __bsx: __uint16_t) -> __uint16_t {
    return (__bsx as libc::c_int >> 8 as libc::c_int & 0xff as libc::c_int
        | (__bsx as libc::c_int & 0xff as libc::c_int) << 8 as libc::c_int)
        as __uint16_t;
}
#[unsafe(no_mangle)]
pub static mut s_iShowHelp: libc::c_int = 0 as libc::c_int;
#[unsafe(no_mangle)]
pub static mut s_iUnzip: libc::c_int = 0 as libc::c_int;
#[unsafe(no_mangle)]
pub static mut s_iSegOprate: libc::c_int = 0 as libc::c_int;
#[unsafe(no_mangle)]
pub static mut g_ulInflateCksum: libc::c_uint = 0 as libc::c_int as libc::c_uint;
#[unsafe(no_mangle)]
pub static mut doSwapNext: libc::c_int = 0 as libc::c_int;
#[unsafe(no_mangle)]
pub unsafe extern "C" fn cksum(
    mut prevSum: libc::c_ushort,
    mut buf: *const libc::c_uchar,
    mut len: libc::c_ulong,
) -> libc::c_ushort {
    let mut doSwap: libc::c_int = 0 as libc::c_int;
    let mut sum: libc::c_ulong = prevSum as libc::c_ulong;
    let mut shorty: C2RustUnnamed = C2RustUnnamed { c: [0; 2] };
    let mut longy: C2RustUnnamed_0 = C2RustUnnamed_0 { s: [0; 2] };
    longy.l = sum;
    sum = (longy.s[0 as libc::c_int as usize] as libc::c_int
        + longy.s[1 as libc::c_int as usize] as libc::c_int) as libc::c_ulong;
    if sum > 65535 as libc::c_int as libc::c_ulong {
        sum = sum.wrapping_sub(65535 as libc::c_int as libc::c_ulong);
    } else {};
    if doSwapNext != 0 {
        if buf as libc::c_long & 1 as libc::c_int as libc::c_long != 0 {
            shorty.c[0 as libc::c_int as usize] = 0 as libc::c_int as libc::c_uchar;
            shorty.c[1 as libc::c_int as usize] = *buf;
            buf = buf.offset(1);
            buf;
            len = len.wrapping_sub(1);
            len;
            sum = sum.wrapping_add(shorty.s as libc::c_ulong);
        } else {
            let mut tmp: libc::c_uchar = 0;
            doSwap = 1 as libc::c_int;
            shorty.s = sum as libc::c_ushort;
            tmp = shorty.c[0 as libc::c_int as usize];
            shorty.c[0 as libc::c_int as usize] = shorty.c[1 as libc::c_int as usize];
            shorty.c[1 as libc::c_int as usize] = tmp;
            sum = shorty.s as libc::c_ulong;
        }
    } else if buf as libc::c_long & 1 as libc::c_int as libc::c_long != 0 {
        let mut tmp_0: libc::c_uchar = 0;
        doSwap = 1 as libc::c_int;
        shorty.s = sum as libc::c_ushort;
        tmp_0 = shorty.c[0 as libc::c_int as usize];
        shorty.c[0 as libc::c_int as usize] = shorty.c[1 as libc::c_int as usize];
        shorty.c[1 as libc::c_int as usize] = tmp_0;
        sum = shorty.s as libc::c_ulong;
        shorty.c[0 as libc::c_int as usize] = 0 as libc::c_int as libc::c_uchar;
        shorty.c[1 as libc::c_int as usize] = *buf;
        buf = buf.offset(1);
        buf;
        len = len.wrapping_sub(1);
        len;
        sum = sum.wrapping_add(shorty.s as libc::c_ulong);
    }
    while len > 1 as libc::c_int as libc::c_ulong {
        sum = sum.wrapping_add(*(buf as *mut libc::c_ushort) as libc::c_ulong);
        buf = buf.offset(2 as libc::c_int as isize);
        len = len.wrapping_sub(2 as libc::c_int as libc::c_ulong);
        if len & 0x7ffe as libc::c_int as libc::c_ulong
            == 0 as libc::c_int as libc::c_ulong
        {
            longy.l = sum;
            sum = (longy.s[0 as libc::c_int as usize] as libc::c_int
                + longy.s[1 as libc::c_int as usize] as libc::c_int) as libc::c_ulong;
            if sum > 65535 as libc::c_int as libc::c_ulong {
                sum = sum.wrapping_sub(65535 as libc::c_int as libc::c_ulong);
            } else {};
        }
    }
    if len == 1 as libc::c_int as libc::c_ulong {
        doSwapNext = 1 as libc::c_int & !doSwap;
        shorty.c[0 as libc::c_int as usize] = *buf;
        shorty.c[1 as libc::c_int as usize] = 0 as libc::c_int as libc::c_uchar;
        sum = sum.wrapping_add(shorty.s as libc::c_ulong);
    }
    longy.l = sum;
    sum = (longy.s[0 as libc::c_int as usize] as libc::c_int
        + longy.s[1 as libc::c_int as usize] as libc::c_int) as libc::c_ulong;
    if sum > 65535 as libc::c_int as libc::c_ulong {
        sum = sum.wrapping_sub(65535 as libc::c_int as libc::c_ulong);
    } else {};
    longy.l = sum;
    sum = (longy.s[0 as libc::c_int as usize] as libc::c_int
        + longy.s[1 as libc::c_int as usize] as libc::c_int) as libc::c_ulong;
    if sum > 65535 as libc::c_int as libc::c_ulong {
        sum = sum.wrapping_sub(65535 as libc::c_int as libc::c_ulong);
    } else {};
    shorty.s = sum as libc::c_ushort;
    if doSwap != 0 {
        let mut tmp_1: libc::c_uchar = 0;
        tmp_1 = shorty.c[0 as libc::c_int as usize];
        shorty.c[0 as libc::c_int as usize] = shorty.c[1 as libc::c_int as usize];
        shorty.c[1 as libc::c_int as usize] = tmp_1;
    }
    return shorty.s;
}
#[unsafe(no_mangle)]
pub unsafe extern "C" fn BspDeflate(
    mut pucSrc: *const libc::c_uchar,
    mut pucDest: *mut libc::c_uchar,
    mut sourceLen: libc::c_ulong,
    mut pdestLen: *mut libc::c_ulong,
) -> libc::c_uint {
    let mut sum: libc::c_ushort = 0 as libc::c_int as libc::c_ushort;
    let mut err: libc::c_int = compress(
        pucDest.offset(1 as libc::c_int as isize),
        pdestLen as *mut uLongf,
        pucSrc,
        sourceLen,
    );
    *pucDest = 8 as libc::c_int as libc::c_uchar;
    sum = 0 as libc::c_int as libc::c_ushort;
    sum = (0xffff as libc::c_int
        - cksum(
            0 as libc::c_int as libc::c_ushort,
            pucDest,
            (*pdestLen).wrapping_add(1 as libc::c_int as libc::c_ulong),
        ) as libc::c_int) as libc::c_ushort;
    if (*pdestLen).wrapping_add(1 as libc::c_int as libc::c_ulong)
        & 0x1 as libc::c_int as libc::c_ulong != 0
    {
        sum = __bswap_16(sum);
    }
    // 使用 Rust 风格的代码复制内存
    // 计算目标地址：pucDest + *pdestLen + 1
    let dest_ptr = pucDest.offset(*pdestLen as isize).offset(1 as libc::c_int as isize) as *mut libc::c_ushort;
    // 使用 std::ptr::write 直接写入，更安全高效
    unsafe {
        std::ptr::write(dest_ptr, sum);
    }
    *pdestLen = (*pdestLen).wrapping_add(3 as libc::c_int as libc::c_ulong);
    return err as libc::c_uint;
}
#[unsafe(no_mangle)]
pub unsafe extern "C" fn BspInflate(
    mut pucSrc: *const libc::c_uchar,
    mut pucDest: *mut libc::c_uchar,
    mut sourceLen: libc::c_ulong,
    mut pdestLen: *mut libc::c_ulong,
) -> libc::c_uint {
    let mut d_stream: z_stream = z_stream {
        next_in: 0 as *mut Bytef,
        avail_in: 0,
        total_in: 0,
        next_out: 0 as *mut Bytef,
        avail_out: 0,
        total_out: 0,
        msg: 0 as *mut libc::c_char,
        state: 0 as *mut internal_state,
        zalloc: None,
        zfree: None,
        opaque: 0 as *mut libc::c_void,
        data_type: 0,
        adler: 0,
        reserved: 0,
    };
    let mut err: libc::c_int = 0;
    let mut sum: libc::c_ushort = 0 as libc::c_int as libc::c_ushort;
    if *pucSrc as libc::c_int != 8 as libc::c_int {
        return 0 as libc::c_int as libc::c_uint;
    }
    sum = ((*pucSrc.offset(sourceLen as isize).offset(-(2 as libc::c_int as isize))
        as libc::c_int) << 8 as libc::c_int
        | *pucSrc.offset(sourceLen as isize).offset(-(1 as libc::c_int as isize))
            as libc::c_int) as libc::c_ushort;
    if sum as libc::c_int != 0xffff as libc::c_int {
        if g_ulInflateCksum != 0 {
            if cksum(0 as libc::c_int as libc::c_ushort, pucSrc, sourceLen)
                as libc::c_int != 0xffff as libc::c_int
            {
                // 使用 Rust println! 替换 printf
                println!("checksum failed! sum = {}", sum as libc::c_int);
                return 0 as libc::c_int as libc::c_uint;
            }
        }
    }
    pucSrc = pucSrc.offset(1);
    pucSrc;
    sourceLen = sourceLen.wrapping_sub(3 as libc::c_int as libc::c_ulong);
    err = uncompress(pucDest, pdestLen, pucSrc, sourceLen);
    return err as libc::c_uint;
}
#[unsafe(no_mangle)]
pub unsafe extern "C" fn BspZipDataCheck(
    mut pucSrc: *const libc::c_uchar,
    mut ulBytes: libc::c_long,
) -> libc::c_uint {
    if ulBytes < 3 as libc::c_int as libc::c_long {
        return 0 as libc::c_int as libc::c_uint;
    }
    let fresh0 = pucSrc;
    pucSrc = pucSrc.offset(1);
    if *fresh0 as libc::c_int != 8 as libc::c_int {
        return 0 as libc::c_int as libc::c_uint;
    }
    if *pucSrc as libc::c_int & 8 as libc::c_int != 8 as libc::c_int {
        return 0 as libc::c_int as libc::c_uint;
    }
    if (*pucSrc as libc::c_int >> 4 as libc::c_int) + 8 as libc::c_int
        > 15 as libc::c_int
    {
        return 0 as libc::c_int as libc::c_uint;
    }
    if (((*pucSrc as libc::c_int) << 8 as libc::c_int)
        + *pucSrc.offset(1 as libc::c_int as isize) as libc::c_int) % 31 as libc::c_int
        != 0
    {
        return 0 as libc::c_int as libc::c_uint;
    }
    return 1 as libc::c_int as libc::c_uint;
}

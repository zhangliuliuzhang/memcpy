#![allow(
    dead_code,
    mutable_transmutes,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    unused_assignments,
    unused_mut
)]
#![feature(extern_types)]
unsafe extern "C" {
    fn malloc(_: libc::c_ulong) -> *mut libc::c_void;
    fn free(__ptr: *mut libc::c_void);
    // memmove 已在 surezip_clib.rs 中实现，不需要外部声明
    // fn memmove(
    //     _: *mut libc::c_void,
    //     _: *const libc::c_void,
    //     _: libc::c_ulong,
    // ) -> *mut libc::c_void;
    fn fclose(__stream: *mut FILE) -> libc::c_int;
    fn fopen(_: *const libc::c_char, _: *const libc::c_char) -> *mut FILE;
    fn fread(
        _: *mut libc::c_void,
        _: libc::c_ulong,
        _: libc::c_ulong,
        _: *mut FILE,
    ) -> libc::c_ulong;
    fn fwrite(
        _: *const libc::c_void,
        _: libc::c_ulong,
        _: libc::c_ulong,
        _: *mut FILE,
    ) -> libc::c_ulong;
    fn fseek(
        __stream: *mut FILE,
        __off: libc::c_long,
        __whence: libc::c_int,
    ) -> libc::c_int;
    fn ftell(__stream: *mut FILE) -> libc::c_long;
    fn LzmaDec_Init(p: *mut CLzmaDec);
    fn LzmaDec_Allocate(
        p: *mut CLzmaDec,
        props: *const Byte,
        propsSize: libc::c_uint,
        alloc: ISzAllocPtr,
    ) -> SRes;
    fn LzmaDec_Free(p: *mut CLzmaDec, alloc: ISzAllocPtr);
    fn LzmaEncProps_Init(p: *mut CLzmaEncProps);
    fn LzmaEnc_Create(alloc: ISzAllocPtr) -> CLzmaEncHandle;
    fn LzmaEnc_Destroy(p: CLzmaEncHandle, alloc: ISzAllocPtr, allocBig: ISzAllocPtr);
    fn LzmaEnc_SetProps(p: CLzmaEncHandle, props: *const CLzmaEncProps) -> SRes;
    static g_Alloc: ISzAlloc;
}
// use crate::surezip_clib::*;
use std::ffi::c_void;
#[repr(C)]
pub struct _IO_wide_data(c_void);
pub struct _IO_codecvt(c_void);
pub struct _IO_marker(c_void);

pub type __off_t = libc::c_long;
pub type __off64_t = libc::c_long;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct _IO_FILE {
    pub _flags: libc::c_int,
    pub _IO_read_ptr: *mut libc::c_char,
    pub _IO_read_end: *mut libc::c_char,
    pub _IO_read_base: *mut libc::c_char,
    pub _IO_write_base: *mut libc::c_char,
    pub _IO_write_ptr: *mut libc::c_char,
    pub _IO_write_end: *mut libc::c_char,
    pub _IO_buf_base: *mut libc::c_char,
    pub _IO_buf_end: *mut libc::c_char,
    pub _IO_save_base: *mut libc::c_char,
    pub _IO_backup_base: *mut libc::c_char,
    pub _IO_save_end: *mut libc::c_char,
    pub _markers: *mut _IO_marker,
    pub _chain: *mut _IO_FILE,
    pub _fileno: libc::c_int,
    pub _flags2: libc::c_int,
    pub _old_offset: __off_t,
    pub _cur_column: libc::c_ushort,
    pub _vtable_offset: libc::c_schar,
    pub _shortbuf: [libc::c_char; 1],
    pub _lock: *mut libc::c_void,
    pub _offset: __off64_t,
    pub _codecvt: *mut _IO_codecvt,
    pub _wide_data: *mut _IO_wide_data,
    pub _freeres_list: *mut _IO_FILE,
    pub _freeres_buf: *mut libc::c_void,
    pub __pad5: libc::c_int,
    pub _mode: libc::c_int,
    pub _unused2: libc::c_char,
}
pub type _IO_lock_t = ();
pub type FILE = _IO_FILE;
pub type SRes = libc::c_int;
pub type Byte = libc::c_uchar;
pub type UInt16 = libc::c_ushort;
pub type UInt32 = libc::c_uint;
pub type Int64 = libc::c_longlong;
pub type UInt64 = libc::c_ulonglong;
pub type SizeT = libc::c_int;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct ISzAlloc {
    pub Alloc: Option::<
        unsafe extern "C" fn(ISzAllocPtr, libc::c_int) -> *mut libc::c_void,
    >,
    pub Free: Option::<unsafe extern "C" fn(ISzAllocPtr, *mut libc::c_void) -> ()>,
}
pub type ISzAllocPtr = *const ISzAlloc;
pub type CLzmaProb = UInt16;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct _CLzmaProps {
    pub lc: Byte,
    pub lp: Byte,
    pub pb: Byte,
    pub _pad_: Byte,
    pub dicSize: UInt32,
}
pub type CLzmaProps = _CLzmaProps;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct CLzmaDec {
    pub prop: CLzmaProps,
    pub probs: *mut CLzmaProb,
    pub probs_1664: *mut CLzmaProb,
    pub dic: *mut Byte,
    pub dicBufSize: SizeT,
    pub dicPos: SizeT,
    pub buf: *const Byte,
    pub range: UInt32,
    pub code: UInt32,
    pub processedPos: UInt32,
    pub checkDicSize: UInt32,
    pub reps: [UInt32; 4],
    pub state: UInt32,
    pub remainLen: UInt32,
    pub numProbs: UInt32,
    pub tempBufSize: libc::c_uint,
    pub tempBuf: [Byte; 20],
}
pub type ELzmaFinishMode = libc::c_uint;
pub const LZMA_FINISH_END: ELzmaFinishMode = 1;
pub const LZMA_FINISH_ANY: ELzmaFinishMode = 0;
pub type ELzmaStatus = libc::c_uint;
pub const LZMA_STATUS_MAYBE_FINISHED_WITHOUT_MARK: ELzmaStatus = 4;
pub const LZMA_STATUS_NEEDS_MORE_INPUT: ELzmaStatus = 3;
pub const LZMA_STATUS_NOT_FINISHED: ELzmaStatus = 2;
pub const LZMA_STATUS_FINISHED_WITH_MARK: ELzmaStatus = 1;
pub const LZMA_STATUS_NOT_SPECIFIED: ELzmaStatus = 0;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct _CLzmaEncProps {
    pub level: libc::c_int,
    pub dictSize: UInt32,
    pub lc: libc::c_int,
    pub lp: libc::c_int,
    pub pb: libc::c_int,
    pub algo: libc::c_int,
    pub fb: libc::c_int,
    pub btMode: libc::c_int,
    pub numHashBytes: libc::c_int,
    pub mc: UInt32,
    pub writeEndMark: libc::c_uint,
    pub numThreads: libc::c_int,
    pub reduceSize: UInt64,
    pub affinity: UInt64,
}
pub type CLzmaEncProps = _CLzmaEncProps;
pub type CLzmaEncHandle = *mut libc::c_void;
#[derive(Copy, Clone)]
#[repr(C, packed)]
pub struct T_lzma_header {
    pub props: [libc::c_uchar; 12],
    pub unpack_size: UInt64,
}
static mut PrnLama: libc::c_ulong = 0 as libc::c_int as libc::c_ulong;
#[unsafe(no_mangle)]
pub unsafe extern "C" fn LzmaGetHeaderInfo(
    mut srcbuf: *mut libc::c_uchar,
    mut BufLength: libc::c_ulong,
    mut ptLocalHeader: *mut T_lzma_header,
) -> libc::c_int {
    // 添加空指针检查，避免段错误
    if srcbuf.is_null() || ptLocalHeader.is_null() {
        return 0x106 as libc::c_int;
    }
    // 先检查长度，避免不必要的操作
    if BufLength < ::core::mem::size_of::<T_lzma_header>() as libc::c_ulong {
        println!("BufLength");
        return 0x106 as libc::c_int;
    }
    
    let mut i: libc::c_int = 0;
    // 使用 Rust 风格的代码复制内存
    // 安全地访问 packed 结构体的字段
    unsafe {
        let props_ptr = std::ptr::addr_of_mut!((*ptLocalHeader).props) as *mut libc::c_void;
        // 使用 std::ptr::copy_nonoverlapping 替代 memmove（Rust 风格）
        std::ptr::copy_nonoverlapping(
            srcbuf as *const libc::c_void,
            props_ptr,
            5, // 复制 5 个字节
        );
    }
    // // PrnLama 已初始化为 0，不会执行调试代码
    // // 安全地访问 packed 结构体的字段，避免对齐错误
    // unsafe {
    //     let unpack_size_ptr = std::ptr::addr_of_mut!((*ptLocalHeader).unpack_size);
    //     // *unpack_size_ptr = 0 as libc::c_int as UInt64;
    // }
    // i = 0 as libc::c_int;
    // while i < 8 as libc::c_int {
    //     unsafe {
    //         let unpack_size_ptr = std::ptr::addr_of_mut!((*ptLocalHeader).unpack_size);
    //         let current_size = *unpack_size_ptr;
    //         *unpack_size_ptr = (current_size as libc::c_ulonglong)
    //             .wrapping_add(
    //                 (*srcbuf.offset((5 as libc::c_int + i) as isize) as UInt64)
    //                     << i * 8 as libc::c_int,
    //             ) as UInt64 as UInt64;
    //     }
    //     i += 1;
    //     i;
    // }
    // PrnLama 已初始化为 0，不会执行调试代码
    return 0 as libc::c_int;
}

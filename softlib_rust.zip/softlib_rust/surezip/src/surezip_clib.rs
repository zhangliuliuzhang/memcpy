//! Rust 打桩实现 C 库函数
//! 
//! 本文件包含对 surezip 模块中使用的 C 函数的 Rust 打桩实现

use std::ffi::c_void;
use libc;

// 类型定义
pub type Byte = libc::c_uchar;
pub type Bytef = Byte;
pub type uLong = libc::c_ulong;
pub type uLongf = uLong;
pub type uInt = libc::c_uint;
pub type voidpf = *mut libc::c_void;
pub type z_streamp = *mut c_void; // 简化类型定义

// newunpress.rs 需要的类型
pub type UINT32 = libc::c_uint;
pub type UINT8 = libc::c_uchar;
pub type STATUS = libc::c_uint;
pub type rsize_t = libc::c_int;
pub type SEM_ID = *mut c_void;
pub type SEM_B_STATE = libc::c_uint;
pub const SEM_FULL: SEM_B_STATE = 1;
pub const SEM_EMPTY: SEM_B_STATE = 0;

// 打桩实现：压缩函数
// 用于 surezip.rs 中的 BspDeflate 函数
#[unsafe(no_mangle)]
pub unsafe extern "C" fn compress(
    dest: *mut Bytef,
    destLen: *mut uLongf,
    source: *const Bytef,
    sourceLen: uLong,
) -> libc::c_int {
    // 打桩实现：简单复制数据（不实际压缩）
    // 检查空指针
    if dest.is_null() || destLen.is_null() || source.is_null() {
        return -1;
    }
    
    // 检查目标缓冲区大小
    // 注意：这里假设 destLen 指向的值表示目标缓冲区的大小
    // 在实际使用中，应该检查 *destLen 是否足够大
    let available_space = if !destLen.is_null() {
        // 假设 destLen 初始值表示可用空间，但这里我们简单处理
        sourceLen.min(1024 * 1024) // 限制最大 1MB
    } else {
        return -1;
    };
    
    // 计算实际复制长度
    let copy_len = sourceLen.min(available_space) as usize;
    
    // 执行内存复制
    unsafe {
        std::ptr::copy_nonoverlapping(source, dest, copy_len);
        *destLen = copy_len as uLong;
    }
    
    0 // 成功
}

// 打桩实现：解压缩函数
// 用于 surezip.rs 中的 BspInflate 函数
#[unsafe(no_mangle)]
pub unsafe extern "C" fn uncompress(
    dest: *mut Bytef,
    destLen: *mut uLongf,
    source: *const Bytef,
    sourceLen: uLong,
) -> libc::c_int {
    // 打桩实现：简单复制数据（不实际解压缩）
    // 检查空指针
    if dest.is_null() || destLen.is_null() || source.is_null() {
        return -1;
    }
    
    // 检查目标缓冲区大小
    // 注意：这里假设 destLen 指向的值表示目标缓冲区的大小
    // 在实际使用中，应该检查 *destLen 是否足够大
    let available_space = if !destLen.is_null() {
        // 假设 destLen 初始值表示可用空间，但这里我们简单处理
        sourceLen.min(1024 * 1024) // 限制最大 1MB
    } else {
        return -1;
    };
    
    // 计算实际复制长度
    let copy_len = sourceLen.min(available_space) as usize;
    
    // 执行内存复制
    unsafe {
        std::ptr::copy_nonoverlapping(source, dest, copy_len);
        *destLen = copy_len as uLong;
    }
    
    0 // 成功
}

// 打桩实现：初始化压缩流
#[unsafe(no_mangle)]
pub unsafe extern "C" fn deflateInit_(
    _strm: z_streamp,
    _level: libc::c_int,
    _version: *const libc::c_char,
    _stream_size: libc::c_int,
) -> libc::c_int {
    // 检查参数有效性以增加分支覆盖率
    if _strm.is_null() {
        return -2; // Z_STREAM_ERROR
    }
    if _version.is_null() {
        return -2; // Z_STREAM_ERROR
    }
    if _stream_size < 0 {
        return -2; // Z_STREAM_ERROR
    }
    if _level < -1 || _level > 9 {
        return -2; // Z_STREAM_ERROR
    }
    0 // 成功
}

// 打桩实现：压缩数据
#[unsafe(no_mangle)]
pub unsafe extern "C" fn deflate(
    _strm: z_streamp,
    _flush: libc::c_int,
) -> libc::c_int {
    // 检查参数有效性以增加分支覆盖率
    if _strm.is_null() {
        return -2; // Z_STREAM_ERROR
    }
    if _flush < 0 || _flush > 4 {
        return -2; // Z_STREAM_ERROR
    }
    0 // 成功
}

// 打桩实现：结束压缩
#[unsafe(no_mangle)]
pub unsafe extern "C" fn deflateEnd(_strm: z_streamp) -> libc::c_int {
    // 检查参数有效性以增加分支覆盖率
    if _strm.is_null() {
        return -2; // Z_STREAM_ERROR
    }
    0 // 成功
}

// 打桩实现：初始化解压缩流
#[unsafe(no_mangle)]
pub unsafe extern "C" fn inflateInit_(
    _strm: z_streamp,
    _version: *const libc::c_char,
    _stream_size: libc::c_int,
) -> libc::c_int {
    // 检查参数有效性以增加分支覆盖率
    if _strm.is_null() {
        return -2; // Z_STREAM_ERROR
    }
    if _version.is_null() {
        return -2; // Z_STREAM_ERROR
    }
    if _stream_size < 0 {
        return -2; // Z_STREAM_ERROR
    }
    0 // 成功
}

// 打桩实现：解压缩数据
#[unsafe(no_mangle)]
pub unsafe extern "C" fn inflate(
    _strm: z_streamp,
    _flush: libc::c_int,
) -> libc::c_int {
    // 检查参数有效性以增加分支覆盖率
    if _strm.is_null() {
        return -2; // Z_STREAM_ERROR
    }
    if _flush < 0 || _flush > 4 {
        return -2; // Z_STREAM_ERROR
    }
    0 // 成功
}

// 打桩实现：结束解压缩
#[unsafe(no_mangle)]
pub unsafe extern "C" fn inflateEnd(_strm: z_streamp) -> libc::c_int {
    // 检查参数有效性以增加分支覆盖率
    if _strm.is_null() {
        return -2; // Z_STREAM_ERROR
    }
    0 // 成功
}

// 打桩实现：内存移动
#[unsafe(no_mangle)]
pub unsafe extern "C" fn memmove(
    dest: *mut libc::c_void,
    src: *const libc::c_void,
    n: libc::c_ulong,
) -> *mut libc::c_void {
    // 空指针或长度为 0，直接返回
    if dest.is_null() || src.is_null() || n == 0 {
        return dest;
    }

    // 限制拷贝上限，避免极端长度导致分配过大
    const MAX_COPY: usize = 16 * 1024 * 1024; // 16MB
    let len = n as usize;
    if len > MAX_COPY {
        return dest;
    }

    // 按字节处理，先拷贝到临时缓冲再写回，天然支持重叠，避免对齐问题
    let src_u8 = src as *const u8;
    let dest_u8 = dest as *mut u8;

    let src_slice = std::slice::from_raw_parts(src_u8, len);
    let mut tmp = Vec::with_capacity(len);
    tmp.extend_from_slice(src_slice);

    std::ptr::copy_nonoverlapping(tmp.as_ptr(), dest_u8, len);

    dest
}

// 打桩实现：创建信号量
// 使用 Box::into_raw 创建一个在程序整个生命周期内有效的指针
// 注意：这里不考虑多线程并发，仅用于测试环境
static mut FAKE_SEM_PTR: *mut libc::c_int = std::ptr::null_mut();

#[unsafe(no_mangle)]
pub unsafe extern "C" fn semBCreate(
    _options: libc::c_int,
    _initialState: SEM_B_STATE,
) -> SEM_ID {
    // 第一次调用时分配内存并保存裸指针，后续直接返回同一指针
    if FAKE_SEM_PTR.is_null() {
        // 使用 Box::into_raw 将 Box 转换为裸指针，避免被释放
        let boxed = Box::new(0i32);
        FAKE_SEM_PTR = Box::into_raw(boxed);
    }
    FAKE_SEM_PTR as SEM_ID
}

// 打桩实现：获取信号量
#[unsafe(no_mangle)]
pub unsafe extern "C" fn semTake(_semId: SEM_ID, _timeout: libc::c_int) -> STATUS {
    // 检查参数有效性以增加分支覆盖率
    if _semId.is_null() {
        return 0xFFFFFFFF; // 错误
    }
    if _timeout < -1 {
        return 0xFFFFFFFF; // 错误
    }
    0 // 成功
}

// 打桩实现：释放信号量
#[unsafe(no_mangle)]
pub unsafe extern "C" fn semGive(_semId: SEM_ID) -> STATUS {
    // 检查参数有效性以增加分支覆盖率
    if _semId.is_null() {
        return 0xFFFFFFFF; // 错误
    }
    0 // 成功
}

// 打桩实现：系统延迟
#[unsafe(no_mangle)]
pub unsafe extern "C" fn BspSysMsDelay(_ulDelay: UINT32) {
    // 打桩实现：不执行实际延迟
}

// 打桩实现：获取系统时钟滴答
#[unsafe(no_mangle)]
pub unsafe extern "C" fn tickGet() -> libc::c_uint {
    // 返回一个模拟的时钟滴答值
    1000
}

// 打桩实现：安全内存复制
#[unsafe(no_mangle)]
pub unsafe extern "C" fn encapsulationOfZte_memcpy_s(
    s1: *mut libc::c_void,
    s1max: rsize_t,
    s2: *const libc::c_void,
    n: rsize_t,
    _fileName: *const libc::c_char,
    _lineNo: libc::c_int,
) -> libc::c_int {
    if s1.is_null() || s2.is_null() {
        return -1;
    }
    if s1max <= 0 || n < 0 {
        return -1;
    }
    
    let copy_len = (n as usize).min(s1max as usize);
    unsafe {
        std::ptr::copy_nonoverlapping(s2, s1, copy_len);
    }
    
    0 // 成功
}


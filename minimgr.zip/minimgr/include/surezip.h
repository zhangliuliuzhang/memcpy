/*****************************************************************************
 * 版权所有(C) 2009, ZTE Corp. WiMAX
 *----------------------------------------------------------------------------
 * 模 块 名 : TOOLS
 * 文件名称 : surezip.h
 * 文件标识 : {[N/A]}
 * 内容摘要 : ZLIB库函数之应用, 压缩和解压缩
 * 注意事项 : 从网上搜集而来, 兼以VXWORKS的inflate.c库文件源码
 * 作    者 : 田瑞忠
 * 创建日期 : 2010-05-18
 * 当前版本 : Ver1.0
 *----------------------------------------------------------------------------
 * 变更记录 :
 *
 * $记录1
 * 变 更 单: $0000000(N/A)
 * 责 任 人: 田瑞忠
 * 修改日戳: 2010-5-18 19:07:08
 * 变更说明: 创建
 *

 * $记录2
 * 变 更 单: $0000000(N/A)
 * 责 任 人: 宋志强
 * 修改日戳: 2018-01-18
 * 变更说明: 代码重构，符合开源合规，同时修改BspComp,为BspDeflate,修改 BspDeComp为BspInflate
 *
 *----------------------------------------------------------------------------
 */

#ifndef SUREZIP_H
#define SUREZIP_H


unsigned int  BspDeflate(const unsigned char *pucSrc, unsigned char *pucDest, unsigned long sourceLen, unsigned long *pdestLen);
unsigned int BspInflate(const unsigned char  *pucSrc, unsigned char  *pucDest, unsigned long sourceLen, unsigned long *pdestLen);

long BspSegzip(int ulSegNo, unsigned char *pucSrc, unsigned char *pucDest, long *plBytes, long *plBufSize);
short BspSegUnzip(int ulSegNo, unsigned char *pucSrc, unsigned char *pucDest, long *plBytes, long *plBufSize);

unsigned int BspZipDataCheck(const unsigned char *pucSrc, long lBytes);
long BspGetUnZipLen(unsigned char *pucSrc, long lBytes);
unsigned int vx_inflate (unsigned char *src, unsigned char *dest, unsigned long nBytes, size_t *pOutBytes);


#endif /* SUREZIP_H */


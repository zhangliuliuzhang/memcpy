/************************************************************************
* 版权所有 (C)2008, 深圳市中兴通讯股份有限公司。
* 
* 文件名称： NewUnpress.h
* 文件标识： WCDMA
* 内容摘要： V4版本解压实现
* 其它说明： 
* 当前版本： 1.0
* 作    者： wood
* 完成日期：
* 
* 修改记录1：
*    修改日期：
*    版 本 号：
*    修 改 人：
*    修改内容：
************************************************************************/
#ifndef NEWUNPRESS_H
#define NEWUNPRESS_H



/**************************************************************************
 *                            常量                                        *
 **************************************************************************/
#define UNPRESS_EC_BASE                     0x20000000
#define UNPRESS_EC_NULL_BUFFER              (UNPRESS_EC_BASE + 1)
#define UNPRESS_EC_WHOLE_FILE_CRC_ERROR     (UNPRESS_EC_BASE + 2)
#define UNPRESS_EC_WHOLE_FILE_LEN_ERROR     (UNPRESS_EC_BASE + 3)
#define UNPRESS_EC_PACKED_FILE_CRC_ERROR    (UNPRESS_EC_BASE + 4)
#define UNPRESS_EC_UNPACK_ERROR             (UNPRESS_EC_BASE + 5)
#define UNPRESS_EC_UNPACKED_FILE_CRC_ERROR  (UNPRESS_EC_BASE + 6)
#define UNPRESS_EC_DIV_NUM_ERROR            (UNPRESS_EC_BASE + 7)

#define UNPRESS_OK                          (BSP_OK)
#ifndef SW_MAX_NUMBER
#define SW_MAX_NUMBER                       10    /* 限制下载软件中文件的个数 */
#endif

/**************************************************************************
 *                           宏定义                                       *
 **************************************************************************/

/**************************************************************************
 *                          数据类型                                      *
 **************************************************************************/

#pragma pack(1)

/* T_VerFileHeader move to Bsp.h*/

typedef struct TagSwIdInfo      /* 软件包头中每个软件的ID和大小信息 */
{
    unsigned char    ucSwId                      ;   /* 软件包中的软件ID */
    unsigned int    ulSwLen                     ;   /* 软件包中的软件大小 */
}TSwIdInfo, *PTSwIdInfo;

typedef struct TagSwPackage     /* 软件包的文件头结构 */
{
    unsigned char    ucSwNum                     ;   /* 软件包中的软件个数 */
    TSwIdInfo        atSwIdInfo[SW_MAX_NUMBER]   ;   /* 每个软件的ID和大小 */
  /*unsigned long    ulSwHeaderLen               ;    软件包头的大小：sizeof(unsigned char)+sizeof(TSwIdInfo)*ucSwNum */
}TSwPackage, *PTSwPackage;

#pragma pack()

/**************************************************************************
 *                           类声明                                       *
 **************************************************************************/



/**************************************************************************
 *                            模板                                        *
 **************************************************************************/



/**************************************************************************
 *                         全局变量声明                                   *
 **************************************************************************/



/**************************************************************************
 *                         全局函数原型                                   *
 **************************************************************************/
unsigned long GetDivFromUnion(unsigned char  *pucUnion,
                              unsigned long   dwWorkMode,
                              unsigned char **pucDivAddr,
                              unsigned long  *pulLength);

unsigned long NewUnpress(unsigned char *pucInFile,
                         unsigned long  ulFileLen,
                         unsigned char *pucOutFile);

unsigned long UnpressV4(unsigned char *ucInFile,
                        unsigned long  ulFileLen,
                        unsigned char *ucOutFile);


unsigned long GetDivFromUnionByIndex(unsigned char  *pucUnion,
                              UINT32   ulIndex,
                              unsigned char **pucDivAddr,
                              unsigned long  *pulLength);

void RegHeaderByteOrder(T_VerFileHeader  *ptVerHeader);

#endif /* NEWUNPRESS_H */


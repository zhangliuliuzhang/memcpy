#ifndef __ELF_SYMBOL_H__
#define __ELF_SYMBOL_H__

#include "pub_typedef.h"

/* elf function */
WORD32 symFindByName(CHAR *name, WORDPTR *pValue, WORD32 *size, WORD32 *pType);
ULONG findFunNameByPc(ULONG uladdr, CHAR *pucFunName);
ULONG matchFunName(CHAR *pfunname);
void PrintSymTable();
WORD32 symShow(CHAR *name);
WORD32 PrintSelfSemPosByValue(WORDPTR value);
WORD32 InitSymbolTable(CHAR *filename);
WORD32 FreeSymbolTable();
WORD32 symShowEx(CHAR *name, UCHAR ucRadioMode);
WORD32 symFindAttrByValueEx(WORDPTR value, CHAR *name, WORDPTR *pValue, 
                         WORD32 *pType, WORD32 *pSize, UCHAR ucRadioMode);
WORD32 symFindAttrByValue(WORDPTR value, CHAR *name, WORDPTR *pValue, 
                         WORD32 *pType, WORD32 *pSize);


#endif //__ELF_SYMBOL_H__

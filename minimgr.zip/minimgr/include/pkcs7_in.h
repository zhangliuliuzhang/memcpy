/************************************************************************
 * 版权所有   (C)2011, 深圳市中兴通讯股份有限公司。
 * 文件名称： pkcs7_in.h
 * 文件标识：
 * 内容摘要： 
 * 其它说明：
 * 当前版本：
 * 作    者： lianglin
 * 完成日期： 2011年2月16日
 ************************************************************************/
#ifndef PKI_PKCS7_H
#define PKI_PKCS7_H

#include "openssl/x509.h"
#include "openssl/pem.h"
#include "openssl/pkcs7.h"


/**************************************************************/
/*                     内部宏定义                             */
/**************************************************************/

#define PKI_PKCS7_ERR            (WORD32)0   
#define PKI_PKCS7_OK             (WORD32)1    
#define PKI_PKCS7_INVALID        (WORD32)2 

#define FORMAT_ASN1     1
#define FORMAT_PEM      3

#define IS_ROOTCA(x) (0 == X509_name_cmp(X509_get_issuer_name(x), X509_get_subject_name(x))) 

/* PKI支持的应用类型定义 */
#define PKI_APP_NOEXIST            (BYTE)0
#define PKI_APP_OPERATOR_CERT      (BYTE)1
#define PKI_APP_VENDOR_CERT        (BYTE)2  /* 为保证前后台接口(下载证书、查询证书)保持一致，设备商目录编号置为2 */
#define PKI_APP_TRUSTCA_CERT       (BYTE)3  /* 信任证书 */
#define PKI_APP_CROSS_CERT         (BYTE)4  /* 交叉证书 */
#define PKI_APP_CRL                (BYTE)5  /* 证书撤销 *//*action_upd_crl*/
#define PKI_APP_OVERFLOW           (BYTE)6  /* 应用溢出数 */

/* start for 为了直接打印BRS的内存调用链，调用Trace系列的函数 by zengmiao 2012-05-10 */
/*typedef SWORD32 (*free_node_function)(void*);*/
typedef SWORD32 (*free_node_function)(void*, void*, WORD32);
/* end for 为了直接打印BRS的内存调用链，调用Trace系列的函数 by zengmiao 2012-05-10 */


typedef struct cert_link
{
    void *data;
    size_t len;
    free_node_function free_node;
    struct cert_link *next;
    struct cert_link *prev;
}link_t;

typedef struct cert cert_t, T_CERT, *PT_CERT;

typedef struct link_cert
{
    PT_CERT data;
    INT num;
    CHAR Filename[64];
    struct link_cert *next;
}multi_cert, *PT_MultiCert;

/**************************************************************/
/*                    对外函数声明                                */
/**************************************************************/

WORD32 BrsReadPkcs7ToCertList(CHAR *psFullFileName, BYTE ucAppNo, link_t **ptCertNodeList,INT *num);
WORD32 BrsGetCaCertToVerifyCrossCert(link_t * pCertlist);
WORD32 BrsDelMultiCertListInMemory(CHAR *psFileName, BYTE ucAppNo, PT_MultiCert MultiCert);


#endif /* #ifndef PKI_PKCS7_H */

#ifndef __INCtaskLibh
#define __INCtaskLibh

#ifdef VOS_LINUX
#include <errno.h>
#include <assert.h>
#include <unistd.h>
#include <sched.h>
#include <sys/mman.h>
#include <stdlib.h>
#include <stdio.h>
#include <signal.h>
#include <fcntl.h>
#include <sys/time.h>
#include <string.h>
#include <pthread.h>
#include <linux/fs.h>       /* everything... */
#include <linux/pci.h>
#include <semaphore.h>
#include <mqueue.h>
#include <syscall.h>
#include "pub_typedef.h"
#endif

#ifdef VOS_CYGWIN
#include <errno.h>
#include <assert.h>
#include <unistd.h>
#include <sched.h>
#include <sys/mman.h>
#include <stdlib.h>
#include <stdio.h>
#include <signal.h>
#include <fcntl.h>
#include <sys/time.h>
#include <string.h>
#include <pthread.h>
#include <semaphore.h>
#include <mqueue.h>
#include "pub_typedef.h"
#endif

#ifdef __cplusplus
extern "C" {
#endif


/* ��Zte_v2l.hת�ƹ��� */
/* ��1.1.7B2����Ʒ�߲����࣬�г�ͻ */
//typedef struct v2pt_wdog *WDOG_ID;
/* ���ݸ߲�Ľ���ע��v2pt_wdog���� ʯ��2010-9-26 */
#if 0
typedef struct v2pt_wdog
{
    int magic;
    pthread_mutex_t wdog_lock;

    /* TS is zero means this watchdog is inactive */
        struct timespec ts;
    int (*timeout_func) (int);
    int timeout_parm;
    struct v2pt_wdog *next;
} v2pt_wdog_t;
#endif
/* Zte_v2l.hת�ƹ����Ķ������ */

#if 1/*2011-04-09 yxy*/
#define  DISABLE_SEM_V2LIN_STYLE
#define COUNT_SEM_TYPE             0x1
#define SYNC_SEM_TYPE              0x2
#define MUTEX_TYPE                 0x3
#endif


/*�û�̬�ж���غ궨��*/
#define KDA_NAME  "KernDrvAgt"
#define KDA_MAJOR 10  /*Misc Drive Major*/
#define KDA_MINOR 244

#define KDA_SUCCESS  0
#define KDA_ERROR    1
#define KDA_TIMEOUT  2
#define KDA_SIGOUT   3   /*�ȴ�״̬�У����źŴ��*/
#define KDA_FAULT    4   /*�ڴ���ʴ���*/
#define KDA_OBJ_DELETE    5   /*����ɾ��*/

#define MUX_DEV_NAME_LEN        255

#ifdef NXP_32_TO_64_KDA
#define KDA_ACESS_TYPE  unsigned long long
#define INT_NUM_TYPE    unsigned short
#else
#define KDA_ACESS_TYPE  unsigned long
#define INT_NUM_TYPE    unsigned short
#endif

//typedef void      (*VOIDFUNCPTR) (); /* ptr to function returning void */

extern STATUS kdaLibInit(void);

extern STATUS intConnect
(
    VOIDFUNCPTR *vector,    /* interrupt vector to attach to     */
    VOIDFUNCPTR routine,    /* routine to be called              */
    int parameter       /* parameter to be passed to routine */
);

typedef struct  {
    KDA_ACESS_TYPE dev_id; /* Device ID */
    KDA_ACESS_TYPE rs;  /* Operation Return Status */
    KDA_ACESS_TYPE rv; /* Operation Return Value*/
    KDA_ACESS_TYPE d0;  /* Operation specific data */
    KDA_ACESS_TYPE d1;
    KDA_ACESS_TYPE d2;
    KDA_ACESS_TYPE d3;
    KDA_ACESS_TYPE dx[17];
}kda_ioctl_t;

typedef struct _tad_kdaScheTimeGetParm
{
   int              pid;
   struct timespec *pTmRet;
}kdaScheTimeGetParm;

typedef void (*kda_irq_func_t)(void*);

#if (!defined(CONFIG_KDA_MUL_PROCESS))
STATUS kdaIrqHdBind(int vector, kda_irq_func_t isr_func,void *data);
#endif

#ifdef CONFIG_KDA_MUL_PROCESS

#define MPC_85XX_IRQS      512
#define KDA_NR_IRQS        MPC_85XX_IRQS
typedef struct __tag_Act_Irq
{
   KDA_ACESS_TYPE  IrqCnt;
   KDA_ACESS_TYPE  IrqStat;
   KDA_ACESS_TYPE  IrqReserved[5];  /*Ԥ��*/
   INT_NUM_TYPE    IrqNumArray[KDA_NR_IRQS]; /*ע������IrqNumArray��������������ݽṹ��ĩ��Ա���ں�������copyt to user ʱֻ��IrqNumArray[IrqCnt]֮ǰ�ĳ�Ա,liuzhw*/
}kda_act_irq_t;

typedef struct {
    void *data;
   kda_act_irq_t      *s_tActIrq; //add
}kda_handler_parm_t;
#endif

#ifdef CONFIG_KDA_MUL_PROCESS
typedef struct {
    kda_handler_parm_t handler_parm_t;
    kda_irq_func_t handler;
    int vector;
} kda_irq_handler_t;
#else
typedef struct {
    void *data;
    kda_irq_func_t handler;
    int vector;
    unsigned int intrCnt;
} kda_irq_handler_t;
#endif

#define KDA_DEVICE_MAGIC 0x44490000
// #define CSM6700_DEVICE_ID (KDA_DEVICE_MAGIC + 1)

/* ioctls  cmd*/

#define KDA_CMD_MAGIC 0x44410000
#define _KDA_CMD(magic,num) (KDA_CMD_MAGIC + num)

#ifdef CONFIG_KDA_MUL_PROCESS
enum
{
    /*PCI-CMD*/
    KDA_PCI_GET_DEV = _KDA_CMD(KDA_CMD_MAGIC, 1),
    KDA_PCI_CONFIG_PUT32,
    KDA_PCI_CONFIG_GET32,
    KDA_PCI_CONFIG_PUT16,
    KDA_PCI_CONFIG_GET16,
    KDA_PCI_DEV_RESUME,
    KDA_PCI_FINDDEVICE,
    KDA_PCI_CONFIG_INLONG,
    KDA_PCI_CONFIG_INWORD,
    KDA_PCI_CONFIG_INBYTE,    /* 10 */
    KDA_PCI_CONFIG_OUTLONG,
    KDA_PCI_CONFIG_OUTWORD,
    KDA_PCI_CONFIG_OUTBYTE,
    /*DMA CMD*/
    KDA_DMA_ALLOC_MEM,
    KDA_DMA_FREE_MEM,
    /*INT CMD*/
    KDA_INTERRUPT_REQUEST,
    KDA_INTERRUPT_FREE,
    KDA_INTERRUPT_ENABLE,
    KDA_INTERRUPT_DISABLE,
    KDA_WAIT_FOR_INTERRUPT,
    KDA_INTERRUPT_LOCK,
    KDA_INTERRUPT_UNLOCK,
    /*MISC cmd*/
    KDA_GET_SCHE_TIME,

    /*MUX CMDS*/
    KDA_DEV_MUX_INIT,
    KDA_DEV_MUX_BIND,
    KDA_DEV_MUX_RCV,
    KDA_DEV_MUX_TX,
    KDA_DEV_MUX_FREE,
    KDA_DEV_MUX_SEND,
    KDA_MUX_TX_ALLOC,
    KDA_MUX_RX_START,
    KDA_MUX_TX_FREE,
    KDA_MUX_RX_MMAP,
    /*KDA write flash*/
    KDA_WRITE_FLASH,
    KDA_FLASH_MUTEX_DISABLE,
    KDA_FLASH_MUTEX_ENABLE,
    /*KDA mult task intconnect surport*/
    KDA_GET_INT_MEM,
    KDA_FREE_INT_MEM,
    KDA_SET_GPIO_MASK,
    /*
    KDA_TEST_INFO,
    KDA_INIT_GPIO_RESEND,
    KDA_REINIT_GPIO_MASK,
    */
    /*KDA RRUID*/
    KDA_SET_RRUID_MAP,
    KDA_GET_RRUID_MAP,

    KDA_BTTL_PARA_CHANGE,
    KDA_SIG_MODE,
    KDA_GET_PTE,
    KDA_SET_SMMU,
    KDA_GET_PTES_INFO,

    KDA_SMP_CPU_UP,
    KDA_RELEASE_RSVMEM,
    /*  Լ���ճ�(KDA_CMD_MAGIC+50)��ǰ��CGEL3.X���������룬
     *  �����߼̳�+1������������ơ�
     *  Լ��LSP��BSPһ�´�(KDA_CMD_MAGIC+50)��CGEL4.X���������룬
     *  �����߼̳�+1������������ơ�
     *  Լ��LSP��BSPһ�´�(KDA_CMD_MAGIC+60)��CGEL6.X���������룬
     *  �����߼̳�+1������������ơ�
     *  Լ��LSP��BSPһ�´�(KDA_CMD_MAGIC+100)���¹������������룬
     *  �����߼̳�+1������������ơ�
     */
    /***************CGEL4.X (KDA_CMD_MAGIC+50)******************/
    KDA_BOARD_INFO_SET = _KDA_CMD(KDA_CMD_MAGIC, 50),
    KDA_DSPCFG_REGSET = _KDA_CMD(KDA_CMD_MAGIC, 51),//for DSP BOOT ADDR setting
    KDA_MDIO_READ = _KDA_CMD(KDA_CMD_MAGIC, 52),    /*note:only for dra62x*/
    KDA_MDIO_WRITE = _KDA_CMD(KDA_CMD_MAGIC, 53),   /*note:only for dra62x*/

    /***************CGEL6.X (KDA_CMD_MAGIC+60)*****************/
    KDA_PCI_MSIX_INT_GET = _KDA_CMD(KDA_CMD_MAGIC, 60),

    /***************COMMON (KDA_CMD_MAGIC+100)*****************/
    /* PHY MDIO READ WRITE*/
    KDA_MDIO_READ_COMMON = _KDA_CMD(KDA_CMD_MAGIC, 100),
    KDA_MDIO_WRITE_COMMON = _KDA_CMD(KDA_CMD_MAGIC, 101),
    KDA_SERIAL_RECORD_MEMORY = _KDA_CMD(KDA_CMD_MAGIC, 102),
    KDA_PRINT_IN_OS = _KDA_CMD(KDA_CMD_MAGIC, 103),
};

#else
enum
{
/*PCI-CMD*/
    KDA_PCI_GET_DEV = _KDA_CMD(KDA_CMD_MAGIC, 1),
    KDA_PCI_CONFIG_PUT32,
    KDA_PCI_CONFIG_GET32,
    KDA_PCI_CONFIG_PUT16,
    KDA_PCI_CONFIG_GET16,
    KDA_PCI_DEV_RESUME,
    KDA_PCI_FINDDEVICE,
    KDA_PCI_CONFIG_INLONG,
    KDA_PCI_CONFIG_INWORD,
    KDA_PCI_CONFIG_INBYTE,    /* 10 */
    KDA_PCI_CONFIG_OUTLONG,
    KDA_PCI_CONFIG_OUTWORD,
    KDA_PCI_CONFIG_OUTBYTE,
/*DMA CMD*/
    KDA_DMA_ALLOC_MEM,
    KDA_DMA_FREE_MEM,
/*INT CMD*/
    KDA_INTERRUPT_REQUEST,
    KDA_INTERRUPT_FREE,
    KDA_INTERRUPT_ENABLE,
    KDA_INTERRUPT_DISABLE,
    KDA_WAIT_FOR_INTERRUPT,
    KDA_INTERRUPT_LOCK,
    KDA_INTERRUPT_UNLOCK,
/*MISC cmd*/
    KDA_GET_SCHE_TIME,

/*MUX CMDS*/
    KDA_DEV_MUX_INIT,
    KDA_DEV_MUX_BIND,
    KDA_DEV_MUX_RCV,
    KDA_DEV_MUX_TX,
    KDA_DEV_MUX_FREE,
    KDA_DEV_MUX_SEND,
    KDA_MUX_TX_ALLOC,
    KDA_MUX_RX_START,
    KDA_MUX_TX_FREE,
    KDA_MUX_RX_MMAP,
    /* interface */
    KDA_IP_ATTACH,
    KDA_IP_DETACH,
    /* packet */
    KDA_PACKET_RECV,
    KDA_PACKET_GET,
    KDA_PACKET_FREE,
    KDA_INIT,
    KDA_SETMODE,
    /* HDLC_LOOP */
    /* EC:614002647187 */
    KDA_SET_UCC_HDLC_LOOP_ON,
    KDA_SET_UCC_HDLC_LOOP_OFF,
    KDA_SET_IS_PP1S_IRQ_EXIST,
    KDA_GET_IS_PP1S_IRQ_EXIST,
    /*  Լ���ճ�(KDA_CMD_MAGIC+50)��ǰ��CGEL3.X���������룬
     *  �����߼̳�+1������������ơ�
     *  Լ��LSP��BSPһ�´�(KDA_CMD_MAGIC+50)��CGEL4.X���������룬
     *  �����߼̳�+1������������ơ�
     *  Լ��LSP��BSPһ�´�(KDA_CMD_MAGIC+60)��CGEL6.X���������룬
     *  �����߼̳�+1������������ơ�
     *  Լ��LSP��BSPһ�´�(KDA_CMD_MAGIC+100)���¹������������룬
     *  �����߼̳�+1������������ơ�
     */
    /***************CGEL4.X (KDA_CMD_MAGIC+50)******************/
    KDA_PWM_RUN,
    KDA_BOARD_INFO_SET = _KDA_CMD(KDA_CMD_MAGIC, 50),
    KDA_DSPCFG_REGSET = _KDA_CMD(KDA_CMD_MAGIC, 51),//for DSP BOOT ADDR setting
    KDA_MDIO_READ = _KDA_CMD(KDA_CMD_MAGIC, 52),    /*note:only for dra62x*/
    KDA_MDIO_WRITE = _KDA_CMD(KDA_CMD_MAGIC, 53),   /*note:only for dra62x*/
    /***************CGEL6.X (KDA_CMD_MAGIC+60)*****************/

    /***************COMMON (KDA_CMD_MAGIC+100)*****************/
    KDA_MDIO_READ_COMMON   = _KDA_CMD(KDA_CMD_MAGIC,100),
    KDA_MDIO_WRITE_COMMON  = _KDA_CMD(KDA_CMD_MAGIC,101),
    KDA_SERIAL_RECORD_MEMORY = _KDA_CMD(KDA_CMD_MAGIC, 102),
    KDA_PRINT_IN_OS = _KDA_CMD(KDA_CMD_MAGIC, 103),
};
#endif


#define FIOOPTIONS      3       /* set options (FIOSETOPTIONS) */
#define FIOSETOPTIONS   FIOOPTIONS  /* set options */
#define FIORFLUSH       26      /* flush any chars in read buffers */
#define FIOGETOPTIONS   19      /* get options */

#define OPT_ECHO    0x01        /* echo input */
#define OPT_LINE    0x40        /* enable basic line protocol */

/*������غ궨��*/
#define READY           0x0000
#define PEND            0x0001
#define DELAY           0x0002
#define SUSPEND         0x0004
#define TIMEOUT         0x0008
#define INH_PRI         0x0010
#define DEAD            0x0080
#define RDY_MSK         0x008f

#define WIND_READY      READY   /* ready to run */
#define WIND_SUSPEND    SUSPEND /* explicitly suspended */
#define WIND_PEND       PEND    /* pending on semaphore */
#define WIND_DELAY      DELAY   /* task delay (or timeout) */
#define WIND_DEAD       DEAD    /* dead task */

#define MIN_V2PT_PRIORITY 255
#define MAX_V2PT_PRIORITY 0

#define TRACEV(F,V)
#define TRACEF(args ... )

#define TRACE_DLL_V(F,V)
#define TRACE_DLL_F(args ... )

#define M_taskLib       (3 << 16)
#define M_memLib        (17 << 16)
#define M_semLib        (22 << 16)
#define M_objLib        (61 << 16)
#define M_msgQLib       (65 << 16)
#define M_smObjLib      (88 << 16)

#define S_objLib_OBJ_ID_ERROR           (M_objLib | 1)
#define S_objLib_OBJ_UNAVAILABLE        (M_objLib | 2)
#define S_objLib_OBJ_DELETED            (M_objLib | 3)
#ifndef S_objLib_OBJ_TIMEOUT
#define S_objLib_OBJ_TIMEOUT            (M_objLib | 4)
#endif
#define S_objLib_OBJ_NO_METHOD          (M_objLib | 5)

#define S_memLib_NOT_ENOUGH_MEMORY      (M_memLib | 1)
#define S_memLib_INVALID_NBYTES         (M_memLib | 2)
#define S_memLib_BLOCK_ERROR            (M_memLib | 3)
#define S_memLib_NO_PARTITION_DESTROY       (M_memLib | 4)
#define S_memLib_PAGE_SIZE_UNAVAILABLE      (M_memLib | 5)

#define S_smObjLib_NOT_INITIALIZED        (M_smObjLib | 1)
#define S_smObjLib_NOT_A_GLOBAL_ADRS      (M_smObjLib | 2)
#define S_smObjLib_NOT_A_LOCAL_ADRS       (M_smObjLib | 3)
#define S_smObjLib_SHARED_MEM_TOO_SMALL   (M_smObjLib | 4)
#define S_smObjLib_TOO_MANY_CPU           (M_smObjLib | 5)
#define S_smObjLib_LOCK_TIMEOUT           (M_smObjLib | 6)
#define S_smObjLib_NO_OBJECT_DESTROY      (M_smObjLib | 7)

#define S_msgQLib_INVALID_MSG_LENGTH            (M_msgQLib | 1)
#define S_msgQLib_NON_ZERO_TIMEOUT_AT_INT_LEVEL (M_msgQLib | 2)
#define S_msgQLib_INVALID_QUEUE_TYPE            (M_msgQLib | 3)
#define S_msgQLib_INIT_MSGQ_FAIL                (M_msgQLib | 4)
#define S_msgQLib_CREATE_COUNT_SEM_FAIL         (M_msgQLib | 5)
#define S_msgQLib_CREATE_FREE_SEM_FAIL          (M_msgQLib | 6)
#define S_msgQLib_SEND_FAIL                     (M_msgQLib | 7)

#define S_semLib_INVALID_STATE          (M_semLib | 101)
#define S_semLib_INVALID_OPTION         (M_semLib | 102)
#define S_semLib_INVALID_QUEUE_TYPE     (M_semLib | 103)
#define S_semLib_INVALID_OPERATION      (M_semLib | 104)

#define V2PT_TICK 10

typedef void * CLASS_ID;        /* CLASS_ID */

typedef struct task_s
{
    int check;
    int taskid;
    char *name;
    pthread_t pthrid;
    pthread_attr_t attr;
    struct sched_param prv_priority;
    int (*entry_point) (int, int, int, int, int, int, int, int, int, int);
    int parms[10];
    int static_task;    /* Flag indicating if task control block allocated dynamically ( == 0 )*/
    int flags;
    int state;
    int vxw_priority;
    /* struct task_s *suspend_list; use waiting instead*/
    struct task_s *nxt_susp;    /* Next task control block in list of tasks waiting on object*/
    int delete_safe_count;      /* Nesting level for number of taskSafe calls*/
    /* Mutex and Condition variable for task delete 'pend'*/
    pthread_mutex_t tdelete_lock;
    pthread_cond_t t_deletable;

    /* Mutex and Condition variable for task delete 'broadcast'*/
    pthread_mutex_t dbcst_lock;
    pthread_cond_t delete_bcplt;

    /* Mutex and Condition variable for task suspend and resume'*/
    pthread_mutex_t  tsuspend_lock;
    pthread_cond_t  tsuspendable;

    /* First task control block in list of tasks waiting on this task (for deletion purposes)*/
    struct task_s *first_susp;

    /* Next task control block in list*/
    struct task_s *nxt_task;
    struct task_s *nxt_task_hash;
    /* the task waits this objects:*/
    #if 0
    #ifdef _USE_SEM_FUTEX_
    struct v2pt_sema4 *waiting;
    #else
    struct v2lsem *waiting;
    #endif
    #endif
    struct v2lsem *waiting;
    pthread_mutex_t *waiting_m;
    /*task var*/
    //struct taskVar *  pTaskVar;   /* 0x9c: ptr to task variable list */

    UINT16      swapInMask; /* 0x58: task's switch in hooks */
    UINT16      swapOutMask;    /* 0x5a: task's switch out hooks */
    #if 0
    #ifdef _USE_SEM_FUTEX_
    struct v2pt_sema4 * pend_sem;   /* ����������ĳ���ź�����   */
    #endif
    #endif
    int lock_num;                   /* taskLock�ĵ��ô���       */
    int oldpriority;                /* ����taskLock֮ǰ�����ȼ� */

    /*/�����⼸����Ա��Ϊ��һЩ��Ҫ����vxworks TCB���ƿ��Ӧ�ô����ܹ����*/
    int         reserved1;  /* 0x100: possible user extension */
    int         reserved2;  /* 0x104: possible user extension */
    int         spare1;     /* 0x108: possible user extension */
    int         spare2;     /* 0x10c: possible user extension */
    int         spare3;     /* 0x110: possible user extension */
    int         spare4;     /* 0x114: possible user extension */
    unsigned int        status;     /* 0x3c: status of task */
    //REG_SET    regs;      /* 0x11c: register set */
    //REG_SET *  pExcRegSet;    /* 0xd8: exception regSet ptr or NULL */
    int        options; /* 0x38: task option bits */
    unsigned int        priority;   /* 0x40: task's current priority */
    unsigned int        priNormal;  /* 0x44: task's normal priority */

    char *      pStackBase; /* 0x78: points to bottom of stack */
    char *      pStackLimit;    /* 0x7c: points to stack limit */
    char *      pStackEnd;  /* 0x80: points to init stack limit */

    char * file_name;
    int  line_no;
} WIND_TCB;

#define windTcb  task_s
/*extern WIND_TCB *taskIdCurrent;        always current executing task */
extern WIND_TCB *my_task(void);
#define  taskIdCurrent   my_task()

typedef struct          /* TASK_DESC - information structure */
    {
    int         td_id;      /* task id */
    char *      td_name;    /* name of task */
    int         td_priority;    /* task priority */
    int         td_status;  /* task status */
    int         td_options; /* task option bits (see below) */
    FUNCPTR     td_entry;   /* original entry point of task */
    char *      td_sp;      /* saved stack pointer */
    char *      td_pStackBase;  /* the bottom of the stack */
    char *      td_pStackLimit; /* the effective end of the stack */
    char *      td_pStackEnd;   /* the actual end of the stack */
    int         td_stackSize;   /* size of stack in bytes */
    int         td_stackCurrent;/* current stack usage in bytes */
    int         td_stackHigh;   /* maximum stack usage in bytes */
    int         td_stackMargin; /* current stack margin in bytes */
    int         td_errorStatus; /* most recent task error status */
    int         td_delay;   /* delay/timeout ticks */
} TASK_DESC;

typedef ULONG (*FUNC_BSP_TASK_LOCK)(VOID);
typedef ULONG (*FUNC_BSP_TASK_UNLOCK)(VOID);

/* generic status codes */

#define S_taskLib_NAME_NOT_FOUND            (M_taskLib | 101)
#define S_taskLib_TASK_HOOK_TABLE_FULL      (M_taskLib | 102)
#define S_taskLib_TASK_HOOK_NOT_FOUND       (M_taskLib | 103)
#define S_taskLib_TASK_SWAP_HOOK_REFERENCED (M_taskLib | 104)
#define S_taskLib_TASK_SWAP_HOOK_SET        (M_taskLib | 105)
#define S_taskLib_TASK_SWAP_HOOK_CLEAR      (M_taskLib | 106)
#define S_taskLib_TASK_VAR_NOT_FOUND        (M_taskLib | 107)
#define S_taskLib_TASK_UNDELAYED            (M_taskLib | 108)
#define S_taskLib_ILLEGAL_PRIORITY          (M_taskLib | 109)

#define MAX_TASK_ARGS           10  /* max args passed to a task */
#define VX_MAX_TASK_SWITCH_RTNS 16  /* max task switch callout routines */
#define VX_MAX_TASK_SWAP_RTNS   16  /* max task swap callout routines */
#define VX_MAX_TASK_DELETE_RTNS 16  /* max task delete callout routines */
#define VX_MAX_TASK_CREATE_RTNS 16  /* max task create callout routines */

#define VX_SUPERVISOR_MODE  0x0001  /* OBSOLETE: tasks always in sup mode */
#define VX_UNBREAKABLE      0x0002  /* INTERNAL: breakpoints ignored */
#define VX_DEALLOC_STACK    0x0004  /* INTERNAL: deallocate stack */
#define VX_FP_TASK          0x0008  /* 1 = f-point coprocessor support */
#define VX_STDIO            0x0010  /* OBSOLETE: need not be set for stdio*/
#define VX_ADA_DEBUG        0x0020  /* 1 = VADS debugger support */
#define VX_FORTRAN          0x0040  /* 1 = NKR FORTRAN support */
#define VX_PRIVATE_ENV      0x0080  /* 1 = private environment variables */
#define VX_NO_STACK_FILL    0x0100  /* 1 = avoid stack fill of 0xee */
#define VX_DSP_TASK         0x0200  /* 1 = dsp coprocessor support */
#define VX_ALTIVEC_TASK     0x0400  /* 1 = ALTIVEC coprocessor support */

extern STATUS   taskLibInit (void);

extern int  taskSpawn (const char *name, int priority, int options, int stackSize,
                   FUNCPTR entryPt, int arg1, int arg2, int arg3,
                   int arg4, int arg5, int arg6, int arg7,
                   int arg8, int arg9, int arg10);
extern STATUS   taskInit (WIND_TCB *pTcb, char *name, int priority, int options,
              char *pStackBase, int stackSize, FUNCPTR entryPt,
              int arg1, int arg2, int arg3, int arg4, int arg5,
              int arg6, int arg7, int arg8, int arg9, int arg10);
extern STATUS   taskActivate (int tid);
extern STATUS   taskDelete (int tid);
extern STATUS   taskDeleteForce (int tid);
extern STATUS   taskSuspend (int tid);
extern STATUS   taskResume (int tid);
extern STATUS   taskRestart (int tid);
extern STATUS   taskPrioritySet (int tid, int newPriority);
extern STATUS   taskPriorityGet (int tid, int *pPriority);
extern STATUS   taskLock (void);
extern STATUS   taskUnlock (void);
extern STATUS   taskSafe (void);
extern STATUS   taskUnsafe (void);
extern STATUS   taskDelay (int ticks);
extern STATUS   taskDelay_Sys (int ticks);
extern STATUS   taskOptionsSet (int tid, int mask, int newOptions);
extern STATUS   taskOptionsGet (int tid, int *pOptions);
extern char *   taskName (int tid);
extern int      taskNameToId (char *name);
extern STATUS   taskIdVerify (int tid);
extern int      taskIdSelf (void);
extern WIND_TCB * taskSelf(void);
extern int      taskIdDefault (int tid);
extern BOOL     taskIsReady (int tid);
extern BOOL     taskIsSuspended (int tid);
extern WIND_TCB *taskTcb (int tid);
extern int      taskIdListGet (int idList [ ], int maxTasks);
extern STATUS   taskInfoGet (int tid, TASK_DESC *pTaskDesc);
extern STATUS   taskStatusString (int tid, char *pString);
extern STATUS   taskOptionsString (int tid, char *pString);
//extern STATUS     taskRegsGet (int tid, REG_SET *pRegs);
//extern STATUS     taskRegsSet (int tid, REG_SET *pRegs);
extern void     taskRegsShow (int tid);
extern void *   taskStackAllot (int tid, unsigned nBytes);
extern void     taskShowInit (void);
extern STATUS   taskShow (int tid, int level);

/*/v2lin additinal utility functions*/
//extern int taskList(FILE * out, int mem);
extern char * VxWorksError(STATUS status);
extern int v2lin_init(void);

/* �ú����Ǹ����̼��shellʹ��,�����ж�Ŀǰ�Ƿ�ʹ����V2LIN */
extern int  use_zte_chengyan_v2lin(void);

extern STATUS BspSetVxTaskPriority(INT32 tid,INT32 linuxPrior);
#ifndef NO_WAIT
#define NO_WAIT     0
#endif
#ifndef WAIT_FOREVER
#define WAIT_FOREVER    (-1)
#endif


#define V2LIN_MAGIC 0xdf0df045
#define V2LIN_MAGIC_SEM 0x2f0df043
#define V2LIN_MAGIC_MSGQ 0x42375cd5

#define SEM_Q_MASK       0x03   /* q-type mask */
#define SEM_Q_FIFO       0x00   /* first in first out queue */
#define SEM_Q_PRIORITY       0x01   /* priority sorted queue */
#define SEM_DELETE_SAFE      0x04   /* owner delete safe (mutex opt.) */
#define SEM_INVERSION_SAFE   0x08   /* no priority inversion (mutex opt.) */
#define SEM_EVENTSEND_ERR_NOTIFY 0x10   /* notify when eventRsrcSend fails */

typedef struct v2lsem
{
#if 1 /*2011-04-09 yxy*/
#ifdef DISABLE_SEM_V2LIN_STYLE
    int sem_type;
    int owner_pid;
    union
    {
        pthread_mutex_t   mutex;
        sem_t             sem;
    }sem_obj;
#endif
#endif
    int magic;

    int static_sem;
    /* Mutex and Condition variable for semaphore post/pend*/
    pthread_mutex_t sem_lock;
    pthread_cond_t sem_send;
    int flags;

    /*Mutex and Condition variable for semaphore delete*/
    pthread_mutex_t smdel_lock;
    pthread_cond_t smdel_cplt;

    /*  Count of available 'tokens' for semaphore.*/
    int token_count;
    int count_orig;

    /* Type of send operation last performed on semaphore*/
    int send_type;

    /* Ownership nesting level for mutual exclusion semaphore.*/
    int recursion_level;

    /* Task control block ptr for task which currently owns semaphore*/
    WIND_TCB *current_owner;

    /*�̡�?�㨮�̨�D??��?��?���䨬???current_owner */
    pthread_t owner;

    struct v2lsem *nxt_sem;

    /* First task control block in list of tasks waiting on semaphore*/
    WIND_TCB *first_susp;
} v2lsem_t;

#define SEMAPHORE v2lsem_t
#define semaphore v2lsem

typedef v2lsem_t *SEM_ID;

typedef enum        /* SEM_B_STATE */
{
    SEM_EMPTY,          /* 0: semaphore not available */
    SEM_FULL            /* 1: semaphore available */
} SEM_B_STATE;

STATUS  semGive (SEM_ID semId);
STATUS  semTake (SEM_ID semId, int timeout);
STATUS  semFlush (SEM_ID semId);
STATUS  semDelete (SEM_ID semId);
int     semInfo (SEM_ID semId, int idList[], int maxTasks);
STATUS  semBLibInit (void);
SEM_ID  semBCreate (int options, SEM_B_STATE initialState);
STATUS  semCLibInit (void);
SEM_ID  semCCreate (int options, int initialCount);
STATUS  semMLibInit (void);
SEM_ID  semMCreate (int options);
STATUS  semMGiveForce (SEM_ID semId);
STATUS  semOLibInit (void);
SEM_ID  semCreate (void);
void    semShowInit (void);
STATUS  semShow (SEM_ID semId, int level);

INT intLock(void);
INT intUnlock(int LockKey);
unsigned long long tick64Get(void);
ULONG tickGet();
int getKdaFd(void);



#define BR_PS_16    0x00000800  /* 16 bit port size */
#define BR_MS_GPCM  0x00000000  /* G.P.C.M. Machine Select */
#define BR_V        0x00000001  /* Bank Valid */
#define BR_BA_MSK   0xffff8000  /* Base Address Mask */

#ifndef FIONREAD
#define FIONREAD        1       /* get num chars available to read */
#endif

#define MSG_Q_FIFO  0x00    /* tasks wait in FIFO order */

#ifndef OK
#define OK 0
#endif
#ifndef ERROR
#define ERROR -1
#endif
#define SIUMCR_MPRE     0x00001000  /* Multi CPU Reserva. Enable */
#ifndef IVEC_TO_UNUM
#define IVEC_TO_INUM(intVec)    ((int) (intVec))
#endif

#define INUM_TO_IVEC(intNum)    ((VOIDFUNCPTR *) (intNum))

#define IV_IRQ0         INUM_TO_IVEC (0)    /* IRQ 0 interrupt */
#define IV_LEVEL0       INUM_TO_IVEC (1)    /* level 0 interrupt */
#define IV_IRQ1         INUM_TO_IVEC (2)    /* IRQ 1 interrupt */
#define IV_LEVEL1       INUM_TO_IVEC (3)    /* level 1 interrupt */
#define IV_IRQ2         INUM_TO_IVEC (4)    /* IRQ 2 interrupt */
#define IV_LEVEL2       INUM_TO_IVEC (5)    /* level 2 interrupt */
#define IV_IRQ3         INUM_TO_IVEC (6)    /* IRQ 3 interrupt */
#define IV_LEVEL3       INUM_TO_IVEC (7)    /* level 3 interrupt */
#define IV_IRQ4         INUM_TO_IVEC (8)    /* IRQ 4 interrupt */
#define IV_LEVEL4       INUM_TO_IVEC (9)    /* level 4 interrupt */
#define IV_IRQ5         INUM_TO_IVEC (10)   /* IRQ 5 interrupt */
#define IV_LEVEL5       INUM_TO_IVEC (11)   /* level 5 interrupt */
#define IV_IRQ6         INUM_TO_IVEC (12)   /* IRQ 6 interrupt */
#define IV_LEVEL6       INUM_TO_IVEC (13)   /* level 6 interrupt */
#define IV_IRQ7         INUM_TO_IVEC (14)   /* IRQ 7 interrupt */
#define IV_LEVEL7       INUM_TO_IVEC (15)   /* level 7 interrupt */

#define SIO_BAUD_SET        0x1003
#define SIO_BAUD_GET        0x1004

#define SIO_MODE_SET        0x1007
#define SIO_MODE_POLL   1
#define SIO_MODE_INT    2
#define SIO_MODE_GET        0x1008
#define SIO_AVAIL_MODES_GET 0x1009
#define SIO_HW_OPTS_SET     0x1005
#define SIO_HW_OPTS_GET     0x1006

#define SIO_CALLBACK_GET_TX_CHAR    1
#define SIO_CALLBACK_PUT_RCV_CHAR   2

#define SIO_OPEN        0x100A
#define SIO_HUP         0x100B

#define PDDIR(base) ((VUINT16 *)((base) + 0x0970)) /* PD data dir */
#define PDPAR(base) ((VUINT16 *)((base) + 0x0972)) /* PD pin assign*/
#define PDDAT(base) ((VUINT16 *)((base) + 0x0976)) /* PD data reg */
#define PBPAR(base) ((VUINT32 *)((base) + 0x0ABC)) /* PB pin ass*/
#define PBDIR(base) ((VUINT32 *)((base) + 0x0AB8)) /* PB data dir */
#define PBODR(base) ((VUINT16 *)((base) + 0x0AC2)) /* PB open drain*/
#define SIUMCR(base) ((VUINT32 *)((base) + 0x0000)) /* SIU Module Conf*/
#define SIPEND(base)    ((VUINT32 *)((base) + 0x0010)) /* Intr Pending reg*/
#define SIMASK(base)    ((VUINT32 *)((base) + 0x0014)) /* Intr Mask reg */
#define SIEL(base)  ((VUINT32 *)((base) + 0x0018)) /* Intr Edge Lvl */
#define SIPEND_IRQ5 0x00200000  /* Interrupt IRQ5 pending */
#define SIPEND_IRQ6 0x00080000  /* Interrupt IRQ6 pending */
#define SIMASK_IRM5 0x00200000  /* Interrupt IRQ5 mask */
#define SIMASK_IRM6 0x00080000  /* Interrupt IRQ6 mask */
#define SIEL_ED5    0x00200000  /* Interrupt IRQ5 on falling Edge */
#define SIEL_ED6    0x00080000  /* Interrupt IRQ6 on falling Edge */
#define SIUMCR_DPC      0x00002000  /* Data Parity pins Config. */
#define SIPEND_IRQ0 0x80000000  /* Interrupt IRQ0 pending */
#define SIEL_ED0    0x80000000  /* Interrupt IRQ0 on falling Edge */
#define SIMASK_IRM0 0x80000000  /* Interrupt IRQ0 mask */

typedef volatile INT32 VINT32; /* volatile unsigned word */
typedef volatile UINT32 VUINT32; /* volatile unsigned word */
typedef volatile USHORT VUINT16; /* volatile unsigned halfword */
#define PPC860  97  /* CPU */

/* low-level I/O input, output, error fd's */
#define STD_IN         0
#define STD_OUT        1
#define STD_ERR        2

typedef struct sio_drv_funcs SIO_DRV_FUNCS;

typedef struct sio_chan             /* a serial channel */
    {
    SIO_DRV_FUNCS * pDrvFuncs;
    /* device data */
    } SIO_CHAN;

struct sio_drv_funcs                /* driver functions */
    {
    int     (*ioctl)
            (
            SIO_CHAN *  pSioChan,
            int     cmd,
            void *      arg
            );

    int     (*txStartup)
            (
            SIO_CHAN *  pSioChan
            );

    int     (*callbackInstall)
            (
            SIO_CHAN *  pSioChan,
            int     callbackType,
            STATUS      (*callback)(void *, ...),
            void *      callbackArg
            );

    int     (*pollInput)
            (
            SIO_CHAN *  pSioChan,
            char *      inChar
            );

    int     (*pollOutput)
            (
            SIO_CHAN *  pSioChan,
            char        outChar
            );
    };

typedef struct q_class      /* Q_CLASS */
    {
    FUNCPTR createRtn;      /* create and initialize a queue */
    FUNCPTR initRtn;        /* initialize a queue */
    FUNCPTR deleteRtn;      /* delete and terminate a queue */
    FUNCPTR terminateRtn;   /* terminate a queue */
    FUNCPTR putRtn;     /* insert a node into q with insertion key */
    FUNCPTR getRtn;     /* return and remove lead node routine */
    FUNCPTR removeRtn;      /* remove routine */
    FUNCPTR resortRtn;      /* resort node to new priority */
    FUNCPTR advanceRtn;     /* advance queue by one tick routine */
    FUNCPTR getExpiredRtn;  /* return and remove an expired Q_NODE */
    FUNCPTR keyRtn;     /* return insertion key of node */
    FUNCPTR calibrateRtn;   /* calibrate every node in queue by an offset */
    FUNCPTR infoRtn;        /* return array of nodes in queue */
    FUNCPTR eachRtn;        /* call a user routine for each node in queue */
    struct q_class *valid;  /* valid == pointer to queue class */
    } Q_CLASS;

typedef struct      /* Q_NODE */
    {
    UINT     qPriv1;            /* use is queue type dependent */
    UINT     qPriv2;            /* use is queue type dependent */
    UINT     qPriv3;            /* use is queue type dependent */
    UINT     qPriv4;            /* use is queue type dependent */
    } Q_NODE;

typedef struct      /* Q_HEAD */
    {
    Q_NODE  *pFirstNode;        /* first node in queue based on key */
    UINT     qPriv1;            /* use is queue type dependent */
    UINT     qPriv2;            /* use is queue type dependent */
    Q_CLASS *pQClass;           /* pointer to queue class */
    } Q_HEAD;
/* HIDDEN */

typedef struct qJobNode         /* Node of a job queue */
    {
    struct qJobNode *next;
    } Q_JOB_NODE;

typedef struct  qJobHead            /* Head of job queue */
    {
    Q_JOB_NODE *first;          /* first node in queue */
    Q_JOB_NODE *last;           /* last node in queue */
    int     count;          /* number of nodes in queue */
    Q_CLASS    *pQClass;        /* must be 4th long word */
    Q_HEAD  pendQ;          /* queue of blocked tasks */
    } Q_JOB_HEAD;

/*typedef struct v2pt_mqueue * MSG_Q_ID;*/

typedef struct v2pt_mqueue
{
    int magic;

    /*Mutex and Condition variable for queue send/pend*/
    pthread_mutex_t queue_lock;
    SEM_ID          count_sem;
    SEM_ID          free_sem;

    Q_JOB_HEAD      msgQ;         /* message queue head */
    Q_JOB_HEAD      freeQ;        /* free message queue head */
    int             send_type;    /* Type of send operation last performed on queue*/
    int             msg_count;    /* Total number of messages currently sent to queue*/
    int             options;      /* message queue options */
    int             maxMsgs;      /* max number of messages in queue */
    unsigned int    maxMsgLength; /* Maximum size of messages sent to queue*/
    int             order;        /* Task pend order (FIFO or Priority) for queue*/
} v2pt_mqueue_t;

int sysClkRateGet(void);
INT32 KdaInitComRecord(unsigned long long logAddrBase, UINT32 interruptNum);
int kdaMdioRead(int phy,int reg,int *value);
int kdaMdioWrite(int phy,int reg,int value);
STATUS bspTaskLock(VOID);
STATUS bspTaskUnlock(VOID);
void blockticksig(void);
#define BspSysUsDelay_Sys(A)      usleep(A)
#define BspSysMsDelay_Sys(A)      usleep(A*1000)
#ifdef __cplusplus
}
#endif

#endif /* __INCtaskLibh */

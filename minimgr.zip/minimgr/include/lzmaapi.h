/************************************************************************
* 版权所有 (C)2012, 深圳市中兴通讯股份有限公司。
*
* 文件名称： LzmaApi.h
* 文件标识： SDR
* 内容摘要： LZMA 对外接口
* 其它说明：
* 当前版本： 1.0
* 作    者： wood
* 完成日期：
*
* 修改记录1：
*    修改日期：
*    版 本 号：
*    修 改 人：
*    修改内容：
************************************************************************/
#ifndef LZMAAPI_H
#define LZMAAPI_H


#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

#include "7zTypes.h"
#include "LzmaLib.h"


/**************************************************************************
 *                            常量                                        *
 **************************************************************************/



/**************************************************************************
 *                           宏定义                                       *
 **************************************************************************/

#define UNPACK_LENGTH_LIMIT                (1*1024*1024*1024)   /* 设置最大支持的解压尺寸 */
/* Started by AICoder, pid:x784934cc9neae11470b0999e0253b1f6f215811 */
#define UNPACK_LENGTH_WARNING_THRESHOLD_MINI    (200*1024*1024)       /* 解压的告警尺寸 */
/* Ended by AICoder, pid:x784934cc9neae11470b0999e0253b1f6f215811 */

#define LZMA_RET_OK              (0)
#define LZMA_RET_ERROR           (-1)
#define LZMA_ERROR_BASE          (0x100)

#define LZMA_ERROR_DATA           (LZMA_ERROR_BASE +1)
#define LZMA_ERROR_MEM            (LZMA_ERROR_BASE +2)
#define LZMA_ERROR_CRC            (LZMA_ERROR_BASE +3)
#define LZMA_ERROR_UNSUPPORTED    (LZMA_ERROR_BASE +4)
#define LZMA_ERROR_PARAM          (LZMA_ERROR_BASE +5)
#define LZMA_ERROR_INPUT_EOF      (LZMA_ERROR_BASE +6)
#define LZMA_ERROR_OUTPUT_EOF     (LZMA_ERROR_BASE +7)
#define LZMA_ERROR_READ           (LZMA_ERROR_BASE +8)
#define LZMA_ERROR_WRITE          (LZMA_ERROR_BASE +9)
#define LZMA_ERROR_OPEN           (LZMA_ERROR_BASE +10)
#define LZMA_ERROR_FAIL           (LZMA_ERROR_BASE +11)
#define LZMA_ERROR_THREAD         (LZMA_ERROR_BASE +12)

#define LZMA_ERROR_ARCHIVE        (LZMA_ERROR_BASE +16)
#define LZMA_ERROR_NO_ARCHIVE     (LZMA_ERROR_BASE +17)

/**************************************************************************
 *                          数据类型                                      *
 **************************************************************************/
#pragma pack(1)
typedef struct
{
    unsigned char       props[LZMA_PROPS_SIZE];
    UInt64              unpack_size;
}T_lzma_header;
#pragma pack()


/**************************************************************************
 *                           类声明                                       *
 **************************************************************************/



/**************************************************************************
 *                            模板                                        *
 **************************************************************************/



/**************************************************************************
 *                         全局变量声明                                   *
 **************************************************************************/

 /**************************************************************************
函数名称:  LzmaDecMem
功能描述:  LZMA 内存解压到内存
输入参数:
               PackedBuf -- 待解压的内存buf
               UnpackBuf -- 解压之后的内存buf
               PackedLength -- 待解压的长度
输出参数:
返 回 值:  0:操作成功
附加说明:  lzma 压缩格式
           props      --  5字节，压缩参数
           unpacksize --  8字节，未经压缩的长度
修改说明:
  修改日期          版本号      修改人      修改内容
  -----------------------------------------------
  2012年6月1日      1.0       wood        创建
**************************************************************************/

unsigned long LzmaDecMem(const unsigned char * PackedBuf, unsigned char * UnpackBuf, size_t PackedLength, size_t *unPackedLength);

 /**************************************************************************
函数名称:   LzmaDecFile
功能描述:  LZMA 文件解压为文件
输入参数:
               *PackedFile -- 压缩的文件名
               *UnpackedFile -- 解压后的文件名
输出参数:
返 回 值:  0:操作成功
附加说明:  lzma 压缩格式
           props      --  5字节，压缩参数
           unpacksize --  8字节，未经压缩的长度
修改说明:
  修改日期          版本号      修改人      修改内容
  -----------------------------------------------
  2012年6月1日      1.0       wood        创建
**************************************************************************/
extern unsigned long LzmaDecFile(char *PackedFile,char *UnpackedFile);


/* 边读边解压， 省内存型接口，推荐使用 */
/**************************************************************************
函数名称:  long LzmaDecFileOpted
功能描述:  节约内存型解压接口（File To File）
输入参数:
               *PackedFile --
               *UnpackedFile --
输出参数:
返 回 值:  BSP_OK:操作成功
附加说明:
修改说明:
  修改日期          版本号      修改人      修改内容
  -----------------------------------------------
  2012年6月9日      1.0       wood        创建
**************************************************************************/
extern unsigned long LzmaDecFileOpted(char *PackedFile,char *UnpackedFile);


/**************************************************************************
函数名称:  LzmaEncMem
功能描述:  LZMA 内存压缩到内存
输入参数:
               InBuf     -- 待压缩的内存buf
               OutBuf    -- 压缩之后的内存buf
               InLen     -- 待压缩数据的长度
               *OutLen   -- 压缩后数据的长度
               level     -- 压缩等级，如果<0则用默认等级5压缩
输出参数:
返 回 值:  0:操作成功
附加说明:  lzma 压缩格式
           props      --  5字节，压缩参数
           unpacksize --  8字节，未经压缩的长度
修改说明:
  修改日期          版本号      修改人      修改内容
  -----------------------------------------------
  2018年7月25日      1.0       宋志强        创建
**************************************************************************/
unsigned long LzmaEncMem(const unsigned char *InBuf, unsigned char *OutBuf, size_t InLen, size_t *OutLen, int level);

/**************************************************************************
函数名称:  LzmaEncFile
功能描述:  LZMA 内存压缩到内存
输入参数:
               InFile     -- 待压缩的文件名
               OutFile    -- 压缩之后的文件名
               level     -- 压缩等级，如果<0则用默认等级5压缩
输出参数:
返 回 值:  0:操作成功
附加说明:  lzma 压缩格式
           props      --  5字节，压缩参数
           unpacksize --  8字节，未经压缩的长度
修改说明:
  修改日期          版本号      修改人      修改内容
  -----------------------------------------------
  2018年7月25日      1.0       宋志强        创建
**************************************************************************/
unsigned long LzmaEncFile(char *InFile, char *OutFile, int level);

/**************************************************************************
 *                         全局函数原型                                   *
 **************************************************************************/



#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif /* LZMAAPI_H */

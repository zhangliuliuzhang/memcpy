#ifndef	_MINIMGR_H_
#define	_MINIMGR_H_

#ifdef __cplusplus
extern "C" {
#endif
#include <sys/mman.h>
#include "ru_basedef.h"
#include "pub_basetypedef.h"
#include "bsperrcode.h"
#include "zprintf.h"

/**************************************************************************
 *                         宏常量                                            *
 **************************************************************************/

#define BspSysMsDelay(A)                usleep(A*1000)
#define BSP_ERROR_NULL_POINTER          ERROR_NULL_POINTER
#define FLAG_FPGAVER                    "FPGA_VER_FLAG"
#define FPGA_LOAD_BY_NEW_FLAG           0x02
#define FPGA_LOAD_ACK_VERSION           '1'
#define MINIMGR_MASTER_FLAG             0
#define MINIMGR_SLAVE_FLAG              1
#define FLASH_PARA_FILE                 "/.FLASH_PARA.ini"
#define FLASH_SEL_KEY                   "SEL"

#define MINIMGR_SIZE_1K                  (1024)
#define MINIMGR_SIZE_4K                  (MINIMGR_SIZE_1K*4)
#define MINIMGR_SIZE_8K                  (MINIMGR_SIZE_1K*8)
#define MINIMGR_SIZE_64K                 (MINIMGR_SIZE_1K*64)
#define MINIMGR_SIZE_128K                (MINIMGR_SIZE_1K*128)
#define MINIMGR_SIZE_256K                (MINIMGR_SIZE_1K*256)
#define MINIMGR_SIZE_320K                (MINIMGR_SIZE_1K*320)
#define MINIMGR_SIZE_512K                (MINIMGR_SIZE_1K*512)
#define MINIMGR_SIZE_1M                  (MINIMGR_SIZE_1K*1024)
#define MINIMGR_SIZE_2M                  (MINIMGR_SIZE_1M*2)
#define MINIMGR_SIZE_3M                  (MINIMGR_SIZE_1M*3)
#define MINIMGR_SIZE_4M                  (MINIMGR_SIZE_1M*4)
#define MINIMGR_SIZE_6M                  (MINIMGR_SIZE_1M*6)
#define MINIMGR_SIZE_8M                  (MINIMGR_SIZE_1M*8)
#define MINIMGR_SIZE_9M                  (MINIMGR_SIZE_1M*9)
#define MINIMGR_SIZE_10M                 (MINIMGR_SIZE_1M*10)
#define MINIMGR_SIZE_12M                 (MINIMGR_SIZE_1M*12)
#define MINIMGR_SIZE_17M                 (MINIMGR_SIZE_1M*17)
#define MINIMGR_SIZE_31M                 (MINIMGR_SIZE_1M*31)
#define MINIMGR_SIZE_35M                 (MINIMGR_SIZE_1M*35)
#define MINIMGR_SIZE_64M                 (MINIMGR_SIZE_1M*64)
#define MINIMGR_SIZE_128M                (MINIMGR_SIZE_1M*128)
#define MINIMGR_SIZE_256M                (MINIMGR_SIZE_1M*256)
#define MINIMGR_SIZE_384M                (MINIMGR_SIZE_1M*384)
#define MINIMGR_SIZE_512M                (MINIMGR_SIZE_1M*512)
#define MINIMGR_SIZE_1G                  (MINIMGR_SIZE_1M*1024)
#define MINIMGR_SIZE_2G                  ((UINT32)MINIMGR_SIZE_1M * 2048)
#define RUN_VERSION_NAME_SIZE            64

#define MEM_DEVICE_MEM                  (0)
#define MEM_DEVICE_CACHEDMEM            (1)
#define MEM_DEVICE_MEMNC                (2)
/**************************************************************************
 *                         数据类型                                       *
 **************************************************************************/

/**************************************************************************
 *                         全局变量声明                                   *
 **************************************************************************/


/**************************************************************************
 *                         全局函数声明                                   *
 **************************************************************************/
UINT32 BspDoMemMap(UINT32 devSel, unsigned long virAddr, off_t phyAddr, size_t size, unsigned long *pVirAddr);
UINT32 BspSetSecVerifyFunStat(UINT32 ulSwitch);
UINT32 BspInitSecVerifyFun(VOID);
UINT32 BspGetVerFileInfo(CHAR *file, UINT32 *pLen, UINT32 *pCrc);
VOID BspDecodeB64(UCHAR *d64,UCHAR *d,INT32 mlen);
UINT32 BspGetVersionSign(CHAR *ucBuf,UINT32 ulBufLen,UINT32 ulFileLen, UINT32 ulFileCrc,UCHAR *ucSign);
UINT32 BspModuleVersion_Verify(UCHAR *ulBuf,UINT32 ulBufLen,UCHAR *sign_data) ;
UINT32 BspGetSafeBootDbgFlag(VOID);
void BspSetMiniMasterSlaveFlag(UINT32 flag);
UINT32 BspCreateRuCfgIniFile(const CHAR *pszFileName, T_Bsp_RruIniCfgItem *ptCfgItem);
void BspSetProZoneAddr(UINT32 addr);

#endif  /* _USHELLAPI_H_ */


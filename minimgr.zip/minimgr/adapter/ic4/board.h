/*****************************************************************************
 * 版权所有(C) 2015, ZTE Corp. ZXSDR-RRU Platform BSP
 *----------------------------------------------------------------------------
 * 模 块 名 : BSP
 * 文件名称 : board.h
 * 文件标识 : {[N/A]}
 * 内容摘要 : 本文件主要提供单板flash及cpu相关定义
 * 注意事项 : 无
 * 作    者 : 10090699
 * 创建日期 : 2017-2-27 16:03:00
 * 当前版本 : Ver1.0
 *----------------------------------------------------------------------------
 * 变更记录 :
 *
 * $记录1
 * 变 更 单:
 * 责 任 人:
 * 修改日戳:
 * 变更说明:

 *----------------------------------------------------------------------------
 */
#ifndef _BOARD_H_H_
#define _BOARD_H_H_

#ifdef __cplusplus
extern "C" {
#endif

/*----------------------------------------------------------------------------*/
/*                        宏定义            */
/*----------------------------------------------------------------------------*/
#define SIZE_1K                  (1024)
#define SIZE_4K                  (SIZE_1K*4)
#define SIZE_8K                  (SIZE_1K*8)
#define SIZE_64K                 (SIZE_1K*64)
#define SIZE_128K                (SIZE_1K*128)
#define SIZE_256K                (SIZE_1K*256)
#define SIZE_320K                (SIZE_1K*320)
#define SIZE_512K                (SIZE_1K*512)
#define SIZE_1M                  (SIZE_1K*1024)
#define SIZE_2M                  (SIZE_1M*2)
#define SIZE_3M                  (SIZE_1M*3)
#define SIZE_4M                  (SIZE_1M*4)
#define SIZE_6M                  (SIZE_1M*6)
#define SIZE_8M                  (SIZE_1M*8)
#define SIZE_9M                  (SIZE_1M*9)
#define SIZE_10M                 (SIZE_1M*10)
#define SIZE_12M                 (SIZE_1M*12)
#define SIZE_17M                 (SIZE_1M*17)
#define SIZE_31M                 (SIZE_1M*31)
#define SIZE_35M                 (SIZE_1M*35)
#define SIZE_64M                 (SIZE_1M*64)
#define SIZE_128M                (SIZE_1M*128)
#define SIZE_256M                (SIZE_1M*256)
#define SIZE_384M                (SIZE_1M*384)
#define SIZE_512M                (SIZE_1M*512)
#define SIZE_1G                  (SIZE_1M*1024)
#define SIZE_2G                  ((UINT32)SIZE_1M * 2048)

/* DDR映射相关 */
#define DRAM_128M                SIZE_128M
#define DRAM_256M                SIZE_256M
#define DRAM_384M                SIZE_384M

#define LOCAL_MEM_LOCAL_ADRS     (0x00000000) /* 低端内存留给系统分配用 */
//#define LOCAL_MEM_SIZE           DRAM_256M
#define LOCAL_MEM_SIZE            DRAM_384M

#define SYS_PHYS_MEM_TOP         (LOCAL_MEM_LOCAL_ADRS + LOCAL_MEM_SIZE)
/*********************高端内存规划*************************
   +------------------------------------------+
   |    中试和BSP (512K)                      |
   |    BSP_HIGH_RESERVED_MEM_BSP             |
   +------------------------------------------+
   |    OSS黑匣子 (512K)                      |
   |    BSP_HIGH_RESERVED_MEM_MGR             |
   +------------------------------------------+
   |    应用保留区(1M)                        |
   |    BSP_HIGH_RESERVED_MEM_L3    128K      |
   |    BSP_HIGH_RESERVED_MEM_APP3  320K      |
   |    BSP_HIGH_RESERVED_MEM_APP2  512K      |
   |    BSP_HIGH_RESERVED_MEM_APP1  64K       |
   +------------------------------------------+
   |    版本保护区 (4M)                       |
   |    BSP_HIGH_RESERVED_MEM_USER_DEFINE     |
   +------------------------------------------+
 **********************************************************/
#define OSS_MEM_SIZE             SIZE_512K
#define BSP_MEM_SIZE             SIZE_512K
#define BSP_VER_PROTECT_SIZE     SIZE_4M
#define APP_RESERVED_SIZE        SIZE_1M
#define USER_RESERVED_SIZE       (OSS_MEM_SIZE + BSP_MEM_SIZE + BSP_VER_PROTECT_SIZE + APP_RESERVED_SIZE)

//#define SYS_MEM_TOP              (SYS_PHYS_MEM_TOP - USER_RESERVED_SIZE)
#define SYS_MEM_TOP              0x11200000  //0x1B600000 DDR降容，改为512M，高端DDR 起始地址改为0x11200000
#define USER_RESERVED_ADDR       (SYS_MEM_TOP)
#define BSP_VER_PROTECT_ADDR     (SYS_MEM_TOP)
#define APP_RESERVED_ADDR        (BSP_VER_PROTECT_ADDR + BSP_VER_PROTECT_SIZE)
#define OSS_MEM_ADDR             (APP_RESERVED_ADDR + APP_RESERVED_SIZE)
#define BSP_MEM_ADDR             (OSS_MEM_ADDR + OSS_MEM_SIZE)


/********************************************************************************************************
                                       flash区域规划定义128M+256M
 ********************************************************************************************************
 FLASH空间规划        用途                容量       说明
     0M ~  0.5M     bootstrap             512k    Bootstrap 一级boot，ddr初始化，引导kexecboot，双boot模块
   0.5M ~    4M     主BOOT版本            3.5M    3.5M区域首部的128K为主boot版本头
     4M ~  7.5M     从BOOT版本            3.5M    3.5M区域首部的128K为从boot版本头
   7.5M ~ 7.75M     双BOOT控制字          256K  　
  7.75M ~    8M     环境变量              256K    沿用UBOOT环境变量区域用于各种引导参数配置
    8M  ~ 8M+0x10   BOMID区               0x10    存放BOMID区，具体以下4组8bit数据:
 8M+0x10~ 8M+0x90   MAC地址区             0x80    配置主核光网口MAC地址        
 8.25M  ~   12M   校准表FT/高温老化写表区 3M+768K 高温老化写表约定低端开始使用
   12M  ~  128M     版本保护区            116M 　
  128M  ~128+256M   文件系统区            256M
 *******************************************************************************************************/
/********************************************************************************************************
                                       flash区域规划定义16M （还需优化）
 ********************************************************************************************************
 FLASH空间规划        用途                容量       说明
     0M ~  1M       bootstrap             1M      Bootstrap 一级boot，ddr初始化，引导kexecboot，双boot模块
     1M ~  9M     主KEBOOT版本            8M      层3版本头在前面
    9M  ~ 9M+0x10   BOMID区               0x10    存放BOMID区，具体以下4组8bit数据:
 9M+0x10~ 9M+0x90   MAC地址区             0x80    配置主核光网口MAC地址        
 9M+0x90~ 16M        保留区                       保留区
 *******************************************************************************************************/
#define NOR_FLASH_SIZE                 SIZE_1M*16
#define NAND_FLASH_SIZE                SIZE_256M
#define FLASH_SECTOR_SIZE              SIZE_256K /*SPI Flash 的擦除块大小不同--与硬件强相关*/
#define FLASH_PARTITION_NUM            (3)       /*boot、保护区、文件系统*/

/* BOOT区定义 */
#define BOOT_STRAP_OFFSET              0
#define BOOT_STRAP_SIZE                SIZE_1M
#define BOOT_VERSION_START             (BOOT_STRAP_OFFSET+BOOT_STRAP_SIZE)
#define BOOT_VERSION_SIZE              SIZE_8M


/* FLASH mtd定义 */
#define FLASH_BOOT_OFFSET              (0)
#define FLASH_BOOT_SIZE                BOOT_STRAP_SIZE + BOOT_VERSION_SIZE

#define FLASH_RESVERD_OFFSET           FLASH_BOOT_SIZE //绝对地址是第9M
#define FLASH_RESVERD_SIZE             (NOR_FLASH_SIZE - FLASH_RESVERD_OFFSET) //大小是128M - 8M = 120M

#define FLASH_JFFS2_OFFSET             (FLASH_RESVERD_OFFSET + FLASH_RESVERD_SIZE) //绝对地址128M，也即跳过了NOR FLASH，进入到NAND FLASH
#define FLASH_JFFS2_SIZE               (NAND_FLASH_SIZE)                           //大小是128M

/* BOM ID */
#define FLASH_BOMID_OFFSET             FLASH_RESVERD_OFFSET  //绝对地址是第9M
#define FLASH_BOMID_SIZE               0x10
#define FLASH_MODULE_GROUP_ID          (FLASH_BOMID_OFFSET+0)//绝对地址是第9M + 0个字节
#define FLASH_BOARD_GROUP_ID           (FLASH_BOMID_OFFSET+1)//绝对地址是第9M + 1个字节
#define FLASH_BOARD_TYPE_ID            (FLASH_BOMID_OFFSET+2)//绝对地址是第9M + 2个字节
#define FLASH_BOARD_HARD_CHANGE_ID     (FLASH_BOMID_OFFSET+3)//绝对地址是第9M + 3个字节
#define FLASH_BOMID_CRC_OFFSET         (FLASH_BOMID_OFFSET+4)//绝对地址是第9M + 4个字节


#define FLASH_MACID_OFFSET            (FLASH_RESVERD_OFFSET + 0x10) // 绝对地址是第9M+0x10
#define FLASH_MACID_SIZE              (0x80)

/* 校准表,资产信息表 */
#define FLASH_RFTBL_OFFSET             (FLASH_RESVERD_OFFSET + SIZE_256K) //绝对地址是第9.25M
#define FLASH_RFTBL_SIZE               (SIZE_3M + SIZE_512K)              //大小是3.5M

/* FT/WFS规划区 从低端开始使用 */
#define FLASH_FT_WFS_OFFSET            (FLASH_RFTBL_OFFSET + FLASH_RFTBL_SIZE)//绝对地址是第12.75M~13M
#define FLASH_FT_WFS_SIZE              SIZE_256K                              //大小是0.25M

/* 保护区 */
#define PROTECT_ZONE_ADDRESS           FLASH_FT_WFS_OFFSET + FLASH_FT_WFS_SIZE/* 保护区起始地址，第13M        */
#define PROTECT_ZONE_SIZE              (NOR_FLASH_SIZE-PROTECT_ZONE_ADDRESS)  /* 保护区大小，16M - 12M = 4M */

/*读取boot版本*/
#define IC_BOOT_KEBOOT_ADDR            0x100000        /* keboot起始地址 */

/****************END of flash区域规划定义*****************/


#ifdef __cplusplus
}
#endif

#endif /* _BOARD_H_H_ */



#ifdef MINIMGR_SUPPORT

#ifndef	_MINIMGR_ADPT_H_
#define	_MINIMGR_ADPT_H_

#ifdef __cplusplus
extern "C" {
#endif


/*CPU bit type: 0:32bit,1:64bit*/
#define  CPU_BIT_TYPE_FLAG        1

#define  HIMEM_VIR_BASEADDR        (0)
#define  HIMEM_PHY_BASEADDR       (SYS_MEM_TOP)

UINT32 BspAdaptMemUnmap(VOID);
UINT32 BspInitBoardAdpt(VOID);


#endif
#endif


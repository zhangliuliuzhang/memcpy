#ifdef MINIMGR_SUPPORT

#include <math.h>
#include "bsppub.h"
#include "bspcomm.h"
#include "board.h"
#include "minimgr.h"
#include "minimgradpt.h"

typedef volatile UINT32 T_LOACLABUS_REG;

#define WDT_MAX_TIME  1373

#define WD_REG_LOCK      (0xC00)
#define WD_REG_COUNTROL   (0x008)
#define CRM_REG_IDX_A53_CPU_RESET   (0x410)

#define CRM_A53_CPU_RESET_POW        0x0
#define CRM_A53_CPU_RESET_CORE       0x1
#define CRM_A53_CPU_RESET_DBG        0x2
#define CRM_A53_CPU_RESET_WATCHDOG   0x3
#define CRM_A53_CPU_RESET_CORE_ONLY  0x4

#define	UNLOCK		    (0x1ACCE551)
#define	LOCK		    (0x00000001)


UINT32 g_ulIcRstVirtualBaseAddr = 0;
UINT32 g_ulIcRstPhyBaseAddr = 0xD4C00000;
UINT32 g_ulIcRstMapMemSize = 0x1000;
UINT32 g_ulIcRstMapVirtualBaseAddr = 0;


UINT32 g_ulIcWdtVirtualBaseAddr = 0;
UINT32 g_ulIcWdtPhyBaseAddr = 0xDC102000;
UINT32 g_ulIcWdtMapMemSize = 0x2000;
UINT32 g_ulIcWdtMapVirtualBaseAddr = 0;

static UINT32 DpdIcHalRegWr_LocalBus(UINT32 baseAddr,UINT32 addr, UINT32 val)
{

    *(T_LOACLABUS_REG*)(addr+baseAddr) = (T_LOACLABUS_REG)val;

    return BSP_OK;
}

static UINT32 DpdIcHalRegRd_LocalBus(UINT32 baseAddr, UINT32 addr, UINT32 *pVal)
{
    if(NULL==pVal)
    {
        return BSP_ERROR;
    }

    *pVal = (UINT32)*(T_LOACLABUS_REG*)(addr+baseAddr);
    
    return BSP_OK;
}

static UINT32 DpdIcHalRegWrMask_LocalBus(UINT32 baseAddr,UINT32 addr, UINT32 val, UINT32 mask)
{
    T_LOACLABUS_REG regVal  = 0;
    T_LOACLABUS_REG setVal  = (T_LOACLABUS_REG)val;
    T_LOACLABUS_REG valMask = (T_LOACLABUS_REG)(~mask);
    
    regVal  = (UINT32)*(T_LOACLABUS_REG*)(addr+baseAddr);
    setVal &= (T_LOACLABUS_REG)mask;
    regVal &=valMask;
    setVal |= regVal;
    *(T_LOACLABUS_REG*)(addr+baseAddr) = setVal;

    return BSP_OK;
}

UINT32 IcRstRegWr(UINT32 addr, UINT32 val)
{
    return  DpdIcHalRegWr_LocalBus(g_ulIcRstMapVirtualBaseAddr,addr,val);
}

UINT32 IcWdtRegWr(UINT32 addr, UINT32 val)
{
    return DpdIcHalRegWr_LocalBus(g_ulIcWdtMapVirtualBaseAddr,addr,val);
}

UINT32 IcRstRegWrMask(UINT32 addr, UINT32 val,UINT32 ulMask)
{
    return  DpdIcHalRegWrMask_LocalBus(g_ulIcRstMapVirtualBaseAddr,addr,val,ulMask);
}


UINT32 setWtdLockMini(UINT32 lock)
{
    IcWdtRegWr(WD_REG_LOCK,lock);
    return BSP_OK;
}
UINT32 setWtdCtrlMini(UINT32 ctrl)
{
    IcWdtRegWr(WD_REG_COUNTROL,ctrl);
    return BSP_OK;
}
static UINT32 IcHalCrmA53SetResetMini(UINT32 type, UINT32 rstFlag)
{
	UINT32 retVal = BSP_OK;
	UINT32 rstBit = 0;
	UINT32 regAddr = CRM_REG_IDX_A53_CPU_RESET;
	switch(type)
	{
		case CRM_A53_CPU_RESET_POW:
		{
			rstBit = 0;
			break;
		}
		case CRM_A53_CPU_RESET_CORE:
		{
			rstBit = 4;
			break;
		}
		case CRM_A53_CPU_RESET_DBG:
		{
			rstBit = 8;
			break;
		}
		case CRM_A53_CPU_RESET_WATCHDOG:
		{
			rstBit = 12;
			break;
		}
		case CRM_A53_CPU_RESET_CORE_ONLY:
		{
			rstBit = 16;
			break;
		}
		default:
		{
			dbgErr("[%s]A53 type&d Reset Bit Para Error \n",__FUNCTION__,type);
			rstBit = 0;
			break;
		}
	}
    
	retVal |= IcRstRegWrMask(regAddr,rstFlag,(0x1<< rstBit));
	return retVal;
}

static UINT32 IcHalCrmA53SetResetWdMini(UINT32 rstFlag)
{
    return IcHalCrmA53SetResetMini(CRM_A53_CPU_RESET_WATCHDOG,rstFlag);
}

UINT32 WatchDogEnable(VOID)
{
    UINT32       ulVal = 0;
#if 0
    setWtdLock(0,UNLOCK);
    setWtdCtrl(0,INT_ENABLE | RESET_ENABLE);//使能计数和中断
    setWtdLock(0,LOCK);
#endif
    return BSP_OK;
}

UINT32 WatchDogInit(VOID)
{
    UINT32 ulRet = BSP_OK;
#if 0
    UINT32 ulRet = BSP_ERROR;
    UINT32 ulVal = 0;

    IcHalCrmA53SetResetWdMini(0);
    IcHalCrmA53SetResetWdMini(1);
    ulRet = WatchDogDisable();

    //ulRet |= SetWatchDogTime(WDT_MAX_TIME);/*DPDIC3.0看门狗最大支持21S，所以喂狗周期要在21S之内，推荐15S*/
    //ulRet |= WatchDogEnable();
#endif
    return ulRet;
}

static UINT32 WatchDogDisable(VOID)
{
    setWtdLockMini(UNLOCK);
    setWtdCtrlMini(0); /* IC看门狗复位去使能 ,关闭中断和计数*/
    setWtdLockMini(LOCK);

    return BSP_OK;
}

UINT32 BspWatchDogDisable(VOID)
{
    return WatchDogDisable();
}

UINT32 BspIcRegInit(VOID)
{
    UINT32 ulTmpRet = BSP_OK;
    
    ulTmpRet = BspDoMemMap(MEM_DEVICE_MEM, g_ulIcRstVirtualBaseAddr,g_ulIcRstPhyBaseAddr,g_ulIcRstMapMemSize,&g_ulIcRstMapVirtualBaseAddr);
    
    if((ulTmpRet != BSP_OK)||(g_ulIcRstMapVirtualBaseAddr == 0))
    {
        printf("%s>>IcRst map Err !\n",__FUNCTION__);
        return BSP_ERROR;
    }

    ulTmpRet = BspDoMemMap(MEM_DEVICE_MEM, g_ulIcWdtVirtualBaseAddr,g_ulIcWdtPhyBaseAddr,g_ulIcWdtMapMemSize,&g_ulIcWdtMapVirtualBaseAddr);
  
    if((ulTmpRet != BSP_OK)||(g_ulIcWdtMapVirtualBaseAddr == 0))
    {
        printf("%s>>IcWdt map Err !\n",__FUNCTION__);
        return BSP_ERROR;
    }

    return BSP_OK;
}

UINT32 BspIcRegMapMemRelease(VOID)
{
    if(g_ulIcRstMapVirtualBaseAddr != NULL)
    {
        munmap((VOID*)g_ulIcRstMapVirtualBaseAddr,g_ulIcRstMapMemSize);
    }

    if(g_ulIcWdtMapVirtualBaseAddr != NULL)
    {
        munmap((VOID*)g_ulIcWdtMapVirtualBaseAddr,g_ulIcWdtMapMemSize);
    }
    return BSP_OK;
}


UINT32 BspInitBoardAdpt(VOID)
{
    BspIcRegInit();  
    BspWatchDogDisable();
    BspSetMiniMasterSlaveFlag(MINIMGR_SLAVE_FLAG);
    return BSP_OK;
}

UINT32 BspAdaptMemUnmap(VOID)
{
    BspIcRegMapMemRelease();

    return BSP_OK;
}
#endif


#include "pub_typedef.h"
#include "pub_errordef.h"
#include "ru_basedef.h"
#include "zprintf.h"
#include "flash.h"
#include "minimgr.h"
#include "minimgradpt.h"
#include "zx211413gpio.h"

typedef volatile UINT32 T_LOACLABUS_REG;
#define WD_REG_WdogLoad     (0x0)
#define WD_REG_WdogControl  (0x008)
#define WD_REG_WdogLock     (0xC00)
#define UNLOCK              (0x1ACCE551)
#define LOCK                (0x00000001)
#define INT_ENABLE          (1 << 0)
#define RESET_ENABLE        (1 << 1)
#define KERNEL_FEEDDOG_TIME 240     /* 240s */
#define WDT_MAX_TIME        1374    /* 0xffffffff / 50000000 * 16 */
#define PAD0_GPIO0_TO_15_OFFSET     (0x188)
#define PAD_0_MAP_ADDR              (0xC1100000)
#define PAD_0_MAP_SIZE              (0x00010000)

static unsigned long s_ulIcWdtVirtualBaseAddr   = 0;
static off_t s_ulIcWdtPhyBaseAddr               = 0xDC104000;
static size_t s_ulIcWdtMapMemSize               = 0x2000;
static unsigned long s_ulIcWdtMapVirtualBaseAddr= 0;
static T_HW_GPIO_MAP_ADDR aGpioMapAddr = {0xD6400000,    0,      0};
static unsigned long g_Pad0VirAddr = 0;

static UINT32 DpdIcHalRegWr_LocalBus(unsigned long baseAddr, UINT32 addr, UINT32 val)
{
    *(T_LOACLABUS_REG*)(addr+baseAddr) = (T_LOACLABUS_REG)val;

    return BSP_OK;
}

static UINT32 IcWdtRegWr(UINT32 addr, UINT32 val)
{
    return DpdIcHalRegWr_LocalBus(s_ulIcWdtMapVirtualBaseAddr, addr, val);
}

static UINT32 setWtdLockMini(UINT32 lock)
{
    return IcWdtRegWr(WD_REG_WdogLock, lock);
}

static UINT32 SetWtdLoadMini(UINT32 load)
{
    return IcWdtRegWr(WD_REG_WdogLoad, load);
}

static UINT32 setWtdCtrlMini(UINT32 ctrl)
{
    return IcWdtRegWr(WD_REG_WdogControl, ctrl);
}

static UINT32 WatchDogCtrlMini(UINT32 enable)
{
    UINT32 ctrl = 0;

    setWtdLockMini(UNLOCK);
    if (enable == 1)
    {
        ctrl = INT_ENABLE | RESET_ENABLE;
    }
    else
    {
        /* IC看门狗复位去使能 ,关闭中断和计数*/
        ctrl = 0;
    }
    setWtdCtrlMini(ctrl);
    setWtdLockMini(LOCK);

    return BSP_OK;
}

/* ulTimerValue 单位s */
static UINT32 SetWatchDogTimeMini(UINT32 ulTimerValue)
{
    UINT32      ulLoadVal = 0;

    if (ulTimerValue < 1)
    {
        dbgErr("%s: set wtd timeout error\n", __FUNCTION__);
        return BSP_ERROR;
    }
    ulTimerValue = min(ulTimerValue, WDT_MAX_TIME);

    // 1: IC4.2 看门狗时钟是50MHZ.  2: 计数器位宽是 36bit,可配置的是高32bit,所以要除以16
    ulLoadVal = (UINT32)((ulTimerValue * (5 * pow(10, 7))) / 16);
    setWtdLockMini(UNLOCK);
    SetWtdLoadMini(ulLoadVal);
    setWtdLockMini(LOCK);

    return BSP_OK;
}

static UINT32 BspIcRegInit(void)
{
    UINT32 ret = BSP_OK;

    ret = BspDoMemMap(MEM_DEVICE_MEM, s_ulIcWdtVirtualBaseAddr, s_ulIcWdtPhyBaseAddr, s_ulIcWdtMapMemSize, &s_ulIcWdtMapVirtualBaseAddr);
    if((ret != BSP_OK) || (s_ulIcWdtMapVirtualBaseAddr == 0))
    {
        printf("%s>>IcWdt map Err !\n",__FUNCTION__);
        return BSP_ERROR;
    }

    return BSP_OK;
}

static UINT32 BspGetDpdicRpuId(void)
{
    UCHAR   *pBaseAddr = NULL;
    UINT32  ulRpuId = 0;
    UCHAR   *pAddr = NULL;

    if (BSP_OK == BspDoMemMap(MEM_DEVICE_MEMNC, 0, 0xD4B00000, 0x1000, (unsigned long *)&pBaseAddr))
    {
        pAddr = pBaseAddr + 0x64;
        ulRpuId = (UINT32)*(volatile UINT32*)pAddr;
        munmap((void*)pBaseAddr, 0x1000);
    }
    return (ulRpuId & 0x7);
}

static UINT32 Zx211413GpioMmap(void)
{
    UINT32 retVal = 0;
    retVal = BspDoMemMap(MEM_DEVICE_MEM, 0, aGpioMapAddr.phyAddr, ZX211413_GPIO_REGS_SIZE, (unsigned long *)&aGpioMapAddr.virAddr);
    retVal |= BspDoMemMap(MEM_DEVICE_MEM, 0, PAD_0_MAP_ADDR, PAD_0_MAP_SIZE, (unsigned long *)&g_Pad0VirAddr);
    return retVal;
}

static UINT32 zx211413GetGpioReg(UINT32 offset, UINT32 *regVal)
{
    void* gpioAddr = 0;

    gpioAddr = aGpioMapAddr.virAddr + offset;
    *regVal = *(volatile UINT32 *)(gpioAddr);

    return BSP_OK;
}

static UINT32 zx211413SetGpioReg(UINT32 offset, UINT32 regVal)
{
    void* gpioAddr = 0;

    gpioAddr = aGpioMapAddr.virAddr + offset;
    *(volatile UINT32 *)(gpioAddr) = regVal;

    return BSP_OK;
}

/**********************************************************************
* 函数名称: zx211413InputParaProcess
* 功能描述: 依据Port计算寄存器地址和bit位
* 输入参数: port:管脚编号【0~127】
* 输出参数: portBase：偏移地址的基地址，0x40的整倍数
* 说       明: 无
* 返  回  值: BSP_OK / BSP_ERROR
************************************************************************/
static UINT32 zx211413InputParaProcess(UINT32 port, UINT32 *portBase, UINT32 *bit)
{
    *portBase = (UINT32)((port / ONE_REG_MAX_GPIO) * ZX211413_GPIO_PORT_SIZE);
    *bit      = (UINT32)(port % ONE_REG_MAX_GPIO);
    return BSP_OK;
}

/**********************************************************************
* 函数名称: zx211413GetGpioRegBit
* 功能描述: 获取寄存器地址对应bit位的值
* 输入参数: addr: 寄存器地址，bit: bit位
* 输出参数: 无
* 说       明: 无
* 返  回  值: BSP_OK / BSP_ERROR
************************************************************************/
static UINT32 zx211413GetGpioRegBit(UINT32 addr, UINT32 bit)
{
    UINT32 regVal = 0;

    zx211413GetGpioReg(addr, &regVal);
    regVal = GPIO_GET_BIT_VAL(regVal, bit);

    return regVal;
}

/**********************************************************************
* 函数名称: _BspZteGpioGet1
* 功能描述: 获取Port管教的状态
* 输入参数: port:管脚编号【0~127】
* 输出参数: 无
* 说       明: 只有输入管脚可用接口
* 返  回  值: BSP_OK / BSP_ERROR
************************************************************************/
static UINT32 _BspZteGpioGet1(UINT32 port)
{
    UINT32 regBitVal       = 0;
    UINT32 bit             = 0;
    UINT32 portBase        = 0;

    INPUT_PORT_CHECK(port);
    zx211413InputParaProcess(port, &portBase, &bit);

    regBitVal = zx211413GetGpioRegBit(portBase + GPIO_INPUT_DATA, bit);

    return regBitVal;
}

/******************************************************************************
* 函数名称   : BootRdIcGpioPadReg(UINT32 padIdx,UINT32 ulAddr)
* 功能描述   : 实现对gpio pad读寄存器操作，padIdx分为两组
* 读全局变量 : 无
* 写全局变量 : 无
* 输入参数   : ulAddr pad地址
* 输出参数   : 无
* 返 回 值   : BSP_OK, 操作成功; BSP_ERROR_INVALID_PARA, 输入参数错误
* 其它说明   : *  函数属性   : 基础接口
*------------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*------------------------------------------------------------------------------
*/
static UINT32 BootRdIcGpioPadReg(UINT32 ulAddr)
{
    unsigned long ulRegAddr = 0;
    unsigned long base = g_Pad0VirAddr;

    if (base == 0)
    {
        return 0;
    }

    ulRegAddr = ulAddr + base;
    return *((volatile UINT32 *)ulRegAddr);
}

/******************************************************************************
* 函数名称   : BootWrIcGpioPadReg(UINT32 padIdx,UINT32 ulAddr, UINT32 ulData)
* 功能描述   : 实现对gpio pad写寄存器操作，padIdx分为两组
* 读全局变量 : 无
* 写全局变量 : 无
* 输入参数   : ulAddr pad地址       ulData 值
* 输出参数   : 无
* 返 回 值   : BSP_OK, 操作成功; BSP_ERROR_INVALID_PARA, 输入参数错误
* 其它说明   : *  函数属性   : 基础接口
*------------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*------------------------------------------------------------------------------
*/
UINT32 BootWrIcGpioPadReg(UINT32 ulAddr, UINT32 ulData)
{
    unsigned long ulRegAddr = 0;
    unsigned long base = g_Pad0VirAddr;

    ulRegAddr = ulAddr + base;
    *((volatile UINT32 *)ulRegAddr) = ulData;

    return BSP_OK;
}

/******************************************************************************
* 函数名称   : BootWrIcGpioPadRegBit(UINT32 padIdx,UINT32 ulAddr, UINT32 ulData, UINT32 bitoff)
* 功能描述   : 实现对gpio pad写寄存器操作，padIdx分为两组
* 读全局变量 : 无
* 写全局变量 : 无
* 输入参数   : padIdx  pad组号，ulAddr pad地址       ulData 值
* 输出参数   : 无
* 返 回 值   : BSP_OK, 操作成功; BSP_ERROR_INVALID_PARA, 输入参数错误
* 其它说明   : *  函数属性   : 基础接口
*------------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*------------------------------------------------------------------------------
*/
static UINT32 BootWrIcGpioPadRegBit(UINT32 gpio, UINT32 ulVal, UINT32 bitoff)
{
    UINT32 regVal = 0;
    UINT32 ulAddr = 0;

    if (gpio >= 0 && gpio <= 15)
    {
        ulAddr = 4 * gpio + PAD0_GPIO0_TO_15_OFFSET;
    }
    else
    {
        return BSP_ERROR;
    }

    regVal = BootRdIcGpioPadReg(ulAddr);
    BITS_SET(regVal, ulVal, bitoff, 1);

    return BootWrIcGpioPadReg(ulAddr, regVal);
}

static UINT32 BootWrIcGpioPadEn(UINT32 gpio, UINT32 en)
{
    return BootWrIcGpioPadRegBit(gpio, en, 8);
}

/**********************************************************************
* 函数名称: zx211413SetGpioRegBit
* 功能描述: 修改寄存器对应Bit位的值
* 输入参数: addr: 寄存器地址，bit: bit位， isHigh: 1/0(高/低电平)
* 输出参数: 无
* 说       明: 只修改对应bit的值，其他bit不变
* 返  回  值: BSP_OK / BSP_ERROR
************************************************************************/
static UINT32 zx211413SetGpioRegBit(UINT32 addr, UINT32 bit, UINT32 isHigh)
{
    UINT32 retVal = BSP_OK;
    UINT32 regVal = 0;

    /*默认将大于等于1的值都配置成1*/
    isHigh = isHigh ? 1 : 0;

    retVal = zx211413GetGpioReg(addr, &regVal);
    regVal = GPIO_SET_BIT_VAL(regVal, isHigh, bit);
    retVal |= zx211413SetGpioReg(addr,regVal);

    return retVal;
}

/**********************************************************************
* 函数名称: _BspZteGpioSetInputMode
* 功能描述: 设置GPIO为输入模式
* 输入参数: port: GPIO管脚号
* 输出参数: 无
* 说       明:
* 返  回  值: BSP_OK / BSP_ERROR
************************************************************************/
static UINT32 _BspZteGpioSetInputMode(UINT32 port)
{
    UINT32 retVal          = BSP_OK;
    UINT32 bit             = 0;
    UINT32 portBase        = 0;

    INPUT_PORT_CHECK(port);
    retVal |= zx211413InputParaProcess(port, &portBase, &bit);
    retVal |= zx211413SetGpioRegBit(portBase + GPIO_DIRECTION , bit, 0);
    retVal |= zx211413SetGpioRegBit(portBase + GPIO_INT_ENABLE, bit, 0);
    retVal |= zx211413SetGpioRegBit(portBase + GPIO_INPUT_CLEAR, bit, 1);

    return retVal;
}

UINT32 BspInitBoardAdpt(void)
{
    UINT32 retVal = 0;
    UINT32 addrSel = 0;
    UINT32 rpuId = 0;
    UINT32 gpio0 = 0;
    T_Bsp_RruIniCfgItem iniCfg = {0};
    T_FlashInfo boardFlashInfo[] =
    {
        {
            NOR_FLASH_SIZE + NAND_FLASH_SIZE,
            FLASH_SECTOR_SIZE,
            FLASH_PARTITION_NUM,
            {
                {"/dev/mtd0", FLASH_BOOT_PART_OFFSET,       FLASH_BOOT_PART_SIZE},
                {"/dev/mtd1", FLASH_BSP_PART_OFFSET,        FLASH_BSP_PART_SIZE},
                {"/dev/mtd2", FLASH_SECRET_KEY_OFFSET,      FLASH_SECRET_KEY_SIZE},
            }
        },
        {
            NOR_FLASH_SIZE,
            FLASH_SECTOR_SIZE,
            FLASH_PARTITION_NUM,
            {
                {"/dev/mtd0", FLASH_BOOT_PART_OFFSET,       FLASH_BOOT_PART_SIZE_NOR},
                {"/dev/mtd1", FLASH_BSP_PART_OFFSET_NOR,    FLASH_BSP_PART_SIZE_NOR},
                {"/dev/mtd2", FLASH_SECRET_KEY_OFFSET_NOR,  FLASH_SECRET_KEY_SIZE},
            }
        }
    };

    BspIcRegInit();

    // rpuid为0是主片,大于0是从片
    rpuId = BspGetDpdicRpuId();
    if (rpuId == 0)
    {
        retVal = Zx211413GpioMmap();
        if (retVal == BSP_OK)
        {
            (void)BootWrIcGpioPadRegBit(0, 0, 9);
            (void)BootWrIcGpioPadRegBit(0, 0, 10);
            (void)_BspZteGpioSetInputMode(0);
            (void)BootWrIcGpioPadEn(0, 1);
            gpio0 = _BspZteGpioGet1(0);
            if (gpio0 == 1)
            {
                addrSel = 1;
                BspSetProZoneAddr(PROTECT_ZONE_ADDRESS_NOR);
            }
            (void)strncpy_s(iniCfg.acFieldName, sizeof(iniCfg.acFieldName), FLASH_SEL_KEY, sizeof(iniCfg.acFieldName));
            iniCfg.cFieldValue = '0' + addrSel;
            iniCfg.cFieldFlag  = '=';
            iniCfg.cFieldEnd   = '\n';
            (void)BspCreateRuCfgIniFile(FLASH_PARA_FILE, &iniCfg);
            dbgPrn("%s: gpio0=%u\n", __FUNCTION__, gpio0);
        }
        BspFlashModuleInit(&boardFlashInfo[addrSel]);
        BspFlashShowCfg();
        BspSetMiniMasterSlaveFlag(MINIMGR_MASTER_FLAG);
        SetWatchDogTimeMini(KERNEL_FEEDDOG_TIME);
        WatchDogCtrlMini(1);
        BspInitSecVerifyFun();
    }
    else
    {
        BspSetMiniMasterSlaveFlag(MINIMGR_SLAVE_FLAG);
        WatchDogCtrlMini(0);
    }
    return BSP_OK;
}

UINT32 BspIcRegMapMemRelease(VOID)
{
    if(s_ulIcWdtMapVirtualBaseAddr != 0)
    {
        munmap((void*)s_ulIcWdtMapVirtualBaseAddr, s_ulIcWdtMapMemSize);
    }
    if (aGpioMapAddr.virAddr != 0)
    {
        munmap(aGpioMapAddr.virAddr, ZX211413_GPIO_REGS_SIZE);
    }
    if (g_Pad0VirAddr != 0)
    {
        munmap((void*)g_Pad0VirAddr, PAD_0_MAP_SIZE);
    }
    return BSP_OK;
}

UINT32 BspAdaptMemUnmap(void)
{
    BspIcRegMapMemRelease();
    return BSP_OK;
}

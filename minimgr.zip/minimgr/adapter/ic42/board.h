#ifndef _IC42_MINIMGR_BOARD_H
#define _IC42_MINIMGR_BOARD_H

#ifdef __cplusplus 
extern "C" { 
#endif

/**************************************************************************
 *                        宏
 **************************************************************************/
#define SIZE_1K                  ((UINT32)1024)
#define SIZE_4K                  (SIZE_1K * (UINT32)4)
#define SIZE_8K                  (SIZE_1K * (UINT32)8)
#define SIZE_32K                 (SIZE_1K * (UINT32)32)
#define SIZE_64K                 (SIZE_1K * (UINT32)64)
#define SIZE_128K                (SIZE_1K * (UINT32)128)
#define SIZE_256K                (SIZE_1K * (UINT32)256)
#define SIZE_320K                (SIZE_1K * (UINT32)320)
#define SIZE_384K                (SIZE_1K * (UINT32)384)
#define SIZE_512K                (SIZE_1K * (UINT32)512)
#define SIZE_832K                (SIZE_1K * (UINT32)832)
#define SIZE_1M                  (SIZE_1K * (UINT32)1024)
#define SIZE_2M                  (SIZE_1M * (UINT32)2)
#define SIZE_3M                  (SIZE_1M * (UINT32)3)
#define SIZE_4M                  (SIZE_1M * (UINT32)4)
#define SIZE_6M                  (SIZE_1M * (UINT32)6)
#define SIZE_8M                  (SIZE_1M * (UINT32)8)
#define SIZE_9M                  (SIZE_1M * (UINT32)9)
#define SIZE_10M                 (SIZE_1M * (UINT32)10)
#define SIZE_12M                 (SIZE_1M * (UINT32)12)
#define SIZE_14M                 (SIZE_1M * (UINT32)14)
#define SIZE_17M                 (SIZE_1M * (UINT32)17)
#define SIZE_19M                 (SIZE_1M * (UINT32)19)
#define SIZE_20M                 (SIZE_1M * (UINT32)20)
#define SIZE_27M                 (SIZE_1M * (UINT32)27)
#define SIZE_28M                 (SIZE_1M * (UINT32)28)
#define SIZE_33M                 (SIZE_1M * (UINT32)33)
#define SIZE_35M                 (SIZE_1M * (UINT32)35)
#define SIZE_36M                 (SIZE_1M * (UINT32)36)
#define SIZE_45M                 (SIZE_1M * (UINT32)45)
#define SIZE_64M                 (SIZE_1M * (UINT32)64)
#define SIZE_128M                (SIZE_1M * (UINT32)128)
#define SIZE_256M                (SIZE_1M * (UINT32)256)
#define SIZE_384M                (SIZE_1M * (UINT32)384)
#define SIZE_512M                (SIZE_1M * (UINT32)512)
#define SIZE_1G                  (SIZE_1M * (UINT32)1024)
#define SIZE_2G                  (SIZE_1M * (UINT32)2048)

/****************START of flash区域规划定义*****************/

/***************************************************************************************
                             flash区域规划定义128M+256M(NOR+NAND)
 ***************************************************************************************
    FLASH空间规划                   用途                 容量         说明
 ======================================= MTD0 ==========================================
 0M            ~  256K           M0 BOOT主区(升级区)     256k
 256K          ~  512K           M0 BOOT GOLDEN区        256M
 512K          ~  1M             保留区                  512K         保留区
 1M            ~  1M+256K        A53 BOOT0主区(升级区)   256K         ZTE[BL2安全格式]]+PAD
 1M+256K       ~  2M+256K        A53 BOOT1主区(升级区)   1M           ZTE[FIP[BL31安全格式+BL33安全格式]]]+PAD
 2M+256K       ~  14M+256K       A53 BOOT2主区(升级区)   12M          ZTE[KEBOOT安全格式]+PAD+ZTEHEADER
 14M+256K      ~  14M+512K       A53 BOOT0 GOLDEN区      256K         ZTE[BL2安全格式]+PAD
 14M+512K      ~  15M+512K       A53 BOOT1 GOLDEN区      1M           ZTE[FIP[BL31安全格式+BL33安全格式]]]+PAD
 15M+512K      ~  27M+512K       A53 BOOT2 GOLDEN区      12M          ZTE[KEBOOT安全格式]+PAD+ZTEHEADER
 27M+512K      ~  27M+768K       双BOOT控制字            256K         预留
 27M+768K      ~  28M            环境变量                256K         沿用UBOOT环境变量区域用于各种引导参数配置
 ======================================= MTD1 ==========================================
 28M           ~  28M+0x10       Bomid区                 0x10         存放BomID区域
 28M+0x10      ~  28M+0x90       Mac地址区               0x80         全球唯一MAC地址信息
 28M+0x90      ~  28M+0xA0       业务id区                0x10         预留存放业务ID，具体以8bit为单位：印尼防盗ID
 28M+0xA0      ~  28M+256K       保留区                  256K-0xA0    保留区
 28M+256K      ~  33M            特性表、FT/高温老化表区 4.75M        校准表和资产信息表写入,FT和高温老化优先从高端规划
 33M           ~  NOR大小-1M     版本保护区              NOR大小-1M-33M
 ======================================= MTD2 ==========================================
 NOR大小-1M    ~  NOR大小        安全证书相关            1M           安全区，4K擦除
 ======================================= MTD3 ==========================================
 0M            ~  NAND大小       文件系统区              NAND大小*90% UBIFS文件系统空间开销约10%
 ***************************************************************************************

 ***************************************************************************************
                             flash区域规划定义128M(单NOR)
 ***************************************************************************************
    FLASH空间规划                   用途                 容量         说明
 ======================================= MTD0 ==========================================
 0M            ~  256K           M0 BOOT主区(升级区)     256K
 256K          ~  512K           M0 BOOT GOLDEN区        256K
 512K          ~  576K           保留区                  64K         保留区
 576K          ~  704K           A53 BOOT0主区(升级区)   128K         ZTE[BL2安全格式]]+PAD
 704K          ~  832K           A53 BOOT1主区(升级区)   128K         ZTE[FIP[BL31安全格式+BL33安全格式]]]+PAD
 832K          ~  9M+832K        A53 BOOT2主区(升级区)   9M           ZTE[KEBOOT安全格式]+PAD+ZTEHEADER
 9M+832K       ~  9M+960K        A53 BOOT0 GOLDEN区      128K        ZTE[BL2安全格式]+PAD
 9M+960K       ~  10M+64K        A53 BOOT1 GOLDEN区      128K        ZTE[FIP[BL31安全格式+BL33安全格式]]]+PAD
 10M+64K       ~  19M+64K        A53 BOOT2 GOLDEN区      9M          ZTE[KEBOOT安全格式]+PAD+ZTEHEADER
 19M+64K       ~  19M+256K       环境变量                192K        沿用UBOOT环境变量区域用于各种引导参数配置
 ======================================= MTD1 ==========================================
 19M+256K      ~  19M+256K+0x10  Bomid区                 0x10         存放BomID区域
 19M+256K+0x10 ~  19M+256K+0x90  Mac地址区               0x80         全球唯一MAC地址信息
 19M+256K+0x90 ~  19M+256K+0xA0  业务id区A               0x10         预留存放业务ID，具体以8bit为单位：印尼防盗ID
 19M+256K+0xA0 ~  19M+256K+0x4A0 即插即用功能占用区       0x400        即插即用功能占用区
 19M+256K+0x4A0~  19M+256K+0x4B0 业务id区B               0x10         预留存放业务ID，具体以8bit为单位
 19M+256K+0x4B0~  19M+320K       保留区                  64K-0x4B0    保留区
 19M+320K      ~  20M+320K       特性表、FT/高温老化表区 1M           校准表和资产信息表写入,FT和高温老化优先从高端规划
 20M+320k      ~  45M            版本保护区              24M+704K
 ======================================= MTD2 ==========================================
 45M           ~  46M            安全证书相关            1M           安全区，4K擦除
 ======================================= MTD3 ==========================================
 46M           ~  NOR大小        文件系统区              (NOR大小-46M)*90% UBIFS文件系统空间开销约10%
 ***************************************************************************************/
#define NOR_FLASH_SIZE                 ((UINT32)(SIZE_128M))                                         /* 和NOR FLASH大小有关 */
#define NAND_FLASH_SIZE                ((UINT32)(SIZE_256M))                                         /* 和NAND FLASH大小有关 */
#define FLASH_SECTOR_SIZE              ((UINT32)(SIZE_64K)) /*SPI Flash 的擦除块大小不同--与硬件强相关*/ //todo 待确认
#define FLASH_PARTITION_NUM            (3)

/* ====== BOOT区定义, BL2等其它空间需要新增 ====== */
#define M0BOOT_MASTER_ADDR             ((UINT32)(0))
#define M0BOOT_SLAVE_ADDR              ((UINT32)(SIZE_256K))
#define M0BOOT_SIZE                    ((UINT32)(SIZE_256K))
#define BOOT_BL2_MASTER_ADDR           ((UINT32)(SIZE_1M))
#define BOOT_BL2_SLAVE_ADDR            ((UINT32)(SIZE_14M+SIZE_256K))
#define BOOT_BL2_SIZE                  ((UINT32)(SIZE_256K)) 
#define BOOT_FIP_MASTER_ADDR           ((UINT32)(SIZE_1M+SIZE_256K))
#define BOOT_FIP_SLAVE_ADDR            ((UINT32)(SIZE_14M+SIZE_512K))
#define BOOT_FIP_SIZE                  ((UINT32)(SIZE_1M))
#define KEBOOT_MASTER_ADDR             ((UINT32)(SIZE_2M+SIZE_256K)) 
#define KEBOOT_SLAVE_ADDR              ((UINT32)(SIZE_14M+SIZE_1M+SIZE_512K)) 
#define KEBOOT_MAX_SIZE                ((UINT32)(SIZE_12M))
/* ================================================ */

/* FLASH BOOT PART(NOR+NAND)    mtd0 定义: 绝对地址是第0, 大小是28M */
#define FLASH_BOOT_PART_OFFSET         ((UINT32)0)
#define FLASH_BOOT_PART_SIZE           ((UINT32)(SIZE_28M))
/* FLASH BOOT PART(单NOR)       mtd0 定义: 绝对地址是第0, 大小是19.25M */
#define FLASH_BOOT_PART_SIZE_NOR       ((UINT32)(SIZE_19M + SIZE_256K))

/* FLASH BSP PART(NOR+NAND)     mtd1 定义: 绝对地址是第28M+128K, 大小是128M - 1M - (28M) */
#define FLASH_BSP_PART_OFFSET          ((UINT32)(FLASH_BOOT_PART_OFFSET + FLASH_BOOT_PART_SIZE))
#define FLASH_BSP_PART_SIZE            ((UINT32)(NOR_FLASH_SIZE - SIZE_1M - FLASH_BSP_PART_OFFSET))   /* 和NOR FLASH大小有关 */
/* FLASH BSP PART(单NOR)        mtd1 定义: 绝对地址是第19M+256K, 大小是45M - (19M + 256K) */
#define FLASH_BSP_PART_OFFSET_NOR      ((UINT32)(FLASH_BOOT_PART_SIZE_NOR))
#define FLASH_BSP_PART_SIZE_NOR        ((UINT32)(SIZE_45M - FLASH_BSP_PART_OFFSET_NOR))

/* FLASH SECRET KEY(NOR+NAND)   mtd2 定义: 绝对地址是第128M - 1M, 大小是1M */
#define FLASH_SECRET_KEY_OFFSET        ((UINT32)(NOR_FLASH_SIZE - SIZE_1M))                           /* 和NOR FLASH大小有关 */
#define FLASH_SECRET_KEY_SIZE          ((UINT32)(SIZE_1M))
/* FLASH SECRET KEY(单NOR)      mtd2 定义: 绝对地址是第45M, 大小是1M */
#define FLASH_SECRET_KEY_OFFSET_NOR    ((UINT32)(SIZE_45M))

// BOMID: 绝对地址28M, 大小是0x10
#define FLASH_BOMID_OFFSET             ((UINT32)(SIZE_28M))
#define FLASH_BOMID_SIZE               ((UINT32)0x10)
#define FLASH_BOMID_OFFSET_NOR         ((UINT32)(FLASH_BSP_PART_OFFSET_NOR))

// MACID: 绝对地址28M+0x10, 大小是0x80
#define FLASH_MACID_OFFSET             ((UINT32)(FLASH_BOMID_OFFSET + FLASH_BOMID_SIZE))
#define FLASH_MACID_SIZE               ((UINT32)0x80)
#define FLASH_MACID_OFFSET_NOR         ((UINT32)(FLASH_BOMID_OFFSET_NOR + FLASH_BOMID_SIZE))

// 防盗标示ID:28M+0x90到28M+0xa0，共0x10
#define FLASH_ANTI_STEAL_ID_OFFSET     ((UINT32)(FLASH_MACID_OFFSET + FLASH_MACID_SIZE))
#define FLASH_ANTI_STEAL_ID_SIZE       ((UINT32)0x10)
#define FLASH_ANTI_STEAL_ID_OFFSET_NOR ((UINT32)(FLASH_MACID_OFFSET_NOR + FLASH_MACID_SIZE))

// 校准表资产信息表: 绝对地址28M+256K, 大小是4.75M
#define FLASH_RFTBL_OFFSET             ((UINT32)(SIZE_28M + SIZE_256K))
#define FLASH_RFTBL_SIZE               ((UINT32)(SIZE_4M  + SIZE_512K))
#define FLASH_RFTBL_OFFSET_NOR         ((UINT32)(SIZE_19M + SIZE_320K))
#define FLASH_RFTBL_SIZE_NOR           ((UINT32)(SIZE_1M - SIZE_256K))

// FT/WFS规划区从低端开始使用: 绝对地址32M+768K, 大小是256K
#define FLASH_FT_WFS_OFFSET            ((UINT32)(FLASH_RFTBL_OFFSET + FLASH_RFTBL_SIZE))
#define FLASH_FT_WFS_SIZE              ((UINT32)(SIZE_256K))
#define FLASH_FT_WFS_OFFSET_NOR        ((UINT32)(FLASH_RFTBL_OFFSET_NOR + FLASH_RFTBL_SIZE_NOR))

// 保护区: 绝对地址33M, 大小94M, NorFlash容量128M
#define PROTECT_ZONE_ADDRESS           ((UINT32)(SIZE_33M))
#define PROTECT_ZONE_SIZE              ((UINT32)(NOR_FLASH_SIZE - PROTECT_ZONE_ADDRESS - SIZE_1M))    /* 和NOR FLASH大小有关 */
#define PROTECT_ZONE_ADDRESS_NOR       ((UINT32)(SIZE_20M + SIZE_320K))
#define PROTECT_ZONE_SIZE_NOR          ((UINT32)(SIZE_45M - PROTECT_ZONE_ADDRESS_NOR))

// 小版本压力测试ST: 绝对地址27M+192K, 大小32K;
// ###### 特别提醒: 使用了MTD1的保留区, 如果此区有其它用途, 需要修改此测试的基地址 !!!!!!
/* 块数据最大32k todo 待确认 */
#define ST_BLOCK_SIZE_TEST             ((UINT32)(SIZE_32K))                               //todo 待确认
#define ST_BLOCK_ADDR_FLASH            ((UINT32)(SIZE_28M+0xA0))

/****************END of flash区域规划定义*****************/



/****************START of DDR区域规划定义*****************/

/*********************高端内存规划*************************
   +------------------------------------------+
   |    中试和BSP (512K)                      |
   |    BSP_HIGH_RESERVED_MEM_BSP             |
   +------------------------------------------+
   |    OSS黑匣子 (512K)                      |
   |    BSP_HIGH_RESERVED_MEM_MGR             |
   +------------------------------------------+
   |    应用保留区(1M)                        |
   |    BSP_HIGH_RESERVED_MEM_L3    128K      |
   |    BSP_HIGH_RESERVED_MEM_APP3  320K      |
   |    BSP_HIGH_RESERVED_MEM_APP2  512K      |
   |    BSP_HIGH_RESERVED_MEM_APP1  64K       |
   +------------------------------------------+
   |    版本保护区 (4M)                       |
   |    BSP_HIGH_RESERVED_MEM_USER_DEFINE     |
   +------------------------------------------+
 **********************************************************/
#define OSS_MEM_SIZE             SIZE_512K
#define BSP_MEM_SIZE             SIZE_512K
#define BSP_VER_PROTECT_SIZE     SIZE_4M
#define APP_RESERVED_SIZE        SIZE_1M
#define USER_RESERVED_SIZE       (OSS_MEM_SIZE + BSP_MEM_SIZE + BSP_VER_PROTECT_SIZE + APP_RESERVED_SIZE)

#define SYS_MEM_TOP              (0x800000) 
#define USER_RESERVED_ADDR       (SYS_MEM_TOP)
#define BSP_VER_PROTECT_ADDR     (SYS_MEM_TOP)
#define APP_RESERVED_ADDR        (BSP_VER_PROTECT_ADDR + BSP_VER_PROTECT_SIZE)
#define OSS_MEM_ADDR             (APP_RESERVED_ADDR + APP_RESERVED_SIZE)
#define BSP_MEM_ADDR             (OSS_MEM_ADDR + OSS_MEM_SIZE)


#define ST_BLOCK_ADDR_DDR              (BspGetReservedMemAddr(BSP_HIGH_RESERVED_MEM_BSP) + (UINT32)0x50000)


/* 从MGR专用高端内存(仅限UBR机型使用，其他机型暂无空间划分) */
#define SLAVE_USER_RESERVED_SIZE       (OSS_MEM_SIZE + BSP_MEM_SIZE + APP_RESERVED_SIZE)
#define SLAVE_SYS_MEM_TOP              (0x3E00000) 
#define SLAVE_APP_RESERVED_ADDR        (SLAVE_SYS_MEM_TOP)
#define SLAVE_OSS_MEM_ADDR             (SLAVE_APP_RESERVED_ADDR + APP_RESERVED_SIZE)
#define SLAVE_BSP_MEM_ADDR             (SLAVE_OSS_MEM_ADDR + OSS_MEM_SIZE)


/****************END of DDR区域规划定义*****************/


/****************START of GPIO规划定义*****************/

/* 此处定义平台通用的GPIO，以下为示例，仅供参考 */
#define DPDIC_PIN_GPIO0      (0)
#define DPDIC_PIN_GPIO1      (1)
#define DPDIC_PIN_GPIO2      (2)
#define DPDIC_PIN_GPIO3      (3)
#define DPDIC_PIN_GPIO4      (4)
#define DPDIC_PIN_GPIO5      (5)
#define DPDIC_PIN_GPIO6      (6)
#define DPDIC_PIN_GPIO7      (7)
#define DPDIC_PIN_GPIO8      (8)
#define DPDIC_PIN_GPIO9      (9)
#define DPDIC_PIN_GPIO10      (10)
#define DPDIC_PIN_GPIO11      (11)
#define DPDIC_PIN_GPIO12      (12)
#define DPDIC_PIN_GPIO13      (13)
#define DPDIC_PIN_GPIO14      (14)
#define DPDIC_PIN_GPIO15      (15)
#define DPDIC_PIN_GPIO16      (16)
#define DPDIC_PIN_GPIO17      (17)
#define DPDIC_PIN_GPIO18      (18)
#define DPDIC_PIN_GPIO19      (19)
#define DPDIC_PIN_GPIO20      (20)
#define DPDIC_PIN_GPIO21      (21)
#define DPDIC_PIN_GPIO22      (22)
#define DPDIC_PIN_GPIO23      (23)
#define DPDIC_PIN_GPIO24      (24)
#define DPDIC_PIN_GPIO25      (25)
#define DPDIC_PIN_GPIO26      (26)
#define DPDIC_PIN_GPIO27      (27)
#define DPDIC_PIN_GPIO28      (28)
#define DPDIC_PIN_GPIO29      (29)
#define DPDIC_PIN_GPIO30      (30)
#define DPDIC_PIN_GPIO31      (31)
#define DPDIC_PIN_GPIO32      (32)
#define DPDIC_PIN_GPIO33      (33)
#define DPDIC_PIN_GPIO34      (34)
#define DPDIC_PIN_GPIO35      (35)
#define DPDIC_PIN_GPIO36      (36)
#define DPDIC_PIN_GPIO37      (37)
#define DPDIC_PIN_GPIO38      (38)
#define DPDIC_PIN_GPIO39      (39)
#define DPDIC_PIN_GPIO40      (40)
#define DPDIC_PIN_GPIO41      (41)
#define DPDIC_PIN_GPIO42      (42)
#define DPDIC_PIN_GPIO43      (43)
#define DPDIC_PIN_GPIO44      (44)
#define DPDIC_PIN_GPIO45      (45)
#define DPDIC_PIN_GPIO46      (46)
#define DPDIC_PIN_GPIO47      (47)
#define DPDIC_PIN_GPIO48      (48)
#define DPDIC_PIN_GPIO49      (49)
#define DPDIC_PIN_GPIO50      (50)
#define DPDIC_PIN_GPIO51      (51)
#define DPDIC_PIN_GPIO52      (52)
#define DPDIC_PIN_GPIO53      (53)
#define DPDIC_PIN_GPIO54      (54)
#define DPDIC_PIN_GPIO55      (55)
#define DPDIC_PIN_GPIO56      (56)
#define DPDIC_PIN_GPIO57      (57)
#define DPDIC_PIN_GPIO58      (58)
#define DPDIC_PIN_GPIO59      (59)
#define DPDIC_PIN_GPIO60      (60)

/****************END of GPIO规划定义*****************/


/**************************************************************************
 *                         数据类型
 **************************************************************************/

/**************************************************************************
*                         函数声明
**************************************************************************/


#ifdef __cplusplus
}
#endif

#endif /* _IC42_MINIMGR_BOARD_H */

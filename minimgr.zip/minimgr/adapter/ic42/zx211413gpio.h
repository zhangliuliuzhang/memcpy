/*****************************************************************************
* 版权所有(C) 2017, ZTE Corp. ZXSDR-RRU Platform BSP
*----------------------------------------------------------------------------
* 模  块  名 : zx211413gpio
* 文件名称 : zx211413gpio.h
* 文件标识 : {[N/A]}
* 内容摘要 : 本文件提供了ic4.2 gpio模块头文件
* 注意事项 : 无
* 作       者 : 10279092
* 创建日期 : 2022-03-18
* 当前版本 : Ver1.0
*---------------------------------------------------------------------------*/
#ifndef ZX211413GPIO_H_
#define ZX211413GPIO_H_

#ifdef __cplusplus
extern "C" {
#endif


/**************************************************************************
 *                        宏
 **************************************************************************/
#define GPIO_GROUP_MAX                 (1)
#define GPIO_MMAP_INITED               (UINT32)(1)
#define ONE_REG_MAX_GPIO               (UINT32)(16)

#define GPIO_MODE_OUTPUT               (0x00)            // 输出模式
#define GPIO_MODE_INPUT                (0x01)            // 输入模式
#define GPIO_MODE_INT                  (0x02)            // 中断模式

#define ZX211413_GPIO_REGS_SIZE        (0x1000)
#define ZX211413_GPIO_PORT_SIZE        (0x40)
#define ZX211413_GPIO_PORT_MAX         (128)

#define GPIO_CMODE_LEVEL_HIGH       0x00         /*高电平采集  */
#define GPIO_CMODE_LEVEL_LOW        0x10         /*低电平采集  */
#define GPIO_CMODE_EDGE_UP          0x20         /*上升沿平采集*/
#define GPIO_CMODE_EDGE_DOWN        0x40         /*下降沿采集  */
#define GPIO_CMODE_EDGE             0x80         /*全边缘采集  */

#define GPIO_SET_BIT_VAL(var, cfgVal, bit)    BITS_FIELD_CFG((var), (cfgVal), bit, 1)/* 修改1bit位的值 */
#define GPIO_GET_BIT_VAL(var, bit)            BITS_RIGHT_JUST_GET((var), bit, 1)/* TX传输FIFO中的有效数据量 */

#define INPUT_PORT_CHECK(port)                                  \
    if(port >= ZX211413_GPIO_PORT_MAX)                          \
    {                                                           \
        dbgInfo("ERROR: [ic4.2] The pin range is 0 ~ 127 !\n"); \
        return BSP_ERROR;                                       \
    }
/**************************************************************************
 *                         数据类型
 **************************************************************************/
typedef struct struct_hw_gpio_map_addr
{
    UINT32 phyAddr;
    void* virAddr;
    UINT32 init;
}T_HW_GPIO_MAP_ADDR;

enum eGpioRegisters {
    GPIO_DIRECTION          = 0x00,          /*输入输出     0 : input  1 : output   */
    GPIO_COLLECT_MODE       = 0x04,          /*数据采集模式 0 为边缘采集    1为电平采集        */
    GPIO_COLLECT_VOLT       = 0x08,          /*电平采集模式 0 为低电平采集  1 为高电平采集*/
    GPIO_COLLECT_POSEDGE    = 0x0C,          /*上升沿采集模式使能 0 为失能  1为使能              */
    GPIO_COLLECT_NEGEDGE    = 0x10,          /*下降沿采集模式使能 0 为失能  1为使能              */
    GPIO_INPUT_DATA         = 0x14,          /*R 输入数据, 存储 GPIO 端口输入数据            */
    GPIO_OUTPUT_SET1        = 0x18,          /*发送数据1                         */
    GPIO_OUTPUT_SET0        = 0x1C,          /*发送数据0                         */
    GPIO_OUTPUT_DATA        = 0x20,          /*R 发送数据的值                                                    */
    GPIO_INPUT_CLEAR        = 0x24,          /*输入数据清零 1 清零          0 禁止清零             */
    GPIO_INT_MASK           = 0x28,          /*中断屏蔽     1 禁止中断输出  0 允许中断输出  */
    GPIO_INT_ENABLE         = 0x2C,          /*R 中断状态                                                            */
    GPIO_INT_STATUS         = 0x30,          /*中断清零     1 清零          0 不清零                     */
    GPIO_INT_CLEAR          = 0x34,          /*使整个结构体占据 0x40 的空间                         */

    GPIO_OUTPUT_SET1_48V    = 0x58,          /*发送数据1                         */
    GPIO_OUTPUT_SET0_48V    = 0x5C,          /*发送数据0                         */
    GPIO_OUTPUT_DATA_48V    = 0x60,          /*R 发送数据的值                                         */
};

/**************************************************************************
*                         函数声明
**************************************************************************/
UINT32 zx211413GpioInit(VOID);
UINT32 _BspZteGpioGet(UINT32 port); /* 获取输入管脚状态  */
UINT32 _BspZteGpioSetMode(UINT32 port, UINT32 mode);
UINT32 _BspZteGpioSet(UINT32 port, UINT32 isHigh);
UINT32 _BspZteGpioInputClr(UINT32 port, UINT32 isHigh);
UINT32 zx211413SetD48vVoltLevel(UINT32 data);
UINT32 BspDpdicGpioSetMode( UINT32 ulBit, UINT32 bIsInput);
UINT32 BspDpdicGpioGet( UINT32 port);
#ifdef __cplusplus
}
#endif

#endif

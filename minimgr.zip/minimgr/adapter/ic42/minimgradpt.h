#ifndef _IC42_MINIMGR_ADPT_H_
#define _IC42_MINIMGR_ADPT_H_

#ifdef __cplusplus
extern "C" {
#endif

#include "pub_basetypedef.h"
#include "board.h"

#define  HIMEM_PHY_BASEADDR     (SYS_MEM_TOP)
#define  HIMEM_VIR_BASEADDR     (0)

UINT32 BspInitBoardAdpt(void);
UINT32 BspAdaptMemUnmap(void);

#endif // end _IC42_MINIMGR_ADPT_H_

/*****************************************************************************
 * 版权所有(C) 2015, ZTE Corp. ZXSDR-RRU Platform BSP
 *----------------------------------------------------------------------------
 * 模 块 名 : BSP
 * 文件名称 : board.h
 * 文件标识 : {[N/A]}
 * 内容摘要 : 本文件主要提供单板flash及cpu相关定义
 * 注意事项 : 无
 * 作    者 : 10090699
 * 创建日期 : 2017-2-27 16:03:00
 * 当前版本 : Ver1.0
 *----------------------------------------------------------------------------
 * 变更记录 :
 *
 * $记录1
 * 变 更 单:
 * 责 任 人:
 * 修改日戳:
 * 变更说明:
 *----------------------------------------------------------------------------
 */
#ifndef _BOARD_H_H_
#define _BOARD_H_H_

#ifdef __cplusplus
extern "C" {
#endif

// #include "bsppub.h"

/*----------------------------------------------------------------------------*/
/*                             宏定义                                         */
/*----------------------------------------------------------------------------*/
#define SIZE_1K                  ((UINT32)1024)
#define SIZE_4K                  (SIZE_1K * (UINT32)4)
#define SIZE_8K                  (SIZE_1K * (UINT32)8)
#define SIZE_32K                 (SIZE_1K * (UINT32)32)
#define SIZE_64K                 (SIZE_1K * (UINT32)64)
#define SIZE_128K                (SIZE_1K * (UINT32)128)
#define SIZE_256K                (SIZE_1K * (UINT32)256)
#define SIZE_320K                (SIZE_1K * (UINT32)320)
#define SIZE_384K                (SIZE_1K * (UINT32)384)
#define SIZE_512K                (SIZE_1K * (UINT32)512)
#define SIZE_832K                (SIZE_1K * (UINT32)832)
#define SIZE_1M                  (SIZE_1K * (UINT32)1024)
#define SIZE_2M                  (SIZE_1M * (UINT32)2)
#define SIZE_3M                  (SIZE_1M * (UINT32)3)
#define SIZE_4M                  (SIZE_1M * (UINT32)4)
#define SIZE_6M                  (SIZE_1M * (UINT32)6)
#define SIZE_8M                  (SIZE_1M * (UINT32)8)
#define SIZE_9M                  (SIZE_1M * (UINT32)9)
#define SIZE_10M                 (SIZE_1M * (UINT32)10)
#define SIZE_12M                 (SIZE_1M * (UINT32)12)
#define SIZE_14M                 (SIZE_1M * (UINT32)14)
#define SIZE_17M                 (SIZE_1M * (UINT32)17)
#define SIZE_27M                 (SIZE_1M * (UINT32)27)
#define SIZE_31M                 (SIZE_1M * (UINT32)31)
#define SIZE_35M                 (SIZE_1M * (UINT32)35)
#define SIZE_36M                 (SIZE_1M * (UINT32)36)
#define SIZE_64M                 (SIZE_1M * (UINT32)64)
#define SIZE_128M                (SIZE_1M * (UINT32)128)
#define SIZE_256M                (SIZE_1M * (UINT32)256)
#define SIZE_384M                (SIZE_1M * (UINT32)384)
#define SIZE_512M                (SIZE_1M * (UINT32)512)
#define SIZE_1G                  (SIZE_1M * (UINT32)1024)
#define SIZE_2G                  (SIZE_1M * (UINT32)2048)

/* DDR映射相关 */
#define DRAM_128M                            SIZE_128M
#define DRAM_256M                            SIZE_256M
#define DRAM_384M                            SIZE_384M

#define LOCAL_MEM_LOCAL_ADRS                 (0x00000000) /* 低端内存留给系统分配用 */
#define MCS_RESV_HIGH_MEM_ADDR               (SIZE_2G - SIZE_1M)

#define LOCAL_MEM_SIZE                       (SIZE_1G)
#define SHARE_REG_MEM_SIZE                   (SIZE_512K) /* 1M共享区MCS0&1平均分两块 */
// #define DDR_RESV_HIGH_MEM_SIZE            (SIZE_1M)

#define SYS_PHYS_MEM_TOP                     (LOCAL_MEM_LOCAL_ADRS  + LOCAL_MEM_SIZE)
#define PS_SHARE_REG_MEM_TOP                 (MCS_RESV_HIGH_MEM_ADDR - SHARE_REG_MEM_SIZE * 2)

#define MCS_SHARED_DDR_MAP_PHY_BASE_ADDR0    (0x80000000 + PS_SHARE_REG_MEM_TOP)
#define MCS_SHARED_DDR_MAP_PHY_BASE_ADDR1    (0x80000000 + PS_SHARE_REG_MEM_TOP + SHARE_REG_MEM_SIZE)
#define MCS_SHARED_DDR_MAP_PHY_BASE_ADDR2    (0x80000000 + PS_SHARE_REG_MEM_TOP - SIZE_1M)
#define MCS_SHARED_DDR_MAP_VIR_BASE_ADDR0    (0x90000000 + PS_SHARE_REG_MEM_TOP)
#define MCS_SHARED_DDR_MAP_VIR_BASE_ADDR1    (0x90000000 + PS_SHARE_REG_MEM_TOP + SHARE_REG_MEM_SIZE)
#define MCS_SHARED_DDR_MAP_VIR_BASE_ADDR2    (0x90000000 + PS_SHARE_REG_MEM_TOP - SIZE_1M)

/*********************高端内存规划*************************
   +------------------------------------------+
   |    中试和BSP (512K)                      |
   |    BSP_HIGH_RESERVED_MEM_BSP             |
   +------------------------------------------+
   |    OSS黑匣子 (512K)                      |
   |    BSP_HIGH_RESERVED_MEM_MGR             |
   +------------------------------------------+
   |    应用保留区(1M)                        |
   |    BSP_HIGH_RESERVED_MEM_L3    128K      |
   |    BSP_HIGH_RESERVED_MEM_APP3  320K      |
   |    BSP_HIGH_RESERVED_MEM_APP2  512K      |
   |    BSP_HIGH_RESERVED_MEM_APP1  64K       |
   +------------------------------------------+
   |    版本保护区 (4M)                       |
   |    BSP_HIGH_RESERVED_MEM_USER_DEFINE     |
   +------------------------------------------+
 **********************************************************/
#define BSP_MEM_SIZE             SIZE_512K
#define OSS_MEM_SIZE             SIZE_512K
/* 产品应用APP保留区域由低到高: APP1、APP2、APP3、L3, 共用
   1MBytes的空间, 其中L3为128K, 其它APP1~3由产品规格自己定
   义, NXP暂不区分APP1~3、L3, L3定义为0, 此区域统一处理 */
#define APP_MEM_L3_SIZE          0 // SIZE_128K
#define APP_RESERVED_SIZE        (SIZE_1M - APP_MEM_L3_SIZE)
#define BSP_VER_PROTECT_SIZE     (SIZE_4M)
#define USER_RESERVED_SIZE       (BSP_MEM_SIZE + OSS_MEM_SIZE + APP_MEM_L3_SIZE + APP_RESERVED_SIZE + BSP_VER_PROTECT_SIZE)

#define SYS_MEM_TOP              (SYS_PHYS_MEM_TOP - USER_RESERVED_SIZE)
#define USER_RESERVED_ADDR       (SYS_MEM_TOP)
#define BSP_VER_PROTECT_ADDR     (SYS_MEM_TOP)
#define APP_RESERVED_ADDR        (BSP_VER_PROTECT_ADDR + BSP_VER_PROTECT_SIZE)
#define APP_MEM_L3_ADDR          (APP_RESERVED_ADDR + APP_RESERVED_SIZE)
#define OSS_MEM_ADDR             (APP_MEM_L3_ADDR + APP_MEM_L3_SIZE)
#define BSP_MEM_ADDR             (OSS_MEM_ADDR + OSS_MEM_SIZE)

/***************************************************************************************
                             flash区域规划定义128M+256M
 ***************************************************************************************
    FLASH空间规划                   用途                 容量         说明
 ======================================= MTD0 ==========================================
 0M            ~  256K           BL2主区即升级区         256k     CERT PKG+BL2 PKG+ZTEHEADER
 256K          ~  512K           BL2 GOLDEN区            256M     CERT PKG+BL2 PKG+ZTEHEADER
 512K          ~  1M             保留区                  512K     保留区 
 1M            ~  2M             BOOT PART1主区          1M  　   ZTE[FIP[BL31安全格式+BL33安全格式]]+PAD
 2M            ~  14M            BOOT PART2主区          12M      KEBOOT安全格式+PAD+ZTEHEADER
 14M           ~  15M            BOOT PART1备区          1M  　   ZTE[FIP[BL31安全格式+BL33安全格式]]+PAD
 15M           ~  27M            BOOT PART2备区          12M      KEBOOT安全格式+PAD+ZTEHEADER
 27M           ~  27M+64K        双BOOT控制字            64K      新双BOOT方案  
 27M+64K       ~  27M+128K       环境变量                64K      沿用UBOOT环境变量区域用于各种引导参数配置
 ======================================= MTD1 ==========================================
 27M+128K      ~  27M+128K+0x10  Bomid区                 0x10 　  存放BomID区域
 27M+128K+0x10 ~  27M+128K+0x90  Mac地址区               0x80 　  全球唯一MAC地址信息
 27M+128K+0x90 ~  27M+128K+0xA0  硬件扩展信息区          0x10 　  继承NR3X原规划, 预留给MCS4芯片区分信息等
 27M+128K+0xA0 ~  27M+128K+0xB0  业务ID区                0x10     业务ID区：防盗ID
 27M+128K+0xB0 ~  27M+128K+0x4B0 版本即插即用标志区        0x400    版本即插即用标志区
 27M+128K+0x4B0 ~ 27M+128K+0x4C0 业务ID区_B              0x10     业务ID区_B
 27M+128K+0x4C0 ~ 27M+192K       保留区                  64K-0xA0   保留区
 27M+192K      ~  27M+196K       各机型定制区             4K       保留区
 27M+196K      ~  27M+200K       各平台定制区             4K       0~1k:V4平台用作从片D4调压标志；1k~4k保留
 27M+200K      ~  27M+256K       保留区                  56K      保留区 
 27M+256K      ~  31M+768K       特性表、FT/高温老化表区 4.5M     校准表和资产信息表(低4.25M)/FT和高温老化写表区(高端256K)  
 31M+768K      ~  31M+832K       保留区                  64K      保留区 
 31M+832K      ~  128M-1M        版本保护区              95M+192K 适用于NOR+Nand的场景, 实际NOR大小= 128M
 ======================================= MTD2 ==========================================
 128M-1M      ~  128M-1M+64K    根秘钥材料主区          64K      顶头, 根秘钥生成材料, 实际仅按4K Sector独占
 128M-1M+64K  ~  128M-1M+128K   设备商证书&私钥包主区   64K      主用区
 128M-1M+128K ~  128M-1M+192K   根秘钥材料备区          64K      备用区
 128M-1M+192K ~  128M-1M+256K   设备商证书&私钥包备区   64K      备用区
 128M-1M+256K ~  128M           保留区                  768K     保留区  
 ======================================= MTD3 ==========================================
 128M         ~  128M+512M      文件系统区              512M     NOR+Nand, UBIFS文件系统空间开销约10% 
 ***************************************************************************************/
#define NOR_FLASH_SIZE                 ((UINT32)(SIZE_128M))
#define NAND_FLASH_SIZE                ((UINT32)(SIZE_512M))
#define FLASH_SECTOR_SIZE              ((UINT32)(SIZE_64K)) /*SPI Flash 的擦除块大小不同--与硬件强相关*/
#define FLASH_PARTITION_NUM            (3)

/* ====== BOOT区定义, BL2等其它空间需要新增 ====== */
//#define BOOT_STRAP_OFFSET              ((UINT32)(SIZE_1M))  // BOOT_PART1(STRAP)主区即升级区绝对地址
//#define BOOT_STRAP_SIZE                ((UINT32)(SIZE_1M))
//#define KEBOOT_VERSION_START           ((UINT32)(SIZE_2M))  // BOOT_PART2(KEBOOT)主区即升级区绝对地址
//#define KEBOOT_VERSION_SIZE            ((UINT32)(SIZE_12M))

#define BOOT_BL2_MASTER_ADDR           ((UINT32)(0))  
#define BOOT_BL2_SLAVE_ADDR            ((UINT32)(SIZE_256K)) 
#define BOOT_BL2_SIZE                  ((UINT32)(SIZE_256K)) 
#define BOOT_FIP_MASTER_ADDR           ((UINT32)(SIZE_1M)) 
#define BOOT_FIP_SLAVE_ADDR            ((UINT32)(SIZE_14M)) 
#define BOOT_FIP_SIZE                  ((UINT32)(SIZE_1M)) 
#define KEBOOT_MASTER_ADDR             ((UINT32)(SIZE_2M)) 
#define KEBOOT_SLAVE_ADDR              ((UINT32)(SIZE_14M + SIZE_1M)) 
#define KEBOOT_MAX_SIZE                ((UINT32)(SIZE_12M))
/* ================================================ */

/* FLASH BOOT PART mtd0 定义: 绝对地址是第0, 大小是27M+128K */
#define FLASH_BOOT_PART_OFFSET         ((UINT32)0)
#define FLASH_BOOT_PART_SIZE           ((UINT32)(SIZE_27M + SIZE_128K)) // FLASH_BOOT_SIZE

/* FLASH BSP PART mtd1 定义: 绝对地址是第27M+128K, 大小是128M - 1M - (27M+128K) */
#define FLASH_BSP_PART_OFFSET          ((UINT32)(FLASH_BOOT_PART_OFFSET + FLASH_BOOT_PART_SIZE))
#define FLASH_BSP_PART_SIZE            ((UINT32)(NOR_FLASH_SIZE - SIZE_1M - FLASH_BSP_PART_OFFSET))

/* FLASH SECRET KEY mtd2 定义: 绝对地址是第128M - 1M, 大小是1M */
#define FLASH_SECRET_KEY_OFFSET        ((UINT32)(NOR_FLASH_SIZE - SIZE_1M))
#define FLASH_SECRET_KEY_SIZE          ((UINT32)(SIZE_1M))

/* FLASH JFFS2 mtd3 定义: 绝对地址是第128M, 大小是512M, 即跳过了NOR FLASH, 进入到NAND FLASH */
#define FLASH_JFFS2_OFFSET             ((UINT32)(NOR_FLASH_SIZE))
#define FLASH_JFFS2_SIZE               ((UINT32)(NAND_FLASH_SIZE))

// BOMID: 绝对地址27M+128K, 大小是0x10
#define FLASH_BOMID_OFFSET             ((UINT32)(SIZE_27M + SIZE_128K)) // FLASH_BSP_PART_OFFSET
#define FLASH_BOMID_SIZE               ((UINT32)0x10)

#define FLASH_MODULE_GROUP_ID_L        (FLASH_BOMID_OFFSET + (UINT32)0)  // BOMID绝对地址 + 0 个字节
#define FLASH_BOARD_GROUP_ID_L         (FLASH_BOMID_OFFSET + (UINT32)1)  // BOMID绝对地址 + 1 个字节
#define FLASH_BOARD_TYPE_ID_L          (FLASH_BOMID_OFFSET + (UINT32)2)  // BOMID绝对地址 + 2 个字节
#define FLASH_BOARD_HARD_CHANGE_ID_L   (FLASH_BOMID_OFFSET + (UINT32)3)  // BOMID绝对地址 + 3 个字节
#define FLASH_HARDWARE_CUSTOM_A_L      (FLASH_BOMID_OFFSET + (UINT32)4)  // BOMID绝对地址 + 4 个字节
#define FLASH_HARDWARE_CUSTOM_B_L      (FLASH_BOMID_OFFSET + (UINT32)5)  // BOMID绝对地址 + 5 个字节
#define FLASH_MODULE_GROUP_ID_H        (FLASH_BOMID_OFFSET + (UINT32)6)  // BOMID绝对地址 + 6 个字节
#define FLASH_BOARD_GROUP_ID_H         (FLASH_BOMID_OFFSET + (UINT32)7)  // BOMID绝对地址 + 7 个字节
#define FLASH_BOARD_TYPE_ID_H          (FLASH_BOMID_OFFSET + (UINT32)8)  // BOMID绝对地址 + 8 个字节
#define FLASH_BOARD_HARD_CHANGE_ID_H   (FLASH_BOMID_OFFSET + (UINT32)9)  // BOMID绝对地址 + 9 个字节
#define FLASH_HARDWARE_CUSTOM_A_H      (FLASH_BOMID_OFFSET + (UINT32)10) // BOMID绝对地址 + 10个字节
#define FLASH_HARDWARE_CUSTOM_B_H      (FLASH_BOMID_OFFSET + (UINT32)11) // BOMID绝对地址 + 11个字节
#define FLASH_BOMID_CRC_OFFSET_H       (FLASH_BOMID_OFFSET + (UINT32)12) // BOMID绝对地址 + 12个字节
#define FLASH_BOMID_CRC_OFFSET_L       (FLASH_BOMID_OFFSET + (UINT32)13) // BOMID绝对地址 + 13个字节
#define FLASH_BOMID_MAGIC_NUM_A_L      (FLASH_BOMID_OFFSET + (UINT32)14) // BOMID绝对地址 + 14个字节
#define FLASH_BOMID_MAGIC_NUM_B_H      (FLASH_BOMID_OFFSET + (UINT32)15) // BOMID绝对地址 + 15个字节

#define FLASH_ANTI_TAMPER_OFFSET       (FLASH_BOMID_OFFSET + (UINT32)0xa0) // BOMID绝对地址 + 0xa0个字节

// MACID: 绝对地址27M+128K+0x10, 大小是0x80
#define FLASH_MACID_OFFSET             ((UINT32)(FLASH_BOMID_OFFSET + FLASH_BOMID_SIZE))
#define FLASH_MACID_SIZE               ((UINT32)0x80)

// HW ExtInfo: 绝对地址27M+128K+0x90, 大小是64K - 0xA0
#define FLASH_HW_EXT_INFO_OFFSET       ((UINT32)(FLASH_MACID_OFFSET + FLASH_MACID_SIZE))
#define FLASH_HW_EXT_INFO_SIZE         ((UINT32)0x10)

/* 业务ID区: 绝对地址 27M+128K+0xA0, 大小是0x10 */
#define FLASH_BUSINESSID_OFFSET        (FLASH_HW_EXT_INFO_OFFSET + FLASH_HW_EXT_INFO_SIZE)
#define FLASH_BUSINESSID_SIZE          (0x10)

/* 版本即插即用标志区: 绝对地址 27M+128K+0xB0, 大小是0x400 */
#define FLASH_PLUG_AND_PLAY_OFFSET     (FLASH_BUSINESSID_OFFSET + FLASH_BUSINESSID_SIZE)
#define FLASH_PLUG_AND_PLAY_SIZE       (0x400)

/* 业务ID区_B: 绝对地址 27M+128K+0x4B0, 大小是0x10 */
#define FLASH_BUSINESSID_B_OFFSET     (FLASH_PLUG_AND_PLAY_OFFSET + FLASH_PLUG_AND_PLAY_SIZE)
#define FLASH_BUSINESSID_B_SIZE       (0x10)

/* FLASH mtd2 RESERVED0: 绝对地址27M+128K+0x4C0, 大小是64K - 0x4C0 */
#define FLASH_MTD2_RESERVED0_OFFSET    ((UINT32)(FLASH_BUSINESSID_B_OFFSET + FLASH_BUSINESSID_B_SIZE))
#define FLASH_MTD2_RESERVED0_SIZE      ((UINT32)(SIZE_64K - (UINT32)0x4C0))

/* 支持DPDIC调压标志区: 绝对地址 27M+196K, 大小是4K */
#define FLASH_DPDIC4_DYN_VOLT_OFFSET     (FLASH_MTD2_RESERVED0_OFFSET + FLASH_MTD2_RESERVED0_SIZE + SIZE_4K)
#define FLASH_DPDIC4_DYN_VOLT_SIZE       (SIZE_4K)

/* FLASH mtd2 RESERVED1: 绝对地址27M+200K, 大小是56K */
#define FLASH_MTD2_RESERVED1_OFFSET    ((UINT32)(FLASH_DPDIC4_DYN_VOLT_OFFSET + FLASH_DPDIC4_DYN_VOLT_SIZE))
#define FLASH_MTD2_RESERVED1_SIZE      ((UINT32)(SIZE_1K * (UINT32)56))

// 校准表资产信息表: 绝对地址27M+256K, 大小是4.25M
// #define FLASH_RFTBL_OFFSET          ((UINT32)(FLASH_MTD2_RESERVED1_OFFSET + FLASH_MTD2_RESERVED1_SIZE))
#define FLASH_RFTBL_OFFSET             ((UINT32)(SIZE_27M + SIZE_256K))
#define FLASH_RFTBL_SIZE               ((UINT32)(SIZE_4M  + SIZE_256K))

// FT/WFS规划区从低端开始使用: 绝对地址31M+512K, 大小是256K
#define FLASH_FT_WFS_OFFSET            ((UINT32)(FLASH_RFTBL_OFFSET + FLASH_RFTBL_SIZE))
#define FLASH_FT_WFS_SIZE              ((UINT32)(SIZE_256K))

// 保护区: 绝对地址31M+832K, 大小95M+192K, NorFlash容量128M
#define PROTECT_ZONE_ADDRESS           ((UINT32)(SIZE_31M + SIZE_832K))
#define PROTECT_ZONE_SIZE              ((UINT32)(NOR_FLASH_SIZE - PROTECT_ZONE_ADDRESS))

// 小版本压力测试ST: 绝对地址27M+200K, 大小32K; 
// ###### 特别提醒: MTD2_RESERVED1为保留区, 如果此区有其它用途, 需要修改此测试的基地址 !!!!!!
#define ST_BLOCK_SIZE_TEST             ((UINT32)(SIZE_32K)) /* 块数据最大32k */
#define ST_BLOCK_ADDR_FLASH            ((UINT32)(FLASH_MTD2_RESERVED1_OFFSET))
#define ST_BLOCK_ADDR_DDR              (BspGetReservedMemAddr(BSP_HIGH_RESERVED_MEM_BSP) + (UINT32)0x50000)

/****************END of flash区域规划定义*****************/

#ifdef __cplusplus
}
#endif

#endif /* _BOARD_H_H_ */


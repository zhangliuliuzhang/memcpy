#ifdef MINIMGR_SUPPORT

#include "minimgr.h"
#include "zxw11200spi.h"
#include "minimgradpt.h"
#include "flash.h"


#define SPI_BUS_ID_EPLD0     106

/*外部EPLD看门狗*/
#define EPLD_EXT_WDT_EN       0x18
#define EPLD_EXT_WDT_TIME   0x17
#define EPLD_EXT_WDT_FEED   0x15

/******************************4C内部看门狗*******************************/

#define WDT_REGS_SIZE               (0x1000)
#define SCU_REGS_SIZE               (0x1000)
#define ReadL(addr)           ({UINT32 __v = (*(volatile UINT32 *) (addr)); __v;})
#define WriteL(addr, data)    (VOID)((*(volatile UINT32 *)(addr)) = (data))

#define _WDT_CHECK(preg)            \
    if (NULL == preg)       \
    {                           \
        dbgErr("%s NULL pointer!\n", __FUNCTION__);\
        return BSP_ERROR;       \
    }


typedef struct tagT_wdt
{
    UINT32 WDT_CR;               /* 0x0000 */
    UINT32 WDT_TORR;             /* 0x0004 */
    UINT32 WDT_CCVR;             /* 0x0008 */
    UINT32 WDT_CRR;              /* 0x000C */
    UINT32 WDT_STAT;             /* 0x0010 */
    UINT32 WDT_EOI;              /* 0x0014 */
    UINT32 RES1;
    UINT32 WDT_PROT_LEVEL;       /* 0x001C */
    UINT32 RES2[49];
    UINT32 WDT_COMP_PARAM_5;     /* 0x00E4 */
    UINT32 WDT_COMP_PARAM_4;     /* 0x00E8 */
    UINT32 WDT_COMP_PARAM_3;     /* 0x00EC */
    UINT32 WDT_COMP_PARAM_2;     /* 0x00F0 */
    UINT32 WDT_COMP_PARAM_1;     /* 0x00F4 */
    UINT32 WDT_COMP_VERSION;     /* 0x00F8 */
    UINT32 WDT_COMP_TYPE;        /* 0x00FC */
} T_WDT_REG;

typedef struct tagT_wdt_slave
{
    UINT32    ulPhyAddr;
    UINT32    ulVirAddr;
    T_WDT_REG *ptWdtRegs;
} T_4C_WDT_SLAVE;


static T_4C_WDT_SLAVE _4c_Wdt =
{
    0x000011E000, 0x98150000, NULL
};


static T_C4_SPI_PARA s_Zxw11200SpiPriv[] =
{
    [SPI_BUS_ID_EPLD0] = /* EPLD */
    {
        .ulBusId    = CPU_SPI_BUS_2,
        .ulSpiCs    = 0,
        .ulFreqHz   = C4_SPI_MAX_FREQ_HZ / 40, /* 暂时按照8M的速率配置, 后期根据需要调整 */
        .ulSpiMode  = SPI_MODE_0,
        .ulFrameLen = 8, /* Bit总数 */
    },
};

static T_SPI_DRV s_atHwSpiBusDrv = {
        .ulSpiDrvId   = SPI_BUS_ID_EPLD0,
        .ulDrvType    = SPI_DRV_TYPE_ZXW11200,
        .pPrivateData = &(s_Zxw11200SpiPriv[SPI_BUS_ID_EPLD0]),
        .ptPrev       = NULL,
        .ptNext       = NULL,
};

static T_SPI_OWNER_INFO s_atHwDevDrvInfo = {
       .ulSpiDrvId = SPI_BUS_ID_EPLD0,
       .ulSpiMode = 0,  /*待确认*/
       .ulSpiOwner = 0,
};


UINT32 g_ulEpldVirtualBaseAddr = 0x90000000+SYS_MEM_TOP;
UINT32 g_ulEpldPhyBaseAddr = 0x80000000+SYS_MEM_TOP;
UINT32 g_ulEpldMapMemSize = USER_RESERVED_SIZE;
UINT32 g_ulEpldMapVirtualBaseAddr = 0;
static UINT32 s_watchDogStatFalg = 0; /* 记录看门狗是否使能:1使能，0去使能 */


INT32 BspSpiEpldInit(VOID)
{
    UINT32 ulTmpRet = 0;
    T_SPI_DRV *ptSpiBusDrv = &s_atHwSpiBusDrv;

    ulTmpRet = BspZxw11200SpiInit(ptSpiBusDrv);
    if (0 != ulTmpRet)
    {
        dbgErr("%s: line%d. SpiBusDrv init Error!ErrRet= 0x%x\n",
        __FUNCTION__, __LINE__,  ulTmpRet);
    }

    return ulTmpRet;
}

UINT32 BspWrEpldReg(UINT32 addr, UINT32 data)
{
    UINT32 len = 0;
    UINT32 tmplen = 0;
    UINT32 retVal = BSP_OK;
    UINT8  send[6] = {0};
    UINT16 RegData = (UINT16)data;
    T_SPI_DRV    *pSpi = &s_atHwSpiBusDrv;
    //T_C4_SPI_PARA *pHwSpiPara = NULL;


    /* 申请SPI控制器的控制权*/
    pSpi->pTakeSpiOwner(&s_atHwDevDrvInfo);
#if (0)
    pHwSpiPara = (T_C4_SPI_PARA *)pSpi->pPrivateData;
    if (pHwSpiPara == NULL)
    {
        dbgErr("%s>>Error!pHwSpiPara NULL;\n",__FUNCTION__);
        /* 释放SPI控制器的控制权，其它使用本SPI控制的设备可以使用 */
        pSpi->pGiveSpiOwner(&s_atHwDevDrvInfo);
        return BSP_ERROR_NULL_POINTER;
    }
#endif
    /* 发送写命令; EPLD SPI格式顺序说明：
       读写：1 bit, 1=读，0=写
       地址：22 bit，高位地址先打出, EPLD上升沿采样↑
       读写保护：9 bit, 用于数据读出&凑成整数字节
       数据：16 bit, 高位数据先写/读, 读：CPU上升沿采样↑,写：EPLD上升沿采样↑
       总计48个bit。SPI时钟暂定24M */
    send[0] = (addr >> 15) & 0x7F;
    send[1] = (addr >>  7) & 0xFF;
    send[2] = (addr <<  1) & 0xFE;
    send[3] = 0x00;
    send[4] = (RegData >> 8) & 0xFF;
    send[5] = (RegData >> 0) & 0xFF;
    len     = 6;

    tmplen = ((len&0xFF)<<16) | 0;
    // HwSpiXfer--> zxw1200SpiXfer
    retVal = (*pSpi->pSpiXfer)(pSpi, send, NULL,tmplen);

    if (BSP_OK != retVal)
    {
        dbgErr("%s>>SpiXfer Error! Ret= 0x%X\n",
               __FUNCTION__, retVal);
    }

    /* 释放SPI控制器的控制权，其它使用本SPI控制的设备可以使用 */
    pSpi->pGiveSpiOwner(&s_atHwDevDrvInfo);

    return retVal;
}

static UINT32 WdtRegWr(UINT32 ulAddr, UINT32 ulData)
{
    WriteL(ulAddr, ulData);
    return BSP_OK;
}

/*****************************************************************************
 * 函数名称: InnerWdtInit
 * 功能描述: 内部看门狗初始化,地址映射
 * 输入参数:
 * 输出参数: 无
 * 返 回 值: BSP_OK- 成功; 其他- 失败
 * 其它说明: 无
 * 修改日期        版本号     修改人          修改内容
 * -----------------------------------------------
 ** 2020/12  V1.0  10279092
 ***********************************************************************/
UINT32 InnerWdtInit(VOID)
{
    INT32  lFileRet  = 0;
    UINT32 ulVirAddr = 0;
    UINT32 ulPhyAddr = 0;
    UINT32 ulSpaceProt = 0;
    T_4C_WDT_SLAVE *ptWdtCfg = NULL;

    ulSpaceProt = PROT_READ | PROT_WRITE;
    ptWdtCfg = &_4c_Wdt;

    ulPhyAddr = ptWdtCfg->ulPhyAddr;
    ulVirAddr = ptWdtCfg->ulVirAddr;

    if ((lFileRet = open("/dev/mem", O_RDWR | O_SYNC)) < 0)
    {
        dbgErr("%s>>/dev/mem open Error!\n", __FUNCTION__);
        return BSP_ERROR;
    }

    ulVirAddr = (UINT32)mmap((VOID *)ulVirAddr, WDT_REGS_SIZE, ulSpaceProt, MAP_SHARED, lFileRet, ulPhyAddr);
    if (ulVirAddr != ptWdtCfg->ulVirAddr)
    {
        dbgErr("%s>>mmap Error! VirAddr= 0x%X\n", __FUNCTION__, ulVirAddr);
    }
    close(lFileRet); // 映射完后就可以关闭文件，映射的内存可以正常访问
    ptWdtCfg->ulVirAddr = ulVirAddr;
    ptWdtCfg->ptWdtRegs = (T_WDT_REG *)(ptWdtCfg->ulVirAddr);
    dbgInfo("%s>> Addr= P'0x%X V'0x%X\n",
            __FUNCTION__,  ptWdtCfg->ulPhyAddr, ptWdtCfg->ulVirAddr);

    return BSP_OK;
}

UINT32 DisableInnerWatchDog(VOID)
{
    T_4C_WDT_SLAVE *ptWdtCfg = NULL;
    ptWdtCfg = &_4c_Wdt;
    _WDT_CHECK(ptWdtCfg->ptWdtRegs);
    WdtRegWr((UINT32)(&ptWdtCfg->ptWdtRegs->WDT_CR),0);
    return BSP_OK;
}

UINT32 EnableInnerWatchDog(VOID)
{
    T_4C_WDT_SLAVE *ptWdtCfg = NULL;
    ptWdtCfg = &_4c_Wdt;
    _WDT_CHECK(ptWdtCfg->ptWdtRegs);
    WdtRegWr((UINT32)(&ptWdtCfg->ptWdtRegs->WDT_CR),0x3);
    return BSP_OK;
}

/*****************************************************************************
 * 函数名称: SetInnerWatchDogTime
 * 功能描述: 设置超时时间，共16个档位，对应0x0~0xf
 * 100ms 200ms 500ms 1s 2s 5s 10s 30s 60 120 240 300 360 420 480 600s
 * 输入参数:
 * 输出参数: 无
 * 返 回 值: BSP_OK- 成功; 其他- 失败
 * 其它说明: 无
 * 修改日期        版本号     修改人          修改内容
 * -----------------------------------------------
 ** 2020/12  V1.0  10279092
 ***********************************************************************/
UINT32 SetInnerWatchDogTime(UINT32 level)
{
    T_4C_WDT_SLAVE *ptWdtCfg = NULL;
    ptWdtCfg = &_4c_Wdt;
    _WDT_CHECK(ptWdtCfg->ptWdtRegs);
    WdtRegWr((UINT32)(&ptWdtCfg->ptWdtRegs->WDT_CRR),0x76);
    WdtRegWr((UINT32)(&ptWdtCfg->ptWdtRegs->WDT_TORR),level);
    WdtRegWr((UINT32)(&ptWdtCfg->ptWdtRegs->WDT_CRR),0x76);
    return BSP_OK;
}

UINT32 FeedInnerWatchDog(VOID)
{
    T_4C_WDT_SLAVE *ptWdtCfg = NULL;
    ptWdtCfg = &_4c_Wdt;
    _WDT_CHECK(ptWdtCfg->ptWdtRegs);
    WdtRegWr((UINT32)(&ptWdtCfg->ptWdtRegs->WDT_CRR),0x76);
    return BSP_OK;
}


static UINT32 DisableWatchDog(VOID)
{
#if 1
    UINT32 regVal = 0;
    UINT32 epldId = 0, epldBusType = 0;

    s_watchDogStatFalg = 0;

    BspWrEpldReg(EPLD_EXT_WDT_EN,0);

    return BSP_OK;
#else /*待确认*/
    UINT32 regVal = 0;
    regVal |= BspRegPinWr(REG_GPIO_EXT_WDT_EN, 1);
    s_watchDogStatFalg = 0;
    return BSP_OK;

#endif
}

static UINT32 EnableWatchDog(VOID)
{
#if 1
    UINT32 regVal = 0;
    UINT32 epldId = 0, epldBusType = 0;

    BspWrEpldReg(EPLD_EXT_WDT_EN,1);

    s_watchDogStatFalg = 1;

    return BSP_OK;
#else /*待确认*/
    UINT32 regVal = 0;
    regVal |= BspRegPinWr(REG_GPIO_EXT_WDT_EN, 0);
    s_watchDogStatFalg = 1;
    return BSP_OK;

#endif
}

/* ulTimerValue:单位2s */
static UINT32 SetWatchDogTime(UINT32 timerValue)
{
    UINT32 regVal = BSP_OK;
    UINT32 epldId =0;
    UINT32 epldBusType = 0;

    /*先喂一次狗*/
    BspWrEpldReg(EPLD_EXT_WDT_FEED,0x5A);
    BspWrEpldReg(EPLD_EXT_WDT_FEED,0);

    /*修改超时时间*/
    BspWrEpldReg(EPLD_EXT_WDT_TIME, timerValue);
    dbgInfo("%s>>WatchDogTime %d *2s\n",__FUNCTION__,timerValue);

    return BSP_OK;
}

UINT32 BspInitWatchDog(VOID)
{
    InnerWdtInit();
    //DisableInnerWatchDog();
    SetInnerWatchDogTime(9);/*2分钟*/
    //EnableInnerWatchDog();
    //HwScuRstInit(); //内部看门狗复位信息记录初始化

    //DisableWatchDog();    /* 默认Disable，因为BSP版本下没有喂狗，不打开，正式代码会马上打开 */
    SetWatchDogTime(240); /* 设置时间480s */
    //EnableWatchDog();

    return BSP_OK;
 }

UINT32 BspFlashInit(VOID)
{
    UINT32 retVal = BSP_OK;
    T_FlashInfo flashInfo =
    {
        NOR_FLASH_SIZE + NAND_FLASH_SIZE,
        FLASH_SECTOR_SIZE,
        FLASH_PARTITION_NUM,
        {
            {"/dev/mtd0", FLASH_BOOT_PART_OFFSET,  FLASH_BOOT_PART_SIZE},
            {"/dev/mtd1", FLASH_BSP_PART_OFFSET,   FLASH_BSP_PART_SIZE},
            {"/dev/mtd2", FLASH_SECRET_KEY_OFFSET, FLASH_SECRET_KEY_SIZE},
        //  {"/dev/mtd3", FLASH_JFFS2_OFFSET,      FLASH_JFFS2_SIZE},
        }
    };

    retVal = BspFlashModuleInit(&flashInfo);
#if BSP_MAKE_VER
    BspFlashShowCfg();
#endif
    return retVal;
}

UINT32 BspInitBoardAdpt(VOID)
{
    BspFlashInit();
    /*映射EPLD读写部分*/
    BspSpiEpldInit();
    /*看门狗初始化*/
    BspInitWatchDog();
    /*是否启用验签*/
    //BspSetSecVerifyFunStat(0);
    BspInitSecVerifyFun();
    BspSetMiniMasterSlaveFlag(MINIMGR_MASTER_FLAG);
    return BSP_OK;
}
UINT32 BspInnerWatchDogMemRelease(VOID)
{
    T_4C_WDT_SLAVE *ptWdtCfg = &_4c_Wdt;

    if(ptWdtCfg->ulVirAddr != 0)
    {
        munmap((void *)(ptWdtCfg->ulVirAddr),WDT_REGS_SIZE);
    }
    return BSP_OK;
}
UINT32 BspAdaptMemUnmap(VOID)
{
    T_SPI_DRV    *pSpi = &s_atHwSpiBusDrv;

    BspInnerWatchDogMemRelease();
    Zxw11200SpiMemRelease(pSpi);

    return BSP_OK;
}
#endif

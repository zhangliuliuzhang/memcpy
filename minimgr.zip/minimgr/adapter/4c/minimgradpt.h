#ifdef MINIMGR_SUPPORT

#ifndef    _MINIMGR_ADPT_H_
#define    _MINIMGR_ADPT_H_

#ifdef __cplusplus
extern "C" {
#endif

#include "board.h"


/*CPU bit type: 0:32bit,1:64bit*/
#define  CPU_BIT_TYPE_FLAG         1

#define  HIMEM_VIR_BASEADDR        (0x90000000+SYS_MEM_TOP)
#define  HIMEM_PHY_BASEADDR       (0x80000000+SYS_MEM_TOP)

#define REDEF_CA_FLASH_ADDR
/*安全启动相关*/
#define Z_PublicKey_Base_Addr            (MINIMGR_SIZE_128M - MINIMGR_SIZE_1M)
#define Z_PublicKey_Length                 (MINIMGR_SIZE_4K)

#define VendorCert_Base_Addr            (MINIMGR_SIZE_128M - MINIMGR_SIZE_1M+MINIMGR_SIZE_8K)
#define VendorCert_Main_Length         (MINIMGR_SIZE_4K*7)
#define VendorCert_Back_Length         (MINIMGR_SIZE_4K*7)
#define OperatorCert_Zone_Length      (SIZE_32K)
//#define VendorCert_Reserve_Length    (MINIMGR_SIZE_64K)

#define CA_Secure_ExHead_Base_Addr      (MINIMGR_SIZE_128M - MINIMGR_SIZE_1M+MINIMGR_SIZE_256K)
#define CA_Secure_ExHead_Main_Length   (MINIMGR_SIZE_64K)
#define CA_Secure_ExHead_Back_Length   (MINIMGR_SIZE_64K)

#define MAX_CERT_SIZE   (MINIMGR_SIZE_4K*7)


UINT32 BspAdaptMemUnmap(VOID);
UINT32 BspInitBoardAdpt(VOID);


#endif
#endif



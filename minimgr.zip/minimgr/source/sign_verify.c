#include "ru_basedef.h"
#include "pub_svmdef.h"
#include "zprintf.h"
#include <openssl/x509.h>
#include <openssl/pem.h>
#include <openssl/conf.h>
#include <openssl/evp.h>
#include "pkcs7_in.h"
#include "cJSON.h"
#include "flash.h"
#include "minimgr.h"
#include "crc.h"

#define TYPE_NUM 5
/* Started by AICoder, pid:174e88eb90c7c65146290adbf076310017e553e4 */
#ifndef UINT16_MAX
#define UINT16_MAX 65535
#endif
/* Ended by AICoder, pid:174e88eb90c7c65146290adbf076310017e553e4 */
#pragma pack(1)
struct stVendorCert
{
     BYTE    magic[8]; // _ZTEKEY_
     USHORT  le;  //FL+data
     USHORT  crc16;
     BYTE    update_flag;
     BYTE    res[3];
     struct  tFile
     {
        USHORT fl;
        USHORT crc16;
        USHORT off;
        USHORT res;
     }FL[TYPE_NUM];
     BYTE data;
};
#pragma pack()

#define VenDorCertHeadLen (sizeof(struct stVendorCert)-1)
#define VenDorCertHeadPreLen (16)
#define VenDorCertHeadFlLen  (VenDorCertHeadLen-16)

#define TPM_SAFE_DEV_FLASH_MAIN   0
#define TPM_SAFE_DEV_FLASH_BACK   1


#if 0
#define TLS_BASE_SIZE      (SIZE_17M + SIZE_64K)
#define Z_PublicKey_Off (TLS_BASE_SIZE + 2048)  /*length = 256+16 512+16 or 1024+16*/
#define VendorCert_Tls     (Z_PublicKey_Off + 2048)
#define TYPE_NUM_USE 3
#define MAX_CERT_SIZE   8*1024     
#define VendorCert_Flash   (0x10000000 - 0x1400000 - 0x40000)
#endif
/*涉及flash划分，从单板传入  start*/



#ifndef REDEF_CA_FLASH_ADDR
#define Z_PublicKey_Base_Addr            (MINIMGR_SIZE_128M - MINIMGR_SIZE_1M)   
#define Z_PublicKey_Length                 (MINIMGR_SIZE_4K)  

#define VendorCert_Base_Addr            (MINIMGR_SIZE_128M - MINIMGR_SIZE_1M+MINIMGR_SIZE_8K)
#define VendorCert_Main_Length         (MINIMGR_SIZE_4K*7) 
#define VendorCert_Back_Length         (MINIMGR_SIZE_4K*7) 
#define OperatorCert_Zone_Length      (MINIMGR_SIZE_32K) 
//#define VendorCert_Reserve_Length    (SIZE_64K) 

#define CA_Secure_ExHead_Base_Addr      (MINIMGR_SIZE_128M - MINIMGR_SIZE_1M+MINIMGR_SIZE_128K)
#define CA_Secure_ExHead_Main_Length   (MINIMGR_SIZE_4K*5) 
#define CA_Secure_ExHead_Back_Length   (MINIMGR_SIZE_4K*5) 

#define MAX_CERT_SIZE   (MINIMGR_SIZE_4K*7)  

#endif

#define Z_PublicKey_Off                          (Z_PublicKey_Base_Addr)
#define Z_PublicKey_Len                         (Z_PublicKey_Length)   

#define VendorCert_Main_Zone_Off       (VendorCert_Base_Addr)
#define VendorCert_Main_Zone_Len      (VendorCert_Main_Length)
#define VendorCert_Back_Zone_Off       (VendorCert_Main_Zone_Off+VendorCert_Main_Zone_Len)
#define VendorCert_Back_Zone_Len      (VendorCert_Back_Length)
#define OperatorCert_Zone_Off              (VendorCert_Back_Zone_Off+VendorCert_Back_Zone_Len)
#define OperatorCert_Zone_Len             (OperatorCert_Zone_Length)
//#define VendorCert_Reserve_Off            (OperatorCert_Zone_Off+OperatorCert_Zone_Len)
//#define VendorCert_Reserve_Len           (VendorCert_Reserve_Length)

#define CA_Secure_ExHead_Main_Off    (CA_Secure_ExHead_Base_Addr)
#define CA_Secure_ExHead_Main_Len   (CA_Secure_ExHead_Main_Length)
#define CA_Secure_ExHead_Back_Off    (CA_Secure_ExHead_Main_Off+CA_Secure_ExHead_Main_Len)
#define CA_Secure_ExHead_Back_Len   (CA_Secure_ExHead_Back_Length)

/*涉及flash划分，从单板传入  end*/


#define TYPE_NUM_USE 3


/*获取验签文件属性*/
static UINT32 GetVerFileInfo(char *file, UINT32 *pLen, UINT32 *pCrc)
{
    FILE *fp = NULL;
    struct stat  tStat = {0};
    INT32  iReadLen = 0;
    INT32  lSnpRet = 0;
    T_VerFileHeader tVerFileHeader = {0};

    if(file==NULL)
    {
         dbgErr("%s>>input para is null !\n",__FUNCTION__);
         return BSP_ERROR;
    }
    dbgInfo("%s>>VersionFile: %s\n",__FUNCTION__,file);

    fp = fopen(file, "rb");
    if(NULL == fp)
    {
        dbgErr("%s>>can't open %s !\n",__FUNCTION__,file);
        return BSP_ERROR;
    }
    
    if (stat(file, &tStat) == -1)
    {        
        lSnpRet = fclose(fp);
        FCLOSE_CHECK(lSnpRet);
        dbgErr("%s>>Get File %s Status Failed !\n",__FUNCTION__,file);
        return BSP_ERROR;
    }
    dbgInfo("%s>>file: %s,lenth is %ld;\n", __FUNCTION__, file, tStat.st_size);
    if(pLen!=NULL)
    {
        *pLen = tStat.st_size;  
    }
    
    iReadLen = fread(&tVerFileHeader, 1,  sizeof(T_VerFileHeader), fp);
    if (iReadLen != sizeof(T_VerFileHeader))
    {
        lSnpRet = fclose(fp);
        FCLOSE_CHECK(lSnpRet);
        dbgErr("%s>>fread version file %s error !\n",__FUNCTION__,file);
        return BSP_ERROR;
    }
    dbgInfo("%s>>file: %s,crc is %d\n",__FUNCTION__,file,ntohl(tVerFileHeader.ulCRC32));
    if(pCrc!=NULL)
    {
        *pCrc = ntohl(tVerFileHeader.ulCRC32);
    }
    lSnpRet = fclose(fp);
    FCLOSE_CHECK(lSnpRet);    
    //dbgInfo("%s>>file %s: len %d,crc %d\n",__FUNCTION__,file,*pLen,*pCrc);
    return BSP_OK;
}
/*签名处理pkcs1*/
VOID b64dcode_t(UCHAR *d64,UCHAR *d,INT32 mlen)
{
    CHAR bb[128]={0};
    INT32 i=0,j=0,L=0;
    UINT32 v = 0;
  
    if((d64==NULL)||(d==NULL))
    {
        dbgErr("%s>>input para is null !\n",__FUNCTION__);
        return;
    }
   //base64 decode init
   for(i=0;i<26;i++)
   {
      bb['A'+i] = i;
      bb['a'+i] = 26+i;   
   }
    for(i=0;i<10;i++)
    {
        bb['0'+i] = 52+i;
    }
   bb['+'] = 62;
   bb['/'] = 63;
  
   L = strlen((const char *)d64);

   for(i=0;i<L/4;i++)
   {  
        v = 0;
        for(j=0;j<4;j++)
        {
            v = ((v << 6)|(bb[d64[4*i+j]]));
        }
        if(mlen>(3*i))
        {
            d[3*i] = ((UCHAR *)&v)[2];
        }
        if(mlen>(3*i+1))
        {
            d[3*i+1] = ((UCHAR *)&v)[1];
        }
        if(mlen>(3*i+2))
        {
            d[3*i+2] = ((UCHAR *)&v)[0];
        }
   };
   return;
}
UINT32 BspReadCertInfo(WORD32 wDtSrcType, WORD32 wOffset, BYTE *pData, WORD32 wLen)
{
    UINT32 ulZoneOffset = 0; 

    if(wDtSrcType == 1)
    {
        ulZoneOffset = VendorCert_Main_Zone_Len;
    }
 
    if( BSP_OK != BspFlashRead(VendorCert_Main_Zone_Off +ulZoneOffset + wOffset,pData, wLen) )
    {
       dbgErr( "%s>>BspReadFlashInfo error !type[%d]\n",__FUNCTION__,wDtSrcType);
       return BSP_ERROR;
    }
    return BSP_OK;
}
//byType: 0-new check;  1-old check
//检测证书区域的头部合法性
//type ：0：crc只包含头部；  1： crc包括数据部分
//return: 0-ok;  1- head error;  2-crc error;  3- fl error
ULONG CheckCertHead(BYTE byType, BYTE *ptrData)
{
      struct stVendorCert *cert = NULL;
      USHORT usCrcSum = 0;
      WORD32 wLe = MAX_CERT_SIZE - VenDorCertHeadLen;
      WORD32 wCrcChkLen = 0;
      WORD32 wOffset = 0;
      WORD32 wFLen = 0;
      BYTE byi = 0;

      cert = (struct stVendorCert *)ptrData;
      if(memcmp(cert,"_ZTEKEY_",8) != 0
              || cert->le > (MAX_CERT_SIZE - VenDorCertHeadPreLen)
              || cert->le == 0)
      {
        dbgInfo("read cert file failed! type = %d\n",memcmp(cert, "_ZTEKEY_",8) != 0 );
        dbgInfo("read cert file failed! type = %d\n",cert->le > (MAX_CERT_SIZE-VenDorCertHeadPreLen));
        dbgInfo("read cert file failed! type = %d\n",cert->le == 0);
        dbgInfo("read cert file failed! type = %d\n",byType);
        return 1;
      }

      wCrcChkLen = (byType == 0) ? VenDorCertHeadFlLen : (cert->le);
      usCrcSum = CalculateCRC16(0xffff, (const unsigned char*)&cert->FL[0], wCrcChkLen);
      if(cert->crc16 != usCrcSum)
      {
          if( byType != 0)
          {
            dbgInfo("check cert crc(0x%x,0x%x) failed! type = %d\n", usCrcSum, cert->crc16, byType);
          }
          return 2;
      }
      wOffset = 0;
      wFLen = 0;
      for(byi = 0; byi < TYPE_NUM_USE; byi++)
      {
          if( cert->FL[byi].fl != 0 )
          {
             if( wOffset+wFLen != cert->FL[byi].off )
             {
                dbgInfo("header fl(%u) error;\n",byi);
                return 3;
             }
             if(cert->FL[byi].fl + cert->FL[byi].off > wLe)
             {
                dbgInfo("header fl(%u) off error;\n",byi);
                return 3;
             }
             wOffset = cert->FL[byi].off;
             wFLen =  cert->FL[byi].fl;
          }
      }
      return BSP_OK;
}
//检测证书的合法性,必须在头部检测ok后，才能调用
//wCerData： 证书的全部数据，包括头部
//type ：0~2
WORD32 CheckCertFL(BYTE type, BYTE *pCertData)
{
      struct stVendorCert *cert = NULL;
      USHORT usCrcSum = 0;
      WORD32 wRt = BSP_OK;
      UCHAR uci = 0;
      UCHAR startno = type;
      UCHAR stopno = type + 1;

      if( type != 0xff && type >= TYPE_NUM_USE )
      {
          dbgInfo("CheckCertFl: type(%u) error!", type);
          return BSP_ERROR;
      }

      if( type == 0xff)
      {
          startno = 0;
          stopno = TYPE_NUM_USE;
      }
      for( uci = startno; uci< stopno; uci++ )
      {
          cert = (struct stVendorCert *)pCertData;
          if( cert->FL[uci].fl )
          {
              usCrcSum = CalculateCRC16(0xffff,(&cert->data) + cert->FL[uci].off ,cert->FL[uci].fl);
              if(cert->FL[uci].crc16 != usCrcSum)
              {
                  dbgInfo("check cert[%u] len:0x%x,crc failed, 0x%x,0x%x\n",uci,cert->FL[uci].fl,cert->FL[uci].crc16,usCrcSum);
                  dbgInfo("data: 0x%x, 0x%x",pCertData[0],pCertData[4]);
                  dbgInfo("check cert[%u] crc failed\n",uci);
                  wRt = BSP_ERROR;
              }
          }
      }
      return wRt;
}

//获取证书
//wDevType： 0 flash main zone 1：flash back zone
//type ：0~2 或 0xff（全读）
/* Started by AICoder, pid:45d2fcb099h5b0c140a90b9ec01f9a0625c5fdb7 */
WORD32 GetCertAndKey(WORD32 wDevType, BYTE type, BYTE *pData)
{
    struct stVendorCert *cert = NULL;
    BYTE *pCertData = pData;
    WORD32 wRt = 0;
    WORD32 wCrcType = 0;
    if (NULL == pCertData)
    {
        dbgErr("%s>>The pCertData is equal NULL!\n",__FUNCTION__);
        return BSP_ERROR;
    }

    //先检查头部合法性
    if( BspReadCertInfo(wDevType, 0, pCertData,VenDorCertHeadLen) != BSP_OK )
    {
        dbgInfo("%s>>BspReadCertInfo head fail  !!!\n",__FUNCTION__);
        return BSP_ERROR;
    }
    cert = (struct stVendorCert *)pCertData;
    if (NULL == cert)
    {
        dbgErr("%s>>The cert is equal NULL!\n",__FUNCTION__);
        return BSP_ERROR;
    }
    if(cert->le >= UINT16_MAX)
    {
        dbgErr("%s>>cert->le = %d error!!\n", __FUNCTION__, cert->le);
        return BSP_ERROR;
    }
   //crc 只包括FL部分
    wRt = CheckCertHead(0,pCertData);
    if( wRt != BSP_OK )
    {
        if( wRt != 2 )
        {
            dbgErr("%s>>check head fail  !!\n",__FUNCTION__);
            return BSP_ERROR;
        }
        //crc 包括数据体（旧的，需要替换掉）
        if( BspReadCertInfo(wDevType, 0, pCertData,cert->le + VenDorCertHeadPreLen) != BSP_OK )
        {
            dbgErr("%s>>BspReadCertInfo prehead fail  !!!\n",__FUNCTION__);
            return BSP_ERROR;
        }
        wRt = CheckCertHead(1,pCertData);
        if( wRt != BSP_OK )
        {
            dbgErr("%s>>Cert: check prehead fail !!!\n",__FUNCTION__);
            return BSP_ERROR;
        }
        wCrcType = 1;
    }
    if( type == 0xff )
    {
        if( wCrcType == 0 )
        {
            if(BspReadCertInfo(wDevType, 0, pCertData, cert->le + VenDorCertHeadPreLen) != BSP_OK )
            {
                dbgErr("%s>>BspReadCertInfo fail  crctype = 0 !!!\n",__FUNCTION__);
                return BSP_ERROR;
            }
        }
    }
    else if( type < TYPE_NUM_USE)
    {
        wRt = BspReadCertInfo(wDevType, (WORD32)(VenDorCertHeadLen + cert->FL[type].off),
                (pCertData + VenDorCertHeadLen + cert->FL[type].off),
                cert->FL[type].fl);
        if( wRt != BSP_OK )
        {
            dbgErr("%s>>BspReadCertInfo fail type[%d] !!!\n",__FUNCTION__,type);
            return BSP_ERROR;
        }
    }
    else
    {
        dbgErr("%s>>type[%d] is wrong !!!\n",__FUNCTION__,type);
        return BSP_ERROR;
    }
    wRt = CheckCertFL(type, pCertData);
    if( wRt != BSP_OK )
    {
        dbgErr("%s>>Cert: check head FL fail !!!\n",__FUNCTION__);
        return wRt;
    }
    return BSP_OK;
}
/* Ended by AICoder, pid:45d2fcb099h5b0c140a90b9ec01f9a0625c5fdb7 */

/*************************************************
高层获取证书信息BspGetCertAndKey
Type: 0-根证书 1-用户证书 2-私钥
其中:私钥是加密存储的
**************************************************/
UINT32 BspGetCertAndKey(BYTE type, BYTE *pData, WORD32 *pdwDataLen)
{
    struct stVendorCert *cert = NULL;
    BYTE *pCertData = NULL;
    /* WORD32 wLe = MAX_CERT_SIZE - VenDorCertHeadLen; */
    UINT32 wRt = 0;

    INPUT_POINTER_CHECK(pData);
    INPUT_POINTER_CHECK(pdwDataLen);

    if(type >= TYPE_NUM_USE )
    {
        dbgErr( "%s>>type error: %u\n",__FUNCTION__,type);
        return BSP_ERROR;
    }
    pCertData = (BYTE *)malloc(MAX_CERT_SIZE);
    if( pCertData == NULL )
    {
        dbgErr( "%s>>malloc %d k error!\n", __FUNCTION__,MAX_CERT_SIZE/1024);
        return BSP_ERROR;
    }
    wRt = GetCertAndKey(TPM_SAFE_DEV_FLASH_MAIN,type,pCertData);/*先检查主区*/
    if(BSP_OK != wRt )
    {
        dbgErr( "%s>>get flash main zone cert(type:%u) fail!!!\n",__FUNCTION__,type);
        wRt = GetCertAndKey(TPM_SAFE_DEV_FLASH_BACK,type,pCertData);/*先检查备区*/
        if( BSP_OK != wRt )
        {
            free(pCertData);
            dbgErr( "%s>>get  flash back zone cert(type:%u) fail!!!\n",__FUNCTION__,type);
            return BSP_ERROR;
        }
    }
    
    cert = (struct stVendorCert *)pCertData;
    if (*pdwDataLen < cert->FL[type].fl)
    {
        free(pCertData);
        dbgErr( "%s>>DataLen error can not to memcpy !!!\n",__FUNCTION__);
        return BSP_ERROR;
    }

    memcpy_s(pData, (rsize_t) *pdwDataLen, (&cert->data)+cert->FL[type].off, (rsize_t)cert->FL[type].fl);
    *pdwDataLen = cert->FL[type].fl;
    free(pCertData);
    return BSP_OK;
}
UINT32 g_CertKeyFromFile  = 0;

UINT32 BspGetCertAndKeyFromFile(BYTE type,BYTE *pData, WORD32 *pdwDataLen)
{
    UINT32 ulRet = BSP_OK;
    FILE * fp = NULL;    
    INT32 iTmpRet = 0;   
    INT32 Len = 0;
    UINT32 ulRdLen = 0;
    CHAR filePath[3][32]={"/ata/rru/CAcert.p7b","/ata/rru/CA.cer","/ata/rru/CA.key"};
    
    dbgInfo("%s>>Get Cert From Filesystem!-----------------\n",__FUNCTION__);

    INPUT_POINTER_CHECK(pData);
    INPUT_POINTER_CHECK(pdwDataLen);
    
    if(type >= TYPE_NUM_USE )
    {
        dbgErr( "%s>>type error: %u, max: %d\n",__FUNCTION__,type,TYPE_NUM_USE-1);
        return BSP_ERROR;
    }

    fp = fopen(filePath[type], "r");
    if (fp == NULL)
    {
        dbgErr("%s>>open %s failed!\n",__FUNCTION__,filePath[type]);
        return NULL;
    }
    if(0 != fseek(fp, 0, SEEK_END))
    {
        dbgErr("%s>>fseek %s to end failed!\n",__FUNCTION__,filePath[type]);
        iTmpRet = fclose(fp);
        FCLOSE_CHECK(iTmpRet);
        return NULL;
    }   
    Len = ftell(fp); 
    if (Len < 0)
    {
        dbgErr("%s>>ftell failed!\n",__FUNCTION__);
        iTmpRet = fclose(fp);
        FCLOSE_CHECK(iTmpRet);
        return BSP_ERROR;
    }
    if(*pdwDataLen<Len)
    {
        dbgErr( "%s>>file %s DataLen error can not to memcpy !!![ulLen %d, bufLen %d]\n",__FUNCTION__,filePath[type],Len,*pdwDataLen);
        iTmpRet = fclose(fp);
        FCLOSE_CHECK(iTmpRet);
        return BSP_ERROR;
    }
    *pdwDataLen = Len;
    if(0 != fseek(fp, 0, SEEK_SET))
    {
        dbgErr("%s>>fseek %s to head failed!\n",__FUNCTION__,filePath[type]);
        iTmpRet = fclose(fp);
        FCLOSE_CHECK(iTmpRet);        
        return NULL;
    } 

    ulRdLen = fread(pData, 1, Len, fp);
    if (ulRdLen == Len)
    {
        dbgInfo("%s>>read file %s Succ !\n",__FUNCTION__,filePath[type]);
        ulRet = BSP_OK;
    }
    else
    {
        dbgErr("%s>>read file %s failed![len %d,read %d]\n",__FUNCTION__,filePath[type],Len,ulRdLen);
        ulRet = BSP_ERROR;
    }
    iTmpRet = fclose(fp);
    FCLOSE_CHECK(iTmpRet);

    return ulRet;
}

static UINT32 BspGetCertKey(BYTE *pcert, WORD32 *pdwDataLen)
{
    UINT32 ulRet = BSP_OK;
    
    INPUT_POINTER_CHECK(pcert);
    INPUT_POINTER_CHECK(pdwDataLen);
    
    if(g_CertKeyFromFile==1)
    {
        ulRet = BspGetCertAndKeyFromFile(0,pcert,pdwDataLen);
    }
    else
    {
        ulRet = BspGetCertAndKey(0,pcert,pdwDataLen);
    }
    if(BSP_OK!=ulRet)
    {
        dbgErr("%s>>Get Flash Zone Cert Failed ![ulRet %d]\n",__FUNCTION__,ulRet);
        return BSP_ERROR;
    }
    return BSP_OK;
}
/*从CA获取公钥*/
static EVP_PKEY *GetPublicKeyFromP7b(VOID)
{
   PKCS7 *p7 = NULL;
   BIO *b = NULL;
   EVP_PKEY *k = NULL;
   BYTE *pcert = NULL;
   UINT32 certLen = 8192;
   INT32 le = 0,i = 0;
   STACK_OF(X509)*certs = NULL;
   X509 *x = NULL;

   
   pcert = malloc(8192);
   if(NULL==pcert)
   {
        dbgErr("%s>>malloc pcert failed !\n",__FUNCTION__);
        return NULL;
   }
   //if(BSP_OK != BspGetCertAndKey(1,pcert,&certLen))/*找曾鑫确认??,从备区里取*/
   if(BSP_OK!=BspGetCertKey(pcert,&certLen))
   {
        dbgErr("%s>>BspGetCertAndKey failed !\n",__FUNCTION__);
        free(pcert);
        pcert = NULL;
        return NULL;
   }
   dbgInfo("%s>>pcert %p,certlen %d\n",__FUNCTION__,pcert,certLen);
   
   b = BIO_new(BIO_s_mem());
   if(b==NULL)
   {
        dbgErr("%s>>BIO_new error !\n",__FUNCTION__);
        free(pcert);
        pcert = NULL;
        return NULL;  
   }
   le = certLen;
   if(le != BIO_write(b,pcert,le))
   {
        dbgErr("%s>>BIO_write error !\n",__FUNCTION__);  
   }
   
   p7 = PEM_read_bio_PKCS7(b,NULL,NULL,NULL);
   if(NULL==p7)
   {
        dbgErr("%s>>PEM_read_bio_PKCS7 error !\n",__FUNCTION__);
        free(pcert);
        pcert = NULL;
        BIO_free(b);
        return NULL;
   }

   i = OBJ_obj2nid(p7->type);
   if(i==NID_pkcs7_signed)
   {
        certs=p7->d.sign->cert;
   }
   else if(i==NID_pkcs7_signedAndEnveloped)
   {
        certs=p7->d.signed_and_enveloped->cert;
   }

   for(i=0; (certs !=NULL) && (i<sk_X509_num(certs));i++)
   {
        x=sk_X509_value(certs,i);
        if( !IS_ROOTCA(x) )
        {
            //X509_print_fp(stdout, x);
            k = X509_get_pubkey(x);
            break;
        }
   }
      
    BIO_free(b);
    PKCS7_free(p7);
    free(pcert);
    pcert = NULL;
    
    return k;   
}
#if 0
/*Boot安全验签开关*/
UINT32 BspGetSafeBootCheckSwitch(BYTE *pbySwitch )
{
    BYTE cbuf[16] = {0};
    BYTE cTmpbuf[16] = {0};

    INPUT_POINTER_CHECK(pbySwitch);
    *pbySwitch = 0;
    //BspReadFlashInfo(cbuf,16,Z_PublicKey_Off+Z_PublinKey_len-16);/*待确认,dz*/
    
    if( cbuf[0] > 1)
    {
        dbgErr("%s>>switch value > 1, error !\n",__FUNCTION__);
        return BSP_ERROR;
    }
    memset(cTmpbuf,cbuf[0],16);
    if( memcmp(cTmpbuf,cbuf,16)!= 0 )
    {
        dbgErr("%s>>switch value error !\n",__FUNCTION__);
        return BSP_ERROR;
    }
    dbgInfo("%s>>switch value: %u!\n",__FUNCTION__,cbuf[0]);
    *pbySwitch = cbuf[0];
    return BSP_OK;
}
#endif
/*************************组件化安全启动验签**********************************************/

cJSON * cJSON_from_swv_file(CHAR * path)
{
    FILE * fp = NULL;
    size_t len = 0;
    size_t read_len = 0;
    cJSON * root = NULL;
    CHAR * str = NULL;
    INT32 iTmpRet = 0;

    fp = fopen(path, "r");
    if (fp == NULL)
    {
        dbgErr("%s>>open %s failed!\n",__FUNCTION__,path);
        return NULL;
    }
    if(0 != fseek(fp, 0, SEEK_END))
    {
        dbgErr("%s>>fseek %s to end failed!\n",__FUNCTION__,path);
        iTmpRet = fclose(fp);
        FCLOSE_CHECK(iTmpRet);
        return NULL;
    }   
    len = ftell(fp);
    if (len < 128)
    {
        dbgErr("%s>>ftell failed!\n",__FUNCTION__);
        iTmpRet = fclose(fp);
        FCLOSE_CHECK(iTmpRet);        
        return NULL;
    }
    if(0 != fseek(fp, 128, SEEK_SET))
    {
        dbgErr("%s>>fseek %s to head failed!\n",__FUNCTION__,path);
        iTmpRet = fclose(fp);
        FCLOSE_CHECK(iTmpRet);        
        return NULL;
    }   
    
    str = (CHAR *)malloc(len+1);
    if (str==NULL)
    {
        dbgErr("%s>>%s malloc failed!\n",__FUNCTION__,path);
        iTmpRet = fclose(fp);
        FCLOSE_CHECK(iTmpRet);        
        return NULL;
    }

    read_len = fread(str, 1, len-128, fp);
    if (read_len == (len-128))
    {
        str[len-128] = '\0';
        root = cJSON_Parse(str);
    }
    else
    {
        root = NULL;
        dbgErr("%s>>%s fread failed![len %zu,read %zu]\n",__FUNCTION__,path,len,read_len);
    }
    iTmpRet = fclose(fp);
    FCLOSE_CHECK(iTmpRet);
    free(str);
    dbgInfo("%s>>cJSON_Parse file %s Succ !\n",__FUNCTION__,path);
    return root;
}

UINT32 BspGetVerFileInfo(char *file, UINT32 *pLen, UINT32 *pCrc)
{
    if(file==NULL)
    {
        dbgErr("%s>>input para is null !\n",__FUNCTION__);
        return BSP_ERROR;
    }
    return GetVerFileInfo(file,pLen,pCrc);
}

VOID BspDecodeB64(UCHAR *d64,UCHAR *d,INT32 mlen)
{
    if((d64==NULL)||(d==NULL))
    {
        dbgErr("%s>>input para is null !\n",__FUNCTION__);
        return;
    }
    b64dcode_t(d64,d,mlen);
    return;
}

/*保护区or 文件系统 hash文件*/
UINT32 BspGetVersionSign(CHAR *ucBuf,UINT32 ulBufLen,UINT32 ulFileLen, UINT32 ulFileCrc,UCHAR* ucSign)
{
    cJSON * ver_sign_json = NULL;
    cJSON * ver_pkg = NULL;
    cJSON * pkg_child = NULL;
    cJSON * hash_type = NULL;
    cJSON * ver_infos = NULL;
    cJSON * ver_child = NULL;
    cJSON * size = NULL;
    cJSON * crc = NULL;
    cJSON * hashSign = NULL;
    UINT32 ulVerLen =0;
    UINT32 ulVerCrc = 0;

    if( ucSign == NULL)
    {
        dbgErr("%s>>input para is null !\n",__FUNCTION__);
        return BSP_ERROR;
    }

    if(ulBufLen == 0)
    {    
        dbgInfo("%s>>SignSrcFile: %s,search file:Lenth %d,Crc %d\n",__FUNCTION__,ucBuf,ulFileLen,ulFileCrc);
        ver_sign_json = cJSON_from_swv_file(ucBuf);
    }
    else
    {
        dbgInfo("%s>>SignSrcFile From Protect,search file:Lenth %d,Crc %d\n",__FUNCTION__,ulFileLen,ulFileCrc);
        ver_sign_json = cJSON_Parse(ucBuf+128);
    }
    
    if(NULL==ver_sign_json)
    {
        dbgErr("%s>>ver_sign_json is NULL !\n",__FUNCTION__);
        return BSP_ERROR;
    }
    ver_pkg = cJSON_GetObjectItem(ver_sign_json,"pkgGroup");
    if(NULL == ver_pkg)
    {
        cJSON_Delete(ver_sign_json);
        dbgErr("%s>>Get pkgGroup Object Failed [crc:%d len:%d] !\n", __FUNCTION__,ulFileCrc,ulFileLen);
        return BSP_ERROR;
    }
    pkg_child = ver_pkg->child;
    while(pkg_child !=NULL)
    {
        hash_type = cJSON_GetObjectItem(pkg_child,"hashType");
        if(NULL == hash_type)
        {
            dbgErr("%s>>Get hashType Object Failed [crc:%d len:%d] !\n", __FUNCTION__,ulFileCrc,ulFileLen);
            break;
        }
        dbgInfo("%s>>hash type: %d\n",__FUNCTION__,hash_type->valueint);     

        ver_infos = cJSON_GetObjectItem(pkg_child,"softInfos");        
        if(NULL == ver_infos)
        {
            dbgErr("%s>>Get softInfos Object Failed [crc:%d len:%d] !\n", __FUNCTION__,ulFileCrc,ulFileLen);
            break;
        }
        ver_child = ver_infos->child;    
        while(ver_child != NULL)
        {
        
            size = cJSON_GetObjectItem(ver_child, "size");            
            crc = cJSON_GetObjectItem(ver_child, "crc");
            if( crc==NULL || size==NULL )
            {
                dbgErr("%s>>Get size & crc Object Failed [crc:%d len:%d] !\n", __FUNCTION__,ulFileCrc,ulFileLen);
                break;
            }
            ulVerLen = (UINT32)size->valueint;
            ulVerCrc = (UINT32)crc->valueint;
            //dbgInfo("%s>>size %d,crc %d Get Succ !\n",__FUNCTION__,ulVerLen,ulVerCrc);
            if((ulFileLen == ulVerLen)&&(ulFileCrc==ulVerCrc))
            {
                hashSign = cJSON_GetObjectItem(ver_child, "hashSign");
                if(NULL == hashSign)
                {
                    dbgErr("%s>>Get size & crc Object Failed [crc:%d len:%d] !\n", __FUNCTION__,ulFileCrc,ulFileLen);
                    break;
                }
                dbgInfo("%s>>hash lenth %zu, string %s [crc:%d len:%d] !\n", __FUNCTION__,strlen(hashSign->valuestring),hashSign->valuestring,ulFileCrc,ulFileLen);
                memcpy_s(ucSign,4096,hashSign->valuestring, strlen(hashSign->valuestring)+1);
                cJSON_Delete(ver_sign_json);
                return BSP_OK;
            }
            ver_child = ver_child->next;
        }
        pkg_child = pkg_child->next;
    }
    cJSON_Delete(ver_sign_json);
    return BSP_ERROR;    
}
/*使用CA证书验签*/
UINT32 BspModuleVersion_Verify(UCHAR *ulBuf,UINT32 ulBufLen,UCHAR *sign_data)
{
    EVP_PKEY *ptKey = NULL;
    const EVP_MD *ptMd = NULL;
    EVP_MD_CTX   *ptMdCtx = NULL;
    CHAR *pcDataBuf = NULL;
    FILE *fp = NULL;
    INT32 sigDataSize = 0;
    INT32 iTmpRet = 0;

    ptMd = EVP_get_digestbynid(NID_sha256);
    if (NULL==ptMd) 
    {
        dbgErr("%s>>EVP_get_digestbynid failed !\n",__FUNCTION__);
        return BSP_ERROR;
    }
    ptMdCtx = EVP_MD_CTX_new();
    if (NULL==ptMdCtx)
    {
        dbgErr("%s>>EVP_MD_CTX_new failed !\n",__FUNCTION__);
        return BSP_ERROR;
    }

    if (!EVP_VerifyInit(ptMdCtx, ptMd))
    {
        dbgErr("%s>>EVP_VerifyInit failed !\n",__FUNCTION__);
        return BSP_ERROR;
    }

    if(ulBufLen==0)
    {
        dbgInfo("%s>>Verfile:%s\n",__FUNCTION__,ulBuf);
        fp = fopen((const char *)ulBuf,"rb");
        if(fp==NULL)
        {
            dbgErr("%s>>open file %s failed !\n",__FUNCTION__,ulBuf);
            return BSP_ERROR;
        }
        pcDataBuf = malloc(2048);
        if (NULL == pcDataBuf)
        {
            dbgErr("%s>>malloc failed !\n",__FUNCTION__);
            iTmpRet = fclose(fp);
            FCLOSE_CHECK(iTmpRet);
            return BSP_ERROR;
        }

        while(1)
        {
            sigDataSize = fread(pcDataBuf, 1, 2048, fp);
            if(sigDataSize > 0)
            {
                if (!EVP_VerifyUpdate(ptMdCtx, pcDataBuf, sigDataSize))
                {
                    dbgErr("%s>>file:%s EVP_VerifyUpdate failed !\n",__FUNCTION__,ulBuf);
                    free(pcDataBuf);
                    pcDataBuf = NULL;
                    iTmpRet = fclose(fp);
                    FCLOSE_CHECK(iTmpRet);
                    return BSP_ERROR;
                }
            }
            else
            {
                break;
            }
        }
        free(pcDataBuf);
        pcDataBuf = NULL;
        iTmpRet = fclose(fp);
        FCLOSE_CHECK(iTmpRet);
    }
    else
    {
        dbgInfo("%s>>ProtectVer,BufLen %d\n",__FUNCTION__,ulBufLen);
        if (!EVP_VerifyUpdate(ptMdCtx,ulBuf,ulBufLen))
        {
            dbgErr("%s>>EVP_VerifyUpdate failed !\n",__FUNCTION__);           
            return BSP_ERROR;
        }
    }
    dbgInfo("%s>>EVP_VerifyUpdate OK ![bufLen %d]\n",__FUNCTION__,ulBufLen);
    
    ptKey = GetPublicKeyFromP7b();
    if(NULL==ptKey)
    {
        dbgErr("%s>>GetPublicKey failed !\n",__FUNCTION__);
        return BSP_ERROR;
    }
    if (EVP_VerifyFinal(ptMdCtx, sign_data, 256, ptKey) > 0)
    {
        /*
        UCHAR *mymd = NULL;
        mymd = malloc(0x300);
        EVP_DigestFinal(ptMdCtx, mymd, NULL);
        
        dbgInfo("%s>>The ptMdCtx is equal:",__FUNCTION__);
        for (int i = 0; i < 300 ; i++)
        {
            dbgInfo("%x:",mymd[i]);
        }
        dbgInfo("\n");
        free(mymd);
        */
        
        dbgInfo("%s>>EVP_VerifyFinal success !\n",__FUNCTION__);
        EVP_PKEY_free(ptKey);
        return BSP_OK;
    }


    
    dbgErr("%s>>EVP_VerifyFinal failed !\n",__FUNCTION__);
    EVP_PKEY_free(ptKey);
    return BSP_ERROR;
}



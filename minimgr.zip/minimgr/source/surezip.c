/*****************************************************************************
 * 版权所有(C) 2009 - 2020, ZTE Corp. WiMAX
 *----------------------------------------------------------------------------
 * 模 块 名 : surezip
 * 文件名称 : surezip.c
 * 文件标识 : {[N/A]}
 * 内容摘要 : ZLIB库函数之应用, 压缩和解压缩
 * 注意事项 : 从网上搜集而来, 兼以VXWORKS的inflate.c库文件源码
 * 作    者 : 田瑞忠
 * 创建日期 : 2010-05-18
 * 当前版本 : Ver1.0
 *----------------------------------------------------------------------------
 * 变更记录 :
 *
 * $记录1
 * 变 更 单: $0000000(N/A)
 * 责 任 人: 田瑞忠
 * 修改日戳: 2010-5-18 19:07:08
 * 变更说明: 创建
 *

 * $记录2
 * 变 更 单: $0000000(N/A)
 * 责 任 人: 宋志强
 * 修改日戳: 2018-01-18
 * 变更说明: 代码重构，符合开源合规，同时修改BspComp,为BspDeflate,修改 BspDeComp为BspInflate
 *
 *----------------------------------------------------------------------------
 */



#include <stdio.h>
#include <stdlib.h>
#include <sys/stat.h>
#include <string.h>
#ifdef WIN32
#define htons(x) (\
                          (((x) & 0x00ffu) << 8) |\
                          (((x) & 0xff00u) >> 8)\
                 )
#else
#include <arpa/inet.h>
#endif

#include "zlib.h"
#include "surezip.h"

#ifndef DEF_WBITS
#  define DEF_WBITS MAX_WBITS
#endif



#ifndef EOS
#define EOS         '\0'
#endif

#ifndef OPT_FLAG
#define OPT_FLAG    '-'
#endif

unsigned int g_ulInflateCksum = 0;  /* set to TRUE to validate compressed checksum */

/*****************************************************************************
 *  函数名称   : cksum(*)
 *  功能描述   :
 *  读全局变量 : 无
 *  写全局变量 : 无
 *  输入参数   : prevSum     - previous total
                 buf         - buffer to checksum
                 ulLen       - size of buffer
 *  输出参数   : 无

 *  返 回 值   :
 *  其它说明   :
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *  $0000000(N/A), 石乔@2010-6-21 18:48, 创建函数
 *  $0000000(N/A), 宋志强@2018-1-3 10:33,重构校验和计算，与vxworks以及RRU之前的工具兼容
 *----------------------------------------------------------------------------
*/
static int doSwapNext = 0;

static unsigned short cksum(unsigned short prevSum, const unsigned char *buf, unsigned long len)
{
    int doSwap = 0;
    unsigned long sum = prevSum;
    union
    {
        unsigned char   c[2];
        unsigned short  s;
    } shorty;
    union
    {
        unsigned short  s[2];
        unsigned long   l;
    } longy;
#define ADDCARRY(x) (x > 65535 ? x -= 65535 : x)
#define REDUCE(x) {longy.l = x; x = longy.s[0] + longy.s[1]; ADDCARRY(x);}
    REDUCE(sum);
    /*
     * doSwapNext is 1 if 0 was effectively added to end of last chunk of data
     * 'effectively' means swap is taken into account
     */

    if (doSwapNext)
    {
        /* do the first byte now for misaligned buffers */
        if ((long)buf & 1)
        {
            shorty.c[0] = 0;
            shorty.c[1] = *buf;
            buf++;
            len--;
            sum += shorty.s;
        }
        else
        {
            unsigned char tmp;
            doSwap = 1;
            shorty.s = (unsigned short)sum;
            tmp = shorty.c[0];
            shorty.c[0] = shorty.c[1];
            shorty.c[1] = tmp;
            sum = shorty.s;
        }
    }
    else
    {
        if ((long)buf & 1)
        {
            unsigned char tmp;
            doSwap = 1;
            shorty.s = (unsigned short)sum;
            tmp = shorty.c[0];
            shorty.c[0] = shorty.c[1];
            shorty.c[1] = tmp;
            sum = shorty.s;
            shorty.c[0] = 0;
            shorty.c[1] = *buf;
            buf++;
            len--;
            sum += shorty.s;
        }
    }

    /* do the rest two bytes at a time */
    while (len > 1)
    {
        sum += *((unsigned short *)buf);
        buf += 2;
        len -= 2;

        if ((len & 0x7ffe) == 0)
        {
            REDUCE(sum);
        }
    }

    /* add in the last byte if needed */

    if (len == 1)
    {
        /*
         * if swap will happen, then this 0 is effectively inserted before
         * last byte, not added to the end of the data
         */
        doSwapNext = 1 & ~doSwap;
        shorty.c[0] = *buf;
        shorty.c[1] = 0;
        sum += shorty.s;
    }

    REDUCE(sum);
    REDUCE(sum);
    shorty.s = (unsigned short)sum;
    /* swap bytes if needed */

    if (doSwap)
    {
        unsigned char tmp;
        tmp = shorty.c[0];
        shorty.c[0] = shorty.c[1];
        shorty.c[1] = tmp;
    }

    return (shorty.s);
} /*cksum end*/

/*****************************************************************************
 *  函数名称   : BspComp(*)
 *  功能描述   : 一次性压缩整个映象数据, 与vxWorks版本的deflate.exe兼容
 *  读全局变量 : 无
 *  写全局变量 : 无
 *  输入参数   : pucSrc     - 压缩映象源地址
                 pucDest    - 解压缩目标地址
                 sourceLen - 原始数据长度
                 *pdestLen  - 压缩缓存空间大小
 *  输出参数   : 无
 *  返 回 值   : zlib压缩的错误值, 如果没有错误，返回 Z_OK
 *  其它说明   : 这个代码是 compress.c 中的compress 基础上增加Z_DEFLATED 头以及cksum尾
                 兼容 vcworks中deflate.exe 生成的文件格式
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *  $0000000(N/A), 宋志强@2009-2-5 15:46:28
 *  $0000000(N/A), 宋志强@2018-1-3 10:35:00 直接调用zlib接口，开源合规清理
 *----------------------------------------------------------------------------
 */
unsigned int  BspDeflate(const unsigned char *pucSrc, unsigned char *pucDest, unsigned long sourceLen, unsigned long *pdestLen)
{
    unsigned short sum = 0;
    int err = compress(pucDest + 1, (uLongf *)pdestLen, pucSrc, sourceLen);

    *pucDest = Z_DEFLATED;
    sum =  0;
    /*append 16bit check sum*/
    sum = 0xffff - cksum(0, pucDest, *pdestLen + 1);

    if ((*pdestLen + 1) & 0x1)
    {
        sum = htons(sum);
    }

    memcpy(pucDest + *pdestLen + 1, &sum, sizeof(unsigned short));
    *pdestLen += 3; /* Z_DEFLATED, and last two a valid checksum. */
    return err;
}


/*****************************************************************************
 *  函数名称   : BspInflate(*)
 *  功能描述   : 一次性解压缩整个映象数据, 与旧版本兼容
 *  读全局变量 : 无
 *  写全局变量 : 无
 *  输入参数   : pucSrc    - 压缩映象源地址
                 pucDest   - 解压缩目标地址
                 sourceLen - 待解压数据长度
                 pdestLen  - 解压缩缓存空间大小
 *  输出参数   : 无
 *  返 回 值   : 成功解压缩后的数据长度
 *  其它说明   :
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *  $0000000(N/A), 田瑞忠@2009-2-5 15:46:28
 *  $0000000(N/A), 宋志强@2018-1-3 10:35:00 直接调用zlib接口，开源合规清理
 *----------------------------------------------------------------------------
 */
unsigned int BspInflate(const unsigned char *pucSrc, unsigned char *pucDest, unsigned long sourceLen, unsigned long *pdestLen)
{
    int err;
    unsigned short sum = 0;
    /*
     * Validate the compression stream.
     * The first byte should be Z_DEFLATED, the last two a valid checksum.
     */

    if (*pucSrc != Z_DEFLATED)
    {
        return (0);
    }

    sum = (*(pucSrc + sourceLen -2 ) << 8) | *(pucSrc + sourceLen -1);
    if (sum != 0xFFFF) /* 兼容考虑：部分时期Deflate生成的压缩数据没有sum,写了0xFFFF */
    {
        if (g_ulInflateCksum)
        {
            if (cksum(0, pucSrc, sourceLen) != 0xffff)
            {
                printf("checksum failed! sum = %d\n", sum);

                return (0);
            }
        }
    }

    /* 解压缩数据忽略 Z_DEFLATED 以及 sum校验和*/
    pucSrc++;
    sourceLen -= 3;
    err = uncompress(pucDest, pdestLen, pucSrc, sourceLen);

    return err;
}


/*****************************************************************************
 *  函数名称   : vx_inflate(*)
 *  功能描述   : 兼容vxworks inflate 函数的接口，提供单板或者其他模块调用
 *  读全局变量 : 无
 *  写全局变量 : 无
 *  输入参数   : src        - 原始数据，需要包含Z_DEFLATED头
                 dest       - 解压缩后的数据缓冲区
                 nBytes     - 原始数据长度
 *  输出参数   : 无
 *  返 回 值   : 返回解压缩错误码。
 *  其它说明   : 需要外部调用保证对dest 分配了足够的空间，避免空间踩踏
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *  $0000000(N/A),  宋志强@2018-01-16 新建适配vxworks函数
 *----------------------------------------------------------------------------
 */
unsigned int vx_inflate (unsigned char *src, unsigned char *dest, unsigned long nBytes, size_t *pOutBytes)
{
    if(pOutBytes == NULL)
    {
        printf("%s parameter is NULL\n", __FUNCTION__);
        return (-1);
    }
    unsigned long lOutBytes = *pOutBytes;
    return BspInflate(src, dest, nBytes, &lOutBytes);

}


/*****************************************************************************
 *  函数名称   : BspSegzip(*)
 *  功能描述   : 压缩映象分段解压缩(注意没有资源互斥考虑)
 *  读全局变量 : 无
 *  写全局变量 : 无
 *  输入参数   : ulSegNo    - 压缩段号
                 pucSrc     - 数据源指针
                 pucDest    - 目标缓存首指针
                 *plBytes   - 数据源长度
                 *plBufSize - 目标缓存长度
 *  输出参数   : pucDest    - 解压缩后的数据
                 *plBytes   - 解压缩已经处理的源数据长度
                 *plBufSize - 解压缩得到的数据长度
 *  返 回 值   : 0 - 解压缩结束, 1, 解压缩成功但尚未结束, -1, 解压缩出错
 *  其它说明   : 当ulSegNo不为0, 且源数据指针为空时, 表示继续上一次的解压缩
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *  $0000000(N/A), 田瑞忠@2009-1-6 8:40:43, 创建函数
 *----------------------------------------------------------------------------
 */
long BspSegzip(int ulSegNo, unsigned char *pucSrc,
               unsigned char *pucDest, long *plBytes, long *plBufSize)
{
    static  z_stream stream;
    static  int pend = 0;
    int err;

    if ((ulSegNo == 0 && pucSrc == NULL) ||
        pucDest == NULL || plBytes == NULL || plBufSize == NULL)
    {
        return -1;
    }

    /* 首段, 初始化压缩实体 */
    if (ulSegNo == 0)
    {
        /* 如果有未结束的压缩, 则先进行清空 */
        if (pend)
        {
            deflateEnd(&stream);
            pend = 0;
        }

        stream.next_in  = (Bytef *)pucSrc;
        stream.avail_in = (uInt)(*plBytes);
        stream.next_out = pucDest;
        stream.avail_out = (uInt)(*plBufSize);

        if ((uLong)stream.avail_out != *plBufSize)
        {
            return Z_BUF_ERROR;
        }

        stream.zalloc = (alloc_func)0;
        stream.zfree = (free_func)0;
        stream.opaque = (voidpf)0;
        err = deflateInit(&stream, Z_DEFAULT_COMPRESSION);

        if (err != Z_OK)
        {
            return err;
        }
    }
    /* 后续段, 更新数据指针 */
    else
    {
        if (pucSrc == NULL)
        {
            pucSrc = stream.next_in;
        }
        else
        {
            stream.next_in  = pucSrc;
            stream.avail_in = *plBytes;
        }

        stream.next_out = pucDest;
        stream.avail_out = *plBufSize;
    }

    err = deflate(&stream, (ulSegNo >= 0) ? Z_NO_FLUSH : Z_FINISH);
    *plBytes = stream.next_in - pucSrc, *plBufSize = stream.next_out - pucDest;

    if (err == Z_STREAM_END)
    {
        err = deflateEnd(&stream);
        pend = 0;
        return 0;
    }

    if (err != Z_OK)
    {
        pend = 0;
        deflateEnd(&stream);
        return (-1);
    }

    return 1; /* ((int)d_stream.total_out); */
}



/*****************************************************************************
 *  函数名称   : BspSegUnzip(*)
 *  功能描述   : 压缩映象分段解压缩(注意没有资源互斥考虑)
 *  读全局变量 : 无
 *  写全局变量 : 无
 *  输入参数   : ulSegNo    - 解压缩段号
                 pucSrc     - 数据源指针
                 pucDest    - 目标缓存首指针
                 *plBytes    - 数据源长度
                 *plBufSize  - 目标缓存长度
 *  输出参数   : pucDest    - 解压缩后的数据
                 *plBytes    - 解压缩已经处理的源数据长度
                 *plBufSize  - 解压缩得到的数据长度
 *  返 回 值   : 0 - 解压缩结束, 1, 解压缩成功但尚未结束, -1, 解压缩出错
 *  其它说明   : 当ulSegNo不为0, 且源数据指针为空时, 表示继续上一次的解压缩
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *  $0000000(N/A), 田瑞忠@2009-1-6 8:40:43, 创建函数
 *----------------------------------------------------------------------------
 */
short BspSegUnzip(int ulSegNo, unsigned char *pucSrc,
                  unsigned char *pucDest, long *plBytes, long *plBufSize)
{
    static  z_stream d_stream = {0};    /* decompression stream */
    static  int pend = 0;
    int     err;

    if ((ulSegNo == 0 && pucSrc == NULL) ||
        pucDest == NULL || plBytes == NULL || plBufSize == NULL)
    {
        return -1;
    }

    /* 首段, 初始化压缩实体 */
    if (ulSegNo == 0)
    {
        /* 如果有未结束的压缩, 则先进行清空 */
        if (pend)
        {
            inflateEnd(&d_stream);
            pend = 0;
        }

        /*
         * Validate the compression stream.
         * The first byte should be Z_DEFLATED, the last two a valid checksum.
         */

        if (*pucSrc != Z_DEFLATED)
        {
            //DBG_PUT ("inflate error: *pucSrc = %d. not Z_DEFLATED data\n", *pucSrc);
            return (0);
        }

        /* do the decompression */
        d_stream.zalloc = (alloc_func)0;
        d_stream.zfree = (free_func)0;
        d_stream.opaque = (voidp)0;
        d_stream.next_in  =(Bytef *)(pucSrc + 1);
        d_stream.avail_in = *plBytes - 1;
        d_stream.next_out = pucDest;
        d_stream.avail_out = *plBufSize;

        if (inflateInit(&d_stream) != Z_OK)
        {
            return (-1);
        }

        pend = 1;
    }
    /* 后续段, 更新数据指针 */
    else
    {
        if (pucSrc != NULL)
        {
            d_stream.next_in  =(Bytef *) pucSrc;
            d_stream.avail_in = *plBytes;
        }
        else
        {
            pucSrc = d_stream.next_in;
        }

        d_stream.next_out = pucDest;
        d_stream.avail_out = *plBufSize;
    }

    /* 执行解压缩 */
    err = inflate(&d_stream, 0);
    *plBytes = d_stream.next_in - pucSrc, *plBufSize = d_stream.next_out - pucDest;

    if (err == Z_STREAM_END)
    {
        err = inflateEnd(&d_stream);
        pend = 0;
        return 0;
    }

    if (err != Z_OK)
    {
        pend = 0;
        return (-1);
    }

    return 1; /* ((int)d_stream.total_out); */
}


/*****************************************************************************
 *  函数名称   : BspZipDataCheck(*)
 *  功能描述   : 简单判断数据是否为标准ZIP压缩的映象(只利用前3个字节)
 *  读全局变量 : 无
 *  写全局变量 : 无
 *  输入参数   : pucSrc    - 数据源指针
                 ulBytes    - 数据源长度
 *  输出参数   : 无
 *  返 回 值   : 无
 *  其它说明   : 只判断头部分, 并不严密
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *  $0000000(N/A), 田瑞忠@2009-1-6 8:40:43, 创建函数
 *----------------------------------------------------------------------------
 */
unsigned int BspZipDataCheck(const unsigned char *pucSrc, long ulBytes)
{
    /* 至少三个字节 */
    if (ulBytes < 3)
    {
        return 0;
    }

    /* 第一个字节应该是魔法数: Z_DEFLATED */
    if (*pucSrc++ != Z_DEFLATED)
    {
        return 0;
    }

    /* 第二个字节, method */
    if ((*pucSrc & 8) != Z_DEFLATED)
    {
        return 0;
    }

    if ((*pucSrc >> 4) + 8 > DEF_WBITS)
    {
        return 0;
    }

    if (((*pucSrc << 8) + *(pucSrc + 1)) % 31)
    {
        return 0;
    }

    return 1;

} /* BspZipDataCheck() */


//#define _MAKE_TOOL
#ifdef _MAKE_TOOL   /* 用于在PC机上测试应用,生成deflate工具 */


#define SEG_LEN   1024
char    *s_cInFileName     = "test.txt";
char    *s_cOutFileName    = "suerzip_test.z";
char    s_ucGetBuffer[SEG_LEN];
char    s_ucPutBuffer[SEG_LEN];


/*****************************************************************************
 *  函数名称   : UseZip(*)
 *  功能描述   : 程序处理主函数
 *  读全局变量 : 无
 *  写全局变量 : 无
 *  输入参数   : argc   - 参数个数
                 argv[] - 参数列表
 *  输出参数   : 无
 *  返 回 值   : 0为成功, 其余失败
 *  其它说明   :
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *  $0000000(N/A), 田瑞忠@2009-01-14
 *----------------------------------------------------------------------------
 */
int UseZip(void)
{
    FILE    *ptInFile;
    FILE    *ptOutFile;
    signed int     iReadLen;
    signed int     iOutLen;
    unsigned char   *pucSrc;
    unsigned char   *pucDest;
    struct stat tStatInfo;
    unsigned int  ulSrcFileLen;

    if (NULL == (ptOutFile = fopen(s_cOutFileName, "wb")))
    {
        printf("Cannot create file \"%s\".\n", s_cOutFileName);
        return -1;
    }

    if (NULL == (ptInFile = fopen(s_cInFileName, "rb")))
    {
        fclose(ptOutFile);
        printf("Cannot open file \"%s\".\n", s_cInFileName);
        return -1;
    }

    /* 获取运行版本文件长度 */
    if (stat(s_cInFileName, &tStatInfo) == -1)
    {
        fclose(ptOutFile);
        fclose(ptInFile);
        return -1;
    }

    ulSrcFileLen = tStatInfo.st_size;
    pucSrc = malloc(ulSrcFileLen);
    if(pucSrc == NULL)
    {
        fclose(ptOutFile);
        fclose(ptInFile);
        return BSP_ERROR_MEM_MALLOC;
    }
    pucDest = malloc(ulSrcFileLen);

    if(pucSrc == NULL)
    {
        fclose(ptOutFile);
        fclose(ptInFile);
        free(pucSrc);
        return BSP_ERROR_MEM_MALLOC;
    }

    iReadLen = fread(pucSrc, 1, ulSrcFileLen, ptInFile);
    iOutLen  = iReadLen;
    BspDeflate(pucSrc, pucDest, (long)iReadLen, (long*)&iOutLen);
    fwrite(pucDest, 1, iOutLen, ptOutFile);
    free(pucDest);
    free(pucSrc);
    fclose(ptOutFile);
    fclose(ptInFile);
    return 0;
}



/*****************************************************************************
 *  函数名称   : UseZip(*)
 *  功能描述   : 程序处理主函数
 *  读全局变量 : 无
 *  写全局变量 : 无
 *  输入参数   : argc   - 参数个数
                 argv[] - 参数列表
 *  输出参数   : 无
 *  返 回 值   : 0为成功, 其余失败
 *  其它说明   :
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *  $0000000(N/A), 田瑞忠@2009-01-14
 *----------------------------------------------------------------------------
 */
int UseUnzip(void)
{
    FILE    *ptInFile;
    FILE    *ptOutFile;
    int     iReadLen;
    int     iOutLen;
    unsigned char   *pucSrc;
    unsigned char   *pucDest;
    struct stat tStatInfo;
    unsigned int   ulSrcFileLen;

    if (NULL == (ptOutFile = fopen(s_cOutFileName, "wb")))
    {
        printf("Cannot create file \"%s\".\n", s_cOutFileName);
        return -1;
    }

    if (NULL == (ptInFile = fopen(s_cInFileName, "rb")))
    {
        printf("Cannot open file \"%s\".\n", s_cInFileName);
        fclose(ptOutFile);
        return -1;
    }

    /* 获取运行版本文件长度 */
    if (-1 == stat(s_cInFileName, &tStatInfo))
    {
        fclose(ptInFile);
        fclose(ptOutFile);
        return -1;
    }

    ulSrcFileLen = tStatInfo.st_size;
    iOutLen = ulSrcFileLen * 10;
    pucSrc = malloc(ulSrcFileLen);
    if(pucSrc == NULL)
    {
        fclose(ptOutFile);
        fclose(ptInFile);
        return BSP_ERROR_MEM_MALLOC;
    }
    pucDest = malloc(iOutLen);
    if(pucSrc == NULL)
    {
        fclose(ptOutFile);
        fclose(ptInFile);
        free(pucSrc);
        return BSP_ERROR_MEM_MALLOC;
    }
    iReadLen = fread(pucSrc, 1, ulSrcFileLen, ptInFile);

    BspInflate(pucSrc, pucDest, (long)iReadLen, (long*)&iOutLen);
    fwrite(pucDest, 1, iOutLen, ptOutFile);
    free(pucDest);
    free(pucSrc);
    fclose(ptOutFile);
    fclose(ptInFile);
    return 0;
}



/*****************************************************************************
 *  函数名称   : UseSegZip(*)
 *  功能描述   : 程序处理主函数
 *  读全局变量 : 无
 *  写全局变量 : 无
 *  输入参数   : argc   - 参数个数
                 argv[] - 参数列表
 *  输出参数   : 无
 *  返 回 值   : 0为成功, 其余失败
 *  其它说明   :
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *  $0000000(N/A), 田瑞忠@2009-01-14
 *----------------------------------------------------------------------------
 */
int UseSegZip(void)
{
    FILE    *ptInFile;
    FILE    *ptOutFile;
    int     iReadLen;
    int     iSegNo;
    int     iInPtr;
    long     iInLen;
    long     iOutLen;
    int     iInAll;
    int     iOutAll;

    if (NULL == (ptOutFile = fopen(s_cOutFileName, "wb")))
    {
        printf("Cannot create file \"%s\".\n", s_cOutFileName);
        return -1;
    }

    if (NULL == (ptInFile = fopen(s_cInFileName, "rb")))
    {
        fclose(ptOutFile);
        printf("Cannot open file \"%s\".\n", s_cInFileName);
        return -1;
    }

    for (iInAll = iOutAll = iSegNo = iInPtr = iReadLen = 0; 1; iSegNo++)
    {
        if (iReadLen <= iInPtr)
        {
            if (iSegNo & 0x80000000)
            {
                break;
            }

            iReadLen = fread(s_ucGetBuffer, 1, SEG_LEN, ptInFile);

            if (iReadLen < SEG_LEN)
            {
                iSegNo |= 0x80000000;
            }

            iInPtr = 0;
        }

        iInLen = iReadLen - iInPtr;
        iOutLen = SEG_LEN;
        BspSegzip(iSegNo, s_ucGetBuffer + iInPtr, s_ucPutBuffer, &iInLen, &iOutLen);
        fwrite(s_ucPutBuffer, 1, iOutLen, ptOutFile);
        iInPtr += iInLen;
        iInAll += iInLen;
        iOutAll += iOutLen;

        while (iOutLen == SEG_LEN)
        {
            BspSegzip(iSegNo++, NULL, s_ucPutBuffer, &iInLen, &iOutLen);
            fwrite(s_ucPutBuffer, 1, iOutLen, ptOutFile);
            iInAll += iInLen;
            iOutAll += iOutLen;
        }
    }

    fclose(ptOutFile);
    fclose(ptInFile);
    printf("deflate %d bytes, ratio %d%%\n", iInAll, (int)(iOutAll * 100 / iInAll));
    return 0;
}


/*****************************************************************************
 *  函数名称   : UseSegUnZip(*)
 *  功能描述   : 程序处理主函数
 *  读全局变量 : 无
 *  写全局变量 : 无
 *  输入参数   : argc   - 参数个数
                 argv[] - 参数列表
 *  输出参数   : 无
 *  返 回 值   : 0为成功, 其余失败
 *  其它说明   :
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *  $0000000(N/A), 田瑞忠@2009-01-14
 *----------------------------------------------------------------------------
 */
int UseSegUnzip(void)
{
    FILE    *ptInFile;
    FILE    *ptOutFile;
    int     iReadLen;
    int     iSegNo;
    int     iInPtr;
    long     iInLen;
    long     iOutLen;
    int     iInAll;
    int     iOutAll;

    if (NULL == (ptOutFile = fopen(s_cOutFileName, "wb")))
    {
        printf("Cannot create file \"%s\".\n", s_cOutFileName);
        return -1;
    }

    if (NULL == (ptInFile = fopen(s_cInFileName, "rb")))
    {
        fclose(ptOutFile);
        printf("Cannot open file \"%s\".\n", s_cInFileName);
        return -1;
    }

    for (iInAll = iOutAll = iSegNo = iInPtr = iReadLen = 0; 1; iSegNo++)
    {
        if (iReadLen <= iInPtr)
        {
            if (iSegNo & 0x80000000)
            {
                break;
            }

            iReadLen = fread(s_ucGetBuffer, 1, SEG_LEN, ptInFile);

            if (iReadLen < SEG_LEN)
            {
                iReadLen -= 2;
                iSegNo |= 0x80000000;
            }

            iInPtr = 0;
        }

        iInLen = iReadLen - iInPtr;
        iOutLen = SEG_LEN;
        BspSegUnzip(iSegNo,
                    s_ucGetBuffer + iInPtr, s_ucPutBuffer, &iInLen, &iOutLen);

        if (iOutLen > 0)
        {
            fwrite(s_ucPutBuffer, 1, iOutLen, ptOutFile);
        }

        iInPtr += iInLen, iInAll += iInLen, iOutAll += iOutLen;
    }

    fclose(ptOutFile);
    fclose(ptInFile);
    printf("inflate %d bytes, ratio %d%%\n", iInAll, (int)(iOutAll * 100 / iInAll));
    return 0;
}


/*****************************************************************************
 *  函数名称   : InputArgParse(*)
 *  功能描述   : 输入参数解析, 用以得到关键变量及选项
 *  读全局变量 : 无
 *  写全局变量 : 无
 *  输入参数   : argc   - 参数个数
                 argv[] - 参数列表
 *  输出参数   : 无
 *  返 回 值   : 0为成功, 其余失败
 *  其它说明   : 从conv_img.cpp移植
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *  $0000000(N/A), 田瑞忠@2009-1-24 21:44:18
 *----------------------------------------------------------------------------
 */
static int InputArgParse(int argc, char *argv[])
{
    unsigned int     iLoop;
    unsigned int     iNameIndex;
    char        *argvi;
    char        **cNameTbl[] = {&s_cInFileName, &s_cOutFileName};

    for (iLoop = 1, iNameIndex = 0; iLoop < (unsigned int)argc; iLoop++)
    {
        // 不是选项, 直接置目标文件名
        argvi = argv[iLoop];

        if (*argvi != OPT_FLAG && iNameIndex < (sizeof(cNameTbl) / sizeof(cNameTbl[0])))
        {
            *cNameTbl[iNameIndex++] = argvi;
            continue;
        }

        // 跳过选项的斜框
        argvi++;

        if (*argvi == '?')
        {
            s_iShowHelp = 1;
        }
        // 逆向数据转换
        else if (*argvi == 'i')
        {
            s_iUnzip = 1;
        }
        /* 分段处理，节约内存 */
        else if (*argvi == 's')
        {
            s_iSegOprate = 1;
        }
    } /* for (i = 1, iNameIndex = 0; i < argc; i++) */

    return 0;
} /* InputArgParse() */



#if 1
/*****************************************************************************
 *  函数名称   : main(*)
 *  功能描述   : 程序处理主函数
 *  读全局变量 : 无
 *  写全局变量 : 无
 *  输入参数   : argc   - 参数个数
                 argv[] - 参数列表
 *  输出参数   : 无
 *  返 回 值   : 0为成功, 其余失败
 *  其它说明   :
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *  $0000000(N/A), 田瑞忠@2009-01-14
 *----------------------------------------------------------------------------
 */
int main(int argc, char *argv[])
{
#if 1
    s_cInFileName     = argv[1];
    s_cOutFileName    = argv[2];
#else
    s_cInFileName     = "D:\\test\\BcbDeflate\\debug\\wptr_fpga.bin";
    s_cOutFileName    = "D:\\test\\BcbDeflate\\debug\\wptr_fpga.z";
#endif
    InputArgParse(argc, argv);

    if (s_iSegOprate)
    {
        return s_iUnzip ? UseSegUnzip() : UseSegZip();
    }
    else
    {
        return s_iUnzip ? UseUnzip() : UseZip();
    }
}
#endif

#endif /* _MAKE_TOOL */

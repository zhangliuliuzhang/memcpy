/*********************************************************************
* 版权所有 (C)2008 ~2020, 深圳市中兴通讯股份有限公司。
*
* 文件名称： elf.c
* 文件标识：
* 其它说明： elf 文件符号表解析操作
* 当前版本： V1.1
* 作    者：
* 完成日期：
*
* 修改记录1：
*    修改日期：2008年05月15日
*    版 本 号：V1.0
*    修 改 人：张文剑
*    修改内容：创建

* 修改记录2：
*    修改日期：2019年03月26日
*    版 本 号：V1.1
*    修 改 人：宋志强
*    修改内容：把elf 文件符号表的解析从OSS中独立到 common中，供 BSP、工装、OSS使用，统一成一个符号表操作。
              增加对arm64 的解析支持
* 修改记录3：
*    修改日期：2020年09月01日
*    版 本 号：V1.2
*    修 改 人：宋志强
*    修改内容：消除告警，同时分析，对于AAU来说，符号表与RadioMode无关，其实只有一个符号表，因此优化对应代码，减少内存消耗，但是保留相关定义，以便可能的扩充。
              增加对arm64 的解析支持
**********************************************************************/

#include "ru_basedef.h"

/*************************************************************************************
*                 文件内部使用的宏                                                   *
*************************************************************************************/
#define B2L(a, size) toLE((BYTE*)&a, size)
#define B2L2(a) (B2L(a, 2))
#define B2L4(a) (B2L(a, 4))
#define B2L8(a) (B2L(a, 8))
#define PERR printf("error at line %d\n", __LINE__)
#define MAX_SEC_NUM     100
#define MAX_SEC_NAME_LEN    30
#define SYM_TYPE_NAME_SIZE 32

/*************************************************************************************
*                 文件内部使用的数据类型                                             *
*************************************************************************************/
typedef struct {
    CHAR *name;
    CHAR *addr;
    WORD32 size;
    WORD32  type;
} SYMBOL_ENT;


/************************************************************************************
 *                     局部变量声明                                                 *
************************************************************************************/
#define RADIOMODE_MAX 10
#define SELF_MODE 1
static SYMBOL_ENT* taSymTbl[RADIOMODE_MAX]; /* SYMBOL_ENT taSymTbl [SYM_NUM];  */
static INT ulSymTblSize[RADIOMODE_MAX];
static INT g_iEndianType;
static CHAR s_aSecNames[RADIOMODE_MAX][MAX_SEC_NUM][MAX_SEC_NAME_LEN];
static BOOLEAN bSymTabInitFlag[RADIOMODE_MAX];

extern BOOLEAN R_IsMemUseDebugEnable(VOID);

/************************************************************************************
 *                     局部函数声明                                                 *
************************************************************************************/
static BOOLEAN isOurConcernedSection (INT section_index, UCHAR ucRadioMode);
static INT SortSymbolTable(SYMBOL_ENT *buff, WORD32 symbolnum);
static SIZE_T toLE(BYTE *p, INT size);
static WORD32 symGetPosByValue(WORDPTR value, UCHAR ucRadioMode);
static INT OpenCurrentELF(CHAR *filename, UCHAR ucRadioMode);


#ifdef SUPPORT_64BIT
static INT VerifyELFHeader(INT fd,Elf64_Ehdr * pHdr);
static INT BuildSymTable(Elf64_Ehdr *elfHdr, INT fd, UCHAR ucRadioMode);
#else
#if((CPU_FAMILY == I80X86) || (CPU_FAMILY == POWERPC )|| (CPU_FAMILY == ARM) || (CPU_FAMILY == MIPS))
static INT VerifyELFHeader(INT fd,Elf32_Ehdr * pHdr);
static INT BuildSymTable(Elf32_Ehdr *elfHdr, INT fd, UCHAR ucRadioMode);
#endif
#if((CPU_FAMILY == IA64) || (CPU_FAMILY== MIPS64) || (CPU_FAMILY == ARM64))
static INT VerifyELFHeader(INT fd,Elf64_Ehdr * pHdr);
static INT BuildSymTable(Elf64_Ehdr *elfHdr, INT fd, UCHAR ucRadioMode);
#endif
#endif

/************************************************************************************
 *                     局部函数定义                                                 *
************************************************************************************/
unsigned char *XOS_Malloc(unsigned int dwSize)
{
    return malloc(dwSize);
}

static void XOS_Free(void *pucBuf)
{
    free(pucBuf);
    return;
}


WORD32 InitSymbolTableEx(CHAR *filename, UCHAR ucRadioMode)
{
    if(taSymTbl[ucRadioMode] == NULL)
    {
        return OpenCurrentELF(filename,ucRadioMode);
    }
    else if(bSymTabInitFlag[ucRadioMode] == TRUE)
    {
        return OK;/* 已经初始化过了，直接返回 OK */
    }
    else
    {
        return ERROR;
    }
}

/**********************************************************************
* 函数名称：InitSymbolTable
* 功能描述：
* 访问的表：无
* 修改的表：无
* 输入参数：
* 输出参数：
* 返 回 值：
* 其它说明：无
* 修改日期      版本号  修改人      修改内容
* ---------------------------------------------------------------------
* 2008/05/05    V1.0    张文剑      创建
************************************************************************/
WORD32 InitSymbolTable(CHAR *filename)
{
    return InitSymbolTableEx(filename, SELF_MODE);
}

/**********************************************************************
* 函数名称：DelSymbolTable
* 功能描述：
* 访问的表：无
* 修改的表：无
* 输入参数：
* 输出参数：
* 返 回 值：
* 其它说明：无
* 修改日期      版本号  修改人      修改内容
* ---------------------------------------------------------------------
* 2011/06/01    V1.0    yq      创建
************************************************************************/
WORD32 DelSymbolTable(UCHAR ucRadioMode)
{
    if(bSymTabInitFlag[ucRadioMode] == TRUE)
    {
        XOS_Free((BYTE *)taSymTbl[ucRadioMode]);
        taSymTbl[ucRadioMode] = NULL;
        bSymTabInitFlag[ucRadioMode] = FALSE;
        ulSymTblSize[ucRadioMode] = 0;
        return OK;
    }
    else
    {
        return ERROR;
    }
}

/**********************************************************************
* 函数名称： FreeSymbolTable
* 功能描述： 清空所有符号表
* 访问的表：无
* 修改的表：无
* 输入参数：
* 输出参数：
* 返 回 值：
* 其它说明：无
* 修改日期      版本号  修改人      修改内容
* ---------------------------------------------------------------------
* 2019/03/28    V1.0    宋志强10099236     创建
************************************************************************/
WORD32 FreeSymbolTable()
{
    int i = 0;
    for(i = 0; i <RADIOMODE_MAX; i++)
    {
        DelSymbolTable(i);
    }
    return OK;
}

unsigned short g_cpu_Family = 0;
unsigned short OSS_GetCPUFamily(void)
{
    return g_cpu_Family;
}
INT OSS_GetEndianType(void)
{
	return g_iEndianType;
}

/**********************************************************************
* 函数名称：OpenCurrentELF
* 功能描述：
* 访问的表：无
* 修改的表：无
* 输入参数：
* 输出参数：
* 返 回 值：
* 其它说明：无
* 修改日期      版本号  修改人      修改内容
* ---------------------------------------------------------------------
* 2008/05/05    V1.0    张文剑      创建
************************************************************************/
static INT OpenCurrentELF(CHAR *filename, UCHAR ucRadioMode)
{
    INT fd;
    #ifdef SUPPORT_64BIT
    Elf64_Ehdr elfHdr;
    #else
    #if(CPU_FAMILY==I80X86||CPU_FAMILY==POWERPC||CPU_FAMILY==ARM||CPU_FAMILY== MIPS)
    Elf32_Ehdr elfHdr;
    #endif
    #if((CPU_FAMILY == IA64) || (CPU_FAMILY== MIPS64) || (CPU_FAMILY == ARM64))
    Elf64_Ehdr elfHdr;
    #endif
    #endif
    fd = open(filename, S_IRUSR);
    if (fd < 0)
    {
        printf("\nOpenCurrentELF open file error: %s\n",filename);
        return ERROR;
    }

    if (OK != VerifyELFHeader (fd, &elfHdr))
    {
        PERR;
        close(fd);
        return ERROR;
    }

    B2L2 (elfHdr.e_type);
    B2L2 (elfHdr.e_machine);
	if(0 == g_cpu_Family)
	{
		g_cpu_Family = elfHdr.e_machine;
	}

    #ifdef SUPPORT_64BIT
    B2L8 (elfHdr.e_shoff);
    #else
    #if(CPU_FAMILY==I80X86||CPU_FAMILY==POWERPC||CPU_FAMILY==ARM ||CPU_FAMILY==MIPS)
    B2L4 (elfHdr.e_shoff);
    #endif
    #if((CPU_FAMILY == IA64) || (CPU_FAMILY== MIPS64) || (CPU_FAMILY == ARM64))
    B2L8 (elfHdr.e_shoff);
    #endif
    #endif
    B2L2 (elfHdr.e_shentsize);
    B2L2 (elfHdr.e_shnum);
    B2L2 (elfHdr.e_shstrndx);

    if (OK != BuildSymTable(&elfHdr, fd, ucRadioMode))
    {
        close(fd);
        return ERROR;
    }

    close(fd);
    return OK;
}
#ifdef SUPPORT_64BIT
/**********************************************************************
* 函数名称：BuildSymTable
* 功能描述：
* 访问的表：无
* 修改的表：无
* 输入参数：
* 输出参数：
* 返 回 值：
* 其它说明：无
* 修改日期      版本号  修改人      修改内容
* ---------------------------------------------------------------------
* 2008/05/05    V1.0    张文剑      创建
************************************************************************/
INT BuildSymTable(Elf64_Ehdr *elfHdr, INT fd, UCHAR ucRadioMode)
{
    INT i;
    WORD64 ret;
    WORD64 iSymStrTabOffset = 0;   /* .strtab偏移 */
    WORD64 iSymStrTabSize = 0;     /* .strtab大小 */
    WORD64 iSymTabOffset = 0;      /* .symtab偏移 */
    WORD64 iSymTabSize = 0;         /* .symtab大小 */
    WORD64 iSymTabEntSize = 0;    /* .symtab中entry的大小 */

    Elf64_Shdr secHdr;                /* section header 结构 */
    Elf64_Shdr shSecNameStrTab; /* .shstrtab section header */
#if 0
    Elf64_Shdr shSymStrTab;        /* .strtab section header */
    Elf64_Shdr shSymTab;            /* .symtab section header */
#endif
    CHAR *pSecNameStrTab = NULL;  /* .shstrtab */
    CHAR *pSymStrTab = NULL;      /* .strtab */
    CHAR *pSymTab = NULL;            /* .symtab */

    /* 找到.shstrtab section header */
    ret=lseek(fd, elfHdr->e_shoff + sizeof(Elf64_Shdr)*(elfHdr->e_shstrndx),SEEK_SET);
    if(-1==ret)
    {
        printf("BuildSymTable lseek failed!errno:%d\n",errno);
        return ERROR;
    }
    printf("BuildSymTable lseek !errno:%d,fd=%d,elfHdr->e_shoff=%ld,sizeof(Elf64_Shdr)*(elfHdr->e_shstrndx) =%ld\n",
              errno,fd,elfHdr->e_shoff,sizeof(Elf64_Shdr)*(elfHdr->e_shstrndx));

    ret=read(fd, &shSecNameStrTab, sizeof(Elf64_Shdr));
    if ( -1 == ret||0 == ret)
    {
        printf("BuildSymTable888 read failed!errno:%d\n",errno);
         return ERROR;
    }
    B2L4 (shSecNameStrTab.sh_name);
    B2L4 (shSecNameStrTab.sh_type);
    B2L8 (shSecNameStrTab.sh_offset);
    B2L8 (shSecNameStrTab.sh_addr);
    B2L8 (shSecNameStrTab.sh_addralign);
    B2L8 (shSecNameStrTab.sh_size);
    B2L8 (shSecNameStrTab.sh_entsize);

    /* 根据.shstrtab section header得到.shstrtab section的偏移和大小 */
    /* 从而将.shstrtab section读入pSecNameStrTab */
    pSecNameStrTab = (CHAR*)XOS_Malloc(shSecNameStrTab.sh_size);
    if (NULL == pSecNameStrTab)
    {
        return ERROR;
    }
    ret=lseek(fd, shSecNameStrTab.sh_offset, SEEK_SET);
    if(-1==ret)
    {
        XOS_Free(pSecNameStrTab);
        printf("BuildSymTable lseek failed!errno:%d\n",errno);
        return ERROR;
    }
    ret=read(fd, pSecNameStrTab, shSecNameStrTab.sh_size);
    if ( -1 == ret||0 == ret)
    {
        XOS_Free(pSecNameStrTab);
        printf("BuildSymTable000 read failed!errno:%d\n",errno);
         return ERROR;
    }
    /* 遍历各个section header，得到.strtab和.symtab的偏移和大小 */
    /* 其间各个section的名称都可以在.shstrtab section中找到 */
    ret=lseek(fd, elfHdr->e_shoff, SEEK_SET);
    if(-1==ret)
    {
        XOS_Free(pSecNameStrTab);
        printf("BuildSymTable lseek failed!errno:%d\n",errno);
        return ERROR;
    }
    for (i = 0; i < elfHdr->e_shnum; i++)
    {
        ret=read(fd, &secHdr, sizeof(secHdr));
        if ( -1 == ret||0 == ret)
        {
            XOS_Free(pSecNameStrTab);
            printf("BuildSymTable111 read failed!errno:%d\n",errno);
         return ERROR;
        }
        B2L4 (secHdr.sh_name);
        B2L4 (secHdr.sh_type);
        B2L8 (secHdr.sh_offset);
        B2L8 (secHdr.sh_addr);
        B2L8 (secHdr.sh_addralign);
        B2L8 (secHdr.sh_size);
        B2L8 (secHdr.sh_entsize);

        /* 记录节名 */
        /*strcpy (&s_aSecNames[i][0], &pSecNameStrTab[secHdr.sh_name]);*/
        strncpy (&s_aSecNames[ucRadioMode][i][0], &pSecNameStrTab[secHdr.sh_name],MAX_SEC_NAME_LEN);

        /* 找到.strtab section的偏移和大小 */
        if ((SHT_STRTAB == secHdr.sh_type) && (0 == strncmp(".strtab", &pSecNameStrTab[secHdr.sh_name], 7)))
        {
            iSymStrTabOffset = secHdr.sh_offset; /* 节区的第一个字节与文件头之间的偏移 */
            iSymStrTabSize = secHdr.sh_size;      /* 节区的长度（字节数） */
            continue;
        }
        /* 找到.symtab section的偏移和大小 */
        if ((SHT_SYMTAB == secHdr.sh_type) && (0 == strncmp(".symtab", &pSecNameStrTab[secHdr.sh_name], 7)))
        {
            iSymTabOffset = secHdr.sh_offset;  /* 节区的第一个字节与文件头之间的偏移 */
            iSymTabSize = secHdr.sh_size;       /* 节区的长度（字节数） */
            iSymTabEntSize = secHdr.sh_entsize; /* 某些节区中包含固定大小的项目，如符号表。对于这类节区，此成员给出每个表项的长度字节数。 */
            continue;
        }
    }

    /* 读出.strtab section至pSymStrTable */
    pSymStrTab = (CHAR*)XOS_Malloc(iSymStrTabSize);
    if (NULL == pSymStrTab)
    {
        XOS_Free((BYTE*)pSecNameStrTab);
        return ERROR;
    }
    ret=lseek(fd, iSymStrTabOffset, SEEK_SET);
    if(-1==ret)
    {
        XOS_Free(pSecNameStrTab);
        XOS_Free(pSymStrTab);
        printf("BuildSymTable lseek failed!errno:%d\n",errno);
        return ERROR;
    }
    ret=read(fd, pSymStrTab, iSymStrTabSize);
    if ( -1 == ret||0 == ret)
    {
        XOS_Free(pSecNameStrTab);
        XOS_Free(pSymStrTab);
        printf("BuildSymTable222 read failed!errno:%d\n",errno);
         return ERROR;
    }
    /* 读出.symtab section至pSymTab */
    pSymTab = (CHAR*)XOS_Malloc(iSymTabSize);
    if (NULL == pSymTab)
    {
        XOS_Free((BYTE*)pSecNameStrTab);
        XOS_Free((BYTE*)pSymStrTab);
        return ERROR;
    }
    ret=lseek(fd, iSymTabOffset, SEEK_SET);
    if(-1==ret)
    {
        XOS_Free(pSecNameStrTab);
        XOS_Free(pSymStrTab);
        XOS_Free(pSymTab);
        printf("BuildSymTable lseek failed!errno:%d\n",errno);
        return ERROR;
    }
    ret=read(fd, pSymTab, iSymTabSize);
    if ( -1 == ret||0 == ret)
    {
        XOS_Free(pSecNameStrTab);
        XOS_Free(pSymStrTab);
        XOS_Free(pSymTab);
        printf("BuildSymTable333 read failed!errno:%d\n",errno);
         return ERROR;
    }

    /* 下面进入符号表提取符号： */
    INT iSymTabEntryNum = iSymTabSize / iSymTabEntSize;  /* .symtab中entry的数量 */

    /* 用在循环体中，指向.symtab中当前处理的entry */
    Elf64_Sym *pSymEnt = (Elf64_Sym*)pSymTab;

    /* 计算FUNCTION和OBJECT符号的数量 */
    ulSymTblSize[ucRadioMode] = 0;
    for (i = 0; i < iSymTabEntryNum; i++)
    {
        if  ((STT_FUNC == ELF64_ST_TYPE(pSymEnt->st_info) || (STT_OBJECT == ELF64_ST_TYPE(pSymEnt->st_info))) &&
            isOurConcernedSection(pSymEnt->st_shndx,ucRadioMode) &&
            0 != pSymEnt->st_shndx)
        {
            ulSymTblSize[ucRadioMode]++;
        }
        pSymEnt++;
    }

    /*
    printf("symbols string table size: %d bytes\n",iSymStrTabSize);
    printf("%d symbols will be fectched!\n",ulSymTblSize);
    */

    /* 根据需要提取的符号数量，分配存放符号的内存 */
    taSymTbl[ucRadioMode] = (SYMBOL_ENT*)XOS_Malloc(ulSymTblSize[ucRadioMode] *sizeof(SYMBOL_ENT));
    if (NULL == taSymTbl[ucRadioMode])
    {
        XOS_Free((BYTE*)pSecNameStrTab);
        XOS_Free((BYTE*)pSymStrTab);
        XOS_Free((BYTE*)pSymTab);
        return ERROR;
    }
    SYMBOL_ENT *pCurMemForSym = taSymTbl[ucRadioMode];  /* 指向上面分配的符号表空间，用来接收符号 */

    /* 提取符号到分配好的内存中去 */
    pSymEnt = (Elf64_Sym*)pSymTab;          /* 循环体中指向.symtab中当前符号的指针 */
    for (i = 0; i < iSymTabEntryNum; i++)
    {
        /* STT_OBJECT == ELF64_ST_TYPE(pSymEnt->st_info) */
        if  ((STT_FUNC == ELF64_ST_TYPE(pSymEnt->st_info) || (STT_OBJECT == ELF64_ST_TYPE(pSymEnt->st_info))) &&
              isOurConcernedSection(pSymEnt->st_shndx,ucRadioMode))

        {
            pCurMemForSym->name = &pSymStrTab[pSymEnt->st_name];
            pCurMemForSym->addr = (CHAR*)pSymEnt->st_value;
            pCurMemForSym->type = ELF64_ST_TYPE(pSymEnt->st_info);
            pCurMemForSym->size = pSymEnt->st_size;
            pCurMemForSym++;
        }
        pSymEnt++;
    }/* end for loop */

    /* 对符号表进行排序，使得symFindByValue函数中可以折半查找 */
    SortSymbolTable(taSymTbl[ucRadioMode], ulSymTblSize[ucRadioMode]);

    /* 释放堆内存 */
    if(pSecNameStrTab)
    {
        XOS_Free((BYTE*)pSecNameStrTab);
    }

    if(pSymStrTab)
    {
        /* 符号字符串的实际存放位置，不能释放 */
        /* XOS_Free(pSymStrTab); */
    }

    if(pSymTab)
    {
        XOS_Free((BYTE*)pSymTab);
    }
    bSymTabInitFlag[ucRadioMode] = TRUE;
    return OK;
}
#else
#if(CPU_FAMILY==I80X86||CPU_FAMILY==POWERPC||CPU_FAMILY==ARM ||CPU_FAMILY== MIPS)
VOID ClearOneUninitializedSymMem(CHAR *pucSymAddr, WORD32 dwSymSize)
{
    WORD32 dwLoop;
    CHAR   *pTmpAddr;

    if ((NULL == pucSymAddr) || (0 == dwSymSize))
    {
        return;
    }

    pTmpAddr = pucSymAddr;

    for (dwLoop = 0; dwLoop < dwSymSize; dwLoop++)
    {
        if (0 != *(pTmpAddr + dwLoop))
        {
            printf("SymAddr:%p, SymSize:%d is already initialized!\n", pucSymAddr, dwSymSize);
            break;
        }
        *(pTmpAddr + dwLoop) = 0;
    }
}
/**********************************************************************
* 函数名称：BuildSymTable
* 功能描述：
* 访问的表：无
* 修改的表：无
* 输入参数：
* 输出参数：
* 返 回 值：
* 其它说明：无
* 修改日期      版本号  修改人      修改内容
* ---------------------------------------------------------------------
* 2008/05/05    V1.0    张文剑      创建
************************************************************************/
INT BuildSymTable(Elf32_Ehdr *elfHdr, INT fd, UCHAR ucRadioMode)
{
    INT i;
    INT ret;
    INT iSymStrTabOffset = 0;   /* .strtab偏移 */
    INT iSymStrTabSize = 0;     /* .strtab大小 */
    INT iSymTabOffset = 0;      /* .symtab偏移 */
    INT iSymTabSize = 0;         /* .symtab大小 */
    INT iSymTabEntSize = 0;    /* .symtab中entry的大小 */
    INT iSymTabEntryNum = 0;
    Elf32_Shdr secHdr;                /* section header 结构 */
    Elf32_Shdr shSecNameStrTab; /* .shstrtab section header */
#if 0
    Elf32_Shdr shSymStrTab;        /* .strtab section header */
    Elf32_Shdr shSymTab;            /* .symtab section header */
#endif
    CHAR *pSecNameStrTab = NULL;  /* .shstrtab */
    CHAR *pSymStrTab = NULL;      /* .strtab */
    CHAR *pSymTab = NULL;            /* .symtab */

    /* 找到.shstrtab section header */
    ret=lseek(fd, elfHdr->e_shoff + sizeof(Elf32_Shdr)*(elfHdr->e_shstrndx),SEEK_SET);
    if(-1==ret)
    {
        printf("BuildSymTable lseek failed!errno:%d\n", errno);//errno);
        return ERROR;
    }
    ret=read(fd, &shSecNameStrTab, sizeof(Elf32_Shdr));
    if ( -1 == ret||0 == ret)
    {
        printf("BuildSymTable read failed!errno:%d\n",errno);
         return ERROR;
    }
    B2L4 (shSecNameStrTab.sh_name);
    B2L4 (shSecNameStrTab.sh_type);
    B2L4 (shSecNameStrTab.sh_offset);
    B2L4 (shSecNameStrTab.sh_addr);
    B2L4 (shSecNameStrTab.sh_addralign);
    B2L4 (shSecNameStrTab.sh_size);
    B2L4 (shSecNameStrTab.sh_entsize);

    /* 根据.shstrtab section header得到.shstrtab section的偏移和大小 */
    /* 从而将.shstrtab section读入pSecNameStrTab */
    pSecNameStrTab = (CHAR*)XOS_Malloc(shSecNameStrTab.sh_size);
    if (NULL == pSecNameStrTab)
    {
        return ERROR;
    }
    ret=lseek(fd, shSecNameStrTab.sh_offset, SEEK_SET);
    if(-1==ret)
    {
        XOS_Free(pSecNameStrTab);
        printf("BuildSymTable lseek failed!errno:%d\n",errno);
    return ERROR;
    }
    ret=zte_read_s(fd, pSecNameStrTab, shSecNameStrTab.sh_size, shSecNameStrTab.sh_size);
    if ( -1 == ret||0 == ret)
    {
        XOS_Free(pSecNameStrTab);
        printf("BuildSymTable read failed!errno:%d\n",errno);
         return ERROR;
    }
    /* 遍历各个section header，得到.strtab和.symtab的偏移和大小 */
    /* 其间各个section的名称都可以在.shstrtab section中找到 */
    ret=lseek(fd, elfHdr->e_shoff, SEEK_SET);
    if(-1==ret)
    {
        XOS_Free(pSecNameStrTab);
        printf("BuildSymTable lseek failed!errno:%d\n",errno);
    return ERROR;
    }
    for (i = 0; i < elfHdr->e_shnum; i++)
    {
        ret=read(fd, &secHdr, sizeof(secHdr));
        if ( -1 == ret||0 == ret)
        {
            XOS_Free(pSecNameStrTab);
            printf("BuildSymTable read failed!errorno = %d\n",errno);
             return ERROR;
        }
        B2L4 (secHdr.sh_name);
        B2L4 (secHdr.sh_type);
        B2L4 (secHdr.sh_offset);
        B2L4 (secHdr.sh_addr);
        B2L4 (secHdr.sh_addralign);
        B2L4 (secHdr.sh_size);
        B2L4 (secHdr.sh_entsize);

        /* 记录节名 */
       strncpy_s (&s_aSecNames[ucRadioMode][i][0],MAX_SEC_NAME_LEN, &pSecNameStrTab[secHdr.sh_name],MAX_SEC_NAME_LEN);

        /* 找到.strtab section的偏移和大小 */
        if ((SHT_STRTAB == secHdr.sh_type) && (0 == strncmp(".strtab", &pSecNameStrTab[secHdr.sh_name], 7)))
        {
            iSymStrTabOffset = secHdr.sh_offset; /* 节区的第一个字节与文件头之间的偏移 */
            iSymStrTabSize = secHdr.sh_size;      /* 节区的长度（字节数） */
            continue;
        }
        /* 找到.symtab section的偏移和大小 */
        if ((SHT_SYMTAB == secHdr.sh_type) && (0 == strncmp(".symtab", &pSecNameStrTab[secHdr.sh_name], 7)))
        {
            iSymTabOffset = secHdr.sh_offset;  /* 节区的第一个字节与文件头之间的偏移 */
            iSymTabSize = secHdr.sh_size;       /* 节区的长度（字节数） */
            iSymTabEntSize = secHdr.sh_entsize; /* 某些节区中包含固定大小的项目，如符号表。对于这类节区，此成员给出每个表项的长度字节数。 */
            continue;
        }
    }

    /* 读出.strtab section至pSymStrTable */
    if (iSymStrTabSize <= 0)
    {
        XOS_Free((BYTE *)pSecNameStrTab);
        return ERROR;
    }
    pSymStrTab = (CHAR*)XOS_Malloc(iSymStrTabSize);
    if (NULL == pSymStrTab)
    {
        XOS_Free((BYTE *)pSecNameStrTab);
        return ERROR;
    }
    ret=lseek(fd, iSymStrTabOffset, SEEK_SET);
    if(-1==ret)
    {
        XOS_Free((BYTE *)pSecNameStrTab);
        XOS_Free((BYTE *)pSymStrTab);
        printf("BuildSymTable lseek failed!errno:%d\n",errno);
    return ERROR;
    }
    ret=read(fd, pSymStrTab, iSymStrTabSize);
    if ( -1 == ret||0 == ret)
    {
        XOS_Free((BYTE *)pSecNameStrTab);
        XOS_Free((BYTE *)pSymStrTab);
        printf("BuildSymTable read failed!errno:%d\n",errno);
         return ERROR;
    }
    /* 读出.symtab section至pSymTab */
    pSymTab = (CHAR*)XOS_Malloc(iSymTabSize);
    if (NULL == pSymTab)
    {
        XOS_Free((BYTE *)pSecNameStrTab);
        XOS_Free((BYTE *)pSymStrTab);
        return ERROR;
    }
    ret=lseek(fd, iSymTabOffset, SEEK_SET);
    if(-1==ret)
    {
        XOS_Free((BYTE *)pSecNameStrTab);
        XOS_Free((BYTE *)pSymStrTab);
        XOS_Free((BYTE *)pSymTab);
        printf("BuildSymTable lseek failed!errno:%d\n",errno);
    return ERROR;
    }
    ret=read(fd, pSymTab, iSymTabSize);
    if ( -1 == ret||0 == ret)
    {
        XOS_Free((BYTE *)pSecNameStrTab);
        XOS_Free((BYTE *)pSymStrTab);
        XOS_Free((BYTE *)pSymTab);
        printf("BuildSymTable read failed!errno:%d\n",errno);
         return ERROR;
    }
    /* 下面进入符号表提取符号： */
    if(iSymTabEntSize != 0)
    {
        iSymTabEntryNum = iSymTabSize / iSymTabEntSize;  /* .symtab中entry的数量 */
    }
    /* 用在循环体中，指向.symtab中当前处理的entry */
    Elf32_Sym *pSymEnt = (Elf32_Sym*)pSymTab;

    /* 计算FUNCTION和OBJECT符号的数量 */
    ulSymTblSize[ucRadioMode] = 0;
    for (i = 0; i < iSymTabEntryNum; i++)
    {
        if  ((STT_FUNC == ELF32_ST_TYPE(pSymEnt->st_info) || (STT_OBJECT == ELF32_ST_TYPE(pSymEnt->st_info))) &&
            isOurConcernedSection(pSymEnt->st_shndx, ucRadioMode) &&
            0 != pSymEnt->st_shndx)
        {
            ulSymTblSize[ucRadioMode]++;
        }
        pSymEnt++;
    }

    /*
    printf("symbols string table size: %d bytes\n",iSymStrTabSize);
    printf("%d symbols will be fectched!\n",ulSymTblSize);
    */

    /* 根据需要提取的符号数量，分配存放符号的内存 */
    taSymTbl[ucRadioMode] = (SYMBOL_ENT*)XOS_Malloc(ulSymTblSize[ucRadioMode] *sizeof(SYMBOL_ENT));
    if (NULL == taSymTbl[ucRadioMode])
    {
        XOS_Free((BYTE *)pSecNameStrTab);
        XOS_Free((BYTE *)pSymStrTab);
        XOS_Free((BYTE *)pSymTab);
        return ERROR;
    }
    SYMBOL_ENT *pCurMemForSym = taSymTbl[ucRadioMode];  /* 指向上面分配的符号表空间，用来接收符号 */

    /* 提取符号到分配好的内存中去 */
    pSymEnt = (Elf32_Sym*)pSymTab;          /* 循环体中指向.symtab中当前符号的指针 */
    for (i = 0; i < iSymTabEntryNum; i++)
    {
        /* STT_OBJECT == ELF32_ST_TYPE(pSymEnt->st_info) */
        if  ((STT_FUNC == ELF32_ST_TYPE(pSymEnt->st_info) || (STT_OBJECT == ELF32_ST_TYPE(pSymEnt->st_info))) &&
              isOurConcernedSection(pSymEnt->st_shndx, ucRadioMode))

        {
            pCurMemForSym->name = &pSymStrTab[pSymEnt->st_name];
            pCurMemForSym->addr = (CHAR*)pSymEnt->st_value;
            pCurMemForSym->type = ELF32_ST_TYPE(pSymEnt->st_info);
            pCurMemForSym->size = pSymEnt->st_size;

           /* 宋志强10099236 屏蔽： 从oss 下移到common中时候暂时屏蔽这个功能。
            if (TRUE == R_IsMemUseDebugEnable())
            {
                if ((STT_OBJECT == ELF32_ST_TYPE(pSymEnt->st_info)) && isCurSectionBSS(pSymEnt->st_shndx, ucRadioMode))
                {
                    ClearOneUninitializedSymMem((CHAR *)pSymEnt->st_value, pSymEnt->st_size);
                }
            }
            */

            pCurMemForSym++;
        }
        pSymEnt++;
    }/* end for loop */

    /* 对符号表进行排序，使得symFindByValue函数中可以折半查找 */
    SortSymbolTable(taSymTbl[ucRadioMode], ulSymTblSize[ucRadioMode]);

    /* 释放堆内存 */
    if(pSecNameStrTab)
    {
        XOS_Free((BYTE *)pSecNameStrTab);
    }

    if(pSymStrTab)
    {
        /* 符号字符串的实际存放位置，不能释放 */
        /* XOS_Free(pSymStrTab); */
    }

    if(pSymTab)
    {
        XOS_Free((BYTE *)pSymTab);
    }
    bSymTabInitFlag[ucRadioMode] = TRUE;
    return OK;
}
#endif


#if((CPU_FAMILY == IA64) || (CPU_FAMILY== MIPS64) || (CPU_FAMILY == ARM64))
/**********************************************************************
* 函数名称：BuildSymTable
* 功能描述：
* 访问的表：无
* 修改的表：无
* 输入参数：
* 输出参数：
* 返 回 值：
* 其它说明：无
* 修改日期      版本号  修改人      修改内容
* ---------------------------------------------------------------------
* 2008/05/05    V1.0    张文剑      创建
************************************************************************/
INT BuildSymTable(Elf64_Ehdr *elfHdr, INT fd, UCHAR ucRadioMode)
{
    INT i;
    WORD64 ret;
    WORD64 iSymStrTabOffset = 0;   /* .strtab偏移 */
    WORD64 iSymStrTabSize = 0;     /* .strtab大小 */
    WORD64 iSymTabOffset = 0;      /* .symtab偏移 */
    WORD64 iSymTabSize = 0;         /* .symtab大小 */
    WORD64 iSymTabEntSize = 0;    /* .symtab中entry的大小 */
    INT iSymTabEntryNum = 0;

    Elf64_Shdr secHdr;                /* section header 结构 */
    Elf64_Shdr shSecNameStrTab; /* .shstrtab section header */
#if 0
    Elf64_Shdr shSymStrTab;        /* .strtab section header */
    Elf64_Shdr shSymTab;            /* .symtab section header */
#endif
    CHAR *pSecNameStrTab = NULL;  /* .shstrtab */
    CHAR *pSymStrTab = NULL;      /* .strtab */
    CHAR *pSymTab = NULL;            /* .symtab */

    /* 找到.shstrtab section header */
    ret=lseek(fd, elfHdr->e_shoff + sizeof(Elf64_Shdr)*(elfHdr->e_shstrndx),SEEK_SET);
    if(-1==ret)
    {
        printf("BuildSymTable lseek failed!errno:%d\n",errno);
        return ERROR;
    }
    ret=read(fd, &shSecNameStrTab, sizeof(Elf64_Shdr));
    if ( -1 == ret||0 == ret)
    {
        printf("BuildSymTable read failed!errno:%d\n",errno);
         return ERROR;
    }
    B2L4 (shSecNameStrTab.sh_name);
    B2L4 (shSecNameStrTab.sh_type);
    B2L8 (shSecNameStrTab.sh_offset);
    B2L8 (shSecNameStrTab.sh_addr);
    B2L8 (shSecNameStrTab.sh_addralign);
    B2L8 (shSecNameStrTab.sh_size);
    B2L8 (shSecNameStrTab.sh_entsize);

    /* 根据.shstrtab section header得到.shstrtab section的偏移和大小 */
    /* 从而将.shstrtab section读入pSecNameStrTab */
    pSecNameStrTab = (CHAR*)XOS_Malloc(shSecNameStrTab.sh_size);
    if (NULL == pSecNameStrTab)
    {
        return ERROR;
    }
    ret=lseek(fd, shSecNameStrTab.sh_offset, SEEK_SET);
    if(-1==ret)
    {
        XOS_Free(pSecNameStrTab);
        printf("BuildSymTable lseek failed!errno:%d\n",errno);
        return ERROR;
    }
    ret=read(fd, pSecNameStrTab, shSecNameStrTab.sh_size);
    if ( -1 == ret||0 == ret)
    {
        XOS_Free(pSecNameStrTab);
        printf("BuildSymTable read failed!errno:%d\n",errno);
         return ERROR;
    }
    /* 遍历各个section header，得到.strtab和.symtab的偏移和大小 */
    /* 其间各个section的名称都可以在.shstrtab section中找到 */
    ret=lseek(fd, elfHdr->e_shoff, SEEK_SET);
    if(-1==ret)
    {
        XOS_Free(pSecNameStrTab);
        printf("BuildSymTable lseek failed!errno:%d\n",errno);
        return ERROR;
    }
    for (i = 0; i < elfHdr->e_shnum; i++)
    {
        ret=read(fd, &secHdr, sizeof(secHdr));
        if ( -1 == ret||0 == ret)
        {
            XOS_Free(pSecNameStrTab);
            printf("BuildSymTable read failed!errno:%d\n",errno);
         return ERROR;
        }
        B2L4 (secHdr.sh_name);
        B2L4 (secHdr.sh_type);
        B2L8 (secHdr.sh_offset);
        B2L8 (secHdr.sh_addr);
        B2L8 (secHdr.sh_addralign);
        B2L8 (secHdr.sh_size);
        B2L8 (secHdr.sh_entsize);

        /* 记录节名 */
        /*strcpy (&s_aSecNames[i][0], &pSecNameStrTab[secHdr.sh_name]);*/
        strncpy (&s_aSecNames[ucRadioMode][i][0], &pSecNameStrTab[secHdr.sh_name],MAX_SEC_NAME_LEN);

        /* 找到.strtab section的偏移和大小 */
        if ((SHT_STRTAB == secHdr.sh_type) && (0 == strncmp(".strtab", &pSecNameStrTab[secHdr.sh_name], 7)))
        {
            iSymStrTabOffset = secHdr.sh_offset; /* 节区的第一个字节与文件头之间的偏移 */
            iSymStrTabSize = secHdr.sh_size;      /* 节区的长度（字节数） */
            continue;
        }
        /* 找到.symtab section的偏移和大小 */
        if ((SHT_SYMTAB == secHdr.sh_type) && (0 == strncmp(".symtab", &pSecNameStrTab[secHdr.sh_name], 7)))
        {
            iSymTabOffset = secHdr.sh_offset;  /* 节区的第一个字节与文件头之间的偏移 */
            iSymTabSize = secHdr.sh_size;       /* 节区的长度（字节数） */
            iSymTabEntSize = secHdr.sh_entsize; /* 某些节区中包含固定大小的项目，如符号表。对于这类节区，此成员给出每个表项的长度字节数。 */
            continue;
        }
    }

    /* 读出.strtab section至pSymStrTable */
    pSymStrTab = (CHAR*)XOS_Malloc(iSymStrTabSize);
    if (NULL == pSymStrTab)
    {
        XOS_Free((BYTE*)pSecNameStrTab);
        return ERROR;
    }
    ret=lseek(fd, iSymStrTabOffset, SEEK_SET);
    if(-1==ret)
    {
        XOS_Free(pSecNameStrTab);
        XOS_Free(pSymStrTab);
        printf("BuildSymTable lseek failed!errno:%d\n",errno);
        return ERROR;
    }
    ret=read(fd, pSymStrTab, iSymStrTabSize);
    if ( -1 == ret||0 == ret)
    {
        XOS_Free(pSecNameStrTab);
        XOS_Free(pSymStrTab);
        printf("BuildSymTable read failed!errno:%d\n",errno);
         return ERROR;
    }
    /* 读出.symtab section至pSymTab */
    pSymTab = (CHAR*)XOS_Malloc(iSymTabSize);
    if (NULL == pSymTab)
    {
        XOS_Free((BYTE*)pSecNameStrTab);
        XOS_Free((BYTE*)pSymStrTab);
        return ERROR;
    }
    ret=lseek(fd, iSymTabOffset, SEEK_SET);
    if(-1==ret)
    {
        XOS_Free(pSecNameStrTab);
        XOS_Free(pSymStrTab);
        XOS_Free(pSymTab);
        printf("BuildSymTable lseek failed!errno:%d\n",errno);
        return ERROR;
    }
    ret=read(fd, pSymTab, iSymTabSize);
    if ( -1 == ret||0 == ret)
    {
        XOS_Free(pSecNameStrTab);
        XOS_Free(pSymStrTab);
        XOS_Free(pSymTab);
        printf("BuildSymTable read failed!errno:%d\n",errno);
         return ERROR;
    }

    /* 下面进入符号表提取符号： */
    if(iSymTabEntSize != 0)
    {
        iSymTabEntryNum = iSymTabSize / iSymTabEntSize;  /* .symtab中entry的数量 */
    }

    /* 用在循环体中，指向.symtab中当前处理的entry */
    Elf64_Sym *pSymEnt = (Elf64_Sym*)pSymTab;

    /* 计算FUNCTION和OBJECT符号的数量 */
    ulSymTblSize[ucRadioMode] = 0;
    for (i = 0; i < iSymTabEntryNum; i++)
    {
        if  ((STT_FUNC == ELF64_ST_TYPE(pSymEnt->st_info) || (STT_OBJECT == ELF64_ST_TYPE(pSymEnt->st_info))) &&
            isOurConcernedSection(pSymEnt->st_shndx,ucRadioMode) &&
            0 != pSymEnt->st_shndx)
        {
            ulSymTblSize[ucRadioMode]++;
        }
        pSymEnt++;
    }

    /*
    printf("symbols string table size: %d bytes\n",iSymStrTabSize);
    printf("%d symbols will be fectched!\n",ulSymTblSize);
    */

    /* 根据需要提取的符号数量，分配存放符号的内存 */
    taSymTbl[ucRadioMode] = (SYMBOL_ENT*)XOS_Malloc(ulSymTblSize[ucRadioMode] *sizeof(SYMBOL_ENT));
    if (NULL == taSymTbl[ucRadioMode])
    {
        XOS_Free((BYTE*)pSecNameStrTab);
        XOS_Free((BYTE*)pSymStrTab);
        XOS_Free((BYTE*)pSymTab);
        return ERROR;
    }
    SYMBOL_ENT *pCurMemForSym = taSymTbl[ucRadioMode];  /* 指向上面分配的符号表空间，用来接收符号 */

    /* 提取符号到分配好的内存中去 */
    pSymEnt = (Elf64_Sym*)pSymTab;          /* 循环体中指向.symtab中当前符号的指针 */
    for (i = 0; i < iSymTabEntryNum; i++)
    {
        /* STT_OBJECT == ELF64_ST_TYPE(pSymEnt->st_info) */
        if  ((STT_FUNC == ELF64_ST_TYPE(pSymEnt->st_info) || (STT_OBJECT == ELF64_ST_TYPE(pSymEnt->st_info))) &&
              isOurConcernedSection(pSymEnt->st_shndx,ucRadioMode))

        {
            pCurMemForSym->name = &pSymStrTab[pSymEnt->st_name];
            pCurMemForSym->addr = (CHAR*)pSymEnt->st_value;
            pCurMemForSym->type = ELF64_ST_TYPE(pSymEnt->st_info);
            pCurMemForSym->size = pSymEnt->st_size;
            pCurMemForSym++;
        }
        pSymEnt++;
    }/* end for loop */

    /* 对符号表进行排序，使得symFindByValue函数中可以折半查找 */
    SortSymbolTable(taSymTbl[ucRadioMode], ulSymTblSize[ucRadioMode]);

    /* 释放堆内存 */
    if(pSecNameStrTab)
    {
        XOS_Free((BYTE*)pSecNameStrTab);
    }

    if(pSymStrTab)
    {
        /* 符号字符串的实际存放位置，不能释放 */
        /* XOS_Free(pSymStrTab); */
    }

    if(pSymTab)
    {
        XOS_Free((BYTE*)pSymTab);
    }
    bSymTabInitFlag[ucRadioMode] = TRUE;
    return OK;
}
#endif
#endif

/**********************************************************************
* 函数名称：R_GetSymTblSize
* 功能描述：
* 访问的表：无
* 修改的表：无
* 输入参数：
* 输出参数：
* 返 回 值：
* 其它说明：无
* 修改日期      版本号  修改人      修改内容
* ---------------------------------------------------------------------
* 2008/05/05    V1.0    张文剑      创建
************************************************************************/
WORD32 R_GetSymTblSize(UCHAR ucRadioMode)
{
    if(!bSymTabInitFlag[ucRadioMode])
    {
        return 0;
    }

    return ulSymTblSize[ucRadioMode];
}

/**********************************************************************
* 函数名称：R_GetSym
* 功能描述：
* 访问的表：无
* 修改的表：无
* 输入参数：
* 输出参数：
* 返 回 值：
* 其它说明：无
* 修改日期      版本号  修改人      修改内容
* ---------------------------------------------------------------------
* 2008/05/05    V1.0    张文剑      创建
************************************************************************/
CHAR* R_GetSym(WORD32 dwindex, UCHAR ucRadioMode)
{

    if(!bSymTabInitFlag[ucRadioMode] || dwindex > ulSymTblSize[ucRadioMode])
    {
        return NULL;
    }

    return taSymTbl[ucRadioMode][dwindex].name;
}

/**********************************************************************
* 函数名称：PrintSymTable
* 功能描述：
* 访问的表：无
* 修改的表：无
* 输入参数：
* 输出参数：
* 返 回 值：
* 其它说明：无
* 修改日期      版本号  修改人      修改内容
* ---------------------------------------------------------------------
* 2008/05/05    V1.0    张文剑      创建
************************************************************************/
VOID PrintSymTableEx(UCHAR ucRadioMode)
{
    INT i = 0;
    if(taSymTbl[ucRadioMode] == NULL)
    {
        printf("symbol table not ready!\n");
        return;
    }
    printf("\nOutput %d symbols ... ...\n",ulSymTblSize[ucRadioMode]);

    printf("%5s %20s %5s\n","index","name","addr");
    for (i = 0; i < ulSymTblSize[ucRadioMode]; i++)
    {
        printf("%5d %-20s %p\n",i,taSymTbl[ucRadioMode][i].name,taSymTbl[ucRadioMode][i].addr);
    }

    return ;
}

VOID PrintSymTable(VOID)
{
    PrintSymTableEx(SELF_MODE);
}

WORD32 symFindAttrByValueEx(WORDPTR value, CHAR *name, WORDPTR *pValue,
                         WORD32 *pType, WORD32 *pSize, UCHAR ucRadioMode)
{
    WORD32 wPosition;

    if (name == NULL || taSymTbl[ucRadioMode] == NULL)
    {
        return  (WORD32)(ERROR);
    }

    wPosition = symGetPosByValue(value, ucRadioMode);
    if ((WORD32)(ERROR) != wPosition)
    {
        if(NULL == taSymTbl[ucRadioMode][wPosition].name)
        {
            return (WORD32)(ERROR);
        }
        strncpy_s(name, 128, taSymTbl[ucRadioMode][wPosition].name, 128);
        if (pValue)
        {
            *pValue = (WORDPTR)(taSymTbl[ucRadioMode][wPosition].addr);
        }
        if (pType)
        {
            *pType = (WORD32)(taSymTbl[ucRadioMode][wPosition].type);
        }
        if(pSize)
        {
            *pSize = (WORD32)(taSymTbl[ucRadioMode][wPosition].size);
        }
        return (WORD32)(OK);
    }
    return (WORD32)(ERROR);
}

/**********************************************************************
* 函数名称：symFindByValue
* 功能描述：
* 访问的表：无
* 修改的表：无
* 输入参数：
* 输出参数：
* 返 回 值：
* 其它说明：无
* 修改日期      版本号  修改人      修改内容
* ---------------------------------------------------------------------
* 2008/05/05    V1.0    张文剑      创建
************************************************************************/

WORD32 symFindByValueEx(WORDPTR value, CHAR *name, WORDPTR *pValue, WORD32 *pType, UCHAR ucRadioMode)
{
    WORD32 dwSize;

    return symFindAttrByValueEx(value, name, pValue, pType, &dwSize, ucRadioMode);
}

WORD32 symFindAttrByValue(WORDPTR value, CHAR *name, WORDPTR *pValue,
                         WORD32 *pType, WORD32 *pSize)
{
    return symFindAttrByValueEx(value, name, pValue, pType, pSize, SELF_MODE);
}

WORD32 symFindByValue(WORDPTR value, CHAR *name, WORDPTR *pValue, WORD32 *pType)
{
    return symFindByValueEx(value, name, pValue, pType, SELF_MODE);
}

/**********************************************************************
* 函数名称：symFindByNameEx
* 功能描述：
* 访问的表：无
* 修改的表：无
* 输入参数：
* 输出参数：
* 返 回 值：
* 其它说明：无
* 修改日期      版本号  修改人      修改内容
* ---------------------------------------------------------------------
* 2008/05/05    V1.0    张文剑      创建
************************************************************************/
WORD32 symFindByNameEx(CHAR *name, WORDPTR *pValue, WORD32 *size, WORD32 *pType, UCHAR ucRadioMode)
{
    WORD32 num;
    WORD32 i;
    num = ulSymTblSize[ucRadioMode];
    if(taSymTbl[ucRadioMode] == NULL)
    {
        return  ERROR;
    }

    for (i = 0; i < num; i++)
    {
        if (strcmp(name, taSymTbl[ucRadioMode][i].name) == 0)
        {
            break;
        }
    }

    if (i >= num)
    {
        return  ERROR;
    }

    if (pValue)
    {
        *pValue = (WORDPTR)(taSymTbl[ucRadioMode][i].addr);
    }
    if (pType)
    {
        *pType = (WORD32)(taSymTbl[ucRadioMode][i].type);
    }
    if (size)
    {
        *size = (WORD32)(taSymTbl[ucRadioMode][i].size);
    }
    return OK;
}

WORD32 symFindByName(CHAR *name, WORDPTR *pValue, WORD32 *size, WORD32 *pType)
{
    return symFindByNameEx(name, pValue, size, pType, SELF_MODE);
}

/*******************************************************************************
*
* strMatch - find an occurrence of a string in another string
*
* This is a simple pattern matcher used by symPrint().  It looks for an
* occurence of <str2> in <str1> and returns a pointer to that occurrence in
* <str1>.  If it doesn't find one, it returns 0.
*/

char * strMatch(
    FAST char *str1,        /* where to look for match */
    FAST char *str2     /* string to find a match for */
    )
{
    FAST int str2Length = strlen (str2);
    FAST int ntries = strlen (str1) - str2Length;

    for (; ntries >= 0; str1++, --ntries)
    {
    if (strncmp (str1, str2, str2Length) == 0)
        return (str1);  /* we've found a match */
    }

    return (NULL);
}

/**********************************************************************
* 函数名称：symFindByName
* 功能描述：
* 访问的表：无
* 修改的表：无
* 输入参数：
* 输出参数：
* 返 回 值：
* 其它说明：无
* 修改日期      版本号  修改人      修改内容
* ---------------------------------------------------------------------
* 2008/05/05    V1.0    张文剑      创建
************************************************************************/
WORD32 symShowEx(CHAR *name, UCHAR ucRadioMode)
{
    WORD32 num;
    WORD32 i;
    num = ulSymTblSize[ucRadioMode];
    if(taSymTbl[ucRadioMode] == NULL)
    {
        return  ERROR;
    }

    for (i = 0; i < num; i++)
    {
        if (strMatch(taSymTbl[ucRadioMode][i].name,name) != NULL)
        {
#ifdef SUPPORT_64BIT
            printf("0x%016lx   %s\n",(OSS_LONG)taSymTbl[ucRadioMode][i].addr, taSymTbl[ucRadioMode][i].name);
#else
            printf("0x%08lx   %s\n",(OSS_LONG)taSymTbl[ucRadioMode][i].addr, taSymTbl[ucRadioMode][i].name);
#endif
        }
    }

    if (i >= num)
    {
        return  ERROR;
    }
    return OK;
}

WORD32 symShow(CHAR *name)
{
    return symShowEx(name,SELF_MODE);
}


WORDPTR symFindFuncEntrybyPcEx(OSS_ULONG  *pdwPc, OSS_ULONG *dwsymbolsize, OSS_ULONG *dwOffset, UCHAR ucRadioMode)
{
    WORDPTR   dwAddr;
    OSS_ULONG dwLow;
    OSS_ULONG dwHigh;
    OSS_ULONG dwMid;
    WORDPTR dwCurPc ;

    if(NULL == pdwPc)
    {
        printf("symGetFuncAddrbyPc : PC is NULL !! \n");
        return 0;
    }
    dwCurPc = (WORDPTR)pdwPc;
    dwHigh = ulSymTblSize[ucRadioMode];
    dwLow = 0;
  /*  printf("@@@ symGetFuncAddrbyPc@@@ \n");
    printf("@@@ dwCurPc = 0x%llx, dwHigh= %d,dwLow=%d\n", dwCurPc,dwHigh,dwLow); */
    while (dwHigh -dwLow >1 )
    {
        dwMid = (dwLow + dwHigh) / 2;
        dwAddr = (WORDPTR)taSymTbl[ucRadioMode][dwMid].addr;
        if (dwAddr <= dwCurPc)
        {
            dwLow = dwMid ;
        }
        else
        {
            dwHigh = dwMid ;
        }
    }
  /*  printf("@@@  dwLow = %d\n", dwLow);
    printf("@@@  Function Name is %s\n",taSymTbl[dwLow].name); */
    * dwsymbolsize = taSymTbl[ucRadioMode][dwLow].size;
    dwAddr = (WORDPTR)taSymTbl[ucRadioMode][dwLow].addr;
    * dwOffset = (OSS_ULONG)(dwCurPc - dwAddr);
 /*   printf("@@@ Function Entry is : 0x%llx\n", dwAddr); */
    return dwAddr;
}

WORDPTR symFindFuncEntrybyPc(OSS_ULONG  * pdwPc, OSS_ULONG * dwsymbolsize, OSS_ULONG *dwOffset)
{
    return symFindFuncEntrybyPcEx(pdwPc, dwsymbolsize, dwOffset,SELF_MODE);
}


/*****************************************************************************
 *  函数名称   : findFunNameByPcEx(*)
 *  功能描述   : 根据PC 指针获取函数名字
 *  读全局变量 : 无
 *  写全局变量 : 无
 *  输入参数   :
 *  输出参数   : 无
 *  返 回 值   : 成功 - BSP_OK
 *  其它说明   :
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *  $0000000(N/A), 姜建奎@2011-10-25 10:59:21
 *----------------------------------------------------------------------------
 */
OSS_ULONG findFunNameByPcEx(OSS_ULONG uladdr, CHAR * pcFunName, UCHAR ucRadioMode)
{
   OSS_ULONG ulret = 0;

   int ilen=0;

   if(NULL == pcFunName)
   {
       return ERROR;
   }

   ulret = symGetPosByValue(uladdr, ucRadioMode);

   if(ERROR == ulret)
   {
       printf("The Fun addr Maybe Error, Can not find the Function \n");

	return ERROR;
   }

   ilen = strlen(taSymTbl[ucRadioMode][ulret].name);

   memcpy(pcFunName,taSymTbl[ucRadioMode][ulret].name, ilen);

   return OK;
}


/*****************************************************************************
 *  函数名称   : findFunNameByPc(*)
 *  功能描述   : 根据PC 指针获取函数名字
 *  读全局变量 : 无
 *  写全局变量 : 无
 *  输入参数   :
 *  输出参数   : 无
 *  返 回 值   : 成功 - BSP_OK
 *  其它说明   :
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *  $0000000(N/A), 姜建奎@2011-10-25 10:59:21
 *----------------------------------------------------------------------------
 */
ULONG findFunNameByPc(ULONG uladdr, CHAR * pcFunName)
{
    return findFunNameByPcEx(uladdr, pcFunName, SELF_MODE);
}

/*****************************************************************************
 *  函数名称   : BspMatchFunname(*)
 *  功能描述   :  从符号表匹配是否存在改函数
 *  读全局变量 : 无
 *  写全局变量 : 无
 *  输入参数   : 函数名字
 *  输出参数   : 无
 *  返 回 值   : 成功 - BSP_OK
 *  其它说明   :
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *  $0000000(N/A), 姜建奎@2011-10-25 10:59:21
 *----------------------------------------------------------------------------
 */
ULONG matchFunNameEx(CHAR * pfunname, UCHAR ucRadioMode)
{
    WORD32 num;
    WORD32 i;
    num = ulSymTblSize[ucRadioMode];
    if(taSymTbl[ucRadioMode] == NULL)
    {
        return  ERROR;
    }

    for (i = 0; i < num; i++)
    {
        if (strcmp(pfunname, taSymTbl[ucRadioMode][i].name) == 0)
        {
            break;
        }
    }

    if (i >= num)
    {
        return  ERROR;
    }

    return OK;
}

ULONG matchFunName(CHAR * pfunName)
{
    return matchFunNameEx(pfunName, SELF_MODE);
}


/**********************************************************************
* 函数名称：
* 功能描述：
* 访问的表：无
* 修改的表：无
* 输入参数：
* 输出参数：
* 返 回 值：
* 其它说明：无
* 修改日期      版本号  修改人      修改内容
* ---------------------------------------------------------------------
* 2008/05/05    V1.0    张文剑      创建
************************************************************************/
static SIZE_T toLE(BYTE *p, INT size)
{
#ifdef SUPPORT_64BIT
    WORD64 val;
#endif
    WORD32 i;
    WORD16 s;
    if (g_iEndianType == ELFDATA2MSB)
    {
#ifdef SUPPORT_64BIT
        if (8 == size)
        {
            val = (p[0] << 56) + (p[1] << 48) + (p[2] << 40) + (p[3] << 32) + (p[4] << 24) + (p[5] << 16) + (p[6] << 8) + p[7];
            *(SIZE_T*)p = val;
        }
        else
#endif
        if (4 == size)
        {
            i = (p[0] << 24) + (p[1] << 16) + (p[2] << 8) + p[3];
            *(WORD32*)p = i;
        }
        else if (2 == size)
        {
            s = (p[0] << 8) + p[1];
            *(WORD16*)p = s;
        }
    }
    return 0;
}

#ifdef SUPPORT_64BIT
/**********************************************************************
* 函数名称：VerifyELFHeader
* 功能描述：验证ELF头
* 访问的表：无
* 修改的表：无
* 输入参数：
* 输出参数：
* 返 回 值：
* 其它说明：无
* 修改日期      版本号  修改人      修改内容
* ---------------------------------------------------------------------
* 2008/05/05    V1.0    张文剑      创建
************************************************************************/
static INT VerifyELFHeader(INT fd, Elf64_Ehdr *pHdr)
{
    INT iReadRv;
    INT iHdrSize;
    iHdrSize = sizeof(*pHdr);
    iReadRv = read(fd, (CHAR*)pHdr, iHdrSize);
    if (iReadRv != iHdrSize)
    {
        printf("iReadRv = %d\n", iReadRv);
        printf("Erroneous header read\n");
        return (ERROR);
    }
    /* Is it an ELF file? */
    if (strncmp((CHAR*)pHdr->e_ident, (CHAR*)ELFMAG, SELFMAG) != 0)
    {
        return (ERROR);
    }
    if (ELFDATA2MSB == pHdr->e_ident[EI_DATA])
    {
        g_iEndianType = ELFDATA2MSB;
    }
    else if (ELFDATA2LSB == pHdr->e_ident[EI_DATA])
    {
        g_iEndianType = ELFDATA2LSB;
    }
    else
    {
        PERR;
        printf("unknown endian type\n");
        return (ERROR);
    }
    return OK;
}
#else
#if(CPU_FAMILY==I80X86||CPU_FAMILY==POWERPC||CPU_FAMILY==ARM||CPU_FAMILY==MIPS)
/**********************************************************************
* 函数名称：VerifyELFHeader
* 功能描述：验证ELF文件头
* 访问的表：无
* 修改的表：无
* 输入参数：
* 输出参数：
* 返 回 值：
* 其它说明：无
* 修改日期      版本号  修改人      修改内容
* ---------------------------------------------------------------------
* 2008/05/05    V1.0    张文剑      创建
************************************************************************/
static INT VerifyELFHeader(INT fd, Elf32_Ehdr *pHdr)
{
    INT iReadRv;
    INT iHdrSize;
    iHdrSize = sizeof(*pHdr);
    iReadRv = zte_read_s(fd, (CHAR*)pHdr, iHdrSize, iHdrSize);
    if (iReadRv != iHdrSize)
    {
        printf("iReadRv = %d\n", iReadRv);
        printf("Erroneous header read\n");
        return (ERROR);
    }
    /* Is it an ELF file? */
    if (strncmp((CHAR*)pHdr->e_ident, (CHAR*)ELFMAG, SELFMAG) != 0)
    {
        return (ERROR);
    }
    if (ELFDATA2MSB == pHdr->e_ident[EI_DATA])
    {
        g_iEndianType = ELFDATA2MSB;
    }
    else if (ELFDATA2LSB == pHdr->e_ident[EI_DATA])
    {
        g_iEndianType = ELFDATA2LSB;
    }
    else
    {
        PERR;
        printf("unknown enidan type\n");
        return (ERROR);
    }
    return OK;
}
#endif

#if((CPU_FAMILY == IA64) || (CPU_FAMILY== MIPS64) || (CPU_FAMILY == ARM64))
/**********************************************************************
* 函数名称：VerifyELFHeader
* 功能描述：验证ELF头
* 访问的表：无
* 修改的表：无
* 输入参数：
* 输出参数：
* 返 回 值：
* 其它说明：无
* 修改日期      版本号  修改人      修改内容
* ---------------------------------------------------------------------
* 2008/05/05    V1.0    张文剑      创建
************************************************************************/
static INT VerifyELFHeader(INT fd, Elf64_Ehdr *pHdr)
{
    INT iReadRv;
    INT iHdrSize;
    iHdrSize = sizeof(*pHdr);
    iReadRv = read(fd, (CHAR*)pHdr, iHdrSize);
    if (iReadRv != iHdrSize)
    {
        printf("iReadRv = %d\n", iReadRv);
        printf("Erroneous header read\n");
        return (ERROR);
    }
    /* Is it an ELF file? */
    if (strncmp((CHAR*)pHdr->e_ident, (CHAR*)ELFMAG, SELFMAG) != 0)
    {
        return (ERROR);
    }
    if (ELFDATA2MSB == pHdr->e_ident[EI_DATA])
    {
        g_iEndianType = ELFDATA2MSB;
    }
    else if (ELFDATA2LSB == pHdr->e_ident[EI_DATA])
    {
        g_iEndianType = ELFDATA2LSB;
    }
    else
    {
        PERR;
        printf("unknown endian type\n");
        return (ERROR);
    }
    return OK;
}
#endif
#endif

/**********************************************************************
* 函数名称：isOurConcernedSection
* 功能描述：是否是我们需要关心的section
* 访问的表：无
* 修改的表：无
* 输入参数：
* 输出参数：
* 返 回 值：
* 其它说明：无
* 修改日期      版本号  修改人      修改内容
* ---------------------------------------------------------------------
* 2008/05/05    V1.0    张文剑      创建
************************************************************************/
static BOOLEAN isOurConcernedSection (INT section_index, UCHAR ucRadioMode)
{
    if(section_index >= MAX_SEC_NUM || section_index < 0)
    {
        return FALSE;
    }

    /* .text: 代码和常量 */
    /* .data: 已初始化数据 */
    /* .bss: 未初始化数据 */
    /* .sdata: 已初始化small数据，大小跟CPU体系有关 */
    /* .sbss: 未初始化small数据，大小跟CPU体系有关 */
    /* .tdata: 已初始化tls数据，ARM */
    /* .tbss: 未初始化tls数据，ARM */
    if(strcmp (s_aSecNames[ucRadioMode][section_index],".text") == 0 ||
       strcmp (s_aSecNames[ucRadioMode][section_index],".data") == 0 ||
       strcmp(s_aSecNames[ucRadioMode][section_index],".bss") == 0 ||
       strcmp(s_aSecNames[ucRadioMode][section_index],".sbss") == 0 ||
       strcmp(s_aSecNames[ucRadioMode][section_index],".sdata") == 0 ||
       strcmp(s_aSecNames[ucRadioMode][section_index],".tbss") == 0 ||
       strcmp(s_aSecNames[ucRadioMode][section_index],".opd") == 0 ||
       strcmp(s_aSecNames[ucRadioMode][section_index],".tdata") == 0)
    {
        return TRUE;
    }

    return FALSE;
}

/**********************************************************************
* 函数名称：partition
* 功能描述：将待排序的表进行分区
* 访问的表：无
* 修改的表：无
* 输入参数：
* 输出参数：
* 返 回 值：
* 其它说明：无
* 修改日期      版本号  修改人      修改内容
* ---------------------------------------------------------------------
* 2008/12/16    V1.0    张文剑      创建
************************************************************************/
static INT32 partition(SYMBOL_ENT arr[],INT32 low,INT32 high)
{
    SYMBOL_ENT pivot = arr[low];
    while (low < high)
    {
        while ((low<high) && (arr[high].addr >= pivot.addr))
        {
            high--;
        }
        arr[low] = arr[high];

        while ((low<high) && (arr[low].addr <= pivot.addr))
        {
            low++;
        }
        arr[high] = arr[low];
    }
    arr[low] = pivot;
    return low;
}

/**********************************************************************
* 函数名称：quicksort
* 功能描述：将符号表进行快速排序
* 访问的表：无
* 修改的表：无
* 输入参数：
* 输出参数：
* 返 回 值：
* 其它说明：无
* 修改日期      版本号  修改人      修改内容
* ---------------------------------------------------------------------
* 2008/12/16    V1.0    张文剑      创建
************************************************************************/
static VOID quicksort(SYMBOL_ENT arr[],INT32 low,INT32 high)
{
    INT32 pivotindex;
    if (low < high)
    {
        pivotindex = partition(arr,low,high);
        quicksort(arr,low,pivotindex-1);
        quicksort(arr,pivotindex+1,high);
    }
}

/**********************************************************************
* 函数名称：SortSymbolTable
* 功能描述：将符号表进行排序
* 访问的表：无
* 修改的表：无
* 输入参数：
* 输出参数：
* 返 回 值：
* 其它说明：无
* 修改日期      版本号  修改人      修改内容
* ---------------------------------------------------------------------
* 2008/05/05    V1.0    张文剑      创建
************************************************************************/
static INT SortSymbolTable(SYMBOL_ENT *buff, WORD32 symbolnum)
{
#if 0
    SYMBOL_ENT *sort_buff;
    SYMBOL_ENT tSYMBOL;
    WORD32 i, j;

    sort_buff = (SYMBOL_ENT *)buff;
    for(i=0; i<symbolnum; i++)
    {
        for(j=1; j<symbolnum-i; j++)
        {
            if((sort_buff+symbolnum-j)->addr < (sort_buff+symbolnum-j-1)->addr)
            {
                memcpy(&tSYMBOL, sort_buff+symbolnum-j, sizeof(SYMBOL_ENT));
                memcpy(sort_buff+symbolnum-j, sort_buff+symbolnum-j-1, sizeof(SYMBOL_ENT));
                memcpy(sort_buff+symbolnum-j-1, &tSYMBOL, sizeof(SYMBOL_ENT));
            }
        }
    }
#else
    quicksort(buff,0,symbolnum - 1);
#endif
    return OK;
}

/**********************************************************************
* 函数名称：symGetPosByValue
* 功能描述：根据符号值获取其位置
* 访问的表：无
* 修改的表：无
* 输入参数：
* 输出参数：
* 返 回 值：
* 其它说明：无
* 修改日期      版本号  修改人      修改内容
* ---------------------------------------------------------------------
* 2008/05/05    V1.0    张文剑      创建
************************************************************************/
static WORD32 symGetPosByValue(WORDPTR value, UCHAR ucRadioMode)
{
    WORD32 length;
    WORDPTR addr;
    WORD32 low;
    WORD32 high;
    WORD32 mid;

    length = ulSymTblSize[ucRadioMode];
    low = 1;
    high = length;

    while (low <= high)
    {
        mid = (low + high) / 2;
        addr = (WORDPTR)taSymTbl[ucRadioMode][mid].addr;
        if ((value >= addr) && (value < (addr + taSymTbl[ucRadioMode][mid].size)))
        {
            return mid;
        }
        else if (value < addr)
        {
            high = mid - 1;
        }
        else
        {
            low = mid + 1;
        }
    }
    return ERROR;
}

VOID R_SymTblInit(VOID)
{
    memset((VOID *)taSymTbl,0,sizeof(taSymTbl));
    memset((VOID *)ulSymTblSize,0,sizeof(ulSymTblSize));
    memset((VOID *)s_aSecNames,0,sizeof(s_aSecNames));
    memset((VOID *)bSymTabInitFlag,0,sizeof(bSymTabInitFlag));
}


WORD32 PrintSelfSemPosByValue(WORDPTR value)
{
    INT PositionOri, Position;
    CHAR pucSymType[SYM_TYPE_NAME_SIZE] = {0};
    INT        loop;

    PositionOri = (INT)symGetPosByValue(value, SELF_MODE);
    if (ERROR != PositionOri)
    {
        for (loop = -3; loop < 4; loop ++)
        {
            Position = PositionOri + loop;

            if (Position < 0 || Position > ulSymTblSize[SELF_MODE])
                continue;

            switch (taSymTbl[SELF_MODE][Position].type)
            {
                case STT_FUNC:
                    if(snprintf_s(pucSymType,SYM_TYPE_NAME_SIZE,"Function") < 0)
                    {
                        printf("snprintf_s Failed!!!\n");
                        return ERROR;
                    }
                    break;

                case STT_OBJECT:
                    if(snprintf_s(pucSymType,SYM_TYPE_NAME_SIZE,"Varible") < 0)
                    {
                        printf("snprintf_s Failed!!!\n");
                        return ERROR;
                    }
                    break;

                default:
                    if(snprintf_s(pucSymType,SYM_TYPE_NAME_SIZE,"UnknowType") < 0)
                    {
                        printf("snprintf_s Failed!!!\n");
                        return ERROR;
                    }
                    break;

            }

            if (loop < 0)
                printf("↑");
            else if(loop > 0)
                printf("↓");
            else
                printf("●");

            printf("Addr: %p; Type: %s; Name: %s;\n",
                            taSymTbl[SELF_MODE][Position].addr,
                            pucSymType,
                            taSymTbl[SELF_MODE][Position].name
                            );
        }
        return OK;
    }

    printf("Can Not Found Symbol\n");
    return ERROR;
}


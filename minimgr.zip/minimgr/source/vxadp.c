/*********************************************************************
* 版权所有 (C)2007, 深圳市中兴通讯股份有限公司。
*
* 文件名称： ltaskLib.c
* 文件标识：
* 其它说明： 任务管理相关API实现
* 当前版本： V1.0
* 作    者：
* 完成日期：
*
* 修改记录1：
*    修改日期：2007-6-7 19:26:38
*    版 本 号：V1.0
*    修 改 人：
*    修改内容：创建
* 修改记录2：
*    修改日期：2018-12-11
*    修改版本号：无
*    修改人：   宋志强
*    修改内容： 去掉对 uf_*头文件的include
 
 **********************************************************************/

#include "bsperrcode.h"
#include "secure_func.h"
#include "vxadp.h"
#include "zprintf.h"


#if (__GNUC__ == 9 && (__GNUC_MINOR__ == 2))
#include <sys/sysmacros.h>
#endif

FUNC_BSP_TASK_LOCK pBspTaskLockFunc  = NULL;
ULONG ulTaskLockFuncInstallFlag = 0;
FUNC_BSP_TASK_UNLOCK pBspTaskUnlockFunc = NULL;
ULONG ulTaskUnlockFuncInstallFlag = 0;

/* global variables */

BOOL kernelState;            /* mutex to enter kernel state *////解决一些vxworks的编译链接错误
BOOL kernelIsIdle;            /* boolean reflecting idle state *////解决一些vxworks的编译链接错误
pthread_mutex_t   taskmutex = PTHREAD_MUTEX_INITIALIZER;

/*
**  selfRestart is a system function used by a task to restart itself.
**              The function creates a temporary watchdog timer which restarts 
**              the terminated task and then deletes itself. 
*/
extern void selfRestart(WIND_TCB * restart_task);

extern BOOL roundRobinIsEnabled(void);


extern int init_module(void *, unsigned long, const char *);

/*
**  task_list is a linked list of pthread task structs.
**            It is used to perform en-masse operations on all v2pthread
**            tasks at once.
*/
WIND_TCB *task_list = NULL;


pthread_mutex_t task_list_lock = PTHREAD_MUTEX_INITIALIZER;
pthread_mutex_t task_hash_list_lock = PTHREAD_MUTEX_INITIALIZER;

/*
**  v2pthread_task_lock is a mutex used to make taskLock exclusive to one
**                    thread at a time.
*/
pthread_mutex_t v2pthread_task_lock = PTHREAD_MUTEX_INITIALIZER;

/*
**  locker contains the pthread ID of the thread which currently
**                   has the scheduler locked (or NULL if it is unlocked).
*/
#ifndef __MINGW32__
static pthread_t locker = 0;
#else
static pthread_t locker = {0,0};
#endif

/*
**  taskLock_level tracks recursive nesting levels of taskLock/unlock calls
**                 so the scheduler is only unlocked at the outermost
**                 taskUnlock call.
*/
static unsigned long taskLock_level = 0;

/*
**  taskLock_change is a condition variable which signals a change from
**                  locked to unlocked or vice-versa.
*/
#if 0
static pthread_cond_t taskLock_change = PTHREAD_COND_INITIALIZER;
#endif

///新增加
CLASS_ID    taskClassId;        /* task class id */
CLASS_ID taskInstClassId;      /* instrumented task class id */
WIND_TCB *taskIdCurrent;        /* always current executing task */
BOOL     taskPriRangeCheck;      /* limit priorities to 0-255 */

//hooks
FUNCPTR        taskCreateTable   [VX_MAX_TASK_CREATE_RTNS + 1];
FUNCPTR        taskSwitchTable   [VX_MAX_TASK_SWITCH_RTNS + 1];
FUNCPTR     taskDeleteTable   [VX_MAX_TASK_DELETE_RTNS + 1];
FUNCPTR     taskSwapTable     [VX_MAX_TASK_SWAP_RTNS   + 1];
int        taskSwapReference [VX_MAX_TASK_SWAP_RTNS   + 1];

typedef void *(*start_routine) (void *);

// whq add,use hash array to optimize my_task function
#define    MAX_HASH_TABLE_LEN 43
#define    GET_HASH_KEY(tid) ((tid) % MAX_HASH_TABLE_LEN)
static WIND_TCB * hash_table[MAX_HASH_TABLE_LEN] = {NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,
                                                    NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,
                                                    NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,
                                                    NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,
                                                    NULL,NULL,NULL};

/* added by liujiusheng, 用于taskSuspend，其他程序不能使用这个信号.  */
#define SIG_TASKSUSPEND 50


/*****************************************************************************
 *  函数名称   : BspMkdir
 *  功能描述   : 创建文件夹
 *  输入参数   : path  文件夹名
 *  输出参数   : 无
 *  返 回 值   : BSP_OK  成功
 *               其它    失败
 *  其它说明   :
*****************************************************************************/
ULONG BspMkdir(const char *path)
{
    int ret;

    if(NULL == path)
    {
        dbgErr("null pointer err\n");
        return BSP_ERROR_NULL_POINTER;
    }

    ret = mkdir(path,0755);
    if(ret)
    {
        dbgErr("mkdir err=%d\n",ret);
        return ret;
    }
    return BSP_OK;
}

/*****************************************************************************
 *  函数名称   : BspMknod
 *  功能描述   : 创建设备节点
 *  输入参数   : filepath  节点名
 *               oprator   类型
 *               majornew  主设备号
 *               minornew  次设备号
 *  输出参数   : 无
 *  返 回 值   : BSP_OK  成功
 *               其它    失败
 *  其它说明   :
*****************************************************************************/
ULONG BspMknod(const char * filepath, const char *oprator, const char *majornew, const char* minornew)
{
    const char * path = filepath;
    int mode = 0666;
    char *end;
    int args;
    int major =0;
    int minor = 0;
    if(NULL == filepath)
    {
        dbgErr("null pointer err\n");
        return BSP_ERROR_NULL_POINTER;
    }
    if(NULL == oprator)
    {
        dbgErr("null pointer err\n");
        return BSP_ERROR_NULL_POINTER;
    }
    if(NULL == majornew)
    {
        dbgErr("null pointer err\n");
        return BSP_ERROR_NULL_POINTER;
    }
    if(NULL == minornew)
    {
        dbgErr("null pointer err\n");
        return BSP_ERROR_NULL_POINTER;
    }

    /* the second argument tells us the type of node to create */
    if (!strcmp(oprator, "b"))
    {
        mode |= S_IFBLK;
        args = 5;
    }
    else if (!strcmp(oprator, "c") || !strcmp(oprator, "u"))
    {
        mode |= S_IFCHR;
        args = 5;
    }
    else if (!strcmp(oprator, "p"))
    {
        mode |= S_IFIFO;
        args = 3;
    }
    else
    {
        dbgErr("unknown node type %s\n", oprator);
        return BSP_ERROR;
    }

    if (5 == args)
    {
      /* get the major and minor numbers for the device file to
       create */
        major = strtol(majornew, &end, 0);
        if (*end)
        {
            dbgErr("bad major number %s\n", majornew);
            return BSP_ERROR;
        }

        minor = strtol(minornew, &end, 0);
        if (*end)
        {
            dbgErr("bad minor number %s\n", minornew);
            return BSP_ERROR;
        }
    }

    /* if we're creating a named pipe, the final parameter is
       ignored */
    if (mknod(path, mode, makedev(major, minor)))
    {
        dbgErr("mknod failed: %s\n", (char *)strerror(errno));
        return BSP_ERROR;
    }

    return BSP_OK;
}
static void *read_file(const char *filename, ssize_t *_size)
{
    int ret, fd;
    struct stat sb;
    ssize_t size;
    void *buffer = NULL;

    /* open the file */
    fd = open(filename, O_RDONLY);
    if (fd < 0)
    {
        dbgErr("fd <0;\n");
        return NULL;
    }
    /* find out how big it is */
    if (fstat(fd, &sb) < 0)
    {
        close(fd);
        return buffer;
    }
    size = sb.st_size;

    /* allocate memory for it to be read into */
    buffer = malloc(size);
    if (!buffer)
    {
        close(fd);
        return buffer;
    }

    /* slurp it into our buffer */
    ret = read(fd, buffer, size);
    if (ret != size)
    {
        close(fd);
        free(buffer);
        return NULL;
    }

    /* let the caller know how big it is */
    *_size = size;
    close(fd);
    return buffer;
}

/*****************************************************************************
 *  函数名称   : BspInsmod
 *  功能描述   : 加载模块
 *  输入参数   : filepath  模块名
 *  输出参数   : 无
 *  返 回 值   : BSP_OK  成功
 *               其它    失败
 *  其它说明   :
*****************************************************************************/
ULONG BspInsmod(const char * filepath)
{
    void *file;
    ssize_t size;
    int ret;

    if(NULL == filepath)
    {
        dbgErr("null pointer err\n");
        return BSP_ERROR_NULL_POINTER;
    }

    /* read the file into memory */
    file = read_file(filepath, &size);
    if (!file)
    {
        dbgErr("insmod: can't open '%s'\n", filepath);
        return BSP_ERROR;
    }

    ret = init_module(file, size, "");
    if (ret != 0)
    {
        dbgErr("insmod: init_module '%s' failed (%s)\n", filepath, strerror(errno));
    }

    /* free the file buffer */
    free(file);
    return ret;
}




/*****************************************************************************
** tcb_input_hash_table - add a node in hash table
*****************************************************************************/
void tcb_input_hash_table(WIND_TCB * t)
{
    int       hash_Key = GET_HASH_KEY((unsigned int)t->pthrid);
    WIND_TCB *temp_t   = NULL;

    pthread_mutex_lock(&task_hash_list_lock);
    if (NULL == hash_table[hash_Key]) {
        hash_table[hash_Key] = t;
    }else {
        // hash collision
        temp_t = hash_table[hash_Key];

        while (NULL != temp_t->nxt_task_hash) {
            temp_t = temp_t->nxt_task_hash;
        }
        temp_t->nxt_task_hash = t;
    }
    pthread_mutex_unlock(&task_hash_list_lock);
}

/*****************************************************************************
** tcb_get_hash_table - get a node in hash table by tid
*****************************************************************************/
static WIND_TCB * tcb_get_hash_table(pthread_t pthrid)
{

    int        hash_Key = GET_HASH_KEY((unsigned int)pthrid);
    WIND_TCB * temp_t   = NULL;

    pthread_mutex_lock(&task_hash_list_lock);
    temp_t = hash_table[hash_Key];

    while (NULL != temp_t) {
        if (pthread_equal(temp_t->pthrid,pthrid)) {
            pthread_mutex_unlock(&task_hash_list_lock);
            return temp_t;
        }

        temp_t = temp_t->nxt_task_hash;
    }

    pthread_mutex_unlock(&task_hash_list_lock);
     return NULL;
}

/*****************************************************************************
** tcb_delete_hash_table - delete a node in hash table by tid
**                         only delete node ,not free memory
*****************************************************************************/
static void tcb_delete_hash_table(pthread_t pthrid)
{
    int      hash_Key = GET_HASH_KEY((unsigned int)pthrid);
    WIND_TCB * temp_t = NULL;
    WIND_TCB * up_t   = NULL;

    pthread_mutex_lock(&task_hash_list_lock);
    if (hash_table[hash_Key] == NULL) {
        pthread_mutex_unlock(&task_hash_list_lock);
        return;
    }

    if (pthread_equal(hash_table[hash_Key]->pthrid,pthrid)) {
        if (NULL == hash_table[hash_Key]->nxt_task_hash)
            hash_table[hash_Key] = NULL; //delete
        else
            hash_table[hash_Key] = hash_table[hash_Key]->nxt_task_hash; // delete
    } else {
        if (NULL == hash_table[hash_Key]->nxt_task_hash) {
            pthread_mutex_unlock(&task_hash_list_lock);
            return; // find error
        } else {
            up_t   = hash_table[hash_Key];
            temp_t = hash_table[hash_Key]->nxt_task_hash;

            while(NULL != temp_t) {
                if (pthread_equal(temp_t->pthrid,pthrid)) {
                    up_t->nxt_task_hash = temp_t->nxt_task_hash; // delete;
                    pthread_mutex_unlock(&task_hash_list_lock);
                    return;
                }

                up_t   = temp_t;
                temp_t = temp_t->nxt_task_hash;
            }
        }
    }
    pthread_mutex_unlock(&task_hash_list_lock);
}

// TODO:do we need ts_malloc ts_free?
// thread-safe malloc
void *ts_malloc(size_t blksize)
{
    void *blkaddr;
    //static pthread_mutex_t malloc_lock = PTHREAD_MUTEX_INITIALIZER;

    //pthread_cleanup_push((void (*)(void *)) pthread_mutex_unlock, (void *) &malloc_lock);
    //pthread_mutex_lock(&malloc_lock);

    blkaddr = malloc(blksize);
    if (NULL == blkaddr)
    {
        return NULL;
    }

    //pthread_cleanup_pop(1);

    return (blkaddr);
}

// thread-safe free
void ts_free(void *blkaddr)
{
    //static pthread_mutex_t free_lock = PTHREAD_MUTEX_INITIALIZER;

    //pthread_cleanup_push((void (*)(void *)) pthread_mutex_unlock, (void *) &free_lock);
    //pthread_mutex_lock(&free_lock);

    free(blkaddr);

    //pthread_cleanup_pop(1);
}

STATUS taskLibInit (void)
    {
    return ( OK );
    }
/*****************************************************************************
**  my_task - returns a pointer to the task struct for the calling task
*****************************************************************************/
WIND_TCB *my_task(void)
{
    pthread_t my_pthrid;
    /* WIND_TCB *t; */
    my_pthrid = pthread_self();
    /*
     **  No locking
     **  of the task list is done here since the access is read-only.
     **  NOTE that a task being appended to the task_list MUST have its
     **  nxt_task member initialized to NULL before being linked into
     **  the list.
     */
    /*for (t = task_list; t != NULL; t = t->nxt_task) {
        #ifndef __MINGW32__
        if (my_pthrid == t->pthrid) {
        #else
        if (pthread_equal(my_pthrid, t->pthrid))
        {
        #endif
            return t;
        }
    }
    return NULL;*/
    return tcb_get_hash_table(my_pthrid);
}

/*****************************************************************************
** task_for - returns the address of the task struct for the task
**           idenified by taskid
*****************************************************************************/
WIND_TCB *task_for(int taskid)
{
    WIND_TCB *t;
    if (!taskid)
        return my_task();

    for (t = task_list; t != NULL; t = t->nxt_task) {
        if (t->taskid == taskid) {
            return t;
        }
    }

    return NULL;
}

/* oldpriority - to record the original scheduling priority of the task that calls taskLock */
#define SCHED_PRIO_BOTTOM   0
#define SCHED_PRIO_CIELING    98  //任务锁只将优先级提升到98，中断任务优先级为99，不能被抢占
static int oldpriority = SCHED_PRIO_BOTTOM;
static int lock_num    = 0;

static int  BackedScheduler = -1;

/*****************************************************************************
** taskLock - 'locks the scheduler' to prevent preemption of the current task
**           by other task-level code.  Because we cannot actually lock the
**           scheduler in a pthreads environment, we temporarily set the
**           dynamic priority of the calling thread above that of any other
**           thread, thus guaranteeing that no other tasks preempt it.
*****************************************************************************/
#if 1
STATUS taskLock(void)
{
    struct sched_param param;
    WIND_TCB * task = my_task();

    if (NULL == task) {
        // task为NULL,可以说明该任务是主线程,
        lock_num++;
        if (1 == lock_num) {
             /*注意:如果读出当前线程优先级为0，那么这个线程应该不是实时线程，对于用taskSpawn创建的
             任务不存在这个问题，但是对于主线程来说就恰好是这种情况，如果不做特殊处理的话，那
             么在taskUnlock的时候按SCHED_FIFO类型恢复优先级为0是会不生效的，会导致主线程优先级
             一直为最高的98，为了解决这个问题，在这种情况下把主线程设置为优先级为1的实时任务*/
             /*oldpriority = 1;*/
			 sched_getparam(0, &param);
		oldpriority = param.sched_priority;
             BackedScheduler = sched_getscheduler(0);

             param.sched_priority = SCHED_PRIO_CIELING;
             sched_setscheduler(0, SCHED_FIFO, &param);

        }
        return OK;
    } else {
        task->lock_num++;
        if (1 == task->lock_num) {
            sched_getparam(0, &param);
            task->oldpriority = param.sched_priority;
            BackedScheduler = sched_getscheduler(0);

            param.sched_priority = SCHED_PRIO_CIELING; /*The realtime scheduling priority (0 - 99)*/
            sched_setscheduler(0, SCHED_FIFO, &param);
        }
        return OK;
    }
}
#else
STATUS taskLock(void)
{
    pthread_t my_pthrid = pthread_self();
    WIND_TCB *task = my_task();
    int got_lock = FALSE;

    /*
     **  v2pthread_task_lock ensures that only one v2pthread pthread at a time gets
     **  to run at max_priority (effectively locking out all other v2pthread
     **  pthreads).  Due to the semantics of the pthread_cleanup push/pop
     **  pairs (which protect against deadlocks in the event a thread gets
     **  terminated while holding the mutex lock), we cannot safely leave
     **  the mutex itself locked until taskUnlock() is called.  Therefore,
     **  we instead use the mutex to provide 'atomic access' to a global
     **  flag indicating if the scheduler is currently locked.  We will
     **  'spin' and briefly suspend until the scheduler is unlocked, and
     **  will then lock it ourselves before proceeding.
     */
    //TRACE_DLL_F("%x",my_pthrid);
    /*
     **  'Spin' here until locker == NULL or our pthread ID
     **  This effectively prevents more than one pthread at a time from
     **  setting its priority to max_priority.
     */
    do {
        pthread_mutex_clean_lock(&v2pthread_task_lock);
        #ifndef __MINGW32__
        if (!locker || locker == my_pthrid) {
            locker = my_pthrid;
        #else
        if ((!locker.p) || pthread_equal(locker,my_pthrid))
        {
            locker.p= my_pthrid.p;
            locker.x= my_pthrid.x;
        #endif

            taskLock_level++;
            if (taskLock_level == 0L)
                taskLock_level--;
            got_lock = TRUE;
            pthread_cond_broadcast(&taskLock_change);
        } else {
            if ( task ) task-> waiting_m = &v2pthread_task_lock;
            pthread_cond_wait(&taskLock_change, &v2pthread_task_lock);
            if ( task ) task-> waiting_m = NULL;
        }
        pthread_mutex_unlock(&v2pthread_task_lock);

        //  Add a cancellation point to this loop, since there are no others.
        pthread_testcancel();
        pthread_cleanup_pop(0);
    } while (got_lock == FALSE);
    #ifndef __MINGW32__
    assert(pthread_self() == locker);
        #else
        assert(pthread_equal(pthread_self(), locker));
        #endif
    /*
     **  task_list_lock prevents other v2pthread pthreads from modifying
     **  the v2pthread pthread task list while we're searching it and modifying
     **  the calling task's priority level.
     */
    pthread_mutex_clean_lock(&task_list_lock);
    if (task) {
        int max_priority, sched_policy;
        //int sched_policy2;
        struct sched_param schedparam;
        //struct sched_param schedparam2;
        pthread_attr_getschedpolicy(&task->attr, &sched_policy);
        pthread_attr_getschedparam(&task->attr, &schedparam);
        max_priority = sched_get_priority_max(sched_policy);
        schedparam.sched_priority = max_priority;
        (pthread_attr_setschedparam(&task->attr, &schedparam));
        (pthread_setschedparam(task->pthrid, sched_policy, &schedparam));
    }
    pthread_cleanup_pop(1);
    return OK;
}
#endif
/*****************************************************************************
** taskUnlock - 'unlocks the scheduler' to allow preemption of the current
**             task by other task-level code.  Because we cannot actually lock
**             the scheduler in a pthreads environment, the dynamic priority of
**             the calling thread was temporarily raised above that of any
**             other thread.  Therefore, we now restore the priority of the
**             calling thread to its original value to 'unlock' the task
**             scheduler.
*****************************************************************************/
#if 1
STATUS taskUnlock(void)
{
    struct sched_param param;
    WIND_TCB * task = my_task();

    if (NULL == task)
    {
        if (0 == lock_num)
            return OK;

        lock_num--;

        if (0 == lock_num)
        {
            sched_getparam(0, &param);
            param.sched_priority = oldpriority;/*The realtime scheduling priority (0 - 99)*/
            /*oldpriority = SCHED_PRIO_BOTTOM;*/
            sched_setscheduler(0, BackedScheduler, &param);
            oldpriority = SCHED_PRIO_BOTTOM;
            BackedScheduler = -1;
        }
        return OK;
    }
    else
    {
        if (0 == task->lock_num)
            return OK;

        task->lock_num--;

        if (0 == task->lock_num)
        {
            sched_getparam(0, &param);
            param.sched_priority = task->oldpriority;/*The realtime scheduling priority (0 - 99)*/
            task->oldpriority = SCHED_PRIO_BOTTOM;
            sched_setscheduler(0, BackedScheduler, &param);
            BackedScheduler = -1;
        }
        return OK;
    }
}
#else
STATUS taskUnlock(void)
{
    WIND_TCB *task;
    int sched_policy;
    /*
     **  locker ensures that only one v2pthread pthread at a time gets
     **  to run at max_priority (effectively locking out all other v2pthread
     **  pthreads).  Unlock it here to complete 'unlocking' of the scheduler.
     */
    pthread_mutex_clean_lock(&v2pthread_task_lock);
    #ifndef __MINGW32__
    if (locker == pthread_self()) {
    #else
    if (pthread_equal(locker,pthread_self())) {
    #endif
        TRACE_DLL_F();
        if (taskLock_level > 0L)
            taskLock_level--;
        if (taskLock_level < 1L) {
            /*
             **  task_list_lock prevents other v2pthread pthreads from modifying
             **  the v2pthread pthread task list while we're searching it and
             **  modifying the calling task's priority level.
             */
            pthread_mutex_clean_lock(&task_list_lock);
            task = my_task();
            if (task) {
                struct sched_param schedparam;
                pthread_attr_getschedpolicy(&(task->attr), &sched_policy);
                pthread_attr_getschedparam(&(task->attr), &schedparam);
                //pthread_getschedparam(task->pthrid, &sched_policy2, &schedparam2);
                schedparam.sched_priority = task->prv_priority.sched_priority;

                pthread_attr_setschedparam(&(task->attr), &schedparam);
                (pthread_setschedparam(task->pthrid, sched_policy, &schedparam));
            }
            pthread_cleanup_pop(1);

            #ifndef __MINGW32__
            locker = 0;
            #else
            locker.p=0;
            locker.x=0;
            #endif
            pthread_cond_broadcast(&taskLock_change);
        }
        //TRACE_DLL_F("%x level %i",locker, taskLock_level);
    } else {
        //TRACE_DLL_F("locking tid %ld my tid %lx", locker, pthread_self());
    }

    pthread_cleanup_pop(1);
    return OK;
}
#endif

ULONG BspTaskLockFuncInstall(FUNC_BSP_TASK_LOCK pInstallFunc)
{
    /* 安装回调函数指针 */
    if (NULL != pInstallFunc)
    {
        pBspTaskLockFunc = pInstallFunc;
        ulTaskLockFuncInstallFlag = 1;
    }
    else
    {
        ulTaskLockFuncInstallFlag = 0;
        return (BSP_ERROR);
    }
    return (BSP_OK);
}

ULONG BspTaskUnlockFuncInstall(FUNC_BSP_TASK_UNLOCK pInstallFunc)
{
    /* 安装回调函数指针 */
    if (NULL != pInstallFunc)
    {
        pBspTaskUnlockFunc = pInstallFunc;
        ulTaskUnlockFuncInstallFlag = 1;
    }
    else
    {
        ulTaskUnlockFuncInstallFlag = 0;
        return (BSP_ERROR);
    }
    return (BSP_OK);
}

STATUS bspTaskLock(VOID)
{
    if (NULL == pBspTaskLockFunc)
    {
        taskLock();
    }
    else
    {
        pBspTaskLockFunc();
    }
    return OK;
}

STATUS bspTaskUnlock(VOID)
{
    if (NULL == pBspTaskUnlockFunc)
    {
        taskUnlock();
    }
    else
    {
        pBspTaskUnlockFunc();
    }
    return OK;
}

/*****************************************************************************
** link_susp_task - appends a new task pointer to a linked list of task pointers
**                 for tasks suspended on the object owning the list.
*****************************************************************************/
void link_susp_task(WIND_TCB ** list_head, WIND_TCB * new_entry)
{
    if (!new_entry)
        return;
    // pthread_cleanup_push((void (*)(void *)) pthread_mutex_unlock, &task_list_lock); 
    pthread_mutex_lock(&task_list_lock);
    new_entry->nxt_susp = NULL;
    WIND_TCB **i = list_head;
    while (*i) {
        if (*i==new_entry) {
            *i = (*i)->nxt_susp;    // remove the task
            continue;
        }
        i = &(*i)->nxt_susp;    // look for the tail
    }
    *i = new_entry;

    /*
     **  Initialize the suspended task's pointer back to suspend list
     **  This is used for cleanup during task deletion.
     */
    //new_entry->suspend_list = *list_head;
    new_entry->state |= PEND;

    // pthread_cleanup_pop(1);
    pthread_mutex_unlock(&task_list_lock);
}

/*****************************************************************************
** unlink_susp_task - removes task pointer from a linked list of task pointers
**                   for tasks suspended on the object owning the list.
*****************************************************************************/
void unlink_susp_task(WIND_TCB ** list_head, WIND_TCB * entry)
{
    WIND_TCB **i = list_head;
    if (!entry)
        return;
    // pthread_cleanup_push((void (*)(void *)) pthread_mutex_unlock, &task_list_lock); 
    pthread_mutex_lock(&task_list_lock);
    while (*i && (*i != entry) )
        i = &(*i)->nxt_susp;
    if (*i) {
        //TRACE_DLL_F("%x", entry);
        *i = (*i)->nxt_susp;    // remove the task
        entry->nxt_susp = NULL;
        entry->state &= ~PEND;
    } else {
        TRACE_DLL_F("warning: entry not found");
    }
    // pthread_cleanup_pop(1);
    pthread_mutex_unlock(&task_list_lock);
}

/*****************************************************************************
** signal_for_my_task - searches the specified 'pended task list' for the
**                      task to be selected according to the specified
**                      pend order.  If the selected task is the currently
**                      executing task, the task is deleted from the
**                      specified pended task list and returns a non-zero
**                      result... otherwise the pended task list is not
**                      modified and a zero result is returned.
*****************************************************************************/
int signal_for_my_task(WIND_TCB ** list_head, int pend_order)
{
#if 0
    WIND_TCB *signalled_task;
    WIND_TCB *t;
    int result;

    result = FALSE;
    if (!list_head)
        return result;
    signalled_task = *list_head;

    //  First determine which task is being signalled
    if (pend_order != 0) {
        /*
         **  Tasks pend in priority order... locate the highest priority
         **  task in the pended list.
         */
        for (t = *list_head; t; t = t->nxt_susp) {
            if ((t->prv_priority).sched_priority > (signalled_task->prv_priority).sched_priority)
                signalled_task = t;
        }
    }
    /*
       else
       **
       ** Tasks pend in FIFO order... signal is for task at list head.
     */

    //  Signalled task located... see if it's the currently executing task.
    if (signalled_task == my_task()) {
        // The currently executing task is being signalled...
        result = TRUE;
    }

    return result;
#endif
    return TRUE;
}

/*****************************************************************************
** new_tid - assigns the next unused task ID for the caller's task
*****************************************************************************/
static int new_tid(void)
{
    WIND_TCB *t;
    int new_taskid;

    new_taskid = 1;
    //  Get the highest previously assigned task id and add one.
    for (t = task_list; t; t = t->nxt_task) {
        /*
         **  We use a kluge here to prevent address-based task IDs created
         **  by explicit taskInit calls from polluting the normal sequence
         **  for task ID numbers.  This is based on the PROBABILITY that
         **  Linux will not allocate pthread data space below the 64K
         **  address space.  NOTE that this will BREAK taskSpawn if you
         **  create 64K tasks or more.
         */
        if ((t->taskid < 65536) && (t->taskid >= new_taskid)) {
            new_taskid = t->taskid + 1;
        }
    }

    return new_taskid;
}

/*****************************************************************************
** translate_priority - translates a v2pthread priority into a pthreads priority
*****************************************************************************/
#if 0
static int translate_priority(int v2pthread_priority, int sched_policy, int *errp)
{
    int max_priority, min_priority, pthread_priority;
    int scale;

    //  Validate the range of the user's task priority.
    if ((v2pthread_priority > MIN_V2PT_PRIORITY) | (v2pthread_priority < MAX_V2PT_PRIORITY))
        *errp = S_taskLib_ILLEGAL_PRIORITY;

    /*
     **  Translate the v2pthread priority into a pthreads priority.
     **  'Invert' the caller's priority so highest priority == highest number.
     */
    //pthread_priority = MIN_V2PT_PRIORITY - v2pthread_priority;
    pthread_priority = v2pthread_priority;

    //  Next get the allowable priority range for the scheduling policy.
    min_priority = sched_get_priority_min(sched_policy);
    max_priority = sched_get_priority_max(sched_policy);

    /*
     **  'Telescope' the v2pthread priority (0-255) into the smaller pthreads
     **  priority range (1-97) on a proportional basis.  NOTE that this may
     **  collapse some distinct v2pthread priority levels into the same priority.
     **  Use this technique if the tasks span a large priority range but no
     **  tasks are within fewer than 3 levels of one another.
     */
    scale = MIN_V2PT_PRIORITY / (min_priority-max_priority);
    pthread_priority /=scale;
    pthread_priority -= min_priority;

    //printf("pthread_priority = %d\n",pthread_priority);

    if (pthread_priority > min_priority)
        pthread_priority = min_priority;
    if (pthread_priority < max_priority)
        pthread_priority = max_priority;

    //printf("---------translate_priority--------=%d\n",pthread_priority);
    return pthread_priority;
}
#endif
static int translate_priority(int v2pthread_priority, int sched_policy, STATUS *errp)
{
    int max_priority, pthread_priority;

    //  Validate the range of the user's task priority.
    if ((v2pthread_priority > MIN_V2PT_PRIORITY) | (v2pthread_priority < MAX_V2PT_PRIORITY))
        *errp = S_taskLib_ILLEGAL_PRIORITY;

    #if 0
    /*
     **  Translate the v2pthread priority into a pthreads priority.
     **  'Invert' the caller's priority so highest priority == highest number.
     */
    pthread_priority = MIN_V2PT_PRIORITY - v2pthread_priority;

    //  Next get the allowable priority range for the scheduling policy.
    min_priority = sched_get_priority_min(sched_policy);
    max_priority = sched_get_priority_max(sched_policy);

    /*
     **  'Telescope' the v2pthread priority (0-255) into the smaller pthreads
     **  priority range (1-97) on a proportional basis.  NOTE that this may
     **  collapse some distinct v2pthread priority levels into the same priority.
     **  Use this technique if the tasks span a large priority range but no
     **  tasks are within fewer than 3 levels of one another.
     */
    pthread_priority *= max_priority;
    pthread_priority /= (MIN_V2PT_PRIORITY + 1);

    /*
     **  Now 'clip' the new priority level to within priority range.
     **  Reserve max_priority level for temporary use during system calls.
     **  Reserve (max_priority level - 1) for the system exception task.
     **  NOTE that relative v2pthread priorities may not translate properly
     **  if the v2pthread priorities used span several multiples of max_priority.
     **  Use this technique if the tasks span a small priority range and their
     **  relative priorities are within 3 or fewer levels of one another.
     */
    pthread_priority %= (max_priority /*- 1*/);
    if (pthread_priority < min_priority)
        pthread_priority = min_priority;
    #endif

    max_priority = sched_get_priority_max(sched_policy);

    pthread_priority = max_priority - (v2pthread_priority / 3);
    
    pthread_priority -= 2;  /*预留 99的优先级给中断服务任务，98的优先级给taskLock*/

    return pthread_priority;
}

/*****************************************************************************
** task_delete - deletes a pthread task struct from the task_list
**              and frees the memory allocated for the task
*****************************************************************************/
static void task_delete(WIND_TCB * task)
{
    WIND_TCB **i;

    TRACE_DLL_F("%x %x", task, task->waiting);
    //unlink_susp_task(&task->suspend_list, task);
    #if 1
    if (task->waiting)
		unlink_susp_task(&task->first_susp, task);
    // pthread_cleanup_push((void (*)(void *)) pthread_mutex_unlock, &task_list_lock);
    pthread_mutex_lock(&task_list_lock);
    for (i = &task_list; *i; i = &(*i)->nxt_task) {
        if (task == *i) {
            *i = (*i)->nxt_task;    // remove
            break;
        }
    }
    // pthread_cleanup_pop(1);
    pthread_mutex_unlock(&task_list_lock);
    #endif
    if (task->name)
        ts_free(task->name);
    if (!task->static_task)
        ts_free(task);
}

/*****************************************************************************
** notify_task_delete - notifies any pended tasks of the specified task's
**                      deletion.
*****************************************************************************/
void notify_task_delete(WIND_TCB * task)
{
    if (!task->first_susp) return;
    /*
     **  Task just made deletable... ensure that we awaken any
     **  other tasks pended on deletion of this task
     */
    // pthread_cleanup_push((void (*)(void *)) pthread_mutex_unlock, &(task->dbcst_lock)); 
    pthread_mutex_lock(&(task->dbcst_lock));
    //pthread_cleanup_push((void (*)(void *)) pthread_mutex_unlock, &task->tdelete_lock); 
    pthread_mutex_lock(&(task->tdelete_lock));
    TRACE_DLL_F("");
    pthread_cond_broadcast(&(task->t_deletable));

    //pthread_cleanup_pop(1);
    pthread_mutex_unlock(&(task->tdelete_lock));
    /*
     **  Wait for all pended tasks to receive deletion notification.
     **  The last task to receive the notification will signal the
     **  delete broadcast-complete condition variable.
     */
    TRACE_DLL_F("wait till pended tasks respond @ task %p", task);
    while (task->first_susp != (WIND_TCB *) NULL)
        pthread_cond_wait(&(task->delete_bcplt), &(task->dbcst_lock));

    TRACE_DLL_F("all pended tasks responded @ task %p", task);
    // pthread_cleanup_pop(1);
    pthread_mutex_unlock(&(task->dbcst_lock));
}


void task_delete_unlock(WIND_TCB * task)
{
    TRACE_DLL_F();
    task_delete(task);
    taskUnlock();
}


/*****************************************************************************
** taskDeleteForce - removes the specified task(s) from the task list,
**                   frees the memory occupied by the task struct(s),
**                   and kills the pthread(s) associated with the task(s).
*****************************************************************************/
STATUS taskDeleteForce(int tid)
{
    WIND_TCB *t;
    WIND_TCB *self_task = my_task();
    STATUS error = OK;

    taskLock();

    t = task_for(tid);
    TRACE_DLL_F("%#x %x",tid,t);

    if (!t) {
        error = S_objLib_OBJ_DELETED;
        goto exit;
    }
    notify_task_delete(t);

    if ( t != self_task) {
        /*
         **  Task being deleted is not the current task.
         **  Kill the task pthread and wait for it to die.
         **  Then de-allocate its data structures.
         */
        TRACE_DLL_F("%i %x", tid, t);
        #ifdef _USE_SEM_FUTEX_
        if (t->pend_sem != NULL)
            t->pend_sem->waiting_count--;
        #endif
        error = pthread_cancel(t->pthrid);
        if (error == 0)
            pthread_join(t->pthrid, NULL);
        tcb_delete_hash_table(t->pthrid);  
        task_delete(t);
    } else {
        /*
         **  Kill the currently executing task's pthread
         **  and then de-allocate its data structures.
         */
        TRACE_DLL_F("self %i %x", tid, t);
        //pthread_detach(self_task->pthrid);
        //pthread_cleanup_push((void (*)(void *)) task_delete_unlock, self_task);
        tcb_delete_hash_table(t->pthrid);  
        #ifdef _USE_SEM_FUTEX_
        if (t->pend_sem != NULL)
            t->pend_sem->waiting_count--;
        #endif
        //task_delete_unlock(self_task); 
        pthread_detach(t->pthrid); // 防止线程反复创建达到一定数量就不能再创建了
        task_delete(t);  
        pthread_exit(NULL);
        // not executed
        //pthread_cleanup_pop(1);
    
    }

  exit:
    taskUnlock();
    if (error != OK) {
        errno = (int) error;
        error = ERROR;
    }
    return error;
}

/*****************************************************************************
**  task_wrapper_cleanup ensures that a killed pthread releases the
**                         scheduler lock if it owned it.
*****************************************************************************/
static void task_wrapper_cleanup(void *task)
{
    TRACE_DLL_F();
    pthread_mutex_lock(&v2pthread_task_lock);
    #ifndef __MINGW32__
    if (locker == pthread_self()) {
    #else
    if (pthread_equal(locker,pthread_self())) {
    #endif
        taskLock_level = 0;
    #ifndef __MINGW32__
        locker = (pthread_t) NULL;
    #else
        locker.p=0;
        locker.x=0;
    #endif
        // or call Unlock?
    }
    pthread_mutex_unlock(&v2pthread_task_lock);
}

#include <sys/prctl.h>

int SetTaskName(char *name)
{

    if(prctl(PR_SET_NAME,(unsigned long)name,0,0,0) != 0)
    {
        return -1;
    }
    else
    {
        return 0;
    }   

}

/*****************************************************************************
**  taskSuspendSelf is a signal handler used to suspend itself, added by liujiusheng.
*****************************************************************************/
static void taskSuspendSelf()
{
    WIND_TCB *pTcb;

    pTcb = my_task();

    if (pTcb == NULL)
        return;

    while (pTcb->state & SUSPEND)
    {
        pthread_mutex_lock(&(pTcb->tsuspend_lock));
        pthread_cond_wait(&(pTcb->tsuspendable), &(pTcb->tsuspend_lock));
        pthread_mutex_unlock(&(pTcb->tsuspend_lock));
    }
}

/*****************************************************************************
**  task_wrapper is a pthread used to 'contain' a v2pthread task.
*****************************************************************************/
void *task_wrapper(WIND_TCB *task)
{
//    int ix=0;
    errno = 0;

#if 0
    static int task_number=0;
    struct pthread_int
    {
    void *skip[18];
    pid_t tid;
    };
    task_number++;
    struct pthread_int * pt = (struct pthread_int *) pthread_self();
    printf("===%d===task %s  tid = %d \n",task_number, task->name ,pt->tid);
#endif
	SetTaskName(task->name);
    //TRACE_DLL_F("%x %x %i", task,pthread_self(),getpid());
    // Ensure that this pthread will release the scheduler lock if killed.
    // pthread_cleanup_push(task_wrapper_cleanup, task);

    // Call the v2pthread task.  Normally this is an endless loop and doesn't
    /*
     * TODO: replace this ugly patch with waiting for conditional variable on task->thrid
     * or better yet, fill the task->pthrid with pthread_self(). Check if this can be done
     * with atomic_xchange here and in the taskActivate function simultaneously
     */
    sched_yield();
    #ifndef __MINGW32__
    while (0 == (volatile pthread_t) task->pthrid) {
    #else
    while (0 == (volatile) task->pthrid.p) {
    #endif
        sched_yield();
        usleep(5000);
        TRACE_DLL_F("task_wrapper() PATCH! task (%s) wait for task->pthrid to get its value... \n",
               task->taskname ? task->name : "no-name");
    }

    pthread_setcancelstate( PTHREAD_CANCEL_ENABLE, NULL);
    pthread_setcanceltype(PTHREAD_CANCEL_ASYNCHRONOUS,NULL);

    /* Added by liujiusheng */
    signal(SIG_TASKSUSPEND, taskSuspendSelf);

    (*(task->entry_point)) (task->parms[0], task->parms[1], task->parms[2], task->parms[3],
                            task->parms[4], task->parms[5], task->parms[6], task->parms[7],
                            task->parms[8], task->parms[9]);
    //  If for some reason the task above DOES return, clean up the  pthread and task resources and kill the pthread.
    // pthread_cleanup_pop(1);
    task_wrapper_cleanup(task);

    // NOTE taskDelete takes no action if the task has already been deleted.
    taskDeleteForce(task->taskid);
    TRACE_DLL_F("DONE");
    return NULL;
}

/*****************************************************************************
** taskIdListGet - returns a list of active task identifiers
*****************************************************************************/
int taskIdListGet(int list[], int maxIds)
{
    WIND_TCB *t;
    int count;
    count = 0;
    taskLock();
    assert(list);
    for (t = task_list; t; t = t->nxt_task) {
        if (count < maxIds) {
            list[count] = t->taskid;
            count++;
        }
    }
    taskUnlock();
    return (count);
}

/*****************************************************************************
** taskIdSelf - returns the identifier of the calling task
*****************************************************************************/
int taskIdSelf(void)
{
    WIND_TCB *self_task;
    int my_tid;

    self_task = my_task();

    if (self_task)
        my_tid = self_task->taskid;
    else
        my_tid = 0;

    return my_tid;
}


/*****************************************************************************
** taskSelf - 
*****************************************************************************/
WIND_TCB * taskSelf(void)
{
    WIND_TCB *self_task = NULL;
   
    self_task = my_task();

    return self_task;
}    
/*****************************************************************************
** taskIdVerify - indicates whether the specified task exists or not
** returns OK==0, if a task exists
*****************************************************************************/
STATUS taskIdVerify(int taskid)
{
    WIND_TCB *task;
    STATUS error;

    // pthread_cleanup_push((void (*)(void *)) pthread_mutex_unlock, &task_list_lock); 
    pthread_mutex_lock(&task_list_lock);

    task = task_for(taskid);

    // pthread_cleanup_pop(1);
    pthread_mutex_unlock(&task_list_lock);

    if (task != NULL)
        error = OK;
    else                        /* NULL TCB pointer */
        error = S_objLib_OBJ_ID_ERROR;

    if (error != OK) {
        errno = (int) error;
        error = ERROR;
    }
    return error;
}

/*****************************************************************************
** taskInit - initializes the requisite data structures to support v2pthread 
**            task behavior not directly supported by Posix threads.
*****************************************************************************/
extern STATUS taskInit(WIND_TCB * task, char *name, int pri,
                       int opts, char *pstack, int stksize, FUNCPTR entry, int arg1, int arg2,
                       int arg3, int arg4, int arg5, int arg6, int arg7, int arg8, int arg9,
                       int arg10);
STATUS taskInit(WIND_TCB * task, char *name, int pri, int opts,
                char *pstack, int stksize,
                int (*funcptr) (int, int, int, int, int, int, int, int, int, int),
                int arg1, int arg2, int arg3, int arg4, int arg5,
                int arg6, int arg7, int arg8, int arg9, int arg10)
{
    int i, new_priority=0, sched_policy=0;
    STATUS error = OK;
    TRACE_DLL_F("%x %s %x", task, name, funcptr);

    if(NULL == funcptr || stksize<0)
        return ERROR;

    #if 0        /**/
    if (opts != 0) {
        // no options are currently implemented.
        errno = ENOSYS;
        return (errno);
    }
    #endif
    if (!task) {
        error = S_objLib_OBJ_ID_ERROR;
        goto error;
    }

    memset(task,0,sizeof(*task));
    #ifndef __MINGW32__
    task->pthrid = 0;
    #else
    task->pthrid.p = 0;
    task->pthrid.x = 0;
    #endif
    task->taskid =  (int)(long)task;

    if (name) {
        i = strlen(name) + 1;
        task->name = ts_malloc(i);
        if (task->name)
            strncpy(task->name, name, i);
    } else
        task->name = NULL;

    task->vxw_priority = pri;

    pthread_attr_init(&task->attr);

    pthread_attr_getschedparam(&task->attr, &task->prv_priority);

#if 0
#ifndef _USE_LINUX_PRI_   /*屏蔽线程优先级*/
/* nothing */
#else /*罗贤国--优先级完善*/
    if (roundRobinIsEnabled())
        sched_policy = SCHED_RR;
    else
        sched_policy = SCHED_FIFO;
    pthread_attr_setinheritsched(&task->attr,PTHREAD_EXPLICIT_SCHED);  /* 很重要，否则调度策略、优先级都默认继承父进程属性、而后面设置不起作用 */
    pthread_attr_setschedpolicy(&task->attr, sched_policy);//sched_policy

    new_priority = translate_priority(pri, sched_policy, &error);

    task->prv_priority.sched_priority = new_priority;
    (pthread_attr_setschedparam(&task->attr, &task->prv_priority));
#endif
#else

	sched_policy = SCHED_FIFO;		

	pthread_attr_setinheritsched(&task->attr,PTHREAD_EXPLICIT_SCHED);  /* 很重要，否则调度策略、优先级都默认继承父进程属性、而后面设置不起作用 */
		
	pthread_attr_setinheritsched(&task->attr,PTHREAD_CREATE_DETACHED); 	

	pthread_attr_setschedpolicy(&task->attr, sched_policy);//sched_policy
	new_priority = translate_priority(pri, sched_policy, &error);
    task->prv_priority.sched_priority = new_priority;
    (pthread_attr_setschedparam(&task->attr, &task->prv_priority));
#endif
    task->entry_point = funcptr;
    task->static_task = 1;
    task->flags = opts;
    task->state = DEAD;
    //task->suspend_list = NULL;
    task->nxt_susp = NULL;
    task->nxt_task = NULL;
    task->delete_safe_count = 0;

    task->pStackBase=pstack;
    //仿真环境下任务的最小堆栈设置为1M//dxd
    task->pStackLimit=pstack+(stksize>0x100000?stksize:0x100000);
    task->pStackEnd=task->pStackLimit;

    #ifdef _USE_SEM_FUTEX_
    task->pend_sem = NULL; 
    #endif
    
    // Mutex and Condition variable for task delete 'pend'
    pthread_mutex_init(&task->tdelete_lock, NULL);
    pthread_cond_init(&task->t_deletable, NULL);

    // Mutex and Condition variable for task delete 'broadcast'
    pthread_mutex_init(&task->dbcst_lock, NULL);
    pthread_cond_init(&task->delete_bcplt, NULL);

    pthread_mutex_init(&task->tsuspend_lock, NULL);
    pthread_cond_init(&task->tsuspendable, NULL);
    
    task->first_susp = NULL;

    task->parms[0] = arg1;
    task->parms[1] = arg2;
    task->parms[2] = arg3;
    task->parms[3] = arg4;
    task->parms[4] = arg5;
    task->parms[5] = arg6;
    task->parms[6] = arg7;
    task->parms[7] = arg8;
    task->parms[8] = arg9;
    task->parms[9] = arg10;
    pthread_mutex_lock(&task_list_lock);
    if (error == OK) {
        WIND_TCB **i = &task_list;
        while (*i){
            /*需要防止同一任务多次初始化，避免变成循环链表*/
            if( *i==task ){
                break;
            }
            i = &(*i)->nxt_task;    // search_last
        }
        if( *i!=task ){
        *i = task;                    // add to tail
    }
    }
error:
    pthread_mutex_unlock(&task_list_lock);
    if (error != OK) {
        errno = (int) error;
        error = ERROR;
    }
    return error;
}

/*****************************************************************************
** taskIsReady - indicates if the specified task is ready to run
*****************************************************************************/
BOOL taskIsReady(int taskid)
{
    WIND_TCB *task;
    BOOL result = FALSE;
    // pthread_cleanup_push((void (*)(void *)) pthread_mutex_unlock, &task_list_lock);
    pthread_mutex_lock(&task_list_lock);

    task = task_for(taskid);

    if (!task) {
        TRACE_DLL_F("no task");
    }
    else {
        TRACE_DLL_F("%x %x",task,task->state);
        if ((task->state & RDY_MSK) == READY)
            result = TRUE;
    }

    //pthread_cleanup_pop(1);
    pthread_mutex_unlock(&task_list_lock);
    return result;
}
/*****************************************************************************
** taskIsSuspended - indicates if the specified task is explicitly suspended 
*****************************************************************************/
BOOL taskIsSuspended(int taskid)
{
    WIND_TCB *pTcb;
    pTcb=taskTcb(taskid);
    return ((pTcb != NULL) && (pTcb->state & SUSPEND));
}

/*****************************************************************************
** taskActivate -  creates a pthread containing the specified v2pthread task
*****************************************************************************/
STATUS taskActivate(int tid)
{
    WIND_TCB *task;
    STATUS error;
    //TRACE_DLL_F("%x",tid);
    error = OK;
    int ret=0;

    /*
     **  'Lock the v2pthread scheduler' to defer any context switch to a higher
     **  priority task until after this call has completed its work.
     */
    pthread_mutex_lock(&taskmutex);
    /*taskLock();*/

    task = task_for(tid);
    if (task ) {
        /*
         **  Found our task struct.
         **  Start a new real-time pthread for the task. 
         */
        if (task->state == DEAD) {
            task->state = READY;
            TRACE_DLL_F("%x",task);

            /*
             * TODO There is un ugly patch here to ensure the called thread has a valid task->pthrid
             * check if that can be done better with atomic_set
             */
            #ifndef __MINGW32__
            task->pthrid = 0;
            #else
            task->pthrid.p = 0;
            task->pthrid.x = 0;
            #endif
            //pthread_attr_setstacksize(&task->attr,(int)task->pStackLimit);
            ret = pthread_create(&task->pthrid, &task->attr, (start_routine) task_wrapper, task);
            if (ret != 0) {
                TRACE_DLL_F("taskActivate pthread_create returned error:");
                error = S_memLib_NOT_ENOUGH_MEMORY;
                task_delete(task);
            }else {
                tcb_input_hash_table(task);  // add by wanghq
            }
        } else {
            /*
             ** task already made runnable
             */
            TRACE_DLL_F("taskActivate task @ task %p already active", task);
        }
    } else
        error = S_objLib_OBJ_ID_ERROR;

    /*
     **  'Unlock the v2pthread scheduler' to enable a possible context switch
     **  to a task made runnable by this call.
     */
   /*taskUnlock();*/
    pthread_mutex_unlock(&taskmutex);
    //TRACE_DLL_F("%x %s vxw_Prio=%d, Linux-Prio=%d",
    //      task, task->name, task->pthrid, task->vxw_priority, task->prv_priority.sched_priority);

    //TRACE_DLL_F("ADDED task=%x (%s) task=%x, vxw_Prio=%d, Linux-Prio=%d",
    //   (int) task->pthrid, task->name ,
    //   (int) task, task->vxw_priority, (task->prv_priority).sched_priority);

    if (error != OK) {
        errno = (int) error;
        error = ERROR;
    }
    return error;
}

extern void blockticksig(void);

typedef struct {
    unsigned long   ulTimerNum;
    unsigned long   ulTickPerSecond;
    void           *timer;
    int             sigNum;     /*信号 */
    int             argCall;    /*中断回调函数参数 */
    FUNCPTR         clkCallBack;        /*中断回调函数 */
    struct itimerspec timevalue;
} T_TIMER_PARAM;

#define SYS_AUX_CLK_NUM       0 /* 系统辅助时钟使用Timer1 */
#define NUM_OF_GTM_TIMERS      9




typedef struct  
{
	 unsigned long s_addr;
}in_addr;

void inet_ntoa_b
(
    in_addr inetAddress, /* inet address */
    char *pString               /* where to return ASCII string */
)
{
    register char *p = (char *)&inetAddress;
    INT32 iTmpRet = 0;
#define	UC(b)	(((int)b)&0xff)
    iTmpRet = snprintf_s (pString, 32,"%d.%d.%d.%d",UC(p[0]), UC(p[1]), UC(p[2]), UC(p[3]));
    SNPRINTF_S_CHECK(iTmpRet, 32);
}

STATUS sysAuxClkRateSet(int ticksPerSecond      /* number of clock interrupts per second */
    )
{
    return 100;/* sysGtmClkRateSet(&tTimer[SYS_AUX_CLK_NUM], ticksPerSecond); */
}


#define NUM_OF_GTM_TIMERS      9
void blockticksig(void)
{
    int             i;
    sigset_t        waitset;
    sigemptyset(&waitset);
    for (i = 0; i < NUM_OF_GTM_TIMERS + 1; i++)
        sigaddset(&waitset, SIGRTMAX - i);
    sigprocmask(SIG_BLOCK, &waitset, NULL);
}
#if 0
int inflate
    (
    CHAR *	src,
    CHAR *	dest,
    int		nBytes
    )
{
}
#endif
VOID sysAuxClkEnable(VOID)
{
}


STATUS sysAuxClkConnect
    (
    FUNCPTR routine,    /* routine called at each aux clock interrupt */
    int arg             /* argument to auxiliary clock interrupt routine */
    )
{
    return OK;	
}

/*****************************************************************************
** taskSpawn -   initializes the requisite data structures to support v2pthread 
**               task behavior not directly supported by Posix threads and
**               creates a pthread to contain the specified v2pthread task.
*****************************************************************************/
/* Started by AICoder, pid:f498cge80a70dae14565097a9058f351ad6544e6 */
int taskSpawn(const char *name, int pri, int opts, int stksize,
              int (*funcptr) (int, int, int, int, int, int, int, int, int,
                              int), int arg1, int arg2, int arg3, int arg4,
              int arg5, int arg6, int arg7, int arg8, int arg9, int arg10)
{
    WIND_TCB *task;
    int my_tid;
    STATUS error;
    char myname[16];
    INT32 iSnpRet = 0;

    if(NULL == funcptr || stksize<0)
        return ERROR;
    task = ts_malloc(sizeof(*task));
    if (!task) {
        error = S_smObjLib_NOT_INITIALIZED;
        my_tid = (int) error;
        goto exit;
    }
    memset(task,0,sizeof(*task));
    //Synthesize a default task name if none specified
    my_tid = new_tid();
    TRACE_DLL_F("%i %s %i %x", my_tid, name, pri, funcptr);
    if (!name) {
        iSnpRet = snprintf_s(myname,sizeof(myname), "t%d", my_tid);
        SNPRINTF_S_CHECK(iSnpRet, sizeof(myname));
        name = &(myname[0]);
    }
    error = taskInit(task, (char *)name, pri, opts, (char *) NULL, stksize, funcptr,
                     arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10);
    if (error != OK) {
        ts_free((void *) task);
        goto exit;
    }
    // Establish 'normal' task identifier, overwriting taskid set by taskInit call.
    //pthread_cleanup_push((void (*)(void *)) pthread_mutex_unlock, (void *) &task_list_lock);
    //pthread_mutex_lock(&task_list_lock);
    task->taskid = my_tid;

    task->static_task = 0;        // Indicate TCB dynamically allocated
    blockticksig(); // 编译找不到符号
    //pthread_mutex_unlock(&task_list_lock);
    //pthread_cleanup_pop(0);

    //在taskActivate失败的情况下, 代码会直接返回my_tid, 而不会释放task的内存。
    error = taskActivate(my_tid);
    if (error != OK) {
        my_tid = errno = (int) error;
        ts_free((void *) task);
    }

exit:
    return (my_tid);

}
/* Ended by AICoder, pid:f498cge80a70dae14565097a9058f351ad6544e6 */

extern void *cygwin_get_thread_handle(pthread_t pth);
/*****************************************************************************
** taskSuspend - suspends the specified v2pthread task
*****************************************************************************/
STATUS taskSuspend(int tid)
{
    WIND_TCB *pTcb;
#ifndef __linux__
#ifndef __MINGW32__    
    void * handle;
#else
    HANDLE handle;
    int ret;
#endif
    pthread_t pth;
       if(pTcb)
        pTcb=taskTcb(tid);
    else
        pTcb=my_task();
    if(NULL == pTcb){
        errno=S_objLib_OBJ_ID_ERROR;
        return ERROR;
    }
    if(pTcb->state &= SUSPEND)
        return OK;
    pth=pTcb->pthrid;
    pTcb->state |= SUSPEND;
#ifndef __MINGW32__
    handle=cygwin_get_thread_handle(pth);
#else
    handle=pthread_getw32threadhandle_np(pth);
#endif
    SuspendThread(handle);
#else
    pTcb = taskTcb(tid);

    if (NULL == pTcb) {
        return ERROR;
    }
   
    pthread_mutex_lock(&(pTcb->tsuspend_lock));
    pTcb->state |= SUSPEND;
    /* modified by liujiusheng */
    pthread_kill(pTcb->pthrid, SIG_TASKSUSPEND);
    pthread_mutex_unlock(&(pTcb->tsuspend_lock));
#endif
    return (OK);
}

/*****************************************************************************
** taskResume - creates a pthread to contain the specified v2pthread task and
*****************************************************************************/
STATUS taskResume(int tid)
{
    WIND_TCB *pTcb;
#ifndef __linux__
    pthread_t pth;
    void * handle;
    pTcb=taskTcb(tid);
    if(NULL == pTcb){
        errno=S_objLib_OBJ_ID_ERROR;
        return ERROR;
    }
    if(!(pTcb->state &= SUSPEND))
        return OK;
    pth=pTcb->pthrid;
#ifndef __MINGW32__
    handle=cygwin_get_thread_handle(pth);
#else
    handle=pthread_getw32threadhandle_np(pth);
#endif
    pTcb->state &= ~SUSPEND;
    ResumeThread(handle);
#else
    pTcb=taskTcb(tid);
    if (NULL == pTcb) {
        return ERROR;
    }
    pthread_mutex_lock(&(pTcb->tsuspend_lock));
    pTcb->state &= ~SUSPEND;
    pthread_cond_signal(&(pTcb->tsuspendable));
    pthread_mutex_unlock(&(pTcb->tsuspend_lock));
    
#endif
    return (OK);
}

/*****************************************************************************
** taskPriorityGet - examines the current priority for the specified task
*****************************************************************************/
STATUS taskPriorityGet(int tid, int *priority)
{
    WIND_TCB *task;
    STATUS error  = OK;

    taskLock();

    task = task_for(tid);
    if (task) {
        if (priority != (int *) NULL)
            *priority = task->vxw_priority;
    } else
        error = S_objLib_OBJ_ID_ERROR;

    taskUnlock();

    if (error != OK) {
        errno = (int) error;
        error = ERROR;
    }
    return (error);
}


/*****************************************************************************
** taskPrioritySet - sets a new priority for the specified task
*****************************************************************************/
STATUS taskPrioritySet(int tid, int pri)
{
    WIND_TCB *task;
    int new_priority, sched_policy;
    STATUS error;

    error = OK;

    taskLock();

    task = task_for(tid);

    if (!task) {
        error = S_objLib_OBJ_ID_ERROR;
        goto exit;
    }
    //  Translate the v2pthread priority into a pthreads priority
    pthread_attr_getschedpolicy(&(task->attr), &sched_policy);
    //pthread_getschedparam(task->pthrid, &sched_policy2, &schedparam2);
    new_priority = translate_priority(pri, sched_policy, &error);

    /*
     **  Update the TCB with the new priority
     */
    task->vxw_priority = pri;
    (task->prv_priority).sched_priority = new_priority;

    /*
     **  If the selected task is not the currently-executing task,
     **  modify the pthread's priority now.  If the selected task
     **  IS the currently-executing task, the taskUnlock operation
     **  will restore this task to the new priority level.
     */
    if ((tid != 0) && (task != my_task())) {
        struct sched_param schedparam;
        pthread_attr_setschedparam(&task->attr, &task->prv_priority);
        pthread_attr_getschedparam(&task->attr, &schedparam);
        schedparam.sched_priority = new_priority;
        pthread_attr_setschedparam(&task->attr, &schedparam);
        pthread_setschedparam(task->pthrid, sched_policy, &schedparam);
    }
  exit:
    taskUnlock();

    if (error != OK) {
        errno = (int) error;
        error = ERROR;
    }
    return (error);
}
/*tid:  任务Id,    prior :任务优先级(linux下)*/
STATUS BspSetVxTaskPriority(int tid,int linuxPrior)
{
    int vxPrior = 100;
    
    if((tid<=0)||(linuxPrior<12)||(linuxPrior>97))
    {
        dbgErr("%s>>Input Err !Range[tid>0;linuxPrior(12~97)]\n",__FUNCTION__);
        return BSP_ERROR;
    }
   /*此处为优先级转换linux->vxworks*/
   /*vxPrior= (99 - (linuxPrior +2))*3 ;*/
   vxPrior = (97-linuxPrior)*3;
   
    return taskPrioritySet(tid,vxPrior);
}
/*****************************************************************************
** taskName - returns the name of the specified v2pthread task
*****************************************************************************/
/* Started by AICoder, pid:lb840af6c2s4e4214672088bd00e9426a2b3cbcc */
char *taskName(int tid)
{
    WIND_TCB *t;
    static char acTmpVal[] = "\0";
    //static char NullTaskName[] = "NULLTASK";
    // pthread_cleanup_push((void (*)(void *)) pthread_mutex_unlock, &task_list_lock);
    pthread_mutex_lock(&task_list_lock);

    t = task_for(tid);

    
    if (t) 
    {
        if (NULL == t->name)
        {
            t->name = acTmpVal;
        }
        pthread_mutex_unlock(&task_list_lock);
        return t->name;
    }
    else
    {
        // pthread_cleanup_pop(1);
        pthread_mutex_unlock(&task_list_lock);
        return NULL;
    }
}
/* Ended by AICoder, pid:lb840af6c2s4e4214672088bd00e9426a2b3cbcc */
/*****************************************************************************
** taskNametoId - identifies the named v2pthread task
*****************************************************************************/
int taskNameToId(char *name)
{
    WIND_TCB *t;
    int tid;

    tid = (int) ERROR;

    if (!name)
        return tid;
    pthread_mutex_lock(&task_list_lock);
    for (t = task_list; t; t = t->nxt_task) {
        if ((strcmp(name, t->name)) == 0) {
            tid = t->taskid;
            break;
        }
    }
    pthread_mutex_unlock(&task_list_lock);

    return tid;
}

// utility function for taskDelete
// NOTE: called after taskLock, and exits in locked state
void task_pend_delete(WIND_TCB * self_task, WIND_TCB * t)
{
    #if 0
    /*
     **  Specified task is a different task, but not deletable.
     **  Our task must pend until the specified task becomes
     **  deletable.  Add our task to the list of tasks waiting to
     **  delete the specified task.
     */
    TRACE_DLL_F("%x %x ", self_task, t);
    link_susp_task(&t->first_susp, self_task);

    /*
     **  Lock mutex for task delete_safe_count & condition variable
     */
    TRACE_DLL_F("taskDelete - lock delete cond var mutex @ task %p", t);
    // pthread_cleanup_push((void (*)(void *)) pthread_mutex_unlock, (void *) &(t->tdelete_lock));
    pthread_mutex_lock(&(t->tdelete_lock));

    //  Unlock scheduler to allow other tasks to make specified task deletable.
    taskUnlock();

    //  Wait without timeout for task to become deletable.
    TRACE_DLL_F("taskDelete - wait till task @ task %p deletable", t);
    while (t->delete_safe_count > 0) {
        pthread_cond_wait(&(t->t_deletable), &(t->tdelete_lock));
    }

    TRACE_DLL_F("taskDelete - task @ task %p now deletable", t);
    taskLock();

    /*
     **  Remove the calling task's task from the pended task list
     **  for the task being deleted.  Clear the calling task 's
     **  suspend list pointer since the TCB it was suspended on is
     **  being deleted and deallocated.
     */
    //unlink_susp_task(&(t->first_susp), self_task);
    TRACEV("%x", self_task->waiting);
    if (self_task->waiting) unlink_susp_task(&self_task->first_susp, self_task);
    //self_task->suspend_list = NULL;

    /*
     **  If our task was the last one pended, signal the task
     **  which enabled the deletion and indicate that all pended
     **  tasks have been awakened.
     */
    if (t->first_susp == (WIND_TCB *) NULL) {
        // Lock mutex for task delete broadcast completion
        TRACE_DLL_F("taskDelete - lock del bcast mutex @ task %p", t);
        // pthread_cleanup_push((void (*)(void *)) pthread_mutex_unlock, (void *) &(t->dbcst_lock));
        pthread_mutex_lock(&(t->dbcst_lock));

        // Signal task delete broadcast completion. 
        TRACE_DLL_F("taskDelete - bcast delete complt @ task %p", t);
        pthread_cond_broadcast(&(t->delete_bcplt));

        //  Unlock the task delete broadcast completion mutex. 
        TRACE_DLL_F("taskDelete - unlock del bcast mutex @ task %p", t);
        //pthread_cleanup_pop(1);
        pthread_mutex_unlock(&(t->dbcst_lock));
        //task_deletable = TRUE;
    }
    // Unlock the mutex for the condition variable and clean up.
    TRACE_DLL_F("taskDelete - unlock delete cond var mutex @ task %p", t);
    // pthread_cleanup_pop(1);
    pthread_mutex_unlock(&(t->tdelete_lock));
    #endif
}

/*****************************************************************************
** taskDelete - removes the specified task(s) from the task list,
**              frees the memory occupied by the task struct(s),
**              and kills the pthread(s) associated with the task(s).
*****************************************************************************/
STATUS taskDelete(int tid)
{
    WIND_TCB *t;
    WIND_TCB *self_task = my_task();
    int task_deletable;
    STATUS error  = OK;

    taskLock();
    t = task_for(tid);
    if (!t) {
        error = S_objLib_OBJ_DELETED;
        TRACE_DLL_F("%x not found",tid);
        goto exit;
    }
    /*
     **  If the current task is one of several attempting to delete the
     **  specified task, then only the first of the deleting tasks will
     **  actually succeed in deleting the target task.
     */
    TRACE_DLL_F("%x", t);
    // pthread_cleanup_push((void (*)(void *)) pthread_mutex_unlock, &t->tdelete_lock); 
    pthread_mutex_lock(&t->tdelete_lock);

    if (t->delete_safe_count > 0)
        task_deletable = FALSE;
    else
        task_deletable = TRUE;

    // pthread_cleanup_pop(1);
    pthread_mutex_unlock(&t->tdelete_lock);

    if (task_deletable == TRUE)
        error = taskDeleteForce(tid);

    if (task_deletable == FALSE) {
        if (t == self_task) {
            /*
             **  Task being deleted is currently executing task, and is
             **  delete-protected at this time...
             **  Task cannot block or delete itself while delete-protected.
             */
            TRACE_DLL_F("can't self-delete prot task @ task %p", t);
            error = S_objLib_OBJ_UNAVAILABLE;
        } else {
            /*
             **  Specified task is a different task, but not deletable.
             **  Our task must pend until the specified task becomes
             **  deletable.  Add our task to the list of tasks waiting to
             **  delete the specified task.
             */
            task_pend_delete(self_task, t);
        }
    }

  exit:
    taskUnlock();

    if (error != OK) {
        errno = (int) error;
        error = ERROR;
    }

    return error;
}

/*****************************************************************************
** taskRestart - terminates the specified task and starts it over from its
**               entry point.
*****************************************************************************/
STATUS taskRestart(int tid)
{
#if 0
    WIND_TCB *t;
    taskLock();
    WIND_TCB *self_task= my_task();
    STATUS error = OK;

    if (tid == 0)
        t = self_task;
    else
        t = task_for(tid);

    if (!t) {
        error = S_objLib_OBJ_ID_ERROR;
        goto exit;
    }
    TRACE_DLL_F("%x ", t);
    //unlink_susp_task(&t->suspend_list, t); // ???
    //TRACEV("%x", t->waiting);
    if (t->waiting) unlink_susp_task(&t->first_susp, t);

    if (t != self_task) {
        /*
         **  Task being restarted is not the current task.
         **  Kill the task pthread and wait for it to die.
         */
        TRACE_DLL_F("taskRestart - other task @ %x", t);
        pthread_cancel(t->pthrid);
        pthread_join(t->pthrid, (void **) NULL);
        tcb_delete_hash_table(t->pthrid);  
        //  Start a new pthread using the existing task struct.
        #ifndef __MINGW32__
        t->pthrid = (pthread_t) NULL;
        #else
        t->pthrid.p = 0;
        t->pthrid.x = 0;
        #endif
        t->state = READY;
        #ifdef _USE_SEM_FUTEX_
        if (t->pend_sem != NULL) {
            t->pend_sem->waiting_count--;
            t->pend_sem = NULL;
        }
        #endif

        if (pthread_create(&t->pthrid, &t->attr,(start_routine) task_wrapper, (void *) t) != 0) {
            perror("taskRestart pthread_create returned error:");
            error = S_memLib_NOT_ENOUGH_MEMORY;
        } else {
            tcb_input_hash_table(t);
        }
    } else {
        //  Restart the currently executing task.
        TRACE_DLL_F(" self task @ %p", t);

        //  Detach our task's pthread to clean up memory, etc. without a 'join' operation.
        pthread_detach(self_task->pthrid);

        // must delete tcb from hash before task over
        tcb_delete_hash_table(self_task->pthrid);  
        
        //  Start a watchdog timer to restart our task after we terminate.
        selfRestart(self_task);

        // Kill the currently executing task's pthread.
        pthread_exit(NULL);
    }

    taskUnlock();
  exit:
    if (error != OK) {
        errno = (int) error;
        error = ERROR;
    }
    return (error);
#endif
    return 0;
}

/*****************************************************************************
** taskSafe - marks the calling task as safe from explicit deletion.
*****************************************************************************/
STATUS taskSafe(void)
{
#if 0
    WIND_TCB *t;
    TRACE_DLL_F();    
    taskLock();

    t = my_task();

    /*
     **  Lock mutex for task delete_safe_count & condition variable
     */
    pthread_cleanup_push((void (*)(void *)) pthread_mutex_unlock, (void *) &(t->tdelete_lock));
    pthread_mutex_lock(&(t->tdelete_lock));
    TRACE_DLL_F(" lock delete cond var mutex @ task %p", t);

    // Increment task delete_safe_count and adjust for any overflow.
    t->delete_safe_count++;
    if (t->delete_safe_count <= 0) {
        fprintf(stderr, "delete_safe_count overflow");
        t->delete_safe_count--;
    }
    TRACE_DLL_F("new delete_safe_count %d @ task %p", t->delete_safe_count, t);
    pthread_cleanup_pop(1);

    taskUnlock();
#endif
    return OK;
}

/*****************************************************************************
** taskUnsafe - marks the calling task as subject to explicit deletion.
*****************************************************************************/
STATUS taskUnsafe(void)
{
#if 0
    WIND_TCB *t;
    int task_made_deletable;

    taskLock();

    t = my_task();

    task_made_deletable = FALSE;

    TRACE_DLL_F("lock delete cond var mutex @ task %p", t);
    pthread_cleanup_push((void (*)(void *)) pthread_mutex_unlock, (void *) &(t->tdelete_lock));
    pthread_mutex_lock(&(t->tdelete_lock));

    if (t->delete_safe_count > 0) {
        t->delete_safe_count--;
        if (t->delete_safe_count == 0)
            task_made_deletable = TRUE;
    }
    TRACE_DLL_F("new delete_safe_count %d @ task %p", t->delete_safe_count, t);

    TRACE_DLL_F("unlock delete cond var mutex @ task %p", t);
    pthread_cleanup_pop(1);

    taskUnlock();

    if (task_made_deletable) {
        /*
         **  Task just made deletable... ensure that we awaken any
         **  other tasks pended on deletion of this task
         */
        if (t->first_susp != (WIND_TCB *) NULL) {
            notify_task_delete(t);
        }
    }
#endif
    return ((STATUS) OK);
}

WIND_TCB *taskTcb(int taskid)
{
    WIND_TCB *task;

    pthread_mutex_lock(&task_list_lock);
    task = task_for(taskid);
    pthread_mutex_unlock(&task_list_lock);

    return task;
}

void display_task(FILE * out, ulong tid)    // OLD
{
    TRACE_DLL_F();
    int policy;
    int detachstate;
    struct sched_param schedparam;
    WIND_TCB *cur_task;
    INT32 iTmpRet = 0;

    cur_task = task_for(tid);

    if (cur_task == (WIND_TCB *) NULL)
        return;

    iTmpRet = fprintf(out, "Task %p Name: %s  Task ID: %d  Thread ID: %lx  Vxworks priority: %d",
            cur_task,
            cur_task->name, cur_task->taskid, cur_task->pthrid, cur_task->vxw_priority);
    FPRINTF_CHECK(iTmpRet);

    pthread_attr_getschedpolicy(&cur_task->attr, &policy);
    //pthread_getschedparam(task->pthrid, &sched_policy2, &schedparam2);
    switch (policy) {
    case SCHED_FIFO:
        iTmpRet = fprintf(out, "schedpolicy: SCHED_FIFO ");
        FPRINTF_CHECK(iTmpRet);
        break;
    case SCHED_RR:
        iTmpRet = fprintf(out, "schedpolicy: SCHED_RR ");
        FPRINTF_CHECK(iTmpRet);
        break;
    case SCHED_OTHER:
        iTmpRet = fprintf(out, "schedpolicy: SCHED_OTHER ");
        FPRINTF_CHECK(iTmpRet);
        break;
    default:
        iTmpRet = fprintf(out, "schedpolicy: %d ", policy);
        FPRINTF_CHECK(iTmpRet);
    }
    pthread_attr_getschedparam(&cur_task->attr, &schedparam);
    iTmpRet = fprintf(out, " priority %d ", schedparam.sched_priority);
    FPRINTF_CHECK(iTmpRet);
    iTmpRet = fprintf(out, " prv_priority %d ", cur_task->prv_priority.sched_priority);
    FPRINTF_CHECK(iTmpRet);
    pthread_attr_getdetachstate(&cur_task->attr, &detachstate);
    iTmpRet = fprintf(out, " detachstate %d ", detachstate);
    FPRINTF_CHECK(iTmpRet);
    iTmpRet = fprintf(out, "\n");
    FPRINTF_CHECK(iTmpRet);
}

STATUS     taskShow (int tid, int level)
{
#if 0
    int policy;
    int detachstate;
    struct sched_param schedparam;
    WIND_TCB * t;
    FILE * out=stdout;

    t=task_for(tid);
    fprintf(out, "%#10x %10p %10s ", t->taskid, t, t->name);
    //fprintf(out, "th:%x ", t->pthrid);
    fprintf(out, "s:%#x ", t->state);
    if ( t->state & PEND  ) fprintf(out, "P ");
    if ( t->state & DELAY  ) fprintf(out, "D " );
    fprintf(out, "w:%p ", t->waiting);
    if (t->waiting && t->waiting->current_owner)  {
        fprintf(out, "%s ", t->waiting->current_owner->name);
    }
    fprintf(out, "w:%p ", t->waiting_m);
    fprintf(out, "s:%p ", t->first_susp);
    //fprintf(out, " Thread ID: %lx  Vxworks priority: %d", t->pthrid, t->vxw_priority);

    pthread_attr_getschedpolicy(&t->attr, &policy);
    //pthread_getschedparam(task->pthrid, &sched_policy2, &schedparam2);
    switch (policy) {
    case SCHED_FIFO:
        fprintf(out, "SCHED_FIFO ");
        break;
    case SCHED_RR:
        fprintf(out, "SCHED_RR ");
        break;
    case SCHED_OTHER:
        fprintf(out, "SCHED_OTHER ");
        break;
    default:
        fprintf(out, "schedpolicy: %d ", policy);
    }
    pthread_attr_getschedparam(&t->attr, &schedparam);
    fprintf(out, " pri %d ", schedparam.sched_priority);
    fprintf(out, " prv_pri %d ", t->prv_priority.sched_priority);
    pthread_attr_getdetachstate(&t->attr, &detachstate);
    //fprintf(out, " detachstate %d ", detachstate);
    fprintf(out, "\n");
#endif
    return OK;
}

void taskShow_old(FILE * out, WIND_TCB * t)
{
#if 0
    int policy;
    int detachstate;
    struct sched_param schedparam;

    fprintf(out, "%#10x %10p %10s ", t->taskid, t, t->name);
    //fprintf(out, "th:%x ", t->pthrid);
    fprintf(out, "s:%#x ", t->state);
    if ( t->state & PEND  ) fprintf(out, "P ");
    if ( t->state & DELAY  ) fprintf(out, "D " );
    fprintf(out, "w:%p ", t->waiting);
    if (t->waiting && t->waiting->current_owner)  {
        fprintf(out, "%s ", t->waiting->current_owner->name);
    }
    fprintf(out, "w:%p ", t->waiting_m);
    fprintf(out, "s:%p ", t->first_susp);
    //fprintf(out, " Thread ID: %lx  Vxworks priority: %d", t->pthrid, t->vxw_priority);

    pthread_attr_getschedpolicy(&t->attr, &policy);
    //pthread_getschedparam(task->pthrid, &sched_policy2, &schedparam2);
    switch (policy) {
    case SCHED_FIFO:
        fprintf(out, "SCHED_FIFO ");
        break;
    case SCHED_RR:
        fprintf(out, "SCHED_RR ");
        break;
    case SCHED_OTHER:
        fprintf(out, "SCHED_OTHER ");
        break;
    default:
        fprintf(out, "schedpolicy: %d ", policy);
    }
    pthread_attr_getschedparam(&t->attr, &schedparam);
    fprintf(out, " pri %d ", schedparam.sched_priority);
    fprintf(out, " prv_pri %d ", t->prv_priority.sched_priority);
    pthread_attr_getdetachstate(&t->attr, &detachstate);
    //fprintf(out, " detachstate %d ", detachstate);
    fprintf(out, "\n");
#endif
}

void taskIdListSort
    (
    int idList[],        /* id list to sort */
    int nTasks            /* number of tasks in id list */
    )
    {
    }


#if 0
int taskList(FILE * out, int mem)
{
    int c=0;
    TRACE_DLL_F();
    WIND_TCB *t = task_list;
    taskLock();
    while (t) {
        taskShow_old(stdout,t);
        if (mem) {
            int *w;
            for (w = (int *) t; w < (int *) (t + 1); w++)
                fprintf(out, "%x ", *w);
            fprintf(out, "\n");
        }
        t = t->nxt_task;
        c++;
    }
    taskUnlock();
    return c;
}
#endif

#define ERR(e) case e: return #e;
char * VxWorksError(STATUS status)
{
    switch ( status ) {
        ERR(S_memLib_NOT_ENOUGH_MEMORY);
        ERR(S_msgQLib_INVALID_MSG_LENGTH);
        ERR(S_objLib_OBJ_DELETED);
        ERR(S_objLib_OBJ_ID_ERROR)
        ERR(S_objLib_OBJ_TIMEOUT);
        ERR(S_objLib_OBJ_UNAVAILABLE);
        ERR(S_semLib_INVALID_OPERATION);
        ERR(S_smObjLib_NOT_INITIALIZED);
        ERR(S_taskLib_ILLEGAL_PRIORITY);
        default:
            return strerror(status);
    }
}

void *taskStackAllot
    (
    int      tid,               /* task whose stack will be allotted from */
    unsigned nBytes             /* number of bytes to allot */
    )
    {
    return  0;

    }

/*******************************************************************************
*
* taskRegsGet - get a task's registers from the TCB
*
* This routine gathers task information kept in the TCB.  It copies the
* contents of the task's registers to the register structure <pRegs>.
*
* NOTE
* This routine only works well if the task is known to be in a stable,
* non-executing state.  Self-examination, for instance, is not advisable,
* as results are unpredictable.
*
* RETURNS: OK, or ERROR if the task ID is invalid.
*
* SEE ALSO: taskSuspend(), taskRegsSet()
*/

/*******************************************************************************
*
* taskStatusString - get a task's status as a string
*
* This routine deciphers the WIND task status word in the TCB for a
* specified task, and copies the appropriate string to <pString>.
* 
* The formatted string is one of the following:
*
* .TS
* tab(|);
* lf3 lf3
* l l .
* String   | Meaning
* _
* READY    | Task is not waiting for any resource other than the CPU.
* PEND     | Task is blocked due to the unavailability of some resource.
* DELAY    | Task is asleep for some duration.
* SUSPEND  | Task is unavailable for execution (but not suspended, delayed, or pended).
* DELAY+S  | Task is both delayed and suspended.
* PEND+S   | Task is both pended and suspended.
* PEND+T   | Task is pended with a timeout.
* PEND+S+T | Task is pended with a timeout, and also suspended.
* \&...+I  | Task has inherited priority (+I may be appended to any string above).
* DEAD     | Task no longer exists.
* .TE
*
* EXAMPLE
* .CS
*     -> taskStatusString (taskNameToId ("tShell"), xx=malloc (10))
*     new symbol "xx" added to symbol table.
*     value = 0 = 0x0
*     -> printf ("shell status = <%s>\en", xx)
*     shell status = <READY>
*     value = 2 = 0x2
* .CE
*
* RETURNS: OK, or ERROR if the task ID is invalid.
*/

STATUS taskStatusString
    (
    int  tid,           /* task to get string for */
    char *pString       /* where to return string */
    )
    {
    return OK;
}

// 该函数是给进程监控shell使用,用来判断目前是否使用了V2LIN
int  use_zte_chengyan_v2lin(void)
{
    return 1;
}

/**************************信号量相关******************************/
#define SEM_OPT_MASK       0x0f
#define SEM_TYPE_MASK      0xf0

#define BINARY_SEMA4       0x00
#define MUTEX_SEMA4        0x10
#define COUNTING_SEMA4     0x20

#define SEND  0
#define FLUSH 1
#define KILLD 2

/*****************************************************************************
**  Control block for v2pthread semaphore
**
**  The basic POSIX semaphore does not provide for time-bounded waits nor
**  for selection of a thread to ready based either on FIFO or PRIORITY-based
**  waiting.  This 'wrapper' extends the POSIX pthreads semaphore to include
**  the attributes of a v2pthread semaphore.
**
*****************************************************************************/

extern STATUS semShow (SEM_ID semId, int level)
{
#ifndef DISABLE_SEM_V2LIN_STYLE
	v2lsem_t *s;
	FILE * out;
	int mem;
	WIND_TCB *t;
	s=semId;
	out=stdout;
	mem=level;
	fprintf(out,"o:%p ",s->current_owner);
	if (s->current_owner ) { 
		pthread_cleanup_push((void (*)(void *)) pthread_mutex_unlock, &task_list_lock); 
		pthread_mutex_lock(&task_list_lock);
		// look for the task t
		for (t = task_list; t; t = t->nxt_task) 
			if (t == s->current_owner) break;
		pthread_cleanup_pop(1);
		if (!t) // task not found
			fprintf(out,"<deleted> ");
		else fprintf(out,"%s ",s->current_owner->name);
	}
	fprintf(out,"rl:%i ",s->recursion_level);
	fprintf(out,"tc:%i ",s->token_count);
	fprintf(out,"(");
	for ( t = s->first_susp; t; t = t->nxt_susp ) {
		fprintf(out,"%p ",t);
		fprintf(out,"%s ",t->name);
	}
	fprintf(out,") ");
	fprintf(out,"%x ",s->send_type);

	if ( mem ) {
		int * i;
		for ( i = (int*)s; i < (int*) (s+1);i++) 
			fprintf(out,"%x ",*i);
	}
	fprintf(out,"\n");
#endif
	return OK;
}

void semShow_old(v2lsem_t *s, FILE * out, int mem)
{
#ifndef DISABLE_SEM_V2LIN_STYLE
	WIND_TCB *t;
	fprintf(out,"o:%p ",s->current_owner);
	if (s->current_owner ) { 
		pthread_cleanup_push((void (*)(void *)) pthread_mutex_unlock, &task_list_lock); 
		pthread_mutex_lock(&task_list_lock);
		// look for the task t
		for (t = task_list; t; t = t->nxt_task) 
			if (t == s->current_owner) break;
		pthread_cleanup_pop(1);
		if (!t) // task not found
			fprintf(out,"<deleted> ");
		else fprintf(out,"%s ",s->current_owner->name);
	}
	fprintf(out,"rl:%i ",s->recursion_level);
	fprintf(out,"tc:%i ",s->token_count);
	fprintf(out,"(");
	for ( t = s->first_susp; t; t = t->nxt_susp ) {
		fprintf(out,"%p ",t);
		fprintf(out,"%s ",t->name);
	}
	fprintf(out,") ");
	fprintf(out,"%x ",s->send_type);

	if ( mem ) {
		int * i;
		for ( i = (int*)s; i < (int*) (s+1);i++) 
			fprintf(out,"%x ",*i);
	}
	fprintf(out,"\n");
#endif
}

int semList(FILE * out, int mem)
{
	dbgInfo("-------semList-----\n");
	return 0;
}

/*****************************************************************************
** new_sem - creates a new v2pthread semaphore using pthreads resources
*****************************************************************************/
v2lsem_t *new_sem(int count)
{
#ifndef DISABLE_SEM_V2LIN_STYLE
	v2lsem_t *pSem;

	pSem = (v2lsem_t *) ts_malloc(sizeof(v2lsem_t));
	if (! pSem ) {
		return NULL;
	}
	memset(pSem,0,sizeof(*pSem));
	pSem->token_count = count;
	pSem->count_orig=count;

	/*
	 ** Mutex and Condition variable for semaphore send/pend
	 */
	pthread_mutex_init(&pSem->sem_lock, NULL);
	pthread_cond_init(&pSem->sem_send, NULL);

	pthread_mutex_init(&pSem->smdel_lock, NULL);
	pthread_cond_init(&pSem->smdel_cplt, NULL);

	pSem->send_type = SEND;
	pSem->recursion_level = 0;
	pSem->current_owner = NULL;
	pSem->owner = 0;
	pSem->first_susp =  NULL;

	pSem->magic=V2LIN_MAGIC_SEM;
	return pSem;
#else
    dbgInfo("new_sem not use!!!\n");
    return NULL;
#endif
}

/*****************************************************************************
** semBCreate - creates a v2pthread binary semaphore
*****************************************************************************/
v2lsem_t *semBCreate(int opt, SEM_B_STATE initial_state)
{
	v2lsem_t *pSem;
#ifdef DISABLE_SEM_V2LIN_STYLE
    int init_value = 0;
    pSem = (v2lsem_t *)malloc(sizeof(v2lsem_t));
    if (pSem == NULL)
    {
        dbgErr("semBCreate: malloc sem failed\n");
        return NULL;
    }
    memset(pSem,0,sizeof(v2lsem_t));
    pSem->sem_type = SYNC_SEM_TYPE;
    
    if (initial_state == SEM_EMPTY)
    {
        init_value = 0;
    }
    else if (initial_state == SEM_FULL)
    {
        init_value = 1;
    }
    else
    {
        dbgErr("semBCreate: invalid initial states %d\n",initial_state);
        free(pSem);
        return NULL;
    }

    if (0 != sem_init(&(pSem->sem_obj.sem),0,init_value))   
    {
        dbgErr("semBCreate: sem_init failure error=%d!\n",errno);
        free(pSem);
        return NULL;
    }
#else
	if ((opt & SEM_Q_PRIORITY)
			|| (opt & SEM_DELETE_SAFE)
			|| (opt & SEM_INVERSION_SAFE)) {
		//强制支持
		//errno = ENOSYS;
		//return (NULL);
	}

	if (initial_state == 0)
		pSem = new_sem(0);
	else
		pSem = new_sem(1);

	if (! pSem ) return NULL;
	TRACE_DLL_F("%x %#x %x", pSem,opt,initial_state);

	pSem->flags = (opt & SEM_Q_PRIORITY) | BINARY_SEMA4;
#endif
	return pSem;
}

STATUS semBInit
    (
    SEMAPHORE  *pSemaphore,             /* pointer to semaphore to initialize */
    int         options,                /* semaphore options */
    SEM_B_STATE initialState            /* initial semaphore state */
    )
{
	if ( ! pSemaphore ) return ERROR;
#ifdef DISABLE_SEM_V2LIN_STYLE
	int init_value = 0;

	memset(pSemaphore,0,sizeof(v2lsem_t));
	pSemaphore->sem_type = SYNC_SEM_TYPE;
	
	if (initialState == SEM_EMPTY)
	{
		init_value = 0;
	}
	else if (initialState == SEM_FULL)
	{
		init_value = 1;
	}
	else
	{
		dbgErr("semBCreate: invalid initial states %d\n",initialState);
		return ERROR;
	}

	if (0 != sem_init(&(pSemaphore->sem_obj.sem),0,init_value))	
	{
		dbgErr("semBCreate: sem_init failure error=%d!\n",errno);
		return ERROR;
	}
	return (OK);
#else
	new_sem_placement(pSemaphore,initialState);
	pSemaphore->static_sem=1;
	pSemaphore->flags = (options & SEM_Q_PRIORITY) | BINARY_SEMA4;
	return (OK);
#endif
    }

/*****************************************************************************
** semCCreate - creates a v2pthread counting semaphore
*****************************************************************************/
v2lsem_t *semCCreate(int opt, int initial_count)
{
	v2lsem_t *pSem;
#ifdef DISABLE_SEM_V2LIN_STYLE
	pSem = (v2lsem_t *)malloc(sizeof(v2lsem_t));
	if (pSem == NULL)
	{
		dbgErr("semBCreate: malloc sem failed\n");
		return NULL;
	}
	memset(pSem,0,sizeof(v2lsem_t));
	pSem->sem_type = COUNT_SEM_TYPE;

	if (0 != sem_init(&(pSem->sem_obj.sem),0,initial_count))	
	{
		dbgErr("semBCreate: sem_init failure error=%d!\n",errno);
		free(pSem);
		return NULL;
	}
#else

	if ((opt & SEM_Q_PRIORITY)
			|| (opt & SEM_DELETE_SAFE)
			|| (opt & SEM_INVERSION_SAFE)) {
		//errno = ENOSYS;
		//return (NULL);
	}

	pSem = new_sem(initial_count);

	if (! pSem ) return NULL;
	TRACE_DLL_F("Creating counting semaphore - id %p", pSem);

	pSem->flags = (opt & SEM_Q_PRIORITY) | COUNTING_SEMA4;
#endif
	return pSem;
}

/*****************************************************************************
** semMCreate - creates a v2pthread mutual exclusion semaphore
*****************************************************************************/
/* Started by AICoder, pid:4e60du2ccf367dd14b9f0ae6204c7a4f5ee8e9d0 */
v2lsem_t *semMCreate(int opt)
{
	v2lsem_t *pSem;
#ifdef DISABLE_SEM_V2LIN_STYLE
    pthread_mutexattr_t attr;
    pSem = (v2lsem_t *)malloc(sizeof(v2lsem_t));
    if (pSem == NULL)
    {
        dbgErr("semMCreate: malloc sem failed\n");
        return NULL;
    }
    memset(pSem,0,sizeof(v2lsem_t));
    pSem->sem_type = MUTEX_TYPE;
    pthread_mutexattr_init(&attr);
    /*为了便于回收，这边不能使用 PTHREAD_MUTEX_RECURSIVE属性*/
    pthread_mutexattr_settype(&attr,PTHREAD_MUTEX_RECURSIVE); 
    pthread_mutexattr_setpshared (&attr, PTHREAD_PROCESS_SHARED);            
    if (0 != pthread_mutex_init(&(pSem->sem_obj.mutex),&attr))
    {
        pthread_mutexattr_destroy(&attr);
        free(pSem);
		pSem = NULL;
        dbgErr("semMCreate:pthread_mutex_init failed %s\n",strerror(errno));
        return NULL;
    }
    pthread_mutexattr_destroy(&attr); // 释放属性资源
#else
	if ((opt & SEM_Q_PRIORITY)
			|| (opt & SEM_DELETE_SAFE)
			|| (opt & SEM_INVERSION_SAFE)) {
		TRACE_DLL_F("WARNING not implemented");
		//暂时不返回失败，dxd
		//errno = ENOSYS;
		//return (NULL);
	}
	pSem = new_sem(1);

	if ( ! pSem ) return NULL;
	TRACE_DLL_F("Creating mutex semaphore - id %p", pSem);

	pSem->flags = (opt & SEM_OPT_MASK) | MUTEX_SEMA4;
#endif
	return pSem;
}
/* Ended by AICoder, pid:4e60du2ccf367dd14b9f0ae6204c7a4f5ee8e9d0 */
/*******************************************************************************
*
* semMInit - initialize a mutual-exclusion semaphore
*
* The initialization of a static mutual exclusion semaphore, or a mutual
* exclusion semaphore embedded in some larger object need not deal
* with allocation.  This routine may be called to initialize such a
* semaphore.  The semaphore state is initialized to the full state.
*
* Mutual exclusion semaphore options include the queuing style for blocked
* tasks.  Tasks may be queued on the basis of their priority or
* first-in-first-out.  These options are SEM_Q_PRIORITY and SEM_Q_FIFO
* respectively.
*
* The SEM_DELETE_SAFE option protects the task that currently owns the
* semaphore from unexpected deletion.  This option enables an implicit
* taskSafe() on each semTake(), and an implicit taskUnsafe() of every semGive().
*
* The SEM_INVERSION_SAFE option protects the system from priority inversion.
* This option must be accompanied by the SEM_Q_PRIORITY queuing mode.  With
* this option selected, the task owning the semaphore will execute at the
* highest priority of the tasks pended on the semaphore if it is higher than
* its current priority.
*
* RETURNS: OK, or ERROR if semaphore could not be initialized.
*
* ERRNO: S_semLib_INVALID_OPTION
*
* SEE ALSO: semLib, semBLib, semMCreate(), taskSafe(), taskUnsafe()
*
* NOMANUAL
*/
/* Started by AICoder, pid:t560ch0b41h9b6214c4d092f60dd842607389ad3 */
STATUS semMInit
    (
    SEMAPHORE * pSemaphore,     /* pointer to mutex semaphore to initialize */
    int         options         /* mutex semaphore options */
    )
{
#ifdef DISABLE_SEM_V2LIN_STYLE
    pthread_mutexattr_t attr;
#endif

    if ( ! pSemaphore ) 
        return ERROR;

#ifdef DISABLE_SEM_V2LIN_STYLE
    memset(pSemaphore,0,sizeof(v2lsem_t));
	pSemaphore->sem_type = MUTEX_TYPE;
	pthread_mutexattr_init(&attr);
	/*为了便于回收，这边不能使用 PTHREAD_MUTEX_RECURSIVE属性*/
	pthread_mutexattr_settype(&attr,PTHREAD_MUTEX_NORMAL); 
	pthread_mutexattr_setpshared (&attr, PTHREAD_PROCESS_SHARED);			 
	if (0 != pthread_mutex_init(&(pSemaphore->sem_obj.mutex),&attr))
	{
		pthread_mutexattr_destroy(&attr);
		dbgErr("semMInit:pthread_mutex_init failed %s\n",strerror(errno));
		return ERROR;
	}
    pthread_mutexattr_destroy(&attr); // 释放互斥锁属性资源 
#else
	new_sem_placement(pSemaphore,1);
	pSemaphore->static_sem=1;
	pSemaphore->flags = (options & SEM_OPT_MASK) | MUTEX_SEMA4;
#endif
	return (OK);
}
/* Ended by AICoder, pid:t560ch0b41h9b6214c4d092f60dd842607389ad3 */

/*****************************************************************************
** semDelete - removes the specified semaphore from the semaphore list and
**             frees the memory allocated for the semaphore control block.
*****************************************************************************/
STATUS semDelete(v2lsem_t * pSem)
{
#ifdef DISABLE_SEM_V2LIN_STYLE
    if (pSem == NULL)
    { 
        dbgErr("---semDelete check sem failed!!!---\n");
        return ERROR;
    }
    switch (pSem->sem_type)
    {
        case COUNT_SEM_TYPE:
        {
            if (0 != sem_destroy(&(pSem->sem_obj.sem)))
            {
                return FALSE;
            }
            break;
        }
        case SYNC_SEM_TYPE:
        {
            if (0 != sem_destroy(&(pSem->sem_obj.sem)))
            {
                return FALSE;
            }
            break;
        }
        case MUTEX_TYPE:
        {
            pthread_mutex_destroy(&(pSem->sem_obj.mutex));
            break;
        }
        default:
        {
            dbgErr("semDelete: Flag of semaphore is invalid!\n");
            return FALSE;
            break;
        }
    }
    return OK;
#else
        STATUS error = OK;

	if(FALSE==check_sem(pSem))
		return ERROR;
	pthread_cleanup_push((void (*)(void *)) pthread_mutex_unlock, &pSem->sem_lock);
	if (! sem_find_lock(pSem)) {
		error = S_objLib_OBJ_ID_ERROR;	/* Invalid semaphore specified */
		goto exit;
	}
	TRACE_DLL_F("task @ %p delete semaphore @ %p", my_task(), pSem);
	//  Send signal and block while any tasks are still waiting on the semaphore
	//taskLock();
	if (pSem->first_susp !=  NULL) {
		TRACE_DLL_F("isemDelete - tasks pending on semaphore list @ %p", pSem->first_susp);
		// Lock mutex for semaphore delete completion
		pthread_cleanup_push((void (*)(void *)) pthread_mutex_unlock, &pSem->smdel_lock);
		pthread_mutex_lock(&(pSem->smdel_lock));

		pSem->send_type = KILLD;

		pthread_cond_broadcast(&(pSem->sem_send));
              /*释放删除锁，以便最后一个获取线程发送删除确认通知*/
		pthread_mutex_unlock(&(pSem->smdel_lock));
		pthread_mutex_unlock(&(pSem->sem_lock));

		/*
		 **  Wait for all pended tasks to receive delete message.
		 **  The last task to receive the message will signal the
		 **  delete-complete condition variable.
		 */
		while (pSem->first_susp != (WIND_TCB *) NULL)
			pthread_cond_wait(&(pSem->smdel_cplt), &(pSem->smdel_lock));

		pthread_cleanup_pop(0);
	}

	pSem->magic=0;
	if(pSem->static_sem==0)
		ts_free((void *) pSem);
	//taskUnlock();

	exit:
	{}
	pthread_cleanup_pop(0);

	if (error != OK) {
		errno = (int) error;
		error = ERROR;
	}
	return error;
#endif
}

/*****************************************************************************
** semFlush - unblocks all tasks waiting on the specified semaphore
*****************************************************************************/
STATUS semFlush(v2lsem_t * pSem)
{
	STATUS error = OK;
#ifndef DISABLE_SEM_V2LIN_STYLE
	TRACE_DLL_F("%x",pSem);
	if(FALSE==check_sem(pSem))
		return ERROR;
	pthread_cleanup_push((void (*)(void *)) pthread_mutex_unlock, &pSem->sem_lock);
	if (!sem_find_lock(pSem)) {
		error = S_objLib_OBJ_ID_ERROR;	/* Invalid semaphore specified */
		goto exit;
	}
	if ((pSem->flags & SEM_TYPE_MASK) == MUTEX_SEMA4) {
		error = S_semLib_INVALID_OPERATION;	/* Flush invalid for mutex */
		pthread_mutex_unlock(&pSem->sem_lock);
		goto exit;
	}
	TRACE_DLL_F("task @ %p flush semaphore list @ %p", my_task(), &(pSem->first_susp));
	/*
	 **  Send signal and block while any tasks are still waiting
	 **  on the semaphore
	 */
	//taskLock();
	if (pSem->first_susp ) {
		// Lock mutex for semaphore delete completion
		pthread_cleanup_push((void (*)(void *)) pthread_mutex_unlock, &pSem->smdel_lock);
		pthread_mutex_lock(&(pSem->smdel_lock));

		pSem->send_type = FLUSH;
		pthread_cond_broadcast(&pSem->sem_send);
		pthread_mutex_unlock(&pSem->sem_lock);

		/*
		 **  Wait for all pended tasks to receive delete message.
		 **  The last task to receive the message will signal the
		 **  delete-complete condition variable.
		 */
		while (pSem->first_susp != NULL)
			pthread_cond_wait(&(pSem->smdel_cplt), &(pSem->smdel_lock));

		pthread_mutex_unlock(&(pSem->smdel_lock));
		pthread_cleanup_pop(0);
	}
	// TODO ??? else pthread_mutex_unlock(&(semaphore->sem_lock));
	//taskUnlock();
exit:
	{}
	pthread_cleanup_pop(0);

	if (error != OK) {
		errno = (int) error;
		error = ERROR;
	}
#endif
	return error;
}

/*****************************************************************************
** semGive - releases a v2pthread semaphore token and awakens the first
**           selected task waiting on the semaphore.
*****************************************************************************/
STATUS semGive(v2lsem_t * pSem)
{
#ifdef DISABLE_SEM_V2LIN_STYLE
    int value = 0;    
    if (pSem == NULL)
    { 
        dbgErr("---semGive check sem failed!!!---\n");
        return ERROR;
    }
    switch(pSem->sem_type)
    {
    case COUNT_SEM_TYPE:
        if (0 != sem_post(&(pSem->sem_obj.sem)))
        {
            return FALSE;
        }
        break;
    case SYNC_SEM_TYPE:
        if (sem_getvalue(&(pSem->sem_obj.sem), &value) != 0)
        {
            return FALSE;
        }
        if ((value < 1) && (0 != sem_post(&(pSem->sem_obj.sem))))
        {
            return FALSE;
        }
        break;
    case MUTEX_TYPE:
        pthread_mutex_unlock(&(pSem->sem_obj.mutex));
        break;
    default:
        dbgErr("semGive: Flag of semaphore is invalid!\n");
        return FALSE;
        break;
    }
	return OK;
#else
	pthread_t my_pthrid = pthread_self();
	STATUS error = OK;
	if(FALSE==check_sem(pSem)){
		return ERROR;
	}
	pthread_cleanup_push((void (*)(void *)) pthread_mutex_unlock, &pSem->sem_lock);
	if (! sem_find_lock(pSem)) {
		dbgErr("WARNING not found %p\n",pSem);
		error = S_objLib_OBJ_ID_ERROR;
		goto exit;
	}
	//  If semaphore is a mutex, make sure we own it before giving up the token.
	if (((pSem->flags & SEM_TYPE_MASK) == MUTEX_SEMA4) && pSem->current_owner && (pSem->owner  != my_pthrid) ) {
		//printf("-semGive--%s   %s--0x%x\n", my_task()->taskname, pSem->current_owner->name, pSem);
		error = S_semLib_INVALID_OPERATION;	
		goto unlock;
	}
	/*
	 **  Either semaphore isn't a mutex or we currently own the mutex.
	 **  If semaphore is a mutex, recursion level should be > zero.
	 **  In this case, decrement recursion level, and if level == zero
	 **  after decrement, relinquish mutex ownership.
	 */
	if (pSem->recursion_level > 0) {
		--pSem->recursion_level;
		if ( ! pSem->recursion_level ) {
			pSem->token_count++;
			pSem->current_owner =  NULL;
			pSem->owner =0;
			if (pSem->flags & SEM_DELETE_SAFE)
				// Task was made deletion-safe when mutex acquired...  Remove deletion safety now.
				taskUnsafe();
			if (pSem->flags & SEM_INVERSION_SAFE) {
				/*
				 **  Task priority may have been boosted during
				 **  ownership of semaphore...
				 **  Restore to original priority now.  Call taskLock
				 **  so taskUnlock can be called to restore priority.
				 */
				//taskLock();
				//taskUnlock();
			}
		}
		// else pSem->recursion_level > 0
	} else  {
		++pSem->token_count;
		pSem->current_owner=NULL;
		pSem->owner =0;
	}

	if (pSem->first_susp) {
		pthread_cond_broadcast(&pSem->sem_send);
	}
unlock:
	pthread_mutex_unlock(&pSem->sem_lock);
	//printf("%x %i %i\n",pSem,pSem->recursion_level, pSem->token_count);
exit:
	{}
	pthread_cleanup_pop(0);

	if (error != OK) {
		errno = (int) error;
		error = ERROR;
	}
	TRACE_DLL_F("%x",pSem);
	return error;
#endif
}

BOOL time_expired(struct timespec *timeout)
{
	struct timeval now;
//	ulong usec;
	gettimeofday(&now, NULL);
	if (timeout->tv_sec < now.tv_sec)
		return TRUE;
	if (timeout->tv_sec > now.tv_sec)
		return FALSE;
	assert(timeout->tv_sec == now.tv_sec);
	return timeout->tv_nsec <= now.tv_usec * 1000;
}

void priority_inversion(v2lsem_t * pSem, int max_wait, WIND_TCB * our_task)
{
#if 0
	WIND_TCB *task;
	int my_priority, owners_priority, sched_policy;
	//taskLock();

	my_priority = our_task->prv_priority.sched_priority;

	task = pSem->current_owner;
	owners_priority = task->prv_priority.sched_priority;

	TRACE_DLL_F("Task @ %p priority %d owns mutex", task, owners_priority);
	TRACE_DLL_F("Calling task @ %p priority %d wants mutex", our_task, my_priority);
	/*
	 **  If mutex owner's priority is lower than ours, boost it
	 **  to our priority level tempororily until owner releases mutex.
	 **  This avoids 'priority inversion'.
	 */
	if (owners_priority < my_priority) {
		struct sched_param schedparam;
		pthread_attr_getschedpolicy(&task->attr, &sched_policy);
		pthread_attr_getschedparam(&task->attr, &schedparam);
		schedparam.sched_priority = my_priority;
		pthread_attr_setschedparam(&task->attr, &schedparam);
		pthread_setschedparam(task->pthrid, sched_policy, &schedparam);
	}

	//taskUnlock();
#endif
}
/*****************************************************************************
** wait_for_token - blocks the calling task until a token is available on the
**                  specified v2pthread semaphore.  If a token is acquired and
**                  the pSem is a mutex type, this function also handles
**                  priority inversion and deletion safety issues as needed.
*****************************************************************************/
STATUS wait_for_token(v2lsem_t * pSem, int max_wait, WIND_TCB * our_task)
{
#ifndef DISABLE_SEM_V2LIN_STYLE
	struct timeval now;
	struct timespec timeout;
	int retcode = 0;
	long sec, usec;
	STATUS error = OK;

	if (our_task) {
		link_susp_task(&pSem->first_susp, our_task);
	}
	if (max_wait == NO_WAIT) {
		//  Caller specified no wait on pSem token...
		//  Check the condition variable with an immediate timeout.
#if 0  /* 怀疑是这个地方，目前用一个简化版*/
		gettimeofday(&now, (struct timezone *) NULL);
		timeout.tv_sec = now.tv_sec;
		timeout.tv_nsec = now.tv_usec * 1000;
		while ((waiting_on_sem(pSem, &timeout, &retcode)) && (retcode != ETIMEDOUT)) {
			retcode = pthread_cond_timedwait(&pSem->sem_send, &pSem->sem_lock, &timeout);
		}
		puts("WWWWWWWWWWWWWWWWWWWWWWWWWWW");
		if (retcode &&  retcode != ETIMEDOUT) {
			error = S_objLib_OBJ_UNAVAILABLE;
		}
#else   
		if(pSem->token_count > 0){
			pSem->token_count--;
		}
		else
			error = S_objLib_OBJ_TIMEOUT;
#endif
	} else {
		//  Caller expects to wait on semaphore, with or without a timeout.
		//  If the semaphore is a mutex type, check for and handle any
		//  priority inversion issues.
		if ((pSem->flags & SEM_INVERSION_SAFE) && pSem->current_owner ) {
			priority_inversion(pSem, max_wait, our_task);
		}

		if (max_wait == WAIT_FOREVER) {
			while (waiting_on_sem(pSem, 0, &retcode)) {
				pthread_cond_wait(&pSem->sem_send, &pSem->sem_lock);
			}
		} else {
			/*
			 **  Wait on semaphore message arrival with timeout...
			 **  Calculate timeout delay in seconds and microseconds.
			 */
			sec = 0;
			usec = max_wait * V2PT_TICK * 1000;
			gettimeofday(&now, (struct timezone *) NULL);
			usec += now.tv_usec;
			if (usec >= 1000000) {
				sec = usec / 1000000;
				usec = usec % 1000000;
			}
			timeout.tv_sec = now.tv_sec + sec;
			timeout.tv_nsec = usec * 1000;

			/*
			 **  Wait for a semaphore message for the current task or
			 **  for the timeout to expire.  The loop is required since
			 **  the task may be awakened by signals for semaphore
			 **  tokens which are not ours, or for signals other than
			 **  from a semaphore token being returned.
			 */
			while ((waiting_on_sem(pSem, &timeout, &retcode)) && (retcode != ETIMEDOUT)) {
				retcode = pthread_cond_timedwait(&(pSem->sem_send),
						&(pSem->sem_lock), &timeout);
			}
		}
		if (retcode == ETIMEDOUT) {
			error = S_objLib_OBJ_TIMEOUT;
		}
	}

	/*
	 **  Remove the calling task's task from the waiting task list
	 **  for the semaphore.  Clear our TCB's suspend list pointer in
	 **  case the semaphore was killed & its ctrl blk deallocated.
	 */
	if (our_task) {
		unlink_susp_task(&pSem->first_susp, our_task);
		//our_task->suspend_list = NULL;
	}
	//  See if we were awakened due to a semDelete or a semFlush.
	if ((pSem->send_type & KILLD) || (pSem->send_type & FLUSH)) {
		if (pSem->send_type & KILLD) {
			error = S_objLib_OBJ_ID_ERROR;	// Semaphore deleted 
		} else {
			;
		}

		if ( ! pSem->first_susp ) {
			pthread_cleanup_push((void (*)(void *)) pthread_mutex_unlock, &pSem->smdel_lock);
			pthread_mutex_lock(&pSem->smdel_lock);
			pthread_cond_broadcast(&pSem->smdel_cplt);
			pSem->send_type = SEND;
			pthread_cleanup_pop(1);
		}
		return error;
	} 
	//if ( retcode == OK) {
	if ( error == OK) {
		/*
		 **  Just received a token from the semaphore...
		 **  If the semaphore is a mutex, indicate the mutex is now owned
		 **  by the current task, and then see if the task owning the
		 **  token is to be made deletion-safe.  
		 */
		pSem->current_owner = our_task;
		pSem->owner = pthread_self();
		if ((pSem->flags & SEM_TYPE_MASK) == MUTEX_SEMA4) {
			pSem->recursion_level++; // is it a good place?
			if (pSem->flags & SEM_DELETE_SAFE)
				taskSafe();
		}
	}
	return error;
#else
    dbgInfo("waiting_for_token not use\n");
    return OK;
#endif
}

/*****************************************************************************
** semTake - blocks the calling task until a token is available on the
**           specified v2pthread semaphore.
*****************************************************************************/
STATUS semTake(v2lsem_t * pSem, int max_wait)
{
#ifdef DISABLE_SEM_V2LIN_STYLE
    int ret = 0;
    if (pSem == NULL)
    { 
        dbgErr("---check_sem failed!!!---\n");
        return ERROR;
    }
    switch(pSem->sem_type)
    {
    case COUNT_SEM_TYPE:
    case SYNC_SEM_TYPE:
        if(WAIT_FOREVER == max_wait)
        {
        /* 如果阻塞时被信号打断，重新执行操作。 */
            do
            {
                errno = 0;
                ret =  sem_wait(&(pSem->sem_obj.sem));   
            }
            while((ret != 0) && (errno == EINTR));
        }
        else if(NO_WAIT == max_wait)
        {
            do
            {
                errno = 0;
                ret =  sem_trywait(&(pSem->sem_obj.sem));   
            }
            while((ret != 0) && (errno == EINTR));
        }
        else
        {
            struct timespec ts;  
            long msec;   
			msec = max_wait * V2PT_TICK;                   
            clock_gettime(CLOCK_REALTIME, &ts );           /* 获取当前时间       */
            ts.tv_sec += (msec / 1000 );              /* 加上等待时间的秒数 */
            ts.tv_nsec += ( msec % 1000 ) * 1000 * 1000;     /* 加上等待时间纳秒数 */
            ts.tv_sec += ts.tv_nsec / (1000 * 1000 * 1000);
            ts.tv_nsec = ts.tv_nsec % (1000 * 1000 * 1000);
            do
            {
                errno = 0;
            	ret =  sem_timedwait(&(pSem->sem_obj.sem), &ts);
            }
            while((ret != 0) && (errno == EINTR)); 
        }

        if(ret != 0)
        {
             return   ERROR;
        }
        break;

    case MUTEX_TYPE:   
        if(WAIT_FOREVER == max_wait)
        {        
            ret =  pthread_mutex_lock(&(pSem->sem_obj.mutex));            
        }
        else if(NO_WAIT == max_wait)
        {       
            ret =  pthread_mutex_trylock(&(pSem->sem_obj.mutex));            
        }
        else
        {
            struct timespec ts; 
            long msec;   
			msec = max_wait * V2PT_TICK;                         
            clock_gettime(CLOCK_REALTIME, &ts );           /* 获取当前时间       */
            ts.tv_sec += (msec / 1000 );              /* 加上等待时间的秒数 */
            ts.tv_nsec += ( msec % 1000 ) * 1000 * 1000;     /* 加上等待时间纳秒数 */
            ts.tv_sec += ts.tv_nsec / (1000 * 1000 * 1000);
            ts.tv_nsec = ts.tv_nsec % (1000 * 1000 * 1000);
            ret =  pthread_mutex_timedlock(&(pSem->sem_obj.mutex), &ts);            
        }
        if(ret != 0)
        {
            return  ERROR;
        }
        /*pSem->owner_pid = gettid();*//*记录拥有此互斥量的PID*/
        pSem->owner_pid = (pid_t)syscall(224); /*__NR_gettid=224*/
        break;
    default:
        dbgErr("semTake: Flag of semaphore is invalid!\n");
        return   ERROR;
    }      
    return OK;
#else
    STATUS error = OK;
	WIND_TCB *our_task=my_task();
	pthread_t my_pthrid = pthread_self();
	if(FALSE==check_sem(pSem)){
		return ERROR;
	}
	pthread_cleanup_push((void (*)(void *)) pthread_mutex_unlock, &pSem->sem_lock);
	if (!sem_find_lock(pSem)) {
		dbgErr("WARNING not found %p\n",pSem);
		error = S_objLib_OBJ_ID_ERROR;
		goto exit;
	}
	// If the semaphore is a mutex, check to see if this task already owns the token.
	if ( our_task ) our_task->waiting = pSem;
	if (((pSem->flags & SEM_TYPE_MASK) == MUTEX_SEMA4) && pSem->current_owner && (pSem->owner== my_pthrid) ) {
		//  Current task already owns the mutex... 
		// simply increment the  ownership recursion level and return.
		pSem->recursion_level++; // is i a good place?
		//printf("------pSem = 0x%x-----%d-----\n",pSem,pSem->recursion_level);
	} else {
		// Either semaphore is not a mutex or current task doesn't own it
		// Wait for timeout or acquisition of token
		error = wait_for_token(pSem, max_wait, our_task);
	}
	if ( our_task ) our_task->waiting = NULL;
	pthread_mutex_unlock(&(pSem->sem_lock));
exit:
	{}
	pthread_cleanup_pop(0);

	if (error != OK) {
		errno = (int) error;
		error = ERROR;
	}
	return error;
#endif
}

/********************用户态中断实现*************************/
#include <fcntl.h>
#include <signal.h>
#include <sys/mman.h>
#include <assert.h>
#include <stdio.h>
//#include <limits.h>
#include <sys/time.h>
#include <sys/resource.h>
#include <sys/ioctl.h>
#include <time.h>


/*宏定义*/
#ifdef CONFIG_KDA_MUL_PROCESS
#define KDA_DEVICE_NAME "/dev/KernDrvAgt"
#else
#define KDA_DEVICE_NAME "/dev/misc/KernDrvAgt"
#endif
/* 
 * The path to the mem device file 
 */
#define MEM_DEVICE_NAME "/dev/mem"

/*静态变量定义*/
int        g_iKdaDrvFd = -1;
int siMemDrvFd = -1;

#define SUPPORT_USR_INT 1

#ifdef SUPPORT_USR_INT
/*******************用户态 中断************************************************/

#define MPC_85XX_IRQS      512
#define KDA_NR_IRQS        MPC_85XX_IRQS
#define NUM_IRQ_PENDINGS   ((KDA_NR_IRQS + 31)/32)

static kda_irq_handler_t saKdaIrqHandlerArray[KDA_NR_IRQS];

#ifndef CONFIG_KDA_MUL_PROCESS
typedef struct __tag_Act_Irq
{
   unsigned long   IrqCnt;
   unsigned short  IrqNumArray[KDA_NR_IRQS];
}kda_act_irq_t;
#endif


int intTreadId = 0;

void (*g_pRspIntCountCallBack)(unsigned long vecNum); 

int g_dwIrqPrintSwtich = 0;

#ifdef CONFIG_KDA_MUL_PROCESS
/*多进程支持中断挂接参数地址,多进程中断支持 liuzhw*/
static KDA_ACESS_TYPE kda_mult_int_mem_addr = 0;
#endif

int intEnable (int irq)
{
    return OK;
}

int intDisable (int irq)
{
    return OK;
}

/******************************************************************************
* 函数名称： requestIrq
* 功能描述： 中断挂接函数
* 输入参数：
* 输出参数： 无
* 返 回 值： 无
* 其它说明：
*
* 修改日期        版本号     修改人           修改内容
* ---------------------------------------------------------------
*
******************************************************************************/
STATUS  requestIrq(int vector, kda_irq_func_t isr_func,void *data)
{
    kda_ioctl_t devio;

 /*   if (vector == 16)
        devio.dev_id = CSM6700_DEVICE_ID;
    else*/
        devio.dev_id = 0;
    
    if ((vector < 0)  || ( vector >= KDA_NR_IRQS))
    {
        return (ERROR);   /*  out of range  */
    }

    devio.d0 = (unsigned int)vector;

#ifdef CONFIG_KDA_MUL_PROCESS
    devio.d1 = kda_mult_int_mem_addr;
    #ifdef MGR_PROCESS
        tCurrentPid = getpid();
        devio.d2 = tCurrentPid;
    #endif
#endif
    if(ioctl(g_iKdaDrvFd, KDA_INTERRUPT_REQUEST, &devio))
    {
        return ERROR;
    }

    if(devio.rs != KDA_SUCCESS)
        return ERROR;
   
    saKdaIrqHandlerArray[vector].handler = isr_func;
#ifdef CONFIG_KDA_MUL_PROCESS
    saKdaIrqHandlerArray[vector].handler_parm_t.data = data;
#else
    saKdaIrqHandlerArray[vector].data    = data;
#endif
    saKdaIrqHandlerArray[vector].vector  = vector;
#ifndef CONFIG_KDA_MUL_PROCESS
    saKdaIrqHandlerArray[vector].intrCnt = 0;
#endif
    return OK;
}

#ifdef CONFIG_KDA_MUL_PROCESS
STATUS intDisconnect
    (
    VOIDFUNCPTR *   vector,     /* interrupt vector to attach */
    VOIDFUNCPTR     routine,    /* routine to be called */
    int         parameter   /* parameter to be passed to routine */
    )
{
    kda_irq_handler_t * pHandler;

    if (((int)vector < 0)  || ((int) vector >= KDA_NR_IRQS))
    {
        return (ERROR);   /*  out of range  */
    }

    pHandler = saKdaIrqHandlerArray[(int) vector].handler;
     /* 1. 表是空表 */
    if(pHandler == NULL)
    {
        return (OK);
    }

    if(pHandler == routine)/* 直接删除即可 */
    {
        saKdaIrqHandlerArray[(int) vector].handler= NULL;
        saKdaIrqHandlerArray[(int) vector].handler_parm_t.data = 0;
        saKdaIrqHandlerArray[(int) vector].vector = 0;
        free(pHandler);
        return (OK);
    }
    return (OK);
}

#endif

#if (!defined(CONFIG_KDA_MUL_PROCESS))
STATUS kdaIrqHdBind(int vector, kda_irq_func_t isr_func,void *data)
{
    if ((vector < 0)  || (vector >= KDA_NR_IRQS))
    {
        return (ERROR);   /*  out of range  */
    }
	saKdaIrqHandlerArray[vector].handler = isr_func;
    saKdaIrqHandlerArray[vector].data    = data;
    saKdaIrqHandlerArray[vector].vector  = vector;

    return (OK);
}
static  unsigned long  sKdaIrqRetVal[KDA_NR_IRQS]={0};
unsigned long Get_KDA_Irq_RetVal(int irq)
{
    return sKdaIrqRetVal[irq];
}
#endif

#ifdef CONFIG_KDA_MUL_PROCESS
STATUS BspSetProcGpioIntMask(unsigned int dwMask)
{
    kda_ioctl_t     devio;
    devio.d1 = kda_mult_int_mem_addr;
    devio.d2 = dwMask;
    int iRet = 0;

    iRet = ioctl(g_iKdaDrvFd, KDA_SET_GPIO_MASK, &devio);
    if (iRet < 0)
    {
        dbgErr("kda set gpio mask for KdaDrv: ioctl failure\n");
        return ERROR;
    }
    return OK;
}
#endif



STATUS intConnect
(
    VOIDFUNCPTR *vector,	/* interrupt vector to attach to     */
    VOIDFUNCPTR routine,	/* routine to be called              */
    int parameter		/* parameter to be passed to routine */
)
{
#ifdef SUPPORT_USR_INT
    return requestIrq((int)(long)vector, routine,(void*)(long)parameter);
#else
    return OK;
#endif
}
#ifdef CONFIG_KDA_MUL_PROCESS
UINT32 g_audUserKdaIrqCnt[KDA_NR_IRQS]={0};
#endif
/******************************************************************************
* 函数名称： kdaIrqThread
* 功能描述： 中断处理任务函数
* 输入参数：
* 输出参数： 无
* 返 回 值： 无
* 其它说明：
*
* 修改日期        版本号     修改人           修改内容
* ---------------------------------------------------------------
*
******************************************************************************/

//extern void Mpc85xxExIntUnMask(int hw_irq);
static void * kdaIrqThread(void *context)
{
    struct sched_param param;
    int    i,curr_vec,err;
    kda_act_irq_t   s_atActIrqNumArray;
#ifdef CONFIG_KDA_MUL_PROCESS
    int iRet = 0;
    kda_ioctl_t     devio;
#endif

    memset(&s_atActIrqNumArray,0,sizeof(s_atActIrqNumArray));
    /*The realtime scheduling priority (1 - 99), this task need the higherst*/
    param.sched_priority = 99;
    if (sched_setscheduler(0, SCHED_FIFO, &param)) {       
        perror("\ninterrupt priority set: ");
    }
  
    err = pthread_setcanceltype (PTHREAD_CANCEL_ASYNCHRONOUS, NULL);
    if (err != 0) {
        dbgErr ("setcanceltype failed: %s [so you can't stop me]\n", strerror (err));
    }

    for (;;) {

#ifdef CONFIG_KDA_MUL_PROCESS
        /*这里d0向内核传入要获取值的数组 ， d1传入本进程在内核中申请到的中断控制块数组的mem地址. liuzhw */
    #ifdef BSP_BPQ_CORTEXA53
        devio.d0 = (unsigned long)&s_atActIrqNumArray;
    #else
        devio.d0 = &s_atActIrqNumArray;
        #ifdef NXP_32_TO_64_KDA
        devio.d0 = devio.d0 & 0xffffffff;
        #endif
    #endif
        devio.d1 = kda_mult_int_mem_addr;
        iRet = ioctl(g_iKdaDrvFd, KDA_WAIT_FOR_INTERRUPT, &devio);
        if (iRet < 0)
        {
            dbgErr("kda wait for interrupt to KdaDrv: ioctl failure\n");
        }
#else

        if(ioctl(g_iKdaDrvFd,KDA_WAIT_FOR_INTERRUPT, &s_atActIrqNumArray))
        {
            dbgErr ("ioctl KDA_WAIT_FOR_INTERRUPT fail.\n");
        }
#endif

        for(i=0; i<s_atActIrqNumArray.IrqCnt; i++){
            curr_vec = s_atActIrqNumArray.IrqNumArray[i];
            if (saKdaIrqHandlerArray[curr_vec].handler)
            {

#ifdef CONFIG_KDA_MUL_PROCESS
                g_audUserKdaIrqCnt[curr_vec]++;
                saKdaIrqHandlerArray[curr_vec].handler_parm_t. s_tActIrq = &s_atActIrqNumArray;

                saKdaIrqHandlerArray[curr_vec].handler((void*)&saKdaIrqHandlerArray[curr_vec].handler_parm_t);

#else
                saKdaIrqHandlerArray[curr_vec].intrCnt++;
                saKdaIrqHandlerArray[curr_vec].handler(saKdaIrqHandlerArray[curr_vec].data);

#endif

            }
        }
    }

    return NULL;
}

void kdaShowIntrCnt(unsigned int vector)
{

#ifdef CONFIG_KDA_MUL_PROCESS
    dbgInfo("vector[%d] cnt is %d\n",vector,g_audUserKdaIrqCnt[vector]);
#else
    dbgInfo("vector[%d] cnt is %d\n",vector,saKdaIrqHandlerArray[vector].intrCnt);
#endif
}

/******************************************************************************
* 函数名称： enableIrq
* 功能描述： 中断使能函数
* 输入参数：
* 输出参数： 无
* 返 回 值： 无
* 其它说明：
*
* 修改日期        版本号     修改人           修改内容
* ---------------------------------------------------------------
*
******************************************************************************/
STATUS enableIrq(int vector)
{
    return OK;
}

/******************************************************************************
* 函数名称： enableIrq
* 功能描述： 中断关闭函数
* 输入参数：
* 输出参数： 无
* 返 回 值： 无
* 其它说明：
*
* 修改日期        版本号     修改人           修改内容
* ---------------------------------------------------------------
*
******************************************************************************/
STATUS disableIrq(int vector)
{
    int ret;

    ret = ioctl(g_iKdaDrvFd, KDA_INTERRUPT_FREE,vector);
    if(ret != KDA_SUCCESS)
    {
        dbgErr("KDA_INTERRUPT_FREE [%p] ret =[%p]\n", (void *)(long)vector,(void *)(long)ret);
    }
/*
    if(devio.rs != KDA_SUCCESS)
    {
        ret = ERROR;
    }
*/
    return OK;
}
/******************************************************************************
* 函数名称： kdaIntLock
* 功能描述： 锁中断
* 输入参数：
* 输出参数： 无
* 返 回 值： 无
* 其它说明：
*
* 修改日期        版本号     修改人           修改内容
* ---------------------------------------------------------------
*
******************************************************************************/
int kdaIntLock(void)
{
    kda_ioctl_t devio;

    if(ioctl(g_iKdaDrvFd, KDA_INTERRUPT_LOCK, &devio))
    {
        return ERROR;
    }

    return devio.rv;
}

/*---------------kda mdio read/write [note:only for dra62x]---------------------*/
int kdaMdioRead(int phy,int reg,int *value)
{
	kda_ioctl_t mdio = {0};
	mdio.d0 = (ULONG)phy;
	mdio.d1 = (ULONG)reg;
	if (ioctl(g_iKdaDrvFd, KDA_MDIO_READ, &mdio))
	{
		return -1;
	}
	*value = (int)mdio.d2;
	return 0;
}

int kdaMdioWrite(int phy,int reg,int value)
{
	kda_ioctl_t mdio = {0};
	mdio.d0  = (ULONG)phy;
	mdio.d1  = (ULONG)reg;
	mdio.d2  = (ULONG)value;
	if (ioctl(g_iKdaDrvFd, KDA_MDIO_WRITE, &mdio))
	{
		return -1;
	}
	return 0;
}

/******************************************************************************
* 函数名称： kdaIntUnlock
* 功能描述： 解锁中断
* 输入参数：
* 输出参数： 无
* 返 回 值： 无
* 其它说明：
*
* 修改日期        版本号     修改人           修改内容
* ---------------------------------------------------------------
*
******************************************************************************/
int kdaIntUnlock(int flag)
{
    kda_ioctl_t devio;
    devio.d0 = flag;
    if(ioctl(g_iKdaDrvFd, KDA_INTERRUPT_UNLOCK, &devio))
    {
        return ERROR;
    }
	return OK;
}
#endif  // end of #ifdef SUPPORT_USR_INT


#ifdef SUPPORT_DMA
/******************DMA 内存池的管理接口************************************/
unsigned long  g_dwCsmDmaBuffVBase = 0;
unsigned long  g_dwCsmDmaBuffPBase = 0;
unsigned long  g_dwCsmDmaBuffSize  = 0;
static struct dma_pool_mem_s* s_ptCsmDmaBuffPool = NULL;

/******************************************************************************
* 函数名称： csmDmaBuffInit
* 功能描述： 初始化 DMA 缓冲池
* 输入参数：
* 输出参数： 无
* 返 回 值： 无
* 其它说明：
*
* 修改日期        版本号     修改人           修改内容
* ---------------------------------------------------------------
*
******************************************************************************/
STATUS csmDmaBuffInit(unsigned long size)
{
    g_dwCsmDmaBuffSize  = RES_DMA_MEM_SIZE;

    g_dwCsmDmaBuffPBase = RES_DMA_MEM_START;

    g_dwCsmDmaBuffVBase = (unsigned long)mmap(NULL, g_dwCsmDmaBuffSize,\
                   PROT_READ|PROT_WRITE,MAP_SHARED, siMemDrvFd, g_dwCsmDmaBuffPBase);

    dbgInfo(" ------------- OK g_dwCsmDmaBuffPBase=%p g_dwCsmDmaBuffVBase=%p\n",\
          (void*)g_dwCsmDmaBuffPBase, (void*)g_dwCsmDmaBuffVBase);


    dbgInfo();

    s_ptCsmDmaBuffPool = dma_pool_create((void *)g_dwCsmDmaBuffVBase, g_dwCsmDmaBuffSize);
    return OK;
}

/******************************************************************************
* 函数名称： csmDmaBuffClean
* 功能描述： 释放 DMA 缓冲池
* 输入参数：
* 输出参数： 无
* 返 回 值： 无
* 其它说明：
*
* 修改日期        版本号     修改人           修改内容
* ---------------------------------------------------------------
*
******************************************************************************/
STATUS csmDmaBuffClean(void)
{
    kda_ioctl_t devio;
    
    if(g_dwCsmDmaBuffPBase == 0)
    {
        return OK;
    }

    dma_pool_destroy(s_ptCsmDmaBuffPool);
    munmap((void *)g_dwCsmDmaBuffVBase,g_dwCsmDmaBuffSize);
    g_dwCsmDmaBuffVBase = 0;
    g_dwCsmDmaBuffSize      = 0;
    devio.d0 = g_dwCsmDmaBuffPBase;    
    /*ioctl(g_iKdaDrvFd,KDA_DMA_FREE_MEM,&devio);

    if(devio.rs != KDA_SUCCESS){
        g_dwCsmDmaBuffPBase = 0;
        return ERROR;
    }else {
        g_dwCsmDmaBuffPBase = 0;
        return OK;
    }*/
    return OK;
}

/******************************************************************************
* 函数名称： csmDmaMemAlloc
* 功能描述： DMA 内存分配
* 输入参数：
* 输出参数： 无
* 返 回 值： 无
* 其它说明：
*
* 修改日期        版本号     修改人           修改内容
* ---------------------------------------------------------------
*
******************************************************************************/
void * csmDmaMemAlloc(int size)
{

    if(!s_ptCsmDmaBuffPool)
       return NULL;

    return dma_pool_alloc(s_ptCsmDmaBuffPool,size);

}

/******************************************************************************
* 函数名称： csmDmaMemFree
* 功能描述： DMA 内存释放
* 输入参数：
* 输出参数： 无
* 返 回 值： 无
* 其它说明：
*
* 修改日期        版本号     修改人           修改内容
* ---------------------------------------------------------------
*
******************************************************************************/
void  csmDmaMemFree(void* ptr)
{
    if(s_ptCsmDmaBuffPool)
    dma_pool_free(s_ptCsmDmaBuffPool,ptr);
}
#endif // end of SUPPORT_DMA

INT32 KdaInitComRecord(unsigned long long logAddrBase, UINT32 interruptNum)
{
    kda_ioctl_t devIo = {0};

    devIo.d0 = (logAddrBase >> 32) & 0xffffffff;
    devIo.d1 = logAddrBase & 0xffffffff;
    devIo.d2 = interruptNum;
    devIo.d3 = 1;

    if (ioctl(g_iKdaDrvFd, KDA_SERIAL_RECORD_MEMORY, &devIo))
    {
        //(VOID)printf_s("ioctl KDA_SERIAL_RECORD_MEMORY failed\n");
        dbgErr("ioctl KDA_SERIAL_RECORD_MEMORY failed\n");
        return ERROR;
    }

    return 0;
}
#if (SUPPORT_MUX_TYPE == ENHANCED_MUX)
/******************增强型用户态MUX层支持************************************/

//static struct rx_info *gprxinfo;

/******************************************************************************
* 函数名称： kdaMuxInit
* 功能描述： MUX初始化，获取内核环形buffer地址
* 输入参数：
* 输出参数： 无
* 返 回 值： 无
* 其它说明：
*
* 修改日期        版本号     修改人           修改内容
* ---------------------------------------------------------------
*
******************************************************************************/

int kdaMuxBind(char *name, void **ppdev, void **pprxinfo)
{
    kda_ioctl_t devio = {0};

    /*strcpy((char *)&(devio.dx), name); 用strncpy 代替*/
    strncpy((char *)&(devio.dx),name,17);
    devio.dx[16] = '\0';
    if (ioctl(g_iKdaDrvFd,KDA_DEV_MUX_BIND,&devio)) {
        dbgErr("ioctl KDA_DEV_MUX_INIT failed\n");
        return -1;
    }
    *ppdev = (void*)devio.d0;
    *pprxinfo = (void*)devio.d1;

//    gprxinfo = (struct rx_info*)devio.d1;
    return 0;

}

/* 通过kda进入内核特权模式，设置0x48140048寄存器(修改dsp boot address)，需要与内核配合 */
int kdaDspBootAddrSet(unsigned int u32DspBootAddr)
{
    if(ioctl(g_iKdaDrvFd, KDA_DSPCFG_REGSET, u32DspBootAddr))
    {
        dbgErr("DSP Boot ADDR set failed!\n");
        return -1;
    }
    else
    {
        dbgInfo("%s>>succ: dspBootAddr=0x%x\n", __func__, u32DspBootAddr);
        return 0;
    }
}


int kdaMuxInit(int memfd, int maxtxpkt)
{
    kda_ioctl_t devio;
    
    devio.d0 = memfd;
    devio.d1 = maxtxpkt;
    if (ioctl(g_iKdaDrvFd,KDA_DEV_MUX_INIT,&devio)) {
        dbgErr("ioctl KDA_DEV_MUX_INIT failed\n");
        return -1;
    }
	return 0;
}

/******************************************************************************
* 函数名称： kdaMuxSend
* 功能描述： 发送函数
* 输入参数：
* 输出参数： 无
* 返 回 值： 无
* 其它说明：
*
* 修改日期        版本号     修改人           修改内容
* ---------------------------------------------------------------
*
******************************************************************************/
int kdaMuxSend(void *dev, void *pData, unsigned int len)
{
    kda_ioctl_t devio;

    devio.d0 = (unsigned long)pData;
    devio.d1 = (unsigned long)len;
    devio.d2 = (unsigned long)dev;
    if(ioctl(g_iKdaDrvFd,KDA_DEV_MUX_SEND,&devio))
    {
        return -1;
    }

    if(devio.rs != KDA_SUCCESS)
        return -1;

    return 0;
}

int tx_allocs = 0;
int tx_frees = 0;
/******************************************************************************
* 函数名称： kdaTxAlloc
* 功能描述： 申请内存
* 输入参数：
* 输出参数： 无
* 返 回 值： 无
* 其它说明：
*
* 修改日期        版本号     修改人           修改内容
* ---------------------------------------------------------------
*
******************************************************************************/
void* kdaTxAlloc(int size)
{
    kda_ioctl_t devio;

    devio.d0 = (unsigned long)size;
    if(ioctl(g_iKdaDrvFd,KDA_MUX_TX_ALLOC,&devio))
    {
        dbgErr("kdaTxAlloc:ioctl error!\n");
    }

    tx_allocs++;

    return (void*)(devio.d0);
}

/******************************************************************************
* 函数名称： kdaTxAlloc
* 功能描述： 释放内存
* 输入参数：
* 输出参数： 无
* 返 回 值： 无
* 其它说明：
*
* 修改日期        版本号     修改人           修改内容
* ---------------------------------------------------------------
*
******************************************************************************/
void kdaTxFree(void *buf)
{
    kda_ioctl_t devio;

    devio.d0 = (unsigned long)buf;
    if(ioctl(g_iKdaDrvFd,KDA_MUX_TX_FREE,&devio))
    {
        dbgErr("kdaTxFree:ioctl error!\n");
    }

    tx_frees++;
}
#endif  // end of #if (SUPPORT_MUX_TYPE == ENHANCED_MUX)

/******************KDA模块初始化与清理************************************/
/******************************************************************************
* 函数名称： kdaLibInit
* 功能描述： KDA模块初始化
* 输入参数：
* 输出参数： 无
* 返 回 值： 无
* 其它说明：
*
* 修改日期        版本号     修改人           修改内容
* ---------------------------------------------------------------
*
******************************************************************************/

STATUS kdaLibInit(void)
{
#ifdef CONFIG_KDA_MUL_PROCESS
    int iRet = 0;
    kda_ioctl_t     devio;
#endif
    if (g_iKdaDrvFd >= 0)
    {
        /* Already open */
        return OK;
    }
    memset(saKdaIrqHandlerArray,0,sizeof(saKdaIrqHandlerArray));
#ifndef CONFIG_KDA_MUL_PROCESS
//#ifdef MGR_PROCESS
    BspMkdir("/dev/misc");
    BspMknod("/dev/misc/KernDrvAgt","c","10","244");
//#endif
#endif
    if ((g_iKdaDrvFd = open(KDA_DEVICE_NAME,O_RDWR | O_SYNC )) < 0)
    {
	    BspInsmod("/home/kmod.ko");
        if ((g_iKdaDrvFd = open(KDA_DEVICE_NAME,O_RDWR | O_SYNC )) < 0)
        {
            perror("open " KDA_DEVICE_NAME ": ");
            return ERROR;
        }
    }

    if ((siMemDrvFd = open(MEM_DEVICE_NAME,O_RDWR | O_SYNC )) < 0)
    {
        perror("open " MEM_DEVICE_NAME ": ");
        close(g_iKdaDrvFd);
        return ERROR;
    }
#ifdef CONFIG_KDA_MUL_PROCESS
    memset(&devio,0,sizeof(kda_ioctl_t));
    iRet = ioctl(g_iKdaDrvFd, KDA_GET_INT_MEM, &devio);
    if (iRet < 0)
    {
        dbgErr("kda get int mem for KdaDrv: ioctl failure\n");
    }

    if (devio.rs == 0)
    {
        dbgErr("KDA_GET_INT_MEM ###########failed：%d\n",sizeof(kda_ioctl_t));
        return ERROR;
    }
    /*这里使用成员变量rs返回本进程的中断控制块在内核中获取到的mem地址，与内核配套使用。 liuzhw */
    kda_mult_int_mem_addr = devio.rs;
   /* if(sizeof(unsigned long long) == sizeof(KDA_ACESS_TYPE) )
        printf("tsk %d kda_mult_int_mem_addr = 0x%llx\n", getpid(), kda_mult_int_mem_addr);
    else
        printf("tsk %d kda_mult_int_mem_addr = 0x%lx\n", getpid(), kda_mult_int_mem_addr);*/
   // BspSetProcGpioIntMask(ulGpioMask);

#endif


#ifdef SUPPORT_DMA
    if(csmDmaBuffInit(0) != OK)
    {
        close(g_iKdaDrvFd);
        close(siMemDrvFd);
        dbgErr("DMA BUFFER Init Failure\n");
        return ERROR;
    }    
#endif

#ifdef SUPPORT_USR_INT
    intTreadId = taskSpawn("kda_irqd",40,0,1024,(FUNCPTR)kdaIrqThread,0,0,0,0,0,0,0,0,0,0);

    if( intTreadId == ERROR )
    {  
        #ifdef SUPPORT_DMA
            csmDmaBuffClean();
        #endif
        close(g_iKdaDrvFd);
        close(siMemDrvFd);
        return ERROR;
    }
#endif

#if (SUPPORT_MUX_TYPE == ENHANCED_MUX)
#ifndef CONFIG_KDA_MUL_PROCESS
	kdaMuxInit(siMemDrvFd, 0);
#endif
#endif
    return OK;
}

/******************************************************************************
* 函数名称： kdaLibClose
* 功能描述： KDA模块关闭
* 输入参数：
* 输出参数： 无
* 返 回 值： 无
* 其它说明：
*
* 修改日期        版本号     修改人           修改内容
* ---------------------------------------------------------------
*
******************************************************************************/
STATUS kdaLibClose(void)
{
#ifdef CONFIG_KDA_MUL_PROCESS
    kda_ioctl_t     devio;
#endif

#ifdef SUPPORT_DMA
    csmDmaBuffClean();
#endif

    close(siMemDrvFd);
    siMemDrvFd = -1;
#ifdef CONFIG_KDA_MUL_PROCESS
    memset(&devio,0,sizeof(kda_ioctl_t));
    devio.d0 = kda_mult_int_mem_addr;
    if ( ioctl(g_iKdaDrvFd, KDA_FREE_INT_MEM, &devio))
    {
        dbgErr("kda free int mem for KdaDrv: ioctl failure\n");
    }
#endif

    close(g_iKdaDrvFd);
    g_iKdaDrvFd = -1;
    
#ifdef SUPPORT_USR_INT
    taskDelete(intTreadId);
#endif

    return OK;
}


int getKdaFd(void)
{
	return g_iKdaDrvFd;
}


static pthread_mutex_t s_mutex = PTHREAD_RECURSIVE_MUTEX_INITIALIZER_NP;
INT intLock(void)
{
    pthread_mutex_lock(&s_mutex);
    return 0;
}

int intUnlock(int LockKey)
{
    pthread_mutex_unlock(&s_mutex);
    return 0;
}



#ifdef _PPC_CPU_ 
int  fsa_irq_save(void)
{
	return lll_fuirq_save();
}

void fsa_irq_restore(int flag)
{
	lll_fuirq_restore(flag);
}
#endif

#if 0
/* 20131210,宋志强 根据成研的技术支持，增加 ARM CPU的中断锁*/
#ifdef _ARM_CPU_

#define ARM_FSA_OP_MAGIC1       0x65000000
#define ARM_FSA_OP_MAGIC2       0x3c0
#define ARM_FSA_OP_IRQ_SAVE     0x11
#define ARM_FSA_OP_IRQ_RESTORE  0x22

int fsa_irq_save(void)
{
    int flag;
    register int _a1 asm ("a1") = ARM_FSA_OP_MAGIC1;
    register int _a2 asm ("a2") = ARM_FSA_OP_MAGIC2;
    register int _a3 asm ("a3") = ARM_FSA_OP_IRQ_SAVE;
    register int _a4 asm ("a4") = 0;
    
    asm volatile ("mrc p15, 0, r0, c1, c0, 0"
                        :
                        :"r" (_a1), "r" (_a2), "r" (_a3), "r" (_a4)
                        : "memory");
    flag = _a1;
    return flag;
}

void fsa_irq_restore(int flag)
{
    register int _a1 asm ("a1") = ARM_FSA_OP_MAGIC1;
    register int _a2 asm ("a2") = ARM_FSA_OP_MAGIC2;
    register int _a3 asm ("a3") = ARM_FSA_OP_IRQ_RESTORE;
    register int _a4 asm ("a4") = flag;
    
    asm volatile ("mrc p15, 0, r0, c1, c0, 0"
                        :
                        :"r" (_a1), "r" (_a2), "r" (_a3), "r" (_a4)
                        : "memory");
}
#endif




int intLockReal(void)
{
#ifndef _X86_32_CPU_            /*如果是X86编译不用 by wangfei 2017-02-10*/
    return fsa_irq_save();
#else
    return 0;
#endif
}

int intUnlockReal(int lockKey)
{
#ifndef _X86_32_CPU_             /*如果是X86编译不用 by wangfei 2017-02-10*/
    fsa_irq_restore(lockKey);
    return 0;
#else
    return 0;
#endif
}

#endif

/* Started by AICoder, pid:r08f0h24078907014d180a7f4062a012be04cac8 */
unsigned long long g_ullTick64GetOffset = 0;

unsigned long long tick64Get(void)
{
    unsigned long long uptime;
    struct timespec t;

    clock_gettime(CLOCK_MONOTONIC, &t);
    
    uptime = (unsigned long long)((unsigned long long)t.tv_sec * 100 + (t.tv_nsec) / 10000000);

    return (uptime + g_ullTick64GetOffset);
}
/* Ended by AICoder, pid:r08f0h24078907014d180a7f4062a012be04cac8 */

static unsigned long long start_point = 0;
ULONG tickGet()
{
	unsigned long long uptime;
	struct timespec t;
	t.tv_sec = 0;  /* 秒清零 */
	t.tv_nsec = 0; /* 纳秒清零 */
	clock_gettime(CLOCK_MONOTONIC, &t);
	uptime = (unsigned long long)((unsigned long long)t.tv_sec*100+(t.tv_nsec)/10000000);
	if(start_point==0)
		start_point=uptime;
	return (ULONG)(uptime - start_point);
}

/******************************************************************************
* 函数名称： copy
* 功能描述： 简易文件拷贝功能
* 输入参数： 源文件名
* 输出参数： 目的文件名
* 返 回 值： OK: 成功; ERROR: 失败
* 其它说明： 最大支持10M文件大小
*
* 修改日期        版本号     修改人           修改内容
* ---------------------------------------------------------------
* 2010-3-27       V1.0       刘骏儒           创建
******************************************************************************/
STATUS copy
(
    const char *in,	/* name of file to read  (if NULL assume stdin)  */
    const char *out 	/* name of file to write (if NULL assume stdout) */
)
{
    int fd = 0;
	int iCopyLen = 0;
	UCHAR *pcCopyBuf = NULL;
    
    if ((NULL == in) || (NULL == out))
    {
        dbgErr("copy: input pointer null!\n");
        return ERROR;
    }
    
	fd = open (in, O_RDONLY);
    if(ERROR == fd)
    {
    	dbgErr("copy: open src fail!\n");
        return ERROR;
    }
	pcCopyBuf = (UCHAR *)malloc(0xa00000);
	if(NULL == pcCopyBuf)
    {
        dbgErr("copy: malloc buf fail!\n");
        close(fd);
        return ERROR;
    }

	iCopyLen = read(fd, pcCopyBuf, 0xa00000);
	if (0 >= iCopyLen)
    {
        dbgErr("copy: read src fail!\n");
		close(fd);
		free(pcCopyBuf);
		pcCopyBuf = NULL;
        return ERROR;
    }
	close(fd);
	
	fd = open (out, O_CREAT | O_RDWR, S_IRUSR|S_IWUSR);
    if(ERROR == fd)
    {
    	dbgErr("copy: open dest fail!\n");
		free(pcCopyBuf);
		pcCopyBuf = NULL;        
        return ERROR;
    }
	if(iCopyLen != write(fd, pcCopyBuf, iCopyLen))
    {
		dbgErr("copy: write dest fail!\n");        
		free(pcCopyBuf);
		pcCopyBuf = NULL;        
    	close(fd);
        return ERROR;
    }
	
	free(pcCopyBuf);
	pcCopyBuf = NULL;        
    close(fd);
	return OK;	
}

int sysClkRateGet(void)
{
    return 100;
}

int vxImmrGet(void)
{
    return 0x80000000;
}


int ioGlobalStdGet
    (
    int stdFd /* std input (0), output (1), or error (2) */
    )
{
    return OK;
}

void ioGlobalStdSet
    (
    int stdFd, /* std input (0), output (1), or error (2) */
    int newFd  /* new underlying file descriptor */
    )
{
}

STATUS pipeDevCreate
    (
    char * name,      /* name of pipe to be created */
    int    nMessages, /* max. number of messages in pipe */
    int    nBytes     /* size of each message */
    )

{
    return OK;
}

STATUS errnoSet
    (
    int errorValue /* error status value to set */
    )
{
    return OK;
}

int ioTaskStdGet
    (
    int taskId, /* ID of desired task (0 = self) */
    int stdFd   /* std input (0), output (1), or error (2) */
    )
{
    return OK;
}

void ioTaskStdSet
    (
    int taskId, /* task whose std fd is to be set (0 = self) */
    int stdFd,  /* std input (0), output (1), or error (2) */
    int newFd   /* new underlying file descriptor */
    )
{
}


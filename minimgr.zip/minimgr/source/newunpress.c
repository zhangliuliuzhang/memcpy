/************************************************************************
* 版权所有 (C)2008, 深圳市中兴通讯股份有限公司。
*
* 文件名称： NewUnpress.c
* 文件标识： WCDMA
* 内容摘要： V4版本的解压功能实现
* 其它说明：
* 当前版本： 1.0
* 作    者： wood
* 完成日期：
*
* 修改记录1：
*    修改日期：2010 - 11 - 23
*    版 本 号：1.0
*    修 改 人：张雷
*    修改内容：移植，并修改部分函数，做了入参保护
************************************************************************/

#include "ru_basedef.h"
#include "pub_svmdef.h"
#include "crc.h"
#include "vxadp.h"
#include "zprintf.h"
#include "minimgr.h"
#include "lzmaapi.h"
#include "surezip.h"
#include "newunpress.h"

#if defined (SUPPORT_ZSTD)
#include "zstd.h"
#endif


/**************************************************************************
 *                            常量                                        *
 **************************************************************************/



/**************************************************************************
 *                           宏定义                                       *
 **************************************************************************/


/**************************************************************************
 *                          数据类型                                      *
 **************************************************************************/



/**************************************************************************
 *                          全局变量                                      *
 **************************************************************************/
static SEM_ID  NewUnpressSem = NULL;



/**************************************************************************
 *                        局部函数原型                                    *
 **************************************************************************/

unsigned long CheckCrc16(unsigned char *ucBuffer,
                         	  unsigned long  ulBufferLength,
                         	  unsigned short ulTarCrcValue);

/**************************************************************************
 *                        全局函数实现                                    *
**************************************************************************/


/**************************************************************************
 *                        局部函数实现                                    *
 **************************************************************************/
static UINT32 SemNewUnpressInit(VOID)
{
    static UINT8 s_ucSemNUInit = 0;

    if (1 == s_ucSemNUInit)
    {
        return BSP_OK;
    }

    NewUnpressSem = semBCreate(SEM_Q_FIFO, SEM_FULL);
    if (NULL == NewUnpressSem)
    {
        dbgErr("%s:semBCreate failed.\n", __FUNCTION__);
        return BSP_ERROR;
    }
    s_ucSemNUInit = 1;
    return BSP_OK;
}
static UINT32 BspGetNewUnpressSem(VOID)
{

    if (BSP_OK != SemNewUnpressInit())
    {
        return BSP_ERROR;
    }
    semTake(NewUnpressSem, WAIT_FOREVER);
    return BSP_OK;
}

static UINT32 BspRlsNewUnpressSem(VOID)
{
    semGive(NewUnpressSem);
    return BSP_OK;
}

/*===========================================================
函数名      :  UnpressV4
功能        :  解压V4版本包
输入参数说明:
               *ucInFile  -- 压缩文件地址
               ulFileLen  -- 压缩文件的长度(带版本头)
               *ucOutFile -- 解压文件地址
返回值说明  :
引用全局变量:
附加说明    :
修改说明    :
  修改日期          版本号      修改人      修改内容
  -----------------------------------------------
  2008年11月29日      1.0       wood        增加buffer合法性判断
  2008年2月19日      1.0       wood        创建
===========================================================*/
unsigned long UnpressV4(unsigned char *ucInFile,
                        unsigned long  ulFileLen,
                        unsigned char *ucOutFile)
{
    T_VerFileHeader  *ptHeader;
    T_VerFileHeader   tHeader;
    size_t originalSize = 0;
    UINT32 startTick = 0;
    UINT32 endTick = 0;
    UINT32 size = 0;
    size_t zstd_decompress_len = 0;

    if(NULL == ucInFile || NULL == ucOutFile)
    {
        printf("null input pointer at unpress routine.\n");
        return UNPRESS_EC_NULL_BUFFER;
    }

    memcpy_s(&tHeader,sizeof(T_VerFileHeader),ucInFile,sizeof(T_VerFileHeader));
    ptHeader = &tHeader;

    RegHeaderByteOrder(ptHeader);

    /* 若采用deflate解压缩，则需要给originalSize赋值 */
    originalSize = ptHeader->ulOriginalSize;

    /* check file length after pack */
    if(ulFileLen - sizeof(T_VerFileHeader) != ptHeader->ulCompressedSize)
    {
        printf("File length is not matched.\n");
        return UNPRESS_EC_WHOLE_FILE_LEN_ERROR;
    }

    /* crc whole package include header */
    if(0 != CheckCrc16(ucInFile+4,ulFileLen-4,(unsigned short)ptHeader->ulCRC32))
    {
        /* try V3 format unpress */
        printf("V4 format CRC error.\n");
        return UNPRESS_EC_WHOLE_FILE_CRC_ERROR;
    }

    /* now header is ok */

    /* crc package context */
    if(0 != CheckCrc16(ucInFile+sizeof(T_VerFileHeader),
                       ulFileLen - sizeof(T_VerFileHeader),
                       (unsigned short)ptHeader->ulCompressedCRC))
    {
        printf("packed file crc error.\n");
        return UNPRESS_EC_PACKED_FILE_CRC_ERROR;
    }
    size = ulFileLen - sizeof(T_VerFileHeader);

    if(1 == ptHeader->ucReserved0)/* ucreserved0 为1的话，代表Lzma压缩方式 */
    {
        /* unpress package */
        printf("\n---------------- lzma  compress -----------\n");
        startTick = tickGet();
        if(BSP_OK != LzmaDecMem(ucInFile+sizeof(T_VerFileHeader), ucOutFile, ulFileLen - sizeof(T_VerFileHeader), &originalSize))
        {
            printf("lzma fail to uncompress data\n");
            return UNPRESS_EC_UNPACK_ERROR;
        }
        endTick = tickGet();
        dbgInfo("%s>>Init Have Been Finished! startTick= %d,  endTick= %d\n", __FUNCTION__, startTick, endTick);
    }
    else if(2 == ptHeader->ucReserved0)/* ucreserved0 为2的话，代表zstd压缩方式 */
    {
        #if defined (SUPPORT_ZSTD)
            /* unpress package */
            dbgInfo("\n---------------- zstd  compress -----------\n");
            startTick = tickGet();
            zstd_decompress_len = ZSTD_decompress(ucOutFile, originalSize, ucInFile+sizeof(T_VerFileHeader), size);
            if(zstd_decompress_len != originalSize)
            {
                dbgInfo("%s\n", ZSTD_getErrorName(zstd_decompress_len));
                return UNPRESS_EC_UNPACK_ERROR;
            }
            endTick = tickGet();
            dbgInfo("ZSTD_decompress return %zu\n", zstd_decompress_len);
            dbgInfo("%s>>Init Have Been Finished! startTick= %d,  endTick= %d\n", __FUNCTION__, startTick, endTick);
        #else
            dbgInfo("%s>>Error !!! The Board Not Support Zstd Compression(%zu);\n", __FUNCTION__, zstd_decompress_len);
            return UNPRESS_EC_UNPACK_ERROR;
        #endif
    }
    else
    {
        /* unpress package */
        printf("\n---------------- deflate compress -----------\n");
        if(BSP_OK != vx_inflate(ucInFile+sizeof(T_VerFileHeader), ucOutFile, ulFileLen - sizeof(T_VerFileHeader), &originalSize))
        {
            printf("fail to inflate data\n");
            return UNPRESS_EC_UNPACK_ERROR;
        }
    }

    /* crc package context */
    if(0 != CheckCrc16(ucOutFile,originalSize,ptHeader->ulOriginalCRC))
    {
        printf("FileDataLen'%u: unpacked file crc error.\n", size);
        return UNPRESS_EC_UNPACKED_FILE_CRC_ERROR;
    }

    return UNPRESS_OK;
}/* UnpressV4() */


/*===========================================================
函数名      :  NewUnpress
功能        :  解压V4/V3版本包
输入参数说明:
               *ucInFile  -- 压缩文件地址
               ulFileLen  -- 压缩文件的长度(带版本头)
               *ucOutFile -- 解压文件地址
返回值说明  :  UNPRESS_EC_NULL_BUFFER
               UNPRESS_EC_WHOLE_FILE_CRC_ERROR
               UNPRESS_EC_WHOLE_FILE_LEN_ERROR
               UNPRESS_EC_PACKED_FILE_CRC_ERROR
               UNPRESS_EC_UNPACK_ERROR
               UNPRESS_EC_UNPACKED_FILE_CRC_ERROR
               UNPRESS_OK

引用全局变量:
附加说明    :
修改说明    :
  修改日期          版本号      修改人      修改内容
  -----------------------------------------------
  2008年1月25日      1.0       wood        创建
===========================================================*/
unsigned long NewUnpress(unsigned char *pucInFile,
                         unsigned long  ulFileLen,
                         unsigned char *pucOutFile)
{
    unsigned long ulTemp;
    unsigned char *pucDataBuf = NULL;

    pucDataBuf = pucInFile;
    if (NULL == pucDataBuf)
    {
        printf("%s>>Error! pInFile cannot Null\n", __FUNCTION__);
        return UNPRESS_EC_NULL_BUFFER;
    }

    BspGetNewUnpressSem();
    ulTemp = UnpressV4(pucDataBuf, ulFileLen, (unsigned char *)pucOutFile);
    BspRlsNewUnpressSem();

    return ulTemp;
}


 /*===========================================================
函数名      :  RegHeaderByteOrder
功能        :  版本头字节序转化（网络字节序转化为主机字节序）
输入参数说明:
               *ptVerHeader -- 版本头
返回值说明  :
引用全局变量:
附加说明    :
修改说明    :
  修改日期          版本号      修改人      修改内容
  -----------------------------------------------
  2008年3月10日      1.0       wood        创建
===========================================================*/
void RegHeaderByteOrder(T_VerFileHeader  *ptVerHeader)
{
    /*lint --e{1055} */
    ptVerHeader->ulCRC32          = ntohl(ptVerHeader->ulCRC32);
    ptVerHeader->ulHeaderVersion  = ntohl(ptVerHeader->ulHeaderVersion);
    ptVerHeader->usVerType        = ntohs(ptVerHeader->usVerType);
    ptVerHeader->ulCompressedSize = ntohl(ptVerHeader->ulCompressedSize);
    ptVerHeader->ulCompressedCRC  = ntohl(ptVerHeader->ulCompressedCRC);
    ptVerHeader->ulOriginalSize   = ntohl(ptVerHeader->ulOriginalSize);
    ptVerHeader->ulOriginalCRC    = ntohl(ptVerHeader->ulOriginalCRC);
    ptVerHeader->ulSoftType       = ntohl(ptVerHeader->ulSoftType);
    ptVerHeader->ulCreateTime     = ntohl(ptVerHeader->ulCreateTime);
    /*lint -restore*/

}


 /*===========================================================
函数名      :  CheckCrc16
功能        :  CRC16检查
输入参数说明:
               *ucBuffer     -- 待检查的buffer
               ulBufferLength-- buffer长度
               ulTarCrcValue -- 预期CRC
返回值说明  :  0 -- CRC正确
               1 -- CRC长度不正确
               2 -- CRC错误
引用全局变量:
附加说明    :
修改说明    :
  修改日期          版本号      修改人      修改内容
  -----------------------------------------------
  2008年1月25日      1.0       wood        创建
===========================================================*/
unsigned long CheckCrc16(unsigned char *ucBuffer,
                         unsigned long  ulBufferLength,
                         unsigned short ulTarCrcValue)
{
    unsigned short ulCrcValue;
    if(ulBufferLength == 0)
    {
        return 1;
    }

    /* 最终决策修改初始值为 全1 */
    ulCrcValue = BspCountCrc16(0xFFFF,ucBuffer,ulBufferLength);

    if(ulCrcValue != ulTarCrcValue)
    {
        printf("target crc %#8x != calced crc %#8x\n",ulTarCrcValue,ulCrcValue);
        return 2;
    }

    return 0;
}

/*===========================================================
函数名      :  GetDivFromUnion
功能        :  从合并包里获取单个软件的地址以及长度
输入参数说明:
               *pucUnion -- 输入合并包的缓冲区地址
               ucNum -- 输入要提取的软件序号(从0开始)
               **pucDivAddr -- 输出要提取软件的缓冲区地址
               *pulLength -- 输出要提取软件的大小
返回值说明  :  UNPRESS_EC_NULL_BUFFER
               UNPRESS_EC_DIV_NUM_ERROR
               UNPRESS_OK

引用全局变量:
附加说明    :
修改说明    :
  修改日期          版本号      修改人      修改内容
  -----------------------------------------------
  2008年2月19日      1.0       wood        创建
===========================================================*/
unsigned long GetDivFromUnion(unsigned char  *pucUnion,
                              unsigned long   dwWorkMode,
                              unsigned char **pucDivAddr,
                              unsigned long  *pulLength)
{
    TSwPackage *ptUnionAddr;
    unsigned long ulUnionHeaderLen;
    unsigned char ucLoop;
	unsigned char ucNum;

    if(NULL == pucUnion || NULL == pucDivAddr)
    {
        return UNPRESS_EC_NULL_BUFFER;
    }

    ptUnionAddr = (TSwPackage *)pucUnion;
	dbgInfo("The Number of Version is %d\n",ptUnionAddr->ucSwNum);

	switch (dwWorkMode) /* 工作模式转换成包中子版本序号 */
	{
		case RADIO_STANDARD_GSM:
		{
   			ucNum = 0;
    		break;
		}

        case RADIO_STANDARD_CDMA:
        case RADIO_STANDARD_CDMA | RADIO_STANDARD_LTE_FDD:
            ucNum = 0;
            break;

		case RADIO_STANDARD_UMTS:
		{
    		ucNum = 1;
    		break;
		}

		case (RADIO_STANDARD_GSM | RADIO_STANDARD_UMTS):
		{
    		ucNum = 2;
    		break;
		}
		case RADIO_STANDARD_LTE_FDD:
		{
   			ucNum = 0;
    		break;
		}

		default:
		{
		    ucNum = 0;
		}
	}

    if(ucNum > (ptUnionAddr->ucSwNum - 1))
    {
        printf("Max division number of union must be less than %d\n",ptUnionAddr->ucSwNum);
        return UNPRESS_EC_DIV_NUM_ERROR;
    }

	/*目前知道最多三个包打在一起*/
	if((ptUnionAddr->ucSwNum - 1) > 3)
    {
        printf("Max division number of union must be max to 3\n");
        return UNPRESS_EC_DIV_NUM_ERROR;
    }

    ulUnionHeaderLen = sizeof(unsigned char) + ptUnionAddr->ucSwNum * sizeof(TSwIdInfo);

    *pucDivAddr = pucUnion + ulUnionHeaderLen;

    for(ucLoop = 0;ucLoop < ucNum;ucLoop++)
    {
        *pucDivAddr += ptUnionAddr->atSwIdInfo[ucLoop].ulSwLen;
    }/* end of for */

    *pulLength = ptUnionAddr->atSwIdInfo[ucNum].ulSwLen;

	BspSysMsDelay(1);

    return UNPRESS_OK;
}


/*===========================================================
函数名      :  GetDivFromUnionByIndex
功能        :  从合并包里获取单个软件的地址以及长度
输入参数说明:
               *pucUnion -- 输入合并包的缓冲区地址
               ucNum -- 输入要提取的软件序号(从0开始)
               **pucDivAddr -- 输出要提取软件的缓冲区地址
               *pulLength -- 输出要提取软件的大小

返回值说明  :  UNPRESS_EC_NULL_BUFFER
               UNPRESS_EC_DIV_NUM_ERROR
               UNPRESS_OK

引用全局变量:
附加说明    :
修改说明    :
  修改日期          版本号      修改人      修改内容
  -----------------------------------------------
  2008年2月19日      1.0       wood        创建
===========================================================*/
unsigned long GetDivFromUnionByIndex(unsigned char  *pucUnion,
                              UINT32   ulIndex,
                              unsigned char **pucDivAddr,
                              unsigned long  *pulLength)
{
    TSwPackage *ptUnionAddr;
    unsigned long ulUnionHeaderLen;
    unsigned char ucLoop;

    if(NULL == pucUnion || NULL == pucDivAddr)
    {
        return UNPRESS_EC_NULL_BUFFER;
    }

    ptUnionAddr = (TSwPackage *)pucUnion;
    dbgInfo("Total count of Version pack %d\n",ptUnionAddr->ucSwNum);


    if(ulIndex > (UINT32)(ptUnionAddr->ucSwNum - 1))
    {
        printf("Max division number of union must be less than %d\n",ptUnionAddr->ucSwNum);
        return UNPRESS_EC_DIV_NUM_ERROR;
    }
#if 0
    /*目前知道最多六个包打在一起*/
    if((ptUnionAddr->ucSwNum - 1) > 6)
    {
        printf("Max division number of union must be max to 6\n");
        return UNPRESS_EC_DIV_NUM_ERROR;
    }
#endif
    ulUnionHeaderLen = sizeof(unsigned char) + ptUnionAddr->ucSwNum * sizeof(TSwIdInfo);

    *pucDivAddr = pucUnion + ulUnionHeaderLen;

    for(ucLoop = 0;ucLoop < ulIndex;ucLoop++)
    {
        *pucDivAddr += ntohl(ptUnionAddr->atSwIdInfo[ucLoop].ulSwLen);
    }/* end of for */

    *pulLength = ntohl(ptUnionAddr->atSwIdInfo[ulIndex].ulSwLen);

    BspSysMsDelay(1);

    return UNPRESS_OK;
}



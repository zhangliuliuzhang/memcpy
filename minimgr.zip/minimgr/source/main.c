#include "minimgr.h"
#include "pub_svmdef.h"
#include "vxadp.h"
#include "ushellapi.h"
#include "newunpress.h"
#include "minimgradpt.h"
#include "trustsvc.h"
#include "secure_func.h"
#include "flash.h"
#include "crc.h"
#include "pub_code_info.h"
#include "xmlite.h"
#include "zte_slibc.h"

#define strCfgFileName                         "/ata/RRUCFG.INI" /* 即/ata, 和boot确认放在这个路径 */
#define FLAG_MGRVER                            "MGR_VER_FLAG"
#define DbgFlagFileName                        "/ata/miniMGR_dbg"
#define SocDbgFlagFileName                     "/miniMGR_dbg"
#define SafeBootDbgFlagName                    "/ata/SafeBoot_dbg"
#define MGR_LOAD_BY_FLAG                        0x01
#define FILE_NAME_LENGTH                        32
#define MAX_SOFTTYPE_NUM                        32
#define CONNECT_XML_FILE_PATH                   "/ata/rru/RruConnect.xml"
#define LOAD_PROTECT_CONNECT_VER_FLAG           "/Protect.INI"
/*需要内核确认*/
/*
高端内存预留偏移从0x5300开始连续32个16Bytes

0   内核+安全组件         0x5300
3   业务MGR.EXE           0x5310
10  FPGA0                 0x5320
11  FPGA1                 0x5330
12  SOC_FPGA              0x5340
13  SOC_内核安全组件      0x5350
14  SOC_MGR               0x5360
15  MCS_内核安全组件      0x5370
16  MCS_MGR               0x5380
17  AC_DSP                0x5390
18  AC_R8                 0x53a0
19  DPD_DSP               0x53b0

*/
#define BSP_MGR_LOAD_REASON_MARKVAL           0x4d455252 /* MGR运行版本特征码 "MERR"*/
#define MGR_VER_ERR_ADRS         (BspGetHighMemAddr(BSP_HIGH_RESERVED_MEM_BSP) + 0x5310)    /* MGR版本加载错误码，16字节 */
#define MODULE_MGR_VER_ADRS      (BspGetHighMemAddr(BSP_HIGH_RESERVED_MEM_BSP) + 0x5440)    /* MGR版本号，44字节 */
#define MODULE_HASH_VER_ADRS     (BspGetHighMemAddr(BSP_HIGH_RESERVED_MEM_BSP) + 0x55CC)    /* HASH版本号，44字节 */
#define DSP_VER_ADRS             (BspGetHighMemAddr(BSP_HIGH_RESERVED_MEM_BSP) + 0x5090)    /* DPDDSP版本号，44字节 */

/***********************************错误码************************************/
#define  BSP_BOOTINI_OPEN_ERROR      (0x01)  /* boot.ini打开错误(文件不存在)*/
#define  BSP_BOOTINI_LEN_ERROR       (0x02)  /* boot.ini长度错误 */
#define  BSP_BOOTINI_READ_ERROR      (0x03)  /* boot.ini读取错误 */
#define  BSP_BOOTINI_CRC_ERROR       (0x04)  /* boot.ini CRC错误 */
#define  BSP_BOOTINI_WRITE_ERROR     (0x05)  /* boot.ini 写错误 */
#define  BSP_VERINFO_OPEN_ERROR      (0x06)  /* VerInfo.ini打开错误(文件不存在) */
#define  BSP_VERINFO_READ_ERROR      (0x07)  /* VerInfo.ini读取错误 */
#define  BSP_VERINFO_CRC_ERROR       (0x08)  /* VerInfo.ini CRC错误 */
#define  BSP_VERINFO_ZERO_ERROR      (0x09)  /* VerInfo记录为0错误 */
#define  BSP_VER_OPEN_ERROR          (0x0a)  /* 版本文件打开错误(文件不存)*/
#define  BSP_VER_READ_ERROR          (0x0b)  /* 版本文件读取错误 */
#define  BSP_VER_SWCLASS_ERROR       (0x0c)  /* 版本软件类型不匹配错误 */
#define  BSP_VER_CPUTYPE_ERROR       (0x0d)  /* 版本CPU类型不匹配错误 */
#define  BSP_VER_CRC_ERROR           (0x0e)  /* 版本CRC错误 */
#define  BSP_VER_UNCMP_ERROR         (0x0f)  /* 版本解压缩失败错误 */
#define  BSP_VER_EXIST_ERROR         (0x10)  /* 小版本在打包文件中不存在 */
#define  BSP_VER_LOAD_ERROR          (0x11)  /* 小版本加载错误 */
#define  BSP_FLASH_PROTECT_READ_ERROR (0x12)  /*flash保护区读取失败*/
#define  BSP_LOAD_PROC_VER_ERROR     (0x1000)  /*保护区版本加载失败*/
#define  BSP_LOAD_ACK_VER_ERROR      (0x1a00)  /*激活版本加载失败*/
#define  BSP_LOAD_FLAG_READ_ERROR    (0x1b00)  /*读取RRUCFG.INI Flag标志失败*/
#define  BSP_LOAD_FLAG_UPDATE_ERROR  (0x1c00)  /*更新RRUCFG.INI Flag标志失败*/

#define MGR_VER_MASTER                  0
#define MGR_VER_TEMP                    1
#define MGR_VER_PROTECT                 2
#define MGR_VER_SOC                     3
#define MGR_VER_WFS                     4

#define NORMAL_BOOT                     '0'
#define ACTIVE_BOOT                     '1'
#define UPGRADE_BOOT                    '2'
#define FAILURE_BOOT                    '3'

#define FTP_SERV_IP                     "198.33.33.100"

typedef struct tag_T_PkgVerInfo
{
    UINT32 ulSoftType;/*版本类型*/
    UINT32 ulPosition;/*1:保护区;2:文件系统*/
    UINT32 ulVerOffset;
    UINT32 ulPostRes;/*0:cur;1:tmp*/
    CHAR  acFileName[32];
    T_VerFileHeader tVerHeadInfo;
}T_PkgVerInfo;

typedef struct tag_T_CONNECT_XMLLIST_PARA
{
    UINT32 softType;
    UINT32 linkNecessity;
    CHAR acFileName[FILE_NAME_LENGTH];
}T_CONNECT_XMLLIST_PARA;


static T_Bsp_RruIniCfgItem g_tMgrCfgInfo = {0}; /* MGR版本配置信息 */

/*需要从board.h or miniadpt.h中获取的数据*/
static unsigned long g_ulHiMemVirtualBaseAddr  = HIMEM_VIR_BASEADDR;
static off_t         g_ulHiMemPhyBaseAddr = HIMEM_PHY_BASEADDR;
static size_t        g_ulHiMemMapMemSize = USER_RESERVED_SIZE;
static unsigned long g_ulHiMemMapVirtualBaseAddr = 0;

/*主从片定义,master 0, slave 1*/
static UINT32 g_ulMasterOrSlaveFlag = MINIMGR_MASTER_FLAG;
static UINT32 g_SecVerifySwitch = 0;
static UINT32 s_ProZoneAddr = PROTECT_ZONE_ADDRESS;

UINT32 BspSetSecVerifyFunStat(UINT32 ulSwitch)
{
    g_SecVerifySwitch = (ulSwitch==0)?(0):(1);
    return BSP_OK;
}

// bspMGR对应接口: BspCfgSecVerifyFun
UINT32 BspInitSecVerifyFun(VOID) /* 是否启用验签功能 */
{
    UINT32  ulBySwitch = 0;
    UINT32  ulTmpRet = BSP_OK;
    UINT32  ulFunRet = BSP_ERROR;

    /* 检查调试标记 */
    if (BSP_OK == BspGetSafeBootDbgFlag())
    {
        dbgInfo("%s>>MiniMGR File[/ata/SafeBoot_dbg] Exist!\n", __FUNCTION__);
        return BSP_ERROR;
    }

    // 获取安全Boot开关状态: 0-安全关闭, 1-安全打开
    ulTmpRet = BspGetSafeBootCheckSwitch(&ulBySwitch);
    if (BSP_OK == ulTmpRet)
    {
        if (1 == ulBySwitch) /* 启用验签 */
        {
            ulFunRet = BspSetSecVerifyFunStat(1);
            dbgInfo("%s>>MiniMGR SafeBoot Open; SecVerifyFunStat Set %s!\n", __FUNCTION__,
                    (ulFunRet == BSP_OK) ? ("Succ") : ("Error"));
        }
        else
        {
            dbgInfo("%s>>MiniMGR SafeBootCheckSwitch'%d Get Succ! SafeBoot Close;\n",
                    __FUNCTION__, ulBySwitch);
        }
    }
    else
    {
        dbgErr("%s>>MiniMGR SafeBootCheckSwitch'%d Get Error! SafeBoot Close;\n",
               __FUNCTION__, ulBySwitch);
    }

    return ulFunRet;
}

static UINT32 BspGetMasterSlaveFlag(void)
{
    return g_ulMasterOrSlaveFlag;
}

void BspSetMiniMasterSlaveFlag(UINT32 flag)
{
    dbgInfo("%s: flag = %u\n", __FUNCTION__, flag);
    g_ulMasterOrSlaveFlag = flag;
}

/*映射保护区地址*/

/**************************************************************************
* 函数名称: BspDoMemMap
* 功能描述: 虚拟地址映射
* 输入参数: phyAddr       :物理地址
*          size          :申请空间大小
* 输出参数: pVirAddr      :虚拟地址
* 返 回 值: BSP_OK /BSP_ERROR
* 其它说明:
*----------------------------------------------------------------------------*/
UINT32 BspDoMemMap(UINT32 devSel, unsigned long virAddr, off_t phyAddr, size_t size, unsigned long *pVirAddr)
{
    int iSpaceProt = PROT_READ | PROT_WRITE;
    int iFd = -1; /* 打开内存设备的文件描述符 */
    int ret = 0;
#if(CPU_FAMILY == ARM64)
    const char *memDevList[] = {"/dev/mem", "/dev/cachedmem", "/dev/memnc"};
    UINT32 listCnt = NELEMENTS(memDevList);

    if (devSel >= listCnt)
    {
        return BSP_ERROR;
    }
    if ((iFd = open(memDevList[devSel], O_RDWR | O_SYNC)) >= 0)
#else
    if ((iFd = open("/dev/mem", O_RDWR | O_SYNC)) >= 0)
#endif
    {
        *pVirAddr = (unsigned long)mmap((VOID *)virAddr, size, iSpaceProt, MAP_SHARED, iFd, phyAddr);
        if (*pVirAddr == -1)
        {
            ret = close(iFd);
            FCLOSE_CHECK(ret);
            *pVirAddr = 0;
            dbgErr("%s>>ParamAddr(Phy'%lu Vir'%lu): Mmap Error!\n",
                   __FUNCTION__, phyAddr, virAddr);
            return BSP_ERROR;
        }
    }
    else
    {
        dbgErr("%s>>ParamAddr(Phy'%lu Vir'%lu): Open /dev/mem Error!\n",
               __FUNCTION__, phyAddr, virAddr);
        return BSP_ERROR;
    }
    ret = close(iFd);
    FCLOSE_CHECK(ret);

    dbgInfo("%s>>ParamAddr(Phy'%lu Vir'%lu): pVirAddr= %p, size= %#zx\n",
            __FUNCTION__, phyAddr, virAddr, pVirAddr, size);
    return BSP_OK;
}

UINT32 BspMapHighMemAddr(VOID)
{
    BspDoMemMap(MEM_DEVICE_MEMNC, g_ulHiMemVirtualBaseAddr,g_ulHiMemPhyBaseAddr,g_ulHiMemMapMemSize,&g_ulHiMemMapVirtualBaseAddr);
    return BSP_OK;
}

UINT32 BspHighMemUnmap(VOID)
{
    if(g_ulHiMemMapVirtualBaseAddr !=0)
    {
        munmap((unsigned char*)g_ulHiMemMapVirtualBaseAddr,g_ulHiMemMapMemSize);
    }
    return BSP_OK;
}

typedef UINT32 (*FUNC_GETHIGHMEMADDRFUNC)(UINT32 ulType);
FUNC_GETHIGHMEMADDRFUNC pGetHighMemAddrFunc = NULL;

UINT32 BspGetHighMemAddrCallback(FUNC_GETHIGHMEMADDRFUNC pFunc)
{
    INPUT_POINTER_CHECK(pFunc);
    pGetHighMemAddrFunc = pFunc;
    return BSP_OK;
}

unsigned long BspGetHighMemAddr(UINT32 ulType)
{
    unsigned long ulRet = 0;

    if (NULL != pGetHighMemAddrFunc)
    {
       return pGetHighMemAddrFunc(ulType);
    }

    switch(ulType)
    {
        case BSP_HIGH_RESERVED_MEM_BSP :
            ulRet = g_ulHiMemMapVirtualBaseAddr + (BSP_MEM_ADDR - SYS_MEM_TOP);
            break;
        case BSP_HIGH_RESERVED_MEM_MGR :
            ulRet = g_ulHiMemMapVirtualBaseAddr + (OSS_MEM_ADDR - SYS_MEM_TOP);
            break;
        case BSP_HIGH_RESERVED_MEM_APP1 :
            ulRet =  g_ulHiMemMapVirtualBaseAddr + (APP_RESERVED_ADDR - SYS_MEM_TOP);
            break;
        case BSP_HIGH_RESERVED_MEM_USER_DEFINE :
            ulRet =  g_ulHiMemMapVirtualBaseAddr + (BSP_VER_PROTECT_ADDR - SYS_MEM_TOP);
            break;
        default:
            ulRet = g_ulHiMemMapVirtualBaseAddr;
            break;
    }
    if((ulRet == 0)||(ulRet < g_ulHiMemMapVirtualBaseAddr))
    {
        dbgErr("%s>>Type'%u Get BaseAddr[0x%lX] Failed!\n", __FUNCTION__, ulType, ulRet);
        ulRet = 0;
    }
    return ulRet;
}
#if 1
/*****************************************************************************
 *  函数名称   : BspCreateRuCfgIniFile(*)
 *  功能描述   : 创建文件，并写入字段，若文件已经存在，则返回错误
 *  读全局变量 :
 *  写全局变量 :
 *  输入参数   : pcFileName -- 配置文件的路径
                 ptCfgInfo  -- 创建文件同时写入的字段信息

 *  输出参数   : 无
 *  返 回 值   :
 *  其它说明   : 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *  $0000000(N/A),  宋志强@2012-12-06 14:15:58, 创建
 *----------------------------------------------------------------------------
 */
UINT32 BspCreateRuCfgIniFile(const CHAR *pszFileName, T_Bsp_RruIniCfgItem *ptCfgItem)
{
    FILE *fp;
    int iWrite = 0;
    INT32 iTmpRet = 0;

    fp = fopen(pszFileName, "r+b");
    if (NULL != fp)
    {
        /* 如果文件已经存在，则返回错误，不需要重新创建了 */
        iTmpRet = fclose(fp);
        FCLOSE_CHECK(iTmpRet);
        return BSP_ERROR;
    }
    fp = fopen(pszFileName, "w+b");
    if (fp == NULL)
    {
        return BSP_ERROR;
    }

    if(fseek(fp, 0L, SEEK_END) != 0)
    {
        iTmpRet = fclose(fp);
        FCLOSE_CHECK(iTmpRet);
        return BSP_ERROR;
    }

    iWrite = fwrite(ptCfgItem, 1, sizeof(T_Bsp_RruIniCfgItem), fp);
    iTmpRet = fclose(fp);
    FCLOSE_CHECK(iTmpRet);

    if (iWrite == 0)
    {
         return BSP_ERROR;
    }

    (void)chmod(pszFileName, S_IRUSR|S_IWUSR|S_IRGRP|S_IROTH);
    return BSP_OK;
}

/*****************************************************************************
 *  函数名称   : BspReadRuCfgIniFieldValue(*)
 *  功能描述   : 读相应的字段，并读该字段的信息
 *  读全局变量 :
 *  写全局变量 :
 *  输入参数   : pcFileName  -- 配置文件的路径
                 pcFieldName -- 搜索的字段

 *  输出参数   : ptCfgInfo  -- 搜索到相应的字段，读取的该字段信息
 *  返 回 值   :
 *  其它说明   : 重构一下GetRruIniCValue
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *  $0000000(N/A),  yc @2012-10-16 14:15:58, 创建
 *----------------------------------------------------------------------------
 */
UINT32 BspReadRuCfgIniFieldValue(const CHAR * pcFileName, const CHAR *pcFieldName,
                        T_Bsp_RruIniCfgItem *ptCfgInfo)
{
    T_Bsp_RruIniCfgItem tCfgItem = {0};
    FILE *fp = NULL;
    int iRead = 0;
    INT32 iTmpRet = 0;

    if((NULL == pcFileName) || (NULL == pcFieldName) || (NULL == ptCfgInfo))
    {
        return BSP_ERROR_NULL_POINTER;
    }

    fp = fopen(pcFileName, "r+b");
    if(NULL == fp)
    {
        return BSP_ERROR;
    }

    do
    {
        iRead = fread(&tCfgItem, 1, sizeof(T_Bsp_RruIniCfgItem), fp);
        if(iRead != sizeof(T_Bsp_RruIniCfgItem))
        {
            break;
        }
    }while(strncmp(tCfgItem.acFieldName, pcFieldName, RRUCFG_FIELDNAME_LEN) != 0);

    iTmpRet = fclose(fp);
    FCLOSE_CHECK(iTmpRet);

    if(iRead != sizeof(T_Bsp_RruIniCfgItem))
    {
        return BSP_ERROR;
    }

    memcpy(ptCfgInfo, &tCfgItem, sizeof(T_Bsp_RruIniCfgItem));

    return BSP_OK;
}
/*****************************************************************************
 *  函数名称   : BspUpdateRuCfgIniFieldValue(*)
 *  功能描述   : 更新的对应的字段值,按照状态机循环更新字段状态
 *  读全局变量 :
 *  写全局变量 :
 *  输入参数   :  pcFileName -- 配置文件的路径
                  ptCfgInfo  -- 更新的字段
 *  输出参数   :
 *  返 回 值   : BSP_OK -- 正确; 其他失败
 *  其它说明   : 字段存在的时候更新
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *  $0000000(N/A),  yc @2012-10-16 14:15:58, 创建
 *----------------------------------------------------------------------------
 */
UINT32 BspUpdateRuCfgIniFieldValue(const CHAR *pszFileName, T_Bsp_RruIniCfgItem *ptCfgInfo)
{
    FILE *fp;
    UINT32 ulRead;
    UINT32 iWrite = 0;
    UINT32 iLoop = 0;
    T_Bsp_RruIniCfgItem tCfgItemTemp;
    INT32 iTmpRet = 0;

    if(('0' == ptCfgInfo->cFieldValue) || ('3' == ptCfgInfo->cFieldValue))
    {
        /* 值是0和3 不需要更新文件参数*/
        return BSP_OK;
    }

    if ('1' == ptCfgInfo->cFieldValue)
    {
        ptCfgInfo->cFieldValue = '2';
    }
    else if('2' == ptCfgInfo->cFieldValue)
    {
        ptCfgInfo->cFieldValue = '3';
    }
    else
    {
        ptCfgInfo->cFieldValue = '0';
    }

    fp = fopen(pszFileName, "r+b");
    if (fp == NULL)
    {
        printf("open file [%s] fail.\n", pszFileName);
        return FALSE;
    }

    do
    {
        ulRead = fread(&tCfgItemTemp, 1, sizeof(tCfgItemTemp), fp);

        if (ulRead <= 0)
        {
            iTmpRet = fclose(fp);
            FCLOSE_CHECK(iTmpRet);
            return BSP_ERROR;
        }

        if (strncmp(tCfgItemTemp.acFieldName, ptCfgInfo->acFieldName, RRUCFG_FIELDNAME_LEN) != 0)
        {
            iLoop += 1;
        }
        else
        {
            break;
        }
    }while (1);

    ptCfgInfo->cFieldFlag = '=';
    ptCfgInfo->cFieldEnd  = '\n';

    /* 定位到和配置名称对应的配置项 */
    if(fseek(fp, iLoop * sizeof(T_Bsp_RruIniCfgItem), SEEK_SET) != 0)
    {
        iTmpRet = fclose(fp);
        FCLOSE_CHECK(iTmpRet);
        return BSP_ERROR;
    }
    iWrite = fwrite(ptCfgInfo, 1, sizeof(T_Bsp_RruIniCfgItem), fp);
    iTmpRet = fclose(fp);
    FCLOSE_CHECK(iTmpRet);

    if (iWrite == 0)
    {
        printf("write file [%s] fail.\n", pszFileName);
        return BSP_ERROR;
    }
    return BSP_OK;
}
#endif
INT32 BspGetMgrLoadFlag(VOID)
{
    FILE *pfile;
    UINT32 ulRead = BSP_ERROR;
    T_Bsp_RruIniCfgItem tCfgItem = {0};
    UINT32 iRet = BSP_ERROR;
    INT32 iTmpRet = 0;
    INT32 iWrLen = 0;
    CHAR acStrCfgFileName[] = "/ata/RRUCFG.INI";

    pfile = fopen(strCfgFileName,"r+b");
    if(NULL == pfile)
    {
        dbgInfo("RRUCFG.INI File NOT Exit!!\n");
        dbgInfo("Create a New File (for mgrflag) !\n");
        memset((CHAR *)tCfgItem.acFieldName, '\0', RRUCFG_FIELDNAME_LEN);
        strncpy((CHAR *)tCfgItem.acFieldName, FLAG_MGRVER, RRUCFG_FIELDNAME_LEN);
        tCfgItem.cFieldFlag  = '=';
        tCfgItem.cFieldValue = '0';
        tCfgItem.cFieldEnd   = '\n';
        BspCreateRuCfgIniFile(acStrCfgFileName, &tCfgItem);
        return BSP_ERROR;
    }
    do
    {
        ulRead = fread(&tCfgItem, 1, sizeof(tCfgItem), pfile);
        if (ulRead != sizeof(T_Bsp_RruIniCfgItem))
        {
            break;
        }

        if(strncmp(tCfgItem.acFieldName, FLAG_MGRVER, RRUCFG_FIELDNAME_LEN) == 0)
        {
            iRet = MGR_LOAD_BY_FLAG;
            break;
        }
        else
        {
            iRet = BSP_ERROR;
        }
    }while (1);

    if(BSP_ERROR == iRet)
    {
        dbgInfo("There is no MGR_VER_FLAG  section in RRUCFG.INI\nwill create the section and fill it by 0.\n");

        memset((CHAR *)tCfgItem.acFieldName, '\0', RRUCFG_FIELDNAME_LEN);
        strncpy_s((CHAR *)tCfgItem.acFieldName, RRUCFG_FIELDNAME_LEN, FLAG_MGRVER, RRUCFG_FIELDNAME_LEN);
        tCfgItem.cFieldFlag  = '=';
        tCfgItem.cFieldValue = '0';
        tCfgItem.cFieldEnd   = '\n';
        if(fseek(pfile, 0L, SEEK_END) ==0)
        {
            iWrLen = fwrite(&tCfgItem, 1, sizeof(T_Bsp_RruIniCfgItem), pfile);
            if (iWrLen != (INT32)sizeof(T_Bsp_RruIniCfgItem))
            {
                dbgErr("%s>>write file fail.\n", __FUNCTION__);
            }
        }

        iTmpRet = fclose(pfile);
        FCLOSE_CHECK(iTmpRet);
        return iRet;
    }
#if 1
    if(fseek(pfile, 0L, SEEK_SET) !=0)	/*定位到文件的开头*/
    {
        iRet = BSP_ERROR;
    }
    else
    {
        do  /*寻找有无MGR字段，无MGR字段则文件异常*/
        {
            ulRead = fread(&tCfgItem, 1, sizeof(tCfgItem), pfile);
            if (ulRead <= 0)
            {
                iRet = BSP_ERROR;
                break;
            }

            if(strncmp(tCfgItem.acFieldName, FLAG_MGRVER, RRUCFG_FIELDNAME_LEN) == 0)
            {
                iRet = tCfgItem.cFieldValue;
                break;
            }
            else
            {
                iRet = BSP_ERROR;
            }
        }while (1);
    }

    if(BSP_ERROR == iRet)
    {
        dbgInfo("There is no MGR_VER_FLAG section in RRUCFG.INI\n");
    }
#endif
    iTmpRet = fclose(pfile);
    FCLOSE_CHECK(iTmpRet);
    return iRet;
}
/* Started by AICoder, pid:re8c3rf0d76fe6714df5083b00ddcd0aa716a43c */
INT32 BspGetFpgaLoadFlag(VOID)
{
    FILE *pfile = NULL;
    UINT32 ulRead = BSP_ERROR;
    T_Bsp_RruIniCfgItem tCfgItem = {0};
    INT32 iRet = -1;
    INT32 iTmpRet = 0;
    UINT32 uWrRet = 0;
    CHAR acStrCfgFileName[] = "/ata/RRUCFG.INI";

    pfile = fopen(strCfgFileName,"r+b");
    if(NULL == pfile)
    {
        dbgInfo("RRUCFG.INI File NOT Exit!!\n");
        dbgInfo("Create a New File (for fpgaflag) !\n");
        memset((CHAR *)tCfgItem.acFieldName, '\0', RRUCFG_FIELDNAME_LEN);
        strncpy_s((CHAR *)tCfgItem.acFieldName, RRUCFG_FIELDNAME_LEN, FLAG_FPGAVER, RRUCFG_FIELDNAME_LEN);
        tCfgItem.cFieldFlag  = '=';
        tCfgItem.cFieldValue = '0';
        tCfgItem.cFieldEnd   = '\n';
        BspCreateRuCfgIniFile(acStrCfgFileName, &tCfgItem);
        return -1;
    }
    do
    {
        ulRead = fread(&tCfgItem, 1, sizeof(tCfgItem), pfile);
        if (ulRead != sizeof(T_Bsp_RruIniCfgItem))
        {
            break;
        }

        if(strncmp(tCfgItem.acFieldName, FLAG_FPGAVER, RRUCFG_FIELDNAME_LEN) == 0)
        {
            iRet = FPGA_LOAD_BY_NEW_FLAG;
            break;
        }
        else
        {
            iRet = -1;
        }
    }while (1);

    if(-1 == iRet)
    {
        dbgInfo("There is no FPGA_VER_FLAG  section in RRUCFG.INI\nwill create the section and fill it by 0.\n");

        memset((CHAR *)tCfgItem.acFieldName, '\0', RRUCFG_FIELDNAME_LEN);
        strncpy((CHAR *)tCfgItem.acFieldName, FLAG_FPGAVER, RRUCFG_FIELDNAME_LEN);
        tCfgItem.cFieldFlag  = '=';
        tCfgItem.cFieldValue = '0';
        tCfgItem.cFieldEnd   = '\n';
        if(fseek(pfile, 0L, SEEK_END) ==0)
        {
            uWrRet = fwrite(&tCfgItem, 1, sizeof(T_Bsp_RruIniCfgItem), pfile);
            if (uWrRet != (UINT32)sizeof(T_Bsp_RruIniCfgItem))
            {
                dbgErr("%s>>write failed!\n",__FUNCTION__);
            }
        }

        iTmpRet = fclose(pfile);
        FCLOSE_CHECK(iTmpRet);
        return iRet;
    }
#if 1
    if(fseek(pfile, 0L, SEEK_SET) !=0)	/*定位到文件的开头*/
    {
        iRet = -1;
    }
    else
    {
        do  /*寻找有无FPGA字段，无FPGA字段则文件异常*/
        {
            ulRead = fread(&tCfgItem, 1, sizeof(tCfgItem), pfile);
            if (ulRead <= 0)
            {
                iRet = -1;
                break;
            }

            if(strncmp(tCfgItem.acFieldName, FLAG_FPGAVER, RRUCFG_FIELDNAME_LEN) == 0)
            {
                iRet = tCfgItem.cFieldValue;
                break;
            }
            else
            {
                iRet = -1;
            }
        }while (1);
    }

    if(-1 == iRet)
    {
        dbgInfo("There is no FPGA_VER_FLAG section in RRUCFG.INI\n");
    }
#endif
    iTmpRet = fclose(pfile);
    FCLOSE_CHECK(iTmpRet);
    return iRet;

}
/* Ended by AICoder, pid:re8c3rf0d76fe6714df5083b00ddcd0aa716a43c */

UINT32 BspGetFpgaLoadFlagTest(VOID)
{
    INT32 iFlag = -1;
    iFlag = BspGetFpgaLoadFlag();
    dbgInfo("%s>>the flag equal %d!\n",__FUNCTION__,iFlag);
    return 0;
}

UINT32 BspGetMgrVerErrReason(T_CtrlVerErrReason *ptMgrErrReason)
{
#if (CPU_FAMILY != I80X86)

    if (ptMgrErrReason == NULL)
    {
        dbgErr("%s>> input is NULL !\n",__FUNCTION__);
        return BSP_ERROR;
    }
    memcpy(ptMgrErrReason, (T_CtrlVerErrReason *)MGR_VER_ERR_ADRS, sizeof(T_CtrlVerErrReason));
    if (BSP_MGR_LOAD_REASON_MARKVAL == ptMgrErrReason->ulMarkVal)
    {
        return BSP_OK;
    }
    else
    {
        memset(ptMgrErrReason, 0, sizeof(T_CtrlVerErrReason));
        dbgErr("%s>>MarkVal[%#x] is false !\n",__FUNCTION__,ptMgrErrReason->ulMarkVal);
        return BSP_ERROR;
    }
#endif
    return BSP_OK;
}
UINT32  BspClrMgrVerErrReason(VOID)
{
    memset((CHAR *)MGR_VER_ERR_ADRS, 0, sizeof(T_CtrlVerErrReason));

    return BSP_OK;
}
 UINT32  BspSetMgrVerErrReason(UCHAR ucRunVer,UCHAR ucErrReason)
 {
    T_CtrlVerErrReason tMgrErrReason;

    memcpy(&tMgrErrReason, (CHAR *)MGR_VER_ERR_ADRS, sizeof(T_CtrlVerErrReason));
    /*设置特征值，以区分新旧BOOT*/
    tMgrErrReason.ulMarkVal = BSP_MGR_LOAD_REASON_MARKVAL;

    tMgrErrReason.ucRunVer = ucRunVer;
    if (BSP_RUN_VERSION == ucRunVer) /*主用版本*/
    {
        tMgrErrReason.ucMasterVerErr = ucErrReason;
    }
    if (BSP_BAK_VERSION == ucRunVer) /*备用版本*/
    {
        tMgrErrReason.ucSlaveVerErr = ucErrReason;
    }
    if (BSP_BIN_DEF_VERSION == ucRunVer) /*BIN/Default版本*/
    {
        tMgrErrReason.ucBinDefaultVerErr = ucErrReason;
    }
    if (BSP_BAK_DEF_VERSION == ucRunVer) /*BIN/Default版本*/
    {
        tMgrErrReason.ucBakDefaultVerErr = ucErrReason;
    }
    if (BSP_ACK_VERSION == ucRunVer) /*BIN/Default版本*/
    {
        tMgrErrReason.ucAckVerErr = ucErrReason;
    }
    if (BSP_PROVERSION == ucRunVer) /*保护区版本*/
    {
        tMgrErrReason.ucProtectVerErr = ucErrReason;
    }
    memcpy((CHAR *)MGR_VER_ERR_ADRS, &tMgrErrReason, sizeof(T_CtrlVerErrReason));

    return BSP_OK;
 }

 UINT32  BspSetModuleSoftVersion(CHAR *pcModuleSoftVer,UCHAR ucSizeofBytes)
 {
     CHAR *ptModuleAddr = NULL;

     if (pcModuleSoftVer == NULL)
     {
         dbgErr("%s>> input buffer is null !\n",__FUNCTION__);
         return BSP_ERROR_NULL_POINTER;
     }
     ptModuleAddr = (CHAR *)MODULE_MGR_VER_ADRS      ;
     memset((CHAR*)ptModuleAddr, 0,VERNO_LEN);/* 先清空 */
     if (ucSizeofBytes <= VERNO_LEN)
     {
         memcpy((CHAR *)ptModuleAddr, pcModuleSoftVer, ucSizeofBytes);
     }
     else
     {
         memcpy((CHAR *)ptModuleAddr, pcModuleSoftVer, VERNO_LEN);
     }
     return BSP_OK;
 }
 UINT32 mgrverstatus(VOID)
{
    T_CtrlVerErrReason tCpuErrReason = {0};
    CHAR szVer[RUN_VERSION_NAME_SIZE]= {0};
    UCHAR ucReason = 0;
    INT32 lSnpRet = 0;

    if(BSP_OK != BspGetMgrVerErrReason(&tCpuErrReason))
    {
        dbgErr("Get MgrVeErrorReason Fail!\n");
        return BSP_ERROR;
    }
    switch(tCpuErrReason.ucRunVer)
    {
        case BSP_RUN_VERSION:
        {
            lSnpRet =snprintf_s(szVer,RUN_VERSION_NAME_SIZE,"%s","Run Ver(主用版本)\n");
            SNPRINTF_S_CHECK(lSnpRet, RUN_VERSION_NAME_SIZE);
            ucReason = tCpuErrReason.ucMasterVerErr;
            break;
        }
        case BSP_BAK_VERSION:
        {
            lSnpRet =snprintf_s(szVer,RUN_VERSION_NAME_SIZE,"%s","Bak Ver(备用版本)\n");
            SNPRINTF_S_CHECK(lSnpRet, RUN_VERSION_NAME_SIZE);
            ucReason = tCpuErrReason.ucSlaveVerErr;
            break;
        }
        case BSP_BIN_DEF_VERSION:
        {
            lSnpRet =snprintf_s(szVer,RUN_VERSION_NAME_SIZE,"%s","Bin Def Ver(BIN/default版本)\n");
            SNPRINTF_S_CHECK(lSnpRet, RUN_VERSION_NAME_SIZE);
            ucReason = tCpuErrReason.ucBinDefaultVerErr;
            break;
        }
        case BSP_BAK_DEF_VERSION:
        {
            lSnpRet =snprintf_s(szVer,RUN_VERSION_NAME_SIZE,"%s","Bak Def Ver(BAK/default版本)\n");
            SNPRINTF_S_CHECK(lSnpRet, RUN_VERSION_NAME_SIZE);
            ucReason = tCpuErrReason.ucBakDefaultVerErr;
            break;
        }
        case BSP_ACK_VERSION:
        {
            lSnpRet =snprintf_s(szVer,RUN_VERSION_NAME_SIZE,"%s","ACK Ver(激活版本)\n");
            SNPRINTF_S_CHECK(lSnpRet, RUN_VERSION_NAME_SIZE);
            ucReason = tCpuErrReason.ucAckVerErr;
            break;
        }
        case BSP_PROVERSION:
        {
            lSnpRet =snprintf_s(szVer,RUN_VERSION_NAME_SIZE,"%s","Protected Ver(保护区版本)\n");
            SNPRINTF_S_CHECK(lSnpRet, RUN_VERSION_NAME_SIZE);
            ucReason = tCpuErrReason.ucProtectVerErr;
            break;
        }
        case BSP_BOOT_PROVERSION:
        {
            lSnpRet =snprintf_s(szVer,RUN_VERSION_NAME_SIZE,"%s","Protected Ver(保护区版本)\n");
            SNPRINTF_S_CHECK(lSnpRet, RUN_VERSION_NAME_SIZE);
            ucReason = 0;
			break;
        }
        default:
        {
            lSnpRet =snprintf_s(szVer,RUN_VERSION_NAME_SIZE,"%s","Unknow(BSP version?)(无法判断或者是BSP小板本/工装板本)\n");
            SNPRINTF_S_CHECK(lSnpRet, RUN_VERSION_NAME_SIZE);
            ucReason = 0xFF;
        }
            break;
    }
   dbgErr(szVer);
   dbgErr("mgr load error reason: %x\n",ucReason);
   return BSP_OK;
}
#if 0
 UINT32 BspGetProtectMgrVerInfo(UINT32 ulVerIndex, UINT32 *pulVerOffset, T_VerFileHeader* ptVerHeader)
{
    UINT32 ulRet = BSP_OK;

    BYTE* pbyHeaderBuf;
    TSwPackage *ptUnionAddr;
    UINT32 ulUnionHeaderLen;
    UINT32 ulVerOffset;
    UINT32 ulLoop;
    T_VerProtectHead *ptProHead;
    UINT32 ulProZoneAddrOffset;
    UINT32 ulProtectHeadLen;
    UINT32 ulProtectFpgaVerLen;
    UINT32 ulFpgaOffset;

    ulProZoneAddrOffset = PROTECT_ZONE_ADDRESS;//BspGetVerProtectAddr();	/*拿到保护区偏移地址*/
    ulProtectHeadLen = sizeof(T_VerProtectHead);

    ptProHead = (T_VerProtectHead *)malloc(ulProtectHeadLen);
    if(NULL == ptProHead)
    {
        dbgInfo("%s>> malloc failed !!\n",__FUNCTION__);
        return BSP_ERROR;
    }

    memset(ptProHead, 0, ulProtectHeadLen);
    ulRet = BspFlashRead(ulProZoneAddrOffset, (UCHAR *)ptProHead, ulProtectHeadLen);

    if(ulRet != BSP_OK)
    {
        dbgInfo(" %s>>T_VerProtectHead INFO READ wrong!!\n",__FUNCTION__);
        free(ptProHead);
        ptProHead = NULL;
        return BSP_ERROR;
    }

    ulFpgaOffset        = ptProHead->tVerInfo[1].ulVerOffSet;	/*版本种类 0：CPU软件 1：FPGA软件 */
    ulProtectFpgaVerLen = ptProHead->tVerInfo[1].tVerInfoFile.ulSWLength;

    pbyHeaderBuf = (BYTE *)malloc(sizeof(T_VerFileHeader) + sizeof(TSwPackage));
    if(NULL == pbyHeaderBuf)
    {
        dbgInfo("Load: headerbuf malloc error. %s: %d\n",__FUNCTION__, __LINE__);
        free(ptProHead);
        ptProHead = NULL;
        return BSP_ERROR;
    }

    ulRet = BspFlashRead(ulProZoneAddrOffset + ulFpgaOffset, (UCHAR *)pbyHeaderBuf, sizeof(T_VerFileHeader) + sizeof(TSwPackage));

    if (BSP_OK != ulRet)
    {
        free(ptProHead);
        free(pbyHeaderBuf);
        return BSP_ERROR;
    }

    ptUnionAddr = (TSwPackage*) (pbyHeaderBuf+ sizeof(T_VerFileHeader));
    if(ulVerIndex > (UINT32)(ptUnionAddr->ucSwNum - 1))
    {
        dbgErr("Max division number of union must be less than %d\n",ptUnionAddr->ucSwNum);
        free(ptProHead);
        ptProHead = NULL;
        free(pbyHeaderBuf);
        pbyHeaderBuf = NULL;
        return UNPRESS_EC_DIV_NUM_ERROR;
    }

    ulUnionHeaderLen = sizeof(unsigned char) + ptUnionAddr->ucSwNum * sizeof(TSwIdInfo);
    ulVerOffset = sizeof(T_VerFileHeader) + ulUnionHeaderLen;

    for(ulLoop = 0;ulLoop < ulVerIndex; ulLoop++)
    {
        ulVerOffset += ntohl(ptUnionAddr->atSwIdInfo[ulLoop].ulSwLen);
    }

    free(pbyHeaderBuf);
    pbyHeaderBuf = NULL;
    free(ptProHead);
    ptProHead = NULL;

    ulRet = BspFlashRead(ulProZoneAddrOffset + ulFpgaOffset + ulVerOffset, (UCHAR *)ptVerHeader, sizeof(T_VerFileHeader));

    if (BSP_OK != ulRet )
    {
        dbgErr("Error! VerLen = 0x%x, ReadLen = 0x%x.\n",sizeof(T_VerFileHeader), ulRet);
        ulRet = BSP_ERROR;
    }
    ptVerHeader->ulCRC32          = ntohl(ptVerHeader->ulCRC32);
    ptVerHeader->usVerType        = ntohs(ptVerHeader->usVerType);
    ptVerHeader->ulCompressedSize = ntohl(ptVerHeader->ulCompressedSize);
    ptVerHeader->ulCompressedCRC  = ntohl(ptVerHeader->ulCompressedCRC);
    ptVerHeader->ulOriginalSize   = ntohl(ptVerHeader->ulOriginalSize);
    ptVerHeader->ulOriginalCRC    = ntohl(ptVerHeader->ulOriginalCRC);
    ptVerHeader->ulSoftType       = ntohl(ptVerHeader->ulSoftType);
    ptVerHeader->ulCreateTime     = ntohl(ptVerHeader->ulCreateTime);

    *pulVerOffset = ulFpgaOffset + ulVerOffset;

    dbgLow("FpgaVer Offset:0x%0x\n",*pulVerOffset);

    dbgLow("File CRC:                             0x%lx\n", ptVerHeader->ulCRC32);
    dbgLow("File VerType:                         0x%x\n",  ptVerHeader->usVerType);
    dbgLow("File Compressed Size:                 0x%lx\n", ptVerHeader->ulCompressedSize);
    dbgLow("File Compressed CRC:                  0x%lx\n", ptVerHeader->ulCompressedCRC);
    dbgLow("File Original Size:                   0x%lx\n", ptVerHeader->ulOriginalSize);
    dbgLow("File Original CRC:                    0x%lx\n", ptVerHeader->ulOriginalCRC);
    dbgLow("File Create time:                     %ld\n",   ptVerHeader->ulCreateTime);

    return ulRet;
}
#else

/**************************************************************************
 * 函数名称: BspGetFileHeaderInfo
 * 功能描述: 获取文件的头信息
 * 输入参数: ulBuf:  带路径的文件名
 * 输出参数: ptFileHeader: 获取的文件头信息
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * 修改日期       版本号           修改人    修改内容
 * ------------------------------------------------------------------------
 * 2021年07月19日        00283311      创建
 **************************************************************************/
static UINT32 BspGetFileHeaderInfo(CHAR *ulBuf, T_VerFileHeader *ptFileHeader)
{
    UINT32  ulRet               = BSP_OK;
    INT32   lRet                = 0;
    INT32   lReadLen            = 0;
    INT32   lSize               = 1;
    INT32   lLenth              = 128;//sizeof(T_VerFileHeader)
    T_VerFileHeader tFileHeader = {0};

    INPUT_POINTER_CHECK(ulBuf);
    INPUT_POINTER_CHECK(ptFileHeader);

    FILE *pf = NULL;
    pf = fopen(ulBuf, "rb");
    if(NULL == pf)
    {
        dbgErr("%s>>can't open %s !\n",__FUNCTION__,ulBuf);
        return BSP_ERROR;
    }
    if(fseek(pf, 0 ,SEEK_SET) != 0)
    {
        lRet = fclose(pf);
        FCLOSE_CHECK(lRet);
        return BSP_ERROR;
    }
    lReadLen = fread(&tFileHeader, lSize, lLenth, pf);
    if (lReadLen != (int)sizeof(T_VerFileHeader))
    {
        dbgErr("%s>>Error! VerLen = 0x%zx, ReadLen = 0x%x.\n",__FUNCTION__,sizeof(T_VerFileHeader), lReadLen);
        lRet = fclose(pf);
        FCLOSE_CHECK(lRet);
        return BSP_ERROR;
    }
    lRet = fclose(pf);
    FCLOSE_CHECK(lRet);


    ptFileHeader->ulCRC32            = ntohl(tFileHeader.ulCRC32);
    ptFileHeader->ulHeaderVersion    = ntohl(tFileHeader.ulHeaderVersion);
    ptFileHeader->usVerType          = ntohs(tFileHeader.usVerType);
    ptFileHeader->ucCpuType          = tFileHeader.ucCpuType;
    ptFileHeader->ucReserved0        = tFileHeader.ucReserved0;
    ptFileHeader->ulCompressedSize   = ntohl(tFileHeader.ulCompressedSize);
    ptFileHeader->ulCompressedCRC    = ntohl(tFileHeader.ulCompressedCRC);
    ptFileHeader->ulOriginalSize     = ntohl(tFileHeader.ulOriginalSize);
    ptFileHeader->ulOriginalCRC      = ntohl(tFileHeader.ulOriginalCRC);
    ptFileHeader->ulSoftType         = ntohl(tFileHeader.ulSoftType);
    ptFileHeader->ulCreateTime       = ntohl(tFileHeader.ulCreateTime);
    ptFileHeader->ucPackedFile       = tFileHeader.ucPackedFile;
    ptFileHeader->ucPackedFileNum    = tFileHeader.ucPackedFileNum;
    memcpy_s(ptFileHeader->ucVerNo,VERNO_LEN,&tFileHeader.ucVerNo,VERNO_LEN);

    return ulRet;
}

/**************************************************************************
 * 函数名称: BspCalculateFileCrc
 * 功能描述: 从文件系统读文件并计算CRC
 * 输入参数: pFileName: 包含路径的文件名
 * 输出参数: pulCrc: 计算的CRC结果
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明: 适用于前四个字节为CRC的文件
 * 修改日期       版本号           修改人    修改内容
 * ------------------------------------------------------------------------
 * 2021年07月16日        00283311      创建
 **************************************************************************/

static UINT32 BspCalculateFileCrc(CHAR *pFileName, UINT32 *pulCrc)
{
    UINT32 ulBuffLen       = 0;
    UCHAR  *pucBuffer      = NULL;
    INT32  iReadLen        = 0;
    INT32  lSnpRet         = 0;
    FILE   *fp             = NULL;
    INT32  status          = 0;
    struct stat tStatInfo  = {0};

    INPUT_POINTER_CHECK(pFileName);
    INPUT_POINTER_CHECK(pulCrc);

    fp = fopen(pFileName, "rb");
    if(NULL == fp)
    {
        dbgErr("%s>>can't open %s !\n",__FUNCTION__,pFileName);
        return BSP_ERROR;
    }
    else
    {
        //获取运行版本文件长度
        status = stat(pFileName, &tStatInfo);
        if(0!= status)
        {
            lSnpRet = fclose(fp);
            FCLOSE_CHECK(lSnpRet);
            dbgErr("%s>>File:%s not exist!!\n",__FUNCTION__,pFileName);
            return BSP_ERROR;
        }

        if(tStatInfo.st_size < 0 || tStatInfo.st_size >= 0x7FFFFFFF)
        {
            lSnpRet = fclose(fp);
            FCLOSE_CHECK(lSnpRet);
            dbgErr("%s>>Casting data from LONG to UINT32 ERROR!\n",__FUNCTION__);
            return BSP_ERROR;
        }
        else
        {
            ulBuffLen = (UINT32)tStatInfo.st_size;
        }

        //申请内存用于CRC校验
        pucBuffer = (UCHAR *)malloc(ulBuffLen);
        if (NULL == pucBuffer)
        {
            lSnpRet = fclose(fp);
            FCLOSE_CHECK(lSnpRet);
            free(pucBuffer);
            pucBuffer = NULL;
            dbgErr("%s>>malloc buffer for crc calculte failed !\n",__FUNCTION__);
            return BSP_ERROR;
        }
    }

    iReadLen = fread(pucBuffer, 1, ulBuffLen, fp);
    if (iReadLen != ulBuffLen)
    {
        lSnpRet = fclose(fp);
        FCLOSE_CHECK(lSnpRet);
        free(pucBuffer);
        pucBuffer = NULL;
        dbgErr("%s>>fread  file %s error !\n",__FUNCTION__,pFileName);
        return BSP_ERROR;
    }
    *pulCrc = BspCountCrc16(0xFFFF, (UCHAR *)pucBuffer+sizeof(UINT32), ulBuffLen-sizeof(UINT32));

    lSnpRet = fclose(fp);
    FCLOSE_CHECK(lSnpRet);
    free(pucBuffer);
    pucBuffer = NULL;

    dbgInfo("%s>>File:%s ,CalcCrc = 0x%x\n",__FUNCTION__,pFileName,*pulCrc);
    return BSP_OK;
}

void BspSetProZoneAddr(UINT32 addr)
{
    s_ProZoneAddr = addr;
}

static UINT32 BspGetVerProtectAddr(void)
{
    return s_ProZoneAddr;
}

/*验签函数*/
static unsigned long BspCheckProtectVerSafeFunc(CHAR* verName)
{
    UINT32 ulCnt = 0;
    UINT32 ulIdxSign = 0xFFFF;
    UINT32 ulIdxVer = 0xFFFF;
    unsigned long ulRet = BSP_OK;
    UINT32 ulProZoneAddrOffset = 0;
    UINT32 ulProtectHeadLen = 0;
    UINT32 ulSignLen = 0;
    UINT32 ulSignOffSet = 0;
    UINT32 ulVerLen = 0;
    UINT32 ulVerOffSet = 0;
    UINT32 ulVerCrc = 0;
    UCHAR ucP1Data[256]={0};
    T_VerProtectHead *ptProHead = NULL;
    BYTE* pbSignBuf = NULL;
    BYTE* pbSignData = NULL;
    BYTE* pbVerBuf = NULL;
    UINT32 ulLoop = 0;
    const CHAR *tmpStr = NULL;

    if(verName == NULL)
    {
        dbgErr("%s>>input para is null !\n",__FUNCTION__);
        return BSP_ERROR;
    }

    ulProZoneAddrOffset = BspGetVerProtectAddr();   /*拿到保护区偏移地址*/
    ulProtectHeadLen = sizeof(T_VerProtectHead);

    ptProHead = (T_VerProtectHead *)malloc(ulProtectHeadLen);
    if(NULL == ptProHead)
    {
        dbgErr("%s>>file:%s  malloc failed !![line:%d]\n",verName,__FUNCTION__,__LINE__);
        return BSP_ERROR;
    }

    memset(ptProHead, 0, ulProtectHeadLen);
    ulRet = BspFlashRead(ulProZoneAddrOffset, (UCHAR *)ptProHead, ulProtectHeadLen);
    if(ulRet != BSP_OK)
    {
        dbgErr(" %s>>file:%s T_VerProtectHead INFO READ wrong!!\n",verName,__FUNCTION__);
        free(ptProHead);
        ptProHead = NULL;
        return BSP_ERROR;
    }

    /*获取验签文件*/
    ulLoop = PROTECT_FILES_NUM_MAX;
    if (ptProHead->tVerInfoFileHead.ucReserve[1] < PROTECT_FILES_NUM_MAX)
    {
        ulLoop = ptProHead->tVerInfoFileHead.ucReserve[1];
    }
    if (ptProHead->tVerInfoFileHead.ucReserve[1] == 0)
    {
        dbgErr("%s>>ptProHead->tVerInfoFileHead.ucReserve[1] is equal 0!\n",__FUNCTION__);
        free(ptProHead);
        ptProHead = NULL;
        return BSP_ERROR;
    }
    for(ulCnt = 0;ulCnt < ulLoop;ulCnt++)
    {
        if(strncmp("cur27.swv", ptProHead->tVerInfo[ulCnt].tVerInfoFile.acFileName, zte_strnlen_s("cur27.swv",32)) == 0)
        {
            dbgInfo("%s>>find %s,Index is %d\n",__FUNCTION__,"cur27.swv",ulCnt);
            //break;
            ulIdxSign = ulCnt;
        }
        else if(strncmp(verName, ptProHead->tVerInfo[ulCnt].tVerInfoFile.acFileName, strlen(verName)) == 0)
        {
            dbgInfo("%s>>find %s,Index is %d\n",__FUNCTION__,verName,ulCnt);
            //break;
            ulIdxVer = ulCnt;
        }
    }
    if((ulIdxSign == 0xFFFF)||(ulIdxVer == 0xFFFF))
    {
        if (ulIdxSign == 0xFFFF)
        {
            tmpStr = "cur27.swv";
        }
        else
        {
            tmpStr = verName;
        }
        dbgErr("%s>>can't find %s in protectzone !\n",__FUNCTION__, tmpStr);
        free(ptProHead);
        ptProHead = NULL;
        return BSP_ERROR;
    }
    if (ulIdxSign >= PROTECT_FILES_NUM_MAX || ulIdxVer >= PROTECT_FILES_NUM_MAX)
    {
        dbgErr("%s>>The Index of tVerInfo is out of bound!\n",__FUNCTION__);
        free(ptProHead);
        ptProHead = NULL;
        return BSP_ERROR;
    }
    ulSignLen = ptProHead->tVerInfo[ulIdxSign].tVerInfoFile.ulSWLength;
    ulSignOffSet = ptProHead->tVerInfo[ulIdxSign].ulVerOffSet;
    ulVerLen =  ptProHead->tVerInfo[ulIdxVer].tVerInfoFile.ulSWLength;
    ulVerOffSet = ptProHead->tVerInfo[ulIdxVer].ulVerOffSet;
    ulVerCrc = ptProHead->tVerInfo[ulIdxVer].tVerInfoFile.ulCRC32;

    free(ptProHead);
    ptProHead = NULL;

    /*获取sign data*/
    pbSignBuf = (BYTE *)malloc(ulSignLen);
    if(NULL == pbSignBuf)
    {
        dbgInfo("Load file:%s, pbSignBuf malloc error. %s: %d\n",verName,__FUNCTION__, __LINE__);
        return BSP_ERROR;
    }
    ulRet = BspFlashRead(ulProZoneAddrOffset +ulSignOffSet, (UCHAR *)pbSignBuf,ulSignLen);
    if (BSP_OK != ulRet)
    {
        dbgErr("%s>>file:%s flash read signdata failed !\n",__FUNCTION__,verName);
        free(pbSignBuf);
        pbSignBuf = NULL;
        return BSP_ERROR;
    }

    /*获取ver data*/
    pbVerBuf = (BYTE *)malloc(ulVerLen);
    if(NULL == pbVerBuf)
    {
        free(pbSignBuf);
        pbSignBuf = NULL;
        dbgInfo("Load file:%s, pbVerBuf malloc error. %s: %d\n",verName,__FUNCTION__, __LINE__);
        return BSP_ERROR;
    }
    ulRet = BspFlashRead(ulProZoneAddrOffset + ulVerOffSet, (UCHAR *)pbVerBuf,ulVerLen);
    if (BSP_OK != ulRet)
    {
        dbgErr("%s>>file:%s flash read verdata failed !\n",__FUNCTION__,verName);
        free(pbSignBuf);
        pbSignBuf = NULL;
        free(pbVerBuf);
        pbVerBuf = NULL;

        return BSP_ERROR;
    }

    pbSignData = (BYTE *)malloc(4096);
    if(NULL == pbSignData)
    {
        dbgInfo("Load file:%s, pbSignData malloc error. %s: %d\n",verName,__FUNCTION__, __LINE__);
        free(pbSignBuf);
        pbSignBuf = NULL;
        free(pbVerBuf);
        pbVerBuf = NULL;
        return BSP_ERROR;
    }
    if(BSP_OK !=(ulRet = BspGetVersionSign((CHAR *)pbSignBuf,ulSignLen,ulVerLen,ulVerCrc,pbSignData)) )
    {
        dbgInfo("%s>>----------------------------\n",__FUNCTION__);
        dbgErr("%s>>file:%s Get VerSign failed !\n",__FUNCTION__,verName);
        free(pbSignBuf);
        pbSignBuf = NULL;
        free(pbVerBuf);
        pbVerBuf = NULL;
        free(pbSignData);
        pbSignData = NULL;

        return BSP_ERROR;
    }

    BspDecodeB64(pbSignData,ucP1Data,256);

    if(BSP_OK !=(ulRet = BspModuleVersion_Verify(pbVerBuf,ulVerLen,ucP1Data)) )
    {
        dbgErr("%s>>file:%s verify module failed !\n",__FUNCTION__,verName);
    }
    else
    {
        dbgInfo("%s>>file:%s verify module succ !\n",__FUNCTION__,verName);
    }
    free(pbSignBuf);
    pbSignBuf = NULL;
    free(pbVerBuf);
    pbVerBuf = NULL;
    free(pbSignData);
    pbSignData = NULL;

    return ulRet;
}

unsigned long BspGetProtectFileInfo(UINT32 ulSoftVerType,UINT32 ulVerIndex,T_PkgVerInfo* ptProctVerInfo)
{
    unsigned long ulRet = BSP_OK;
    BYTE* pbyHeaderBuf = NULL;
    TSwPackage *ptUnionAddr = NULL;
    UINT32 ulUnionHeaderLen = 0;
    UINT32 ulVerOffset = 0;
    UINT32 ulLoop = 0;
    T_VerProtectHead *ptProHead = NULL;
    UINT32 ulProZoneAddrOffset = 0;
    UINT32 ulProtectHeadLen = 0;
    UINT32 ulFpgaOffset = 0;
    UINT32 ulCnt = 0;
    CHAR acFileName[32]={0};

    //INPUT_POINTER_CHECK(pcFileName);
    INPUT_POINTER_CHECK(ptProctVerInfo);

    ulProZoneAddrOffset = BspGetVerProtectAddr();//BspGetVerProtectAddr();   /*拿到保护区偏移地址*/
    ulProtectHeadLen = sizeof(T_VerProtectHead);

    /*生成保护区名字*/
    if(snprintf_s(acFileName,32,"cur%d.swv",ulSoftVerType) < 0)
    {
        dbgErr("%s>>snprintf error ![line:%d]\n",__FUNCTION__,__LINE__);
        return BSP_ERROR;
    }
    /*是否验签*/
    if(1 == g_SecVerifySwitch)
    {
        if(BspCheckProtectVerSafeFunc(acFileName)!=BSP_OK)
        {
            dbgErr("%s>>file:%s,SecVerifyVer Failed !\n",__FUNCTION__,acFileName);
            return BSP_ERROR;
        }
    }

    ptProHead = (T_VerProtectHead *)malloc(ulProtectHeadLen);
    if(NULL == ptProHead)
    {
        dbgErr("%s>>malloc failed !![line:%d]\n",__FUNCTION__,__LINE__);
        return BSP_ERROR;
    }
    memset(ptProHead, 0, ulProtectHeadLen);

    ulRet = BspFlashRead(ulProZoneAddrOffset, (UCHAR *)ptProHead, ulProtectHeadLen);
    if(ulRet != BSP_OK)
    {
        dbgErr(" %s>>T_VerProtectHead INFO READ wrong, ret:%lx\n",__FUNCTION__, ulRet);
        free(ptProHead);
        ptProHead = NULL;
        return BSP_ERROR;
    }
    /*比较名字查找需要的版本*/
    for(ulCnt = 0;ulCnt < PROTECT_FILES_NUM_MAX;ulCnt++)
    {
        if(strncmp(acFileName, ptProHead->tVerInfo[ulCnt].tVerInfoFile.acFileName, strlen(acFileName)) == 0)
        {
            dbgInfo("%s>>find %s,Index is %d\n",__FUNCTION__,acFileName,ulCnt);
            break;
        }
    }
    if(ulCnt == PROTECT_FILES_NUM_MAX)
    {
        dbgErr("%s>>can't find %s in protectzone !\n",__FUNCTION__,acFileName);
        free(ptProHead);
        ptProHead = NULL;
        return BSP_ERROR;
    }

    ulFpgaOffset = ptProHead->tVerInfo[ulCnt].ulVerOffSet;   /*版本种类 0：CPU软件 1：FPGA软件 */

    pbyHeaderBuf = (BYTE *)malloc(sizeof(T_VerFileHeader) + sizeof(TSwPackage));
    if(NULL == pbyHeaderBuf)
    {
        dbgInfo("Load: headerbuf malloc error. %s: %d\n",__FUNCTION__, __LINE__);
        free(ptProHead);
        ptProHead = NULL;
        return BSP_ERROR;
    }

    ulRet = BspFlashRead(ulProZoneAddrOffset + ulFpgaOffset, (UCHAR *)pbyHeaderBuf, sizeof(T_VerFileHeader) + sizeof(TSwPackage));
    if (BSP_OK != ulRet)
    {
        free(ptProHead);
        free(pbyHeaderBuf);
        return BSP_ERROR;
    }
    /*设置版本号到高端内存*/
    if(BSP_OK != BspSetModuleSoftVersion((CHAR*)((T_VerFileHeader*)pbyHeaderBuf)->ucVerNo,(UCHAR)VERNO_LEN))
    {
        dbgErr("%s>>BspSetModuleSoftVersionTest failed!\n",__FUNCTION__);
    }

    ptUnionAddr = (TSwPackage*) (pbyHeaderBuf+ sizeof(T_VerFileHeader));
    if(ulVerIndex > (UINT32)(ptUnionAddr->ucSwNum - 1))
    {
        dbgErr("%s>>Max division number of union must be less than %d [verIdx %d]\n",__FUNCTION__,ptUnionAddr->ucSwNum,ulVerIndex);
        free(ptProHead);
        ptProHead = NULL;
        free(pbyHeaderBuf);
        pbyHeaderBuf = NULL;
        return UNPRESS_EC_DIV_NUM_ERROR;
    }

    ulUnionHeaderLen = sizeof(unsigned char) + ptUnionAddr->ucSwNum * sizeof(TSwIdInfo);
    ulVerOffset = sizeof(T_VerFileHeader) + ulUnionHeaderLen;

    for(ulLoop = 0;ulLoop < ulVerIndex; ulLoop++)
    {
        ulVerOffset += ntohl(ptUnionAddr->atSwIdInfo[ulLoop].ulSwLen);
    }

    free(pbyHeaderBuf);
    pbyHeaderBuf = NULL;
    free(ptProHead);
    ptProHead = NULL;

    //ptVerFileHead =  &(ptProctVerInfo->tVerHeadInfo);
    ulRet = BspFlashRead(ulProZoneAddrOffset + ulFpgaOffset + ulVerOffset, (UCHAR *)&(ptProctVerInfo->tVerHeadInfo), sizeof(T_VerFileHeader));
    if (BSP_OK != ulRet )
    {
        dbgErr("%s>>Error! VerLen = 0x%zx, ReadLen = 0x%lx.\n",__FUNCTION__,sizeof(T_VerFileHeader), ulRet);
        ulRet = BSP_ERROR;
    }

    if(snprintf_s(ptProctVerInfo->acFileName,32,"%s", acFileName) < 0)
    {
        dbgErr("%s>>snprintf error ![line:%d]\n",__FUNCTION__,__LINE__);
        return BSP_ERROR;
    }

    ptProctVerInfo->tVerHeadInfo.ulCRC32          = ntohl(ptProctVerInfo->tVerHeadInfo.ulCRC32);
    ptProctVerInfo->tVerHeadInfo.usVerType        = ntohs(ptProctVerInfo->tVerHeadInfo.usVerType);
    ptProctVerInfo->tVerHeadInfo.ulCompressedSize = ntohl(ptProctVerInfo->tVerHeadInfo.ulCompressedSize);
    ptProctVerInfo->tVerHeadInfo.ulCompressedCRC  = ntohl(ptProctVerInfo->tVerHeadInfo.ulCompressedCRC);
    ptProctVerInfo->tVerHeadInfo.ulOriginalSize   = ntohl(ptProctVerInfo->tVerHeadInfo.ulOriginalSize);
    ptProctVerInfo->tVerHeadInfo.ulOriginalCRC    = ntohl(ptProctVerInfo->tVerHeadInfo.ulOriginalCRC);
    ptProctVerInfo->tVerHeadInfo.ulSoftType       = ntohl(ptProctVerInfo->tVerHeadInfo.ulSoftType);
    ptProctVerInfo->tVerHeadInfo.ulCreateTime     = ntohl(ptProctVerInfo->tVerHeadInfo.ulCreateTime);

    ptProctVerInfo->ulVerOffset = ulFpgaOffset + ulVerOffset;
    ptProctVerInfo->ulPosition = 1;/*保护区版本*/

    dbgInfo("Ver Offset:0x%0x [position:%d]\n",ptProctVerInfo->ulVerOffset,ptProctVerInfo->ulPosition);

    dbgInfo("File CRC:                             0x%x\n", ptProctVerInfo->tVerHeadInfo.ulCRC32);
    dbgInfo("File VerType:                         0x%x\n", ptProctVerInfo->tVerHeadInfo.usVerType);
    dbgInfo("File Compressed Size:                 0x%x\n", ptProctVerInfo->tVerHeadInfo.ulCompressedSize);
    dbgInfo("File Compressed CRC:                  0x%x\n", ptProctVerInfo->tVerHeadInfo.ulCompressedCRC);
    dbgInfo("File Original Size:                   0x%x\n", ptProctVerInfo->tVerHeadInfo.ulOriginalSize);
    dbgInfo("File Original CRC:                    0x%x\n", ptProctVerInfo->tVerHeadInfo.ulOriginalCRC);
    dbgInfo("File Create time:                     %u\n",   ptProctVerInfo->tVerHeadInfo.ulCreateTime);

    return ulRet;
}
static unsigned long BspCheckSystemVerSafeFunc(char* verName,UINT32 ulPostRes)
{
    unsigned long ulRet = BSP_OK;
    UINT32 ulVerLen = 0;
    UINT32 ulVerCrc = 0;
    UCHAR ucP1Data[256]={0};
    //BYTE* pbSignData = NULL;
    UCHAR * pbSignData = NULL;
    CHAR acJsonFile[60] = {0};
    UCHAR aucFileInfo[256] = {0};
    CHAR *pcAddrS = NULL;
    CHAR acJsonFileBspPath[2][32] = {"/ata/BSP/cur27.swv","/ata/BSP/tmp27.swv"};
    CHAR acJsonFileRruPath[2][32] = {"/ata/rru/cur27.swv","/ata/rru/tmp27.swv"};
    UINT32 ulHeadFileCrc = 0;
    UINT32 ulCalCrc = 0;
    T_VerFileHeader ptFileHeader = {0};

    if(verName == NULL)
    {
        dbgErr("%s>>input para is null !\n",__FUNCTION__);
        return BSP_ERROR;
    }

    if(strlen(verName) > 255)
    {
        dbgErr("%s>>Input failed!The length of verName equal %zu!\n",__FUNCTION__,strlen(verName));
        return BSP_ERROR;
    }
    memcpy(aucFileInfo, verName, strlen(verName));
    aucFileInfo[255]='\0';
    pcAddrS = strstr((CHAR *)aucFileInfo, "/ata/BSP/");
    if(NULL == pcAddrS)
    {
        pcAddrS = strstr((CHAR *)aucFileInfo, "/ata/rru/");
        if(NULL == pcAddrS)
        {
            dbgErr("%s>>VerName %s input failed !\n",__FUNCTION__,verName);
            return BSP_ERROR;
        }
        else
        {
            if(snprintf_s(acJsonFile,60,"%s", acJsonFileRruPath[ulPostRes]) < 0)
            {
                dbgErr("%s>>snprintf error [line:%d]\n",__FUNCTION__,__LINE__);
                return BSP_ERROR;
            }
        }
    }
    else
    {
        if(snprintf_s(acJsonFile,60,"%s", acJsonFileBspPath[ulPostRes]) < 0)
        {
            dbgErr("%s>>snprintf error [line:%d]\n",__FUNCTION__,__LINE__);
            return BSP_ERROR;
        }
    }
    /*获取正确的hash文件*/
    if(ulPostRes > 1)
    {
        dbgErr("%s>>file: %s,ulPostRes is %d,[0~1] !\n",__FUNCTION__,verName,ulPostRes);
        return BSP_ERROR;
    }

    /*获取版本信息*/
    if(BSP_OK!=(ulRet=BspGetVerFileInfo(verName,&ulVerLen,&ulVerCrc)))
    {
        dbgErr("%s>>file: %s,GetVerFileInfo failed ![ret %#lx]\n",__FUNCTION__,verName,ulRet);
        return BSP_ERROR;
    }

    //提取文件头信息
    if(BSP_OK != BspGetFileHeaderInfo(acJsonFile,(T_VerFileHeader *)(&ptFileHeader)))
    {
        dbgErr("%s>>BspGetFileHeaderInfo failed!\n",__FUNCTION__);
        return BSP_ERROR;
    }
    /*校验cur27.swv的CRC值*/
    ulHeadFileCrc = ptFileHeader.ulCRC32;
    if(BSP_OK != BspCalculateFileCrc(acJsonFile,&ulCalCrc))
    {
        return BSP_ERROR;
    }
    if(ulHeadFileCrc != ulCalCrc)
    {
        dbgErr("%s>>Crc Check Failed!, HeadCrc = 0x%x, CalculateCrc = 0x%x!\n",
            __FUNCTION__,ulHeadFileCrc, ulCalCrc);
        return BSP_ERROR;
    }

    /*获取sign hash*/
    pbSignData = (UCHAR*)malloc(4096);
    if(NULL == pbSignData)
    {
        dbgErr("Load file:%s, pbSignData malloc error. %s: %d\n",verName,__FUNCTION__, __LINE__);
        return BSP_ERROR;
    }
    if(BSP_OK !=(ulRet = BspGetVersionSign(acJsonFile,0,ulVerLen,ulVerCrc,pbSignData)) )
    {
        dbgErr("%s>>file:%s Get VerSign failed !\n",__FUNCTION__,verName);
        free(pbSignData);
        pbSignData = NULL;

        return BSP_ERROR;
    }
    BspDecodeB64(pbSignData,ucP1Data,256);

    if(BSP_OK !=(ulRet = BspModuleVersion_Verify((UCHAR *)verName,0,ucP1Data)) )
    {
        dbgErr("%s>>file:%s verify module failed !\n",__FUNCTION__,verName);
    }
    else
    {
        dbgInfo("%s>>file:%s verify module succ !\n",__FUNCTION__,verName);
    }

    free(pbSignData);
    pbSignData = NULL;

    return ulRet;
}

unsigned long BspGetFileSysPackVerInfo(char* pcFileName, UINT32 ulVerIndex, T_PkgVerInfo* ptPkgVerInfo)
{
    INT32  lSnpRet = 0;
    unsigned long ulRet = BSP_OK;
    FILE *pf;
    int iReadLen;
    BYTE* pbyHeaderBuf;
    TSwPackage *ptUnionAddr;
    UINT32 ulUnionHeaderLen;
    UINT32 ulVerOffset;
    UINT32 ulLoop;
    //T_VerFileHeader tVerHeader = {0};
    //T_VerFileHeader *pVerHeader = &tVerHeader;/*coverity 修改，按照旺旺提供的修改方式*/
    /*CHAR acFileName[32] = {0};*/

    INPUT_POINTER_CHECK(pcFileName);
    INPUT_POINTER_CHECK(ptPkgVerInfo);
#if 0
    /*生成文件系统内版本名*/
    if(snprintf_s(acFileName,32,"/ata/rru/%s",pcFileName) < 0)
    {
        dbgErr("%s>>snprintf error [line:%d]\n",__FUNCTION__,__LINE__);
        return BSP_ERROR;
    }
#endif
    ptPkgVerInfo->ulPosition = 2;/*文件系统*/
    /*是否验签*/
    if(1 == g_SecVerifySwitch)
    {
        if(BspCheckSystemVerSafeFunc(pcFileName,ptPkgVerInfo->ulPostRes)!=BSP_OK)
        {
            dbgErr("%s>>file:%s,SecVerifyVer Failed !\n",__FUNCTION__,pcFileName);
            return BSP_ERROR;
        }
    }
    pf = fopen(pcFileName, "rb");

    if(NULL == pf)
    {
        dbgErr("%s>>can't open %s !\n",__FUNCTION__,pcFileName);
        return BSP_ERROR;
    }
    if(fseek(pf, 0 ,SEEK_SET) != 0)
    {
        lSnpRet = fclose(pf);
        FCLOSE_CHECK(lSnpRet);
        dbgErr("%s>>fseek  %s  err !\n",__FUNCTION__,pcFileName);
        return BSP_ERROR;
    }
    pbyHeaderBuf = (BYTE *)malloc(sizeof(T_VerFileHeader) + sizeof(TSwPackage));
    if(NULL == pbyHeaderBuf)
    {
        dbgErr("Load: headerbuf malloc error. %s: %d\n",__FUNCTION__, __LINE__);
        lSnpRet = fclose(pf);
        FCLOSE_CHECK(lSnpRet);
        return BSP_ERROR;
    }
    iReadLen = fread(pbyHeaderBuf, 1, sizeof(T_VerFileHeader) + sizeof(TSwPackage), pf);
    if (iReadLen != sizeof(T_VerFileHeader) + sizeof(TSwPackage))
    {
        free(pbyHeaderBuf);
        pbyHeaderBuf = NULL;
        lSnpRet = fclose(pf);
        FCLOSE_CHECK(lSnpRet);
        dbgErr("fread data to buffer error. %s: %d\n",__FUNCTION__, __LINE__);
        return BSP_ERROR;
    }
    /*设置版本号到高端内存*/
    if (BSP_OK != BspSetModuleSoftVersion((CHAR*)((T_VerFileHeader*)pbyHeaderBuf)->ucVerNo,(UCHAR)VERNO_LEN))
    {
        dbgErr("%s>>BspSetModuleSoftVersionTest failed!\n",__FUNCTION__);
    }
    ptUnionAddr = (TSwPackage*) (pbyHeaderBuf+ sizeof(T_VerFileHeader));
    if(ulVerIndex > (UINT32)(ptUnionAddr->ucSwNum - 1))
    {
        dbgErr("%s>>Max division number of union must be less than %d\n",__FUNCTION__,ptUnionAddr->ucSwNum);
        free(pbyHeaderBuf);
        pbyHeaderBuf = NULL;
        lSnpRet = fclose(pf);
        FCLOSE_CHECK(lSnpRet);
        return UNPRESS_EC_DIV_NUM_ERROR;
    }
    ulUnionHeaderLen = sizeof(unsigned char) + ptUnionAddr->ucSwNum * sizeof(TSwIdInfo);
    ulVerOffset = sizeof(T_VerFileHeader) + ulUnionHeaderLen;

    for(ulLoop = 0;ulLoop < ulVerIndex; ulLoop++)
    {
        ulVerOffset += ntohl(ptUnionAddr->atSwIdInfo[ulLoop].ulSwLen);
    }
    free(pbyHeaderBuf);
    pbyHeaderBuf = NULL;

    if(fseek(pf, ulVerOffset, SEEK_SET) != 0)
    {
        ulRet = BSP_ERROR;
    }
    else
    {
        iReadLen = fread(&(ptPkgVerInfo->tVerHeadInfo), 1, sizeof(T_VerFileHeader), pf);
        if (iReadLen != (int)sizeof(T_VerFileHeader))
        {
            lSnpRet = fclose(pf);
            FCLOSE_CHECK(lSnpRet);
            dbgErr("%s>>Error! VerLen = 0x%zx, ReadLen = 0x%x.\n",__FUNCTION__,sizeof(T_VerFileHeader), iReadLen);
            return BSP_ERROR;
        }
        if(snprintf_s(ptPkgVerInfo->acFileName,32,"%s", pcFileName) < 0)
        {
            lSnpRet = fclose(pf);
            FCLOSE_CHECK(lSnpRet);
            dbgErr("%s>>snprintf error ![line:%d]\n",__FUNCTION__,__LINE__);
            return BSP_ERROR;
        }

        ptPkgVerInfo->tVerHeadInfo.ulCRC32          = ntohl(ptPkgVerInfo->tVerHeadInfo.ulCRC32);
        ptPkgVerInfo->tVerHeadInfo.usVerType        = ntohs(ptPkgVerInfo->tVerHeadInfo.usVerType);
        ptPkgVerInfo->tVerHeadInfo.ulCompressedSize = ntohl(ptPkgVerInfo->tVerHeadInfo.ulCompressedSize);
        ptPkgVerInfo->tVerHeadInfo.ulCompressedCRC  = ntohl(ptPkgVerInfo->tVerHeadInfo.ulCompressedCRC);
        ptPkgVerInfo->tVerHeadInfo.ulOriginalSize   = ntohl(ptPkgVerInfo->tVerHeadInfo.ulOriginalSize);
        ptPkgVerInfo->tVerHeadInfo.ulOriginalCRC    = ntohl(ptPkgVerInfo->tVerHeadInfo.ulOriginalCRC);
        ptPkgVerInfo->tVerHeadInfo.ulSoftType       = ntohl(ptPkgVerInfo->tVerHeadInfo.ulSoftType);
        ptPkgVerInfo->tVerHeadInfo.ulCreateTime     = ntohl(ptPkgVerInfo->tVerHeadInfo.ulCreateTime);

        ptPkgVerInfo->ulVerOffset = ulVerOffset;

        dbgInfo("Ver Offset:0x%0x [position:%d]\n",ptPkgVerInfo->ulVerOffset,ptPkgVerInfo->ulPosition);

        dbgInfo("File CRC:                             0x%x\n", ptPkgVerInfo->tVerHeadInfo.ulCRC32);
        dbgInfo("File VerType:                         0x%x\n", ptPkgVerInfo->tVerHeadInfo.usVerType);
        dbgInfo("File Compressed Size:                 0x%x\n", ptPkgVerInfo->tVerHeadInfo.ulCompressedSize);
        dbgInfo("File Compressed CRC:                  0x%x\n", ptPkgVerInfo->tVerHeadInfo.ulCompressedCRC);
        dbgInfo("File Original Size:                   0x%x\n", ptPkgVerInfo->tVerHeadInfo.ulOriginalSize);
        dbgInfo("File Original CRC:                    0x%x\n", ptPkgVerInfo->tVerHeadInfo.ulOriginalCRC);
        dbgInfo("File Create time:                     %u\n",   ptPkgVerInfo->tVerHeadInfo.ulCreateTime);
    }
    lSnpRet = fclose(pf);
    FCLOSE_CHECK(lSnpRet);
    return ulRet;
}

static UINT32 BspDeleteFile(const char *filename)
{
    if(NULL == filename)
    {
        dbgErr("null pointer err\n");
        return BSP_ERROR_NULL_POINTER;
    }

    if(-1 == remove(filename))
    {
        dbgErr("remove err\n");
        return BSP_ERROR;
    }
    return BSP_OK;
}

static UINT32 BspWriteSwToFile(UINT8 *pucSrcBuf, UINT32 ulBufLen, const char *pucOutName)
{
    FILE *fp = NULL;
    INT32 iWrLen = 0;
    INT32 lSnpRet = 0;
    UINT32 ulRetVal = BSP_OK;
    struct stat fileStat = {0};

    if (NULL == pucSrcBuf)
    {
        dbgErr("%s>>Param Error! SrcBuf is NULL\n", __FUNCTION__);
        return BSP_ERROR;
    }

    if (NULL == pucOutName)
    {
        dbgErr("%s>>Param Error! outputFilePath is NULL\n", __FUNCTION__);
        return BSP_ERROR;
    }
    /*检查是否存在*/
    if ((stat(pucOutName, &fileStat) != -1)&&(BSP_OK != BspDeleteFile(pucOutName)))
    {
        dbgErr("%s>>file %s can't delete !\n",__FUNCTION__,pucOutName);
        return BSP_ERROR;
    }
    fp = fopen(pucOutName, "w+");
    if (fp == NULL)
    {
        dbgErr("%s>>[%s] Open Error!\n", __FUNCTION__, pucOutName);
        return BSP_ERROR;
    }
    iWrLen = fwrite(pucSrcBuf, 1, ulBufLen, fp);
    if (iWrLen != (INT32)ulBufLen)
    {
        lSnpRet = fclose(fp);
        FCLOSE_CHECK(lSnpRet);

        ulRetVal = BspDeleteFile(pucOutName);
        if (BSP_OK != ulRetVal)
        {
            dbgErr("%s>>Fwrite Fail! File Delete Error!\n", __FUNCTION__);
            return BSP_ERROR - 2;
        }
        return BSP_ERROR - 1;
    }

    lSnpRet = fclose(fp);
    FCLOSE_CHECK(lSnpRet);
    return BSP_OK;
}

/*获取版本内容，放到buf or 生成文件*/
UINT32 BspGetVerPackData(T_PkgVerInfo* ptPkgVerInfo,const CHAR* pcOutFileName,BYTE* pbyImgBuf)
{
    unsigned long ulRet = BSP_OK;
    FILE *pf = NULL;
    int iReadLen = 0;
    UINT32 ulDataLen = 0;
    BYTE* pByZipDataBuf = NULL;
    UINT32 ulProZoneAddrOffset = 0;
    INT32  lSnpRet = 0;

    INPUT_POINTER_CHECK(ptPkgVerInfo);

    if((pcOutFileName == NULL)&&(pbyImgBuf ==NULL))
    {
        dbgErr("%s>>OutFileName or  Buffer is null !\n",__FUNCTION__);
        return BSP_ERROR;
    }
    /* others */
    /*保护区版本*/
    if(ptPkgVerInfo->ulPosition == 1)
    {
        ulProZoneAddrOffset = BspGetVerProtectAddr();//BspGetVerProtectAddr();   /*拿到保护区偏移地址*/
        ulDataLen = ptPkgVerInfo->tVerHeadInfo.ulCompressedSize + sizeof(T_VerFileHeader);
        pByZipDataBuf = (BYTE*)malloc(ulDataLen);
        if(NULL == pByZipDataBuf)
        {
            dbgErr("%s>>malloc failed [line:%d]!\n",__FUNCTION__,__LINE__);
            return BSP_ERROR;
        }
        ulRet = BspFlashRead(ulProZoneAddrOffset + ptPkgVerInfo->ulVerOffset, pByZipDataBuf, ulDataLen);
        if (BSP_OK != ulRet)
        {
            dbgErr("%s>>FlashRead Error! VerLen = 0x%x, ReadLen = 0x%lx.\n",__FUNCTION__,ulDataLen,ulRet);
            free(pByZipDataBuf);
            return BSP_ERROR;
        }
    }
    /*文件系统版本*/
    else if((ptPkgVerInfo->ulPosition == 2)&&(zte_strnlen_s(ptPkgVerInfo->acFileName,32) != 0))
    {
        pf = fopen(ptPkgVerInfo->acFileName, "rb");
        if(NULL == pf)
        {
            dbgErr("%s open file %s error!\n",__FUNCTION__,ptPkgVerInfo->acFileName);
            return BSP_ERROR;
        }

        if(fseek(pf, ptPkgVerInfo->ulVerOffset ,SEEK_SET) != 0)
        {
            lSnpRet = fclose(pf);
            FCLOSE_CHECK(lSnpRet);
            return BSP_ERROR;
        }

        ulDataLen = ptPkgVerInfo->tVerHeadInfo.ulCompressedSize + sizeof(T_VerFileHeader);
        pByZipDataBuf = (BYTE*)malloc(ulDataLen);
        if(NULL == pByZipDataBuf)
        {
            dbgErr("%s>>malloc failed [line:%d]!\n",__FUNCTION__,__LINE__);
            lSnpRet = fclose(pf);
            FCLOSE_CHECK(lSnpRet);
            return BSP_ERROR;
        }

        iReadLen = fread((VOID *)pByZipDataBuf, 1, ulDataLen, pf);
        lSnpRet = fclose(pf);
        FCLOSE_CHECK(lSnpRet);
        if (iReadLen != (int)ulDataLen)
        {
           dbgErr("%s>>File Read Error! VerLen = 0x%x, ReadLen = 0x%x.\n",
                  __FUNCTION__, ulDataLen, iReadLen);
           free(pByZipDataBuf);
           return BSP_ERROR;
        }
    }
    else
    {
        dbgErr("%s>>can't understand what are you doing [position:%d]!\n",__FUNCTION__,ptPkgVerInfo->ulPosition);
        return BSP_ERROR;
    }

    if(pbyImgBuf != NULL)/*解压缩放到内存*/
    {
        ulRet = NewUnpress(pByZipDataBuf, ulDataLen, pbyImgBuf);
        free(pByZipDataBuf);
        pByZipDataBuf = NULL;
        if (UNPRESS_OK != ulRet)
        {
            dbgErr("%s>>Uncompress Version Image data Wrong!\n",__FUNCTION__);
            return BSP_ERROR;
        }
    }

    if(pcOutFileName != NULL)/*生成解压缩版本到文件*/
    {
        ulRet = BspWriteSwToFile(pbyImgBuf, ptPkgVerInfo->tVerHeadInfo.ulOriginalSize, pcOutFileName);
        if (ulRet != BSP_OK)
        {
            dbgErr("%s>>%s write original ver to %s Error!\n", __FUNCTION__,\
                (ptPkgVerInfo->acFileName != NULL)?(ptPkgVerInfo->acFileName):("unknown"),pcOutFileName);
            free(pByZipDataBuf);
            pByZipDataBuf = NULL;
            return BSP_ERROR;
        }
    }
    return BSP_OK;
}

#endif
char* strncpyex(char *dest, const char *src, int len)
{
    char* p;
    memset(dest, 0, len);
    p = strncpy(dest, src, len-1);
    return p;
}
#define PID_NAME_MAX_NUM    10
#define STR_ARR_CPY(a,b)        strncpyex(a,b,sizeof(a))

static CHAR* BspGetNumFromStr(CHAR *pachStr,INT32 wIndex)
{
    CHAR seps[]  = " ";
    CHAR *token  = NULL;
    CHAR *holder = NULL;  /* points to initString fragment beyond tok */
    int wLoop=0;
    static CHAR aucBufVar[128] = {0};

    INPUT_POINTER_CHECK_RETURN_NULL(pachStr);
    STR_ARR_CPY(aucBufVar,pachStr);

    while(  1  )
    {
        /* While there are tokens in "string" */
        /* Get next token: */
        if( 0 == wLoop )
        {
            token = strtok_r (aucBufVar, seps, &holder);
        }
        else
        {
            token = strtok_r (NULL, seps, &holder);
        }
        if (NULL == token)
        {
            /* 不满足要求 需要立即退出 */
            return token;
        }
        if( wLoop == wIndex )
        {
            /* dbgInfo( " %s\n", token ); */
            return token;
        }
        wLoop++;
    }
}

UINT32 BspGetProcPidsByName(UCHAR *pucPathProcName, UINT32 *pulProcPidNo,UINT32 ulPidNum)
{
    UINT32 ulRetVal = BSP_OK;
    UINT32 ulCnt  = 0;
    CHAR   acGetBuf[64] = " ";
    CHAR   acCmdBuf[64] = " ";
    CHAR  *pucRetHandle = NULL;
    CHAR   *pcPidNum = NULL;
    FILE   *pFileHandle = NULL;
    INT32  lSnpRet = 0;

    if ((NULL == pucPathProcName)||(NULL == pulProcPidNo))
    {
        ulRetVal |= BIT_SET(0);
        dbgErr("%s>>Error! PathProcName or ProcPidNo is NULL !\n", __FUNCTION__);
        return ulRetVal;
    }

    lSnpRet = snprintf_s(acCmdBuf, sizeof(acCmdBuf), "pidof %s", pucPathProcName);
    SNPRINTF_S_CHECK(lSnpRet, sizeof(acCmdBuf));

    pFileHandle = popen(acCmdBuf, "r");
    if (NULL == pFileHandle)
    {
        ulRetVal |= BIT_SET(1);
        dbgErr("%s>>%s Open Error!\n", __FUNCTION__, acCmdBuf);
        return ulRetVal;
    }
    sleep(2);
    pucRetHandle = fgets(acGetBuf, sizeof(acGetBuf) - 2, pFileHandle);
    if (NULL == pucRetHandle)
    {
        dbgErr("%s>> Fgets Char Error!\n", __FUNCTION__);
        pclose(pFileHandle);
        return BSP_ERROR;
    }
    pclose(pFileHandle);
    for(ulCnt = 0;ulCnt < min(ulPidNum,PID_NAME_MAX_NUM);ulCnt++)
    {
        pcPidNum = BspGetNumFromStr(pucRetHandle,ulCnt);
        if(pcPidNum != NULL)
        {
            *(pulProcPidNo+ulCnt) = (int)strtol(pcPidNum, (char **)NULL, 10);
        }
    }
    return ulRetVal;
}

UINT32 LoadMgrBin(VOID)
{
    UINT32 aulProcPidNo[PID_NAME_MAX_NUM] = {0};
    UINT32 ulCnt = 0;
    UINT32 ulRetVal = BSP_OK;
    UINT32 ulTmpRet = BSP_OK;
    CHAR  aucProcName[64] = {0};
    UCHAR ucFileName[] = "MGR.EXE";
    int ret = 0;

    /*先kill掉之前的MGR*/
    if (BSP_OK == BspGetProcPidsByName(ucFileName, aulProcPidNo,3))
    {
        for(ulCnt = 0;ulCnt < 3;ulCnt++)
        {
            if(aulProcPidNo[ulCnt] != 0)
            {
                ulRetVal |= kill(aulProcPidNo[ulCnt], SIGKILL);
            }
        }
    }
    if(ulRetVal != BSP_OK)
    {
        dbgErr("%s>> kill old MGR.EXE failed !\n",__FUNCTION__);
        return BSP_ERROR;/*待确认是否需要返回*/
    }
    ret = chmod("/MGR.EXE", S_IRWXU|S_IRGRP|S_IXGRP|S_IROTH|S_IXOTH);
    if (ret != 0)
    {
        dbgErr("%s>>chmod error, ret:%d\n", __FUNCTION__, ret);
        return BSP_ERROR;
    }
    ulTmpRet=snprintf_s(aucProcName, sizeof(aucProcName), "/%s &", "MGR.EXE");
    if(ulTmpRet != strnlen_s(aucProcName,sizeof(aucProcName)))
    {
        dbgErr("%s>>/MGR.EXE snprintf_s error!!\n", __FUNCTION__);
        return BSP_ERROR;
    }
    ulRetVal = (UINT32)system(aucProcName);

    dbgInfo("%s>>PathNameCmdBuf: [%s]\n", __FUNCTION__, aucProcName);

    return ulRetVal;
}
/* Started by AICoder, pid:v701dpee93z566f1467c0a39a05b612981335eac */
static unsigned long UnpackOemFile(char *pcFileName, T_PkgVerInfo *pkgVerInfo)
{
    T_PkgVerInfo tPkgVerInfo = {0};
    UINT32 ulVerIndex = 1;
    unsigned long ulRet = BSP_OK;
    int ret = 0;
    BYTE *ptImgBuf = NULL;
    const char *acFileName = "/oemfile.tar.bz2";
    char * const argv[4] = {"tar", "-jxvf", "/oemfile.tar.bz2", NULL};
    rsize_t argc = 4;
    char * const pathlist[1] = {"/bin/tar"};
    rsize_t pathlist_size = 1;

    INPUT_POINTER_CHECK(pkgVerInfo);
    memcpy_s(&tPkgVerInfo, sizeof(T_PkgVerInfo), pkgVerInfo, sizeof(T_PkgVerInfo));
    if(pcFileName == NULL)
    {
        ulRet = BspGetProtectFileInfo(3, ulVerIndex, &tPkgVerInfo);
    }
    else
    {
        ulRet = BspGetFileSysPackVerInfo(pcFileName, ulVerIndex, &tPkgVerInfo);
        if((1 == tPkgVerInfo.ulPostRes) && (BSP_OK != ulRet))
        {
            tPkgVerInfo.ulPostRes = 0;
            ulRet = BspGetFileSysPackVerInfo(pcFileName, ulVerIndex,&tPkgVerInfo);
        }
    }
    /* 非IC4.2机型此处返回失败,是正常现象,函数返回成功 */
    if(ulRet != BSP_OK)
    {
        dbgErr("%s>>Get ulVerIndex:%u PackVerInfo failed ![Ret %lx]\n",__FUNCTION__, ulVerIndex, ulRet);
        return BSP_OK;
    }
    if (tPkgVerInfo.tVerHeadInfo.ulOriginalSize == 0)
    {
        dbgErr("%s>>tPkgVerInfo.tVerHeadInfo.ulOriginalSize is equal 0!\n",__FUNCTION__);
        return BSP_ERROR;
    }
    if (tPkgVerInfo.tVerHeadInfo.ulOriginalSize > SIZE_256M)
    {
        dbgErr("%s>>tPkgVerInfo.tVerHeadInfo.ulOriginalSize is over SIZE_256M!\n",__FUNCTION__);
        return BSP_ERROR;
    }
    if (tPkgVerInfo.tVerHeadInfo.ulCompressedSize > SIZE_64M)
    {
        dbgErr("%s>>tPkgVerInfo.tVerHeadInfo.ulOriginalSize is over SIZE_256M!\n",__FUNCTION__);
        return BSP_ERROR;
    }
    ptImgBuf = (BYTE*)malloc(tPkgVerInfo.tVerHeadInfo.ulOriginalSize);
    if(NULL == ptImgBuf)
    {
        dbgErr("%s>>malloc failed [line:%d]!\n",__FUNCTION__,__LINE__);
        return BSP_ERROR;
    }
    if(BSP_OK!=(ulRet = BspGetVerPackData(&tPkgVerInfo,acFileName,ptImgBuf)))
    {
        dbgErr("%s>>Get PackVerData failed ![Ret %lx]\n",__FUNCTION__,ulRet);
        free(ptImgBuf);
        return BSP_ERROR;
    }
    free(ptImgBuf);

    ret = zte_system_s("/bin/tar", argv, argc, pathlist, pathlist_size);
    if (ret != 0)
    {
        dbgErr("%s>>tar -jxvf %s failed[ret %x]\n",__FUNCTION__, acFileName, ret);
        return BSP_ERROR;
    }

    // 删除临时文件
    remove(acFileName);
    return BSP_OK;
}
/* Ended by AICoder, pid:v701dpee93z566f1467c0a39a05b612981335eac */

/* Started by AICoder, pid:l89f8798bdq1eb714e590b49d090115ffcf32c0a */
UINT32 BspGetSysFileHeaderInfo(INT8 *ulBuf, T_VerFileHeader *ptFileHeader)
{
    UINT32  ulRet               = BSP_OK;
    INT32   lRet                = 0;
    INT32   lReadLen            = 0;
    UINT32   lSize               = 1;
    UINT32   lLenth              = 128;//sizeof(T_VerFileHeader)
    T_VerFileHeader tFileHeader = {0};

    INPUT_POINTER_CHECK(ulBuf);
    INPUT_POINTER_CHECK(ptFileHeader);

    FILE *pf = NULL;
    (VOID)fopen_s(&pf, (char const *)ulBuf, "rb");
    if(NULL == pf)
    {
        dbgErr("%s>>can't open %s !\n",__FUNCTION__,ulBuf);
        return BSP_ERROR;
    }
    if(fseek(pf, 0 ,SEEK_SET) != 0)
    {
        lRet = fclose(pf);
        FCLOSE_CHECK(lRet);
        return BSP_ERROR;
    }
    lReadLen = fread(&tFileHeader, lSize, lLenth, pf);
    if (lReadLen != (int)sizeof(T_VerFileHeader))
    {
        dbgErr("%s>>Error! VerLen = 0x%zx, ReadLen = 0x%x.\n",__FUNCTION__,sizeof(T_VerFileHeader), lReadLen);
        lRet = fclose(pf);
        FCLOSE_CHECK(lRet);
        return BSP_ERROR;
    }
    lRet = fclose(pf);
    FCLOSE_CHECK(lRet);

    ptFileHeader->ulCRC32            = ntohl(tFileHeader.ulCRC32);
    ptFileHeader->ulHeaderVersion    = ntohl(tFileHeader.ulHeaderVersion);
    ptFileHeader->usVerType          = ntohs(tFileHeader.usVerType);
    ptFileHeader->ucCpuType          = tFileHeader.ucCpuType;  
    ptFileHeader->ucReserved0        = tFileHeader.ucReserved0;          
    ptFileHeader->ulCompressedSize   = ntohl(tFileHeader.ulCompressedSize);
    ptFileHeader->ulCompressedCRC    = ntohl(tFileHeader.ulCompressedCRC);
    ptFileHeader->ulOriginalSize     = ntohl(tFileHeader.ulOriginalSize);
    ptFileHeader->ulOriginalCRC      = ntohl(tFileHeader.ulOriginalCRC);
    ptFileHeader->ulSoftType         = ntohl(tFileHeader.ulSoftType);    
    ptFileHeader->ulCreateTime       = ntohl(tFileHeader.ulCreateTime);
    ptFileHeader->ucPackedFile       = tFileHeader.ucPackedFile;
    ptFileHeader->ucPackedFileNum    = tFileHeader.ucPackedFileNum;
    memcpy_s(ptFileHeader->ucVerNo,VERNO_LEN,&tFileHeader.ucVerNo,VERNO_LEN);

    return ulRet;
}

UINT32 BspCheckSysFileCrc(CHAR* acFileName)
{
    UINT32 ulHeadFileCrc = 0;
    UINT32 ulCalCrc = 0;
    T_VerFileHeader ptFileHeader = {0};

    INPUT_POINTER_CHECK(acFileName);

    if(BSP_OK != BspGetFileHeaderInfo(acFileName,(T_VerFileHeader *)(&ptFileHeader)))
    {
        dbgErr("%s>>File: %s is not exit!!!\n", __FUNCTION__, acFileName);
        return BSP_ERROR;
    }
    ulHeadFileCrc = ptFileHeader.ulCRC32;

    /* 此处Crc计算不包含版本头的Crc字段 */
    if(BSP_OK != BspCalculateFileCrc(acFileName, &ulCalCrc))
    {
        dbgErr("%s>>File: %s Calc File Crc!!!\n", __FUNCTION__, acFileName);
        return BSP_ERROR;
    }

    if(ulHeadFileCrc != ulCalCrc)
    {
        dbgErr("%s>>Crc Check Failed!, HeadCrc = 0x%x, CalculateCrc = 0x%x!\n", 
            __FUNCTION__, ulHeadFileCrc, ulCalCrc);
        return BSP_ERROR;
    }

    dbgInfo("[%s]Check %s Crc ok, Crc = 0x%x!\n", __FUNCTION__, acFileName, ulCalCrc);
    return BSP_OK;
}

BOOL BspCheckXmlFileExist(VOID)
{
    INT32 iTmpRet = 0;
    FILE *pFile = NULL;

    (VOID)fopen_s(&pFile, CONNECT_XML_FILE_PATH, "r");
    if(NULL != pFile)
    {
        iTmpRet = fclose(pFile);
        FCLOSE_CHECK(iTmpRet);
        dbgInfo("%s>>The File %s Exists!\n",__FUNCTION__,CONNECT_XML_FILE_PATH);
        return TRUE;
    }

    dbgInfo("%s>>The File %s not Exists!\n",__FUNCTION__,CONNECT_XML_FILE_PATH);
    return FALSE;
}

UINT32 BspGetConnectVerPara(UINT32 softType, T_CONNECT_XMLLIST_PARA* connectVerPara)
{
    xmlite_t xml ,root, coreXml;
    INT32  xmlSoftType = 0;
    const char* attr_tmp = NULL;

    INPUT_POINTER_CHECK(connectVerPara);

    do
    {
        if(NULL == (xml = xmlite_parse_file(CONNECT_XML_FILE_PATH)))
        {
            dbgErr("%s>>xmlite_parse_file failed !\n",__FUNCTION__);
            return BSP_VER_EXIST_ERROR;
        }
        root = xml;
        while (root && root->parent)
        {
            root = root->parent;
        }
        for (coreXml = xmlite_child(root,"SubVerInfo"); coreXml != NULL; coreXml = coreXml->next)
        {
            attr_tmp = xmlite_attr(coreXml, "SoftType");
            if(NULL != attr_tmp)
            {
                xmlSoftType = atoi(attr_tmp);
                if(xmlSoftType == softType)/*find ,break*/
                {
                      connectVerPara->softType = xmlSoftType;
                      break;
                }
            }
        }
        if(coreXml == NULL)
        {
            dbgInfo("%s>>can't find SoftType %d !\n",__FUNCTION__,softType);
            xmlite_free(xml);
            return BSP_VER_EXIST_ERROR;
        }
        if(NULL != xmlite_attr(coreXml,"FileName"))
        {
            strncpy_s(connectVerPara->acFileName,FILE_NAME_LENGTH,xmlite_attr(coreXml,"FileName"),FILE_NAME_LENGTH);
        }
        attr_tmp = xmlite_attr(coreXml, "LinkNecessity");
        if(NULL != attr_tmp)
        {
            connectVerPara->linkNecessity = atoi(attr_tmp);
        }

    }while(0);
    xmlite_free(xml);

    return BSP_OK;
}

UINT32 BspGetConnectVerList(UINT32* pConnectVerList, UINT32* pConnectVerNum)
{
    INPUT_POINTER_CHECK(pConnectVerList);
    INPUT_POINTER_CHECK(pConnectVerNum);

    UINT32 softType = 0;
    UINT32 connectVerNum = 0;
    T_CONNECT_XMLLIST_PARA connectVerPara = {0};

    for(softType = 0; softType < MAX_SOFTTYPE_NUM; softType++)
    {
        if(BSP_OK == BspGetConnectVerPara(softType, &connectVerPara))
        {
            pConnectVerList[connectVerNum] = softType;
            connectVerNum++;
        }
    }

    *pConnectVerNum = connectVerNum;
    return BSP_OK;
}

VOID BspCheckSysConnectVer(VOID)
{
    UINT32 ret = BSP_OK;
    UINT32 loop = 0;
    UINT32 connectVerNum = 0;
    UINT32 connectVerList[MAX_SOFTTYPE_NUM] = {0};
    INT32  iTmpRet = 0;
    INT32  snprtRet = 0;
    CHAR   acFileName[FILE_NAME_LENGTH];
    FILE *pFile = NULL;

    for(loop = 0; loop < MAX_SOFTTYPE_NUM; loop++)
    {
        connectVerList[loop] = 0xff;
    }

    if(FALSE == BspCheckXmlFileExist())
    {
        dbgInfo("[%s]file %s is not exit, do not need check\n", __FUNCTION__, CONNECT_XML_FILE_PATH);
        return;
    }
    
    ret = BspGetConnectVerList(connectVerList, &connectVerNum);
    if((BSP_OK == ret) && (0 != connectVerNum))
    {
        dbgInfo("[%s]connectVerNum = %d\n", __FUNCTION__, connectVerNum);
        for(loop = 0; loop < connectVerNum; loop++)
        {
            snprtRet = snprintf_s(acFileName,sizeof(acFileName), "/ata/rru/cur%d.swv", connectVerList[loop]);
            SNPRINTF_S_CHECK(snprtRet, sizeof(acFileName));
            ret = BspCheckSysFileCrc(acFileName);
            if(BSP_OK != ret)
            {
                dbgErr("[%s]BspCheckSysFileCrc failed, acFileName = %s\n", __FUNCTION__, acFileName);
                (VOID)fopen_s(&pFile, LOAD_PROTECT_CONNECT_VER_FLAG, "w");
                if(NULL != pFile)
                {
                    iTmpRet = fclose(pFile);
                    FCLOSE_CHECK(iTmpRet);
                }
                return;
            }
        }
    }

    return;
}

BOOL BspCheckProIniFileExist(VOID)
{
    INT32 iTmpRet = 0;
    FILE *pFile = NULL;

    (VOID)fopen_s(&pFile, LOAD_PROTECT_CONNECT_VER_FLAG, "r");
    if(NULL != pFile)
    {
        iTmpRet = fclose(pFile);
        FCLOSE_CHECK(iTmpRet);
        dbgInfo("%s>>The File %s Exists!\n",__FUNCTION__,LOAD_PROTECT_CONNECT_VER_FLAG);
        return TRUE;
    }

    dbgInfo("%s>>The File %s not Exists!\n",__FUNCTION__,LOAD_PROTECT_CONNECT_VER_FLAG);
    return FALSE;
}

VOID BspChangeFileName(UINT32 ulVerType, char **ppcFileName)
{
    if(NULL == ppcFileName)
    {
        return;
    }

    if((MGR_VER_MASTER == ulVerType) && (TRUE == BspCheckProIniFileExist()))
    {
        dbgInfo("%s:Load Version From Protect !\n", __FUNCTION__);
        *ppcFileName = NULL;
    }

    return;
}
/* Ended by AICoder, pid:l89f8798bdq1eb714e590b49d090115ffcf32c0a */

/* Started by AICoder, pid:vf506x5fb116fa2146de0a0ae07a8e1680c88bfb */
BOOL BspCheckDataSize(T_PkgVerInfo* tPkgVerInfo)
{
    INPUT_POINTER_CHECK(tPkgVerInfo);

    if((tPkgVerInfo->tVerHeadInfo.ulOriginalSize == 0) || (tPkgVerInfo->tVerHeadInfo.ulOriginalSize >= SIZE_256M))
    {
        return FALSE;
    }

    return TRUE;
}
/* Ended by AICoder, pid:vf506x5fb116fa2146de0a0ae07a8e1680c88bfb */

static unsigned long BspLoadMgrVer(UINT32 ulVerType)
{
    unsigned long ulRet = BSP_OK;
    CHAR cMgrFileName[4][32]={"/ata/rru/cur3.swv","/ata/rru/tmp3.swv","/cur14.swv", "/ata/BSP/cur3.swv"};
    CHAR *pcFileName = NULL;
    T_PkgVerInfo tPkgVerInfo = {0};
    UINT32 ulVerIndex = 0;
    BYTE *ptImgBuf = NULL;
    CHAR acFileName[] = "/MGR.EXE";
    ULONG begin = 0;

    switch (ulVerType)
    {
        case MGR_VER_MASTER:
            pcFileName = cMgrFileName[0];
            tPkgVerInfo.ulPostRes = 0;
            break;
        case MGR_VER_TEMP:
            pcFileName = cMgrFileName[1];
            tPkgVerInfo.ulPostRes = 1;
            break;
       case MGR_VER_SOC:
            pcFileName = cMgrFileName[2];
            tPkgVerInfo.ulPostRes = 0;
            break;
       case MGR_VER_WFS:
            dbgInfo("%s>>FT Mode!!\n", __FUNCTION__);
            pcFileName = cMgrFileName[3];
            tPkgVerInfo.ulPostRes = 0;
            break;
        default:
            pcFileName = NULL;
            break;
    }
    dbgInfo("%s>>MGR Load from %s\n", __FUNCTION__, (pcFileName==NULL)?"protect zone":pcFileName);
    begin = tickGet();
    ulRet = UnpackOemFile(pcFileName, &tPkgVerInfo);
    if (ulRet != BSP_OK)
    {
        return BSP_ERROR;
    }
    if(pcFileName == NULL)
    {
        ulRet = BspGetProtectFileInfo(3, ulVerIndex,&tPkgVerInfo);
    }
    else
    {
        ulRet = BspGetFileSysPackVerInfo(pcFileName, ulVerIndex,&tPkgVerInfo);
        if((1 == tPkgVerInfo.ulPostRes) && (BSP_OK != ulRet))
        {
            tPkgVerInfo.ulPostRes = 0;
            ulRet = BspGetFileSysPackVerInfo(pcFileName, ulVerIndex,&tPkgVerInfo);
        }
    }
    dbgInfo("%s>>decompression file %u ms\n", __FUNCTION__, (tickGet() - begin) * 10);
    if(ulRet !=BSP_OK)
    {
        dbgErr("%s>>Get %s PackVerInfo failed ![Ret %lx]\n",__FUNCTION__,pcFileName,ulRet);
        return BSP_ERROR;
    }
    if(!BspCheckDataSize(&tPkgVerInfo))
    {
        dbgErr("%s>>tPkgVerInfo.tVerHeadInfo.ulOriginalSize is equal %d!\n", __FUNCTION__, tPkgVerInfo.tVerHeadInfo.ulOriginalSize);
        return BSP_ERROR;
    }
    dbgInfo("%s:version<%s>\n", __FUNCTION__, tPkgVerInfo.tVerHeadInfo.ucVerNo);
    ptImgBuf = (BYTE*)malloc(tPkgVerInfo.tVerHeadInfo.ulOriginalSize);
    if(NULL == ptImgBuf)
    {
        dbgErr("%s>>malloc failed [line:%d]!\n",__FUNCTION__,__LINE__);
        return BSP_ERROR;
    }
    if(BSP_OK!=(ulRet = BspGetVerPackData(&tPkgVerInfo,acFileName,ptImgBuf)))
    {
        dbgErr("%s>>Get PackVerData failed ![Ret %lx]\n",__FUNCTION__,ulRet);
        free(ptImgBuf);
        ptImgBuf = NULL;
        return BSP_ERROR;
    }
    free(ptImgBuf);
    ptImgBuf = NULL;

    ulRet = LoadMgrBin();

    return ulRet;
}

VOID BspChangeSysVerLoadRet(unsigned long* pRet)
{
    if(NULL == pRet)
    {
        return;
    }

    if(TRUE == BspCheckProIniFileExist())
    {
        dbgInfo("%s:Load Version cur3.swv From Protect !\n", __FUNCTION__);
        *pRet = BSP_ERROR;
    }

    return;
}

UINT32 BspLoadMgrProcess(VOID)
{
    unsigned long ulRet = BSP_OK;
    INT32 iLoadMgrType = 0;
    T_CtrlVerErrReason tVerErrReason;
    CHAR acFileName[] = "/ata/RRUCFG.INI";

    /*对MGR版本加载错误记录清零,保留激活版本回退的错误码*/
    memset((UCHAR *)&tVerErrReason, 0, sizeof(T_CtrlVerErrReason));
    if (BSP_OK == BspGetMgrVerErrReason(&tVerErrReason))
    {
        BspClrMgrVerErrReason();
        if ((tVerErrReason.ucRunVer == BSP_ACK_VERSION) && (tVerErrReason.ucAckVerErr != 0))
        {
            dbgInfo("%s>>\33[5m\33[1m\33[31mAck ver Error flag not 0!\n\33[0m", __FUNCTION__);
            BspSetMgrVerErrReason(BSP_ACK_VERSION, tVerErrReason.ucAckVerErr);
        }
    }
    else
    {
        BspClrMgrVerErrReason();
    }

    iLoadMgrType = BspGetMgrLoadFlag();
    if (BSP_ERROR == iLoadMgrType) /* RruIni文件异常 */
    {
        dbgInfo("%s>>\33[5m\33[1m\33[31mRRUCFG.INI FILE WRONG\n\33[0m", __FUNCTION__);
        BspSetMgrVerErrReason(BSP_RUN_VERSION, 0);
        ulRet = BspLoadMgrVer(MGR_VER_MASTER);/*to do:加载MGR master版本*/
        BspChangeSysVerLoadRet(&ulRet);
        if (BSP_OK == ulRet)
        {
            return BSP_OK;
        }
        else
        {
            BspSetMgrVerErrReason(BSP_RUN_VERSION, ulRet);
            //fpgaloadLog(LOAD_ERR, "%s,rrucfgini[err],cpu[cur]fpga[cur]:failed\n", __FUNCTION__);
        }
        /* 加载失败加载保护区版本 */
        ulRet = BspLoadMgrVer(MGR_VER_PROTECT);/*to do:加载MGR 保护区版本*/
         if (BSP_OK != ulRet)
        {
            BspSetMgrVerErrReason(BSP_PROVERSION, ulRet);
            dbgInfo("%s>>Load Protect Zone MGR Version Failed!!\n", __FUNCTION__);
            //fpgaloadLog(LOAD_ERR, "%s,rrucfgini[err],cpu[null]fpga[pro]:failed\n", __FUNCTION__);
            return (BSP_LOAD_PROC_VER_ERROR|ulRet |0x100);
        }
        dbgInfo("%s>>RruIni Error; Load Protect Zone MGR Version succeed!\n", __FUNCTION__);
        BspSetMgrVerErrReason(BSP_PROVERSION, 0);
    }
    else
    {
        if (BSP_OK != BspReadRuCfgIniFieldValue(strCfgFileName, FLAG_MGRVER, &g_tMgrCfgInfo))
        {
            dbgInfo("%s>>Get Ini File Failed When Load New Platform MGR Version\n", __FUNCTION__);
            //fpgaloadLog(LOAD_ERR, "%s,rrucfgini[ok],readcfg[fpgaver]:failed\n", __FUNCTION__);
            return BSP_LOAD_FLAG_READ_ERROR;
        }
        dbgInfo("%s>>The MGR_VER_FLAG in RRUCFG.INI is %c\n", __FUNCTION__, g_tMgrCfgInfo.cFieldValue);
        if (NORMAL_BOOT == g_tMgrCfgInfo.cFieldValue)	/*直接加载主用版本*/
        {
            BspSetMgrVerErrReason(BSP_RUN_VERSION, 0);
            ulRet = BspLoadMgrVer(MGR_VER_MASTER);/*to do:加载MGR 主分支版本*/
            BspChangeSysVerLoadRet(&ulRet);
            if (BSP_OK != ulRet)
            {
                BspSetMgrVerErrReason(BSP_RUN_VERSION, ulRet);
                BspSetMgrVerErrReason(BSP_PROVERSION,0);
                dbgInfo("%s>>BootNormal; Load Main New Platform MGR version Failed\n", __FUNCTION__);
                 ulRet = BspLoadMgrVer(MGR_VER_PROTECT);/*to do:加载MGR 保护区版本*/
                if (BSP_OK != ulRet)
                {
                    BspSetMgrVerErrReason(BSP_PROVERSION,ulRet);
                    dbgInfo("%s>>BootNormal; Load Protect Zone MGR Version Failed!!\n", __FUNCTION__);
                    //fpgaloadLog(LOAD_ERR, "%s,rrucfgini[ok],flag[new]fBoot[nor]fpga[pro]:failed\n", __FUNCTION__);
                    return (BSP_LOAD_PROC_VER_ERROR|ulRet|0x200);
                }
            }
        }
        else if (ACTIVE_BOOT == g_tMgrCfgInfo.cFieldValue) /*加载备用版本，UPDATE文件*/
        {
            if (BSP_OK != BspUpdateRuCfgIniFieldValue(acFileName, &g_tMgrCfgInfo))
            {
                dbgInfo("%s>>Update Ini File Failed When Load Backup New Platform MGR version\n", __FUNCTION__);
                //fpgaloadLog(LOAD_ERR, "%s,rrucfgini[ok],flag[new]fBoot[act]cBoot[ok]updatecfg:failed\n", __FUNCTION__);
                return (BSP_LOAD_FLAG_UPDATE_ERROR |0x0);
            }
            BspSetMgrVerErrReason(BSP_ACK_VERSION, 0);/*to do:加载MGR 升级版本*/
            ulRet = BspLoadMgrVer(MGR_VER_TEMP);
            if (BSP_OK != ulRet)
            {
                BspSetMgrVerErrReason(BSP_ACK_VERSION, ulRet);
                dbgInfo("%s>>Load Backup New Platform MGR version Failed\n", __FUNCTION__);
                //fpgaloadLog(LOAD_ERR, "%s,rrucfgini[ok],flag[new]fBoot[act]fpga[tmp]:failed\n", __FUNCTION__);
                //return (BSP_LOAD_ACK_VER_ERROR | ulRet);
			    //升级失败，发起复位
                system("reboot 7"); //单板复位类型：BSP_LOCAL_SOFTEXCP_RESET
            }

        }
        else if (UPGRADE_BOOT == g_tMgrCfgInfo.cFieldValue) /*加载主用版本,UPDATE文件*/
        {
            if (BSP_OK != BspUpdateRuCfgIniFieldValue(acFileName, &g_tMgrCfgInfo))
            {
                dbgInfo("%s>>Update Ini File Failed When Load Main New Platform MGR version\n", __FUNCTION__);
                //fpgaloadLog(LOAD_ERR, "%s,rrucfgini[ok],flag[new]fBoot[up]updatecfg:failed\n", __FUNCTION__);
                return (BSP_LOAD_FLAG_UPDATE_ERROR |0x1);
            }
            BspSetMgrVerErrReason(BSP_RUN_VERSION, 0);
            ulRet = BspLoadMgrVer(MGR_VER_MASTER);/*to do:加载MGR 主用版本*/
            if (BSP_OK != ulRet)
            {
                BspSetMgrVerErrReason(BSP_RUN_VERSION, ulRet);
                BspSetMgrVerErrReason(BSP_PROVERSION, 0);
                dbgInfo("%s>>BootUpGrade; Load Main New Platform MGR version Failed\n", __FUNCTION__);
                ulRet= BspLoadMgrVer(MGR_VER_PROTECT);/*to do:加载MGR 保护区版本*/
                if (BSP_OK != ulRet)
                {
                    BspSetMgrVerErrReason(BSP_PROVERSION, ulRet);
                    dbgInfo("%s>>BootUpGrade; Load Protect Zone MGR Version Failed!!\n", __FUNCTION__);
                    //fpgaloadLog(LOAD_ERR, "%s,rrucfgini[ok],flag[new]fBoot[up]fpga[pro]:failed\n", __FUNCTION__);
                    return (BSP_LOAD_PROC_VER_ERROR |ulRet|0x300);
                }
            }
        }
        else if (FAILURE_BOOT == g_tMgrCfgInfo.cFieldValue) /*加载备用版本*/
        {
            BspSetMgrVerErrReason(BSP_RUN_VERSION, 0);
            ulRet = BspLoadMgrVer(MGR_VER_MASTER);/*to do:加载MGR 主用版本*/
            if (BSP_OK != ulRet)
            {
                BspSetMgrVerErrReason(BSP_RUN_VERSION, ulRet);
                BspSetMgrVerErrReason(BSP_PROVERSION, 0);
                dbgInfo("%s>>BootFailure; Load Main New Platform MGR version Failed\n", __FUNCTION__);
                ulRet = BspLoadMgrVer(MGR_VER_PROTECT);/*to do:加载MGR 保护区版本*/
                if (BSP_OK != ulRet)
                {
                    BspSetMgrVerErrReason(BSP_PROVERSION, ulRet);
                    dbgInfo("%s>>BootFailure; Load Protect Zone MGR Version Failed!!\n", __FUNCTION__);
                    //fpgaloadLog(LOAD_ERR, "%s,rrucfgini[ok],flag[new]fBoot[fail]fpga[pro]:failed\n", __FUNCTION__);
                    return (BSP_LOAD_PROC_VER_ERROR|ulRet|0x400);
                }
            }
        }
        else
        {
            dbgInfo("%s>>RRUCFG.INI file wrong\n", __FUNCTION__);
            dbgInfo("%s>>MGR_VER_FLAG have wrong number!!\n", __FUNCTION__);
            BspSetMgrVerErrReason(BSP_PROVERSION, 0);
            ulRet = BspLoadMgrVer(MGR_VER_PROTECT);/*to do:加载MGR 保护区版本*/
            if (BSP_OK != ulRet)
            {
                BspSetMgrVerErrReason(BSP_PROVERSION, ulRet);
                dbgInfo("%s>>Load Protect Zone MGR Version Failed!!\n", __FUNCTION__);
                //fpgaloadLog(LOAD_ERR, "%s,rrucfgini[ok],flag[new]fBoot[err]fpga[pro]:failed\n", __FUNCTION__);
                return (BSP_LOAD_PROC_VER_ERROR|ulRet|0x500);
            }
        }
    }
    return BSP_OK;
}
UINT32 BspGetBootStartFlag(VOID)
{
    unsigned long ulRet = BSP_ERROR;
    UINT32 ulProZoneAddrOffset = 0;
    UINT32 ulProtectVerInfoHeadLen = 0;
    UINT32 ulFlag = 0;
    T_ProtectVerInfoHead *ptVerInfoHead = NULL;

    /*拿到保护区偏移地址*/
    ulProZoneAddrOffset = BspGetVerProtectAddr();

    ulProtectVerInfoHeadLen = sizeof(T_ProtectVerInfoHead);
    ptVerInfoHead = (T_ProtectVerInfoHead*)malloc((size_t)ulProtectVerInfoHeadLen);
    if(NULL == ptVerInfoHead)
    {
        dbgErr("%s>>line:%d mem malloc wrong !!\n",__FUNCTION__,__LINE__);
        //fpgaloadLog(LOAD_ERR, "%s>>mode %d, mem malloc err \n",__FUNCTION__,ulMode);
        return BSP_ERROR;
    }

    /*Get Flag*/
    memset(ptVerInfoHead, 0, (size_t)ulProtectVerInfoHeadLen);
    ulRet = BspFlashRead(ulProZoneAddrOffset, (UCHAR *)((VOID *)ptVerInfoHead), ulProtectVerInfoHeadLen);
    if(ulRet != BSP_OK)
    {
        dbgInfo("%s>>line:%d T_ProtectVerInfoHead INFO READ wrong !!\n",__FUNCTION__,__LINE__);
        //fpgaloadLog(LOAD_ERR, "%s>>mode %d, read info 2 err \n",__FUNCTION__,ulMode);
        free(ptVerInfoHead);
        ptVerInfoHead = NULL;

        return BSP_ERROR;
    }
    ulFlag = (UINT32)(ptVerInfoHead->ucReserve[0]);
    free(ptVerInfoHead);
    ptVerInfoHead = NULL;

    return ulFlag;
}

UINT32 BspGetDbgFlag(VOID)
{
    FILE *pfile = NULL;
    INT32 iTmpRet = 0;

    pfile = fopen(DbgFlagFileName,"r");
    if(NULL == pfile)
    {
        return BSP_ERROR;
    }
    else
    {
        iTmpRet = fclose(pfile);
        FCLOSE_CHECK(iTmpRet);
        pfile = NULL;
        return BSP_OK;
    }
}

UINT32 BspGetSocDbgFlag(VOID)
{
    FILE *pfile = NULL;
    INT32 iTmpRet = 0;

    pfile = fopen(SocDbgFlagFileName,"r");
    if(NULL == pfile)
    {
        return BSP_ERROR;
    }
    else
    {
        iTmpRet = fclose(pfile);
        FCLOSE_CHECK(iTmpRet);
        pfile = NULL;
        return BSP_OK;
    }
}

/* 检查调试文件是否存在 */
UINT32 BspGetSafeBootDbgFlag(VOID)
{
#if (1)
    INT32  lStatFileRet  = 0;
    UINT32 ulProcFileLen = 0;
    UINT32 ulVerExistFlg = BSP_OK;
    struct stat tFileStat = {0};
//  CHAR   acProcNoName[81] = {0};

//  lStatFileRet = snprintf_s(acProcNoName, sizeof(acProcNoName), "%s", SafeBootDbgFlagName);
//  SNPRINTF_S_CHECK(lStatFileRet, sizeof(acProcNoName));

    /* stat函数: 检查文件是否存在, 成功返回0，失败返回-1 */
//  lStatFileRet  = (INT32)stat((CHAR *)&acProcNoName[0], &tFileStat);
    lStatFileRet  = (INT32)stat((CHAR *)SafeBootDbgFlagName, &tFileStat);
    ulProcFileLen = (UINT32)tFileStat.st_size;
    if ((INT32)0 == lStatFileRet)
    {
        /* 文件存在, 检查文件长度是否有效 */
    //  if ((0 == ulProcFileLen)  ||  (BSP_ERROR == ulProcFileLen))
        if (BSP_ERROR == ulProcFileLen)
        {
            ulVerExistFlg = BSP_ERROR;
        }
    }
    else
    {
        ulVerExistFlg = BSP_ERROR; /* 文件不存在, 返回ERROR */
    }

    return ulVerExistFlg;
#else
    FILE  *pfile = NULL;
    INT32 lSnpRet = 0;

    pfile = fopen(SafeBootDbgFlagName, "r");
    if ((FILE *)NULL == pfile)
    {
        return BSP_ERROR;
    }
    else
    {
        lSnpRet = fclose(pfile);
        FCLOSE_CHECK(lSnpRet);
    //  pfile = NULL;
        return BSP_OK;
    }
#endif
}

UINT32 BspMiniMgrPreInit(VOID)
{
    /*做个内存映射，记录原因到高端内存*/
    BspMapHighMemAddr();

    /*规格部分代码处理，主要是看门狗*/
    BspInitBoardAdpt();

    return BSP_OK;
}
UINT32 BspMiniMgrPostInit(VOID)
{
    if((BspGetDbgFlag()==BSP_OK)||(BspGetSocDbgFlag()==BSP_OK))
    {
        /*ushell agent*/
        ushell_init();

        while (1)
        {
            sleep(1);
        }
    }
    BspHighMemUnmap();
    BspAdaptMemUnmap();

    return BSP_OK;
}

/* Started by AICoder, pid:n89afw6a7ff780214e7a089ca048685954886463 */
static UINT32 DpdIcDoMemMap(UCHAR* uPhyAddr,UINT32 uSize,UCHAR **pVirAddr)
{
    /* 打开内存设备的文件描述符 */
    int iSpaceProt = PROT_READ | PROT_WRITE;
    int iFd = 0;

    if ((iFd = open("/dev/mem", O_RDWR | O_SYNC)) >= 0)
    {
        *pVirAddr = (UCHAR*)mmap(0, uSize, iSpaceProt, MAP_SHARED, iFd, (off_t)(UINTPTR_T)uPhyAddr);
        if (*pVirAddr == (UCHAR*)-1)
        {
            close(iFd);
            *pVirAddr = 0;
            dbgErr("%s>>mmap failed !\n",__FUNCTION__);
            return BSP_ERROR;
        }
        close(iFd);
    }
    else
    {
        dbgErr("open /dev/mem failed\n");
        return BSP_ERROR;
    }

    return BSP_OK;
}

static UINT32 BspGetDpd4Id(VOID)
{
    UCHAR    * pBaseAddr = NULL;
    UINT32    ulRpuId = 0;
    UCHAR    * pAddr = NULL;
    UCHAR    *pPhyAddr = (UCHAR *)0xD4B00000;

    if(BSP_OK == DpdIcDoMemMap(pPhyAddr,0x1000,&pBaseAddr))
    {
        pAddr = pBaseAddr+0x64;
        ulRpuId = (UINT32)*(volatile UINT32*)pAddr;
        munmap(pBaseAddr, 0x1000);  // 释放内存资源，防止资源泄露
    }

    return (ulRpuId & 0x3);
}

UINT32 BspIsFileExist(const CHAR *pcFileName)
{
    UINT32 ulRet = BSP_OK;
    struct stat tStatInfo;
    STATUS status;

    INPUT_POINTER_CHECK(pcFileName);
    status = stat(pcFileName, &tStatInfo);
    if (0 != status)
    {
        ulRet = BSP_ERROR;
    }
    return ulRet;
}
/* Ended by AICoder, pid:n89afw6a7ff780214e7a089ca048685954886463 */

/* Started by AICoder, pid:64c6eld22an433b140a30b61e0bc497587b53076 */
UINT32 BspGetNeedLoadSoftVerType(UINT32 socId, UINT32 *softType)
{
    FILE *fp = NULL;
    INT32 lSnpRet = 0;
    UINT32 fileSocId = 0;
    UINT32 fileVerName = 0;
    CHAR * const dirlist[1] = {"/"};
    rsize_t dirlist_size = 1;
    const CHAR *acFileName = "/soc_verlist.ini";

    INPUT_POINTER_CHECK(softType);
    INT32 ret = zte_fopen_s(&fp, acFileName, "r", dirlist, dirlist_size);
    if (0 != ret)
    {
        dbgErr("Failed to open file %s\n", acFileName);
        return BSP_ERROR;
    }

    char line[256];
    while (fgets(line, sizeof(line), fp))
    {
        // 去除行尾换行符
        line[strcspn(line, "\n")] = '\0';

        // 解析行内容
        if (sscanf(line, "%u:%u", &fileSocId, &fileVerName) != 2)
        {
            dbgErr("Invalid line format: %s\n", line);
            continue;
        }

        // 匹配 socId
        if (fileSocId == socId)
        {
            *softType = fileVerName;
            lSnpRet = fclose(fp);
            FCLOSE_CHECK(lSnpRet);
            return BSP_OK;
        }
    }

    // 未找到匹配项
    dbgErr("socId %u not found in %s\n", socId, acFileName);
    lSnpRet = fclose(fp);
    FCLOSE_CHECK(lSnpRet);
    return BSP_ERROR;
}

UINT32 BspGetSocVerLoadListFile(UINT32 ulCnt)
{
    INT32  snRet = BSP_OK;
    char  ftpCmd[100] = {0};
    UINT32 idx = 0;
    struct stat fileStat = {0};

    snRet = snprintf_s(ftpCmd,sizeof(ftpCmd),"tftp -g -r %s -l %s %s -b 16384",
                    "soc_verlist.ini","soc_verlist.ini",FTP_SERV_IP);
    SNPRINTF_S_CHECK(snRet, sizeof(ftpCmd));

    for (idx = 0; idx < ulCnt; idx++)
    {
        system(ftpCmd);
        sleep(2);
        if(stat("/soc_verlist.ini", &fileStat) != -1)
        {
            dbgInfo("%s>>Cnt %d, Get soc_verlist.ini !\n",__FUNCTION__,idx);
            break;
        }
    }
    return BSP_OK;
}
/* Ended by AICoder, pid:64c6eld22an433b140a30b61e0bc497587b53076 */

UINT32 BspGetSocMgrVer(UINT32 ulCnt)
{
    INT32  snRet = BSP_OK;
    char  ftpCmd[100] = {0};
    UINT32 idx = 0;
    struct stat fileStat = {0};
    UINT32 socId = BspGetDpd4Id();
    UINT32 verNo = 14;/*默认SOC_MGR类型*/
    char fileName[32] = {0};

    BspGetSocVerLoadListFile(3);
    if (BSP_OK == BspGetNeedLoadSoftVerType(socId, &verNo))
    {
        snRet |= snprintf_s(fileName, sizeof(fileName), "cur%u.swv", verNo);
        snRet |= snprintf_s(ftpCmd,sizeof(ftpCmd),"tftp -g -r %s -l %s %s -b 16384",
                         fileName,"cur14.swv",FTP_SERV_IP);
    }
    else
    {
        snRet = snprintf_s(ftpCmd,sizeof(ftpCmd),"tftp -g -r %s -l %s %s -b 16384",
                        "cur14.swv","cur14.swv",FTP_SERV_IP);
    }

    SNPRINTF_S_CHECK(snRet, sizeof(ftpCmd));

    for (idx = 0; idx < ulCnt; idx++)
    {
        system(ftpCmd);
        sleep(3);
        if(stat("/cur14.swv", &fileStat) != -1)
        {
            dbgInfo("%s>>Cnt %d, Get Soc MGR Ver !\n",__FUNCTION__,idx);
            break;
        }
    }
    return BSP_OK;
}

UINT32 BspGetDbgFlagFile(UINT32 ulCnt)
{
    INT32  snRet = BSP_OK;
    char  ftpCmd[100] = {0};
    UINT32 idx = 0;
    struct stat fileStat = {0};

    snRet = snprintf_s(ftpCmd,sizeof(ftpCmd),"tftp -g -r %s -l %s %s -b 16384",
                    "miniMGR_dbg","miniMGR_dbg",FTP_SERV_IP);
    SNPRINTF_S_CHECK(snRet, sizeof(ftpCmd));

    for (idx = 0; idx < ulCnt; idx++)
    {
        system(ftpCmd);
        sleep(2);
        if(stat("/miniMGR_dbg", &fileStat) != -1)
        {
            dbgInfo("%s>>Cnt %d, Get miniMGR_dbg !\n",__FUNCTION__,idx);
            break;
        }
    }
    return BSP_OK;
}

static UINT32 BspCreateMasterFlag(void)
{
    INT32 fd = 0;

    fd = creat("/.MasterFlag", S_IRUSR | S_IWUSR | S_IRGRP | S_IROTH);
    if (fd == -1)
    {
        dbgInfo("%s>>create master flag failed!\n",__FUNCTION__);
        return BSP_ERROR;
    }
    FCLOSE_CHECK(close(fd));

    return BSP_OK;
}

static UINT32 BspCreateMiniPreFile(void)
{
    INT32 fd = 0;

    fd = creat("/MiniPre", S_IRUSR | S_IWUSR | S_IRGRP | S_IROTH);
    if (fd == -1)
    {
        dbgInfo("%s>>create MiniPre File failed!\n",__FUNCTION__);
        return BSP_ERROR;
    }
    FCLOSE_CHECK(close(fd));
    return BSP_OK;
}

static void BspWriteGitInfo(const char *fileName)
{
    FILE *fp = NULL;
    int ret = 0;
    CHAR * const dirlist[1] = {"/"};
    rsize_t dirlist_size = 1;
    CHAR gitStr[NAME_MAX] = {0};
    size_t gitStrLen = 0;
    T_CodeInfo gitInfo = {0};

    INPUT_POINTER_CHECK_RETURN(fileName);

    ret = zte_fopen_s(&fp, fileName, "w+", dirlist, dirlist_size);
    if (ret != 0)
    {
        dbgErr("%s: open %s failed, ret = %d\n", __FUNCTION__, fileName, ret);
        return;
    }

    gitInfo = Pub_GetCodeInfo();
    (void)snprintf_s(gitStr, sizeof(gitStr), "bsp(MINIMGR):%s | %s", gitInfo.bsp_code_branch, gitInfo.bsp_code_hash);
    ret = strnlen_s(gitStr, NAME_MAX);
    if (ret <= 0)
    {
        ret = fclose(fp);
        FCLOSE_CHECK(ret);
        return;
    }
    gitStrLen = (size_t)ret;
    if (fwrite(gitStr, gitStrLen, 1, fp) != 1)
    {
        dbgErr("%s: write failed\n", __FUNCTION__);
        ret = fclose(fp);
        FCLOSE_CHECK(ret);
        return;
    }

    if (fsync(fileno(fp)) != 0)
    {
        dbgErr("%s: fsync failed\n", __FUNCTION__);
        ret = fclose(fp);
        FCLOSE_CHECK(ret);
        return;
    }

    ret = fclose(fp);
    FCLOSE_CHECK(ret);
    return;
}

static UINT32 BspCreateMiniPostFile(void)
{
    INT32 fd = 0;

    fd = creat("/MiniPost", S_IRUSR | S_IWUSR | S_IRGRP | S_IROTH);
    if (fd == -1)
    {
        dbgInfo("%s>>create MiniPost File failed!\n",__FUNCTION__);
        return BSP_ERROR;
    }

    FCLOSE_CHECK(close(fd));
    BspWriteGitInfo("/MiniPost");
    return BSP_OK;
}

UINT32 BspSetHashVerNo(CHAR *pcModuleSoftVer,UCHAR ucSizeofBytes)
{
#if (CPU_FAMILY != I80X86)
    CHAR *ptModuleAddr = NULL;

    if (pcModuleSoftVer == NULL)
    {
        dbgErr("%s>> input buffer is null !\n",__FUNCTION__);
        return BSP_ERROR_NULL_POINTER;
    }

    ptModuleAddr = (CHAR *)MODULE_HASH_VER_ADRS;
    memset((CHAR*)ptModuleAddr, 0,VERNO_LEN);/* 先清空 */
    if (ucSizeofBytes <= VERNO_LEN)
    {
        memcpy((CHAR *)ptModuleAddr, pcModuleSoftVer, ucSizeofBytes);
    }
    else
    {
        memcpy((CHAR *)ptModuleAddr, pcModuleSoftVer, VERNO_LEN);
    }
#endif
    return BSP_OK;
}

UINT32 BspLoadHashVer(CHAR* pcFileName)
{
    FILE* pf = NULL;
    CHAR* pBuffer = NULL;
    UINT32 ulLen = 0;
    INT32 lSnpRet = 0;
    struct stat tStatInfo;
    STATUS status;

    INPUT_POINTER_CHECK(pcFileName);

    pf = fopen(pcFileName, "rb");
    if(NULL == pf)
    {
        dbgErr("%s>>fopen failed!\n",__FUNCTION__);
        return BSP_ERROR;
    }

    status = stat(pcFileName, &tStatInfo);
    if((STATUS)0 != status)
    {
        lSnpRet = fclose(pf);
        FCLOSE_CHECK(lSnpRet);
        dbgErr("File:%s not exist!!\n",pcFileName);
        return BSP_ERROR;
    }

    BspSysMsDelay(1);
    pBuffer = (CHAR*)malloc(sizeof(T_VerFileHeader));
    if(NULL == pBuffer)
    {
        lSnpRet = fclose(pf);
        FCLOSE_CHECK(lSnpRet);
        dbgErr("%s>>pBuffer malloc failed!\n",__FUNCTION__);
        return BSP_ERROR;
    }

    BspSysMsDelay(1);
    ulLen = fread(pBuffer, sizeof(T_VerFileHeader), 1, pf);
    lSnpRet = fclose(pf);
    FCLOSE_CHECK(lSnpRet);
    if (1 == ulLen)
    {
        BspSetHashVerNo((CHAR*)((T_VerFileHeader*)pBuffer)->ucVerNo,(UCHAR)VERNO_LEN);
        free(pBuffer);
        pBuffer = NULL;
        return BSP_OK;
    }
    else
    {
        free(pBuffer);
        pBuffer = NULL;
        dbgErr("%s>>pBuffer fread failed!\n",__FUNCTION__);
        return BSP_ERROR;
    }
}

INT32 main(INT32 argc, CHAR *argv[])
{
    UINT32 ulFlag = 0;
    unsigned long ulRet = BSP_OK;
    CHAR acJsonFile[60] = {0};
    CHAR acJsonFilePath[2][32] = {"/ata/rru/cur27.swv","/ata/rru/tmp27.swv"};

    printf("Hello From miniMGR !\n");

    BspCreateMiniPreFile();
    BspMiniMgrPreInit();
    BspCheckSysConnectVer();

    memset((CHAR*)DSP_VER_ADRS, 0,VERNO_LEN);
    memset((CHAR*)MODULE_MGR_VER_ADRS, 0,VERNO_LEN*10);

    if(FPGA_LOAD_ACK_VERSION == (CHAR)BspGetFpgaLoadFlag())
    {
       if(snprintf_s(acJsonFile,60,"%s", acJsonFilePath[1]) < 0)
       {
           dbgErr("%s>>snprintf error [line:%d]\n",__FUNCTION__,__LINE__);
       }
    }
    else
    {
        if(snprintf_s(acJsonFile,60,"%s", acJsonFilePath[0]) < 0)
        {
            dbgErr("%s>>snprintf error [line:%d]\n",__FUNCTION__,__LINE__);
        }
    }
    /*设置HASH版本号到高端内存*/
    if (BSP_OK != BspLoadHashVer(acJsonFile))
    {
        dbgErr("%s>>Set Hash File VerNo To High Memory Failed!\n",__FUNCTION__);
    }

    /*检查主从片*/
    if (BspGetMasterSlaveFlag() == MINIMGR_SLAVE_FLAG) // 从片直接解压缩MGR后，启动
    {
        dbgInfo("%s>>minimgr slave\n",__FUNCTION__);
        /*获取soc MGR*/
        BspGetSocMgrVer(3);
        BspClrMgrVerErrReason();
        ulRet = BspLoadMgrVer(MGR_VER_SOC);// 加载MGR 文件系统版本
        if (BSP_OK != ulRet)
        {
            dbgErr("miniMGR Load Soc Ver failed !\n");
        }
        BspSetMgrVerErrReason(BSP_RUN_VERSION, ulRet);
        BspGetDbgFlagFile(2);
        BspMiniMgrPostInit();
        BspCreateMiniPostFile();

        return ulRet;
    }
    else
    {
        /*生成主板标志文件给业务MGR用*/
        BspCreateMasterFlag();
        dbgInfo("%s>>minimgr master\n",__FUNCTION__);
    }

    dbgInfo("Start to load wfs version\n");
    ulRet = BspLoadMgrVer(MGR_VER_WFS);
    if (ulRet == BSP_OK)
    {
        BspMiniMgrPostInit();
        BspCreateMiniPostFile();
        return BSP_OK;
    }
    ulFlag = BspLoadMgrProcess();
    if(ulFlag != BSP_OK)
    {
        /*记录加载失败原因到文件，然后加载保护区版本*/
        dbgErr("miniMGR Load Active Ver failed !\n");

        ulRet = BspLoadMgrVer(MGR_VER_PROTECT);/*加载MGR 保护区版本*/
        if (BSP_OK != ulRet)
        {
            dbgErr("miniMGR Load Proctect Ver failed !\n");
            BspSetMgrVerErrReason(BSP_PROVERSION, ulRet);
        }
    }

    BspMiniMgrPostInit();
    BspCreateMiniPostFile();

    return BSP_OK;
}


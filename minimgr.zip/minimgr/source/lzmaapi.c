/************************************************************************
* 版权所有 (C)2012, 深圳市中兴通讯股份有限公司。
*
* 文件名称： LzmaApi.c
* 文件标识： SDR
* 内容摘要： LZMA模块对外接口
* 其它说明： 本模块将对外提供两种接口
*            从内存解压到内存
*            从文件解压到文件
* 当前版本： 1.0
* 作    者： wood
* 完成日期：
*
* 修改记录1：
*    修改日期：20180725
*    版 本 号：
*    修 改 人：宋志强
*    修改内容：增加encode 接口函数，从lzma模块放到surezip模块中
************************************************************************/

#include <stdlib.h>
#include <string.h>
#include "LzmaLib.h"
#include "LzmaDec.h"
#include "LzmaEnc.h"
#include "7zTypes.h"
#include "fcntl.h"
#include "lzmaapi.h"
#include "Alloc.h"
#include "pub_basetypedef.h"
#include "bsperrcode.h"
#include "zprintf.h"

/**************************************************************************
 *                            常量                                        *
 **************************************************************************/

#define LZMA_MALLOC    malloc
#define LZMA_FREE      free
#define LZMA_OPEN      fopen
#define LZMA_READ      fread
#define LZMA_WRITE     fwrite
#define LZMA_CLOSE     fclose
static unsigned long PrnLama = 1;

#define LZMA_PRINT     if(PrnLama) printf


/* 复合内存释放，仅对非空指针进行释放 */
#define LZMA_MM_FREE(x)   {\
                               if(NULL != x)\
                               {\
                                   free(x); \
                                   x = NULL; \
                               }\
                               else \
                               {\
                                   printf("Free NULL pointer\n");\
                               }\
                          }

#define LZMA_MM_CLOSE(x)   {\
                               if(NULL != x)\
                               {\
                                   fclose(x); \
                                   x = NULL; \
                               }\
                               else \
                               {\
                                   printf("Close invalid file\n");\
                               }\
                           }

/**************************************************************************
 *                           宏定义                                       *
 **************************************************************************/
#define IN_BUF_SIZE  (1 << 16) /* 64k */
#define OUT_BUF_SIZE (1 << 16) /* 64k */


#define READ_RETRY_COUNT     3
/**************************************************************************
 *                          数据类型                                      *
 **************************************************************************/


/**************************************************************************
 *                          全局变量                                      *
 **************************************************************************/


/**************************************************************************
 *                        局部函数原型                                    *
 **************************************************************************/



/**************************************************************************
 *                        全局函数实现                                    *
 **************************************************************************/



/**************************************************************************
 *                        局部函数实现                                    *
 **************************************************************************/



/**************************************************************************
函数名称:  LzmaGetHeaderInfo
功能描述:  从buffer中获取lzma头部,包含 props参数以及未压缩长度信息
输入参数:
               srcbuf -- buffer
               *ptLocalHeader -- 本地格式的头部信息
输出参数:      *ptLocalHeader -- 本地格式的头部信息
返 回 值:  0:操作成功
附加说明:
修改说明:
  修改日期          版本号      修改人      修改内容
  -----------------------------------------------
  2012年6月9日      1.0       wood        创建
**************************************************************************/
int LzmaGetHeaderInfo(const unsigned char * srcbuf, unsigned long BufLength,T_lzma_header *ptLocalHeader)
{
    int i;

    LZMA_PRINT("Start to get header:%d\n",LZMA_PROPS_SIZE);
    LZMA_PRINT("srcbuf :%d  %d  %d  %d  %d  %d \n",srcbuf[0],srcbuf[1],srcbuf[2],srcbuf[3],srcbuf[4],srcbuf[5]);

    if(BufLength < sizeof(T_lzma_header))
    {
        return LZMA_ERROR_INPUT_EOF;
    }

    /* copy props */
    memmove(ptLocalHeader->props,srcbuf,LZMA_PROPS_SIZE);
    LZMA_PRINT("copy props ok\n");

    /* construct 64 bit unpack_size, ignore big or little endian local system */
    ptLocalHeader->unpack_size = 0;
    for (i = 0; i < 8; i++)
    {
        ptLocalHeader->unpack_size += (UInt64)srcbuf[LZMA_PROPS_SIZE + i] << (i * 8);
    }

    /* debug info */
    LZMA_PRINT("unpacked size : %lld\n",ptLocalHeader->unpack_size);
    LZMA_PRINT("Props:\n");
    for(i = 0; i<LZMA_PROPS_SIZE;i++)
    {
        LZMA_PRINT(" %2x\n",ptLocalHeader->props[i]);
    }
    LZMA_PRINT("\n");
    /* debug info end */
    return 0;
}


/**************************************************************************
函数名称:  LzmaGetHeaderInfoFromFd
功能描述:  从文件中获取lzma头部,包含 props参数以及未压缩长度信息
输入参数:
               *TargetFile -- 文件名
               *ptLocalHeader -- 头部信息
输出参数:      *ptLocalHeader -- 头部信息
返 回 值:  0:操作成功
附加说明:
修改说明:
  修改日期          版本号      修改人      修改内容
  -----------------------------------------------
  2012年6月9日      1.0       wood        创建
**************************************************************************/
int LzmaGetHeaderInfoFromFd(char *TargetFile,T_lzma_header *ptLocalHeader)
{
    FILE     *fp;
    int      ReadCnt;
    int  lFclsRet = 0;
    unsigned char TempBuf[sizeof(T_lzma_header)];

    fp = fopen(TargetFile, "rb");

    if (fp == NULL)
    {
        printf("Fail to open file %s\n",TargetFile);
        return -1;
    }

    ReadCnt = fread(TempBuf, 1, sizeof(T_lzma_header), fp);

    if(ReadCnt != sizeof(T_lzma_header))
    {
        printf("The file %s has invalid length\n",TargetFile);
        lFclsRet = fclose(fp);
        FCLOSE_CHECK(lFclsRet);
        return -1;
    }

    lFclsRet = fclose(fp);
    FCLOSE_CHECK(lFclsRet);

    return LzmaGetHeaderInfo(TempBuf,sizeof(T_lzma_header),ptLocalHeader);

}

/**************************************************************************
函数名称:  LzmaGetFileLen
功能描述:  获取文件的长度
输入参数:
               *pstrFileName -- 文件名
输出参数:
返 回 值:  文件长度
附加说明:
修改说明:
  修改日期          版本号      修改人      修改内容
  -----------------------------------------------
  2012年6月9日      1.0       wood        创建
**************************************************************************/
int LzmaGetFileLen(char *pstrFileName)
{
    FILE     *fp;
    int      iFileLen;
    int  iFsekRet = 0;
    int  lFclsRet = 0;

    fp = fopen(pstrFileName, "rb");
    if (fp == NULL)
    {
        printf("Fail to open file %s\n",pstrFileName);
        return 0;
    }
    long pos = ftell(fp);
    if (pos < 0)
    {
        printf("%s>>ftell failed!\n",__FUNCTION__);
        lFclsRet = fclose(fp);
        FCLOSE_CHECK(lFclsRet);
        return -1;
    }
    int res = fseek(fp, 0, SEEK_END);
    if ((int)0 != res)
    {
        printf("%s>>Fseek Failed!!!\n",__FUNCTION__);
        lFclsRet = fclose(fp);
        FCLOSE_CHECK(lFclsRet);
        return -1;
    }
    iFileLen = ftell(fp);
    if (iFileLen < 0)
    {
        printf("%s>>ftell failed!\n",__FUNCTION__);
        lFclsRet = fclose(fp);
        FCLOSE_CHECK(lFclsRet);
        return -1;
    }
    iFsekRet = fseek(fp, pos, SEEK_SET);
    if((int)0 != iFsekRet)
    {
        printf("%s>>Fseek Failed!!!\n",__FUNCTION__);
        lFclsRet = fclose(fp);
        FCLOSE_CHECK(lFclsRet);
        return -1;
    }
    lFclsRet = fclose(fp);
    FCLOSE_CHECK(lFclsRet);
    return iFileLen;
}


/**************************************************************************
函数名称:  LzmaDecMem
功能描述:  LZMA 内存解压到内存
输入参数:
               PackedBuf -- 待解压的内存buf
               UnpackBuf -- 解压之后的内存buf
               PackedLength -- 待解压的长度
输出参数:
返 回 值:  0:操作成功
附加说明:  lzma 压缩格式
           props      --  5字节，压缩参数
           unpacksize --  8字节，未经压缩的长度
修改说明:
  修改日期          版本号      修改人      修改内容
  -----------------------------------------------
  2012年6月1日      1.0       wood        创建
**************************************************************************/
unsigned long LzmaDecMem(const unsigned char * PackedBuf, unsigned char * UnpackBuf, size_t PackedLength, size_t *unPackedLength)
{
    T_lzma_header tLzma_header;

    int Retcode = 0;
    int thereIsSize = 0;
    size_t onceDestCnt = 0;
    size_t onceSrcCnt = 0;
    size_t propsSize  = 0;

    if(NULL == PackedBuf || NULL == UnpackBuf  || NULL == unPackedLength || 0 == PackedLength)
    {
        printf("Invalid buffer or length from LzmaDecMem\n");
        return LZMA_RET_ERROR;
    }

    Retcode = LzmaGetHeaderInfo(PackedBuf, PackedLength,&tLzma_header);

    if(0 != Retcode)
    {
        printf("Fail to get lzma header\n");
        return LZMA_RET_ERROR;
    }

    thereIsSize = (tLzma_header.unpack_size != (UInt64)(Int64)-1);
    if (!thereIsSize)
    {
        //如果没有填充解压缩后的数据长度，默认按照100倍压缩率分配内存
        onceDestCnt = PackedLength * 100;
    }
    else
    {
        onceDestCnt =(unsigned long) tLzma_header.unpack_size;
    }

    if(tLzma_header.unpack_size > UNPACK_LENGTH_WARNING_THRESHOLD_MINI)
    {
        /* beep only,keep moving */
        printf("Warning: the unpacked file length %lld is great than %d\n",tLzma_header.unpack_size,UNPACK_LENGTH_WARNING_THRESHOLD_MINI);
    }

    /* one gigabytes is the current restriction. */
    if(tLzma_header.unpack_size > UNPACK_LENGTH_LIMIT)
    {
#if 0
        printf("Fail to get lzma header\n");
        return LZMA_RET_ERROR;
#else
        tLzma_header.unpack_size = PackedLength * 100;
#endif
    }

    onceSrcCnt  = PackedLength;
    propsSize =LZMA_PROPS_SIZE;

    Retcode = LzmaUncompress(UnpackBuf, &onceDestCnt, PackedBuf+sizeof(T_lzma_header), &onceSrcCnt, tLzma_header.props, propsSize);
    *unPackedLength = onceDestCnt;
    return Retcode;
}

/**************************************************************************
函数名称:  LzmaEncMem
功能描述:  LZMA 内存压缩到内存
输入参数:
               InBuf     -- 待压缩的内存buf
               OutBuf    -- 压缩之后的内存buf
               InLen     -- 待压缩数据的长度
               *OutLen   -- 压缩后数据的长度
               level     -- 压缩等级，如果<0则用默认等级5压缩
输出参数:
返 回 值:  0:操作成功
附加说明:  lzma 压缩格式
           props      --  5字节，压缩参数
           unpacksize --  8字节，未经压缩的长度
修改说明:
  修改日期          版本号      修改人      修改内容
  -----------------------------------------------
  2018年7月25日      1.0       宋志强        创建
**************************************************************************/
unsigned long LzmaEncMem(const unsigned char *InBuf, unsigned char *OutBuf, size_t InLen, size_t *OutLen, int level)
{
    unsigned long RetCode = LZMA_RET_OK;

    unsigned char header[LZMA_PROPS_SIZE + 8];
    size_t headerSize = LZMA_PROPS_SIZE;

    if (NULL == InBuf|| NULL == OutBuf)
    {
        printf("Null string\n");
        return LZMA_ERROR_UNSUPPORTED;
    }

    CLzmaEncHandle enc;
    CLzmaEncProps props;
    int i = 0;

    enc = LzmaEnc_Create(&g_Alloc);
    if (enc == 0)
        return SZ_ERROR_MEM;
    do
    {
        LzmaEncProps_Init(&props);
        if (level < 0)
        {
            props.level = 5;
        }
        else
        {
            props.level = level;
        }
        (void)LzmaEnc_SetProps(enc, &props);
        (void)LzmaEnc_WriteProperties(enc, header, &headerSize);
        for (i = 0; i < 8; i++)
            header[headerSize++] = (Byte)((UInt64)InLen >> (8 * i));

        memmove(OutBuf, header, headerSize);
        RetCode = LzmaCompress(OutBuf + headerSize, (size_t*)OutLen, InBuf, (size_t)InLen,
            &header[0],
            &headerSize,
            props.level,//9 /* 0 <= level <= 9, default = 5 */
            props.dictSize,// 1 << 24, /* use (1 << N) or (3 << N). 4 KB < dictSize <= 128 MB */
            props.lc, //3, /* 0 <= lc <= 8, default = 3  */
            props.lp, //0, /* 0 <= lp <= 4, default = 0  */
            props.pb, // 2, /* 0 <= pb <= 4, default = 2  */
            props.fb, // 32,  /* 5 <= fb <= 273, default = 32 */
            props.numThreads //1 /* 1 or 2, default = 2 */
            );

        break;
    } while (1);

    LzmaEnc_Destroy(enc, &g_Alloc, &g_Alloc);

    return RetCode;
}




/**************************************************************************
函数名称:   LzmaDecFile
功能描述:  LZMA 文件解压为文件
输入参数:
               *PackedFile -- 压缩的文件名
               *UnpackedFile -- 解压后的文件名
输出参数:
返 回 值:  0:操作成功
附加说明:  lzma 压缩格式
           props      --  5字节，压缩参数
           unpacksize --  8字节，未经压缩的长度
修改说明:
  修改日期          版本号      修改人      修改内容
  -----------------------------------------------
  2012年6月1日      1.0       wood        创建
**************************************************************************/
unsigned long LzmaDecFile(char *PackedFile,char *UnpackedFile)
{
    unsigned long PackedFileLength;
    size_t        UnpackedFileLength;
    unsigned long ReadCnt;
    unsigned long WriteCnt;
    unsigned char *PackFileBuf = NULL;
    unsigned char *UnpackefFileBuf = NULL;
    FILE          *PackedFileFd = NULL;
    FILE          *UnpackedFileFd = NULL;
    int           RetryCnt;
    unsigned long RetCode = LZMA_RET_OK;
    T_lzma_header tLzma_header;


    if(NULL == PackedFile || NULL == UnpackedFile)
    {
        printf("Null string\n");
        return LZMA_ERROR_UNSUPPORTED;
    }

    do
    {
        PackedFileLength = LzmaGetFileLen(PackedFile);

        if(0 == PackedFileLength)
        {
            RetCode = LZMA_ERROR_UNSUPPORTED;
            break;
        }

        PackFileBuf = LZMA_MALLOC(PackedFileLength);

        if(NULL == PackFileBuf)
        {
            printf("Fail to malloc mem in LzmaDecFile\n");
            break;
        }

        PackedFileFd = LZMA_OPEN(PackedFile,"rb");

        if(NULL == PackedFileFd)
        {
            printf("Fail to open file %s\n",PackedFile);
            RetCode = LZMA_ERROR_OPEN;
            break;
        }

        for(RetryCnt = 0; RetryCnt <READ_RETRY_COUNT ; RetryCnt++)
        {
            ReadCnt = LZMA_READ(PackFileBuf, 1, PackedFileLength, PackedFileFd);

            if(ReadCnt != PackedFileLength)
            {
                printf("Fail to read file %s, %ld time\n",PackedFile,ReadCnt);
            }
            else
            {
                break;
            }
        }

        if(READ_RETRY_COUNT == RetryCnt)
        {
            RetCode = LZMA_ERROR_READ;
            break;
        }

        RetCode = LzmaGetHeaderInfo(PackFileBuf,PackedFileLength,&tLzma_header);

        if(0 != RetCode)
        {
            printf("Fail to get lzma header\n");
            RetCode = LZMA_ERROR_DATA;
            break;
        }


        UnpackedFileLength = (size_t)tLzma_header.unpack_size;

        /* one gigabytes is the current restriction. */
        if (UnpackedFileLength > UNPACK_LENGTH_LIMIT)
        {
            printf("Fail to get lzma header\n");
            //RetCode = LZMA_ERROR_DATA;
            //break;
            UnpackedFileLength = PackedFileLength * 100;
        }

/* Started by AICoder, pid:r7e712ef8ftb4ac145e80bbc50859d1fd0858dfc */
        if(UnpackedFileLength > UNPACK_LENGTH_WARNING_THRESHOLD_MINI)
        {
            /* beep only,keep moving */
            printf("Warning2: the unpacked file length %lld is great than %d\n",tLzma_header.unpack_size,UNPACK_LENGTH_WARNING_THRESHOLD_MINI);
            break;
        }
/* Ended by AICoder, pid:r7e712ef8ftb4ac145e80bbc50859d1fd0858dfc */

        UnpackefFileBuf = LZMA_MALLOC(UnpackedFileLength);

        if(NULL == UnpackefFileBuf)
        {
            printf("Fail to malloc unpacked buffer\n");
            RetCode = LZMA_ERROR_MEM;
            break;
        }

        RetCode = LzmaDecMem(PackFileBuf,UnpackefFileBuf,PackedFileLength,&UnpackedFileLength);

        if(LZMA_RET_OK != RetCode)
        {
            break;
        }

        UnpackedFileFd = LZMA_OPEN(UnpackedFile, "wb");

        if(NULL == UnpackedFileFd)
        {
            printf("Fail to create %s\n",UnpackedFile);
            RetCode = LZMA_ERROR_OPEN;
            break;
        }

        for(RetryCnt = 0; RetryCnt <READ_RETRY_COUNT ; RetryCnt++)
        {
            WriteCnt = LZMA_WRITE(UnpackefFileBuf,1, UnpackedFileLength, UnpackedFileFd);
            if(WriteCnt != UnpackedFileLength)
            {
                printf("Fail to read file %s, %d time\n",UnpackedFile,RetryCnt);
            }
            else
            {
                break;
            }
        }

        if(READ_RETRY_COUNT == RetryCnt)
        {
            RetCode = LZMA_ERROR_WRITE;
            break;
        }

        break;
    }while(1);

    LZMA_MM_CLOSE(PackedFileFd);
    LZMA_MM_CLOSE(UnpackedFileFd);
    LZMA_MM_FREE(PackFileBuf);
    LZMA_MM_FREE(UnpackefFileBuf);

    return RetCode;
}

/* Started by AICoder, pid:j2f75057f8830161470d0927c0e3b9166877f198 */
/* Started by AICoder, pid:l354698dc169d2014a760a750039960c3649d630 */
UINT32 SafeAddFunc(UInt64 num1, UInt64 num2, UInt64* ret)
{
    INPUT_POINTER_CHECK(ret);

    if(num1 > UINT64_MAX - num2)
    {
        dbgErr("[%s] overflow!\n", __FUNCTION__);
        return BSP_ERROR;
    }

    *ret = num1 + num2;
    return BSP_OK;
}
/* Ended by AICoder, pid:l354698dc169d2014a760a750039960c3649d630 */
/* Ended by AICoder, pid:j2f75057f8830161470d0927c0e3b9166877f198 */

/**************************************************************************
函数名称:  LzmaEncFile
功能描述:  LZMA 内存压缩到内存
输入参数:
               InFile     -- 待压缩的文件名
               OutFile    -- 压缩之后的文件名
               level     -- 压缩等级，如果<0则用默认等级5压缩
输出参数:
返 回 值:  0:操作成功
附加说明:  lzma 压缩格式
           props      --  5字节，压缩参数
           unpacksize --  8字节，未经压缩的长度
修改说明:
  修改日期          版本号      修改人      修改内容
  -----------------------------------------------
  2018年7月25日      1.0       宋志强        创建
**************************************************************************/
unsigned long LzmaEncFile(char *InFile, char *OutFile, int level)
{
    UInt64 InFileLength;
    UInt64 OutFileLength;
    UInt64 tmpLength;
    unsigned long ReadCnt;
    unsigned long WriteCnt;
    unsigned char *InFileBuf = NULL;
    unsigned char *OutFileBuf = NULL;
    FILE          *InFileFp = NULL;
    FILE          *OutFileFp = NULL;
    int RetryCnt;
    unsigned long RetCode = LZMA_RET_OK;

    unsigned char header[LZMA_PROPS_SIZE + 8];

    INPUT_POINTER_CHECK(InFile);
    INPUT_POINTER_CHECK(OutFile);

    CLzmaEncHandle enc = 0;

    do
    {
        InFileLength = LzmaGetFileLen(InFile);

        if (0 == InFileLength)
        {
            RetCode = LZMA_ERROR_UNSUPPORTED;
            break;
        }

        enc = LzmaEnc_Create(&g_Alloc);
        if (enc == 0)
            return SZ_ERROR_MEM;

        InFileBuf = LZMA_MALLOC((size_t)InFileLength);

        if (NULL == InFileBuf)
        {
            printf("Fail to malloc mem in LzmaDecFile\n");
            break;
        }

        InFileFp = LZMA_OPEN(InFile, "rb");

        if (NULL == InFileFp)
        {
            printf("Fail to open file %s\n", InFile);
            RetCode = LZMA_ERROR_OPEN;
            break;
        }

        for (RetryCnt = 0; RetryCnt <READ_RETRY_COUNT; RetryCnt++)
        {
            ReadCnt = LZMA_READ(InFileBuf, 1, (size_t)InFileLength, InFileFp);

            if (ReadCnt != InFileLength)
            {
                printf("Fail to read file %s, %ld time\n", InFile, ReadCnt);
            }
            else
            {
                break;
            }
        }

        if (READ_RETRY_COUNT == RetryCnt)
        {
            RetCode = LZMA_ERROR_READ;
            break;
        }

        OutFileLength = InFileLength;

        OutFileBuf = LZMA_MALLOC((size_t)OutFileLength);

        if (NULL == OutFileBuf)
        {
            printf("Fail to malloc unpacked buffer\n");
            RetCode = LZMA_ERROR_MEM;
            break;
        }

        OutFileFp = LZMA_OPEN(OutFile, "wb");
        if (NULL == OutFileFp)
        {
            printf("Fail to create %s\n", OutFile);
            RetCode = LZMA_ERROR_OPEN;
            break;
        }

        RetCode = LzmaEncMem(InFileBuf, OutFileBuf, InFileLength, (size_t*)&OutFileLength, 9);

/* Started by AICoder, pid:j2f75057f8830161470d0927c0e3b9166877f198 */
        for (RetryCnt = 0; RetryCnt <READ_RETRY_COUNT; RetryCnt++)
        {
            if(BSP_OK != SafeAddFunc(OutFileLength, sizeof(header), &tmpLength))
            {
                printf("[%s]Fail to add header\n", __FUNCTION__);
                break;
            }

            WriteCnt = LZMA_WRITE(OutFileBuf, 1, (size_t)tmpLength, OutFileFp);
            if (WriteCnt != OutFileLength + sizeof(header))
            {
                printf("Fail to read file %s, %d time\n", OutFile, RetryCnt);
            }
            else
            {
                break;
            }
        }
/* Ended by AICoder, pid:j2f75057f8830161470d0927c0e3b9166877f198 */

        if (READ_RETRY_COUNT == RetryCnt)
        {
            RetCode = LZMA_ERROR_WRITE;
            break;
        }

        break;
    } while (1);

    LzmaEnc_Destroy(enc, &g_Alloc, &g_Alloc);
    LZMA_MM_CLOSE(InFileFp);
    LZMA_MM_CLOSE(OutFileFp);
    LZMA_MM_FREE(InFileBuf);
    LZMA_MM_FREE(OutFileBuf);

    return RetCode;
}

/* 边读边解压， 省内存型接口，推荐使用 */
/**************************************************************************
函数名称:  long LzmaDecFileOpted
功能描述:  节约内存型解压接口（File To File）
输入参数:
               *PackedFile --
               *UnpackedFile --
输出参数:
返 回 值:  BSP_OK:操作成功
附加说明:
修改说明:
  修改日期          版本号      修改人      修改内容
  -----------------------------------------------
  2012年6月9日      1.0       wood        创建
**************************************************************************/
unsigned long LzmaDecFileOpted(char *PackedFile,char *UnpackedFile)
{
    unsigned long UnpackedFileLength;
    unsigned long ReadCnt;
    unsigned long RetCode;
    unsigned long InPos  = 0;
    unsigned long OutPos = 0;
    unsigned long InProcessed  = 0;

    unsigned long OutProcessed = 0;
    unsigned long InSize = 0;
    unsigned long UnpackedSize;
    unsigned char *InBuf=NULL;
    unsigned char *OutBuf=NULL;
    ELzmaFinishMode FinishMode;
    ELzmaStatus     status;
    CLzmaDec        state;
    T_lzma_header   tLzma_header;
    SRes TempRes;
    int LengthValid;
    FILE          *PackedFileFd = NULL;
    FILE          *UnpackedFileFd = NULL;

    /* debug*/
    int seekpos = 0;
    unsigned char tempbuf[20];

    /* todo : params verifying */
    do
    {
        /* analyze file header */
        LzmaGetHeaderInfoFromFd(PackedFile,&tLzma_header);
        LengthValid = (tLzma_header.unpack_size != (UInt64)(Int64)-1);

        /* 仅支持32bit的长度 先 */
        UnpackedFileLength = (unsigned long)tLzma_header.unpack_size;
        UnpackedSize = UnpackedFileLength;

        /* construct dec status*/
        LzmaDec_Construct(&state);

        /* allocate dict */
        LzmaDec_Allocate(&state, (Byte *)&tLzma_header, LZMA_PROPS_SIZE, &g_Alloc);

        /* init state */
        LzmaDec_Init(&state);

        PackedFileFd = fopen(PackedFile, "rb");
        if(NULL == PackedFileFd)
        {
            printf("Fail to open file %s\n",PackedFile);
            RetCode = LZMA_ERROR_OPEN;
            break;
        }

        UnpackedFileFd = fopen(UnpackedFile, "wb");
        if(NULL == UnpackedFileFd)
        {
            printf("Fail to create %s\n",UnpackedFile);
            RetCode = LZMA_ERROR_OPEN;
            break;
        }

        InBuf = malloc(IN_BUF_SIZE);
        if(NULL == InBuf)
        {
            printf("Fail to malloc mem for InBuf\n");
            RetCode= LZMA_ERROR_MEM;
            break;
        }

        OutBuf = malloc(IN_BUF_SIZE);
        if(NULL == OutBuf)
        {
            printf("Fail to malloc mem for OutBuf\n");
            RetCode= LZMA_ERROR_MEM;
            break;
        }

        /* read, decode and write */
        /* lseek 无效?? */
        seekpos = fread(tempbuf, 1, sizeof(T_lzma_header), PackedFileFd);
        if (seekpos != sizeof(T_lzma_header))
        {
            printf("%s>>Fread Failed!!!\n",__FUNCTION__);
        }
        LZMA_PRINT("seekpos  = %d\n",seekpos);

        for (;;)
        {
            if (InPos == InSize)
            {
                InSize = IN_BUF_SIZE;
                InSize = fread(InBuf, 1, IN_BUF_SIZE, PackedFileFd);
                if (InSize != IN_BUF_SIZE)
                {
                    printf("%s>>Fread Failed!!!\n",__FUNCTION__);
                }
                InPos = 0;
                ReadCnt = InSize;

                /* debug */
                LZMA_PRINT("ReadCnt  = %ld\n",ReadCnt);
                /* logBuf(InBuf,InSize);*/
            }

            InProcessed = InSize - InPos;
            OutProcessed = OUT_BUF_SIZE - OutPos;
            FinishMode = LZMA_FINISH_ANY;

            if (LengthValid && OutProcessed > UnpackedSize)
            {
                OutProcessed = UnpackedSize;
                FinishMode = LZMA_FINISH_END;
            }

            TempRes = LzmaDec_DecodeToBuf(&state,
                                          OutBuf + OutPos,
                                          (SizeT *)&OutProcessed,
                                          InBuf + InPos,
                                          (SizeT *)&InProcessed,
                                          FinishMode,
                                          &status);
            InPos += InProcessed;
            OutPos += OutProcessed;
            UnpackedSize -= OutProcessed;
            LZMA_PRINT("\n============\n");
            LZMA_PRINT("TempRes = %d\n",TempRes);
            LZMA_PRINT("InPos = %ld\n",InPos);
            LZMA_PRINT("OutPos = %ld\n",OutPos);
            LZMA_PRINT("UnpackedSize = %ld\n",UnpackedSize);

            /* printf("%s",OutBuf); */
            if (fwrite(OutBuf, 1, OutPos, UnpackedFileFd) != OutPos)
            {
                RetCode = LZMA_ERROR_WRITE;
                break;
            }

            /* next time */
            OutPos = 0;

            /* abnormal branch */
            if ((TempRes != SZ_OK) || (LengthValid && (UnpackedSize == 0)))
            {
                RetCode = (unsigned long)TempRes;
                break;
            }

            /* Final branch */
            if (InProcessed == 0 && OutProcessed == 0)
            {
              if (LengthValid || status != LZMA_STATUS_FINISHED_WITH_MARK)
              {
                 RetCode = SZ_ERROR_DATA;
                 break;
              }
              RetCode = TempRes;
              break;
            }

        }

        break;

    }while(1);

    LZMA_MM_CLOSE(PackedFileFd);
    LZMA_MM_CLOSE(UnpackedFileFd);
    LZMA_MM_FREE(InBuf);
    LZMA_MM_FREE(OutBuf);
    LzmaDec_Free(&state, &g_Alloc);

    return RetCode;

}


//#ifdef VOS_LINUX
#include "elf.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <errno.h>
#include <fcntl.h>
#include <limits.h>
#include <pthread.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/time.h>
#include <linux/unistd.h>
#include <mqueue.h>
#include <math.h>
#include <signal.h>
#include <sys/mman.h>
#include "pub_basetypedef.h"
#include "elf_symbol.h"
#include "zprintf.h"
#include "bsperrcode.h"
#include "secure_func.h"

#define MGR_PROCESS


#define IPC_MSG_LENTH 512
#define IPC_MSG_NUM 50
#define IPC_FIFO_LENTH 4096
#define USHELL_NAME_LENGTH  64
#define MSGQ_LENGTH  64

#define ARG_NUM 10
#define ARG_LENGTH 512

#define MIN(a,b) ((a)<(b) ? (a) : (b))
#define MINIMGR_isspace(c)           (c == ' ' || c == '\f' || c == '\n' || c == '\r' || c == '\t' || c == '\v')

/* Config for mgr and app process */

#define PROC_NAME "miniMGR.EXE"
#define FIFO_NAME  "/ushell_fifo"
#define MSGQ_NAME "/ushell_msq"
#define CMDLOG_NAME "/cmdlog_"

#define MINIMGR_SIGRTMAX 64
#define   SIGTASKTRACK               (MINIMGR_SIGRTMAX-20)       /* 死锁、死循环处理专用信号 */
#define isdigit(a) ((unsigned)((a) - '0') <= 9)

/* defines */
struct plist {
    int pid;    
    int tgid;    /* thread group id */
    int ppid;
    int priority;
    CHAR    name[16];
    CHAR    state;
    CHAR    pad[3];
    struct  plist *next;
};


/* working in appstart */
mqd_t mqd;
static struct mq_attr attr;
char msg[IPC_MSG_LENTH];

mqd_t UshellClientmqd = -1;
char g_aucUshellClientMsgqName[MSGQ_LENGTH];
int g_ushell_client_pid =0;
long  g_ushell_command_result =0;


int flag_print = 0; //flag of stdout direct (fifo ? 1 : 0)
int flag_debug = 0; //flag of debug command state
int g_ushell_debug = 0;


static char *gpfifo_name = NULL;
static char *gmsgq_name = NULL;
static char *gcmdlog_name = NULL;


long (*testFUNC)(long, long, long, long, long, long, long, long, long, long);
typedef void (*TaskEntryProto)(void *); /* 任务入口原型 */
typedef pthread_t       VOS_TASK_T;


void *pthread_msgqueue(void *);
int symbol_init(char *);
void InitSignal(void);
void handle_signal(int s) ;


static int translate_priority(int v2pthread_priority, int sched_policy, int *errp)
{
    int max_priority, pthread_priority;

    //  Validate the range of the user's task priority.
    if ((v2pthread_priority > 255) | (v2pthread_priority < 0))
        *errp = -1;

    max_priority = sched_get_priority_max(sched_policy);

    pthread_priority = max_priority - (v2pthread_priority / 3);
    
    pthread_priority -= 2;  /*预留 99的优先级给中断服务任务，98的优先级给taskLock*/

    return pthread_priority;
}

/*****************************************************************************
* 函数名: SetFdBlockMode
* 功能: 设置ushell的阻塞模式
* 参数:
*   fd: 文件描述符
*   isBlock:
*          TRUE: 设置为阻塞模式
*          FALSE: 设置为非阻塞模式
*/
/*****************************************************************************
 *  函数名称   : Vos_StartTask(*)
 *  功能描述   :
 *  读全局变量 : 无
 *  写全局变量 : 无
 *  输入参数   : pucName      - 任务名
 *               wPriority    - 任务优先级
 *               dwStacksize  - 任务栈
 *               tTaskEntry   - 任务入口
 *               lpTaskInPara - 任务入口参数
 *  输出参数   :
 *  返 回 值   :
 *  其它说明   : 无
 *---------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *  $0000000(N/A), 周元庆@2002-10-15 14:21:35,创建
 *----------------------------------------------------------------------------
 */
/* Started by AICoder, pid:d3113ge4751d3a0146820a6fd0395c99cd08aebc */
VOS_TASK_T Vos_StartTask(
    unsigned char           *pucName,
    short         wPriority,
    unsigned int         dwStacksize,
    int        sdwOptions,
    TaskEntryProto tTaskEntry,
    unsigned int         dwTaskPara1    
)
{
    VOS_TASK_T tTaskId = 0;/* 0 为无效Id */
//    OSS_ASSERT(tTaskEntry != NULL);
#ifdef VOS_WINNT
    if (CreateThread(NULL,
                     dwStacksize,
                     (LPTHREAD_START_ROUTINE)tTaskEntry,
                     (LPVOID)dwTaskPara1,
                     0,
                     &tTaskId
                    ) == NULL)
    {
        return 0;
    }
#endif

#ifdef VOS_VXWORKS
    tTaskId = taskSpawn(
                   (CHAR*)pucName,
                   (INT)wPriority,
                   (INT)sdwOptions,
                   dwStacksize,
                   (FUNCPTR)tTaskEntry,
                   (INT)dwTaskPara1, 0, 0, 0, 0, 0, 0, 0, 0, 0
               );
    if ((WORD32)ERROR == tTaskId)
    {
        return 0;
    }
#endif
#ifdef VOS_LINUX
    pthread_attr_t        attr;
    pthread_t             threadID;
    struct sched_param    scheparam;
    unsigned long         no = 0;
    int                   errcode   = 0;
    int                  swMemPageSize = getpagesize();

    /*consider data align*/
    /* modify by lizl,20070904,thread's stack has minimal size  */
    if( swMemPageSize > 0 )
    {
        dwStacksize     += (1+1) * swMemPageSize;    /* 加上4个保护页,另外一页是留给pthread使用的 */
    }

    if( dwStacksize < 4096 )
    {
        dwStacksize = 4096; 
    }

    pthread_attr_init(&attr);

    if( pthread_attr_setinheritsched(&attr,PTHREAD_EXPLICIT_SCHED) != 0 )
    {
        printf("Vos_StartTask: set attr failed!\n");
    }
    
    pthread_attr_setschedpolicy(&attr,SCHED_FIFO);
    pthread_attr_getschedparam(&attr,&scheparam);
    scheparam.__sched_priority = translate_priority(wPriority,SCHED_FIFO,&errcode);
 //   scheparam.__sched_priority  = wPriority;
    pthread_attr_setschedparam(&attr,&scheparam);
    pthread_attr_setstacksize(&attr,dwStacksize);

    if( swMemPageSize > 0 )
    {
        pthread_attr_setguardsize(&attr,1*swMemPageSize);
    }
    
//    no = AddThreadIntoDebugTable(tTaskId,(CHAR*)pucName,tTaskEntry,(VOID *)dwTaskPara1,wPriority,dwStacksize);
//    if(no < 0)
//    {
//        return 0;
//    }
        
    errcode = pthread_create(&threadID,&attr,(void *)tTaskEntry,(void *)no);

/* Started by AICoder, pid:b5fb5t5708ya9af14e0f0812e0168410c826ef0e */
    if (0 != errcode)
    {
        if(0 != pthread_attr_destroy(&attr))
        {
            dbgErr("[%s]%d:pthread_attr_destroy failed! ", __FUNCTION__, __LINE__);
        }
        return 0;
    }

    tTaskId  = threadID;
    if(0 != pthread_attr_destroy(&attr))
    {
        dbgErr("[%s]%d:pthread_attr_destroy failed! ", __FUNCTION__, __LINE__);
    }
/* Ended by AICoder, pid:b5fb5t5708ya9af14e0f0812e0168410c826ef0e */
#endif
    return tTaskId;
}
/* Ended by AICoder, pid:d3113ge4751d3a0146820a6fd0395c99cd08aebc */

/*信号处理函数*/
void handle_signal(int s) 
{ 
    printf("Rev SIGPIPE signal,do not exit!!\n");

    InitSignal();
}

/*初始化时调用*/
void InitSignal(void)
{
   signal(SIGPIPE,handle_signal);   
}


int ushell_init(void)
{
    unsigned long ulpid = 0;
    CHAR acFileName[] = "miniMGR.EXE";
    UCHAR ucStr[] = "ushellAgent";
    INT32 iTmpRet = 0;
    
    ulpid = getpid();
    symbol_init(acFileName);

    gpfifo_name = (char *)malloc(USHELL_NAME_LENGTH);
    if (NULL == gpfifo_name)
    {
        printf("malloc failed!\n");
        return -1;
    }
    gmsgq_name = (char *)malloc(USHELL_NAME_LENGTH);
    if (NULL == gmsgq_name)
    {
        free(gpfifo_name);
        gpfifo_name = NULL;
        printf("malloc failed!\n");
        return -1;
    }
    gcmdlog_name = (char *)malloc(USHELL_NAME_LENGTH);
    if (NULL == gcmdlog_name)
    {
        free(gpfifo_name);
        gpfifo_name = NULL;
        free(gmsgq_name);
        gmsgq_name = NULL;
        printf("malloc failed!\n");
        return -1;
    }
    memset(gpfifo_name,0,USHELL_NAME_LENGTH);
    memset(gmsgq_name,0,USHELL_NAME_LENGTH); 
    memset(gcmdlog_name,0,USHELL_NAME_LENGTH); 
    
    iTmpRet = snprintf_s(gpfifo_name,USHELL_NAME_LENGTH,"%s%d",FIFO_NAME, ulpid);    
    SNPRINTF_S_CHECK(iTmpRet, USHELL_NAME_LENGTH);
    iTmpRet = snprintf_s(gmsgq_name,USHELL_NAME_LENGTH,"%s%d", MSGQ_NAME, ulpid);      
    SNPRINTF_S_CHECK(iTmpRet, USHELL_NAME_LENGTH);
    if(-1 ==sprintf(gcmdlog_name,"%s%ld.log", CMDLOG_NAME, ulpid))
    {
        dbgErr("%s>>sprintf_s Failed!!!\n",__FUNCTION__);
    }

    //sprintf(aucbuf,"rm -rf  %s",gpfifo_name);
    //sprintf(aucbuf,"rm -rf  ushell_fifo* ");
    //system(aucbuf);

    printf("gpfifo_name = %s\n", gpfifo_name);
    printf("gmsgq_name = %s\n", gmsgq_name);
    printf("gcmdlog_name = %s\n", gcmdlog_name);
 
    unlink(gpfifo_name);
       
    /* fifo for redirect stdout */
    if(0 != mkfifo(gpfifo_name,O_CREAT))
    {
        printf("Create fifo error!");
        free(gpfifo_name);
        gpfifo_name = NULL;
        free(gmsgq_name);
        gmsgq_name = NULL;
        free(gcmdlog_name);
        gcmdlog_name = NULL;
        return -1;
    }
    /* msg queue */
    memset(&attr, 0, sizeof(attr));
    attr.mq_maxmsg  = IPC_MSG_NUM;
    attr.mq_msgsize = IPC_MSG_LENTH;
    shm_unlink(gmsgq_name);
    mqd = mq_open(gmsgq_name, O_RDONLY | O_CREAT,666,&attr);
    if ((mqd_t)-1 == mqd)
    {
        printf("Open MsgQueue:%s error!",gmsgq_name);
        free(gpfifo_name);
        gpfifo_name = NULL;
        free(gmsgq_name);
        gmsgq_name = NULL;
        free(gcmdlog_name);
        gcmdlog_name = NULL;
        return -1;
    }

    if (0 ==
            Vos_StartTask(ucStr,
                          1,
                          32*1024,
                          0,
                          (TaskEntryProto)pthread_msgqueue,
                          0))
    {
        printf("ushell_init Create thread error!\n ");
        free(gpfifo_name);
        gpfifo_name = NULL;
        free(gmsgq_name);
        gmsgq_name = NULL;
        free(gcmdlog_name);
        gcmdlog_name = NULL;
        return -1;
    }
    
    return 0;
}




















/* ushell command queue daemon thread */
/*****************************************************************************
 *  函数名称   : OSS_TimerSignalBlock(*)
 *  功能描述   : 屏蔽时钟信号，需在线程入口处添加
 *  读全局变量 : 无
 *  写全局变量 : 无
 *  输入参数   : 无
 *  输出参数   : 无
 *  返 回 值   : 无
 *  其它说明   : 无
 *---------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *  $0000000(N/A), 袁师盛@2009-07-20 14:29:30,创建,for Linux
 *----------------------------------------------------------------------------
 */
void OSS_TimerSignalBlock(VOID)
{
    //blockticksig();
}
void OSS_HexDump (unsigned char *buf, int len)
{
    int i;

    for (i = 0; i < len; i++) {
        if ((i % 16) == 0)
            printf ("%s%p: ", i ? "\n" : "", &buf[i]);
        printf ("%s%02x", (i % 4) ? "" : " ", buf[i]);
    }
    printf ("\n");
}



/** **************************************************************************
*函数名: SetFdBlockMode
* 功能: 设置ushell的阻塞模式
* 参数: *   fd: 文件描述符
               *   isBlock:*TRUE: 设置为阻塞模式*FALSE: 设置为非阻塞模式
               
*****************************************************************************/
VOID SetFdBlockMode(int fd, BOOLEAN isBlock)
{   
    int flags;    

    flags = fcntl(fd, F_GETFL);    
    if(TRUE == isBlock)    
    {        
        flags &= ~O_NONBLOCK;     
    }    
    else    
    {        
        flags |= O_NONBLOCK;    
    }       
    if(fcntl(fd, F_SETFL, flags) < 0)    
    {        
        printf("SetFdBlockMode fcntl fd %d isBlock %d\n", fd, isBlock);    
    }
}

/*去除命令和参数之间多余的空格 shenhuadong 20110818*/
static char *trim(char *str)  
{ 
    char *start = str;
    char *end;
    if(start)
    {
        end = start + strlen(str) - 1;
        while(*start && MINIMGR_isspace(*start))
        {
            start++;
        }

        if ('\0' == *start)
        {
            str[0] = '\0';
            return str;
        }
        
        while(MINIMGR_isspace(*end))
        {
            *end-- = '\0';
        }
        memmove(str, start, end - start + 2);
    }

    return str;
    
} 

/**********************************************************************
* 函数名称： symFindByAddress
* 功能描述： 判断输入的命令是否地址，如果是地址是否可以找到函数
* 访问的表： 无
* 修改的表： 无
* 输入参数： 1. 输入的命令字符串
* 输出参数： 1. 输出该地址的类型，1为全局变量，2为函数, 其他值为错误类型
* 返 回 值： TRUE:地址是可以找到函数或者全局变量
* 其它说明： 无
* 修改日期        版本号     修改人       修改内容
* ----------------------------------------------------------------------
* 2012/12/27       V1.0      jiagnjw          创建
* 
***********************************************************************/
BOOLEAN symFindByAddress(CHAR *command, CHAR* name, WORDPTR *pValue, WORD32 *pSize, WORD32 *ptSymType)
{
    unsigned long   wSymValue;
    CHAR *end;
    
    if(NULL == command || NULL == name || NULL == pValue || 
       NULL == pSize || NULL == ptSymType)
    {
        printf("symFindByAddress param error");
        return FALSE;
    }

    if(command[0] == '0' && (command[1] == 'x' || command[1] == 'X'))
    {
            const long sl = strtol(command, &end, 10);
            errno = 0;
            
            if (end == command) 
            {
                printf("[%s:%d]%s: not a decimal number\n", __FUNCTION__, __LINE__, command);
            } 
            else if ('\0' != *end) 
            {
                printf("[%s:%d]%s: extra characters at end of input\n", __FUNCTION__, __LINE__, command);
            } 
            else if ((LONG_MIN == sl || LONG_MAX == sl) && ERANGE == errno) 
            {
                printf("[%s:%d]%s out of range of type long\n", __FUNCTION__, __LINE__, command);
            } 
            else 
            {
                *pValue = (int)sl;
            }

    }
    if(OK == symFindAttrByValue((WORDPTR)*pValue,name,&wSymValue,ptSymType, pSize))
    {
        /*如果该地址是函数入口地址*/
        if (STT_FUNC == *ptSymType && (*pValue) == wSymValue)
        {
            return TRUE;
        }
    }
    
    return FALSE;
}
BOOLEAN IsDangerCmd(CHAR command[])
{
    /* 如下4个命令在mgr ushell里输入了会导致MGR退出 */
    if((0 == strcmp("err" , command))\
        ||(0 == strcmp("errx" , command))\
        ||(0 == strcmp("verr" , command))\
        ||(0 == strcmp("verrx" , command)))
    {
        return TRUE;
    }
    return FALSE;
}

VOID ExcuteDebugCommand(CHAR command[],
    long arg1, long arg2, long arg3, long arg4, long arg5, 
    long arg6, long arg7, long arg8, long arg9, long arg10)
{ 
    long value = -1;

    if(NULL == command)
        return ;
    if(TRUE == IsDangerCmd(command))
    {
        printf("can not input fun: %s,it will make process exit!\n",command);
        return;
    }

    printf("[   begin to excel fun:%s      ]\n", command);
    
    value = testFUNC(arg1, arg2, arg3, arg4, arg5, 
                          arg6, arg7, arg8, arg9, arg10);
    g_ushell_command_result = value;

    printf("value = %ld(0x%lx)\n",value,value);
    
    /* printf("\nUshell Input Is Wrong! Data Access Error Happened,"\
                 " Please Check Your Input Again!!\n"); */

        
   printf("[   end to excel fun:%s      ]\n", command);
}

VOID UshellResponseClient(mqd_t client, char* pMsg)
{
    if((-1 != client) && (pMsg != NULL))
    {
        if(1 == g_ushell_debug)
        {
            printf("send respond %s to %d \n", pMsg, client);
        }
        
        mq_send(client, pMsg, IPC_MSG_LENTH, 0);
    }
}
/*lint +e644*/

VOID UshellShowVarValue(CHAR command[],
                        CHAR argstr[ARG_NUM][ARG_LENGTH], 
                        WORD32 symsize, long firstArgInt)
{
/*lint -e611*/
    WORD32 iloop      = 0;
    UCHAR *ucptemp = NULL;
    
    if((NULL == command) || (NULL == argstr))
        return;

    switch(symsize)
    {
    case 1:
        {
            if(argstr[0][0]!='\0')
            {
               *(char *)testFUNC= firstArgInt;
            }
            printf("%s = 0x%lx value=0x%02x\n", command, (long)testFUNC,*(char *)testFUNC); //shaohui
            break;
        }
    case 2:
        {
            if(argstr[0][0]!='\0')
            {
               *(WORD16 *)testFUNC = firstArgInt;
            }
            printf("%s = 0x%lx value=0x%04x\n",command, (long)testFUNC,*(WORD16 *)testFUNC);
            break;
        }
   case 4:
        {
            if(argstr[0][0]!='\0')
            {
               *(WORD32 *)testFUNC = firstArgInt;
            }
            printf("%s = 0x%lx value=0x%08x\n",command, (long)testFUNC,*(WORD32 *)testFUNC);
            break;
        }
   case 8:
        {
            if(argstr[0][0]!='\0')
            {
               *(WORD64 *)testFUNC = firstArgInt;
            }
            printf("%s = 0x%lx value=0x%016llx\n",command, (long)testFUNC,*(WORD64 *)testFUNC);
            break;
        }
   default:
        {
            ucptemp = (UCHAR *)testFUNC;
            printf("%s= addr:0x%p\n",command, testFUNC);
            for(iloop=0;iloop<symsize;iloop++)
            {
                if((iloop%4==0)&&(iloop>0))
                {
                    printf("  ");
                }
                if((iloop%16==0)&&(iloop>0))
                {
                    printf("\n");
                }
                printf("%02x",*(ucptemp+iloop));
                
            }
            printf("\n");
        }
    }
/*lint +e611*/
}

/* 调用elf文件，分析出符号表，可根据进程名修改elf文件名（使用绝对路径） */
int symbol_init(char * filename)
{
    return InitSymbolTable(PROC_NAME);
   // PrintSymTable();
}

void *pthread_msgqueue(void *arg)
{
/* debug command return */
  int i,j,k;
  char command_buf[ARG_LENGTH],argstr[ARG_NUM][ARG_LENGTH],argtemp[ARG_LENGTH];
  signed long  argint[ARG_NUM],argflag[ARG_NUM];
  char ExcCodeName[255];
  BOOLEAN bAccessBySymName = FALSE;
  int fd = 0;
  //int fd_old = 0;
  int fd_STDOUT = 0;
  WORD32 symtype,symsize;
  CHAR *end;
  
 //屏蔽掉时钟信号
  OSS_TimerSignalBlock();

    /*fd=open(gpfifo_name,O_WRONLY | O_ASYNC,0);*/
  /* do with the ushell command */
      /* **********************************
      * ushell命令处理部分，
      * 三种命令：
      * 1、printfifo输出定向至管道；
      * 2、输出定向至标准输出设备；
      * 3、执行调试命令（参数不多于10个）
      *************************************/
    while(1) 
    {
        memset(msg,0,IPC_MSG_LENTH);
        if(-1 == mq_receive(mqd, msg, IPC_MSG_LENTH, NULL))//len must bigger than the msg len sent
            perror("mq_receive()");

        /*1.output direct to fifo */
        printf("%s\n",msg);

        if(strcmp(msg,"print_fifo") == 0)
        {    /* if output direct to fifo stdout */
            if(flag_print == 0) 
            {
                fd = -1;            
                fd=open(gpfifo_name,O_WRONLY,0);
                
                if(-1 == fd)            
                {               
                    printf("open fifo:%s \n",gpfifo_name);                
                    return NULL;            
                }  
                /* 设置ushell的非阻塞模式 */
                SetFdBlockMode(fd, FALSE);   
                
                fd_STDOUT=dup(STDOUT_FILENO); 
                
                dup2(fd,STDOUT_FILENO);
                
                printf("ushell enter print mod \n "); 
                
                flag_print = 1;
            }
        }
#if 0        
        /*2.output direct to fifo stdout */
        else if((strcmp(msg,"quit")) == 0)
        {    /* if output direct to fifo */
            if(flag_print == 1)
            {
                dup2(fd_old,STDOUT_FILENO);
                flag_print = 0;
            }
            flag_debug = 0;

        }
#endif
        /*output not direct to fifo */
        else if((strcmp(msg,"not_print_fifo")) == 0)
        {    
            /* if output direct to fifo */
            if(flag_print == 1)
            {
                printf("ushell exit print mod \n ");
                if(-1 != fd_STDOUT)
                {
                    dup2(fd_STDOUT,STDOUT_FILENO);
                    close(fd_STDOUT);
                }
                close(fd);
                flag_print = 0;
            }
        }
        /* debug command */
        else if((strcmp(msg,"debug")) == 0)
        {
            printf("ushell enter debug mod \n ");
            flag_debug = 1;
        }
        /* not debug command */
        else if((strcmp(msg,"not_debug")) == 0)
        {
            printf("ushell exit debug mod \n ");
            flag_debug = 0;
        }        
        else if((strcmp(msg,"print_fifo_and_debug")) == 0)
        {
            if(flag_print == 0)         
            {  
                if(0 != setvbuf(stdout,NULL,_IOLBF,512))
                {
                     printf("ushell setvbuf stdout fail !!!\n");
                }
                fd = -1;            
                fd=open(gpfifo_name,O_WRONLY,0);
                if(-1 == fd)            
                {                
                    printf("open fifo:%s error\n",gpfifo_name);               
                    return NULL;            
                }            
                /* 设置ushell的非阻塞模式 */
                SetFdBlockMode(fd, FALSE);                
                fd_STDOUT=dup(STDOUT_FILENO);           
                dup2(fd,STDOUT_FILENO);           
                printf("ushell enter print mod \n ");           
                flag_print = 1;        
            }                
            printf("ushell enter debug mod \n ");       
            flag_debug = 1;
        }
        else if((strcmp(msg,"not_print_fifo_and_debug")) == 0)
        {
            /* if output direct to fifo */
            if(flag_print == 1)    
            {
                if(-1!=fd_STDOUT)
                {
                    dup2(fd_STDOUT,STDOUT_FILENO);
                    close(fd_STDOUT);
                }
                close(fd);
                if(-1 != UshellClientmqd)
                {
                    mq_close(UshellClientmqd);
                    memset(g_aucUshellClientMsgqName,0,MSGQ_LENGTH);
                    UshellClientmqd = -1;
                    g_ushell_client_pid = 0;
                }    
                flag_print =0;
            }
            flag_debug = 0;
        }
        else if((strcmp(msg,"ushell_thread_print_and_debug")) == 0)
        {
            if(flag_print == 0) 
            { 
                flag_print = 1;
            }
            
            flag_debug = 1;
        }
        else if((strcmp(msg,"ushell_thread_print_wait_and_debug")) == 0)
        {
            if((flag_print != 0) ||(flag_debug != 0))
            {
                printf("warning have ushell attach in\n");
                /* if output direct to fifo */
                if(flag_print == 1)
                {
                    if(-1 != fd_STDOUT)
                    {
                        dup2(fd_STDOUT,STDOUT_FILENO);
                        close(fd_STDOUT);
                    }
                    close(fd);                    
                    if(-1 != UshellClientmqd)
                    {
                        mq_close(UshellClientmqd);
                        memset(g_aucUshellClientMsgqName,0,MSGQ_LENGTH);
                        UshellClientmqd = -1;
                        g_ushell_client_pid = 0;
                        
                    }       
                    flag_print = 0;
                }
                flag_debug = 0;
           }
            g_ushell_client_pid = atoi(msg+zte_strnlen_s("ushell_thread_print_wait_and_debug",64));
            
            memset(g_aucUshellClientMsgqName,0,MSGQ_LENGTH);
            if(-1 == snprintf_s(g_aucUshellClientMsgqName,MSGQ_LENGTH,"/ushell_client_msq%d",g_ushell_client_pid))
            {
                dbgErr("%s>>sprintf_s Failed!!!\n",__FUNCTION__);
            }
            UshellClientmqd = mq_open((char *)g_aucUshellClientMsgqName, O_WRONLY|O_NONBLOCK);
            if ((mqd_t)-1 == UshellClientmqd)
            {
                printf("Open MsgQueue:%s error!\n",g_aucUshellClientMsgqName);
                continue;
            }
            //if(g_ushell_debug == 1)
            //{
                printf("g_ushell_client_pid:%d g_aucUshellClientMsgqName:%s \n",g_ushell_client_pid,g_aucUshellClientMsgqName);
            //}
            flag_print = 1;
            flag_debug = 1;
        }    
        else
        {   
            if(1 == flag_debug)
            {
                /* get the command */
                memset(command_buf,'\0',ARG_LENGTH);
                memset(argstr[0],'\0',sizeof(argstr));
                for(i=0;i<ARG_NUM;i++)
                {
                  argflag[i]=0;
                  argint[i]=0;
                }
                if(g_ushell_debug == 1)
                {
                    printf("%s\n",msg);
                }

                //rmbcmd(msg);
                //bAddrFunc = VerifyAddressFuncCmd(msg);
                /* 将字符串调试命令分解为函数和参数 */
                i=0;j=0;k=0;
                for(i = 0;(i<IPC_MSG_LENTH);i++)
                {/* 函数名分离 */
                    if(j == 0)
                    {
                        if (k >= IPC_MSG_LENTH)
                        {
                            continue;
                        }
                        if((msg[i]!=' ')&&(msg[i]!='\0'))
                        {    
                            command_buf[k] = msg[i];
                            k++;
                        }
                        else   
                        {          
                            command_buf[k] = '\0';      
                            j++;
                            k = 0;                    
                        }
                    }
                    else
                    {/* 参数分离，字符串形式 */
                        if((msg[i]!=',')&&(msg[i]!='\0'))
                        {    
                            //argstr[j-1][ARG_LENGTH-1]用来存放\0,参数最多不能超过29个字符
                            if(msg[i] == '\"')
                            {
                                if(i == (ARG_LENGTH - 1))
                                {
                                    printf(" para %d is error \n",j);
                                    goto USHELL_PARA_ERROR;
                                }
                                argstr[j-1][k] = '\"';
                                k++;
                                i++;
                                while((msg[i] != '\"') &&  (msg[i] != '\0'))
                                {
                                    if(k < ARG_LENGTH - 1)
                                    {
                                        argstr[j-1][k] = msg[i];
                                        k++;
                                    }
                                    i++;

                                }
                                argstr[j-1][k] = '\"';
                                k++;
                            }
                            else
                            {
                                if(k<ARG_LENGTH -1) 
                                {
                                    argstr[j-1][k] = msg[i];
                                    k++;
                                }
                                else
                                {
                                    printf(" para %d is too long \n",j);
                                    goto USHELL_PARA_ERROR;
                                }
                            }
                        }
                        else   
                        {       
                            argstr[j-1][k] = '\0';         
                            j++;
                            k = 0;
                            if(msg[i]=='\0')
                            {
                                break;
                            }
                            if (j > ARG_NUM)
                            {
                                printf(" para num is too much\n");
                                goto USHELL_PARA_ERROR;
                            }
                            
                        }
                    }
                }
                
                /* 参数字符串形式转化为整型数 */
                for(i = 0; i < 10; i++)
                {
                    /*去除命令和参数之间多余的空格 shenhuadong 20110818*/
                    trim(argstr[i]);
                   
                    //参数为16进制数
                    if(((argstr[i][0] == '0')&&(argstr[i][1] == 'x'))
                        ||((argstr[i][0] == '0')&&(argstr[i][1] == 'X')))
                    {
                    #if 1
                        const long sl = strtol(argstr[i], &end, 10);
                        errno = 0;
            
                        if (end == argstr[i]) 
                        {
                            printf("[%s:%d]%s: not a decimal number\n", __FUNCTION__, __LINE__, argstr[i]);
                        } 
                        else if ('\0' != *end) 
                        {
                            printf("[%s:%d]%s: extra characters at end of input\n", __FUNCTION__, __LINE__, argstr[i]);
                        } 
                        else if ((LONG_MIN == sl || LONG_MAX == sl) && ERANGE == errno) 
                        {
                            printf("[%s:%d]%s out of range of type long\n", __FUNCTION__, __LINE__, argstr[i]);
                        } 
                        else 
                        {
                            argint[i] = (int)sl;
                        }
                    #else
                        if(EOF == sscanf_s(argstr[i],"0x%lx",&argint[i]))/* 32位%lx,%p */
                        {
                            printf("[%s:%d]sscanf fail!\n", __FUNCTION__, __LINE__);
                        }
                    #endif
                        if(g_ushell_debug == 1)
                        {
                            printf("line :%d argstr[%d] :%s argint[%d]:0x%lx \n",__LINE__,i,argstr[i],i,argint[i]);
                        }
                    }
                    //参数为字符串
                    else if(argstr[i][0] == '\"')
                    {
                        argflag[i]=1;

                        int iCopyLen = MIN(strlen(&argstr[i][1]), ARG_LENGTH);
                        memcpy(argtemp,&argstr[i][1], iCopyLen);
                        if (iCopyLen > 0)
                             argtemp[iCopyLen - 1] = '\0';

                        memset(argstr[i],0,sizeof(argstr[i]));
                        strncpy_s(argstr[i],iCopyLen,argtemp,iCopyLen);
                        //OSS_S_strcpy(argstr[i],ARG_LENGTH,argtemp);
                        if(g_ushell_debug == 1)
                        {
                            printf("line :%d argstr[%d] :%s  \n",__LINE__,i,argstr[i]);
                        }
                        
                    }
                    //参数为十进制
                    else
                    {
                    #if 0
                        argint[i] = atoll(argstr[i]);
                    #else
                        argint[i] = atoi(argstr[i]);
                    #endif
                        if(g_ushell_debug == 1)
                        {
                            printf("line :%d argstr[%d] :%s argint[%d]:0x%lx \n",__LINE__,i,argstr[i],i,argint[i]);
                        }
                    }
                }
                
                /* 分解出调试函数形式: command_buf(argint[0], argint[1], argint[2]) */

                /* excute debug command */
        /*lint -e644*/
                /* 命令是函数或者全局变量，命令为0x开头的一个地址也要判断 */
                memset(ExcCodeName, 0, sizeof(ExcCodeName));
                bAccessBySymName = (symFindByName(command_buf,(WORDPTR*)&testFUNC,&symsize,&symtype) == 0) ? TRUE : FALSE;
                /*
                if((TRUE == bAccessBySymName) || 
                    ((TRUE == bAddrFunc) && 
                    (TRUE == symFindByAddress(command_buf, ExcCodeName, (WORDPTR*)&testFUNC, (WORD32*)&symsize,(WORD32*)&symtype))
                    )
                  ) 
                */
                if (TRUE == bAccessBySymName)
                    { /* 设置ushell的阻塞模式 */
                    /* 设置ushell为阻塞模式 */
                    SetFdBlockMode(fd, TRUE);
                    //执行函数
                    if(STT_FUNC == symtype )
                    {
                        //ExcuteDebugCommand(((bAddrFunc == TRUE) ? ExcCodeName : command_buf),
                        ExcuteDebugCommand((command_buf),
                                       ((argflag[0]== 0)?argint[0]:(OSS_LONG)argstr[0]),
                                       ((argflag[1]== 0)?argint[1]:(OSS_LONG)argstr[1]),
                                       ((argflag[2]== 0)?argint[2]:(OSS_LONG)argstr[2]),
                                       ((argflag[3]== 0)?argint[3]:(OSS_LONG)argstr[3]),
                                       ((argflag[4]== 0)?argint[4]:(OSS_LONG)argstr[4]),
                                       ((argflag[5]== 0)?argint[5]:(OSS_LONG)argstr[5]),
                                       ((argflag[6]== 0)?argint[6]:(OSS_LONG)argstr[6]),
                                       ((argflag[7]== 0)?argint[7]:(OSS_LONG)argstr[7]),
                                       ((argflag[8]== 0)?argint[8]:(OSS_LONG)argstr[8]),
                                       ((argflag[9]== 0)?argint[9]:(OSS_LONG)argstr[9]));

                        UshellResponseClient(UshellClientmqd, msg);
                        //fflushSpecFile();                  
                    }
        /*lint +e644*/
        /*lint -e611*/
                    //显示变量值
                    else if(STT_OBJECT == symtype )
                    {
                        if (TRUE == bAccessBySymName)
                        {
                            UshellShowVarValue(command_buf, &argstr[0], symsize, argint[0]);
                        }
                        else
                        {
                            printf("address  %s is not in code segment!\n",command_buf);
                            UshellResponseClient(UshellClientmqd, msg);
                        }
                    }
                    else 
                    {
                       printf("symtype:%d error \n",symtype);
                    }
                    /* 设置ushell的非阻塞模式 */
                    SetFdBlockMode(fd, FALSE);
                    
                }   
                else 
                {
                    printf("sym:%s not found!\n",command_buf);
                   
                    UshellResponseClient(UshellClientmqd, msg);
                }
           USHELL_PARA_ERROR:
               continue;
                
          }
          else
          {
              if(1 == g_ushell_debug)
              {
                 printf("%s\n",msg);
              }
          }
        }                 
      }
}

/*********************************************************************************************/
/* fuctions for test */
/*********************************************************************************************/


char g_testval = 0;
unsigned short g_testval_16 =0x1234;
unsigned long g_testval_32 =0x12345678;


unsigned long EXC_SendSignalToTask(pthread_t threadid, unsigned long signo)
{
    int ret;
    ret = pthread_kill(threadid,signo);
    if (0 == ret)
    {
        return 0;
    }
    else
    {
       // printf("pthread_kill failed to send signal! errno: %d.\n",errnoGet());
        return -1;
    }
}


void tt(VOS_TASK_T dwThreadId)
{
    //dwThreadId = Vos_GetCurTaskID();
    if((VOS_TASK_T)NULL == dwThreadId )
    {
       printf("dwThreadId is null \n");
       return;
    }
    printf("dwThreadId is 0x%lx \n",dwThreadId);
    //EXC_Printf(NULL,NULL,"Show task context by signal ...\n");
    EXC_SendSignalToTask(dwThreadId,SIGTASKTRACK);
    sleep(1);

}


/*****************************************************************************
 *  函数名称   : m(*)
 *  功能描述   : 修改内存
 *  读全局变量 :
 *  写全局变量 :
 *  输入参数   :
 *  输出参数   :
 *  返 回 值   :
 *  其它说明   :
 *---------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *  $0000000(N/A), CLH@2009-10-21 14:31:32,创建
 *----------------------------------------------------------------------------
 */
int m(unsigned long iaddr,int value)
{
     char * puctemp = NULL;
     printf("iaddr:0x%lx value:%d\n",iaddr,value);
     if(iaddr == 0)
     {
        return -1;
     }
     puctemp = (char *)iaddr;
     *puctemp = (char)value;
     return *puctemp;
}

/*****************************************************************************
 *  函数名称   : d(*)
 *  功能描述   : 修改内存
 *  读全局变量 :
 *  写全局变量 :
 *  输入参数   :
 *  输出参数   :
 *  返 回 值   :
 *  其它说明   :
 *---------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *  $0000000(N/A), CLH@2009-10-21 14:34:04,创建
 *----------------------------------------------------------------------------
 */
int d(unsigned long iaddr,int len)
{
     printf("addr:0x%lx \n",iaddr);
     if(iaddr == 0)
     {
        return -1;
     }
    /*for(i=0;i<16;i++)
     {
         if((i%4==0)&&(i>0))
         {
            printf("  ");
         }
         printf("%02x",*(ucptemp+i));
     }*/
     OSS_HexDump((unsigned char*)iaddr,len);
     
     return 0;
}

int a()
{
        if(g_testval == 1)
        {
            printf("\nI'm A!\n");
        }
    return 100;

}

int b(int i0,char * puc1,int i1,char * puc2)
{
    printf("\nI'm B, Received %d puc:%s %d %s \n",i0,puc1,i1,puc2);
    return i0;

}

int c(int i0, int  i1, int  i2, int  i3, int i4, int  i5, int  i6, int i7, int i8,int  i9)
{
    printf("\nI'm C, Received %d %d %d\n",i3,i4,i8);
    return i9;

}

int OSS_DbgOpenUshellDebug(void)
{
  g_ushell_debug =1;
  return g_ushell_debug;
}
int OSS_DbgCloseUshellDebug(void)
{
  g_ushell_debug =0;
  return g_ushell_debug;
}

/**********************************************************************
* 函数名称：UshellDelSubProcess
* 功能描述：管理进程在监控到子进程退出时删除子进程fifo和消息队列
* 访问的表：
* 修改的表：无
* 输入参数：

* 输出参数：无
* 返 回 值：无
* 其它说明：
* 修改日期        版本号     修改人          修改内容
* -----------------------------------------------
************************************************************************/
OSS_STATUS UshellDelSubProcess(BYTE ucProductType, INT iExitState)
{
    WORD32    dwCurProcId;
    CHAR auctemp[USHELL_NAME_LENGTH];    
    INT32 iRet = 0;
    dwCurProcId = getpid();
    
    memset(auctemp,0,sizeof(auctemp));
    iRet = snprintf_s((CHAR*)(auctemp),sizeof(auctemp), FIFO_NAME,dwCurProcId);
    SNPRINTF_S_CHECK(iRet, sizeof(auctemp));
    unlink((char *)auctemp);
    
    memset(auctemp,0,sizeof(auctemp));
    iRet = snprintf_s((CHAR*)(auctemp),USHELL_NAME_LENGTH, MSGQ_NAME,dwCurProcId);
    SNPRINTF_S_CHECK(iRet, USHELL_NAME_LENGTH);
    mq_unlink((char *)auctemp);
        
    return 0;

}


/**********************************************************************
* 函数名称：int proc_filter
* 功能描述：过滤函数
* 访问的表：
* 修改的表：无
* 输入参数：
* 输出参数：无
* 返 回 值：无
* 其它说明：
* 修改日期        版本号     修改人          修改内容
* -----------------------------------------------
  2009.12.15        UniBTSV1.0          chenlinhai        创建
************************************************************************/
int proc_filter(const struct dirent * di)
{
    /* 
     * processes start with a number (pid)
     * threads start with '.' 
     */
/*lint -e1055*/
    return isdigit(di->d_name[0]) ||
    (di->d_name[0] == '.' && isdigit(di->d_name[1]));
}
/*lint +e1055*/
/**********************************************************************
* 函数名称：static void fill_plist(FILE * fd, struct plist *pcurr)
* 功能描述：读取proc文件系统下status内容
* 访问的表：
* 修改的表：无
* 输入参数：
* 输出参数：无
* 返 回 值：无
* 其它说明：
* 修改日期        版本号     修改人          修改内容
* -----------------------------------------------
  2009.12.15        UniBTSV1.0          chenlinhai        创建
************************************************************************/
void fill_plist(FILE * fd, struct plist *pcurr)
{
    CHAR buff[1024];
    CHAR *cp;
    CHAR *end;
    rsize_t size_array[2] = {16,0};
    
    while (fgets(buff, sizeof(buff), fd) != NULL)
    {
        cp = buff;
        while (!MINIMGR_isspace(*cp) && *cp)
        {
            cp++;
        }
        while (MINIMGR_isspace(*cp) && *cp)
        {
            cp++;
        }
        if (!strncmp(buff, "Name:", 5))
        {
            if (EOF == zte_sscanf_s(cp, "%16s", size_array,pcurr->name))
            {
                dbgInfo("[%s:%d]sscanf fail!\n", __FUNCTION__, __LINE__);
            }
        }
        else if (!strncmp(buff, "State:", 6))
        {
            pcurr->state = (*cp);
        }
        else if (!strncmp(buff, "Tgid:", 5))
        {
            if (EOF == sscanf(cp, "%d", &pcurr->tgid))
            {
                dbgInfo("[%s:%d]sscanf fail!\n", __FUNCTION__, __LINE__);
            }
        }
        else if (!strncmp(buff, "Pid:", 4))
        {
            const long sl = strtol(cp, &end, 10);
            errno = 0;
            
            if (end == cp) 
            {
                printf("[%s:%d]%s: not a decimal number\n", __FUNCTION__, __LINE__, cp);
            } 
            else if ('\0' != *end) 
            {
                printf("[%s:%d]%s: extra characters at end of input\n", __FUNCTION__, __LINE__, cp);
            } 
            else if ((LONG_MIN == sl || LONG_MAX == sl) && ERANGE == errno) 
            {
                printf("[%s:%d]%s out of range of type long\n", __FUNCTION__, __LINE__, cp);
            } 
            else 
            {
                pcurr->pid = (int)sl;
            }

        }
        else if (!strncmp(buff, "PPid:", 5))
        {
            if (EOF == sscanf(cp, "%d", &pcurr->ppid))
            {
                dbgInfo("[%s:%d]sscanf fail!\n", __FUNCTION__, __LINE__);
            }
        }
    }
}


/**********************************************************************
* 函数名称：void i(viod)
* 功能描述：显示任务信息列表
* 访问的表：
* 修改的表：无
* 输入参数：
* 输出参数：无
* 返 回 值：无
* 其它说明：
* 修改日期        版本号     修改人          修改内容
* -----------------------------------------------
  2009.12.15        UniBTSV1.0          chenlinhai        创建
************************************************************************/
void i(VOID)
{
    struct dirent **pNameList;
    int iFileNum;
    int iloop;
    CHAR aucbuff[120];
    struct plist tList;
    struct sched_param    param;
    int pid = 0;
    INT32 iRet = 0;
    CHAR *end;
    
    FILE *fd;
    CHAR buff[1024];
    
    WORD32 CurProcessID =0;
    CurProcessID = getpid();
    INT32 iTmpRet = 0;
    //获取线程ID
    iTmpRet = snprintf_s(aucbuff,sizeof(aucbuff), "/proc/%d/task",CurProcessID);
    SNPRINTF_S_CHECK(iTmpRet, sizeof(aucbuff));

     /*调用系统调用查看目录下的文件*/
     /*lint -e605*/
    iFileNum= scandir(aucbuff, &pNameList, proc_filter, 0);
     /*lint +e605*/

     //iFileNum= scandir(aucbuff, &pNameList, 0, alphasort); /*调用系统调用查看目录下的文件*/
    if (iFileNum< 0)
    {
        printf("scandir line :%d \n",__LINE__);
    }
    else 
    {
        printf("pid:   state:   tgid:   ppid:   priority:   name:         \n");
        //获取每个线程的属性
        for(iloop=0 ; iloop<iFileNum ; iloop++)
        {

            /*sprintf(buff, "/proc/%d/task/%s/status", CurProcessID,pNameList[iloop]->d_name);*/
            iRet = snprintf_s(buff, 1024,"/proc/%d/task/%s/status", CurProcessID,pNameList[iloop]->d_name);
            SNPRINTF_S_CHECK(iRet, 1024);
            if (NULL == (fd = fopen(buff, "r")))
            {
                //printf("fopen:%s failed line :%d \n",buff,__LINE__);
                continue;
            }
            else
            {
                //printf("fopen:%s success line :%d \n",buff,__LINE__);
            }

            const long sl = strtol(pNameList[iloop]->d_name, &end, 10);
            errno = 0;
            
            if (end == pNameList[iloop]->d_name) 
            {
                printf("[%s:%d]%s: not a decimal number\n", __FUNCTION__, __LINE__, pNameList[iloop]->d_name);
            } 
            else if ('\0' != *end) 
            {
                printf("[%s:%d]%s: extra characters at end of input: %s\n", __FUNCTION__, __LINE__, pNameList[iloop]->d_name, end);
            } 
            else if ((LONG_MIN == sl || LONG_MAX == sl) && ERANGE == errno) 
            {
                printf("[%s:%d]%s out of range of type long\n", __FUNCTION__, __LINE__, pNameList[iloop]->d_name);
            } 
            else 
            {
                pid = (int)sl;
            }

            sched_getparam(pid,&param);  
            tList.priority = param.__sched_priority; 
        
            fill_plist(fd,&tList);
            printf("%4d     %4c  %4d    %4d   %4d        %12s \n",
                   tList.pid,
                   tList.state,
                   tList.tgid,
                   tList.ppid,
                   tList.priority,
                   tList.name
                   );
            iTmpRet = fclose(fd);
            FCLOSE_CHECK(iTmpRet);
            free(pNameList[iloop]);
        }
        free(pNameList);
    }
}



/**********************************************************************
* 函数名称：void lkup(char *substr)
* 功能描述：打印出跟入参有相同子字串的符号
* 访问的表：
* 修改的表：无
* 输入参数：substr:想查找的字串
* 输出参数：无
* 返 回 值：无
* 其它说明：
* 修改日期        版本号     修改人          修改内容
* -----------------------------------------------
  2010.03.23        UniBTSV1.0          chenlinhai        创建
************************************************************************/
void lkup(char *substr)
{
    UCHAR ucRadioMode = 0;
  if((NULL == substr) || (strlen(substr) == 0))
  {
    printf("NULL\n");
    return;
  }
  symShowEx(substr,ucRadioMode);
}
//#endif








/*ushell_oss*/

